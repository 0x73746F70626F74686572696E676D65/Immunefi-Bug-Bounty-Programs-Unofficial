package keeper_test

import (
	"fmt"
	"math/big"
	"time"

	sdkmath "cosmossdk.io/math"
	sdk "github.com/cosmos/cosmos-sdk/types"
	markertypes "github.com/provenance-io/provenance/x/marker/types"

	"github.com/provlabs/vault/interest"
	"github.com/provlabs/vault/keeper"
	"github.com/provlabs/vault/types"
)

func (s *TestSuite) TestKeeper_ReconcileVault() {
	shareDenom := "vaultshares"
	underlying := sdk.NewInt64Coin("underlying", 1_000_000_000)
	totalShares := sdk.NewInt64Coin(shareDenom, 1_000_000_000_000_000)
	vaultAddress := types.GetVaultAddress(shareDenom)
	testBlockTime := time.Now()
	futureTime := testBlockTime.Add(100 * time.Second)
	pastTime := testBlockTime.Add(-60 * 24 * time.Hour)
	interestEarnedAtPositiveRate := sdkmath.NewInt(41_952_013)
	feeOnTVVAfterPositiveInterest := sdkmath.NewInt(256_919)
	interestPaidAtNegativeRate := sdkmath.NewInt(40_262_904)
	feeOnTVVAfterNegativeInterest := sdkmath.NewInt(236_647)

	tests := []struct {
		name              string
		interestRate      string
		periodStart       int64
		paused            bool
		expectedVaultAmt  sdkmath.Int
		expectedMarkerAmt sdkmath.Int
		inPayoutQueue     bool
		expectedErrSubstr string
		expectedEvents    func() sdk.Events
	}{
		{
			name:              "no start period found, should set period start and return no error",
			interestRate:      "0.25",
			periodStart:       0,
			expectedVaultAmt:  underlying.Amount,
			expectedMarkerAmt: underlying.Amount,
			inPayoutQueue:     true,
		},
		{
			name:              "interest period start in future, should return nil and do nothing",
			interestRate:      "0.25",
			periodStart:       futureTime.Unix(),
			expectedVaultAmt:  underlying.Amount,
			expectedMarkerAmt: underlying.Amount,
			inPayoutQueue:     true,
		},
		{
			name:              "interest period has elasped, should pay interest and update period start",
			interestRate:      "0.25",
			periodStart:       pastTime.Unix(),
			expectedVaultAmt:  underlying.Amount.Sub(interestEarnedAtPositiveRate),
			expectedMarkerAmt: underlying.Amount.Add(interestEarnedAtPositiveRate).Sub(feeOnTVVAfterPositiveInterest),
			inPayoutQueue:     true,
			expectedEvents: func() sdk.Events {
				markerAddr := markertypes.MustGetMarkerAddress(shareDenom)
				ev := createReconcileEvents(
					vaultAddress,
					markerAddr,
					sdkmath.NewInt(41_952_013),
					sdkmath.NewInt(1_000_000_000),
					sdkmath.NewInt(1_041_952_013),
					underlying.Denom,
					"0.25",
					5_184_000,
				)
				provlabsAddr, err := s.k.GetAUMFeeAddress(s.ctx)
				s.Require().NoError(err, "failed to get AUM fee address")

				feeEvs := createSendCoinEvents(markerAddr.String(), provlabsAddr.String(), "256919underlying")
				feeEv := createVaultFeeCollectedEvent(
					vaultAddress,
					sdk.NewCoin(underlying.Denom, sdkmath.NewInt(1_041_952_013)),
					sdk.NewCoin(underlying.Denom, sdkmath.NewInt(256_919)),
					sdk.NewCoin(underlying.Denom, sdkmath.NewInt(256_919)),
					sdk.NewCoin(underlying.Denom, sdkmath.ZeroInt()),
					5_184_000,
				)

				nav := createMarkerSetNAV(
					shareDenom,
					sdk.NewCoin(underlying.Denom, sdkmath.NewInt(1_041_695_094)),
					"vault",
					totalShares.Amount.Uint64(),
				)
				all := append(ev, feeEvs...)
				all = append(all, feeEv, nav)
				return all
			},
		},
		{
			name:              "interest period has elasped, should pay negative interest and update period start",
			interestRate:      "-0.25",
			periodStart:       pastTime.Unix(),
			expectedVaultAmt:  underlying.Amount.Add(interestPaidAtNegativeRate),
			expectedMarkerAmt: underlying.Amount.Sub(interestPaidAtNegativeRate).Sub(feeOnTVVAfterNegativeInterest),
			inPayoutQueue:     true,
			expectedEvents: func() sdk.Events {
				markerAddr := markertypes.MustGetMarkerAddress(shareDenom)
				ev := createReconcileEvents(
					vaultAddress,
					markerAddr,
					sdkmath.NewInt(-40_262_904),
					sdkmath.NewInt(1_000_000_000),
					sdkmath.NewInt(959_737_096),
					underlying.Denom,
					"-0.25",
					5_184_000,
				)
				provlabsAddr, err := s.k.GetAUMFeeAddress(s.ctx)
				s.Require().NoError(err, "failed to get AUM fee address")

				feeEvs := createSendCoinEvents(markerAddr.String(), provlabsAddr.String(), "236647underlying")
				feeEv := createVaultFeeCollectedEvent(
					vaultAddress,
					sdk.NewCoin(underlying.Denom, sdkmath.NewInt(959_737_096)),
					sdk.NewCoin(underlying.Denom, sdkmath.NewInt(236_647)),
					sdk.NewCoin(underlying.Denom, sdkmath.NewInt(236_647)),
					sdk.NewCoin(underlying.Denom, sdkmath.ZeroInt()),
					5_184_000,
				)

				nav := createMarkerSetNAV(
					shareDenom,
					sdk.NewCoin(underlying.Denom, sdkmath.NewInt(959_500_449)),
					"vault",
					totalShares.Amount.Uint64(),
				)
				all := append(ev, feeEvs...)
				all = append(all, feeEv, nav)
				return all
			},
		},
		{
			name:              "paused vault, should do nothing",
			interestRate:      "0.25",
			periodStart:       pastTime.Unix(),
			paused:            true,
			expectedVaultAmt:  underlying.Amount,
			expectedMarkerAmt: underlying.Amount,
			inPayoutQueue:     false,
		},
	}

	for _, tc := range tests {
		s.Run(tc.name, func() {
			s.SetupTest()
			s.setupReconcileVault(tc.interestRate, tc.periodStart, tc.paused, underlying, shareDenom, totalShares, testBlockTime)

			vault, err := s.k.GetVault(s.ctx, vaultAddress)
			s.Require().NoError(err, "failed to get vault %s before reconcile", vaultAddress.String())
			err = s.k.TestAccessor_reconcileVault(s.T(), s.ctx, vault)

			if len(tc.expectedErrSubstr) > 0 {
				s.Require().Error(err, "expected error from ReconcileVault for case: %s", tc.name)
				s.Require().Contains(err.Error(), tc.expectedErrSubstr, "error substring mismatch for case: %s", tc.name)
			} else {
				s.Require().NoError(err, "ReconcileVault should not error for case: %s", tc.name)
			}

			s.assertInPayoutVerificationQueue(vaultAddress, tc.inPayoutQueue)
			s.assertVaultAndMarkerBalances(vaultAddress, shareDenom, underlying.Denom, tc.expectedVaultAmt, tc.expectedMarkerAmt)

			if tc.paused {
				updatedVault, err := s.k.GetVault(s.ctx, vaultAddress)
				s.Require().NoError(err, "failed to get vault %s after reconcile", vaultAddress.String())
				s.Require().Equal(tc.periodStart, updatedVault.PeriodStart, "PeriodStart should remain unchanged when paused for case: %s", tc.name)
			}

			var expectedEvents sdk.Events = sdk.Events{}
			if tc.expectedEvents != nil {
				expectedEvents = tc.expectedEvents()
			}
			s.Assert().Equal(
				normalizeEvents(expectedEvents),
				normalizeEvents(s.ctx.EventManager().Events()),
				"events mismatch for case: %s", tc.name,
			)
		})
	}
}

func (s *TestSuite) TestKeeper_PerformVaultReconcile_CompositeWithOutstandingFee() {
	shareDenom := "composite.shares"
	underlyingDenom := "underlying"
	heldDenom := "held"
	vaultAddress := types.GetVaultAddress(shareDenom)
	testBlockTime := time.Date(2024, 3, 1, 0, 0, 0, 0, time.UTC)
	sixtyDays := 60 * 24 * time.Hour
	pastTime := testBlockTime.Add(-sixtyDays)

	setupVaultWithHeldAssetAndOutstandingFee := func(outstanding sdk.Coin, markerLiquidity sdk.Coins, heldNavPrice *sdk.Coin) *types.VaultAccount {
		s.SetupTest()
		s.requireAddFinalizeAndActivateMarker(sdk.NewInt64Coin(underlyingDenom, 10_000_000_000), s.adminAddr)
		s.requireAddFinalizeAndActivateMarker(sdk.NewInt64Coin(heldDenom, 10_000_000_000), s.adminAddr)

		vault := s.CreateVaultWithParams(shareDenom, underlyingDenom)
		vault.CurrentInterestRate = "0.25"
		vault.DesiredInterestRate = "0.25"
		vault.PeriodStart = pastTime.Unix()
		vault.FeePeriodStart = pastTime.Unix()
		vault.OutstandingAumFee = outstanding
		s.k.AuthKeeper.SetAccount(s.ctx, vault)

		markerAddr := markertypes.MustGetMarkerAddress(shareDenom)
		s.Require().NoError(FundAccount(s.ctx, s.simApp, markerAddr, markerLiquidity), "failed to fund marker account with liquidity")
		s.Require().NoError(FundAccount(s.ctx, s.simApp, vaultAddress, sdk.NewCoins(sdk.NewInt64Coin(underlyingDenom, 1_000_000_000))), "failed to fund vault reserves")

		if heldNavPrice == nil {
			heldNavPrice = &sdk.Coin{Denom: underlyingDenom, Amount: sdkmath.NewInt(1)}
		}

		s.setVaultNAV(vault, heldDenom, *heldNavPrice, 1)

		s.ctx = s.ctx.WithBlockTime(testBlockTime).WithEventManager(sdk.NewEventManager())
		return vault
	}

	s.Run("Case 1: Full Collection (Sufficient Liquidity)", func() {
		outstanding := sdk.NewInt64Coin(underlyingDenom, 100_000)
		markerLiquidity := sdk.NewCoins(
			sdk.NewInt64Coin(underlyingDenom, 1_000_000_000),
			sdk.NewInt64Coin(heldDenom, 1_000_000),
		)
		vault := setupVaultWithHeldAssetAndOutstandingFee(outstanding, markerLiquidity, nil)

		expectedInterest := sdkmath.NewInt(41_993_965)

		err := s.k.TestAccessor_reconcileVault(s.T(), s.ctx, vault)
		s.Require().NoError(err, "reconcileVault should not error for case: Full Collection")

		events := normalizeEvents(s.ctx.EventManager().Events())
		var reconcileEv *sdk.Event
		for i := range events {
			if events[i].Type == "provlabs.vault.v1.EventVaultReconcile" {
				reconcileEv = &events[i]
				break
			}
		}
		s.Require().NotNil(reconcileEv, "EventVaultReconcile should be emitted in Case 1 (events: %v)", events)
		s.Require().Equal("1001000000underlying", getAttribute(*reconcileEv, "principal_before"), "principal_before mismatch in Case 1")
		s.Require().Equal(expectedInterest.String()+"underlying", getAttribute(*reconcileEv, "interest_earned"), "interest_earned should be 0.25 on gross TVV 1,001,000,000 (underlying + held) over 60 days = 41,993,965 in Case 1")

		updatedVault, err := s.k.GetVault(s.ctx, vaultAddress)
		s.Require().NoError(err, "failed to get updated vault")
		s.Require().True(updatedVault.OutstandingAumFee.IsZero(), "all fees should be cleared")

		provlabsAddr, err := s.k.GetAUMFeeAddress(s.ctx)
		s.Require().NoError(err, "failed to get AUM fee address")
		currentFeeOnTVVAfterInterest := sdkmath.NewInt(257_176)
		s.assertBalance(provlabsAddr, underlyingDenom, currentFeeOnTVVAfterInterest.Add(outstanding.Amount))
	})

	s.Run("Case 2: Partial Collection (Insufficient Underlying Liquidity)", func() {
		outstanding := sdk.NewInt64Coin(underlyingDenom, 1_000_000)
		markerLiquidity := sdk.NewCoins(
			sdk.NewInt64Coin(underlyingDenom, 100_000),
			sdk.NewInt64Coin(heldDenom, 1_000_000),
		)
		vault := setupVaultWithHeldAssetAndOutstandingFee(outstanding, markerLiquidity, nil)
		vault.CurrentInterestRate = "0"
		vault.DesiredInterestRate = "0"
		vault.AumFeeBips = 0
		s.k.AuthKeeper.SetAccount(s.ctx, vault)

		err := s.k.TestAccessor_reconcileVault(s.T(), s.ctx, vault)
		s.Require().NoError(err, "reconcileVault should not error for case: Partial Collection")

		updatedVault, err := s.k.GetVault(s.ctx, vaultAddress)
		s.Require().NoError(err, "failed to get updated vault")
		s.Require().Equal(sdkmath.NewInt(900_000), updatedVault.OutstandingAumFee.Amount, "outstanding fee should be the 1,000,000 liability minus the marker's 100,000 of underlying liquidity collected in Case 2, uncapped because the illiquid held asset keeps gross TVV above the liability")

		provlabsAddr, err := s.k.GetAUMFeeAddress(s.ctx)
		s.Require().NoError(err, "failed to get AUM fee address")
		s.assertBalance(provlabsAddr, underlyingDenom, sdkmath.NewInt(100_000))
	})

	s.Run("Case 3: Interest Accrual on Debted Assets (Verify Gross Logic)", func() {
		outstanding := sdk.NewInt64Coin(underlyingDenom, 500_000_000)
		markerLiquidity := sdk.NewCoins(
			sdk.NewInt64Coin(underlyingDenom, 1_000_000_000),
			sdk.NewInt64Coin(heldDenom, 500_000_000),
		)
		vault := setupVaultWithHeldAssetAndOutstandingFee(outstanding, markerLiquidity, nil)

		expectedInterest := sdkmath.NewInt(62_928_020)

		err := s.k.TestAccessor_reconcileVault(s.T(), s.ctx, vault)
		s.Require().NoError(err, "reconcileVault should not error for case: Interest Accrual on Debted Assets")

		events := normalizeEvents(s.ctx.EventManager().Events())
		var reconcileEv *sdk.Event
		for i := range events {
			if events[i].Type == "provlabs.vault.v1.EventVaultReconcile" {
				reconcileEv = &events[i]
				break
			}
		}
		s.Require().NotNil(reconcileEv, "EventVaultReconcile should be emitted in Case 3 (events: %v)", events)
		s.Require().Equal("1500000000underlying", getAttribute(*reconcileEv, "principal_before"), "principal_before mismatch in Case 3")
		s.Require().Equal(expectedInterest.String()+"underlying", getAttribute(*reconcileEv, "interest_earned"), "interest_earned should accrue on gross TVV 1,500,000,000 (not net of the 500,000,000 fee debt) = 62,928,020 in Case 3")
	})

	s.Run("Case 4: Net Valuation for Share Pricing", func() {
		outstanding := sdk.NewInt64Coin(underlyingDenom, 100_000_000)
		markerLiquidity := sdk.NewCoins(sdk.NewInt64Coin(underlyingDenom, 1_000_000_000))
		vault := setupVaultWithHeldAssetAndOutstandingFee(outstanding, markerLiquidity, nil)

		tvv, err := s.k.GetTVV(s.ctx, *vault)
		s.Require().NoError(err, "failed to get TVV in underlying asset")
		s.Require().Equal(sdkmath.NewInt(1_000_000_000), tvv, "GetTVV returns Gross")

		expectedNetValuation := sdkmath.NewInt(941_695_094)

		val, err := s.k.CalculateVaultTotalAssets(s.ctx, vault, sdk.NewInt64Coin(underlyingDenom, 1_000_000_000))
		s.Require().NoError(err, "CalculateVaultTotalAssets should not error for case: Net Valuation for Share Pricing")
		s.Require().Equal(expectedNetValuation, val, "valuation should be net of outstanding fees: gross 1,000,000,000 + interest 41,952,013 - fee 256,919 - debt 100,000,000 = 941,695,094")
	})

	s.Run("Case 5: Negative Interest with Liabilities", func() {
		outstanding := sdk.NewInt64Coin(underlyingDenom, 100_000)
		markerLiquidity := sdk.NewCoins(sdk.NewInt64Coin(underlyingDenom, 1_000_000_000))
		vault := setupVaultWithHeldAssetAndOutstandingFee(outstanding, markerLiquidity, nil)
		vault.CurrentInterestRate = "-0.25"
		vault.DesiredInterestRate = "-0.25"
		s.k.AuthKeeper.SetAccount(s.ctx, vault)

		expectedRefund := sdkmath.NewInt(40_262_904)

		err := s.k.TestAccessor_reconcileVault(s.T(), s.ctx, vault)
		s.Require().NoError(err, "reconcileVault should not error for case: Negative Interest with Liabilities")

		events := normalizeEvents(s.ctx.EventManager().Events())
		var reconcileEv *sdk.Event
		for i := range events {
			if events[i].Type == "provlabs.vault.v1.EventVaultReconcile" {
				reconcileEv = &events[i]
				break
			}
		}
		s.Require().NotNil(reconcileEv, "EventVaultReconcile should be emitted in Case 5 (events: %v)", events)
		s.Require().Equal(expectedRefund.Neg().String()+"underlying", getAttribute(*reconcileEv, "interest_earned"), "interest_earned should be -0.25 on gross TVV 1,000,000,000 over 60 days = -40,262,904 in Case 5")

		s.assertBalance(vaultAddress, underlyingDenom, sdkmath.NewInt(1_000_000_000).Add(expectedRefund))
	})
}

func (s *TestSuite) TestKeeper_ReconcileLeavesUncollectedFee_PricesOffNetTVV() {
	shareDenom := "underfunded.shares"
	underlyingDenom := "underlying"
	heldDenom := "held"
	vaultAddress := types.GetVaultAddress(shareDenom)
	testBlockTime := time.Date(2024, 3, 1, 0, 0, 0, 0, time.UTC)
	pastTime := testBlockTime.Add(-60 * 24 * time.Hour)

	s.requireAddFinalizeAndActivateMarker(sdk.NewInt64Coin(underlyingDenom, 10_000_000_000), s.adminAddr)
	s.requireAddFinalizeAndActivateMarker(sdk.NewInt64Coin(heldDenom, 10_000_000_000), s.adminAddr)

	vault := s.CreateVaultWithParams(shareDenom, underlyingDenom)
	vault.CurrentInterestRate = "0"
	vault.DesiredInterestRate = "0"
	vault.AumFeeBips = 0
	vault.PeriodStart = pastTime.Unix()
	vault.FeePeriodStart = pastTime.Unix()
	vault.OutstandingAumFee = sdk.NewInt64Coin(underlyingDenom, 100_000_000)
	totalShares := sdk.NewInt64Coin(shareDenom, 1_000_000)
	vault.TotalShares = totalShares
	s.k.AuthKeeper.SetAccount(s.ctx, vault)
	s.Require().NoError(s.k.MarkerKeeper.MintCoin(s.ctx, vault.GetAddress(), totalShares), "should mint share supply")

	s.setVaultNAV(vault, heldDenom, sdk.NewInt64Coin(underlyingDenom, 1), 1)

	s.Require().NoError(FundAccount(s.ctx, s.simApp, vault.PrincipalMarkerAddress(), sdk.NewCoins(
		sdk.NewInt64Coin(heldDenom, 1_000_000_000),
	)), "should fund principal marker with the held asset only, leaving no underlying liquidity to pay the fee")

	s.SetCtxBlockTime(testBlockTime)

	err := s.k.TestAccessor_reconcileVault(s.T(), s.ctx, vault)
	s.Require().NoError(err, "reconcileVault should not error")

	reconciled, err := s.k.GetVault(s.ctx, vaultAddress)
	s.Require().NoError(err, "should fetch reconciled vault")

	s.Require().Equal(sdkmath.NewInt(100_000_000), reconciled.OutstandingAumFee.Amount, "fee could not be collected, so the full liability survives reconcile")
	provlabsAddr, err := s.k.GetAUMFeeAddress(s.ctx)
	s.Require().NoError(err, "should get AUM fee address")
	s.assertBalance(provlabsAddr, underlyingDenom, sdkmath.ZeroInt())

	grossTVV, err := s.k.GetTVV(s.ctx, *reconciled)
	s.Require().NoError(err, "should compute gross TVV")
	s.Require().Equal(sdkmath.NewInt(1_000_000_000), grossTVV, "gross TVV still counts the assets backing the unpaid fee")
	netTVV, err := s.k.GetNetTVV(s.ctx, *reconciled)
	s.Require().NoError(err, "should compute net TVV")
	s.Require().Equal(sdkmath.NewInt(900_000_000), netTVV, "net TVV = gross 1,000,000,000 minus outstanding fee 100,000,000, so gross > net even after reconcile")

	grossView := *reconciled
	grossView.OutstandingAumFee = sdk.NewInt64Coin(underlyingDenom, 0)

	navNet, err := s.k.GetNAVPerShare(s.ctx, *reconciled)
	s.Require().NoError(err, "should compute net NAV per share")
	s.Require().Equal(sdkmath.NewInt(900), navNet, "net NAV per share = 900,000,000 / 1,000,000")
	navGross, err := s.k.GetNAVPerShare(s.ctx, grossView)
	s.Require().NoError(err, "should compute gross NAV per share")
	s.Require().Equal(sdkmath.NewInt(1_000), navGross, "gross NAV per share = 1,000,000,000 / 1,000,000")

	deposit := sdk.NewInt64Coin(underlyingDenom, 1_000_000)
	netMint, err := s.k.ConvertDepositToShares(s.ctx, *reconciled, deposit)
	s.Require().NoError(err, "net deposit conversion should succeed")
	grossMint, err := s.k.ConvertDepositToShares(s.ctx, grossView, deposit)
	s.Require().NoError(err, "gross deposit conversion should succeed")
	s.Require().True(netMint.Amount.GT(grossMint.Amount), "net pricing mints more shares per deposit than gross would (gross overstates TVV)")

	redeemShares := sdkmath.NewInt(100_000)
	netRedeem, err := s.k.ConvertSharesToRedeemCoin(s.ctx, *reconciled, redeemShares)
	s.Require().NoError(err, "net redeem conversion should succeed")
	grossRedeem, err := s.k.ConvertSharesToRedeemCoin(s.ctx, grossView, redeemShares)
	s.Require().NoError(err, "gross redeem conversion should succeed")
	s.Require().True(netRedeem.Amount.LT(grossRedeem.Amount), "net pricing pays out less per share than gross would (gross overstates TVV)")
}

func (s *TestSuite) TestKeeper_CalculateVaultTotalAssets() {
	shareDenom := "vaultshares"
	underlying := sdk.NewInt64Coin("underlying", 1_000_000_000)
	vaultAddress := types.GetVaultAddress(shareDenom)
	testBlockTime := time.Now()
	pastTime := testBlockTime.Add(-60 * 24 * time.Hour)

	setup := func(interestRate string, periodStartSeconds int64) *types.VaultAccount {
		s.requireAddFinalizeAndActivateMarker(underlying, s.adminAddr)
		_, err := s.k.CreateVault(s.ctx, &types.MsgCreateVaultRequest{
			Admin:           s.adminAddr.String(),
			ShareDenom:      shareDenom,
			UnderlyingAsset: underlying.Denom,
		})
		s.Require().NoError(err, "CreateVault should not error in CalculateVaultTotalAssets setup")

		vault, err := s.k.GetVault(s.ctx, vaultAddress)
		s.Require().NoError(err, "GetVault should not error in CalculateVaultTotalAssets setup")
		vault.CurrentInterestRate = interestRate
		vault.PeriodStart = periodStartSeconds
		vault.FeePeriodStart = testBlockTime.Unix()
		s.k.AuthKeeper.SetAccount(s.ctx, vault)

		s.ctx = s.ctx.WithBlockTime(testBlockTime)
		return vault
	}

	tests := []struct {
		name             string
		rate             string
		startTime        int64
		expectedIncrease sdkmath.Int
		expectErr        bool
	}{
		{
			name:             "no interest rate set",
			rate:             "",
			startTime:        pastTime.Unix(),
			expectedIncrease: sdkmath.NewInt(1_000_000_000),
		},
		{
			name:             "zero interest rate",
			rate:             types.ZeroInterestRate,
			startTime:        pastTime.Unix(),
			expectedIncrease: sdkmath.NewInt(1_000_000_000),
		},
		{
			name:             "no start time",
			rate:             "1.0",
			startTime:        0,
			expectedIncrease: sdkmath.NewInt(1_000_000_000),
		},
		{
			name:             "interest accrues positively",
			rate:             "0.25",
			startTime:        pastTime.Unix(),
			expectedIncrease: sdkmath.NewInt(1_041_952_013),
		},
		{
			name:             "negative interest accrues",
			rate:             "-0.25",
			startTime:        pastTime.Unix(),
			expectedIncrease: sdkmath.NewInt(959_737_096),
		},
		{
			name:             "period in future returns original amount",
			rate:             "0.25",
			startTime:        testBlockTime.Add(100 * time.Second).Unix(),
			expectedIncrease: sdkmath.NewInt(1_000_000_000),
		},
	}

	for _, tc := range tests {
		s.Run(tc.name, func() {
			s.SetupTest()
			vault := setup(tc.rate, tc.startTime)
			est, err := s.k.CalculateVaultTotalAssets(s.ctx, vault, underlying)

			if tc.expectErr {
				s.Require().Error(err, "test case %s: expected error from CalculateVaultTotalAssets", tc.name)
			} else {
				s.Require().NoError(err, "test case %s: CalculateVaultTotalAssets should not error", tc.name)
				s.Require().Equal(tc.expectedIncrease, est, "test case %s: total assets estimation mismatch", tc.name)
			}
		})
	}
}

func (s *TestSuite) TestKeeper_HandleVaultInterestTimeouts() {
	now := time.Now()
	twoMonthsAgo := now.Add(-60 * 24 * time.Hour).Unix()
	testBlockTime := now
	shareDenom := "vaultshares"
	underlying := sdk.NewInt64Coin("underlying", 1_000_000_000)
	vaultAddr := types.GetVaultAddress(shareDenom)
	markerAddr := markertypes.MustGetMarkerAddress(shareDenom)

	tests := []struct {
		name           string
		setup          func()
		postCheck      func()
		expectRate     string
		expectedEvents sdk.Events
	}{
		{
			name: "happy path: interest paid and period reset",
			setup: func() {
				s.requireAddFinalizeAndActivateMarker(underlying, s.adminAddr)
				_, err := s.k.CreateVault(s.ctx, &types.MsgCreateVaultRequest{
					Admin:           s.adminAddr.String(),
					ShareDenom:      shareDenom,
					UnderlyingAsset: underlying.Denom,
				})
				s.Require().NoError(err, "happy path: CreateVault should not error")
				vault, err := s.k.GetVault(s.ctx, vaultAddr)
				s.Require().NoError(err, "happy path: GetVault should not error")
				vault.CurrentInterestRate = "0.25"
				vault.DesiredInterestRate = "0.25"
				vault.PeriodStart = twoMonthsAgo
				vault.FeePeriodStart = twoMonthsAgo
				s.k.AuthKeeper.SetAccount(s.ctx, vault)
				s.Require().NoError(FundAccount(s.ctx, s.simApp, vaultAddr, sdk.NewCoins(underlying)), "happy path: funding vault account should not error")
				s.Require().NoError(FundAccount(s.ctx, s.simApp, markerAddr, sdk.NewCoins(underlying)), "happy path: funding marker account should not error")
				s.Require().NoError(s.k.PayoutTimeoutQueue.Enqueue(s.ctx, testBlockTime.Unix(), vault.GetAddress()), "happy path: enqueuing payout timeout should not error")
				s.ctx = s.ctx.WithBlockTime(testBlockTime).WithEventManager(sdk.NewEventManager())
			},
			expectRate: "0.25",
			expectedEvents: func() sdk.Events {
				markerAddr := markertypes.MustGetMarkerAddress(shareDenom)
				evs := sdk.Events{
					sdk.NewEvent("coin_spent",
						sdk.NewAttribute("spender", vaultAddr.String()),
						sdk.NewAttribute("amount", "41952013underlying"),
					),
					sdk.NewEvent("coin_received",
						sdk.NewAttribute("receiver", markerAddr.String()),
						sdk.NewAttribute("amount", "41952013underlying"),
					),
					sdk.NewEvent("transfer",
						sdk.NewAttribute("recipient", markerAddr.String()),
						sdk.NewAttribute("sender", vaultAddr.String()),
						sdk.NewAttribute("amount", "41952013underlying"),
					),
					sdk.NewEvent("message",
						sdk.NewAttribute("sender", vaultAddr.String()),
					),
					sdk.NewEvent("provlabs.vault.v1.EventVaultReconcile",
						sdk.NewAttribute("interest_earned", "41952013underlying"),
						sdk.NewAttribute("principal_after", "1041952013underlying"),
						sdk.NewAttribute("principal_before", "1000000000underlying"),
						sdk.NewAttribute("rate", "0.25"),
						sdk.NewAttribute("time", "5184000"),
						sdk.NewAttribute("vault_address", vaultAddr.String()),
					),
				}
				return evs
			}(),
		},
		{
			name: "vault cannot pay: interest set to 0 and record deleted",
			setup: func() {
				s.requireAddFinalizeAndActivateMarker(underlying, s.adminAddr)
				_, err := s.k.CreateVault(s.ctx, &types.MsgCreateVaultRequest{
					Admin:           s.adminAddr.String(),
					ShareDenom:      shareDenom,
					UnderlyingAsset: underlying.Denom,
				})
				s.Require().NoError(err, "vault cannot pay: CreateVault should not error")
				vault, err := s.k.GetVault(s.ctx, vaultAddr)
				s.Require().NoError(err, "vault cannot pay: GetVault should not error")
				vault.CurrentInterestRate = "0.25"
				vault.DesiredInterestRate = "0.25"
				s.k.AuthKeeper.SetAccount(s.ctx, vault)
				s.Require().NoError(FundAccount(s.ctx, s.simApp, markerAddr, sdk.NewCoins(underlying)), "vault cannot pay: funding marker account should not error")
				s.Require().NoError(s.k.SafeAddPayoutVerification(s.ctx, vault), "vault cannot pay: SafeAddPayoutVerification should not error")
				s.Require().NoError(s.k.PayoutTimeoutQueue.Enqueue(s.ctx, testBlockTime.Unix(), vault.GetAddress()), "vault cannot pay: enqueuing payout timeout should not error")
				s.ctx = s.ctx.WithBlockTime(testBlockTime).WithEventManager(sdk.NewEventManager())
			},
			expectRate: types.ZeroInterestRate,
			expectedEvents: sdk.Events{
				sdk.NewEvent("provlabs.vault.v1.EventVaultInterestChange",
					sdk.NewAttribute("current_rate", types.ZeroInterestRate),
					sdk.NewAttribute("desired_rate", "0.25"),
					sdk.NewAttribute("vault_address", vaultAddr.String()),
				),
			},
		},
		{
			name: "paused vault is not reconciled and is dequeued",
			setup: func() {
				s.requireAddFinalizeAndActivateMarker(underlying, s.adminAddr)
				_, err := s.k.CreateVault(s.ctx, &types.MsgCreateVaultRequest{
					Admin:           s.adminAddr.String(),
					ShareDenom:      shareDenom,
					UnderlyingAsset: underlying.Denom,
				})
				s.Require().NoError(err, "paused vault: CreateVault should not error")
				vault, err := s.k.GetVault(s.ctx, vaultAddr)
				s.Require().NoError(err, "paused vault: GetVault should not error")
				vault.Paused = true
				s.k.AuthKeeper.SetAccount(s.ctx, vault)
				s.Require().NoError(s.k.PayoutTimeoutQueue.Enqueue(s.ctx, testBlockTime.Unix(), vault.GetAddress()), "paused vault: enqueuing payout timeout should not error")
				s.ctx = s.ctx.WithBlockTime(testBlockTime).WithEventManager(sdk.NewEventManager())
			},
			postCheck: func() {
				s.Assert().Equal(0, s.countDuePayoutTimeouts(testBlockTime.Unix()), "paused vault should be dequeued from the payout timeout queue")
			},
			expectedEvents: sdk.Events{},
		},
		{
			name: "non-vault address in interest details does nothing",
			setup: func() {
				s.Require().NoError(s.k.PayoutVerificationSet.Set(s.ctx, markerAddr), "non-vault: PayoutVerificationSet.Set should not error")
				s.Require().NoError(s.k.PayoutTimeoutQueue.Enqueue(s.ctx, testBlockTime.Unix(), markerAddr), "non-vault: enqueuing payout timeout should not error")
				s.ctx = s.ctx.WithBlockTime(testBlockTime).WithEventManager(sdk.NewEventManager())
			},
			expectedEvents: sdk.Events{},
		},
	}

	for _, tc := range tests {
		s.Run(tc.name, func() {
			s.SetupTest()
			tc.setup()
			err := s.k.TestAccessor_handleVaultInterestTimeouts(s.T(), s.ctx, keeper.MaxInterestTimeoutsPerBlock)
			s.Require().NoError(err, "test case %s: handleVaultInterestTimeouts should not error", tc.name)
			if tc.expectRate != "" {
				vault, err := s.k.GetVault(s.ctx, vaultAddr)
				s.Require().NoError(err, "test case %s: GetVault should not error after timeout handling", tc.name)
				s.Require().Equal(tc.expectRate, vault.CurrentInterestRate, "test case %s: current interest rate mismatch", tc.name)
			}
			em := s.ctx.EventManager()
			s.Assert().Equalf(
				normalizeEvents(tc.expectedEvents),
				normalizeEvents(em.Events()),
				"test case %s: beginblocker events mismatch", tc.name,
			)
			if tc.postCheck != nil {
				tc.postCheck()
			}
		})
	}
}

func (s *TestSuite) TestKeeper_HandleReconciledVaults() {
	v1, v2 := NewVaultInfo(1), NewVaultInfo(2)
	orphanAddr := sdk.AccAddress("orphanVaultAddr_____")

	testBlockTime := time.Now().UTC().Truncate(time.Second)

	AssertIsPayable := func(info VaultInfo, expectedRate string) {
		s.T().Helper()
		vault, err := s.k.GetVault(s.ctx, info.vaultAddr)
		s.Require().NoError(err, "GetVault should not error for payable vault %s", info.vaultAddr)
		s.Require().NotNil(vault, "vault %s should not be nil", info.vaultAddr)
		s.Assert().Equal(expectedRate, vault.CurrentInterestRate, "interest rate should not change for payable vault %s", info.vaultAddr)
	}

	AssertIsDepleted := func(info VaultInfo) {
		s.T().Helper()
		vault, err := s.k.GetVault(s.ctx, info.vaultAddr)
		s.Require().NoError(err, "GetVault should not error for depleted vault %s", info.vaultAddr)
		s.Require().NotNil(vault, "vault %s should not be nil", info.vaultAddr)
		s.Assert().Equal(types.ZeroInterestRate, vault.CurrentInterestRate, "interest rate should be zeroed out for depleted vault %s", info.vaultAddr)
		s.assertInPayoutVerificationQueue(vault.GetAddress(), false)
	}

	tests := []struct {
		name           string
		setup          func()
		postCheck      func()
		expectErr      bool
		expectedEvents sdk.Events
	}{
		{
			name:  "no vaults in store",
			setup: func() {},
			postCheck: func() {
				vaults, err := s.k.GetVaults(s.ctx)
				s.Require().NoError(err, "no vaults: GetVaults should not error")
				s.Require().Empty(vaults, "no vaults: vaults should be empty")
			},
			expectErr:      false,
			expectedEvents: sdk.Events{},
		},
		{
			name: "one vault reconciled, sufficient funds",
			setup: func() {
				createVaultWithInterest(s, v1, "0.1", testBlockTime.Unix(), testBlockTime.Unix(), true, true)
			},
			postCheck: func() {
				AssertIsPayable(v1, "0.1")
			},
			expectErr:      false,
			expectedEvents: sdk.Events{},
		},
		{
			name: "one vault reconciled, insufficient funds",
			setup: func() {
				createVaultWithInterest(s, v1, "0.1", testBlockTime.Unix(), testBlockTime.Unix(), false, true)
			},
			postCheck: func() {
				AssertIsDepleted(v1)
			},
			expectErr: false,
			expectedEvents: sdk.Events{
				sdk.NewEvent(
					"provlabs.vault.v1.EventVaultInterestChange",
					sdk.NewAttribute("current_rate", types.ZeroInterestRate),
					sdk.NewAttribute("desired_rate", "0.1"),
					sdk.NewAttribute("vault_address", v1.vaultAddr.String()),
				),
			},
		},
		{
			name: "two vaults reconciled, one payable, one depleted",
			setup: func() {
				createVaultWithInterest(s, v1, "0.1", testBlockTime.Unix(), testBlockTime.Unix(), true, true)
				createVaultWithInterest(s, v2, "0.1", testBlockTime.Unix(), testBlockTime.Unix(), false, true)
			},
			postCheck: func() {
				AssertIsPayable(v1, "0.1")
				AssertIsDepleted(v2)
			},
			expectErr: false,
			expectedEvents: sdk.Events{
				sdk.NewEvent(
					"provlabs.vault.v1.EventVaultInterestChange",
					sdk.NewAttribute("current_rate", types.ZeroInterestRate),
					sdk.NewAttribute("desired_rate", "0.1"),
					sdk.NewAttribute("vault_address", v2.vaultAddr.String()),
				),
			},
		},
		{
			name: "paused vault is not reconciled and is removed from the verification set",
			setup: func() {
				vault := createVaultWithInterest(s, v1, "0.1", testBlockTime.Unix(), testBlockTime.Unix(), true, true)
				vault.Paused = true
				s.k.AuthKeeper.SetAccount(s.ctx, vault)
			},
			postCheck: func() {
				s.assertInPayoutVerificationQueue(v1.vaultAddr, false)
			},
			expectErr:      false,
			expectedEvents: sdk.Events{},
		},
		{
			name: "entry whose account is present but not a vault stays in the verification set",
			setup: func() {
				s.Require().NoError(
					s.k.PayoutVerificationSet.Set(s.ctx, s.adminAddr),
					"seeding the verification set with a non-vault address should not error",
				)
			},
			postCheck: func() {
				s.assertInPayoutVerificationQueue(s.adminAddr, true)
				s.Assert().Zero(s.countPayoutTimeoutsForVault(s.adminAddr), "an unreadable entry must not be promoted to the payout timeout queue")
			},
			expectErr:      false,
			expectedEvents: sdk.Events{},
		},
		{
			name: "orphaned entry whose vault account no longer exists is removed from the verification set",
			setup: func() {
				s.Require().False(
					s.simApp.AccountKeeper.HasAccount(s.ctx, orphanAddr),
					"the orphan address must have no account for this case to exercise the cleanup",
				)
				s.Require().NoError(
					s.k.PayoutVerificationSet.Set(s.ctx, orphanAddr),
					"seeding the verification set with an accountless address should not error",
				)
			},
			postCheck: func() {
				s.assertInPayoutVerificationQueue(orphanAddr, false)
				s.Assert().Zero(s.countPayoutTimeoutsForVault(orphanAddr), "an orphaned entry must not be promoted to the payout timeout queue")
			},
			expectErr:      false,
			expectedEvents: sdk.Events{},
		},
		{
			name: "vault whose payout forecast errors is deferred to the next timeout window",
			setup: func() {
				createVaultWithInterest(s, v1, "0.1", testBlockTime.Unix(), 0, true, true)
				s.requireUnpriceableVault(v1.vaultAddr)
			},
			postCheck: func() {
				s.assertInPayoutVerificationQueue(v1.vaultAddr, false)
				s.assertSinglePayoutTimeoutAt(v1.vaultAddr, testBlockTime.Unix()+keeper.AutoReconcileTimeout)
			},
			expectErr:      false,
			expectedEvents: sdk.Events{},
		},
		{
			name: "payable vault that cannot be persisted stays in the verification set",
			setup: func() {
				createVaultWithInterest(s, v1, "0.1", testBlockTime.Unix(), 0, true, true)
				s.requireUnpersistableVault(v1.vaultAddr)
			},
			postCheck: func() {
				s.assertInPayoutVerificationQueue(v1.vaultAddr, true)
				s.Assert().Zero(s.countPayoutTimeoutsForVault(v1.vaultAddr), "a failed promotion must not enqueue a payout timeout")
			},
			expectErr:      false,
			expectedEvents: sdk.Events{},
		},
		{
			name: "depleted vault that cannot be persisted stays in the verification set",
			setup: func() {
				createVaultWithInterest(s, v1, "0.1", testBlockTime.Unix(), 0, false, true)
				s.requireUnpersistableVault(v1.vaultAddr)
			},
			postCheck: func() {
				vault, err := s.k.GetVault(s.ctx, v1.vaultAddr)
				s.Require().NoError(err, "GetVault should not error after a failed demotion")
				s.Assert().Equal("0.1", vault.CurrentInterestRate, "a failed demotion must not zero the current rate")
				s.assertInPayoutVerificationQueue(v1.vaultAddr, true)
			},
			expectErr:      false,
			expectedEvents: sdk.Events{},
		},
	}

	for _, tc := range tests {
		s.Run(tc.name, func() {
			s.SetupTest()
			s.ctx = s.ctx.WithBlockTime(testBlockTime)
			if tc.setup != nil {
				tc.setup()
			}
			s.ctx = s.ctx.WithEventManager(sdk.NewEventManager())

			err := s.k.TestAccessor_handleReconciledVaults(s.T(), s.ctx, keeper.MaxPayoutVerificationsPerBlock)

			if tc.expectErr {
				s.Require().Error(err, "test case %s: expected error from handleReconciledVaults", tc.name)
			} else {
				s.Require().NoError(err, "test case %s: handleReconciledVaults should not error", tc.name)
			}

			actualEvents := normalizeEvents(s.ctx.EventManager().Events())
			expectedEvents := normalizeEvents(tc.expectedEvents)
			s.Assert().Equal(expectedEvents, actualEvents, "test case %s: emitted events mismatch", tc.name)

			if tc.postCheck != nil {
				tc.postCheck()
			}
		})
	}
}

func (s *TestSuite) TestKeeper_HandleReconciledVaults_FailedTransitionIsRetriedOnALaterBlock() {
	v1 := NewVaultInfo(1)
	testBlockTime := time.Now().UTC().Truncate(time.Second)
	initialRate := "0.1"

	tests := []struct {
		name             string
		fundReserves     bool
		assertTransition func()
	}{
		{
			name:         "payable vault is promoted once it can be persisted again",
			fundReserves: true,
			assertTransition: func() {
				s.assertSinglePayoutTimeoutAt(v1.vaultAddr, testBlockTime.Unix()+keeper.AutoReconcileTimeout)
			},
		},
		{
			name:         "depleted vault is zeroed once it can be persisted again",
			fundReserves: false,
			assertTransition: func() {
				vault, err := s.k.GetVault(s.ctx, v1.vaultAddr)
				s.Require().NoError(err, "GetVault should not error after the retried demotion")
				s.Assert().Equal(types.ZeroInterestRate, vault.CurrentInterestRate, "the retried demotion should zero the current rate")
			},
		},
	}

	for _, tc := range tests {
		s.Run(tc.name, func() {
			s.SetupTest()
			s.ctx = s.ctx.WithBlockTime(testBlockTime)
			createVaultWithInterest(s, v1, initialRate, testBlockTime.Unix(), 0, tc.fundReserves, true)
			s.requireUnpersistableVault(v1.vaultAddr)

			s.Require().NoError(
				s.k.TestAccessor_handleReconciledVaults(s.T(), s.ctx, keeper.MaxPayoutVerificationsPerBlock),
				"handleReconciledVaults should not error while the vault cannot be persisted",
			)
			s.assertInPayoutVerificationQueue(v1.vaultAddr, true)
			s.Assert().Zero(s.countPayoutTimeoutsForVault(v1.vaultAddr), "a failed transition must leave the vault unpromoted")

			s.writeVaultDesiredRate(v1.vaultAddr, initialRate)

			s.Require().NoError(
				s.k.TestAccessor_handleReconciledVaults(s.T(), s.ctx, keeper.MaxPayoutVerificationsPerBlock),
				"handleReconciledVaults should not error once the vault can be persisted",
			)
			s.assertInPayoutVerificationQueue(v1.vaultAddr, false)
			tc.assertTransition()
		})
	}
}

func (s *TestSuite) TestKeeper_HandleReconciledVaults_RetainedEntryDoesNotStarveOtherVaults() {
	infos := []VaultInfo{NewVaultInfo(1), NewVaultInfo(2), NewVaultInfo(3)}
	testBlockTime := time.Now().UTC().Truncate(time.Second)

	tests := []struct {
		name              string
		retainedIdx       int
		retainedIsPayable bool
	}{
		{
			name:              "retained payable vault does not hold the budget against the others",
			retainedIdx:       0,
			retainedIsPayable: true,
		},
		{
			name:              "retained depleted vault does not hold the budget against the others",
			retainedIdx:       2,
			retainedIsPayable: false,
		},
	}

	for _, tc := range tests {
		s.Run(tc.name, func() {
			s.SetupTest()
			s.ctx = s.ctx.WithBlockTime(testBlockTime)
			for i, info := range infos {
				fundReserves := i != tc.retainedIdx || tc.retainedIsPayable
				createVaultWithInterest(s, info, "0.1", testBlockTime.Unix(), 0, fundReserves, true)
			}
			s.requireUnpersistableVault(infos[tc.retainedIdx].vaultAddr)

			for block := range infos {
				s.Require().NoError(
					s.k.TestAccessor_handleReconciledVaults(s.T(), s.ctx, 1),
					"handleReconciledVaults should not error on pass %d", block+1,
				)
			}

			s.Assert().Equal(1, s.countPayoutVerificationEntries(), "only the retained vault should remain in the verification set")
			for i, info := range infos {
				s.assertInPayoutVerificationQueue(info.vaultAddr, i == tc.retainedIdx)
			}
		})
	}
}

func (s *TestSuite) TestKeeper_promotePayableVault() {
	v1 := NewVaultInfo(1)
	testBlockTime := time.Now().UTC().Truncate(time.Second)
	expectedTimeout := testBlockTime.Unix() + keeper.AutoReconcileTimeout

	tests := []struct {
		name      string
		setup     func() *types.VaultAccount
		postCheck func(vault *types.VaultAccount)
	}{
		{
			name: "payable vault is enqueued and leaves the verification set",
			setup: func() *types.VaultAccount {
				return createVaultWithInterest(s, v1, "0.1", testBlockTime.Unix(), 0, true, true)
			},
			postCheck: func(vault *types.VaultAccount) {
				promoted, err := s.k.GetVault(s.ctx, vault.GetAddress())
				s.Require().NoError(err, "GetVault should not error after promotion")
				s.Assert().Equal(expectedTimeout, promoted.PeriodTimeout, "promoted vault should record the next payout timeout")
				s.assertSinglePayoutTimeoutAt(vault.GetAddress(), expectedTimeout)
				s.assertInPayoutVerificationQueue(vault.GetAddress(), false)
			},
		},
		{
			name: "vault that cannot be persisted stays in the verification set and is not enqueued",
			setup: func() *types.VaultAccount {
				vault := createVaultWithInterest(s, v1, "0.1", testBlockTime.Unix(), 0, true, true)
				return s.requireUnpersistableVault(vault.GetAddress())
			},
			postCheck: func(vault *types.VaultAccount) {
				unpromoted, err := s.k.GetVault(s.ctx, vault.GetAddress())
				s.Require().NoError(err, "GetVault should not error after a failed promotion")
				s.Assert().Zero(unpromoted.PeriodTimeout, "a failed promotion must not record a payout timeout")
				s.Assert().Zero(s.countPayoutTimeoutsForVault(vault.GetAddress()), "a failed promotion must not enqueue a payout timeout")
				s.assertInPayoutVerificationQueue(vault.GetAddress(), true)
			},
		},
	}

	for _, tc := range tests {
		s.Run(tc.name, func() {
			s.SetupTest()
			s.ctx = s.ctx.WithBlockTime(testBlockTime)
			vault := tc.setup()
			s.k.TestAccessor_promotePayableVault(s.T(), s.ctx, vault)
			tc.postCheck(vault)
		})
	}
}

func (s *TestSuite) TestKeeper_demoteDepletedVault() {
	v1 := NewVaultInfo(1)
	initialRate := "0.1"

	tests := []struct {
		name           string
		setup          func() *types.VaultAccount
		postCheck      func(vault *types.VaultAccount)
		expectedEvents sdk.Events
	}{
		{
			name: "depleted vault has its rate zeroed and leaves the verification set",
			setup: func() *types.VaultAccount {
				return createVaultWithInterest(s, v1, initialRate, 0, 0, false, true)
			},
			postCheck: func(vault *types.VaultAccount) {
				demoted, err := s.k.GetVault(s.ctx, vault.GetAddress())
				s.Require().NoError(err, "GetVault should not error after demotion")
				s.Assert().Equal(types.ZeroInterestRate, demoted.CurrentInterestRate, "depleted vault should have its current rate zeroed")
				s.Assert().Equal(initialRate, demoted.DesiredInterestRate, "depleted vault should keep its desired rate")
				s.assertInPayoutVerificationQueue(vault.GetAddress(), false)
			},
			expectedEvents: sdk.Events{
				sdk.NewEvent(
					"provlabs.vault.v1.EventVaultInterestChange",
					sdk.NewAttribute("current_rate", types.ZeroInterestRate),
					sdk.NewAttribute("desired_rate", initialRate),
					sdk.NewAttribute("vault_address", v1.vaultAddr.String()),
				),
			},
		},
		{
			name: "vault that cannot be persisted keeps its rate and stays in the verification set",
			setup: func() *types.VaultAccount {
				vault := createVaultWithInterest(s, v1, initialRate, 0, 0, false, true)
				return s.requireUnpersistableVault(vault.GetAddress())
			},
			postCheck: func(vault *types.VaultAccount) {
				undemoted, err := s.k.GetVault(s.ctx, vault.GetAddress())
				s.Require().NoError(err, "GetVault should not error after a failed demotion")
				s.Assert().Equal(initialRate, undemoted.CurrentInterestRate, "a failed demotion must not zero the current rate")
				s.assertInPayoutVerificationQueue(vault.GetAddress(), true)
			},
			expectedEvents: sdk.Events{},
		},
	}

	for _, tc := range tests {
		s.Run(tc.name, func() {
			s.SetupTest()
			vault := tc.setup()

			s.ctx = s.ctx.WithEventManager(sdk.NewEventManager())
			s.k.TestAccessor_demoteDepletedVault(s.T(), s.ctx, vault)

			s.Assert().Equal(
				normalizeEvents(tc.expectedEvents),
				normalizeEvents(s.ctx.EventManager().Events()),
				"emitted events mismatch",
			)
			tc.postCheck(vault)
		})
	}
}

func (s *TestSuite) TestKeeper_deferPayoutVerification() {
	v1 := NewVaultInfo(1)
	testBlockTime := time.Now().UTC().Truncate(time.Second)
	periodStart := testBlockTime.Add(-time.Hour).Unix()
	expectedTimeout := testBlockTime.Unix() + keeper.AutoReconcileTimeout

	tests := []struct {
		name      string
		setup     func() *types.VaultAccount
		postCheck func(vault *types.VaultAccount)
	}{
		{
			name: "deferred vault moves to the next timeout window with its period start preserved",
			setup: func() *types.VaultAccount {
				return createVaultWithInterest(s, v1, "0.1", periodStart, 0, true, true)
			},
			postCheck: func(vault *types.VaultAccount) {
				deferred, err := s.k.GetVault(s.ctx, vault.GetAddress())
				s.Require().NoError(err, "GetVault should not error after deferral")
				s.Assert().Equal(expectedTimeout, deferred.PeriodTimeout, "deferred vault should be filed at the next payout timeout")
				s.Assert().Equal(periodStart, deferred.PeriodStart, "deferral must preserve the period start so accrued interest is not lost")
				s.assertSinglePayoutTimeoutAt(vault.GetAddress(), expectedTimeout)
				s.assertInPayoutVerificationQueue(vault.GetAddress(), false)
			},
		},
		{
			name: "vault that cannot be persisted stays in the verification set",
			setup: func() *types.VaultAccount {
				vault := createVaultWithInterest(s, v1, "0.1", periodStart, 0, true, true)
				return s.requireUnpersistableVault(vault.GetAddress())
			},
			postCheck: func(vault *types.VaultAccount) {
				s.Assert().Zero(s.countPayoutTimeoutsForVault(vault.GetAddress()), "a failed deferral must not enqueue a payout timeout")
				s.assertInPayoutVerificationQueue(vault.GetAddress(), true)
			},
		},
	}

	for _, tc := range tests {
		s.Run(tc.name, func() {
			s.SetupTest()
			s.ctx = s.ctx.WithBlockTime(testBlockTime)
			vault := tc.setup()
			vault.PeriodStart = periodStart
			s.k.TestAccessor_deferPayoutVerification(s.T(), s.ctx, vault)
			tc.postCheck(vault)
		})
	}
}

func (s *TestSuite) TestKeeper_retireDepletedVault() {
	v1 := NewVaultInfo(1)
	initialRate := "0.1"

	tests := []struct {
		name      string
		setup     func(dueTime int64) *types.VaultAccount
		postCheck func(vault *types.VaultAccount, dueTime int64)
	}{
		{
			name: "depleted vault has its rate zeroed and its due timeout dequeued",
			setup: func(dueTime int64) *types.VaultAccount {
				return s.createVaultWithDueInterestTimeout(v1, dueTime, false)
			},
			postCheck: func(vault *types.VaultAccount, _ int64) {
				retired, err := s.k.GetVault(s.ctx, vault.GetAddress())
				s.Require().NoError(err, "GetVault should not error after retirement")
				s.Assert().Equal(types.ZeroInterestRate, retired.CurrentInterestRate, "retired vault should have its current rate zeroed")
				s.Assert().Zero(s.countPayoutTimeoutsForVault(vault.GetAddress()), "a retired vault should have no payout timeout left")
			},
		},
		{
			name: "vault that cannot be persisted keeps its rate and its timeout stays queued",
			setup: func(dueTime int64) *types.VaultAccount {
				vault := s.createVaultWithDueInterestTimeout(v1, dueTime, false)
				return s.requireUnpersistableVault(vault.GetAddress())
			},
			postCheck: func(vault *types.VaultAccount, dueTime int64) {
				notRetired, err := s.k.GetVault(s.ctx, vault.GetAddress())
				s.Require().NoError(err, "GetVault should not error after a failed retirement")
				s.Assert().Equal(initialRate, notRetired.CurrentInterestRate, "a failed retirement must not zero the current rate")
				s.assertSinglePayoutTimeoutAt(vault.GetAddress(), dueTime)
			},
		},
	}

	for _, tc := range tests {
		s.Run(tc.name, func() {
			s.SetupTest()
			dueTime := s.ctx.BlockTime().Unix()
			vault := tc.setup(dueTime)
			s.k.TestAccessor_retireDepletedVault(s.T(), s.ctx, vault, dueTime)
			tc.postCheck(vault, dueTime)
		})
	}
}

func (s *TestSuite) TestKeeper_UpdateInterestRates() {
	v1 := NewVaultInfo(1)
	initialRate := "0.1"
	newRate := "0.2"
	desiredRate := "0.2"

	tests := []struct {
		name           string
		setup          func() *types.VaultAccount
		currentRate    string
		desiredRate    string
		expectedEvents sdk.Events
		postCheck      func(vault *types.VaultAccount)
	}{
		{
			name: "successful rate change",
			setup: func() *types.VaultAccount {
				return createVaultWithInterest(s, v1, initialRate, 0, 0, false, false)
			},
			currentRate: newRate,
			desiredRate: desiredRate,
			expectedEvents: sdk.Events{
				sdk.NewEvent(
					"provlabs.vault.v1.EventVaultInterestChange",
					sdk.NewAttribute("current_rate", newRate),
					sdk.NewAttribute("desired_rate", desiredRate),
					sdk.NewAttribute("vault_address", v1.vaultAddr.String()),
				),
			},
			postCheck: func(vault *types.VaultAccount) {
				updatedVault, err := s.k.GetVault(s.ctx, vault.GetAddress())
				s.Require().NoError(err, "retrieving updated vault should not error")
				s.Require().NotNil(updatedVault, "updated vault should not be nil")
				s.Assert().Equal(newRate, updatedVault.CurrentInterestRate, "current interest rate should be updated")
				s.Assert().Equal(desiredRate, updatedVault.DesiredInterestRate, "desired interest rate should be updated")
			},
		},
	}

	for _, tc := range tests {
		s.Run(tc.name, func() {
			s.SetupTest()
			vault := tc.setup()

			s.ctx = s.ctx.WithEventManager(sdk.NewEventManager())
			s.Require().NoError(s.k.UpdateInterestRates(s.ctx, vault, tc.currentRate, tc.desiredRate), "test case %s: interest rate update should succeed", tc.name)

			s.Assert().Equal(
				normalizeEvents(tc.expectedEvents),
				normalizeEvents(s.ctx.EventManager().Events()),
				"test case %s: emitted events mismatch", tc.name)

			if tc.postCheck != nil {
				tc.postCheck(vault)
			}
		})
	}
}

func createVaultWithInterest(s *TestSuite, info VaultInfo, interestRate string, periodStart, periodTimeout int64, fundReserves, fundPrincipal bool) *types.VaultAccount {
	s.requireAddFinalizeAndActivateMarker(info.underlying, s.adminAddr)
	vault, err := s.k.CreateVault(s.ctx, &types.MsgCreateVaultRequest{
		Admin:           s.adminAddr.String(),
		ShareDenom:      info.shareDenom,
		UnderlyingAsset: info.underlying.Denom,
	})
	s.Require().NoError(err, "failed to create vault in createVaultWithInterest for share denom %s", info.shareDenom)

	vault.CurrentInterestRate = interestRate
	vault.DesiredInterestRate = interestRate
	vault.PeriodStart = periodStart
	vault.PeriodTimeout = periodTimeout
	s.k.AuthKeeper.SetAccount(s.ctx, vault)

	if fundReserves {
		// Fund with enough to cover a day's interest
		err = FundAccount(s.ctx, s.simApp, info.vaultAddr, sdk.NewCoins(sdk.NewInt64Coin(info.underlying.Denom, 1_000_000)))
		s.Require().NoError(err, "failed to fund vault reserves in createVaultWithInterest for vault %s", info.vaultAddr)
	}
	if fundPrincipal {
		err = FundAccount(s.ctx, s.simApp, markertypes.MustGetMarkerAddress(info.shareDenom), sdk.NewCoins(info.underlying))
		s.Require().NoError(err, "failed to fund marker principal in createVaultWithInterest for marker %s", info.shareDenom)
	}

	s.Require().NoError(s.k.SafeAddPayoutVerification(s.ctx, vault), "failed to safe add payout verification in createVaultWithInterest for vault %s", info.vaultAddr)
	return vault
}

type VaultInfo struct {
	shareDenom string
	underlying sdk.Coin
	vaultAddr  sdk.AccAddress
}

func NewVaultInfo(id int) VaultInfo {
	shareDenom := fmt.Sprintf("vault%d", id)
	return VaultInfo{
		shareDenom: shareDenom,
		underlying: sdk.NewInt64Coin(fmt.Sprintf("underlying%d", id), 1_000_000_000),
		vaultAddr:  types.GetVaultAddress(shareDenom),
	}
}

func (s *TestSuite) TestKeeper_CanPayInterestDuration() {
	shareDenom := "vaultshares"
	underlying := sdk.NewInt64Coin("underlying", 1_000_000_000)
	vaultAddr := types.GetVaultAddress(shareDenom)
	markerAddr := markertypes.MustGetMarkerAddress(shareDenom)

	createVaultWithRate := func(rate string) *types.VaultAccount {
		s.requireAddFinalizeAndActivateMarker(underlying, s.adminAddr)
		_, err := s.k.CreateVault(s.ctx, &types.MsgCreateVaultRequest{
			Admin:           s.adminAddr.String(),
			ShareDenom:      shareDenom,
			UnderlyingAsset: underlying.Denom,
		})
		s.Require().NoError(err, "failed to create vault in createVaultWithRate")

		vault, err := s.k.GetVault(s.ctx, vaultAddr)
		s.Require().NoError(err, "failed to get vault in createVaultWithRate")
		vault.CurrentInterestRate = rate
		s.k.AuthKeeper.SetAccount(s.ctx, vault)
		return vault
	}

	oneDay := int64(24 * time.Hour / time.Second)

	tests := []struct {
		name          string
		rate          string
		duration      int64
		fundReserves  sdkmath.Int
		fundPrincipal sdkmath.Int
		expectOK      bool
	}{
		{
			name:          "zero duration always OK",
			rate:          "0.25",
			duration:      0,
			fundReserves:  sdkmath.NewInt(0),
			fundPrincipal: sdkmath.NewInt(0),
			expectOK:      true,
		},
		{
			name:          "zero interest accrual is OK",
			rate:          "0.0",
			duration:      oneDay,
			fundReserves:  sdkmath.NewInt(0),
			fundPrincipal: sdkmath.NewInt(0),
			expectOK:      true,
		},
		{
			name:          "positive interest, sufficient reserves",
			rate:          "1.0",
			duration:      1,
			fundReserves:  sdkmath.NewInt(1_000_000_000),
			fundPrincipal: sdkmath.NewInt(100_000),
			expectOK:      true,
		},
		{
			name:          "positive interest, insufficient reserves",
			rate:          "1.0",
			duration:      oneDay,
			fundReserves:  sdkmath.NewInt(10),
			fundPrincipal: sdkmath.NewInt(100_000),
			expectOK:      false,
		},
		{
			name:          "negative interest, principal available",
			rate:          "-1.0",
			duration:      oneDay,
			fundReserves:  sdkmath.NewInt(0),
			fundPrincipal: sdkmath.NewInt(100_000),
			expectOK:      true,
		},
	}

	for _, tc := range tests {
		s.Run(tc.name, func() {
			s.SetupTest()

			vault := createVaultWithRate(tc.rate)

			if tc.fundReserves.IsPositive() {
				s.Require().NoError(FundAccount(
					s.ctx,
					s.simApp,
					vaultAddr,
					sdk.NewCoins(sdk.NewCoin(underlying.Denom, tc.fundReserves)),
				), "failed to fund vault reserves for test case %s", tc.name)
			}

			if tc.fundPrincipal.IsPositive() {
				s.Require().NoError(FundAccount(
					s.ctx,
					s.simApp,
					markerAddr,
					sdk.NewCoins(sdk.NewCoin(underlying.Denom, tc.fundPrincipal)),
				), "failed to fund marker principal for test case %s", tc.name)
			}

			ok, err := s.k.CanPayInterestDuration(s.ctx, vault, tc.duration)
			s.Require().NoError(err, "error checking CanPayInterestDuration")
			s.Require().Equal(tc.expectOK, ok, "unexpected CanPayInterestDuration result")
		})
	}
}

func (s *TestSuite) TestKeeper_CanPayInterestDuration_NegativeInterest_Composite_InsufficientUnderlying() {
	s.SetupTest()

	shareDenom := "vaultshares.composite"
	underlyingDenom := "uylds.fcc.receipt.token"
	heldDenom := "uylds.fcc"

	underlying := sdk.NewInt64Coin(underlyingDenom, 1_000_000_000)
	vaultAddr := types.GetVaultAddress(shareDenom)
	markerAddr := markertypes.MustGetMarkerAddress(shareDenom)

	s.requireAddFinalizeAndActivateMarker(underlying, s.adminAddr)
	s.requireAddFinalizeAndActivateMarker(sdk.NewInt64Coin(heldDenom, 10_000_000_000_000), s.adminAddr)

	vault := s.CreateVaultWithParams(shareDenom, underlyingDenom)
	s.setVaultNAV(vault, heldDenom, sdk.NewInt64Coin(underlyingDenom, 1), 1)

	vault.CurrentInterestRate = "-0.5"
	vault.DesiredInterestRate = "-0.5"
	s.k.AuthKeeper.SetAccount(s.ctx, vault)

	s.Require().NoError(FundAccount(s.ctx, s.simApp, vaultAddr, sdk.NewCoins(sdk.NewCoin(underlyingDenom, sdkmath.NewInt(1_000_000)))), "failed to fund composite vault in TestKeeper_CanPayInterestDuration_NegativeInterest_Composite_InsufficientUnderlying")

	tinyUnderlying := sdkmath.NewInt(10_000_000)
	hugeHeld := sdkmath.NewInt(10_000_000_000_000)

	s.Require().NoError(FundAccount(s.ctx, s.simApp, markerAddr, sdk.NewCoins(sdk.NewCoin(underlyingDenom, tinyUnderlying), sdk.NewCoin(heldDenom, hugeHeld))), "failed to fund marker account")

	year := int64(365 * 24 * time.Hour / time.Second)

	canPayLong, err := s.k.CanPayInterestDuration(s.ctx, vault, year)
	s.Require().NoError(err, "error checking CanPayInterestDuration for long duration")
	s.Require().False(canPayLong, "expected CanPayInterestDuration to be false for long duration with insufficient underlying")

	smallDuration := int64(1)

	canPayShort, err := s.k.CanPayInterestDuration(s.ctx, vault, smallDuration)
	s.Require().NoError(err, "error checking CanPayInterestDuration for short duration")
	s.Require().True(canPayShort, "expected CanPayInterestDuration to be true for short duration with sufficient underlying")
}

func (s *TestSuite) TestKeeper_PerformVaultInterestTransfer_PositiveInterest_UsesTVV() {
	s.SetupTest()

	shareDenom := "nvylds.shares"
	underlying := sdk.NewInt64Coin("uylds.fcc", 1_000_000_000)
	vaultAddr := types.GetVaultAddress(shareDenom)
	markerAddr := markertypes.MustGetMarkerAddress(shareDenom)
	now := time.Now().UTC()
	periodStart := now.Add(-60 * 24 * time.Hour).Unix()

	s.requireAddFinalizeAndActivateMarker(underlying, s.adminAddr)

	_, err := s.k.CreateVault(s.ctx, &types.MsgCreateVaultRequest{
		Admin:           s.adminAddr.String(),
		ShareDenom:      shareDenom,
		UnderlyingAsset: underlying.Denom,
	})
	s.Require().NoError(err, "failed to create vault")

	vault, err := s.k.GetVault(s.ctx, vaultAddr)
	s.Require().NoError(err, "failed to get vault in TestKeeper_PerformVaultInterestTransfer_PositiveInterest_UsesTVV")

	vault.CurrentInterestRate = "0.25"
	vault.DesiredInterestRate = "0.25"
	vault.PeriodStart = periodStart
	vault.FeePeriodStart = periodStart
	s.k.AuthKeeper.SetAccount(s.ctx, vault)

	s.Require().NoError(
		FundAccount(s.ctx, s.simApp, vaultAddr, sdk.NewCoins(underlying)),
		"failed to fund vault account in TestKeeper_PerformVaultInterestTransfer_PositiveInterest_UsesTVV",
	)
	s.Require().NoError(
		FundAccount(s.ctx, s.simApp, markerAddr, sdk.NewCoins(underlying)),
		"failed to fund marker account in TestKeeper_PerformVaultInterestTransfer_PositiveInterest_UsesTVV",
	)

	s.ctx = s.ctx.WithBlockTime(now).WithEventManager(sdk.NewEventManager())

	startVault := s.simApp.BankKeeper.GetBalance(s.ctx, vaultAddr, underlying.Denom).Amount
	startMarker := s.simApp.BankKeeper.GetBalance(s.ctx, markerAddr, underlying.Denom).Amount
	s.Require().Equal(underlying.Amount, startVault, "initial vault reserves should match funded amount")
	s.Require().Equal(underlying.Amount, startMarker, "initial marker principal should match funded amount")

	principalTvv, err := s.k.GetTVV(s.ctx, *vault)
	s.Require().NoError(err, "failed to get TVV in underlying asset")
	s.Require().True(principalTvv.GT(sdkmath.ZeroInt()), "expected positive TVV")

	principalCoin := sdk.NewCoin(underlying.Denom, principalTvv)
	periodDuration := s.ctx.BlockTime().Unix() - vault.PeriodStart

	interestEarned, err := interest.CalculateInterestEarned(principalCoin, vault.CurrentInterestRate, periodDuration)
	s.Require().NoError(err, "failed to calculate interest earned")
	s.Require().True(interestEarned.IsPositive(), "expected positive interest earned")

	err = s.k.TestAccessor_reconcileVault(s.T(), s.ctx, vault)
	s.Require().NoError(err, "failed to reconcile vault")

	endVault := s.simApp.BankKeeper.GetBalance(s.ctx, vaultAddr, underlying.Denom).Amount
	endMarker := s.simApp.BankKeeper.GetBalance(s.ctx, markerAddr, underlying.Denom).Amount

	sixtyDayAumFee := sdkmath.NewInt(256_919)
	expectedVault := startVault.Sub(interestEarned)
	expectedMarker := startMarker.Add(interestEarned).Sub(sixtyDayAumFee)

	s.Require().Equal(expectedVault, endVault, "vault reserves mismatch")
	s.Require().Equal(sdkmath.NewInt(1_041_695_094), endMarker, "marker principal should be 1,000,000,000 plus interest 41,952,013 minus the 60-day AUM fee 256,919")

	s.assertVaultAndMarkerBalances(
		vaultAddr,
		shareDenom,
		underlying.Denom,
		expectedVault,
		expectedMarker,
	)

	events := normalizeEvents(s.ctx.EventManager().Events())

	found := false
	for _, event := range events {
		if event.Type == "provlabs.vault.v1.EventVaultReconcile" {
			found = true

			var principalBeforeStr, principalAfterStr, interestStr string
			for _, attr := range event.Attributes {
				switch string(attr.Key) {
				case "principal_before":
					principalBeforeStr = string(attr.Value)
				case "principal_after":
					principalAfterStr = string(attr.Value)
				case "interest_earned":
					interestStr = string(attr.Value)
				}
			}

			s.Require().Equal(
				fmt.Sprintf("%s%s", startMarker.String(), underlying.Denom),
				principalBeforeStr,
				"principal before mismatch",
			)

			s.Require().Equal(
				fmt.Sprintf("%s%s", startMarker.Add(interestEarned).String(), underlying.Denom),
				principalAfterStr,
				"principal after mismatch",
			)

			s.Require().Equal(
				fmt.Sprintf("%s%s", interestEarned.String(), underlying.Denom),
				interestStr,
				"interest earned mismatch",
			)

			break
		}
	}
	s.Require().True(found, "expected EventVaultReconcile to be emitted")
}

func (s *TestSuite) TestKeeper_PerformVaultInterestTransfer_PositiveInterest_UsesCompositeTVV() {
	s.SetupTest()

	shareDenom := "nvylds.shares.composite"
	underlying := sdk.NewInt64Coin("uylds.fcc.receipt.token", 1_000_000_000)
	heldDenom := "uylds.fcc"

	vaultAddr := types.GetVaultAddress(shareDenom)
	markerAddr := markertypes.MustGetMarkerAddress(shareDenom)
	now := time.Now().UTC()
	periodStart := now.Add(-60 * 24 * time.Hour).Unix()

	s.requireAddFinalizeAndActivateMarker(underlying, s.adminAddr)
	s.requireAddFinalizeAndActivateMarker(sdk.NewInt64Coin(heldDenom, 1_000_000_000), s.adminAddr)

	vault := s.CreateVaultWithParams(shareDenom, underlying.Denom)
	s.setVaultNAV(vault, heldDenom, sdk.NewInt64Coin(underlying.Denom, 1), 1)

	vault.CurrentInterestRate = "0.25"
	vault.DesiredInterestRate = "0.25"
	vault.PeriodStart = periodStart
	vault.FeePeriodStart = periodStart
	s.k.AuthKeeper.SetAccount(s.ctx, vault)

	s.Require().NoError(
		FundAccount(s.ctx, s.simApp, vaultAddr, sdk.NewCoins(underlying)),
		"expected funding vault reserves to succeed",
	)

	receiptPortion := sdkmath.NewInt(950_000_000)
	heldPortion := sdkmath.NewInt(50_000_000)

	s.Require().NoError(
		FundAccount(s.ctx, s.simApp, markerAddr, sdk.NewCoins(
			sdk.NewCoin(underlying.Denom, receiptPortion),
			sdk.NewCoin(heldDenom, heldPortion),
		)),
		"expected funding composite principal to succeed",
	)

	s.ctx = s.ctx.WithBlockTime(now).WithEventManager(sdk.NewEventManager())

	startVault := s.simApp.BankKeeper.GetBalance(s.ctx, vaultAddr, underlying.Denom).Amount
	startMarkerUnderlying := s.simApp.BankKeeper.GetBalance(s.ctx, markerAddr, underlying.Denom).Amount
	startMarkerHeld := s.simApp.BankKeeper.GetBalance(s.ctx, markerAddr, heldDenom).Amount

	s.Require().Equal(underlying.Amount, startVault, "expected initial vault reserves to equal funded amount")
	s.Require().Equal(receiptPortion, startMarkerUnderlying, "expected marker underlying balance to equal receipt portion")
	s.Require().Equal(heldPortion, startMarkerHeld, "expected marker held-asset balance to equal held portion")

	principalTvv, err := s.k.GetTVV(s.ctx, *vault)
	s.Require().NoError(err, "expected GetTVV to succeed")
	s.Require().True(principalTvv.GT(sdkmath.ZeroInt()), "expected TVV principal to be positive for composite principal")

	principalCoin := sdk.NewCoin(underlying.Denom, principalTvv)
	periodDuration := s.ctx.BlockTime().Unix() - vault.PeriodStart

	interestEarned, err := interest.CalculateInterestEarned(principalCoin, vault.CurrentInterestRate, periodDuration)
	s.Require().NoError(err, "expected CalculateInterestEarned to succeed")
	s.Require().True(interestEarned.IsPositive(), "expected interest earned to be positive for positive rate")

	err = s.k.TestAccessor_reconcileVault(s.T(), s.ctx, vault)
	s.Require().NoError(err, "expected reconcileVault to succeed")

	endVault := s.simApp.BankKeeper.GetBalance(s.ctx, vaultAddr, underlying.Denom).Amount
	endMarkerUnderlying := s.simApp.BankKeeper.GetBalance(s.ctx, markerAddr, underlying.Denom).Amount
	endMarkerHeld := s.simApp.BankKeeper.GetBalance(s.ctx, markerAddr, heldDenom).Amount

	sixtyDayAumFee := sdkmath.NewInt(256_919)
	expectedVault := startVault.Sub(interestEarned)
	expectedMarkerUnderlying := startMarkerUnderlying.Add(interestEarned).Sub(sixtyDayAumFee)

	s.Require().Equal(expectedVault, endVault, "expected vault reserves to decrease by TVV-based interest")
	s.Require().Equal(expectedMarkerUnderlying, endMarkerUnderlying, "expected marker underlying balance to rise by interest and fall by the 15bps 60-day AUM fee of 256,919 on post-interest TVV")
	s.Require().Equal(heldPortion, endMarkerHeld, "expected marker held-asset balance to be untouched by the underlying-denominated fee")

	s.assertVaultAndMarkerBalances(
		vaultAddr,
		shareDenom,
		underlying.Denom,
		expectedVault,
		expectedMarkerUnderlying,
	)

	events := normalizeEvents(s.ctx.EventManager().Events())

	found := false
	for _, ev := range events {
		if ev.Type == "provlabs.vault.v1.EventVaultReconcile" {
			found = true

			var principalBeforeStr, principalAfterStr, interestStr string
			for _, attr := range ev.Attributes {
				switch string(attr.Key) {
				case "principal_before":
					principalBeforeStr = string(attr.Value)
				case "principal_after":
					principalAfterStr = string(attr.Value)
				case "interest_earned":
					interestStr = string(attr.Value)
				}
			}

			expectedPrincipalBefore := sdk.NewCoin(underlying.Denom, principalTvv)
			expectedPrincipalAfter := expectedPrincipalBefore.Add(sdk.NewCoin(underlying.Denom, interestEarned))

			s.Require().Equal(
				expectedPrincipalBefore.String(),
				principalBeforeStr,
				"expected principal_before to reflect TVV-based principal before transfer",
			)

			s.Require().Equal(
				expectedPrincipalAfter.String(),
				principalAfterStr,
				"expected principal_after to reflect TVV-based principal after interest but before AUM fees",
			)

			s.Require().Equal(
				fmt.Sprintf("%s%s", interestEarned.String(), underlying.Denom),
				interestStr,
				"expected interest_earned to reflect TVV-based interest amount",
			)

			break
		}
	}
	s.Require().True(found, "expected EventVaultReconcile to be emitted for composite principal TVV transfer")
}

func (s *TestSuite) TestKeeper_PerformVaultInterestTransfer_NegativeInterest_LargeNegativeExponentRetainsRemainder() {
	s.SetupTest()

	shareDenom := "nvylds.shares.liquid"
	underlying := sdk.NewInt64Coin("uylds.fcc", 1_000_000_000)
	vaultAddr := types.GetVaultAddress(shareDenom)
	markerAddr := markertypes.MustGetMarkerAddress(shareDenom)
	now := time.Now().UTC()
	periodStart := now.Add(-365 * 24 * time.Hour).Unix()

	s.requireAddFinalizeAndActivateMarker(underlying, s.adminAddr)

	_, err := s.k.CreateVault(s.ctx, &types.MsgCreateVaultRequest{
		Admin:           s.adminAddr.String(),
		ShareDenom:      shareDenom,
		UnderlyingAsset: underlying.Denom,
	})
	s.Require().NoError(err, "CreateVault should succeed")

	vault, err := s.k.GetVault(s.ctx, vaultAddr)
	s.Require().NoError(err, "GetVault should return the created vault")

	vault.CurrentInterestRate = "-10.0"
	vault.DesiredInterestRate = "-10.0"
	vault.PeriodStart = periodStart
	vault.FeePeriodStart = now.Unix()
	s.k.AuthKeeper.SetAccount(s.ctx, vault)

	s.Require().NoError(FundAccount(s.ctx, s.simApp, vaultAddr, sdk.NewCoins(underlying)), "Funding vault should succeed")

	smallPrincipal := sdk.NewInt64Coin(underlying.Denom, 100_000)
	s.Require().NoError(FundAccount(s.ctx, s.simApp, markerAddr, sdk.NewCoins(smallPrincipal)), "Funding marker with small principal should succeed")

	s.ctx = s.ctx.WithBlockTime(now).WithEventManager(sdk.NewEventManager())

	err = s.k.TestAccessor_reconcileVault(s.T(), s.ctx, vault)
	s.Require().NoError(err, "ReconcileVault should not error at a deeply negative e^(rt) exponent")

	expectedReclaim := sdkmath.NewInt(99_995)
	expectedRemainder := smallPrincipal.Amount.Sub(expectedReclaim)

	endMarker := s.simApp.BankKeeper.GetBalance(s.ctx, markerAddr, underlying.Denom)
	s.Require().Equal(expectedRemainder, endMarker.Amount, "marker must retain the e^(rt) share of principal, not be swept to zero by an inverted exponent")

	endVault := s.simApp.BankKeeper.GetBalance(s.ctx, vaultAddr, underlying.Denom)
	s.Require().Equal(underlying.Amount.Add(expectedReclaim), endVault.Amount, "vault should receive only the reclaimed portion of the marker balance")

	found := false
	for _, ev := range normalizeEvents(s.ctx.EventManager().Events()) {
		if ev.Type == "provlabs.vault.v1.EventVaultReconcile" {
			found = true
			for _, attr := range ev.Attributes {
				if string(attr.Key) == "interest_earned" {
					expectedStr := expectedReclaim.Neg().String() + underlying.Denom
					s.Require().Equal(expectedStr, string(attr.Value), "event interest_earned should reflect the uncapped reclaim amount")
				}
			}
		}
	}
	s.Require().True(found, "EventVaultReconcile should be emitted")
}

func (s *TestSuite) TestKeeper_PerformVaultInterestTransfer_NegativeInterest_Composite_DepletesUnderlying() {
	s.SetupTest()

	shareDenom := "nvylds.shares.composite.neg"
	underlyingDenom := "uylds.fcc.receipt"
	heldDenom := "uylds.fcc"

	vaultAddr := types.GetVaultAddress(shareDenom)
	markerAddr := markertypes.MustGetMarkerAddress(shareDenom)
	now := time.Now().UTC()
	periodStart := now.Add(-365 * 24 * time.Hour).Unix()

	s.requireAddFinalizeAndActivateMarker(sdk.NewInt64Coin(underlyingDenom, 1000), s.adminAddr)
	s.requireAddFinalizeAndActivateMarker(sdk.NewInt64Coin(heldDenom, 1_000_000_000), s.adminAddr)

	vault := s.CreateVaultWithParams(shareDenom, underlyingDenom)
	s.setVaultNAV(vault, heldDenom, sdk.NewInt64Coin(underlyingDenom, 1), 1)

	vault.CurrentInterestRate = "-0.5"
	vault.DesiredInterestRate = "-0.5"
	vault.PeriodStart = periodStart
	vault.FeePeriodStart = periodStart
	s.k.AuthKeeper.SetAccount(s.ctx, vault)

	s.Require().NoError(FundAccount(s.ctx, s.simApp, vaultAddr, sdk.NewCoins(sdk.NewInt64Coin(underlyingDenom, 1_000_000))), "Funding vault should succeed")

	hugeHeldBalance := sdk.NewInt64Coin(heldDenom, 1_000_000_000)
	tinyUnderlyingBalance := sdk.NewInt64Coin(underlyingDenom, 10)

	s.Require().NoError(FundAccount(s.ctx, s.simApp, markerAddr, sdk.NewCoins(hugeHeldBalance, tinyUnderlyingBalance)), "Funding marker with composite assets should succeed")

	s.ctx = s.ctx.WithBlockTime(now).WithEventManager(sdk.NewEventManager())

	tvv, err := s.k.GetTVV(s.ctx, *vault)
	s.Require().NoError(err, "GetTVV should succeed")
	s.Require().True(tvv.GT(sdkmath.NewInt(100_000)), "TVV should be significantly higher than the underlying balance due to the held asset")

	err = s.k.TestAccessor_reconcileVault(s.T(), s.ctx, vault)
	s.Require().NoError(err, "ReconcileVault should not error even if underlying liquidity is insufficient for full negative interest")

	endUnderlying := s.simApp.BankKeeper.GetBalance(s.ctx, markerAddr, underlyingDenom)
	endHeld := s.simApp.BankKeeper.GetBalance(s.ctx, markerAddr, heldDenom)

	s.Require().True(endUnderlying.IsZero(), "Underlying asset should be fully depleted by the capped negative interest")
	s.Require().Equal(hugeHeldBalance.Amount, endHeld.Amount, "Held asset should be untouched by the underlying-denominated fee once underlying is depleted")
}

func (s *TestSuite) TestKeeper_setShareDenomNAV() {
	shareDenom := "vaultshares"
	underlyingDenom := "underlying"
	vaultAddr := types.GetVaultAddress(shareDenom)
	markerAddr := markertypes.MustGetMarkerAddress(shareDenom)

	maxU64 := sdkmath.NewIntFromBigInt(new(big.Int).SetUint64(^uint64(0)))
	overUint64 := maxU64.Add(sdkmath.OneInt())

	tenToThe18 := sdkmath.NewIntWithDecimal(1, 18)
	realisticShares := sdkmath.NewInt(18_000_000).Mul(tenToThe18)
	realisticTVV := sdkmath.NewInt(18_000_000).Mul(sdkmath.NewIntWithDecimal(1, 6))

	setup := func(shares sdkmath.Int) (*types.VaultAccount, markertypes.MarkerAccountI) {
		s.requireAddFinalizeAndActivateMarker(
			sdk.NewInt64Coin(underlyingDenom, 1),
			s.adminAddr,
		)

		_, err := s.k.CreateVault(s.ctx, &types.MsgCreateVaultRequest{
			Admin:           s.adminAddr.String(),
			ShareDenom:      shareDenom,
			UnderlyingAsset: underlyingDenom,
		})
		s.Require().NoError(err, "CreateVault should not error in setup")

		vault, err := s.k.GetVault(s.ctx, vaultAddr)
		s.Require().NoError(err, "GetVault should not error in setup")
		s.Require().NotNil(vault, "vault should not be nil in setup")

		vault.TotalShares = sdk.NewCoin(shareDenom, shares)
		s.k.AuthKeeper.SetAccount(s.ctx, vault)

		marker, err := s.k.MarkerKeeper.GetMarker(s.ctx, markerAddr)
		s.Require().NoError(err, "GetMarker should not error in setup")
		s.Require().NotNil(marker, "marker should not be nil in setup")

		s.ctx = s.ctx.WithEventManager(sdk.NewEventManager())
		return vault, marker
	}

	maxInt256 := sdkmath.NewIntFromBigInt(new(big.Int).Sub(new(big.Int).Lsh(big.NewInt(1), 256), big.NewInt(1)))

	tests := []struct {
		name           string
		shares         sdkmath.Int
		tvv            sdkmath.Int
		expectNAVEvent bool
	}{
		{
			name:           "shares within uint64 publish an unscaled NAV",
			shares:         sdkmath.NewInt(1_000_000),
			tvv:            sdkmath.NewInt(123_456),
			expectNAVEvent: true,
		},
		{
			name:           "shares at the uint64 maximum publish an exact unscaled NAV",
			shares:         maxU64,
			tvv:            sdkmath.NewInt(123_456),
			expectNAVEvent: true,
		},
		{
			name:           "large uint64-safe supply above 10^18 publishes an exact unscaled NAV",
			shares:         sdkmath.NewInt(1_500_000_000_000_000_000),
			tvv:            sdkmath.OneInt(),
			expectNAVEvent: true,
		},
		{
			name:           "uint64-safe supply with a TVV that would overflow the scaled multiply publishes the exact TVV",
			shares:         maxU64,
			tvv:            sdkmath.NewIntFromBigInt(new(big.Int).Lsh(big.NewInt(1), 200)),
			expectNAVEvent: true,
		},
		{
			name:           "shares one past the uint64 maximum publish a scaled NAV",
			shares:         overUint64,
			tvv:            sdkmath.NewInt(123_456),
			expectNAVEvent: true,
		},
		{
			name:           "realistic 18M-share vault past uint64 scales to the reference volume",
			shares:         realisticShares,
			tvv:            realisticTVV,
			expectNAVEvent: true,
		},
		{
			name:           "scaled price truncating to zero publishes a zero-price NAV",
			shares:         overUint64,
			tvv:            sdkmath.OneInt(),
			expectNAVEvent: true,
		},
		{
			name:           "tvv near the 256-bit ceiling scales through big.Int without overflow and publishes",
			shares:         overUint64,
			tvv:            maxInt256,
			expectNAVEvent: true,
		},
		{
			name:           "negative TVV in the unscaled range is skipped without handing NewCoin a negative amount",
			shares:         sdkmath.NewInt(1_000_000),
			tvv:            sdkmath.NewInt(-123_456),
			expectNAVEvent: false,
		},
		{
			name:           "negative TVV in the scaled range is skipped after the big.Int path without panicking",
			shares:         overUint64,
			tvv:            sdkmath.NewInt(-123_456),
			expectNAVEvent: false,
		},
		{
			name:           "vault with no shares skips publication",
			shares:         sdkmath.ZeroInt(),
			tvv:            sdkmath.NewInt(123_456),
			expectNAVEvent: false,
		},
	}

	for _, tc := range tests {
		s.Run(tc.name, func() {
			s.SetupTest()
			vault, marker := setup(tc.shares)

			s.Require().NotNil(vault, "vault should not be nil for test case %q", tc.name)
			s.Require().NotNil(marker, "marker should not be nil for test case %q", tc.name)

			var err error
			s.Require().NotPanics(
				func() {
					err = s.k.TestAccessor_setShareDenomNAV(s.T(), s.ctx, vault, marker, tc.tvv)
				},
				"setShareDenomNAV should not panic for test case %q (shares=%s tvv=%s)",
				tc.name, tc.shares.String(), tc.tvv.String(),
			)
			s.Require().NoError(err, "setShareDenomNAV should not error for test case %q (shares=%s tvv=%s)", tc.name, tc.shares.String(), tc.tvv.String())

			found := false
			for _, ev := range normalizeEvents(s.ctx.EventManager().Events()) {
				if ev.Type == "provenance.marker.v1.EventSetNetAssetValue" {
					found = true
					break
				}
			}
			s.Require().Equal(tc.expectNAVEvent, found,
				"NAV event presence mismatch for test case %q: expected=%t got=%t (shares=%s tvv=%s)",
				tc.name, tc.expectNAVEvent, found, tc.shares.String(), tc.tvv.String())

			stored, err := s.k.MarkerKeeper.GetNetAssetValue(s.ctx, shareDenom, underlyingDenom)
			s.Require().NoError(err, "GetNetAssetValue should not error for test case %q", tc.name)

			if !tc.expectNAVEvent {
				s.Require().Nil(stored, "no marker NAV should be stored for test case %q (shares=%s tvv=%s)", tc.name, tc.shares.String(), tc.tvv.String())
				return
			}

			s.Require().NotNil(stored, "marker NAV should be stored for test case %q (shares=%s tvv=%s)", tc.name, tc.shares.String(), tc.tvv.String())

			s.Assert().Equal(underlyingDenom, stored.Price.Denom,
				"published NAV price denom mismatch for test case %q", tc.name)

			if !tc.shares.GT(keeper.NavReferenceVolume) {
				s.Assert().Equal(tc.shares.Uint64(), stored.Volume,
					"uint64-safe supply must publish its exact share count as the NAV volume for test case %q (shares=%s)", tc.name, tc.shares.String())
				s.Assert().Equal(tc.tvv.String(), stored.Price.Amount.String(),
					"uint64-safe supply must publish Price = TVV without scaling for test case %q (shares=%s tvv=%s)", tc.name, tc.shares.String(), tc.tvv.String())
				return
			}

			expectedVolume := keeper.NavReferenceVolume
			trueRatio := new(big.Int).Mul(tc.tvv.BigInt(), expectedVolume.BigInt())
			expectedPrice := new(big.Int).Quo(trueRatio, tc.shares.BigInt())

			s.Assert().Equal(expectedVolume.Uint64(), stored.Volume,
				"scaled NAV volume must equal the reference volume for test case %q (shares=%s)", tc.name, tc.shares.String())
			s.Assert().Equal(expectedPrice.String(), stored.Price.Amount.String(),
				"published NAV price mismatch for test case %q (shares=%s tvv=%s)", tc.name, tc.shares.String(), tc.tvv.String())

			publishedRatio := new(big.Int).Mul(stored.Price.Amount.BigInt(), tc.shares.BigInt())
			s.Assert().True(publishedRatio.Cmp(trueRatio) <= 0,
				"published price-per-share must not exceed the true TVV/totalShares ratio for test case %q: published=%s true=%s",
				tc.name, publishedRatio.String(), trueRatio.String())
			residual := new(big.Int).Sub(trueRatio, publishedRatio)
			s.Assert().True(residual.Cmp(tc.shares.BigInt()) < 0,
				"truncation error must be under one share-unit for test case %q: residual=%s totalShares=%s",
				tc.name, residual.String(), tc.shares.String())

			if expectedPrice.Sign() == 0 {
				s.Assert().True(stored.Price.Amount.IsZero(),
					"the marker should accept and store a zero-price NAV for test case %q, got price %s", tc.name, stored.Price.Amount.String())
			}
		})
	}
}

func (s *TestSuite) TestKeeper_publishShareNav_NAVLifecycle() {
	shareDenom := "vaultshares"
	underlyingDenom := "underlying"
	vaultAddr := types.GetVaultAddress(shareDenom)
	markerAddr := markertypes.MustGetMarkerAddress(shareDenom)

	const (
		seedNone                   = "none"
		seedNonZero                = "nonzero"
		seedZero                   = "zero"
		seedZeroPriceNonZeroVolume = "zeroprice_nonzerovolume"
	)

	setup := func(shares sdkmath.Int, seedMode string) *types.VaultAccount {
		s.requireAddFinalizeAndActivateMarker(sdk.NewInt64Coin(underlyingDenom, 1), s.adminAddr)

		_, err := s.k.CreateVault(s.ctx, &types.MsgCreateVaultRequest{
			Admin:           s.adminAddr.String(),
			ShareDenom:      shareDenom,
			UnderlyingAsset: underlyingDenom,
		})
		s.Require().NoError(err, "CreateVault should not error in setup")

		vault, err := s.k.GetVault(s.ctx, vaultAddr)
		s.Require().NoError(err, "GetVault should not error in setup")

		marker, err := s.k.MarkerKeeper.GetMarker(s.ctx, markerAddr)
		s.Require().NoError(err, "GetMarker should not error in setup")

		switch seedMode {
		case seedNonZero:
			s.Require().NoError(s.k.MarkerKeeper.SetNetAssetValue(s.ctx, marker, markertypes.NetAssetValue{
				Price:  sdk.NewInt64Coin(underlyingDenom, 100),
				Volume: 1_000,
			}, types.ModuleName), "seeding a prior non-zero share NAV should not error")
		case seedZero:
			s.Require().NoError(s.k.MarkerKeeper.SetNetAssetValue(s.ctx, marker, markertypes.NetAssetValue{
				Price:  sdk.NewInt64Coin(underlyingDenom, 0),
				Volume: 0,
			}, types.ModuleName), "seeding a prior zero share NAV should not error")
		case seedZeroPriceNonZeroVolume:
			s.Require().NoError(s.k.MarkerKeeper.SetNetAssetValue(s.ctx, marker, markertypes.NetAssetValue{
				Price:  sdk.NewInt64Coin(underlyingDenom, 0),
				Volume: 1_000,
			}, types.ModuleName), "seeding a prior zero-price non-zero-volume share NAV should not error")
		}

		vault.TotalShares = sdk.NewCoin(shareDenom, shares)
		s.k.AuthKeeper.SetAccount(s.ctx, vault)
		return vault
	}

	tests := []struct {
		name          string
		shares        sdkmath.Int
		seedMode      string
		expectPresent bool
		expectZeroed  bool
	}{
		{
			name:          "zero shares with an existing non-zero NAV overwrites the stale price with zero",
			shares:        sdkmath.ZeroInt(),
			seedMode:      seedNonZero,
			expectPresent: true,
			expectZeroed:  true,
		},
		{
			name:          "zero shares with no existing NAV does not create a spurious NAV",
			shares:        sdkmath.ZeroInt(),
			seedMode:      seedNone,
			expectPresent: false,
		},
		{
			name:          "zero shares with an already-zero NAV is an idempotent no-op",
			shares:        sdkmath.ZeroInt(),
			seedMode:      seedZero,
			expectPresent: true,
			expectZeroed:  true,
		},
		{
			name:          "zero shares with a zero-price but non-zero-volume NAV re-zeros the stale volume",
			shares:        sdkmath.ZeroInt(),
			seedMode:      seedZeroPriceNonZeroVolume,
			expectPresent: true,
			expectZeroed:  true,
		},
		{
			name:          "positive shares with zero TVV preserves the existing NAV rather than zeroing it",
			shares:        sdkmath.NewInt(1_000_000),
			seedMode:      seedNonZero,
			expectPresent: true,
			expectZeroed:  false,
		},
	}

	for _, tc := range tests {
		s.Run(tc.name, func() {
			s.SetupTest()
			vault := setup(tc.shares, tc.seedMode)

			var err error
			s.Require().NotPanics(func() {
				err = s.k.TestAccessor_publishShareNav(s.T(), s.ctx, vault)
			}, "publishShareNav should not panic for test case %q", tc.name)
			s.Require().NoError(err, "publishShareNav should not error for test case %q", tc.name)

			stored, err := s.k.MarkerKeeper.GetNetAssetValue(s.ctx, shareDenom, underlyingDenom)
			s.Require().NoError(err, "GetNetAssetValue should not error for test case %q", tc.name)

			if !tc.expectPresent {
				s.Require().Nil(stored, "no share NAV should exist after reconcile for test case %q", tc.name)
				return
			}

			s.Require().NotNil(stored, "a share NAV should be present after reconcile for test case %q", tc.name)
			if tc.expectZeroed {
				s.Assert().True(stored.Price.Amount.IsZero(),
					"zero-share NAV price should be zero for test case %q, got %s", tc.name, stored.Price.Amount.String())
				s.Assert().Equal(uint64(0), stored.Volume,
					"zero-share NAV volume should be zero for test case %q, got %d", tc.name, stored.Volume)
			} else {
				s.Assert().Equal(int64(100), stored.Price.Amount.Int64(),
					"preserved NAV price should equal the seeded value for test case %q", tc.name)
				s.Assert().Equal(uint64(1_000), stored.Volume,
					"preserved NAV volume should equal the seeded value for test case %q", tc.name)
			}
		})
	}
}

func (s *TestSuite) TestKeeper_ReconcileVault_RefreshesShareNavMirror() {
	shareDenom := "mirror.shares"
	underlyingDenom := "underlying"
	underlying := sdk.NewInt64Coin(underlyingDenom, 1_000_000_000)
	totalShares := sdk.NewInt64Coin(shareDenom, 1_000_000)
	testBlockTime := time.Date(2024, 3, 1, 0, 0, 0, 0, time.UTC)
	twoMonthsAgo := testBlockTime.Add(-60 * 24 * time.Hour).Unix()

	stalePrice := sdk.NewInt64Coin(underlyingDenom, 1)
	staleVolume := uint64(1)

	tests := []struct {
		name           string
		interestRate   string
		aumFeeBips     uint32
		periodStart    int64
		feePeriodStart int64
		expectRefresh  bool
	}{
		{
			name:           "fee-only reconcile republishes the mirror against the post-fee net TVV",
			interestRate:   "0.0",
			aumFeeBips:     100,
			periodStart:    0,
			feePeriodStart: twoMonthsAgo,
			expectRefresh:  true,
		},
		{
			name:           "interest-only reconcile republishes the mirror",
			interestRate:   "0.10",
			aumFeeBips:     0,
			periodStart:    twoMonthsAgo,
			feePeriodStart: 0,
			expectRefresh:  true,
		},
		{
			name:           "combined interest and fee reconcile republishes the mirror",
			interestRate:   "0.10",
			aumFeeBips:     100,
			periodStart:    twoMonthsAgo,
			feePeriodStart: twoMonthsAgo,
			expectRefresh:  true,
		},
		{
			name:           "reconcile with neither period elapsed leaves the mirror untouched",
			interestRate:   "0.10",
			aumFeeBips:     100,
			periodStart:    testBlockTime.Unix(),
			feePeriodStart: testBlockTime.Unix(),
			expectRefresh:  false,
		},
		{
			name:           "elapsed fee period on a vault with no fee rate leaves the mirror untouched",
			interestRate:   "0.0",
			aumFeeBips:     0,
			periodStart:    0,
			feePeriodStart: twoMonthsAgo,
			expectRefresh:  false,
		},
	}

	for _, tc := range tests {
		s.Run(tc.name, func() {
			s.SetupTest()
			vaultAddr, vault := s.setupReconcileVault(tc.interestRate, tc.periodStart, false, underlying, shareDenom, totalShares, testBlockTime)
			vault.AumFeeBips = tc.aumFeeBips
			vault.FeePeriodStart = tc.feePeriodStart
			s.k.AuthKeeper.SetAccount(s.ctx, vault)
			s.seedShareNav(vault, stalePrice, staleVolume)

			netTVVBefore, err := s.k.GetNetTVV(s.ctx, *vault)
			s.Require().NoError(err, "should compute net TVV before reconcile for test case %q", tc.name)

			s.Require().NoError(s.k.TestAccessor_reconcileVault(s.T(), s.ctx, vault),
				"reconcileVault should not error for test case %q", tc.name)

			reconciled, err := s.k.GetVault(s.ctx, vaultAddr)
			s.Require().NoError(err, "should fetch reconciled vault for test case %q", tc.name)

			netTVVAfter, err := s.k.GetNetTVV(s.ctx, *reconciled)
			s.Require().NoError(err, "should compute net TVV after reconcile for test case %q", tc.name)

			if !tc.expectRefresh {
				s.Require().Equal(netTVVBefore.String(), netTVVAfter.String(),
					"net TVV should not move when neither period elapsed for test case %q", tc.name)
				stored := s.requireShareNav(reconciled)
				s.Assert().Equal(stalePrice.Amount.String(), stored.Price.Amount.String(),
					"a reconcile that moves no value should not republish the mirror for test case %q", tc.name)
				s.Assert().Equal(staleVolume, stored.Volume,
					"a reconcile that moves no value should not republish the mirror volume for test case %q", tc.name)
				return
			}

			s.Require().NotEqual(netTVVBefore.String(), netTVVAfter.String(),
				"the accrual should have moved net TVV for test case %q", tc.name)
			s.assertShareNavMirrorsNetTVV(reconciled)
		})
	}
}

func (s *TestSuite) TestKeeper_HandleVaultFeeTimeouts_RefreshesShareNavMirror() {
	s.SetupTest()
	shareDenom := "fee.mirror.shares"
	underlyingDenom := "underlying"
	underlying := sdk.NewInt64Coin(underlyingDenom, 1_000_000_000)
	totalShares := sdk.NewInt64Coin(shareDenom, 1_000_000)
	vaultAddr := types.GetVaultAddress(shareDenom)
	twoMonthsAgo := s.ctx.BlockTime().Add(-60 * 24 * time.Hour).Unix()

	s.requireAddFinalizeAndActivateMarker(underlying, s.adminAddr)
	vault := s.CreateVaultWithParams(shareDenom, underlyingDenom)
	s.Require().NoError(s.k.FeeTimeoutQueue.Dequeue(s.ctx, vault.FeePeriodTimeout, vaultAddr),
		"should dequeue the initial fee timeout enqueued by CreateVaultWithParams")

	vault.AumFeeBips = 100
	vault.TotalShares = totalShares
	s.SetVaultRatesAndPeriod(vault, "0.0", "0.0", twoMonthsAgo, twoMonthsAgo)
	s.FundMarker(shareDenom, sdk.NewCoins(underlying))
	s.seedShareNav(vault, sdk.NewInt64Coin(underlyingDenom, 1), 1)
	s.Require().NoError(s.k.FeeTimeoutQueue.Enqueue(s.ctx, twoMonthsAgo, vaultAddr),
		"should enqueue the due fee timeout for vault %s", vaultAddr)

	netTVVBefore, err := s.k.GetNetTVV(s.ctx, *vault)
	s.Require().NoError(err, "should compute net TVV before the fee timeout runs")

	s.Require().NoError(s.k.TestAccessor_handleVaultFeeTimeouts(s.T(), s.ctx, keeper.MaxFeeTimeoutsPerBlock),
		"handleVaultFeeTimeouts should not error")

	reconciled, err := s.k.GetVault(s.ctx, vaultAddr)
	s.Require().NoError(err, "should fetch the vault after the fee timeout ran")

	netTVVAfter, err := s.k.GetNetTVV(s.ctx, *reconciled)
	s.Require().NoError(err, "should compute net TVV after the fee timeout ran")
	s.Require().NotEqual(netTVVBefore.String(), netTVVAfter.String(),
		"the fee collection should have moved net TVV")

	s.assertShareNavMirrorsNetTVV(reconciled)
}

func (s *TestSuite) TestKeeper_HandleVaultInterestTimeouts_RefreshesShareNavMirror() {
	s.SetupTest()
	shareDenom := "interest.mirror.shares"
	underlyingDenom := "underlying"
	underlying := sdk.NewInt64Coin(underlyingDenom, 1_000_000_000)
	totalShares := sdk.NewInt64Coin(shareDenom, 1_000_000)
	vaultAddr := types.GetVaultAddress(shareDenom)
	twoMonthsAgo := s.ctx.BlockTime().Add(-60 * 24 * time.Hour).Unix()

	s.requireAddFinalizeAndActivateMarker(underlying, s.adminAddr)
	vault := s.CreateVaultWithParams(shareDenom, underlyingDenom)

	vault.TotalShares = totalShares
	vault.PeriodStart = twoMonthsAgo
	vault.PeriodTimeout = twoMonthsAgo
	s.SetVaultRatesAndPeriod(vault, "0.10", "0.10", twoMonthsAgo, twoMonthsAgo)
	s.Require().NoError(
		FundAccount(s.ctx, s.simApp, vaultAddr, sdk.NewCoins(underlying)),
		"should fund vault reserves so the interest payment succeeds",
	)
	s.FundMarker(shareDenom, sdk.NewCoins(underlying))
	s.seedShareNav(vault, sdk.NewInt64Coin(underlyingDenom, 1), 1)
	s.Require().NoError(s.k.PayoutTimeoutQueue.Enqueue(s.ctx, twoMonthsAgo, vaultAddr),
		"should enqueue the due interest timeout for vault %s", vaultAddr)

	netTVVBefore, err := s.k.GetNetTVV(s.ctx, *vault)
	s.Require().NoError(err, "should compute net TVV before the interest timeout runs")

	s.Require().NoError(s.k.TestAccessor_handleVaultInterestTimeouts(s.T(), s.ctx, keeper.MaxInterestTimeoutsPerBlock),
		"handleVaultInterestTimeouts should not error")

	reconciled, err := s.k.GetVault(s.ctx, vaultAddr)
	s.Require().NoError(err, "should fetch the vault after the interest timeout ran")

	netTVVAfter, err := s.k.GetNetTVV(s.ctx, *reconciled)
	s.Require().NoError(err, "should compute net TVV after the interest timeout ran")
	s.Require().True(netTVVAfter.GT(netTVVBefore),
		"the interest payment should have raised net TVV from %s, got %s", netTVVBefore, netTVVAfter)

	s.assertShareNavMirrorsNetTVV(reconciled)
}

func (s *TestSuite) TestKeeper_PerformVaultFeeTransfer() {
	tests := []struct {
		name                string
		aumFeeBips          uint32
		initialLiquidity    sdkmath.Int
		expectedFeeTotal    sdkmath.Int
		expectedCollected   sdkmath.Int
		expectedOutstanding sdkmath.Int
		secondLiquidity     sdkmath.Int
		expectedFinalMarker sdkmath.Int
		aumSnapshot         string
	}{
		{
			name:                "partial collection then full (default 15 bps)",
			aumFeeBips:          15,
			initialLiquidity:    sdkmath.NewInt(100_000),
			expectedFeeTotal:    sdkmath.NewInt(246_600),
			expectedCollected:   sdkmath.NewInt(100_000),
			expectedOutstanding: sdkmath.NewInt(146_600),
			secondLiquidity:     sdkmath.NewInt(1_000_000),
			expectedFinalMarker: sdkmath.NewInt(853_400),
			aumSnapshot:         "1000100000uylds.fcc.receipt",
		},
		{
			name:                "partial collection then full (100 bps)",
			aumFeeBips:          100,
			initialLiquidity:    sdkmath.NewInt(100_000),
			expectedFeeTotal:    sdkmath.NewInt(1_644_000),
			expectedCollected:   sdkmath.NewInt(100_000),
			expectedOutstanding: sdkmath.NewInt(1_544_000),
			secondLiquidity:     sdkmath.NewInt(2_000_000),
			expectedFinalMarker: sdkmath.NewInt(456_000),
			aumSnapshot:         "1000100000uylds.fcc.receipt",
		},
		{
			name:                "zero fee collection",
			aumFeeBips:          0,
			initialLiquidity:    sdkmath.NewInt(100_000),
			expectedFeeTotal:    sdkmath.NewInt(0),
			expectedCollected:   sdkmath.NewInt(0),
			expectedOutstanding: sdkmath.NewInt(0),
			secondLiquidity:     sdkmath.NewInt(0),
			expectedFinalMarker: sdkmath.NewInt(100_000),
			aumSnapshot:         "1000100000uylds.fcc.receipt",
		},
	}

	for _, tc := range tests {
		s.Run(tc.name, func() {
			s.SetupTest()
			shareDenom := "fee.shares"
			underlyingDenom := "uylds.fcc.receipt"
			heldDenom := "uylds.fcc"
			heldAmount := sdkmath.NewInt(1_000_000_000)
			vaultAddr := types.GetVaultAddress(shareDenom)
			now := s.ctx.BlockTime()
			twoMonthsAgo := now.Add(-60 * 24 * time.Hour)

			s.requireAddFinalizeAndActivateMarker(sdk.NewInt64Coin(underlyingDenom, 1_000_000_000), s.adminAddr)
			s.requireAddFinalizeAndActivateMarker(sdk.NewInt64Coin(heldDenom, 1_000_000_000), s.adminAddr)
			vault := s.CreateVaultWithParams(shareDenom, underlyingDenom)
			vault.AumFeeBips = tc.aumFeeBips
			s.SetVaultRatesAndPeriod(vault, "0.0", "0.0", twoMonthsAgo.Unix(), 0)
			s.setVaultNAV(vault, heldDenom, sdk.NewInt64Coin(underlyingDenom, 1), 1)

			s.FundMarker(shareDenom, sdk.NewCoins(sdk.NewCoin(heldDenom, heldAmount)))
			s.FundMarker(shareDenom, sdk.NewCoins(sdk.NewCoin(underlyingDenom, tc.initialLiquidity)))

			s.SetCtxBlockTime(now)

			err := s.k.PerformVaultFeeTransfer(s.ctx, vault)
			s.Require().NoError(err, "PerformVaultFeeTransfer should not error during initial collection")
			s.Require().NoError(s.k.SetVaultAccount(s.ctx, vault), "SetVaultAccount should succeed after initial collection")

			provlabsAddr, err := s.k.GetAUMFeeAddress(s.ctx)
			s.Require().NoError(err, "failed to get AUM fee address from GetAUMFeeAddress")

			s.assertBalance(provlabsAddr, underlyingDenom, tc.expectedCollected)
			s.Require().Equal(tc.expectedOutstanding, vault.OutstandingAumFee.Amount, "outstanding fee balance mismatch")

			events := normalizeEvents(s.ctx.EventManager().Events())
			found := false
			for _, ev := range events {
				if ev.Type == "provlabs.vault.v1.EventVaultFeeCollected" {
					found = true
					snapshot, err := sdk.ParseCoinNormalized(tc.aumSnapshot)
					s.Require().NoError(err, "failed to parse aum snapshot coin")
					expectedEv := createVaultFeeCollectedEvent(
						vaultAddr,
						snapshot,
						sdk.NewCoin(underlyingDenom, tc.expectedCollected),
						sdk.NewCoin(underlyingDenom, tc.expectedFeeTotal),
						sdk.NewCoin(underlyingDenom, tc.expectedOutstanding),
						int64(60*24*time.Hour/time.Second),
					)
					s.Assert().Equal(normalizeEvent(expectedEv), ev, "EventVaultFeeCollected mismatch: aum snapshot should equal gross TVV (held 1,000,000,000 priced 1:1 plus underlying liquidity)")
				}
			}
			s.Require().Equal(!tc.expectedFeeTotal.IsZero(), found, "EventVaultFeeCollected emission mismatch")

			if tc.expectedFeeTotal.IsZero() {
				return
			}

			s.SetCtxBlockTime(now.Add(time.Second))
			s.FundMarker(shareDenom, sdk.NewCoins(sdk.NewCoin(underlyingDenom, tc.secondLiquidity)))

			err = s.k.PerformVaultFeeTransfer(s.ctx, vault)
			s.Require().NoError(err, "PerformVaultFeeTransfer should not error during second collection")
			s.Require().NoError(s.k.SetVaultAccount(s.ctx, vault), "SetVaultAccount should succeed after second collection")

			vault, err = s.k.GetVault(s.ctx, types.GetVaultAddress(shareDenom))
			s.Require().NoError(err, "failed to get vault for share denom %s", shareDenom)
			s.Require().Equal(s.ctx.BlockTime().Unix(), vault.FeePeriodStart, "FeePeriodStart should be updated")
			s.Require().True(vault.OutstandingAumFee.IsZero(), "outstanding fee should be cleared")
			s.assertBalance(markertypes.MustGetMarkerAddress(shareDenom), underlyingDenom, tc.expectedFinalMarker)
		})
	}
}

func (s *TestSuite) TestKeeper_PerformVaultFeeTransfer_OversizedTVVDegradesToError() {
	vault, _, underlyingDenom, heldDenom := s.setupOversizedNAVVault()
	s.seedOversizedNAV(vault, heldDenom, underlyingDenom, maxValidNAVPrice(), sdkmath.OneInt())

	s.fundPrincipalForBrokenValuation(vault, sdk.NewCoins(sdk.NewInt64Coin(heldDenom, 1)))
	s.materializeTotalValue(vault.GetAddress(), maxValidNAVPrice())

	now := s.ctx.BlockTime()
	twoMonthsAgo := now.Add(-60 * 24 * time.Hour)
	vault.AumFeeBips = 10_000
	s.SetVaultRatesAndPeriod(vault, "0.0", "0.0", twoMonthsAgo.Unix(), 0)
	s.SetCtxBlockTime(now)

	err := s.k.PerformVaultFeeTransfer(s.ctx, vault)
	s.Require().Error(err, "an oversized TVV must degrade to an error, not panic the BeginBlock fee hook")
	s.Require().ErrorContains(err, "overflow", "error should originate from the CalculateAUMFee recover guard")
}

func (s *TestSuite) TestKeeper_PerformVaultFeeTransfer_OutstandingFeeAtIntegerCeilingIsCappedAtGrossTVV() {
	s.SetupTest()
	shareDenom := "fee.shares"
	underlyingDenom := "uylds.fcc.receipt"
	underlying := sdk.NewInt64Coin(underlyingDenom, 1_000_000_000)
	now := s.ctx.BlockTime()
	twoMonthsAgo := now.Add(-60 * 24 * time.Hour)

	s.requireAddFinalizeAndActivateMarker(underlying, s.adminAddr)
	vault := s.CreateVaultWithParams(shareDenom, underlyingDenom)
	vault.AumFeeBips = 100
	vault.OutstandingAumFee = sdk.NewCoin(underlyingDenom, maxValidNAVPrice())
	s.SetVaultRatesAndPeriod(vault, "0.0", "0.0", twoMonthsAgo.Unix(), 0)

	s.FundMarker(shareDenom, sdk.NewCoins(underlying))
	s.SetCtxBlockTime(now)

	provlabsAddr, err := s.k.GetAUMFeeAddress(s.ctx)
	s.Require().NoError(err, "failed to get AUM fee address from GetAUMFeeAddress")

	err = s.k.PerformVaultFeeTransfer(s.ctx, vault)
	s.Require().NoError(err, "an outstanding fee at the 256-bit ceiling must be capped at gross TVV rather than failing the BeginBlock fee hook")

	collected := s.simApp.BankKeeper.GetBalance(s.ctx, provlabsAddr, underlyingDenom)
	s.Assert().Equal(underlying.String(), collected.String(), "the capped liability equals the gross TVV and the principal marker holds all of it, so the whole gross TVV must be collected")
	s.Assert().True(vault.OutstandingAumFee.IsZero(), "collecting the full capped liability must leave nothing outstanding, got %s", vault.OutstandingAumFee)
	s.Assert().Equal(now.Unix(), vault.FeePeriodStart, "fee period must advance after the capped fee is collected")
}

func (s *TestSuite) TestKeeper_capAumFeeLiability() {
	ceiling := maxValidNAVPrice()

	tests := []struct {
		name            string
		carried         sdkmath.Int
		accrued         sdkmath.Int
		grossTVV        sdkmath.Int
		expected        sdkmath.Int
		expectForfeited bool
	}{
		{
			name:            "nothing carried and nothing accrued stays at zero",
			carried:         sdkmath.ZeroInt(),
			accrued:         sdkmath.ZeroInt(),
			grossTVV:        sdkmath.NewInt(1_000_000),
			expected:        sdkmath.ZeroInt(),
			expectForfeited: false,
		},
		{
			name:            "carried plus accrued below gross TVV accumulates untouched",
			carried:         sdkmath.NewInt(300_000),
			accrued:         sdkmath.NewInt(200_000),
			grossTVV:        sdkmath.NewInt(1_000_000),
			expected:        sdkmath.NewInt(500_000),
			expectForfeited: false,
		},
		{
			name:            "carried plus accrued exactly equal to gross TVV forfeits nothing",
			carried:         sdkmath.NewInt(900_000),
			accrued:         sdkmath.NewInt(100_000),
			grossTVV:        sdkmath.NewInt(1_000_000),
			expected:        sdkmath.NewInt(1_000_000),
			expectForfeited: false,
		},
		{
			name:            "accrual that overshoots the remaining headroom is trimmed to gross TVV",
			carried:         sdkmath.NewInt(900_000),
			accrued:         sdkmath.NewInt(250_000),
			grossTVV:        sdkmath.NewInt(1_000_000),
			expected:        sdkmath.NewInt(1_000_000),
			expectForfeited: true,
		},
		{
			name:            "carried balance already above gross TVV is pulled back down to it",
			carried:         sdkmath.NewInt(5_000_000),
			accrued:         sdkmath.NewInt(1),
			grossTVV:        sdkmath.NewInt(1_000_000),
			expected:        sdkmath.NewInt(1_000_000),
			expectForfeited: true,
		},
		{
			name:            "carried balance at the 256-bit ceiling caps without overflowing",
			carried:         ceiling,
			accrued:         sdkmath.NewInt(1_000),
			grossTVV:        sdkmath.NewInt(1_000_000),
			expected:        sdkmath.NewInt(1_000_000),
			expectForfeited: true,
		},
		{
			name:            "accrual at the 256-bit ceiling caps without overflowing",
			carried:         sdkmath.ZeroInt(),
			accrued:         ceiling,
			grossTVV:        sdkmath.NewInt(1_000_000),
			expected:        sdkmath.NewInt(1_000_000),
			expectForfeited: true,
		},
		{
			name:            "gross TVV at the 256-bit ceiling leaves a ceiling carry intact",
			carried:         ceiling,
			accrued:         sdkmath.ZeroInt(),
			grossTVV:        ceiling,
			expected:        ceiling,
			expectForfeited: false,
		},
		{
			name:            "an empty vault forfeits the entire liability",
			carried:         sdkmath.NewInt(750_000),
			accrued:         sdkmath.NewInt(25_000),
			grossTVV:        sdkmath.ZeroInt(),
			expected:        sdkmath.ZeroInt(),
			expectForfeited: true,
		},
	}

	for _, tc := range tests {
		s.Run(tc.name, func() {
			capped, forfeited := s.k.TestAccessor_capAumFeeLiability(s.T(), tc.carried, tc.accrued, tc.grossTVV)
			s.Assert().Equal(tc.expected.String(), capped.String(), "capped liability for carried %s plus accrued %s against gross TVV %s", tc.carried, tc.accrued, tc.grossTVV)
			s.Assert().Equal(tc.expectForfeited, forfeited, "forfeiture flag for carried %s plus accrued %s against gross TVV %s", tc.carried, tc.accrued, tc.grossTVV)
			s.Assert().False(capped.GT(tc.grossTVV), "capped liability %s must never exceed gross TVV %s", capped, tc.grossTVV)
		})
	}
}

func (s *TestSuite) TestKeeper_PerformVaultFeeTransfer_RejectedTransferLeavesFeeOutstanding() {
	const (
		underlyingDenom = "aumu"
		shareDenom      = "vaumu"
	)
	feePeriod := 60 * 24 * time.Hour
	deposit := sdkmath.NewInt(1_000_000)
	accruedFee := sdkmath.NewInt(1_643)

	tests := []struct {
		name                string
		revokeFeeAttribute  bool
		expectedCollected   sdkmath.Int
		expectedOutstanding sdkmath.Int
	}{
		{
			name:                "fee collector holds the required attribute, whole fee is collected",
			revokeFeeAttribute:  false,
			expectedCollected:   accruedFee,
			expectedOutstanding: sdkmath.ZeroInt(),
		},
		{
			name:                "fee collector lost the required attribute, whole fee stays outstanding",
			revokeFeeAttribute:  true,
			expectedCollected:   sdkmath.ZeroInt(),
			expectedOutstanding: accruedFee,
		},
	}

	for _, tc := range tests {
		s.Run(tc.name, func() {
			s.SetupTest()
			vault, _ := s.setupRestrictedVaultWithDeposit(underlyingDenom, shareDenom, deposit)
			now := s.ctx.BlockTime()
			vault.AumFeeBips = 100
			s.SetVaultRatesAndPeriod(vault, "0.0", "0.0", now.Add(-feePeriod).Unix(), 0)

			feeCollector, err := s.k.GetAUMFeeAddress(s.ctx)
			s.Require().NoError(err, "failed to get AUM fee address")
			if tc.revokeFeeAttribute {
				s.revokeTechFeeAttribute()
			}

			s.SetCtxBlockTime(now)
			err = s.k.PerformVaultFeeTransfer(s.ctx, vault)
			s.Require().NoError(err, "an uncollectable AUM fee must not fail the transfer, it must be carried as outstanding")

			s.Require().Equal(tc.expectedOutstanding.String(), vault.OutstandingAumFee.Amount.String(), "outstanding AUM fee mismatch after the fee transfer")
			s.Require().Equal(now.Unix(), vault.FeePeriodStart, "fee period should advance even when the fee could not be transferred")
			s.assertBalance(feeCollector, underlyingDenom, tc.expectedCollected)
			s.assertBalance(vault.PrincipalMarkerAddress(), underlyingDenom, deposit.Sub(tc.expectedCollected))

			s.requireTypedEventEmitted(types.NewEventVaultFeeCollected(
				vault.GetAddress().String(),
				sdk.NewCoin(underlyingDenom, tc.expectedCollected),
				sdk.NewCoin(underlyingDenom, accruedFee),
				sdk.NewCoin(underlyingDenom, deposit),
				sdk.NewCoin(underlyingDenom, tc.expectedOutstanding),
				int64(feePeriod/time.Second),
			))
		})
	}
}

func (s *TestSuite) TestKeeper_PerformVaultFeeTransfer_CapsOutstandingFeeAtGrossTVV() {
	const (
		underlyingDenom = "aumu"
		shareDenom      = "vaumu"
	)
	halfYear := time.Duration(interest.SecondsPerYear/2) * time.Second
	deposit := sdkmath.NewInt(1_000_000)
	halfYearFeeAtMaxBips := sdkmath.NewInt(500_000)

	tests := []struct {
		name                string
		halfYearPeriods     int
		expectedOutstanding sdkmath.Int
	}{
		{
			name:                "one uncollectable period accrues half the vault value",
			halfYearPeriods:     1,
			expectedOutstanding: halfYearFeeAtMaxBips,
		},
		{
			name:                "two uncollectable periods accrue exactly the vault value",
			halfYearPeriods:     2,
			expectedOutstanding: deposit,
		},
		{
			name:                "a third uncollectable period is capped at the vault value",
			halfYearPeriods:     3,
			expectedOutstanding: deposit,
		},
		{
			name:                "a decade of uncollectable periods stays capped at the vault value",
			halfYearPeriods:     20,
			expectedOutstanding: deposit,
		},
	}

	for _, tc := range tests {
		s.Run(tc.name, func() {
			s.SetupTest()
			vault, _ := s.setupRestrictedVaultWithDeposit(underlyingDenom, shareDenom, deposit)
			vault.AumFeeBips = 10_000
			s.SetVaultRatesAndPeriod(vault, "0.0", "0.0", s.ctx.BlockTime().Unix(), 0)
			s.revokeTechFeeAttribute()

			for period := 1; period <= tc.halfYearPeriods; period++ {
				s.SetCtxBlockTime(s.ctx.BlockTime().Add(halfYear))
				s.Require().NoError(s.k.PerformVaultFeeTransfer(s.ctx, vault),
					"an uncollectable AUM fee must not fail the transfer on half-year period %d", period)
				s.Require().Equal(s.ctx.BlockTime().Unix(), vault.FeePeriodStart,
					"fee period must advance on half-year period %d so no period is charged twice", period)
			}

			grossTVV, err := s.k.GetTVV(s.ctx, *vault)
			s.Require().NoError(err, "failed to compute gross TVV for vault %s", vault.GetAddress())
			s.Require().Equal(deposit.String(), grossTVV.String(),
				"no fee could be collected, so the whole deposit should still back the gross TVV")
			s.Require().Equal(tc.expectedOutstanding.String(), vault.OutstandingAumFee.Amount.String(),
				"the fee collector must never be owed more than the %s%s the vault holds", grossTVV, underlyingDenom)

			netTVV, err := s.k.GetNetTVV(s.ctx, *vault)
			s.Require().NoError(err, "failed to compute net TVV for vault %s", vault.GetAddress())
			s.Require().Equal(grossTVV.Sub(tc.expectedOutstanding).String(), netTVV.String(),
				"net TVV must be gross minus the capped liability rather than a zero floored over an oversized liability")
			s.assertBalance(vault.PrincipalMarkerAddress(), underlyingDenom, deposit)
		})
	}
}

func (s *TestSuite) TestKeeper_sendAUMFee() {
	const (
		underlyingDenom = "aumu"
		shareDenom      = "vaumu"
	)
	deposit := sdkmath.NewInt(1_000_000)

	tests := []struct {
		name               string
		revokeFeeAttribute bool
		fee                sdkmath.Int
		expectedErr        string
		expectedCollected  sdkmath.Int
	}{
		{
			name:              "attributed fee collector, whole fee moves out of the principal marker",
			fee:               sdkmath.NewInt(1_643),
			expectedCollected: sdkmath.NewInt(1_643),
		},
		{
			name:              "fee equal to the entire principal balance is transferable",
			fee:               deposit,
			expectedCollected: deposit,
		},
		{
			name:               "unattributed fee collector is rejected and no coins move",
			revokeFeeAttribute: true,
			fee:                sdkmath.NewInt(1_643),
			expectedErr:        `does not contain the "aumu" required attribute`,
			expectedCollected:  sdkmath.ZeroInt(),
		},
		{
			name:              "fee larger than the principal balance is rejected and no coins move",
			fee:               deposit.AddRaw(1),
			expectedErr:       "insufficient funds",
			expectedCollected: sdkmath.ZeroInt(),
		},
	}

	for _, tc := range tests {
		s.Run(tc.name, func() {
			s.SetupTest()
			vault, _ := s.setupRestrictedVaultWithDeposit(underlyingDenom, shareDenom, deposit)
			feeCollector, err := s.k.GetAUMFeeAddress(s.ctx)
			s.Require().NoError(err, "failed to get AUM fee address")
			if tc.revokeFeeAttribute {
				s.revokeTechFeeAttribute()
			}

			err = s.k.TestAccessor_sendAUMFee(s.T(), s.ctx, vault, feeCollector, sdk.NewCoin(underlyingDenom, tc.fee))

			if tc.expectedErr != "" {
				s.Require().ErrorContains(err, tc.expectedErr, "sending a fee of %s%s should have been rejected", tc.fee, underlyingDenom)
			} else {
				s.Require().NoError(err, "sending a fee of %s%s should have succeeded", tc.fee, underlyingDenom)
			}
			s.assertBalance(feeCollector, underlyingDenom, tc.expectedCollected)
			s.assertBalance(vault.PrincipalMarkerAddress(), underlyingDenom, deposit.Sub(tc.expectedCollected))
		})
	}
}

func (s *TestSuite) TestKeeper_sendAUMFee_GrantsVaultAsTransferAgent() {
	const (
		underlyingDenom = "aumu"
		shareDenom      = "vaumu"
	)
	deposit := sdkmath.NewInt(1_000_000)
	fee := sdk.NewCoin(underlyingDenom, sdkmath.NewInt(1_643))

	vault, _ := s.setupRestrictedVaultWithDeposit(underlyingDenom, shareDenom, deposit)
	feeCollector, err := s.k.GetAUMFeeAddress(s.ctx)
	s.Require().NoError(err, "failed to get AUM fee address")

	err = s.k.BankKeeper.SendCoins(s.ctx, vault.PrincipalMarkerAddress(), feeCollector, sdk.NewCoins(fee))
	s.Require().Error(err, "moving the fee out of the principal marker without a transfer agent should be rejected, otherwise this test proves nothing")
	s.assertBalance(feeCollector, underlyingDenom, sdkmath.ZeroInt())

	s.Require().NoError(s.k.TestAccessor_sendAUMFee(s.T(), s.ctx, vault, feeCollector, fee),
		"sendAUMFee must supply the vault as the transfer agent so the same send succeeds")
	s.assertBalance(feeCollector, underlyingDenom, fee.Amount)
}

func (s *TestSuite) TestKeeper_ReconcileVault_UncollectableAUMFeeDoesNotBrickVault() {
	const (
		underlyingDenom = "aumu"
		shareDenom      = "vaumu"
	)
	feePeriod := 30 * 24 * time.Hour
	deposit := sdkmath.NewInt(1_000_000)

	vault, _ := s.setupRestrictedVaultWithDeposit(underlyingDenom, shareDenom, deposit)
	vaultAddr := vault.GetAddress()

	s.SetCtxBlockTime(s.ctx.BlockTime().Add(feePeriod))
	vault, err := s.k.GetVault(s.ctx, vaultAddr)
	s.Require().NoError(err, "failed to get vault %s before the first reconcile", vaultAddr)
	s.Require().NoError(s.k.TestAccessor_reconcileVault(s.T(), s.ctx, vault),
		"reconcile should succeed while the fee collector holds the required attribute")
	s.Require().NoError(s.k.SetVaultAccount(s.ctx, vault), "failed to persist vault after the first reconcile")

	s.revokeTechFeeAttribute()

	s.SetCtxBlockTime(s.ctx.BlockTime().Add(feePeriod))
	vault, err = s.k.GetVault(s.ctx, vaultAddr)
	s.Require().NoError(err, "failed to get vault %s before the reconcile with an unattributed fee collector", vaultAddr)
	s.Require().NoError(s.k.TestAccessor_reconcileVault(s.T(), s.ctx, vault),
		"reconcile must not fail when the AUM fee cannot be transferred to an unattributed fee collector")
	s.Require().True(vault.OutstandingAumFee.Amount.IsPositive(), "the uncollected AUM fee must be carried as an outstanding liability")
	s.Require().NoError(s.k.SetVaultAccount(s.ctx, vault), "failed to persist vault after the reconcile with an unattributed fee collector")

	depositor := s.fundRestrictedHolder(underlyingDenom, sdkmath.NewInt(100_000))
	shares, err := s.k.SwapIn(s.ctx, vaultAddr, depositor, sdk.NewCoin(underlyingDenom, sdkmath.NewInt(100_000)))
	s.Require().NoError(err, "swap-in must keep working while the AUM fee is uncollectable")

	_, err = s.k.SwapOut(s.ctx, vaultAddr, depositor, *shares)
	s.Require().NoError(err, "swap-out must keep working while the AUM fee is uncollectable")

	s.Require().NoError(s.k.TestAccessor_processPendingSwapOuts(s.T(), s.ctx, keeper.MaxSwapOutBatchSize),
		"swap-out processing must keep working while the AUM fee is uncollectable")
	s.Require().Zero(s.countPendingSwapOuts(), "the swap-out should have been paid out, not deferred")
	s.Require().True(s.k.BankKeeper.GetBalance(s.ctx, depositor, underlyingDenom).Amount.IsPositive(),
		"the depositor should have been paid their redeemed underlying asset")
}

func (s *TestSuite) TestKeeper_CanPayInterestDuration_WithAUMFee() {
	s.SetupTest()
	shareDenom := "fee.payout.shares"
	underlyingDenom := "underlying"
	underlying := sdk.NewInt64Coin(underlyingDenom, 1_000_000_000)

	s.requireAddFinalizeAndActivateMarker(underlying, s.adminAddr)
	vault := s.CreateVaultWithParams(shareDenom, underlyingDenom)
	s.SetVaultRatesAndPeriod(vault, "0.0", "", 0, 0)
	s.FundMarker(shareDenom, sdk.NewCoins(underlying))

	year := int64(365 * 24 * time.Hour / time.Second)

	ok, err := s.k.CanPayInterestDuration(s.ctx, vault, year)
	s.Require().NoError(err, "CanPayInterestDuration returned error for vault=%s year=%d", vault.Address, year)
	s.Require().True(ok, "should succeed because a zero interest rate never requires reserves regardless of AUM fees")
}

func (s *TestSuite) TestKeeper_HandleVaultFeeTimeouts() {
	s.SetupTest()
	shareDenom := "fee.timeout.shares"
	underlyingDenom := "underlying"
	underlying := sdk.NewInt64Coin(underlyingDenom, 1_000_000_000)
	vaultAddr := types.GetVaultAddress(shareDenom)

	now := s.ctx.BlockTime()
	twoMonthsAgo := now.Add(-60 * 24 * time.Hour)

	s.requireAddFinalizeAndActivateMarker(underlying, s.adminAddr)
	vault := s.CreateVaultWithParams(shareDenom, underlyingDenom)
	s.SetVaultRatesAndPeriod(vault, "0.0", "0.0", twoMonthsAgo.Unix(), twoMonthsAgo.Unix())
	s.FundMarker(shareDenom, sdk.NewCoins(underlying))

	s.Require().NoError(s.k.FeeTimeoutQueue.Enqueue(s.ctx, twoMonthsAgo.Unix(), vaultAddr), "failed to enqueue vault in FeeTimeoutQueue")

	err := s.k.TestAccessor_handleVaultFeeTimeouts(s.T(), s.ctx, keeper.MaxFeeTimeoutsPerBlock)
	s.Require().NoError(err, "handleVaultFeeTimeouts should succeed")

	provlabsAddr, err := s.k.GetAUMFeeAddress(s.ctx)
	s.Require().NoError(err, "failed to get AUM fee address from GetAUMFeeAddress")

	feeCollected := s.simApp.BankKeeper.GetBalance(s.ctx, provlabsAddr, underlyingDenom).Amount
	s.Require().True(feeCollected.IsPositive(), "fee should be collected for address %s", provlabsAddr)

	found := false
	err = s.k.FeeTimeoutQueue.Walk(s.ctx, func(timeout uint64, addr sdk.AccAddress) (bool, error) {
		if addr.Equals(vaultAddr) {
			found = true
			s.Require().Greater(int64(timeout), now.Unix(), "new fee timeout should be in the future")
		}
		return false, nil
	})
	s.Require().NoError(err, "FeeTimeoutQueue.Walk returned unexpected error during verification")
	s.Require().True(found, "new fee timeout should be enqueued")

	vault, err = s.k.GetVault(s.ctx, vaultAddr)
	s.Require().NoError(err, "failed to get vault for address %s", vaultAddr)
	s.Require().Equal(s.ctx.BlockTime().Unix(), vault.FeePeriodStart, "FeePeriodStart should be updated")
}

func (s *TestSuite) TestKeeper_AccrualCalculations() {
	shareDenom := "vaultshares"
	underlyingDenom := "underlying"
	underlying := sdk.NewInt64Coin(underlyingDenom, 1_000_000_000)
	vaultAddress := types.GetVaultAddress(shareDenom)
	testBlockTime := time.Now().UTC()
	sixtyDays := -60 * 24 * time.Hour
	pastTime := testBlockTime.Add(sixtyDays)

	setup := func() *types.VaultAccount {
		s.requireAddFinalizeAndActivateMarker(underlying, s.adminAddr)
		_, err := s.k.CreateVault(s.ctx, &types.MsgCreateVaultRequest{
			Admin:           s.adminAddr.String(),
			ShareDenom:      shareDenom,
			UnderlyingAsset: underlyingDenom,
		})
		s.Require().NoError(err, "failed to create vault in setup")

		vault, err := s.k.GetVault(s.ctx, vaultAddress)
		s.Require().NoError(err, "failed to get vault in setup")
		s.ctx = s.ctx.WithBlockTime(testBlockTime)
		return vault
	}

	s.Run("CalculateAccruedInterest", func() {
		s.SetupTest()
		vault := setup()

		tests := []struct {
			name     string
			rate     string
			start    int64
			expected sdkmath.Int
		}{
			{
				name:     "no interest rate set, should return zero interest",
				rate:     "",
				start:    pastTime.Unix(),
				expected: sdkmath.ZeroInt(),
			},
			{
				name:     "positive interest rate, should return correct accrual",
				rate:     "0.25",
				start:    pastTime.Unix(),
				expected: sdkmath.NewInt(41_952_013),
			},
			{
				name:     "negative interest rate, should return negative accrual",
				rate:     "-0.25",
				start:    pastTime.Unix(),
				expected: sdkmath.NewInt(-40_262_904),
			},
			{
				name:     "period start in the future, should return zero interest",
				rate:     "0.25",
				start:    testBlockTime.Add(time.Hour).Unix(),
				expected: sdkmath.ZeroInt(),
			},
		}

		for _, tc := range tests {
			s.Run(tc.name, func() {
				vault.CurrentInterestRate = tc.rate
				vault.PeriodStart = tc.start
				amt, err := s.k.CalculateAccruedInterest(s.ctx, *vault, underlying)
				s.Require().NoError(err, "accrued interest calculation failed for case: %s", tc.name)
				s.Require().Equal(tc.expected, amt, "interest accrual mismatch for case: %s", tc.name)
			})
		}
	})

	s.Run("CalculateAccruedAUMFee", func() {
		s.SetupTest()
		vault := setup()

		tests := []struct {
			name     string
			start    int64
			assets   sdkmath.Int
			expected sdkmath.Int
		}{
			{
				name:     "no fee period start, should return zero fee",
				start:    0,
				assets:   underlying.Amount,
				expected: sdkmath.ZeroInt(),
			},
			{
				name:     "valid period elapsed, should return 15bps annual fee",
				start:    pastTime.Unix(),
				assets:   underlying.Amount,
				expected: sdkmath.NewInt(246_575),
			},
			{
				name:     "zero assets, should return zero fee",
				start:    pastTime.Unix(),
				assets:   sdkmath.ZeroInt(),
				expected: sdkmath.ZeroInt(),
			},
		}

		for _, tc := range tests {
			s.Run(tc.name, func() {
				vault.FeePeriodStart = tc.start
				amt, err := s.k.CalculateAccruedAUMFee(s.ctx, *vault, tc.assets)
				s.Require().NoError(err, "accrued AUM fee calculation failed for case: %s", tc.name)
				s.Require().Equal(tc.expected, amt, "AUM fee mismatch for case: %s", tc.name)
			})
		}
	})

	s.Run("CalculateAccruedAUMFeePayment", func() {
		s.SetupTest()
		vault := setup()

		tests := []struct {
			name     string
			start    int64
			expected sdk.Coin
		}{
			{
				name:     "no fee period start, should return zero coin",
				start:    0,
				expected: sdk.NewInt64Coin(underlyingDenom, 0),
			},
			{
				name:     "valid period, should return the fee in the underlying asset",
				start:    pastTime.Unix(),
				expected: sdk.NewInt64Coin(underlyingDenom, 246_575),
			},
		}

		for _, tc := range tests {
			s.Run(tc.name, func() {
				vault.FeePeriodStart = tc.start
				s.k.AuthKeeper.SetAccount(s.ctx, vault)

				amt, err := s.k.CalculateAccruedAUMFeePayment(s.ctx, *vault, underlying.Amount)
				s.Require().NoError(err, "accrued AUM fee payment calculation failed for case: %s", tc.name)
				s.Require().Equal(tc.expected, amt, "accrued AUM fee payment coin mismatch for case: %s", tc.name)
			})
		}
	})

	s.Run("CalculateVaultTotalAssets", func() {
		s.SetupTest()
		vault := setup()

		tests := []struct {
			name        string
			rate        string
			periodStart int64
			feeStart    int64
			outstanding sdk.Coin
			expected    sdkmath.Int
		}{
			{
				name:        "static vault with no accruals, should return principal",
				rate:        "0.0",
				periodStart: 0,
				feeStart:    0,
				outstanding: sdk.NewInt64Coin(underlyingDenom, 0),
				expected:    underlying.Amount,
			},
			{
				name:        "active vault with interest and fees, should return net assets after all accruals",
				rate:        "0.25",
				periodStart: pastTime.Unix(),
				feeStart:    pastTime.Unix(),
				outstanding: sdk.NewInt64Coin(underlyingDenom, 1000),
				expected:    sdkmath.NewInt(1_041_694_094),
			},
		}

		for _, tc := range tests {
			s.Run(tc.name, func() {
				vault.CurrentInterestRate = tc.rate
				vault.PeriodStart = tc.periodStart
				vault.FeePeriodStart = tc.feeStart
				vault.OutstandingAumFee = tc.outstanding

				amt, err := s.k.CalculateVaultTotalAssets(s.ctx, vault, underlying)
				s.Require().NoError(err, "total assets calculation failed for case: %s", tc.name)
				s.Require().Equal(tc.expected, amt, "total vault assets mismatch for case: %s", tc.name)
			})
		}
	})
}

func (s *TestSuite) TestKeeper_HandleVaultFeeTimeouts_RetryOnFailure() {
	s.SetupTest()
	shareDenom := "fee.timeout.shares"
	underlyingDenom := "underlying"
	heldDenom := "other"
	underlying := sdk.NewInt64Coin(underlyingDenom, 1_000_000_000)
	vaultAddr := types.GetVaultAddress(shareDenom)

	now := s.ctx.BlockTime()
	twoMonthsAgo := now.Add(-60 * 24 * time.Hour)

	s.requireAddFinalizeAndActivateMarker(underlying, s.adminAddr)
	s.requireAddFinalizeAndActivateMarker(sdk.NewInt64Coin(heldDenom, 1_000_000_000), s.adminAddr)

	vault := s.CreateVaultWithParams(shareDenom, underlyingDenom)

	s.Require().NoError(s.k.FeeTimeoutQueue.Dequeue(s.ctx, vault.FeePeriodTimeout, vaultAddr), "failed to dequeue the initial fee timeout enqueued by CreateVaultWithParams")

	s.SetVaultRatesAndPeriod(vault, "0.0", "0.0", twoMonthsAgo.Unix(), twoMonthsAgo.Unix())

	s.FundMarker(shareDenom, sdk.NewCoins(underlying))

	s.Require().NoError(s.k.FeeTimeoutQueue.Enqueue(s.ctx, twoMonthsAgo.Unix(), vaultAddr), "failed to enqueue vault in FeeTimeoutQueue")

	// Funding the principal out of band leaves the vault unvaluable, simulating a transient
	// PerformVaultFeeTransfer failure.
	s.seedOversizedNAV(vault, heldDenom, underlyingDenom, maxValidNAVPrice(), sdkmath.OneInt())
	s.fundPrincipalForBrokenValuation(vault, sdk.NewCoins(sdk.NewInt64Coin(heldDenom, 2)))

	err := s.k.TestAccessor_handleVaultFeeTimeouts(s.T(), s.ctx, keeper.MaxFeeTimeoutsPerBlock)
	s.Require().NoError(err, "handleVaultFeeTimeouts should not return error even if a vault fails")

	expectedTimeout := uint64(s.ctx.BlockTime().Unix() + keeper.AutoReconcileTimeout)
	found := false
	err = s.k.FeeTimeoutQueue.Walk(s.ctx, func(timeout uint64, addr sdk.AccAddress) (bool, error) {
		if addr.Equals(vaultAddr) {
			found = true
			s.Require().Equal(expectedTimeout, timeout, "vault should be rescheduled with new timeout")
		}
		return false, nil
	})
	s.Require().NoError(err, "FeeTimeoutQueue.Walk returned unexpected error during retry verification")
	s.Require().True(found, "vault should be re-enqueued in the fee timeout queue after the transient failure")

	updatedVault, err := s.k.GetVault(s.ctx, vaultAddr)
	s.Require().NoError(err)
	s.Require().Equal(twoMonthsAgo.Unix(), updatedVault.FeePeriodStart, "FeePeriodStart should be preserved on transient failure")
}

func (s *TestSuite) TestKeeper_HandleVaultFeeTimeouts_Success() {
	s.SetupTest()
	shareDenom := "fee.success.shares"
	underlyingDenom := "underlying"
	underlying := sdk.NewInt64Coin(underlyingDenom, 1_000_000_000)
	vaultAddr := types.GetVaultAddress(shareDenom)

	now := s.ctx.BlockTime()
	twoMonthsAgo := now.Add(-60 * 24 * time.Hour)

	s.requireAddFinalizeAndActivateMarker(underlying, s.adminAddr)

	vault := s.CreateVaultWithParams(shareDenom, underlyingDenom)

	s.Require().NoError(s.k.FeeTimeoutQueue.Dequeue(s.ctx, vault.FeePeriodTimeout, vaultAddr), "failed to dequeue the initial fee timeout enqueued by CreateVaultWithParams")

	s.SetVaultRatesAndPeriod(vault, "0.0", "0.0", twoMonthsAgo.Unix(), twoMonthsAgo.Unix())

	s.FundMarker(shareDenom, sdk.NewCoins(underlying))

	s.Require().NoError(s.k.FeeTimeoutQueue.Enqueue(s.ctx, twoMonthsAgo.Unix(), vaultAddr), "failed to enqueue vault in FeeTimeoutQueue")

	err := s.k.TestAccessor_handleVaultFeeTimeouts(s.T(), s.ctx, keeper.MaxFeeTimeoutsPerBlock)
	s.Require().NoError(err, "handleVaultFeeTimeouts should succeed")

	foundOld := false
	foundNew := false
	err = s.k.FeeTimeoutQueue.Walk(s.ctx, func(timeout uint64, addr sdk.AccAddress) (bool, error) {
		if addr.Equals(vaultAddr) {
			if timeout == uint64(twoMonthsAgo.Unix()) {
				foundOld = true
			} else if timeout > uint64(now.Unix()) {
				foundNew = true
			}
		}
		return false, nil
	})
	s.Require().NoError(err, "FeeTimeoutQueue.Walk returned unexpected error during verification")
	s.Require().False(foundOld, "vault should be dequeued from old timeout")
	s.Require().True(foundNew, "vault should be enqueued with new timeout")
}

func (s *TestSuite) TestKeeper_HandleVaultInterestTimeouts_RetryOnFailure() {
	s.SetupTest()
	shareDenom := "interest.timeout.shares"
	underlyingDenom := "underlying"
	heldDenom := "other"
	underlying := sdk.NewInt64Coin(underlyingDenom, 1_000_000_000)
	vaultAddr := types.GetVaultAddress(shareDenom)

	now := s.ctx.BlockTime()
	twoMonthsAgo := now.Add(-60 * 24 * time.Hour)

	s.requireAddFinalizeAndActivateMarker(underlying, s.adminAddr)
	s.requireAddFinalizeAndActivateMarker(sdk.NewInt64Coin(heldDenom, 1_000_000_000), s.adminAddr)

	vault := s.CreateVaultWithParams(shareDenom, underlyingDenom)

	// The initial fee timeout from CreateVaultWithParams is left in place; this test exercises
	// the interest PayoutTimeoutQueue.
	s.SetVaultRatesAndPeriod(vault, "0.1", "0.1", twoMonthsAgo.Unix(), twoMonthsAgo.Unix())
	vault.PeriodStart = twoMonthsAgo.Unix()
	vault.PeriodTimeout = twoMonthsAgo.Unix()
	s.k.AuthKeeper.SetAccount(s.ctx, vault)

	s.FundMarker(shareDenom, sdk.NewCoins(underlying))

	s.Require().NoError(s.k.PayoutTimeoutQueue.Enqueue(s.ctx, twoMonthsAgo.Unix(), vaultAddr), "failed to enqueue vault")

	// Funding the principal out of band leaves the vault unvaluable, simulating a transient
	// failure without making the VaultAccount itself invalid.
	s.seedOversizedNAV(vault, heldDenom, underlyingDenom, maxValidNAVPrice(), sdkmath.OneInt())
	s.fundPrincipalForBrokenValuation(vault, sdk.NewCoins(sdk.NewInt64Coin(heldDenom, 2)))

	err := s.k.TestAccessor_handleVaultInterestTimeouts(s.T(), s.ctx, keeper.MaxInterestTimeoutsPerBlock)
	s.Require().NoError(err, "handleVaultInterestTimeouts should not return error")

	expectedTimeout := uint64(s.ctx.BlockTime().Unix() + keeper.AutoReconcileTimeout)
	found := false
	err = s.k.PayoutTimeoutQueue.Walk(s.ctx, func(timeout uint64, addr sdk.AccAddress) (bool, error) {
		if addr.Equals(vaultAddr) {
			found = true
			s.Require().Equal(expectedTimeout, timeout, "vault should be rescheduled with new timeout")
		}
		return false, nil
	})
	s.Require().NoError(err, "PayoutTimeoutQueue.Walk returned unexpected error during retry verification")
	s.Require().True(found, "vault should be re-enqueued in the interest timeout queue after the transient failure")

	updatedVault, err := s.k.GetVault(s.ctx, vaultAddr)
	s.Require().NoError(err)
	s.Require().Equal(twoMonthsAgo.Unix(), updatedVault.PeriodStart, "PeriodStart should be preserved on transient failure")
}

func (s *TestSuite) TestReconcileVault_BootstrapFeePeriod() {
	shareDenom := "vaultshares"
	underlying := sdk.NewInt64Coin("underlying", 1_000_000_000)
	totalShares := sdk.NewInt64Coin(shareDenom, 1_000_000_000_000_000)
	testBlockTime := time.Now()
	periodStart := testBlockTime.Add(-1 * time.Hour).Unix()

	vaultAddr, vault := s.setupReconcileVault("0.25", periodStart, false, underlying, shareDenom, totalShares, testBlockTime)

	vault.FeePeriodStart = 0
	vault.FeePeriodTimeout = 0
	s.k.AuthKeeper.SetAccount(s.ctx, vault)

	v, err := s.k.GetVault(s.ctx, vaultAddr)
	s.Require().NoError(err)
	s.Require().Equal(int64(0), v.FeePeriodStart, "FeePeriodStart should be 0 initially")

	err = s.k.TestAccessor_reconcileVault(s.T(), s.ctx, v)
	s.Require().NoError(err)

	v, err = s.k.GetVault(s.ctx, vaultAddr)
	s.Require().NoError(err)
	s.Require().NotEqual(int64(0), v.FeePeriodStart, "FeePeriodStart should have been bootstrapped")
	s.Require().Equal(testBlockTime.Unix(), v.FeePeriodStart, "FeePeriodStart should be set to current block time")
}

func (s *TestSuite) TestKeeper_HandleVaultInterestTimeouts_PerBlockVisitBudget() {
	testBlockTime := time.Now().UTC()
	dueTime := testBlockTime.Add(-1 * time.Hour).Unix()
	infos := []VaultInfo{NewVaultInfo(1), NewVaultInfo(2), NewVaultInfo(3)}

	tests := []struct {
		name                string
		limit               int
		expectedDuePerBlock []int
	}{
		{
			name:                "zero budget visits nothing and leaves the backlog due",
			limit:               0,
			expectedDuePerBlock: []int{3, 3},
		},
		{
			name:                "budget smaller than backlog drains it across blocks",
			limit:               2,
			expectedDuePerBlock: []int{1, 0},
		},
		{
			name:                "budget larger than backlog drains it in one block",
			limit:               keeper.MaxInterestTimeoutsPerBlock,
			expectedDuePerBlock: []int{0, 0},
		},
	}

	for _, tc := range tests {
		s.Run(tc.name, func() {
			s.SetupTest()
			s.ctx = s.ctx.WithBlockTime(testBlockTime)
			for _, info := range infos {
				s.createVaultWithDueInterestTimeout(info, dueTime, false)
			}

			for block, expectedDue := range tc.expectedDuePerBlock {
				err := s.k.TestAccessor_handleVaultInterestTimeouts(s.T(), s.ctx, tc.limit)
				s.Require().NoError(err, "handleVaultInterestTimeouts should not error on pass %d with limit %d", block+1, tc.limit)
				s.Require().Equal(
					expectedDue, s.countDuePayoutTimeouts(testBlockTime.Unix()),
					"due interest timeout backlog mismatch after pass %d with limit %d", block+1, tc.limit,
				)
			}
		})
	}
}

func (s *TestSuite) TestKeeper_HandleVaultInterestTimeouts_PausedVaultsDoNotStarveActiveVaults() {
	testBlockTime := time.Now().UTC()
	pausedDueTime := testBlockTime.Add(-2 * time.Hour).Unix()
	activeDueTime := testBlockTime.Add(-1 * time.Hour).Unix()
	pausedInfos := []VaultInfo{NewVaultInfo(1), NewVaultInfo(2)}
	activeInfo := NewVaultInfo(3)

	tests := []struct {
		name                string
		limit               int
		expectedDuePerBlock []int
	}{
		{
			name:                "budget filled by the paused front dequeues it and the active vault is served the next block",
			limit:               2,
			expectedDuePerBlock: []int{1, 0},
		},
		{
			name:                "budget larger than the paused front dequeues it and serves the active vault in the same block",
			limit:               3,
			expectedDuePerBlock: []int{0, 0},
		},
	}

	for _, tc := range tests {
		s.Run(tc.name, func() {
			s.SetupTest()
			s.ctx = s.ctx.WithBlockTime(testBlockTime)
			for _, info := range pausedInfos {
				s.createVaultWithDueInterestTimeout(info, pausedDueTime, true)
			}
			s.createVaultWithDueInterestTimeout(activeInfo, activeDueTime, false)

			for block, expectedDue := range tc.expectedDuePerBlock {
				err := s.k.TestAccessor_handleVaultInterestTimeouts(s.T(), s.ctx, tc.limit)
				s.Require().NoError(err, "handleVaultInterestTimeouts should not error on pass %d with limit %d", block+1, tc.limit)
				s.Require().Equal(
					expectedDue, s.countDuePayoutTimeouts(testBlockTime.Unix()),
					"due backlog mismatch after pass %d with limit %d: paused entries must be dequeued instead of starving the active vault", block+1, tc.limit,
				)
			}
		})
	}
}

func (s *TestSuite) TestKeeper_HandleVaultFeeTimeouts_PerBlockVisitBudget() {
	underlyingDenom := "underlying"
	underlying := sdk.NewInt64Coin(underlyingDenom, 1_000_000_000)

	tests := []struct {
		name                string
		limit               int
		expectedDuePerBlock []int
	}{
		{
			name:                "zero budget visits nothing and leaves the backlog due",
			limit:               0,
			expectedDuePerBlock: []int{3, 3},
		},
		{
			name:                "budget smaller than backlog drains it across blocks",
			limit:               2,
			expectedDuePerBlock: []int{1, 0},
		},
		{
			name:                "budget larger than backlog drains it in one block",
			limit:               keeper.MaxFeeTimeoutsPerBlock,
			expectedDuePerBlock: []int{0, 0},
		},
	}

	for _, tc := range tests {
		s.Run(tc.name, func() {
			s.SetupTest()
			now := s.ctx.BlockTime()
			dueTime := now.Add(-60 * 24 * time.Hour).Unix()

			s.requireAddFinalizeAndActivateMarker(underlying, s.adminAddr)
			for i := 1; i <= 3; i++ {
				s.createVaultWithDueFeeTimeout(fmt.Sprintf("feebudgetshares%d", i), underlyingDenom, dueTime, false)
			}

			for block, expectedDue := range tc.expectedDuePerBlock {
				err := s.k.TestAccessor_handleVaultFeeTimeouts(s.T(), s.ctx, tc.limit)
				s.Require().NoError(err, "handleVaultFeeTimeouts should not error on pass %d with limit %d", block+1, tc.limit)
				s.Require().Equal(
					expectedDue, s.countDueFeeTimeouts(now.Unix()),
					"due fee timeout backlog mismatch after pass %d with limit %d", block+1, tc.limit,
				)
			}
		})
	}
}

func (s *TestSuite) TestKeeper_HandleVaultFeeTimeouts_PausedVaultsDoNotStarveActiveVaults() {
	underlyingDenom := "underlying"
	underlying := sdk.NewInt64Coin(underlyingDenom, 1_000_000_000)

	tests := []struct {
		name                string
		limit               int
		expectedDuePerBlock []int
	}{
		{
			name:                "budget filled by the paused front dequeues it and the active vault is served the next block",
			limit:               2,
			expectedDuePerBlock: []int{1, 0},
		},
		{
			name:                "budget larger than the paused front dequeues it and serves the active vault in the same block",
			limit:               3,
			expectedDuePerBlock: []int{0, 0},
		},
	}

	for _, tc := range tests {
		s.Run(tc.name, func() {
			s.SetupTest()
			now := s.ctx.BlockTime()
			pausedDueTime := now.Add(-60 * 24 * time.Hour).Unix()
			activeDueTime := now.Add(-30 * 24 * time.Hour).Unix()

			s.requireAddFinalizeAndActivateMarker(underlying, s.adminAddr)
			s.createVaultWithDueFeeTimeout("feepausedshares1", underlyingDenom, pausedDueTime, true)
			s.createVaultWithDueFeeTimeout("feepausedshares2", underlyingDenom, pausedDueTime, true)
			s.createVaultWithDueFeeTimeout("feeactiveshares", underlyingDenom, activeDueTime, false)

			for block, expectedDue := range tc.expectedDuePerBlock {
				err := s.k.TestAccessor_handleVaultFeeTimeouts(s.T(), s.ctx, tc.limit)
				s.Require().NoError(err, "handleVaultFeeTimeouts should not error on pass %d with limit %d", block+1, tc.limit)
				s.Require().Equal(
					expectedDue, s.countDueFeeTimeouts(now.Unix()),
					"due fee backlog mismatch after pass %d with limit %d: paused entries must be dequeued instead of starving the active vault", block+1, tc.limit,
				)
			}
		})
	}
}

func (s *TestSuite) TestKeeper_HandleReconciledVaults_PerBlockVisitBudget() {
	testBlockTime := time.Now().UTC().Truncate(time.Second)
	infos := []VaultInfo{NewVaultInfo(1), NewVaultInfo(2), NewVaultInfo(3)}

	tests := []struct {
		name                string
		limit               int
		expectedSetPerBlock []int
	}{
		{
			name:                "zero budget visits nothing and leaves the set untouched",
			limit:               0,
			expectedSetPerBlock: []int{3, 3},
		},
		{
			name:                "budget smaller than backlog drains the set across blocks",
			limit:               2,
			expectedSetPerBlock: []int{1, 0},
		},
		{
			name:                "budget larger than backlog drains the set in one block",
			limit:               keeper.MaxPayoutVerificationsPerBlock,
			expectedSetPerBlock: []int{0, 0},
		},
	}

	for _, tc := range tests {
		s.Run(tc.name, func() {
			s.SetupTest()
			s.ctx = s.ctx.WithBlockTime(testBlockTime)
			for _, info := range infos {
				createVaultWithInterest(s, info, "0.1", testBlockTime.Unix(), testBlockTime.Unix(), true, true)
			}

			for block, expectedRemaining := range tc.expectedSetPerBlock {
				err := s.k.TestAccessor_handleReconciledVaults(s.T(), s.ctx, tc.limit)
				s.Require().NoError(err, "handleReconciledVaults should not error on pass %d with limit %d", block+1, tc.limit)
				s.Require().Equal(
					expectedRemaining, s.countPayoutVerificationEntries(),
					"payout verification set backlog mismatch after pass %d with limit %d", block+1, tc.limit,
				)
			}
		})
	}
}
