package keeper

import (
	"errors"
	"fmt"

	"github.com/provlabs/vault/types"

	"cosmossdk.io/collections"

	sdk "github.com/cosmos/cosmos-sdk/types"

	metadatatypes "github.com/provenance-io/provenance/x/metadata/types"
)

// requireNAVDenomRegistered enforces the on-chain denom requirement for an internal
// NAV entry: the asset the price refers to must exist before a price can be recorded
// for it, so a typo or a fabricated denom cannot be priced into the vault's table.
//
// A well-formed metadata value-owner denom (nft/<bech32-metadata-addr>), such as the
// coin minted for a scope, must name a scope that exists in the metadata module. These
// denoms are legitimate vault assets but are barred from being markers, so the metadata
// module is the only registry that can vouch for them. Every other denom, including a
// malformed nft/... string, must be a registered marker.
//
// SetVaultNAV rejects an entry that fails this check; InitGenesis logs and skips it, so a
// deleted scope cannot make a state export unimportable.
func (k Keeper) requireNAVDenomRegistered(ctx sdk.Context, denom string) error {
	if metadataAddr, err := metadatatypes.MetadataAddressFromDenom(denom); err == nil {
		if _, found := k.MetadataKeeper.GetScope(ctx, metadataAddr); !found {
			return fmt.Errorf("NAV denom %q is not an existing metadata scope", denom)
		}
		return nil
	}
	if _, err := k.MarkerKeeper.GetMarkerByDenom(ctx, denom); err != nil {
		return fmt.Errorf("NAV denom %q is not a registered marker: %w", denom, err)
	}
	return nil
}

// validateVaultNAVFields checks all stateless constraints on a NAV entry
// against its vault. It does not verify chain state (e.g. registered markers).
func validateVaultNAVFields(vault *types.VaultAccount, nav types.VaultNAV) error {
	if nav.Denom == vault.TotalShares.Denom {
		return fmt.Errorf("cannot set NAV for vault share denom %q", nav.Denom)
	}
	if err := types.ValidateNotIBCDenom(nav.Denom); err != nil {
		return err
	}
	if nav.Denom == nav.Price.Denom {
		return fmt.Errorf("NAV denom %q and price denom must differ", nav.Denom)
	}
	if err := nav.Price.Validate(); err != nil {
		return fmt.Errorf("invalid NAV price: %w", err)
	}
	if nav.Price.Denom != vault.UnderlyingAsset {
		return fmt.Errorf("NAV price denom %q must be the vault underlying asset %q", nav.Price.Denom, vault.UnderlyingAsset)
	}
	if nav.Volume.IsNil() || !nav.Volume.IsPositive() {
		return fmt.Errorf("NAV volume must be positive")
	}
	if err := types.ValidateNAVComponentMagnitudes(nav.Price, nav.Volume); err != nil {
		return err
	}
	if len(nav.Source) > types.MaxNAVSourceLength {
		return fmt.Errorf("NAV source too long (expected <= %d, actual: %d)", types.MaxNAVSourceLength, len(nav.Source))
	}
	return nil
}

// SetVaultNAV creates or updates the internal net asset value entry for a denom
// on the given vault. The denom need not be one the vault already holds: pricing an
// unheld denom is what authorizes the asset manager to acquire it, and the entry
// contributes nothing to total vault value until the asset arrives at the principal
// marker (see GetTVV). The nav argument supplies the denom, price, volume, and
// source; the updated block height and time are stamped from ctx before the entry
// is stored.
//
// The denom may not be the vault's share denom, whose value is derived from
// the vault's total holdings rather than set externally, and may not be an IBC
// voucher denom (see types.ValidateNotIBCDenom). The denom must also name an
// asset that exists on-chain: a registered marker, or for a metadata
// value-owner denom (nft/<scope-id>) an existing metadata scope.
// The price must be a valid coin denominated in the vault's underlying asset.
// Its amount may be zero so the authority can write a worthless held asset
// down to zero. The volume must be positive.
//
// This method does NOT verify that signer is authorized to mutate the vault's
// NAV table; signer is recorded for event attribution only. Callers must run
// vault.ValidateNAVAuthority (or an equivalent check) before invoking it.
//
// An EventNAVUpdated event is emitted with signer recorded as the NAV authority
// that performed the update.
func (k *Keeper) SetVaultNAV(ctx sdk.Context, vault *types.VaultAccount, nav types.VaultNAV, signer string) error {
	if err := validateVaultNAVFields(vault, nav); err != nil {
		return err
	}
	if err := k.requireNAVDenomRegistered(ctx, nav.Denom); err != nil {
		return err
	}

	navKey := collections.Join(vault.GetAddress(), nav.Denom)
	priced, err := k.NAVs.Has(ctx, navKey)
	if err != nil {
		return fmt.Errorf("failed to check for an existing NAV entry for denom %q on vault %s: %w", nav.Denom, vault.Address, err)
	}

	var entryCount uint64
	if !priced {
		entryCount, err = k.NAVEntryCount(ctx, vault.GetAddress())
		if err != nil {
			return err
		}
		if entryCount >= types.MaxVaultNAVEntries {
			return fmt.Errorf("vault %s already prices %d denoms (max %d): remove an entry before pricing %q",
				vault.Address, entryCount, types.MaxVaultNAVEntries, nav.Denom)
		}
	}

	heldBalance := k.BankKeeper.GetBalance(ctx, vault.PrincipalMarkerAddress(), nav.Denom).Amount
	valueAtOldPrice, err := k.denomValue(ctx, *vault, nav.Denom, heldBalance)
	if err != nil {
		return fmt.Errorf("failed to value denom %q at its previous price: %w", nav.Denom, err)
	}

	nav.UpdatedBlockHeight = ctx.BlockHeight()
	nav.UpdatedTime = ctx.BlockTime().UTC()
	if err = k.NAVs.Set(ctx, navKey, nav); err != nil {
		return fmt.Errorf("failed to store vault NAV: %w", err)
	}
	if !priced {
		if err = k.NAVCounts.Set(ctx, vault.GetAddress(), entryCount+1); err != nil {
			return fmt.Errorf("failed to record NAV entry count for vault %s: %w", vault.Address, err)
		}
	}

	valueAtNewPrice, err := k.denomValue(ctx, *vault, nav.Denom, heldBalance)
	if err != nil {
		return fmt.Errorf("failed to value denom %q at its new price: %w", nav.Denom, err)
	}
	if err := k.adjustTotalValue(ctx, *vault, valueAtNewPrice.Sub(valueAtOldPrice)); err != nil {
		return fmt.Errorf("failed to record repriced value for denom %q: %w", nav.Denom, err)
	}

	k.emitEvent(ctx, types.NewEventNAVUpdated(vault.Address, nav, signer))

	return nil
}

// requirePausedHeldReprice requires the vault to be paused to reprice an asset it holds.
// Pricing a denom it does not hold, or restating a held asset at the price it already
// carries, is allowed while live.
func (k *Keeper) requirePausedHeldReprice(ctx sdk.Context, vault *types.VaultAccount, nav types.VaultNAV) error {
	if vault.Paused {
		return nil
	}

	held := k.BankKeeper.GetBalance(ctx, vault.PrincipalMarkerAddress(), nav.Denom)
	if held.IsZero() {
		return nil
	}

	current, err := k.GetVaultNAV(ctx, vault.GetAddress(), nav.Denom)
	if err != nil && !errors.Is(err, collections.ErrNotFound) {
		return fmt.Errorf("failed to get internal NAV for denom %q on vault %s: %w", nav.Denom, vault.Address, err)
	}
	if err == nil && current.PricesSameAs(nav) {
		return nil
	}

	return fmt.Errorf("vault %s holds %s: pause the vault to reprice a held asset", vault.Address, held)
}

// GetVaultNAV returns the internal NAV entry for the given vault address and
// denom. It returns collections.ErrNotFound when no entry exists.
func (k *Keeper) GetVaultNAV(ctx sdk.Context, vaultAddr sdk.AccAddress, denom string) (types.VaultNAV, error) {
	return k.NAVs.Get(ctx, collections.Join(vaultAddr, denom))
}

// NAVEntryCount returns how many denoms the vault prices. A vault with no recorded count prices
// nothing, so a missing entry reads as zero rather than an error.
func (k *Keeper) NAVEntryCount(ctx sdk.Context, vaultAddr sdk.AccAddress) (uint64, error) {
	count, err := k.NAVCounts.Get(ctx, vaultAddr)
	if err != nil {
		if errors.Is(err, collections.ErrNotFound) {
			return 0, nil
		}
		return 0, fmt.Errorf("failed to read NAV entry count for vault %s: %w", vaultAddr, err)
	}
	return count, nil
}

// releaseNAVEntry drops the vault's NAV entry count by one after an entry is deleted. A count
// already at zero is left alone, since refusing to remove a NAV over a miscount would strand
// the entry. The last entry clears the record instead of storing zero, so the store holds only
// what rebuildNAVCounts would derive.
func (k *Keeper) releaseNAVEntry(ctx sdk.Context, vaultAddr sdk.AccAddress) error {
	count, err := k.NAVEntryCount(ctx, vaultAddr)
	if err != nil {
		return err
	}
	if count == 0 {
		k.getLogger(ctx).Error("NAV entry removed while the recorded count was already zero",
			"vault", vaultAddr.String(),
		)
		return nil
	}
	if count == 1 {
		if err := k.NAVCounts.Remove(ctx, vaultAddr); err != nil {
			return fmt.Errorf("failed to clear NAV entry count for vault %s: %w", vaultAddr, err)
		}
		return nil
	}
	if err := k.NAVCounts.Set(ctx, vaultAddr, count-1); err != nil {
		return fmt.Errorf("failed to record NAV entry count for vault %s: %w", vaultAddr, err)
	}
	return nil
}

// rebuildNAVCounts derives every vault's NAV entry count from the NAV table itself. It backs both
// genesis import and the migration that introduced the count, neither of which can trust a stored
// value. A table already over the cap is recorded as-is and logged, so an import or upgrade never
// fails over pre-existing state; that vault prices no new denoms until it falls back under the cap.
func (k Keeper) rebuildNAVCounts(ctx sdk.Context) error {
	if err := k.NAVCounts.Clear(ctx, nil); err != nil {
		return fmt.Errorf("failed to clear vault NAV entry counts: %w", err)
	}

	var walkedVault sdk.AccAddress
	var count uint64
	recordWalkedVault := func() error {
		if count == 0 {
			return nil
		}
		if count > types.MaxVaultNAVEntries {
			k.getLogger(ctx).Error("vault prices more denoms than the cap allows",
				"vault", walkedVault.String(),
				"nav_entries", count,
				"max", types.MaxVaultNAVEntries,
			)
		}
		if err := k.NAVCounts.Set(ctx, walkedVault, count); err != nil {
			return fmt.Errorf("failed to record NAV entry count for vault %s: %w", walkedVault, err)
		}
		return nil
	}

	err := k.NAVs.Walk(ctx, nil, func(key collections.Pair[sdk.AccAddress, string], _ types.VaultNAV) (bool, error) {
		vaultAddr := key.K1()
		if !vaultAddr.Equals(walkedVault) {
			if err := recordWalkedVault(); err != nil {
				return true, err
			}
			walkedVault, count = vaultAddr, 0
		}
		count++
		return false, nil
	})
	if err != nil {
		return fmt.Errorf("failed to rebuild vault NAV entry counts: %w", err)
	}

	return recordWalkedVault()
}

// checkSettlementNAVGuardrail requires an asset settlement to trade exactly at the
// vault's internal NAV entry for the asset denom, so the manager cannot settle at
// off-NAV prices. Equality is checked by cross-multiplication
// (assetAmount * navPrice == paymentAmount * navVolume) to avoid rounding.
//
// A denom with no entry is rejected rather than waved through. The NAV authority must
// price a denom before the asset manager can trade it, so the manager cannot mint a
// price of their choosing into the pricing table by being the first to acquire the
// denom. The internal NAV table is a price list rather than a held-asset inventory:
// the authority may price a denom the vault does not hold yet, and until the asset
// arrives at the principal marker that entry contributes nothing to the vault's value
// (see GetTVV). Pricing first and settling second is therefore the acquisition path,
// and both messages can ride in a single transaction so the authority's price and the
// manager's settlement commit atomically.
func (k *Keeper) checkSettlementNAVGuardrail(ctx sdk.Context, vault *types.VaultAccount, assetCoin, paymentCoin sdk.Coin) error {
	nav, err := k.GetVaultNAV(ctx, vault.GetAddress(), assetCoin.Denom)
	if err != nil {
		if errors.Is(err, collections.ErrNotFound) {
			return fmt.Errorf("denom %q has no internal NAV entry on vault %s: the NAV authority must price it before it can be settled", assetCoin.Denom, vault.Address)
		}
		return fmt.Errorf("failed to get internal NAV for denom %q on vault %s: %w", assetCoin.Denom, vault.Address, err)
	}

	if nav.Price.Denom != paymentCoin.Denom {
		return fmt.Errorf("settlement of %s for %s is priced in %q but internal NAV for %q on vault %s is priced in %q",
			assetCoin, paymentCoin, paymentCoin.Denom, assetCoin.Denom, vault.Address, nav.Price.Denom)
	}

	assetValue, err := assetCoin.Amount.SafeMul(nav.Price.Amount)
	if err != nil {
		return fmt.Errorf("failed to multiply settlement asset amount %s by NAV price %s: %w", assetCoin.Amount, nav.Price.Amount, err)
	}
	paymentValue, err := paymentCoin.Amount.SafeMul(nav.Volume)
	if err != nil {
		return fmt.Errorf("failed to multiply settlement payment amount %s by NAV volume %s: %w", paymentCoin.Amount, nav.Volume, err)
	}
	if !assetValue.Equal(paymentValue) {
		return fmt.Errorf("settlement of %s for %s does not match internal NAV of %s per %s%s on vault %s",
			assetCoin, paymentCoin, nav.Price, nav.Volume, assetCoin.Denom, vault.Address)
	}

	return nil
}

// RemoveVaultNAV deletes the internal net asset value entry for a denom on the
// given vault and emits an EventNAVRemoved carrying the last recorded price and
// volume, so a price the vault no longer stands behind stops driving valuation
// while its final value is still surfaced to downstream consumers.
//
// It serves two callers: the outbound settlement path, which drops the entry
// once it has drained the vault's last unit of a denom, and the NAV authority,
// which revokes a price it set for a denom the vault never acquired. The
// signer is recorded on the event for attribution and is empty for the
// protocol-initiated settlement removal.
//
// This method does NOT verify that signer is authorized to mutate the vault's
// NAV table, nor that the vault has stopped holding the denom; callers own both
// checks. It returns an error when no entry exists for the denom.
func (k *Keeper) RemoveVaultNAV(ctx sdk.Context, vault *types.VaultAccount, denom, signer string) error {
	nav, err := k.GetVaultNAV(ctx, vault.GetAddress(), denom)
	if err != nil {
		return fmt.Errorf("failed to get internal NAV for denom %q on vault %s: %w", denom, vault.Address, err)
	}
	remainingBalance := k.BankKeeper.GetBalance(ctx, vault.PrincipalMarkerAddress(), denom).Amount
	valueLosingItsPrice, err := k.denomValue(ctx, *vault, denom, remainingBalance)
	if err != nil {
		return fmt.Errorf("failed to value denom %q before dropping its price: %w", denom, err)
	}

	if err := k.NAVs.Remove(ctx, collections.Join(vault.GetAddress(), denom)); err != nil {
		return fmt.Errorf("failed to remove internal NAV for denom %q on vault %s: %w", denom, vault.Address, err)
	}
	if err := k.releaseNAVEntry(ctx, vault.GetAddress()); err != nil {
		return err
	}

	if err := k.adjustTotalValue(ctx, *vault, valueLosingItsPrice.Neg()); err != nil {
		return fmt.Errorf("failed to record removed value for denom %q: %w", denom, err)
	}

	k.emitEvent(ctx, types.NewEventNAVRemoved(vault.Address, nav, signer))
	return nil
}

// SetNAVAuthority rotates the address authorized to mutate the vault's internal
// NAV table. The caller is responsible for verifying that signer is authorized
// to perform this rotation (typically via vault.ValidateAdmin); signer is
// recorded on the emitted EventNAVAuthorityUpdated for attribution only.
//
// When newAuthority equals the current vault.NavAuthority this is a no-op: the
// vault is left unchanged and no event is emitted.
func (k *Keeper) SetNAVAuthority(ctx sdk.Context, vault *types.VaultAccount, newAuthority, signer string) error {
	if vault.NavAuthority == newAuthority {
		return nil
	}
	vault.NavAuthority = newAuthority
	if err := k.SetVaultAccount(ctx, vault); err != nil {
		return fmt.Errorf("failed to set vault account: %w", err)
	}
	k.emitEvent(ctx, types.NewEventNAVAuthorityUpdated(vault.Address, signer, newAuthority))
	return nil
}
