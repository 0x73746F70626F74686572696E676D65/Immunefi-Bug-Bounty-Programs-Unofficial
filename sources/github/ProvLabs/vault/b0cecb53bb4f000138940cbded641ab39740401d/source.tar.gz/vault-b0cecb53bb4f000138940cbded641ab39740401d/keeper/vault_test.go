package keeper_test

import (
	"fmt"
	stdmath "math"
	"time"

	"cosmossdk.io/math"
	sdk "github.com/cosmos/cosmos-sdk/types"
	authtypes "github.com/cosmos/cosmos-sdk/x/auth/types"
	markertypes "github.com/provenance-io/provenance/x/marker/types"

	"github.com/provlabs/vault/interest"
	"github.com/provlabs/vault/keeper"
	"github.com/provlabs/vault/simulation"
	"github.com/provlabs/vault/types"
	"github.com/provlabs/vault/utils"
)

// TestKeeperTestSuite is handled in suite_test.go

func (s *TestSuite) TestCreateVault_Success() {
	share := "vaultshare"
	base := "undercoin"
	s.requireAddFinalizeAndActivateMarker(sdk.NewInt64Coin(base, 1_000_000), s.adminAddr)

	attrs := vaultAttrs{
		admin:      s.adminAddr.String(),
		share:      share,
		underlying: base,
	}

	vault, err := s.k.CreateVault(s.ctx, attrs)
	s.Require().NoError(err, "CreateVault should succeed for valid attributes")
	s.Require().Equal(attrs.admin, vault.Admin, "vault admin should match request")
	s.Require().Equal(attrs.share, vault.TotalShares.Denom, "vault share denom should match request")
	s.Require().Equal(attrs.underlying, vault.UnderlyingAsset, "vault underlying asset should match request")

	addr := types.GetVaultAddress(share)
	stored, err := s.k.GetVault(s.ctx, addr)
	s.Require().NoError(err, "GetVault should succeed for existing vault")
	s.Require().Equal(vault.Address, stored.Address, "stored vault address should match created vault address")
}

func (s *TestSuite) TestCreateVault_ShareMarkerDepositProtection() {
	share := "vaultshare"
	base := "undercoin"
	vault := s.setupBaseVault(base, share)

	marker, err := s.simApp.MarkerKeeper.GetMarkerByDenom(s.ctx, share)
	s.Require().NoError(err, "share marker should exist after vault creation")
	s.True(marker.RequiresDepositAccess(), "share marker must require deposit access so arbitrary denoms cannot be sent into it")

	cases := []struct {
		name   string
		access markertypes.Access
	}{
		{name: "deposit access granted to the vault", access: markertypes.Access_Deposit},
		{name: "mint access preserved", access: markertypes.Access_Mint},
		{name: "burn access preserved", access: markertypes.Access_Burn},
		{name: "withdraw access preserved", access: markertypes.Access_Withdraw},
	}
	for _, tc := range cases {
		s.Run(tc.name, func() {
			s.True(marker.AddressHasAccess(vault.GetAddress(), tc.access), "vault address must hold %s on share marker %s", tc.access, share)
		})
	}
}

func (s *TestSuite) TestVaultShareMarker_RejectsUnauthorizedDeposits() {
	share := "vaultshare"
	base := "undercoin"
	s.setupBaseVault(base, share)

	stranger := s.CreateAndFundAccount(sdk.NewInt64Coin(base, 500))
	shareMarkerAddr := markertypes.MustGetMarkerAddress(share)

	err := s.simApp.BankKeeper.SendCoins(s.ctx, stranger, shareMarkerAddr, sdk.NewCoins(sdk.NewInt64Coin(base, 100)))
	s.Require().Error(err, "a third-party send of an unrestricted denom into a protected share marker must be rejected")
	s.Require().ErrorContains(err, "does not have ACCESS_DEPOSIT", "rejection should cite the missing deposit access on the share marker")
}

func (s *TestSuite) TestCreateVault_AssetMarkerMissing() {
	share := "vaultshare"
	base := "missingasset"

	attrs := vaultAttrs{
		admin:      s.adminAddr.String(),
		share:      share,
		underlying: base,
	}

	_, err := s.k.CreateVault(s.ctx, attrs)
	s.Require().ErrorContains(err, "underlying asset marker")
}

func (s *TestSuite) TestCreateVault_IBCUnderlyingFails() {
	attrs := vaultAttrs{
		admin:      s.adminAddr.String(),
		share:      "vaultshare",
		underlying: "ibc/27394FB092D2ECCD56123C74F36E4C1F926001CEADA9CA97EA622B25F41E5EB2",
	}

	_, err := s.k.CreateVault(s.ctx, attrs)
	s.Require().Error(err, "CreateVault should fail for an IBC underlying asset")
	s.Require().ErrorContains(err, "cannot be used by a vault", "error message should mention the IBC denom ban")
}

func (s *TestSuite) TestCreateVault_DuplicateMarkerFails() {
	denom := "dupecoin"
	base := "basecoin"

	s.requireAddFinalizeAndActivateMarker(sdk.NewInt64Coin(base, 1000), s.adminAddr)
	s.requireAddFinalizeAndActivateMarker(sdk.NewInt64Coin(denom, 1), s.adminAddr)

	attrs := vaultAttrs{
		admin:      s.adminAddr.String(),
		share:      denom,
		underlying: base,
	}

	_, err := s.k.CreateVault(s.ctx, attrs)
	s.Require().Error(err, "CreateVault should fail for duplicate marker")
	s.Require().ErrorContains(err, "already exists", "error message should mention duplicate marker")
}

func (s *TestSuite) TestCreateVault_InvalidDenomFails() {
	attrs := vaultAttrs{
		admin:      s.adminAddr.String(),
		share:      "!!bad!!",
		underlying: "under",
	}
	s.requireAddFinalizeAndActivateMarker(sdk.NewInt64Coin(attrs.underlying, 1000), s.adminAddr)

	_, err := s.k.CreateVault(s.ctx, attrs)
	s.Require().Error(err, "CreateVault should fail for invalid share denom")
	s.Require().ErrorContains(err, "invalid denom", "error message should mention invalid denom")
}

func (s *TestSuite) TestCreateVault_InvalidAdminFails() {
	share := "vaultx"
	base := "basecoin"
	s.requireAddFinalizeAndActivateMarker(sdk.NewInt64Coin(base, 500), s.adminAddr)

	attrs := vaultAttrs{
		admin:      "not-a-valid-bech32",
		share:      share,
		underlying: base,
	}

	_, err := s.k.CreateVault(s.ctx, attrs)
	s.Require().Error(err, "CreateVault should fail for invalid admin address")
	s.Require().ErrorContains(err, "invalid admin address", "error message should mention invalid admin address")
}

func (s *TestSuite) TestCreateVault_DefaultsPaymentDenomToUnderlying() {
	underlying := "ulying"

	s.requireAddFinalizeAndActivateMarker(sdk.NewInt64Coin(underlying, 1_000_000), s.adminAddr)

	vault, err := s.k.CreateVault(s.ctx, vaultAttrs{
		admin:      s.adminAddr.String(),
		share:      "vshare.single",
		underlying: underlying,
	})
	s.Require().NoError(err, "CreateVault should succeed for a single-denom vault")
	s.Require().Equal(underlying, vault.PaymentDenom, "deprecated payment denom state field should default to the underlying asset")
	_, navErr := s.k.GetVaultNAV(s.ctx, vault.GetAddress(), underlying)
	s.Require().Error(navErr, "no internal NAV entry should be seeded at creation")
}

func (s *TestSuite) TestSwapIn_SingleDenomEnforcement() {
	underlyingDenom := "ylds"
	unacceptedDenom := "usdc"
	shareDenom := "vshare"
	vault := s.setupBaseVault(underlyingDenom, shareDenom)
	vault.SwapInEnabled = true
	s.k.AuthKeeper.SetAccount(s.ctx, vault)

	depositorAddr := s.CreateAndFundAccount(sdk.NewInt64Coin(underlyingDenom, 1000))
	s.Require().NoError(FundAccount(s.ctx, s.simApp, depositorAddr, sdk.NewCoins(sdk.NewInt64Coin(unacceptedDenom, 1000))), "should fund depositor with a non-underlying denom")

	totalShares := sdk.NewCoin(shareDenom, utils.ShareScalar.MulRaw(1000))
	s.Require().NoError(s.sendCoinsBypass(markertypes.WithBypass(s.ctx), s.adminAddr, vault.PrincipalMarkerAddress(), sdk.NewCoins(sdk.NewInt64Coin(underlyingDenom, 1000))), "should fund vault principal with initial TVV")
	s.Require().NoError(s.k.MarkerKeeper.MintCoin(s.ctx, vault.GetAddress(), totalShares), "should mint initial share supply")
	vault.TotalShares = totalShares
	s.k.AuthKeeper.SetAccount(s.ctx, vault)

	depositCoin := sdk.NewInt64Coin(underlyingDenom, 10)
	mintedShares, err := s.k.SwapIn(s.ctx, vault.GetAddress(), depositorAddr, depositCoin)
	s.Require().NoError(err, "should successfully swap in the underlying asset")

	expectedShares := utils.ShareScalar.MulRaw(10)
	s.Require().Equal(expectedShares, mintedShares.Amount, "minted shares should be proportional to the underlying deposit at the current share price")
	s.assertBalance(depositorAddr, shareDenom, expectedShares)
	s.assertBalance(vault.PrincipalMarkerAddress(), underlyingDenom, math.NewInt(1_010))

	unacceptedCoin := sdk.NewInt64Coin(unacceptedDenom, 50)
	_, err = s.k.SwapIn(s.ctx, vault.GetAddress(), depositorAddr, unacceptedCoin)
	s.Require().Error(err, "should reject a swap in of a non-underlying denom under single-denom enforcement")
	s.Require().ErrorContains(err, "denom not supported for vault", "error should indicate the denom is not accepted")
}

func (s *TestSuite) TestSwapIn_Failures() {
	underlyingDenom := "ylds"
	shareDenom := "vshare"
	vault := s.setupBaseVault(underlyingDenom, shareDenom)
	depositorAddr := s.CreateAndFundAccount(sdk.NewInt64Coin(underlyingDenom, 100))

	vault.SwapInEnabled = false
	s.k.AuthKeeper.SetAccount(s.ctx, vault)
	_, err := s.k.SwapIn(s.ctx, vault.GetAddress(), depositorAddr, sdk.NewInt64Coin(underlyingDenom, 10))
	s.Require().Error(err, "swap in should fail when disabled")
	s.Require().ErrorContains(err, "swaps are not enabled", "error should mention swaps are disabled")

	vault.SwapInEnabled = true
	s.k.AuthKeeper.SetAccount(s.ctx, vault)
	_, err = s.k.SwapIn(s.ctx, vault.GetAddress(), depositorAddr, sdk.NewInt64Coin(underlyingDenom, 101))
	s.Require().Error(err, "swap in should fail with insufficient funds")
	s.Require().ErrorContains(err, "insufficient funds", "error should mention insufficient funds")
}

func (s *TestSuite) TestSwapIn_ZeroShareDeposit() {
	tests := []struct {
		name                string
		totalShares         math.Int
		principalBacking    int64
		deposit             int64
		expectedShares      math.Int
		expectedErrContains string
	}{
		{
			name:                "deposit floors to zero shares, should be rejected with no funds moved",
			totalShares:         math.OneInt(),
			principalBacking:    1_500_000,
			deposit:             1,
			expectedErrContains: "too small to mint shares",
		},
		{
			name:             "deposit just above the zero-share boundary, should mint a share",
			totalShares:      math.OneInt(),
			principalBacking: 1_500_000,
			deposit:          2,
			expectedShares:   math.OneInt(),
		},
	}

	for i, tc := range tests {
		s.Run(tc.name, func() {
			underlyingDenom := fmt.Sprintf("ylds%d", i)
			shareDenom := fmt.Sprintf("vshare%d", i)
			depositorFunding := math.NewInt(100)

			vault := s.setupBaseVault(underlyingDenom, shareDenom)
			vault.SwapInEnabled = true
			vault.TotalShares = sdk.NewCoin(shareDenom, tc.totalShares)
			s.k.AuthKeeper.SetAccount(s.ctx, vault)

			s.Require().NoError(s.k.MarkerKeeper.MintCoin(s.ctx, vault.GetAddress(), sdk.NewCoin(shareDenom, tc.totalShares)),
				"should mint initial share supply %s%s", tc.totalShares, shareDenom)
			s.Require().NoError(s.withdrawMarkerCoins(s.ctx, s.adminAddr, s.adminAddr, underlyingDenom, sdk.NewCoins(sdk.NewInt64Coin(underlyingDenom, tc.principalBacking))),
				"should withdraw %d%s of backing to the admin", tc.principalBacking, underlyingDenom)
			s.Require().NoError(s.sendCoinsBypass(markertypes.WithBypass(s.ctx), s.adminAddr, vault.PrincipalMarkerAddress(), sdk.NewCoins(sdk.NewInt64Coin(underlyingDenom, tc.principalBacking))),
				"should fund vault principal with %d%s of backing", tc.principalBacking, underlyingDenom)

			depositorAddr := s.CreateAndFundAccount(sdk.NewCoin(underlyingDenom, depositorFunding))
			depositCoin := sdk.NewInt64Coin(underlyingDenom, tc.deposit)

			mintedShares, err := s.k.SwapIn(s.ctx, vault.GetAddress(), depositorAddr, depositCoin)

			if tc.expectedErrContains != "" {
				s.Require().Error(err, "swap in of %s should be rejected when it converts to zero shares", depositCoin)
				s.Require().ErrorContains(err, tc.expectedErrContains, "swap in rejection should explain the deposit is too small for vault %s", vault.GetAddress())
				s.assertBalance(depositorAddr, underlyingDenom, depositorFunding)
				s.assertBalance(depositorAddr, shareDenom, math.ZeroInt())
				s.assertBalance(vault.PrincipalMarkerAddress(), underlyingDenom, math.NewInt(tc.principalBacking))

				updatedVault, getErr := s.k.GetVault(s.ctx, vault.GetAddress())
				s.Require().NoError(getErr, "should get vault %s after rejected swap in", vault.GetAddress())
				s.Assert().Equal(tc.totalShares.String(), updatedVault.TotalShares.Amount.String(), "vault total shares must be unchanged after rejected swap in for vault %s", vault.GetAddress())
				return
			}

			s.Require().NoError(err, "swap in of %s should succeed when it converts to at least one share", depositCoin)
			s.Require().Equal(tc.expectedShares.String(), mintedShares.Amount.String(), "minted share amount mismatch for deposit %s", depositCoin)
			s.assertBalance(depositorAddr, underlyingDenom, depositorFunding.SubRaw(tc.deposit))
			s.assertBalance(depositorAddr, shareDenom, tc.expectedShares)
			s.assertBalance(vault.PrincipalMarkerAddress(), underlyingDenom, math.NewInt(tc.principalBacking+tc.deposit))

			updatedVault, getErr := s.k.GetVault(s.ctx, vault.GetAddress())
			s.Require().NoError(getErr, "should get vault %s after successful swap in", vault.GetAddress())
			s.Assert().Equal(tc.totalShares.Add(tc.expectedShares).String(), updatedVault.TotalShares.Amount.String(), "vault total shares should grow by the minted amount for vault %s", vault.GetAddress())
		})
	}
}

func (s *TestSuite) TestSwapIn_ZeroNetTVVWithSharesOutstanding() {
	tests := []struct {
		name            string
		grossUnderlying int64
		outstandingFee  int64
	}{
		{
			name:            "fee sweep drained the principal, leaving no gross value behind the outstanding shares",
			grossUnderlying: 0,
			outstandingFee:  0,
		},
		{
			name:            "uncollectable fee liability consumed the gross value the principal still holds",
			grossUnderlying: 1_000_000,
			outstandingFee:  1_000_000,
		},
	}

	for i, tc := range tests {
		s.Run(tc.name, func() {
			underlyingDenom := fmt.Sprintf("zeronet%d", i)
			shareDenom := fmt.Sprintf("zeronetshare%d", i)
			depositorFunding := math.NewInt(1_000_000)

			vault := s.setupZeroNetTVVVault(underlyingDenom, shareDenom, tc.grossUnderlying, tc.outstandingFee)
			depositor := s.CreateAndFundAccount(sdk.NewCoin(underlyingDenom, depositorFunding))
			deposit := sdk.NewCoin(underlyingDenom, depositorFunding)

			_, err := s.k.SwapIn(s.ctx, vault.GetAddress(), depositor, deposit)
			s.Require().Error(err, "swap in of %s should be rejected while net TVV is zero with %s outstanding", deposit, vault.TotalShares)
			s.Require().ErrorIs(err, utils.ErrZeroAssetsWithSharesOutstanding, "rejection should be classifiable as the zero-net-value guard for vault %s", vault.GetAddress())
			s.Require().ErrorContains(err, "cannot accept deposits", "rejection should read as a deposit policy rejection for vault %s", vault.GetAddress())

			s.assertBalance(depositor, underlyingDenom, depositorFunding)
			s.assertBalance(depositor, shareDenom, math.ZeroInt())

			updatedVault, getErr := s.k.GetVault(s.ctx, vault.GetAddress())
			s.Require().NoError(getErr, "should get vault %s after rejected swap in", vault.GetAddress())
			s.Require().Equal(vault.TotalShares.Amount.String(), updatedVault.TotalShares.Amount.String(), "vault total shares must be unchanged after rejected swap in for vault %s", vault.GetAddress())

			_, estimateErr := keeper.NewQueryServer(s.simApp.VaultKeeper).EstimateSwapIn(s.ctx, &types.QueryEstimateSwapInRequest{
				VaultAddress: vault.GetAddress().String(),
				Assets:       deposit,
			})
			s.Require().Error(estimateErr, "the estimate must agree with the transaction and reject the same deposit %s", deposit)
			s.Require().ErrorContains(estimateErr, "cannot accept deposits", "estimate rejection should match the transaction's reason for vault %s", vault.GetAddress())
		})
	}
}

func (s *TestSuite) TestCheckDepositDenyList() {
	frozenDenom := "frozencoin"
	otherFrozenDenom := "otherfrozencoin"
	unrestrictedDenom := "plaincoin"

	s.requireRestrictedMarker(frozenDenom)
	s.requireRestrictedMarker(otherFrozenDenom)
	s.requireAddFinalizeAndActivateMarker(sdk.NewInt64Coin(unrestrictedDenom, 1_000_000), s.adminAddr)

	depositorAddr := s.CreateAndFundAccount(sdk.NewInt64Coin("stake", 1))
	unrelatedHolderAddr := s.CreateAndFundAccount(sdk.NewInt64Coin("stake", 1))
	s.requireSendDeny(frozenDenom, depositorAddr)
	s.requireSendDeny(otherFrozenDenom, unrelatedHolderAddr)

	tests := []struct {
		name                string
		denom               string
		expectedErrContains string
	}{
		{
			name:                "depositor is on the deny list of the deposited denom",
			denom:               frozenDenom,
			expectedErrContains: "is on deny list for sending restricted marker",
		},
		{
			name:  "only another holder is on the deny list of the deposited denom",
			denom: otherFrozenDenom,
		},
		{
			name:  "deposited denom is an unrestricted marker with no deny list",
			denom: unrestrictedDenom,
		},
		{
			name:  "deposited denom has no marker at all",
			denom: "nomarkercoin",
		},
		{
			name:                "deposited denom is not a valid denom",
			denom:               "!!bad!!",
			expectedErrContains: "failed to get marker address for !!bad!!",
		},
	}

	for _, tc := range tests {
		s.Run(tc.name, func() {
			err := s.k.TestAccessor_checkDepositDenyList(s.T(), s.ctx, depositorAddr, tc.denom)

			if tc.expectedErrContains == "" {
				s.Require().NoError(err, "deposit of %s by %s should pass the deny list check", tc.denom, depositorAddr)
				return
			}
			s.Require().Error(err, "deposit of %s by %s should fail the deny list check", tc.denom, depositorAddr)
			s.Require().ErrorContains(err, tc.expectedErrContains, "deny list rejection for denom %s should explain why the depositor is blocked", tc.denom)
		})
	}
}

func (s *TestSuite) TestSwapIn_DenyListedDepositor() {
	tests := []struct {
		name                string
		denyDepositor       bool
		expectedErrContains string
	}{
		{
			name:                "depositor is frozen on the underlying deny list, swap in is rejected",
			denyDepositor:       true,
			expectedErrContains: "is on deny list for sending restricted marker",
		},
		{
			name:          "depositor is not on the underlying deny list, swap in is accepted",
			denyDepositor: false,
		},
	}

	for i, tc := range tests {
		s.Run(tc.name, func() {
			underlyingDenom := fmt.Sprintf("restrictedasset%d", i)
			shareDenom := fmt.Sprintf("vshare%d", i)
			depositorFunding := int64(1_000)
			deposit := sdk.NewInt64Coin(underlyingDenom, 100)

			vault := s.setupBaseVaultRestricted(underlyingDenom, shareDenom)
			vault.SwapInEnabled = true
			s.k.AuthKeeper.SetAccount(s.ctx, vault)

			depositorAddr := s.CreateAndFundAccount(sdk.NewInt64Coin("stake", 1))
			s.requireAttribute(depositorAddr, simulation.RequiredMarkerAttribute)
			s.Require().NoError(s.k.MarkerKeeper.WithdrawCoins(s.ctx, s.adminAddr, depositorAddr, underlyingDenom, sdk.NewCoins(sdk.NewInt64Coin(underlyingDenom, depositorFunding))),
				"should seed depositor %s with the restricted underlying %s while it is still an eligible holder", depositorAddr, underlyingDenom)

			if tc.denyDepositor {
				s.requireSendDeny(underlyingDenom, depositorAddr)
			}

			mintedShares, err := s.k.SwapIn(s.ctx, vault.GetAddress(), depositorAddr, deposit)

			if tc.expectedErrContains != "" {
				s.Require().Error(err, "swap in of %s must be rejected for a depositor frozen on the %s deny list", deposit, underlyingDenom)
				s.Require().ErrorContains(err, tc.expectedErrContains, "swap in rejection should name the deny list enforcement for depositor %s", depositorAddr)
				s.assertBalance(depositorAddr, underlyingDenom, math.NewInt(depositorFunding))
				s.assertBalance(depositorAddr, shareDenom, math.ZeroInt())
				s.assertBalance(vault.PrincipalMarkerAddress(), underlyingDenom, math.ZeroInt())
				return
			}

			s.Require().NoError(err, "swap in of %s should succeed for a depositor that is not on the %s deny list", deposit, underlyingDenom)
			s.Require().True(mintedShares.Amount.IsPositive(), "swap in of %s should mint shares, got %s", deposit, mintedShares)
			s.assertBalance(depositorAddr, underlyingDenom, math.NewInt(depositorFunding-deposit.Amount.Int64()))
			s.assertBalance(vault.PrincipalMarkerAddress(), underlyingDenom, deposit.Amount)
		})
	}
}

func (s *TestSuite) TestSwapOut_RedeemsInUnderlying() {
	underlyingDenom := "ylds"
	shareDenom := "vshare"
	blockTime := time.Now().UTC()
	s.ctx = s.ctx.WithBlockTime(blockTime)

	initialShares := utils.ShareScalar.MulRaw(100)
	vault := s.setupBaseVault(underlyingDenom, shareDenom)
	vault.SwapOutEnabled = true
	vault.WithdrawalDelaySeconds = 0
	vault.TotalShares = sdk.NewCoin(shareDenom, initialShares)
	s.k.AuthKeeper.SetAccount(s.ctx, vault)
	redeemerAddr := s.CreateAndFundAccount(sdk.NewCoin(shareDenom, initialShares))

	s.Require().NoError(s.sendCoinsBypass(markertypes.WithBypass(s.ctx), s.adminAddr, vault.PrincipalMarkerAddress(), sdk.NewCoins(
		sdk.NewInt64Coin(underlyingDenom, 600),
	)), "should fund vault principal with liquidity")

	vault, err := s.k.GetVault(s.ctx, vault.GetAddress())
	s.Require().NoError(err, "should get vault")
	s.Require().NotNil(vault, "vault should not be nil")
	s.Require().NoError(s.k.MarkerKeeper.MintCoin(s.ctx, vault.GetAddress(), sdk.NewCoin(shareDenom, utils.ShareScalar.MulRaw(500))), "should mint additional share supply")
	vault.TotalShares = vault.TotalShares.Add(sdk.NewCoin(shareDenom, utils.ShareScalar.MulRaw(500)))
	s.k.AuthKeeper.SetAccount(s.ctx, vault)

	sharesToRedeemFirst := sdk.NewCoin(shareDenom, utils.ShareScalar.MulRaw(10))
	reqID1, err := s.k.SwapOut(s.ctx, vault.GetAddress(), redeemerAddr, sharesToRedeemFirst)
	s.Require().NoError(err, "should successfully queue the first swap out")
	s.Require().Equal(uint64(0), reqID1, "first request id should be 0")

	s.assertBalance(redeemerAddr, shareDenom, initialShares.Sub(sharesToRedeemFirst.Amount))
	s.assertBalance(vault.GetAddress(), shareDenom, sharesToRedeemFirst.Amount)

	sharesToRedeemSecond := sdk.NewCoin(shareDenom, utils.ShareScalar.MulRaw(5))
	reqID2, err := s.k.SwapOut(s.ctx, vault.GetAddress(), redeemerAddr, sharesToRedeemSecond)
	s.Require().NoError(err, "should successfully queue the second swap out")
	s.Require().Equal(uint64(1), reqID2, "second request id should be 1")

	err = s.k.TestAccessor_processPendingSwapOuts(s.T(), s.ctx, keeper.MaxSwapOutBatchSize)
	s.Require().NoError(err, "processing pending withdrawals should not fail")

	s.assertBalance(redeemerAddr, underlyingDenom, math.NewInt(15))
}

func (s *TestSuite) TestSwapOut_FailsWhenDisabled() {
	underlyingDenom := "ylds"
	shareDenom := "vshare"
	vault := s.setupBaseVault(underlyingDenom, shareDenom)
	redeemerAddr := s.CreateAndFundAccount(sdk.NewCoin(shareDenom, math.NewInt(100)))

	vault.SwapOutEnabled = false
	s.k.AuthKeeper.SetAccount(s.ctx, vault)

	_, err := s.k.SwapOut(s.ctx, vault.GetAddress(), redeemerAddr, sdk.NewInt64Coin(shareDenom, 10))
	s.Require().Error(err, "SwapOut should fail when swaps are disabled")
	s.Require().ErrorContains(err, "swaps are not enabled", "error message should mention swaps are disabled")
}

func (s *TestSuite) TestSwapOut_FailsWithInsufficientShares() {
	underlyingDenom := "ylds"
	shareDenom := "vshare"
	vault := s.setupBaseVault(underlyingDenom, shareDenom)

	initialTVV := int64(1000)
	s.Require().NoError(s.sendCoinsBypass(markertypes.WithBypass(s.ctx), s.adminAddr, vault.PrincipalMarkerAddress(), sdk.NewCoins(sdk.NewInt64Coin(underlyingDenom, initialTVV))), "should fund vault principal to give shares value")
	initialShares := utils.ShareScalar.MulRaw(initialTVV)
	s.Require().NoError(s.k.MarkerKeeper.MintCoin(s.ctx, vault.GetAddress(), sdk.NewCoin(shareDenom, initialShares)), "should mint initial share supply")

	sharesForRedeemer := utils.ShareScalar.MulRaw(100)
	redeemerAddr := s.CreateAndFundAccount(sdk.Coin{})
	s.Require().NoError(s.withdrawMarkerCoins(s.ctx, vault.GetAddress(), redeemerAddr, shareDenom, sdk.NewCoins(sdk.NewCoin(shareDenom, sharesForRedeemer))), "should fund redeemer with shares")

	vault.SwapOutEnabled = true
	s.k.AuthKeeper.SetAccount(s.ctx, vault)

	sharesToRedeem := utils.ShareScalar.MulRaw(101)
	_, err := s.k.SwapOut(s.ctx, vault.GetAddress(), redeemerAddr, sdk.NewCoin(shareDenom, sharesToRedeem))
	s.Require().Error(err, "swap out should fail with insufficient shares")
	s.Require().ErrorContains(err, "insufficient funds", "error should mention insufficient funds for shares")
}

func (s *TestSuite) TestSwapOut_FailsWhenReconcileFails() {
	underlyingDenom := "reconcilefail"
	shareDenom := "reconcilefailvault"
	vault := s.setupBaseVault(underlyingDenom, shareDenom)

	initialTVV := int64(1_000)
	s.Require().NoError(s.k.BankKeeper.SendCoins(markertypes.WithBypass(s.ctx), s.adminAddr, vault.PrincipalMarkerAddress(), sdk.NewCoins(sdk.NewInt64Coin(underlyingDenom, initialTVV))), "should fund vault principal to give shares value")
	initialShares := utils.ShareScalar.MulRaw(initialTVV)
	s.Require().NoError(s.k.MarkerKeeper.MintCoin(s.ctx, vault.GetAddress(), sdk.NewCoin(shareDenom, initialShares)), "should mint initial share supply")

	sharesForRedeemer := utils.ShareScalar.MulRaw(100)
	redeemerAddr := s.CreateAndFundAccount(sdk.Coin{})
	s.Require().NoError(s.k.MarkerKeeper.WithdrawCoins(s.ctx, vault.GetAddress(), redeemerAddr, shareDenom, sdk.NewCoins(sdk.NewCoin(shareDenom, sharesForRedeemer))), "should fund redeemer with shares")

	vault.SwapOutEnabled = true
	vault.CurrentInterestRate = "unparseable"
	vault.PeriodStart = s.ctx.BlockTime().Unix() - 3600
	s.k.AuthKeeper.SetAccount(s.ctx, vault)

	sharesToRedeem := sdk.NewCoin(shareDenom, utils.ShareScalar.MulRaw(10))
	_, err := s.k.SwapOut(s.ctx, vault.GetAddress(), redeemerAddr, sharesToRedeem)
	s.Require().Error(err, "swap out should fail when the pre-pricing reconcile fails")
	s.Require().ErrorContains(err, "failed to reconcile vault", "error should name the failed reconcile")
	s.Require().ErrorContains(err, "failed to calculate interest", "error should wrap the underlying interest calculation failure")

	s.assertBalance(redeemerAddr, shareDenom, sharesForRedeemer)
	s.assertBalance(vault.GetAddress(), shareDenom, math.ZeroInt())

	s.Require().Zero(s.countPendingSwapOuts(), "a swap out rejected by a failed reconcile should not enqueue a pending request")
}

func (s *TestSuite) TestSwapOut_LimitsGateOnPostReconcileValuation() {
	tests := []struct {
		name            string
		minSwapOutValue string
		maxSwapOutValue string
		expectedErr     string
	}{
		{
			name:            "redemption that only clears the maximum on the un-reconciled valuation is refused",
			maxSwapOutValue: "150",
			expectedErr:     "is above the maximum allowed value",
		},
		{
			name:            "redemption that only breaches the minimum on the un-reconciled valuation is admitted",
			minSwapOutValue: "150",
		},
	}

	for i, tc := range tests {
		s.Run(tc.name, func() {
			underlyingDenom := fmt.Sprintf("staleunder%d", i)
			shareDenom := fmt.Sprintf("stalevault%d", i)
			blockTime := time.Now().UTC()
			s.ctx = s.ctx.WithBlockTime(blockTime)

			vault := s.setupBaseVault(underlyingDenom, shareDenom)
			vaultAddr := vault.GetAddress()

			depositAmount := sdk.NewInt64Coin(underlyingDenom, 1_000)
			redeemer := s.CreateAndFundAccount(sdk.NewInt64Coin("stake", 1))
			s.Require().NoError(FundAccount(s.ctx, s.simApp, redeemer, sdk.NewCoins(depositAmount)),
				"funding the redeemer with %s should succeed", depositAmount)
			_, err := s.k.SwapIn(s.ctx, vaultAddr, redeemer, depositAmount)
			s.Require().NoError(err, "swap-in should seed the vault with priced shares")

			s.Require().NoError(s.k.BankKeeper.SendCoins(markertypes.WithBypass(s.ctx), s.adminAddr, vaultAddr,
				sdk.NewCoins(sdk.NewInt64Coin(underlyingDenom, 5_000))), "funding vault reserves should let a full year of interest settle")

			vault, err = s.k.GetVault(s.ctx, vaultAddr)
			s.Require().NoError(err, "GetVault should succeed after swap-in")
			vault.CurrentInterestRate = "1.0"
			vault.DesiredInterestRate = "1.0"
			vault.PeriodStart = blockTime.Unix() - interest.SecondsPerYear
			vault.MinSwapOutValue = tc.minSwapOutValue
			vault.MaxSwapOutValue = tc.maxSwapOutValue
			s.k.AuthKeeper.SetAccount(s.ctx, vault)

			redeemShares := sdk.NewCoin(shareDenom, s.simApp.BankKeeper.GetBalance(s.ctx, redeemer, shareDenom).Amount.QuoRaw(10))
			staleValue, err := s.k.ConvertSharesToRedeemCoin(s.ctx, *vault, redeemShares.Amount)
			s.Require().NoError(err, "pricing the redemption on the un-reconciled valuation should succeed")
			s.Require().Equal(int64(100), staleValue.Amount.Int64(),
				"a tenth of the share supply should price at a tenth of the un-accrued principal, on the admitted side of the 150 limit")

			_, err = s.k.SwapOut(s.ctx, vaultAddr, redeemer, redeemShares)
			if tc.expectedErr != "" {
				s.Require().Error(err, "SwapOut should refuse a redemption that breaches the limit once accrued interest is reconciled")
				s.Require().ErrorContains(err, tc.expectedErr, "error should name the breached swap-out limit")
			} else {
				s.Require().NoError(err, "SwapOut should admit a redemption that clears the limit once accrued interest is reconciled")
			}

			reconciled, err := s.k.GetVault(s.ctx, vaultAddr)
			s.Require().NoError(err, "GetVault should succeed after the swap-out attempt")
			s.Require().Equal(blockTime.Unix(), reconciled.PeriodStart, "SwapOut should reconcile the vault before pricing the redemption")

			reconciledValue, err := s.k.ConvertSharesToRedeemCoin(s.ctx, *reconciled, redeemShares.Amount)
			s.Require().NoError(err, "pricing the redemption on the reconciled valuation should succeed")
			s.Require().True(reconciledValue.Amount.GT(staleValue.Amount),
				"reconciling should lift the redemption value from %s to above the 150 limit, but it priced at %s", staleValue, reconciledValue)
		})
	}
}

// TODO: https://github.com/ProvLabs/vault/issues/49
// We will probably need to review the implementation of this if it isn't right.
// This test confirms that a SwapOut from a marker account fails if the underlying restricted asset has no required attributes
// and the vault lacks TRANSFER permission on it. This behavior is distinct from the case where the asset has required
// attributes, in which the attribute check is correctly enforced. We need to confirm if this "fail-on-no-attributes" path is
// the intended design. A proposed solution would be to add bypass but send it to the vault account, then from the vault
// account, send it to the claimer without bypass in order to apply all the send restrictions correctly.
func (s *TestSuite) TestSwapOut_FailsWithRestrictedUnderlyingAssetNoAttributes() {
	shareDenom := "vshare"
	restrictedUnderlyingDenom := "restrictedasset"

	s.SetupTechFeeAccount(restrictedUnderlyingDenom)

	restrictedMarkerAddr := markertypes.MustGetMarkerAddress(restrictedUnderlyingDenom)
	restrictedMarker := markertypes.NewMarkerAccount(
		authtypes.NewBaseAccountWithAddress(restrictedMarkerAddr),
		sdk.NewInt64Coin(restrictedUnderlyingDenom, 1_000_000),
		s.adminAddr,
		[]markertypes.AccessGrant{
			{Address: s.adminAddr.String(), Permissions: markertypes.AccessList{markertypes.Access_Mint, markertypes.Access_Admin, markertypes.Access_Withdraw, markertypes.Access_Burn, markertypes.Access_Transfer}},
			{Address: s.EnsureTechFeeAccount().String(), Permissions: markertypes.AccessList{markertypes.Access_Transfer, markertypes.Access_Deposit}},
			{Address: types.GetVaultAddress(shareDenom).String(), Permissions: markertypes.AccessList{markertypes.Access_Withdraw, markertypes.Access_Transfer}},
		},
		markertypes.StatusProposed,
		markertypes.MarkerType_RestrictedCoin,
		false, true, false, []string{},
	)
	s.Require().NoError(s.simApp.MarkerKeeper.AddFinalizeAndActivateMarker(s.ctx, restrictedMarker), "should successfully create the restricted underlying asset marker")

	vaultCfg := vaultAttrs{
		admin:      s.adminAddr.String(),
		share:      shareDenom,
		underlying: restrictedUnderlyingDenom,
	}
	vault, err := s.k.CreateVault(s.ctx, vaultCfg)
	s.Require().NoError(err, "vault creation with restricted underlying should succeed when vault has transfer permission")
	vault.SwapOutEnabled = true
	s.k.AuthKeeper.SetAccount(s.ctx, vault)

	marker, err := s.simApp.MarkerKeeper.GetMarker(s.ctx, restrictedMarkerAddr)
	s.Require().NoError(err, "should fetch active marker")
	activeMarker := marker.(*markertypes.MarkerAccount)

	// Remove the vault's transfer permission to exercise the fail-on-no-attributes path.
	activeMarker.AccessControl = []markertypes.AccessGrant{
		{Address: s.adminAddr.String(), Permissions: markertypes.AccessList{markertypes.Access_Mint, markertypes.Access_Admin, markertypes.Access_Withdraw, markertypes.Access_Burn, markertypes.Access_Transfer}},
		{Address: s.EnsureTechFeeAccount().String(), Permissions: markertypes.AccessList{markertypes.Access_Transfer, markertypes.Access_Deposit}},
		{Address: types.GetVaultAddress(shareDenom).String(), Permissions: markertypes.AccessList{markertypes.Access_Withdraw}},
	}
	s.simApp.MarkerKeeper.SetMarker(s.ctx, activeMarker)

	initialTVV := int64(500)
	s.fundPrincipal(vault, sdk.NewInt64Coin(restrictedUnderlyingDenom, initialTVV))
	initialShares := utils.ShareScalar.MulRaw(initialTVV)
	s.Require().NoError(s.k.MarkerKeeper.MintCoin(s.ctx, vault.GetAddress(), sdk.NewCoin(shareDenom, initialShares)), "should mint initial share supply")

	redeemerAddr := s.CreateAndFundAccount(sdk.Coin{})
	sharesForRedeemer := utils.ShareScalar.MulRaw(100)
	s.Require().NoError(s.withdrawMarkerCoins(s.ctx, vault.GetAddress(), redeemerAddr, shareDenom, sdk.NewCoins(sdk.NewCoin(shareDenom, sharesForRedeemer))), "should fund redeemer from the vault's existing shares")

	sharesToRedeem := sdk.NewCoin(shareDenom, utils.ShareScalar.MulRaw(50))
	_, err = s.k.SwapOut(s.ctx, vault.GetAddress(), redeemerAddr, sharesToRedeem)

	s.Require().Error(err, "swap-out should fail because the vault lacks transfer permission and the asset is restricted (even with no attributes)")
	s.Require().ErrorContains(err, "does not have transfer permissions", "error should indicate missing transfer permissions")
}

func (s *TestSuite) TestSwapOut_FailsWithRestrictedUnderlyingAssetRequiredAttributes() {
	shareDenom := "vshare"
	restrictedUnderlyingDenom := "restrictedasset"

	requiredAttr := "you.dont.have.me"
	s.SetupTechFeeAccount(requiredAttr)

	restrictedMarkerAddr := markertypes.MustGetMarkerAddress(restrictedUnderlyingDenom)
	restrictedMarker := markertypes.NewMarkerAccount(
		authtypes.NewBaseAccountWithAddress(restrictedMarkerAddr),
		sdk.NewInt64Coin(restrictedUnderlyingDenom, 1_000_000),
		s.adminAddr,
		[]markertypes.AccessGrant{
			{Address: s.adminAddr.String(), Permissions: markertypes.AccessList{markertypes.Access_Mint, markertypes.Access_Admin, markertypes.Access_Withdraw, markertypes.Access_Burn, markertypes.Access_Transfer}},
			{Address: s.EnsureTechFeeAccount().String(), Permissions: markertypes.AccessList{markertypes.Access_Transfer, markertypes.Access_Deposit}},
			{Address: types.GetVaultAddress(shareDenom).String(), Permissions: markertypes.AccessList{markertypes.Access_Withdraw}},
		},
		markertypes.StatusProposed,
		markertypes.MarkerType_RestrictedCoin,
		false, true, false, []string{"you.dont.have.me"},
	)
	s.Require().NoError(s.simApp.MarkerKeeper.AddFinalizeAndActivateMarker(s.ctx, restrictedMarker), "should successfully create the restricted underlying asset marker")

	vaultCfg := vaultAttrs{
		admin:      s.adminAddr.String(),
		share:      shareDenom,
		underlying: restrictedUnderlyingDenom,
	}
	vault, err := s.k.CreateVault(s.ctx, vaultCfg)
	s.Require().NoError(err, "vault creation with restricted underlying should succeed")
	vault.SwapOutEnabled = true
	s.k.AuthKeeper.SetAccount(s.ctx, vault)

	initialTVV := int64(500)
	s.fundPrincipal(vault, sdk.NewInt64Coin(restrictedUnderlyingDenom, initialTVV))
	initialShares := utils.ShareScalar.MulRaw(initialTVV)
	s.Require().NoError(s.k.MarkerKeeper.MintCoin(s.ctx, vault.GetAddress(), sdk.NewCoin(shareDenom, initialShares)), "should mint initial share supply")

	sharesForRedeemer := utils.ShareScalar.MulRaw(100)
	redeemerAddr := s.CreateAndFundAccount(sdk.NewCoin(shareDenom, sharesForRedeemer))

	sharesToRedeem := sdk.NewCoin(shareDenom, utils.ShareScalar.MulRaw(50))
	_, err = s.k.SwapOut(s.ctx, vault.GetAddress(), redeemerAddr, sharesToRedeem)

	s.Require().Error(err, "swap-out should fail because the redeemer is missing a required attribute")
	s.Require().ErrorContains(err, "required attribute: \"you.dont.have.me\"", "error should indicate a missing attribute failure")
}

func (s *TestSuite) TestSwapOut_SucceedsWithRestrictedUnderlyingAssetRequiredAttributes() {
	shareDenom := "vshare"
	restrictedUnderlyingDenom := "restrictedasset"
	requiredAttribute := "iamrequired"

	s.SetupTechFeeAccount(requiredAttribute)

	s.ctx = s.ctx.WithBlockTime(time.Now().UTC())

	restrictedMarkerAddr := markertypes.MustGetMarkerAddress(restrictedUnderlyingDenom)
	restrictedMarker := markertypes.NewMarkerAccount(
		authtypes.NewBaseAccountWithAddress(restrictedMarkerAddr),
		sdk.NewInt64Coin(restrictedUnderlyingDenom, 1_000_000),
		s.adminAddr,
		[]markertypes.AccessGrant{
			{Address: s.adminAddr.String(), Permissions: markertypes.AccessList{markertypes.Access_Mint, markertypes.Access_Admin, markertypes.Access_Withdraw, markertypes.Access_Burn, markertypes.Access_Transfer}},
			{Address: s.EnsureTechFeeAccount().String(), Permissions: markertypes.AccessList{markertypes.Access_Transfer, markertypes.Access_Deposit}},
			{Address: types.GetVaultAddress(shareDenom).String(), Permissions: markertypes.AccessList{markertypes.Access_Withdraw}},
		},
		markertypes.StatusProposed,
		markertypes.MarkerType_RestrictedCoin,
		false, true, false, []string{requiredAttribute},
	)
	s.Require().NoError(s.simApp.MarkerKeeper.AddFinalizeAndActivateMarker(s.ctx, restrictedMarker), "should successfully create the restricted underlying asset marker")

	vaultCfg := vaultAttrs{
		admin:      s.adminAddr.String(),
		share:      shareDenom,
		underlying: restrictedUnderlyingDenom,
	}
	vault, err := s.k.CreateVault(s.ctx, vaultCfg)
	s.Require().NoError(err, "vault creation with restricted underlying should succeed")
	vault.SwapOutEnabled = true
	vault.WithdrawalDelaySeconds = 0
	s.k.AuthKeeper.SetAccount(s.ctx, vault)

	initialTVV := int64(500)
	s.fundPrincipal(vault, sdk.NewInt64Coin(restrictedUnderlyingDenom, initialTVV))
	initialShares := utils.ShareScalar.MulRaw(initialTVV)
	s.Require().NoError(s.k.MarkerKeeper.MintCoin(s.ctx, vault.GetAddress(), sdk.NewCoin(shareDenom, initialShares)), "should mint initial share supply")
	vault, err = s.k.GetVault(s.ctx, vault.GetAddress())
	s.Require().NoError(err, "should get vault")
	s.Require().NotNil(vault, "vault should not be nil")
	vault.TotalShares = sdk.NewCoin(shareDenom, initialShares)
	s.k.AuthKeeper.SetAccount(s.ctx, vault)

	redeemerAddr := s.CreateAndFundAccount(sdk.Coin{})
	sharesForRedeemer := utils.ShareScalar.MulRaw(100)
	s.Require().NoError(s.withdrawMarkerCoins(s.ctx, vault.GetAddress(), redeemerAddr, shareDenom, sdk.NewCoins(sdk.NewCoin(shareDenom, sharesForRedeemer))), "should fund redeemer from the vault's existing shares")

	s.simApp.AccountKeeper.SetAccount(s.ctx, s.simApp.AccountKeeper.NewAccountWithAddress(s.ctx, s.adminAddr))

	s.requireAttribute(redeemerAddr, requiredAttribute)

	sharesToRedeem := sdk.NewCoin(shareDenom, utils.ShareScalar.MulRaw(50))
	_, err = s.k.SwapOut(s.ctx, vault.GetAddress(), redeemerAddr, sharesToRedeem)
	s.Require().NoError(err, "swap-out request should succeed because the redeemer has the required attribute")

	s.assertBalance(redeemerAddr, shareDenom, sharesForRedeemer.Sub(sharesToRedeem.Amount))
	s.assertBalance(vault.GetAddress(), shareDenom, sharesToRedeem.Amount)
	err = s.k.TestAccessor_processPendingSwapOuts(s.T(), s.ctx, keeper.MaxSwapOutBatchSize)
	s.Require().NoError(err, "processing pending withdrawals should not fail")

	s.assertBalance(redeemerAddr, restrictedUnderlyingDenom, math.NewInt(50))
}

func (s *TestSuite) TestSetMinMaxInterestRate_NoOp_NoEvent() {
	share := "vaultshare-np"
	base := "undercoin-np"
	s.requireAddFinalizeAndActivateMarker(sdk.NewInt64Coin(base, 1_000), s.adminAddr)

	attrs := vaultAttrs{admin: s.adminAddr.String(), share: share, underlying: base}
	v, err := s.k.CreateVault(s.ctx, attrs)
	s.Require().NoError(err, "vault creation should succeed")

	s.Require().NoError(s.k.UpdateInterestRates(s.ctx, v, "0.10", "0.10"), "should set initial min/max rates without error")
	s.k.AuthKeeper.SetAccount(s.ctx, v)

	s.ctx = s.ctx.WithEventManager(sdk.NewEventManager())
	err = s.k.SetMinInterestRate(s.ctx, v, "0.10")
	s.Require().NoError(err, "setting min interest rate should not error")

	s.ctx = s.ctx.WithEventManager(sdk.NewEventManager())
	err = s.k.SetMinInterestRate(s.ctx, v, "0.10")
	s.Require().NoError(err, "setting min interest rate should not error")
	s.Require().Len(s.ctx.EventManager().Events(), 0, "no events should be emitted when setting the same min interest rate")

	s.ctx = s.ctx.WithEventManager(sdk.NewEventManager())
	err = s.k.SetMaxInterestRate(s.ctx, v, "0.25")
	s.Require().NoError(err, "setting max interest rate should not error")

	s.ctx = s.ctx.WithEventManager(sdk.NewEventManager())
	err = s.k.SetMaxInterestRate(s.ctx, v, "0.25")
	s.Require().NoError(err, "setting max interest rate should not error")
	s.Require().Len(s.ctx.EventManager().Events(), 0, "no events should be emitted when setting the same max interest rate")
}

func (s *TestSuite) TestSetMinInterestRate_ValidationBlocksWhenAboveExistingMax() {
	share := "vaultshare-min-gt-max"
	base := "undercoin-min-gt-max"
	s.requireAddFinalizeAndActivateMarker(sdk.NewInt64Coin(base, 1_000), s.adminAddr)

	attrs := vaultAttrs{admin: s.adminAddr.String(), share: share, underlying: base}
	v, err := s.k.CreateVault(s.ctx, attrs)
	s.Require().NoError(err)

	s.Require().NoError(s.k.SetMaxInterestRate(s.ctx, v, "0.40"))

	s.ctx = s.ctx.WithEventManager(sdk.NewEventManager())
	err = s.k.SetMinInterestRate(s.ctx, v, "0.50")
	s.Require().Error(err, "setting min interest rate above max should fail")
	s.Require().Contains(err.Error(), "minimum interest rate", "error message mismatch when setting min > max")
	s.Require().Equal("0.40", v.MaxInterestRate, "max interest rate should remain unchanged")
	s.Require().Equal("", v.MinInterestRate, "min interest rate should remain unchanged")
	s.Require().Empty(s.ctx.EventManager().Events(), "no events should be emitted on validation failure")
}

func (s *TestSuite) TestSetMaxInterestRate_ValidationBlocksWhenBelowExistingMin() {
	share := "vaultshare-max-lt-min"
	base := "undercoin-max-lt-min"
	s.requireAddFinalizeAndActivateMarker(sdk.NewInt64Coin(base, 1_000), s.adminAddr)

	attrs := vaultAttrs{admin: s.adminAddr.String(), share: share, underlying: base}
	v, err := s.k.CreateVault(s.ctx, attrs)
	s.Require().NoError(err, "CreateVault should succeed")

	s.Require().NoError(s.k.SetMinInterestRate(s.ctx, v, "-0.50"), "setting min interest rate should succeed")

	s.ctx = s.ctx.WithEventManager(sdk.NewEventManager())
	err = s.k.SetMaxInterestRate(s.ctx, v, "-0.60")
	s.Require().Error(err, "setting max interest rate below min should fail")
	s.Require().Contains(err.Error(), "minimum interest rate", "error message mismatch when setting max < min")
	s.Require().Equal("-0.50", v.MinInterestRate, "min interest rate should remain unchanged")
	s.Require().Equal("", v.MaxInterestRate, "max interest rate should remain unchanged")
	s.Require().Empty(s.ctx.EventManager().Events(), "no events should be emitted on validation failure")
}

func (s *TestSuite) TestValidateInterestRateLimits() {
	tests := []struct {
		name      string
		min       string
		max       string
		expectErr string
	}{
		{
			name: "both empty => ok",
			min:  "",
			max:  "",
		},
		{
			name: "min empty => ok",
			min:  "",
			max:  "0.25",
		},
		{
			name: "max empty => ok",
			min:  "0.10",
			max:  "",
		},
		{
			name: "equal => ok",
			min:  "0.15",
			max:  "0.15",
		},
		{
			name: "min < max => ok",
			min:  "0.049",
			max:  "0.051",
		},
		{
			name:      "min > max => error",
			min:       "0.60",
			max:       "0.50",
			expectErr: "minimum interest rate",
		},
		{
			name:      "bad min => error",
			min:       "nope",
			max:       "0.10",
			expectErr: "invalid min interest rate",
		},
		{
			name:      "bad max => error",
			min:       "0.10",
			max:       "wat",
			expectErr: "invalid max interest rate",
		},
		{
			name:      "bad min, empty max => error",
			min:       "not-a-number",
			max:       "",
			expectErr: "invalid min interest rate",
		},
		{
			name:      "empty min, bad max => error",
			min:       "",
			max:       "invalid-decimal",
			expectErr: "invalid max interest rate",
		},
		{
			name:      "both bad => error",
			min:       "bad",
			max:       "worse",
			expectErr: "invalid min interest rate",
		},
		{
			name: "zero min, zero max => ok",
			min:  "0",
			max:  "0",
		},
		{
			name: "zero min, positive max => ok",
			min:  "0",
			max:  "0.25",
		},
		{
			name: "high precision => ok",
			min:  "0.123456789012345678",
			max:  "0.223456789012345678",
		},
		{
			name:      "negative min > negative max => error",
			min:       "-0.05",
			max:       "-0.10",
			expectErr: "cannot be greater than",
		},
		{
			name: "negative min < negative max => ok",
			min:  "-0.10",
			max:  "-0.05",
		},
	}

	for _, tc := range tests {
		s.Run(tc.name, func() {
			err := s.k.ValidateInterestRateLimits(tc.min, tc.max)
			if tc.expectErr == "" {
				s.Require().NoError(err)
			} else {
				s.Require().Error(err)
				s.Require().Contains(err.Error(), tc.expectErr)
			}
		})
	}
}

func (s *TestSuite) TestUpdateInterestRate_BoundsEnforced() {
	share := "vaultshare-rate"
	base := "undercoin-rate"
	s.requireAddFinalizeAndActivateMarker(sdk.NewInt64Coin(base, 1_000_000), s.adminAddr)

	attrs := vaultAttrs{admin: s.adminAddr.String(), share: share, underlying: base}
	_, err := s.k.CreateVault(s.ctx, attrs)
	s.Require().NoError(err)
	addr := types.GetVaultAddress(share)

	v, err := s.k.GetVault(s.ctx, addr)
	s.Require().NoError(err, "GetVault should succeed")

	s.Require().NoError(s.k.UpdateInterestRates(s.ctx, v, "0.10", "0.10"), "should set initial min/max rates without error")
	s.k.AuthKeeper.SetAccount(s.ctx, v)

	s.Require().NoError(s.k.SetMinInterestRate(s.ctx, v, "0.10"), "setting min interest rate should not error")
	s.Require().NoError(s.k.SetMaxInterestRate(s.ctx, v, "0.50"), "setting max interest rate should not error")

	srv := keeper.NewMsgServer(s.simApp.VaultKeeper)

	s.ctx = s.ctx.WithEventManager(sdk.NewEventManager())
	_, err = srv.UpdateInterestRate(s.ctx, &types.MsgUpdateInterestRateRequest{
		Authority:    s.adminAddr.String(),
		VaultAddress: addr.String(),
		NewRate:      "0.25",
	})
	s.Require().NoError(err, "updating interest rate to 0.25 should not error")
	v2, err := s.k.GetVault(s.ctx, addr)
	s.Require().NoError(err, "getting vault after interest rate update should not error")
	s.Require().Equal("0.25", v2.CurrentInterestRate, "current interest rate mismatch after update")
	s.Require().Equal("0.25", v2.DesiredInterestRate, "desired interest rate mismatch after update")

	s.ctx = s.ctx.WithEventManager(sdk.NewEventManager())
	_, err = srv.UpdateInterestRate(s.ctx, &types.MsgUpdateInterestRateRequest{
		Authority:    s.adminAddr.String(),
		VaultAddress: addr.String(),
		NewRate:      "0.05",
	})
	s.Require().Error(err, "updating interest rate to 0.05 (below min 0.10) should error")

	s.ctx = s.ctx.WithEventManager(sdk.NewEventManager())
	_, err = srv.UpdateInterestRate(s.ctx, &types.MsgUpdateInterestRateRequest{
		Authority:    s.adminAddr.String(),
		VaultAddress: addr.String(),
		NewRate:      "0.60",
	})
	s.Require().Error(err, "updating interest rate to 0.60 (above max 0.50) should error")
}

func (s *TestSuite) TestAutoPauseVault_SetsPausedAndEmitsEvent() {
	under := "under-ap"
	share := "share-ap"
	s.requireAddFinalizeAndActivateMarker(sdk.NewInt64Coin(under, 1_000), s.adminAddr)

	v, err := s.k.CreateVault(s.ctx, vaultAttrs{admin: s.adminAddr.String(), share: share, underlying: under})
	s.Require().NoError(err, "CreateVault should succeed")

	s.ctx = s.ctx.WithEventManager(sdk.NewEventManager())

	reason := "critical failure"
	s.k.TestAccessor_autoPauseVault(s.T(), s.ctx, v, reason)

	got, err := s.k.GetVault(s.ctx, types.GetVaultAddress(share))
	s.Require().NoError(err, "GetVault should succeed after autoPause")
	s.Require().True(got.Paused, "vault should be marked paused")
	s.Require().Equal(reason, got.PausedReason, "paused reason should match provided error")
	s.Require().Equal(types.ZeroInterestRate, got.CurrentInterestRate, "auto pause should zero the current interest rate to stop accrual, mirroring the operator pause")

	evs := s.ctx.EventManager().Events()
	s.Require().NotEmpty(evs, "an event should be emitted")

	hasInterestChange := false
	for _, e := range evs {
		if e.Type == "provlabs.vault.v1.EventVaultInterestChange" {
			hasInterestChange = true
		}
	}
	s.Require().True(hasInterestChange, "auto pause should emit an EventVaultInterestChange when zeroing the rate, mirroring the operator pause")

	last := evs[len(evs)-1]
	s.Require().Equal("provlabs.vault.v1.EventVaultPaused", last.Type, "event type should be EventVaultAutoPaused")

	hasAddr := false
	hasReason := false
	for _, a := range last.Attributes {
		if a.Key == "vault_address" && a.Value == fmt.Sprintf("\"%s\"", v.GetAddress().String()) {
			hasAddr = true
		}
		if a.Key == "reason" && a.Value == fmt.Sprintf("\"%s\"", reason) {
			hasReason = true
		}
	}
	s.Require().True(hasAddr, "event should include vault_address attribute")
	s.Require().True(hasReason, "event should include reason attribute")
}

func (s *TestSuite) TestApplyPausedState_PausedBalanceAmountIsNeverNil() {
	under := "under-aps"
	share := "share-aps"
	s.requireAddFinalizeAndActivateMarker(sdk.NewInt64Coin(under, 1_000), s.adminAddr)

	v, err := s.k.CreateVault(s.ctx, vaultAttrs{admin: s.adminAddr.String(), share: share, underlying: under})
	s.Require().NoError(err, "CreateVault should succeed")

	tests := []struct {
		name           string
		pausedBalance  sdk.Coin
		expectedAmount math.Int
	}{
		{
			name:           "nil amount is normalised to zero",
			pausedBalance:  sdk.Coin{Denom: under, Amount: math.Int{}},
			expectedAmount: math.ZeroInt(),
		},
		{
			name:           "zero amount is preserved",
			pausedBalance:  sdk.NewCoin(under, math.ZeroInt()),
			expectedAmount: math.ZeroInt(),
		},
		{
			name:           "positive amount is preserved",
			pausedBalance:  sdk.NewInt64Coin(under, 750),
			expectedAmount: math.NewInt(750),
		},
	}

	for _, tc := range tests {
		s.Run(tc.name, func() {
			reason := "applying paused state"
			s.k.TestAccessor_applyPausedState(s.T(), s.ctx, v, reason, s.adminAddr.String(), tc.pausedBalance)

			s.Require().False(v.PausedBalance.Amount.IsNil(), "paused balance amount must never be nil after applyPausedState; a nil math.Int panics on any read and applyPausedState is reachable from the EndBlocker")
			s.Require().NoError(v.PausedBalance.Validate(), "paused balance %s should be a valid coin after applyPausedState", v.PausedBalance)
			s.Assert().Equal(tc.expectedAmount, v.PausedBalance.Amount, "paused balance amount mismatch after applyPausedState")
			s.Assert().Equal(under, v.PausedBalance.Denom, "paused balance denom should be the vault underlying asset")
			s.Assert().True(v.Paused, "vault should be marked paused")
			s.Assert().Equal(reason, v.PausedReason, "paused reason mismatch")
			s.Assert().Equal(s.adminAddr.String(), v.PausedBy, "applyPausedState should record the pause initiator")
			s.Assert().True(v.PausedForced, "applyPausedState serves the emergency pause paths, which are always forced")
			s.Assert().Equal(types.ZeroInterestRate, v.CurrentInterestRate, "applyPausedState should zero the current interest rate")
		})
	}
}

func (s *TestSuite) TestAutoPauseVault_ValuationFailureSnapshotsZeroPausedBalance() {
	under := "under-apz"
	share := "share-apz"
	s.requireAddFinalizeAndActivateMarker(sdk.NewInt64Coin(under, 1_000), s.adminAddr)

	v, err := s.k.CreateVault(s.ctx, vaultAttrs{admin: s.adminAddr.String(), share: share, underlying: under})
	s.Require().NoError(err, "CreateVault should succeed")

	vaultAddr := types.GetVaultAddress(share)
	s.requireUnvaluableVault(vaultAddr)

	_, err = s.k.GetNetTVV(s.ctx, *v)
	s.Require().Error(err, "the vault must be unvaluable for this test to exercise the auto-pause valuation failure branch")

	reason := "critical failure with a failing valuation"
	s.Require().NotPanics(func() {
		s.k.TestAccessor_autoPauseVault(s.T(), s.ctx, v, reason)
	}, "auto-pausing on a failed valuation must not panic; it runs inside the EndBlocker where a panic halts the chain")

	s.Require().False(v.PausedBalance.Amount.IsNil(), "auto-pause must snapshot a non-nil paused balance even when valuation fails")
	s.Assert().Equal(sdk.NewCoin(under, math.ZeroInt()), v.PausedBalance, "a failed valuation should snapshot a zero paused balance in the underlying asset")

	got, err := s.k.GetVault(s.ctx, vaultAddr)
	s.Require().NoError(err, "GetVault should succeed after auto-pause")
	s.Assert().True(got.Paused, "vault should be persisted as paused")
	s.Assert().Equal(reason, got.PausedReason, "persisted paused reason mismatch")
	s.Assert().Equal(sdk.NewCoin(under, math.ZeroInt()), got.PausedBalance, "persisted paused balance mismatch after a failed valuation")
}

func (s *TestSuite) TestSetWithdrawalDelay() {
	share := "jackthecatshare"
	under := "georgethedogunder"
	s.requireAddFinalizeAndActivateMarker(sdk.NewInt64Coin(under, 1_000_000), s.adminAddr)

	attrs := vaultAttrs{
		admin:      s.adminAddr.String(),
		share:      share,
		underlying: under,
	}
	vault, err := s.k.CreateVault(s.ctx, attrs)
	s.Require().NoError(err, "CreateVault should succeed")

	vaultAddr := types.GetVaultAddress(share)
	authorityAddr := s.CreateAndFundAccount(sdk.NewInt64Coin("stake", 1))
	authority := authorityAddr.String()
	delay := uint64(3600)

	s.ctx = s.ctx.WithEventManager(sdk.NewEventManager())
	err = s.k.SetWithdrawalDelay(s.ctx, vault, delay, authority)
	s.Require().NoError(err, "SetWithdrawalDelay should succeed")

	updated, err := s.k.GetVault(s.ctx, vaultAddr)
	s.Require().NoError(err, "GetVault should succeed after SetWithdrawalDelay")
	s.Require().NotNil(updated, "vault should exist after SetWithdrawalDelay")
	s.Require().Equal(delay, updated.WithdrawalDelaySeconds, "WithdrawalDelaySeconds should be updated")

	expectedEvents := sdk.Events{
		sdk.NewEvent("provlabs.vault.v1.EventWithdrawalDelayUpdated",
			sdk.NewAttribute("authority", authority),
			sdk.NewAttribute("vault_address", vaultAddr.String()),
			sdk.NewAttribute("withdrawal_delay_seconds", fmt.Sprintf("%d", delay)),
		),
	}

	evs := s.ctx.EventManager().Events()
	s.Require().Equal(normalizeEvents(expectedEvents), normalizeEvents(evs), "events should match expected EventWithdrawalDelayUpdated")
}

func (s *TestSuite) TestSetWithdrawalDelay_RejectsDelayAboveMax() {
	underlyingDenom := "delayunder"
	shareDenom := "delayshare"
	vault := s.setupBaseVault(underlyingDenom, shareDenom)
	vaultAddr := vault.GetAddress()

	err := s.k.SetWithdrawalDelay(s.ctx, vault, types.MaxWithdrawalDelay+1, s.adminAddr.String())
	s.Require().Error(err, "SetWithdrawalDelay should reject a delay above MaxWithdrawalDelay")
	s.Require().ErrorContains(err, fmt.Sprintf("withdrawal delay cannot exceed %d seconds", types.MaxWithdrawalDelay),
		"error should name the withdrawal delay bound")

	persisted, err := s.k.GetVault(s.ctx, vaultAddr)
	s.Require().NoError(err, "GetVault should succeed after the rejected update")
	s.Require().Equal(uint64(0), persisted.WithdrawalDelaySeconds, "the rejected delay must not be persisted")
}

func (s *TestSuite) TestSetVaultAccount_RejectsWithdrawalDelayAboveMax() {
	underlyingDenom := "genesisunder"
	shareDenom := "genesisshare"
	vault := s.setupBaseVault(underlyingDenom, shareDenom)

	tests := []struct {
		name         string
		delaySeconds uint64
		expectedErr  string
	}{
		{
			name:         "delay at the maximum is accepted",
			delaySeconds: types.MaxWithdrawalDelay,
		},
		{
			name:         "delay one second above the maximum is rejected",
			delaySeconds: types.MaxWithdrawalDelay + 1,
			expectedErr:  fmt.Sprintf("withdrawal delay cannot exceed %d seconds", types.MaxWithdrawalDelay),
		},
		{
			name:         "MaxUint64 delay is rejected before it can truncate to a negative queue key",
			delaySeconds: stdmath.MaxUint64,
			expectedErr:  fmt.Sprintf("withdrawal delay cannot exceed %d seconds", types.MaxWithdrawalDelay),
		},
	}

	for _, tc := range tests {
		s.Run(tc.name, func() {
			candidate := vault.Clone()
			candidate.WithdrawalDelaySeconds = tc.delaySeconds

			err := s.k.SetVaultAccount(s.ctx, candidate)
			if tc.expectedErr == "" {
				s.Require().NoError(err, "SetVaultAccount should accept a delay of %d seconds", tc.delaySeconds)
				return
			}
			s.Require().Error(err, "SetVaultAccount should reject a delay of %d seconds", tc.delaySeconds)
			s.Require().ErrorContains(err, tc.expectedErr, "error should name the withdrawal delay bound")
		})
	}
}

func (s *TestSuite) TestSwapOut_FailsWhenPersistedWithdrawalDelayExceedsMax() {
	underlyingDenom := "wdgu"
	shareDenom := "vaultwdgu"
	blockTime := time.Now().UTC()
	s.ctx = s.ctx.WithBlockTime(blockTime)

	vault := s.setupBaseVault(underlyingDenom, shareDenom)
	vaultAddr := vault.GetAddress()

	redeemer := s.CreateAndFundAccount(sdk.NewInt64Coin("stake", 1))
	s.Require().NoError(FundAccount(s.ctx, s.simApp, redeemer, sdk.NewCoins(sdk.NewInt64Coin(underlyingDenom, 1_000_000))),
		"funding the redeemer with underlying should succeed")
	_, err := s.k.SwapIn(s.ctx, vaultAddr, redeemer, sdk.NewInt64Coin(underlyingDenom, 1_000_000))
	s.Require().NoError(err, "swap-in should succeed before the delay is tampered with")

	vault, err = s.k.GetVault(s.ctx, vaultAddr)
	s.Require().NoError(err, "GetVault should succeed after swap-in")
	vault.WithdrawalDelaySeconds = stdmath.MaxUint64
	s.k.AuthKeeper.SetAccount(s.ctx, vault)

	shares := s.simApp.BankKeeper.GetBalance(s.ctx, redeemer, shareDenom).Amount
	_, err = s.k.SwapOut(s.ctx, vaultAddr, redeemer, sdk.NewCoin(shareDenom, shares))
	s.Require().Error(err, "SwapOut must refuse a vault whose persisted withdrawal delay exceeds MaxWithdrawalDelay")
	s.Require().ErrorContains(err, fmt.Sprintf("withdrawal delay cannot exceed %d seconds", types.MaxWithdrawalDelay),
		"error should name the withdrawal delay bound")

	s.assertBalance(redeemer, shareDenom, shares)
	s.assertBalance(vaultAddr, shareDenom, math.ZeroInt())

	before := s.simApp.BankKeeper.GetBalance(s.ctx, redeemer, underlyingDenom).Amount
	s.Require().NoError(s.k.TestAccessor_processPendingSwapOuts(s.T(), s.ctx, keeper.MaxSwapOutBatchSize),
		"processing pending swap-outs should not fail")
	after := s.simApp.BankKeeper.GetBalance(s.ctx, redeemer, underlyingDenom).Amount
	s.Require().Equal(before, after, "nothing may pay out in the requesting block when the swap-out was refused")
}
