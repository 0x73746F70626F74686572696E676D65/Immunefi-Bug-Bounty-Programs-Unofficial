package keeper

import (
	"errors"
	"fmt"
	"strings"

	"github.com/provlabs/vault/types"

	sdk "github.com/cosmos/cosmos-sdk/types"
	sdkerrors "github.com/cosmos/cosmos-sdk/types/errors"

	markertypes "github.com/provenance-io/provenance/x/marker/types"
)

// processPendingSwapOuts processes the queue of pending swap-out requests. Called from the EndBlocker,
// it iterates through requests due for payout at the current block time. It uses a safe "collect-then-mutate"
// pattern to comply with the SDK iterator contract. It first collects due requests up to the provided `batchSize`,
// counting every visited entry (including ones for paused vaults) against the budget, then passes them to
// `processSwapOutJobs` for execution. Critical, unrecoverable errors during job processing will cause the
// associated vault to be automatically paused.
func (k *Keeper) processPendingSwapOuts(ctx sdk.Context, batchSize int) error {
	now := ctx.BlockTime().Unix()
	var jobsToProcess []types.PayoutJob

	visited := 0
	err := k.PendingSwapOutQueue.WalkDue(ctx, now, func(timestamp int64, id uint64, vaultAddr sdk.AccAddress, req types.PendingSwapOut) (stop bool, err error) {
		if visited == batchSize {
			return true, nil
		}
		visited++
		jobsToProcess = append(jobsToProcess, types.NewPayoutJob(timestamp, id, vaultAddr, req))
		return false, nil
	})
	if err != nil {
		k.getLogger(ctx).Error("error during pending withdrawal queue walk", "error", err)
		return fmt.Errorf("failed to walk pending swap out queue: %w", err)
	}

	k.processSwapOutJobs(ctx, jobsToProcess)

	return nil
}

// processSwapOutJobs iterates pending swap-out jobs collected for this block and executes them.
//
// A pending request is removed from the queue only when a durable outcome is committed in the same
// atomic unit as the deletion: a completed payout or a successful refund. The dequeue therefore shares
// the cache context with its outcome, so on a critical failure both the work and the deletion roll back
// together and the request, along with the shares escrowed at request time, is preserved for later
// settlement. This keeps the payout/burn atomicity intact while ensuring escrow can never be stranded
// by a partially committed outcome.
//
// The processing strategy involves:
//  1. Verifying the request is well formed and deferring it if not, since the payout and refund paths
//     both build sdk.Coins from the escrowed shares and would panic the EndBlocker on a bad amount.
//  2. Verifying the vault exists; jobs for non-existent vaults are dequeued and skipped, and jobs
//     for paused vaults are dequeued and refunded atomically in their own cache context.
//  3. Executing the withdrawal logic (reconciliation, payout, and burning) within a cache context, then
//     dequeuing in that same cache context and committing only on success.
//  4. Handling recoverable failures by dequeuing and refunding atomically in a fresh cache context.
//  5. Handling critical or unrecoverable failures by auto-pausing the vault and discarding the cache so
//     the request is preserved. Because the vault is now paused, the preserved request is refunded on a
//     later block rather than re-executed, so it is never double-processed.
//
// Every path that preserves a request also calls deferSwapOutRetry, which re-keys it behind the
// currently due work. A failure such as a deactivated share marker or a revoked owner attribute is
// deterministic, so an entry left under its original key would be re-collected and re-fail every
// block, and enough of them would consume the whole batch budget and stall the queue.
//
// A failed Dequeue on an active vault's job is also treated as a critical, unrecoverable failure, so it
// auto-pauses the vault to signal operators while the escrowed shares are preserved.
func (k *Keeper) processSwapOutJobs(ctx sdk.Context, jobsToProcess []types.PayoutJob) {
	for _, j := range jobsToProcess {
		if err := j.Req.Validate(); err != nil {
			k.getLogger(ctx).Error(
				"CRITICAL: skipping malformed pending withdrawal request",
				"request_id", j.ID,
				"vault_address", j.VaultAddr.String(),
				"error", err,
			)
			k.deferSwapOutRetry(ctx, j, types.RetryReasonInvalidRequest)
			continue
		}

		vault, ok := k.tryGetVault(ctx, j.VaultAddr)
		if !ok {
			if err := k.PendingSwapOutQueue.Dequeue(ctx, j.Timestamp, j.VaultAddr, j.ID); err != nil {
				k.getLogger(ctx).Error(
					fmt.Sprintf("CRITICAL: failed to dequeue withdrawal request %d for non-existent vault %s", j.ID, j.VaultAddr),
					"error", err,
				)
				k.deferSwapOutRetry(ctx, j, types.RetryReasonDequeueFailure)
			} else {
				k.getLogger(ctx).Error(
					"dequeued and skipped pending withdrawal for non-existent vault",
					"request_id", j.ID,
					"vault_address", j.VaultAddr.String(),
				)
			}
			continue
		}

		if vault.Paused {
			k.refundPausedVaultSwapOut(ctx, j)
			continue
		}

		var cErr *types.CriticalError
		cacheCtx, write := ctx.CacheContext()
		err := k.processSingleWithdrawal(cacheCtx, j.ID, j.Req, *vault)
		if err == nil {
			if derr := k.PendingSwapOutQueue.Dequeue(cacheCtx, j.Timestamp, j.VaultAddr, j.ID); derr != nil {
				errMsg := fmt.Sprintf("failed to dequeue withdrawal request %d after successful payout", j.ID)
				k.getLogger(ctx).Error(
					"CRITICAL: "+errMsg,
					"request_id", j.ID,
					"vault_address", j.VaultAddr.String(),
					"error", derr,
				)
				k.autoPauseVault(ctx, vault, errMsg)
				k.deferSwapOutRetry(ctx, j, types.RetryReasonDequeueFailure)
				continue
			}
			write()
			continue
		}

		if errors.As(err, &cErr) {
			k.autoPauseVault(ctx, vault, cErr.Reason)
			k.deferSwapOutRetry(ctx, j, types.RetryReasonCriticalFailure)
			continue
		}

		reason := k.getRefundReason(err)
		k.getLogger(ctx).Error(
			"failed to process withdrawal, issuing refund",
			"withdrawal_id", j.ID,
			"reason", reason,
			"error", err,
		)

		refundCtx, refundWrite := ctx.CacheContext()
		if derr := k.PendingSwapOutQueue.Dequeue(refundCtx, j.Timestamp, j.VaultAddr, j.ID); derr != nil {
			errMsg := fmt.Sprintf("failed to dequeue withdrawal request %d before refund", j.ID)
			k.getLogger(ctx).Error(
				"CRITICAL: "+errMsg,
				"request_id", j.ID,
				"vault_address", j.VaultAddr.String(),
				"error", derr,
			)
			k.autoPauseVault(ctx, vault, errMsg)
			k.deferSwapOutRetry(ctx, j, types.RetryReasonDequeueFailure)
			continue
		}
		if rerr := k.refundWithdrawal(refundCtx, j.ID, j.Req, reason); rerr != nil {
			if errors.As(rerr, &cErr) {
				k.autoPauseVault(ctx, vault, cErr.Reason)
			}
			k.deferSwapOutRetry(ctx, j, types.RetryReasonRefundFailure)
			continue
		}
		refundWrite()
	}
}

// refundPausedVaultSwapOut atomically dequeues a due swap-out job for a paused vault and
// refunds the escrowed shares, so paused entries cannot camp at the front of the queue.
// On any failure the cache context is discarded, keeping the request queued as the record
// of who is owed shares, and the retry is deferred to a later block.
func (k *Keeper) refundPausedVaultSwapOut(ctx sdk.Context, j types.PayoutJob) {
	cacheCtx, write := ctx.CacheContext()

	if err := k.PendingSwapOutQueue.Dequeue(cacheCtx, j.Timestamp, j.VaultAddr, j.ID); err != nil {
		k.getLogger(ctx).Error(
			"failed to dequeue withdrawal request for paused vault, leaving queued",
			"request_id", j.ID,
			"vault_address", j.VaultAddr.String(),
			"error", err,
		)
		k.deferSwapOutRetry(ctx, j, types.RetryReasonDequeueFailure)
		return
	}

	if err := k.refundWithdrawal(cacheCtx, j.ID, j.Req, types.RefundReasonVaultPaused); err != nil {
		k.getLogger(ctx).Error(
			"failed to refund withdrawal request for paused vault, leaving queued",
			"request_id", j.ID,
			"vault_address", j.VaultAddr.String(),
			"error", err,
		)
		k.deferSwapOutRetry(ctx, j, types.RetryReasonRefundFailure)
		return
	}

	write()
}

// deferSwapOutRetry records a failed attempt on a preserved swap-out request and re-keys it to a
// later retry time. The escrowed shares stay with the vault, but the request no longer sits at the
// front of the queue re-failing on every block. If the re-key itself fails, the entry is left where
// it is and retried on the next block.
func (k *Keeper) deferSwapOutRetry(ctx sdk.Context, j types.PayoutJob, reason string) {
	req := j.Req
	req.FailureCount++
	retryTime := ctx.BlockTime().Unix() + swapOutRetryDelay(j.ID, req.FailureCount)

	cacheCtx, write := ctx.CacheContext()
	if err := k.PendingSwapOutQueue.Reschedule(cacheCtx, j.Timestamp, j.VaultAddr, j.ID, retryTime, &req); err != nil {
		k.getLogger(ctx).Error(
			"CRITICAL: failed to reschedule withdrawal request, leaving it at the front of the queue",
			"request_id", j.ID,
			"vault_address", j.VaultAddr.String(),
			"error", err,
		)
		return
	}
	write()

	k.getLogger(ctx).Info(
		"rescheduled withdrawal request after failed attempt",
		"request_id", j.ID,
		"vault_address", j.VaultAddr.String(),
		"reason", reason,
		"failure_count", req.FailureCount,
		"retry_time", retryTime,
	)
	k.emitEvent(ctx, types.NewEventSwapOutRetryScheduled(req.VaultAddress, req.Owner, req.Shares, j.ID, reason, req.FailureCount, retryTime))
}

// swapOutRetryDelay returns how many seconds to delay the next attempt for swap out id, spreading a
// delayed retry across SwapOutRetryJitterSpread so entries failing together stop coming due together.
func swapOutRetryDelay(id uint64, failureCount uint32) int64 {
	backoff := swapOutRetryBackoff(failureCount)
	if backoff == 0 {
		return 0
	}

	return backoff + int64(id%SwapOutRetryJitterSpread)
}

// swapOutRetryBackoff returns how many seconds to delay the next attempt for a swap out that has
// failed failureCount times. The first SwapOutImmediateRetries failures retry on the next block;
// after that the delay doubles from SwapOutRetryBackoffBase up to SwapOutRetryBackoffMax.
func swapOutRetryBackoff(failureCount uint32) int64 {
	if failureCount <= SwapOutImmediateRetries {
		return 0
	}

	backoff := int64(SwapOutRetryBackoffBase)
	for i := failureCount - SwapOutImmediateRetries - 1; i > 0 && backoff < SwapOutRetryBackoffMax; i-- {
		backoff *= 2
	}

	return min(backoff, SwapOutRetryBackoffMax)
}

// processSingleWithdrawal executes a pending swap-out. It first reconciles the vault (interest and AUM fees), then converts the user's
// shares to the redeemable asset amount. It then pays out those assets to the owner and burns their escrowed shares.
// It returns nil on success and emits an EventSwapOutCompleted. If a failure occurs before payout (e.g., insufficient
// liquidity), a normal error is returned and can be refunded. If a failure occurs after payout (e.g., transfer to
// principal or burn failure), the error is wrapped in a *types.CriticalError with a stable reason so the vault
// can be automatically paused.
func (k *Keeper) processSingleWithdrawal(ctx sdk.Context, id uint64, req types.PendingSwapOut, vault types.VaultAccount) error {
	vaultAddr, err := sdk.AccAddressFromBech32(req.VaultAddress)
	if err != nil {
		return fmt.Errorf("invalid vault address %s: %w", req.VaultAddress, err)
	}
	ownerAddr, err := sdk.AccAddressFromBech32(req.Owner)
	if err != nil {
		return fmt.Errorf("invalid owner address %s: %w", req.Owner, err)
	}
	principalAddress, err := markertypes.MarkerAddress(req.Shares.Denom)
	if err != nil {
		return fmt.Errorf("invalid principal address for denom %s: %w", req.Shares.Denom, err)
	}

	if err = k.reconcileVault(ctx, &vault); err != nil {
		return fmt.Errorf("%w: failed to reconcile vault: %w", types.ErrReconcileFailure, err)
	}

	assets, err := k.ConvertSharesToRedeemCoin(ctx, vault, req.Shares.Amount)
	if err != nil {
		return fmt.Errorf("failed to convert shares to redeem coin for single withdrawal: %w", err)
	}

	if err = k.BankKeeper.SendCoins(markertypes.WithTransferAgents(ctx, vaultAddr), principalAddress, ownerAddr, sdk.NewCoins(assets)); err != nil {
		return fmt.Errorf("failed to payout assets to owner: %w", err)
	}

	if err = k.adjustTotalValue(ctx, vault, assets.Amount.Neg()); err != nil {
		errMsg := fmt.Sprintf("failed to record payout of %s from vault %s in total vault value", assets, vaultAddr)
		k.getLogger(ctx).Error("CRITICAL: "+errMsg, "error", err)
		return types.CriticalErr(errMsg, fmt.Errorf("%s: %w", errMsg, err))
	}

	if err = k.BankKeeper.SendCoins(ctx, vaultAddr, principalAddress, sdk.NewCoins(req.Shares)); err != nil {
		errMsg := fmt.Sprintf(
			"failed to transfer %s shares from %s to principal %s for burning",
			req.Shares, vaultAddr, principalAddress,
		)
		k.getLogger(ctx).Error("CRITICAL: "+errMsg, "error", err)
		return types.CriticalErr(errMsg, fmt.Errorf("%s: %w", errMsg, err))
	}

	if err = k.MarkerKeeper.BurnCoin(ctx, vaultAddr, req.Shares); err != nil {
		errMsg := fmt.Sprintf(
			"failed to burn %s shares from account %s after successful payout",
			req.Shares, vaultAddr,
		)
		k.getLogger(ctx).Error("CRITICAL: "+errMsg, "error", err)
		return types.CriticalErr(errMsg, fmt.Errorf("%s: %w", errMsg, err))
	}

	// This should not fail under correct accounting. Liquidity issues would cause BankKeeper.SendCoins to fail earlier.
	// If SafeSub fails here, req.Shares > TotalShares, indicating accounting drift; we pause the vault.
	vault.TotalShares, err = vault.TotalShares.SafeSub(req.Shares)
	if err != nil {
		errMsg := fmt.Sprintf(
			"failed to deduct %s shares from vault %s total shares after successful payout",
			req.Shares, vaultAddr,
		)
		k.getLogger(ctx).Error("CRITICAL: "+errMsg, "error", err)
		return types.CriticalErr(errMsg, fmt.Errorf("%s: %w", errMsg, err))
	}

	if err := k.SetVaultAccount(ctx, &vault); err != nil {
		errMsg := fmt.Sprintf(
			"failed to update vault account %s after successful payout",
			vaultAddr,
		)
		k.getLogger(ctx).Error("CRITICAL: "+errMsg, "error", err)
		return types.CriticalErr(errMsg, fmt.Errorf("%s: %w", errMsg, err))
	}

	k.emitEvent(ctx, types.NewEventSwapOutCompleted(req.VaultAddress, req.Owner, assets, id))
	return nil
}

// refundWithdrawal handles the failure case for a pending swap out. It returns the user's
// escrowed shares from the vault's own account back to the owner and emits an EventSwapOutRefunded.
// It returns nil on success. If the refund transfer itself fails, the error is wrapped in a
// *types.CriticalError with a stable reason so the vault can be automatically paused.
func (k *Keeper) refundWithdrawal(ctx sdk.Context, id uint64, req types.PendingSwapOut, reason string) error {
	vaultAddr, err := sdk.AccAddressFromBech32(req.VaultAddress)
	if err != nil {
		return fmt.Errorf("invalid vault address %s: %w", req.VaultAddress, err)
	}
	ownerAddr, err := sdk.AccAddressFromBech32(req.Owner)
	if err != nil {
		return fmt.Errorf("invalid owner address %s: %w", req.Owner, err)
	}

	if err := k.BankKeeper.SendCoins(ctx, vaultAddr, ownerAddr, sdk.NewCoins(req.Shares)); err != nil {
		errMsg := fmt.Sprintf(
			"failed to refund %s shares from vault %s to owner %s",
			req.Shares, vaultAddr, ownerAddr,
		)
		k.getLogger(ctx).Error("CRITICAL: "+errMsg, "error", err)
		return types.CriticalErr(errMsg, fmt.Errorf("%s: %w", errMsg, err))
	}

	k.emitEvent(ctx, types.NewEventSwapOutRefunded(req.VaultAddress, req.Owner, req.Shares, id, reason))
	return nil
}

// getRefundReason translates a swap-out processing error into a standardized reason string for the
// EventSwapOutRefunded event. Failures raised inside this module carry typed sentinels and are
// matched with errors.Is; x/marker send-restriction failures are untyped and fall through to
// markerRefundReason. Unrecognized errors return RefundReasonUnknown.
func (k Keeper) getRefundReason(err error) string {
	if err == nil {
		return types.RefundReasonUnknown
	}
	if errors.Is(err, ErrInternalNAVNotFound) {
		return types.RefundReasonNavNotFound
	}

	switch {
	case errors.Is(err, sdkerrors.ErrInsufficientFunds):
		return types.RefundReasonInsufficientFunds
	case errors.Is(err, types.ErrNavNotFound):
		return types.RefundReasonNavNotFound
	case errors.Is(err, types.ErrReconcileFailure):
		return types.RefundReasonReconcileFailure
	}

	return markerRefundReason(err)
}

// markerRefundReason classifies an untyped x/marker send-restriction error by its message text.
// The marker module exposes these failures only as plain errors, so the substrings here mirror
// send_restrictions.go and should be revisited when the provenance dependency is bumped.
// Unrecognized errors return RefundReasonUnknown.
func markerRefundReason(err error) string {
	msg := err.Error()
	switch {
	case strings.Contains(msg, "marker status") && strings.Contains(msg, "is not active"):
		return types.RefundReasonMarkerNotActive
	case strings.Contains(msg, "does not contain") && strings.Contains(msg, "required attribute"):
		return types.RefundReasonRecipientMissingAttributes
	case strings.Contains(msg, "is on deny list"),
		strings.Contains(msg, "does not have transfer permissions"):
		return types.RefundReasonPermissionDenied
	case strings.Contains(msg, "cannot be sent to the fee collector"):
		return types.RefundReasonRecipientInvalid
	}

	return types.RefundReasonUnknown
}
