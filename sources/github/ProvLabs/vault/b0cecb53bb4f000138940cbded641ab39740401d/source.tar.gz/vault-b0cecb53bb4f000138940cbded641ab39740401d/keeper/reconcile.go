package keeper

import (
	"errors"
	"fmt"
	"math"
	"math/big"

	"github.com/provlabs/vault/interest"
	"github.com/provlabs/vault/types"

	"cosmossdk.io/collections"
	sdkmath "cosmossdk.io/math"

	sdk "github.com/cosmos/cosmos-sdk/types"

	markertypes "github.com/provenance-io/provenance/x/marker/types"
)

const (
	// AutoReconcilePayoutDuration is the time period (in seconds) used to forecast if a vault has
	// sufficient funds to cover future interest payments.
	AutoReconcilePayoutDuration = 24 * interest.SecondsPerHour
)

// navReferenceVolume is the reference share volume used to publish a marker NAV when a vault's
// total shares exceed the uint64 ceiling that NetAssetValue.Volume can represent.
//
// A NAV is a price-per-share ratio, not a function of absolute supply, so the published volume can
// be any representative quantity as long as the price is scaled to preserve price/volume. It is set
// to the uint64 maximum so every supply that fits in uint64 publishes its exact share count as the
// volume (no scaling, price = TVV), and only supplies beyond uint64 are capped at this value with the
// price scaled down proportionally. Using the uint64 ceiling rather than a smaller bound both avoids
// needlessly scaling uint64-safe supplies and maximizes price precision in the scaled case.
var navReferenceVolume = sdkmath.NewIntFromUint64(math.MaxUint64)

// reconcileVault updates interest accounting and collects AUM fees for a vault if a new period has started.
//
// If this is the first time the vault accrues fees, it bootstraps the fee period.
// If the current block time is after the relevant PeriodStart, it applies the interest and/or fee transfers.
// This function will do nothing if the vault is paused.
//
// This should be called before any transaction that changes vault principal/reserves or depends on the
// current interest state.
//
// The reconciliation is performed atomically using a cache context. If any part of the process fails,
// all state changes (interest transfers, fee transfers, and queue updates) are rolled back.
// To ensure a clean state, the operation works on a cloned copy of the vault and only updates
// the original object upon successful completion.
//
// The process follows a strict mathematical ordering:
// 1. Interest is processed first to ensure the Total Vault Value (TVV) is updated.
// 2. AUM fees are then calculated and collected based on the post-interest TVV.
// 3. Timeouts are rescheduled and the updated NAV is published.
//
// The share NAV is republished whenever either accrual moved the net TVV, so a fee-only
// reconcile refreshes the marker mirror just as an interest accrual does. A reconcile that
// moves no value publishes nothing.
func (k Keeper) reconcileVault(ctx sdk.Context, vault *types.VaultAccount) error {
	if vault == nil {
		return fmt.Errorf("vault account cannot be nil")
	}
	if vault.Paused {
		return nil
	}

	cacheCtx, write := ctx.CacheContext()
	v := vault.Clone()
	currentBlockTime := cacheCtx.BlockTime().Unix()
	netValueMoved := interestPeriodElapsed(v, currentBlockTime) || feeAccrualMovesNetValue(v, currentBlockTime)

	if interestPeriodElapsed(v, currentBlockTime) {
		if err := k.PerformVaultInterestTransfer(cacheCtx, v); err != nil {
			return fmt.Errorf("perform vault interest transfer: %w", err)
		}
	}

	if v.FeePeriodStart != 0 {
		if err := k.PerformVaultFeeTransfer(cacheCtx, v); err != nil {
			return fmt.Errorf("perform vault fee transfer: %w", err)
		}
		if err := k.SafeEnqueueFeeTimeout(cacheCtx, v); err != nil {
			return fmt.Errorf("enqueue fee timeout after transfer: %w", err)
		}
	} else {
		if err := k.SafeEnqueueFeeTimeout(cacheCtx, v); err != nil {
			return fmt.Errorf("enqueue fee timeout: %w", err)
		}
	}

	if netValueMoved {
		if err := k.publishShareNav(cacheCtx, v); err != nil {
			return fmt.Errorf("publish share nav: %w", err)
		}
	}

	if err := k.SafeAddPayoutVerification(cacheCtx, v); err != nil {
		return fmt.Errorf("reconcileVault: failed to SafeAddPayoutVerification for vault %s: %w", v.GetAddress().String(), err)
	}

	write()
	*vault = *v
	return nil
}

// interestPeriodElapsed reports whether an interest accrual is due for the vault at blockTime,
// meaning a reconcile will move the vault's total value by settling interest.
func interestPeriodElapsed(vault *types.VaultAccount, blockTime int64) bool {
	return vault.PeriodStart != 0 && blockTime > vault.PeriodStart
}

// feePeriodElapsed reports whether an AUM fee accrual is due for the vault at blockTime.
func feePeriodElapsed(vault *types.VaultAccount, blockTime int64) bool {
	return vault.FeePeriodStart != 0 && blockTime > vault.FeePeriodStart
}

// feeAccrualMovesNetValue reports whether a due AUM fee accrual will move the vault's net total
// value. The net moves by the newly accrued fee alone, so a vault with no fee rate never moves it.
func feeAccrualMovesNetValue(vault *types.VaultAccount, blockTime int64) bool {
	return vault.AumFeeBips != 0 && feePeriodElapsed(vault, blockTime)
}

// refreshShareNav republishes the mirrored share NAV after an ABCI reconcile moved the vault's net
// total vault value. The mirror is informational, so a failure is logged rather than returned and
// cannot roll back the transfer that already succeeded in the same cache context.
func (k Keeper) refreshShareNav(ctx sdk.Context, vault *types.VaultAccount) {
	if err := k.publishShareNav(ctx, vault); err != nil {
		k.getLogger(ctx).Error("failed to publish share NAV after reconcile",
			"vault", vault.GetAddress().String(),
			"err", err,
		)
	}
}

// setShareDenomNAV publishes the Net Asset Value (NAV) for a vault’s share denom
// in terms of the underlying asset.
//
// A NAV is a price-per-share ratio (Price / Volume), not a function of absolute supply. When the
// vault's total shares fit in uint64, the NAV is published directly as (Price = TVV, Volume = total
// shares). When total shares exceed uint64, the volume is capped at navReferenceVolume (the uint64
// maximum) and the price is scaled down proportionally (price = TVV * volume / totalShares),
// preserving the price-per-share ratio while keeping the published volume within uint64. The unscaled
// branch computes entirely in sdkmath.Int; the scaled branch computes the price through math/big (see
// the panic-safety note below). Only the final bounded volume is converted to uint64.
//
// The price division truncates toward zero (rounds down) by design, following the accounting
// principle of conservatism: the reported per-share value is never rounded above the provable
// TVV / totalShares ratio. A scaled price that truncates to zero is still published as a zero price so
// consumers observe the current (near-zero) valuation rather than a stale prior NAV.
//
// All arithmetic is panic-safe and never skips a representable NAV. Unscaled supplies publish
// Price = TVV directly with no multiply. The scaled price is computed through math/big so the
// intermediate TVV * volume product cannot overflow the 256-bit sdkmath.Int bound; the final quotient
// always fits because it is strictly less than TVV (volume < totalShares in the scaled branch), so the
// conversion back to sdkmath.Int never panics. The final division cannot divide by zero because
// totalShares is guarded as positive, and a negative price (only reachable from a non-positive TVV,
// which callers already exclude) is skipped so NewCoin is never handed a negative amount.
//
// If the vault has no shares, no NAV is published.
func (k Keeper) setShareDenomNAV(ctx sdk.Context, vault *types.VaultAccount, vaultMarker markertypes.MarkerAccountI, tvv sdkmath.Int) error {
	totalShares := vault.TotalShares.Amount
	if !totalShares.IsPositive() {
		return nil
	}

	volume := totalShares
	price := tvv
	if totalShares.GT(navReferenceVolume) {
		volume = navReferenceVolume
		scaled := new(big.Int).Mul(tvv.BigInt(), volume.BigInt())
		scaled.Quo(scaled, totalShares.BigInt())
		price = sdkmath.NewIntFromBigInt(scaled)
	}
	if price.IsNegative() {
		k.getLogger(ctx).Debug("skipping share NAV publication: price is negative",
			"vault", vault.GetAddress().String(),
			"tvv", tvv.String(),
			"total_shares", totalShares.String(),
		)
		return nil
	}

	return k.MarkerKeeper.SetNetAssetValue(
		ctx,
		vaultMarker,
		markertypes.NetAssetValue{
			Price:  sdk.NewCoin(vault.UnderlyingAsset, price),
			Volume: volume.Uint64(),
		},
		types.ModuleName,
	)
}

// publishShareNav records the Net Asset Value (NAV) for the vault's share denom
// in terms of its underlying asset. It fetches the vault’s principal marker,
// computes the net total value of vault assets in underlying units (TVV net of the
// OutstandingAumFee liability), and publishes it via setShareDenomNAV, which encodes the
// net-TVV-per-share ratio while keeping the marker volume within uint64.
//
// When the vault has no shares its price-per-share is undefined. If a non-zero share NAV was
// previously published, it is overwritten with a zero price (leaving any other price-denom NAV on the
// marker untouched) so GetNetAssetValue no longer serves a stale price for a share denom that has no
// supply. The overwrite is skipped only when no NAV exists or it is already fully zero (zero price and
// zero volume), so a vault that never had shares does not gain a spurious NAV and the zero is emitted
// at most once; a NAV left at zero price but non-zero volume (which the scaled truncation path can
// publish) is still re-zeroed. When the TVV is non-positive, no NAV is published.
//
// If NAV publication fails, the error is logged and the operation continues
// without failing the overall vault reconciliation process.
func (k Keeper) publishShareNav(ctx sdk.Context, vault *types.VaultAccount) error {
	vaultMarker, err := k.MarkerKeeper.GetMarker(ctx, vault.PrincipalMarkerAddress())
	if err != nil {
		return fmt.Errorf("failed to get principal marker: %w", err)
	}
	if !vault.TotalShares.IsPositive() {
		var existing *markertypes.NetAssetValue
		existing, err = k.MarkerKeeper.GetNetAssetValue(ctx, vaultMarker.GetDenom(), vault.UnderlyingAsset)
		if err != nil {
			k.getLogger(ctx).Error("failed to read share NAV while zeroing empty vault", "err", err)
			return nil
		}
		if existing != nil && (!existing.Price.Amount.IsZero() || existing.Volume != 0) {
			zeroNAV := markertypes.NetAssetValue{
				Price:  sdk.NewCoin(vault.UnderlyingAsset, sdkmath.ZeroInt()),
				Volume: 0,
			}
			if err = k.MarkerKeeper.SetNetAssetValue(ctx, vaultMarker, zeroNAV, types.ModuleName); err != nil {
				k.getLogger(ctx).Error("failed to zero share NAV for empty vault", "err", err)
			}
		}
		return nil
	}
	tvv, err := k.GetNetTVV(ctx, *vault)
	if err != nil {
		return fmt.Errorf("failed to get TVV: %w", err)
	}
	if !tvv.IsPositive() {
		return nil
	}

	if err := k.setShareDenomNAV(ctx, vault, vaultMarker, tvv); err != nil {
		k.getLogger(ctx).Error("failed to publish share NAV", "err", err)
	}
	return nil
}

// PerformVaultInterestTransfer applies accrued interest between the vault and the marker account
// if the current block time is beyond PeriodStart.
//
// Interest is settled exclusively in the vault's defined UnderlyingAsset.
// Interest is calculated based on the **Gross TVV** (the literal sum of all assets in the marker).
//   - Positive Interest: Paid from vault reserves to the marker. Fails if reserves are insufficient.
//   - Negative Interest: Refunded from marker principal to the vault. This is bounded by the
//     available balance of the UnderlyingAsset in the marker account.
//
// IMPORTANT: If the vault utilizes composite reserves (holding multiple token types), secondary
// assets are NOT liquidated or transferred to satisfy interest obligations. If the marker owes
// negative interest but lacks sufficient liquidity in the UnderlyingAsset, the transfer is
// capped at the available underlying balance, potentially resulting in a partial payment.
//
// An EventVaultReconcile is emitted upon success. This method does not modify PeriodStart.
func (k Keeper) PerformVaultInterestTransfer(ctx sdk.Context, vault *types.VaultAccount) error {
	currentBlockTime := ctx.BlockTime().Unix()
	if currentBlockTime <= vault.PeriodStart {
		return nil
	}

	periodDuration := currentBlockTime - vault.PeriodStart
	denom := vault.UnderlyingAsset
	vaultAddr := vault.GetAddress()
	principalAddress := vault.PrincipalMarkerAddress()

	reserves := k.BankKeeper.GetBalance(ctx, vaultAddr, denom)
	principalTvv, err := k.GetTVV(ctx, *vault)
	if err != nil {
		return fmt.Errorf("failed to get TVV: %w", err)
	}
	principalInTvv := sdk.NewCoin(denom, principalTvv)

	interestEarned, err := interest.CalculateInterestEarned(principalInTvv, vault.CurrentInterestRate, periodDuration)
	if err != nil {
		return fmt.Errorf("failed to calculate interest: %w", err)
	}

	actualInterest := interestEarned

	if interestEarned.IsPositive() {
		if reserves.Amount.LT(interestEarned) {
			return fmt.Errorf("insufficient reserves to pay interest")
		}
		if err = k.BankKeeper.SendCoins(
			markertypes.WithBypass(ctx),
			vaultAddr,
			principalAddress,
			sdk.NewCoins(sdk.NewCoin(denom, interestEarned)),
		); err != nil {
			return fmt.Errorf("failed to pay interest: %w", err)
		}
		if err = k.adjustTotalValue(ctx, *vault, interestEarned); err != nil {
			return fmt.Errorf("failed to record paid interest value: %w", err)
		}
	} else if interestEarned.IsNegative() {
		principalUnderlying := k.BankKeeper.GetBalance(ctx, principalAddress, denom)
		owed := interestEarned.Abs()
		if principalUnderlying.Amount.LT(owed) {
			owed = principalUnderlying.Amount
		}
		if owed.IsZero() {
			actualInterest = sdkmath.ZeroInt()
		} else {
			if err = k.BankKeeper.SendCoins(
				markertypes.WithBypass(ctx),
				principalAddress,
				vaultAddr,
				sdk.NewCoins(sdk.NewCoin(denom, owed)),
			); err != nil {
				return fmt.Errorf("failed to reclaim negative interest: %w", err)
			}
			if err = k.adjustTotalValue(ctx, *vault, owed.Neg()); err != nil {
				return fmt.Errorf("failed to record reclaimed interest value: %w", err)
			}
			actualInterest = owed.Neg()
		}
	}

	principalTvvAfter, err := k.GetTVV(ctx, *vault)
	if err != nil {
		return fmt.Errorf("failed to get TVV after reconciliation: %w", err)
	}

	k.emitEvent(ctx, types.NewEventVaultReconcile(
		vaultAddr.String(),
		principalInTvv,
		sdk.NewCoin(denom, principalTvvAfter),
		vault.CurrentInterestRate,
		periodDuration,
		actualInterest,
	))

	return nil
}

// PerformVaultFeeTransfer computes and collects the AUM technology fee
// from the vault's principal marker account using its configured AumFeeBips.
//
// The fee is calculated based on the **Gross TVV** (the literal sum of all assets in the marker)
// and collected in the vault's underlying asset.
//
// This method implements a "collect-what-is-available" strategy: it attempts to transfer
// the total outstanding fee (accrued + previously unpaid), but caps the collection at
// the principal marker's current underlying-asset balance. Any uncollected remainder is
// recorded in OutstandingAumFee to be retried during the next reconciliation.
//
// A rejected fee transfer is treated the same way as an insufficient balance: the error is
// logged, the full fee stays in OutstandingAumFee, and the fee period still advances. This
// keeps an uncollectable fee (for example a restricted underlying whose fee collector lost its
// required attribute) from failing reconciliation and bricking every vault operation. The
// outstanding total is capped at the gross TVV, so an uncollectable fee's excess is forfeited.
//
// An EventVaultFeeCollected is emitted upon success.
func (k Keeper) PerformVaultFeeTransfer(ctx sdk.Context, vault *types.VaultAccount) error {
	currentBlockTime := ctx.BlockTime().Unix()
	if currentBlockTime <= vault.FeePeriodStart {
		return nil
	}

	tvv, err := k.GetTVV(ctx, *vault)
	if err != nil {
		return fmt.Errorf("failed to get TVV: %w", err)
	}

	newFeePayment, err := k.CalculateAccruedAUMFeePayment(ctx, *vault, tvv)
	if err != nil {
		return fmt.Errorf("failed to calculate accrued AUM fee payment: %w", err)
	}

	carriedOutstanding := vault.OutstandingAumFee.Amount
	if carriedOutstanding.IsZero() && newFeePayment.Amount.IsZero() {
		vault.FeePeriodStart = currentBlockTime
		return nil
	}

	totalOutstandingAmount, excessForfeited := capAumFeeLiability(carriedOutstanding, newFeePayment.Amount, tvv)
	if excessForfeited {
		k.getLogger(ctx).Error("outstanding AUM fee exceeds gross vault value, capping and forfeiting the excess",
			"vault", vault.GetAddress().String(),
			"carried_outstanding", vault.OutstandingAumFee.String(),
			"accrued_fee", newFeePayment.String(),
			"gross_tvv", sdk.NewCoin(vault.UnderlyingAsset, tvv).String(),
		)
	}
	totalOutstanding := sdk.NewCoin(vault.UnderlyingAsset, totalOutstandingAmount)

	provlabsAddr, err := k.GetAUMFeeAddress(ctx)
	if err != nil {
		return fmt.Errorf("failed to get AUM fee address: %w", err)
	}

	principalAddress := vault.PrincipalMarkerAddress()
	balance := k.BankKeeper.GetBalance(ctx, principalAddress, vault.UnderlyingAsset)

	toCollect := totalOutstanding
	if balance.Amount.LT(totalOutstanding.Amount) {
		toCollect = balance
	}

	if !toCollect.IsZero() {
		if err = k.sendAUMFee(ctx, vault, provlabsAddr, toCollect); err != nil {
			k.getLogger(ctx).Error("failed to transfer AUM fee, leaving it outstanding",
				"vault", vault.GetAddress().String(),
				"recipient", provlabsAddr.String(),
				"fee", toCollect.String(),
				"err", err,
			)
			toCollect = sdk.NewCoin(vault.UnderlyingAsset, sdkmath.ZeroInt())
		}
		if err = k.adjustTotalValue(ctx, *vault, toCollect.Amount.Neg()); err != nil {
			return fmt.Errorf("failed to record collected AUM fee value: %w", err)
		}
	}

	periodDuration := currentBlockTime - vault.FeePeriodStart
	remainingOutstanding, err := totalOutstanding.SafeSub(toCollect)
	if err != nil {
		return fmt.Errorf("failed to subtract collected %s from outstanding AUM fee %s: %w", toCollect, totalOutstanding, err)
	}
	vault.OutstandingAumFee = remainingOutstanding
	vault.FeePeriodStart = currentBlockTime

	k.emitEvent(ctx, types.NewEventVaultFeeCollected(
		vault.GetAddress().String(),
		toCollect,
		totalOutstanding,
		sdk.NewCoin(vault.UnderlyingAsset, tvv),
		vault.OutstandingAumFee,
		periodDuration,
	))

	return nil
}

// capAumFeeLiability adds the newly accrued fee to the balance carried from prior periods, bounded
// by the vault's gross TVV, and reports whether any excess was forfeited to honor that bound.
func capAumFeeLiability(carried, accrued, grossTVV sdkmath.Int) (sdkmath.Int, bool) {
	boundedCarried := sdkmath.MinInt(carried, grossTVV)
	boundedAccrued := sdkmath.MinInt(accrued, grossTVV.Sub(boundedCarried))
	return boundedCarried.Add(boundedAccrued), boundedCarried.LT(carried) || boundedAccrued.LT(accrued)
}

// sendAUMFee transfers the fee from the vault's principal marker to the fee collector inside a
// cache context, so a rejected transfer leaves no partial state behind for the caller to unwind.
func (k Keeper) sendAUMFee(ctx sdk.Context, vault *types.VaultAccount, recipient sdk.AccAddress, fee sdk.Coin) error {
	cacheCtx, write := ctx.CacheContext()
	if err := k.BankKeeper.SendCoins(
		markertypes.WithTransferAgents(cacheCtx, vault.GetAddress()),
		vault.PrincipalMarkerAddress(),
		recipient,
		sdk.NewCoins(fee),
	); err != nil {
		return err
	}
	write()
	return nil
}

// CanPayInterestDuration determines whether the vault can fulfill the projected
// interest payment/refund over the given duration based on current reserves and principal TVV.
//
// Interest is checked against vault reserves (positive interest) or principal
// marker underlying balance (negative interest).
//
// It returns true only if interest checks pass.
func (k Keeper) CanPayInterestDuration(ctx sdk.Context, vault *types.VaultAccount, duration int64) (bool, error) {
	if duration <= 0 {
		return true, nil
	}

	underlyingDenom := vault.UnderlyingAsset
	vaultAddr := vault.GetAddress()
	principalAddr := vault.PrincipalMarkerAddress()

	principalTvv, err := k.GetTVV(ctx, *vault)
	if err != nil {
		return false, fmt.Errorf("failed to get TVV: %w", err)
	}
	if principalTvv.IsZero() {
		return true, nil
	}

	principalCoin := sdk.NewCoin(underlyingDenom, principalTvv)
	interestEarned, err := interest.CalculateInterestEarned(principalCoin, vault.CurrentInterestRate, duration)
	if err != nil {
		return false, fmt.Errorf("failed to calculate interest: %w", err)
	}

	if !interestEarned.IsZero() {
		if interestEarned.IsPositive() {
			reserves := k.BankKeeper.GetBalance(ctx, vaultAddr, underlyingDenom)
			if reserves.Amount.LT(interestEarned) {
				return false, nil
			}
		} else if interestEarned.IsNegative() {
			principalUnderlying := k.BankKeeper.GetBalance(ctx, principalAddr, underlyingDenom)
			owed := interestEarned.Abs()
			if principalUnderlying.Amount.LT(owed) {
				return false, nil
			}
		}
	}

	return true, nil
}

// UpdateInterestRates sets the vault's current and desired interest rates and emits
// an EventVaultInterestChange. The modified account is persisted via the auth keeper.
func (k Keeper) UpdateInterestRates(ctx sdk.Context, vault *types.VaultAccount, currentRate, desiredRate string) error {
	event := types.NewEventVaultInterestChange(vault.GetAddress().String(), currentRate, desiredRate)
	vault.CurrentInterestRate = currentRate
	vault.DesiredInterestRate = desiredRate
	if err := k.SetVaultAccount(ctx, vault); err != nil {
		return fmt.Errorf("failed to update vault account: %w", err)
	}
	k.emitEvent(ctx, event)
	return nil
}

// CalculateAccruedInterest calculates the interest that would have accrued for the vault
// from its PeriodStart to the current block time, based on the provided principal.
// It returns the interest amount (which can be negative) and does not mutate state.
func (k Keeper) CalculateAccruedInterest(ctx sdk.Context, vault types.VaultAccount, principal sdk.Coin) (sdkmath.Int, error) {
	if vault.CurrentInterestRate == "" || vault.PeriodStart == 0 {
		return sdkmath.ZeroInt(), nil
	}
	duration := ctx.BlockTime().Unix() - vault.PeriodStart
	if duration <= 0 {
		return sdkmath.ZeroInt(), nil
	}
	return interest.CalculateInterestEarned(principal, vault.CurrentInterestRate, duration)
}

// CalculateAccruedAUMFee calculates the AUM fees that would have accrued for the vault
// from its FeePeriodStart to the current block time, based on the provided total assets.
// It returns the fee amount in the underlying asset and does not mutate state.
func (k Keeper) CalculateAccruedAUMFee(ctx sdk.Context, vault types.VaultAccount, totalAssets sdkmath.Int) (sdkmath.Int, error) {
	if vault.FeePeriodStart == 0 {
		return sdkmath.ZeroInt(), nil
	}
	duration := ctx.BlockTime().Unix() - vault.FeePeriodStart
	if duration <= 0 {
		return sdkmath.ZeroInt(), nil
	}
	return interest.CalculateAUMFee(totalAssets, vault.AumFeeBips, duration)
}

// CalculateAccruedAUMFeePayment calculates the AUM fees that would have accrued for the vault
// from its FeePeriodStart to the current block time, as a coin in the vault's underlying asset.
func (k Keeper) CalculateAccruedAUMFeePayment(ctx sdk.Context, vault types.VaultAccount, totalAssets sdkmath.Int) (sdk.Coin, error) {
	feeUnderlying, err := k.CalculateAccruedAUMFee(ctx, vault, totalAssets)
	if err != nil {
		return sdk.Coin{}, fmt.Errorf("failed to calculate accrued AUM fee: %w", err)
	}
	return sdk.NewCoin(vault.UnderlyingAsset, feeUnderlying), nil
}

// CalculateVaultTotalAssets returns the total value of the vault's assets, including the interest
// that would have accrued from PeriodStart to the current block time, and subtracting the
// AUM fees accrued since FeePeriodStart, without mutating state.
//
// VALUATION LOGIC (Net TVV): This method subtracts the **OutstandingAumFee** from the gross total
// to ensure share pricing (NAV) reflects the actual equity owned by shareholders, excluding
// vault liabilities.
//
// If no rate is set or accrual has not started, it returns the provided principal unchanged.
func (k Keeper) CalculateVaultTotalAssets(ctx sdk.Context, vault *types.VaultAccount, principal sdk.Coin) (sdkmath.Int, error) {
	interestEarned, err := k.CalculateAccruedInterest(ctx, *vault, principal)
	if err != nil {
		return sdkmath.Int{}, fmt.Errorf("error calculating interest: %w", err)
	}
	estimated := principal.Amount.Add(interestEarned)

	feeAccrued, err := k.CalculateAccruedAUMFee(ctx, *vault, estimated)
	if err != nil {
		return sdkmath.Int{}, fmt.Errorf("error calculating AUM fee: %w", err)
	}
	estimated = estimated.Sub(feeAccrued)

	estimated = estimated.Sub(vault.OutstandingAumFee.Amount)

	if estimated.IsNegative() {
		estimated = sdkmath.ZeroInt()
	}

	return estimated, nil
}

// handleVaultInterestTimeouts checks vaults with expired interest periods and reconciles or disables them.
// It uses a safe "collect-then-mutate" pattern to comply with the SDK iterator contract.
// At most limit due entries are visited per block; the remainder stays queued for later blocks.
// Paused vaults are dequeued rather than skipped so they cannot hold the front of the queue.
func (k Keeper) handleVaultInterestTimeouts(ctx sdk.Context, limit int) error {
	now := ctx.BlockTime().Unix()

	var keysToProcess []collections.Pair[uint64, sdk.AccAddress]
	var pausedKeys []collections.Pair[uint64, sdk.AccAddress]

	visited := 0
	err := k.PayoutTimeoutQueue.WalkDue(ctx, now, func(timeout uint64, addr sdk.AccAddress) (bool, error) {
		if visited == limit {
			return true, nil
		}
		visited++
		vault, ok := k.tryGetVault(ctx, addr)
		if ok && vault.Paused {
			pausedKeys = append(pausedKeys, collections.Join(timeout, addr))
			return false, nil
		}
		keysToProcess = append(keysToProcess, collections.Join(timeout, addr))
		return false, nil
	})
	if err != nil {
		return fmt.Errorf("walk failed: %w", err)
	}

	for _, key := range pausedKeys {
		timeoutUnix := int64(key.K1()) //nolint:gosec // G115: queue key is a bounded unix-second timestamp.
		addr := key.K2()
		if err := k.PayoutTimeoutQueue.Dequeue(ctx, timeoutUnix, addr); err != nil {
			k.getLogger(ctx).Error("failed to dequeue paused vault from payout timeout queue", "vault", addr.String(), "err", err)
		}
	}

	for _, key := range keysToProcess {
		timeoutUnix := int64(key.K1()) //nolint:gosec // G115: queue key is a bounded unix-second timestamp.
		addr := key.K2()

		vault, ok := k.tryGetVault(ctx, addr)
		if !ok {
			// clean up queue if vault no longer exists
			_ = k.PayoutTimeoutQueue.Dequeue(ctx, timeoutUnix, addr)
			continue
		}

		periodDuration := timeoutUnix - vault.PeriodStart
		if periodDuration < 0 {
			periodDuration = now - vault.PeriodStart
		}

		canPay, err := k.CanPayInterestDuration(ctx, vault, periodDuration)
		if err != nil {
			k.getLogger(ctx).Error("failed to check payout ability, rescheduling", "vault", addr.String(), "err", err)
			k.reschedulePayoutTimeout(ctx, vault, timeoutUnix)
			continue
		}

		if !canPay {
			k.retireDepletedVault(ctx, vault, timeoutUnix)
			continue
		}

		if err := k.atomicallyReconcileInterest(ctx, vault, timeoutUnix); err != nil {
			k.getLogger(ctx).Error("failed to reconcile interest atomically, rescheduling", "vault", addr.String(), "err", err)
			k.reschedulePayoutTimeout(ctx, vault, timeoutUnix)
			continue
		}
	}

	return nil
}

// retireDepletedVault zeroes the current interest rate of a due vault that can no longer cover its
// payout window, preserving the desired rate, and dequeues the timeout it was walked under in the same
// atomic write. A failure leaves the timeout queued as it was found rather than rescheduling it, since
// a reschedule drops the entry before re-filing it.
func (k Keeper) retireDepletedVault(ctx sdk.Context, vault *types.VaultAccount, walkedTimeout int64) {
	cacheCtx, write := ctx.CacheContext()
	v := vault.Clone()

	if err := k.UpdateInterestRates(cacheCtx, v, types.ZeroInterestRate, v.DesiredInterestRate); err != nil {
		k.getLogger(ctx).Error("failed to update interest rates for depleted vault, leaving its timeout queued", "vault", v.GetAddress().String(), "err", err)
		return
	}

	if err := k.PayoutTimeoutQueue.Dequeue(cacheCtx, walkedTimeout, v.GetAddress()); err != nil {
		k.getLogger(ctx).Error("CRITICAL: failed to dequeue interest timeout for depleted vault, leaving its timeout queued", "vault", v.GetAddress().String(), "err", err)
		return
	}

	write()
}

// atomicallyReconcileInterest performs the interest transfer, dequeues the current
// timeout, and enqueues the next period timeout within a single atomic cache context.
// If any step fails, the entire operation is reverted.
//
// walkedTimeout is the key the entry was found under. It can differ from the vault's recorded
// timeout, so both are dequeued and no entry is left behind to stay due forever.
//
// A settled interest accrual moves the total vault value, so the mirrored share NAV is
// republished before the cache context is written.
func (k Keeper) atomicallyReconcileInterest(ctx sdk.Context, vault *types.VaultAccount, walkedTimeout int64) error {
	cacheCtx, write := ctx.CacheContext()
	v := vault.Clone()
	interestAccrued := interestPeriodElapsed(v, cacheCtx.BlockTime().Unix())

	if err := k.PerformVaultInterestTransfer(cacheCtx, v); err != nil {
		return fmt.Errorf("failed to perform vault interest transfer: %w", err)
	}

	if interestAccrued {
		k.refreshShareNav(cacheCtx, v)
	}

	if err := k.PayoutTimeoutQueue.Dequeue(cacheCtx, walkedTimeout, v.GetAddress()); err != nil {
		return fmt.Errorf("failed to dequeue walked payout timeout: %w", err)
	}

	if err := k.SafeEnqueuePayoutTimeout(cacheCtx, v); err != nil {
		return fmt.Errorf("failed to reset interest period: %w", err)
	}

	write()
	*vault = *v
	return nil
}

// reschedulePayoutTimeout pushes a vault's payout (interest) timeout to the next window.
// This is used when a reconciliation attempt fails due to transient errors, preventing
// block-to-block retries.
//
// NOTE: This preserves the PeriodStart to ensure accrued interest is not lost.
func (k Keeper) reschedulePayoutTimeout(ctx sdk.Context, vault *types.VaultAccount, oldTimeout int64) {
	if err := k.ReschedulePayoutTimeout(ctx, vault, oldTimeout); err != nil {
		k.getLogger(ctx).Error("failed to reschedule payout timeout", "vault", vault.GetAddress().String(), "err", err)
	}
}

// tryGetVault returns the vault if found, or false if the vault is missing or invalid.
// It should only be used in BeginBlocker/EndBlocker or migration logic where failure is non-critical.
func (k Keeper) tryGetVault(ctx sdk.Context, addr sdk.AccAddress) (*types.VaultAccount, bool) {
	vault, err := k.GetVault(ctx, addr)
	if err != nil {
		k.getLogger(ctx).Error("failed to get vault", "address", addr.String(), "error", err)
		return nil, false
	}
	if vault == nil {
		k.getLogger(ctx).Error("vault not found", "address", addr.String())
		return nil, false
	}
	return vault, true
}

// handleReconciledVaults advances vaults out of the payout verification set with a safe
// "collect-then-mutate" pattern, visiting at most limit entries per block, resuming where the previous
// block stopped, and removing paused vaults without processing them. A set entry is the vault's retry
// token, cleared only in the same atomic write that transitions it. Only a Walk failure is returned.
func (k Keeper) handleReconciledVaults(ctx sdk.Context, limit int) error {
	var keysToProcess []sdk.AccAddress
	var pausedKeys []sdk.AccAddress

	visited := 0
	var lastVisited sdk.AccAddress
	err := k.PayoutVerificationSet.Walk(ctx, k.payoutVerificationSweepRange(ctx), func(addr sdk.AccAddress) (bool, error) {
		if visited == limit {
			return true, nil
		}
		visited++
		lastVisited = addr
		v, ok := k.tryGetVault(ctx, addr)
		if ok && v.Paused {
			pausedKeys = append(pausedKeys, addr)
			return false, nil
		}
		keysToProcess = append(keysToProcess, addr)
		return false, nil
	})
	if err != nil {
		return fmt.Errorf("walk failed: %w", err)
	}

	if visited < limit {
		lastVisited = nil
	}
	k.setPayoutVerificationCursor(ctx, lastVisited)

	for _, addr := range pausedKeys {
		if err := k.PayoutVerificationSet.Remove(ctx, addr); err != nil {
			k.getLogger(ctx).Error("failed to remove paused vault from payout verification set", "vault", addr.String(), "err", err)
		}
	}

	for _, addr := range keysToProcess {
		k.transitionVerifiedVault(ctx, addr)
	}

	return nil
}

// payoutVerificationSweepRange resumes the verification walk after the entry the previous block
// stopped on, so entries retained by a failed transition cannot monopolize the per-block budget: every
// entry is reached within one sweep of the set no matter how many ahead of it keep failing. An
// unreadable or exhausted cursor starts a fresh sweep from the beginning of the set.
func (k Keeper) payoutVerificationSweepRange(ctx sdk.Context) *collections.Range[sdk.AccAddress] {
	sweep := new(collections.Range[sdk.AccAddress])

	cursor, err := k.PayoutVerificationCursor.Get(ctx)
	if err != nil {
		if !errors.Is(err, collections.ErrNotFound) {
			k.getLogger(ctx).Error("failed to read payout verification cursor, restarting the sweep", "err", err)
		}
		return sweep
	}
	if len(cursor) == 0 {
		return sweep
	}

	return sweep.StartExclusive(cursor)
}

// setPayoutVerificationCursor records the entry the next sweep resumes after. A nil address means the
// sweep reached the end of the set, so the next one starts over.
func (k Keeper) setPayoutVerificationCursor(ctx sdk.Context, addr sdk.AccAddress) {
	if err := k.PayoutVerificationCursor.Set(ctx, addr); err != nil {
		k.getLogger(ctx).Error("failed to record the payout verification cursor", "err", err)
	}
}

// transitionVerifiedVault moves one verified vault to its next accrual state: payable vaults are
// promoted into the PayoutTimeoutQueue, depleted vaults have their current rate zeroed, and a vault
// whose forecast errors is deferred to the next timeout window. An entry whose account is gone can
// never be transitioned, so it is dropped rather than re-walked forever; an account that is present but
// unreadable keeps its entry, since a decode failure could otherwise strand a live vault.
func (k Keeper) transitionVerifiedVault(ctx sdk.Context, addr sdk.AccAddress) {
	vault, err := k.GetVault(ctx, addr)
	if err != nil {
		k.getLogger(ctx).Error("CRITICAL: payout verification entry has an unreadable vault, leaving it in the set", "vault", addr.String(), "err", err)
		return
	}
	if vault == nil {
		k.getLogger(ctx).Error("CRITICAL: payout verification entry has no vault account, removing the orphaned entry", "vault", addr.String())
		if removeErr := k.PayoutVerificationSet.Remove(ctx, addr); removeErr != nil {
			k.getLogger(ctx).Error("CRITICAL: failed to remove orphaned payout verification entry, retrying next block", "vault", addr.String(), "err", removeErr)
		}
		return
	}

	canPay, err := k.CanPayInterestDuration(ctx, vault, AutoReconcilePayoutDuration)
	if err != nil {
		k.getLogger(ctx).Error("failed to check payout ability, deferring to the next timeout window", "vault", addr.String(), "err", err)
		k.deferPayoutVerification(ctx, vault)
		return
	}

	if canPay {
		k.promotePayableVault(ctx, vault)
		return
	}

	k.demoteDepletedVault(ctx, vault)
}

// promotePayableVault enqueues the next payout timeout for a vault that remains payable and clears its
// verification entry in the same atomic write, so a failed enqueue leaves the vault queued for
// verification on a later block.
func (k Keeper) promotePayableVault(ctx sdk.Context, vault *types.VaultAccount) {
	cacheCtx, write := ctx.CacheContext()
	v := vault.Clone()

	if err := k.SafeEnqueuePayoutTimeout(cacheCtx, v); err != nil {
		k.getLogger(ctx).Error("failed to enqueue timeout, leaving vault in the payout verification set", "vault", v.GetAddress().String(), "err", err)
		return
	}

	if err := k.PayoutVerificationSet.Remove(cacheCtx, v.GetAddress()); err != nil {
		k.getLogger(ctx).Error("CRITICAL: failed to remove promoted vault from the payout verification set, retrying next block", "vault", v.GetAddress().String(), "err", err)
		return
	}

	write()
}

// demoteDepletedVault zeroes the current interest rate of a vault that cannot cover the forecast payout
// window, preserving the desired rate, and clears its verification entry in the same atomic write. A
// failed rate update keeps the entry so the vault is revisited on a later block.
func (k Keeper) demoteDepletedVault(ctx sdk.Context, vault *types.VaultAccount) {
	cacheCtx, write := ctx.CacheContext()
	v := vault.Clone()

	if err := k.UpdateInterestRates(cacheCtx, v, types.ZeroInterestRate, v.DesiredInterestRate); err != nil {
		k.getLogger(ctx).Error("failed to update interest rates, leaving vault in the payout verification set", "vault", v.GetAddress().String(), "err", err)
		return
	}

	if err := k.PayoutVerificationSet.Remove(cacheCtx, v.GetAddress()); err != nil {
		k.getLogger(ctx).Error("CRITICAL: failed to remove depleted vault from the payout verification set, retrying next block", "vault", v.GetAddress().String(), "err", err)
		return
	}

	write()
}

// deferPayoutVerification files a vault whose payout forecast could not be computed at the next timeout
// window, preserving PeriodStart, and clears its verification entry in the same atomic write. The
// time-keyed queue bounds its retries to one per window rather than one per block; a failed deferral
// keeps the entry.
func (k Keeper) deferPayoutVerification(ctx sdk.Context, vault *types.VaultAccount) {
	cacheCtx, write := ctx.CacheContext()
	v := vault.Clone()

	if err := k.ReschedulePayoutTimeout(cacheCtx, v, v.PeriodTimeout); err != nil {
		k.getLogger(ctx).Error("failed to defer payout verification, leaving vault in the payout verification set", "vault", v.GetAddress().String(), "err", err)
		return
	}

	if err := k.PayoutVerificationSet.Remove(cacheCtx, v.GetAddress()); err != nil {
		k.getLogger(ctx).Error("CRITICAL: failed to remove deferred vault from the payout verification set, retrying next block", "vault", v.GetAddress().String(), "err", err)
		return
	}

	write()
}

// handleVaultFeeTimeouts checks vaults with expired fee periods and reconciles them.
// It uses a safe "collect-then-mutate" pattern to comply with the SDK iterator contract.
// At most limit due entries are visited per block; the remainder stays queued for later blocks.
// Paused vaults are dequeued rather than skipped so they cannot hold the front of the queue.
func (k Keeper) handleVaultFeeTimeouts(ctx sdk.Context, limit int) error {
	now := ctx.BlockTime().Unix()

	var keysToProcess []collections.Pair[uint64, sdk.AccAddress]
	var pausedKeys []collections.Pair[uint64, sdk.AccAddress]

	visited := 0
	err := k.FeeTimeoutQueue.WalkDue(ctx, now, func(timeout uint64, addr sdk.AccAddress) (bool, error) {
		if visited == limit {
			return true, nil
		}
		visited++
		vault, ok := k.tryGetVault(ctx, addr)
		if ok && vault.Paused {
			pausedKeys = append(pausedKeys, collections.Join(timeout, addr))
			return false, nil
		}
		keysToProcess = append(keysToProcess, collections.Join(timeout, addr))
		return false, nil
	})
	if err != nil {
		return fmt.Errorf("walk failed: %w", err)
	}

	for _, key := range pausedKeys {
		timeoutUnix := int64(key.K1()) //nolint:gosec // G115: queue key is a bounded unix-second timestamp.
		addr := key.K2()
		if err := k.FeeTimeoutQueue.Dequeue(ctx, timeoutUnix, addr); err != nil {
			k.getLogger(ctx).Error("failed to dequeue paused vault from fee timeout queue", "vault", addr.String(), "err", err)
		}
	}

	for _, key := range keysToProcess {
		timeoutUnix := int64(key.K1()) //nolint:gosec // G115: queue key is a bounded unix-second timestamp.
		addr := key.K2()

		vault, ok := k.tryGetVault(ctx, addr)
		if !ok {
			// clean up queue if vault no longer exists
			_ = k.FeeTimeoutQueue.Dequeue(ctx, timeoutUnix, addr)
			continue
		}

		if err := k.atomicallyReconcileFee(ctx, vault, timeoutUnix); err != nil {
			k.getLogger(ctx).Error("failed to collect AUM fee atomically, rescheduling", "vault", addr.String(), "err", err)
			k.rescheduleFeeTimeout(ctx, vault, timeoutUnix)
			continue
		}
	}

	return nil
}

// atomicallyReconcileFee performs the AUM fee collection, dequeues the current
// fee timeout, and enqueues the next fee period timeout within a single atomic
// cache context. If any step fails, the entire operation is reverted.
//
// walkedTimeout is the key the entry was found under. It can differ from the vault's recorded
// fee timeout, so both are dequeued and no entry is left behind to stay due forever.
//
// An accrued fee moves the net total vault value, so the mirrored share NAV is republished before
// the cache context is written.
func (k Keeper) atomicallyReconcileFee(ctx sdk.Context, vault *types.VaultAccount, walkedTimeout int64) error {
	cacheCtx, write := ctx.CacheContext()
	v := vault.Clone()
	netValueMoved := feeAccrualMovesNetValue(v, cacheCtx.BlockTime().Unix())

	if err := k.PerformVaultFeeTransfer(cacheCtx, v); err != nil {
		return fmt.Errorf("failed to perform vault fee transfer: %w", err)
	}

	if netValueMoved {
		k.refreshShareNav(cacheCtx, v)
	}

	if err := k.FeeTimeoutQueue.Dequeue(cacheCtx, walkedTimeout, v.GetAddress()); err != nil {
		return fmt.Errorf("failed to dequeue walked fee timeout: %w", err)
	}

	if err := k.SafeEnqueueFeeTimeout(cacheCtx, v); err != nil {
		return fmt.Errorf("failed to reset fee period: %w", err)
	}

	write()
	*vault = *v
	return nil
}

// rescheduleFeeTimeout pushes a vault's fee timeout to the next window.
// This is used when a fee collection attempt fails due to transient errors
// (e.g. missing NAVs), preventing block-to-block retries.
//
// NOTE: This preserves the FeePeriodStart to ensure accrued fees are not lost.
func (k Keeper) rescheduleFeeTimeout(ctx sdk.Context, vault *types.VaultAccount, oldTimeout int64) {
	if err := k.RescheduleFeeTimeout(ctx, vault, oldTimeout); err != nil {
		k.getLogger(ctx).Error("failed to reschedule fee timeout", "vault", vault.GetAddress().String(), "err", err)
	}
}
