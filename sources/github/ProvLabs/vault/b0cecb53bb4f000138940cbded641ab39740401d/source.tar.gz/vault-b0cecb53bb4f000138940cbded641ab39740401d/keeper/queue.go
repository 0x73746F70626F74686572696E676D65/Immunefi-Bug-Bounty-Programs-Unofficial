package keeper

import (
	"fmt"

	"github.com/provlabs/vault/interest"
	"github.com/provlabs/vault/types"

	sdk "github.com/cosmos/cosmos-sdk/types"
)

const (
	// AutoReconcileTimeout is the duration (in seconds) that a vault is considered
	// recently reconciled and is exempt from automatic interest checks.
	AutoReconcileTimeout = 20 * interest.SecondsPerHour
)

// SafeAddPayoutVerification clears any existing timeout entry for the given vault (if any),
// sets the vault's period start to the current block time, clears the period timeout,
// persists the vault, and stores the vault in the PayoutVerificationSet.
//
// This ensures a vault is not present in both the verification set and timeout queues
// at the same time. Typically called after enabling interest or completing a
// reconciliation so the next accrual cycle begins cleanly.
func (k Keeper) SafeAddPayoutVerification(ctx sdk.Context, vault *types.VaultAccount) error {
	cacheCtx, write := ctx.CacheContext()
	currentBlockTime := cacheCtx.BlockTime().Unix()
	v := vault.Clone()

	if err := k.PayoutTimeoutQueue.Dequeue(cacheCtx, v.PeriodTimeout, v.GetAddress()); err != nil {
		return fmt.Errorf("failed to dequeue existing payout timeout for vault %s: %w", v.GetAddress(), err)
	}

	v.PeriodStart = currentBlockTime
	v.PeriodTimeout = 0
	if err := k.SetVaultAccount(cacheCtx, v); err != nil {
		k.getLogger(cacheCtx).Error("failed to set vault while adding to verification set", "vault", v.GetAddress().String(), "err", err)
		return fmt.Errorf("failed to persist vault period for vault %s: %w", v.GetAddress(), err)
	}

	if err := k.PayoutVerificationSet.Set(cacheCtx, v.GetAddress()); err != nil {
		return fmt.Errorf("failed to set payout verification for vault %s: %w", v.GetAddress(), err)
	}

	write()
	*vault = *v
	return nil
}

// SafeEnqueuePayoutTimeout clears any existing timeout entry for the given vault (if any),
// sets the vault's period start to the current block time, sets a new period timeout
// at (now + AutoReconcileTimeout), persists the vault, and enqueues the timeout entry
// in the PayoutTimeoutQueue.
//
// This ensures a vault is not present in both the timeout and verification queues
// at the same time. Typically called after a vault has been marked as payable so it
// will be revisited after the auto-reconcile window.
func (k Keeper) SafeEnqueuePayoutTimeout(ctx sdk.Context, vault *types.VaultAccount) error {
	cacheCtx, write := ctx.CacheContext()
	v := vault.Clone()

	if err := k.PayoutTimeoutQueue.Dequeue(cacheCtx, v.PeriodTimeout, v.GetAddress()); err != nil {
		return fmt.Errorf("failed to dequeue existing payout timeout for vault %s: %w", v.GetAddress(), err)
	}

	currentBlockTime := cacheCtx.BlockTime().Unix()
	v.PeriodStart = currentBlockTime
	v.PeriodTimeout = currentBlockTime + AutoReconcileTimeout
	if err := k.SetVaultAccount(cacheCtx, v); err != nil {
		k.getLogger(cacheCtx).Error("failed to set vault while enqueueing payout timeout", "vault", v.GetAddress().String(), "err", err)
		return fmt.Errorf("failed to persist vault period for vault %s: %w", v.GetAddress(), err)
	}

	if err := k.PayoutTimeoutQueue.Enqueue(cacheCtx, v.PeriodTimeout, v.GetAddress()); err != nil {
		return fmt.Errorf("failed to enqueue payout timeout for vault %s at %d: %w", v.GetAddress(), v.PeriodTimeout, err)
	}

	write()
	*vault = *v
	return nil
}

// SafeEnqueueFeeTimeout clears any existing fee timeout entry for the given vault (if any),
// sets the vault's fee period start to the current block time, sets a new fee period timeout
// at (now + AutoReconcileTimeout), persists the vault, and enqueues the timeout entry
// in the FeeTimeoutQueue.
func (k Keeper) SafeEnqueueFeeTimeout(ctx sdk.Context, vault *types.VaultAccount) error {
	cacheCtx, write := ctx.CacheContext()
	v := vault.Clone()

	if err := k.FeeTimeoutQueue.Dequeue(cacheCtx, v.FeePeriodTimeout, v.GetAddress()); err != nil {
		return fmt.Errorf("failed to dequeue existing fee timeout for vault %s: %w", v.GetAddress(), err)
	}

	currentBlockTime := cacheCtx.BlockTime().Unix()
	v.FeePeriodStart = currentBlockTime
	v.FeePeriodTimeout = currentBlockTime + AutoReconcileTimeout
	if err := k.SetVaultAccount(cacheCtx, v); err != nil {
		k.getLogger(cacheCtx).Error("failed to set vault while enqueueing fee timeout", "vault", v.GetAddress().String(), "err", err)
		return fmt.Errorf("failed to persist vault fee period for vault %s: %w", v.GetAddress(), err)
	}

	if err := k.FeeTimeoutQueue.Enqueue(cacheCtx, v.FeePeriodTimeout, v.GetAddress()); err != nil {
		return fmt.Errorf("failed to enqueue fee timeout for vault %s at %d: %w", v.GetAddress(), v.FeePeriodTimeout, err)
	}

	write()
	*vault = *v
	return nil
}

// haltVaultAccrual removes a vault from the payout timeout queue, the fee timeout queue, and the
// payout verification set, and clears its interest and fee accrual periods. Removing at pause time
// keeps a paused vault from occupying a per-block visit slot at all; the blocker processors also
// dequeue any paused entry they encounter, so this is the cheap path rather than the only safeguard.
// Both periods are re-armed on unpause, so the paused span accrues no interest and no AUM fees.
//
// Removal uses the vault's recorded timeouts as keys so it stays constant-time; auto-pause calls
// this from the EndBlocker, where scanning a queue would grow block time with the backlog. An entry
// filed under any other key is left for the blocker processors to dequeue when it comes due.
//
// Like applyPausedState, this does not persist the account; the caller chooses SetVaultAccount
// (validated) or SetAccount (validation-skipped).
func (k Keeper) haltVaultAccrual(ctx sdk.Context, vault *types.VaultAccount) error {
	vaultAddr := vault.GetAddress()
	cacheCtx, write := ctx.CacheContext()

	if err := k.PayoutTimeoutQueue.Dequeue(cacheCtx, vault.PeriodTimeout, vaultAddr); err != nil {
		return fmt.Errorf("failed to dequeue payout timeout for vault %s: %w", vaultAddr, err)
	}

	if err := k.FeeTimeoutQueue.Dequeue(cacheCtx, vault.FeePeriodTimeout, vaultAddr); err != nil {
		return fmt.Errorf("failed to dequeue fee timeout for vault %s: %w", vaultAddr, err)
	}

	if err := k.PayoutVerificationSet.Remove(cacheCtx, vaultAddr); err != nil {
		return fmt.Errorf("failed to remove payout verification entry for vault %s: %w", vaultAddr, err)
	}

	write()

	vault.PeriodStart = 0
	vault.PeriodTimeout = 0
	vault.FeePeriodStart = 0
	vault.FeePeriodTimeout = 0
	return nil
}

// ReschedulePayoutTimeout updates a vault's payout timeout to the next window (now + AutoReconcileTimeout)
// without resetting the PeriodStart. This is used for transient reconciliation failures to
// preserve accrued interest while preventing block-to-block retry loops.
//
// The dequeue shares the atomic write, so a failure leaves the vault queued under its old timeout.
func (k Keeper) ReschedulePayoutTimeout(ctx sdk.Context, vault *types.VaultAccount, oldTimeout int64) error {
	cacheCtx, write := ctx.CacheContext()
	v := vault.Clone()

	if err := k.PayoutTimeoutQueue.Dequeue(cacheCtx, oldTimeout, v.GetAddress()); err != nil {
		return fmt.Errorf("failed to dequeue old payout timeout: %w", err)
	}

	currentBlockTime := cacheCtx.BlockTime().Unix()
	v.PeriodTimeout = currentBlockTime + AutoReconcileTimeout

	if err := k.SetVaultAccount(cacheCtx, v); err != nil {
		return fmt.Errorf("failed to persist vault while rescheduling payout timeout: %w", err)
	}

	if err := k.PayoutTimeoutQueue.Enqueue(cacheCtx, v.PeriodTimeout, v.GetAddress()); err != nil {
		return fmt.Errorf("failed to enqueue payout timeout while rescheduling: %w", err)
	}

	write()
	*vault = *v
	return nil
}

// RescheduleFeeTimeout updates a vault's fee timeout to the next window (now + AutoReconcileTimeout)
// without resetting the FeePeriodStart. This is used for transient reconciliation failures to
// preserve accrued fees while preventing block-to-block retry loops.
//
// The dequeue shares the atomic write, so a failure leaves the vault queued under its old timeout.
func (k Keeper) RescheduleFeeTimeout(ctx sdk.Context, vault *types.VaultAccount, oldTimeout int64) error {
	cacheCtx, write := ctx.CacheContext()
	v := vault.Clone()

	if err := k.FeeTimeoutQueue.Dequeue(cacheCtx, oldTimeout, v.GetAddress()); err != nil {
		return fmt.Errorf("failed to dequeue old fee timeout: %w", err)
	}

	currentBlockTime := cacheCtx.BlockTime().Unix()
	v.FeePeriodTimeout = currentBlockTime + AutoReconcileTimeout

	if err := k.SetVaultAccount(cacheCtx, v); err != nil {
		return fmt.Errorf("failed to persist vault while rescheduling fee timeout: %w", err)
	}

	if err := k.FeeTimeoutQueue.Enqueue(cacheCtx, v.FeePeriodTimeout, v.GetAddress()); err != nil {
		return fmt.Errorf("failed to enqueue fee timeout while rescheduling: %w", err)
	}

	write()
	*vault = *v
	return nil
}
