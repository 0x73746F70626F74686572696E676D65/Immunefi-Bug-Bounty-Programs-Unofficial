package keeper

import (
	"errors"
	"fmt"
	"strings"

	"github.com/provlabs/vault/types"
	"github.com/provlabs/vault/utils"

	sdkmath "cosmossdk.io/math"

	sdk "github.com/cosmos/cosmos-sdk/types"
	authtypes "github.com/cosmos/cosmos-sdk/x/auth/types"

	markertypes "github.com/provenance-io/provenance/x/marker/types"
)

const (
	Supply          = 0
	NoFixedSupply   = false
	NoForceTransfer = false
	NoGovControl    = false
)

// VaultAttributer provides the attributes for creating a new vault.
type VaultAttributer interface {
	GetAdmin() string
	GetShareDenom() string
	GetUnderlyingAsset() string
	GetWithdrawalDelaySeconds() uint64
	GetMinSwapInValue() string
	GetMinSwapOutValue() string
	GetMaxSwapInValue() string
	GetMaxSwapOutValue() string
}

// CreateVault creates a new vault and its corresponding share marker atomically.
//
// The process involves:
//  1. Creating and persisting a new VaultAccount and its lookup entries.
//  2. Initializing the fee timeout queue for the new vault.
//  3. Creating, finalizing, and activating a restricted marker for the vault's shares.
//  4. Performing a pre-flight check against the principal path by calling
//     SendRestrictionFn with vault.PrincipalMarkerAddress() to ensure the fee
//     collection address is permissioned to receive the underlying asset.
//
// All steps are performed within a cache context. If any step fails, including the
// pre-flight permission check, all state changes are discarded to prevent the creation
// of inconsistent or "orphan" vaults.
func (k *Keeper) CreateVault(ctx sdk.Context, attributes VaultAttributer) (*types.VaultAccount, error) {
	underlying := attributes.GetUnderlyingAsset()
	withdrawalDelay := attributes.GetWithdrawalDelaySeconds()
	minSwapIn := attributes.GetMinSwapInValue()
	minSwapOut := attributes.GetMinSwapOutValue()
	maxSwapIn := attributes.GetMaxSwapInValue()
	maxSwapOut := attributes.GetMaxSwapOutValue()

	if err := types.ValidateNotIBCDenom(underlying); err != nil {
		return nil, fmt.Errorf("invalid underlying asset: %w", err)
	}

	underlyingAssetAddr, err := markertypes.MarkerAddress(underlying)
	if err != nil {
		return nil, fmt.Errorf("failed to get underlying asset marker address: %w", err)
	}
	if found := k.MarkerKeeper.IsMarkerAccount(ctx, underlyingAssetAddr); !found {
		return nil, fmt.Errorf("underlying asset marker %q not found", underlying)
	}

	cacheCtx, write := ctx.CacheContext()

	vault, err := k.createVaultAccount(cacheCtx, attributes.GetAdmin(), attributes.GetShareDenom(), underlying, withdrawalDelay, minSwapIn, minSwapOut, maxSwapIn, maxSwapOut)
	if err != nil {
		return nil, fmt.Errorf("failed to create vault account: %w", err)
	}

	if _, err = k.createVaultMarker(cacheCtx, vault.GetAddress(), vault.TotalShares.Denom); err != nil {
		return nil, fmt.Errorf("failed to create vault marker: %w", err)
	}

	if err = k.InitTotalValue(cacheCtx, vault); err != nil {
		return nil, fmt.Errorf("failed to seed vault total value: %w", err)
	}

	provlabsAddr, err := k.GetAUMFeeAddress(cacheCtx)
	if err != nil {
		return nil, fmt.Errorf("failed to get AUM fee address: %w", err)
	}

	if recipient, err := k.MarkerKeeper.SendRestrictionFn(
		markertypes.WithTransferAgents(cacheCtx, vault.GetAddress()),
		vault.PrincipalMarkerAddress(),
		provlabsAddr,
		sdk.NewCoins(sdk.NewInt64Coin(vault.UnderlyingAsset, 1)),
	); err != nil {
		return nil, fmt.Errorf("fee account %s is not permissioned to receive underlying asset %s: %w", provlabsAddr.String(), vault.UnderlyingAsset, err)
	} else if !recipient.Equals(provlabsAddr) {
		return nil, fmt.Errorf("effective recipient %s differs from expected fee collector %s for underlying asset %s", recipient.String(), provlabsAddr.String(), vault.UnderlyingAsset)
	}

	write()
	k.emitEvent(ctx, types.NewEventVaultCreated(vault))
	return vault, nil
}

// GetVault returns the vault account for the given address.
// This function will return nil if nothing exists at this address.
func (k Keeper) GetVault(ctx sdk.Context, address sdk.AccAddress) (*types.VaultAccount, error) {
	mac := k.AuthKeeper.GetAccount(ctx, address)
	if mac != nil {
		macc, ok := mac.(*types.VaultAccount)
		if !ok {
			return nil, fmt.Errorf("account at %s is not a vault account", address.String())
		}
		return macc, nil
	}
	return nil, nil
}

// getVault returns the vault at the given address, or an error if it does not exist.
func (k Keeper) getVault(ctx sdk.Context, addr sdk.AccAddress) (*types.VaultAccount, error) {
	vault, err := k.GetVault(ctx, addr)
	if err != nil {
		return nil, fmt.Errorf("failed to get vault: %w", err)
	}
	if vault == nil {
		return nil, fmt.Errorf("vault not found: %s", addr.String())
	}
	return vault, nil
}

// availableBridgeMintCapacity returns the share supply the bridge may still mint locally
func (k Keeper) availableBridgeMintCapacity(ctx sdk.Context, vault *types.VaultAccount) (sdk.Coin, error) {
	currentSupply := k.BankKeeper.GetSupply(ctx, vault.TotalShares.Denom)
	available, err := vault.TotalShares.SafeSub(currentSupply)
	if err != nil {
		return sdk.Coin{}, fmt.Errorf("share supply invariant violated for vault %s: total shares %s is below local supply %s: %w",
			vault.Address, vault.TotalShares, currentSupply, err)
	}
	return available, nil
}

// createVaultAccount creates and stores a new vault account and initializes its fee tracking.
// It verifies that the vault address is available and not already associated with another account.
func (k *Keeper) createVaultAccount(ctx sdk.Context, admin, shareDenom, underlyingAsset string, withdrawalDelay uint64, minSwapIn, minSwapOut, maxSwapIn, maxSwapOut string) (*types.VaultAccount, error) {
	vaultAddr := types.GetVaultAddress(shareDenom)

	params, err := k.Params.Get(ctx)
	if err != nil {
		params = types.DefaultParams()
	}

	vault := types.NewVaultAccount(
		authtypes.NewBaseAccountWithAddress(vaultAddr),
		admin,
		shareDenom,
		underlyingAsset,
		withdrawalDelay,
		params.DefaultAumFeeBips,
		minSwapIn,
		minSwapOut,
		maxSwapIn,
		maxSwapOut,
	)

	if err := vault.Validate(); err != nil {
		return nil, fmt.Errorf("failed to validate vault account: %w", err)
	}

	if err := k.SetVaultLookup(ctx, vault); err != nil {
		return nil, fmt.Errorf("failed to store new vault: %w", err)
	}

	vaultAcc := k.AuthKeeper.GetAccount(ctx, vault.GetAddress())
	if vaultAcc != nil {
		if _, ok := vaultAcc.(types.VaultAccountI); ok {
			return nil, fmt.Errorf("vault address already exists for %s", vaultAddr.String())
		}
		return nil, fmt.Errorf("account at %s already exists and is not a vault account", vaultAddr.String())
	}
	vaultAcc = k.AuthKeeper.NewAccount(ctx, vault).(types.VaultAccountI)
	k.AuthKeeper.SetAccount(ctx, vaultAcc)

	if err := k.SafeEnqueueFeeTimeout(ctx, vault); err != nil {
		return nil, fmt.Errorf("failed to enqueue initial fee timeout: %w", err)
	}

	return vault, nil
}

// createVaultMarker creates, finalizes, and activates the deposit-protected marker for the vault's share denomination.
func (k *Keeper) createVaultMarker(ctx sdk.Context, markerManager sdk.AccAddress, shareDenom string) (*markertypes.MarkerAccount, error) {
	vaultShareMarkerAddress, err := markertypes.MarkerAddress(shareDenom)
	if err != nil {
		return nil, fmt.Errorf("failed to get vault share marker address: %w", err)
	}

	if found := k.MarkerKeeper.IsMarkerAccount(ctx, vaultShareMarkerAddress); found {
		return nil, fmt.Errorf("a marker with the share denomination %q already exists", shareDenom)
	}

	baseAccount := authtypes.NewBaseAccountWithAddress(vaultShareMarkerAddress)
	newMarker := markertypes.NewMarkerAccount(
		baseAccount,
		sdk.NewInt64Coin(shareDenom, Supply),
		markerManager,
		[]markertypes.AccessGrant{
			{
				Address: markerManager.String(),
				Permissions: []markertypes.Access{
					markertypes.Access_Mint,
					markertypes.Access_Burn,
					markertypes.Access_Withdraw,
					markertypes.Access_Deposit,
				},
			},
		},
		markertypes.StatusProposed,
		markertypes.MarkerType_Coin,
		NoFixedSupply,
		NoGovControl,
		NoForceTransfer,
		[]string{},
	)
	newMarker.SetRequireDepositAccess(true)

	if err := k.MarkerKeeper.AddFinalizeAndActivateMarker(ctx, newMarker); err != nil {
		return nil, fmt.Errorf("failed to create and activate vault share marker: %w", err)
	}

	return newMarker, nil
}

// SwapIn handles the process of depositing underlying assets into a vault in
// exchange for newly minted vault shares.
//
// It performs the following steps:
//  1. Retrieves the vault configuration for the given vault address.
//  2. Verifies that swap-in is enabled for the vault.
//  3. Reconciles the vault (interest and AUM fees) if due.
//  4. Resolves the vault share marker address.
//  5. Validates that the provided underlying asset matches the vault’s configured underlying denom.
//  6. Rejects the deposit when the depositor is on the underlying marker’s deny list.
//  7. Calculates the number of shares to mint based on the deposit, current supply, and vault balance,
//     rejecting deposits that round down to zero shares, or that price against a zero net vault
//     value with shares outstanding, before any funds move.
//  8. Mints the computed amount of shares under the vault’s admin authority.
//  9. Withdraws the minted shares from the vault to the recipient address.
//
// 10. Sends the underlying asset from the recipient to the vault’s marker account.
// 11. Emits a SwapIn event with metadata for indexing and audit.
//
// Returns the minted share amount on success, or an error if any step fails.
func (k *Keeper) SwapIn(ctx sdk.Context, vaultAddr, recipient sdk.AccAddress, asset sdk.Coin) (*sdk.Coin, error) {
	vault, err := k.GetVault(ctx, vaultAddr)
	if err != nil {
		return nil, fmt.Errorf("failed to get vault: %w", err)
	}
	if vault == nil {
		return nil, fmt.Errorf("vault with address %v not found", vaultAddr.String())
	}

	if vault.Paused {
		return nil, fmt.Errorf("vault %s is paused", vaultAddr.String())
	}

	if !vault.SwapInEnabled {
		return nil, fmt.Errorf("swaps are not enabled for vault %s", vaultAddr.String())
	}

	if err = vault.ValidateAcceptedCoin(asset); err != nil {
		return nil, fmt.Errorf("failed to validate asset: %w", err)
	}

	if err = k.checkDepositDenyList(ctx, recipient, asset.Denom); err != nil {
		return nil, fmt.Errorf("failed to swap in: %w", err)
	}

	accept, reason, err := k.AllowSwapInAmount(ctx, asset, *vault)
	if err != nil {
		return nil, fmt.Errorf("swap in amount not allowed: %w", err)
	}
	if !accept {
		return nil, fmt.Errorf("failed to swap in: swap in amount %s %s for vault %s", asset.String(), reason, vaultAddr.String())
	}

	if err = k.reconcileVault(ctx, vault); err != nil {
		return nil, fmt.Errorf("failed to reconcile vault: %w", err)
	}

	principalAddress := vault.PrincipalMarkerAddress()

	shares, err := k.ConvertDepositToShares(ctx, *vault, asset)
	if err != nil {
		if errors.Is(err, utils.ErrZeroAssetsWithSharesOutstanding) {
			return nil, fmt.Errorf("vault %s cannot accept deposits: net vault value is zero with %s outstanding: %w", vaultAddr.String(), vault.TotalShares.String(), err)
		}
		return nil, fmt.Errorf("failed to calculate shares from assets: %w", err)
	}

	if err := shares.Validate(); err != nil {
		return nil, fmt.Errorf("failed to validate shares: %w", err)
	}

	if !shares.Amount.IsPositive() {
		return nil, fmt.Errorf("deposit %s is too small to mint shares for vault %s at the current share price", asset, vaultAddr.String())
	}

	if err := k.MarkerKeeper.MintCoin(ctx, vault.GetAddress(), shares); err != nil {
		return nil, fmt.Errorf("failed to mint shares: %w", err)
	}

	vault.TotalShares = vault.TotalShares.Add(shares)
	if err := k.SetVaultAccount(ctx, vault); err != nil {
		return nil, fmt.Errorf("failed to update vault account: %w", err)
	}

	if err := k.MarkerKeeper.WithdrawCoins(ctx, vault.GetAddress(), recipient, shares.Denom, sdk.NewCoins(shares)); err != nil {
		return nil, fmt.Errorf("failed to withdraw shares: %w", err)
	}

	if err := k.BankKeeper.SendCoins(markertypes.WithBypass(ctx), recipient, principalAddress, sdk.NewCoins(asset)); err != nil {
		return nil, fmt.Errorf("failed to send asset to principal: %w", err)
	}

	if err := k.adjustTotalValue(ctx, *vault, asset.Amount); err != nil {
		return nil, fmt.Errorf("failed to record swap-in value: %w", err)
	}

	k.emitEvent(ctx, types.NewEventSwapIn(vaultAddr.String(), recipient.String(), asset, shares))
	return &shares, nil
}

// checkDepositDenyList rejects a depositor that is on the deny list of the deposited denom's marker.
// Deposits move funds with a marker bypass, which skips the deny-list enforcement in SendRestrictionFn.
func (k *Keeper) checkDepositDenyList(ctx sdk.Context, depositor sdk.AccAddress, denom string) error {
	markerAddr, err := markertypes.MarkerAddress(denom)
	if err != nil {
		return fmt.Errorf("failed to get marker address for %s: %w", denom, err)
	}
	if k.MarkerKeeper.IsSendDeny(ctx, markerAddr, depositor) {
		return fmt.Errorf("%s is on deny list for sending restricted marker %s", depositor, denom)
	}
	return nil
}

// checkPayoutRestrictions performs a pre-flight check to ensure a user is permissioned to receive
// the assets from a vault's principal marker. This prevents queueing a withdrawal that is guaranteed
// to fail later due to marker transfer restrictions (e.g., required attributes).
func (k *Keeper) checkPayoutRestrictions(ctx sdk.Context, vault *types.VaultAccount, owner sdk.AccAddress, assets sdk.Coin) error {
	_, err := k.MarkerKeeper.SendRestrictionFn(
		markertypes.WithTransferAgents(ctx, vault.GetAddress()),
		vault.PrincipalMarkerAddress(),
		owner,
		sdk.NewCoins(assets),
	)
	if err != nil {
		return fmt.Errorf("failed to pass send restrictions test: %w", err)
	}
	return nil
}

// SwapOut validates a swap-out request, calculates the resulting assets in the vault's
// underlying asset, escrows the user's shares, and enqueues a pending withdrawal request
// to be processed by the EndBlocker.
// It returns the unique ID of the newly queued request.
//
// The vault is reconciled before pricing so the swap-out limits gate the current net valuation.
// The limits are checked only at admission; the payout is re-priced at maturity without a second check.
func (k *Keeper) SwapOut(ctx sdk.Context, vaultAddr, owner sdk.AccAddress, shares sdk.Coin) (uint64, error) {
	vault, err := k.GetVault(ctx, vaultAddr)
	if err != nil {
		return 0, fmt.Errorf("failed to get vault: %w", err)
	}
	if vault == nil {
		return 0, fmt.Errorf("vault with address %v not found", vaultAddr.String())
	}

	if vault.Paused {
		return 0, fmt.Errorf("vault %s is paused", vaultAddr.String())
	}

	if !vault.SwapOutEnabled {
		return 0, fmt.Errorf("swaps are not enabled for vault %s", vaultAddr.String())
	}

	if shares.Denom != vault.TotalShares.Denom {
		return 0, fmt.Errorf("swap out denom must be share denom %v : %v", shares.Denom, vault.TotalShares.Denom)
	}

	if err = k.reconcileVault(ctx, vault); err != nil {
		return 0, fmt.Errorf("failed to reconcile vault: %w", err)
	}

	assets, err := k.ConvertSharesToRedeemCoin(ctx, *vault, shares.Amount)
	if err != nil {
		return 0, fmt.Errorf("failed to calculate assets from shares: %w", err)
	}

	accept, reason, err := k.AllowSwapOutAmount(ctx, assets, *vault)
	if err != nil {
		return 0, fmt.Errorf("swap out amount not allowed: %w", err)
	}
	if !accept {
		return 0, fmt.Errorf("failed to swap out: swap out amount %s %s for vault %s", assets.String(), reason, vaultAddr.String())
	}

	if err = k.checkPayoutRestrictions(ctx, vault, owner, assets); err != nil {
		return 0, fmt.Errorf("failed to check payout restrictions: %w", err)
	}

	payoutTime, err := vault.SwapOutPayoutTime(ctx.BlockTime().Unix())
	if err != nil {
		return 0, fmt.Errorf("failed to determine swap out payout time: %w", err)
	}

	if err = k.BankKeeper.SendCoins(ctx, owner, vault.GetAddress(), sdk.NewCoins(shares)); err != nil {
		return 0, fmt.Errorf("failed to escrow shares: %w", err)
	}

	pendingReq := types.NewPendingSwapOut(owner, vaultAddr, shares, vault.UnderlyingAsset)
	requestID, err := k.PendingSwapOutQueue.Enqueue(ctx, payoutTime, &pendingReq)
	if err != nil {
		return 0, fmt.Errorf("failed to enqueue pending swap out request: %w", err)
	}

	k.emitEvent(ctx, types.NewEventSwapOutRequested(vaultAddr.String(), owner.String(), vault.UnderlyingAsset, shares, requestID))
	return requestID, nil
}

// SetSwapInEnable updates the SwapInEnabled flag for a given vault. It updates the vault account in the state and
// emits an EventToggleSwapIn event.
func (k *Keeper) SetSwapInEnable(ctx sdk.Context, vault *types.VaultAccount, enabled bool) error {
	vault.SwapInEnabled = enabled
	if err := k.SetVaultAccount(ctx, vault); err != nil {
		return fmt.Errorf("failed to set vault account: %w", err)
	}
	k.emitEvent(ctx, types.NewEventToggleSwapIn(vault.Address, vault.Admin, enabled))
	return nil
}

// SetSwapOutEnable updates the SwapOutEnabled flag for a given vault. It updates the vault account in the state and
// emits an EventToggleSwapOut event.
func (k *Keeper) SetSwapOutEnable(ctx sdk.Context, vault *types.VaultAccount, enabled bool) error {
	vault.SwapOutEnabled = enabled
	if err := k.SetVaultAccount(ctx, vault); err != nil {
		return fmt.Errorf("failed to set vault account: %w", err)
	}
	k.emitEvent(ctx, types.NewEventToggleSwapOut(vault.Address, vault.Admin, enabled))
	return nil
}

// SetMinInterestRate sets the minimum interest rate for a vault.
// An empty string disables the minimum rate check.
func (k *Keeper) SetMinInterestRate(ctx sdk.Context, vault *types.VaultAccount, minRate string) error {
	if err := k.ValidateInterestRateLimits(minRate, vault.MaxInterestRate); err != nil {
		return fmt.Errorf("failed to validate interest rate limits: %w", err)
	}
	if vault.MinInterestRate == minRate {
		return nil
	}
	vault.MinInterestRate = minRate
	if err := k.SetVaultAccount(ctx, vault); err != nil {
		return fmt.Errorf("failed to set vault account: %w", err)
	}
	k.emitEvent(ctx, types.NewEventMinInterestRateUpdated(vault.Address, vault.Admin, minRate))
	return nil
}

// SetMaxInterestRate sets the maximum interest rate for a vault.
// An empty string disables the maximum rate check.
func (k *Keeper) SetMaxInterestRate(ctx sdk.Context, vault *types.VaultAccount, maxRate string) error {
	if err := k.ValidateInterestRateLimits(vault.MinInterestRate, maxRate); err != nil {
		return fmt.Errorf("failed to validate interest rate limits: %w", err)
	}
	if vault.MaxInterestRate == maxRate {
		return nil
	}
	vault.MaxInterestRate = maxRate
	if err := k.SetVaultAccount(ctx, vault); err != nil {
		return fmt.Errorf("failed to set vault account: %w", err)
	}
	k.emitEvent(ctx, types.NewEventMaxInterestRateUpdated(vault.Address, vault.Admin, maxRate))
	return nil
}

// ValidateInterestRateLimits checks that the provided minimum and maximum interest
// rates are valid decimal values, that neither exceeds the MaxAbsInterestRate
// ceiling in magnitude, and that the minimum rate is not greater than the maximum
// rate. The magnitude ceiling stops an admin from configuring bounds large enough
// to overflow the e^(rt) interest math and panic inside the block hooks. Empty
// values are treated as unset and pass validation.
func (k Keeper) ValidateInterestRateLimits(minRateStr, maxRateStr string) error {
	var minRate, maxRate sdkmath.LegacyDec
	var err error
	var hasMin, hasMax bool

	if minRateStr != "" {
		minRate, err = sdkmath.LegacyNewDecFromStr(minRateStr)
		if err != nil {
			return fmt.Errorf("invalid min interest rate: %w", err)
		}
		if err = types.ValidateInterestRateMagnitude(minRate); err != nil {
			return fmt.Errorf("invalid min interest rate: %w", err)
		}
		hasMin = true
	}

	if maxRateStr != "" {
		maxRate, err = sdkmath.LegacyNewDecFromStr(maxRateStr)
		if err != nil {
			return fmt.Errorf("invalid max interest rate: %w", err)
		}
		if err := types.ValidateInterestRateMagnitude(maxRate); err != nil {
			return fmt.Errorf("invalid max interest rate: %w", err)
		}
		hasMax = true
	}

	if hasMin && hasMax {
		if minRate.GT(maxRate) {
			return fmt.Errorf("minimum interest rate %s cannot be greater than maximum interest rate %s", minRate, maxRate)
		}
	}

	return nil
}

func (k *Keeper) SetWithdrawalDelay(ctx sdk.Context, vault *types.VaultAccount, delaySeconds uint64, authority string) error {
	if vault.WithdrawalDelaySeconds == delaySeconds {
		return nil
	}
	vault.WithdrawalDelaySeconds = delaySeconds
	if err := k.SetVaultAccount(ctx, vault); err != nil {
		return fmt.Errorf("failed to set vault account: %w", err)
	}
	k.emitEvent(ctx, types.NewEventWithdrawalDelayUpdated(vault.Address, authority, delaySeconds))
	return nil
}

// applyPausedState performs the in-memory paused-state transition shared by the two
// emergency pause paths, forcePauseVault and autoPauseVault, so both stop interest
// accrual identically. Both waive the strict reconcile and valuation gate, so it marks the
// pause forced; pausedBy is types.NoPauseAuthority when no signer initiated the pause. It
// intentionally does not persist the account: the caller chooses SetVaultAccount (validated)
// or SetAccount (validation-skipped) depending on whether the vault may be in an invalid state.
func (k *Keeper) applyPausedState(ctx sdk.Context, vault *types.VaultAccount, reason, pausedBy string, pausedBalance sdk.Coin) {
	if pausedBalance.Amount.IsNil() {
		pausedBalance.Amount = sdkmath.ZeroInt()
	}
	vault.PausedBalance = pausedBalance
	vault.Paused = true
	vault.PausedReason = reason
	vault.PausedBy = pausedBy
	vault.PausedForced = true
	vault.CurrentInterestRate = types.ZeroInterestRate
	k.emitEvent(ctx, types.NewEventVaultInterestChange(vault.GetAddress().String(), types.ZeroInterestRate, vault.DesiredInterestRate))
}

// resumeVault clears the paused state, re-arms interest and fee accrual from the current
// block time so the paused span is never charged, and emits EventVaultUnpaused. Shared by
// UnpauseVault and RepriceVault; the caller authorizes the resume.
//
// The total vault value it reports is read, not re-derived: everything done during the pause
// folded its own change into the materialized total as it happened.
func (k *Keeper) resumeVault(ctx sdk.Context, vault *types.VaultAccount, authority string) error {
	if err := k.UpdateInterestRates(ctx, vault, vault.DesiredInterestRate, vault.DesiredInterestRate); err != nil {
		return fmt.Errorf("failed to update interest rates: %w", err)
	}

	vault.PausedBalance = sdk.Coin{}
	vault.Paused = false
	vault.PausedReason = ""
	vault.PausedBy = ""
	vault.PausedForced = false
	if err := k.SetVaultAccount(ctx, vault); err != nil {
		return fmt.Errorf("failed to set vault account: %w", err)
	}

	tvv, err := k.totalValue(ctx, *vault)
	if err != nil {
		return fmt.Errorf("failed to read total vault value on unpause: %w", err)
	}

	if err := k.SafeAddPayoutVerification(ctx, vault); err != nil {
		return fmt.Errorf("failed to enqueue vault payout verification: %w", err)
	}

	if err := k.SafeEnqueueFeeTimeout(ctx, vault); err != nil {
		return fmt.Errorf("failed to enqueue vault fee timeout: %w", err)
	}

	k.emitEvent(ctx, types.NewEventVaultUnpaused(vault.Address, authority, sdk.NewCoin(vault.UnderlyingAsset, tvv)))

	return nil
}

// autoPauseVault sets a vault's state to paused, records the reason, persists it to state,
// and emits an EventVaultPaused. This function is intended to be called in response to a
// critical, unrecoverable error for a specific vault. The provided reason should be a stable,
// hard-coded string suitable for persistence and later auditing.
func (k *Keeper) autoPauseVault(ctx sdk.Context, vault *types.VaultAccount, reason string) {
	k.getLogger(ctx).Error(
		"Auto-pausing vault due to critical error",
		"vault_address", vault.GetAddress().String(),
		"reason", reason,
	)

	tvv, err := k.GetNetTVV(ctx, *vault)
	if err != nil {
		k.getLogger(ctx).Error("Failed to get net TVV in underlying asset", "vault_address", vault.GetAddress().String(), "error", err)
		tvv = sdkmath.ZeroInt()
	}

	k.applyPausedState(ctx, vault, reason, types.NoPauseAuthority, sdk.NewCoin(vault.UnderlyingAsset, tvv))

	if err := k.haltVaultAccrual(ctx, vault); err != nil {
		k.getLogger(ctx).Error("failed to halt vault accrual during auto-pause", "vault_address", vault.GetAddress().String(), "error", err)
	}

	k.AuthKeeper.SetAccount(ctx, vault) // Updating via SetAccount to skip validation since auto-pausing is triggered by invalid state

	k.emitEvent(ctx, types.NewEventVaultPaused(vault.GetAddress().String(), vault.GetAddress().String(), reason, vault.PausedBalance, true, ""))
}

// forcePauseVault performs an emergency, best-effort pause for the operator-initiated
// PauseVault path when Force is set. Unlike the strict pause it never aborts: a failed
// reconcile or valuation is logged and recorded rather than returned, and the frozen
// PausedBalance falls back to zero when valuation itself fails. Persistence is attempted
// first via the validated SetVaultAccount; if validation fails it falls back to the
// unvalidated SetAccount so an invalid-state vault can still be frozen, recording the
// failure so the resulting inconsistency saved to state is auditable. Every tolerated
// failure is joined and surfaced via EventVaultPaused.forced_error. It shares
// applyPausedState with autoPauseVault so both emergency pause paths perform an
// identical in-memory paused-state transition, and calls haltVaultAccrual so the frozen
// vault holds no reconciliation queue entries.
func (k *Keeper) forcePauseVault(ctx sdk.Context, vault *types.VaultAccount, authority, reason string) {
	var forcedErrors []string

	if err := k.reconcileVault(ctx, vault); err != nil {
		forcedErrors = append(forcedErrors, fmt.Sprintf("reconcile failed: %v", err))
		k.getLogger(ctx).Error(
			"reconcile failed before forced pause; pausing best-effort",
			"vault", vault.GetAddress().String(),
			"err", err,
		)
	}

	tvv, err := k.GetNetTVV(ctx, *vault)
	if err != nil {
		forcedErrors = append(forcedErrors, fmt.Sprintf("valuation failed: %v", err))
		k.getLogger(ctx).Error(
			"failed to value vault before forced pause; snapshotting zero paused balance",
			"vault", vault.GetAddress().String(),
			"err", err,
		)
		tvv = sdkmath.ZeroInt()
	}

	k.applyPausedState(ctx, vault, reason, authority, sdk.NewCoin(vault.UnderlyingAsset, tvv))

	if err := k.haltVaultAccrual(ctx, vault); err != nil {
		forcedErrors = append(forcedErrors, fmt.Sprintf("halt accrual failed: %v", err))
		k.getLogger(ctx).Error(
			"failed to halt vault accrual during forced pause; queue entries may remain",
			"vault", vault.GetAddress().String(),
			"err", err,
		)
	}

	if err := k.SetVaultAccount(ctx, vault); err != nil {
		forcedErrors = append(forcedErrors, fmt.Sprintf("set vault account failed: %v", err))
		k.getLogger(ctx).Error(
			"failed to validate and set vault account during forced pause; persisting without validation",
			"vault", vault.GetAddress().String(),
			"err", err,
		)
		k.AuthKeeper.SetAccount(ctx, vault)
	}

	forcedError := strings.Join(forcedErrors, "; ")
	k.emitEvent(ctx, types.NewEventVaultPaused(vault.GetAddress().String(), authority, reason, vault.PausedBalance, true, forcedError))
}

// UpdateVaultAUMFeeBips reconciles outstanding AUM fees for the provided VaultAccount
// before updating the stored fee rate (in basis points).
//
// This method ensures that all fees accrued under the old rate are accounted for
// before applying the new rate to future periods.
// It returns an error if the new bips value exceeds 10,000 (100%) or if reconciliation fails.
func (k *Keeper) UpdateVaultAUMFeeBips(ctx sdk.Context, vault *types.VaultAccount, bips uint32, authority string) error {
	if bips > 10_000 {
		return fmt.Errorf("invalid AUM fee bips: %d (max 10000)", bips)
	}

	if vault.AumFeeBips == bips {
		return nil
	}

	if err := k.reconcileVault(ctx, vault); err != nil {
		return fmt.Errorf("failed to reconcile before bips change: %w", err)
	}

	vault.AumFeeBips = bips
	if err := k.SetVaultAccount(ctx, vault); err != nil {
		return fmt.Errorf("failed to set vault account: %w", err)
	}

	k.emitEvent(ctx, types.NewEventVaultAUMFeeBipsUpdated(vault.Address, authority, bips))
	return nil
}

// SetMinSwapInValue updates the minimum swap-in value for a vault.
func (k *Keeper) SetMinSwapInValue(ctx sdk.Context, vault *types.VaultAccount, minSwapIn string, authority string) error {
	if err := types.ValidateSwapLimits(minSwapIn, vault.MaxSwapInValue); err != nil {
		return fmt.Errorf("failed to set MinSwapIn: %w", err)
	}
	if vault.MinSwapInValue == minSwapIn {
		return nil
	}
	vault.MinSwapInValue = minSwapIn
	if err := k.SetVaultAccount(ctx, vault); err != nil {
		return fmt.Errorf("failed to set vault account: %w", err)
	}
	k.emitEvent(ctx, types.NewEventMinSwapInValueUpdated(vault.Address, authority, minSwapIn))
	return nil
}

// SetMinSwapOutValue updates the minimum swap-out value for a vault.
func (k *Keeper) SetMinSwapOutValue(ctx sdk.Context, vault *types.VaultAccount, minSwapOut string, authority string) error {
	if err := types.ValidateSwapLimits(minSwapOut, vault.MaxSwapOutValue); err != nil {
		return fmt.Errorf("failed to set MinSwapOut: %w", err)
	}
	if vault.MinSwapOutValue == minSwapOut {
		return nil
	}
	vault.MinSwapOutValue = minSwapOut
	if err := k.SetVaultAccount(ctx, vault); err != nil {
		return fmt.Errorf("failed to set vault account: %w", err)
	}
	k.emitEvent(ctx, types.NewEventMinSwapOutValueUpdated(vault.Address, authority, minSwapOut))
	return nil
}

// SetMaxSwapInValue updates the maximum swap-in value for a vault.
func (k *Keeper) SetMaxSwapInValue(ctx sdk.Context, vault *types.VaultAccount, maxSwapIn string, authority string) error {
	if err := types.ValidateSwapLimits(vault.MinSwapInValue, maxSwapIn); err != nil {
		return fmt.Errorf("failed to set MaxSwapIn: %w", err)
	}
	if vault.MaxSwapInValue == maxSwapIn {
		return nil
	}
	vault.MaxSwapInValue = maxSwapIn
	if err := k.SetVaultAccount(ctx, vault); err != nil {
		return fmt.Errorf("failed to set vault account: %w", err)
	}
	k.emitEvent(ctx, types.NewEventMaxSwapInValueUpdated(vault.Address, authority, maxSwapIn))
	return nil
}

// SetMaxSwapOutValue updates the maximum swap-out value for a vault.
func (k *Keeper) SetMaxSwapOutValue(ctx sdk.Context, vault *types.VaultAccount, maxSwapOut string, authority string) error {
	if err := types.ValidateSwapLimits(vault.MinSwapOutValue, maxSwapOut); err != nil {
		return fmt.Errorf("failed to set MaxSwapOut: %w", err)
	}
	if vault.MaxSwapOutValue == maxSwapOut {
		return nil
	}
	vault.MaxSwapOutValue = maxSwapOut
	if err := k.SetVaultAccount(ctx, vault); err != nil {
		return fmt.Errorf("failed to set vault account: %w", err)
	}
	k.emitEvent(ctx, types.NewEventMaxSwapOutValueUpdated(vault.Address, authority, maxSwapOut))
	return nil
}

// AllowSwapInAmount checks whether a swap-in amount meets the minimum and maximum value requirements for a vault.
func (k *Keeper) AllowSwapInAmount(ctx sdk.Context, swapInAsset sdk.Coin, vault types.VaultAccount) (bool, string, error) {
	assetInUnderlying, err := k.ToUnderlyingAssetAmount(ctx, vault, swapInAsset)
	if err != nil {
		return false, "", fmt.Errorf("failed to convert swap in asset to underlying asset amount: %w", err)
	}

	return checkLimit(assetInUnderlying, vault.MinSwapInValue, vault.MaxSwapInValue)
}

// AllowSwapOutAmount checks whether a swap-out amount meets the minimum and maximum value requirements for a vault.
func (k *Keeper) AllowSwapOutAmount(ctx sdk.Context, assets sdk.Coin, vault types.VaultAccount) (bool, string, error) {
	assetInUnderlying, err := k.ToUnderlyingAssetAmount(ctx, vault, assets)
	if err != nil {
		return false, "", fmt.Errorf("failed to convert assets to underlying asset amount: %w", err)
	}

	return checkLimit(assetInUnderlying, vault.MinSwapOutValue, vault.MaxSwapOutValue)
}

// checkLimit compares an underlying asset amount against the configured min/max limits.
func checkLimit(amount sdkmath.Int, minStr, maxStr string) (bool, string, error) {
	if minStr != "" {
		minVal, ok := sdkmath.NewIntFromString(minStr)
		if !ok {
			return false, "", fmt.Errorf("failed to parse minimum limit: %s", minStr)
		}
		if !minVal.IsZero() && amount.LT(minVal) {
			return false, "is below the minimum required value", nil
		}
	}

	if maxStr != "" {
		maxVal, ok := sdkmath.NewIntFromString(maxStr)
		if !ok {
			return false, "", fmt.Errorf("failed to parse maximum limit: %s", maxStr)
		}
		if !maxVal.IsZero() && amount.GT(maxVal) {
			return false, "is above the maximum allowed value", nil
		}
	}

	return true, "", nil
}
