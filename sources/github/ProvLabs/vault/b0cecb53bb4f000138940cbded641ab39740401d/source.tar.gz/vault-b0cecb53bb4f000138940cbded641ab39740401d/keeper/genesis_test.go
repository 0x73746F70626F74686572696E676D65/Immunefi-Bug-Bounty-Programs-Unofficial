package keeper_test

import (
	"fmt"
	"math"
	"time"

	"cosmossdk.io/collections"
	sdkmath "cosmossdk.io/math"
	sdk "github.com/cosmos/cosmos-sdk/types"
	authtypes "github.com/cosmos/cosmos-sdk/x/auth/types"
	"github.com/google/uuid"
	metadatatypes "github.com/provenance-io/provenance/x/metadata/types"

	"github.com/provlabs/vault/keeper"
	"github.com/provlabs/vault/types"
)

func (s *TestSuite) TestVaultGenesis_InitAndExport() {
	shareDenom := "vaultshare"
	underlying := "undercoin"
	admin := s.adminAddr.String()
	vaultAddr := types.GetVaultAddress(shareDenom)

	vault := makeGenesisVaultAccount(shareDenom, underlying, admin)

	past := time.Now().Add(-5 * time.Minute).Unix()
	vault.PeriodTimeout = past

	genesis := &types.GenesisState{
		Params: types.DefaultParams(),
		Vaults: []types.VaultAccount{vault},
		PayoutTimeoutQueue: []types.QueueEntry{
			{Time: uint64(past), Addr: vaultAddr.String()},
		},
		PendingSwapOutQueue: types.PendingSwapOutQueue{
			LatestSequenceNumber: 55,
			Entries: []types.PendingSwapOutQueueEntry{
				{
					Time: 10000,
					Id:   1,
					SwapOut: types.PendingSwapOut{
						Owner:        admin,
						VaultAddress: vault.Address,
						RedeemDenom:  "ylds",
						Shares:       sdk.NewInt64Coin("vshares", 100),
						FailureCount: 3,
					},
				},
			},
		},
	}

	s.k.InitGenesis(s.ctx, genesis)
	s.ctx = s.ctx.WithBlockTime(time.Unix(past+60, 0))

	exported := s.k.ExportGenesis(s.ctx)
	s.Require().Len(exported.Vaults, 1, "exported genesis should contain exactly one vault")
	exp := exported.Vaults[0]
	s.Require().Equal(vault.GetAddress().String(), exp.GetAddress().String(), "exported vault address mismatch")
	s.Require().Equal(vault.Admin, exp.Admin, "exported vault admin mismatch")
	s.Require().Equal(vault.TotalShares, exp.TotalShares, "exported vault total shares mismatch")
	s.Require().Equal(vault.UnderlyingAsset, exp.UnderlyingAsset, "exported vault underlying asset mismatch")

	s.Require().Len(exported.PayoutTimeoutQueue, 1, "exported genesis should contain exactly one payout timeout entry")
	s.Require().Equal(vaultAddr.String(), exported.PayoutTimeoutQueue[0].Addr, "payout timeout entry address mismatch")
	s.Require().Equal(uint64(past), exported.PayoutTimeoutQueue[0].Time, "payout timeout entry time mismatch")

	got, err := s.k.GetVault(s.ctx, vaultAddr)
	s.Require().NoError(err, "failed to get vault after InitGenesis")
	s.Require().NotNil(got, "vault should not be nil after InitGenesis")
	s.Require().Equal(vaultAddr.String(), got.GetAddress().String(), "retrieved vault address mismatch")

	s.Require().Len(exported.PendingSwapOutQueue.Entries, 1, "exported genesis should contain exactly one pending swap out entry")
	s.Require().Equal(uint64(55), exported.PendingSwapOutQueue.LatestSequenceNumber, "pending swap out queue latest sequence number mismatch")
	s.Require().Equal(uint64(1), exported.PendingSwapOutQueue.Entries[0].Id, "pending swap out entry ID mismatch")
	s.Require().Equal(int64(10000), exported.PendingSwapOutQueue.Entries[0].Time, "pending swap out entry time mismatch")
	s.Require().Equal(admin, exported.PendingSwapOutQueue.Entries[0].SwapOut.Owner, "pending swap out entry owner mismatch")
	s.Require().Equal(vault.Address, exported.PendingSwapOutQueue.Entries[0].SwapOut.VaultAddress, "pending swap out entry vault address mismatch")
	s.Require().Equal("ylds", exported.PendingSwapOutQueue.Entries[0].SwapOut.RedeemDenom, "pending swap out entry redeem denom mismatch")
	s.Require().Equal(uint32(3), exported.PendingSwapOutQueue.Entries[0].SwapOut.FailureCount, "pending swap out entry failure count should survive a genesis round trip")
}

func (s *TestSuite) TestInitGenesis_PanicOnInvalidTimeout() {
	vaultAddr := types.GetVaultAddress("panic-vault").String()
	vault := makeGenesisVaultAccount("panic-vault", "undercoin", s.adminAddr.String())

	tests := []struct {
		name     string
		genState *types.GenesisState
		panicMsg string
	}{
		{
			name: "payout timeout exceeds max int64",
			genState: &types.GenesisState{
				Params: types.DefaultParams(),
				Vaults: []types.VaultAccount{
					func() types.VaultAccount {
						v := vault
						v.PeriodTimeout = math.MinInt64
						return v
					}(),
				},
				PayoutTimeoutQueue: []types.QueueEntry{
					{Time: uint64(math.MaxInt64) + 1, Addr: vaultAddr},
				},
			},
			panicMsg: fmt.Sprintf("invalid vault genesis state: payout timeout queue entry at index 0 has time %d which exceeds max int64", uint64(math.MaxInt64)+1),
		},
		{
			name: "fee timeout exceeds max int64",
			genState: &types.GenesisState{
				Params: types.DefaultParams(),
				Vaults: []types.VaultAccount{
					func() types.VaultAccount {
						v := vault
						v.FeePeriodTimeout = math.MinInt64
						return v
					}(),
				},
				FeeTimeoutQueue: []types.QueueEntry{
					{Time: uint64(math.MaxInt64) + 1, Addr: vaultAddr},
				},
			},
			panicMsg: fmt.Sprintf("invalid vault genesis state: fee timeout queue entry at index 0 has time %d which exceeds max int64", uint64(math.MaxInt64)+1),
		},
	}

	for _, tt := range tests {
		s.Run(tt.name, func() {
			s.SetupTest()
			s.Require().PanicsWithError(tt.panicMsg, func() {
				s.k.InitGenesis(s.ctx, tt.genState)
			})
		})
	}
}

func (s *TestSuite) TestVaultGenesis_RoundTrip_FeeTimeoutAndParams() {
	shareDenom := "vaultshare_fee"
	underlying := "under_fee"
	vaultAddr := types.GetVaultAddress(shareDenom)
	admin := s.adminAddr.String()
	aumFeeAddress := sdk.AccAddress{1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20}

	now := time.Now().Unix()
	future := now + 1000

	vault := makeGenesisVaultAccount(shareDenom, underlying, admin)
	vault.FeePeriodTimeout = future

	params := types.Params{
		TechFeeAddress:    aumFeeAddress.String(),
		DefaultAumFeeBips: 100,
	}

	genesis := &types.GenesisState{
		Vaults: []types.VaultAccount{vault},
		FeeTimeoutQueue: []types.QueueEntry{
			{Time: uint64(future), Addr: vaultAddr.String()},
		},
		Params: params,
	}

	s.k.InitGenesis(s.ctx, genesis)

	exported := s.k.ExportGenesis(s.ctx)
	s.Require().Len(exported.FeeTimeoutQueue, 1, "exported genesis should contain exactly one fee timeout entry")
	s.Require().Equal(vaultAddr.String(), exported.FeeTimeoutQueue[0].Addr, "fee timeout entry address mismatch")
	s.Require().Equal(uint64(future), exported.FeeTimeoutQueue[0].Time, "fee timeout entry time mismatch")
	s.Require().Equal(params, exported.Params, "exported Params mismatch")

	// Verify the AUM fee address was actually set in the keeper
	storedAddr, err := s.k.GetAUMFeeAddress(s.ctx)
	s.Require().NoError(err, "failed to get AUM fee address")
	s.Require().Equal(aumFeeAddress, storedAddr, "stored AUM fee address mismatch in keeper")
}

func (s *TestSuite) TestVaultGenesis_Params_RoundTrip() {
	techFeeAddress := sdk.AccAddress{1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20}

	tests := []struct {
		name   string
		params types.Params
	}{
		{
			name: "zero bips is a valid stored value, should survive export and re-import",
			params: types.Params{
				TechFeeAddress:    techFeeAddress.String(),
				DefaultAumFeeBips: 0,
			},
		},
		{
			name: "nonzero bips should survive export and re-import",
			params: types.Params{
				TechFeeAddress:    techFeeAddress.String(),
				DefaultAumFeeBips: 100,
			},
		},
		{
			name:   "default params should survive export and re-import",
			params: types.DefaultParams(),
		},
		{
			name: "gov-only vault creation should survive export and re-import",
			params: types.Params{
				TechFeeAddress:       techFeeAddress.String(),
				DefaultAumFeeBips:    100,
				GovOnlyVaultCreation: true,
			},
		},
	}

	for _, tc := range tests {
		s.Run(tc.name, func() {
			s.SetupTest()

			genesis := &types.GenesisState{Params: tc.params}
			s.k.InitGenesis(s.ctx, genesis)

			exported := s.k.ExportGenesis(s.ctx)
			s.Require().Equal(tc.params, exported.Params, "params should round-trip through InitGenesis and ExportGenesis unchanged")
		})
	}
}

func (s *TestSuite) TestVaultGenesis_RoundTrip_PastAndFutureTimeouts() {
	shareDenom1 := "vaultshare2"
	underlying1 := "under2"
	vaultAddr1 := types.GetVaultAddress(shareDenom1)

	shareDenom2 := "vaultshare3"
	underlying2 := "under3"
	vaultAddr2 := types.GetVaultAddress(shareDenom2)

	admin := s.adminAddr.String()

	now := time.Now()
	past := now.Add(-10 * time.Minute).Unix()
	future := now.Add(10 * time.Minute).Unix()

	vault1 := makeGenesisVaultAccount(shareDenom1, underlying1, admin)
	vault1.PeriodTimeout = past

	vault2 := makeGenesisVaultAccount(shareDenom2, underlying2, admin)
	vault2.PeriodTimeout = future

	genesis := &types.GenesisState{
		Params: types.DefaultParams(),
		Vaults: []types.VaultAccount{vault1, vault2},
		PayoutTimeoutQueue: []types.QueueEntry{
			{Time: uint64(past), Addr: vaultAddr1.String()},
			{Time: uint64(future), Addr: vaultAddr2.String()},
		},
		PendingSwapOutQueue: types.PendingSwapOutQueue{},
	}

	s.k.InitGenesis(s.ctx, genesis)
	s.ctx = s.ctx.WithBlockTime(now)

	exported := s.k.ExportGenesis(s.ctx)
	s.Require().Len(exported.PayoutTimeoutQueue, 2, "exported genesis should contain exactly two payout timeout entries")
}

func (s *TestSuite) TestVaultGenesis_InvalidTimeoutAddressPanics() {
	shareDenom := "vaultshare3"
	underlying := "under3"
	admin := s.adminAddr.String()

	now := uint64(time.Now().Unix())

	vault := makeGenesisVaultAccount(shareDenom, underlying, admin)
	vault.PeriodTimeout = int64(now)

	genesis := &types.GenesisState{
		Params: types.DefaultParams(),
		Vaults: []types.VaultAccount{vault},
		PayoutTimeoutQueue: []types.QueueEntry{
			{Time: now, Addr: "invalid-bech32"},
		},
		PendingSwapOutQueue: types.PendingSwapOutQueue{},
	}

	expectedPanic := "invalid vault genesis state: invalid payout timeout queue address at index 0: decoding bech32 failed: invalid separator index -1"
	s.Require().PanicsWithError(expectedPanic, func() { s.k.InitGenesis(s.ctx, genesis) }, "InitGenesis should panic on invalid timeout address")
}

func (s *TestSuite) TestVaultGenesis_ExistingAccountNumberCopied() {
	shareDenom := "vaultshare4"
	underlying := "under4"
	admin := s.adminAddr.String()
	vaultAddr := types.GetVaultAddress(shareDenom)

	existing := authtypes.NewBaseAccountWithAddress(vaultAddr)
	s.Require().NoError(existing.SetAccountNumber(999), "failed to set account number for existing account")
	s.k.AuthKeeper.SetAccount(s.ctx, existing)

	vault := makeGenesisVaultAccount(shareDenom, underlying, admin)

	genesis := &types.GenesisState{
		Params:              types.DefaultParams(),
		Vaults:              []types.VaultAccount{vault},
		PendingSwapOutQueue: types.PendingSwapOutQueue{},
	}

	s.k.InitGenesis(s.ctx, genesis)
	exported := s.k.ExportGenesis(s.ctx)
	s.Require().Len(exported.Vaults, 1, "exported genesis should contain exactly one vault")
	s.Require().Equal(uint64(999), exported.Vaults[0].GetAccountNumber(), "exported vault account number mismatch")
}

func (s *TestSuite) TestVaultGenesis_InitNilDoesNothing() {
	s.k.InitGenesis(s.ctx, nil)
	exported := s.k.ExportGenesis(s.ctx)
	s.Require().Len(exported.Vaults, 0, "exported genesis should contain zero vaults after nil InitGenesis")
	s.Require().Len(exported.PayoutTimeoutQueue, 0, "exported genesis should contain zero payout timeout entries after nil InitGenesis")
}

func (s *TestSuite) TestVaultGenesis_InitPanicsOnInvalidVault() {
	vaultAddr := sdk.AccAddress("badaddr")
	vault := types.VaultAccount{
		BaseAccount:         authtypes.NewBaseAccountWithAddress(vaultAddr),
		Admin:               "",
		TotalShares:         sdk.Coin{Denom: "invalid denom!", Amount: sdkmath.NewInt(0)},
		UnderlyingAsset:     "underX",
		PaymentDenom:        "underX",
		CurrentInterestRate: types.ZeroInterestRate,
		DesiredInterestRate: types.ZeroInterestRate,
	}
	genesis := &types.GenesisState{
		Params: types.DefaultParams(),
		Vaults: []types.VaultAccount{vault},
	}
	expectedPanic := "invalid vault genesis state: invalid vault at index 0: invalid admin address: empty address string is not allowed"
	s.Require().PanicsWithError(expectedPanic, func() { s.k.InitGenesis(s.ctx, genesis) }, "InitGenesis should panic on invalid vault")
}

func (s *TestSuite) TestVaultGenesis_InitEnforcesTotalSharesAtLeastLocalSupply() {
	shareDenom := "vaultshare"
	underlying := "undercoin"
	admin := s.adminAddr.String()
	vaultAddr := types.GetVaultAddress(shareDenom)
	localSupply := int64(150)

	tests := []struct {
		name          string
		totalShares   int64
		expectedPanic string
	}{
		{
			name:        "total shares above local supply leaves mint capacity",
			totalShares: 200,
		},
		{
			name:        "total shares equal to local supply leaves no mint capacity",
			totalShares: localSupply,
		},
		{
			name:        "total shares below local supply violates the invariant",
			totalShares: 100,
			expectedPanic: fmt.Sprintf("invalid vault %s in genesis: share supply invariant violated for vault %s: total shares %d%s is below local supply %d%s: negative coin amount: -%d%s",
				vaultAddr, vaultAddr, 100, shareDenom, localSupply, shareDenom, localSupply-100, shareDenom),
		},
	}

	for _, tc := range tests {
		s.Run(tc.name, func() {
			origCtx := s.ctx
			defer func() { s.ctx = origCtx }()
			s.ctx, _ = s.ctx.CacheContext()

			s.requireAddFinalizeAndActivateMarker(sdk.NewInt64Coin(shareDenom, localSupply), s.adminAddr)

			vault := makeGenesisVaultAccount(shareDenom, underlying, admin)
			vault.TotalShares = sdk.NewInt64Coin(shareDenom, tc.totalShares)
			genesis := &types.GenesisState{
				Params: types.DefaultParams(),
				Vaults: []types.VaultAccount{vault},
			}

			if tc.expectedPanic != "" {
				s.Require().PanicsWithError(tc.expectedPanic, func() { s.k.InitGenesis(s.ctx, genesis) },
					"InitGenesis should reject a vault whose total shares %d is below the local supply %d", tc.totalShares, localSupply)
				return
			}

			s.Require().NotPanics(func() { s.k.InitGenesis(s.ctx, genesis) },
				"InitGenesis should accept a vault whose total shares %d is at least the local supply %d", tc.totalShares, localSupply)
			imported, err := s.k.GetVault(s.ctx, vaultAddr)
			s.Require().NoError(err, "failed to read back the imported vault %s", vaultAddr)
			s.Require().NotNil(imported, "vault %s should exist after InitGenesis", vaultAddr)
			s.Assert().Equal(sdk.NewInt64Coin(shareDenom, tc.totalShares).String(), imported.TotalShares.String(),
				"imported vault %s should preserve its genesis total shares", vaultAddr)
		})
	}
}

func (s *TestSuite) TestVaultGenesis_InitPanicsOnInvalidPendingSwapOut() {
	shareDenom := "vaultshare"
	underlying := "undercoin"
	admin := s.adminAddr.String()
	vaultAddr := types.GetVaultAddress(shareDenom).String()
	unknownVaultAddr := types.GetVaultAddress("baddenom").String()

	validSwapOut := types.PendingSwapOut{
		Owner:        admin,
		VaultAddress: vaultAddr,
		RedeemDenom:  underlying,
		Shares:       sdk.NewInt64Coin(shareDenom, 100),
	}
	swapOutWith := func(mutate func(*types.PendingSwapOut)) types.PendingSwapOut {
		swapOut := validSwapOut
		mutate(&swapOut)
		return swapOut
	}

	tests := []struct {
		name          string
		entry         types.PendingSwapOutQueueEntry
		expectedPanic string
	}{
		{
			name:          "bad owner address",
			entry:         types.PendingSwapOutQueueEntry{Time: 10_000, Id: 1, SwapOut: swapOutWith(func(swapOut *types.PendingSwapOut) { swapOut.Owner = "badaddress" })},
			expectedPanic: "invalid vault genesis state: invalid pending swap out at index 0: invalid owner address badaddress: decoding bech32 failed: invalid separator index -1",
		},
		{
			name:          "bad vault address",
			entry:         types.PendingSwapOutQueueEntry{Time: 10_000, Id: 1, SwapOut: swapOutWith(func(swapOut *types.PendingSwapOut) { swapOut.VaultAddress = "badaddress" })},
			expectedPanic: "invalid vault genesis state: invalid vault address in pending swap out queue at index 0: decoding bech32 failed: invalid separator index -1",
		},
		{
			name:          "vault address is not an imported vault",
			entry:         types.PendingSwapOutQueueEntry{Time: 10_000, Id: 1, SwapOut: swapOutWith(func(swapOut *types.PendingSwapOut) { swapOut.VaultAddress = unknownVaultAddr })},
			expectedPanic: fmt.Sprintf("invalid vault genesis state: pending swap out queue vault address at index 0 is not an imported vault: %s", unknownVaultAddr),
		},
		{
			name: "negative escrowed shares amount",
			entry: types.PendingSwapOutQueueEntry{Time: 10_000, Id: 1, SwapOut: swapOutWith(func(swapOut *types.PendingSwapOut) {
				swapOut.Shares = sdk.Coin{Denom: shareDenom, Amount: sdkmath.NewInt(-100)}
			})},
			expectedPanic: fmt.Sprintf("invalid vault genesis state: invalid pending swap out at index 0: invalid shares: -100%s", shareDenom),
		},
		{
			name:          "nil escrowed shares amount",
			entry:         types.PendingSwapOutQueueEntry{Time: 10_000, Id: 1, SwapOut: swapOutWith(func(swapOut *types.PendingSwapOut) { swapOut.Shares = sdk.Coin{Denom: shareDenom} })},
			expectedPanic: "invalid vault genesis state: invalid pending swap out at index 0: invalid shares: <nil>" + shareDenom,
		},
		{
			name:          "zero escrowed shares amount",
			entry:         types.PendingSwapOutQueueEntry{Time: 10_000, Id: 1, SwapOut: swapOutWith(func(swapOut *types.PendingSwapOut) { swapOut.Shares = sdk.NewInt64Coin(shareDenom, 0) })},
			expectedPanic: "invalid vault genesis state: invalid pending swap out at index 0: shares cannot be zero",
		},
		{
			name:          "empty redeem denom",
			entry:         types.PendingSwapOutQueueEntry{Time: 10_000, Id: 1, SwapOut: swapOutWith(func(swapOut *types.PendingSwapOut) { swapOut.RedeemDenom = "" })},
			expectedPanic: "invalid vault genesis state: invalid pending swap out at index 0: redeem denom cannot be empty",
		},
		{
			name:          "negative entry time",
			entry:         types.PendingSwapOutQueueEntry{Time: -1, Id: 1, SwapOut: validSwapOut},
			expectedPanic: "invalid vault genesis state: pending swap out queue entry at index 0 has negative time -1",
		},
	}

	for _, tc := range tests {
		s.Run(tc.name, func() {
			genesis := buildSingleVaultPendingSwapOutGenesisState(shareDenom, underlying, admin, tc.entry)
			s.Require().PanicsWithError(tc.expectedPanic, func() { s.k.InitGenesis(s.ctx, genesis) },
				"InitGenesis should reject a pending swap out with %s", tc.name)
		})
	}
}

func (s *TestSuite) TestVaultGenesis_InitPanicsOnWithdrawalDelayAboveMax() {
	shareDenom := "vaultshare"
	underlying := "undercoin"
	admin := s.adminAddr.String()

	tests := []struct {
		name         string
		delaySeconds uint64
	}{
		{
			name:         "one second above the maximum",
			delaySeconds: types.MaxWithdrawalDelay + 1,
		},
		{
			name:         "MaxUint64 truncates to a negative payout time",
			delaySeconds: math.MaxUint64,
		},
	}

	for _, tc := range tests {
		s.Run(tc.name, func() {
			vault := makeGenesisVaultAccount(shareDenom, underlying, admin)
			vault.WithdrawalDelaySeconds = tc.delaySeconds
			genesis := &types.GenesisState{
				Params: types.DefaultParams(),
				Vaults: []types.VaultAccount{vault},
			}

			expectedPanic := fmt.Sprintf("invalid vault genesis state: invalid vault at index 0: withdrawal delay cannot exceed %d seconds: %d",
				types.MaxWithdrawalDelay, tc.delaySeconds)
			s.Require().PanicsWithError(expectedPanic, func() { s.k.InitGenesis(s.ctx, genesis) },
				"InitGenesis should reject a vault whose withdrawal delay is %d seconds", tc.delaySeconds)
		})
	}
}

func (s *TestSuite) TestVaultGenesis_InitPanicsWhenPayoutTimeoutHasUnknownVault() {
	badVaultAddr := types.GetVaultAddress("baddenom")

	genesis := &types.GenesisState{
		Params: types.DefaultParams(),
		PayoutTimeoutQueue: []types.QueueEntry{
			{Time: 1000, Addr: badVaultAddr.String()},
		},
	}
	expectedPanic := fmt.Sprintf("invalid vault genesis state: payout timeout queue address at index 0 is not an imported vault: %s", badVaultAddr.String())
	s.Require().PanicsWithError(expectedPanic, func() { s.k.InitGenesis(s.ctx, genesis) }, "InitGenesis should panic on unknown vault in payout timeout queue")
}

func (s *TestSuite) TestVaultGenesis_InitPanicsWhenFeeTimeoutHasUnknownVault() {
	badVaultAddr := types.GetVaultAddress("baddenom")

	genesis := &types.GenesisState{
		Params: types.DefaultParams(),
		FeeTimeoutQueue: []types.QueueEntry{
			{Time: 1000, Addr: badVaultAddr.String()},
		},
	}
	expectedPanic := fmt.Sprintf("invalid vault genesis state: fee timeout queue address at index 0 is not an imported vault: %s", badVaultAddr.String())
	s.Require().PanicsWithError(expectedPanic, func() { s.k.InitGenesis(s.ctx, genesis) }, "InitGenesis should panic on unknown vault in fee timeout queue")
}

func (s *TestSuite) TestVaultGenesis_RoundTrip_PayoutVerificationSet() {
	shareDenom := "verifyshare"
	underlying := "verifyunder"
	vaultAddr := types.GetVaultAddress(shareDenom)

	vault := makeGenesisVaultAccount(shareDenom, underlying, s.adminAddr.String())
	vault.PeriodStart = time.Now().Add(-time.Hour).Unix()

	genesis := &types.GenesisState{
		Params:                types.DefaultParams(),
		Vaults:                []types.VaultAccount{vault},
		PayoutVerificationSet: []string{vaultAddr.String()},
	}

	s.Require().NoError(genesis.Validate(), "a genesis carrying a verification-set vault with no scheduled timeout should validate")
	s.k.InitGenesis(s.ctx, genesis)
	s.assertInPayoutVerificationQueue(vaultAddr, true)
	s.assertInPayoutTimeoutQueue(vaultAddr, false)

	exported := s.k.ExportGenesis(s.ctx)
	s.Require().Equal([]string{vaultAddr.String()}, exported.PayoutVerificationSet,
		"ExportGenesis should carry the payout verification set membership for vault %s", vaultAddr)
	s.Require().NoError(exported.Validate(), "ExportGenesis output should pass stateless validation")

	s.SetupTest()
	s.Require().NotPanics(func() { s.k.InitGenesis(s.ctx, exported) },
		"importing the exported genesis into a fresh chain should succeed")
	s.assertInPayoutVerificationQueue(vaultAddr, true)
	s.assertInPayoutTimeoutQueue(vaultAddr, false)
}

func (s *TestSuite) TestVaultGenesis_RestoresPayoutVerificationSetFromVaultState() {
	shareDenom := "restoreshare"
	underlying := "restoreunder"
	vaultAddr := types.GetVaultAddress(shareDenom)

	periodStart := time.Now().Add(-time.Hour).Unix()
	periodTimeout := time.Now().Add(time.Hour).Unix()

	tests := []struct {
		name              string
		periodStart       int64
		periodTimeout     int64
		paused            bool
		expectVerifying   bool
		expectTimeoutHeld bool
	}{
		{
			name:            "open interest period with no scheduled timeout is restored to the verification set",
			periodStart:     periodStart,
			expectVerifying: true,
		},
		{
			name:              "vault holding a scheduled timeout stays in the payout timeout queue",
			periodStart:       periodStart,
			periodTimeout:     periodTimeout,
			expectTimeoutHeld: true,
		},
		{
			name: "vault with no accrual period is left out of both structures",
		},
		{
			name:        "paused vault is left out of both structures",
			periodStart: periodStart,
			paused:      true,
		},
	}

	for _, tc := range tests {
		s.Run(tc.name, func() {
			s.SetupTest()

			vault := makeGenesisVaultAccount(shareDenom, underlying, s.adminAddr.String())
			vault.PeriodStart = tc.periodStart
			vault.PeriodTimeout = tc.periodTimeout
			vault.Paused = tc.paused

			genesis := &types.GenesisState{
				Params: types.DefaultParams(),
				Vaults: []types.VaultAccount{vault},
			}
			if tc.periodTimeout != 0 {
				genesis.PayoutTimeoutQueue = []types.QueueEntry{
					{Time: uint64(tc.periodTimeout), Addr: vaultAddr.String()},
				}
			}

			s.Require().NotPanics(func() { s.k.InitGenesis(s.ctx, genesis) },
				"importing a genesis with no payout_verification_set field should succeed")

			s.assertInPayoutVerificationQueue(vaultAddr, tc.expectVerifying)
			s.assertInPayoutTimeoutQueue(vaultAddr, tc.expectTimeoutHeld)
		})
	}
}

func (s *TestSuite) TestVaultGenesis_RestoredVerificationSetVaultResumesAutomaticReconciliation() {
	shareDenom := "resumeshare"
	underlying := sdk.NewInt64Coin("resumeunder", 1_000_000)
	blockTime := time.Unix(1_700_000_000, 0).UTC()

	vaultAddr, vault := s.setupReconcileVault("0.05", blockTime.Add(-time.Hour).Unix(), false,
		underlying, shareDenom, sdk.NewInt64Coin(shareDenom, 1_000), blockTime)

	s.Require().NoError(s.k.SafeAddPayoutVerification(s.ctx, vault),
		"moving vault %s into the payout verification set should not error", vaultAddr)
	s.assertInPayoutVerificationQueue(vaultAddr, true)

	exported := s.k.ExportGenesis(s.ctx)
	s.Require().Contains(exported.PayoutVerificationSet, vaultAddr.String(),
		"ExportGenesis should carry vault %s in the payout verification set", vaultAddr)

	exported.PayoutVerificationSet = nil
	s.Require().NoError(s.k.PayoutVerificationSet.Remove(s.ctx, vaultAddr),
		"clearing the live set to emulate a pre-fix export should not error")
	s.assertInPayoutVerificationQueue(vaultAddr, false)

	s.Require().NotPanics(func() { s.k.InitGenesis(s.ctx, exported) },
		"importing a genesis exported before payout_verification_set existed should succeed")
	s.assertInPayoutVerificationQueue(vaultAddr, true)

	s.SetCtxBlockTime(blockTime.Add(time.Minute))
	s.Require().NoError(s.k.EndBlocker(s.ctx), "EndBlocker should not error for the restored vault")

	s.assertInPayoutVerificationQueue(vaultAddr, false)
	s.assertInPayoutTimeoutQueue(vaultAddr, true)
}

func (s *TestSuite) TestVaultGenesis_InitPanicsOnInvalidPayoutVerificationSet() {
	shareDenom := "badverifyshare"
	underlying := "badverifyunder"
	vaultAddr := types.GetVaultAddress(shareDenom)
	unknownVaultAddr := types.GetVaultAddress("baddenom")

	tests := []struct {
		name                  string
		periodTimeout         int64
		payoutTimeoutQueue    []types.QueueEntry
		payoutVerificationSet []string
		expectedPanic         string
	}{
		{
			name:                  "address is not valid bech32",
			payoutVerificationSet: []string{"invalid-bech32"},
			expectedPanic:         "invalid vault genesis state: invalid payout verification set address at index 0: decoding bech32 failed: invalid separator index -1",
		},
		{
			name:                  "address is not an imported vault",
			payoutVerificationSet: []string{unknownVaultAddr.String()},
			expectedPanic:         fmt.Sprintf("invalid vault genesis state: payout verification set address at index 0 is not an imported vault: %s", unknownVaultAddr),
		},
		{
			name:                  "duplicate entry for the same vault",
			payoutVerificationSet: []string{vaultAddr.String(), vaultAddr.String()},
			expectedPanic:         fmt.Sprintf("invalid vault genesis state: duplicate payout verification set entry for vault: %s", vaultAddr),
		},
		{
			name:                  "vault is also in the payout timeout queue",
			periodTimeout:         1_700_000_000,
			payoutTimeoutQueue:    []types.QueueEntry{{Time: 1_700_000_000, Addr: vaultAddr.String()}},
			payoutVerificationSet: []string{vaultAddr.String()},
			expectedPanic:         fmt.Sprintf("invalid vault genesis state: vault %s is in both the payout verification set and the payout timeout queue", vaultAddr),
		},
		{
			name:                  "vault carries a scheduled period timeout",
			periodTimeout:         1_700_000_000,
			payoutVerificationSet: []string{vaultAddr.String()},
			expectedPanic:         fmt.Sprintf("invalid vault genesis state: payout verification set vault %s has period timeout %d, expected 0", vaultAddr, 1_700_000_000),
		},
	}

	for _, tc := range tests {
		s.Run(tc.name, func() {
			vault := makeGenesisVaultAccount(shareDenom, underlying, s.adminAddr.String())
			vault.PeriodTimeout = tc.periodTimeout

			genesis := &types.GenesisState{
				Params:                types.DefaultParams(),
				Vaults:                []types.VaultAccount{vault},
				PayoutTimeoutQueue:    tc.payoutTimeoutQueue,
				PayoutVerificationSet: tc.payoutVerificationSet,
			}

			s.Require().PanicsWithError(tc.expectedPanic, func() { s.k.InitGenesis(s.ctx, genesis) },
				"InitGenesis should reject a payout verification set whose %s", tc.name)
		})
	}
}

// TestVaultGenesis_RoundTrip_NAVs verifies the internal NAV table survives a
// genesis export/import round trip.
func (s *TestSuite) TestVaultGenesis_RoundTrip_NAVs() {
	shareDenom := "navshare"
	underlying := "navunder"
	vaultAddr := types.GetVaultAddress(shareDenom)

	updatedTime := time.Unix(1700000000, 0).UTC()
	navs := []types.VaultNAVEntry{
		{
			VaultAddress: vaultAddr.String(),
			Nav: types.VaultNAV{
				Denom:              "rwaone",
				Price:              sdk.NewInt64Coin(underlying, 150),
				Volume:             sdkmath.NewInt(3),
				Source:             "oracle-one",
				UpdatedBlockHeight: 7,
				UpdatedTime:        updatedTime,
			},
		},
		{
			VaultAddress: vaultAddr.String(),
			Nav: types.VaultNAV{
				Denom:              "rwatwo",
				Price:              sdk.Coin{Denom: underlying, Amount: sdkmath.NewInt(2)},
				Volume:             sdkmath.NewInt(1),
				UpdatedBlockHeight: 9,
				UpdatedTime:        updatedTime,
			},
		},
	}

	genesis := s.setupVaultWithNavs(shareDenom, underlying, s.adminAddr.String(), navs)

	storedNav, err := s.k.GetVaultNAV(s.ctx, vaultAddr, "rwaone")
	s.Require().NoError(err, "NAV should exist after InitGenesis")
	s.Assert().Equal(sdk.NewInt64Coin(underlying, 150), storedNav.Price, "imported NAV price mismatch")
	s.Assert().Equal(sdkmath.NewInt(3), storedNav.Volume, "imported NAV volume mismatch")
	s.Assert().Equal("oracle-one", storedNav.Source, "imported NAV source mismatch")

	exported := s.k.ExportGenesis(s.ctx)
	s.Require().Len(exported.Navs, len(genesis.Navs), "exported genesis should contain every NAV entry")
	s.Assert().ElementsMatch(genesis.Navs, exported.Navs, "exported NAV table should match the imported table")
}

// TestVaultGenesis_InitPanicsOnInvalidNAV verifies genesis validation rejects
// NAV entries that price a self-priced denom or carry a non-positive price or volume.
func (s *TestSuite) TestVaultGenesis_InitPanicsOnInvalidNAV() {
	shareDenom := "navshare"
	underlying := "navunder"
	vaultAddr := types.GetVaultAddress(shareDenom)

	tests := []struct {
		name        string
		nav         types.VaultNAV
		expectPanic string
	}{
		{
			name: "prices the vault share denom",
			nav: types.VaultNAV{
				Denom:       shareDenom,
				Price:       sdk.NewInt64Coin(underlying, 1),
				Volume:      sdkmath.NewInt(1),
				UpdatedTime: time.Unix(1700000000, 0).UTC(),
			},
			expectPanic: "invalid vault genesis state: nav entry at index 0 prices the vault share denom navshare",
		},
		{
			name: "self-referential price denom",
			nav: types.VaultNAV{
				Denom:       "rwa",
				Price:       sdk.NewInt64Coin("rwa", 100),
				Volume:      sdkmath.NewInt(1),
				UpdatedTime: time.Unix(1700000000, 0).UTC(),
			},
			expectPanic: "invalid vault genesis state: nav entry at index 0 has matching denom and price denom \"rwa\"",
		},
		{
			name: "negative price",
			nav: types.VaultNAV{
				Denom:       "rwa",
				Price:       sdk.Coin{Denom: underlying, Amount: sdkmath.NewInt(-1)},
				Volume:      sdkmath.NewInt(1),
				UpdatedTime: time.Unix(1700000000, 0).UTC(),
			},
			expectPanic: "invalid vault genesis state: invalid nav price at index 0: negative coin amount: -1",
		},
		{
			name: "zero volume",
			nav: types.VaultNAV{
				Denom:       "rwa",
				Price:       sdk.NewInt64Coin(underlying, 1),
				Volume:      sdkmath.ZeroInt(),
				UpdatedTime: time.Unix(1700000000, 0).UTC(),
			},
			expectPanic: "invalid vault genesis state: nav volume at index 0 must be positive",
		},
		{
			name: "negative volume",
			nav: types.VaultNAV{
				Denom:       "rwa",
				Price:       sdk.NewInt64Coin(underlying, 1),
				Volume:      sdkmath.NewInt(-1),
				UpdatedTime: time.Unix(1700000000, 0).UTC(),
			},
			expectPanic: "invalid vault genesis state: nav volume at index 0 must be positive",
		},
	}

	for _, tt := range tests {
		s.Run(tt.name, func() {
			genesis := buildSingleVaultGenesisState(shareDenom, underlying, s.adminAddr.String(),
				[]types.VaultNAVEntry{{VaultAddress: vaultAddr.String(), Nav: tt.nav}})
			s.Require().PanicsWithError(tt.expectPanic, func() { s.k.InitGenesis(s.ctx, genesis) }, "InitGenesis should panic on an invalid NAV entry")
		})
	}
}

func (s *TestSuite) TestVaultGenesis_InitSkipsNAVEntriesForUnregisteredDenoms() {
	shareDenom := "navskipshare"
	underlying := "navskipunder"
	registeredDenom := "navskipregistered"
	vaultAddr := types.GetVaultAddress(shareDenom)
	deletedScopeDenom := metadatatypes.ScopeMetadataAddress(uuid.MustParse("00000000-0000-4000-8000-00000000dead")).Denom()

	tests := []struct {
		name        string
		staleDenom  string
		description string
	}{
		{
			name:        "denom that is neither a marker nor a metadata address",
			staleDenom:  "navskipunregistered",
			description: "a denom with no marker",
		},
		{
			name:        "value-owner denom whose scope no longer exists",
			staleDenom:  deletedScopeDenom,
			description: "a value-owner denom for a deleted scope",
		},
	}

	for _, tt := range tests {
		s.Run(tt.name, func() {
			s.SetupTest()
			s.requireSimpleMarker(registeredDenom)

			navEntry := func(denom string) types.VaultNAVEntry {
				return types.VaultNAVEntry{
					VaultAddress: vaultAddr.String(),
					Nav: types.VaultNAV{
						Denom:       denom,
						Price:       sdk.NewInt64Coin(underlying, 100),
						Volume:      sdkmath.NewInt(1),
						UpdatedTime: time.Unix(1_700_000_000, 0).UTC(),
					},
				}
			}
			genesis := buildSingleVaultGenesisState(shareDenom, underlying, s.adminAddr.String(),
				[]types.VaultNAVEntry{navEntry(tt.staleDenom), navEntry(registeredDenom)})

			s.Require().NotPanics(func() { s.k.InitGenesis(s.ctx, genesis) },
				"InitGenesis must import a genesis carrying %s rather than halt the chain", tt.description)

			_, err := s.k.GetVaultNAV(s.ctx, vaultAddr, tt.staleDenom)
			s.Require().ErrorIs(err, collections.ErrNotFound,
				"NAV entry for %s should be dropped on import", tt.staleDenom)

			imported, err := s.k.GetVaultNAV(s.ctx, vaultAddr, registeredDenom)
			s.Require().NoError(err, "NAV entry for registered denom %s should still import alongside the stale entry", registeredDenom)
			s.Require().Equal(registeredDenom, imported.Denom, "imported NAV entry should be the one for denom %s", registeredDenom)
		})
	}
}

func (s *TestSuite) TestVaultGenesis_RoundTripsEveryNAVDenomSetVaultNAVAccepts() {
	const metadataScopeUUID = "00000000-0000-4000-8000-000000000004"
	metadataDenom := metadatatypes.ScopeMetadataAddress(uuid.MustParse(metadataScopeUUID)).Denom()

	tests := []struct {
		name           string
		shareDenom     string
		underlying     string
		navDenom       string
		registerMarker bool
		scopeUUID      string
	}{
		{
			name:           "registered marker denom",
			shareDenom:     "gsnavmkrshare",
			underlying:     "gsnavmkrunder",
			navDenom:       "gsregisteredrwa",
			registerMarker: true,
		},
		{
			name:       "metadata value-owner denom with no marker",
			shareDenom: "gsnavnftshare",
			underlying: "gsnavnftunder",
			navDenom:   metadataDenom,
			scopeUUID:  metadataScopeUUID,
		},
	}

	for _, tt := range tests {
		s.Run(tt.name, func() {
			vaultAddr := types.GetVaultAddress(tt.shareDenom)
			entry := types.VaultNAVEntry{
				VaultAddress: vaultAddr.String(),
				Nav: types.VaultNAV{
					Denom:              tt.navDenom,
					Price:              sdk.NewInt64Coin(tt.underlying, 150),
					Volume:             sdkmath.NewInt(3),
					Source:             "oracle-one",
					UpdatedBlockHeight: 7,
					UpdatedTime:        time.Unix(1_700_000_000, 0).UTC(),
				},
			}

			arrangeAssetRegistration := func() {
				if tt.registerMarker {
					s.requireSimpleMarker(tt.navDenom)
					return
				}
				s.Require().Equal(tt.navDenom, s.requireScope(tt.scopeUUID), "scope %s must back the NAV denom under test", tt.scopeUUID)
				_, markerErr := s.simApp.MarkerKeeper.GetMarkerByDenom(s.ctx, tt.navDenom)
				s.Require().Error(markerErr, "denom %s must not be a registered marker for this case to be meaningful", tt.navDenom)
			}

			s.SetupTest()
			arrangeAssetRegistration()

			genesis := buildSingleVaultGenesisState(tt.shareDenom, tt.underlying, s.adminAddr.String(), []types.VaultNAVEntry{entry})
			s.Require().NotPanics(func() { s.k.InitGenesis(s.ctx, genesis) },
				"InitGenesis should import a NAV entry for denom %s that SetVaultNAV would accept", tt.navDenom)

			stored, err := s.k.GetVaultNAV(s.ctx, vaultAddr, tt.navDenom)
			s.Require().NoError(err, "imported NAV entry for denom %s should be readable from state", tt.navDenom)
			s.Assert().Equal(entry.Nav, stored, "imported NAV entry for denom %s should match the genesis entry", tt.navDenom)

			exported := s.k.ExportGenesis(s.ctx)
			s.Assert().Contains(exported.Navs, entry, "exported genesis should carry the NAV entry for denom %s", tt.navDenom)
			s.Require().NoError(exported.Validate(), "exported genesis should pass stateless validation with a NAV entry for denom %s", tt.navDenom)

			s.SetupTest()
			arrangeAssetRegistration()

			s.Require().NotPanics(func() { s.k.InitGenesis(s.ctx, exported) },
				"importing the exported genesis into a fresh chain should succeed for denom %s", tt.navDenom)

			restored, err := s.k.GetVaultNAV(s.ctx, vaultAddr, tt.navDenom)
			s.Require().NoError(err, "NAV entry for denom %s should be readable after a fresh chain import", tt.navDenom)
			s.Assert().Equal(entry.Nav, restored, "NAV entry for denom %s should survive the export/import round trip intact", tt.navDenom)
		})
	}
}

// TestVaultGenesis_ExportNAVs_MultipleVaults verifies ExportGenesis includes NAV
// entries from all vaults, not just the first one.
func (s *TestSuite) TestVaultGenesis_ExportNAVs_MultipleVaults() {
	shareDenomA := "shareA"
	shareDenomB := "shareB"
	underlyingA := "underA"
	underlyingB := "underB"
	admin := s.adminAddr.String()
	vaultAddrA := types.GetVaultAddress(shareDenomA)
	vaultAddrB := types.GetVaultAddress(shareDenomB)

	vaultA := makeGenesisVaultAccount(shareDenomA, underlyingA, admin)
	vaultB := makeGenesisVaultAccount(shareDenomB, underlyingB, admin)

	navEntriesA := []types.VaultNAVEntry{
		{
			VaultAddress: vaultAddrA.String(),
			Nav: types.VaultNAV{
				Denom:              "rwa1",
				Price:              sdk.NewInt64Coin(underlyingA, 100),
				Volume:             sdkmath.NewInt(3),
				UpdatedBlockHeight: 5,
			},
		},
		{
			VaultAddress: vaultAddrA.String(),
			Nav: types.VaultNAV{
				Denom:              "rwa2",
				Price:              sdk.NewInt64Coin(underlyingA, 200),
				Volume:             sdkmath.NewInt(7),
				UpdatedBlockHeight: 5,
			},
		},
	}
	navEntriesB := []types.VaultNAVEntry{
		{
			VaultAddress: vaultAddrB.String(),
			Nav: types.VaultNAV{
				Denom:              "bond",
				Price:              sdk.NewInt64Coin(underlyingB, 999),
				Volume:             sdkmath.NewInt(1),
				UpdatedBlockHeight: 5,
			},
		},
	}

	allNavs := append(navEntriesA, navEntriesB...)
	genesis := &types.GenesisState{
		Params: types.DefaultParams(),
		Vaults: []types.VaultAccount{vaultA, vaultB},
		Navs:   allNavs,
	}

	for _, entry := range allNavs {
		s.requireSimpleMarker(entry.Nav.Denom)
	}

	s.k.InitGenesis(s.ctx, genesis)

	exported := s.k.ExportGenesis(s.ctx)
	s.Require().Len(exported.Navs, len(allNavs), "ExportGenesis should include NAVs from all vaults")
	s.Assert().ElementsMatch(allNavs, exported.Navs, "exported NAV table should match the imported table across both vaults")
}

// TestVaultGenesis_ExportPanicsOnNAVKeyValueDenomMismatch verifies that ExportGenesis
// surfaces a key/value denom mismatch in the NAVs collection instead of silently
// dropping the key denom. The SetVaultNAV write path enforces equality by construction,
// so this guard exists to catch any future write path that violates the invariant.
func (s *TestSuite) TestVaultGenesis_ExportPanicsOnNAVKeyValueDenomMismatch() {
	shareDenom := "navmismatch"
	underlying := "navmismatchunder"
	vaultAddr := types.GetVaultAddress(shareDenom)

	genesis := &types.GenesisState{
		Params: types.DefaultParams(),
		Vaults: []types.VaultAccount{makeGenesisVaultAccount(shareDenom, underlying, s.adminAddr.String())},
	}
	s.k.InitGenesis(s.ctx, genesis)

	nav := types.VaultNAV{
		Denom:       "valuedenom",
		Price:       sdk.NewInt64Coin(underlying, 1),
		Volume:      sdkmath.NewInt(1),
		UpdatedTime: time.Unix(1700000000, 0).UTC(),
	}
	s.Require().NoError(
		s.k.NAVs.Set(s.ctx, collections.Join(vaultAddr, "keydenom"), nav),
		"writing a mismatched NAV row should succeed at the collection level",
	)

	expectedPanic := fmt.Sprintf(`nav key/value denom mismatch for vault %s: key="keydenom" value="valuedenom"`, vaultAddr)
	s.Require().PanicsWithError(
		"failed to walk vault navs: "+expectedPanic,
		func() { s.k.ExportGenesis(s.ctx) },
		"ExportGenesis should panic when a NAV row's key denom does not match value.Denom",
	)
}

func (s *TestSuite) TestInitGenesis_SeedsTotalValueForVaultReachedThroughTheAuthStore() {
	underlying := "ylds"
	shareDenom := "vshare"
	const parked = 4_242

	vault := s.setupBaseVault(underlying, shareDenom)
	vaultAddr := vault.GetAddress()
	s.Require().NoError(
		FundAccount(s.ctx, s.simApp, vault.PrincipalMarkerAddress(), sdk.NewCoins(sdk.NewInt64Coin(underlying, parked))),
		"funding the principal of vault %s should succeed", vaultAddr,
	)

	s.Require().NoError(s.k.Vaults.Remove(s.ctx, vaultAddr),
		"dropping the vault lookup entry should succeed for vault %s", vaultAddr)
	s.dropStoredTotalValue(vaultAddr)

	genesis := &types.GenesisState{Params: types.DefaultParams()}
	s.Require().Empty(genesis.Vaults,
		"the genesis payload must not list vault %s; it can only be found through the auth store", vaultAddr)

	s.k.InitGenesis(s.ctx, genesis)

	stored, err := s.k.TotalValues.Get(s.ctx, vaultAddr)
	s.Require().NoError(err, "InitGenesis must seed a total for vault %s, which it recovered from the auth store", vaultAddr)
	s.Require().Equal(sdkmath.NewInt(parked).String(), stored.String(),
		"the seeded total must be the %d%s standing at the principal", parked, underlying)

	msg, broken := keeper.TotalValueInvariant(s.k)(s.ctx)
	s.Require().False(broken, "the total value invariant must hold after a genesis import: %s", msg)
}
