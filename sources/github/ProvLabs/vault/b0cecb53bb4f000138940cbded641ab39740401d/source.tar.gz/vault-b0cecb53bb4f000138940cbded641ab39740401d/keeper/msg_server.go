package keeper

import (
	"context"
	"fmt"

	"github.com/provlabs/vault/types"

	sdkmath "cosmossdk.io/math"

	sdk "github.com/cosmos/cosmos-sdk/types"

	"github.com/provenance-io/provenance/x/exchange"
	markertypes "github.com/provenance-io/provenance/x/marker/types"
)

var _ types.MsgServer = &msgServer{}

type msgServer struct {
	*Keeper
}

// NewMsgServer creates a new MsgServer for the module.
func NewMsgServer(keeper *Keeper) types.MsgServer {
	return &msgServer{Keeper: keeper}
}

// validateGovAuthority ensures the provided signer is the module's governance authority.
// Endpoints that can only be executed by a passed governance proposal use this gate.
func (k msgServer) validateGovAuthority(signer string) error {
	expected := k.GetAuthorityString()
	if signer != expected {
		return fmt.Errorf("unauthorized: expected %s got %s", expected, signer)
	}
	return nil
}

// validateVaultCreationAuthority gates CreateVault on the gov_only_vault_creation param:
// only the governance authority may sign while it is on, any account while it is off.
func (k msgServer) validateVaultCreationAuthority(ctx sdk.Context, signer string) error {
	govOnly, err := k.IsVaultCreationGovOnly(ctx)
	if err != nil {
		return fmt.Errorf("failed to determine vault creation authority: %w", err)
	}
	if !govOnly {
		return nil
	}

	return k.validateGovAuthority(signer)
}

// CreateVault creates a vault, signed by the governance module account while the
// gov_only_vault_creation param is enabled and by any account while it is not.
func (k msgServer) CreateVault(goCtx context.Context, msg *types.MsgCreateVaultRequest) (*types.MsgCreateVaultResponse, error) {
	ctx := sdk.UnwrapSDKContext(goCtx)

	if err := k.validateVaultCreationAuthority(ctx, msg.Authority); err != nil {
		return nil, err
	}

	vault, err := k.Keeper.CreateVault(ctx, msg)
	if err != nil {
		return nil, fmt.Errorf("failed to create vault: %w", err)
	}

	return &types.MsgCreateVaultResponse{
		VaultAddress: vault.Address,
	}, nil
}

// SetShareDenomMetadata allows Denom Metadata (see bank module) to be set for the vault's share denom.
func (k msgServer) SetShareDenomMetadata(goCtx context.Context, msg *types.MsgSetShareDenomMetadataRequest) (*types.MsgSetShareDenomMetadataResponse, error) {
	ctx := sdk.UnwrapSDKContext(goCtx)

	vaultAddr := sdk.MustAccAddressFromBech32(msg.VaultAddress)
	vault, err := k.getVault(ctx, vaultAddr)
	if err != nil {
		return nil, err
	}
	if err := vault.ValidateAdmin(msg.Admin); err != nil {
		return nil, fmt.Errorf("failed to validate admin: %w", err)
	}

	metadata := msg.Metadata
	if metadata.Base != vault.TotalShares.Denom {
		return nil, fmt.Errorf("metadata base denom %s does not match vault share denom %s", metadata.Base, vault.TotalShares.Denom)
	}

	k.BankKeeper.SetDenomMetaData(ctx, metadata)

	if err := ctx.EventManager().EmitTypedEvent(
		types.NewEventSetShareDenomMetadata(vaultAddr.String(), msg.Admin, metadata),
	); err != nil {
		return nil, fmt.Errorf("failed to emit EventSetShareDenomMetadata: %w", err)
	}

	return &types.MsgSetShareDenomMetadataResponse{}, nil
}

// SwapIn handles depositing assets accepted by the vault and mints vault shares to the recipient.
func (k msgServer) SwapIn(goCtx context.Context, msg *types.MsgSwapInRequest) (*types.MsgSwapInResponse, error) {
	ctx := sdk.UnwrapSDKContext(goCtx)

	vaultAddr := sdk.MustAccAddressFromBech32(msg.VaultAddress)
	ownerAddr := sdk.MustAccAddressFromBech32(msg.Owner)

	sharesReceived, err := k.Keeper.SwapIn(ctx, vaultAddr, ownerAddr, msg.Assets)
	if err != nil {
		return nil, fmt.Errorf("failed to swap in: %w", err)
	}

	return &types.MsgSwapInResponse{SharesReceived: *sharesReceived}, nil
}

// SwapOut handles redeeming vault shares for assets accepted by the vault and transfers them to the recipient.
func (k msgServer) SwapOut(goCtx context.Context, msg *types.MsgSwapOutRequest) (*types.MsgSwapOutResponse, error) {
	ctx := sdk.UnwrapSDKContext(goCtx)

	vaultAddr := sdk.MustAccAddressFromBech32(msg.VaultAddress)
	ownerAddr := sdk.MustAccAddressFromBech32(msg.Owner)

	if msg.RedeemDenom != "" {
		vault, err := k.GetVault(ctx, vaultAddr)
		if err != nil {
			return nil, fmt.Errorf("failed to get vault: %w", err)
		}
		if vault == nil {
			return nil, fmt.Errorf("vault with address %v not found", msg.VaultAddress)
		}
		if msg.RedeemDenom != vault.UnderlyingAsset {
			return nil, fmt.Errorf("redeem denom is deprecated: the payout is always the underlying asset %q, got %q", vault.UnderlyingAsset, msg.RedeemDenom)
		}
	}

	requestID, err := k.Keeper.SwapOut(ctx, vaultAddr, ownerAddr, msg.Assets)
	if err != nil {
		return nil, fmt.Errorf("failed to swap out: %w", err)
	}

	return &types.MsgSwapOutResponse{RequestId: requestID}, nil
}

// UpdateMinInterestRate sets the minimum allowable interest rate for a vault.
// Only the vault admin is authorized to perform this operation.
// An empty string disables the minimum interest rate limit.
func (k msgServer) UpdateMinInterestRate(goCtx context.Context, msg *types.MsgUpdateMinInterestRateRequest) (*types.MsgUpdateMinInterestRateResponse, error) {
	ctx := sdk.UnwrapSDKContext(goCtx)

	vaultAddr := sdk.MustAccAddressFromBech32(msg.VaultAddress)
	vault, err := k.getVault(ctx, vaultAddr)
	if err != nil {
		return nil, err
	}
	if err := vault.ValidateAdmin(msg.Admin); err != nil {
		return nil, fmt.Errorf("failed to validate admin: %w", err)
	}

	if err := k.SetMinInterestRate(ctx, vault, msg.MinRate); err != nil {
		return nil, fmt.Errorf("failed to set min interest rate: %w", err)
	}

	return &types.MsgUpdateMinInterestRateResponse{}, nil
}

// UpdateMaxInterestRate sets the maximum allowable interest rate for a vault.
// Only the vault admin is authorized to perform this operation.
// An empty string disables the maximum interest rate limit.
func (k msgServer) UpdateMaxInterestRate(goCtx context.Context, msg *types.MsgUpdateMaxInterestRateRequest) (*types.MsgUpdateMaxInterestRateResponse, error) {
	ctx := sdk.UnwrapSDKContext(goCtx)

	vaultAddr := sdk.MustAccAddressFromBech32(msg.VaultAddress)
	vault, err := k.getVault(ctx, vaultAddr)
	if err != nil {
		return nil, err
	}
	if err := vault.ValidateAdmin(msg.Admin); err != nil {
		return nil, fmt.Errorf("failed to validate admin: %w", err)
	}

	if err := k.SetMaxInterestRate(ctx, vault, msg.MaxRate); err != nil {
		return nil, fmt.Errorf("failed to set max interest rate: %w", err)
	}

	return &types.MsgUpdateMaxInterestRateResponse{}, nil
}

// UpdateInterestRate updates the interest rate for a vault.
func (k msgServer) UpdateInterestRate(goCtx context.Context, msg *types.MsgUpdateInterestRateRequest) (*types.MsgUpdateInterestRateResponse, error) {
	ctx := sdk.UnwrapSDKContext(goCtx)

	vaultAddr := sdk.MustAccAddressFromBech32(msg.VaultAddress)
	vault, err := k.getVault(ctx, vaultAddr)
	if err != nil {
		return nil, err
	}
	if err = vault.ValidateManagementAuthority(msg.Authority); err != nil {
		return nil, fmt.Errorf("failed to validate management authority: %w", err)
	}

	newRate, err := sdkmath.LegacyNewDecFromStr(msg.NewRate)
	if err != nil {
		return nil, fmt.Errorf("invalid new rate: %w", err)
	}
	if err = types.ValidateInterestRateMagnitude(newRate); err != nil {
		return nil, fmt.Errorf("invalid new rate: %w", err)
	}
	ok, err := vault.IsInterestRateInRange(newRate)
	if err != nil {
		return nil, fmt.Errorf("failed to validate interest range: %w", err)
	}
	if !ok {
		return nil, fmt.Errorf("interest rate %s is out of bounds for vault %s", newRate, vault.GetAddress())
	}
	if newRate.IsZero() {
		msg.NewRate = types.ZeroInterestRate
	}

	curRate, err := sdkmath.LegacyNewDecFromStr(vault.CurrentInterestRate)
	if err != nil {
		return nil, fmt.Errorf("invalid current rate: %w", err)
	}

	prevEnabled := vault.InterestEnabled()
	if !curRate.IsZero() && !vault.Paused {
		if err := k.reconcileVault(ctx, vault); err != nil {
			return nil, fmt.Errorf("failed to reconcile before rate change: %w", err)
		}
	}

	if err := k.UpdateInterestRates(ctx, vault, msg.NewRate, msg.NewRate); err != nil {
		return nil, fmt.Errorf("failed to update interest rates: %w", err)
	}

	nextEnabled := vault.InterestEnabled()

	switch {
	case !prevEnabled && nextEnabled:
		if err := k.SafeAddPayoutVerification(ctx, vault); err != nil {
			return nil, fmt.Errorf("failed to enqueue vault payout verification: %w", err)
		}
	case prevEnabled && !nextEnabled:
		vault.PeriodStart = 0
		vault.PeriodTimeout = 0
		if err := k.SetVaultAccount(ctx, vault); err != nil {
			return nil, fmt.Errorf("failed to set vault account: %w", err)
		}
		if err := k.PayoutVerificationSet.Remove(ctx, vault.GetAddress()); err != nil {
			return nil, fmt.Errorf("failed to remove payout verification entries: %w", err)
		}
		if err := k.PayoutTimeoutQueue.RemoveAllForVault(ctx, vault.GetAddress()); err != nil {
			return nil, fmt.Errorf("failed to remove payout timeout entries: %w", err)
		}
	}

	return &types.MsgUpdateInterestRateResponse{}, nil
}

func (k msgServer) UpdateWithdrawalDelay(goCtx context.Context, msg *types.MsgUpdateWithdrawalDelayRequest) (*types.MsgUpdateWithdrawalDelayResponse, error) {
	ctx := sdk.UnwrapSDKContext(goCtx)

	vaultAddr := sdk.MustAccAddressFromBech32(msg.VaultAddress)
	vault, err := k.getVault(ctx, vaultAddr)
	if err != nil {
		return nil, err
	}
	if err = vault.ValidateManagementAuthority(msg.Authority); err != nil {
		return nil, fmt.Errorf("failed to validate management authority: %w", err)
	}

	if err := k.SetWithdrawalDelay(ctx, vault, msg.WithdrawalDelaySeconds, msg.Authority); err != nil {
		return nil, fmt.Errorf("failed to set withdrawal delay: %w", err)
	}

	return &types.MsgUpdateWithdrawalDelayResponse{}, nil
}

// UpdateMinSwapInValue sets the minimum allowed value for a swap-in operation.
func (k msgServer) UpdateMinSwapInValue(goCtx context.Context, msg *types.MsgUpdateMinSwapInValueRequest) (*types.MsgUpdateMinSwapInValueResponse, error) {
	ctx := sdk.UnwrapSDKContext(goCtx)

	vaultAddr := sdk.MustAccAddressFromBech32(msg.VaultAddress)
	vault, err := k.getVault(ctx, vaultAddr)
	if err != nil {
		return nil, err
	}
	if err := vault.ValidateManagementAuthority(msg.Authority); err != nil {
		return nil, fmt.Errorf("unauthorized: %w", err)
	}

	if err := k.SetMinSwapInValue(ctx, vault, msg.MinSwapInValue, msg.Authority); err != nil {
		return nil, fmt.Errorf("failed to set min swap in value: %w", err)
	}

	return &types.MsgUpdateMinSwapInValueResponse{}, nil
}

// UpdateMinSwapOutValue sets the minimum allowed value for a swap-out operation.
func (k msgServer) UpdateMinSwapOutValue(goCtx context.Context, msg *types.MsgUpdateMinSwapOutValueRequest) (*types.MsgUpdateMinSwapOutValueResponse, error) {
	ctx := sdk.UnwrapSDKContext(goCtx)

	vaultAddr := sdk.MustAccAddressFromBech32(msg.VaultAddress)
	vault, err := k.getVault(ctx, vaultAddr)
	if err != nil {
		return nil, err
	}
	if err := vault.ValidateManagementAuthority(msg.Authority); err != nil {
		return nil, fmt.Errorf("unauthorized: %w", err)
	}

	if err := k.SetMinSwapOutValue(ctx, vault, msg.MinSwapOutValue, msg.Authority); err != nil {
		return nil, fmt.Errorf("failed to set min swap out value: %w", err)
	}

	return &types.MsgUpdateMinSwapOutValueResponse{}, nil
}

// UpdateMaxSwapInValue sets the maximum allowed value for a swap-in operation.
func (k msgServer) UpdateMaxSwapInValue(goCtx context.Context, msg *types.MsgUpdateMaxSwapInValueRequest) (*types.MsgUpdateMaxSwapInValueResponse, error) {
	ctx := sdk.UnwrapSDKContext(goCtx)

	vaultAddr := sdk.MustAccAddressFromBech32(msg.VaultAddress)
	vault, err := k.getVault(ctx, vaultAddr)
	if err != nil {
		return nil, err
	}
	if err := vault.ValidateManagementAuthority(msg.Authority); err != nil {
		return nil, fmt.Errorf("unauthorized: %w", err)
	}

	if err := k.SetMaxSwapInValue(ctx, vault, msg.MaxSwapInValue, msg.Authority); err != nil {
		return nil, fmt.Errorf("failed to set max swap in value: %w", err)
	}

	return &types.MsgUpdateMaxSwapInValueResponse{}, nil
}

// UpdateMaxSwapOutValue sets the maximum allowed value for a swap-out operation.
func (k msgServer) UpdateMaxSwapOutValue(goCtx context.Context, msg *types.MsgUpdateMaxSwapOutValueRequest) (*types.MsgUpdateMaxSwapOutValueResponse, error) {
	ctx := sdk.UnwrapSDKContext(goCtx)

	vaultAddr := sdk.MustAccAddressFromBech32(msg.VaultAddress)
	vault, err := k.getVault(ctx, vaultAddr)
	if err != nil {
		return nil, err
	}
	if err := vault.ValidateManagementAuthority(msg.Authority); err != nil {
		return nil, fmt.Errorf("unauthorized: %w", err)
	}

	if err := k.SetMaxSwapOutValue(ctx, vault, msg.MaxSwapOutValue, msg.Authority); err != nil {
		return nil, fmt.Errorf("failed to set max swap out value: %w", err)
	}

	return &types.MsgUpdateMaxSwapOutValueResponse{}, nil
}

// ToggleSwapIn enables or disables swap-in operations for a vault.
func (k msgServer) ToggleSwapIn(goCtx context.Context, msg *types.MsgToggleSwapInRequest) (*types.MsgToggleSwapInResponse, error) {
	ctx := sdk.UnwrapSDKContext(goCtx)

	vaultAddr := sdk.MustAccAddressFromBech32(msg.VaultAddress)

	vault, err := k.getVault(ctx, vaultAddr)
	if err != nil {
		return nil, err
	}
	if err := vault.ValidateAdmin(msg.Admin); err != nil {
		return nil, fmt.Errorf("failed to validate admin: %w", err)
	}
	if err := k.SetSwapInEnable(ctx, vault, msg.Enabled); err != nil {
		return nil, fmt.Errorf("failed to set swap in enable: %w", err)
	}

	return &types.MsgToggleSwapInResponse{}, nil
}

// ToggleSwapOut enables or disables swap-out operations for a vault.
func (k msgServer) ToggleSwapOut(goCtx context.Context, msg *types.MsgToggleSwapOutRequest) (*types.MsgToggleSwapOutResponse, error) {
	ctx := sdk.UnwrapSDKContext(goCtx)

	vaultAddr := sdk.MustAccAddressFromBech32(msg.VaultAddress)

	vault, err := k.getVault(ctx, vaultAddr)
	if err != nil {
		return nil, err
	}
	if err := vault.ValidateAdmin(msg.Admin); err != nil {
		return nil, fmt.Errorf("failed to validate admin: %w", err)
	}

	if err := k.SetSwapOutEnable(ctx, vault, msg.Enabled); err != nil {
		return nil, fmt.Errorf("failed to set swap out enable: %w", err)
	}

	return &types.MsgToggleSwapOutResponse{}, nil
}

// DepositInterestFunds handles depositing funds into the vault for paying interest.
func (k msgServer) DepositInterestFunds(goCtx context.Context, msg *types.MsgDepositInterestFundsRequest) (*types.MsgDepositInterestFundsResponse, error) {
	ctx := sdk.UnwrapSDKContext(goCtx)

	authorityAddr := sdk.MustAccAddressFromBech32(msg.Authority)
	vaultAddr := sdk.MustAccAddressFromBech32(msg.VaultAddress)

	vault, err := k.getVault(ctx, vaultAddr)
	if err != nil {
		return nil, err
	}

	if err = vault.ValidateManagementAuthority(msg.Authority); err != nil {
		return nil, fmt.Errorf("failed to validate management authority: %w", err)
	}

	if vault.UnderlyingAsset != msg.Amount.Denom {
		return nil, fmt.Errorf("denom not supported for vault must be of type \"%s\" : got \"%s\"", vault.UnderlyingAsset, msg.Amount.Denom)
	}

	if err := k.checkDepositDenyList(ctx, authorityAddr, msg.Amount.Denom); err != nil {
		return nil, fmt.Errorf("failed to deposit interest funds: %w", err)
	}

	if err := k.BankKeeper.SendCoins(markertypes.WithBypass(ctx), authorityAddr, vaultAddr, sdk.NewCoins(msg.Amount)); err != nil {
		return nil, fmt.Errorf("failed to deposit funds: %w", err)
	}

	if err := k.reconcileVault(ctx, vault); err != nil {
		return nil, fmt.Errorf("failed to reconcile vault after deposit: %w", err)
	}

	k.emitEvent(ctx, types.NewEventInterestDeposit(msg.VaultAddress, msg.Authority, msg.Amount))

	return &types.MsgDepositInterestFundsResponse{}, nil
}

// WithdrawInterestFunds handles withdrawing unused interest funds from the vault.
func (k msgServer) WithdrawInterestFunds(goCtx context.Context, msg *types.MsgWithdrawInterestFundsRequest) (*types.MsgWithdrawInterestFundsResponse, error) {
	ctx := sdk.UnwrapSDKContext(goCtx)

	authorityAddr := sdk.MustAccAddressFromBech32(msg.Authority)
	vaultAddr := sdk.MustAccAddressFromBech32(msg.VaultAddress)

	vault, err := k.getVault(ctx, vaultAddr)
	if err != nil {
		return nil, err
	}

	if err = vault.ValidateManagementAuthority(msg.Authority); err != nil {
		return nil, fmt.Errorf("failed to validate management authority: %w", err)
	}
	if vault.UnderlyingAsset != msg.Amount.Denom {
		return nil, fmt.Errorf("denom not supported for vault must be of type \"%s\" : got \"%s\"", vault.UnderlyingAsset, msg.Amount.Denom)
	}

	if err := k.reconcileVault(ctx, vault); err != nil {
		return nil, fmt.Errorf("failed to reconcile vault before withdrawal: %w", err)
	}

	// for receipt tokens, the transfer agent for the authority address is used
	if err := k.BankKeeper.SendCoins(markertypes.WithTransferAgents(ctx, authorityAddr), vaultAddr, authorityAddr, sdk.NewCoins(msg.Amount)); err != nil {
		return nil, fmt.Errorf("failed to withdraw interest funds: %w", err)
	}

	k.emitEvent(ctx, types.NewEventInterestWithdrawal(msg.VaultAddress, msg.Authority, msg.Amount))

	return &types.MsgWithdrawInterestFundsResponse{}, nil
}

// DepositPrincipalFunds allows an admin to deposit principal funds into a vault.
func (k msgServer) DepositPrincipalFunds(goCtx context.Context, msg *types.MsgDepositPrincipalFundsRequest) (*types.MsgDepositPrincipalFundsResponse, error) {
	ctx := sdk.UnwrapSDKContext(goCtx)

	vaultAddr := sdk.MustAccAddressFromBech32(msg.VaultAddress)
	vault, err := k.getVault(ctx, vaultAddr)
	if err != nil {
		return nil, err
	}
	if err = vault.ValidateManagementAuthority(msg.Authority); err != nil {
		return nil, fmt.Errorf("failed to validate management authority: %w", err)
	}

	if !vault.Paused {
		return nil, fmt.Errorf("vault must be paused to deposit principal funds")
	}

	if err := k.reconcileVault(ctx, vault); err != nil {
		return nil, fmt.Errorf("failed to reconcile vault before principal change: %w", err)
	}

	depositFromAddress := sdk.MustAccAddressFromBech32(msg.Authority)
	principalAddress := vault.PrincipalMarkerAddress()

	if err := vault.ValidateAcceptedCoin(msg.Amount); err != nil {
		return nil, fmt.Errorf("failed to validate accepted coin: %w", err)
	}

	if err := k.checkDepositDenyList(ctx, depositFromAddress, msg.Amount.Denom); err != nil {
		return nil, fmt.Errorf("failed to deposit principal funds: %w", err)
	}

	if err := k.BankKeeper.SendCoins(markertypes.WithBypass(ctx),
		depositFromAddress,
		principalAddress,
		sdk.NewCoins(msg.Amount),
	); err != nil {
		return nil, fmt.Errorf("failed to deposit principal funds: %w", err)
	}

	if err := k.adjustTotalValue(ctx, *vault, msg.Amount.Amount); err != nil {
		return nil, fmt.Errorf("failed to record principal deposit value: %w", err)
	}

	k.emitEvent(ctx, types.NewEventDepositPrincipalFunds(msg.VaultAddress, msg.Authority, msg.Amount))
	return &types.MsgDepositPrincipalFundsResponse{}, nil
}

// WithdrawPrincipalFunds allows an admin to withdraw principal funds from a vault.
func (k msgServer) WithdrawPrincipalFunds(goCtx context.Context, msg *types.MsgWithdrawPrincipalFundsRequest) (*types.MsgWithdrawPrincipalFundsResponse, error) {
	ctx := sdk.UnwrapSDKContext(goCtx)

	vaultAddr := sdk.MustAccAddressFromBech32(msg.VaultAddress)
	vault, err := k.getVault(ctx, vaultAddr)
	if err != nil {
		return nil, err
	}
	if err = vault.ValidateManagementAuthority(msg.Authority); err != nil {
		return nil, fmt.Errorf("failed to validate management authority: %w", err)
	}

	if !vault.Paused {
		return nil, fmt.Errorf("vault must be paused to withdraw principal funds")
	}

	if err := k.reconcileVault(ctx, vault); err != nil {
		return nil, fmt.Errorf("failed to reconcile vault before principal change: %w", err)
	}

	authorityAddress := sdk.MustAccAddressFromBech32(msg.Authority)
	principalAddress := vault.PrincipalMarkerAddress()

	if err := vault.ValidateAcceptedCoin(msg.Amount); err != nil {
		return nil, fmt.Errorf("failed to validate accepted coin: %w", err)
	}

	// for receipt tokens, the transfer agent for the authority address is used
	// transfer agent of vault address is required for all token types since principal is marker account
	if err := k.BankKeeper.SendCoins(markertypes.WithTransferAgents(ctx, authorityAddress, vaultAddr),
		principalAddress,
		authorityAddress,
		sdk.NewCoins(msg.Amount),
	); err != nil {
		return nil, fmt.Errorf("failed to withdraw principal funds: %w", err)
	}

	if err := k.adjustTotalValue(ctx, *vault, msg.Amount.Amount.Neg()); err != nil {
		return nil, fmt.Errorf("failed to record principal withdrawal value: %w", err)
	}

	k.emitEvent(ctx, types.NewEventWithdrawPrincipalFunds(msg.VaultAddress, msg.Authority, msg.Amount))

	return &types.MsgWithdrawPrincipalFundsResponse{}, nil
}

// ExpeditePendingSwapOut expedites a pending swap out from a vault.
func (k msgServer) ExpeditePendingSwapOut(goCtx context.Context, msg *types.MsgExpeditePendingSwapOutRequest) (*types.MsgExpeditePendingSwapOutResponse, error) {
	ctx := sdk.UnwrapSDKContext(goCtx)

	_, swapOut, err := k.PendingSwapOutQueue.GetByID(ctx, msg.RequestId)
	if err != nil {
		return nil, fmt.Errorf("failed to get pending swap out: %w", err)
	}

	vaultAddr := sdk.MustAccAddressFromBech32(swapOut.VaultAddress)
	vault, err := k.getVault(ctx, vaultAddr)
	if err != nil {
		return nil, err
	}
	if err = vault.ValidateManagementAuthority(msg.Authority); err != nil {
		return nil, fmt.Errorf("failed to validate management authority: %w", err)
	}

	if err := k.PendingSwapOutQueue.ExpediteSwapOut(ctx, msg.RequestId); err != nil {
		return nil, fmt.Errorf("failed to expedite swap out: %w", err)
	}

	k.emitEvent(ctx, types.NewEventPendingSwapOutExpedited(msg.RequestId, swapOut.VaultAddress, msg.Authority))

	return &types.MsgExpeditePendingSwapOutResponse{}, nil
}

// PauseVault pauses a vault, disabling all user-facing operations. The admin, the asset
// manager, or the NAV authority may pause; only the first two may unpause.
//
// By default the pause is strict: it reconciles outstanding interest and fees
// and snapshots the net TVV first, and any failure (e.g. insufficient reserves
// to settle positive interest, or a broken TVV/NAV conversion) aborts the pause
// and leaves the vault unpaused. Setting Force on the request makes the pause an
// emergency control handled by forcePauseVault: tolerated reconcile/valuation
// failures are logged and surfaced via EventVaultPaused.forced_error, the frozen
// PausedBalance is the net TVV when valuable or zero when valuation itself failed,
// and the account is persisted with validation first, falling back to an
// unvalidated persist (also surfaced via forced_error) so an invalid-state vault
// can still be frozen and the saved inconsistency remains auditable.
//
// Both paths call haltVaultAccrual so a paused vault holds no reconciliation queue entries.
func (k msgServer) PauseVault(goCtx context.Context, msg *types.MsgPauseVaultRequest) (*types.MsgPauseVaultResponse, error) {
	ctx := sdk.UnwrapSDKContext(goCtx)

	vaultAddr := sdk.MustAccAddressFromBech32(msg.VaultAddress)
	vault, err := k.getVault(ctx, vaultAddr)
	if err != nil {
		return nil, err
	}
	if err = vault.ValidatePauseAuthority(msg.Authority); err != nil {
		return nil, fmt.Errorf("failed to validate pause authority: %w", err)
	}

	if vault.Paused {
		return nil, fmt.Errorf("vault %s is already paused", msg.VaultAddress)
	}

	if msg.Force {
		k.forcePauseVault(ctx, vault, msg.Authority, msg.Reason)
		return &types.MsgPauseVaultResponse{}, nil
	}

	if err = k.reconcileVault(ctx, vault); err != nil {
		return nil, fmt.Errorf("failed to reconcile before pausing: %w", err)
	}

	tvv, err := k.GetNetTVV(ctx, *vault)
	if err != nil {
		return nil, fmt.Errorf("failed to get net TVV before pausing: %w", err)
	}

	vault.PausedBalance = sdk.NewCoin(vault.UnderlyingAsset, tvv)
	vault.Paused = true
	vault.PausedReason = msg.Reason
	vault.PausedBy = msg.Authority
	vault.PausedForced = false

	if err := k.haltVaultAccrual(ctx, vault); err != nil {
		return nil, fmt.Errorf("failed to halt vault accrual before pausing: %w", err)
	}

	if err := k.UpdateInterestRates(ctx, vault, types.ZeroInterestRate, vault.DesiredInterestRate); err != nil {
		return nil, fmt.Errorf("failed to update interest rates: %w", err)
	}

	if err := k.SetVaultAccount(ctx, vault); err != nil {
		return nil, fmt.Errorf("failed to set vault account: %w", err)
	}

	k.emitEvent(ctx, types.NewEventVaultPaused(msg.VaultAddress, msg.Authority, msg.Reason, vault.PausedBalance, false, ""))

	return &types.MsgPauseVaultResponse{}, nil
}

// UnpauseVault unpauses a vault, re-enabling all user-facing operations after a NAV recalculation.
// It re-arms what pausing cleared: payout verification for interest and the fee timeout for AUM
// fees, both starting at the current block time so the paused span is never charged.
func (k msgServer) UnpauseVault(goCtx context.Context, msg *types.MsgUnpauseVaultRequest) (*types.MsgUnpauseVaultResponse, error) {
	ctx := sdk.UnwrapSDKContext(goCtx)

	vaultAddr := sdk.MustAccAddressFromBech32(msg.VaultAddress)
	vault, err := k.getVault(ctx, vaultAddr)
	if err != nil {
		return nil, err
	}
	if err = vault.ValidateManagementAuthority(msg.Authority); err != nil {
		return nil, fmt.Errorf("failed to validate management authority: %w", err)
	}

	if !vault.Paused {
		return nil, fmt.Errorf("vault %s is not paused", msg.VaultAddress)
	}

	if err = k.resumeVault(ctx, vault, msg.Authority); err != nil {
		return nil, err
	}

	return &types.MsgUnpauseVaultResponse{}, nil
}

// SetBridgeAddress sets the single external bridge address allowed to mint or burn shares for a vault.
//
// Rotation does not move or burn any share balance the outgoing bridge holds; drain the outgoing bridge first,
// or mint capacity stays reduced by that balance until it is transferred to the new bridge and burned. See the
// drain-before-rotate procedure in spec/03_messages.md.
func (k msgServer) SetBridgeAddress(goCtx context.Context, msg *types.MsgSetBridgeAddressRequest) (*types.MsgSetBridgeAddressResponse, error) {
	ctx := sdk.UnwrapSDKContext(goCtx)

	vaultAddr := sdk.MustAccAddressFromBech32(msg.VaultAddress)
	vault, err := k.getVault(ctx, vaultAddr)
	if err != nil {
		return nil, err
	}
	if err := vault.ValidateAdmin(msg.Admin); err != nil {
		return nil, fmt.Errorf("failed to validate admin: %w", err)
	}

	vault.BridgeAddress = msg.BridgeAddress
	if err := k.SetVaultAccount(ctx, vault); err != nil {
		return nil, fmt.Errorf("failed to set vault account: %w", err)
	}

	k.emitEvent(ctx, types.NewEventBridgeAddressSet(vaultAddr.String(), msg.Admin, msg.BridgeAddress))

	return &types.MsgSetBridgeAddressResponse{}, nil
}

// ToggleBridge enables or disables the bridge functionality for a vault.
func (k msgServer) ToggleBridge(goCtx context.Context, msg *types.MsgToggleBridgeRequest) (*types.MsgToggleBridgeResponse, error) {
	ctx := sdk.UnwrapSDKContext(goCtx)

	vaultAddr := sdk.MustAccAddressFromBech32(msg.VaultAddress)
	vault, err := k.getVault(ctx, vaultAddr)
	if err != nil {
		return nil, err
	}
	if err := vault.ValidateAdmin(msg.Admin); err != nil {
		return nil, fmt.Errorf("failed to validate admin: %w", err)
	}

	vault.BridgeEnabled = msg.Enabled
	if err := k.SetVaultAccount(ctx, vault); err != nil {
		return nil, fmt.Errorf("failed to set vault account: %w", err)
	}

	k.emitEvent(ctx, types.NewEventBridgeToggled(msg.VaultAddress, msg.Admin, msg.Enabled))

	return &types.MsgToggleBridgeResponse{}, nil
}

// BridgeMintShares mints local share marker supply for a vault; the signer must match the configured bridge address
// and the mint amount must not exceed (total_shares - current marker supply). Pausing a vault is the module's
// incident circuit breaker, so a paused vault rejects bridge mints alongside every other value-touching path.
func (k msgServer) BridgeMintShares(goCtx context.Context, msg *types.MsgBridgeMintSharesRequest) (*types.MsgBridgeMintSharesResponse, error) {
	ctx := sdk.UnwrapSDKContext(goCtx)

	vaultAddr := sdk.MustAccAddressFromBech32(msg.VaultAddress)
	bridgeAddr := sdk.MustAccAddressFromBech32(msg.Bridge)

	vault, err := k.getVault(ctx, vaultAddr)
	if err != nil {
		return nil, err
	}
	if vault.Paused {
		return nil, fmt.Errorf("vault %s is paused", msg.VaultAddress)
	}
	if !vault.BridgeEnabled {
		return nil, fmt.Errorf("bridge is disabled for vault %s", msg.VaultAddress)
	}
	if vault.BridgeAddress != bridgeAddr.String() {
		return nil, fmt.Errorf("unauthorized bridge: expected %s got %s", vault.BridgeAddress, bridgeAddr.String())
	}
	if msg.Shares.Denom != vault.TotalShares.Denom {
		return nil, fmt.Errorf("invalid shares denom: expected %s got %s", vault.TotalShares.Denom, msg.Shares.Denom)
	}
	if !msg.Shares.Amount.IsPositive() {
		return nil, fmt.Errorf("mint amount must be positive")
	}

	available, err := k.availableBridgeMintCapacity(ctx, vault)
	if err != nil {
		return nil, err
	}
	if msg.Shares.Amount.GT(available.Amount) {
		return nil, fmt.Errorf("mint exceeds capacity: requested %s available %s", msg.Shares.Amount.String(), available.Amount.String())
	}

	if err := k.MarkerKeeper.MintCoin(ctx, vaultAddr, msg.Shares); err != nil {
		return nil, fmt.Errorf("failed to mint shares to bridge: %w", err)
	}

	if err := k.MarkerKeeper.WithdrawCoins(ctx, vaultAddr, bridgeAddr, msg.Shares.Denom, sdk.NewCoins(msg.Shares)); err != nil {
		return nil, fmt.Errorf("failed to transfer minted shares to bridge: %w", err)
	}

	k.emitEvent(ctx, types.NewEventBridgeMintShares(vaultAddr.String(), bridgeAddr.String(), msg.Shares))

	return &types.MsgBridgeMintSharesResponse{}, nil
}

// BridgeBurnShares burns local share marker supply for a vault; the signer must match the configured bridge address
// and the burn amount must not exceed the current marker supply. Shares are burned from the bridge account balance.
// Pausing a vault is the module's incident circuit breaker, so a paused vault rejects bridge burns alongside every
// other value-touching path.
func (k msgServer) BridgeBurnShares(goCtx context.Context, msg *types.MsgBridgeBurnSharesRequest) (*types.MsgBridgeBurnSharesResponse, error) {
	ctx := sdk.UnwrapSDKContext(goCtx)

	vaultAddr := sdk.MustAccAddressFromBech32(msg.VaultAddress)
	bridgeAddr := sdk.MustAccAddressFromBech32(msg.Bridge)

	vault, err := k.getVault(ctx, vaultAddr)
	if err != nil {
		return nil, err
	}
	if vault.Paused {
		return nil, fmt.Errorf("vault %s is paused", msg.VaultAddress)
	}
	if !vault.BridgeEnabled {
		return nil, fmt.Errorf("bridge is disabled for vault %s", msg.VaultAddress)
	}
	if vault.BridgeAddress != bridgeAddr.String() {
		return nil, fmt.Errorf("unauthorized bridge: expected %s got %s", vault.BridgeAddress, bridgeAddr.String())
	}
	if msg.Shares.Denom != vault.TotalShares.Denom {
		return nil, fmt.Errorf("invalid shares denom: expected %s got %s", vault.TotalShares.Denom, msg.Shares.Denom)
	}
	if !msg.Shares.Amount.IsPositive() {
		return nil, fmt.Errorf("burn amount must be positive")
	}

	if err := k.BankKeeper.SendCoins(markertypes.WithTransferAgents(ctx, vaultAddr), bridgeAddr, vault.PrincipalMarkerAddress(), sdk.NewCoins(msg.Shares)); err != nil {
		return nil, fmt.Errorf("failed to transfer shares from bridge to vault: %w", err)
	}

	// Intentionally does not decrement vault.TotalShares: bridged-out shares still exist on the
	// remote chain, so TotalShares (the cross-chain supply-of-record) is unchanged. See spec/01_concepts.md.
	if err := k.MarkerKeeper.BurnCoin(ctx, vaultAddr, msg.Shares); err != nil {
		return nil, fmt.Errorf("failed to burn shares from marker: %w", err)
	}

	k.emitEvent(ctx, types.NewEventBridgeBurnShares(vaultAddr.String(), bridgeAddr.String(), msg.Shares))

	return &types.MsgBridgeBurnSharesResponse{}, nil
}

// SetAssetManager sets or clears the optional asset manager address for a vault.
// Only the vault admin may call this. Passing an empty AssetManager clears it.
func (k msgServer) SetAssetManager(goCtx context.Context, msg *types.MsgSetAssetManagerRequest) (*types.MsgSetAssetManagerResponse, error) {
	ctx := sdk.UnwrapSDKContext(goCtx)

	vaultAddr := sdk.MustAccAddressFromBech32(msg.VaultAddress)
	vault, err := k.getVault(ctx, vaultAddr)
	if err != nil {
		return nil, err
	}

	if err := vault.ValidateAdmin(msg.Admin); err != nil {
		return nil, fmt.Errorf("failed to validate admin: %w", err)
	}

	vault.AssetManager = msg.AssetManager

	if err := k.SetVaultAccount(ctx, vault); err != nil {
		return nil, fmt.Errorf("failed to set vault account: %w", err)
	}

	k.emitEvent(ctx, types.NewEventAssetManagerSet(vaultAddr.String(), msg.Admin, msg.AssetManager))

	return &types.MsgSetAssetManagerResponse{}, nil
}

// UpdateParams updates the module parameters.
func (k msgServer) UpdateParams(goCtx context.Context, msg *types.MsgUpdateParamsRequest) (*types.MsgUpdateParamsResponse, error) {
	ctx := sdk.UnwrapSDKContext(goCtx)

	if err := k.validateGovAuthority(msg.Authority); err != nil {
		return nil, err
	}

	if err := msg.Params.Validate(); err != nil {
		return nil, fmt.Errorf("invalid params: %w", err)
	}

	if err := k.Params.Set(ctx, msg.Params); err != nil {
		return nil, fmt.Errorf("failed to set params: %w", err)
	}

	k.emitEvent(ctx, types.NewEventParamsUpdated(msg.Params))

	return &types.MsgUpdateParamsResponse{}, nil
}

// UpdateVaultAUMFeeBips updates the AUM fee bips for a specific vault.
func (k msgServer) UpdateVaultAUMFeeBips(goCtx context.Context, msg *types.MsgUpdateVaultAUMFeeBipsRequest) (*types.MsgUpdateVaultAUMFeeBipsResponse, error) {
	ctx := sdk.UnwrapSDKContext(goCtx)

	vaultAddr := sdk.MustAccAddressFromBech32(msg.VaultAddress)
	vault, err := k.getVault(ctx, vaultAddr)
	if err != nil {
		return nil, err
	}

	params, err := k.Params.Get(ctx)
	if err != nil {
		return nil, fmt.Errorf("failed to get params: %w", err)
	}

	if msg.Authority != params.TechFeeAddress {
		return nil, fmt.Errorf("unauthorized: %s is not the tech fee address", msg.Authority)
	}

	if msg.AumFeeBips > 10_000 {
		return nil, fmt.Errorf("invalid AUM fee bips: %d (max 10000)", msg.AumFeeBips)
	}

	if err := k.Keeper.UpdateVaultAUMFeeBips(ctx, vault, msg.AumFeeBips, msg.Authority); err != nil {
		return nil, fmt.Errorf("failed to update vault AUM fee bips: %w", err)
	}

	return &types.MsgUpdateVaultAUMFeeBipsResponse{}, nil
}

// UpdateVaultNAV creates or updates a vault's internal NAV entry for a denom.
// Only the vault's NAV authority is authorized to perform this operation.
//
// The price lands in the vault's internal NAV table and nowhere else. A vault does not
// own the assets it prices, so it does not mirror an asset price into that asset's
// marker-module NAV records, where it would compete with prices set by the marker's own
// administrators. Only the vault's share denom, which the vault does own, gets a
// published marker NAV (see publishShareNav).
//
// Repricing an asset the vault holds requires the vault to be paused, so no user can swap
// across the share price step (see requirePausedHeldReprice).
//
// Writing the entry is all this handler does to a paused vault. PausedBalance is
// left alone, holding the value as of the moment of pausing, exactly as it does for
// the principal deposits and withdrawals that are themselves only allowed while
// paused. Everything that happened during the pause, repricings included, lands
// together when UnpauseVault clears the snapshot and recomputes total vault value
// from live balances and the NAV table.
//
// The reconcile settles accrued interest against the total vault value that held
// before the price change. It is a no-op on a paused vault, whose interest and
// fee accrual is already halted.
func (k msgServer) UpdateVaultNAV(goCtx context.Context, msg *types.MsgUpdateVaultNAVRequest) (*types.MsgUpdateVaultNAVResponse, error) {
	ctx := sdk.UnwrapSDKContext(goCtx)

	vaultAddr := sdk.MustAccAddressFromBech32(msg.VaultAddress)
	vault, err := k.getVault(ctx, vaultAddr)
	if err != nil {
		return nil, fmt.Errorf("failed to get vault %s: %w", msg.VaultAddress, err)
	}
	if err := vault.ValidateNAVAuthority(msg.Signer); err != nil {
		return nil, fmt.Errorf("failed to validate NAV authority: %w", err)
	}

	nav := types.NewVaultNAV(msg.Denom, msg.Price, msg.Volume, msg.Source)
	if err := k.requirePausedHeldReprice(ctx, vault, nav); err != nil {
		return nil, err
	}

	if err := k.reconcileVault(ctx, vault); err != nil {
		return nil, fmt.Errorf("failed to reconcile vault before NAV update: %w", err)
	}

	if err := k.SetVaultNAV(ctx, vault, nav, msg.Signer); err != nil {
		return nil, fmt.Errorf("failed to update vault NAV: %w", err)
	}

	return &types.MsgUpdateVaultNAVResponse{}, nil
}

// RepriceVault applies a batch of internal NAV updates and, when Resume is set, unpauses
// the vault in the same state transition. It is the batched form of UpdateVaultNAV and
// enforces the identical per-entry rules, so repricing a denom the vault holds still
// requires the pause window.
//
// Leaving Resume unset is what makes a restatement too large for one transaction possible:
// successive batches land while the vault stays frozen, and only the final message resumes
// it. With Resume set, the batch and the unpause commit together, so there is never a block
// in which the vault is live, a new price is public, and the share price step has not landed.
//
// Resuming is gated on a strict pause this same NAV authority took; operator, forced, and
// automatic pauses still require a management unpause. The gate is checked before any price
// is written so a batch that cannot resume changes nothing.
//
// The reconcile settles accrued interest against the total vault value that held before the
// batch, and is a no-op on a paused vault whose accrual is already halted.
func (k msgServer) RepriceVault(goCtx context.Context, msg *types.MsgRepriceVaultRequest) (*types.MsgRepriceVaultResponse, error) {
	ctx := sdk.UnwrapSDKContext(goCtx)

	vaultAddr := sdk.MustAccAddressFromBech32(msg.VaultAddress)
	vault, err := k.getVault(ctx, vaultAddr)
	if err != nil {
		return nil, fmt.Errorf("failed to get vault %s: %w", msg.VaultAddress, err)
	}
	if err := vault.ValidateNAVAuthority(msg.Signer); err != nil {
		return nil, fmt.Errorf("failed to validate NAV authority: %w", err)
	}
	if msg.Resume {
		if err := requireNAVAuthorityResumable(vault, msg.Signer); err != nil {
			return nil, err
		}
	}

	navs := make([]types.VaultNAV, len(msg.Navs))
	for i, update := range msg.Navs {
		navs[i] = types.NewVaultNAV(update.Denom, update.Price, update.Volume, update.Source)
		if err := k.requirePausedHeldReprice(ctx, vault, navs[i]); err != nil {
			return nil, fmt.Errorf("NAV update at index %d: %w", i, err)
		}
	}

	if err := k.reconcileVault(ctx, vault); err != nil {
		return nil, fmt.Errorf("failed to reconcile vault before NAV batch: %w", err)
	}

	for i, nav := range navs {
		if err := k.SetVaultNAV(ctx, vault, nav, msg.Signer); err != nil {
			return nil, fmt.Errorf("failed to update vault NAV for denom %q at index %d: %w", nav.Denom, i, err)
		}
	}

	if msg.Resume {
		if err := k.resumeVault(ctx, vault, msg.Signer); err != nil {
			return nil, err
		}
	}

	return &types.MsgRepriceVaultResponse{}, nil
}

// requireNAVAuthorityResumable requires the vault's current pause to be a strict one the
// signing NAV authority took itself, which is the only pause it may lift on its own.
func requireNAVAuthorityResumable(vault *types.VaultAccount, signer string) error {
	if !vault.Paused {
		return fmt.Errorf("vault %s is not paused: pause it before repricing and resuming", vault.Address)
	}
	if vault.PausedForced {
		return fmt.Errorf("vault %s is under a forced or automatic pause: the vault admin or asset manager must review and unpause it", vault.Address)
	}
	if vault.PausedBy != signer {
		return fmt.Errorf("vault %s was paused by %q rather than the NAV authority: the vault admin or asset manager must unpause it", vault.Address, vault.PausedBy)
	}
	return nil
}

// RemoveVaultNAV deletes a vault's internal NAV entry for a denom the vault does not
// hold, revoking the authorization to acquire that denom at that price. Only the
// vault's NAV authority is authorized to perform this operation.
//
// A denom still held at the principal marker cannot be removed: dropping its entry
// would erase the held balance from the vault's value rather than restate it. Such an
// asset is written down through UpdateVaultNAV, and the settlement path removes the
// entry on its own once an outbound trade drains the denom.
//
// Removal is accepted whether or not the vault is paused: the held-balance check above is
// what keeps it from moving value, in either state.
//
// No reconcile is needed first: an unheld denom contributes nothing to total vault
// value, so removing its entry cannot move the valuation basis.
func (k msgServer) RemoveVaultNAV(goCtx context.Context, msg *types.MsgRemoveVaultNAVRequest) (*types.MsgRemoveVaultNAVResponse, error) {
	ctx := sdk.UnwrapSDKContext(goCtx)

	vaultAddr := sdk.MustAccAddressFromBech32(msg.VaultAddress)
	vault, err := k.getVault(ctx, vaultAddr)
	if err != nil {
		return nil, fmt.Errorf("failed to get vault %s: %w", msg.VaultAddress, err)
	}
	if err := vault.ValidateNAVAuthority(msg.Signer); err != nil {
		return nil, fmt.Errorf("failed to validate NAV authority: %w", err)
	}

	balance := k.BankKeeper.GetBalance(ctx, vault.PrincipalMarkerAddress(), msg.Denom)
	if !balance.IsZero() {
		return nil, fmt.Errorf("vault %s still holds %s: write a held asset down through UpdateVaultNAV instead of removing its NAV", msg.VaultAddress, balance)
	}

	if err := k.Keeper.RemoveVaultNAV(ctx, vault, msg.Denom, msg.Signer); err != nil {
		return nil, fmt.Errorf("failed to remove vault NAV: %w", err)
	}

	return &types.MsgRemoveVaultNAVResponse{}, nil
}

// UpdateNAVAuthority rotates the address authorized to mutate a vault's internal
// NAV table. Only the vault admin is authorized to perform this operation.
func (k msgServer) UpdateNAVAuthority(goCtx context.Context, msg *types.MsgUpdateNAVAuthorityRequest) (*types.MsgUpdateNAVAuthorityResponse, error) {
	ctx := sdk.UnwrapSDKContext(goCtx)

	vaultAddr := sdk.MustAccAddressFromBech32(msg.VaultAddress)
	vault, err := k.getVault(ctx, vaultAddr)
	if err != nil {
		return nil, fmt.Errorf("failed to get vault %s: %w", msg.VaultAddress, err)
	}
	if err := vault.ValidateAdmin(msg.Signer); err != nil {
		return nil, fmt.Errorf("failed to validate admin: %w", err)
	}
	if err := k.SetNAVAuthority(ctx, vault, msg.NewAuthority, msg.Signer); err != nil {
		return nil, fmt.Errorf("failed to set NAV authority: %w", err)
	}

	return &types.MsgUpdateNAVAuthorityResponse{}, nil
}

// AcceptAsset settles a pending exchange-module payment whose target is the vault,
// exchanging an external asset for the vault's underlying asset. Only the vault's asset
// manager may sign it; the admin cannot settle.
//
// The exchange module's AcceptPayment operates on the caller's primary account, so the
// vault account is used as an atomic staging hop while the principal marker account
// remains the long-term store:
//
//	Principal -> Vault (target_amount), AcceptPayment, Vault -> Principal (source_amount)
//
// All steps run in the message handler; any failure reverts the whole transaction. The
// settlement direction (inbound or outbound) is derived from which payment leg carries
// the vault's underlying asset.
func (k msgServer) AcceptAsset(goCtx context.Context, msg *types.MsgAcceptAssetRequest) (*types.MsgAcceptAssetResponse, error) {
	ctx := sdk.UnwrapSDKContext(goCtx)

	vaultAddr := sdk.MustAccAddressFromBech32(msg.VaultAddress)
	vault, err := k.getVault(ctx, vaultAddr)
	if err != nil {
		return nil, err
	}
	if err = vault.ValidateAssetManagerAuthority(msg.Authority); err != nil {
		return nil, fmt.Errorf("failed to validate asset manager authority: %w", err)
	}
	if vault.Paused {
		return nil, fmt.Errorf("vault %s is paused: assets cannot be accepted while paused", msg.VaultAddress)
	}

	sourceAddr, err := sdk.AccAddressFromBech32(msg.Payment.Source)
	if err != nil {
		return nil, fmt.Errorf("invalid payment source address %q: %w", msg.Payment.Source, err)
	}
	payment, err := k.ExchangeKeeper.GetPayment(ctx, sourceAddr, msg.Payment.ExternalId)
	if err != nil {
		return nil, fmt.Errorf("failed to get payment: %w", err)
	}
	if payment == nil {
		return nil, fmt.Errorf("payment not found for source %s and external id %q", msg.Payment.Source, msg.Payment.ExternalId)
	}
	if err = msg.Payment.ValidateMatches(payment); err != nil {
		return nil, fmt.Errorf("stored payment no longer matches the approved terms: %w", err)
	}
	if payment.Target != msg.VaultAddress {
		return nil, fmt.Errorf("payment target %s is not vault %s", payment.Target, msg.VaultAddress)
	}

	direction, err := assetSettlementDirection(vault, payment)
	if err != nil {
		return nil, err
	}

	assetCoin, paymentCoin, err := settlementLegCoins(payment, direction, vault.UnderlyingAsset)
	if err != nil {
		return nil, fmt.Errorf("failed to resolve settlement leg coins: %w", err)
	}
	if err := k.checkSettlementNAVGuardrail(ctx, vault, assetCoin, paymentCoin); err != nil {
		return nil, err
	}

	if err := k.reconcileVault(ctx, vault); err != nil {
		return nil, fmt.Errorf("failed to reconcile vault before settlement: %w", err)
	}

	principalAddr := vault.PrincipalMarkerAddress()

	for _, coin := range payment.TargetAmount {
		if bal := k.BankKeeper.GetBalance(ctx, principalAddr, coin.Denom); bal.Amount.LT(coin.Amount) {
			return nil, fmt.Errorf("insufficient principal balance for %s: have %s, need %s", coin.Denom, bal.Amount, coin.Amount)
		}
	}

	if err := k.stageFromPrincipal(ctx, vault, payment.TargetAmount); err != nil {
		return nil, fmt.Errorf("failed to stage target amount from principal to vault: %w", err)
	}

	if err := k.ExchangeKeeper.AcceptPayment(ctx, payment); err != nil {
		return nil, fmt.Errorf("failed to accept payment: %w", err)
	}

	if err := k.returnToPrincipal(ctx, vault, payment.SourceAmount); err != nil {
		return nil, fmt.Errorf("failed to move source amount from vault to principal: %w", err)
	}

	k.emitEvent(ctx, types.NewEventAssetAccepted(msg.VaultAddress, payment.Source, payment.ExternalId, payment.SourceAmount, payment.TargetAmount, direction))

	if err := k.removeDrainedSettlementNAV(ctx, vault, assetCoin.Denom, direction); err != nil {
		return nil, err
	}

	return &types.MsgAcceptAssetResponse{}, nil
}

// RejectAsset declines a pending exchange-module payment whose target is the vault. The
// exchange module cancels the payment and refunds the source's escrow. Only the vault's
// asset manager may sign it; the admin cannot reject.
func (k msgServer) RejectAsset(goCtx context.Context, msg *types.MsgRejectAssetRequest) (*types.MsgRejectAssetResponse, error) {
	ctx := sdk.UnwrapSDKContext(goCtx)

	vaultAddr := sdk.MustAccAddressFromBech32(msg.VaultAddress)
	vault, err := k.getVault(ctx, vaultAddr)
	if err != nil {
		return nil, err
	}
	if err := vault.ValidateAssetManagerAuthority(msg.Authority); err != nil {
		return nil, fmt.Errorf("failed to validate asset manager authority: %w", err)
	}

	sourceAddr := sdk.MustAccAddressFromBech32(msg.Source)
	if err := k.ExchangeKeeper.RejectPayment(ctx, vaultAddr, sourceAddr, msg.ExternalId); err != nil {
		return nil, fmt.Errorf("failed to reject payment: %w", err)
	}

	k.emitEvent(ctx, types.NewEventAssetRejected(msg.VaultAddress, msg.Source, msg.ExternalId))

	return &types.MsgRejectAssetResponse{}, nil
}

// assetSettlementDirection determines whether a payment settles inbound or outbound for a
// vault, based on which leg carries the vault's underlying asset. The vault settles
// payments where its underlying asset is exactly one of the two legs: it pays the
// underlying out (inbound, target leg) or receives it in (outbound, source leg). A payment
// with the underlying on both legs cannot be settled.
//
// A zero-priced asset carries the underlying on neither leg (the zero coin is stripped),
// so direction is inferred from the leg holding the asset: an asset on the source leg moves
// into the vault (inbound), an asset on the target leg moves out (outbound). A zero-priced
// payment with an asset on both legs, or on neither, cannot be settled.
func assetSettlementDirection(vault *types.VaultAccount, payment *exchange.Payment) (string, error) {
	underlying := vault.UnderlyingAsset
	sourceHasUnderlying := payment.SourceAmount.AmountOf(underlying).IsPositive()
	targetHasUnderlying := payment.TargetAmount.AmountOf(underlying).IsPositive()

	switch {
	case targetHasUnderlying && !sourceHasUnderlying:
		return types.AssetDirectionInbound, nil
	case sourceHasUnderlying && !targetHasUnderlying:
		return types.AssetDirectionOutbound, nil
	case sourceHasUnderlying && targetHasUnderlying:
		return "", fmt.Errorf("payment must carry vault underlying asset %q on exactly one leg: source_amount=%q target_amount=%q", underlying, payment.SourceAmount, payment.TargetAmount)
	}

	// Neither leg carries the underlying asset: a zero-priced settlement. Infer direction
	// from the leg holding the asset.
	switch {
	case payment.TargetAmount.IsZero() && !payment.SourceAmount.IsZero():
		return types.AssetDirectionInbound, nil
	case payment.SourceAmount.IsZero() && !payment.TargetAmount.IsZero():
		return types.AssetDirectionOutbound, nil
	default:
		return "", fmt.Errorf("zero-priced payment must carry the asset on exactly one leg: source_amount=%q target_amount=%q", payment.SourceAmount, payment.TargetAmount)
	}
}
