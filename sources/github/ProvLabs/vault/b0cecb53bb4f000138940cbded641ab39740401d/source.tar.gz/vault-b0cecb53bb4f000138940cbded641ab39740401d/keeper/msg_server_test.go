package keeper_test

import (
	"context"
	"fmt"
	"math/big"
	"time"

	"cosmossdk.io/collections"
	"cosmossdk.io/math"
	sdkmath "cosmossdk.io/math"
	"github.com/cosmos/cosmos-sdk/crypto/keys/secp256k1"
	sdk "github.com/cosmos/cosmos-sdk/types"
	authtypes "github.com/cosmos/cosmos-sdk/x/auth/types"
	banktypes "github.com/cosmos/cosmos-sdk/x/bank/types"
	markertypes "github.com/provenance-io/provenance/x/marker/types"

	"github.com/provlabs/vault/keeper"
	"github.com/provlabs/vault/types"
	"github.com/provlabs/vault/utils"
)

func (s *TestSuite) TestMsgServer_CreateVault() {
	type postCheckArgs struct {
		UnderlyingAsset string
		ShareDenom      string
		Admin           string
		VaultAddr       sdk.AccAddress
		MinSwapInValue  string
		MinSwapOutValue string
		MaxSwapInValue  string
		MaxSwapOutValue string
	}

	testDef := msgServerTestDef[types.MsgCreateVaultRequest, types.MsgCreateVaultResponse, postCheckArgs]{
		endpointName: "CreateVault",
		endpoint:     keeper.NewMsgServer(s.simApp.VaultKeeper).CreateVault,
		postCheck: func(msg *types.MsgCreateVaultRequest, postCheckArgs postCheckArgs) {
			markerAddr := markertypes.MustGetMarkerAddress(postCheckArgs.ShareDenom)

			marker, err := s.simApp.MarkerKeeper.GetMarker(s.ctx, markerAddr)
			s.Require().NoError(err, "failed to get marker for share denom %s", postCheckArgs.ShareDenom)

			s.EqualValues(0, marker.GetSupply().Amount.Int64(), "vault marker supply mismatch for share denom %s", postCheckArgs.ShareDenom)
			s.False(marker.AllowsForcedTransfer(), "vault marker %s should not have forced transfer enabled", postCheckArgs.ShareDenom)
			s.False(marker.HasGovernanceEnabled(), "vault marker %s should not have governance enabled", postCheckArgs.ShareDenom)
			s.True(marker.GetMarkerType() == markertypes.MarkerType_Coin, "vault marker %s should be of type COIN", postCheckArgs.ShareDenom)
			s.False(marker.HasGovernanceEnabled(), "vault marker %s should not allow governance control", postCheckArgs.ShareDenom)
			s.True(marker.RequiresDepositAccess(), "vault marker %s should require deposit access for incoming coins", postCheckArgs.ShareDenom)

			access := marker.GetAccessList()
			s.Require().Len(access, 1, "expected exactly one access entry for vault marker %s", postCheckArgs.ShareDenom)
			s.Equal(types.GetVaultAddress(postCheckArgs.ShareDenom).String(), access[0].Address, "vault marker %s access should be granted to vault account", postCheckArgs.ShareDenom)
			s.ElementsMatch(
				[]markertypes.Access{
					markertypes.Access_Mint,
					markertypes.Access_Burn,
					markertypes.Access_Withdraw,
					markertypes.Access_Deposit,
				},
				access[0].Permissions,
				"vault marker %s permissions mismatch", postCheckArgs.ShareDenom,
			)

			// Check vault record exists
			account := s.simApp.AccountKeeper.GetAccount(s.ctx, postCheckArgs.VaultAddr)
			s.Require().NotNil(account, "vault account %s not found in state", postCheckArgs.VaultAddr)

			vaultAcc, ok := account.(*types.VaultAccount)
			s.Require().True(ok, "account %s is not of type *VaultAccount", postCheckArgs.VaultAddr)

			s.Equal(postCheckArgs.Admin, vaultAcc.GetAdmin(), "vault %s admin address mismatch", postCheckArgs.VaultAddr)
			s.Equal(
				types.GetVaultAddress(postCheckArgs.ShareDenom),
				vaultAcc.GetAddress(),
				"vault %s address mismatch; derived address differs", postCheckArgs.VaultAddr,
			)
			s.Equal(
				postCheckArgs.UnderlyingAsset,
				vaultAcc.GetUnderlyingAsset(),
				"vault %s underlying asset denom mismatch", postCheckArgs.VaultAddr,
			)
			s.Equal(vaultAcc.GetTotalShares(), sdk.NewCoin(postCheckArgs.ShareDenom, math.ZeroInt()), "vault %s initial total shares should be zero", postCheckArgs.VaultAddr)
			s.Equal(postCheckArgs.MinSwapInValue, vaultAcc.MinSwapInValue, "vault %s min swap in value mismatch", postCheckArgs.VaultAddr)
			s.Equal(postCheckArgs.MinSwapOutValue, vaultAcc.MinSwapOutValue, "vault %s min swap out value mismatch", postCheckArgs.VaultAddr)
			s.Equal(postCheckArgs.MaxSwapInValue, vaultAcc.MaxSwapInValue, "vault %s max swap in value mismatch", postCheckArgs.VaultAddr)
			s.Equal(postCheckArgs.MaxSwapOutValue, vaultAcc.MaxSwapOutValue, "vault %s max swap out value mismatch", postCheckArgs.VaultAddr)
		},
	}

	underlying := "undercoin"
	sharedenom := "jackthecat"
	admin := s.adminAddr.String()
	vaultAddr := types.GetVaultAddress(sharedenom)

	vaultReq := types.MsgCreateVaultRequest{
		Authority:       s.govAuthority,
		Admin:           admin,
		ShareDenom:      sharedenom,
		UnderlyingAsset: underlying,
		MinSwapInValue:  "100",
		MinSwapOutValue: "50",
		MaxSwapInValue:  "1000",
		MaxSwapOutValue: "500",
	}

	tc := msgServerTestCase[types.MsgCreateVaultRequest, postCheckArgs]{
		name: "happy path",
		setup: func() {
			s.requireAddFinalizeAndActivateMarker(sdk.NewCoin(underlying, math.NewInt(100)), s.adminAddr)
		},
		msg:                vaultReq,
		expectedErrSubstrs: nil,
		postCheckArgs: postCheckArgs{
			UnderlyingAsset: underlying,
			ShareDenom:      sharedenom,
			Admin:           admin,
			VaultAddr:       vaultAddr,
			MinSwapInValue:  "100",
			MinSwapOutValue: "50",
			MaxSwapInValue:  "1000",
			MaxSwapOutValue: "500",
		},
		expectedEvents: sdk.Events{
			sdk.NewEvent("provenance.marker.v1.EventMarkerAdd",
				sdk.NewAttribute("address", "provlabs157rf76qwxlttnjyncsaxvelc96m9e5eedpymea"),
				sdk.NewAttribute("amount", "0"),
				sdk.NewAttribute("denom", sharedenom),
				sdk.NewAttribute("manager", vaultAddr.String()),
				sdk.NewAttribute("marker_type", "MARKER_TYPE_COIN"),
				sdk.NewAttribute("status", "proposed"),
			),
			sdk.NewEvent("provenance.marker.v1.EventMarkerFinalize",
				sdk.NewAttribute("administrator", vaultAddr.String()),
				sdk.NewAttribute("denom", sharedenom),
			),
			sdk.NewEvent("provenance.marker.v1.EventMarkerActivate",
				sdk.NewAttribute("administrator", vaultAddr.String()),
				sdk.NewAttribute("denom", sharedenom),
			),
			sdk.NewEvent("provlabs.vault.v1.EventVaultCreated",
				sdk.NewAttribute("admin", admin),
				sdk.NewAttribute("share_denom", sharedenom),
				sdk.NewAttribute("underlying_asset", underlying),
				sdk.NewAttribute("vault_address", vaultAddr.String()),
			),
		},
	}

	testDef.expectedResponse = &types.MsgCreateVaultResponse{VaultAddress: vaultAddr.String()}
	runMsgServerTestCase(s, testDef, tc)
}

func (s *TestSuite) TestMsgServer_CreateVault_Failures() {
	testDef := msgServerTestDef[types.MsgCreateVaultRequest, types.MsgCreateVaultResponse, any]{
		endpointName: "CreateVault",
		endpoint:     keeper.NewMsgServer(s.simApp.VaultKeeper).CreateVault,
		postCheck:    nil,
	}

	tests := []msgServerTestCase[types.MsgCreateVaultRequest, any]{
		{
			name: "gov gate enabled and authority is the vault admin instead of governance",
			setup: func() {
				s.SetGovOnlyVaultCreation(true)
				s.requireAddFinalizeAndActivateMarker(sdk.NewInt64Coin("assetcoin", 100), s.adminAddr)
			},
			msg: types.MsgCreateVaultRequest{
				Authority:       s.adminAddr.String(),
				Admin:           s.adminAddr.String(),
				ShareDenom:      "sharecoin",
				UnderlyingAsset: "assetcoin",
			},
			expectedErrSubstrs: []string{"unauthorized: expected " + s.govAuthority + " got " + s.adminAddr.String()},
		},
		{
			name: "gov gate enabled and authority is empty",
			setup: func() {
				s.SetGovOnlyVaultCreation(true)
				s.requireAddFinalizeAndActivateMarker(sdk.NewInt64Coin("assetcoin", 100), s.adminAddr)
			},
			msg: types.MsgCreateVaultRequest{
				Admin:           s.adminAddr.String(),
				ShareDenom:      "sharecoin",
				UnderlyingAsset: "assetcoin",
			},
			expectedErrSubstrs: []string{"unauthorized: expected " + s.govAuthority + " got "},
		},
		{
			name: "invalid admin address",
			setup: func() {
				s.requireAddFinalizeAndActivateMarker(sdk.NewInt64Coin("assetcoin", 100), s.adminAddr)
			},
			msg: types.MsgCreateVaultRequest{
				Authority:       s.govAuthority,
				Admin:           "invalid_bech32",
				ShareDenom:      "sharecoin",
				UnderlyingAsset: "assetcoin",
			},
			expectedErrSubstrs: []string{"failed to create vault account: failed to validate vault account: invalid admin address: decoding bech32"},
		},
		{
			name: "invalid share denom",
			setup: func() {
				s.requireAddFinalizeAndActivateMarker(sdk.NewInt64Coin("assetcoin", 100), s.adminAddr)
			},
			msg: types.MsgCreateVaultRequest{
				Authority:       s.govAuthority,
				Admin:           s.adminAddr.String(),
				ShareDenom:      "invalid denom!",
				UnderlyingAsset: "assetcoin",
			},
			expectedErrSubstrs: []string{"failed to create vault account: failed to validate vault account: invalid share denom: invalid denom: invalid denom!"},
		},
		{
			name: "underlying asset marker not found",
			msg: types.MsgCreateVaultRequest{
				Authority:       s.govAuthority,
				Admin:           s.adminAddr.String(),
				ShareDenom:      "vaulttoken",
				UnderlyingAsset: "nonexistentasset",
			},
			expectedErrSubstrs: []string{"underlying asset marker \"nonexistentasset\" not found"},
		},
		{
			name: "share denom marker already exists",
			setup: func() {
				s.requireAddFinalizeAndActivateMarker(sdk.NewInt64Coin("existingmarker", 1), s.adminAddr)
				s.requireAddFinalizeAndActivateMarker(sdk.NewInt64Coin("under", 1), s.adminAddr)
			},
			msg: types.MsgCreateVaultRequest{
				Authority:       s.govAuthority,
				Admin:           s.adminAddr.String(),
				ShareDenom:      "existingmarker",
				UnderlyingAsset: "under",
			},
			expectedErrSubstrs: []string{"already exists"},
		},
	}

	for _, tc := range tests {
		s.Run(tc.name, func() {
			runMsgServerTestCase(s, testDef, tc)
		})
	}
}

func (s *TestSuite) TestMsgServer_CreateVault_GovOnlyGate() {
	msgServer := keeper.NewMsgServer(s.simApp.VaultKeeper)
	admin := s.adminAddr.String()

	tests := []struct {
		name              string
		govOnly           bool
		authority         string
		expectedErrSubstr string
	}{
		{
			name:      "gate disabled, the admin creates the vault directly",
			govOnly:   false,
			authority: admin,
		},
		{
			name:      "gate disabled, governance may still create the vault",
			govOnly:   false,
			authority: s.govAuthority,
		},
		{
			name:      "gate enabled, governance creates the vault",
			govOnly:   true,
			authority: s.govAuthority,
		},
		{
			name:              "gate enabled, a direct creation by the admin is rejected",
			govOnly:           true,
			authority:         admin,
			expectedErrSubstr: "unauthorized: expected " + s.govAuthority + " got " + admin,
		},
	}

	for i, tc := range tests {
		s.Run(tc.name, func() {
			origCtx := s.ctx
			defer func() { s.ctx = origCtx }()
			s.ctx, _ = s.ctx.CacheContext()

			s.SetGovOnlyVaultCreation(tc.govOnly)

			underlying := fmt.Sprintf("gateasset%d", i)
			shareDenom := fmt.Sprintf("gateshare%d", i)
			vaultAddr := types.GetVaultAddress(shareDenom)
			s.requireAddFinalizeAndActivateMarker(sdk.NewInt64Coin(underlying, 100), s.adminAddr)

			resp, err := msgServer.CreateVault(s.ctx, &types.MsgCreateVaultRequest{
				Authority:       tc.authority,
				Admin:           admin,
				ShareDenom:      shareDenom,
				UnderlyingAsset: underlying,
			})

			if tc.expectedErrSubstr != "" {
				s.Require().Error(err, "CreateVault signed by %s should be rejected while gov_only_vault_creation is %t", tc.authority, tc.govOnly)
				s.Assert().Contains(err.Error(), tc.expectedErrSubstr, "unexpected CreateVault error for signer %s", tc.authority)
				rejected, getErr := s.k.GetVault(s.ctx, vaultAddr)
				s.Require().NoError(getErr, "failed to look up vault %s after a rejected creation", shareDenom)
				s.Assert().Nil(rejected, "no vault should exist for share denom %s after a rejected creation", shareDenom)
				return
			}

			s.Require().NoError(err, "CreateVault signed by %s should succeed while gov_only_vault_creation is %t", tc.authority, tc.govOnly)
			s.Require().Equal(vaultAddr.String(), resp.VaultAddress, "created vault address for share denom %s", shareDenom)

			created, getErr := s.k.GetVault(s.ctx, vaultAddr)
			s.Require().NoError(getErr, "failed to look up vault %s after creation", shareDenom)
			s.Require().NotNil(created, "vault %s should exist after a successful creation", shareDenom)
			s.Assert().Equal(admin, created.Admin, "vault %s admin should be the designated admin, not the signer", shareDenom)
		})
	}
}

func (s *TestSuite) TestMsgServer_SetShareDenomMetadata() {
	type postCheckArgs struct {
		VaultAddress     sdk.AccAddress
		ExpectedMetadata banktypes.Metadata
	}

	testDef := msgServerTestDef[types.MsgSetShareDenomMetadataRequest, types.MsgSetShareDenomMetadataResponse, postCheckArgs]{
		endpointName: "SetShareDenomMetadata",
		endpoint:     keeper.NewMsgServer(s.simApp.VaultKeeper).SetShareDenomMetadata,
		postCheck: func(msg *types.MsgSetShareDenomMetadataRequest, args postCheckArgs) {
			actualMetadata, found := s.simApp.BankKeeper.GetDenomMetaData(s.ctx, args.ExpectedMetadata.Base)
			s.Require().True(found, "metadata for denom %s not found in BankKeeper after update", args.ExpectedMetadata.Base)
			s.Assert().Equal(args.ExpectedMetadata.Base, actualMetadata.Base, "metadata base denom mismatch for %s", args.ExpectedMetadata.Base)
			s.Assert().Equal(args.ExpectedMetadata.Display, actualMetadata.Display, "metadata display denom mismatch for %s", args.ExpectedMetadata.Base)
			s.Assert().Equal(args.ExpectedMetadata.Description, actualMetadata.Description, "metadata description mismatch for %s", args.ExpectedMetadata.Base)
			s.Assert().Equal(args.ExpectedMetadata.Name, actualMetadata.Name, "metadata name mismatch for %s", args.ExpectedMetadata.Base)
			s.Assert().Equal(args.ExpectedMetadata.Symbol, actualMetadata.Symbol, "metadata symbol mismatch for %s", args.ExpectedMetadata.Base)
			s.Assert().Equal(len(args.ExpectedMetadata.DenomUnits), len(actualMetadata.DenomUnits), "metadata denom units count mismatch for %s", args.ExpectedMetadata.Base)
		},
	}

	underlying := "under"
	share := "vaultshares"
	admin := s.adminAddr
	vaultAddr := types.GetVaultAddress(share)

	metadata := banktypes.Metadata{
		Base:        share,
		Display:     share,
		Description: "Vault shares for testing",
		Name:        "Vault Shares",
		Symbol:      "VSHARES",
		DenomUnits: []*banktypes.DenomUnit{
			{
				Denom:    share,
				Exponent: 0,
				Aliases:  []string{"vshare"},
			},
			{
				Denom:    "mvshare",
				Exponent: 6,
				Aliases:  []string{},
			},
		},
	}

	setup := func() {
		s.requireAddFinalizeAndActivateMarker(sdk.NewCoin(underlying, math.NewInt(1000)), admin)
		_, err := s.k.CreateVault(s.ctx, &types.MsgCreateVaultRequest{
			Admin:           admin.String(),
			ShareDenom:      share,
			UnderlyingAsset: underlying,
		})
		s.Require().NoError(err, "setup: expected vault creation to succeed")
		s.ctx = s.ctx.WithEventManager(sdk.NewEventManager())
	}

	tc := msgServerTestCase[types.MsgSetShareDenomMetadataRequest, postCheckArgs]{
		name:  "happy path",
		setup: setup,
		msg: types.MsgSetShareDenomMetadataRequest{
			Admin:        admin.String(),
			VaultAddress: vaultAddr.String(),
			Metadata:     metadata,
		},
		postCheckArgs: postCheckArgs{
			VaultAddress:     vaultAddr,
			ExpectedMetadata: metadata,
		},
		expectedEvents: sdk.Events{
			sdk.NewEvent("provlabs.vault.v1.EventSetShareDenomMetadata",
				sdk.NewAttribute("administrator", admin.String()),
				sdk.NewAttribute("metadata_base", share),
				sdk.NewAttribute("metadata_denom_units", `[{"denom":"vaultshares","exponent":"0","aliases":["vshare"]},{"denom":"mvshare","exponent":"6","aliases":[]}]`),
				sdk.NewAttribute("metadata_description", "Vault shares for testing"),
				sdk.NewAttribute("metadata_display", share),
				sdk.NewAttribute("metadata_name", "Vault Shares"),
				sdk.NewAttribute("metadata_symbol", "VSHARES"),
				sdk.NewAttribute("vault_address", vaultAddr.String()),
			),
		},
	}

	testDef.expectedResponse = &types.MsgSetShareDenomMetadataResponse{}
	runMsgServerTestCase(s, testDef, tc)
}

func (s *TestSuite) TestMsgServer_SetShareDenomMetadata_Failures() {
	testDef := msgServerTestDef[types.MsgSetShareDenomMetadataRequest, types.MsgSetShareDenomMetadataResponse, any]{
		endpointName: "SetShareDenomMetadata",
		endpoint:     keeper.NewMsgServer(s.simApp.VaultKeeper).SetShareDenomMetadata,
		postCheck:    nil,
	}

	underlying := "under"
	share := "vaultshares"
	wrongShare := "wrongshares"
	admin := s.adminAddr
	other := s.CreateAndFundAccount(sdk.NewInt64Coin("stake", 1))
	vaultAddr := types.GetVaultAddress(share)
	markerAddr := markertypes.MustGetMarkerAddress(share)

	validMetadata := banktypes.Metadata{
		Base:        share,
		Display:     share,
		Description: "Vault shares for testing",
		Name:        "Vault Shares",
		Symbol:      "VSHARES",
		DenomUnits: []*banktypes.DenomUnit{
			{
				Denom:    share,
				Exponent: 0,
				Aliases:  []string{},
			},
		},
	}

	wrongMetadata := banktypes.Metadata{
		Base:        wrongShare,
		Display:     wrongShare,
		Description: "Wrong vault shares",
		Name:        "Wrong Shares",
		Symbol:      "WRONG",
		DenomUnits: []*banktypes.DenomUnit{
			{
				Denom:    wrongShare,
				Exponent: 0,
				Aliases:  []string{},
			},
		},
	}

	base := func() {
		s.requireAddFinalizeAndActivateMarker(sdk.NewCoin(underlying, math.NewInt(1000)), admin)
		_, err := s.k.CreateVault(s.ctx, &types.MsgCreateVaultRequest{
			Admin:           admin.String(),
			ShareDenom:      share,
			UnderlyingAsset: underlying,
		})
		s.Require().NoError(err, "base: expected vault creation to succeed")
		s.ctx = s.ctx.WithEventManager(sdk.NewEventManager())
	}

	tests := []msgServerTestCase[types.MsgSetShareDenomMetadataRequest, any]{
		{
			name: "vault not found",
			setup: func() {
				s.ctx = s.ctx.WithEventManager(sdk.NewEventManager())
			},
			msg: types.MsgSetShareDenomMetadataRequest{
				Admin:        admin.String(),
				VaultAddress: types.GetVaultAddress("missing").String(),
				Metadata:     validMetadata,
			},
			expectedErrSubstrs: []string{"vault not found"},
		},
		{
			name:  "invalid vault address (not a vault account)",
			setup: base,
			msg: types.MsgSetShareDenomMetadataRequest{
				Admin:        admin.String(),
				VaultAddress: markerAddr.String(),
				Metadata:     validMetadata,
			},
			expectedErrSubstrs: []string{"failed to get vault", "is not a vault account"},
		},
		{
			name:  "unauthorized admin",
			setup: base,
			msg: types.MsgSetShareDenomMetadataRequest{
				Admin:        other.String(),
				VaultAddress: vaultAddr.String(),
				Metadata:     validMetadata,
			},
			expectedErrSubstrs: []string{"unauthorized", "is not the vault admin"},
		},
		{
			name:  "metadata base denom does not match vault share denom",
			setup: base,
			msg: types.MsgSetShareDenomMetadataRequest{
				Admin:        admin.String(),
				VaultAddress: vaultAddr.String(),
				Metadata:     wrongMetadata,
			},
			expectedErrSubstrs: []string{"metadata base denom", "does not match vault share denom"},
		},
	}

	for _, tc := range tests {
		s.Run(tc.name, func() {
			runMsgServerTestCase(s, testDef, tc)
		})
	}
}

func (s *TestSuite) TestMsgServer_SwapIn() {
	type postCheckArgs struct {
		Owner           sdk.AccAddress
		VaultAddr       sdk.AccAddress
		MarkerAddr      sdk.AccAddress
		UnderlyingAsset sdk.Coin
		Shares          sdk.Coin
	}

	testDef := msgServerTestDef[types.MsgSwapInRequest, types.MsgSwapInResponse, postCheckArgs]{
		endpointName: "SwapIn",
		endpoint:     keeper.NewMsgServer(s.simApp.VaultKeeper).SwapIn,
		postCheck: func(msg *types.MsgSwapInRequest, args postCheckArgs) {
			// Check that the marker created by the vault has a supply of 100.
			markerAddr := markertypes.MustGetMarkerAddress(args.Shares.Denom)
			marker, err := s.simApp.MarkerKeeper.GetMarker(s.ctx, markerAddr)
			s.Require().NoError(err, "failed to get marker for share denom %s", args.Shares.Denom)
			s.Require().NotNil(marker, "marker for share denom %s should exist", args.Shares.Denom)
			supply := s.simApp.BankKeeper.GetSupply(s.ctx, args.Shares.Denom)
			s.Require().Equal(args.Shares.Amount, supply.Amount, "marker supply mismatch for share denom %s", args.Shares.Denom)

			// Check that the balance of the vault account has increased by the denom in the Msg.
			vaultBalance := s.simApp.BankKeeper.GetBalance(s.ctx, markerAddr, args.UnderlyingAsset.Denom)
			s.Require().Equal(args.UnderlyingAsset, vaultBalance, "vault balance mismatch for denom %s", args.UnderlyingAsset.Denom)

			// Check that the owner's balance contains the shares.
			ownerBalance := s.simApp.BankKeeper.GetBalance(s.ctx, args.Owner, args.Shares.Denom)
			s.Require().Equal(args.Shares, ownerBalance, "owner share balance mismatch for user %s", args.Owner)
		},
	}

	underlyingDenom := "underlying"
	shareDenom := "vaultshares"
	owner := s.adminAddr
	vaultAddr := types.GetVaultAddress(shareDenom)
	markerAddr := markertypes.MustGetMarkerAddress(shareDenom)
	assets := sdk.NewInt64Coin(underlyingDenom, 100)
	expectedShares := sdk.NewCoin(shareDenom, assets.Amount.Mul(utils.ShareScalar))

	swapInReq := types.MsgSwapInRequest{
		Owner:        owner.String(),
		VaultAddress: vaultAddr.String(),
		Assets:       assets,
	}

	tc := msgServerTestCase[types.MsgSwapInRequest, postCheckArgs]{
		name: "happy path",
		setup: func() {
			s.ctx = s.ctx.WithBlockTime(time.Now())
			s.requireAddFinalizeAndActivateMarker(sdk.NewCoin(underlyingDenom, math.NewInt(1000)), owner)
			vault, err := s.k.CreateVault(s.ctx, &types.MsgCreateVaultRequest{
				Admin:           owner.String(),
				ShareDenom:      shareDenom,
				UnderlyingAsset: underlyingDenom,
			})
			s.Require().NoError(err, "failed to create vault in TestMsgServer_SwapIn setup")
			vault.SwapInEnabled = true
			s.k.AuthKeeper.SetAccount(s.ctx, vault)
			// Fund owner with underlying assets
			err = FundAccount(s.ctx, s.simApp, owner, sdk.NewCoins(assets))
			s.Require().NoError(err, "failed to fund owner in TestMsgServer_SwapIn setup")
			s.ctx = s.ctx.WithEventManager(sdk.NewEventManager())
		},
		msg:                swapInReq,
		expectedErrSubstrs: nil,
		postCheckArgs:      postCheckArgs{Owner: owner, VaultAddr: vaultAddr, MarkerAddr: markerAddr, UnderlyingAsset: assets, Shares: expectedShares},
		expectedEvents:     createSwapInEvents(owner, vaultAddr, markerAddr, assets, expectedShares),
	}
	testDef.expectedResponse = &types.MsgSwapInResponse{SharesReceived: expectedShares}
	runMsgServerTestCase(s, testDef, tc)
}

func (s *TestSuite) TestMsgServer_SwapIn_Failures() {
	testDef := msgServerTestDef[types.MsgSwapInRequest, types.MsgSwapInResponse, any]{
		endpointName: "SwapIn",
		endpoint:     keeper.NewMsgServer(s.simApp.VaultKeeper).SwapIn,
		postCheck:    nil,
	}

	underlyingDenom := "underlying"
	shareDenom := "vaultshares"
	owner := s.adminAddr
	vaultAddr := types.GetVaultAddress(shareDenom)
	assets := sdk.NewInt64Coin(underlyingDenom, 100)

	setup := func(swapInEnabled, vaultPaused bool, minSwapIn, maxSwapIn string) func() {
		return func() {
			s.requireAddFinalizeAndActivateMarker(sdk.NewCoin(underlyingDenom, math.NewInt(1_000_000_000_000_000_000)), owner)
			vault, err := s.k.CreateVault(s.ctx, &types.MsgCreateVaultRequest{
				Admin:           owner.String(),
				ShareDenom:      shareDenom,
				UnderlyingAsset: underlyingDenom,
				MinSwapInValue:  minSwapIn,
				MaxSwapInValue:  maxSwapIn,
			})
			s.Require().NoError(err, "vault creation should succeed")
			vault.SwapInEnabled = swapInEnabled
			vault.Paused = vaultPaused
			s.k.AuthKeeper.SetAccount(s.ctx, vault)

			err = FundAccount(s.ctx, s.simApp, owner, sdk.NewCoins(sdk.NewInt64Coin(underlyingDenom, 1000)))
			s.Require().NoError(err, "funding owner with underlying should succeed")
		}
	}

	tests := []msgServerTestCase[types.MsgSwapInRequest, any]{
		{
			name: "vault not found returns not found error",
			msg: types.MsgSwapInRequest{
				Owner:        owner.String(),
				VaultAddress: vaultAddr.String(),
				Assets:       assets,
			},
			expectedErrSubstrs: []string{"vault", "not found"},
		},
		{
			name:  "swap in below minimum value",
			setup: setup(true, false, "200", ""),
			msg: types.MsgSwapInRequest{
				Owner:        owner.String(),
				VaultAddress: vaultAddr.String(),
				Assets:       sdk.NewInt64Coin(underlyingDenom, 50),
			},
			expectedErrSubstrs: []string{"below the minimum required value"},
		},
		{
			name:  "swap in above maximum value",
			setup: setup(true, false, "", "100"),
			msg: types.MsgSwapInRequest{
				Owner:        owner.String(),
				VaultAddress: vaultAddr.String(),
				Assets:       sdk.NewInt64Coin(underlyingDenom, 150),
			},
			expectedErrSubstrs: []string{"above the maximum allowed value"},
		},

		{
			name:  "swap in enabled, vaulted paused",
			setup: setup(true, true, "", ""),
			msg: types.MsgSwapInRequest{
				Owner:        owner.String(),
				VaultAddress: vaultAddr.String(),
				Assets:       assets,
			},
			expectedErrSubstrs: []string{"vault", "is paused"},
		},
		{
			name:  "swap in disabled is rejected",
			setup: setup(false, false, "", ""),
			msg: types.MsgSwapInRequest{
				Owner:        owner.String(),
				VaultAddress: vaultAddr.String(),
				Assets:       assets,
			},
			expectedErrSubstrs: []string{"swaps are not enabled for vault"},
		},
		{
			name:  "underlying denom mismatch is rejected",
			setup: setup(true, false, "", ""),
			msg: types.MsgSwapInRequest{
				Owner:        owner.String(),
				VaultAddress: vaultAddr.String(),
				Assets:       sdk.NewInt64Coin("othercoin", 100),
			},
			expectedErrSubstrs: []string{"denom not supported for vault; must be \"underlying\": got \"othercoin\""},
		},
		{
			name: "insufficient owner funds is rejected",
			setup: func() {
				setup(true, false, "", "")()
				err := s.simApp.BankKeeper.SendCoins(s.ctx, owner, authtypes.NewModuleAddress("burn"),
					sdk.NewCoins(sdk.NewInt64Coin(underlyingDenom, 950)))
				s.Require().NoError(err, "reducing owner's balance should succeed")
			},
			msg:                types.MsgSwapInRequest{Owner: owner.String(), VaultAddress: vaultAddr.String(), Assets: assets},
			expectedErrSubstrs: []string{"insufficient funds"},
		},
		{
			name: "swap in minted shares exceeding maximum mintable supply (precision-scaled above underlying assets) is rejected",
			setup: func() {
				setup(true, false, "", "")()
				err := FundAccount(s.ctx, s.simApp, owner,
					sdk.NewCoins(sdk.NewInt64Coin(underlyingDenom, 1_000_000_000_000_000)))
				s.Require().NoError(err, "funding owner with very large underlying should succeed")
			},
			msg: types.MsgSwapInRequest{
				Owner:        owner.String(),
				VaultAddress: vaultAddr.String(),
				Assets:       sdk.NewCoin(underlyingDenom, math.NewInt(1_000_000_000_000_000)),
			},
			expectedErrSubstrs: []string{
				"requested supply 1000000000000000000000 exceeds maximum allowed value 100000000000000000000",
			},
		},
	}

	for _, tc := range tests {
		s.Run(tc.name, func() {
			runMsgServerTestCase(s, testDef, tc)
		})
	}
}

func (s *TestSuite) TestMsgServer_SwapOut() {
	type postCheckArgs struct {
		OwnerAddress         sdk.AccAddress
		VaultAddress         sdk.AccAddress
		ExpectedQueuedPayout sdk.Coin
		ExpectedOwnerShares  math.Int
		EscrowedShares       sdk.Coin
	}

	testDef := msgServerTestDef[types.MsgSwapOutRequest, types.MsgSwapOutResponse, postCheckArgs]{
		endpointName: "SwapOut",
		endpoint:     keeper.NewMsgServer(s.simApp.VaultKeeper).SwapOut,
		postCheck: func(msg *types.MsgSwapOutRequest, args postCheckArgs) {
			s.assertBalance(args.OwnerAddress, args.EscrowedShares.Denom, args.ExpectedOwnerShares)
			s.assertBalance(args.VaultAddress, args.EscrowedShares.Denom, args.EscrowedShares.Amount)
		},
	}

	underlyingDenom := "underlying"
	shareDenom := "vaultshares"
	ownerAddr := s.adminAddr
	vaultAddr := types.GetVaultAddress(shareDenom)
	deposit := sdk.NewInt64Coin(underlyingDenom, 100)

	setup := func() {
		s.requireAddFinalizeAndActivateMarker(sdk.NewCoin(underlyingDenom, math.NewInt(1000)), ownerAddr)

		vault, err := s.k.CreateVault(s.ctx, &types.MsgCreateVaultRequest{
			Admin:           ownerAddr.String(),
			ShareDenom:      shareDenom,
			UnderlyingAsset: underlyingDenom,
		})
		s.Require().NoError(err, "vault creation should succeed")

		vault.SwapInEnabled = true
		vault.SwapOutEnabled = true
		s.k.AuthKeeper.SetAccount(s.ctx, vault)

		err = FundAccount(s.ctx, s.simApp, ownerAddr, sdk.NewCoins(deposit))
		s.Require().NoError(err, "funding owner account should succeed")

		s.ctx = s.ctx.WithBlockTime(time.Now())

		_, err = s.k.SwapIn(s.ctx, vaultAddr, ownerAddr, deposit)
		s.Require().NoError(err, "initial SwapIn should succeed for owner %s and vault %s", ownerAddr, vaultAddr)
	}

	testCases := []struct {
		name               string
		burnSharesScaled   int64
		expectedUnderlying int64
		redeemDenom        string
	}{
		{"swap out 30 shares -> queues withdrawal for 30 underlying", 30_000_000, 30, ""},
		{"swap out 100 shares -> queues withdrawal for 100 underlying", 100_000_000, 100, ""},
		{"deprecated redeem denom equal to underlying still queues withdrawal", 30_000_000, 30, underlyingDenom},
	}

	for _, tc := range testCases {
		s.Run(tc.name, func() {
			escrowedShares := sdk.NewInt64Coin(shareDenom, tc.burnSharesScaled)
			expectedPayout := sdk.NewCoin(underlyingDenom, math.NewInt(tc.expectedUnderlying))
			initialOwnerShares := deposit.Amount.Mul(utils.ShareScalar)

			req := types.MsgSwapOutRequest{
				Owner:        ownerAddr.String(),
				VaultAddress: vaultAddr.String(),
				Assets:       escrowedShares,
				RedeemDenom:  tc.redeemDenom,
			}

			args := postCheckArgs{
				OwnerAddress:         ownerAddr,
				VaultAddress:         vaultAddr,
				ExpectedQueuedPayout: expectedPayout,
				ExpectedOwnerShares:  initialOwnerShares.Sub(escrowedShares.Amount),
				EscrowedShares:       escrowedShares,
			}

			tcDef := msgServerTestCase[types.MsgSwapOutRequest, postCheckArgs]{
				name:           tc.name,
				setup:          setup,
				msg:            req,
				postCheckArgs:  args,
				expectedEvents: createSwapOutEvents(ownerAddr, vaultAddr, expectedPayout, escrowedShares),
			}

			testDef.expectedResponse = &types.MsgSwapOutResponse{RequestId: 0}
			runMsgServerTestCase(s, testDef, tcDef)
		})
	}
}

func (s *TestSuite) TestMsgServer_SwapOut_Failures() {
	testDef := msgServerTestDef[types.MsgSwapOutRequest, types.MsgSwapOutResponse, any]{
		endpointName: "SwapOut",
		endpoint:     keeper.NewMsgServer(s.simApp.VaultKeeper).SwapOut,
		postCheck:    nil,
	}

	underlyingDenom := "underlying"
	shareDenom := "vaultshares"
	owner := s.adminAddr
	vaultAddr := types.GetVaultAddress(shareDenom)
	initialAssets := sdk.NewInt64Coin(underlyingDenom, 1000)

	setup := func(swapOutEnabled, vaultPaused bool, minSwapOut, maxSwapOut string) func() {
		return func() {
			s.requireAddFinalizeAndActivateMarker(sdk.NewCoin(underlyingDenom, math.NewInt(2000)), owner)
			vault, err := s.k.CreateVault(s.ctx, &types.MsgCreateVaultRequest{
				Admin:           owner.String(),
				ShareDenom:      shareDenom,
				UnderlyingAsset: underlyingDenom,
				MinSwapOutValue: minSwapOut,
				MaxSwapOutValue: maxSwapOut,
			})
			s.Require().NoError(err, "vault creation should succeed")
			vault.SwapInEnabled = true
			vault.SwapOutEnabled = swapOutEnabled

			s.k.AuthKeeper.SetAccount(s.ctx, vault)

			err = FundAccount(s.ctx, s.simApp, owner, sdk.NewCoins(initialAssets))
			s.Require().NoError(err, "funding owner should succeed")

			_, err = s.k.SwapIn(s.ctx, vaultAddr, owner, initialAssets)
			s.Require().NoError(err, "initial SwapIn should succeed for vault %s and owner %s", vaultAddr, owner)
			vault.Paused = vaultPaused
			s.k.AuthKeeper.SetAccount(s.ctx, vault)
		}
	}

	randomAddr := sdk.AccAddress(secp256k1.GenPrivKey().PubKey().Address()).String()
	mintedShares := initialAssets.Amount.Mul(utils.ShareScalar)
	overdrawShares := mintedShares.Add(math.NewInt(1)) // force insufficient funds

	tests := []msgServerTestCase[types.MsgSwapOutRequest, any]{
		{
			name: "vault does not exist returns not found error",
			msg: types.MsgSwapOutRequest{
				Owner:        owner.String(),
				VaultAddress: randomAddr,
				Assets:       sdk.NewInt64Coin(shareDenom, 50),
			},
			expectedErrSubstrs: []string{"vault with address", "not found"},
		},
		{
			name:  "swap out below minimum value",
			setup: setup(true, false, "200", ""),
			msg: types.MsgSwapOutRequest{
				Owner:        owner.String(),
				VaultAddress: vaultAddr.String(),
				Assets:       sdk.NewInt64Coin(shareDenom, 50),
			},
			expectedErrSubstrs: []string{"below the minimum required value"},
		},
		{
			name:  "swap out above maximum value",
			setup: setup(true, false, "", "100"),
			msg: types.MsgSwapOutRequest{
				Owner:        owner.String(),
				VaultAddress: vaultAddr.String(),
				Assets:       sdk.NewInt64Coin(shareDenom, 150_000_000),
			},
			expectedErrSubstrs: []string{"above the maximum allowed value"},
		},
		{
			name:  "wrong denom rejected",
			setup: setup(true, false, "", ""),
			msg: types.MsgSwapOutRequest{
				Owner:        owner.String(),
				VaultAddress: vaultAddr.String(),
				Assets:       sdk.NewInt64Coin("wrongdenom", 50),
			},
			expectedErrSubstrs: []string{"swap out denom must be share denom", "wrongdenom", shareDenom},
		},
		{
			name:  "insufficient share balance returns insufficient funds",
			setup: setup(true, false, "", ""),
			msg: types.MsgSwapOutRequest{
				Owner:        owner.String(),
				VaultAddress: vaultAddr.String(),
				Assets:       sdk.NewCoin(shareDenom, overdrawShares),
			},
			expectedErrSubstrs: []string{"failed to escrow shares", "insufficient funds"},
		},
		{
			name:  "swap out enabled, vault is paused",
			setup: setup(true, true, "", ""),
			msg: types.MsgSwapOutRequest{
				Owner:        owner.String(),
				VaultAddress: vaultAddr.String(),
				Assets:       sdk.NewInt64Coin(shareDenom, 150_000_000),
			},
			expectedErrSubstrs: []string{"vault", "is paused"},
		},
		{
			name:  "deprecated redeem denom different from underlying is rejected",
			setup: setup(true, false, "", ""),
			msg: types.MsgSwapOutRequest{
				Owner:        owner.String(),
				VaultAddress: vaultAddr.String(),
				Assets:       sdk.NewInt64Coin(shareDenom, 50_000_000),
				RedeemDenom:  "otherdenom",
			},
			expectedErrSubstrs: []string{"redeem denom is deprecated", underlyingDenom, "otherdenom"},
		},
		{
			name:  "swap out disabled is rejected",
			setup: setup(false, false, "", ""),
			msg: types.MsgSwapOutRequest{
				Owner:        owner.String(),
				VaultAddress: vaultAddr.String(),
				Assets:       sdk.NewInt64Coin(shareDenom, 150_000_000),
			},
			expectedErrSubstrs: []string{"swaps are not enabled for vault"},
		},
	}

	for _, tc := range tests {
		s.Run(tc.name, func() {
			runMsgServerTestCase(s, testDef, tc)
		})
	}
}

func (s *TestSuite) TestMsgServer_ToggleSwapOut() {
	type postCheckArgs struct {
		VaultAddress    sdk.AccAddress
		ExpectedEnabled bool
	}

	testDef := msgServerTestDef[types.MsgToggleSwapOutRequest, types.MsgToggleSwapOutResponse, postCheckArgs]{
		endpointName: "ToggleSwapOut",
		endpoint:     keeper.NewMsgServer(s.simApp.VaultKeeper).ToggleSwapOut,
		postCheck: func(msg *types.MsgToggleSwapOutRequest, args postCheckArgs) {
			vault, err := s.k.GetVault(s.ctx, args.VaultAddress)
			s.Require().NoError(err, "failed to get vault at address %s in post-check", args.VaultAddress)
			s.Assert().Equal(args.ExpectedEnabled, vault.SwapOutEnabled, "swap-out enabled state mismatch for vault %s", args.VaultAddress)
		},
	}

	underlyingDenom := "underlying"
	shareDenom := "vaultshares"
	owner := s.adminAddr
	otherUser := s.CreateAndFundAccount(sdk.NewInt64Coin("stake", 1000))
	vaultAddr := types.GetVaultAddress(shareDenom)

	setup := func(setAccountInvalid bool) func() {
		return func() {
			s.requireAddFinalizeAndActivateMarker(sdk.NewCoin(underlyingDenom, math.NewInt(1000)), owner)
			_, err := s.k.CreateVault(s.ctx, &types.MsgCreateVaultRequest{
				Admin:           owner.String(),
				ShareDenom:      shareDenom,
				UnderlyingAsset: underlyingDenom,
			})
			s.Require().NoError(err, "failed to create vault in ToggleSwapOut setup for share denom %s", shareDenom)
			if setAccountInvalid {
				vault, err := s.k.GetVault(s.ctx, vaultAddr)
				s.Require().NoError(err, "failed to get vault in setup for address %s", vaultAddr)
				vault.PaymentDenom = "!TABLES!"
				s.k.AuthKeeper.SetAccount(s.ctx, vault)
			}
			s.ctx = s.ctx.WithEventManager(sdk.NewEventManager())
			s.ctx = s.ctx.WithBlockTime(time.Now())
		}
	}

	tests := []struct {
		name               string
		setup              func()
		msg                types.MsgToggleSwapOutRequest
		postCheckArgs      postCheckArgs
		expectedEvents     sdk.Events
		expectedErrSubstrs []string
	}{
		{
			name:  "happy path - enable swap out",
			setup: setup(false),
			msg: types.MsgToggleSwapOutRequest{
				Admin:        owner.String(),
				VaultAddress: vaultAddr.String(),
				Enabled:      true,
			},
			postCheckArgs: postCheckArgs{
				VaultAddress:    vaultAddr,
				ExpectedEnabled: true,
			},
			expectedEvents: sdk.Events{
				sdk.NewEvent("provlabs.vault.v1.EventToggleSwapOut",
					sdk.NewAttribute("admin", owner.String()),
					sdk.NewAttribute("enabled", "true"),
					sdk.NewAttribute("vault_address", vaultAddr.String()),
				),
			},
		},
		{
			name: "happy path - disable swap out",
			setup: func() {
				setup(false)()
				vault, err := s.k.GetVault(s.ctx, vaultAddr)
				s.Require().NoError(err, "failed to get vault %s for manual swap-out toggle", vaultAddr)
				vault.SwapOutEnabled = true
				s.k.AuthKeeper.SetAccount(s.ctx, vault)
			},
			msg: types.MsgToggleSwapOutRequest{
				Admin:        owner.String(),
				VaultAddress: vaultAddr.String(),
				Enabled:      false,
			},
			postCheckArgs: postCheckArgs{
				VaultAddress:    vaultAddr,
				ExpectedEnabled: false,
			},
			expectedEvents: sdk.Events{
				sdk.NewEvent("provlabs.vault.v1.EventToggleSwapOut",
					sdk.NewAttribute("admin", owner.String()),
					sdk.NewAttribute("enabled", "false"),
					sdk.NewAttribute("vault_address", vaultAddr.String()),
				),
			},
		},
		{
			name: "happy path - paused vault toggle swap out",
			setup: func() {
				setup(false)()
				vault, err := s.k.GetVault(s.ctx, vaultAddr)
				s.Require().NoError(err, "failed to get vault %s for paused toggle setup", vaultAddr)
				vault.SwapOutEnabled = true
				vault.Paused = true
				s.k.AuthKeeper.SetAccount(s.ctx, vault)
			},
			msg: types.MsgToggleSwapOutRequest{
				Admin:        owner.String(),
				VaultAddress: vaultAddr.String(),
				Enabled:      false,
			},
			postCheckArgs: postCheckArgs{
				VaultAddress:    vaultAddr,
				ExpectedEnabled: false,
			},
			expectedEvents: sdk.Events{
				sdk.NewEvent("provlabs.vault.v1.EventToggleSwapOut",
					sdk.NewAttribute("admin", owner.String()),
					sdk.NewAttribute("enabled", "false"),
					sdk.NewAttribute("vault_address", vaultAddr.String()),
				),
			},
		},
		{
			name:  "failure - vault not found",
			setup: func() { /* no setup, so vault doesn't exist */ },
			msg: types.MsgToggleSwapOutRequest{
				Admin:        owner.String(),
				VaultAddress: vaultAddr.String(),
				Enabled:      true,
			},
			expectedErrSubstrs: []string{"vault not found", vaultAddr.String()},
		},
		{
			name:  "failure - unauthorized admin",
			setup: setup(false),
			msg: types.MsgToggleSwapOutRequest{
				Admin:        otherUser.String(),
				VaultAddress: vaultAddr.String(),
				Enabled:      true,
			},
			expectedErrSubstrs: []string{"unauthorized", otherUser.String(), "is not the vault admin"},
		},
		{
			name:  "failure - invalid vault state during toggle",
			setup: setup(true),
			msg: types.MsgToggleSwapOutRequest{
				Admin:        owner.String(),
				VaultAddress: vaultAddr.String(),
				Enabled:      true,
			},
			expectedErrSubstrs: []string{
				"failed to set swap out enable",
				"must be empty or equal underlying asset",
			},
		},
	}

	for _, tt := range tests {
		s.Run(tt.name, func() {
			tc := msgServerTestCase[types.MsgToggleSwapOutRequest, postCheckArgs]{
				name:               tt.name,
				setup:              tt.setup,
				msg:                tt.msg,
				postCheckArgs:      tt.postCheckArgs,
				expectedEvents:     tt.expectedEvents,
				expectedErrSubstrs: tt.expectedErrSubstrs,
			}

			testDef.expectedResponse = &types.MsgToggleSwapOutResponse{}
			runMsgServerTestCase(s, testDef, tc)
		})
	}
}

func (s *TestSuite) TestMsgServer_UpdateMinSwapInValue() {
	type postCheckArgs struct {
		VaultAddress sdk.AccAddress
		NewValue     string
		Authority    string
	}

	testDef := msgServerTestDef[types.MsgUpdateMinSwapInValueRequest, types.MsgUpdateMinSwapInValueResponse, postCheckArgs]{
		endpointName: "UpdateMinSwapInValue",
		endpoint:     keeper.NewMsgServer(s.simApp.VaultKeeper).UpdateMinSwapInValue,
		postCheck: func(msg *types.MsgUpdateMinSwapInValueRequest, args postCheckArgs) {
			vault, err := s.k.GetVault(s.ctx, args.VaultAddress)
			s.Require().NoError(err, "failed to fetch vault after UpdateMinSwapInValue")
			s.Require().Equal(args.NewValue, vault.MinSwapInValue, "vault MinSwapInValue mismatch: expected %s got %s", args.NewValue, vault.MinSwapInValue)
		},
	}

	underlying := "under"
	share := "vaultshares"
	admin := s.adminAddr
	assetManager := s.CreateAndFundAccount(sdk.NewInt64Coin("stake", 1))
	var vaultAddr sdk.AccAddress

	setup := func() {
		vaultAddr = s.CreateAndActivateVault(admin, share, underlying)
		vault, err := s.k.GetVault(s.ctx, vaultAddr)
		s.Require().NoError(err, "unexpected error fetching vault for asset manager setup at address %s", vaultAddr.String())
		vault.AssetManager = assetManager.String()
		s.k.AuthKeeper.SetAccount(s.ctx, vault)
	}

	tests := []msgServerTestCase[types.MsgUpdateMinSwapInValueRequest, postCheckArgs]{
		{
			name:  "happy path - admin",
			setup: setup,
			msg: types.MsgUpdateMinSwapInValueRequest{
				Authority:      admin.String(),
				VaultAddress:   types.GetVaultAddress(share).String(),
				MinSwapInValue: "500",
			},
			postCheckArgs: postCheckArgs{
				VaultAddress: types.GetVaultAddress(share),
				NewValue:     "500",
				Authority:    admin.String(),
			},
			expectedEvents: sdk.Events{
				sdk.NewEvent("provlabs.vault.v1.EventMinSwapInValueUpdated",
					sdk.NewAttribute("authority", admin.String()),
					sdk.NewAttribute("min_swap_in", "500"),
					sdk.NewAttribute("vault_address", types.GetVaultAddress(share).String()),
				),
			},
		},
		{
			name:  "happy path - asset manager",
			setup: setup,
			msg: types.MsgUpdateMinSwapInValueRequest{
				Authority:      assetManager.String(),
				VaultAddress:   types.GetVaultAddress(share).String(),
				MinSwapInValue: "600",
			},
			postCheckArgs: postCheckArgs{
				VaultAddress: types.GetVaultAddress(share),
				NewValue:     "600",
				Authority:    assetManager.String(),
			},
			expectedEvents: sdk.Events{
				sdk.NewEvent("provlabs.vault.v1.EventMinSwapInValueUpdated",
					sdk.NewAttribute("authority", assetManager.String()),
					sdk.NewAttribute("min_swap_in", "600"),
					sdk.NewAttribute("vault_address", types.GetVaultAddress(share).String()),
				),
			},
		},
	}

	testDef.expectedResponse = &types.MsgUpdateMinSwapInValueResponse{}
	for _, tc := range tests {
		s.Run(tc.name, func() {
			runMsgServerTestCase(s, testDef, tc)
		})
	}
}

func (s *TestSuite) TestMsgServer_UpdateMinSwapInValue_Failures() {
	testDef := msgServerTestDef[types.MsgUpdateMinSwapInValueRequest, types.MsgUpdateMinSwapInValueResponse, any]{
		endpointName: "UpdateMinSwapInValue",
		endpoint:     keeper.NewMsgServer(s.simApp.VaultKeeper).UpdateMinSwapInValue,
		postCheck:    nil,
	}

	underlying := "under"
	share := "vaultshares"
	admin := s.adminAddr
	other := s.CreateAndFundAccount(sdk.NewInt64Coin("stake", 1))

	setup := func() {
		_ = s.CreateAndActivateVault(admin, share, underlying)
	}

	tests := []msgServerTestCase[types.MsgUpdateMinSwapInValueRequest, any]{
		{
			name: "vault not found",
			msg: types.MsgUpdateMinSwapInValueRequest{
				Authority:      admin.String(),
				VaultAddress:   types.GetVaultAddress("missing").String(),
				MinSwapInValue: "100",
			},
			expectedErrSubstrs: []string{"vault not found"},
		},
		{
			name:  "unauthorized",
			setup: setup,
			msg: types.MsgUpdateMinSwapInValueRequest{
				Authority:      other.String(),
				VaultAddress:   types.GetVaultAddress(share).String(),
				MinSwapInValue: "100",
			},
			expectedErrSubstrs: []string{"unauthorized"},
		},
		{
			name:  "invalid value",
			setup: setup,
			msg: types.MsgUpdateMinSwapInValueRequest{
				Authority:      admin.String(),
				VaultAddress:   types.GetVaultAddress(share).String(),
				MinSwapInValue: "invalid",
			},
			expectedErrSubstrs: []string{"failed to set MinSwapIn", "invalid min value"},
		},
		{
			name:  "negative value",
			setup: setup,
			msg: types.MsgUpdateMinSwapInValueRequest{
				Authority:      admin.String(),
				VaultAddress:   types.GetVaultAddress(share).String(),
				MinSwapInValue: "-1",
			},
			expectedErrSubstrs: []string{"failed to set MinSwapIn", "must be non-negative"},
		},
	}

	for _, tc := range tests {
		s.Run(tc.name, func() {
			runMsgServerTestCase(s, testDef, tc)
		})
	}
}

func (s *TestSuite) TestMsgServer_UpdateMinSwapOutValue() {
	type postCheckArgs struct {
		VaultAddress sdk.AccAddress
		NewValue     string
		Authority    string
	}

	testDef := msgServerTestDef[types.MsgUpdateMinSwapOutValueRequest, types.MsgUpdateMinSwapOutValueResponse, postCheckArgs]{
		endpointName: "UpdateMinSwapOutValue",
		endpoint:     keeper.NewMsgServer(s.simApp.VaultKeeper).UpdateMinSwapOutValue,
		postCheck: func(msg *types.MsgUpdateMinSwapOutValueRequest, args postCheckArgs) {
			vault, err := s.k.GetVault(s.ctx, args.VaultAddress)
			s.Require().NoError(err, "failed to fetch vault after UpdateMinSwapOutValue")
			s.Require().Equal(args.NewValue, vault.MinSwapOutValue, "vault MinSwapOutValue mismatch: expected %s got %s", args.NewValue, vault.MinSwapOutValue)
		},
	}

	underlying := "under"
	share := "vaultshares"
	admin := s.adminAddr
	assetManager := s.CreateAndFundAccount(sdk.NewInt64Coin("stake", 1))
	var vaultAddr sdk.AccAddress

	setup := func() {
		vaultAddr = s.CreateAndActivateVault(admin, share, underlying)
		vault, err := s.k.GetVault(s.ctx, vaultAddr)
		s.Require().NoError(err, "unexpected error fetching vault for asset manager setup at address %s", vaultAddr.String())
		vault.AssetManager = assetManager.String()
		s.k.AuthKeeper.SetAccount(s.ctx, vault)
	}

	tests := []msgServerTestCase[types.MsgUpdateMinSwapOutValueRequest, postCheckArgs]{
		{
			name:  "happy path - admin",
			setup: setup,
			msg: types.MsgUpdateMinSwapOutValueRequest{
				Authority:       admin.String(),
				VaultAddress:    types.GetVaultAddress(share).String(),
				MinSwapOutValue: "300",
			},
			postCheckArgs: postCheckArgs{
				VaultAddress: types.GetVaultAddress(share),
				NewValue:     "300",
				Authority:    admin.String(),
			},
			expectedEvents: sdk.Events{
				sdk.NewEvent("provlabs.vault.v1.EventMinSwapOutValueUpdated",
					sdk.NewAttribute("authority", admin.String()),
					sdk.NewAttribute("min_swap_out", "300"),
					sdk.NewAttribute("vault_address", types.GetVaultAddress(share).String()),
				),
			},
		},
		{
			name:  "happy path - asset manager",
			setup: setup,
			msg: types.MsgUpdateMinSwapOutValueRequest{
				Authority:       assetManager.String(),
				VaultAddress:    types.GetVaultAddress(share).String(),
				MinSwapOutValue: "400",
			},
			postCheckArgs: postCheckArgs{
				VaultAddress: types.GetVaultAddress(share),
				NewValue:     "400",
				Authority:    assetManager.String(),
			},
			expectedEvents: sdk.Events{
				sdk.NewEvent("provlabs.vault.v1.EventMinSwapOutValueUpdated",
					sdk.NewAttribute("authority", assetManager.String()),
					sdk.NewAttribute("min_swap_out", "400"),
					sdk.NewAttribute("vault_address", types.GetVaultAddress(share).String()),
				),
			},
		},
	}

	testDef.expectedResponse = &types.MsgUpdateMinSwapOutValueResponse{}
	for _, tc := range tests {
		s.Run(tc.name, func() {
			runMsgServerTestCase(s, testDef, tc)
		})
	}
}

func (s *TestSuite) TestMsgServer_UpdateMinSwapOutValue_Failures() {
	testDef := msgServerTestDef[types.MsgUpdateMinSwapOutValueRequest, types.MsgUpdateMinSwapOutValueResponse, any]{
		endpointName: "UpdateMinSwapOutValue",
		endpoint:     keeper.NewMsgServer(s.simApp.VaultKeeper).UpdateMinSwapOutValue,
		postCheck:    nil,
	}

	underlying := "under"
	share := "vaultshares"
	admin := s.adminAddr
	other := s.CreateAndFundAccount(sdk.NewInt64Coin("stake", 1))

	setup := func() {
		_ = s.CreateAndActivateVault(admin, share, underlying)
	}

	tests := []msgServerTestCase[types.MsgUpdateMinSwapOutValueRequest, any]{
		{
			name: "vault not found",
			msg: types.MsgUpdateMinSwapOutValueRequest{
				Authority:       admin.String(),
				VaultAddress:    types.GetVaultAddress("missing").String(),
				MinSwapOutValue: "100",
			},
			expectedErrSubstrs: []string{"vault not found"},
		},
		{
			name:  "unauthorized",
			setup: setup,
			msg: types.MsgUpdateMinSwapOutValueRequest{
				Authority:       other.String(),
				VaultAddress:    types.GetVaultAddress(share).String(),
				MinSwapOutValue: "100",
			},
			expectedErrSubstrs: []string{"unauthorized"},
		},
		{
			name:  "invalid value",
			setup: setup,
			msg: types.MsgUpdateMinSwapOutValueRequest{
				Authority:       admin.String(),
				VaultAddress:    types.GetVaultAddress(share).String(),
				MinSwapOutValue: "invalid",
			},
			expectedErrSubstrs: []string{"failed to set MinSwapOut", "invalid min value"},
		},
		{
			name:  "negative value",
			setup: setup,
			msg: types.MsgUpdateMinSwapOutValueRequest{
				Authority:       admin.String(),
				VaultAddress:    types.GetVaultAddress(share).String(),
				MinSwapOutValue: "-1",
			},
			expectedErrSubstrs: []string{"failed to set MinSwapOut", "must be non-negative"},
		},
	}

	for _, tc := range tests {
		s.Run(tc.name, func() {
			runMsgServerTestCase(s, testDef, tc)
		})
	}
}

func (s *TestSuite) TestMsgServer_UpdateMaxSwapInValue() {
	type postCheckArgs struct {
		VaultAddress sdk.AccAddress
		NewValue     string
		Authority    string
	}

	testDef := msgServerTestDef[types.MsgUpdateMaxSwapInValueRequest, types.MsgUpdateMaxSwapInValueResponse, postCheckArgs]{
		endpointName: "UpdateMaxSwapInValue",
		endpoint:     keeper.NewMsgServer(s.simApp.VaultKeeper).UpdateMaxSwapInValue,
		postCheck: func(msg *types.MsgUpdateMaxSwapInValueRequest, args postCheckArgs) {
			vault, err := s.k.GetVault(s.ctx, args.VaultAddress)
			s.Require().NoError(err, "failed to fetch vault after UpdateMaxSwapInValue")
			s.Require().Equal(args.NewValue, vault.MaxSwapInValue, "vault MaxSwapInValue mismatch: expected %s got %s", args.NewValue, vault.MaxSwapInValue)
		},
	}

	underlying := "under"
	share := "vaultshares"
	admin := s.adminAddr
	assetManager := s.CreateAndFundAccount(sdk.NewInt64Coin("stake", 1))
	var vaultAddr sdk.AccAddress

	setup := func() {
		vaultAddr = s.CreateAndActivateVault(admin, share, underlying)
		vault, err := s.k.GetVault(s.ctx, vaultAddr)
		s.Require().NoError(err, "unexpected error fetching vault for asset manager setup at address %s", vaultAddr.String())
		vault.AssetManager = assetManager.String()
		s.k.AuthKeeper.SetAccount(s.ctx, vault)
	}

	tests := []msgServerTestCase[types.MsgUpdateMaxSwapInValueRequest, postCheckArgs]{
		{
			name:  "happy path - admin",
			setup: setup,
			msg: types.MsgUpdateMaxSwapInValueRequest{
				Authority:      admin.String(),
				VaultAddress:   types.GetVaultAddress(share).String(),
				MaxSwapInValue: "5000",
			},
			postCheckArgs: postCheckArgs{
				VaultAddress: types.GetVaultAddress(share),
				NewValue:     "5000",
				Authority:    admin.String(),
			},
			expectedEvents: sdk.Events{
				sdk.NewEvent("provlabs.vault.v1.EventMaxSwapInValueUpdated",
					sdk.NewAttribute("authority", admin.String()),
					sdk.NewAttribute("max_swap_in", "5000"),
					sdk.NewAttribute("vault_address", types.GetVaultAddress(share).String()),
				),
			},
		},
		{
			name:  "happy path - asset manager",
			setup: setup,
			msg: types.MsgUpdateMaxSwapInValueRequest{
				Authority:      assetManager.String(),
				VaultAddress:   types.GetVaultAddress(share).String(),
				MaxSwapInValue: "6000",
			},
			postCheckArgs: postCheckArgs{
				VaultAddress: types.GetVaultAddress(share),
				NewValue:     "6000",
				Authority:    assetManager.String(),
			},
			expectedEvents: sdk.Events{
				sdk.NewEvent("provlabs.vault.v1.EventMaxSwapInValueUpdated",
					sdk.NewAttribute("authority", assetManager.String()),
					sdk.NewAttribute("max_swap_in", "6000"),
					sdk.NewAttribute("vault_address", types.GetVaultAddress(share).String()),
				),
			},
		},
	}

	testDef.expectedResponse = &types.MsgUpdateMaxSwapInValueResponse{}
	for _, tc := range tests {
		s.Run(tc.name, func() {
			runMsgServerTestCase(s, testDef, tc)
		})
	}
}

func (s *TestSuite) TestMsgServer_UpdateMaxSwapInValue_Failures() {
	testDef := msgServerTestDef[types.MsgUpdateMaxSwapInValueRequest, types.MsgUpdateMaxSwapInValueResponse, any]{
		endpointName: "UpdateMaxSwapInValue",
		endpoint:     keeper.NewMsgServer(s.simApp.VaultKeeper).UpdateMaxSwapInValue,
		postCheck:    nil,
	}

	underlying := "under"
	share := "vaultshares"
	admin := s.adminAddr
	other := s.CreateAndFundAccount(sdk.NewInt64Coin("stake", 1))

	setup := func() {
		_ = s.CreateAndActivateVault(admin, share, underlying)
	}

	tests := []msgServerTestCase[types.MsgUpdateMaxSwapInValueRequest, any]{
		{
			name: "vault not found",
			msg: types.MsgUpdateMaxSwapInValueRequest{
				Authority:      admin.String(),
				VaultAddress:   types.GetVaultAddress("missing").String(),
				MaxSwapInValue: "100",
			},
			expectedErrSubstrs: []string{"vault not found"},
		},
		{
			name:  "unauthorized",
			setup: setup,
			msg: types.MsgUpdateMaxSwapInValueRequest{
				Authority:      other.String(),
				VaultAddress:   types.GetVaultAddress(share).String(),
				MaxSwapInValue: "100",
			},
			expectedErrSubstrs: []string{"unauthorized"},
		},
		{
			name:  "invalid value",
			setup: setup,
			msg: types.MsgUpdateMaxSwapInValueRequest{
				Authority:      admin.String(),
				VaultAddress:   types.GetVaultAddress(share).String(),
				MaxSwapInValue: "invalid",
			},
			expectedErrSubstrs: []string{"failed to set MaxSwapIn", "invalid max value"},
		},
		{
			name:  "negative value",
			setup: setup,
			msg: types.MsgUpdateMaxSwapInValueRequest{
				Authority:      admin.String(),
				VaultAddress:   types.GetVaultAddress(share).String(),
				MaxSwapInValue: "-1",
			},
			expectedErrSubstrs: []string{"failed to set MaxSwapIn", "must be non-negative"},
		},
	}

	for _, tc := range tests {
		s.Run(tc.name, func() {
			runMsgServerTestCase(s, testDef, tc)
		})
	}
}

func (s *TestSuite) TestMsgServer_UpdateMaxSwapOutValue() {
	type postCheckArgs struct {
		VaultAddress sdk.AccAddress
		NewValue     string
		Authority    string
	}

	testDef := msgServerTestDef[types.MsgUpdateMaxSwapOutValueRequest, types.MsgUpdateMaxSwapOutValueResponse, postCheckArgs]{
		endpointName: "UpdateMaxSwapOutValue",
		endpoint:     keeper.NewMsgServer(s.simApp.VaultKeeper).UpdateMaxSwapOutValue,
		postCheck: func(msg *types.MsgUpdateMaxSwapOutValueRequest, args postCheckArgs) {
			vault, err := s.k.GetVault(s.ctx, args.VaultAddress)
			s.Require().NoError(err, "failed to fetch vault after UpdateMaxSwapOutValue")
			s.Require().Equal(args.NewValue, vault.MaxSwapOutValue, "vault MaxSwapOutValue mismatch: expected %s got %s", args.NewValue, vault.MaxSwapOutValue)
		},
	}

	underlying := "under"
	share := "vaultshares"
	admin := s.adminAddr
	assetManager := s.CreateAndFundAccount(sdk.NewInt64Coin("stake", 1))
	var vaultAddr sdk.AccAddress

	setup := func() {
		vaultAddr = s.CreateAndActivateVault(admin, share, underlying)
		vault, err := s.k.GetVault(s.ctx, vaultAddr)
		s.Require().NoError(err, "unexpected error fetching vault for asset manager setup at address %s", vaultAddr.String())
		vault.AssetManager = assetManager.String()
		s.k.AuthKeeper.SetAccount(s.ctx, vault)
	}

	tests := []msgServerTestCase[types.MsgUpdateMaxSwapOutValueRequest, postCheckArgs]{
		{
			name:  "happy path - admin",
			setup: setup,
			msg: types.MsgUpdateMaxSwapOutValueRequest{
				Authority:       admin.String(),
				VaultAddress:    types.GetVaultAddress(share).String(),
				MaxSwapOutValue: "3000",
			},
			postCheckArgs: postCheckArgs{
				VaultAddress: types.GetVaultAddress(share),
				NewValue:     "3000",
				Authority:    admin.String(),
			},
			expectedEvents: sdk.Events{
				sdk.NewEvent("provlabs.vault.v1.EventMaxSwapOutValueUpdated",
					sdk.NewAttribute("authority", admin.String()),
					sdk.NewAttribute("max_swap_out", "3000"),
					sdk.NewAttribute("vault_address", types.GetVaultAddress(share).String()),
				),
			},
		},
		{
			name:  "happy path - asset manager",
			setup: setup,
			msg: types.MsgUpdateMaxSwapOutValueRequest{
				Authority:       assetManager.String(),
				VaultAddress:    types.GetVaultAddress(share).String(),
				MaxSwapOutValue: "4000",
			},
			postCheckArgs: postCheckArgs{
				VaultAddress: types.GetVaultAddress(share),
				NewValue:     "4000",
				Authority:    assetManager.String(),
			},
			expectedEvents: sdk.Events{
				sdk.NewEvent("provlabs.vault.v1.EventMaxSwapOutValueUpdated",
					sdk.NewAttribute("authority", assetManager.String()),
					sdk.NewAttribute("max_swap_out", "4000"),
					sdk.NewAttribute("vault_address", types.GetVaultAddress(share).String()),
				),
			},
		},
	}

	testDef.expectedResponse = &types.MsgUpdateMaxSwapOutValueResponse{}
	for _, tc := range tests {
		s.Run(tc.name, func() {
			runMsgServerTestCase(s, testDef, tc)
		})
	}
}

func (s *TestSuite) TestMsgServer_UpdateMaxSwapOutValue_Failures() {
	testDef := msgServerTestDef[types.MsgUpdateMaxSwapOutValueRequest, types.MsgUpdateMaxSwapOutValueResponse, any]{
		endpointName: "UpdateMaxSwapOutValue",
		endpoint:     keeper.NewMsgServer(s.simApp.VaultKeeper).UpdateMaxSwapOutValue,
		postCheck:    nil,
	}

	underlying := "under"
	share := "vaultshares"
	admin := s.adminAddr
	other := s.CreateAndFundAccount(sdk.NewInt64Coin("stake", 1))

	setup := func() {
		_ = s.CreateAndActivateVault(admin, share, underlying)
	}

	tests := []msgServerTestCase[types.MsgUpdateMaxSwapOutValueRequest, any]{
		{
			name: "vault not found",
			msg: types.MsgUpdateMaxSwapOutValueRequest{
				Authority:       admin.String(),
				VaultAddress:    types.GetVaultAddress("missing").String(),
				MaxSwapOutValue: "100",
			},
			expectedErrSubstrs: []string{"vault not found"},
		},
		{
			name:  "unauthorized",
			setup: setup,
			msg: types.MsgUpdateMaxSwapOutValueRequest{
				Authority:       other.String(),
				VaultAddress:    types.GetVaultAddress(share).String(),
				MaxSwapOutValue: "100",
			},
			expectedErrSubstrs: []string{"unauthorized"},
		},
		{
			name:  "invalid value",
			setup: setup,
			msg: types.MsgUpdateMaxSwapOutValueRequest{
				Authority:       admin.String(),
				VaultAddress:    types.GetVaultAddress(share).String(),
				MaxSwapOutValue: "invalid",
			},
			expectedErrSubstrs: []string{"failed to set MaxSwapOut", "invalid max value"},
		},
		{
			name:  "negative value",
			setup: setup,
			msg: types.MsgUpdateMaxSwapOutValueRequest{
				Authority:       admin.String(),
				VaultAddress:    types.GetVaultAddress(share).String(),
				MaxSwapOutValue: "-1",
			},
			expectedErrSubstrs: []string{"failed to set MaxSwapOut", "must be non-negative"},
		},
	}

	for _, tc := range tests {
		s.Run(tc.name, func() {
			runMsgServerTestCase(s, testDef, tc)
		})
	}
}

func (s *TestSuite) TestMsgServer_ToggleSwapIn() {
	type postCheckArgs struct {
		VaultAddress    sdk.AccAddress
		ExpectedEnabled bool
	}

	testDef := msgServerTestDef[types.MsgToggleSwapInRequest, types.MsgToggleSwapInResponse, postCheckArgs]{
		endpointName: "ToggleSwapIn",
		endpoint:     keeper.NewMsgServer(s.simApp.VaultKeeper).ToggleSwapIn,
		postCheck: func(msg *types.MsgToggleSwapInRequest, args postCheckArgs) {
			vault, err := s.k.GetVault(s.ctx, args.VaultAddress)
			s.Require().NoError(err, "failed to get vault at address %s in post-check", args.VaultAddress)
			s.Assert().Equal(args.ExpectedEnabled, vault.SwapInEnabled, "swap-in enabled state mismatch for vault %s", args.VaultAddress)
		},
	}

	underlyingDenom := "underlying"
	shareDenom := "vaultshares"
	owner := s.adminAddr
	otherUser := s.CreateAndFundAccount(sdk.NewInt64Coin("stake", 1000))
	vaultAddr := types.GetVaultAddress(shareDenom)

	setup := func(setAccountInvalid bool) func() {
		return func() {
			s.requireAddFinalizeAndActivateMarker(sdk.NewCoin(underlyingDenom, math.NewInt(1000)), owner)
			_, err := s.k.CreateVault(s.ctx, &types.MsgCreateVaultRequest{
				Admin:           owner.String(),
				ShareDenom:      shareDenom,
				UnderlyingAsset: underlyingDenom,
			})
			s.Require().NoError(err, "failed to create vault in ToggleSwapIn setup for share denom %s", shareDenom)
			if setAccountInvalid {
				vault, err := s.k.GetVault(s.ctx, vaultAddr)
				s.Require().NoError(err, "failed to get vault in setup for address %s", vaultAddr)
				vault.PaymentDenom = "!TABLES!"
				s.k.AuthKeeper.SetAccount(s.ctx, vault)
			}
			s.ctx = s.ctx.WithEventManager(sdk.NewEventManager())
		}
	}

	tests := []struct {
		name               string
		setup              func()
		msg                types.MsgToggleSwapInRequest
		postCheckArgs      postCheckArgs
		expectedEvents     sdk.Events
		expectedErrSubstrs []string
	}{
		{
			name:  "happy path - enable swap in",
			setup: setup(false),
			msg: types.MsgToggleSwapInRequest{
				Admin:        owner.String(),
				VaultAddress: vaultAddr.String(),
				Enabled:      true,
			},
			postCheckArgs: postCheckArgs{
				VaultAddress:    vaultAddr,
				ExpectedEnabled: true,
			},
			expectedEvents: sdk.Events{
				sdk.NewEvent("provlabs.vault.v1.EventToggleSwapIn",
					sdk.NewAttribute("admin", owner.String()),
					sdk.NewAttribute("enabled", "true"),
					sdk.NewAttribute("vault_address", vaultAddr.String()),
				),
			},
		},
		{
			name: "happy path - disable swap in",
			setup: func() {
				setup(false)()
				vault, err := s.k.GetVault(s.ctx, vaultAddr)
				s.Require().NoError(err, "failed to get vault %s", vaultAddr)
				vault.SwapInEnabled = true
				s.k.AuthKeeper.SetAccount(s.ctx, vault)
			},
			msg: types.MsgToggleSwapInRequest{
				Admin:        owner.String(),
				VaultAddress: vaultAddr.String(),
				Enabled:      false,
			},
			postCheckArgs: postCheckArgs{
				VaultAddress:    vaultAddr,
				ExpectedEnabled: false,
			},
			expectedEvents: sdk.Events{
				sdk.NewEvent("provlabs.vault.v1.EventToggleSwapIn",
					sdk.NewAttribute("admin", owner.String()),
					sdk.NewAttribute("enabled", "false"),
					sdk.NewAttribute("vault_address", vaultAddr.String()),
				),
			},
		},
		{
			name: "happy path - vault paused toggle swap in",
			setup: func() {
				setup(false)()
				vault, err := s.k.GetVault(s.ctx, vaultAddr)
				s.Require().NoError(err, "failed to get vault %s", vaultAddr)
				vault.SwapInEnabled = true
				vault.Paused = true
				s.k.AuthKeeper.SetAccount(s.ctx, vault)
			},
			msg: types.MsgToggleSwapInRequest{
				Admin:        owner.String(),
				VaultAddress: vaultAddr.String(),
				Enabled:      false,
			},
			postCheckArgs: postCheckArgs{
				VaultAddress:    vaultAddr,
				ExpectedEnabled: false,
			},
			expectedEvents: sdk.Events{
				sdk.NewEvent("provlabs.vault.v1.EventToggleSwapIn",
					sdk.NewAttribute("admin", owner.String()),
					sdk.NewAttribute("enabled", "false"),
					sdk.NewAttribute("vault_address", vaultAddr.String()),
				),
			},
		},
		{
			name:  "failure - vault not found",
			setup: func() {},
			msg: types.MsgToggleSwapInRequest{
				Admin:        owner.String(),
				VaultAddress: vaultAddr.String(),
				Enabled:      true,
			},
			expectedErrSubstrs: []string{"vault not found", vaultAddr.String()},
		},
		{
			name:  "failure - unauthorized admin",
			setup: setup(false),
			msg: types.MsgToggleSwapInRequest{
				Admin:        otherUser.String(),
				VaultAddress: vaultAddr.String(),
				Enabled:      true,
			},
			expectedErrSubstrs: []string{"unauthorized", otherUser.String(), "is not the vault admin"},
		},
		{
			name:  "failure - invalid vault state during toggle",
			setup: setup(true),
			msg: types.MsgToggleSwapInRequest{
				Admin:        owner.String(),
				VaultAddress: vaultAddr.String(),
				Enabled:      true,
			},
			expectedErrSubstrs: []string{
				"failed to set swap in enable",
				"must be empty or equal underlying asset",
			},
		},
	}

	for _, tt := range tests {
		s.Run(tt.name, func() {
			tc := msgServerTestCase[types.MsgToggleSwapInRequest, postCheckArgs]{
				name:               tt.name,
				setup:              tt.setup,
				msg:                tt.msg,
				postCheckArgs:      tt.postCheckArgs,
				expectedEvents:     tt.expectedEvents,
				expectedErrSubstrs: tt.expectedErrSubstrs,
			}

			testDef.expectedResponse = &types.MsgToggleSwapInResponse{}
			runMsgServerTestCase(s, testDef, tc)
		})
	}
}

func (s *TestSuite) TestMsgServer_UpdateInterestRate() {
	type postCheckArgs struct {
		VaultAddress              sdk.AccAddress
		ExpectedRate              string
		ExpectedPeriodStart       int64
		ExpectInVerificationQueue bool
	}

	testDef := msgServerTestDef[types.MsgUpdateInterestRateRequest, types.MsgUpdateInterestRateResponse, postCheckArgs]{
		endpointName: "UpdateInterestRate",
		endpoint:     keeper.NewMsgServer(s.simApp.VaultKeeper).UpdateInterestRate,
		postCheck: func(msg *types.MsgUpdateInterestRateRequest, args postCheckArgs) {
			vault, err := s.k.GetVault(s.ctx, args.VaultAddress)
			s.Require().NoError(err, "should be able to get vault")
			s.Assert().Equal(args.ExpectedRate, vault.CurrentInterestRate, "vault current interest rate should match expected rate")
			s.Assert().Equal(args.ExpectedRate, vault.DesiredInterestRate, "vault desired interest rate should match expected rate")
			if args.ExpectedPeriodStart > 0 {
				s.Assert().Equal(args.ExpectedPeriodStart, vault.PeriodStart, "unexpected period start")
			}
			s.assertInPayoutVerificationQueue(vault.GetAddress(), args.ExpectInVerificationQueue)
		},
	}

	underlyingDenom := "underlying"
	shareDenom := "vaultshares"
	owner := s.adminAddr
	assetMgr := sdk.AccAddress("assetManagerAddr___________")
	vaultAddr := types.GetVaultAddress(shareDenom)
	currentBlockTime := time.Now()

	setup := func() {
		s.requireAddFinalizeAndActivateMarker(sdk.NewCoin(underlyingDenom, math.NewInt(1000)), owner)
		_, err := s.k.CreateVault(s.ctx, &types.MsgCreateVaultRequest{
			Admin:           owner.String(),
			ShareDenom:      shareDenom,
			UnderlyingAsset: underlyingDenom,
		})
		s.Require().NoError(err, "failed to create vault for share denom %s", shareDenom)
		s.ctx = s.ctx.WithEventManager(sdk.NewEventManager())
		s.ctx = s.ctx.WithBlockTime(currentBlockTime)
	}

	tests := []struct {
		name           string
		interestRate   string
		authority      string
		setup          func()
		postCheckArgs  postCheckArgs
		expectedEvents sdk.Events
	}{
		{
			name:         "enable interest from zero to non-zero (disabled → enabled)",
			interestRate: "0.05",
			setup:        setup,
			postCheckArgs: postCheckArgs{
				VaultAddress:              vaultAddr,
				ExpectedRate:              "0.05",
				ExpectInVerificationQueue: true,
				ExpectedPeriodStart:       currentBlockTime.Unix(),
			},
			expectedEvents: sdk.Events{
				sdk.NewEvent("provlabs.vault.v1.EventVaultInterestChange",
					sdk.NewAttribute("current_rate", "0.05"),
					sdk.NewAttribute("desired_rate", "0.05"),
					sdk.NewAttribute("vault_address", vaultAddr.String()),
				),
			},
		},
		{
			name:         "change non-zero rate with reconcile (enabled → enabled)",
			interestRate: "4.06",
			setup: func() {
				setup()
				vaultAcc, err := s.k.GetVault(s.ctx, vaultAddr)
				s.Require().NoError(err, "failed to get vault %s", vaultAddr)
				s.Require().NoError(s.k.UpdateInterestRates(s.ctx, vaultAcc, "4.20", "4.20"), "initial interest rate update should succeed")
				vaultAcc.PeriodStart = currentBlockTime.Unix() - 10000
				s.Require().NoError(s.k.SetVaultAccount(s.ctx, vaultAcc), "setting vault account should succeed")
			},
			postCheckArgs: postCheckArgs{
				VaultAddress:              vaultAddr,
				ExpectedRate:              "4.06",
				ExpectInVerificationQueue: true,
				ExpectedPeriodStart:       currentBlockTime.Unix(),
			},
			expectedEvents: sdk.Events{
				sdk.NewEvent("provlabs.vault.v1.EventVaultReconcile",
					sdk.NewAttribute("interest_earned", sdk.NewInt64Coin(underlyingDenom, 0).String()),
					sdk.NewAttribute("principal_after", sdk.NewInt64Coin(underlyingDenom, 0).String()),
					sdk.NewAttribute("principal_before", sdk.NewInt64Coin(underlyingDenom, 0).String()),
					sdk.NewAttribute("rate", "4.20"),
					sdk.NewAttribute("time", "10000"),
					sdk.NewAttribute("vault_address", vaultAddr.String()),
				),
				sdk.NewEvent("provlabs.vault.v1.EventVaultInterestChange",
					sdk.NewAttribute("current_rate", "4.06"),
					sdk.NewAttribute("desired_rate", "4.06"),
					sdk.NewAttribute("vault_address", vaultAddr.String()),
				),
			},
		},
		{
			name:         "disable interest by setting zero (enabled → disabled)",
			interestRate: "0",
			setup: func() {
				setup()
				vaultAcc, err := s.k.GetVault(s.ctx, vaultAddr)
				s.Require().NoError(err, "failed to get vault %s", vaultAddr)
				s.Require().NoError(s.k.UpdateInterestRates(s.ctx, vaultAcc, "6.12", "6.12"), "initial interest rate update should succeed")
				vaultAcc.PeriodStart = currentBlockTime.Unix() - 10000
				s.Require().NoError(s.k.SetVaultAccount(s.ctx, vaultAcc), "setting vault account should succeed")
			},
			postCheckArgs: postCheckArgs{
				VaultAddress:              vaultAddr,
				ExpectedRate:              types.ZeroInterestRate,
				ExpectInVerificationQueue: false,
			},
			expectedEvents: sdk.Events{
				sdk.NewEvent("provlabs.vault.v1.EventVaultReconcile",
					sdk.NewAttribute("interest_earned", sdk.NewInt64Coin(underlyingDenom, 0).String()),
					sdk.NewAttribute("principal_after", sdk.NewInt64Coin(underlyingDenom, 0).String()),
					sdk.NewAttribute("principal_before", sdk.NewInt64Coin(underlyingDenom, 0).String()),
					sdk.NewAttribute("rate", "6.12"),
					sdk.NewAttribute("time", "10000"),
					sdk.NewAttribute("vault_address", vaultAddr.String()),
				),
				sdk.NewEvent("provlabs.vault.v1.EventVaultInterestChange",
					sdk.NewAttribute("current_rate", "0.0"),
					sdk.NewAttribute("desired_rate", "0.0"),
					sdk.NewAttribute("vault_address", vaultAddr.String()),
				),
			},
		},
		{
			name:         "no-op update with same non-zero rate (enabled → enabled unchanged)",
			interestRate: "3.33",
			setup: func() {
				setup()
				vaultAcc, err := s.k.GetVault(s.ctx, vaultAddr)
				s.Require().NoError(err, "failed to get vault %s", vaultAddr)
				s.Require().NoError(s.k.UpdateInterestRates(s.ctx, vaultAcc, "3.33", "3.33"), "initial interest rate update should succeed")
				vaultAcc.PeriodStart = currentBlockTime.Unix() - 5000
				s.Require().NoError(s.k.SetVaultAccount(s.ctx, vaultAcc), "setting vault account should succeed")
			},
			postCheckArgs: postCheckArgs{
				VaultAddress:              vaultAddr,
				ExpectedRate:              "3.33",
				ExpectInVerificationQueue: true,
				ExpectedPeriodStart:       currentBlockTime.Unix(),
			},
			expectedEvents: sdk.Events{
				sdk.NewEvent("provlabs.vault.v1.EventVaultReconcile",
					sdk.NewAttribute("interest_earned", sdk.NewInt64Coin(underlyingDenom, 0).String()),
					sdk.NewAttribute("principal_after", sdk.NewInt64Coin(underlyingDenom, 0).String()),
					sdk.NewAttribute("principal_before", sdk.NewInt64Coin(underlyingDenom, 0).String()),
					sdk.NewAttribute("rate", "3.33"),
					sdk.NewAttribute("time", "5000"),
					sdk.NewAttribute("vault_address", vaultAddr.String()),
				),
				sdk.NewEvent("provlabs.vault.v1.EventVaultInterestChange",
					sdk.NewAttribute("current_rate", "3.33"),
					sdk.NewAttribute("desired_rate", "3.33"),
					sdk.NewAttribute("vault_address", vaultAddr.String()),
				),
			},
		},
		{
			name:         "no-op update with zero rate (disabled → disabled unchanged)",
			interestRate: "0.0",
			setup:        setup,
			postCheckArgs: postCheckArgs{
				VaultAddress:              vaultAddr,
				ExpectedRate:              types.ZeroInterestRate,
				ExpectInVerificationQueue: false,
			},
			expectedEvents: sdk.Events{
				sdk.NewEvent("provlabs.vault.v1.EventVaultInterestChange",
					sdk.NewAttribute("current_rate", "0.0"),
					sdk.NewAttribute("desired_rate", "0.0"),
					sdk.NewAttribute("vault_address", vaultAddr.String()),
				),
			},
		},
		{
			name:         "re-enable after prior disable with stale period fields present (disabled → enabled)",
			interestRate: "1.25",
			setup: func() {
				setup()
				vaultAcc, err := s.k.GetVault(s.ctx, vaultAddr)
				s.Require().NoError(err, "failed to get vault %s", vaultAddr)
				s.Require().NoError(s.k.UpdateInterestRates(s.ctx, vaultAcc, "0.0", "0.0"), "initial interest rate update should succeed")
				vaultAcc.PeriodStart = currentBlockTime.Unix() - 1234
				vaultAcc.PeriodTimeout = currentBlockTime.Unix() + 9999
				s.Require().NoError(s.k.SetVaultAccount(s.ctx, vaultAcc), "setting vault account should succeed")
			},
			postCheckArgs: postCheckArgs{
				VaultAddress:              vaultAddr,
				ExpectedRate:              "1.25",
				ExpectInVerificationQueue: true,
				ExpectedPeriodStart:       currentBlockTime.Unix(),
			},
			expectedEvents: sdk.Events{
				sdk.NewEvent("provlabs.vault.v1.EventVaultInterestChange",
					sdk.NewAttribute("current_rate", "1.25"),
					sdk.NewAttribute("desired_rate", "1.25"),
					sdk.NewAttribute("vault_address", vaultAddr.String()),
				),
			},
		},
		{
			name:         "paused: change non-zero rate (enabled → enabled) skips reconcile and keeps period start unchanged",
			interestRate: "4.06",
			setup: func() {
				setup()
				vaultAcc, err := s.k.GetVault(s.ctx, vaultAddr)
				s.Require().NoError(err, "failed to get vault %s", vaultAddr)
				s.Require().NoError(s.k.UpdateInterestRates(s.ctx, vaultAcc, "4.20", "4.20"), "initial interest rate update should succeed")
				priorStart := currentBlockTime.Unix() - 7777
				vaultAcc.PeriodStart = priorStart
				vaultAcc.Paused = true
				s.Require().NoError(s.k.SetVaultAccount(s.ctx, vaultAcc), "setting vault account should succeed")
				s.ctx = s.ctx.WithEventManager(sdk.NewEventManager())
			},
			postCheckArgs: postCheckArgs{
				VaultAddress:              vaultAddr,
				ExpectedRate:              "4.06",
				ExpectInVerificationQueue: false,
				ExpectedPeriodStart:       currentBlockTime.Unix() - 7777,
			},
			expectedEvents: sdk.Events{
				sdk.NewEvent("provlabs.vault.v1.EventVaultInterestChange",
					sdk.NewAttribute("current_rate", "4.06"),
					sdk.NewAttribute("desired_rate", "4.06"),
					sdk.NewAttribute("vault_address", vaultAddr.String()),
				),
			},
		},
		{
			name:         "paused: enable from zero (disabled → enabled) enqueues verification, no reconcile",
			interestRate: "1.25",
			setup: func() {
				setup()
				vaultAcc, err := s.k.GetVault(s.ctx, vaultAddr)
				s.Require().NoError(err, "failed to get vault %s", vaultAddr)
				s.Require().NoError(s.k.UpdateInterestRates(s.ctx, vaultAcc, "0.0", "0.0"), "initial interest rate update should succeed")
				vaultAcc.Paused = true
				s.Require().NoError(s.k.SetVaultAccount(s.ctx, vaultAcc), "setting vault account should succeed")
				s.ctx = s.ctx.WithEventManager(sdk.NewEventManager())
			},
			postCheckArgs: postCheckArgs{
				VaultAddress:              vaultAddr,
				ExpectedRate:              "1.25",
				ExpectInVerificationQueue: true,
			},
			expectedEvents: sdk.Events{
				sdk.NewEvent("provlabs.vault.v1.EventVaultInterestChange",
					sdk.NewAttribute("current_rate", "1.25"),
					sdk.NewAttribute("desired_rate", "1.25"),
					sdk.NewAttribute("vault_address", vaultAddr.String()),
				),
			},
		},
		{
			name:         "paused: disable interest (enabled → disabled) clears period fields and removes verification",
			interestRate: "0.0",
			setup: func() {
				setup()
				vaultAcc, err := s.k.GetVault(s.ctx, vaultAddr)
				s.Require().NoError(err, "failed to get vault %s", vaultAddr)
				s.Require().NoError(s.k.UpdateInterestRates(s.ctx, vaultAcc, "2.50", "2.50"), "initial interest rate update should succeed")
				vaultAcc.PeriodStart = currentBlockTime.Unix() - 5000
				vaultAcc.PeriodTimeout = currentBlockTime.Unix() + 3600
				vaultAcc.Paused = true
				s.Require().NoError(s.k.SetVaultAccount(s.ctx, vaultAcc), "setting vault account should succeed")
				s.ctx = s.ctx.WithEventManager(sdk.NewEventManager())
			},
			postCheckArgs: postCheckArgs{
				VaultAddress:              vaultAddr,
				ExpectedRate:              types.ZeroInterestRate,
				ExpectInVerificationQueue: false,
			},
			expectedEvents: sdk.Events{
				sdk.NewEvent("provlabs.vault.v1.EventVaultInterestChange",
					sdk.NewAttribute("current_rate", "0.0"),
					sdk.NewAttribute("desired_rate", "0.0"),
					sdk.NewAttribute("vault_address", vaultAddr.String()),
				),
			},
		},
		{
			name:         "asset manager can update non-zero rate",
			interestRate: "0.75",
			authority:    assetMgr.String(),
			setup: func() {
				setup()
				v, err := s.k.GetVault(s.ctx, vaultAddr)
				s.Require().NoError(err, "failed to get vault %s", vaultAddr)
				v.AssetManager = assetMgr.String()
				s.Require().NoError(s.k.SetVaultAccount(s.ctx, v), "failed to set vault account with asset manager %s", assetMgr)
			},
			postCheckArgs: postCheckArgs{
				VaultAddress:              vaultAddr,
				ExpectedRate:              "0.75",
				ExpectInVerificationQueue: true,
				ExpectedPeriodStart:       currentBlockTime.Unix(),
			},
			expectedEvents: sdk.Events{
				sdk.NewEvent("provlabs.vault.v1.EventVaultInterestChange",
					sdk.NewAttribute("current_rate", "0.75"),
					sdk.NewAttribute("desired_rate", "0.75"),
					sdk.NewAttribute("vault_address", vaultAddr.String()),
				),
			},
		},
	}

	for _, tt := range tests {
		s.Run(tt.name, func() {
			updateInterestRateReq := types.MsgUpdateInterestRateRequest{
				Authority:    owner.String(),
				VaultAddress: vaultAddr.String(),
				NewRate:      tt.interestRate,
			}
			if tt.authority != "" {
				updateInterestRateReq.Authority = tt.authority
			}

			tc := msgServerTestCase[types.MsgUpdateInterestRateRequest, postCheckArgs]{
				name:           tt.name,
				setup:          tt.setup,
				msg:            updateInterestRateReq,
				postCheckArgs:  tt.postCheckArgs,
				expectedEvents: tt.expectedEvents,
			}

			testDef.expectedResponse = &types.MsgUpdateInterestRateResponse{}
			runMsgServerTestCase(s, testDef, tc)
		})
	}
}

func (s *TestSuite) TestMsgServer_UpdateInterestRate_Failures() {
	testDef := msgServerTestDef[types.MsgUpdateInterestRateRequest, types.MsgUpdateInterestRateResponse, any]{
		endpointName: "UpdateInterestRate",
		endpoint:     keeper.NewMsgServer(s.simApp.VaultKeeper).UpdateInterestRate,
		postCheck:    nil,
	}

	underlyingDenom := "underlying"
	shareDenom := "vaultshares"
	owner := s.adminAddr
	vaultAddr := types.GetVaultAddress(shareDenom)
	currentBlockTime := time.Now()

	setup := func() {
		s.requireAddFinalizeAndActivateMarker(sdk.NewCoin(underlyingDenom, math.NewInt(1000)), owner)
		_, err := s.k.CreateVault(s.ctx, &types.MsgCreateVaultRequest{
			Admin:           owner.String(),
			ShareDenom:      shareDenom,
			UnderlyingAsset: underlyingDenom,
		})
		s.Require().NoError(err, "failed to create vault for share denom %s", shareDenom)
		s.ctx = s.ctx.WithEventManager(sdk.NewEventManager())
		s.ctx = s.ctx.WithBlockTime(currentBlockTime)
	}

	tests := []msgServerTestCase[types.MsgUpdateInterestRateRequest, any]{
		{
			name: "vault does not exist",
			msg: types.MsgUpdateInterestRateRequest{
				Authority:    owner.String(),
				VaultAddress: types.GetVaultAddress("invalidvaultaddress").String(),
				NewRate:      "0.05",
			},
			setup:              setup,
			expectedErrSubstrs: []string{"not found"},
		},
		{
			name: "vault invalid vault address",
			msg: types.MsgUpdateInterestRateRequest{
				Authority:    owner.String(),
				VaultAddress: markertypes.MustGetMarkerAddress(shareDenom).String(),
				NewRate:      "0.05",
			},
			setup:              setup,
			expectedErrSubstrs: []string{"failed to get vault", "is not a vault account"},
		},
		{
			name: "unauthorized authority",
			msg: types.MsgUpdateInterestRateRequest{
				Authority:    sdk.AccAddress("bad").String(),
				VaultAddress: vaultAddr.String(),
				NewRate:      "0.05",
			},
			setup:              setup,
			expectedErrSubstrs: []string{"unauthorized authority"},
		},
		{
			name: "rate above absolute ceiling is rejected",
			msg: types.MsgUpdateInterestRateRequest{
				Authority:    owner.String(),
				VaultAddress: vaultAddr.String(),
				NewRate:      "150.0",
			},
			setup:              setup,
			expectedErrSubstrs: []string{"invalid new rate", "exceeds maximum allowed magnitude"},
		},
	}
	for _, tc := range tests {
		s.Run(tc.name, func() {
			runMsgServerTestCase(s, testDef, tc)
		})
	}
}

func (s *TestSuite) TestMsgServer_UpdateMinInterestRate() {
	type postCheckArgs struct {
		VaultAddress sdk.AccAddress
		ExpectedMin  string
	}

	testDef := msgServerTestDef[types.MsgUpdateMinInterestRateRequest, types.MsgUpdateMinInterestRateResponse, postCheckArgs]{
		endpointName: "UpdateMinInterestRate",
		endpoint:     keeper.NewMsgServer(s.simApp.VaultKeeper).UpdateMinInterestRate,
		postCheck: func(msg *types.MsgUpdateMinInterestRateRequest, args postCheckArgs) {
			v, err := s.k.GetVault(s.ctx, args.VaultAddress)
			s.Require().NoError(err, "post-check: failed to get vault %s", args.VaultAddress)
			s.Assert().Equal(args.ExpectedMin, v.MinInterestRate, "post-check: min interest rate mismatch")
		},
	}

	underlying := "under"
	share := "vaultshares"
	admin := s.adminAddr
	vaultAddr := types.GetVaultAddress(share)

	setup := func() {
		s.requireAddFinalizeAndActivateMarker(sdk.NewCoin(underlying, math.NewInt(1000)), admin)
		_, err := s.k.CreateVault(s.ctx, &types.MsgCreateVaultRequest{
			Admin:           admin.String(),
			ShareDenom:      share,
			UnderlyingAsset: underlying,
		})
		s.Require().NoError(err, "failed to create vault for share denom %s", share)
		s.ctx = s.ctx.WithEventManager(sdk.NewEventManager())
	}

	tests := []struct {
		name           string
		minRate        string
		postCheckArgs  postCheckArgs
		expectedEvents sdk.Events
	}{
		{
			name:    "set min to non-empty",
			minRate: "-0.05",
			postCheckArgs: postCheckArgs{
				VaultAddress: vaultAddr,
				ExpectedMin:  "-0.05",
			},
			expectedEvents: sdk.Events{
				sdk.NewEvent("provlabs.vault.v1.EventMinInterestRateUpdated",
					sdk.NewAttribute("admin", admin.String()),
					sdk.NewAttribute("min_rate", "-0.05"),
					sdk.NewAttribute("vault_address", vaultAddr.String()),
				),
			},
		},
		{
			name:    "disable min by empty string",
			minRate: "",
			postCheckArgs: postCheckArgs{
				VaultAddress: vaultAddr,
				ExpectedMin:  "",
			},
			expectedEvents: sdk.Events{},
		},
	}

	for _, tt := range tests {
		s.Run(tt.name, func() {
			tc := msgServerTestCase[types.MsgUpdateMinInterestRateRequest, postCheckArgs]{
				name:  tt.name,
				setup: setup,
				msg: types.MsgUpdateMinInterestRateRequest{
					Admin:        admin.String(),
					VaultAddress: vaultAddr.String(),
					MinRate:      tt.minRate,
				},
				postCheckArgs:  tt.postCheckArgs,
				expectedEvents: tt.expectedEvents,
			}
			testDef.expectedResponse = &types.MsgUpdateMinInterestRateResponse{}
			runMsgServerTestCase(s, testDef, tc)
		})
	}
}

func (s *TestSuite) TestMsgServer_UpdateMinInterestRate_Failures() {
	testDef := msgServerTestDef[types.MsgUpdateMinInterestRateRequest, types.MsgUpdateMinInterestRateResponse, any]{
		endpointName: "UpdateMinInterestRate",
		endpoint:     keeper.NewMsgServer(s.simApp.VaultKeeper).UpdateMinInterestRate,
		postCheck:    nil,
	}

	underlying := "under"
	share := "vaultshares"
	admin := s.adminAddr
	other := s.CreateAndFundAccount(sdk.NewInt64Coin("stake", 1000))
	vaultAddr := types.GetVaultAddress(share)

	setup := func() {
		s.requireAddFinalizeAndActivateMarker(sdk.NewCoin(underlying, math.NewInt(1000)), admin)
		_, err := s.k.CreateVault(s.ctx, &types.MsgCreateVaultRequest{
			Admin:           admin.String(),
			ShareDenom:      share,
			UnderlyingAsset: underlying,
		})
		s.Require().NoError(err, "failed to create vault for share denom %s", share)
		s.ctx = s.ctx.WithEventManager(sdk.NewEventManager())
	}

	tests := []msgServerTestCase[types.MsgUpdateMinInterestRateRequest, any]{
		{
			name: "vault does not exist",
			setup: func() {
				s.ctx = s.ctx.WithEventManager(sdk.NewEventManager())
			},
			msg: types.MsgUpdateMinInterestRateRequest{
				Admin:        admin.String(),
				VaultAddress: types.GetVaultAddress("doesnotexist").String(),
				MinRate:      "0.01",
			},
			expectedErrSubstrs: []string{"not found"},
		},
		{
			name:  "invalid vault address (not a vault account)",
			setup: setup,
			msg: types.MsgUpdateMinInterestRateRequest{
				Admin:        admin.String(),
				VaultAddress: markertypes.MustGetMarkerAddress(share).String(),
				MinRate:      "0.01",
			},
			expectedErrSubstrs: []string{"failed to get vault", "is not a vault account"},
		},
		{
			name:  "unauthorized admin",
			setup: setup,
			msg: types.MsgUpdateMinInterestRateRequest{
				Admin:        other.String(),
				VaultAddress: vaultAddr.String(),
				MinRate:      "0.02",
			},
			expectedErrSubstrs: []string{"unauthorized", "is not the vault admin"},
		},
		{
			name: "validation failure: min > existing max",
			setup: func() {
				setup()
				v, err := s.k.GetVault(s.ctx, vaultAddr)
				s.Require().NoError(err, "failed to get vault %s", vaultAddr)
				s.Require().NoError(s.k.SetMaxInterestRate(s.ctx, v, "0.05"), "failed to set max interest rate")
			},
			msg: types.MsgUpdateMinInterestRateRequest{
				Admin:        admin.String(),
				VaultAddress: vaultAddr.String(),
				MinRate:      "0.06",
			},
			expectedErrSubstrs: []string{"minimum interest rate", "greater than", "maximum"},
		},
		{
			name:  "min below negative absolute ceiling is rejected",
			setup: setup,
			msg: types.MsgUpdateMinInterestRateRequest{
				Admin:        admin.String(),
				VaultAddress: vaultAddr.String(),
				MinRate:      "-150.0",
			},
			expectedErrSubstrs: []string{"invalid min interest rate", "exceeds maximum allowed magnitude"},
		},
	}

	for _, tc := range tests {
		s.Run(tc.name, func() {
			runMsgServerTestCase(s, testDef, tc)
		})
	}
}

func (s *TestSuite) TestMsgServer_UpdateMaxInterestRate() {
	type postCheckArgs struct {
		VaultAddress sdk.AccAddress
		ExpectedMax  string
	}

	testDef := msgServerTestDef[types.MsgUpdateMaxInterestRateRequest, types.MsgUpdateMaxInterestRateResponse, postCheckArgs]{
		endpointName: "UpdateMaxInterestRate",
		endpoint:     keeper.NewMsgServer(s.simApp.VaultKeeper).UpdateMaxInterestRate,
		postCheck: func(msg *types.MsgUpdateMaxInterestRateRequest, args postCheckArgs) {
			v, err := s.k.GetVault(s.ctx, args.VaultAddress)
			s.Require().NoError(err, "post-check: failed to get vault %s", args.VaultAddress)
			s.Assert().Equal(args.ExpectedMax, v.MaxInterestRate, "post-check: max interest rate mismatch")
		},
	}

	underlying := "under"
	share := "vaultshares"
	admin := s.adminAddr
	vaultAddr := types.GetVaultAddress(share)

	setup := func() {
		s.requireAddFinalizeAndActivateMarker(sdk.NewCoin(underlying, math.NewInt(1000)), admin)
		_, err := s.k.CreateVault(s.ctx, &types.MsgCreateVaultRequest{
			Admin:           admin.String(),
			ShareDenom:      share,
			UnderlyingAsset: underlying,
		})
		s.Require().NoError(err, "failed to create vault for share denom %s", share)
		s.ctx = s.ctx.WithEventManager(sdk.NewEventManager())
	}

	tests := []struct {
		name           string
		maxRate        string
		postCheckArgs  postCheckArgs
		expectedEvents sdk.Events
	}{
		{
			name:    "set_max_to_non-empty",
			maxRate: "0.50",
			postCheckArgs: postCheckArgs{
				VaultAddress: vaultAddr,
				ExpectedMax:  "0.50",
			},
			expectedEvents: sdk.Events{
				sdk.NewEvent("provlabs.vault.v1.EventMaxInterestRateUpdated",
					sdk.NewAttribute("admin", admin.String()),
					sdk.NewAttribute("max_rate", "0.50"),
					sdk.NewAttribute("vault_address", vaultAddr.String()),
				),
			},
		},
		{
			name:    "disable_max_by_empty_string",
			maxRate: "",
			postCheckArgs: postCheckArgs{
				VaultAddress: vaultAddr,
				ExpectedMax:  "",
			},
			expectedEvents: sdk.Events{},
		},
	}

	for _, tt := range tests {
		s.Run(tt.name, func() {
			tc := msgServerTestCase[types.MsgUpdateMaxInterestRateRequest, postCheckArgs]{
				name:  tt.name,
				setup: setup,
				msg: types.MsgUpdateMaxInterestRateRequest{
					Admin:        admin.String(),
					VaultAddress: vaultAddr.String(),
					MaxRate:      tt.maxRate,
				},
				postCheckArgs:  tt.postCheckArgs,
				expectedEvents: tt.expectedEvents,
			}
			testDef.expectedResponse = &types.MsgUpdateMaxInterestRateResponse{}
			runMsgServerTestCase(s, testDef, tc)
		})
	}
}

func (s *TestSuite) TestMsgServer_UpdateMaxInterestRate_Failures() {
	testDef := msgServerTestDef[types.MsgUpdateMaxInterestRateRequest, types.MsgUpdateMaxInterestRateResponse, any]{
		endpointName: "UpdateMaxInterestRate",
		endpoint:     keeper.NewMsgServer(s.simApp.VaultKeeper).UpdateMaxInterestRate,
		postCheck:    nil,
	}

	underlying := "under"
	share := "vaultshares"
	admin := s.adminAddr
	other := s.CreateAndFundAccount(sdk.NewInt64Coin("stake", 1000))
	vaultAddr := types.GetVaultAddress(share)

	baseSetup := func() {
		s.requireAddFinalizeAndActivateMarker(sdk.NewCoin(underlying, math.NewInt(1000)), admin)
		_, err := s.k.CreateVault(s.ctx, &types.MsgCreateVaultRequest{
			Admin:           admin.String(),
			ShareDenom:      share,
			UnderlyingAsset: underlying,
		})
		s.Require().NoError(err, "failed to create vault for share denom %s", share)
		s.ctx = s.ctx.WithEventManager(sdk.NewEventManager())
	}

	tests := []msgServerTestCase[types.MsgUpdateMaxInterestRateRequest, any]{
		{
			name:  "vault does not exist",
			setup: func() { s.ctx = s.ctx.WithEventManager(sdk.NewEventManager()) },
			msg: types.MsgUpdateMaxInterestRateRequest{
				Admin:        admin.String(),
				VaultAddress: types.GetVaultAddress("doesnotexist").String(),
				MaxRate:      "0.99",
			},
			expectedErrSubstrs: []string{"not found"},
		},
		{
			name:  "invalid vault address (not a vault account)",
			setup: baseSetup,
			msg: types.MsgUpdateMaxInterestRateRequest{
				Admin:        admin.String(),
				VaultAddress: markertypes.MustGetMarkerAddress(share).String(),
				MaxRate:      "0.10",
			},
			expectedErrSubstrs: []string{"failed to get vault", "is not a vault account"},
		},
		{
			name:  "unauthorized admin",
			setup: baseSetup,
			msg: types.MsgUpdateMaxInterestRateRequest{
				Admin:        other.String(),
				VaultAddress: vaultAddr.String(),
				MaxRate:      "0.33",
			},
			expectedErrSubstrs: []string{"unauthorized", "is not the vault admin"},
		},
		{
			name: "validation_failure: max < existing min",
			setup: func() {
				baseSetup()
				_, err := keeper.NewMsgServer(s.simApp.VaultKeeper).UpdateInterestRate(
					s.ctx, &types.MsgUpdateInterestRateRequest{
						Authority:    admin.String(),
						VaultAddress: vaultAddr.String(),
						NewRate:      "0.50",
					},
				)
				s.Require().NoError(err, "initial interest rate update should succeed")

				_, err = keeper.NewMsgServer(s.simApp.VaultKeeper).UpdateMinInterestRate(
					s.ctx, &types.MsgUpdateMinInterestRateRequest{
						Admin:        admin.String(),
						VaultAddress: vaultAddr.String(),
						MinRate:      "0.50",
					},
				)
				s.Require().NoError(err, "initial min interest rate update should succeed")

				s.ctx = s.ctx.WithEventManager(sdk.NewEventManager())
			},
			msg: types.MsgUpdateMaxInterestRateRequest{
				Admin:        admin.String(),
				VaultAddress: vaultAddr.String(),
				MaxRate:      "0.40",
			},
			expectedErrSubstrs: []string{
				"minimum interest rate",
				"cannot be greater than",
				"maximum interest rate",
			},
		},
		{
			name:  "max above absolute ceiling is rejected",
			setup: baseSetup,
			msg: types.MsgUpdateMaxInterestRateRequest{
				Admin:        admin.String(),
				VaultAddress: vaultAddr.String(),
				MaxRate:      "150.0",
			},
			expectedErrSubstrs: []string{"invalid max interest rate", "exceeds maximum allowed magnitude"},
		},
	}

	for _, tc := range tests {
		s.Run(tc.name, func() {
			runMsgServerTestCase(s, testDef, tc)
		})
	}
}

func (s *TestSuite) TestMsgServer_UpdateWithdrawalDelay() {
	type postCheckArgs struct {
		VaultAddress         sdk.AccAddress
		ExpectedDelaySeconds uint64
		ExpectedAuthority    string
	}

	testDef := msgServerTestDef[types.MsgUpdateWithdrawalDelayRequest, types.MsgUpdateWithdrawalDelayResponse, postCheckArgs]{
		endpointName: "UpdateWithdrawalDelay",
		endpoint:     keeper.NewMsgServer(s.simApp.VaultKeeper).UpdateWithdrawalDelay,
		postCheck: func(msg *types.MsgUpdateWithdrawalDelayRequest, args postCheckArgs) {
			v, err := s.k.GetVault(s.ctx, args.VaultAddress)
			s.Require().NoError(err, "post-check: should load vault for verification")
			s.Assert().Equal(args.ExpectedDelaySeconds, v.WithdrawalDelaySeconds, "post-check: expected WithdrawalDelaySeconds to match")
		},
	}

	underlying := "under"
	share := "vaultshares"
	admin := s.adminAddr
	assetMgr := s.CreateAndFundAccount(sdk.NewInt64Coin("stake", 1))
	vaultAddr := types.GetVaultAddress(share)

	delayAdmin := uint64(3600)
	delayAssetMgr := uint64(7200)

	setup := func() {
		s.requireAddFinalizeAndActivateMarker(sdk.NewCoin(underlying, math.NewInt(1000)), admin)
		_, err := s.k.CreateVault(s.ctx, &types.MsgCreateVaultRequest{
			Admin:           admin.String(),
			ShareDenom:      share,
			UnderlyingAsset: underlying,
		})
		s.Require().NoError(err, "setup: expected vault creation to succeed")

		v, err := s.k.GetVault(s.ctx, vaultAddr)
		s.Require().NoError(err, "setup: should load vault")
		v.AssetManager = assetMgr.String()
		s.k.AuthKeeper.SetAccount(s.ctx, v)

		s.ctx = s.ctx.WithEventManager(sdk.NewEventManager())
	}

	tests := []msgServerTestCase[types.MsgUpdateWithdrawalDelayRequest, postCheckArgs]{
		{
			name:  "happy path - admin is authority",
			setup: setup,
			msg: types.MsgUpdateWithdrawalDelayRequest{
				Authority:              admin.String(),
				VaultAddress:           vaultAddr.String(),
				WithdrawalDelaySeconds: delayAdmin,
			},
			postCheckArgs: postCheckArgs{
				VaultAddress:         vaultAddr,
				ExpectedDelaySeconds: delayAdmin,
				ExpectedAuthority:    admin.String(),
			},
			expectedEvents: sdk.Events{
				sdk.NewEvent("provlabs.vault.v1.EventWithdrawalDelayUpdated",
					sdk.NewAttribute("authority", admin.String()),
					sdk.NewAttribute("vault_address", vaultAddr.String()),
					sdk.NewAttribute("withdrawal_delay_seconds", fmt.Sprintf("%d", delayAdmin)),
				),
			},
		},
		{
			name:  "happy path - asset manager is authority",
			setup: setup,
			msg: types.MsgUpdateWithdrawalDelayRequest{
				Authority:              assetMgr.String(),
				VaultAddress:           vaultAddr.String(),
				WithdrawalDelaySeconds: delayAssetMgr,
			},
			postCheckArgs: postCheckArgs{
				VaultAddress:         vaultAddr,
				ExpectedDelaySeconds: delayAssetMgr,
				ExpectedAuthority:    assetMgr.String(),
			},
			expectedEvents: sdk.Events{
				sdk.NewEvent("provlabs.vault.v1.EventWithdrawalDelayUpdated",
					sdk.NewAttribute("authority", assetMgr.String()),
					sdk.NewAttribute("vault_address", vaultAddr.String()),
					sdk.NewAttribute("withdrawal_delay_seconds", fmt.Sprintf("%d", delayAssetMgr)),
				),
			},
		},
	}

	testDef.expectedResponse = &types.MsgUpdateWithdrawalDelayResponse{}
	for _, tc := range tests {
		s.Run(tc.name, func() {
			runMsgServerTestCase(s, testDef, tc)
		})
	}
}

func (s *TestSuite) TestMsgServer_UpdateWithdrawalDelay_Failures() {
	testDef := msgServerTestDef[types.MsgUpdateWithdrawalDelayRequest, types.MsgUpdateWithdrawalDelayResponse, any]{
		endpointName: "UpdateWithdrawalDelay",
		endpoint:     keeper.NewMsgServer(s.simApp.VaultKeeper).UpdateWithdrawalDelay,
		postCheck:    nil,
	}

	underlying := "under"
	share := "vaultshares"
	admin := s.adminAddr
	other := s.CreateAndFundAccount(sdk.NewInt64Coin("stake", 1))
	vaultAddr := types.GetVaultAddress(share)
	markerAddr := markertypes.MustGetMarkerAddress(share)

	base := func() {
		s.requireAddFinalizeAndActivateMarker(sdk.NewCoin(underlying, math.NewInt(1000)), admin)
		_, err := s.k.CreateVault(s.ctx, &types.MsgCreateVaultRequest{
			Admin:           admin.String(),
			ShareDenom:      share,
			UnderlyingAsset: underlying,
		})
		s.Require().NoError(err, "base: expected vault creation to succeed")
		s.ctx = s.ctx.WithEventManager(sdk.NewEventManager())
	}

	tests := []msgServerTestCase[types.MsgUpdateWithdrawalDelayRequest, any]{
		{
			name: "vault not found",
			setup: func() {
				s.ctx = s.ctx.WithEventManager(sdk.NewEventManager())
			},
			msg: types.MsgUpdateWithdrawalDelayRequest{
				Authority:              admin.String(),
				VaultAddress:           types.GetVaultAddress("missing").String(),
				WithdrawalDelaySeconds: 10,
			},
			expectedErrSubstrs: []string{"vault not found"},
		},
		{
			name:  "invalid vault address (not a vault account)",
			setup: base,
			msg: types.MsgUpdateWithdrawalDelayRequest{
				Authority:              admin.String(),
				VaultAddress:           markerAddr.String(),
				WithdrawalDelaySeconds: 10,
			},
			expectedErrSubstrs: []string{"failed to get vault", "is not a vault account"},
		},
		{
			name:  "unauthorized admin",
			setup: base,
			msg: types.MsgUpdateWithdrawalDelayRequest{
				Authority:              other.String(),
				VaultAddress:           vaultAddr.String(),
				WithdrawalDelaySeconds: 10,
			},
			expectedErrSubstrs: []string{"unauthorized"},
		},
	}

	for _, tc := range tests {
		s.Run(tc.name, func() {
			runMsgServerTestCase(s, testDef, tc)
		})
	}
}

func (s *TestSuite) TestMsgServer_DepositInterestFunds() {
	type postCheckArgs struct {
		VaultAddress          sdk.AccAddress
		ExpectedDepositAmount sdk.Coin
		ExpectedVaultBalance  sdk.Coin
		InVerificationQueue   bool
		ExpectedPeriodStart   int64
	}

	testDef := msgServerTestDef[types.MsgDepositInterestFundsRequest, types.MsgDepositInterestFundsResponse, postCheckArgs]{
		endpointName: "DepositInterestFunds",
		endpoint:     keeper.NewMsgServer(s.simApp.VaultKeeper).DepositInterestFunds,
		postCheck: func(msg *types.MsgDepositInterestFundsRequest, args postCheckArgs) {
			vaultBal := s.k.BankKeeper.GetBalance(s.ctx, args.VaultAddress, args.ExpectedDepositAmount.Denom)
			s.Assert().Equal(args.ExpectedVaultBalance.Amount.Int64(), vaultBal.Amount.Int64(), "vault balance mismatch")

			s.assertInPayoutVerificationQueue(args.VaultAddress, args.InVerificationQueue)
		},
	}

	underlying := "under"
	shares := "vaultshares"
	admin := s.adminAddr
	vaultAddr := types.GetVaultAddress(shares)
	blockTime := time.Now()
	amount := sdk.NewInt64Coin(underlying, 500)

	setup := func() {
		s.requireAddFinalizeAndActivateMarker(sdk.NewCoin(underlying, math.NewInt(1000)), admin)
		s.Require().NoError(FundAccount(s.ctx, s.simApp, admin, sdk.NewCoins(amount)), "failed to fund account")
		_, err := s.k.CreateVault(s.ctx, &types.MsgCreateVaultRequest{
			Admin:           admin.String(),
			ShareDenom:      shares,
			UnderlyingAsset: underlying,
		})
		s.Require().NoError(err, "failed to create vault during setup")
		s.ctx = s.ctx.WithEventManager(sdk.NewEventManager())
		s.ctx = s.ctx.WithBlockTime(blockTime)
	}

	setupRestricted := func() {
		requiredAttribute := "thisisrequired"
		s.simApp.AccountKeeper.SetAccount(s.ctx, s.simApp.AccountKeeper.NewAccountWithAddress(s.ctx, admin))
		s.requireAttribute(admin, requiredAttribute)

		s.requireAddFinalizeAndActivateMarker(sdk.NewCoin(underlying, math.NewInt(1000)), admin, requiredAttribute)
		s.Require().NoError(FundAccount(s.ctx, s.simApp, admin, sdk.NewCoins(amount)), "failed to fund account")
		_, err := s.k.CreateVault(s.ctx, &types.MsgCreateVaultRequest{
			Admin:           admin.String(),
			ShareDenom:      shares,
			UnderlyingAsset: underlying,
		})
		s.Require().NoError(err, "should successfully create restricted vault")
		s.ctx = s.ctx.WithEventManager(sdk.NewEventManager())
		s.ctx = s.ctx.WithBlockTime(blockTime)
	}

	s.Run("happy path - deposit interest funds", func() {
		ev := createSendCoinEvents(admin.String(), vaultAddr.String(), sdk.NewCoins(amount).String())
		ev = append(ev, sdk.NewEvent(
			"provlabs.vault.v1.EventInterestDeposit",
			sdk.NewAttribute("amount", amount.String()),
			sdk.NewAttribute("authority", admin.String()),
			sdk.NewAttribute("vault_address", vaultAddr.String()),
		))

		tc := msgServerTestCase[types.MsgDepositInterestFundsRequest, postCheckArgs]{
			name:  "happy path",
			setup: setup,
			msg: types.MsgDepositInterestFundsRequest{
				Authority:    admin.String(),
				VaultAddress: vaultAddr.String(),
				Amount:       amount,
			},
			postCheckArgs: postCheckArgs{
				VaultAddress:          vaultAddr,
				ExpectedDepositAmount: amount,
				ExpectedVaultBalance:  amount,
				InVerificationQueue:   true,
				ExpectedPeriodStart:   blockTime.Unix(),
			},
			expectedEvents: ev,
		}

		testDef.expectedResponse = &types.MsgDepositInterestFundsResponse{}
		runMsgServerTestCase(s, testDef, tc)
	})

	s.Run("happy path - deposit interest funds - restricted marker with attributes", func() {
		ev := createSendCoinEvents(admin.String(), vaultAddr.String(), sdk.NewCoins(amount).String())
		ev = append(ev, sdk.NewEvent(
			"provlabs.vault.v1.EventInterestDeposit",
			sdk.NewAttribute("amount", amount.String()),
			sdk.NewAttribute("authority", admin.String()),
			sdk.NewAttribute("vault_address", vaultAddr.String()),
		))

		tc := msgServerTestCase[types.MsgDepositInterestFundsRequest, postCheckArgs]{
			name:  "happy path restricted",
			setup: setupRestricted,
			msg: types.MsgDepositInterestFundsRequest{
				Authority:    admin.String(),
				VaultAddress: vaultAddr.String(),
				Amount:       amount,
			},
			postCheckArgs: postCheckArgs{
				VaultAddress:          vaultAddr,
				ExpectedDepositAmount: amount,
				ExpectedVaultBalance:  amount,
				InVerificationQueue:   true,
				ExpectedPeriodStart:   blockTime.Unix(),
			},
			expectedEvents: ev,
		}

		testDef.expectedResponse = &types.MsgDepositInterestFundsResponse{}
		runMsgServerTestCase(s, testDef, tc)
	})

	s.Run("happy path - deposit interest funds as asset manager", func() {
		assetMgr := s.CreateAndFundAccount(amount)
		setupWithAssetMgr := func() {
			setup()
			_, err := keeper.NewMsgServer(s.simApp.VaultKeeper).SetAssetManager(s.ctx, &types.MsgSetAssetManagerRequest{
				Admin:        admin.String(),
				VaultAddress: vaultAddr.String(),
				AssetManager: assetMgr.String(),
			})
			s.Require().NoError(err, "failed to set asset manager")
			s.Require().NoError(FundAccount(s.ctx, s.simApp, assetMgr, sdk.NewCoins(amount)), "failed to fund asset manager account")
		}

		ev := createSendCoinEvents(assetMgr.String(), vaultAddr.String(), sdk.NewCoins(amount).String())
		ev = append(ev, sdk.NewEvent(
			"provlabs.vault.v1.EventInterestDeposit",
			sdk.NewAttribute("amount", amount.String()),
			sdk.NewAttribute("authority", assetMgr.String()),
			sdk.NewAttribute("vault_address", vaultAddr.String()),
		))

		tc := msgServerTestCase[types.MsgDepositInterestFundsRequest, postCheckArgs]{
			name:  "happy path asset manager",
			setup: setupWithAssetMgr,
			msg: types.MsgDepositInterestFundsRequest{
				Authority:    assetMgr.String(),
				VaultAddress: vaultAddr.String(),
				Amount:       amount,
			},
			postCheckArgs: postCheckArgs{
				VaultAddress:          vaultAddr,
				ExpectedDepositAmount: amount,
				ExpectedVaultBalance:  amount,
				InVerificationQueue:   true,
				ExpectedPeriodStart:   blockTime.Unix(),
			},
			expectedEvents: ev,
		}

		testDef.expectedResponse = &types.MsgDepositInterestFundsResponse{}
		runMsgServerTestCase(s, testDef, tc)
	})
}

func (s *TestSuite) TestMsgServer_DepositInterestFunds_Failures() {
	testDef := msgServerTestDef[types.MsgDepositInterestFundsRequest, types.MsgDepositInterestFundsResponse, any]{
		endpointName: "DepositInterestFunds",
		endpoint:     keeper.NewMsgServer(s.simApp.VaultKeeper).DepositInterestFunds,
		postCheck:    nil,
	}

	underlying := "under"
	shares := "vaultshares"
	unsupportedDenom := "unsupportedDenom"
	admin := s.adminAddr
	other := s.CreateAndFundAccount(sdk.NewInt64Coin("stake", 1000))
	vaultAddr := types.GetVaultAddress(shares)
	amount := sdk.NewInt64Coin(underlying, 500)

	setup := func() {
		s.requireAddFinalizeAndActivateMarker(sdk.NewCoin(underlying, math.NewInt(1000)), admin)
		_, err := s.k.CreateVault(s.ctx, &types.MsgCreateVaultRequest{
			Admin:           admin.String(),
			ShareDenom:      shares,
			UnderlyingAsset: underlying,
		})
		s.Require().NoError(err, "failed to create vault")
		s.ctx = s.ctx.WithEventManager(sdk.NewEventManager())
	}

	setupWithAdminFunds := func() {
		setup()
		s.Require().NoError(FundAccount(s.ctx, s.simApp, admin, sdk.NewCoins(amount)), "failed to fund admin account")
	}

	tests := []msgServerTestCase[types.MsgDepositInterestFundsRequest, any]{
		{
			name: "vault does not exist",
			msg: types.MsgDepositInterestFundsRequest{
				Authority:    admin.String(),
				VaultAddress: types.GetVaultAddress("doesnotexist").String(),
				Amount:       amount,
			},
			expectedErrSubstrs: []string{"not found"},
		},
		{
			name:  "invalid vault address not a vault account",
			setup: setup,
			msg: types.MsgDepositInterestFundsRequest{
				Authority:    admin.String(),
				VaultAddress: markertypes.MustGetMarkerAddress(shares).String(),
				Amount:       amount,
			},
			expectedErrSubstrs: []string{"failed to get vault", "is not a vault account"},
		},
		{
			name:  "unauthorized authority",
			setup: setupWithAdminFunds,
			msg: types.MsgDepositInterestFundsRequest{
				Authority:    other.String(),
				VaultAddress: vaultAddr.String(),
				Amount:       amount,
			},
			expectedErrSubstrs: []string{"unauthorized authority"},
		},
		{
			name:  "incorrect underlying asset",
			setup: setup,
			msg: types.MsgDepositInterestFundsRequest{
				Authority:    admin.String(),
				VaultAddress: vaultAddr.String(),
				Amount:       sdk.NewInt64Coin(unsupportedDenom, 9_999_999),
			},
			expectedErrSubstrs: []string{"denom not supported for vault", "under", unsupportedDenom},
		},
		{
			name:  "insufficient admin balance",
			setup: setup,
			msg: types.MsgDepositInterestFundsRequest{
				Authority:    admin.String(),
				VaultAddress: vaultAddr.String(),
				Amount:       sdk.NewInt64Coin(underlying, 9_999_999),
			},
			expectedErrSubstrs: []string{"failed to deposit funds", "insufficient funds"},
		},
		{
			name: "authority frozen on the underlying deny list",
			setup: func() {
				setupWithAdminFunds()
				s.requireSendDeny(underlying, admin)
			},
			msg: types.MsgDepositInterestFundsRequest{
				Authority:    admin.String(),
				VaultAddress: vaultAddr.String(),
				Amount:       amount,
			},
			expectedErrSubstrs: []string{"failed to deposit interest funds", "is on deny list for sending restricted marker"},
		},
		{
			name: "reconcile failure propagates",
			setup: func() {
				setupWithAdminFunds()
				v, err := s.k.GetVault(s.ctx, vaultAddr)
				s.Require().NoError(err, "failed to get vault for manual reconciliation setup")
				s.Require().NotNil(v, "vault should exist for manual reconciliation setup")
				v.CurrentInterestRate = "invalid"
				v.PeriodStart = s.ctx.BlockTime().Unix() - 3600
				s.simApp.AccountKeeper.SetAccount(s.ctx, v)
			},
			msg: types.MsgDepositInterestFundsRequest{
				Authority:    admin.String(),
				VaultAddress: vaultAddr.String(),
				Amount:       sdk.NewInt64Coin(underlying, 1),
			},
			expectedErrSubstrs: []string{"failed to reconcile vault after deposit", "failed to calculate interest"},
		},
	}

	for _, tc := range tests {
		s.Run(tc.name, func() {
			runMsgServerTestCase(s, testDef, tc)
		})
	}
}

func (s *TestSuite) TestMsgServer_WithdrawInterestFunds() {
	type postCheckArgs struct {
		AuthorityAddress     sdk.AccAddress
		ExpectedAuthorityAmt sdk.Coin
	}

	testDef := msgServerTestDef[types.MsgWithdrawInterestFundsRequest, types.MsgWithdrawInterestFundsResponse, postCheckArgs]{
		endpointName: "WithdrawInterestFunds",
		endpoint:     keeper.NewMsgServer(s.simApp.VaultKeeper).WithdrawInterestFunds,
		postCheck: func(msg *types.MsgWithdrawInterestFundsRequest, args postCheckArgs) {
			bal := s.k.BankKeeper.GetBalance(s.ctx, args.AuthorityAddress, args.ExpectedAuthorityAmt.Denom)
			s.Assert().Equal(args.ExpectedAuthorityAmt, bal, "authority balance after withdrawal")
		},
	}

	underlying := "under"
	shares := "vaultshares"
	admin := s.adminAddr
	vaultAddr := types.GetVaultAddress(shares)
	amount := sdk.NewInt64Coin(underlying, 500)

	setup := func() {
		s.requireAddFinalizeAndActivateMarker(sdk.NewCoin(underlying, math.NewInt(1000)), admin)
		_, err := s.k.CreateVault(s.ctx, &types.MsgCreateVaultRequest{
			Admin:           admin.String(),
			ShareDenom:      shares,
			UnderlyingAsset: underlying,
		})
		s.Require().NoError(err, "failed to create vault")
		err = FundAccount(s.ctx, s.simApp, vaultAddr, sdk.NewCoins(amount))
		s.Require().NoError(err, "failed to fund vault account")
		s.ctx = s.ctx.WithEventManager(sdk.NewEventManager())
	}

	s.Run("happy path - withdraw interest funds", func() {
		expectedEvents := createSendCoinEvents(vaultAddr.String(), admin.String(), sdk.NewCoins(amount).String())
		expectedEvents = append(expectedEvents, sdk.NewEvent(
			"provlabs.vault.v1.EventInterestWithdrawal",
			sdk.NewAttribute("amount", amount.String()),
			sdk.NewAttribute("authority", admin.String()),
			sdk.NewAttribute("vault_address", vaultAddr.String()),
		))

		tc := msgServerTestCase[types.MsgWithdrawInterestFundsRequest, postCheckArgs]{
			name:  "happy path",
			setup: setup,
			msg: types.MsgWithdrawInterestFundsRequest{
				Authority:    admin.String(),
				VaultAddress: vaultAddr.String(),
				Amount:       amount,
			},
			postCheckArgs: postCheckArgs{
				AuthorityAddress:     admin,
				ExpectedAuthorityAmt: amount,
			},
			expectedEvents: expectedEvents,
		}

		testDef.expectedResponse = &types.MsgWithdrawInterestFundsResponse{}
		runMsgServerTestCase(s, testDef, tc)
	})

	s.Run("happy path - withdraw interest funds as asset manager", func() {
		assetMgr := s.CreateAndFundAccount(sdk.NewInt64Coin("stake", 1))

		setupWithAssetMgr := func() {
			setup()
			_, err := keeper.NewMsgServer(s.simApp.VaultKeeper).SetAssetManager(s.ctx, &types.MsgSetAssetManagerRequest{
				Admin:        admin.String(),
				VaultAddress: vaultAddr.String(),
				AssetManager: assetMgr.String(),
			})
			s.Require().NoError(err, "failed to set asset manager")
		}

		expectedEvents := createSendCoinEvents(vaultAddr.String(), assetMgr.String(), sdk.NewCoins(amount).String())
		expectedEvents = append(expectedEvents, sdk.NewEvent(
			"provlabs.vault.v1.EventInterestWithdrawal",
			sdk.NewAttribute("amount", amount.String()),
			sdk.NewAttribute("authority", assetMgr.String()),
			sdk.NewAttribute("vault_address", vaultAddr.String()),
		))

		tc := msgServerTestCase[types.MsgWithdrawInterestFundsRequest, postCheckArgs]{
			name:  "happy path asset manager",
			setup: setupWithAssetMgr,
			msg: types.MsgWithdrawInterestFundsRequest{
				Authority:    assetMgr.String(),
				VaultAddress: vaultAddr.String(),
				Amount:       amount,
			},
			postCheckArgs: postCheckArgs{
				AuthorityAddress:     assetMgr,
				ExpectedAuthorityAmt: amount,
			},
			expectedEvents: expectedEvents,
		}

		testDef.expectedResponse = &types.MsgWithdrawInterestFundsResponse{}
		runMsgServerTestCase(s, testDef, tc)
	})

	s.Run("happy path - withdraw interest funds with receipt token (admin)", func() {
		receipt := "receiptunder"
		receiptSupply := math.NewInt(1000)
		withdrawAmt := sdk.NewInt64Coin(receipt, 500)
		receiptVaultAddr := types.GetVaultAddress(shares)

		setupReceiptAdmin := func() {
			s.requireAddFinalizeAndActivateReceiptMarker(sdk.NewCoin(receipt, receiptSupply), admin, receiptVaultAddr)
			_, err := s.k.CreateVault(s.ctx, &types.MsgCreateVaultRequest{
				Admin:           admin.String(),
				ShareDenom:      shares,
				UnderlyingAsset: receipt,
			})
			s.Require().NoError(err, "failed to create vault with receipt underlying")
			err = FundAccount(markertypes.WithBypass(s.ctx), s.simApp, receiptVaultAddr, sdk.NewCoins(withdrawAmt))
			s.Require().NoError(err, "failed to fund vault account with receipt token")
			s.ctx = s.ctx.WithEventManager(sdk.NewEventManager())
		}

		expecteEvents := createSendCoinEvents(receiptVaultAddr.String(), admin.String(), sdk.NewCoins(withdrawAmt).String())
		expecteEvents = append(expecteEvents, sdk.NewEvent(
			"provlabs.vault.v1.EventInterestWithdrawal",
			sdk.NewAttribute("amount", withdrawAmt.String()),
			sdk.NewAttribute("authority", admin.String()),
			sdk.NewAttribute("vault_address", receiptVaultAddr.String()),
		))

		tc := msgServerTestCase[types.MsgWithdrawInterestFundsRequest, postCheckArgs]{
			name:  "receipt token admin",
			setup: setupReceiptAdmin,
			msg: types.MsgWithdrawInterestFundsRequest{
				Authority:    admin.String(),
				VaultAddress: receiptVaultAddr.String(),
				Amount:       withdrawAmt,
			},
			postCheckArgs: postCheckArgs{
				AuthorityAddress:     admin,
				ExpectedAuthorityAmt: withdrawAmt,
			},
			expectedEvents: expecteEvents,
		}

		testDef.expectedResponse = &types.MsgWithdrawInterestFundsResponse{}
		runMsgServerTestCase(s, testDef, tc)
	})

	s.Run("happy path - withdraw interest funds with receipt token (asset manager)", func() {
		receipt := "receiptunder2"
		receiptSupply := math.NewInt(1000)
		withdrawAmt := sdk.NewInt64Coin(receipt, 500)
		assetMgr := s.CreateAndFundAccount(sdk.NewInt64Coin("stake", 1))
		receiptVaultAddr := types.GetVaultAddress(shares)

		setupReceiptAssetMgr := func() {
			s.requireAddFinalizeAndActivateReceiptMarker(sdk.NewCoin(receipt, receiptSupply), assetMgr, receiptVaultAddr)
			_, err := s.k.CreateVault(s.ctx, &types.MsgCreateVaultRequest{
				Admin:           admin.String(),
				ShareDenom:      shares,
				UnderlyingAsset: receipt,
			})
			s.Require().NoError(err, "failed to create vault with receipt underlying")
			err = FundAccount(markertypes.WithBypass(s.ctx), s.simApp, receiptVaultAddr, sdk.NewCoins(withdrawAmt))
			s.Require().NoError(err, "failed to fund vault account with receipt token")
			s.ctx = s.ctx.WithEventManager(sdk.NewEventManager())
			_, err = keeper.NewMsgServer(s.simApp.VaultKeeper).SetAssetManager(s.ctx, &types.MsgSetAssetManagerRequest{
				Admin:        admin.String(),
				VaultAddress: receiptVaultAddr.String(),
				AssetManager: assetMgr.String(),
			})
			s.Require().NoError(err, "failed to set asset manager for receipt case")
		}

		expectedEvent := createSendCoinEvents(receiptVaultAddr.String(), assetMgr.String(), sdk.NewCoins(withdrawAmt).String())
		expectedEvent = append(expectedEvent, sdk.NewEvent(
			"provlabs.vault.v1.EventInterestWithdrawal",
			sdk.NewAttribute("amount", withdrawAmt.String()),
			sdk.NewAttribute("authority", assetMgr.String()),
			sdk.NewAttribute("vault_address", receiptVaultAddr.String()),
		))

		tc := msgServerTestCase[types.MsgWithdrawInterestFundsRequest, postCheckArgs]{
			name:  "receipt token asset manager",
			setup: setupReceiptAssetMgr,
			msg: types.MsgWithdrawInterestFundsRequest{
				Authority:    assetMgr.String(),
				VaultAddress: receiptVaultAddr.String(),
				Amount:       withdrawAmt,
			},
			postCheckArgs: postCheckArgs{
				AuthorityAddress:     assetMgr,
				ExpectedAuthorityAmt: withdrawAmt,
			},
			expectedEvents: expectedEvent,
		}

		testDef.expectedResponse = &types.MsgWithdrawInterestFundsResponse{}
		runMsgServerTestCase(s, testDef, tc)
	})
}

func (s *TestSuite) TestMsgServer_WithdrawInterestFunds_Failures() {
	testDef := msgServerTestDef[types.MsgWithdrawInterestFundsRequest, types.MsgWithdrawInterestFundsResponse, any]{
		endpointName: "WithdrawInterestFunds",
		endpoint:     keeper.NewMsgServer(s.simApp.VaultKeeper).WithdrawInterestFunds,
		postCheck:    nil,
	}

	underlying := "under"
	receiptUnderlying := "receiptunder"
	shares := "vaultshares"
	unsupportedDenom := "unsupportedDenom"
	admin := s.adminAddr
	other := s.CreateAndFundAccount(sdk.NewInt64Coin("stake", 1000))
	vaultAddr := types.GetVaultAddress(shares)
	markerAddr := markertypes.MustGetMarkerAddress(shares)
	amountRegular := sdk.NewInt64Coin(underlying, 500)
	amountReceipt := sdk.NewInt64Coin(receiptUnderlying, 500)

	setupRegular := func() {
		s.requireAddFinalizeAndActivateMarker(sdk.NewCoin(underlying, math.NewInt(1000)), admin)
		_, err := s.k.CreateVault(s.ctx, &types.MsgCreateVaultRequest{
			Admin:           admin.String(),
			ShareDenom:      shares,
			UnderlyingAsset: underlying,
		})
		s.Require().NoError(err, "failed to create vault")
		s.ctx = s.ctx.WithEventManager(sdk.NewEventManager())
	}

	setupRegularWithVaultFunds := func() {
		setupRegular()
		err := FundAccount(s.ctx, s.simApp, vaultAddr, sdk.NewCoins(amountRegular))
		s.Require().NoError(err, "failed to fund vault account")
	}

	setupReceipt := func() {
		s.requireAddFinalizeAndActivateReceiptMarker(sdk.NewCoin(receiptUnderlying, math.NewInt(1000)), admin, types.GetVaultAddress(shares))
		_, err := s.k.CreateVault(s.ctx, &types.MsgCreateVaultRequest{
			Admin:           admin.String(),
			ShareDenom:      shares,
			UnderlyingAsset: receiptUnderlying,
		})
		s.Require().NoError(err, "failed to create receipt-underlying vault")
		s.ctx = s.ctx.WithEventManager(sdk.NewEventManager())
	}

	setupReceiptWithVaultFunds := func() {
		setupReceipt()
		err := FundAccount(markertypes.WithBypass(s.ctx), s.simApp, vaultAddr, sdk.NewCoins(amountReceipt))
		s.Require().NoError(err, "failed to fund receipt-underlying vault account")
	}

	setupSendFailsNoTransferPerm := func() {
		thirdParty := s.CreateAndFundAccount(sdk.NewInt64Coin("stake", 1))
		s.requireAddFinalizeAndActivateReceiptMarker(sdk.NewCoin(receiptUnderlying, math.NewInt(2000)), thirdParty, markertypes.MustGetMarkerAddress(shares))
		_, err := s.k.CreateVault(s.ctx, &types.MsgCreateVaultRequest{
			Admin:           admin.String(),
			ShareDenom:      shares,
			UnderlyingAsset: receiptUnderlying,
		})
		s.Require().NoError(err, "failed to create vault for send-fails case")
		err = FundAccount(markertypes.WithBypass(s.ctx), s.simApp, vaultAddr, sdk.NewCoins(amountReceipt))
		s.Require().NoError(err, "failed to fund receipt-underlying vault account for send-fails case")
		s.ctx = s.ctx.WithEventManager(sdk.NewEventManager())
	}

	tests := []msgServerTestCase[types.MsgWithdrawInterestFundsRequest, any]{
		{
			name: "vault does not exist",
			msg: types.MsgWithdrawInterestFundsRequest{
				Authority:    admin.String(),
				VaultAddress: types.GetVaultAddress("doesnotexist").String(),
				Amount:       amountRegular,
			},
			expectedErrSubstrs: []string{"not found"},
		},
		{
			name:  "invalid vault address not a vault account",
			setup: setupRegular,
			msg: types.MsgWithdrawInterestFundsRequest{
				Authority:    admin.String(),
				VaultAddress: markerAddr.String(),
				Amount:       amountRegular,
			},
			expectedErrSubstrs: []string{"failed to get vault", "is not a vault account"},
		},
		{
			name:  "unauthorized authority",
			setup: setupRegularWithVaultFunds,
			msg: types.MsgWithdrawInterestFundsRequest{
				Authority:    other.String(),
				VaultAddress: vaultAddr.String(),
				Amount:       amountRegular,
			},
			expectedErrSubstrs: []string{"unauthorized authority"},
		},
		{
			name:  "insufficient vault balance",
			setup: setupRegular,
			msg: types.MsgWithdrawInterestFundsRequest{
				Authority:    admin.String(),
				VaultAddress: vaultAddr.String(),
				Amount:       sdk.NewInt64Coin(underlying, 9_999_999),
			},
			expectedErrSubstrs: []string{"failed to withdraw interest funds", "insufficient funds"},
		},
		{
			name:  "incorrect underlying asset",
			setup: setupRegular,
			msg: types.MsgWithdrawInterestFundsRequest{
				Authority:    admin.String(),
				VaultAddress: vaultAddr.String(),
				Amount:       sdk.NewInt64Coin(unsupportedDenom, 9_999_999),
			},
			expectedErrSubstrs: []string{"denom not supported for vault", underlying, unsupportedDenom},
		},
		{
			name: "reconcile failure propagates",
			setup: func() {
				setupRegularWithVaultFunds()
				v, err := s.k.GetVault(s.ctx, vaultAddr)
				s.Require().NoError(err, "failed to get vault")
				s.Require().NotNil(v, "vault should not be nil")
				v.CurrentInterestRate = "invalid"
				v.PeriodStart = s.ctx.BlockTime().Unix() - 3600
				s.simApp.AccountKeeper.SetAccount(s.ctx, v)
			},
			msg: types.MsgWithdrawInterestFundsRequest{
				Authority:    admin.String(),
				VaultAddress: vaultAddr.String(),
				Amount:       sdk.NewInt64Coin(underlying, 1),
			},
			expectedErrSubstrs: []string{"failed to reconcile vault before withdrawal", "failed to calculate interest"},
		},
		{
			name:  "receipt underlying: unauthorized authority",
			setup: setupReceiptWithVaultFunds,
			msg: types.MsgWithdrawInterestFundsRequest{
				Authority:    other.String(),
				VaultAddress: vaultAddr.String(),
				Amount:       amountReceipt,
			},
			expectedErrSubstrs: []string{"unauthorized authority"},
		},
		{
			name:  "receipt underlying: insufficient vault balance",
			setup: setupReceipt,
			msg: types.MsgWithdrawInterestFundsRequest{
				Authority:    admin.String(),
				VaultAddress: vaultAddr.String(),
				Amount:       sdk.NewInt64Coin(receiptUnderlying, 9_999_999),
			},
			expectedErrSubstrs: []string{"failed to withdraw interest funds", "insufficient funds"},
		},
		{
			name:  "receipt underlying: incorrect underlying asset",
			setup: setupReceipt,
			msg: types.MsgWithdrawInterestFundsRequest{
				Authority:    admin.String(),
				VaultAddress: vaultAddr.String(),
				Amount:       sdk.NewInt64Coin(unsupportedDenom, 9_999_999),
			},
			expectedErrSubstrs: []string{"denom not supported for vault", receiptUnderlying, unsupportedDenom},
		},
		{
			name:  "receipt underlying: send fails without transfer permission on receipt token",
			setup: setupSendFailsNoTransferPerm,
			msg: types.MsgWithdrawInterestFundsRequest{
				Authority:    admin.String(),
				VaultAddress: vaultAddr.String(),
				Amount:       amountReceipt,
			},
			expectedErrSubstrs: []string{"failed to withdraw interest funds", "does not have transfer permissions for", receiptUnderlying},
		},
	}

	for _, tc := range tests {
		s.Run(tc.name, func() {
			runMsgServerTestCase(s, testDef, tc)
		})
	}
}

func (s *TestSuite) TestMsgServer_DepositPrincipalFunds() {
	type postCheckArgs struct {
		VaultAddress        sdk.AccAddress
		MarkerAddress       sdk.AccAddress
		ExpectedVaultAssets sdk.Coin
	}

	testDef := msgServerTestDef[types.MsgDepositPrincipalFundsRequest, types.MsgDepositPrincipalFundsResponse, postCheckArgs]{
		endpointName: "DepositPrincipalFunds",
		endpoint:     keeper.NewMsgServer(s.simApp.VaultKeeper).DepositPrincipalFunds,
		postCheck: func(msg *types.MsgDepositPrincipalFundsRequest, args postCheckArgs) {
			balance := s.k.BankKeeper.GetBalance(s.ctx, args.MarkerAddress, args.ExpectedVaultAssets.Denom)
			s.Assert().Equal(args.ExpectedVaultAssets, balance, "marker balance mismatch after principal deposit")
		},
	}

	underlying := "under"
	share := "vaultshares"
	admin := s.adminAddr
	vaultAddr := types.GetVaultAddress(share)
	markerAddr := markertypes.MustGetMarkerAddress(share)
	amount := sdk.NewInt64Coin(underlying, 500)

	setup := func() {
		s.requireAddFinalizeAndActivateMarker(sdk.NewCoin(underlying, math.NewInt(1000)), admin)
		_, err := s.k.CreateVault(s.ctx, &types.MsgCreateVaultRequest{
			Admin:           admin.String(),
			ShareDenom:      share,
			UnderlyingAsset: underlying,
		})
		s.Require().NoError(err, "failed to create vault for share denom %s", share)
		s.Require().NoError(FundAccount(s.ctx, s.simApp, admin, sdk.NewCoins(amount)), "failed to fund admin account during setup")
		s.ctx = s.ctx.WithEventManager(sdk.NewEventManager())
		vault, err := s.k.GetVault(s.ctx, vaultAddr)
		s.Require().NoError(err, "failed to get vault %s", vaultAddr)
		vault.Paused = true
		s.k.AuthKeeper.SetAccount(s.ctx, vault)
	}

	s.Run("happy path - deposit principal funds", func() {
		ev := createSendCoinEvents(admin.String(), markerAddr.String(), sdk.NewCoins(amount).String())
		ev = append(ev, sdk.NewEvent(
			"provlabs.vault.v1.EventDepositPrincipalFunds",
			sdk.NewAttribute("amount", amount.String()),
			sdk.NewAttribute("authority", admin.String()),
			sdk.NewAttribute("vault_address", vaultAddr.String()),
		))

		tc := msgServerTestCase[types.MsgDepositPrincipalFundsRequest, postCheckArgs]{
			name:  "happy path",
			setup: setup,
			msg: types.MsgDepositPrincipalFundsRequest{
				Authority:    admin.String(),
				VaultAddress: vaultAddr.String(),
				Amount:       amount,
			},
			postCheckArgs: postCheckArgs{
				VaultAddress:        vaultAddr,
				MarkerAddress:       markerAddr,
				ExpectedVaultAssets: amount,
			},
			expectedEvents: ev,
		}

		testDef.expectedResponse = &types.MsgDepositPrincipalFundsResponse{}
		runMsgServerTestCase(s, testDef, tc)
	})

	s.Run("happy path - deposit principal funds as asset manager", func() {
		assetMgr := s.CreateAndFundAccount(sdk.NewInt64Coin(underlying, amount.Amount.Int64()))

		setupWithAssetMgr := func() {
			// base setup with marker/vault, but fund the asset manager for the deposit flow
			s.requireAddFinalizeAndActivateMarker(sdk.NewCoin(underlying, math.NewInt(1000)), admin)
			_, err := s.k.CreateVault(s.ctx, &types.MsgCreateVaultRequest{
				Admin:           admin.String(),
				ShareDenom:      share,
				UnderlyingAsset: underlying,
			})
			s.Require().NoError(err, "failed to create vault during asset manager setup")

			s.Require().NoError(FundAccount(s.ctx, s.simApp, assetMgr, sdk.NewCoins(amount)), "failed to fund asset manager during setup")

			s.ctx = s.ctx.WithEventManager(sdk.NewEventManager())
			vault, err := s.k.GetVault(s.ctx, vaultAddr)
			s.Require().NoError(err, "failed to get vault during asset manager setup")
			vault.Paused = true
			s.k.AuthKeeper.SetAccount(s.ctx, vault)

			_, err = keeper.NewMsgServer(s.simApp.VaultKeeper).SetAssetManager(s.ctx, &types.MsgSetAssetManagerRequest{
				Admin:        admin.String(),
				VaultAddress: vaultAddr.String(),
				AssetManager: assetMgr.String(),
			})
			s.Require().NoError(err, "failed to set asset manager")
		}

		ev := createSendCoinEvents(assetMgr.String(), markerAddr.String(), sdk.NewCoins(amount).String())
		ev = append(ev, sdk.NewEvent(
			"provlabs.vault.v1.EventDepositPrincipalFunds",
			sdk.NewAttribute("amount", amount.String()),
			sdk.NewAttribute("authority", assetMgr.String()),
			sdk.NewAttribute("vault_address", vaultAddr.String()),
		))

		tc := msgServerTestCase[types.MsgDepositPrincipalFundsRequest, postCheckArgs]{
			name:  "happy path asset manager",
			setup: setupWithAssetMgr,
			msg: types.MsgDepositPrincipalFundsRequest{
				Authority:    assetMgr.String(),
				VaultAddress: vaultAddr.String(),
				Amount:       amount,
			},
			postCheckArgs: postCheckArgs{
				VaultAddress:        vaultAddr,
				MarkerAddress:       markerAddr,
				ExpectedVaultAssets: amount,
			},
			expectedEvents: ev,
		}

		testDef.expectedResponse = &types.MsgDepositPrincipalFundsResponse{}
		runMsgServerTestCase(s, testDef, tc)
	})
}

func (s *TestSuite) TestMsgServer_DepositPrincipalFunds_Failures() {
	testDef := msgServerTestDef[types.MsgDepositPrincipalFundsRequest, types.MsgDepositPrincipalFundsResponse, any]{
		endpointName: "DepositPrincipalFunds",
		endpoint:     keeper.NewMsgServer(s.simApp.VaultKeeper).DepositPrincipalFunds,
		postCheck:    nil,
	}

	underlying := "under"
	share := "vaultshares"
	admin := s.adminAddr
	other := s.CreateAndFundAccount(sdk.NewInt64Coin("stake", 1000))
	vaultAddr := types.GetVaultAddress(share)
	amount := sdk.NewInt64Coin(underlying, 500)

	setup := func() {
		s.requireAddFinalizeAndActivateMarker(sdk.NewCoin(underlying, math.NewInt(1000)), admin)
		_, err := s.k.CreateVault(s.ctx, &types.MsgCreateVaultRequest{
			Admin:           admin.String(),
			ShareDenom:      share,
			UnderlyingAsset: underlying,
		})
		s.Require().NoError(err, "failed to create vault for share denom %s", share)
		s.ctx = s.ctx.WithEventManager(sdk.NewEventManager())
		vault, err := s.k.GetVault(s.ctx, vaultAddr)
		s.Require().NoError(err, "failed to get vault %s", vaultAddr)
		vault.Paused = true
		s.k.AuthKeeper.SetAccount(s.ctx, vault)
	}

	setupNotPaused := func() {
		setup()
		vault, err := s.k.GetVault(s.ctx, vaultAddr)
		s.Require().NoError(err, "failed to get vault %s", vaultAddr)
		vault.Paused = false
		s.k.AuthKeeper.SetAccount(s.ctx, vault)
	}

	tests := []msgServerTestCase[types.MsgDepositPrincipalFundsRequest, any]{
		{
			name: "vault does not exist",
			msg: types.MsgDepositPrincipalFundsRequest{
				Authority:    admin.String(),
				VaultAddress: types.GetVaultAddress("doesnotexist").String(),
				Amount:       amount,
			},
			expectedErrSubstrs: []string{"not found"},
		},
		{
			name:  "invalid vault address not a vault account",
			setup: setup,
			msg: types.MsgDepositPrincipalFundsRequest{
				Authority:    admin.String(),
				VaultAddress: markertypes.MustGetMarkerAddress(share).String(),
				Amount:       amount,
			},
			expectedErrSubstrs: []string{"failed to get vault", "is not a vault account"},
		},
		{
			name:  "unauthorized admin",
			setup: setup,
			msg: types.MsgDepositPrincipalFundsRequest{
				Authority:    other.String(),
				VaultAddress: vaultAddr.String(),
				Amount:       amount,
			},
			expectedErrSubstrs: []string{"unauthorized authority"},
		},
		{
			name:  "vault is not paused",
			setup: setupNotPaused,
			msg: types.MsgDepositPrincipalFundsRequest{
				Authority:    admin.String(),
				VaultAddress: vaultAddr.String(),
				Amount:       amount,
			},
			expectedErrSubstrs: []string{"vault must be paused to deposit principal funds"},
		},
		{
			name:  "invalid asset for vault",
			setup: setup,
			msg: types.MsgDepositPrincipalFundsRequest{
				Authority:    admin.String(),
				VaultAddress: vaultAddr.String(),
				Amount:       sdk.NewInt64Coin("wrongdenom", 500),
			},
			expectedErrSubstrs: []string{"denom not supported for vault", "under", "wrongdenom"},
		},
		{
			name:  "insufficient admin balance",
			setup: setup,
			msg: types.MsgDepositPrincipalFundsRequest{
				Authority:    admin.String(),
				VaultAddress: vaultAddr.String(),
				Amount:       sdk.NewInt64Coin(underlying, 9_999_999),
			},
			expectedErrSubstrs: []string{"failed to deposit principal funds", "insufficient funds"},
		},
		{
			name: "authority frozen on the underlying deny list",
			setup: func() {
				setup()
				s.Require().NoError(FundAccount(s.ctx, s.simApp, admin, sdk.NewCoins(amount)), "failed to fund admin account")
				s.requireSendDeny(underlying, admin)
			},
			msg: types.MsgDepositPrincipalFundsRequest{
				Authority:    admin.String(),
				VaultAddress: vaultAddr.String(),
				Amount:       amount,
			},
			expectedErrSubstrs: []string{"failed to deposit principal funds", "is on deny list for sending restricted marker"},
		},
	}

	for _, tc := range tests {
		s.Run(tc.name, func() {
			runMsgServerTestCase(s, testDef, tc)
		})
	}
}

func (s *TestSuite) TestMsgServer_WithdrawPrincipalFunds() {
	type postCheckArgs struct {
		AdminAddress        sdk.AccAddress
		MarkerAddress       sdk.AccAddress
		ExpectedAdminAssets sdk.Coin
	}

	testDef := msgServerTestDef[types.MsgWithdrawPrincipalFundsRequest, types.MsgWithdrawPrincipalFundsResponse, postCheckArgs]{
		endpointName: "WithdrawPrincipalFunds",
		endpoint:     keeper.NewMsgServer(s.simApp.VaultKeeper).WithdrawPrincipalFunds,
		postCheck: func(msg *types.MsgWithdrawPrincipalFundsRequest, args postCheckArgs) {
			balance := s.k.BankKeeper.GetBalance(s.ctx, args.AdminAddress, args.ExpectedAdminAssets.Denom)
			s.Assert().Equal(args.ExpectedAdminAssets, balance, "admin balance after principal withdrawal")
		},
	}

	underlying := "under"
	share := "vaultshares"
	admin := s.adminAddr
	vaultAddr := types.GetVaultAddress(share)
	markerAddr := markertypes.MustGetMarkerAddress(share)
	amount := sdk.NewInt64Coin(underlying, 500)

	setup := func() {
		s.requireAddFinalizeAndActivateMarker(sdk.NewCoin(underlying, math.NewInt(1000)), admin)
		_, err := s.k.CreateVault(s.ctx, &types.MsgCreateVaultRequest{
			Admin:           admin.String(),
			ShareDenom:      share,
			UnderlyingAsset: underlying,
		})
		s.Require().NoError(err, "failed to create vault")
		err = FundAccount(s.ctx, s.simApp, markerAddr, sdk.NewCoins(amount))
		s.Require().NoError(err, "failed to fund marker account")
		s.ctx = s.ctx.WithEventManager(sdk.NewEventManager())
		vault, err := s.k.GetVault(s.ctx, vaultAddr)
		s.Require().NoError(err, "failed to get vault")
		vault.Paused = true
		s.k.AuthKeeper.SetAccount(s.ctx, vault)
	}

	s.Run("happy path - withdraw principal funds", func() {
		ev := createSendCoinEvents(markerAddr.String(), admin.String(), sdk.NewCoins(amount).String())
		ev = append(ev, sdk.NewEvent(
			"provlabs.vault.v1.EventWithdrawPrincipalFunds",
			sdk.NewAttribute("amount", amount.String()),
			sdk.NewAttribute("authority", admin.String()),
			sdk.NewAttribute("vault_address", vaultAddr.String()),
		))

		tc := msgServerTestCase[types.MsgWithdrawPrincipalFundsRequest, postCheckArgs]{
			name:  "happy path",
			setup: setup,
			msg: types.MsgWithdrawPrincipalFundsRequest{
				Authority:    admin.String(),
				VaultAddress: vaultAddr.String(),
				Amount:       amount,
			},
			postCheckArgs: postCheckArgs{
				AdminAddress:        admin,
				MarkerAddress:       markerAddr,
				ExpectedAdminAssets: amount,
			},
			expectedEvents: ev,
		}

		testDef.expectedResponse = &types.MsgWithdrawPrincipalFundsResponse{}
		runMsgServerTestCase(s, testDef, tc)
	})

	s.Run("happy path - withdraw principal funds as asset manager", func() {
		assetMgr := s.CreateAndFundAccount(sdk.Coin{Denom: underlying, Amount: math.ZeroInt()})

		setupWithAssetMgr := func() {
			s.requireAddFinalizeAndActivateMarker(sdk.NewCoin(underlying, math.NewInt(1000)), admin)
			_, err := s.k.CreateVault(s.ctx, &types.MsgCreateVaultRequest{
				Admin:           admin.String(),
				ShareDenom:      share,
				UnderlyingAsset: underlying,
			})
			s.Require().NoError(err, "failed to create vault")
			err = FundAccount(s.ctx, s.simApp, markerAddr, sdk.NewCoins(amount))
			s.Require().NoError(err, "failed to fund marker account")
			s.ctx = s.ctx.WithEventManager(sdk.NewEventManager())
			vault, err := s.k.GetVault(s.ctx, vaultAddr)
			s.Require().NoError(err, "failed to get vault")
			vault.Paused = true
			s.k.AuthKeeper.SetAccount(s.ctx, vault)
			_, err = keeper.NewMsgServer(s.simApp.VaultKeeper).SetAssetManager(s.ctx, &types.MsgSetAssetManagerRequest{
				Admin:        admin.String(),
				VaultAddress: vaultAddr.String(),
				AssetManager: assetMgr.String(),
			})
			s.Require().NoError(err, "failed to set asset manager")
		}

		ev := createSendCoinEvents(markerAddr.String(), assetMgr.String(), sdk.NewCoins(amount).String())
		ev = append(ev, sdk.NewEvent(
			"provlabs.vault.v1.EventWithdrawPrincipalFunds",
			sdk.NewAttribute("amount", amount.String()),
			sdk.NewAttribute("authority", assetMgr.String()),
			sdk.NewAttribute("vault_address", vaultAddr.String()),
		))

		tc := msgServerTestCase[types.MsgWithdrawPrincipalFundsRequest, postCheckArgs]{
			name:  "happy path asset manager",
			setup: setupWithAssetMgr,
			msg: types.MsgWithdrawPrincipalFundsRequest{
				Authority:    assetMgr.String(),
				VaultAddress: vaultAddr.String(),
				Amount:       amount,
			},
			postCheckArgs: postCheckArgs{
				AdminAddress:        assetMgr,
				MarkerAddress:       markerAddr,
				ExpectedAdminAssets: amount,
			},
			expectedEvents: ev,
		}

		testDef.expectedResponse = &types.MsgWithdrawPrincipalFundsResponse{}
		runMsgServerTestCase(s, testDef, tc)
	})

	s.Run("happy path - withdraw principal funds with receipt token (admin)", func() {
		receipt := "receiptunder"
		receiptSupply := math.NewInt(1000)
		withdrawAmt := sdk.NewInt64Coin(receipt, 500)
		receiptVaultAddr := types.GetVaultAddress(share)
		receiptMarkerAddr := markertypes.MustGetMarkerAddress(share)

		setupReceiptAdmin := func() {
			s.requireAddFinalizeAndActivateReceiptMarker(sdk.NewCoin(receipt, receiptSupply), admin, receiptVaultAddr)
			_, err := s.k.CreateVault(s.ctx, &types.MsgCreateVaultRequest{
				Admin:           admin.String(),
				ShareDenom:      share,
				UnderlyingAsset: receipt,
			})
			s.Require().NoError(err, "failed to create vault with receipt underlying")
			err = FundAccount(markertypes.WithBypass(s.ctx), s.simApp, receiptMarkerAddr, sdk.NewCoins(withdrawAmt))
			s.Require().NoError(err, "failed to fund receipt marker account")
			s.ctx = s.ctx.WithEventManager(sdk.NewEventManager())
			vault, err := s.k.GetVault(s.ctx, receiptVaultAddr)
			s.Require().NoError(err, "failed to get vault")
			vault.Paused = true
			s.k.AuthKeeper.SetAccount(s.ctx, vault)
		}

		ev := createSendCoinEvents(receiptMarkerAddr.String(), admin.String(), sdk.NewCoins(withdrawAmt).String())
		ev = append(ev, sdk.NewEvent(
			"provlabs.vault.v1.EventWithdrawPrincipalFunds",
			sdk.NewAttribute("amount", withdrawAmt.String()),
			sdk.NewAttribute("authority", admin.String()),
			sdk.NewAttribute("vault_address", receiptVaultAddr.String()),
		))

		tc := msgServerTestCase[types.MsgWithdrawPrincipalFundsRequest, postCheckArgs]{
			name:  "receipt token admin",
			setup: setupReceiptAdmin,
			msg: types.MsgWithdrawPrincipalFundsRequest{
				Authority:    admin.String(),
				VaultAddress: receiptVaultAddr.String(),
				Amount:       withdrawAmt,
			},
			postCheckArgs: postCheckArgs{
				AdminAddress:        admin,
				MarkerAddress:       receiptMarkerAddr,
				ExpectedAdminAssets: withdrawAmt,
			},
			expectedEvents: ev,
		}

		testDef.expectedResponse = &types.MsgWithdrawPrincipalFundsResponse{}
		runMsgServerTestCase(s, testDef, tc)
	})

	s.Run("happy path - withdraw principal funds with receipt token (asset manager)", func() {
		receiptDenom := "receiptunder2"
		receiptSupply := math.NewInt(1000)
		withdrawAmt := sdk.NewInt64Coin(receiptDenom, 500)
		assetMgr := s.CreateAndFundAccount(sdk.Coin{Denom: receiptDenom, Amount: math.ZeroInt()})
		receiptVaultAddr := types.GetVaultAddress(share)
		receiptMarkerAddr := markertypes.MustGetMarkerAddress(share)

		setupReceiptAssetMgr := func() {
			s.requireAddFinalizeAndActivateReceiptMarker(sdk.NewCoin(receiptDenom, receiptSupply), assetMgr, receiptVaultAddr)
			_, err := s.k.CreateVault(s.ctx, &types.MsgCreateVaultRequest{
				Admin:           admin.String(),
				ShareDenom:      share,
				UnderlyingAsset: receiptDenom,
			})
			s.Require().NoError(err, "failed to create vault with receipt underlying")
			err = FundAccount(markertypes.WithBypass(s.ctx), s.simApp, receiptMarkerAddr, sdk.NewCoins(withdrawAmt))
			s.Require().NoError(err, "failed to fund receipt marker account")
			s.ctx = s.ctx.WithEventManager(sdk.NewEventManager())
			vault, err := s.k.GetVault(s.ctx, receiptVaultAddr)
			s.Require().NoError(err, "failed to get vault")
			vault.Paused = true
			s.k.AuthKeeper.SetAccount(s.ctx, vault)
			_, err = keeper.NewMsgServer(s.simApp.VaultKeeper).SetAssetManager(s.ctx, &types.MsgSetAssetManagerRequest{
				Admin:        admin.String(),
				VaultAddress: receiptVaultAddr.String(),
				AssetManager: assetMgr.String(),
			})
			s.Require().NoError(err, "failed to set asset manager for receipt case")
		}

		ev := createSendCoinEvents(receiptMarkerAddr.String(), assetMgr.String(), sdk.NewCoins(withdrawAmt).String())
		ev = append(ev, sdk.NewEvent(
			"provlabs.vault.v1.EventWithdrawPrincipalFunds",
			sdk.NewAttribute("amount", withdrawAmt.String()),
			sdk.NewAttribute("authority", assetMgr.String()),
			sdk.NewAttribute("vault_address", receiptVaultAddr.String()),
		))

		tc := msgServerTestCase[types.MsgWithdrawPrincipalFundsRequest, postCheckArgs]{
			name:  "receipt token asset manager",
			setup: setupReceiptAssetMgr,
			msg: types.MsgWithdrawPrincipalFundsRequest{
				Authority:    assetMgr.String(),
				VaultAddress: receiptVaultAddr.String(),
				Amount:       withdrawAmt,
			},
			postCheckArgs: postCheckArgs{
				AdminAddress:        assetMgr,
				MarkerAddress:       receiptMarkerAddr,
				ExpectedAdminAssets: withdrawAmt,
			},
			expectedEvents: ev,
		}

		testDef.expectedResponse = &types.MsgWithdrawPrincipalFundsResponse{}
		runMsgServerTestCase(s, testDef, tc)
	})
}

func (s *TestSuite) TestMsgServer_WithdrawPrincipalFunds_Failures() {
	testDef := msgServerTestDef[types.MsgWithdrawPrincipalFundsRequest, types.MsgWithdrawPrincipalFundsResponse, any]{
		endpointName: "WithdrawPrincipalFunds",
		endpoint:     keeper.NewMsgServer(s.simApp.VaultKeeper).WithdrawPrincipalFunds,
		postCheck:    nil,
	}

	underlying := "under"
	receiptUnderlying := "receiptunder"
	share := "vaultshares"
	admin := s.adminAddr
	other := s.CreateAndFundAccount(sdk.NewInt64Coin("stake", 1000))
	vaultAddr := types.GetVaultAddress(share)
	shareMarkerAddr := markertypes.MustGetMarkerAddress(share)
	amountRegular := sdk.NewInt64Coin(underlying, 500)
	amountReceipt := sdk.NewInt64Coin(receiptUnderlying, 500)
	requireAttrs := "thisisattri.restricted"

	setupRegular := func() {
		s.requireAddFinalizeAndActivateMarker(sdk.NewCoin(underlying, math.NewInt(1000)), admin, requireAttrs)
		_, err := s.k.CreateVault(s.ctx, &types.MsgCreateVaultRequest{
			Admin:           admin.String(),
			ShareDenom:      share,
			UnderlyingAsset: underlying,
		})
		s.Require().NoError(err, "failed to create vault")
		s.ctx = s.ctx.WithEventManager(sdk.NewEventManager())
		vault, err := s.k.GetVault(s.ctx, vaultAddr)
		s.Require().NoError(err, "failed to get vault")
		vault.Paused = true
		s.k.AuthKeeper.SetAccount(s.ctx, vault)
	}

	setupRegularNotPaused := func() {
		setupRegular()
		vault, err := s.k.GetVault(s.ctx, vaultAddr)
		s.Require().NoError(err, "failed to get vault")
		vault.Paused = false
		s.k.AuthKeeper.SetAccount(s.ctx, vault)
	}

	setupRegularWithShareFunds := func() {
		setupRegular()
		err := FundAccount(markertypes.WithBypass(s.ctx), s.simApp, shareMarkerAddr, sdk.NewCoins(amountRegular))
		s.Require().NoError(err, "failed to fund share marker account")
	}

	setupReceipt := func() {
		s.requireAddFinalizeAndActivateMarker(sdk.NewCoin(receiptUnderlying, math.NewInt(1000)), admin, requireAttrs)
		_, err := s.k.CreateVault(s.ctx, &types.MsgCreateVaultRequest{
			Admin:           admin.String(),
			ShareDenom:      share,
			UnderlyingAsset: receiptUnderlying,
		})
		s.Require().NoError(err, "failed to create receipt-underlying vault")
		s.ctx = s.ctx.WithEventManager(sdk.NewEventManager())
		vault, err := s.k.GetVault(s.ctx, vaultAddr)
		s.Require().NoError(err, "failed to get vault")
		vault.Paused = true
		s.k.AuthKeeper.SetAccount(s.ctx, vault)
	}

	setupReceiptWithShareFunds := func() {
		setupReceipt()
		err := FundAccount(markertypes.WithBypass(s.ctx), s.simApp, shareMarkerAddr, sdk.NewCoins(amountReceipt))
		s.Require().NoError(err, "failed to fund share marker account with receipt token")
	}

	setupSendFailsNoTransferPerm := func() {
		thirdParty := s.CreateAndFundAccount(sdk.NewInt64Coin("stake", 1))
		// The receipt token is created and managed by thirdParty. admin has NO permissions on it.
		s.requireAddFinalizeAndActivateMarker(sdk.NewCoin(receiptUnderlying, math.NewInt(2000)), thirdParty, requireAttrs)

		_, err := s.k.CreateVault(s.ctx, &types.MsgCreateVaultRequest{
			Admin:           admin.String(),
			ShareDenom:      share,
			UnderlyingAsset: receiptUnderlying,
		})
		s.Require().NoError(err, "failed to create vault for send-fails case")

		m, err := s.simApp.MarkerKeeper.GetMarkerByDenom(s.ctx, share)
		s.Require().NoError(err, "failed to get share marker to grant withdraw")
		mk := m.(*markertypes.MarkerAccount)
		// admin is granted Withdraw on the VAULT'S share marker, but still lacks permission on the receipt underlying marker.
		mk.AccessControl = append(mk.AccessControl, markertypes.AccessGrant{
			Address:     admin.String(),
			Permissions: []markertypes.Access{markertypes.Access_Withdraw},
		})
		s.simApp.MarkerKeeper.SetMarker(s.ctx, mk)

		err = FundAccount(markertypes.WithBypass(s.ctx), s.simApp, shareMarkerAddr, sdk.NewCoins(amountReceipt))
		s.Require().NoError(err, "failed to fund share marker account with receipt token for send-fails case")

		s.ctx = s.ctx.WithEventManager(sdk.NewEventManager())
		vault, err := s.k.GetVault(s.ctx, vaultAddr)
		s.Require().NoError(err, "failed to get vault")
		vault.Paused = true
		s.k.AuthKeeper.SetAccount(s.ctx, vault)
	}

	tests := []msgServerTestCase[types.MsgWithdrawPrincipalFundsRequest, any]{
		{
			name: "vault does not exist",
			msg: types.MsgWithdrawPrincipalFundsRequest{
				Authority:    admin.String(),
				VaultAddress: types.GetVaultAddress("doesnotexist").String(),
				Amount:       amountRegular,
			},
			expectedErrSubstrs: []string{"not found"},
		},
		{
			name:  "invalid vault address not a vault account",
			setup: setupRegular,
			msg: types.MsgWithdrawPrincipalFundsRequest{
				Authority:    admin.String(),
				VaultAddress: shareMarkerAddr.String(),
				Amount:       amountRegular,
			},
			expectedErrSubstrs: []string{"failed to get vault", "is not a vault account"},
		},
		{
			name:  "unauthorized authority",
			setup: setupRegularWithShareFunds,
			msg: types.MsgWithdrawPrincipalFundsRequest{
				Authority:    other.String(),
				VaultAddress: vaultAddr.String(),
				Amount:       amountRegular,
			},
			expectedErrSubstrs: []string{"unauthorized authority"},
		},
		{
			name:  "vault is not paused",
			setup: setupRegularNotPaused,
			msg: types.MsgWithdrawPrincipalFundsRequest{
				Authority:    admin.String(),
				VaultAddress: vaultAddr.String(),
				Amount:       amountRegular,
			},
			expectedErrSubstrs: []string{"vault must be paused to withdraw principal funds"},
		},
		{
			name:  "invalid asset for vault",
			setup: setupRegular,
			msg: types.MsgWithdrawPrincipalFundsRequest{
				Authority:    admin.String(),
				VaultAddress: vaultAddr.String(),
				Amount:       sdk.NewInt64Coin("wrongdenom", 500),
			},
			expectedErrSubstrs: []string{"denom not supported for vault", "under", "wrongdenom"},
		},
		{
			name:  "insufficient share marker balance",
			setup: setupRegular,
			msg: types.MsgWithdrawPrincipalFundsRequest{
				Authority:    admin.String(),
				VaultAddress: vaultAddr.String(),
				Amount:       sdk.NewInt64Coin(underlying, 9_999_999),
			},
			expectedErrSubstrs: []string{"failed to withdraw principal funds", "insufficient funds"},
		},
		{
			name:  "receipt underlying: unauthorized authority",
			setup: setupReceiptWithShareFunds,
			msg: types.MsgWithdrawPrincipalFundsRequest{
				Authority:    other.String(),
				VaultAddress: vaultAddr.String(),
				Amount:       amountReceipt,
			},
			expectedErrSubstrs: []string{"unauthorized authority"},
		},
		{
			name:  "receipt underlying: insufficient share marker balance",
			setup: setupReceipt,
			msg: types.MsgWithdrawPrincipalFundsRequest{
				Authority:    admin.String(),
				VaultAddress: vaultAddr.String(),
				Amount:       sdk.NewInt64Coin(receiptUnderlying, 9_999_999),
			},
			expectedErrSubstrs: []string{"failed to withdraw principal funds", "insufficient funds"},
		},
		{
			name:  "receipt underlying: invalid asset for vault",
			setup: setupReceipt,
			msg: types.MsgWithdrawPrincipalFundsRequest{
				Authority:    admin.String(),
				VaultAddress: vaultAddr.String(),
				Amount:       sdk.NewInt64Coin("wrongdenom", 500),
			},
			expectedErrSubstrs: []string{"denom not supported for vault", receiptUnderlying, "wrongdenom"},
		},
		{
			name:  "receipt underlying: send fails without transfer permission on receipt token",
			setup: setupSendFailsNoTransferPerm,
			msg: types.MsgWithdrawPrincipalFundsRequest{
				Authority:    admin.String(),
				VaultAddress: vaultAddr.String(),
				Amount:       amountReceipt,
			},
			expectedErrSubstrs: []string{
				"failed to withdraw principal funds",
				"does not contain the \"receiptunder\" required attribute",
				requireAttrs,
			},
		},
	}

	for _, tc := range tests {
		s.Run(tc.name, func() {
			runMsgServerTestCase(s, testDef, tc)
		})
	}
}

func (s *TestSuite) TestMsgServer_ExpeditePendingSwapOut() {
	type postCheckArgs struct {
		RequestId uint64
	}

	testDef := msgServerTestDef[types.MsgExpeditePendingSwapOutRequest, types.MsgExpeditePendingSwapOutResponse, postCheckArgs]{
		endpointName: "ExpeditePendingSwapOut",
		endpoint:     keeper.NewMsgServer(s.simApp.VaultKeeper).ExpeditePendingSwapOut,
		postCheck: func(msg *types.MsgExpeditePendingSwapOutRequest, args postCheckArgs) {
			release, withdrawal, err := s.k.PendingSwapOutQueue.GetByID(s.ctx, args.RequestId)
			s.Require().NoError(err, "should be able to get swap out request by ID")
			s.Assert().Equal(int64(0), release, "release time should be expedited to 0")
			s.Assert().NotNil(withdrawal, "swap out should not be nil after expedite")
		},
	}

	underlying := "under"
	share := "vaultshares"
	admin := s.adminAddr
	other := s.CreateAndFundAccount(sdk.NewInt64Coin("stake", 1000))
	vaultAddr := types.GetVaultAddress(share)
	blockTime := time.Now()

	var id uint64
	setup := func() {
		s.requireAddFinalizeAndActivateMarker(sdk.NewCoin(underlying, math.NewInt(1000)), admin)
		_, err := s.k.CreateVault(s.ctx, &types.MsgCreateVaultRequest{
			Admin:           admin.String(),
			ShareDenom:      share,
			UnderlyingAsset: underlying,
		})
		s.Require().NoError(err, "should create vault")

		validOwner := s.CreateAndFundAccount(sdk.NewInt64Coin("stake", 1)).String()
		validShares := sdk.NewInt64Coin(share, 1)

		var qErr error
		pendingReq := types.NewPendingSwapOut(
			sdk.MustAccAddressFromBech32(validOwner),
			vaultAddr,
			validShares,
			underlying,
		)
		id, qErr = s.k.PendingSwapOutQueue.Enqueue(s.ctx, blockTime.Unix(), &pendingReq)
		s.Require().NoError(qErr, "should successfully enqueue pending swap out request")
		s.ctx = s.ctx.WithEventManager(sdk.NewEventManager())
	}

	setupWithAssetMgr := func(assetMgr sdk.AccAddress) {
		setup()
		_, err := keeper.NewMsgServer(s.simApp.VaultKeeper).SetAssetManager(s.ctx, &types.MsgSetAssetManagerRequest{
			Admin:        admin.String(),
			VaultAddress: vaultAddr.String(),
			AssetManager: assetMgr.String(),
		})
		s.Require().NoError(err, "should set asset manager")
	}

	tests := []msgServerTestCase[types.MsgExpeditePendingSwapOutRequest, postCheckArgs]{
		{
			name:  "happy path",
			setup: setup,
			msg: types.MsgExpeditePendingSwapOutRequest{
				Authority: admin.String(),
				RequestId: id,
			},
			postCheckArgs: postCheckArgs{
				RequestId: id,
			},
			expectedEvents: sdk.Events{
				sdk.NewEvent(
					"provlabs.vault.v1.EventPendingSwapOutExpedited",
					sdk.NewAttribute("authority", admin.String()),
					sdk.NewAttribute("request_id", fmt.Sprintf("%d", id)),
					sdk.NewAttribute("vault", vaultAddr.String()),
				),
			},
		},
		{
			name:  "unauthorized authority",
			setup: setup,
			msg: types.MsgExpeditePendingSwapOutRequest{
				Authority: other.String(),
				RequestId: id,
			},
			expectedErrSubstrs: []string{"unauthorized"},
		},
		{
			name:  "request id does not exist",
			setup: setup,
			msg: types.MsgExpeditePendingSwapOutRequest{
				Authority: admin.String(),
				RequestId: 999,
			},
			expectedErrSubstrs: []string{"failed to get pending swap out"},
		},
	}

	for _, tc := range tests {
		s.Run(tc.name, func() {
			testDef.expectedResponse = &types.MsgExpeditePendingSwapOutResponse{}
			runMsgServerTestCase(s, testDef, tc)
		})
	}

	s.Run("happy path - asset manager authority", func() {
		assetMgr := s.CreateAndFundAccount(sdk.Coin{Denom: underlying, Amount: math.ZeroInt()})
		setupWithAssetMgr(assetMgr)

		ev := sdk.Events{
			sdk.NewEvent(
				"provlabs.vault.v1.EventPendingSwapOutExpedited",
				sdk.NewAttribute("authority", assetMgr.String()),
				sdk.NewAttribute("request_id", fmt.Sprintf("%d", id)),
				sdk.NewAttribute("vault", vaultAddr.String()),
			),
		}

		tc := msgServerTestCase[types.MsgExpeditePendingSwapOutRequest, postCheckArgs]{
			name: "happy path - asset manager authority",
			msg: types.MsgExpeditePendingSwapOutRequest{
				Authority: assetMgr.String(),
				RequestId: id,
			},
			postCheckArgs: postCheckArgs{
				RequestId: id,
			},
			expectedEvents: ev,
		}

		testDef.expectedResponse = &types.MsgExpeditePendingSwapOutResponse{}
		runMsgServerTestCase(s, testDef, tc)
	})
}

func (s *TestSuite) TestMsgServer_PauseVault() {
	type postCheckArgs struct {
		VaultAddress         sdk.AccAddress
		ExpectedPaused       bool
		ExpectedPauseDenom   string
		ExpectedPauseAmount  int64
		ExpectedPausedReason string
		ExpectedDesiredRate  string
		ExpectedCurrentRate  string
	}

	testDef := msgServerTestDef[types.MsgPauseVaultRequest, types.MsgPauseVaultResponse, postCheckArgs]{
		endpointName: "PauseVault",
		endpoint:     keeper.NewMsgServer(s.simApp.VaultKeeper).PauseVault,
		postCheck: func(msg *types.MsgPauseVaultRequest, args postCheckArgs) {
			v, err := s.k.GetVault(s.ctx, args.VaultAddress)
			s.Require().NoError(err, "expected to load vault %s for post-check", args.VaultAddress)
			s.Assert().Equal(args.ExpectedPaused, v.Paused, "vault paused status")
			s.Assert().Equal(args.ExpectedPauseDenom, v.PausedBalance.Denom, "vault paused balance denom")
			s.Assert().Equal(args.ExpectedPauseAmount, v.PausedBalance.Amount.Int64(), "vault paused balance amount")
			s.Assert().Equal(args.ExpectedPausedReason, v.PausedReason, "vault paused reason")
			s.Assert().Equal(args.ExpectedDesiredRate, v.DesiredInterestRate, "vault desired interest rate")
			s.Assert().Equal(args.ExpectedCurrentRate, v.CurrentInterestRate, "vault current interest rate")
		},
	}

	underlying := "under"
	share := "vaultshares"
	admin := s.adminAddr
	reason := "maintenance"
	interestRate := "0.0406"
	vaultAddr := types.GetVaultAddress(share)

	setup := func() {
		s.requireAddFinalizeAndActivateMarker(sdk.NewCoin(underlying, math.NewInt(10_000)), admin)
		_, err := s.k.CreateVault(s.ctx, &types.MsgCreateVaultRequest{
			Admin:           admin.String(),
			ShareDenom:      share,
			UnderlyingAsset: underlying,
		})
		s.Require().NoError(err, "failed to create vault for share denom %s", share)
		vault, err := s.k.GetVault(s.ctx, vaultAddr)
		s.Require().NoError(err, "failed to get vault in setup")
		s.Require().NoError(s.k.UpdateInterestRates(s.ctx, vault, interestRate, interestRate), "initial interest rate update should succeed")
		s.ctx = s.ctx.WithEventManager(sdk.NewEventManager())
	}

	setupWithAssetMgr := func(assetMgr sdk.AccAddress) {
		setup()
		_, err := keeper.NewMsgServer(s.simApp.VaultKeeper).SetAssetManager(s.ctx, &types.MsgSetAssetManagerRequest{
			Admin:        admin.String(),
			VaultAddress: vaultAddr.String(),
			AssetManager: assetMgr.String(),
		})
		s.Require().NoError(err, "failed to set asset manager in setup")
	}

	s.Run("happy path - admin pause vault", func() {
		ev := sdk.Events{
			sdk.NewEvent(
				"provlabs.vault.v1.EventVaultInterestChange",
				sdk.NewAttribute("current_rate", types.ZeroInterestRate),
				sdk.NewAttribute("desired_rate", interestRate),
				sdk.NewAttribute("vault_address", vaultAddr.String()),
			),
			sdk.NewEvent(
				"provlabs.vault.v1.EventVaultPaused",
				sdk.NewAttribute("authority", admin.String()),
				sdk.NewAttribute("forced", "false"),
				sdk.NewAttribute("forced_error", ""),
				sdk.NewAttribute("reason", reason),
				sdk.NewAttribute("total_vault_value", sdk.NewInt64Coin(underlying, 0).String()),
				sdk.NewAttribute("vault_address", vaultAddr.String()),
			),
		}

		tc := msgServerTestCase[types.MsgPauseVaultRequest, postCheckArgs]{
			name:  "happy path - admin pause",
			setup: setup,
			msg: types.MsgPauseVaultRequest{
				Authority:    admin.String(),
				VaultAddress: vaultAddr.String(),
				Reason:       reason,
			},
			postCheckArgs: postCheckArgs{
				VaultAddress:         vaultAddr,
				ExpectedPaused:       true,
				ExpectedPauseDenom:   underlying,
				ExpectedPauseAmount:  0,
				ExpectedPausedReason: reason,
				ExpectedDesiredRate:  interestRate,
				ExpectedCurrentRate:  types.ZeroInterestRate,
			},
			expectedEvents: ev,
		}

		testDef.expectedResponse = &types.MsgPauseVaultResponse{}
		runMsgServerTestCase(s, testDef, tc)
	})

	s.Run("happy path - asset manager pause vault", func() {
		assetMgr := s.CreateAndFundAccount(sdk.NewInt64Coin(underlying, 100))
		setupWithAssetMgr(assetMgr)

		ev := sdk.Events{
			sdk.NewEvent(
				"provlabs.vault.v1.EventVaultInterestChange",
				sdk.NewAttribute("current_rate", types.ZeroInterestRate),
				sdk.NewAttribute("desired_rate", interestRate),
				sdk.NewAttribute("vault_address", vaultAddr.String()),
			),
			sdk.NewEvent(
				"provlabs.vault.v1.EventVaultPaused",
				sdk.NewAttribute("authority", assetMgr.String()),
				sdk.NewAttribute("forced", "false"),
				sdk.NewAttribute("forced_error", ""),
				sdk.NewAttribute("reason", reason),
				sdk.NewAttribute("total_vault_value", sdk.NewInt64Coin(underlying, 0).String()),
				sdk.NewAttribute("vault_address", vaultAddr.String()),
			),
		}

		tc := msgServerTestCase[types.MsgPauseVaultRequest, postCheckArgs]{
			name:  "happy path - asset manager pause",
			setup: func() {},
			msg: types.MsgPauseVaultRequest{
				Authority:    assetMgr.String(),
				VaultAddress: vaultAddr.String(),
				Reason:       reason,
			},
			postCheckArgs: postCheckArgs{
				VaultAddress:         vaultAddr,
				ExpectedPaused:       true,
				ExpectedPauseDenom:   underlying,
				ExpectedPauseAmount:  0,
				ExpectedPausedReason: reason,
				ExpectedDesiredRate:  interestRate,
				ExpectedCurrentRate:  types.ZeroInterestRate,
			},
			expectedEvents: ev,
		}

		testDef.expectedResponse = &types.MsgPauseVaultResponse{}
		runMsgServerTestCase(s, testDef, tc)
	})
}

func (s *TestSuite) TestMsgServer_PauseVault_Failures() {
	testDef := msgServerTestDef[types.MsgPauseVaultRequest, types.MsgPauseVaultResponse, any]{
		endpointName: "PauseVault",
		endpoint:     keeper.NewMsgServer(s.simApp.VaultKeeper).PauseVault,
		postCheck:    nil,
	}

	underlying := "under"
	share := "vaultshares"
	admin := s.adminAddr
	other := s.CreateAndFundAccount(sdk.NewInt64Coin("stake", 1000))
	vaultAddr := types.GetVaultAddress(share)
	markerAddr := markertypes.MustGetMarkerAddress(share)

	base := func() {
		s.requireAddFinalizeAndActivateMarker(sdk.NewCoin(underlying, math.NewInt(10_000)), admin)
		_, err := s.k.CreateVault(s.ctx, &types.MsgCreateVaultRequest{
			Admin:           admin.String(),
			ShareDenom:      share,
			UnderlyingAsset: underlying,
		})
		s.Require().NoError(err, "expected base vault creation to succeed")
		s.ctx = s.ctx.WithEventManager(sdk.NewEventManager())
	}

	tests := []msgServerTestCase[types.MsgPauseVaultRequest, any]{
		{
			name: "vault not found",
			msg: types.MsgPauseVaultRequest{
				Authority:    admin.String(),
				VaultAddress: types.GetVaultAddress("nope").String(),
				Reason:       "x",
			},
			expectedErrSubstrs: []string{"not found"},
		},
		{
			name:  "invalid vault address (not a vault account)",
			setup: base,
			msg: types.MsgPauseVaultRequest{
				Authority:    admin.String(),
				VaultAddress: markerAddr.String(),
				Reason:       "x",
			},
			expectedErrSubstrs: []string{"failed to get vault", "is not a vault account"},
		},
		{
			name:  "unauthorized admin",
			setup: base,
			msg: types.MsgPauseVaultRequest{
				Authority:    other.String(),
				VaultAddress: vaultAddr.String(),
				Reason:       "x",
			},
			expectedErrSubstrs: []string{"unauthorized authority"},
		},
		{
			name: "already paused",
			setup: func() {
				base()
				_, err := keeper.NewMsgServer(s.simApp.VaultKeeper).PauseVault(s.ctx, &types.MsgPauseVaultRequest{
					Authority:    admin.String(),
					VaultAddress: vaultAddr.String(),
					Reason:       "first",
				})
				s.Require().NoError(err, "expected initial pause to succeed")
				s.ctx = s.ctx.WithEventManager(sdk.NewEventManager())
			},
			msg: types.MsgPauseVaultRequest{
				Authority:    admin.String(),
				VaultAddress: vaultAddr.String(),
				Reason:       "second",
			},
			expectedErrSubstrs: []string{"already paused"},
		},
	}

	for _, tc := range tests {
		s.Run(tc.name, func() {
			runMsgServerTestCase(s, testDef, tc)
		})
	}
}

func (s *TestSuite) TestMsgServer_PauseVault_ForceVsStrict() {
	reason := "emergency"

	insufficientReservesSetup := func() (sdk.AccAddress, string) {
		underlying := "under"
		share := "vaultshares"
		s.requireAddFinalizeAndActivateMarker(sdk.NewCoin(underlying, math.NewInt(10_000)), s.adminAddr)
		_, err := s.k.CreateVault(s.ctx, &types.MsgCreateVaultRequest{
			Admin:           s.adminAddr.String(),
			ShareDenom:      share,
			UnderlyingAsset: underlying,
		})
		s.Require().NoError(err, "vault creation should succeed for share denom %s", share)
		vaultAddr := types.GetVaultAddress(share)
		vault, err := s.k.GetVault(s.ctx, vaultAddr)
		s.Require().NoError(err, "loading the vault for setup should succeed")

		oneDay := int64(24 * time.Hour / time.Second)
		vault.CurrentInterestRate = "1.0"
		vault.DesiredInterestRate = "1.0"
		vault.PeriodStart = s.ctx.BlockTime().Unix() - oneDay
		s.k.AuthKeeper.SetAccount(s.ctx, vault)

		s.Require().NoError(FundAccount(s.ctx, s.simApp, vault.PrincipalMarkerAddress(),
			sdk.NewCoins(sdk.NewInt64Coin(underlying, 100_000))),
			"funding the principal marker should succeed so reconcile owes unpayable interest")
		s.ctx = s.ctx.WithEventManager(sdk.NewEventManager())
		return vaultAddr, underlying
	}

	brokenTVVSetup := func() (sdk.AccAddress, string) {
		vault, _, underlying, heldDenom := s.setupOversizedNAVVault()
		s.seedOversizedNAV(vault, heldDenom, underlying, maxValidNAVPrice(), math.OneInt())
		s.fundPrincipalForBrokenValuation(vault, sdk.NewCoins(sdk.NewInt64Coin(heldDenom, 2)))
		s.ctx = s.ctx.WithEventManager(sdk.NewEventManager())
		return vault.GetAddress(), underlying
	}

	invalidAccountSetup := func() (sdk.AccAddress, string) {
		underlying := "uatom"
		share := "invalidshare"
		vault := s.setupBaseVault(underlying, share)
		vault.DesiredInterestRate = "not-a-decimal"
		s.k.AuthKeeper.SetAccount(s.ctx, vault)
		s.ctx = s.ctx.WithEventManager(sdk.NewEventManager())
		return vault.GetAddress(), underlying
	}

	tests := []struct {
		name                string
		setup               func() (sdk.AccAddress, string)
		force               bool
		expectErr           bool
		expectedPauseAmount int64
		expectedForcedError string
	}{
		{
			name:      "strict pause aborts when reconcile fails on insufficient reserves",
			setup:     insufficientReservesSetup,
			force:     false,
			expectErr: true,
		},
		{
			name:      "strict pause aborts when TVV conversion fails",
			setup:     brokenTVVSetup,
			force:     false,
			expectErr: true,
		},
		{
			name:                "force pause proceeds through insufficient-reserves reconcile failure",
			setup:               insufficientReservesSetup,
			force:               true,
			expectErr:           false,
			expectedPauseAmount: 100_000,
			expectedForcedError: "reconcile failed:",
		},
		{
			name:                "force pause proceeds through broken TVV with zero snapshot",
			setup:               brokenTVVSetup,
			force:               true,
			expectErr:           false,
			expectedPauseAmount: 0,
			expectedForcedError: "valuation failed:",
		},
		{
			name:                "force pause persists without validation when the vault account is invalid",
			setup:               invalidAccountSetup,
			force:               true,
			expectErr:           false,
			expectedPauseAmount: 0,
			expectedForcedError: "set vault account failed:",
		},
	}

	for _, tc := range tests {
		s.Run(tc.name, func() {
			s.SetupTest()
			vaultAddr, underlying := tc.setup()

			_, err := keeper.NewMsgServer(s.simApp.VaultKeeper).PauseVault(s.ctx, &types.MsgPauseVaultRequest{
				Authority:    s.adminAddr.String(),
				VaultAddress: vaultAddr.String(),
				Reason:       reason,
				Force:        tc.force,
			})

			v, getErr := s.k.GetVault(s.ctx, vaultAddr)
			s.Require().NoError(getErr, "loading the vault should succeed for case %q", tc.name)

			if tc.expectErr {
				s.Require().Error(err, "strict pause must fail when pre-pause bookkeeping fails for case %q", tc.name)
				s.Assert().False(v.Paused, "vault must remain unpaused after a failed strict pause for case %q", tc.name)
				s.Assert().Nil(s.findLastEventVaultPaused(), "strict pause must not emit EventVaultPaused for case %q", tc.name)
				return
			}

			s.Require().NoError(err, "force pause must succeed even when the pre-pause reconcile fails for case %q", tc.name)
			s.Assert().True(v.Paused, "vault should be paused after a force pause for case %q", tc.name)
			s.Assert().Equal(reason, v.PausedReason, "paused reason should be recorded for case %q", tc.name)
			s.Assert().Equal(types.ZeroInterestRate, v.CurrentInterestRate, "pausing should zero the current interest rate for case %q", tc.name)
			s.Assert().Equal(underlying, v.PausedBalance.Denom, "paused balance should be denominated in the underlying asset for case %q", tc.name)
			s.Assert().Equal(tc.expectedPauseAmount, v.PausedBalance.Amount.Int64(), "paused balance should be the best-effort TVV snapshot for case %q", tc.name)

			pausedEvent := s.findLastEventVaultPaused()
			s.Require().NotNil(pausedEvent, "an EventVaultPaused should have been emitted for case %q", tc.name)
			s.Assert().True(pausedEvent.Forced, "the forced flag should be set on a force pause for case %q", tc.name)
			s.Assert().Contains(pausedEvent.ForcedError, tc.expectedForcedError, "forced_error should identify the tolerated failure for case %q", tc.name)
		})
	}
}

func (s *TestSuite) TestPauseVault_ClearsReconciliationQueues() {
	underlying := "under"
	share := "vaultshares"
	vaultAddr := types.GetVaultAddress(share)
	reason := "maintenance"

	pauseRequest := func(force bool) *types.MsgPauseVaultRequest {
		return &types.MsgPauseVaultRequest{
			Authority:    s.adminAddr.String(),
			VaultAddress: vaultAddr.String(),
			Reason:       reason,
			Force:        force,
		}
	}

	tests := []struct {
		name  string
		pause func(vault *types.VaultAccount)
	}{
		{
			name: "strict pause",
			pause: func(_ *types.VaultAccount) {
				_, err := keeper.NewMsgServer(s.simApp.VaultKeeper).PauseVault(s.ctx, pauseRequest(false))
				s.Require().NoError(err, "strict pause should not error")
			},
		},
		{
			name: "forced pause",
			pause: func(_ *types.VaultAccount) {
				_, err := keeper.NewMsgServer(s.simApp.VaultKeeper).PauseVault(s.ctx, pauseRequest(true))
				s.Require().NoError(err, "forced pause should not error")
			},
		},
		{
			name: "auto pause",
			pause: func(vault *types.VaultAccount) {
				s.k.TestAccessor_autoPauseVault(s.T(), s.ctx, vault, reason)
			},
		},
	}

	for _, tc := range tests {
		s.Run(tc.name, func() {
			s.SetupTest()
			s.CreateAndActivateVault(s.adminAddr, share, underlying)
			vault, err := s.k.GetVault(s.ctx, vaultAddr)
			s.Require().NoError(err, "GetVault should not error before pausing")
			s.Require().NoError(s.k.SafeEnqueuePayoutTimeout(s.ctx, vault), "enqueuing the payout timeout should not error")
			s.Require().NoError(s.k.SafeEnqueueFeeTimeout(s.ctx, vault), "enqueuing the fee timeout should not error")
			s.Require().NoError(s.k.PayoutVerificationSet.Set(s.ctx, vaultAddr), "seeding the payout verification set should not error")
			s.assertInReconciliationQueues(vaultAddr, true)

			tc.pause(vault)

			paused, err := s.k.GetVault(s.ctx, vaultAddr)
			s.Require().NoError(err, "GetVault should not error after pausing")
			s.Require().True(paused.Paused, "vault should be paused")
			s.assertInReconciliationQueues(vaultAddr, false)
			s.Assert().Zero(paused.PeriodStart, "interest period start should be cleared while paused")
			s.Assert().Zero(paused.PeriodTimeout, "interest period timeout should be cleared while paused")
			s.Assert().Zero(paused.FeePeriodStart, "fee period start should be cleared while paused")
			s.Assert().Zero(paused.FeePeriodTimeout, "fee period timeout should be cleared while paused")
		})
	}
}

func (s *TestSuite) TestPauseVault_LeavesStaleQueueEntryToTheBlockerBackstop() {
	underlying := "under"
	share := "vaultshares"
	vaultAddr := types.GetVaultAddress(share)

	s.CreateAndActivateVault(s.adminAddr, share, underlying)
	staleTimeout := s.ctx.BlockTime().Add(-time.Hour).Unix()
	s.Require().NoError(s.k.PayoutTimeoutQueue.Enqueue(s.ctx, staleTimeout, vaultAddr), "enqueuing a stale payout timeout should not error")

	_, err := keeper.NewMsgServer(s.simApp.VaultKeeper).PauseVault(s.ctx, &types.MsgPauseVaultRequest{
		Authority:    s.adminAddr.String(),
		VaultAddress: vaultAddr.String(),
		Reason:       "maintenance",
	})
	s.Require().NoError(err, "pause should not error")

	now := s.ctx.BlockTime().Unix()
	s.Require().Equal(1, s.countDuePayoutTimeouts(now), "pause removes only the entry keyed by the vault's recorded timeout, so an entry filed under another key survives")

	s.Require().NoError(
		s.k.TestAccessor_handleVaultInterestTimeouts(s.T(), s.ctx, keeper.MaxInterestTimeoutsPerBlock),
		"handleVaultInterestTimeouts should not error",
	)
	s.Assert().Equal(0, s.countDuePayoutTimeouts(now), "the blocker backstop should dequeue the stale entry left behind by pause")
}

func (s *TestSuite) TestUnpauseVault_StaleQueueEntryIsDequeuedWhenProcessed() {
	underlying := "under"
	share := "vaultshares"
	vaultAddr := types.GetVaultAddress(share)

	tests := []struct {
		name     string
		enqueue  func(dueTime int64)
		process  func()
		countDue func(now int64) int
	}{
		{
			name: "stale payout timeout",
			enqueue: func(dueTime int64) {
				s.Require().NoError(s.k.PayoutTimeoutQueue.Enqueue(s.ctx, dueTime, vaultAddr), "enqueuing a stale payout timeout should not error")
			},
			process: func() {
				s.Require().NoError(
					s.k.TestAccessor_handleVaultInterestTimeouts(s.T(), s.ctx, keeper.MaxInterestTimeoutsPerBlock),
					"handleVaultInterestTimeouts should not error",
				)
			},
			countDue: func(now int64) int { return s.countDuePayoutTimeouts(now) },
		},
		{
			name: "stale fee timeout",
			enqueue: func(dueTime int64) {
				s.Require().NoError(s.k.FeeTimeoutQueue.Enqueue(s.ctx, dueTime, vaultAddr), "enqueuing a stale fee timeout should not error")
			},
			process: func() {
				s.Require().NoError(
					s.k.TestAccessor_handleVaultFeeTimeouts(s.T(), s.ctx, keeper.MaxFeeTimeoutsPerBlock),
					"handleVaultFeeTimeouts should not error",
				)
			},
			countDue: func(now int64) int { return s.countDueFeeTimeouts(now) },
		},
	}

	for _, tc := range tests {
		s.Run(tc.name, func() {
			s.SetupTest()
			s.CreateAndActivateVault(s.adminAddr, share, underlying)
			tc.enqueue(s.ctx.BlockTime().Add(-time.Hour).Unix())

			msgServer := keeper.NewMsgServer(s.simApp.VaultKeeper)
			_, err := msgServer.PauseVault(s.ctx, &types.MsgPauseVaultRequest{
				Authority:    s.adminAddr.String(),
				VaultAddress: vaultAddr.String(),
				Reason:       "maintenance",
			})
			s.Require().NoError(err, "pause should not error")
			_, err = msgServer.UnpauseVault(s.ctx, &types.MsgUnpauseVaultRequest{
				Authority:    s.adminAddr.String(),
				VaultAddress: vaultAddr.String(),
			})
			s.Require().NoError(err, "unpause should not error")

			now := s.ctx.BlockTime().Unix()
			s.Require().Equal(1, tc.countDue(now), "the stale entry should survive pause and unpause, since removal is keyed on the vault's recorded timeout")

			tc.process()
			s.Assert().Equal(0, tc.countDue(now), "processing an unpaused vault should dequeue the key its entry was walked under")

			tc.process()
			s.Assert().Equal(0, tc.countDue(now), "the stale entry should not return on later blocks")
		})
	}
}

func (s *TestSuite) TestMsgServer_UnpauseVault_RearmsReconciliationQueues() {
	underlying := "under"
	share := "vaultshares"
	vaultAddr := types.GetVaultAddress(share)
	msgServer := keeper.NewMsgServer(s.simApp.VaultKeeper)

	s.CreateAndActivateVault(s.adminAddr, share, underlying)
	_, err := msgServer.PauseVault(s.ctx, &types.MsgPauseVaultRequest{
		Authority:    s.adminAddr.String(),
		VaultAddress: vaultAddr.String(),
		Reason:       "maintenance",
	})
	s.Require().NoError(err, "pause should not error")
	s.assertInReconciliationQueues(vaultAddr, false)

	unpauseTime := s.ctx.BlockTime().Add(48 * time.Hour)
	s.ctx = s.ctx.WithBlockTime(unpauseTime)

	_, err = msgServer.UnpauseVault(s.ctx, &types.MsgUnpauseVaultRequest{
		Authority:    s.adminAddr.String(),
		VaultAddress: vaultAddr.String(),
	})
	s.Require().NoError(err, "unpause should not error")

	vault, err := s.k.GetVault(s.ctx, vaultAddr)
	s.Require().NoError(err, "GetVault should not error after unpausing")
	s.Require().False(vault.Paused, "vault should be unpaused")

	s.assertInPayoutVerificationQueue(vaultAddr, true)
	s.Assert().Equal(unpauseTime.Unix(), vault.PeriodStart, "interest period should restart at the unpause time")
	s.Assert().Zero(vault.PeriodTimeout, "interest is tracked by the verification set, not a payout timeout")
	s.Assert().Equal(0, s.countDuePayoutTimeouts(unpauseTime.Unix()+keeper.AutoReconcileTimeout), "unpause should not enqueue a payout timeout")

	s.Assert().Equal(unpauseTime.Unix(), vault.FeePeriodStart, "fee period should restart at the unpause time so the paused span is not charged")
	s.Assert().Equal(unpauseTime.Unix()+keeper.AutoReconcileTimeout, vault.FeePeriodTimeout, "fee timeout should be re-armed one auto-reconcile window out")
	s.Assert().Equal(1, s.countDueFeeTimeouts(vault.FeePeriodTimeout), "unpause should re-enqueue exactly one fee timeout")
}

func (s *TestSuite) TestMsgServer_UnpauseVault() {
	type postCheckArgs struct {
		VaultAddress          sdk.AccAddress
		ExpectedPaused        bool
		ExpectedEmptyDenom    string
		ExpectedEmptyAmount   int64
		ExpectedDesiredRate   string
		ExpectedCurrentRate   string
		ExpectedPeriodStart   int64
		ExpectedPeriodTimeout int64
	}

	testDef := msgServerTestDef[types.MsgUnpauseVaultRequest, types.MsgUnpauseVaultResponse, postCheckArgs]{
		endpointName: "UnpauseVault",
		endpoint:     keeper.NewMsgServer(s.simApp.VaultKeeper).UnpauseVault,
		postCheck: func(msg *types.MsgUnpauseVaultRequest, args postCheckArgs) {
			vault, err := s.k.GetVault(s.ctx, args.VaultAddress)
			s.Require().NoError(err, "expected to load vault %s for post-check", args.VaultAddress)
			s.Assert().Equal(args.ExpectedPaused, vault.Paused, "vault paused status")
			s.Assert().Equal(args.ExpectedEmptyDenom, vault.PausedBalance.Denom, "vault paused balance denom")
			s.Assert().Equal(args.ExpectedEmptyAmount, vault.PausedBalance.Amount.Int64(), "vault paused balance amount")
			s.Assert().Empty(vault.PausedReason, "vault paused reason")
			s.Assert().Equal(args.ExpectedDesiredRate, vault.DesiredInterestRate, "vault desired interest rate")
			s.Assert().Equal(args.ExpectedCurrentRate, vault.CurrentInterestRate, "vault current interest rate")
			s.Assert().Equal(args.ExpectedPeriodStart, vault.PeriodStart, "vault interest period start")
			s.Assert().Equal(args.ExpectedPeriodTimeout, vault.PeriodTimeout, "vault interest period timeout")
			found, err := s.k.PayoutVerificationSet.Has(s.ctx, args.VaultAddress)
			s.Require().NoError(err, "error checking payout verification set for vault %s", args.VaultAddress)
			s.Assert().True(found, "vault should be in payout verification set")
		},
	}

	underlying := "under"
	share := "vaultshares"
	admin := s.adminAddr
	vaultAddr := types.GetVaultAddress(share)
	interestRate := "0.0406"
	now := time.Now()

	setup := func() {
		s.ctx = s.ctx.WithBlockTime(now)
		s.requireAddFinalizeAndActivateMarker(sdk.NewCoin(underlying, math.NewInt(10_000)), admin)
		_, err := s.k.CreateVault(s.ctx, &types.MsgCreateVaultRequest{
			Admin:           admin.String(),
			ShareDenom:      share,
			UnderlyingAsset: underlying,
		})
		s.Require().NoError(err, "failed to create vault for share denom %s", share)
		vault, err := s.k.GetVault(s.ctx, vaultAddr)
		s.Require().NoError(err, "failed to get vault in setup")
		s.Require().NoError(s.k.UpdateInterestRates(s.ctx, vault, interestRate, interestRate), "initial interest rate update should succeed")
		vault.PeriodStart = s.ctx.BlockTime().Unix()
		vault.PeriodTimeout = s.ctx.BlockTime().Add(24 * time.Hour).Unix()
		err = s.k.SetVaultAccount(s.ctx, vault)
		s.Require().NoError(err, "failed to set vault account in setup")
		_, err = keeper.NewMsgServer(s.simApp.VaultKeeper).PauseVault(s.ctx, &types.MsgPauseVaultRequest{
			Authority:    admin.String(),
			VaultAddress: vaultAddr.String(),
			Reason:       "maintenance",
		})
		s.Require().NoError(err, "expected pause to succeed in setup")
		s.ctx = s.ctx.WithEventManager(sdk.NewEventManager())
	}

	setupWithAssetMgr := func(assetMgr sdk.AccAddress) {
		setup()
		_, err := keeper.NewMsgServer(s.simApp.VaultKeeper).SetAssetManager(s.ctx, &types.MsgSetAssetManagerRequest{
			Admin:        admin.String(),
			VaultAddress: vaultAddr.String(),
			AssetManager: assetMgr.String(),
		})
		s.Require().NoError(err, "failed to set asset manager in setup")
	}

	s.Run("happy path - admin unpause vault", func() {
		ev := sdk.Events{
			sdk.NewEvent(
				"provlabs.vault.v1.EventVaultInterestChange",
				sdk.NewAttribute("current_rate", interestRate),
				sdk.NewAttribute("desired_rate", interestRate),
				sdk.NewAttribute("vault_address", vaultAddr.String()),
			),
			sdk.NewEvent(
				"provlabs.vault.v1.EventVaultUnpaused",
				sdk.NewAttribute("authority", admin.String()),
				sdk.NewAttribute("total_vault_value", sdk.NewInt64Coin(underlying, 0).String()),
				sdk.NewAttribute("vault_address", vaultAddr.String()),
			),
		}

		tc := msgServerTestCase[types.MsgUnpauseVaultRequest, postCheckArgs]{
			name:  "happy path - admin unpause",
			setup: setup,
			msg: types.MsgUnpauseVaultRequest{
				Authority:    admin.String(),
				VaultAddress: vaultAddr.String(),
			},
			postCheckArgs: postCheckArgs{
				VaultAddress:          vaultAddr,
				ExpectedPaused:        false,
				ExpectedEmptyDenom:    "",
				ExpectedEmptyAmount:   0,
				ExpectedDesiredRate:   interestRate,
				ExpectedCurrentRate:   interestRate,
				ExpectedPeriodStart:   now.Unix(),
				ExpectedPeriodTimeout: 0,
			},
			expectedEvents: ev,
		}

		testDef.expectedResponse = &types.MsgUnpauseVaultResponse{}
		runMsgServerTestCase(s, testDef, tc)
	})

	s.Run("happy path - asset manager unpause vault", func() {
		assetMgr := s.CreateAndFundAccount(sdk.NewInt64Coin(underlying, 100))
		setupWithAssetMgr(assetMgr)

		ev := sdk.Events{
			sdk.NewEvent(
				"provlabs.vault.v1.EventVaultInterestChange",
				sdk.NewAttribute("current_rate", interestRate),
				sdk.NewAttribute("desired_rate", interestRate),
				sdk.NewAttribute("vault_address", vaultAddr.String()),
			),
			sdk.NewEvent(
				"provlabs.vault.v1.EventVaultUnpaused",
				sdk.NewAttribute("authority", assetMgr.String()),
				sdk.NewAttribute("total_vault_value", sdk.NewInt64Coin(underlying, 0).String()),
				sdk.NewAttribute("vault_address", vaultAddr.String()),
			),
		}

		tc := msgServerTestCase[types.MsgUnpauseVaultRequest, postCheckArgs]{
			name:  "happy path - asset manager unpause",
			setup: func() {},
			msg: types.MsgUnpauseVaultRequest{
				Authority:    assetMgr.String(),
				VaultAddress: vaultAddr.String(),
			},
			postCheckArgs: postCheckArgs{
				VaultAddress:          vaultAddr,
				ExpectedPaused:        false,
				ExpectedEmptyDenom:    "",
				ExpectedEmptyAmount:   0,
				ExpectedCurrentRate:   interestRate,
				ExpectedDesiredRate:   interestRate,
				ExpectedPeriodStart:   now.Unix(),
				ExpectedPeriodTimeout: 0,
			},
			expectedEvents: ev,
		}

		testDef.expectedResponse = &types.MsgUnpauseVaultResponse{}
		runMsgServerTestCase(s, testDef, tc)
	})
}

func (s *TestSuite) TestMsgServer_UnpauseVault_Failures() {
	testDef := msgServerTestDef[types.MsgUnpauseVaultRequest, types.MsgUnpauseVaultResponse, any]{
		endpointName: "UnpauseVault",
		endpoint:     keeper.NewMsgServer(s.simApp.VaultKeeper).UnpauseVault,
		postCheck:    nil,
	}

	underlying := "under"
	share := "vaultshares"
	admin := s.adminAddr
	other := s.CreateAndFundAccount(sdk.NewInt64Coin("stake", 1000))
	vaultAddr := types.GetVaultAddress(share)
	markerAddr := markertypes.MustGetMarkerAddress(share)

	base := func() {
		s.requireAddFinalizeAndActivateMarker(sdk.NewCoin(underlying, math.NewInt(10_000)), admin)
		_, err := s.k.CreateVault(s.ctx, &types.MsgCreateVaultRequest{
			Admin:           admin.String(),
			ShareDenom:      share,
			UnderlyingAsset: underlying,
		})
		s.Require().NoError(err, "expected base vault creation to succeed")
		s.ctx = s.ctx.WithEventManager(sdk.NewEventManager())
	}

	paused := func() {
		base()
		_, err := keeper.NewMsgServer(s.simApp.VaultKeeper).PauseVault(s.ctx, &types.MsgPauseVaultRequest{
			Authority:    admin.String(),
			VaultAddress: vaultAddr.String(),
			Reason:       "maintenance",
		})
		s.Require().NoError(err, "expected pause to succeed for paused-state tests")
		s.ctx = s.ctx.WithEventManager(sdk.NewEventManager())
	}

	tests := []msgServerTestCase[types.MsgUnpauseVaultRequest, any]{
		{
			name: "vault not found",
			msg: types.MsgUnpauseVaultRequest{
				Authority:    admin.String(),
				VaultAddress: types.GetVaultAddress("missing").String(),
			},
			expectedErrSubstrs: []string{"not found"},
		},
		{
			name:  "invalid vault address (not a vault account)",
			setup: base,
			msg: types.MsgUnpauseVaultRequest{
				Authority:    admin.String(),
				VaultAddress: markerAddr.String(),
			},
			expectedErrSubstrs: []string{"failed to get vault", "is not a vault account"},
		},
		{
			name:  "unauthorized admin",
			setup: paused,
			msg: types.MsgUnpauseVaultRequest{
				Authority:    other.String(),
				VaultAddress: vaultAddr.String(),
			},
			expectedErrSubstrs: []string{"unauthorized authority"},
		},
		{
			name:  "not paused",
			setup: base,
			msg: types.MsgUnpauseVaultRequest{
				Authority:    admin.String(),
				VaultAddress: vaultAddr.String(),
			},
			expectedErrSubstrs: []string{"is not paused"},
		},
	}

	for _, tc := range tests {
		s.Run(tc.name, func() {
			runMsgServerTestCase(s, testDef, tc)
		})
	}
}

func (s *TestSuite) TestMsgServer_SetBridgeAddress() {
	type postCheckArgs struct {
		VaultAddress   sdk.AccAddress
		ExpectedBridge string
	}

	testDef := msgServerTestDef[types.MsgSetBridgeAddressRequest, types.MsgSetBridgeAddressResponse, postCheckArgs]{
		endpointName: "SetBridgeAddress",
		endpoint:     keeper.NewMsgServer(s.simApp.VaultKeeper).SetBridgeAddress,
		postCheck: func(msg *types.MsgSetBridgeAddressRequest, args postCheckArgs) {
			v, err := s.k.GetVault(s.ctx, args.VaultAddress)
			s.Require().NoError(err, "post-check: should load vault for verification")
			s.Assert().Equal(args.ExpectedBridge, v.BridgeAddress, "post-check: expected vault BridgeAddress to match")
		},
	}

	underlying := "under"
	share := "vaultshares"
	admin := s.adminAddr
	bridge := s.CreateAndFundAccount(sdk.NewInt64Coin("stake", 1))
	vaultAddr := types.GetVaultAddress(share)

	setup := func() {
		s.requireAddFinalizeAndActivateMarker(sdk.NewCoin(underlying, math.NewInt(1000)), admin)
		_, err := s.k.CreateVault(s.ctx, &types.MsgCreateVaultRequest{
			Admin:           admin.String(),
			ShareDenom:      share,
			UnderlyingAsset: underlying,
		})
		s.Require().NoError(err, "setup: expected vault creation to succeed")
		s.ctx = s.ctx.WithEventManager(sdk.NewEventManager())
	}

	tc := msgServerTestCase[types.MsgSetBridgeAddressRequest, postCheckArgs]{
		name:  "happy path",
		setup: setup,
		msg: types.MsgSetBridgeAddressRequest{
			Admin:         admin.String(),
			VaultAddress:  vaultAddr.String(),
			BridgeAddress: bridge.String(),
		},
		postCheckArgs: postCheckArgs{
			VaultAddress:   vaultAddr,
			ExpectedBridge: bridge.String(),
		},
		expectedEvents: sdk.Events{
			sdk.NewEvent("provlabs.vault.v1.EventBridgeAddressSet",
				sdk.NewAttribute("admin", admin.String()),
				sdk.NewAttribute("bridge_address", bridge.String()),
				sdk.NewAttribute("vault_address", vaultAddr.String()),
			),
		},
	}

	testDef.expectedResponse = &types.MsgSetBridgeAddressResponse{}
	runMsgServerTestCase(s, testDef, tc)
}

func (s *TestSuite) TestMsgServer_SetBridgeAddress_Failures() {
	testDef := msgServerTestDef[types.MsgSetBridgeAddressRequest, types.MsgSetBridgeAddressResponse, any]{
		endpointName: "SetBridgeAddress",
		endpoint:     keeper.NewMsgServer(s.simApp.VaultKeeper).SetBridgeAddress,
		postCheck:    nil,
	}

	underlying := "under"
	share := "vaultshares"
	admin := s.adminAddr
	other := s.CreateAndFundAccount(sdk.NewInt64Coin("stake", 1))
	bridge := s.CreateAndFundAccount(sdk.NewInt64Coin("stake", 1))
	vaultAddr := types.GetVaultAddress(share)
	markerAddr := markertypes.MustGetMarkerAddress(share)

	base := func() {
		s.requireAddFinalizeAndActivateMarker(sdk.NewCoin(underlying, math.NewInt(1000)), admin)
		_, err := s.k.CreateVault(s.ctx, &types.MsgCreateVaultRequest{
			Admin:           admin.String(),
			ShareDenom:      share,
			UnderlyingAsset: underlying,
		})
		s.Require().NoError(err, "base: expected vault creation to succeed")
		s.ctx = s.ctx.WithEventManager(sdk.NewEventManager())
	}

	tests := []msgServerTestCase[types.MsgSetBridgeAddressRequest, any]{
		{
			name: "vault not found",
			setup: func() {
				s.ctx = s.ctx.WithEventManager(sdk.NewEventManager())
			},
			msg: types.MsgSetBridgeAddressRequest{
				Admin:         admin.String(),
				VaultAddress:  types.GetVaultAddress("missing").String(),
				BridgeAddress: bridge.String(),
			},
			expectedErrSubstrs: []string{"vault not found"},
		},
		{
			name:  "invalid vault address (not a vault account)",
			setup: base,
			msg: types.MsgSetBridgeAddressRequest{
				Admin:         admin.String(),
				VaultAddress:  markerAddr.String(),
				BridgeAddress: bridge.String(),
			},
			expectedErrSubstrs: []string{"failed to get vault", "is not a vault account"},
		},
		{
			name:  "unauthorized admin",
			setup: base,
			msg: types.MsgSetBridgeAddressRequest{
				Admin:         other.String(),
				VaultAddress:  vaultAddr.String(),
				BridgeAddress: bridge.String(),
			},
			expectedErrSubstrs: []string{"unauthorized", "is not the vault admin"},
		},
	}

	for _, tc := range tests {
		s.Run(tc.name, func() {
			runMsgServerTestCase(s, testDef, tc)
		})
	}
}

func (s *TestSuite) TestMsgServer_ToggleBridge() {
	type postCheckArgs struct {
		VaultAddress    sdk.AccAddress
		ExpectedEnabled bool
	}

	testDef := msgServerTestDef[types.MsgToggleBridgeRequest, types.MsgToggleBridgeResponse, postCheckArgs]{
		endpointName: "ToggleBridge",
		endpoint:     keeper.NewMsgServer(s.simApp.VaultKeeper).ToggleBridge,
		postCheck: func(msg *types.MsgToggleBridgeRequest, args postCheckArgs) {
			v, err := s.k.GetVault(s.ctx, args.VaultAddress)
			s.Require().NoError(err, "post-check: should load vault for verification")
			s.Assert().Equal(args.ExpectedEnabled, v.BridgeEnabled, "post-check: expected BridgeEnabled to match")
		},
	}

	underlying := "under"
	share := "vaultshares"
	admin := s.adminAddr
	vaultAddr := types.GetVaultAddress(share)

	setup := func() {
		s.requireAddFinalizeAndActivateMarker(sdk.NewCoin(underlying, math.NewInt(1000)), admin)
		_, err := s.k.CreateVault(s.ctx, &types.MsgCreateVaultRequest{
			Admin:           admin.String(),
			ShareDenom:      share,
			UnderlyingAsset: underlying,
		})
		s.Require().NoError(err, "setup: expected vault creation to succeed")
		vault, err := s.k.GetVault(s.ctx, vaultAddr)
		s.Require().NoError(err, "setup: should load vault")
		vault.BridgeAddress = s.adminAddr.String()
		s.k.AuthKeeper.SetAccount(s.ctx, vault)
		s.ctx = s.ctx.WithEventManager(sdk.NewEventManager())
	}

	tc := msgServerTestCase[types.MsgToggleBridgeRequest, postCheckArgs]{
		name:  "happy path - enable bridge",
		setup: setup,
		msg: types.MsgToggleBridgeRequest{
			Admin:        admin.String(),
			VaultAddress: vaultAddr.String(),
			Enabled:      true,
		},
		postCheckArgs: postCheckArgs{
			VaultAddress:    vaultAddr,
			ExpectedEnabled: true,
		},
		expectedEvents: sdk.Events{
			sdk.NewEvent("provlabs.vault.v1.EventBridgeToggled",
				sdk.NewAttribute("admin", admin.String()),
				sdk.NewAttribute("enabled", "true"),
				sdk.NewAttribute("vault_address", vaultAddr.String()),
			),
		},
	}

	testDef.expectedResponse = &types.MsgToggleBridgeResponse{}
	runMsgServerTestCase(s, testDef, tc)
}

func (s *TestSuite) TestMsgServer_ToggleBridge_Failures() {
	testDef := msgServerTestDef[types.MsgToggleBridgeRequest, types.MsgToggleBridgeResponse, any]{
		endpointName: "ToggleBridge",
		endpoint:     keeper.NewMsgServer(s.simApp.VaultKeeper).ToggleBridge,
		postCheck:    nil,
	}

	underlying := "under"
	share := "vaultshares"
	admin := s.adminAddr
	other := s.CreateAndFundAccount(sdk.NewInt64Coin("stake", 1))
	vaultAddr := types.GetVaultAddress(share)
	markerAddr := markertypes.MustGetMarkerAddress(share)

	base := func() {
		s.requireAddFinalizeAndActivateMarker(sdk.NewCoin(underlying, math.NewInt(1000)), admin)
		_, err := s.k.CreateVault(s.ctx, &types.MsgCreateVaultRequest{
			Admin:           admin.String(),
			ShareDenom:      share,
			UnderlyingAsset: underlying,
		})
		s.Require().NoError(err, "base: expected vault creation to succeed")
		s.ctx = s.ctx.WithEventManager(sdk.NewEventManager())
	}

	tests := []msgServerTestCase[types.MsgToggleBridgeRequest, any]{
		{
			name: "vault not found",
			setup: func() {
				s.ctx = s.ctx.WithEventManager(sdk.NewEventManager())
			},
			msg: types.MsgToggleBridgeRequest{
				Admin:        admin.String(),
				VaultAddress: types.GetVaultAddress("missing").String(),
				Enabled:      true,
			},
			expectedErrSubstrs: []string{"not found"},
		},
		{
			name:  "invalid vault address (not a vault account)",
			setup: base,
			msg: types.MsgToggleBridgeRequest{
				Admin:        admin.String(),
				VaultAddress: markerAddr.String(),
				Enabled:      true,
			},
			expectedErrSubstrs: []string{"failed to get vault", "is not a vault account"},
		},
		{
			name:  "unauthorized admin",
			setup: base,
			msg: types.MsgToggleBridgeRequest{
				Admin:        other.String(),
				VaultAddress: vaultAddr.String(),
				Enabled:      true,
			},
			expectedErrSubstrs: []string{"unauthorized", "is not the vault admin"},
		},
	}

	for _, tc := range tests {
		s.Run(tc.name, func() {
			runMsgServerTestCase(s, testDef, tc)
		})
	}
}

func (s *TestSuite) TestMsgServer_BridgeMintShares() {
	type postCheckArgs struct {
		BridgeAddress  sdk.AccAddress
		VaultAddress   sdk.AccAddress
		MintedShares   sdk.Coin
		ShareDenom     string
		ExpectedSupply math.Int
	}

	testDef := msgServerTestDef[types.MsgBridgeMintSharesRequest, types.MsgBridgeMintSharesResponse, postCheckArgs]{
		endpointName: "BridgeMintShares",
		endpoint:     keeper.NewMsgServer(s.simApp.VaultKeeper).BridgeMintShares,
		postCheck: func(msg *types.MsgBridgeMintSharesRequest, args postCheckArgs) {
			supply := s.k.BankKeeper.GetSupply(s.ctx, args.ShareDenom)
			s.Assert().Equal(args.ExpectedSupply.String(), supply.Amount.String(), "supply after bridge mint should equal minted amount")
			bal := s.k.BankKeeper.GetBalance(s.ctx, args.BridgeAddress, args.ShareDenom)
			s.Assert().Equal(args.MintedShares, bal, "bridge account balance should equal minted amount")
		},
	}

	underlying := "under"
	share := "vaultshares"
	bridge := s.CreateAndFundAccount(sdk.NewInt64Coin("stake", 1))
	vaultAddr := types.GetVaultAddress(share)
	minted := sdk.NewInt64Coin(share, 250_000_000)

	setup := func() {
		s.setupBridgeVault(underlying, share, bridge, math.NewInt(10_000_000_000))
		s.ctx = s.ctx.WithEventManager(sdk.NewEventManager())
	}

	tc := msgServerTestCase[types.MsgBridgeMintSharesRequest, postCheckArgs]{
		name:  "happy path",
		setup: setup,
		msg: types.MsgBridgeMintSharesRequest{
			VaultAddress: vaultAddr.String(),
			Bridge:       bridge.String(),
			Shares:       minted,
		},
		postCheckArgs: postCheckArgs{
			BridgeAddress:  bridge,
			VaultAddress:   vaultAddr,
			MintedShares:   minted,
			ShareDenom:     share,
			ExpectedSupply: minted.Amount,
		},
		expectedEvents: createBridgeMintSharesEventsExact(vaultAddr, bridge, share, minted),
	}

	testDef.expectedResponse = &types.MsgBridgeMintSharesResponse{}
	runMsgServerTestCase(s, testDef, tc)
}

func (s *TestSuite) TestMsgServer_BridgeMintShares_SupplyAndBalances() {
	type postCheckArgs struct {
		VaultAddress  sdk.AccAddress
		BridgeAddress sdk.AccAddress
		Minted        sdk.Coin
	}

	testDef := msgServerTestDef[types.MsgBridgeMintSharesRequest, types.MsgBridgeMintSharesResponse, postCheckArgs]{
		endpointName: "BridgeMintShares",
		endpoint:     keeper.NewMsgServer(s.simApp.VaultKeeper).BridgeMintShares,
		postCheck: func(msg *types.MsgBridgeMintSharesRequest, args postCheckArgs) {
			supply := s.k.BankKeeper.GetSupply(s.ctx, args.Minted.Denom)
			s.Assert().True(supply.Amount.Equal(args.Minted.Amount), "supply check should equal minted amount")
			b := s.k.BankKeeper.GetBalance(s.ctx, args.BridgeAddress, args.Minted.Denom)
			s.Assert().Equal(args.Minted, b, "bridge balance check should equal minted amount")
		},
	}

	underlying := "underx"
	share := "vaultsharex"
	bridge := s.CreateAndFundAccount(sdk.NewInt64Coin("stake", 1))
	vaultAddr := types.GetVaultAddress(share)
	minted := sdk.NewInt64Coin(share, 1_000)

	setup := func() {
		s.setupBridgeVault(underlying, share, bridge, math.NewInt(9_999_999))
		s.ctx = s.ctx.WithEventManager(sdk.NewEventManager())
	}

	tc := msgServerTestCase[types.MsgBridgeMintSharesRequest, postCheckArgs]{
		name:  "supply and balance update",
		setup: setup,
		msg: types.MsgBridgeMintSharesRequest{
			VaultAddress: vaultAddr.String(),
			Bridge:       bridge.String(),
			Shares:       minted,
		},
		postCheckArgs: postCheckArgs{
			VaultAddress:  vaultAddr,
			BridgeAddress: bridge,
			Minted:        minted,
		},
		expectedEvents: createBridgeMintSharesEventsExact(vaultAddr, bridge, share, minted),
	}

	testDef.expectedResponse = &types.MsgBridgeMintSharesResponse{}
	runMsgServerTestCase(s, testDef, tc)
}

func (s *TestSuite) TestMsgServer_BridgeMintShares_ErrorMessages() {
	testDef := msgServerTestDef[types.MsgBridgeMintSharesRequest, types.MsgBridgeMintSharesResponse, any]{
		endpointName: "BridgeMintShares",
		endpoint:     keeper.NewMsgServer(s.simApp.VaultKeeper).BridgeMintShares,
		postCheck:    nil,
	}

	underlying := "erru"
	share := "errshare"
	bridge := s.CreateAndFundAccount(sdk.NewInt64Coin("stake", 1))
	vaultAddr := types.GetVaultAddress(share)

	setupWithTotalSharesAndLocalSupply := func(totalShares, localSupply int64) func() {
		return func() {
			s.setupBridgeVault(underlying, share, bridge, math.NewInt(totalShares))
			if localSupply > 0 {
				s.Require().NoError(s.k.MarkerKeeper.MintCoin(s.ctx, vaultAddr, sdk.NewInt64Coin(share, localSupply)),
					"setup: expected marker mint of %d local share supply to succeed", localSupply)
			}
			s.ctx = s.ctx.WithEventManager(sdk.NewEventManager())
		}
	}

	tests := []msgServerTestCase[types.MsgBridgeMintSharesRequest, any]{
		{
			name:  "requested amount exceeds remaining capacity",
			setup: setupWithTotalSharesAndLocalSupply(100, 0),
			msg: types.MsgBridgeMintSharesRequest{
				VaultAddress: vaultAddr.String(),
				Bridge:       bridge.String(),
				Shares:       sdk.NewInt64Coin(share, 101),
			},
			expectedErrSubstrs: []string{
				"mint exceeds capacity",
				fmt.Sprintf("requested %d", 101),
				fmt.Sprintf("available %d", 100),
			},
		},
		{
			name:  "local supply already equals total shares, leaving no capacity",
			setup: setupWithTotalSharesAndLocalSupply(100, 100),
			msg: types.MsgBridgeMintSharesRequest{
				VaultAddress: vaultAddr.String(),
				Bridge:       bridge.String(),
				Shares:       sdk.NewInt64Coin(share, 1),
			},
			expectedErrSubstrs: []string{
				"mint exceeds capacity",
				fmt.Sprintf("requested %d", 1),
				fmt.Sprintf("available %d", 0),
			},
		},
		{
			name:  "total shares below local supply returns invariant error instead of panicking",
			setup: setupWithTotalSharesAndLocalSupply(100, 150),
			msg: types.MsgBridgeMintSharesRequest{
				VaultAddress: vaultAddr.String(),
				Bridge:       bridge.String(),
				Shares:       sdk.NewInt64Coin(share, 1),
			},
			expectedErrSubstrs: []string{
				"share supply invariant violated",
				vaultAddr.String(),
				fmt.Sprintf("total shares %d%s", 100, share),
				fmt.Sprintf("below local supply %d%s", 150, share),
			},
		},
		{
			name: "paused vault rejects a mint that would otherwise fit within capacity",
			setup: func() {
				setupWithTotalSharesAndLocalSupply(100, 0)()
				s.pauseVault(vaultAddr)
				s.ctx = s.ctx.WithEventManager(sdk.NewEventManager())
			},
			msg: types.MsgBridgeMintSharesRequest{
				VaultAddress: vaultAddr.String(),
				Bridge:       bridge.String(),
				Shares:       sdk.NewInt64Coin(share, 100),
			},
			expectedErrSubstrs: []string{
				fmt.Sprintf("vault %s is paused", vaultAddr.String()),
			},
		},
	}

	for _, tc := range tests {
		s.Run(tc.name, func() {
			runMsgServerTestCase(s, testDef, tc)
		})
	}
}

func (s *TestSuite) TestMsgServer_BridgeBurnShares() {
	type postCheckArgs struct {
		VaultAddr  sdk.AccAddress
		BridgeAddr sdk.AccAddress
		Shares     sdk.Coin
	}

	testDef := msgServerTestDef[types.MsgBridgeBurnSharesRequest, types.MsgBridgeBurnSharesResponse, postCheckArgs]{
		endpointName: "BridgeBurnShares",
		endpoint:     keeper.NewMsgServer(s.simApp.VaultKeeper).BridgeBurnShares,
		postCheck: func(msg *types.MsgBridgeBurnSharesRequest, args postCheckArgs) {
			supply := s.simApp.BankKeeper.GetSupply(s.ctx, args.Shares.Denom)
			s.Assert().Equal(int64(0), supply.Amount.Int64(), "expected total supply to be zero after burn")
			s.assertBalance(args.BridgeAddr, args.Shares.Denom, sdkmath.ZeroInt())
		},
	}

	underlying := "under"
	share := "vaultshares"
	vaultAddr := types.GetVaultAddress(share)
	markerAddr := markertypes.MustGetMarkerAddress(share)
	bridgeAddr := s.CreateAndFundAccount(sdk.NewInt64Coin("stake", 1))
	burn := sdk.NewInt64Coin(share, 100_000_000)

	setup := func() {
		s.setupBridgeVault(underlying, share, bridgeAddr, math.ZeroInt())

		err := s.k.MarkerKeeper.MintCoin(s.ctx, vaultAddr, burn)
		s.Require().NoError(err, "expected marker mint to succeed")
		err = s.withdrawMarkerCoins(s.ctx, vaultAddr, bridgeAddr, share, sdk.NewCoins(burn))
		s.Require().NoError(err, "expected marker withdraw to bridge to succeed")

		s.ctx = s.ctx.WithEventManager(sdk.NewEventManager())
	}

	events := createSendCoinEvents(bridgeAddr.String(), markerAddr.String(), sdk.NewCoins(burn).String())
	events = append(events, createMarkerBurn(vaultAddr, markerAddr, burn)...)
	events = append(events, sdk.NewEvent("provlabs.vault.v1.EventBridgeBurnShares",
		sdk.NewAttribute("bridge", bridgeAddr.String()),
		sdk.NewAttribute("shares", burn.String()),
		sdk.NewAttribute("vault_address", vaultAddr.String()),
	))

	tc := msgServerTestCase[types.MsgBridgeBurnSharesRequest, postCheckArgs]{
		name:  "happy path",
		setup: setup,
		msg: types.MsgBridgeBurnSharesRequest{
			VaultAddress: vaultAddr.String(),
			Bridge:       bridgeAddr.String(),
			Shares:       burn,
		},
		postCheckArgs:  postCheckArgs{VaultAddr: vaultAddr, BridgeAddr: bridgeAddr, Shares: burn},
		expectedEvents: events,
	}

	testDef.expectedResponse = &types.MsgBridgeBurnSharesResponse{}
	runMsgServerTestCase(s, testDef, tc)
}

func (s *TestSuite) TestMsgServer_BridgeBurnShares_Failures() {
	testDef := msgServerTestDef[types.MsgBridgeBurnSharesRequest, types.MsgBridgeBurnSharesResponse, any]{
		endpointName: "BridgeBurnShares",
		endpoint:     keeper.NewMsgServer(s.simApp.VaultKeeper).BridgeBurnShares,
		postCheck:    nil,
	}

	underlying := "under"
	share := "vaultshares"
	admin := s.adminAddr
	vaultAddr := types.GetVaultAddress(share)
	bridgeAddr := s.CreateAndFundAccount(sdk.NewInt64Coin("stake", 1))
	otherBridge := s.CreateAndFundAccount(sdk.NewInt64Coin("stake", 1))
	burn := sdk.NewInt64Coin(share, 100_000_000)

	base := func() {
		s.requireAddFinalizeAndActivateMarker(sdk.NewInt64Coin(underlying, 2_000_000), admin)
		_, err := s.k.CreateVault(s.ctx, &types.MsgCreateVaultRequest{
			Admin:           admin.String(),
			ShareDenom:      share,
			UnderlyingAsset: underlying,
		})
		s.Require().NoError(err, "expected vault creation to succeed")
		s.ctx = s.ctx.WithEventManager(sdk.NewEventManager())
	}

	enabled := func() {
		s.setupBridgeVault(underlying, share, bridgeAddr, math.ZeroInt())
		s.ctx = s.ctx.WithEventManager(sdk.NewEventManager())
	}

	enabledWithBridgeFunds := func() {
		enabled()
		err := s.k.MarkerKeeper.MintCoin(s.ctx, vaultAddr, burn)
		s.Require().NoError(err, "expected marker mint to succeed")
		err = s.withdrawMarkerCoins(s.ctx, vaultAddr, bridgeAddr, share, sdk.NewCoins(burn))
		s.Require().NoError(err, "expected marker withdraw to bridge to succeed")
		s.ctx = s.ctx.WithEventManager(sdk.NewEventManager())
	}

	tests := []msgServerTestCase[types.MsgBridgeBurnSharesRequest, any]{
		{
			name: "vault not found",
			msg: types.MsgBridgeBurnSharesRequest{
				VaultAddress: types.GetVaultAddress("nosuch").String(),
				Bridge:       bridgeAddr.String(),
				Shares:       burn,
			},
			expectedErrSubstrs: []string{"vault not found"},
		},
		{
			name:  "bridge disabled",
			setup: base,
			msg: types.MsgBridgeBurnSharesRequest{
				VaultAddress: vaultAddr.String(),
				Bridge:       bridgeAddr.String(),
				Shares:       burn,
			},
			expectedErrSubstrs: []string{"bridge is disabled"},
		},
		{
			name:  "unauthorized bridge",
			setup: enabled,
			msg: types.MsgBridgeBurnSharesRequest{
				VaultAddress: vaultAddr.String(),
				Bridge:       otherBridge.String(),
				Shares:       burn,
			},
			expectedErrSubstrs: []string{"unauthorized bridge"},
		},
		{
			name:  "invalid shares denom",
			setup: enabledWithBridgeFunds,
			msg: types.MsgBridgeBurnSharesRequest{
				VaultAddress: vaultAddr.String(),
				Bridge:       bridgeAddr.String(),
				Shares:       sdk.NewInt64Coin("wrongdenom", 10),
			},
			expectedErrSubstrs: []string{"invalid shares denom"},
		},
		{
			name:  "non-positive amount",
			setup: enabledWithBridgeFunds,
			msg: types.MsgBridgeBurnSharesRequest{
				VaultAddress: vaultAddr.String(),
				Bridge:       bridgeAddr.String(),
				Shares:       sdk.NewInt64Coin(share, 0),
			},
			expectedErrSubstrs: []string{"burn amount must be positive"},
		},
		{
			name:  "insufficient bridge balance",
			setup: enabled,
			msg: types.MsgBridgeBurnSharesRequest{
				VaultAddress: vaultAddr.String(),
				Bridge:       bridgeAddr.String(),
				Shares:       burn,
			},
			expectedErrSubstrs: []string{"failed to transfer shares from bridge to vault", "insufficient funds"},
		},
		{
			name: "paused vault rejects a burn the bridge holds the full balance for",
			setup: func() {
				enabledWithBridgeFunds()
				s.pauseVault(vaultAddr)
				s.ctx = s.ctx.WithEventManager(sdk.NewEventManager())
			},
			msg: types.MsgBridgeBurnSharesRequest{
				VaultAddress: vaultAddr.String(),
				Bridge:       bridgeAddr.String(),
				Shares:       burn,
			},
			expectedErrSubstrs: []string{fmt.Sprintf("vault %s is paused", vaultAddr.String())},
		},
	}

	for _, tc := range tests {
		s.Run(tc.name, func() {
			runMsgServerTestCase(s, testDef, tc)
		})
	}
}

func (s *TestSuite) TestMsgServer_BridgeShares_PauseContainsBridge() {
	underlying := "containu"
	share := "containshare"
	vaultAddr := types.GetVaultAddress(share)
	bridgeAddr := s.CreateAndFundAccount(sdk.NewInt64Coin("stake", 1))
	totalShares := math.NewInt(1_000_000)
	halfShares := sdk.NewCoin(share, totalShares.QuoRaw(2))

	msgServer := keeper.NewMsgServer(s.simApp.VaultKeeper)
	s.setupBridgeVault(underlying, share, bridgeAddr, totalShares)

	mintRequest := &types.MsgBridgeMintSharesRequest{
		VaultAddress: vaultAddr.String(),
		Bridge:       bridgeAddr.String(),
		Shares:       halfShares,
	}
	burnRequest := &types.MsgBridgeBurnSharesRequest{
		VaultAddress: vaultAddr.String(),
		Bridge:       bridgeAddr.String(),
		Shares:       halfShares,
	}
	pausedErr := fmt.Sprintf("vault %s is paused", vaultAddr.String())

	_, err := msgServer.BridgeMintShares(s.ctx, mintRequest)
	s.Require().NoError(err, "expected bridge mint of %s to succeed while the vault is live", halfShares)

	_, err = msgServer.PauseVault(s.ctx, &types.MsgPauseVaultRequest{
		VaultAddress: vaultAddr.String(),
		Authority:    s.adminAddr.String(),
		Reason:       "suspected bridge compromise",
	})
	s.Require().NoError(err, "expected the admin pause of vault %s to succeed", vaultAddr)

	_, err = msgServer.BridgeMintShares(s.ctx, mintRequest)
	s.Require().ErrorContains(err, pausedErr,
		"pausing must reject a bridge mint of %s that still fits within the remaining capacity", halfShares)

	_, err = msgServer.BridgeBurnShares(s.ctx, burnRequest)
	s.Require().ErrorContains(err, pausedErr,
		"pausing must reject a bridge burn of %s the bridge holds the full balance for", halfShares)

	s.assertBalance(bridgeAddr, share, halfShares.Amount)

	_, err = msgServer.UnpauseVault(s.ctx, &types.MsgUnpauseVaultRequest{
		VaultAddress: vaultAddr.String(),
		Authority:    s.adminAddr.String(),
	})
	s.Require().NoError(err, "expected the admin unpause of vault %s to succeed", vaultAddr)

	_, err = msgServer.BridgeBurnShares(s.ctx, burnRequest)
	s.Require().NoError(err, "expected bridge burn of %s to succeed once the vault is unpaused", halfShares)

	_, err = msgServer.BridgeMintShares(s.ctx, mintRequest)
	s.Require().NoError(err, "expected bridge mint of %s to succeed once the vault is unpaused", halfShares)
}

// TestMsgServer_BridgeShares_MintBurnMintCycle_TotalSharesInvariant pins the bridge supply-of-record
// model: bridge mint/burn move the local/remote split of an existing cross-chain supply and never
// mutate vault.TotalShares, so a burn re-widens the mint capacity (TotalShares - local_supply) by the
// burned amount while local supply can never exceed TotalShares. See spec/01_concepts.md.
func (s *TestSuite) TestMsgServer_BridgeShares_MintBurnMintCycle_TotalSharesInvariant() {
	underlying := "cyclu"
	share := "cycleshare"
	vaultAddr := types.GetVaultAddress(share)
	bridgeAddr := s.CreateAndFundAccount(sdk.NewInt64Coin("stake", 1))
	totalShares := math.NewInt(1_000_000)

	msgServer := keeper.NewMsgServer(s.simApp.VaultKeeper)

	s.setupBridgeVault(underlying, share, bridgeAddr, totalShares)

	assertInvariant := func(step string) {
		v, err := s.k.GetVault(s.ctx, vaultAddr)
		s.Require().NoError(err, "%s: expected vault retrieval to succeed", step)
		s.Assert().Equal(totalShares.String(), v.TotalShares.Amount.String(),
			"%s: TotalShares must be invariant across bridge ops", step)
		supply := s.k.BankKeeper.GetSupply(s.ctx, share)
		s.Assert().False(supply.Amount.GT(v.TotalShares.Amount),
			"%s: local supply %s must never exceed TotalShares %s", step, supply.Amount, v.TotalShares.Amount)
	}

	_, err := msgServer.BridgeMintShares(s.ctx, &types.MsgBridgeMintSharesRequest{
		VaultAddress: vaultAddr.String(),
		Bridge:       bridgeAddr.String(),
		Shares:       sdk.NewInt64Coin(share, 600_000),
	})
	s.Require().NoError(err, "first mint within capacity should succeed")
	s.Assert().Equal(int64(600_000), s.k.BankKeeper.GetSupply(s.ctx, share).Amount.Int64(),
		"local supply should reflect first mint")
	s.assertBalance(bridgeAddr, share, math.NewInt(600_000))
	assertInvariant("after first mint")

	_, err = msgServer.BridgeBurnShares(s.ctx, &types.MsgBridgeBurnSharesRequest{
		VaultAddress: vaultAddr.String(),
		Bridge:       bridgeAddr.String(),
		Shares:       sdk.NewInt64Coin(share, 400_000),
	})
	s.Require().NoError(err, "burn within bridge balance should succeed")
	s.Assert().Equal(int64(200_000), s.k.BankKeeper.GetSupply(s.ctx, share).Amount.Int64(),
		"local supply should drop by the burned amount")
	s.assertBalance(bridgeAddr, share, math.NewInt(200_000))
	assertInvariant("after burn")

	_, err = msgServer.BridgeMintShares(s.ctx, &types.MsgBridgeMintSharesRequest{
		VaultAddress: vaultAddr.String(),
		Bridge:       bridgeAddr.String(),
		Shares:       sdk.NewInt64Coin(share, 800_000),
	})
	s.Require().NoError(err, "burn re-widened capacity to 800_000; second mint to the cap should succeed")
	s.Assert().Equal(int64(1_000_000), s.k.BankKeeper.GetSupply(s.ctx, share).Amount.Int64(),
		"local supply should reach TotalShares after minting to the re-widened cap")
	assertInvariant("after second mint")

	_, err = msgServer.BridgeMintShares(s.ctx, &types.MsgBridgeMintSharesRequest{
		VaultAddress: vaultAddr.String(),
		Bridge:       bridgeAddr.String(),
		Shares:       sdk.NewInt64Coin(share, 1),
	})
	s.Require().Error(err, "minting beyond TotalShares must be rejected: local supply can never exceed the supply-of-record")
	s.Assert().Contains(err.Error(), "mint exceeds capacity", "expected capacity rejection")
	assertInvariant("after over-cap mint rejected")
}

func (s *TestSuite) TestMsgServer_SetAssetManager_Failures() {
	testDef := msgServerTestDef[types.MsgSetAssetManagerRequest, types.MsgSetAssetManagerResponse, any]{
		endpointName: "SetAssetManager",
		endpoint:     keeper.NewMsgServer(s.simApp.VaultKeeper).SetAssetManager,
		postCheck:    nil,
	}

	underlying := "under"
	share := "vaultshares"
	admin := s.adminAddr
	vaultAddr := types.GetVaultAddress(share)
	assetMgr := s.CreateAndFundAccount(sdk.NewInt64Coin("stake", 1))
	otherAdmin := s.CreateAndFundAccount(sdk.NewInt64Coin("stake", 1))

	base := func() {
		s.requireAddFinalizeAndActivateMarker(sdk.NewInt64Coin(underlying, 2_000_000), admin)
		_, err := s.k.CreateVault(s.ctx, &types.MsgCreateVaultRequest{
			Admin:           admin.String(),
			ShareDenom:      share,
			UnderlyingAsset: underlying,
		})
		s.Require().NoError(err, "expected vault creation to succeed")
		s.ctx = s.ctx.WithEventManager(sdk.NewEventManager())
	}

	tests := []msgServerTestCase[types.MsgSetAssetManagerRequest, any]{
		{
			name: "vault not found",
			msg: types.MsgSetAssetManagerRequest{
				Admin:        admin.String(),
				VaultAddress: types.GetVaultAddress("nosuch").String(),
				AssetManager: assetMgr.String(),
			},
			expectedErrSubstrs: []string{"vault not found"},
		},
		{
			name:  "unauthorized admin",
			setup: base,
			msg: types.MsgSetAssetManagerRequest{
				Admin:        otherAdmin.String(),
				VaultAddress: vaultAddr.String(),
				AssetManager: assetMgr.String(),
			},
			expectedErrSubstrs: []string{"unauthorized"},
		},
	}

	for _, tc := range tests {
		s.Run(tc.name, func() {
			runMsgServerTestCase(s, testDef, tc)
		})
	}
}

func (s *TestSuite) TestMsgServer_UpdateVaultAUMFeeBips() {
	type postCheckArgs struct {
		VaultAddress    sdk.AccAddress
		ExpectedEnabled uint32
	}

	testDef := msgServerTestDef[types.MsgUpdateVaultAUMFeeBipsRequest, types.MsgUpdateVaultAUMFeeBipsResponse, postCheckArgs]{
		endpointName: "UpdateVaultAUMFeeBips",
		endpoint:     keeper.NewMsgServer(s.simApp.VaultKeeper).UpdateVaultAUMFeeBips,
		postCheck: func(msg *types.MsgUpdateVaultAUMFeeBipsRequest, args postCheckArgs) {
			vault, err := s.k.GetVault(s.ctx, args.VaultAddress)
			s.Require().NoError(err, "failed to get vault at address %s in post-check", args.VaultAddress)
			s.Assert().Equal(args.ExpectedEnabled, vault.AumFeeBips, "AUM fee bips state mismatch for vault %s", args.VaultAddress)
		},
	}

	underlyingDenom := "underlying"
	shareDenom := "vaultshares"
	admin := s.adminAddr
	techFeeAddr := s.EnsureTechFeeAccount()
	otherUser := s.CreateAndFundAccount(sdk.NewInt64Coin("stake", 1000))
	vaultAddr := types.GetVaultAddress(shareDenom)

	setup := func() {
		s.requireAddFinalizeAndActivateMarker(sdk.NewCoin(underlyingDenom, math.NewInt(1000)), admin)
		_, err := s.k.CreateVault(s.ctx, &types.MsgCreateVaultRequest{
			Admin:           admin.String(),
			ShareDenom:      shareDenom,
			UnderlyingAsset: underlyingDenom,
		})
		s.Require().NoError(err, "failed to create vault in UpdateVaultAUMFeeBips setup for share denom %s", shareDenom)
		s.ctx = s.ctx.WithEventManager(sdk.NewEventManager())
		s.ctx = s.ctx.WithBlockTime(time.Now())
	}

	tests := []struct {
		name               string
		setup              func()
		msg                types.MsgUpdateVaultAUMFeeBipsRequest
		postCheckArgs      postCheckArgs
		expectedEvents     sdk.Events
		expectedErrSubstrs []string
	}{
		{
			name:  "happy path - update bips",
			setup: setup,
			msg: types.MsgUpdateVaultAUMFeeBipsRequest{
				Authority:    techFeeAddr.String(),
				VaultAddress: vaultAddr.String(),
				AumFeeBips:   20,
			},
			postCheckArgs: postCheckArgs{
				VaultAddress:    vaultAddr,
				ExpectedEnabled: 20,
			},
			expectedEvents: sdk.Events{
				sdk.NewEvent("provlabs.vault.v1.EventVaultAUMFeeBipsUpdated",
					sdk.NewAttribute("aum_fee_bips", "20"),
					sdk.NewAttribute("authority", techFeeAddr.String()),
					sdk.NewAttribute("vault_address", vaultAddr.String()),
				),
			},
		},
		{
			name:  "failure - vault not found",
			setup: func() { /* no setup */ },
			msg: types.MsgUpdateVaultAUMFeeBipsRequest{
				Authority:    techFeeAddr.String(),
				VaultAddress: vaultAddr.String(),
				AumFeeBips:   20,
			},
			expectedErrSubstrs: []string{"vault not found"},
		},
		{
			name:  "failure - unauthorized authority",
			setup: setup,
			msg: types.MsgUpdateVaultAUMFeeBipsRequest{
				Authority:    otherUser.String(),
				VaultAddress: vaultAddr.String(),
				AumFeeBips:   20,
			},
			expectedErrSubstrs: []string{"unauthorized"},
		},
		{
			name:  "failure - invalid bips",
			setup: setup,
			msg: types.MsgUpdateVaultAUMFeeBipsRequest{
				Authority:    techFeeAddr.String(),
				VaultAddress: vaultAddr.String(),
				AumFeeBips:   10001,
			},
			expectedErrSubstrs: []string{"invalid AUM fee bips"},
		},
	}

	for _, tt := range tests {
		s.Run(tt.name, func() {
			tc := msgServerTestCase[types.MsgUpdateVaultAUMFeeBipsRequest, postCheckArgs]{
				name:               tt.name,
				setup:              tt.setup,
				msg:                tt.msg,
				postCheckArgs:      tt.postCheckArgs,
				expectedEvents:     tt.expectedEvents,
				expectedErrSubstrs: tt.expectedErrSubstrs,
			}

			testDef.expectedResponse = &types.MsgUpdateVaultAUMFeeBipsResponse{}
			runMsgServerTestCase(s, testDef, tc)
		})
	}
}

// msgServerTestDef defines the configuration for testing a specific MsgServer endpoint.
// Req is the request message type.
// Resp is the expected response message type.
// CheckArgs is the argument type passed to the postCheck function.
type msgServerTestDef[Req any, Resp any, CheckArgs any] struct {
	endpointName     string
	endpoint         func(ctx context.Context, msg *Req) (*Resp, error)
	expectedResponse *Resp
	postCheck        func(msg *Req, args CheckArgs)
}

// msgServerTestCase defines a single test case for a MsgServer endpoint.
// Req is the request message type.
// CheckArgs is the argument type passed to the postCheck function.
type msgServerTestCase[Req any, CheckArgs any] struct {
	name               string
	setup              func()
	msg                Req
	expectedErrSubstrs []string
	postCheckArgs      CheckArgs
	expectedEvents     sdk.Events
}

// runMsgServerTestCase executes a unit test for a MsgServer endpoint using the given test definition and test case.
// Req is the request message type.
// Resp is the expected response message type.
// CheckArgs is the argument type passed to the postCheck function.
func runMsgServerTestCase[Req any, Resp any, CheckArgs any](
	s *TestSuite,
	td msgServerTestDef[Req, Resp, CheckArgs],
	tc msgServerTestCase[Req, CheckArgs],
) {
	s.T().Helper()

	origCtx := s.ctx
	defer func() { s.ctx = origCtx }()
	s.ctx, _ = s.ctx.CacheContext()

	if tc.setup != nil {
		tc.setup()
	}

	em := sdk.NewEventManager()
	s.ctx = s.ctx.WithEventManager(em)

	var resp *Resp
	var err error
	s.Require().NotPanicsf(func() {
		resp, err = td.endpoint(s.ctx, &tc.msg)
	}, "%s panic", td.endpointName)

	if len(tc.expectedErrSubstrs) == 0 {
		s.Assert().NoErrorf(err, "%s error", td.endpointName)
		s.Assert().Equalf(td.expectedResponse, resp, "%s response", td.endpointName)
	} else {
		s.Require().Errorf(err, "%s error", td.endpointName)
		for _, substr := range tc.expectedErrSubstrs {
			s.Assert().Containsf(err.Error(), substr, "%s error missing expected substring", td.endpointName)
		}
		return
	}

	s.Assert().Equalf(
		normalizeEvents(tc.expectedEvents),
		normalizeEvents(em.Events()),
		"%s events", td.endpointName,
	)

	td.postCheck(&tc.msg, tc.postCheckArgs)
}

func (s *TestSuite) TestMsgServer_UpdateVaultNAV() {
	underlying := "under"
	share := "vaultshares"
	navDenom := "rwa"
	admin := s.adminAddr
	vaultAddr := types.GetVaultAddress(share)

	baseSetup := func() {
		s.setupBaseVault(underlying, share)
		s.requireSimpleMarker(navDenom)
		s.ctx = s.ctx.WithBlockHeight(100)
	}

	type postCheckArgs struct {
		denom  string
		price  sdk.Coin
		volume sdkmath.Int
		source string
		height int64
	}

	testDef := msgServerTestDef[types.MsgUpdateVaultNAVRequest, types.MsgUpdateVaultNAVResponse, postCheckArgs]{
		endpointName:     "UpdateVaultNAV",
		endpoint:         keeper.NewMsgServer(s.simApp.VaultKeeper).UpdateVaultNAV,
		expectedResponse: &types.MsgUpdateVaultNAVResponse{},
		postCheck: func(_ *types.MsgUpdateVaultNAVRequest, args postCheckArgs) {
			nav, err := s.k.GetVaultNAV(s.ctx, vaultAddr, args.denom)
			s.Require().NoError(err, "post-check: failed to get NAV for %s", args.denom)
			s.Assert().Equal(args.denom, nav.Denom, "post-check: NAV denom mismatch")
			s.Assert().Equal(args.price, nav.Price, "post-check: NAV price mismatch")
			s.Assert().Equal(args.volume, nav.Volume, "post-check: NAV volume mismatch")
			s.Assert().Equal(args.source, nav.Source, "post-check: NAV source mismatch")
			s.Assert().Equal(args.height, nav.UpdatedBlockHeight, "post-check: NAV block height mismatch")
			s.Assert().Equal(s.ctx.BlockTime().UTC(), nav.UpdatedTime, "post-check: NAV updated time mismatch")

			markerNAV, err := s.simApp.MarkerKeeper.GetNetAssetValue(s.ctx, args.denom, args.price.Denom)
			s.Require().NoError(err, "post-check: failed to read the marker NAV for %s priced in %s", args.denom, args.price.Denom)
			s.Assert().Nil(markerNAV, "post-check: an asset price must stay in the vault's internal table and never reach the marker module for %s", args.denom)
		},
	}

	tests := []struct {
		name   string
		setup  func()
		price  sdk.Coin
		volume sdkmath.Int
		source string
	}{
		{
			name:   "first NAV write",
			setup:  baseSetup,
			price:  sdk.NewInt64Coin(underlying, 100),
			volume: sdkmath.NewInt(1),
			source: "oracle-a",
		},
		{
			name: "overwrite existing NAV",
			setup: func() {
				baseSetup()
				vault, err := s.k.GetVault(s.ctx, vaultAddr)
				s.Require().NoError(err, "failed to get vault for overwrite setup")
				seed := types.VaultNAV{Denom: navDenom, Price: sdk.NewInt64Coin(underlying, 50), Volume: sdkmath.NewInt(2)}
				s.Require().NoError(s.k.SetVaultNAV(s.ctx, vault, seed, admin.String()), "failed to seed NAV")
			},
			price:  sdk.NewInt64Coin(underlying, 250),
			volume: sdkmath.NewInt(5),
			source: "oracle-b",
		},
		{
			name:   "held denom written down to a zero NAV",
			setup:  baseSetup,
			price:  sdk.NewInt64Coin(underlying, 0),
			volume: sdkmath.NewInt(1),
			source: "bankruptcy-writedown",
		},
		{
			name: "paused vault accepts a repricing so pause, reprice, unpause is a usable sequence",
			setup: func() {
				baseSetup()
				s.pauseVault(vaultAddr)
			},
			price:  sdk.NewInt64Coin(underlying, 175),
			volume: sdkmath.NewInt(3),
			source: "oracle-while-paused",
		},
		{
			name:   "volume beyond the uint64 range is stored, since the internal table is not bounded by a marker mirror",
			setup:  baseSetup,
			price:  sdk.NewInt64Coin(underlying, 100),
			volume: sdkmath.NewIntFromBigInt(new(big.Int).Lsh(big.NewInt(1), 70)),
			source: "oracle-large-volume",
		},
	}

	for _, tt := range tests {
		s.Run(tt.name, func() {
			tc := msgServerTestCase[types.MsgUpdateVaultNAVRequest, postCheckArgs]{
				name:  tt.name,
				setup: tt.setup,
				msg: types.MsgUpdateVaultNAVRequest{
					Signer:       admin.String(),
					VaultAddress: vaultAddr.String(),
					Denom:        navDenom,
					Price:        tt.price,
					Volume:       tt.volume,
					Source:       tt.source,
				},
				postCheckArgs: postCheckArgs{denom: navDenom, price: tt.price, volume: tt.volume, source: tt.source, height: 100},
				expectedEvents: sdk.Events{
					sdk.NewEvent("provlabs.vault.v1.EventNAVUpdated",
						sdk.NewAttribute("denom", navDenom),
						sdk.NewAttribute("price", tt.price.String()),
						sdk.NewAttribute("signer", admin.String()),
						sdk.NewAttribute("source", tt.source),
						sdk.NewAttribute("updated_block_height", "100"),
						sdk.NewAttribute("vault_address", vaultAddr.String()),
						sdk.NewAttribute("volume", tt.volume.String()),
					),
				},
			}
			runMsgServerTestCase(s, testDef, tc)
		})
	}
}

// TestMsgServer_UpdateVaultNAV_Failures covers authority enforcement, denom
// validation, price/volume validation, and the missing-vault path.
func (s *TestSuite) TestMsgServer_UpdateVaultNAV_Failures() {
	underlying := "under"
	share := "vaultshares"
	admin := s.adminAddr
	other := s.CreateAndFundAccount(sdk.NewInt64Coin("stake", 1000))
	vaultAddr := types.GetVaultAddress(share)

	setup := func() {
		s.setupBaseVault(underlying, share)
	}

	testDef := msgServerTestDef[types.MsgUpdateVaultNAVRequest, types.MsgUpdateVaultNAVResponse, any]{
		endpointName: "UpdateVaultNAV",
		endpoint:     keeper.NewMsgServer(s.simApp.VaultKeeper).UpdateVaultNAV,
		postCheck:    nil,
	}

	tests := []msgServerTestCase[types.MsgUpdateVaultNAVRequest, any]{
		{
			name:  "vault does not exist",
			setup: func() {},
			msg: types.MsgUpdateVaultNAVRequest{
				Signer:       admin.String(),
				VaultAddress: types.GetVaultAddress("doesnotexist").String(),
				Denom:        "rwa",
				Price:        sdk.NewInt64Coin(underlying, 100),
				Volume:       sdkmath.NewInt(1),
			},
			expectedErrSubstrs: []string{"vault not found"},
		},
		{
			name:  "wrong signer is not the NAV authority",
			setup: setup,
			msg: types.MsgUpdateVaultNAVRequest{
				Signer:       other.String(),
				VaultAddress: vaultAddr.String(),
				Denom:        "rwa",
				Price:        sdk.NewInt64Coin(underlying, 100),
				Volume:       sdkmath.NewInt(1),
			},
			expectedErrSubstrs: []string{"unauthorized", "is not the vault NAV authority"},
		},
		{
			name:  "rejects vault share denom",
			setup: setup,
			msg: types.MsgUpdateVaultNAVRequest{
				Signer:       admin.String(),
				VaultAddress: vaultAddr.String(),
				Denom:        share,
				Price:        sdk.NewInt64Coin(underlying, 100),
				Volume:       sdkmath.NewInt(1),
			},
			expectedErrSubstrs: []string{"cannot set NAV for vault share denom"},
		},
		{
			name:  "rejects unregistered marker denom",
			setup: setup,
			msg: types.MsgUpdateVaultNAVRequest{
				Signer:       admin.String(),
				VaultAddress: vaultAddr.String(),
				Denom:        "notamarker",
				Price:        sdk.NewInt64Coin(underlying, 100),
				Volume:       sdkmath.NewInt(1),
			},
			expectedErrSubstrs: []string{"is not a registered marker"},
		},
		{
			name:  "rejects negative price",
			setup: setup,
			msg: types.MsgUpdateVaultNAVRequest{
				Signer:       admin.String(),
				VaultAddress: vaultAddr.String(),
				Denom:        "rwa",
				Price:        sdk.Coin{Denom: underlying, Amount: sdkmath.NewInt(-1)},
				Volume:       sdkmath.NewInt(1),
			},
			expectedErrSubstrs: []string{"invalid NAV price"},
		},
		{
			name:  "rejects zero volume",
			setup: setup,
			msg: types.MsgUpdateVaultNAVRequest{
				Signer:       admin.String(),
				VaultAddress: vaultAddr.String(),
				Denom:        "rwa",
				Price:        sdk.NewInt64Coin(underlying, 100),
				Volume:       sdkmath.ZeroInt(),
			},
			expectedErrSubstrs: []string{"NAV volume must be positive"},
		},
		{
			name:  "rejects negative volume",
			setup: setup,
			msg: types.MsgUpdateVaultNAVRequest{
				Signer:       admin.String(),
				VaultAddress: vaultAddr.String(),
				Denom:        "rwa",
				Price:        sdk.NewInt64Coin(underlying, 100),
				Volume:       sdkmath.NewInt(-1),
			},
			expectedErrSubstrs: []string{"NAV volume must be positive"},
		},
	}

	for _, tc := range tests {
		s.Run(tc.name, func() {
			runMsgServerTestCase(s, testDef, tc)
		})
	}
}

func (s *TestSuite) TestMsgServer_UpdateVaultNAV_Reconcile() {
	underlying := "under"
	share := "vaultshares"
	navDenom := "rwa"
	testBlockTime := time.Date(2025, 1, 1, 0, 0, 0, 0, time.UTC)

	tests := []struct {
		name                 string
		interestRate         string
		paused               bool
		useUnregisteredDenom bool
		expectedErrContains  string
		expectedReconciles   int
	}{
		{
			name:               "successful NAV update with an elapsed interest period reconciles exactly once, before the NAV write",
			interestRate:       "4.20",
			expectedReconciles: 1,
		},
		{
			name:               "paused vault accepts the NAV update and does not reconcile, its accrual already being halted",
			interestRate:       "4.20",
			paused:             true,
			expectedReconciles: 0,
		},
		{
			name:                 "NAV update that fails validation reconciles first, relying on tx revert to discard it",
			interestRate:         "4.20",
			useUnregisteredDenom: true,
			expectedErrContains:  "is not a registered marker",
			expectedReconciles:   1,
		},
		{
			name:                "failed reconcile aborts the NAV update",
			interestRate:        "1000000.0",
			expectedErrContains: "failed to reconcile vault before NAV update",
			expectedReconciles:  0,
		},
	}

	for _, tc := range tests {
		s.Run(tc.name, func() {
			origCtx := s.ctx
			defer func() { s.ctx = origCtx }()
			s.ctx, _ = s.ctx.CacheContext()

			vaultAddr, _ := s.setupReconcileVault(tc.interestRate, testBlockTime.Add(-3*time.Hour).Unix(), tc.paused, sdk.NewInt64Coin(underlying, 1_000), share, sdk.NewInt64Coin(share, 0), testBlockTime)
			denom := navDenom
			if tc.useUnregisteredDenom {
				denom = "notamarker"
			} else {
				s.requireSimpleMarker(navDenom)
			}

			s.ctx = s.ctx.WithEventManager(sdk.NewEventManager())
			_, err := keeper.NewMsgServer(s.simApp.VaultKeeper).UpdateVaultNAV(s.ctx, &types.MsgUpdateVaultNAVRequest{
				Signer:       s.adminAddr.String(),
				VaultAddress: vaultAddr.String(),
				Denom:        denom,
				Price:        sdk.NewInt64Coin(underlying, 100),
				Volume:       sdkmath.NewInt(1),
				Source:       "oracle",
			})

			reconcileCount := 0
			reconcileIdx := -1
			updatedIdx := -1
			for i, ev := range s.ctx.EventManager().Events() {
				switch ev.Type {
				case "provlabs.vault.v1.EventVaultReconcile":
					reconcileCount++
					reconcileIdx = i
				case "provlabs.vault.v1.EventNAVUpdated":
					updatedIdx = i
				}
			}

			if tc.expectedErrContains != "" {
				s.Require().ErrorContains(err, tc.expectedErrContains, "UpdateVaultNAV should fail for case %q", tc.name)
			} else {
				s.Require().NoError(err, "UpdateVaultNAV should succeed for case %q", tc.name)
			}
			s.Assert().Equal(tc.expectedReconciles, reconcileCount, "EventVaultReconcile count mismatch for case %q", tc.name)
			if tc.expectedErrContains == "" {
				s.Require().GreaterOrEqual(updatedIdx, 0, "EventNAVUpdated should be emitted for case %q", tc.name)
			}
			if tc.expectedErrContains == "" && tc.expectedReconciles > 0 {
				s.Assert().Less(reconcileIdx, updatedIdx, "reconcile events should precede EventNAVUpdated for case %q", tc.name)
			}
		})
	}
}

func (s *TestSuite) TestMsgServer_UpdateVaultNAV_LeavesPausedBalanceFrozen() {
	underlying := "under"
	share := "vaultshares"
	heldDenom := "rwa"
	vaultAddr := types.GetVaultAddress(share)

	const (
		underlyingHeld = 500
		assetHeld      = 1_000
		seedPrice      = 2
		seedVolume     = 1
		valueAtPause   = underlyingHeld + assetHeld*seedPrice
	)

	tests := []struct {
		name              string
		newPrice          int64
		newVolume         int64
		depositWhilePause int64
		expectedAtUnpause int64
	}{
		{
			name:              "marking a held asset down takes effect at unpause",
			newPrice:          1,
			newVolume:         1,
			expectedAtUnpause: underlyingHeld + assetHeld,
		},
		{
			name:              "marking a held asset up takes effect at unpause",
			newPrice:          5,
			newVolume:         1,
			expectedAtUnpause: underlyingHeld + assetHeld*5,
		},
		{
			name:              "writing a held asset down to zero leaves only the underlying at unpause",
			newPrice:          0,
			newVolume:         1,
			expectedAtUnpause: underlyingHeld,
		},
		{
			name:              "a principal deposit during the same pause lands alongside the repricing at unpause",
			newPrice:          5,
			newVolume:         1,
			depositWhilePause: 250,
			expectedAtUnpause: underlyingHeld + 250 + assetHeld*5,
		},
	}

	for _, tc := range tests {
		s.Run(tc.name, func() {
			origCtx := s.ctx
			defer func() { s.ctx = origCtx }()
			s.ctx, _ = s.ctx.CacheContext()

			getVault := func() *types.VaultAccount {
				vault, err := s.k.GetVault(s.ctx, vaultAddr)
				s.Require().NoError(err, "failed to get vault %s", vaultAddr)
				return vault
			}

			vault := s.setupBaseVault(underlying, share)
			s.requireSimpleMarker(heldDenom)
			s.setVaultNAV(vault, heldDenom, sdk.NewInt64Coin(underlying, seedPrice), seedVolume)
			s.Require().NoError(
				FundAccount(s.ctx, s.simApp, vault.PrincipalMarkerAddress(),
					sdk.NewCoins(sdk.NewInt64Coin(underlying, underlyingHeld), sdk.NewInt64Coin(heldDenom, assetHeld))),
				"failed to fund the principal marker with %d%s and %d%s", underlyingHeld, underlying, assetHeld, heldDenom,
			)

			msgServer := keeper.NewMsgServer(s.simApp.VaultKeeper)
			_, err := msgServer.PauseVault(s.ctx, &types.MsgPauseVaultRequest{
				Authority:    s.adminAddr.String(),
				VaultAddress: vaultAddr.String(),
				Reason:       "repricing held assets",
			})
			s.Require().NoError(err, "PauseVault should succeed before repricing")
			s.Require().Equal(int64(valueAtPause), getVault().PausedBalance.Amount.Int64(),
				"pause should snapshot %d%s as the frozen balance", valueAtPause, underlying)

			if tc.depositWhilePause > 0 {
				_, err = msgServer.DepositPrincipalFunds(s.ctx, &types.MsgDepositPrincipalFundsRequest{
					Authority:    s.adminAddr.String(),
					VaultAddress: vaultAddr.String(),
					Amount:       sdk.NewInt64Coin(underlying, tc.depositWhilePause),
				})
				s.Require().NoError(err, "DepositPrincipalFunds should succeed while the vault is paused")
			}

			_, err = msgServer.UpdateVaultNAV(s.ctx, &types.MsgUpdateVaultNAVRequest{
				Signer:       s.adminAddr.String(),
				VaultAddress: vaultAddr.String(),
				Denom:        heldDenom,
				Price:        sdk.NewInt64Coin(underlying, tc.newPrice),
				Volume:       sdkmath.NewInt(tc.newVolume),
				Source:       "oracle",
			})
			s.Require().NoError(err, "UpdateVaultNAV should be accepted while the vault is paused")

			repriced := getVault()
			s.Assert().Equal(int64(valueAtPause), repriced.PausedBalance.Amount.Int64(),
				"repricing %s at %d/%d must not move the frozen balance", heldDenom, tc.newPrice, tc.newVolume)

			pausedValue, err := s.k.GetNetTVV(s.ctx, *repriced)
			s.Require().NoError(err, "failed to value the paused vault after repricing")
			s.Assert().Equal(int64(valueAtPause), pausedValue.Int64(),
				"a paused vault should keep reporting its pause-time value until it is unpaused")

			navEntry, err := s.k.GetVaultNAV(s.ctx, vaultAddr, heldDenom)
			s.Require().NoError(err, "the repriced NAV entry should be readable while the vault is paused")
			s.Assert().Equal(tc.newPrice, navEntry.Price.Amount.Int64(),
				"the NAV table should record the new price even though the frozen value ignores it")

			_, err = msgServer.UnpauseVault(s.ctx, &types.MsgUnpauseVaultRequest{
				Authority:    s.adminAddr.String(),
				VaultAddress: vaultAddr.String(),
			})
			s.Require().NoError(err, "UnpauseVault should succeed after repricing")

			liveValue, err := s.k.GetNetTVV(s.ctx, *getVault())
			s.Require().NoError(err, "failed to value the vault after unpausing")
			s.Assert().Equal(tc.expectedAtUnpause, liveValue.Int64(),
				"unpausing should apply everything done during the pause at once")
		})
	}
}

func (s *TestSuite) TestMsgServer_UpdateVaultNAV_HeldRepriceRequiresPause() {
	underlying := "under"
	share := "vaultshares"
	heldDenom := "rwa"
	vaultAddr := types.GetVaultAddress(share)

	const (
		seedPrice  = 2
		seedVolume = 1
		heldAmount = 1_000
	)

	tests := []struct {
		name               string
		heldAmount         int64
		unpriced           bool
		paused             bool
		newPrice           int64
		newVolume          int64
		expectedErrSubstr  string
		expectedStorePrice int64
	}{
		{
			name:               "live vault rejects marking a held asset up",
			heldAmount:         heldAmount,
			newPrice:           4,
			newVolume:          1,
			expectedErrSubstr:  "pause the vault to reprice a held asset",
			expectedStorePrice: seedPrice,
		},
		{
			name:               "live vault rejects marking a held asset down",
			heldAmount:         heldAmount,
			newPrice:           1,
			newVolume:          1,
			expectedErrSubstr:  "pause the vault to reprice a held asset",
			expectedStorePrice: seedPrice,
		},
		{
			name:               "live vault rejects writing a held asset down to zero",
			heldAmount:         heldAmount,
			newPrice:           0,
			newVolume:          1,
			expectedErrSubstr:  "pause the vault to reprice a held asset",
			expectedStorePrice: seedPrice,
		},
		{
			name:               "live vault rejects a same-price restatement whose volume changes the unit price",
			heldAmount:         heldAmount,
			newPrice:           seedPrice,
			newVolume:          2,
			expectedErrSubstr:  "pause the vault to reprice a held asset",
			expectedStorePrice: seedPrice,
		},
		{
			name:               "live vault accepts the same unit price restated at a larger volume",
			heldAmount:         heldAmount,
			newPrice:           seedPrice * 3,
			newVolume:          seedVolume * 3,
			expectedStorePrice: seedPrice * 3,
		},
		{
			name:               "live vault accepts an identical restatement",
			heldAmount:         heldAmount,
			newPrice:           seedPrice,
			newVolume:          seedVolume,
			expectedStorePrice: seedPrice,
		},
		{
			name:               "live vault accepts repricing a denom it does not hold",
			heldAmount:         0,
			newPrice:           4,
			newVolume:          1,
			expectedStorePrice: 4,
		},
		{
			name:               "paused vault accepts marking a held asset up",
			heldAmount:         heldAmount,
			paused:             true,
			newPrice:           4,
			newVolume:          1,
			expectedStorePrice: 4,
		},
		{
			name:              "live vault rejects the first price for an asset it already holds",
			heldAmount:        heldAmount,
			unpriced:          true,
			newPrice:          4,
			newVolume:         1,
			expectedErrSubstr: "pause the vault to reprice a held asset",
		},
		{
			name:               "paused vault accepts the first price for an asset it already holds",
			heldAmount:         heldAmount,
			unpriced:           true,
			paused:             true,
			newPrice:           4,
			newVolume:          1,
			expectedStorePrice: 4,
		},
	}

	for _, tc := range tests {
		s.Run(tc.name, func() {
			origCtx := s.ctx
			defer func() { s.ctx = origCtx }()
			s.ctx, _ = s.ctx.CacheContext()

			var vault *types.VaultAccount
			if tc.unpriced {
				vault = s.setupBaseVault(underlying, share)
				s.requireSimpleMarker(heldDenom)
				s.fundPrincipal(vault, sdk.NewInt64Coin(heldDenom, tc.heldAmount))
			} else {
				vault = s.setupHeldNAVVault(underlying, share, heldDenom, sdk.NewInt64Coin(underlying, seedPrice), seedVolume, tc.heldAmount)
			}
			if tc.paused {
				s.pauseVault(vaultAddr)
			}

			_, err := keeper.NewMsgServer(s.simApp.VaultKeeper).UpdateVaultNAV(s.ctx, &types.MsgUpdateVaultNAVRequest{
				Signer:       s.adminAddr.String(),
				VaultAddress: vaultAddr.String(),
				Denom:        heldDenom,
				Price:        sdk.NewInt64Coin(underlying, tc.newPrice),
				Volume:       sdkmath.NewInt(tc.newVolume),
				Source:       "oracle",
			})

			stored, storeErr := s.k.GetVaultNAV(s.ctx, vaultAddr, heldDenom)
			if tc.expectedErrSubstr != "" {
				s.Require().ErrorContains(err, tc.expectedErrSubstr,
					"UpdateVaultNAV should refuse to reprice %d%s while the vault is live", tc.heldAmount, heldDenom)
				if tc.unpriced {
					s.Require().Error(storeErr, "a rejected first price must not leave a NAV entry for %s", heldDenom)
					return
				}
			} else {
				s.Require().NoError(err, "UpdateVaultNAV should accept this update")
			}

			s.Require().NoError(storeErr, "the NAV entry for %s should be readable", heldDenom)
			s.Assert().Equal(tc.expectedStorePrice, stored.Price.Amount.Int64(),
				"stored NAV price for %s after the update attempt", heldDenom)
		})
	}
}

func (s *TestSuite) TestMsgServer_RepriceVault() {
	underlying := "under"
	share := "vaultshares"
	vaultAddr := types.GetVaultAddress(share)
	navAuthority := sdk.AccAddress("navAuthorityAddr____")

	const (
		seedPrice  = 2
		seedVolume = 1
		heldAmount = 1_000
	)

	tests := []struct {
		name           string
		heldDenoms     []string
		unheldDenoms   []string
		startPaused    bool
		resume         bool
		updates        []types.NAVUpdate
		expectedPrices map[string]int64
	}{
		{
			name:        "a single held asset is marked up and the vault resumes",
			heldDenoms:  []string{"rwa"},
			startPaused: true,
			resume:      true,
			updates: []types.NAVUpdate{
				{Denom: "rwa", Price: sdk.NewInt64Coin(underlying, 4), Volume: sdkmath.NewInt(1), Source: "oracle"},
			},
			expectedPrices: map[string]int64{"rwa": 4},
		},
		{
			name:        "a held asset is written down to zero and the vault resumes",
			heldDenoms:  []string{"rwa"},
			startPaused: true,
			resume:      true,
			updates: []types.NAVUpdate{
				{Denom: "rwa", Price: sdk.NewInt64Coin(underlying, 0), Volume: sdkmath.NewInt(1), Source: "oracle"},
			},
			expectedPrices: map[string]int64{"rwa": 0},
		},
		{
			name:        "a book of held loans is restated in one batch and the vault resumes",
			heldDenoms:  []string{"loan1", "loan2", "loan3"},
			startPaused: true,
			resume:      true,
			updates: []types.NAVUpdate{
				{Denom: "loan1", Price: sdk.NewInt64Coin(underlying, 5), Volume: sdkmath.NewInt(1), Source: "oracle"},
				{Denom: "loan2", Price: sdk.NewInt64Coin(underlying, 1), Volume: sdkmath.NewInt(1), Source: "oracle"},
				{Denom: "loan3", Price: sdk.NewInt64Coin(underlying, 9), Volume: sdkmath.NewInt(1), Source: "oracle"},
			},
			expectedPrices: map[string]int64{"loan1": 5, "loan2": 1, "loan3": 9},
		},
		{
			name:         "a batch may price a denom the vault does not hold alongside one it does",
			heldDenoms:   []string{"loan1"},
			unheldDenoms: []string{"loan2"},
			startPaused:  true,
			resume:       true,
			updates: []types.NAVUpdate{
				{Denom: "loan1", Price: sdk.NewInt64Coin(underlying, 7), Volume: sdkmath.NewInt(1), Source: "oracle"},
				{Denom: "loan2", Price: sdk.NewInt64Coin(underlying, 3), Volume: sdkmath.NewInt(1), Source: "oracle"},
			},
			expectedPrices: map[string]int64{"loan1": 7, "loan2": 3},
		},
		{
			name:        "a batch without resume leaves the vault paused for a continuation",
			heldDenoms:  []string{"loan1", "loan2"},
			startPaused: true,
			updates: []types.NAVUpdate{
				{Denom: "loan1", Price: sdk.NewInt64Coin(underlying, 5), Volume: sdkmath.NewInt(1), Source: "oracle"},
				{Denom: "loan2", Price: sdk.NewInt64Coin(underlying, 6), Volume: sdkmath.NewInt(1), Source: "oracle"},
			},
			expectedPrices: map[string]int64{"loan1": 5, "loan2": 6},
		},
		{
			name:         "a live vault may pre-price denoms it does not hold without pausing",
			unheldDenoms: []string{"loan1", "loan2"},
			updates: []types.NAVUpdate{
				{Denom: "loan1", Price: sdk.NewInt64Coin(underlying, 5), Volume: sdkmath.NewInt(1), Source: "oracle"},
				{Denom: "loan2", Price: sdk.NewInt64Coin(underlying, 6), Volume: sdkmath.NewInt(1), Source: "oracle"},
			},
			expectedPrices: map[string]int64{"loan1": 5, "loan2": 6},
		},
	}

	for _, tc := range tests {
		s.Run(tc.name, func() {
			s.SetupTest()

			vault := s.setupBaseVault(underlying, share)
			for _, denom := range tc.heldDenoms {
				s.requireSimpleMarker(denom)
				s.fundPrincipal(vault, sdk.NewInt64Coin(denom, heldAmount))
				s.setVaultNAV(vault, denom, sdk.NewInt64Coin(underlying, seedPrice), seedVolume)
			}
			for _, denom := range tc.unheldDenoms {
				s.requireSimpleMarker(denom)
			}
			s.setNAVAuthority(vaultAddr, navAuthority.String())
			if tc.startPaused {
				s.pauseVaultBy(vaultAddr, navAuthority.String(), false)
			}

			_, err := keeper.NewMsgServer(s.simApp.VaultKeeper).RepriceVault(s.ctx, &types.MsgRepriceVaultRequest{
				Signer:       navAuthority.String(),
				VaultAddress: vaultAddr.String(),
				Navs:         tc.updates,
				Resume:       tc.resume,
			})
			s.Require().NoError(err, "RepriceVault should accept a %d-entry batch from the NAV authority", len(tc.updates))

			for denom, expectedPrice := range tc.expectedPrices {
				stored, storeErr := s.k.GetVaultNAV(s.ctx, vaultAddr, denom)
				s.Require().NoError(storeErr, "the NAV entry for %s should be readable after the batch", denom)
				s.Assert().Equal(expectedPrice, stored.Price.Amount.Int64(), "stored NAV price for %s after the batch", denom)
			}

			after, err := s.k.GetVault(s.ctx, vaultAddr)
			s.Require().NoError(err, "should get vault %s after RepriceVault", vaultAddr)
			if tc.resume {
				s.Assert().False(after.Paused, "RepriceVault with resume should leave the vault live so users can trade at the restated price")
				s.Assert().Empty(after.PausedBy, "resuming should clear the pause attribution")
				s.Assert().False(after.PausedForced, "resuming should clear the forced-pause marker")
				return
			}

			s.Assert().Equal(tc.startPaused, after.Paused, "RepriceVault without resume must leave the pause state exactly as it found it")
			if tc.startPaused {
				s.Assert().Equal(navAuthority.String(), after.PausedBy, "a continuation batch must preserve the pause attribution so a later batch can still resume")
			}
		})
	}
}

func (s *TestSuite) TestMsgServer_RepriceVault_ContinuationAcrossBatches() {
	underlying := "under"
	share := "vaultshares"
	vaultAddr := types.GetVaultAddress(share)
	navAuthority := sdk.AccAddress("navAuthorityAddr____")

	const (
		seedPrice  = 2
		seedVolume = 1
		heldAmount = 1_000
	)

	loans := []string{"loan1", "loan2", "loan3", "loan4"}
	vault := s.setupBaseVault(underlying, share)
	for _, denom := range loans {
		s.requireSimpleMarker(denom)
		s.fundPrincipal(vault, sdk.NewInt64Coin(denom, heldAmount))
		s.setVaultNAV(vault, denom, sdk.NewInt64Coin(underlying, seedPrice), seedVolume)
	}
	s.setNAVAuthority(vaultAddr, navAuthority.String())
	s.pauseVaultBy(vaultAddr, navAuthority.String(), false)

	msgServer := keeper.NewMsgServer(s.simApp.VaultKeeper)
	repriceChunk := func(denoms []string, price int64, resume bool) error {
		navs := make([]types.NAVUpdate, len(denoms))
		for i, denom := range denoms {
			navs[i] = types.NAVUpdate{Denom: denom, Price: sdk.NewInt64Coin(underlying, price), Volume: sdkmath.NewInt(1), Source: "oracle"}
		}
		_, err := msgServer.RepriceVault(s.ctx, &types.MsgRepriceVaultRequest{
			Signer:       navAuthority.String(),
			VaultAddress: vaultAddr.String(),
			Navs:         navs,
			Resume:       resume,
		})
		return err
	}

	s.Require().NoError(repriceChunk(loans[:2], 5, false), "the first continuation chunk should apply while the vault stays frozen")

	midway, err := s.k.GetVault(s.ctx, vaultAddr)
	s.Require().NoError(err, "should get vault %s between continuation chunks", vaultAddr)
	s.Require().True(midway.Paused, "the vault must stay frozen between chunks so no user trades against a half-restated book")

	s.Require().NoError(repriceChunk(loans[2:], 9, true), "the final chunk should apply and resume the vault")

	final, err := s.k.GetVault(s.ctx, vaultAddr)
	s.Require().NoError(err, "should get vault %s after the final chunk", vaultAddr)
	s.Assert().False(final.Paused, "the vault should reopen once, on the chunk that carries resume")

	for i, denom := range loans {
		expectedPrice := int64(5)
		if i >= 2 {
			expectedPrice = 9
		}
		stored, storeErr := s.k.GetVaultNAV(s.ctx, vaultAddr, denom)
		s.Require().NoError(storeErr, "the NAV entry for %s should be readable after the continuation", denom)
		s.Assert().Equal(expectedPrice, stored.Price.Amount.Int64(), "stored NAV price for %s after the continuation", denom)
	}
}

func (s *TestSuite) TestMsgServer_RepriceVault_Failures() {
	underlying := "under"
	share := "vaultshares"
	heldDenom := "rwa"
	vaultAddr := types.GetVaultAddress(share)
	navAuthority := sdk.AccAddress("navAuthorityAddr____")
	rotatedAuthority := sdk.AccAddress("rotatedAuthority____")

	const (
		seedPrice  = 2
		seedVolume = 1
		heldAmount = 1_000
	)

	tests := []struct {
		name              string
		stagePause        func()
		signer            func() string
		updates           []types.NAVUpdate
		resume            bool
		expectedErrSubstr string
	}{
		{
			name:              "the vault admin cannot reprice once a NAV authority is set",
			stagePause:        func() { s.pauseVaultBy(vaultAddr, s.adminAddr.String(), false) },
			signer:            func() string { return s.adminAddr.String() },
			resume:            true,
			expectedErrSubstr: "is not the vault NAV authority",
		},
		{
			name:              "a live vault has nothing to resume",
			stagePause:        func() {},
			signer:            func() string { return navAuthority.String() },
			resume:            true,
			expectedErrSubstr: "is not paused: pause it before repricing and resuming",
		},
		{
			name:              "a live vault cannot reprice a held asset even without resuming",
			stagePause:        func() {},
			signer:            func() string { return navAuthority.String() },
			expectedErrSubstr: "pause the vault to reprice a held asset",
		},
		{
			name:              "a forced pause is reserved for management review",
			stagePause:        func() { s.pauseVaultBy(vaultAddr, navAuthority.String(), true) },
			signer:            func() string { return navAuthority.String() },
			resume:            true,
			expectedErrSubstr: "is under a forced or automatic pause",
		},
		{
			name:              "an automatic pause is reserved for management review",
			stagePause:        func() { s.pauseVaultBy(vaultAddr, "", true) },
			signer:            func() string { return navAuthority.String() },
			resume:            true,
			expectedErrSubstr: "is under a forced or automatic pause",
		},
		{
			name:              "an operator pause cannot be cleared by the NAV authority",
			stagePause:        func() { s.pauseVaultBy(vaultAddr, s.adminAddr.String(), false) },
			signer:            func() string { return navAuthority.String() },
			resume:            true,
			expectedErrSubstr: "rather than the NAV authority",
		},
		{
			name: "a NAV authority rotated in after the pause cannot resume it",
			stagePause: func() {
				s.pauseVaultBy(vaultAddr, navAuthority.String(), false)
				s.setNAVAuthority(vaultAddr, rotatedAuthority.String())
			},
			signer:            func() string { return rotatedAuthority.String() },
			resume:            true,
			expectedErrSubstr: "rather than the NAV authority",
		},
		{
			name:       "a batch entry pricing the share denom is rejected",
			stagePause: func() { s.pauseVaultBy(vaultAddr, navAuthority.String(), false) },
			signer:     func() string { return navAuthority.String() },
			resume:     true,
			updates: []types.NAVUpdate{
				{Denom: share, Price: sdk.NewInt64Coin(underlying, 4), Volume: sdkmath.NewInt(1), Source: "oracle"},
			},
			expectedErrSubstr: "cannot set NAV for vault share denom",
		},
		{
			name:       "a batch fails whole when a later entry is bad",
			stagePause: func() { s.pauseVaultBy(vaultAddr, navAuthority.String(), false) },
			signer:     func() string { return navAuthority.String() },
			resume:     true,
			updates: []types.NAVUpdate{
				{Denom: heldDenom, Price: sdk.NewInt64Coin(underlying, 4), Volume: sdkmath.NewInt(1), Source: "oracle"},
				{Denom: share, Price: sdk.NewInt64Coin(underlying, 4), Volume: sdkmath.NewInt(1), Source: "oracle"},
			},
			expectedErrSubstr: "at index 1",
		},
	}

	for _, tc := range tests {
		s.Run(tc.name, func() {
			s.SetupTest()

			s.setupHeldNAVVault(underlying, share, heldDenom, sdk.NewInt64Coin(underlying, seedPrice), seedVolume, heldAmount)
			s.setNAVAuthority(vaultAddr, navAuthority.String())
			tc.stagePause()

			updates := tc.updates
			if updates == nil {
				updates = []types.NAVUpdate{
					{Denom: heldDenom, Price: sdk.NewInt64Coin(underlying, 4), Volume: sdkmath.NewInt(1), Source: "oracle"},
				}
			}

			wasPaused := func() bool {
				vault, err := s.k.GetVault(s.ctx, vaultAddr)
				s.Require().NoError(err, "should get vault %s before RepriceVault", vaultAddr)
				return vault.Paused
			}()

			_, err := keeper.NewMsgServer(s.simApp.VaultKeeper).RepriceVault(s.ctx, &types.MsgRepriceVaultRequest{
				Signer:       tc.signer(),
				VaultAddress: vaultAddr.String(),
				Navs:         updates,
				Resume:       tc.resume,
			})
			s.Require().ErrorContains(err, tc.expectedErrSubstr, "RepriceVault should refuse this request")

			after, err := s.k.GetVault(s.ctx, vaultAddr)
			s.Require().NoError(err, "should get vault %s after the rejected RepriceVault", vaultAddr)
			s.Assert().Equal(wasPaused, after.Paused,
				"a rejected RepriceVault must leave the pause state untouched, so a failed batch can never reopen the vault mid-restatement")
		})
	}
}

func (s *TestSuite) TestMsgServer_RepriceVault_OperatorPauseAllowsRepriceWithoutResume() {
	underlying := "under"
	share := "vaultshares"
	heldDenom := "rwa"
	vaultAddr := types.GetVaultAddress(share)
	navAuthority := sdk.AccAddress("navAuthorityAddr____")

	s.setupHeldNAVVault(underlying, share, heldDenom, sdk.NewInt64Coin(underlying, 2), 1, 1_000)
	s.setNAVAuthority(vaultAddr, navAuthority.String())
	s.pauseVaultBy(vaultAddr, s.adminAddr.String(), false)

	_, err := keeper.NewMsgServer(s.simApp.VaultKeeper).RepriceVault(s.ctx, &types.MsgRepriceVaultRequest{
		Signer:       navAuthority.String(),
		VaultAddress: vaultAddr.String(),
		Navs: []types.NAVUpdate{
			{Denom: heldDenom, Price: sdk.NewInt64Coin(underlying, 1), Volume: sdkmath.NewInt(1), Source: "oracle"},
		},
	})
	s.Require().NoError(err, "the NAV authority should be able to write a held asset down during an operator pause, which is the incident-response flow")

	stored, err := s.k.GetVaultNAV(s.ctx, vaultAddr, heldDenom)
	s.Require().NoError(err, "the NAV entry for %s should be readable after the write-down", heldDenom)
	s.Assert().Equal(int64(1), stored.Price.Amount.Int64(), "the write-down should be applied during the operator pause")

	after, err := s.k.GetVault(s.ctx, vaultAddr)
	s.Require().NoError(err, "should get vault %s after the write-down", vaultAddr)
	s.Assert().True(after.Paused, "an operator pause must survive a NAV authority reprice; only the admin or asset manager may lift it")
	s.Assert().Equal(s.adminAddr.String(), after.PausedBy, "the operator's pause attribution must be preserved")
}

func (s *TestSuite) TestMsgServer_PauseVault_NAVAuthorityMayPauseButNotUnpause() {
	underlying := "under"
	share := "vaultshares"
	vaultAddr := types.GetVaultAddress(share)
	navAuthority := sdk.AccAddress("navAuthorityAddr____")

	s.setupBaseVault(underlying, share)
	s.setNAVAuthority(vaultAddr, navAuthority.String())

	msgServer := keeper.NewMsgServer(s.simApp.VaultKeeper)

	_, err := msgServer.PauseVault(s.ctx, &types.MsgPauseVaultRequest{
		Authority:    navAuthority.String(),
		VaultAddress: vaultAddr.String(),
		Reason:       "observed a depeg on a priced asset",
	})
	s.Require().NoError(err, "the NAV authority should be able to pause, since a pricing oracle sees a depeg first")

	paused, err := s.k.GetVault(s.ctx, vaultAddr)
	s.Require().NoError(err, "should get vault %s after the NAV authority paused it", vaultAddr)
	s.Require().True(paused.Paused, "the vault should be paused after the NAV authority paused it")
	s.Assert().Equal(navAuthority.String(), paused.PausedBy, "the pause should be attributed to the NAV authority that took it")
	s.Assert().False(paused.PausedForced, "a strict pause should not be marked forced")

	_, err = msgServer.UnpauseVault(s.ctx, &types.MsgUnpauseVaultRequest{
		Authority:    navAuthority.String(),
		VaultAddress: vaultAddr.String(),
	})
	s.Require().ErrorContains(err, "unauthorized authority",
		"the NAV authority must not be able to unpause outright; resuming is a management decision except through RepriceVault")

	stillPaused, err := s.k.GetVault(s.ctx, vaultAddr)
	s.Require().NoError(err, "should get vault %s after the rejected unpause", vaultAddr)
	s.Assert().True(stillPaused.Paused, "the rejected unpause must leave the vault paused")
}

func (s *TestSuite) TestMsgServer_RemoveVaultNAV() {
	underlying := "under"
	share := "vaultshares"
	navDenom := "rwa"
	admin := s.adminAddr
	vaultAddr := types.GetVaultAddress(share)

	seedPrice := sdk.NewInt64Coin(underlying, 250)
	seedVolume := sdkmath.NewInt(5)

	seedUnheldNAV := func() {
		vault := s.setupBaseVault(underlying, share)
		s.requireSimpleMarker(navDenom)
		s.ctx = s.ctx.WithBlockHeight(100)
		s.setVaultNAV(vault, navDenom, seedPrice, seedVolume.Int64())
	}

	testDef := msgServerTestDef[types.MsgRemoveVaultNAVRequest, types.MsgRemoveVaultNAVResponse, string]{
		endpointName:     "RemoveVaultNAV",
		endpoint:         keeper.NewMsgServer(s.simApp.VaultKeeper).RemoveVaultNAV,
		expectedResponse: &types.MsgRemoveVaultNAVResponse{},
		postCheck: func(_ *types.MsgRemoveVaultNAVRequest, expectRemoved string) {
			_, err := s.k.GetVaultNAV(s.ctx, vaultAddr, navDenom)
			if expectRemoved == "" {
				s.Assert().NoError(err, "post-check: NAV entry for %s should survive a rejected removal", navDenom)
				return
			}
			s.Assert().ErrorIs(err, collections.ErrNotFound, "post-check: NAV entry for %s should be gone", navDenom)
		},
	}

	tests := []msgServerTestCase[types.MsgRemoveVaultNAVRequest, string]{
		{
			name:  "NAV authority revokes the price of a denom the vault never acquired",
			setup: seedUnheldNAV,
			msg: types.MsgRemoveVaultNAVRequest{
				Signer:       admin.String(),
				VaultAddress: vaultAddr.String(),
				Denom:        navDenom,
			},
			postCheckArgs: "removed",
			expectedEvents: sdk.Events{
				sdk.NewEvent("provlabs.vault.v1.EventNAVRemoved",
					sdk.NewAttribute("denom", navDenom),
					sdk.NewAttribute("last_price", seedPrice.String()),
					sdk.NewAttribute("last_volume", seedVolume.String()),
					sdk.NewAttribute("signer", admin.String()),
					sdk.NewAttribute("vault_address", vaultAddr.String()),
				),
			},
		},
		{
			name: "vault does not exist",
			msg: types.MsgRemoveVaultNAVRequest{
				Signer:       admin.String(),
				VaultAddress: types.GetVaultAddress("missing").String(),
				Denom:        navDenom,
			},
			expectedErrSubstrs: []string{"failed to get vault"},
		},
		{
			name:  "signer that is not the NAV authority cannot remove",
			setup: seedUnheldNAV,
			msg: types.MsgRemoveVaultNAVRequest{
				Signer:       s.assetManagerAddr.String(),
				VaultAddress: vaultAddr.String(),
				Denom:        navDenom,
			},
			expectedErrSubstrs: []string{"failed to validate NAV authority", "is not the vault NAV authority"},
		},
		{
			name: "denom with no NAV entry cannot be removed",
			setup: func() {
				s.setupBaseVault(underlying, share)
				s.requireSimpleMarker(navDenom)
			},
			msg: types.MsgRemoveVaultNAVRequest{
				Signer:       admin.String(),
				VaultAddress: vaultAddr.String(),
				Denom:        navDenom,
			},
			expectedErrSubstrs: []string{"failed to remove vault NAV", "failed to get internal NAV for denom"},
		},
		{
			name: "denom the vault still holds must be written down instead of removed",
			setup: func() {
				seedUnheldNAV()
				vault, err := s.k.GetVault(s.ctx, vaultAddr)
				s.Require().NoError(err, "failed to get vault %s to fund its principal marker", vaultAddr)
				s.Require().NoError(
					FundAccount(s.ctx, s.simApp, vault.PrincipalMarkerAddress(), sdk.NewCoins(sdk.NewInt64Coin(navDenom, 3))),
					"failed to fund the principal marker with %s", navDenom,
				)
			},
			msg: types.MsgRemoveVaultNAVRequest{
				Signer:       admin.String(),
				VaultAddress: vaultAddr.String(),
				Denom:        navDenom,
			},
			expectedErrSubstrs: []string{"still holds", "write a held asset down through UpdateVaultNAV"},
		},
		{
			name: "paused vault allows the removal of an unheld denom",
			setup: func() {
				seedUnheldNAV()
				s.pauseVault(vaultAddr)
			},
			msg: types.MsgRemoveVaultNAVRequest{
				Signer:       admin.String(),
				VaultAddress: vaultAddr.String(),
				Denom:        navDenom,
			},
			postCheckArgs: "removed",
			expectedEvents: sdk.Events{
				sdk.NewEvent("provlabs.vault.v1.EventNAVRemoved",
					sdk.NewAttribute("denom", navDenom),
					sdk.NewAttribute("last_price", seedPrice.String()),
					sdk.NewAttribute("last_volume", seedVolume.String()),
					sdk.NewAttribute("signer", admin.String()),
					sdk.NewAttribute("vault_address", vaultAddr.String()),
				),
			},
		},
		{
			name: "paused vault still refuses to remove a denom it holds",
			setup: func() {
				seedUnheldNAV()
				vault := s.pauseVault(vaultAddr)
				s.Require().NoError(
					FundAccount(s.ctx, s.simApp, vault.PrincipalMarkerAddress(), sdk.NewCoins(sdk.NewInt64Coin(navDenom, 3))),
					"failed to fund the principal marker with %s", navDenom,
				)
			},
			msg: types.MsgRemoveVaultNAVRequest{
				Signer:       admin.String(),
				VaultAddress: vaultAddr.String(),
				Denom:        navDenom,
			},
			expectedErrSubstrs: []string{"still holds", "write a held asset down through UpdateVaultNAV"},
		},
	}

	for _, tc := range tests {
		s.Run(tc.name, func() {
			runMsgServerTestCase(s, testDef, tc)
		})
	}
}

// TestMsgServer_UpdateNAVAuthority verifies that the vault admin can rotate the
// NAV authority and that the rotation is persisted on the vault account.
func (s *TestSuite) TestMsgServer_UpdateNAVAuthority() {
	underlying := "under"
	share := "vaultshares"
	admin := s.adminAddr
	newAuthority := s.CreateAndFundAccount(sdk.NewInt64Coin("stake", 1000))
	vaultAddr := types.GetVaultAddress(share)

	testDef := msgServerTestDef[types.MsgUpdateNAVAuthorityRequest, types.MsgUpdateNAVAuthorityResponse, string]{
		endpointName:     "UpdateNAVAuthority",
		endpoint:         keeper.NewMsgServer(s.simApp.VaultKeeper).UpdateNAVAuthority,
		expectedResponse: &types.MsgUpdateNAVAuthorityResponse{},
		postCheck: func(_ *types.MsgUpdateNAVAuthorityRequest, expectedAuthority string) {
			vault, err := s.k.GetVault(s.ctx, vaultAddr)
			s.Require().NoError(err, "post-check: failed to get vault")
			s.Assert().Equal(expectedAuthority, vault.NavAuthority, "post-check: nav authority mismatch")
			s.Assert().Equal(expectedAuthority, vault.GetNAVAuthority(), "post-check: resolved nav authority mismatch")
		},
	}

	tc := msgServerTestCase[types.MsgUpdateNAVAuthorityRequest, string]{
		name: "admin rotates nav authority",
		setup: func() {
			s.setupBaseVault(underlying, share)
		},
		msg: types.MsgUpdateNAVAuthorityRequest{
			Signer:       admin.String(),
			VaultAddress: vaultAddr.String(),
			NewAuthority: newAuthority.String(),
		},
		postCheckArgs: newAuthority.String(),
		expectedEvents: sdk.Events{
			sdk.NewEvent("provlabs.vault.v1.EventNAVAuthorityUpdated",
				sdk.NewAttribute("admin", admin.String()),
				sdk.NewAttribute("new_authority", newAuthority.String()),
				sdk.NewAttribute("vault_address", vaultAddr.String()),
			),
		},
	}

	s.Run(tc.name, func() {
		runMsgServerTestCase(s, testDef, tc)
	})
}

// TestMsgServer_UpdateNAVAuthority_Failures covers admin enforcement and the
// missing-vault path for the UpdateNAVAuthority handler.
func (s *TestSuite) TestMsgServer_UpdateNAVAuthority_Failures() {
	underlying := "under"
	share := "vaultshares"
	admin := s.adminAddr
	other := s.CreateAndFundAccount(sdk.NewInt64Coin("stake", 1000))
	vaultAddr := types.GetVaultAddress(share)

	setup := func() {
		s.setupBaseVault(underlying, share)
	}

	testDef := msgServerTestDef[types.MsgUpdateNAVAuthorityRequest, types.MsgUpdateNAVAuthorityResponse, any]{
		endpointName: "UpdateNAVAuthority",
		endpoint:     keeper.NewMsgServer(s.simApp.VaultKeeper).UpdateNAVAuthority,
		postCheck:    nil,
	}

	tests := []msgServerTestCase[types.MsgUpdateNAVAuthorityRequest, any]{
		{
			name:  "vault does not exist",
			setup: func() {},
			msg: types.MsgUpdateNAVAuthorityRequest{
				Signer:       admin.String(),
				VaultAddress: types.GetVaultAddress("doesnotexist").String(),
				NewAuthority: other.String(),
			},
			expectedErrSubstrs: []string{"vault not found"},
		},
		{
			name:  "signer is not the vault admin",
			setup: setup,
			msg: types.MsgUpdateNAVAuthorityRequest{
				Signer:       other.String(),
				VaultAddress: vaultAddr.String(),
				NewAuthority: other.String(),
			},
			expectedErrSubstrs: []string{"unauthorized", "is not the vault admin"},
		},
	}

	for _, tc := range tests {
		s.Run(tc.name, func() {
			runMsgServerTestCase(s, testDef, tc)
		})
	}
}

// TestMsgServer_UpdateNAVAuthority_RotationChangesNAVAuthority verifies that
// after a rotation only the new authority can update NAVs and the prior admin
// loses NAV authority.
func (s *TestSuite) TestMsgServer_UpdateNAVAuthority_RotationChangesNAVAuthority() {
	underlying := "under"
	share := "vaultshares"
	admin := s.adminAddr
	oracle := s.CreateAndFundAccount(sdk.NewInt64Coin("stake", 1000))
	vaultAddr := types.GetVaultAddress(share)

	s.setupBaseVault(underlying, share)
	s.requireSimpleMarker("rwa")
	msgServer := keeper.NewMsgServer(s.simApp.VaultKeeper)

	_, err := msgServer.UpdateNAVAuthority(s.ctx, &types.MsgUpdateNAVAuthorityRequest{
		Signer:       admin.String(),
		VaultAddress: vaultAddr.String(),
		NewAuthority: oracle.String(),
	})
	s.Require().NoError(err, "admin should be able to rotate the nav authority")

	_, err = msgServer.UpdateVaultNAV(s.ctx, &types.MsgUpdateVaultNAVRequest{
		Signer:       admin.String(),
		VaultAddress: vaultAddr.String(),
		Denom:        "rwa",
		Price:        sdk.NewInt64Coin(underlying, 100),
		Volume:       sdkmath.NewInt(1),
	})
	s.Require().Error(err, "former admin should no longer be the nav authority")
	s.Assert().Contains(err.Error(), "is not the vault NAV authority", "unexpected error for stale authority")

	_, err = msgServer.UpdateVaultNAV(s.ctx, &types.MsgUpdateVaultNAVRequest{
		Signer:       oracle.String(),
		VaultAddress: vaultAddr.String(),
		Denom:        "rwa",
		Price:        sdk.NewInt64Coin(underlying, 100),
		Volume:       sdkmath.NewInt(1),
	})
	s.Require().NoError(err, "new nav authority should be able to update NAVs")

	nav, err := s.k.GetVaultNAV(s.ctx, vaultAddr, "rwa")
	s.Require().NoError(err, "NAV should exist after the new authority update")
	s.Assert().Equal(sdk.NewInt64Coin(underlying, 100), nav.Price, "NAV price mismatch")
}

// TestMsgServer_UpdateNAVAuthority_ResetToEmptyFallsBackToAdmin verifies that an
// UpdateNAVAuthority message with an empty new authority clears the explicit NAV
// authority, after which the vault admin again resolves as the NAV authority and
// the previously delegated authority loses its NAV update rights.
func (s *TestSuite) TestMsgServer_UpdateNAVAuthority_ResetToEmptyFallsBackToAdmin() {
	underlying := "under"
	share := "vaultshares"
	admin := s.adminAddr
	oracle := s.CreateAndFundAccount(sdk.NewInt64Coin("stake", 1000))
	vaultAddr := types.GetVaultAddress(share)

	s.setupBaseVault(underlying, share)
	s.requireSimpleMarker("rwa")
	msgServer := keeper.NewMsgServer(s.simApp.VaultKeeper)

	_, err := msgServer.UpdateNAVAuthority(s.ctx, &types.MsgUpdateNAVAuthorityRequest{
		Signer:       admin.String(),
		VaultAddress: vaultAddr.String(),
		NewAuthority: oracle.String(),
	})
	s.Require().NoError(err, "admin should be able to delegate the nav authority to the oracle")

	_, err = msgServer.UpdateNAVAuthority(s.ctx, &types.MsgUpdateNAVAuthorityRequest{
		Signer:       admin.String(),
		VaultAddress: vaultAddr.String(),
		NewAuthority: "",
	})
	s.Require().NoError(err, "admin should be able to reset the nav authority to empty")

	vault, err := s.k.GetVault(s.ctx, vaultAddr)
	s.Require().NoError(err, "failed to get vault after resetting the nav authority")
	s.Assert().Empty(vault.NavAuthority, "reset should clear the explicit nav authority")
	s.Assert().Equal(admin.String(), vault.GetNAVAuthority(), "cleared nav authority should fall back to the vault admin")

	_, err = msgServer.UpdateVaultNAV(s.ctx, &types.MsgUpdateVaultNAVRequest{
		Signer:       oracle.String(),
		VaultAddress: vaultAddr.String(),
		Denom:        "rwa",
		Price:        sdk.NewInt64Coin(underlying, 100),
		Volume:       sdkmath.NewInt(1),
	})
	s.Require().Error(err, "the former delegated authority should lose NAV update rights after the reset")
	s.Assert().Contains(err.Error(), "is not the vault NAV authority", "unexpected error for the former authority")

	_, err = msgServer.UpdateVaultNAV(s.ctx, &types.MsgUpdateVaultNAVRequest{
		Signer:       admin.String(),
		VaultAddress: vaultAddr.String(),
		Denom:        "rwa",
		Price:        sdk.NewInt64Coin(underlying, 100),
		Volume:       sdkmath.NewInt(1),
	})
	s.Require().NoError(err, "the admin should regain NAV update rights after the reset")

	nav, err := s.k.GetVaultNAV(s.ctx, vaultAddr, "rwa")
	s.Require().NoError(err, "NAV should exist after the admin update following the reset")
	s.Assert().Equal(sdk.NewInt64Coin(underlying, 100), nav.Price, "NAV price mismatch after reset")
}

// TestMsgServer_UpdateNAVAuthority_NoOpWhenUnchanged verifies that calling
// UpdateNAVAuthority with the current NAV authority is a no-op: the call
// succeeds, the vault is left untouched, and no EventNAVAuthorityUpdated event
// is emitted.
func (s *TestSuite) TestMsgServer_UpdateNAVAuthority_NoOpWhenUnchanged() {
	underlying := "under"
	share := "vaultshares"
	admin := s.adminAddr
	oracle := s.CreateAndFundAccount(sdk.NewInt64Coin("stake", 1000))
	vaultAddr := types.GetVaultAddress(share)

	s.setupBaseVault(underlying, share)
	msgServer := keeper.NewMsgServer(s.simApp.VaultKeeper)

	_, err := msgServer.UpdateNAVAuthority(s.ctx, &types.MsgUpdateNAVAuthorityRequest{
		Signer:       admin.String(),
		VaultAddress: vaultAddr.String(),
		NewAuthority: oracle.String(),
	})
	s.Require().NoError(err, "initial rotation should succeed")

	vaultBefore, err := s.k.GetVault(s.ctx, vaultAddr)
	s.Require().NoError(err, "failed to read vault after initial rotation")

	s.ctx = s.ctx.WithEventManager(sdk.NewEventManager())
	_, err = msgServer.UpdateNAVAuthority(s.ctx, &types.MsgUpdateNAVAuthorityRequest{
		Signer:       admin.String(),
		VaultAddress: vaultAddr.String(),
		NewAuthority: oracle.String(),
	})
	s.Require().NoError(err, "re-setting the NAV authority to its current value should be a no-op")

	for _, ev := range s.ctx.EventManager().Events() {
		s.Assert().NotEqualf(
			"provlabs.vault.v1.EventNAVAuthorityUpdated", ev.Type,
			"no-op UpdateNAVAuthority should not emit EventNAVAuthorityUpdated",
		)
	}

	vaultAfter, err := s.k.GetVault(s.ctx, vaultAddr)
	s.Require().NoError(err, "failed to read vault after no-op rotation")
	s.Assert().Equal(vaultBefore.NavAuthority, vaultAfter.NavAuthority, "no-op rotation should leave NavAuthority untouched")
}

func (s *TestSuite) TestMsgServer_AcceptAsset_Inbound() {
	underlying, share, asset := "under", "vshare", "rwacoin"
	externalID := "p2p-inbound"

	sourceAmount := sdk.NewCoins(sdk.NewInt64Coin(asset, 10))
	targetAmount := sdk.NewCoins(sdk.NewInt64Coin(underlying, 5))
	vault, principalAddr, source, approved := s.setupAcceptAssetScenario(acceptAssetScenario{
		underlying:    underlying,
		share:         share,
		assetMarker:   asset,
		seedNav:       &types.VaultNAV{Denom: asset, Price: sdk.NewInt64Coin(underlying, 5), Volume: sdkmath.NewInt(10)},
		fundSource:    sourceAmount,
		fundPrincipal: targetAmount,
		sourceAmount:  sourceAmount,
		targetAmount:  targetAmount,
		externalID:    externalID,
	})
	vaultAddr := vault.GetAddress()

	s.ctx = s.ctx.WithEventManager(sdk.NewEventManager())
	resp, err := keeper.NewMsgServer(s.simApp.VaultKeeper).AcceptAsset(s.ctx, &types.MsgAcceptAssetRequest{
		Authority:    s.assetManagerAddr.String(),
		VaultAddress: vaultAddr.String(),
		Payment:      approved,
	})
	s.Require().NoError(err, "AcceptAsset inbound should succeed")
	s.Assert().Equal(&types.MsgAcceptAssetResponse{}, resp, "AcceptAsset inbound response")

	s.assertBalance(source, asset, sdkmath.NewInt(0))
	s.assertBalance(source, underlying, sdkmath.NewInt(5))
	s.assertBalance(principalAddr, asset, sdkmath.NewInt(10))
	s.assertBalance(principalAddr, underlying, sdkmath.NewInt(0))
	s.assertBalance(vaultAddr, asset, sdkmath.NewInt(0))
	s.assertBalance(vaultAddr, underlying, sdkmath.NewInt(0))

	s.requireTypedEventEmitted(types.NewEventAssetAccepted(vaultAddr.String(), source.String(), externalID, sourceAmount, targetAmount, types.AssetDirectionInbound))
}

func (s *TestSuite) TestMsgServer_AcceptAsset_Outbound() {
	underlying, share, asset := "under", "vshare", "rwacoin"
	externalID := "p2p-outbound"

	sourceAmount := sdk.NewCoins(sdk.NewInt64Coin(underlying, 5))
	targetAmount := sdk.NewCoins(sdk.NewInt64Coin(asset, 10))
	seededNAV := types.VaultNAV{Denom: asset, Price: sdk.NewInt64Coin(underlying, 5), Volume: sdkmath.NewInt(10)}
	vault, principalAddr, source, approved := s.setupAcceptAssetScenario(acceptAssetScenario{
		underlying:    underlying,
		share:         share,
		assetMarker:   asset,
		seedNav:       &seededNAV,
		fundSource:    sourceAmount,
		fundPrincipal: targetAmount,
		sourceAmount:  sourceAmount,
		targetAmount:  targetAmount,
		externalID:    externalID,
	})
	vaultAddr := vault.GetAddress()

	s.ctx = s.ctx.WithEventManager(sdk.NewEventManager())
	resp, err := keeper.NewMsgServer(s.simApp.VaultKeeper).AcceptAsset(s.ctx, &types.MsgAcceptAssetRequest{
		Authority:    s.assetManagerAddr.String(),
		VaultAddress: vaultAddr.String(),
		Payment:      approved,
	})
	s.Require().NoError(err, "AcceptAsset outbound should succeed")
	s.Assert().Equal(&types.MsgAcceptAssetResponse{}, resp, "AcceptAsset outbound response")

	s.assertBalance(source, underlying, sdkmath.NewInt(0))
	s.assertBalance(source, asset, sdkmath.NewInt(10))
	s.assertBalance(principalAddr, asset, sdkmath.NewInt(0))
	s.assertBalance(principalAddr, underlying, sdkmath.NewInt(5))
	s.assertBalance(vaultAddr, asset, sdkmath.NewInt(0))
	s.assertBalance(vaultAddr, underlying, sdkmath.NewInt(0))

	s.requireTypedEventEmitted(types.NewEventAssetAccepted(vaultAddr.String(), source.String(), externalID, sourceAmount, targetAmount, types.AssetDirectionOutbound))

	s.requireTypedEventEmitted(types.NewEventNAVRemoved(vaultAddr.String(), seededNAV, ""))
	_, err = s.k.GetVaultNAV(s.ctx, vaultAddr, asset)
	s.Assert().ErrorIs(err, collections.ErrNotFound, "NAV entry for %s should be removed after the draining outbound settlement", asset)
}

func (s *TestSuite) TestMsgServer_AcceptAsset_OutboundStaysCommittedWhenDrainedNAVIsAlreadyAbsent() {
	underlying, share, asset := "under", "vshare", "rwacoin"
	externalID := "p2p-outbound-nav-absent"

	sourceAmount := sdk.NewCoins(sdk.NewInt64Coin(underlying, 5))
	targetAmount := sdk.NewCoins(sdk.NewInt64Coin(asset, 10))
	vault, principalAddr, source, approved := s.setupAcceptAssetScenario(acceptAssetScenario{
		underlying:    underlying,
		share:         share,
		assetMarker:   asset,
		seedNav:       &types.VaultNAV{Denom: asset, Price: sdk.NewInt64Coin(underlying, 5), Volume: sdkmath.NewInt(10)},
		fundSource:    sourceAmount,
		fundPrincipal: targetAmount,
		sourceAmount:  sourceAmount,
		targetAmount:  targetAmount,
		externalID:    externalID,
	})
	vaultAddr := vault.GetAddress()

	s.ctx = s.ctx.WithEventManager(sdk.NewEventManager())
	resp, err := keeper.NewMsgServer(s.simApp.VaultKeeper).AcceptAsset(s.ctx, &types.MsgAcceptAssetRequest{
		Authority:    s.assetManagerAddr.String(),
		VaultAddress: vaultAddr.String(),
		Payment:      approved,
	})
	s.Require().NoError(err, "AcceptAsset outbound should succeed")
	s.Assert().Equal(&types.MsgAcceptAssetResponse{}, resp, "AcceptAsset outbound response")

	_, err = s.k.GetVaultNAV(s.ctx, vaultAddr, asset)
	s.Require().ErrorIs(err, collections.ErrNotFound, "the draining outbound settlement should leave no NAV entry for %s", asset)

	s.Require().NoError(
		s.k.TestAccessor_removeDrainedSettlementNAV(s.T(), s.ctx, vault, asset, types.AssetDirectionOutbound),
		"the drained-NAV cleanup must be best-effort and must not roll back the committed settlement once the NAV entry for %s is already absent", asset,
	)

	s.assertBalance(source, underlying, sdkmath.NewInt(0))
	s.assertBalance(source, asset, sdkmath.NewInt(10))
	s.assertBalance(principalAddr, asset, sdkmath.NewInt(0))
	s.assertBalance(principalAddr, underlying, sdkmath.NewInt(5))
	s.assertBalance(vaultAddr, asset, sdkmath.NewInt(0))
	s.assertBalance(vaultAddr, underlying, sdkmath.NewInt(0))
}

func (s *TestSuite) TestMsgServer_AcceptAsset_ZeroPriceOutbound() {
	underlying, share, asset := "under", "vshare", "rwacoin"
	externalID := "p2p-outbound-zero"

	sourceAmount := sdk.NewCoins()
	targetAmount := sdk.NewCoins(sdk.NewInt64Coin(asset, 10))
	seededNAV := types.VaultNAV{Denom: asset, Price: sdk.NewInt64Coin(underlying, 0), Volume: sdkmath.NewInt(10)}
	vault, principalAddr, source, approved := s.setupAcceptAssetScenario(acceptAssetScenario{
		underlying:    underlying,
		share:         share,
		assetMarker:   asset,
		seedNav:       &seededNAV,
		fundSource:    sdk.NewCoins(sdk.NewInt64Coin(underlying, 1)),
		fundPrincipal: targetAmount,
		sourceAmount:  sourceAmount,
		targetAmount:  targetAmount,
		externalID:    externalID,
	})
	vaultAddr := vault.GetAddress()

	s.ctx = s.ctx.WithEventManager(sdk.NewEventManager())
	resp, err := keeper.NewMsgServer(s.simApp.VaultKeeper).AcceptAsset(s.ctx, &types.MsgAcceptAssetRequest{
		Authority:    s.assetManagerAddr.String(),
		VaultAddress: vaultAddr.String(),
		Payment:      approved,
	})
	s.Require().NoError(err, "AcceptAsset zero-price outbound should succeed")
	s.Assert().Equal(&types.MsgAcceptAssetResponse{}, resp, "AcceptAsset zero-price outbound response")

	s.assertBalance(source, asset, sdkmath.NewInt(10))
	s.assertBalance(source, underlying, sdkmath.NewInt(1))
	s.assertBalance(principalAddr, asset, sdkmath.NewInt(0))
	s.assertBalance(principalAddr, underlying, sdkmath.NewInt(0))
	s.assertBalance(vaultAddr, asset, sdkmath.NewInt(0))
	s.assertBalance(vaultAddr, underlying, sdkmath.NewInt(0))

	s.requireTypedEventEmitted(types.NewEventAssetAccepted(vaultAddr.String(), source.String(), externalID, sourceAmount, targetAmount, types.AssetDirectionOutbound))

	s.requireTypedEventEmitted(types.NewEventNAVRemoved(vaultAddr.String(), seededNAV, ""))
	_, err = s.k.GetVaultNAV(s.ctx, vaultAddr, asset)
	s.Assert().ErrorIs(err, collections.ErrNotFound, "NAV entry for %s should be removed after the draining zero-price outbound settlement", asset)
}

func (s *TestSuite) TestMsgServer_AcceptAsset_ZeroPriceInbound() {
	underlying, share, asset := "under", "vshare", "rwacoin"
	externalID := "p2p-inbound-zero"

	sourceAmount := sdk.NewCoins(sdk.NewInt64Coin(asset, 10))
	targetAmount := sdk.NewCoins()
	vault, principalAddr, source, approved := s.setupAcceptAssetScenario(acceptAssetScenario{
		underlying:   underlying,
		share:        share,
		assetMarker:  asset,
		seedNav:      &types.VaultNAV{Denom: asset, Price: sdk.NewInt64Coin(underlying, 0), Volume: sdkmath.NewInt(10), Source: "oracle"},
		fundSource:   sourceAmount,
		sourceAmount: sourceAmount,
		targetAmount: targetAmount,
		externalID:   externalID,
	})
	vaultAddr := vault.GetAddress()

	s.ctx = s.ctx.WithEventManager(sdk.NewEventManager())
	resp, err := keeper.NewMsgServer(s.simApp.VaultKeeper).AcceptAsset(s.ctx, &types.MsgAcceptAssetRequest{
		Authority:    s.assetManagerAddr.String(),
		VaultAddress: vaultAddr.String(),
		Payment:      approved,
	})
	s.Require().NoError(err, "AcceptAsset zero-price inbound should succeed")
	s.Assert().Equal(&types.MsgAcceptAssetResponse{}, resp, "AcceptAsset zero-price inbound response")

	s.assertBalance(source, asset, sdkmath.NewInt(0))
	s.assertBalance(source, underlying, sdkmath.NewInt(0))
	s.assertBalance(principalAddr, asset, sdkmath.NewInt(10))
	s.assertBalance(principalAddr, underlying, sdkmath.NewInt(0))
	s.assertBalance(vaultAddr, asset, sdkmath.NewInt(0))
	s.assertBalance(vaultAddr, underlying, sdkmath.NewInt(0))

	s.requireTypedEventEmitted(types.NewEventAssetAccepted(vaultAddr.String(), source.String(), externalID, sourceAmount, targetAmount, types.AssetDirectionInbound))

	stored, err := s.k.GetVaultNAV(s.ctx, vaultAddr, asset)
	s.Require().NoError(err, "NAV entry for %s should exist after the zero-price inbound settlement", asset)
	s.Assert().Equal(sdk.NewInt64Coin(underlying, 0), stored.Price, "stored NAV price should be the zero underlying coin")
	s.Assert().Equal(sourceAmount[0].Amount, stored.Volume, "stored NAV volume should be the asset amount")
	s.Assert().Equal("oracle", stored.Source, "settlement must not reattribute the NAV source away from the authority that priced the asset")
}

func (s *TestSuite) TestMsgServer_AcceptAsset_RestrictedMarker() {
	underlying, share, restrictedDenom := "under", "vshare", "restrictedrwa"
	externalID := "p2p-restricted"

	tests := []struct {
		name                      string
		grantVaultMarkerTransfer  bool
		grantSourceMarkerTransfer bool
		expectedErrSubstrs        []string
	}{
		{
			name:                      "vault and source both hold marker transfer access, restricted settlement succeeds",
			grantVaultMarkerTransfer:  true,
			grantSourceMarkerTransfer: true,
		},
		{
			name:                     "source without marker transfer access, agentless exchange escrow transfer is blocked",
			grantVaultMarkerTransfer: true,
			expectedErrSubstrs:       []string{"failed to accept payment", "does not have transfer permissions"},
		},
		{
			name:                      "vault without marker transfer access still settles because the internal hop to principal is bypassed",
			grantSourceMarkerTransfer: true,
		},
	}

	for _, tc := range tests {
		s.Run(tc.name, func() {
			origCtx := s.ctx
			defer func() { s.ctx = origCtx }()
			s.ctx, _ = s.ctx.CacheContext()

			vault, principalAddr := s.setupAssetSettlementVault(underlying, share)
			vaultAddr := vault.GetAddress()
			source := s.CreateAndFundAccount(sdk.NewInt64Coin("stake", 1))

			grants := []markertypes.AccessGrant{
				{Address: s.adminAddr.String(), Permissions: markertypes.AccessList{
					markertypes.Access_Mint, markertypes.Access_Burn, markertypes.Access_Withdraw,
					markertypes.Access_Admin, markertypes.Access_Transfer,
				}},
			}
			if tc.grantVaultMarkerTransfer {
				grants = append(grants, markertypes.AccessGrant{Address: vaultAddr.String(), Permissions: markertypes.AccessList{markertypes.Access_Transfer}})
			}
			if tc.grantSourceMarkerTransfer {
				grants = append(grants, markertypes.AccessGrant{Address: source.String(), Permissions: markertypes.AccessList{markertypes.Access_Transfer}})
			}
			restrictedMarker := markertypes.NewMarkerAccount(
				authtypes.NewBaseAccountWithAddress(markertypes.MustGetMarkerAddress(restrictedDenom)),
				sdk.NewInt64Coin(restrictedDenom, 1_000_000),
				s.adminAddr,
				grants,
				markertypes.StatusProposed,
				markertypes.MarkerType_RestrictedCoin,
				false, true, false, []string{},
			)
			s.Require().NoError(s.simApp.MarkerKeeper.AddFinalizeAndActivateMarker(s.ctx, restrictedMarker), "failed to create restricted marker %s", restrictedDenom)
			s.Require().NoError(s.withdrawMarkerCoins(s.ctx, s.adminAddr, source, restrictedDenom, sdk.NewCoins(sdk.NewInt64Coin(restrictedDenom, 10))), "failed to fund source %s with restricted marker denom %s", source, restrictedDenom)
			s.Require().NoError(FundAccount(s.ctx, s.simApp, principalAddr, sdk.NewCoins(sdk.NewInt64Coin(underlying, 5))), "failed to fund principal %s with underlying asset %s", principalAddr, underlying)
			s.setVaultNAV(vault, restrictedDenom, sdk.NewInt64Coin(underlying, 5), 10)

			sourceAmount := sdk.NewCoins(sdk.NewInt64Coin(restrictedDenom, 10))
			targetAmount := sdk.NewCoins(sdk.NewInt64Coin(underlying, 5))
			approved := s.createPayment(source, vaultAddr, sourceAmount, targetAmount, externalID)

			s.ctx = s.ctx.WithEventManager(sdk.NewEventManager())
			resp, err := keeper.NewMsgServer(s.simApp.VaultKeeper).AcceptAsset(s.ctx, &types.MsgAcceptAssetRequest{
				Authority:    s.assetManagerAddr.String(),
				VaultAddress: vaultAddr.String(),
				Payment:      approved,
			})

			if len(tc.expectedErrSubstrs) > 0 {
				s.Require().Error(err, "AcceptAsset of restricted marker denom %s should fail for case %q", restrictedDenom, tc.name)
				s.Assert().Nil(resp, "AcceptAsset response should be nil on error for case %q", tc.name)
				for _, substr := range tc.expectedErrSubstrs {
					s.Assert().Containsf(err.Error(), substr, "AcceptAsset error missing expected substring for case %q", tc.name)
				}
				return
			}

			s.Require().NoError(err, "AcceptAsset of restricted marker denom %s should succeed when vault %s and source %s hold transfer access", restrictedDenom, vaultAddr, source)
			s.Assert().Equal(&types.MsgAcceptAssetResponse{}, resp, "AcceptAsset restricted marker response")

			s.assertBalance(source, restrictedDenom, sdkmath.NewInt(0))
			s.assertBalance(source, underlying, sdkmath.NewInt(5))
			s.assertBalance(principalAddr, restrictedDenom, sdkmath.NewInt(10))
			s.assertBalance(principalAddr, underlying, sdkmath.NewInt(0))
			s.assertBalance(vaultAddr, restrictedDenom, sdkmath.NewInt(0))
			s.assertBalance(vaultAddr, underlying, sdkmath.NewInt(0))

			s.requireTypedEventEmitted(types.NewEventAssetAccepted(vaultAddr.String(), source.String(), externalID, sourceAmount, targetAmount, types.AssetDirectionInbound))
		})
	}
}

func (s *TestSuite) TestMsgServer_AcceptAsset_Failures() {
	underlying, share, asset := "under", "vshare", "rwacoin"

	tests := []struct {
		name string
		// setup returns the request to send. It is responsible for any vault, payment, and
		// funding state required by the case.
		setup              func() *types.MsgAcceptAssetRequest
		expectedErrSubstrs []string
	}{
		{
			name: "vault does not exist",
			setup: func() *types.MsgAcceptAssetRequest {
				source := s.CreateAndFundAccount(sdk.NewInt64Coin(asset, 10))
				missingVaultAddr := types.GetVaultAddress("missing")
				return &types.MsgAcceptAssetRequest{
					Authority:    s.adminAddr.String(),
					VaultAddress: missingVaultAddr.String(),
					Payment: types.Payment{
						Source:       source.String(),
						SourceAmount: sdk.NewCoins(sdk.NewInt64Coin(asset, 10)),
						Target:       missingVaultAddr.String(),
						TargetAmount: sdk.NewCoins(sdk.NewInt64Coin(underlying, 5)),
						ExternalId:   "none",
					},
				}
			},
			expectedErrSubstrs: []string{"not found"},
		},
		{
			name: "unauthorized signer",
			setup: func() *types.MsgAcceptAssetRequest {
				vault, _, _, approved := s.setupAcceptAssetScenario(acceptAssetScenario{
					underlying:    underlying,
					share:         share,
					fundSource:    sdk.NewCoins(sdk.NewInt64Coin(asset, 10)),
					fundPrincipal: sdk.NewCoins(sdk.NewInt64Coin(underlying, 5)),
					sourceAmount:  sdk.NewCoins(sdk.NewInt64Coin(asset, 10)),
					targetAmount:  sdk.NewCoins(sdk.NewInt64Coin(underlying, 5)),
					externalID:    "unauth",
				})
				stranger := s.CreateAndFundAccount(sdk.NewInt64Coin(underlying, 1))
				return &types.MsgAcceptAssetRequest{
					Authority:    stranger.String(),
					VaultAddress: vault.GetAddress().String(),
					Payment:      approved,
				}
			},
			expectedErrSubstrs: []string{"failed to validate asset manager authority", "unauthorized authority"},
		},
		{
			name: "admin cannot settle, only the asset manager may",
			setup: func() *types.MsgAcceptAssetRequest {
				vault, _, _, approved := s.setupAcceptAssetScenario(acceptAssetScenario{
					underlying:    underlying,
					share:         share,
					fundSource:    sdk.NewCoins(sdk.NewInt64Coin(asset, 10)),
					fundPrincipal: sdk.NewCoins(sdk.NewInt64Coin(underlying, 5)),
					sourceAmount:  sdk.NewCoins(sdk.NewInt64Coin(asset, 10)),
					targetAmount:  sdk.NewCoins(sdk.NewInt64Coin(underlying, 5)),
					externalID:    "admin-settle",
				})
				return &types.MsgAcceptAssetRequest{
					Authority:    s.adminAddr.String(),
					VaultAddress: vault.GetAddress().String(),
					Payment:      approved,
				}
			},
			expectedErrSubstrs: []string{"failed to validate asset manager authority", "unauthorized authority"},
		},
		{
			name: "vault without an asset manager cannot settle",
			setup: func() *types.MsgAcceptAssetRequest {
				vault, _, _, approved := s.setupAcceptAssetScenario(acceptAssetScenario{
					underlying:    underlying,
					share:         share,
					fundSource:    sdk.NewCoins(sdk.NewInt64Coin(asset, 10)),
					fundPrincipal: sdk.NewCoins(sdk.NewInt64Coin(underlying, 5)),
					sourceAmount:  sdk.NewCoins(sdk.NewInt64Coin(asset, 10)),
					targetAmount:  sdk.NewCoins(sdk.NewInt64Coin(underlying, 5)),
					externalID:    "no-mgr",
				})
				vaultAddr := vault.GetAddress()
				_, err := keeper.NewMsgServer(s.simApp.VaultKeeper).SetAssetManager(s.ctx, &types.MsgSetAssetManagerRequest{
					Admin:        s.adminAddr.String(),
					VaultAddress: vaultAddr.String(),
					AssetManager: "",
				})
				s.Require().NoError(err, "failed to clear asset manager on vault %s", vaultAddr)
				return &types.MsgAcceptAssetRequest{
					Authority:    s.adminAddr.String(),
					VaultAddress: vaultAddr.String(),
					Payment:      approved,
				}
			},
			expectedErrSubstrs: []string{"failed to validate asset manager authority", "no asset manager set"},
		},
		{
			name: "payment not found",
			setup: func() *types.MsgAcceptAssetRequest {
				vault, _, source, _ := s.setupAcceptAssetScenario(acceptAssetScenario{
					underlying:  underlying,
					share:       share,
					fundSource:  sdk.NewCoins(sdk.NewInt64Coin(asset, 10)),
					omitPayment: true,
				})
				vaultAddr := vault.GetAddress()
				return &types.MsgAcceptAssetRequest{
					Authority:    s.assetManagerAddr.String(),
					VaultAddress: vaultAddr.String(),
					Payment: types.Payment{
						Source:       source.String(),
						SourceAmount: sdk.NewCoins(sdk.NewInt64Coin(asset, 10)),
						Target:       vaultAddr.String(),
						TargetAmount: sdk.NewCoins(sdk.NewInt64Coin(underlying, 5)),
						ExternalId:   "ghost",
					},
				}
			},
			expectedErrSubstrs: []string{"payment not found"},
		},
		{
			name: "payment target mismatch",
			setup: func() *types.MsgAcceptAssetRequest {
				vault, _, source, _ := s.setupAcceptAssetScenario(acceptAssetScenario{
					underlying:  underlying,
					share:       share,
					fundSource:  sdk.NewCoins(sdk.NewInt64Coin(asset, 10)),
					omitPayment: true,
				})
				other := s.CreateAndFundAccount(sdk.NewInt64Coin(underlying, 1))
				approved := s.createPayment(source, other, sdk.NewCoins(sdk.NewInt64Coin(asset, 10)), sdk.NewCoins(sdk.NewInt64Coin(underlying, 5)), "mismatch")
				return &types.MsgAcceptAssetRequest{
					Authority:    s.assetManagerAddr.String(),
					VaultAddress: vault.GetAddress().String(),
					Payment:      approved,
				}
			},
			expectedErrSubstrs: []string{"is not vault"},
		},
		{
			name: "underlying asset on neither leg",
			setup: func() *types.MsgAcceptAssetRequest {
				vault, _, _, approved := s.setupAcceptAssetScenario(acceptAssetScenario{
					underlying:   underlying,
					share:        share,
					fundSource:   sdk.NewCoins(sdk.NewInt64Coin(asset, 10)),
					sourceAmount: sdk.NewCoins(sdk.NewInt64Coin(asset, 10)),
					targetAmount: sdk.NewCoins(sdk.NewInt64Coin("stake", 5)),
					externalID:   "noleg",
				})
				return &types.MsgAcceptAssetRequest{
					Authority:    s.assetManagerAddr.String(),
					VaultAddress: vault.GetAddress().String(),
					Payment:      approved,
				}
			},
			expectedErrSubstrs: []string{"exactly one leg"},
		},
		{
			name: "underlying asset on both legs",
			setup: func() *types.MsgAcceptAssetRequest {
				vault, _, _, approved := s.setupAcceptAssetScenario(acceptAssetScenario{
					underlying:   underlying,
					share:        share,
					fundSource:   sdk.NewCoins(sdk.NewInt64Coin(underlying, 5)),
					sourceAmount: sdk.NewCoins(sdk.NewInt64Coin(underlying, 5)),
					targetAmount: sdk.NewCoins(sdk.NewInt64Coin(underlying, 3), sdk.NewInt64Coin(asset, 2)),
					externalID:   "bothlegs",
				})
				return &types.MsgAcceptAssetRequest{
					Authority:    s.assetManagerAddr.String(),
					VaultAddress: vault.GetAddress().String(),
					Payment:      approved,
				}
			},
			expectedErrSubstrs: []string{"exactly one leg"},
		},
		{
			name: "insufficient principal balance",
			setup: func() *types.MsgAcceptAssetRequest {
				vault, _, _, approved := s.setupAcceptAssetScenario(acceptAssetScenario{
					underlying:    underlying,
					share:         share,
					assetMarker:   asset,
					seedNav:       &types.VaultNAV{Denom: asset, Price: sdk.NewInt64Coin(underlying, 5), Volume: sdkmath.NewInt(10)},
					fundSource:    sdk.NewCoins(sdk.NewInt64Coin(asset, 10)),
					fundPrincipal: sdk.NewCoins(sdk.NewInt64Coin(underlying, 4)),
					sourceAmount:  sdk.NewCoins(sdk.NewInt64Coin(asset, 10)),
					targetAmount:  sdk.NewCoins(sdk.NewInt64Coin(underlying, 5)),
					externalID:    "short",
				})
				return &types.MsgAcceptAssetRequest{
					Authority:    s.assetManagerAddr.String(),
					VaultAddress: vault.GetAddress().String(),
					Payment:      approved,
				}
			},
			expectedErrSubstrs: []string{"insufficient principal balance"},
		},
		{
			name: "asset denom the NAV authority has not priced cannot be acquired",
			setup: func() *types.MsgAcceptAssetRequest {
				vault, _, _, approved := s.setupAcceptAssetScenario(acceptAssetScenario{
					underlying:    underlying,
					share:         share,
					assetMarker:   asset,
					fundSource:    sdk.NewCoins(sdk.NewInt64Coin(asset, 10)),
					fundPrincipal: sdk.NewCoins(sdk.NewInt64Coin(underlying, 5)),
					sourceAmount:  sdk.NewCoins(sdk.NewInt64Coin(asset, 10)),
					targetAmount:  sdk.NewCoins(sdk.NewInt64Coin(underlying, 5)),
					externalID:    "unpriced",
				})
				return &types.MsgAcceptAssetRequest{
					Authority:    s.assetManagerAddr.String(),
					VaultAddress: vault.GetAddress().String(),
					Payment:      approved,
				}
			},
			expectedErrSubstrs: []string{"has no internal NAV entry", "the NAV authority must price it before it can be settled"},
		},
		{
			name: "rejects settlement while vault is paused",
			setup: func() *types.MsgAcceptAssetRequest {
				vault, _, _, approved := s.setupAcceptAssetScenario(acceptAssetScenario{
					underlying:    underlying,
					share:         share,
					fundSource:    sdk.NewCoins(sdk.NewInt64Coin(asset, 10)),
					fundPrincipal: sdk.NewCoins(sdk.NewInt64Coin(underlying, 5)),
					sourceAmount:  sdk.NewCoins(sdk.NewInt64Coin(asset, 10)),
					targetAmount:  sdk.NewCoins(sdk.NewInt64Coin(underlying, 5)),
					externalID:    "paused",
				})
				vaultAddr := vault.GetAddress()
				paused, err := s.k.GetVault(s.ctx, vaultAddr)
				s.Require().NoError(err, "failed to get vault %s for paused setup", vaultAddr)
				paused.Paused = true
				s.k.AuthKeeper.SetAccount(s.ctx, paused)
				return &types.MsgAcceptAssetRequest{
					Authority:    s.assetManagerAddr.String(),
					VaultAddress: vaultAddr.String(),
					Payment:      approved,
				}
			},
			expectedErrSubstrs: []string{"is paused", "assets cannot be accepted while paused"},
		},
	}

	for _, tc := range tests {
		s.Run(tc.name, func() {
			origCtx := s.ctx
			defer func() { s.ctx = origCtx }()
			s.ctx, _ = s.ctx.CacheContext()

			msg := tc.setup()
			s.ctx = s.ctx.WithEventManager(sdk.NewEventManager())

			resp, err := keeper.NewMsgServer(s.simApp.VaultKeeper).AcceptAsset(s.ctx, msg)
			s.Require().Error(err, "AcceptAsset should fail for case %q", tc.name)
			s.Assert().Nil(resp, "AcceptAsset response should be nil on error for case %q", tc.name)
			for _, substr := range tc.expectedErrSubstrs {
				s.Assert().Containsf(err.Error(), substr, "AcceptAsset error missing expected substring for case %q", tc.name)
			}
		})
	}
}

func (s *TestSuite) TestMsgServer_AcceptAsset_RejectsPaymentSubstitutedAfterApproval() {
	underlying, share, asset := "under", "vshare", "rwacoin"
	externalID := "substituted"

	approvedSourceAmount := sdk.NewCoins(sdk.NewInt64Coin(asset, 2))
	approvedTargetAmount := sdk.NewCoins(sdk.NewInt64Coin(underlying, 1))

	sourceFunding := sdk.NewCoins(sdk.NewInt64Coin(asset, 100), sdk.NewInt64Coin(underlying, 50))
	principalFunding := sdk.NewCoins(sdk.NewInt64Coin(underlying, 1), sdk.NewInt64Coin(asset, 100))

	tests := []struct {
		name string
		// substitute replaces what occupies the approved payment's (source, external_id)
		// label after the asset manager has signed for it.
		substitute        func(source, vaultAddr sdk.AccAddress)
		expectedErrSubstr string
	}{
		{
			name: "small inbound buy is replaced by a large outbound sale priced exactly at NAV",
			substitute: func(source, vaultAddr sdk.AccAddress) {
				s.cancelPayment(source, externalID)
				s.createPayment(source, vaultAddr,
					sdk.NewCoins(sdk.NewInt64Coin(underlying, 50)),
					sdk.NewCoins(sdk.NewInt64Coin(asset, 100)),
					externalID)
			},
			expectedErrSubstr: "approved source amount",
		},
		{
			name: "same direction is kept but both legs are scaled up along the NAV price",
			substitute: func(source, vaultAddr sdk.AccAddress) {
				s.cancelPayment(source, externalID)
				s.createPayment(source, vaultAddr,
					sdk.NewCoins(sdk.NewInt64Coin(asset, 100)),
					sdk.NewCoins(sdk.NewInt64Coin(underlying, 50)),
					externalID)
			},
			expectedErrSubstr: "approved source amount",
		},
		{
			name: "only the leg the vault pays out is enlarged",
			substitute: func(source, vaultAddr sdk.AccAddress) {
				s.cancelPayment(source, externalID)
				s.createPayment(source, vaultAddr, approvedSourceAmount,
					sdk.NewCoins(sdk.NewInt64Coin(underlying, 50)), externalID)
			},
			expectedErrSubstr: "approved target amount",
		},
		{
			name: "payment is retargeted away from the vault the manager approved",
			substitute: func(source, _ sdk.AccAddress) {
				other := s.CreateAndFundAccount(sdk.NewInt64Coin(underlying, 1))
				s.Require().NoError(
					s.simApp.ExchangeKeeper.UpdatePaymentTarget(s.ctx, source, externalID, other),
					"failed to retarget payment %q", externalID,
				)
			},
			expectedErrSubstr: "approved target",
		},
	}

	for _, tc := range tests {
		s.Run(tc.name, func() {
			origCtx := s.ctx
			defer func() { s.ctx = origCtx }()
			s.ctx, _ = s.ctx.CacheContext()

			vault, principalAddr, source, approved := s.setupAcceptAssetScenario(acceptAssetScenario{
				underlying:    underlying,
				share:         share,
				assetMarker:   asset,
				seedNav:       &types.VaultNAV{Denom: asset, Price: sdk.NewInt64Coin(underlying, 5), Volume: sdkmath.NewInt(10)},
				fundSource:    sourceFunding,
				fundPrincipal: principalFunding,
				sourceAmount:  approvedSourceAmount,
				targetAmount:  approvedTargetAmount,
				externalID:    externalID,
			})
			vaultAddr := vault.GetAddress()

			tc.substitute(source, vaultAddr)

			resp, err := keeper.NewMsgServer(s.simApp.VaultKeeper).AcceptAsset(s.ctx, &types.MsgAcceptAssetRequest{
				Authority:    s.assetManagerAddr.String(),
				VaultAddress: vaultAddr.String(),
				Payment:      approved,
			})
			s.Require().Error(err, "AcceptAsset must not settle terms the asset manager never approved for case %q", tc.name)
			s.Assert().Nil(resp, "AcceptAsset response should be nil on error for case %q", tc.name)
			s.Assert().Contains(err.Error(), "no longer matches the approved terms", "AcceptAsset should fail on the approval binding for case %q", tc.name)
			s.Assert().Contains(err.Error(), tc.expectedErrSubstr, "AcceptAsset error should name the substituted field for case %q", tc.name)

			s.assertBalance(source, asset, sdkmath.NewInt(100))
			s.assertBalance(source, underlying, sdkmath.NewInt(50))
			s.assertBalance(principalAddr, asset, sdkmath.NewInt(100))
			s.assertBalance(principalAddr, underlying, sdkmath.NewInt(1))
			s.assertBalance(vaultAddr, asset, sdkmath.NewInt(0))
			s.assertBalance(vaultAddr, underlying, sdkmath.NewInt(0))
		})
	}
}

func (s *TestSuite) TestMsgServer_AcceptAsset_NAVGuardrail() {
	underlying, share, asset := "under", "vshare", "rwacoin"
	externalID := "guardrail"

	tests := []struct {
		name               string
		seedNav            *types.VaultNAV
		fundSource         sdk.Coins
		fundPrincipal      sdk.Coins
		sourceAmount       sdk.Coins
		targetAmount       sdk.Coins
		expectedErrSubstrs []string
	}{
		{
			name:          "inbound settlement at the exact NAV price passes the guardrail",
			seedNav:       &types.VaultNAV{Denom: asset, Price: sdk.NewInt64Coin(underlying, 5), Volume: sdkmath.NewInt(10)},
			fundSource:    sdk.NewCoins(sdk.NewInt64Coin(asset, 10)),
			fundPrincipal: sdk.NewCoins(sdk.NewInt64Coin(underlying, 5)),
			sourceAmount:  sdk.NewCoins(sdk.NewInt64Coin(asset, 10)),
			targetAmount:  sdk.NewCoins(sdk.NewInt64Coin(underlying, 5)),
		},
		{
			name:               "inbound settlement off the NAV price is rejected",
			seedNav:            &types.VaultNAV{Denom: asset, Price: sdk.NewInt64Coin(underlying, 6), Volume: sdkmath.NewInt(10)},
			fundSource:         sdk.NewCoins(sdk.NewInt64Coin(asset, 10)),
			fundPrincipal:      sdk.NewCoins(sdk.NewInt64Coin(underlying, 5)),
			sourceAmount:       sdk.NewCoins(sdk.NewInt64Coin(asset, 10)),
			targetAmount:       sdk.NewCoins(sdk.NewInt64Coin(underlying, 5)),
			expectedErrSubstrs: []string{"does not match internal NAV", "10rwacoin", "5under", "6under"},
		},
		{
			name:               "no NAV entry rejects a first acquisition until the NAV authority prices the denom",
			fundSource:         sdk.NewCoins(sdk.NewInt64Coin(asset, 10)),
			fundPrincipal:      sdk.NewCoins(sdk.NewInt64Coin(underlying, 5)),
			sourceAmount:       sdk.NewCoins(sdk.NewInt64Coin(asset, 10)),
			targetAmount:       sdk.NewCoins(sdk.NewInt64Coin(underlying, 5)),
			expectedErrSubstrs: []string{"has no internal NAV entry", "rwacoin"},
		},
		{
			name:          "denom priced by the authority while the vault holds none of it can be acquired",
			seedNav:       &types.VaultNAV{Denom: asset, Price: sdk.NewInt64Coin(underlying, 5), Volume: sdkmath.NewInt(10)},
			fundSource:    sdk.NewCoins(sdk.NewInt64Coin(asset, 20)),
			fundPrincipal: sdk.NewCoins(sdk.NewInt64Coin(underlying, 10)),
			sourceAmount:  sdk.NewCoins(sdk.NewInt64Coin(asset, 20)),
			targetAmount:  sdk.NewCoins(sdk.NewInt64Coin(underlying, 10)),
		},
		{
			name:          "outbound settlement at the exact NAV price passes the guardrail",
			seedNav:       &types.VaultNAV{Denom: asset, Price: sdk.NewInt64Coin(underlying, 5), Volume: sdkmath.NewInt(10)},
			fundSource:    sdk.NewCoins(sdk.NewInt64Coin(underlying, 5)),
			fundPrincipal: sdk.NewCoins(sdk.NewInt64Coin(asset, 10)),
			sourceAmount:  sdk.NewCoins(sdk.NewInt64Coin(underlying, 5)),
			targetAmount:  sdk.NewCoins(sdk.NewInt64Coin(asset, 10)),
		},
		{
			name:               "outbound settlement off the NAV price is rejected",
			seedNav:            &types.VaultNAV{Denom: asset, Price: sdk.NewInt64Coin(underlying, 5), Volume: sdkmath.NewInt(10)},
			fundSource:         sdk.NewCoins(sdk.NewInt64Coin(underlying, 4)),
			fundPrincipal:      sdk.NewCoins(sdk.NewInt64Coin(asset, 10)),
			sourceAmount:       sdk.NewCoins(sdk.NewInt64Coin(underlying, 4)),
			targetAmount:       sdk.NewCoins(sdk.NewInt64Coin(asset, 10)),
			expectedErrSubstrs: []string{"does not match internal NAV", "10rwacoin", "4under", "5under"},
		},
		{
			name:               "fractional NAV price that floor math would accept is rejected",
			seedNav:            &types.VaultNAV{Denom: asset, Price: sdk.NewInt64Coin(underlying, 3), Volume: sdkmath.NewInt(2)},
			fundSource:         sdk.NewCoins(sdk.NewInt64Coin(asset, 3)),
			fundPrincipal:      sdk.NewCoins(sdk.NewInt64Coin(underlying, 4)),
			sourceAmount:       sdk.NewCoins(sdk.NewInt64Coin(asset, 3)),
			targetAmount:       sdk.NewCoins(sdk.NewInt64Coin(underlying, 4)),
			expectedErrSubstrs: []string{"does not match internal NAV"},
		},
		{
			name:          "fractional NAV price settled at an exact multiple passes the guardrail",
			seedNav:       &types.VaultNAV{Denom: asset, Price: sdk.NewInt64Coin(underlying, 3), Volume: sdkmath.NewInt(2)},
			fundSource:    sdk.NewCoins(sdk.NewInt64Coin(asset, 4)),
			fundPrincipal: sdk.NewCoins(sdk.NewInt64Coin(underlying, 6)),
			sourceAmount:  sdk.NewCoins(sdk.NewInt64Coin(asset, 4)),
			targetAmount:  sdk.NewCoins(sdk.NewInt64Coin(underlying, 6)),
		},
		{
			name:               "asset leg with multiple coins cannot be priced and is rejected",
			fundSource:         sdk.NewCoins(sdk.NewInt64Coin(asset, 10), sdk.NewInt64Coin("othercoin", 5)),
			fundPrincipal:      sdk.NewCoins(sdk.NewInt64Coin(underlying, 5)),
			sourceAmount:       sdk.NewCoins(sdk.NewInt64Coin(asset, 10), sdk.NewInt64Coin("othercoin", 5)),
			targetAmount:       sdk.NewCoins(sdk.NewInt64Coin(underlying, 5)),
			expectedErrSubstrs: []string{"one asset coin"},
		},
		{
			name:               "empty asset leg cannot be priced and is rejected",
			fundPrincipal:      sdk.NewCoins(sdk.NewInt64Coin(underlying, 5)),
			sourceAmount:       sdk.NewCoins(),
			targetAmount:       sdk.NewCoins(sdk.NewInt64Coin(underlying, 5)),
			expectedErrSubstrs: []string{"one asset coin"},
		},
	}

	for _, tc := range tests {
		s.Run(tc.name, func() {
			origCtx := s.ctx
			defer func() { s.ctx = origCtx }()
			s.ctx, _ = s.ctx.CacheContext()

			vault, _, _, approved := s.setupAcceptAssetScenario(acceptAssetScenario{
				underlying:    underlying,
				share:         share,
				assetMarker:   asset,
				seedNav:       tc.seedNav,
				fundSource:    tc.fundSource,
				fundPrincipal: tc.fundPrincipal,
				sourceAmount:  tc.sourceAmount,
				targetAmount:  tc.targetAmount,
				externalID:    externalID,
			})
			vaultAddr := vault.GetAddress()

			resp, err := keeper.NewMsgServer(s.simApp.VaultKeeper).AcceptAsset(s.ctx, &types.MsgAcceptAssetRequest{
				Authority:    s.assetManagerAddr.String(),
				VaultAddress: vaultAddr.String(),
				Payment:      approved,
			})

			if len(tc.expectedErrSubstrs) == 0 {
				s.Require().NoError(err, "AcceptAsset should pass the guardrail for case %q", tc.name)
				s.Assert().Equal(&types.MsgAcceptAssetResponse{}, resp, "AcceptAsset response for case %q", tc.name)
				return
			}

			s.Require().Error(err, "AcceptAsset should fail the guardrail for case %q", tc.name)
			s.Assert().Nil(resp, "AcceptAsset response should be nil on error for case %q", tc.name)
			for _, substr := range tc.expectedErrSubstrs {
				s.Assert().Containsf(err.Error(), substr, "AcceptAsset error missing expected substring for case %q", tc.name)
			}
		})
	}
}

func (s *TestSuite) TestMsgServer_AcceptAsset_RequiresNAVAuthorityPriceFirst() {
	underlying, share, asset := "under", "vshare", "rwacoin"
	externalID := "priced-then-settled"

	origCtx := s.ctx
	defer func() { s.ctx = origCtx }()
	s.ctx, _ = s.ctx.CacheContext()

	navAuthority := s.CreateAndFundAccount(sdk.NewInt64Coin("stake", 1_000))
	sourceAmount := sdk.NewCoins(sdk.NewInt64Coin(asset, 10))
	targetAmount := sdk.NewCoins(sdk.NewInt64Coin(underlying, 5))

	vault, principalAddr, _, approved := s.setupAcceptAssetScenario(acceptAssetScenario{
		underlying:    underlying,
		share:         share,
		assetMarker:   asset,
		fundSource:    sourceAmount,
		fundPrincipal: targetAmount,
		sourceAmount:  sourceAmount,
		targetAmount:  targetAmount,
		externalID:    externalID,
	})
	vaultAddr := vault.GetAddress()

	msgServer := keeper.NewMsgServer(s.simApp.VaultKeeper)
	_, err := msgServer.UpdateNAVAuthority(s.ctx, &types.MsgUpdateNAVAuthorityRequest{
		Signer:       s.adminAddr.String(),
		VaultAddress: vaultAddr.String(),
		NewAuthority: navAuthority.String(),
	})
	s.Require().NoError(err, "admin should be able to hand NAV authority to %s", navAuthority)

	acceptMsg := &types.MsgAcceptAssetRequest{
		Authority:    s.assetManagerAddr.String(),
		VaultAddress: vaultAddr.String(),
		Payment:      approved,
	}

	_, err = msgServer.AcceptAsset(s.ctx, acceptMsg)
	s.Require().ErrorContains(err, "has no internal NAV entry", "the asset manager must not be able to acquire %s before the NAV authority prices it", asset)

	priceMsg := &types.MsgUpdateVaultNAVRequest{
		VaultAddress: vaultAddr.String(),
		Denom:        asset,
		Price:        sdk.NewInt64Coin(underlying, 5),
		Volume:       sdkmath.NewInt(10),
		Source:       "oracle",
	}

	managerPriceMsg := *priceMsg
	managerPriceMsg.Signer = s.assetManagerAddr.String()
	_, err = msgServer.UpdateVaultNAV(s.ctx, &managerPriceMsg)
	s.Require().ErrorContains(err, "is not the vault NAV authority", "the asset manager must not be able to price %s itself", asset)

	tvvBeforePricing, err := s.k.GetTVV(s.ctx, *vault)
	s.Require().NoError(err, "failed to read TVV before pricing %s", asset)

	priceMsg.Signer = navAuthority.String()
	_, err = msgServer.UpdateVaultNAV(s.ctx, priceMsg)
	s.Require().NoError(err, "the NAV authority should be able to price %s before the vault holds any", asset)

	tvvAfterPricing, err := s.k.GetTVV(s.ctx, *vault)
	s.Require().NoError(err, "failed to read TVV after pricing %s", asset)
	s.Assert().Equal(tvvBeforePricing, tvvAfterPricing, "pricing a denom the vault does not hold must not move total vault value")

	priced, err := s.k.GetVaultNAV(s.ctx, vaultAddr, asset)
	s.Require().NoError(err, "NAV entry for %s should exist once the authority has priced it", asset)

	s.bumpHeight()
	_, err = msgServer.AcceptAsset(s.ctx, acceptMsg)
	s.Require().NoError(err, "the asset manager should be able to settle %s at the price the NAV authority set", asset)

	s.assertBalance(principalAddr, asset, sdkmath.NewInt(10))
	stored, err := s.k.GetVaultNAV(s.ctx, vaultAddr, asset)
	s.Require().NoError(err, "NAV entry for %s should survive the settlement", asset)
	s.Assert().Equal(priced, stored, "settling must not rewrite the price the NAV authority set")

	tvvAfterSettling, err := s.k.GetTVV(s.ctx, *vault)
	s.Require().NoError(err, "failed to read TVV after settling %s", asset)
	s.Assert().Equal(tvvBeforePricing, tvvAfterSettling, "swapping 5%s of underlying for 10%s valued at that price must leave total vault value unchanged", underlying, asset)
}

func (s *TestSuite) TestMsgServer_AcceptAsset_SettlementNAV() {
	underlying := "under"
	share := "vshare"
	asset := "rwacoin"
	externalID := "settle-nav"

	tests := []struct {
		name                string
		registerAssetMarker bool
		seedNav             *types.VaultNAV
		fundSource          sdk.Coins
		fundPrincipal       sdk.Coins
		sourceAmount        sdk.Coins
		targetAmount        sdk.Coins
		expectNavRemoved    bool
		expectedErrContains string
	}{
		{
			name:                "inbound settlement leaves the authority's NAV entry exactly as written",
			registerAssetMarker: true,
			seedNav:             &types.VaultNAV{Denom: asset, Price: sdk.NewInt64Coin(underlying, 1), Volume: sdkmath.NewInt(2), Source: "oracle"},
			fundSource:          sdk.NewCoins(sdk.NewInt64Coin(asset, 4)),
			fundPrincipal:       sdk.NewCoins(sdk.NewInt64Coin(underlying, 2)),
			sourceAmount:        sdk.NewCoins(sdk.NewInt64Coin(asset, 4)),
			targetAmount:        sdk.NewCoins(sdk.NewInt64Coin(underlying, 2)),
		},
		{
			name:                "inbound settlement at a fractional NAV price leaves the entry unscaled",
			registerAssetMarker: true,
			seedNav:             &types.VaultNAV{Denom: asset, Price: sdk.NewInt64Coin(underlying, 10), Volume: sdkmath.NewInt(3), Source: "oracle"},
			fundSource:          sdk.NewCoins(sdk.NewInt64Coin(asset, 6)),
			fundPrincipal:       sdk.NewCoins(sdk.NewInt64Coin(underlying, 20)),
			sourceAmount:        sdk.NewCoins(sdk.NewInt64Coin(asset, 6)),
			targetAmount:        sdk.NewCoins(sdk.NewInt64Coin(underlying, 20)),
		},
		{
			name:                "outbound settlement leaving a principal balance keeps the NAV entry",
			registerAssetMarker: true,
			seedNav:             &types.VaultNAV{Denom: asset, Price: sdk.NewInt64Coin(underlying, 5), Volume: sdkmath.NewInt(10), Source: "oracle"},
			fundSource:          sdk.NewCoins(sdk.NewInt64Coin(underlying, 5)),
			fundPrincipal:       sdk.NewCoins(sdk.NewInt64Coin(asset, 20)),
			sourceAmount:        sdk.NewCoins(sdk.NewInt64Coin(underlying, 5)),
			targetAmount:        sdk.NewCoins(sdk.NewInt64Coin(asset, 10)),
		},
		{
			name:                "outbound settlement draining the principal removes the NAV entry",
			registerAssetMarker: true,
			seedNav:             &types.VaultNAV{Denom: asset, Price: sdk.NewInt64Coin(underlying, 5), Volume: sdkmath.NewInt(10), Source: "oracle"},
			fundSource:          sdk.NewCoins(sdk.NewInt64Coin(underlying, 5)),
			fundPrincipal:       sdk.NewCoins(sdk.NewInt64Coin(asset, 10)),
			sourceAmount:        sdk.NewCoins(sdk.NewInt64Coin(underlying, 5)),
			targetAmount:        sdk.NewCoins(sdk.NewInt64Coin(asset, 10)),
			expectNavRemoved:    true,
		},
		{
			name:                "asset denom that is not a registered marker cannot be priced and so cannot be settled",
			registerAssetMarker: false,
			fundSource:          sdk.NewCoins(sdk.NewInt64Coin(asset, 10)),
			fundPrincipal:       sdk.NewCoins(sdk.NewInt64Coin(underlying, 5)),
			sourceAmount:        sdk.NewCoins(sdk.NewInt64Coin(asset, 10)),
			targetAmount:        sdk.NewCoins(sdk.NewInt64Coin(underlying, 5)),
			expectedErrContains: "has no internal NAV entry",
		},
	}

	for _, tc := range tests {
		s.Run(tc.name, func() {
			origCtx := s.ctx
			defer func() { s.ctx = origCtx }()
			s.ctx, _ = s.ctx.CacheContext()

			assetMarker := ""
			if tc.registerAssetMarker {
				assetMarker = asset
			}
			vault, _, _, approved := s.setupAcceptAssetScenario(acceptAssetScenario{
				underlying:    underlying,
				share:         share,
				assetMarker:   assetMarker,
				seedNav:       tc.seedNav,
				fundSource:    tc.fundSource,
				fundPrincipal: tc.fundPrincipal,
				sourceAmount:  tc.sourceAmount,
				targetAmount:  tc.targetAmount,
				externalID:    externalID,
			})
			vaultAddr := vault.GetAddress()

			var seeded types.VaultNAV
			if tc.seedNav != nil {
				var getErr error
				seeded, getErr = s.k.GetVaultNAV(s.ctx, vaultAddr, asset)
				s.Require().NoError(getErr, "seeded NAV entry for %s should be readable before settlement", asset)
			}

			// A later block makes a settlement-time rewrite of the entry observable
			// through its updated height, not only through its price and volume.
			s.bumpHeight()
			s.ctx = s.ctx.WithEventManager(sdk.NewEventManager())
			_, err := keeper.NewMsgServer(s.simApp.VaultKeeper).AcceptAsset(s.ctx, &types.MsgAcceptAssetRequest{
				Authority:    s.assetManagerAddr.String(),
				VaultAddress: vaultAddr.String(),
				Payment:      approved,
			})

			if tc.expectedErrContains != "" {
				s.Require().ErrorContains(err, tc.expectedErrContains, "AcceptAsset should fail for case %q", tc.name)
				return
			}
			s.Require().NoError(err, "AcceptAsset should succeed for case %q", tc.name)

			eventIndex := map[string]int{}
			for i, ev := range s.ctx.EventManager().Events() {
				if _, seen := eventIndex[ev.Type]; !seen {
					eventIndex[ev.Type] = i
				}
			}
			acceptedIdx, ok := eventIndex["provlabs.vault.v1.EventAssetAccepted"]
			s.Require().True(ok, "EventAssetAccepted should be emitted for case %q", tc.name)
			s.Assert().NotContains(eventIndex, "provlabs.vault.v1.EventNAVUpdated", "settling must not rewrite the NAV table for case %q", tc.name)
			s.Assert().NotContains(eventIndex, "provenance.marker.v1.EventSetNetAssetValue", "settling must not republish a marker NAV for case %q", tc.name)

			if tc.expectNavRemoved {
				_, err := s.k.GetVaultNAV(s.ctx, vaultAddr, asset)
				s.Assert().ErrorIs(err, collections.ErrNotFound, "NAV entry for %s should be removed after draining the principal", asset)
				removedIdx, ok := eventIndex["provlabs.vault.v1.EventNAVRemoved"]
				s.Require().True(ok, "EventNAVRemoved should be emitted for case %q", tc.name)
				s.Assert().Less(acceptedIdx, removedIdx, "EventAssetAccepted should be emitted before EventNAVRemoved")
				s.requireTypedEventEmitted(types.NewEventNAVRemoved(vaultAddr.String(), seeded, ""))
				return
			}

			s.Assert().NotContains(eventIndex, "provlabs.vault.v1.EventNAVRemoved", "EventNAVRemoved should not be emitted for case %q", tc.name)
			stored, err := s.k.GetVaultNAV(s.ctx, vaultAddr, asset)
			s.Require().NoError(err, "NAV entry for %s should exist after settlement", asset)
			s.Assert().Equal(seeded, stored, "settlement must leave the NAV entry the authority wrote untouched for case %q", tc.name)
		})
	}
}

func (s *TestSuite) TestMsgServer_AcceptAsset_SettlementNAV_MetadataDenom() {
	underlying := "under"
	share := "vshare"
	asset := s.requireScope("00000000-0000-4000-8000-000000000001")
	externalID := "settle-nav-nft"

	origCtx := s.ctx
	defer func() { s.ctx = origCtx }()
	s.ctx, _ = s.ctx.CacheContext()

	vault, principalAddr, source, approved := s.setupAcceptAssetScenario(acceptAssetScenario{
		underlying:    underlying,
		share:         share,
		seedNav:       &types.VaultNAV{Denom: asset, Price: sdk.NewInt64Coin(underlying, 5), Volume: sdkmath.NewInt(10), Source: "oracle-nft"},
		fundSource:    sdk.NewCoins(sdk.NewInt64Coin(asset, 10)),
		fundPrincipal: sdk.NewCoins(sdk.NewInt64Coin(underlying, 5)),
		sourceAmount:  sdk.NewCoins(sdk.NewInt64Coin(asset, 10)),
		targetAmount:  sdk.NewCoins(sdk.NewInt64Coin(underlying, 5)),
		externalID:    externalID,
	})
	vaultAddr := vault.GetAddress()

	seeded, err := s.k.GetVaultNAV(s.ctx, vaultAddr, asset)
	s.Require().NoError(err, "seeded NAV entry for nft/ denom %s should be readable before settlement", asset)

	s.bumpHeight()
	s.ctx = s.ctx.WithEventManager(sdk.NewEventManager())
	_, err = keeper.NewMsgServer(s.simApp.VaultKeeper).AcceptAsset(s.ctx, &types.MsgAcceptAssetRequest{
		Authority:    s.assetManagerAddr.String(),
		VaultAddress: vaultAddr.String(),
		Payment:      approved,
	})
	s.Require().NoError(err, "AcceptAsset should settle an nft/ asset denom without a registered marker")

	stored, err := s.k.GetVaultNAV(s.ctx, vaultAddr, asset)
	s.Require().NoError(err, "internal NAV entry for nft/ denom %s should exist after settlement", asset)
	s.Assert().Equal(seeded, stored, "settlement must leave the nft/ denom NAV entry the authority wrote untouched")

	_, markerErr := s.simApp.MarkerKeeper.GetMarkerByDenom(s.ctx, asset)
	s.Assert().Error(markerErr, "nft/ asset denom %s must not be a registered marker", asset)
	for _, ev := range s.ctx.EventManager().Events() {
		s.Assert().NotEqual("provenance.marker.v1.EventSetNetAssetValue", ev.Type, "no marker NAV event should be emitted for an nft/ denom")
	}

	const secondID = "settle-nav-nft-2"
	s.Require().NoError(FundAccount(s.ctx, s.simApp, source, sdk.NewCoins(sdk.NewInt64Coin(asset, 10))), "fund source for second settlement")
	s.Require().NoError(FundAccount(s.ctx, s.simApp, principalAddr, sdk.NewCoins(sdk.NewInt64Coin(underlying, 6))), "fund principal for second settlement")
	secondApproved := s.createPayment(source, vaultAddr, sdk.NewCoins(sdk.NewInt64Coin(asset, 10)), sdk.NewCoins(sdk.NewInt64Coin(underlying, 6)), secondID)

	_, err = keeper.NewMsgServer(s.simApp.VaultKeeper).AcceptAsset(s.ctx, &types.MsgAcceptAssetRequest{
		Authority:    s.assetManagerAddr.String(),
		VaultAddress: vaultAddr.String(),
		Payment:      secondApproved,
	})
	s.Require().ErrorContains(err, "does not match internal NAV", "off-NAV settlement of the nft/ denom should be rejected by the guardrail")
}

func (s *TestSuite) TestMsgServer_UpdateVaultNAV_MetadataDenom() {
	underlying := "under"
	share := "vaultshares"
	navDenom := s.requireScope("00000000-0000-4000-8000-000000000002")
	admin := s.adminAddr
	vaultAddr := types.GetVaultAddress(share)

	origCtx := s.ctx
	defer func() { s.ctx = origCtx }()
	s.ctx, _ = s.ctx.CacheContext()

	s.setupBaseVault(underlying, share)
	s.ctx = s.ctx.WithBlockHeight(100).WithEventManager(sdk.NewEventManager())

	price := sdk.NewInt64Coin(underlying, 100)
	volume := sdkmath.NewInt(2)
	_, err := keeper.NewMsgServer(s.simApp.VaultKeeper).UpdateVaultNAV(s.ctx, &types.MsgUpdateVaultNAVRequest{
		Signer:       admin.String(),
		VaultAddress: vaultAddr.String(),
		Denom:        navDenom,
		Price:        price,
		Volume:       volume,
		Source:       "oracle-nft",
	})
	s.Require().NoError(err, "UpdateVaultNAV should accept an nft/ denom without a registered marker")

	nav, err := s.k.GetVaultNAV(s.ctx, vaultAddr, navDenom)
	s.Require().NoError(err, "internal NAV for nft/ denom %s should be written", navDenom)
	s.Assert().Equal(price, nav.Price, "stored NAV price for nft/ denom")
	s.Assert().Equal(volume, nav.Volume, "stored NAV volume for nft/ denom")

	_, markerErr := s.simApp.MarkerKeeper.GetMarkerByDenom(s.ctx, navDenom)
	s.Assert().Error(markerErr, "nft/ denom %s must not be a registered marker", navDenom)
	for _, ev := range s.ctx.EventManager().Events() {
		s.Assert().NotEqual("provenance.marker.v1.EventSetNetAssetValue", ev.Type, "no marker NAV event should be emitted for an nft/ denom")
	}
}

func (s *TestSuite) TestMsgServer_AcceptAsset_Reconcile() {
	underlying := "under"
	share := "vshare"
	asset := "rwacoin"
	externalID := "settle-reconcile"

	atNavPrice := &types.VaultNAV{Denom: asset, Price: sdk.NewInt64Coin(underlying, 5), Volume: sdkmath.NewInt(10)}

	tests := []struct {
		name                string
		interestRate        string
		seedNav             *types.VaultNAV
		expectedErrContains string
		expectedReconciles  int
	}{
		{
			name:               "successful settlement with an elapsed interest period reconciles exactly once, before the transfers",
			interestRate:       "4.20",
			seedNav:            atNavPrice,
			expectedReconciles: 1,
		},
		{
			name:                "settlement rejected by the NAV guardrail does not reconcile",
			interestRate:        "4.20",
			seedNav:             &types.VaultNAV{Denom: asset, Price: sdk.NewInt64Coin(underlying, 9), Volume: sdkmath.NewInt(10)},
			expectedErrContains: "does not match internal NAV",
			expectedReconciles:  0,
		},
		{
			name:                "settlement of an unpriced denom does not reconcile",
			interestRate:        "4.20",
			expectedErrContains: "has no internal NAV entry",
			expectedReconciles:  0,
		},
		{
			name:                "failed reconcile aborts the settlement",
			interestRate:        "1000000.0",
			seedNav:             atNavPrice,
			expectedErrContains: "failed to reconcile vault before settlement",
			expectedReconciles:  0,
		},
	}

	for _, tc := range tests {
		s.Run(tc.name, func() {
			origCtx := s.ctx
			defer func() { s.ctx = origCtx }()
			s.ctx, _ = s.ctx.CacheContext()

			vault, _, _, approved := s.setupAcceptAssetScenario(acceptAssetScenario{
				underlying:    underlying,
				share:         share,
				assetMarker:   asset,
				seedNav:       tc.seedNav,
				fundSource:    sdk.NewCoins(sdk.NewInt64Coin(asset, 10)),
				fundPrincipal: sdk.NewCoins(sdk.NewInt64Coin(underlying, 5)),
				sourceAmount:  sdk.NewCoins(sdk.NewInt64Coin(asset, 10)),
				targetAmount:  sdk.NewCoins(sdk.NewInt64Coin(underlying, 5)),
				externalID:    externalID,
			})
			vaultAddr := vault.GetAddress()

			// An elapsed interest period makes the reconcile observable via EventVaultReconcile.
			vault.CurrentInterestRate = tc.interestRate
			vault.DesiredInterestRate = tc.interestRate
			vault.PeriodStart = s.ctx.BlockTime().Add(-3 * time.Hour).Unix()
			s.k.AuthKeeper.SetAccount(s.ctx, vault)

			s.ctx = s.ctx.WithEventManager(sdk.NewEventManager())
			_, err := keeper.NewMsgServer(s.simApp.VaultKeeper).AcceptAsset(s.ctx, &types.MsgAcceptAssetRequest{
				Authority:    s.assetManagerAddr.String(),
				VaultAddress: vaultAddr.String(),
				Payment:      approved,
			})

			reconcileCount := 0
			reconcileIdx := -1
			acceptedIdx := -1
			for i, ev := range s.ctx.EventManager().Events() {
				switch ev.Type {
				case "provlabs.vault.v1.EventVaultReconcile":
					reconcileCount++
					reconcileIdx = i
				case "provlabs.vault.v1.EventAssetAccepted":
					acceptedIdx = i
				}
			}

			if tc.expectedErrContains != "" {
				s.Require().ErrorContains(err, tc.expectedErrContains, "AcceptAsset should fail for case %q", tc.name)
			} else {
				s.Require().NoError(err, "AcceptAsset should succeed for case %q", tc.name)
			}
			s.Assert().Equal(tc.expectedReconciles, reconcileCount, "EventVaultReconcile count mismatch for case %q", tc.name)
			if tc.expectedErrContains == "" && tc.expectedReconciles > 0 {
				s.Require().GreaterOrEqual(acceptedIdx, 0, "EventAssetAccepted should be emitted for case %q", tc.name)
				s.Assert().Less(reconcileIdx, acceptedIdx, "reconcile events should precede EventAssetAccepted for case %q", tc.name)
			}
		})
	}
}

func (s *TestSuite) TestMsgServer_AcceptAsset_InsufficientPrincipalDoesNotSettle() {
	underlying, share, asset := "under", "vshare", "rwacoin"
	externalID := "short-noop"

	vault, principalAddr, source, approved := s.setupAcceptAssetScenario(acceptAssetScenario{
		underlying:    underlying,
		share:         share,
		assetMarker:   asset,
		seedNav:       &types.VaultNAV{Denom: asset, Price: sdk.NewInt64Coin(underlying, 5), Volume: sdkmath.NewInt(10)},
		fundSource:    sdk.NewCoins(sdk.NewInt64Coin(asset, 10)),
		fundPrincipal: sdk.NewCoins(sdk.NewInt64Coin(underlying, 4)),
		sourceAmount:  sdk.NewCoins(sdk.NewInt64Coin(asset, 10)),
		targetAmount:  sdk.NewCoins(sdk.NewInt64Coin(underlying, 5)),
		externalID:    externalID,
	})
	vaultAddr := vault.GetAddress()

	_, err := keeper.NewMsgServer(s.simApp.VaultKeeper).AcceptAsset(s.ctx, &types.MsgAcceptAssetRequest{
		Authority:    s.assetManagerAddr.String(),
		VaultAddress: vaultAddr.String(),
		Payment:      approved,
	})
	s.Require().Error(err, "AcceptAsset should fail when principal is short")

	stored, getErr := s.simApp.ExchangeKeeper.GetPayment(s.ctx, source, externalID)
	s.Require().NoError(getErr, "GetPayment after failed settle")
	s.Require().NotNil(stored, "payment should remain in escrow after a failed settle")
	s.assertBalance(source, asset, sdkmath.NewInt(10))
	s.assertBalance(principalAddr, underlying, sdkmath.NewInt(4))
}

func (s *TestSuite) TestMsgServer_RejectAsset() {
	underlying, share, asset := "under", "vshare", "rwacoin"
	externalID := "p2p-reject"

	vault, _, source, _ := s.setupAcceptAssetScenario(acceptAssetScenario{
		underlying:   underlying,
		share:        share,
		fundSource:   sdk.NewCoins(sdk.NewInt64Coin(asset, 10)),
		sourceAmount: sdk.NewCoins(sdk.NewInt64Coin(asset, 10)),
		targetAmount: sdk.NewCoins(sdk.NewInt64Coin(underlying, 5)),
		externalID:   externalID,
	})
	vaultAddr := vault.GetAddress()

	s.ctx = s.ctx.WithEventManager(sdk.NewEventManager())
	resp, err := keeper.NewMsgServer(s.simApp.VaultKeeper).RejectAsset(s.ctx, &types.MsgRejectAssetRequest{
		Authority:    s.assetManagerAddr.String(),
		VaultAddress: vaultAddr.String(),
		Source:       source.String(),
		ExternalId:   externalID,
	})
	s.Require().NoError(err, "RejectAsset should succeed")
	s.Assert().Equal(&types.MsgRejectAssetResponse{}, resp, "RejectAsset response")

	stored, getErr := s.simApp.ExchangeKeeper.GetPayment(s.ctx, source, externalID)
	s.Require().NoError(getErr, "GetPayment after reject")
	s.Assert().Nil(stored, "payment should be deleted after reject")
	s.assertBalance(source, asset, sdkmath.NewInt(10))

	s.requireTypedEventEmitted(types.NewEventAssetRejected(vaultAddr.String(), source.String(), externalID))
}

func (s *TestSuite) TestMsgServer_RejectAsset_Failures() {
	underlying, share, asset := "under", "vshare", "rwacoin"

	tests := []struct {
		name               string
		setup              func() *types.MsgRejectAssetRequest
		expectedErrSubstrs []string
	}{
		{
			name: "vault does not exist",
			setup: func() *types.MsgRejectAssetRequest {
				source := s.CreateAndFundAccount(sdk.NewInt64Coin(asset, 10))
				return &types.MsgRejectAssetRequest{
					Authority:    s.adminAddr.String(),
					VaultAddress: types.GetVaultAddress("missing").String(),
					Source:       source.String(),
					ExternalId:   "none",
				}
			},
			expectedErrSubstrs: []string{"not found"},
		},
		{
			name: "unauthorized signer",
			setup: func() *types.MsgRejectAssetRequest {
				vault, _, source, _ := s.setupAcceptAssetScenario(acceptAssetScenario{
					underlying:   underlying,
					share:        share,
					fundSource:   sdk.NewCoins(sdk.NewInt64Coin(asset, 10)),
					sourceAmount: sdk.NewCoins(sdk.NewInt64Coin(asset, 10)),
					targetAmount: sdk.NewCoins(sdk.NewInt64Coin(underlying, 5)),
					externalID:   "unauth",
				})
				stranger := s.CreateAndFundAccount(sdk.NewInt64Coin(underlying, 1))
				return &types.MsgRejectAssetRequest{
					Authority:    stranger.String(),
					VaultAddress: vault.GetAddress().String(),
					Source:       source.String(),
					ExternalId:   "unauth",
				}
			},
			expectedErrSubstrs: []string{"failed to validate asset manager authority", "unauthorized authority"},
		},
		{
			name: "admin cannot reject, only the asset manager may",
			setup: func() *types.MsgRejectAssetRequest {
				vault, _, source, _ := s.setupAcceptAssetScenario(acceptAssetScenario{
					underlying:   underlying,
					share:        share,
					fundSource:   sdk.NewCoins(sdk.NewInt64Coin(asset, 10)),
					sourceAmount: sdk.NewCoins(sdk.NewInt64Coin(asset, 10)),
					targetAmount: sdk.NewCoins(sdk.NewInt64Coin(underlying, 5)),
					externalID:   "admin-reject",
				})
				return &types.MsgRejectAssetRequest{
					Authority:    s.adminAddr.String(),
					VaultAddress: vault.GetAddress().String(),
					Source:       source.String(),
					ExternalId:   "admin-reject",
				}
			},
			expectedErrSubstrs: []string{"failed to validate asset manager authority", "unauthorized authority"},
		},
		{
			name: "vault without an asset manager cannot reject",
			setup: func() *types.MsgRejectAssetRequest {
				vault, _, source, _ := s.setupAcceptAssetScenario(acceptAssetScenario{
					underlying:   underlying,
					share:        share,
					fundSource:   sdk.NewCoins(sdk.NewInt64Coin(asset, 10)),
					sourceAmount: sdk.NewCoins(sdk.NewInt64Coin(asset, 10)),
					targetAmount: sdk.NewCoins(sdk.NewInt64Coin(underlying, 5)),
					externalID:   "no-mgr",
				})
				vaultAddr := vault.GetAddress()
				_, err := keeper.NewMsgServer(s.simApp.VaultKeeper).SetAssetManager(s.ctx, &types.MsgSetAssetManagerRequest{
					Admin:        s.adminAddr.String(),
					VaultAddress: vaultAddr.String(),
					AssetManager: "",
				})
				s.Require().NoError(err, "failed to clear asset manager on vault %s", vaultAddr)
				return &types.MsgRejectAssetRequest{
					Authority:    s.adminAddr.String(),
					VaultAddress: vaultAddr.String(),
					Source:       source.String(),
					ExternalId:   "no-mgr",
				}
			},
			expectedErrSubstrs: []string{"failed to validate asset manager authority", "no asset manager set"},
		},
		{
			name: "payment does not exist",
			setup: func() *types.MsgRejectAssetRequest {
				vault, _, source, _ := s.setupAcceptAssetScenario(acceptAssetScenario{
					underlying:  underlying,
					share:       share,
					fundSource:  sdk.NewCoins(sdk.NewInt64Coin(asset, 10)),
					omitPayment: true,
				})
				return &types.MsgRejectAssetRequest{
					Authority:    s.assetManagerAddr.String(),
					VaultAddress: vault.GetAddress().String(),
					Source:       source.String(),
					ExternalId:   "ghost",
				}
			},
			expectedErrSubstrs: []string{"failed to reject payment"},
		},
	}

	for _, tc := range tests {
		s.Run(tc.name, func() {
			origCtx := s.ctx
			defer func() { s.ctx = origCtx }()
			s.ctx, _ = s.ctx.CacheContext()

			msg := tc.setup()
			s.ctx = s.ctx.WithEventManager(sdk.NewEventManager())

			resp, err := keeper.NewMsgServer(s.simApp.VaultKeeper).RejectAsset(s.ctx, msg)
			s.Require().Error(err, "RejectAsset should fail for case %q", tc.name)
			s.Assert().Nil(resp, "RejectAsset response should be nil on error for case %q", tc.name)
			for _, substr := range tc.expectedErrSubstrs {
				s.Assert().Containsf(err.Error(), substr, "RejectAsset error missing expected substring for case %q", tc.name)
			}
		})
	}
}
