#![allow(deprecated)]

//! # The GMX-Solana Store Program
//!
//! The Store Program defines several fundamental accounts that form the core of its functionality:
//!
//! - [`Store`](states::Store): A central account that serves as a global configuration store and
//!   permission manager. It acts as the authority ("owner") for other program accounts and manages
//!   role-based access control. The global [GT](#gt-model) state is also stored in this account.
//! - [`TokenMap`](states::TokenMap): A mapping of token configurations and price feed configurations
//!   that defines supported tokens and their associated price oracle feeds.
//! - [`Market`](states::Market): A market account that stores market-specific configurations and
//!   maintains the global market state.
//! - [`Position`](states::Position): Tracks a user's active position in a market.
//! - Basic Market Action accounts: Accounts that track user actions and positions in markets
//!   - [`Deposit`](states::Deposit): Tracks a user's pending deposit request into a market.
//!   - [`Withdrawal`](states::Withdrawal): Tracks a user's pending withdrawal request from a market.
//!   - [`Shift`](states::Shift): Tracks a user's pending request to shift from one kind of market token to another.
//!   - [`Order`](states::Order): Tracks a user's pending order request in a market, including swap orders and increase/decrease position orders.
//! - GLV (GMX Liquidity Vault) Action accounts: Accounts that track user interactions with GLV tokens.
//!   - [`GlvDeposit`](states::GlvDeposit): Tracks a user's pending deposit of tokens into a GLV pool to mint GLV tokens.
//!   - [`GlvWithdrawal`](states::GlvWithdrawal): Tracks a user's pending withdrawal of tokens from a GLV pool to burn GLV tokens and withdraw the underlying tokens.
//!   - [`GlvShift`](states::GlvShift): Tracks a keeper's pending request to rebalance tokens between different market pools within the GLV pool.
//! - User accounts (see [`UserHeader`](states::UserHeader) for details): Tracks user information including the GT and esGT balances of the user, referral code, and referral relationships.
//!
//! The instructions for the store program are categorized into the following sections:
//!
//! ## Store
//!
//! A [`Store`](states::Store) Account serves as both an authority and a global configuration
//! storage.
//!
//! A store and its associated accounts form a *deployment*. Each deployment operates independently,
//! allowing multiple instances of the protocol to coexist on-chain (only available when the
//! `multi-store` feature is enabled).
//!
//! #### Instructions for Store Accounts
//! - [`initialize`](gmsol_store::initialize): Create a new [`Store`](states::Store) account.
//! - [`transfer_store_authority`]: Transfer the authority of the given store to a new authority.
//! - [`transfer_receiver`](gmsol_store::transfer_receiver): Set the claimable fee receiver address.
//! - [`set_token_map`]: Set the token map account to use.
//!
//! #### Instructions for Config Management
//! - [`insert_amount`]: Insert an amount to the global config.
//! - [`insert_factor`]: Insert a factor to the global config.
//! - [`insert_address`]: Insert an address to the global config.
//! - [`insert_order_fee_discount_for_referred_user`]:
//!   Insert order fee discount for referred user factor to the global config.
//!
//! #### Instructions for Feature Management
//! - [`toggle_feature`]: Enable or disable the given feature.
//!
//! ## Role-based Permission Management
//!
//! The role-based permission system for each GMSOL deployment is managed through its
//! [`Store`](states::Store) Account. The permission structure consists of:
//!
//! - **Administrator Role**: A single administrator address stored in the `authority` field of the
//!   [`Store`](states::Store) Account. This address has exclusive rights to modify the permission table
//!   and use other administrative instructions.
//!
//! - **Custom Roles**: A flexible role system stored in the `role` field as a [`RoleStore`](states::RoleStore)
//!   structure. This allows for granular permission management through custom roles and role assignments.
//!   Each role can be assigned to multiple addresses.
//!
//! #### Instructions for Permission Management
//! - [`check_admin`](gmsol_store::check_admin): Check whether *the signer* is the admin of the given store.
//! - [`check_role`](gmsol_store::check_role): Check whether *the signer* has the given role in the given store.
//! - [`has_admin`](gmsol_store::has_admin): Return whether the given address is the admin of the given store.
//! - [`has_role`](gmsol_store::has_role): Return whether the given address has the given role in the given store.
//! - [`enable_role`]: Insert or enable a role for the given store.
//! - [`disable_role`]: Disable an existing role for the given store.
//! - [`grant_role`]: Grant a role to the given user in the given store.
//! - [`revoke_role`]: Revoke a role from the given user in the given store.
//!
//! ## Token Config and Oracle Management
//!
//! #### Instructions for managing [`TokenConfig`](states::TokenConfig) and token maps.
//! - [`initialize_token_map`](gmsol_store::initialize_token_map): Initialize a new token map account.
//!   This is a permissionless instruction.
//! - [`push_to_token_map`]: Push a new token config for an existing token to the given token map.
//! - [`push_to_token_map_synthetic`]: Push a new token config for a "synthetic"
//!   token to the given token map.
//! - [`toggle_token_config`]: Enable or disable a token config of the given token map.
//! - [`set_expected_provider`]: Set the expected provider for the given token.
//! - [`set_feed_config_v2`]: Set the feed config of the given provider for the given token.
//! - [`set_feed_config_market_status_flag`]: Set a market-status flag on the feed config of the given provider for the given token.
//! - [`is_token_config_enabled`](gmsol_store::is_token_config_enabled): Check if the config for the given token is enabled.
//! - [`token_expected_provider`](gmsol_store::token_expected_provider): Get the expected provider set for the given token.
//! - [`token_feed`](gmsol_store::token_feed): Get the feed address of the given provider set for the given token.
//! - [`token_timestamp_adjustment`](gmsol_store::token_timestamp_adjustment): Get the timestamp adjustment of the given
//!   provider for the give token.
//! - [`token_name`](gmsol_store::token_name): Get the name of the given token.
//! - [`token_decimals`](gmsol_store::token_decimals): Get the token decimals of the given token.
//! - [`token_precision`](gmsol_store::token_precision): Get the price precision of the given token.
//!
//! #### Instructions for [`Oracle`](states::Oracle) accounts
//! - [`initialize_oracle`](gmsol_store::initialize_oracle): Initialize a new [`Oracle`](states::Oracle) account.
//! - [`clear_all_prices`]: Clear the prices of the given oracle account.
//! - [`set_prices_from_price_feed`]: Validate and set prices parsed from the
//!   provided price feed accounts.
//! - [`initialize_price_feed`]: Initialize a custom price feed.
//! - [`update_price_feed_with_chainlink`]: Update a custom Chainlink price feed with Chainlink Data Streams report.
//!
//! ## Market Management
//!
//! *[See also the module level documentation for Market for details.](states::market)*
//!
//! #### Instructions for [`Market`](states::Market) management
//! - [`initialize_market`]: Initialize a [`Market`](states::Market) account.
//! - [`toggle_market`]: Enable or disable the given market.
//! - [`market_transfer_in`]: Transfer tokens into the market and record the amount in its balance.
//! - [`update_market_config`]: Update an item in the market config.
//! - [`update_market_config_with_buffer`]: Update the market config with the given
//!   [`MarketConfigBuffer`](states::market::config::MarketConfigBuffer) account.
//! - [`get_market_status`](gmsol_store::get_market_status): Calculate the market status with the given prices.
//! - [`get_market_token_price`](gmsol_store::get_market_token_price): Calculate the market token price the given prices.
//! - [`toggle_gt_minting`]: Enable or disable GT minting for the given market.
//!
//! #### Instructions for [`MarketConfigBuffer`](states::market::config::MarketConfigBuffer) accounts
//! - [`initialize_market_config_buffer`](gmsol_store::initialize_market_config_buffer): Initialize a market config buffer account.
//! - [`set_market_config_buffer_authority`](gmsol_store::set_market_config_buffer_authority): Replace the authority of the market
//!   config buffer account with the new one.
//! - [`close_market_config_buffer`](gmsol_store::close_market_config_buffer): Close the given market config buffer account.
//! - [`push_to_market_config_buffer`](gmsol_store::push_to_market_config_buffer): Push config items to the given market config
//!   buffer account.
//!
//! #### Instructions for token accounts
//! - [`initialize_market_vault`]: Initialize the market vault for the given token.
//! - [`use_claimable_account`]: Prepare a claimable account to receive tokens during the order execution.
//! - [`close_empty_claimable_account`]: Close a empty claimable account.
//! - [`prepare_associated_token_account`](gmsol_store::prepare_associated_token_account): Prepare an ATA.
//!
//! ## Exchange
//! The instructions for providing functionalities as an exchange are as follows:
//!
//! #### Instructions for [`Deposit`](states::Deposit)
//! - [`create_deposit`]: Create a deposit by the owner.
//! - [`execute_deposit`](gmsol_store::execute_deposit()): Execute a deposit by keepers.
//! - [`close_deposit`]: Close a deposit, either by the owner or by keepers.
//!
//! #### Instructions for [`Withdrawal`](states::Withdrawal)
//! - [`create_withdrawal`]: Create a withdrawal by the owner.
//! - [`execute_withdrawal`](gmsol_store::execute_withdrawal()): Execute a withdrawal by keepers.
//! - [`close_withdrawal`]: Close a withdrawal, either by the owner or by keepers.
//!
//! #### Instructions for [`Shift`](states::Shift)
//! - [`create_shift`]: Create a shift by the owner.
//! - [`execute_shift`](gmsol_store::execute_shift()): Execute a shift by keepers.
//! - [`close_shift`]: Close a shift, either by the owner or by keepers.
//!
//! #### Instructions for [`Order`](states::Order) and [`Position`](states::Position)
//! - [`prepare_position`](gmsol_store::prepare_position): Prepare the position account for orders.
//! - [`prepare_trade_event_buffer`](gmsol_store::prepare_trade_event_buffer): Prepare trade event buffer.
//! - [`create_order_v2`]: Create an order by the owner.
//! - [`update_order_v2`]: Update an order by the owner.
//! - [`execute_increase_or_swap_order_v2`]: Execute an order by keepers.
//! - [`execute_decrease_order_v2`]: Execute a decrease order by keepers.
//! - [`close_order_v2`]: Close an order, either by the owner or by keepers.
//! - [`cancel_order_if_no_position`]: Cancel an order if the position does not exist.
//! - [`liquidate`]: Perform a liquidation by keepers.
//! - [`auto_deleverage`]: Perform an ADL by keepers.
//! - [`update_adl_state`]: Update the ADL state of the market.
//!
//! ## GLV (GMX Liquidity Vault) Pools
//! The instructions for providing functionalities for GLV are as follows:
//!
//! #### Instructions for [`Glv`](states::Glv).
//! - [`initialize_glv`]: Initialize a GLV.
//! - [`update_glv_market_config`]: Update GLV market config.
//! - [`toggle_glv_market_flag`]: Toggle flags of GLV market.
//! - [`update_glv_config`]: Update GLV global config.
//! - [`insert_glv_market`]: Insert a new market to the GLV.
//! - [`remove_glv_market`]: Remove a market from the GLV.
//!
//! #### Instructions for [`GlvDeposit`](states::GlvDeposit)
//! - [`create_glv_deposit`]: Create a GLV deposit by the owner.
//! - [`execute_glv_deposit`]: Execute a GLV deposit by keepers.
//! - [`close_glv_deposit`]: Close a GLV deposit, either by the owner or by keepers.
//!
//! #### Instructions for [`GlvWithdrawal`](states::glv::GlvWithdrawal)
//! - [`create_glv_withdrawal`]: Create a GLV withdrawal by the owner.
//! - [`execute_glv_withdrawal`]: Execute a GLV withdrawal by keepers.
//! - [`close_glv_withdrawal`]: Close a GLV withdrawal, either by the owner or by keepers.
//!
//! #### Instructions for [`GlvShift`](states::glv::GlvShift)
//! - [`create_glv_shift`]: Create a GLV shift by keepers.
//! - [`execute_glv_shift`]: Execute a GLV shift by keepers.
//! - [`close_glv_shift`]: Close a shift by keepers.
//!
//! ## User Accounts and Referrals
//! The instructions for user accounts and referrals are as follows:
//! - [`prepare_user`](gmsol_store::prepare_user): Prepare a user account.
//! - [`initialize_referral_code`](gmsol_store::initialize_referral_code): Initialize and set a referral code.
//! - [`set_referrer`](gmsol_store::set_referrer): Set the referrer.
//! - [`transfer_referral_code`](gmsol_store::transfer_referral_code): Transfer the referral code to others.
//! - [`cancel_referral_code_transfer`](gmsol_store::cancel_referral_code_transfer): Cancel the referral code transfer.
//! - [`accept_referral_code`](gmsol_store::accept_referral_code): Complete the referral code transfer.
//! - [`set_builder_fee_factor`](gmsol_store::set_builder_fee_factor): Set the builder fee factor advertised by the user.
//!
//! ## GT Model
//!
//! *[See also the module level documentation for GT for details.](states::gt)*
//!
//! The instructions for GT Model are as follows:
//! - [`initialize_gt`]: Initialize the GT state.
//! - [`gt_set_order_fee_discount_factors`]: Set order fee discount factors.
//! - [`gt_set_referral_reward_factors`]: Set referral reward factors.
//! - [`gt_set_exchange_time_window`]: Set GT exchange time window.
//! - [`prepare_gt_exchange_vault`](gmsol_store::prepare_gt_exchange_vault): Prepare current GT exchange vault.
//! - [`confirm_gt_exchange_vault_v2`]: Confirm GT exchange vault.
//! - [`request_gt_exchange`](gmsol_store::request_gt_exchange): Request a GT exchange.
//! - [`close_gt_exchange`]: Close a confirmed GT exchange.

/// Instructions.
pub mod instructions;

/// States.
pub mod states;

/// Operations.
pub mod ops;

/// Constants.
pub mod constants;

/// Utils.
pub mod utils;

/// Events.
pub mod events;

use self::{
    instructions::*,
    ops::{
        deposit::CreateDepositParams,
        glv::{CreateGlvDepositParams, CreateGlvWithdrawalParams},
        order::{CreateOrderParams, PositionCutKind},
        shift::CreateShiftParams,
        withdrawal::CreateWithdrawalParams,
    },
    states::{
        glv::UpdateGlvParams,
        market::{config::EntryArgs, status::MarketStatus},
        order::UpdateOrderParams,
        token_config::UpdateTokenConfigParams,
        FactorKey, PriceProviderKind,
    },
    utils::internal,
};
use anchor_lang::prelude::*;
use gmsol_model::price::Prices;

#[cfg_attr(test, macro_use)]
extern crate static_assertions;

declare_id!("Gmso1uvJnLbawvw7yezdfCDcPydwW2s2iqG3w6MDucLo");

#[program]
/// Instructions definitions of the GMSOL Store Program.
pub mod gmsol_store {
    use gmsol_utils::price::market_status::MarketStatusFlag;
    use gmsol_utils::token_config::TokenConfigFlag;

    use super::*;

    // ===========================================
    //                   Store
    // ===========================================

    /// Create a new [`Store`](states::Store) account.
    ///
    /// # Accounts
    /// *[See the documentation for the accounts.](Initialize).*
    ///
    /// # Arguments
    /// - `key`: The name of the store, used as a seed to derive the store account's address.
    ///   The length must not exceed [`MAX_LEN`](states::Store::MAX_LEN).
    ///
    /// # Errors
    /// - The `key` must be empty unless the `multi-store` feature is enabled
    /// - The [`payer`](Initialize::payer) must be a signer
    /// - The [`authority`](Initialize::authority) must be as signer if it is provided.
    /// - The [`receiver`](Initialize::receiver) must be as signer if it is provided.
    /// - The [`holding`](Initialize::holding) must be as signer if it is provided.
    /// - The [`store`](Initialize::store) must not be initialized
    /// - The [`store`](Initialize::store) address must match the PDA derived from
    ///   the seed of [`Store`](states::Store) and the SHA-256 hash of `key`
    pub fn initialize(ctx: Context<Initialize>, key: String) -> Result<()> {
        instructions::initialize(ctx, key)
    }

    /// Update last restarted slot.
    ///
    /// # Accounts
    /// *[See the documentation for the accounts.](UpdateLastRestartedSlot).*
    ///
    /// # Errors
    /// - The [`authority`](UpdateLastRestartedSlot::authority) must be a signer and the current
    ///   admin of the store.
    /// - The [`store`](UpdateLastRestartedSlot::store) must be an initialized store account
    ///   owned by the store program.
    #[access_control(internal::Authenticate::only_admin(&ctx))]
    pub fn update_last_restarted_slot(ctx: Context<UpdateLastRestartedSlot>) -> Result<()> {
        instructions::update_last_restarted_slot(ctx)
    }

    /// Request to transfer the authority (admin) of the given store to a new address.
    /// # Note
    /// This instruction only sets `next_authority`. Use [`accept_store_authority`] to
    /// complete the transfer.
    ///
    /// # Accounts
    /// *[See the documentation for the accounts.](TransferStoreAuthority).*
    ///
    /// # Errors
    /// - The [`authority`](TransferStoreAuthority::authority) must be a signer and the current
    ///   admin of the store.
    /// - The [`store`](TransferStoreAuthority::store) must be an initialized store account
    ///   owned by the store program.
    /// - The [`next_authority`](TransferStoreAuthority::next_authority) cannot be the same as
    ///   current `next_authority`.
    #[access_control(internal::Authenticate::only_admin(&ctx))]
    pub fn transfer_store_authority(ctx: Context<TransferStoreAuthority>) -> Result<()> {
        instructions::unchecked_transfer_store_authority(ctx)
    }

    /// Accept the transfer of the authority (admin) of the given store.
    ///
    /// # Accounts
    /// *[See the documentation for the accounts.](AcceptStoreAuthority).*
    ///
    /// # Errors
    /// - The [`next_authority`](AcceptStoreAuthority::next_authority) must be a signer and the current
    ///   `next_authority` of the store.
    /// - The [`store`](TransferStoreAuthority::store) must be an initialized store account
    ///   owned by the store program.
    pub fn accept_store_authority(ctx: Context<AcceptStoreAuthority>) -> Result<()> {
        instructions::accept_store_authority(ctx)
    }

    /// Request to transfer the receiver address to a new one.
    /// # Note
    /// This instruction only sets `next_receiver`. Use [`accept_receiver`] to
    /// complete the transfer.
    ///
    /// # Accounts
    /// *[See the documentation for the accounts.](TransferReceiver).*
    ///
    /// # Errors
    /// - The [`authority`](TransferReceiver::authority) must be a signer and the current receiver
    ///   of the given store.
    /// - The [`store`](TransferReceiver::store) must be an initialized store account owned by
    ///   the store program.
    /// - The new [`next_receiver`](TransferReceiver::next_receiver) account provided cannot be the same as
    ///   the current `next_receiver`.
    pub fn transfer_receiver(ctx: Context<TransferReceiver>) -> Result<()> {
        instructions::transfer_receiver(ctx)
    }

    /// Accept the transfer of the receiver address of the given store.
    ///
    /// # Accounts
    /// *[See the documentation for the accounts.](AcceptReceiver).*
    ///
    /// # Errors
    /// - The [`next_receiver`](AcceptReceiver::next_receiver) must be a signer and the current
    ///   `next_receiver` of the store.
    /// - The [`store`](AcceptReceiver::store) must be an initialized store account
    ///   owned by the store program.
    pub fn accept_receiver(ctx: Context<AcceptReceiver>) -> Result<()> {
        instructions::accept_receiver(ctx)
    }

    /// Set the token map address for the store.
    ///
    /// This instruction allows a MARKET_KEEPER to update which token map account the store uses.
    /// The token map account contains token configurations and price feed configurations.
    ///
    /// We say the token map is *authorized by the store* if the token map address of the store is
    /// the same as the address of the token map account.
    ///
    /// # Accounts
    /// *[See the documentation for the accounts.](SetTokenMap).*
    ///
    /// # Errors
    /// - The [`authority`](SetTokenMap::authority) must be a signer and have the MARKET_KEEPER
    ///   role in the store.
    /// - The [`store`](SetTokenMap::store) must be an initialized store account owned by the
    ///   store program.
    /// - The [`token_map`](SetTokenMap::token_map) must be an initialized token map account
    ///   and owned by the given store.
    /// - The new token map address cannot be the same as the current one.
    #[access_control(internal::Authenticate::only_market_keeper(&ctx))]
    pub fn set_token_map(ctx: Context<SetTokenMap>) -> Result<()> {
        instructions::unchecked_set_token_map(ctx)
    }

    // ===========================================
    //      Role-based Permission Management
    // ===========================================

    /// Return whether the signer is the admin of the given store.
    ///
    /// This instruction verifies if the signer has administrator privileges for the given store
    /// and returns a boolean result.
    ///
    /// # Accounts
    /// *[See the documentation for the accounts.](CheckRole).*
    ///
    /// # Returns
    /// Returns `true` if the signer is the admin, `false` otherwise.
    ///
    /// # Errors
    /// - The [`authority`](CheckRole::authority) must be a signer.
    /// - The [`store`](CheckRole::store) must be an initialized store account owned by
    ///   the store program.
    pub fn check_admin(ctx: Context<CheckRole>) -> Result<bool> {
        instructions::check_admin(ctx)
    }

    /// Check that the authority has the given role in the given store.
    ///
    /// This instruction verifies if the authority has the specified role in the given store
    /// and returns a boolean result.
    ///
    /// # Accounts
    /// *[See the documentation for the accounts.](CheckRole).*
    ///
    /// # Arguments
    /// - `role`: The name of the role to check for the authority.
    ///
    /// # Returns
    /// Returns `true` if the authority has the role, `false` otherwise.
    ///
    /// # Errors
    /// - The [`authority`](CheckRole::authority) must be a signer.
    /// - The [`store`](CheckRole::store) must be an initialized store account owned by
    ///   the store program.
    /// - The `role` must exist and be enabled in the store's role configuration.
    pub fn check_role(ctx: Context<CheckRole>, role: String) -> Result<bool> {
        instructions::check_role(ctx, role)
    }

    /// Return whether the given address is the administrator of the given store.
    ///
    /// This instruction checks if the provided address has administrator privileges for the given store
    /// and returns a boolean result.
    ///
    /// # Accounts
    /// *[See the documentation for the accounts.](HasRole).*
    ///
    /// # Arguments
    /// - `authority`: The address to check for administrator privileges.
    ///
    /// # Returns
    /// Returns `true` if the address is the administrator, `false` otherwise.
    ///
    /// # Errors
    /// - The [`store`](HasRole::store) must be an initialized store account owned by
    ///   the store program.
    pub fn has_admin(ctx: Context<HasRole>, authority: Pubkey) -> Result<bool> {
        instructions::has_admin(ctx, authority)
    }

    /// Return whether the given address has the given role in the given store.
    ///
    /// This instruction checks if the provided address has the specified role in the given store
    /// and returns a boolean result.
    ///
    /// # Accounts
    /// *[See the documentation for the accounts.](HasRole).*
    ///
    /// # Arguments
    /// - `authority`: The address to check for role membership.
    /// - `role`: The name of the role to check for the authority.
    ///
    /// # Returns
    /// Returns `true` if the address has the specified role, `false` otherwise.
    ///
    /// # Errors
    /// - The [`store`](HasRole::store) must be an initialized store account owned by
    ///   the store program.
    /// - The `role` must exist and be enabled in the store's role configuration.
    pub fn has_role(ctx: Context<HasRole>, authority: Pubkey, role: String) -> Result<bool> {
        instructions::has_role(ctx, authority, role)
    }

    /// Insert or enable a role for the given store.
    ///
    /// This instruction adds a new role or enables an existing disabled role in the store's role configuration.
    ///
    /// # Accounts
    /// *[See the documentation for the accounts.](EnableRole).*
    ///
    /// # Arguments
    /// - `role`: The name of the role to be added/enabled. The length cannot exceed
    ///   [`MAX_ROLE_NAME_LEN`](states::roles::MAX_ROLE_NAME_LEN).
    ///
    /// # Errors
    /// - The [`authority`](EnableRole::authority) must be a signer and be the `ADMIN` of the store.
    /// - The [`store`](EnableRole::store) must be an initialized store account owned by the store program.
    /// - The `role` name length must not exceed [`MAX_ROLE_NAME_LEN`](states::roles::MAX_ROLE_NAME_LEN).
    /// - The `role` must not be already enabled.
    #[access_control(internal::Authenticate::only_admin(&ctx))]
    pub fn enable_role(ctx: Context<EnableRole>, role: String) -> Result<()> {
        instructions::unchecked_enable_role(ctx, role)
    }

    /// Disable an existing role for the given store.
    ///
    /// This instruction disables an existing role in the store's role configuration.
    ///
    /// # Accounts
    /// *[See the documentation for the accounts.](DisableRole).*
    ///
    /// # Arguments
    /// - `role`: The name of the role to be disabled.
    ///
    /// # Errors
    /// - The [`authority`](DisableRole::authority) must be a signer and be the `ADMIN` of the store.
    /// - The [`store`](DisableRole::store) must be an initialized store account owned by the store program.
    /// - The `role` must be enabled.
    #[access_control(internal::Authenticate::only_admin(&ctx))]
    pub fn disable_role(ctx: Context<DisableRole>, role: String) -> Result<()> {
        instructions::unchecked_disable_role(ctx, role)
    }

    /// Grant a role to the given user in the given store.
    ///
    /// This instruction grants a role to a user in the store's role configuration. If the user already
    /// has the role, this instruction has no effect.
    ///
    /// # Accounts
    /// *[See the documentation for the accounts.](GrantRole).*
    ///
    /// # Arguments
    /// - `user`: The address of the user to whom the role should be granted.
    /// - `role`: The name of the role to be granted. Must be an enabled role in the store.
    ///
    /// # Errors
    /// - The [`authority`](GrantRole::authority) must be a signer and be the `ADMIN` of the store.
    /// - The [`store`](GrantRole::store) must be an initialized store account owned by the store program.
    /// - The `role` must exist and be enabled in the store's role table.
    #[access_control(internal::Authenticate::only_admin(&ctx))]
    pub fn grant_role(ctx: Context<GrantRole>, user: Pubkey, role: String) -> Result<()> {
        instructions::unchecked_grant_role(ctx, user, role)
    }

    /// Revoke a role from the given user in the given store.
    ///
    /// This instruction revokes a role from a user in the store's role configuration. If the user does
    /// not have the role, this instruction has no effect.
    ///
    /// # Accounts
    /// *[See the documentation for the accounts.](RevokeRole).*
    ///
    /// # Arguments
    /// - `user`: The address of the user from whom the role should be revoked.
    /// - `role`: The name of the role to be revoked.
    ///
    /// # Errors
    /// - The [`authority`](RevokeRole::authority) must be a signer and be the `ADMIN` of the store.
    /// - The [`store`](RevokeRole::store) must be an initialized store account owned by the store program.
    /// - The `role` must exist in the store's role table.
    /// - The `user` must exist in the store's member table.
    #[access_control(internal::Authenticate::only_admin(&ctx))]
    pub fn revoke_role(ctx: Context<RevokeRole>, user: Pubkey, role: String) -> Result<()> {
        instructions::unchecked_revoke_role(ctx, user, role)
    }

    // ===========================================
    //              Config Management
    // ===========================================

    /// Insert an amount value into the store's global configuration.
    ///
    /// This instruction allows a CONFIG_KEEPER to set or update an amount value in the store's
    /// configuration. The key must be one of the predefined amount keys.
    ///
    /// # Accounts
    /// *[See the documentation for the accounts.](InsertConfig).*
    ///
    /// # Arguments
    /// - `key`: The configuration key to update. Must be a valid amount key defined in
    ///   [`AmountKey`](crate::states::AmountKey).
    /// - `amount`: The amount value to store for this configuration key.
    ///
    /// # Errors
    /// - The [`authority`](InsertConfig::authority) must be a signer and have the CONFIG_KEEPER role
    ///   in the store.
    /// - The provided `key` must be defined in [`AmountKey`](crate::states::AmountKey).
    /// - The store must be initialized and owned by this program.
    #[access_control(internal::Authenticate::only_config_keeper(&ctx))]
    pub fn insert_amount(ctx: Context<InsertConfig>, key: String, amount: u64) -> Result<()> {
        instructions::unchecked_insert_amount(ctx, &key, amount)
    }

    /// Insert a factor value into the store's global configuration.
    /// This instruction allows a CONFIG_KEEPER to set or update a factor value in the store's
    /// configuration. The key must be one of the predefined factor keys.
    ///
    /// # Accounts
    /// *[See the documentation for the accounts.](InsertConfig).*
    ///
    /// # Arguments
    /// - `key`: The configuration key to update. Must be a valid factor key defined in
    ///   [`FactorKey`](crate::states::FactorKey).
    /// - `factor`: The factor value to store for this configuration key.
    ///
    /// # Errors
    /// - The [`authority`](InsertConfig::authority) must be a signer and have the CONFIG_KEEPER role
    ///   in the store.
    /// - The provided `key` must be defined in [`FactorKey`](crate::states::FactorKey).
    /// - The store must be initialized and owned by this program.
    #[access_control(internal::Authenticate::only_config_keeper(&ctx))]
    pub fn insert_factor(ctx: Context<InsertConfig>, key: String, factor: u128) -> Result<()> {
        instructions::unchecked_insert_factor(ctx, &key, factor)
    }

    /// Insert an address value into the store's global configuration.
    ///
    /// This instruction allows a CONFIG_KEEPER to set or update an address value in the store's
    /// configuration. The key must be one of the predefined address keys.
    ///
    /// # Accounts
    /// *[See the documentation for the accounts.](InsertConfig).*
    ///
    /// # Arguments
    /// - `key`: The configuration key to update. Must be a valid address key defined in
    ///   [`AddressKey`](crate::states::AddressKey).
    /// - `address`: The address value to store for this configuration key.
    ///
    /// # Errors
    /// - The [`authority`](InsertConfig::authority) must be a signer and have the CONFIG_KEEPER role
    ///   in the store.
    /// - The provided `key` must be defined in [`AddressKey`](crate::states::AddressKey).
    /// - The store must be initialized and owned by this program.
    #[access_control(internal::Authenticate::only_config_keeper(&ctx))]
    pub fn insert_address(ctx: Context<InsertConfig>, key: String, address: Pubkey) -> Result<()> {
        instructions::unchecked_insert_address(ctx, &key, address)
    }

    /// Insert order fee discount for referred user factor to the global config.
    ///
    /// This instruction allows a MARKET_KEEPER to set or update the GT minting cost referred
    /// discount factor in the store's configuration. This factor determines the discount
    /// applied to GT minting costs for referred users.
    ///
    /// # Accounts
    /// *[See the documentation for the accounts.](InsertConfig).*
    ///
    /// # Arguments
    /// - `factor`: The discount factor value to set.
    ///
    /// # Errors
    /// - The [`authority`](InsertConfig::authority) must be a signer and have the
    ///   MARKET_KEEPER role in the store.
    /// - The store must be initialized and owned by this program.
    ///
    /// # Notes
    /// - While [`insert_factor`] can also modify this value, it requires CONFIG_KEEPER
    ///   permissions instead of MARKET_KEEPER permissions required by this instruction.
    /// - The factor is stored under the [`FactorKey::OrderFeeDiscountForReferredUser`] key.
    #[access_control(internal::Authenticate::only_market_keeper(&ctx))]
    pub fn insert_order_fee_discount_for_referred_user(
        ctx: Context<InsertConfig>,
        factor: u128,
    ) -> Result<()> {
        let key = FactorKey::OrderFeeDiscountForReferredUser;
        instructions::unchecked_insert_factor(ctx, &key.to_string(), factor)
    }

    // ===========================================
    //             Feature Management
    // ===========================================

    /// Enable or disable a feature in this deployment.
    ///
    /// This instruction allows a FEATURE_KEEPER to toggle specific features on or off by providing
    /// a domain and action combination. Features are used to control which functionality is available
    /// in this deployment.
    ///
    /// # Accounts
    /// *[See the documentation for the accounts.](ToggleFeature).*
    ///
    /// # Arguments
    /// - `domain`: The domain part of the feature flag, must be a valid domain defined in
    ///   [`DomainDisabledFlag`](crate::states::feature::DomainDisabledFlag).
    /// - `action`: The action part of the feature flag, must be a valid action defined in
    ///   [`ActionDisabledFlag`](crate::states::feature::ActionDisabledFlag).
    /// - `enable`: If true, enables the feature. If false, disables it.
    ///
    /// # Errors
    /// - The [`authority`](ToggleFeature::authority) must be a signer and have the
    ///   FEATURE_KEEPER role in the store.
    /// - The `domain` must be a valid domain defined in [`DomainDisabledFlag`](crate::states::feature::DomainDisabledFlag).
    /// - The `action` must be a valid action defined in [`ActionDisabledFlag`](crate::states::feature::ActionDisabledFlag).
    ///
    /// # Warnings
    /// Although we currently do not provide a feature to disable swaps (only a feature to disable swap orders),
    /// if we were to introduce such a feature, we must be aware that the following operations could still potentially
    /// result in swaps:
    /// - (GLV) Deposits
    /// - (GLV) Withdrawals
    /// - Swap Orders
    /// - Increase Orders
    /// - Decrease Orders
    ///
    /// Therefore, to ensure that this feature effectively prevents swaps from occurring, we need to add
    /// validation of the swap parameters before executing all of these actions to ensure that swaps do not happen.
    #[access_control(internal::Authenticate::only_feature_keeper(&ctx))]
    pub fn toggle_feature(
        ctx: Context<ToggleFeature>,
        domain: String,
        action: String,
        enable: bool,
    ) -> Result<()> {
        let domain = domain
            .parse()
            .map_err(|_| error!(CoreError::InvalidArgument))?;
        let action = action
            .parse()
            .map_err(|_| error!(CoreError::InvalidArgument))?;
        instructions::unchecked_toggle_feature(ctx, domain, action, enable)
    }

    // ===========================================
    //           Token Config Management
    // ===========================================

    /// Initialize a new token map account with its store set to [`store`](InitializeTokenMap::store).
    ///
    /// Anyone can initialize a token map account without any permissions, but after initialization, only
    /// addresses authorized by the store can modify this token map (i.e. have the `MARKET_KEEPER` role).
    ///
    /// # Accounts
    /// *[See the documentation for the accounts.](InitializeTokenMap)*
    ///
    /// # Errors
    /// - The [`payer`](InitializeTokenMap::payer) must be a signer.
    /// - The [`store`](InitializeTokenMap::store) must be an initialized [`Store`](states::Store)
    ///   account owned by the store program.
    /// - The [`token_map`](InitializeTokenMap::token_map) must be an uninitialized account.
    pub fn initialize_token_map(ctx: Context<InitializeTokenMap>) -> Result<()> {
        instructions::initialize_token_map(ctx)
    }

    /// Push a new token config to the given token map.
    ///
    /// This instruction is used to add or update the token config for an existing token.
    /// The token's decimals will be automatically set based on the token mint account.
    ///
    /// # Accounts
    /// [*See the documentation for the accounts*](PushToTokenMap).
    ///
    /// # Arguments
    /// - `name`: The token identifier (e.g. "WSOL", "WBTC")
    /// - `builder`: Configuration builder containing token parameters
    /// - `enable`: If true, enables this token config after pushing. If false, disables it.
    /// - `new`: If true, requires this to be a new token config. An error will be returned if
    ///   a config already exists for this token. If false, allows updating existing configs.
    ///
    /// # Errors
    /// - The [`authority`](PushToTokenMap::authority) must be a signer with the MARKET_KEEPER role
    /// - The [`store`](PushToTokenMap::store) must be an initialized [`Store`](states::Store)
    ///   account owned by the store program.
    /// - The [`token_map`](PushToTokenMap::token_map) must be initialized and owned by the `store`.
    /// - The [`token`](PushToTokenMap::token) must be a valid SPL token mint account.
    /// - If `new` is true, the token must not already have a config in the map.
    #[access_control(internal::Authenticate::only_market_keeper(&ctx))]
    pub fn push_to_token_map(
        ctx: Context<PushToTokenMap>,
        name: String,
        builder: UpdateTokenConfigParams,
        enable: bool,
        new: bool,
    ) -> Result<()> {
        instructions::unchecked_push_to_token_map(ctx, &name, builder, enable, new)
    }

    /// Push a new synthetic token config to the given token map.
    ///
    /// This instruction allows adding or updating token configurations for synthetic tokens that don't have
    /// an actual SPL token mint account. Unlike regular tokens where decimals are read from the mint,
    /// synthetic tokens specify their decimals directly through the `token_decimals` parameter.
    ///
    /// # Accounts
    /// [*See the documentation for the accounts*](PushToTokenMapSynthetic).
    ///
    /// # Arguments
    /// - `name`: The identifier for the synthetic token (e.g. "BTC")
    /// - `token`: The public key to use as the synthetic token's address
    /// - `token_decimals`: Number of decimals for the synthetic token's amounts
    /// - `builder`: Configuration builder containing token parameters
    /// - `enable`: If true, enables this token config after pushing. If false, disables it.
    /// - `new`: If true, requires this to be a new token config. An error will be returned if
    ///   a config already exists for this token. If false, allows updating the existing config.
    ///
    /// # Errors
    /// - The [`authority`](PushToTokenMapSynthetic::authority) must be a signer with the MARKET_KEEPER role.
    /// - The [`store`](PushToTokenMapSynthetic::store) must be an initialized [`Store`](states::Store)
    ///   account owned by the store program.
    /// - The [`token_map`](PushToTokenMapSynthetic::token_map) must be initialized and owned by the `store`.
    /// - If updating an existing config, the `token_decimals` must match the original value.
    /// - If `new` is true, the token must not already have a config in the map.
    #[access_control(internal::Authenticate::only_market_keeper(&ctx))]
    pub fn push_to_token_map_synthetic(
        ctx: Context<PushToTokenMapSynthetic>,
        name: String,
        token: Pubkey,
        token_decimals: u8,
        builder: UpdateTokenConfigParams,
        enable: bool,
        new: bool,
    ) -> Result<()> {
        instructions::unchecked_push_to_token_map_synthetic(
            ctx,
            &name,
            token,
            token_decimals,
            builder,
            enable,
            new,
        )
    }

    /// Enable or disable the config for the given token.
    ///
    /// # Accounts
    /// [*See the documentation for the accounts*](ToggleTokenConfig).
    ///
    /// # Arguments
    /// - `token`: The token whose config will be updated.
    /// - `enable`: Enable or disable the config.
    ///
    /// # Errors
    /// - The [`authority`](ToggleTokenConfig::authority) must be a signer
    ///   and a MARKET_KEEPER in the given store.
    /// - The [`store`](ToggleTokenConfig::store) must be an initialized [`Store`](states::Store)
    ///   account owned by the store program .
    /// - The [`token_map`](ToggleTokenConfig::token_map) must be an initialized token map account
    ///   owned by the `store`.
    /// - The given `token` must exist in the token map.
    #[access_control(internal::Authenticate::only_market_keeper(&ctx))]
    pub fn toggle_token_config(
        ctx: Context<ToggleTokenConfig>,
        token: Pubkey,
        enable: bool,
    ) -> Result<()> {
        ToggleTokenConfig::invoke_unchecked(ctx, token, TokenConfigFlag::Enabled, enable)
    }

    /// Enable or disable price adjustment for the token.
    ///
    /// # Accounts
    /// [*See the documentation for the accounts*](ToggleTokenConfig).
    ///
    /// # Arguments
    /// - `token`: The token whose config will be updated.
    /// - `enable`: Enable or disable.
    ///
    /// # Errors
    /// - The [`authority`](ToggleTokenConfig::authority) must be a signer
    ///   and a MARKET_KEEPER in the given store.
    /// - The [`store`](ToggleTokenConfig::store) must be an initialized [`Store`](states::Store)
    ///   account owned by the store program .
    /// - The [`token_map`](ToggleTokenConfig::token_map) must be an initialized token map account
    ///   owned by the `store`.
    /// - The given `token` must exist in the token map.
    #[access_control(internal::Authenticate::only_market_keeper(&ctx))]
    pub fn toggle_token_price_adjustment(
        ctx: Context<ToggleTokenConfig>,
        token: Pubkey,
        enable: bool,
    ) -> Result<()> {
        ToggleTokenConfig::invoke_unchecked(
            ctx,
            token,
            TokenConfigFlag::AllowPriceAdjustment,
            enable,
        )
    }

    /// Set a market-status flag on the feed config of the given provider for
    /// the given token.
    ///
    /// # Accounts
    /// [*See the documentation for the accounts*](SetFeedConfigMarketStatusFlag).
    ///
    /// # Arguments
    /// - `provider`: The index of the provider whose feed config will be updated.
    ///   Must be a valid [`PriceProviderKind`] value.
    /// - `flag`: The [`MarketStatusFlag`] index to set.
    /// - `enable`: Enable or disable the flag.
    ///
    /// # Errors
    /// - The [`authority`](SetFeedConfigMarketStatusFlag::authority) must be a
    ///   signer and a MARKET_KEEPER in the given store.
    /// - The [`token`](SetFeedConfigMarketStatusFlag::token) must exist in the token map.
    /// - The `provider` index must correspond to a valid [`PriceProviderKind`].
    /// - The `provider` must be [`PriceProviderKind::ChainlinkDataStreams`];
    ///   market status flags are not yet supported for other providers.
    /// - The feed config of the `provider` for the `token` must be initialized.
    /// - `flag` must be a valid [`MarketStatusFlag`] value.
    #[access_control(internal::Authenticate::only_market_keeper(&ctx))]
    pub fn set_feed_config_market_status_flag(
        ctx: Context<SetFeedConfigMarketStatusFlag>,
        provider: u8,
        flag: u8,
        enable: bool,
    ) -> Result<()> {
        let token = ctx.accounts.token.key();
        let authorized =
            ctx.accounts.store.load()?.token_map() == Some(&ctx.accounts.token_map.key());
        let kind = PriceProviderKind::try_from(provider)
            .map_err(|_| CoreError::InvalidProviderKindIndex)?;
        require_eq!(
            kind,
            PriceProviderKind::ChainlinkDataStreams,
            CoreError::ProviderDoesNotSupportMarketStatus
        );
        let market_status_flag =
            MarketStatusFlag::try_from(flag).map_err(|_| error!(CoreError::InvalidArgument))?;
        let previous = SetFeedConfigMarketStatusFlag::invoke_unchecked(
            ctx,
            &kind,
            market_status_flag,
            enable,
        )?;
        msg!(
            "set market status flag: token={}, provider={}, flag={}, {} -> {}, authorized_token_map={}",
            token,
            kind,
            flag,
            previous,
            enable,
            authorized,
        );
        Ok(())
    }

    /// Set the expected provider for the given token.
    ///
    /// # Accounts
    /// [*See the documentation for the accounts*](SetExpectedProvider).
    ///
    /// # Arguments
    /// - `token`: The token whose config will be updated.
    /// - `provider`: The provider index to be set as the expected provider
    ///   for the token. Must be a valid [`PriceProviderKind`] value.
    ///
    /// # Errors
    /// - The [`authority`](SetExpectedProvider::authority) must be a signer
    ///   and have the MARKET_KEEPER role in the given store.
    /// - The [`store`](SetExpectedProvider::store) must be an initialized [`Store`](states::Store)
    ///   account owned by the store program.
    /// - The [`token_map`](SetExpectedProvider::token_map) must be an initialized token map account
    ///   owned by the `store`.
    /// - The given `token` must exist in the token map.
    /// - The `provider` index must correspond to a valid [`PriceProviderKind`].
    #[access_control(internal::Authenticate::only_market_keeper(&ctx))]
    pub fn set_expected_provider(
        ctx: Context<SetExpectedProvider>,
        token: Pubkey,
        provider: u8,
    ) -> Result<()> {
        instructions::unchecked_set_expected_provider(
            ctx,
            token,
            PriceProviderKind::try_from(provider)
                .map_err(|_| CoreError::InvalidProviderKindIndex)?,
        )
    }

    /// Set the feed config of the given provider for the given token.
    ///
    /// # Accounts
    /// [*See the documentation for the accounts*](SetFeedConfig).
    ///
    /// # Arguments
    /// - `token`: The token whose config will be updated.
    /// - `provider`: The index of the provider whose feed config will be updated.
    ///   Must be a valid [`PriceProviderKind`] value.
    /// - `feed`: The new feed address.
    /// - `timestamp_adjustment`: The new timestamp adjustment in seconds.
    ///
    /// # Errors
    /// - The [`authority`](SetFeedConfig::authority) must be a signer
    ///   and a MARKET_KEEPER in the given store.
    /// - The [`store`](SetFeedConfig::store) must be an initialized [`Store`](states::Store)
    ///   account owned by the store program.
    /// - The [`token_map`](SetFeedConfig::token_map) must be an initialized token map account
    ///   owned by the `store`.
    /// - The given `token` must exist in the token map.
    /// - The `provider` index must correspond to a valid [`PriceProviderKind`].
    #[access_control(internal::Authenticate::only_market_keeper(&ctx))]
    pub fn set_feed_config_v2(
        ctx: Context<SetFeedConfig>,
        token: Pubkey,
        provider: u8,
        feed: Option<Pubkey>,
        timestamp_adjustment: Option<u32>,
        max_deviation_factor: Option<u128>,
    ) -> Result<()> {
        SetFeedConfig::invoke_unchecked(
            ctx,
            token,
            &PriceProviderKind::try_from(provider)
                .map_err(|_| CoreError::InvalidProviderKindIndex)?,
            feed,
            timestamp_adjustment,
            max_deviation_factor,
        )
    }

    /// Return whether the token config is enabled.
    ///
    /// # Accounts
    /// [*See the documentation for the accounts*](ReadTokenMap).
    ///
    /// # Arguments
    /// - `token`: The address of the token to query for.
    ///
    /// # Errors
    /// - The [`token_map`](ReadTokenMap::token_map) must be an initialized token map account
    ///   owned by the `store`.
    /// - The given `token` must exist in the token map.
    ///
    /// # Returns
    /// Returns `true` if the token config is enabled, `false` otherwise.
    pub fn is_token_config_enabled(ctx: Context<ReadTokenMap>, token: Pubkey) -> Result<bool> {
        instructions::is_token_config_enabled(ctx, &token)
    }

    /// Get the expected provider of the given token.
    ///
    /// # Accounts
    /// [*See the documentation for the accounts*](ReadTokenMap).
    ///
    /// # Arguments
    /// - `token`: The address of the token to query for.
    ///
    /// # Errors
    /// - The [`token_map`](ReadTokenMap::token_map) must be an initialized token map account
    ///   owned by the `store`.
    /// - The given `token` must exist in the token map.
    ///
    /// # Returns
    /// Returns the expected provider kind as a u8 index. See [`PriceProviderKind`] for valid indices.
    pub fn token_expected_provider(ctx: Context<ReadTokenMap>, token: Pubkey) -> Result<u8> {
        instructions::token_expected_provider(ctx, &token).map(|kind| kind as u8)
    }

    /// Get the configured feed of the given token for the provider.
    ///
    /// # Accounts
    /// [*See the documentation for the accounts*](ReadTokenMap).
    ///
    /// # Arguments
    /// - `token`: The address of the token to query for.
    /// - `provider`: The index of provider to query for. Must be a valid index defined in
    ///   [`PriceProviderKind`].
    ///
    /// # Errors
    /// - The [`token_map`](ReadTokenMap::token_map) must be an initialized token map account
    ///   owned by the `store`.
    /// - The given `token` must exist in the token map.
    /// - The `provider` must be a valid index defined in [`PriceProviderKind`], otherwise
    ///   returns [`CoreError::InvalidProviderKindIndex`].
    ///
    /// # Returns
    /// Returns the configured feed address for the given token and provider.
    pub fn token_feed(ctx: Context<ReadTokenMap>, token: Pubkey, provider: u8) -> Result<Pubkey> {
        instructions::token_feed(
            ctx,
            &token,
            &PriceProviderKind::try_from(provider)
                .map_err(|_| CoreError::InvalidProviderKindIndex)?,
        )
    }

    /// Get the configured timestamp adjustment of the given token for the provider.
    ///
    /// # Accounts
    /// [*See the documentation for the accounts*](ReadTokenMap).
    ///
    /// # Arguments
    /// - `token`: The address of the token to query for.
    /// - `provider`: The index of provider to query for. Must be a valid index defined in
    ///   [`PriceProviderKind`].
    ///
    /// # Errors
    /// - The [`token_map`](ReadTokenMap::token_map) must be an initialized token map account
    ///   owned by the `store`.
    /// - The given `token` must exist in the token map.
    /// - The `provider` must be a valid index defined in [`PriceProviderKind`], otherwise
    ///   returns [`CoreError::InvalidProviderKindIndex`].
    ///
    /// # Returns
    /// Returns the configured timestamp adjustment for the given token and provider.
    pub fn token_timestamp_adjustment(
        ctx: Context<ReadTokenMap>,
        token: Pubkey,
        provider: u8,
    ) -> Result<u32> {
        instructions::token_timestamp_adjustment(
            ctx,
            &token,
            &PriceProviderKind::try_from(provider)
                .map_err(|_| CoreError::InvalidProviderKindIndex)?,
        )
    }

    /// Get the name of the token.
    ///
    /// # Accounts
    /// [*See the documentation for the accounts*](ReadTokenMap).
    ///
    /// # Arguments
    /// - `token`: The address of the token to query for.
    ///
    /// # Errors
    /// - The [`token_map`](ReadTokenMap::token_map) must be an initialized token map account
    ///   owned by the store program.
    /// - The given `token` must exist in the token map.
    ///
    /// # Returns
    /// Returns the configured name string for the given token.
    pub fn token_name(ctx: Context<ReadTokenMap>, token: Pubkey) -> Result<String> {
        instructions::token_name(ctx, &token)
    }

    /// Get the decimals of the token.
    ///
    /// # Accounts
    /// [*See the documentation for the accounts*](ReadTokenMap).
    ///
    /// # Arguments
    /// - `token`: The address of the token to query for.
    ///
    /// # Errors
    /// - The [`token_map`](ReadTokenMap::token_map) must be an initialized token map account
    ///   owned by the store program.
    /// - The given `token` must exist in the token map.
    ///
    /// # Returns
    /// Returns the configured number of decimals for the given token.
    pub fn token_decimals(ctx: Context<ReadTokenMap>, token: Pubkey) -> Result<u8> {
        instructions::token_decimals(ctx, &token)
    }

    /// Get the price precision of the token.
    ///
    /// # Accounts
    /// [*See the documentation for the accounts*](ReadTokenMap).
    ///
    /// # Arguments
    /// - `token`: The address of the token to query for.
    ///
    /// # Errors
    /// - The [`token_map`](ReadTokenMap::token_map) must be an initialized token map account
    ///   owned by the store program.
    /// - The given `token` must exist in the token map.
    ///
    /// # Returns
    /// Returns the configured price precision for the given token.
    pub fn token_precision(ctx: Context<ReadTokenMap>, token: Pubkey) -> Result<u8> {
        instructions::token_precision(ctx, &token)
    }

    // ===========================================
    //              Oracle Management
    // ===========================================

    /// Initialize a new oracle account for the given store.
    ///
    /// This instruction creates a new oracle account that will be owned by the store. The oracle
    /// account is used to store price data for tokens configured in the store's token map.
    ///
    /// # Accounts
    /// *[See the documentation for the accounts.](InitializeOracle)*
    ///
    /// # Errors
    /// - The [`store`](InitializeOracle::store) must be an initialized [`Store`](states::Store)
    ///   account owned by the store program.
    /// - The [`oracle`](InitializeOracle::oracle) account must be uninitialized.
    pub fn initialize_oracle(ctx: Context<InitializeOracle>) -> Result<()> {
        instructions::initialize_oracle(ctx)
    }

    /// Clear all prices from the given oracle.
    ///
    /// This instruction removes all stored price data from the oracle account and resets it to the
    /// cleared state. This can be useful when needing to reset price data or when decommissioning an
    /// oracle.
    ///
    /// # Accounts
    /// *[See the documentation for the accounts.](ClearAllPrices)*
    ///
    /// # Errors
    /// - The [`authority`](ClearAllPrices::authority) must be a signer and have the ORACLE_CONTROLLER
    ///   role in the given store. It must also be the authority of the oracle.
    /// - The [`store`](ClearAllPrices::store) must be an initialized store account owned by the
    ///   store program.
    /// - The [`oracle`](ClearAllPrices::oracle) must be an initialized oracle account owned by
    ///   the given store.
    #[access_control(internal::Authenticate::only_oracle_controller(&ctx))]
    pub fn clear_all_prices(ctx: Context<ClearAllPrices>) -> Result<()> {
        instructions::unchecked_clear_all_prices(ctx)
    }

    /// Set prices from the provided price feeds.
    ///
    /// This instruction updates token prices in the oracle account using data from configured price feeds.
    /// For each token provided, it reads the current price from the corresponding price feed account and
    /// stores it in the oracle.
    ///
    /// # Accounts
    /// *[See the documentation for the accounts.](SetPricesFromPriceFeed)*
    ///
    /// # Arguments
    /// - `tokens`: The list of token mint addresses to update prices for. Each token must be configured
    ///   in the token map with a valid price feed.
    ///
    /// # Errors
    /// - The [`authority`](SetPricesFromPriceFeed::authority) must be a signer and have the
    ///   ORACLE_CONTROLLER role in the given store. It must also be the authority of the `oracle`.
    /// - The [`store`](SetPricesFromPriceFeed::store) must be an initialized store account owned by
    ///   the store program.
    /// - The [`oracle`](SetPricesFromPriceFeed::oracle) must be an initialized oracle account owned
    ///   by the given store. It must not have any prices set and be in the cleared state.
    /// - The [`token_map`](SetPricesFromPriceFeed::token_map) must be an initialized token map account
    ///   that is owned and authorized by the store.
    /// - The number of tokens provided cannot exceed [`MAX_TOKENS`](crate::states::oracle::price_map::PriceMap::MAX_TOKENS).
    /// - Each token in `tokens` must be configured and enabled in the token map.
    /// - For each token, there must be a valid corresponding price feed account included in the remaining accounts.
    #[access_control(internal::Authenticate::only_oracle_controller(&ctx))]
    pub fn set_prices_from_price_feed<'info>(
        ctx: Context<'_, '_, 'info, 'info, SetPricesFromPriceFeed<'info>>,
        tokens: Vec<Pubkey>,
    ) -> Result<()> {
        instructions::unchecked_set_prices_from_price_feed(ctx, tokens)
    }

    /// Initialize a custom price feed account.
    ///
    /// Creates a new price feed account that can be used to provide custom price data for a token.
    /// The price feed is owned by the store and can only be updated by ORDER_KEEPERs.
    ///
    /// # Accounts
    /// *[See the documentation for the accounts.](InitializePriceFeed)*
    ///
    /// # Arguments
    /// - `index`: The oracle index this price feed will be associated with.
    /// - `provider`: The price provider kind index that will be used for this feed. Must be a valid
    ///   index from [`PriceProviderKind`] that supports custom price feeds.
    /// - `token`: The mint address of the token this price feed will provide prices for.
    /// - `feed_id`: The feed ID defined by the price provider.
    ///
    /// # Errors
    /// - The [`authority`](InitializePriceFeed::authority) must be a signer and have the PRICE_KEEPER
    ///   role in the store.
    /// - The [`store`](InitializePriceFeed::store) must be an initialized store account owned by
    ///   the store program.
    /// - The [`price_feed`](InitializePriceFeed::price_feed) must be uninitialized and its address
    ///   must match the PDA derived from the `store`, `index`, `feed_id`, and other expected seeds.
    /// - The `provider` index must correspond to a valid [`PriceProviderKind`] that supports
    ///   custom price feeds.
    #[access_control(internal::Authenticate::only_price_keeper(&ctx))]
    pub fn initialize_price_feed(
        ctx: Context<InitializePriceFeed>,
        index: u16,
        provider: u8,
        token: Pubkey,
        feed_id: Pubkey,
    ) -> Result<()> {
        let provider = PriceProviderKind::try_from(provider)
            .map_err(|_| error!(CoreError::InvalidProviderKindIndex))?;
        instructions::unchecked_initialize_price_feed(ctx, index, provider, &token, &feed_id)
    }

    /// Updates the price data in a custom price feed account using a signed price report from
    /// Chainlink Data Streams. The price feed must be configured to use the Chainlink Data Streams
    /// provider.
    ///
    /// # Accounts
    /// *[See the documentation for the accounts.](UpdatePriceFeedWithChainlink)*
    ///
    /// # Arguments
    /// - `signed_report`: A signed price report from Chainlink Data Streams containing the price data.
    ///
    /// # Errors
    /// - The [`authority`](UpdatePriceFeedWithChainlink::authority) must be a signer and have the
    ///   PRICE_KEEPER role in the store.
    /// - The [`store`](UpdatePriceFeedWithChainlink::store) must be an initialized store account
    /// - The [`verifier_account`](UpdatePriceFeedWithChainlink::verifier_account) must be a valid
    ///   Chainlink verifier account.
    /// - The [`price_feed`](UpdatePriceFeedWithChainlink::price_feed) must be initialized, owned by
    ///   the store, and authorized for the `authority`.
    /// - The [`chainlink`](UpdatePriceFeedWithChainlink::chainlink) program ID must be trusted in the
    ///   definition of the [`ChainlinkDataStreamsInterface`](gmsol_chainlink_datastreams::interface::ChainlinkDataStreamsInterface).
    /// - The price feed must be configured to use [`ChainlinkDataStreams`](PriceProviderKind::ChainlinkDataStreams)
    ///   as its provider.
    /// - The `signed_report` must be:
    ///   - Decodable as a valid Chainlink price report
    ///   - Verifiable by the Chainlink Verifier Program
    ///   - Contain valid data for creating a [`PriceFeedPrice`](states::oracle::PriceFeedPrice)
    /// - The current slot and timestamp must be >= the feed's last update.
    /// - The price data timestamp must be >= the feed's last price timestamp
    /// - The price data must meet all validity requirements (see the `update` method of [`PriceFeed`](states::oracle::PriceFeed)).
    #[access_control(internal::Authenticate::only_price_keeper(&ctx))]
    pub fn update_price_feed_with_chainlink(
        ctx: Context<UpdatePriceFeedWithChainlink>,
        compressed_report: Vec<u8>,
    ) -> Result<()> {
        instructions::unchecked_update_price_feed_with_chainlink(ctx, compressed_report, false)?;
        Ok(())
    }

    /// Updates the price data in a custom price feed account using a signed price report from
    /// Chainlink Data Streams. The price feed must be configured to use the Chainlink Data Streams
    /// provider.
    ///
    /// - Returns `Ok(true)` if the price feed is updated.
    /// - Returns `Ok(false)` if the price report is valid but older than the last update, provided no other errors occur.
    ///
    /// # Accounts
    /// *[See the documentation for the accounts.](UpdatePriceFeedWithChainlink)*
    ///
    /// # Arguments
    /// - `signed_report`: A signed price report from Chainlink Data Streams containing the price data.
    ///
    /// # Errors
    /// - The [`authority`](UpdatePriceFeedWithChainlink::authority) must be a signer and have the
    ///   PRICE_KEEPER role in the store.
    /// - The [`store`](UpdatePriceFeedWithChainlink::store) must be an initialized store account
    /// - The [`verifier_account`](UpdatePriceFeedWithChainlink::verifier_account) must be a valid
    ///   Chainlink verifier account.
    /// - The [`price_feed`](UpdatePriceFeedWithChainlink::price_feed) must be initialized, owned by
    ///   the store, and authorized for the `authority`.
    /// - The [`chainlink`](UpdatePriceFeedWithChainlink::chainlink) program ID must be trusted in the
    ///   definition of the [`ChainlinkDataStreamsInterface`](gmsol_chainlink_datastreams::interface::ChainlinkDataStreamsInterface).
    /// - The price feed must be configured to use [`ChainlinkDataStreams`](PriceProviderKind::ChainlinkDataStreams)
    ///   as its provider.
    /// - The `signed_report` must be:
    ///   - Decodable as a valid Chainlink price report
    ///   - Verifiable by the Chainlink Verifier Program
    ///   - Contain valid data for creating a [`PriceFeedPrice`](states::oracle::PriceFeedPrice)
    /// - The current slot and timestamp must be >= the feed's last update.
    /// - The price data must meet all validity requirements (see the `update` method of [`PriceFeed`](states::oracle::PriceFeed)).
    #[access_control(internal::Authenticate::only_price_keeper(&ctx))]
    pub fn update_price_feed_with_chainlink_idempotent(
        ctx: Context<UpdatePriceFeedWithChainlink>,
        compressed_report: Vec<u8>,
    ) -> Result<bool> {
        instructions::unchecked_update_price_feed_with_chainlink(ctx, compressed_report, true)
    }

    // ===========================================
    //              Market Management
    // ===========================================

    /// Initialize a [`Market`](states::Market) account.
    ///
    /// # Accounts
    /// [*See the documentation for the accounts.*](InitializeMarket)
    ///
    /// # Arguments
    /// - `index_token_mint`: The address of the index token.
    /// - `name`: The name of the market.
    /// - `enable`: Whether to enable the market after initialization.
    ///
    /// # Errors
    /// - The [`authority`](InitializeMarket::authority) must be a signer and have the MARKET_KEEPER role
    ///   in the store.
    /// - The [`store`](InitializeMarket::store) must be initialized.
    /// - The [`market_token_mint`](InitializeMarket::market_token_mint) must be uninitialized
    ///   and a PDA derived from the expected seeds.
    /// - The [`market`](InitializeMarket::market) must be uninitialized and a PDA derived from
    ///   the expected seeds (see the documentation for [`market`](InitializeMarket::market) for details).
    /// - The [`token_map`](InitializeMarket::token_map) must be initialized and must be owned and
    ///   authorized by the `store`.
    /// - The [`long_token_vault`](InitializeMarket::long_token_vault) and
    ///   [`short_token_vault`](InitializeMarket::short_token_vault) must be initialized
    ///   and valid market vault accounts of the store for their respective tokens.
    /// - The long and short token mints must be valid Mint accounts.
    #[access_control(internal::Authenticate::only_market_keeper(&ctx))]
    pub fn initialize_market(
        ctx: Context<InitializeMarket>,
        index_token_mint: Pubkey,
        name: String,
        enable: bool,
    ) -> Result<()> {
        instructions::unchecked_initialize_market(ctx, index_token_mint, &name, enable)
    }

    /// Enable or disable the given market.
    ///
    /// This instruction allows a MARKET_KEEPER to toggle whether a market is enabled or disabled.
    ///
    /// # Accounts
    /// [*See the documentation for the accounts.*](ToggleMarket)
    ///
    /// # Arguments
    /// - `enable`: Whether to enable (`true`) or disable (`false`) the market.
    ///
    /// # Errors
    /// - The [`authority`](ToggleMarket::authority) must be a signer and have the MARKET_KEEPER
    ///   role in the store.
    /// - The [`store`](ToggleMarket::store) must be initialized and owned by this program.
    /// - The [`market`](ToggleMarket::market) must be initialized and owned by the store.
    #[access_control(internal::Authenticate::only_market_keeper(&ctx))]
    pub fn toggle_market(ctx: Context<ToggleMarket>, enable: bool) -> Result<()> {
        instructions::unchecked_toggle_market(ctx, enable)
    }

    /// Transfer tokens into the market and record the amounts in its balance.
    ///
    /// This instruction allows a MARKET_KEEPER to transfer tokens from a source account into one of
    /// the market vault accounts, updating the market's internal balance tracking.
    ///
    /// # Accounts
    /// [*See the documentation for the accounts.*](MarketTransferIn)
    ///
    /// # Arguments
    /// - `amount`: The amount of tokens to transfer into the market vault.
    ///
    /// # Errors
    /// - The [`authority`](MarketTransferIn::authority) must be a signer and have the MARKET_KEEPER
    ///   role in the store.
    /// - The [`store`](MarketTransferIn::store) must be an initialized store account owned by this program.
    /// - The [`from_authority`](MarketTransferIn::from_authority) must be a signer and have the
    ///   permission to transfer.
    /// - The [`market`](MarketTransferIn::market) must be an initialized market account owned by the store.
    /// - The [`from`](MarketTransferIn::from) must be an initialized token account and cannot be the
    ///   same as the destination vault.
    /// - The [`vault`](MarketTransferIn::vault) must be an initialized and valid market vault token
    ///   account owned by the store. It must have the same mint as the `from` token account.
    /// - The market must be enabled and the token being transferred must be one of the market's
    ///   configured pool tokens (long token or short token).
    /// - The source token account must have sufficient balance for the transfer amount.
    #[access_control(internal::Authenticate::only_market_keeper(&ctx))]
    pub fn market_transfer_in(ctx: Context<MarketTransferIn>, amount: u64) -> Result<()> {
        instructions::unchecked_market_transfer_in(ctx, amount)
    }

    /// Update an item in the market config.
    ///
    /// This instruction allows the `authority` to update a single configuration value in the market's
    /// configuration. The key must be one of the predefined market config keys.
    ///
    /// # Accounts
    /// [*See the documentation for the accounts.*](UpdateMarketConfig)
    ///
    /// # Arguments
    /// - `key`: The configuration key to update. Must be a valid key defined in
    ///   [`MarketConfigKey`](states::market::config::MarketConfigKey).
    /// - `value`: The new value to set for this configuration key.
    ///
    /// # Errors
    /// - The [`authority`](UpdateMarketConfig::authority) must be a signer and have permission to update
    ///   market config.
    /// - The [`store`](UpdateMarketConfig::store) must be an initialized store account owned by this program.
    /// - The [`market`](UpdateMarketConfig::market) must be an initialized market account owned by the store.
    /// - The provided `key` must be defined in [`MarketConfigKey`](states::market::config::MarketConfigKey).
    #[access_control(internal::Authenticate::ensure_can_update_market_config(&ctx))]
    pub fn update_market_config(
        ctx: Context<UpdateMarketConfig>,
        key: String,
        value: u128,
    ) -> Result<()> {
        instructions::unchecked_update_market_config(ctx, &key, value)
    }

    /// Update a flag in the market config.
    ///
    /// This instruction allows the `authority` to update a single flag in the market's
    /// configuration. The key must be one of the predefined market config flags.
    ///
    /// # Accounts
    /// [*See the documentation for the accounts.*](UpdateMarketConfig)
    ///
    /// # Arguments
    /// - `key`: The flag to update. Must be a valid key defined in
    ///   [`MarketConfigFlag`](states::market::config::MarketConfigFlag).
    /// - `value`: The new boolean value to set for this flag.
    ///
    /// # Errors
    /// - The [`authority`](UpdateMarketConfig::authority) must be a signer and have permission to update
    ///   market config.
    /// - The [`store`](UpdateMarketConfig::store) must be an initialized store account owned by this program.
    /// - The [`market`](UpdateMarketConfig::market) must be an initialized market account owned by the store.
    /// - The provided `key` must be defined in [`MarketConfigFlag`](states::market::config::MarketConfigFlag).
    #[access_control(internal::Authenticate::ensure_can_update_market_config(&ctx))]
    pub fn update_market_config_flag(
        ctx: Context<UpdateMarketConfig>,
        key: String,
        value: bool,
    ) -> Result<()> {
        instructions::unchecked_update_market_config_flag(ctx, &key, value)
    }

    /// Update the market configuration using a pre-populated
    /// [`MarketConfigBuffer`](crate::states::market::config::MarketConfigBuffer) account.
    ///
    /// This instruction allows the `authority` to update multiple market configuration values at once
    /// by applying the changes stored in a buffer account. The buffer must contain valid configuration
    /// keys and values.
    ///
    /// # Accounts
    /// [*See the documentation for the accounts.*](UpdateMarketConfigWithBuffer)
    ///
    /// # Errors
    /// - The [`authority`](UpdateMarketConfigWithBuffer::authority) must be a signer and have permission to update
    ///   market config.
    /// - The [`store`](UpdateMarketConfigWithBuffer::store) must be an initialized store account
    ///   owned by this program.
    /// - The [`market`](UpdateMarketConfigWithBuffer::market) must be an initialized market account
    ///   owned by the store.
    /// - The [`buffer`](UpdateMarketConfigWithBuffer::buffer) must be:
    ///   - An initialized market config buffer account
    ///   - Owned by both the store and the authority
    ///   - Not expired
    /// - All configuration keys in the buffer must be valid keys defined in
    ///   [`MarketConfigKey`](states::market::config::MarketConfigKey).
    #[access_control(internal::Authenticate::ensure_can_update_market_config(&ctx))]
    pub fn update_market_config_with_buffer(
        ctx: Context<UpdateMarketConfigWithBuffer>,
    ) -> Result<()> {
        instructions::unchecked_update_market_config_with_buffer(ctx)
    }

    /// Calculate the current market status.
    ///
    /// This instruction calculates and returns the current status of a market, including metrics like
    /// pool value, PnL, and other key indicators. The calculation can be configured to maximize or
    /// minimize certain values based on the provided flags.
    ///
    /// # Accounts
    /// [*See the documentation for the accounts.*](ReadMarket)
    ///
    /// # Arguments
    /// - `prices`: The current unit prices of tokens in the market, used for calculations.
    /// - `maximize_pnl`: If true, uses the maximum possible PnL values in calculations.
    ///   If false, uses minimum PnL values.
    /// - `maximize_pool_value`: If true, uses the maximum possible pool value in calculations.
    ///   If false, uses minimum pool value.
    ///
    /// # Errors
    /// - The [`market`](ReadMarket::market) account must be properly initialized.
    /// - The provided prices must be non-zero.
    /// - Any calculation errors.
    pub fn get_market_status(
        ctx: Context<ReadMarket>,
        prices: Prices<u128>,
        maximize_pnl: bool,
        maximize_pool_value: bool,
    ) -> Result<MarketStatus> {
        instructions::get_market_status(ctx, &prices, maximize_pnl, maximize_pool_value)
    }

    /// Get the current market token price based on the provided token prices and PnL factor.
    ///
    /// This instruction calculates and returns the current price of the market token, taking into
    /// account the provided token prices and PnL factor. The calculation can be configured to
    /// maximize certain values based on the provided flag.
    ///
    /// # Accounts
    /// [*See the documentation for the accounts.*](ReadMarketWithToken)
    ///
    /// # Arguments
    /// - `prices`: The current unit prices of tokens in the market, used for calculations.
    /// - `pnl_factor`: The PnL factor key to use for price calculations, must be a valid
    ///   [`PnlFactorKind`](gmsol_model::PnlFactorKind).
    /// - `maximize`: If true, uses the maximum possible values in calculations.
    ///   If false, uses minimum values.
    ///
    /// # Errors
    /// - The [`market`](ReadMarketWithToken::market) must be an initialized market account.
    /// - The provided prices must be non-zero.
    /// - The `pnl_factor` must be a valid [`PnlFactorKind`](gmsol_model::PnlFactorKind).
    /// - Any calculation errors.
    pub fn get_market_token_price(
        ctx: Context<ReadMarketWithToken>,
        prices: Prices<u128>,
        pnl_factor: String,
        maximize: bool,
    ) -> Result<u128> {
        instructions::get_market_token_price(
            ctx,
            &prices,
            pnl_factor
                .parse()
                .map_err(|_| error!(CoreError::InvalidArgument))?,
            maximize,
        )
    }

    /// Returns the USD value for the given market token amount.
    ///
    /// # Accounts
    /// [*See the documentation for the accounts.*](GetMarketTokenValue)
    ///
    /// # Arguments
    /// - `amount`: Amount of the market tokens to evaluate.
    /// - `pnl_factor`: The PnL factor key to use for price calculations, must be a valid
    ///   [`PnlFactorKind`](gmsol_model::PnlFactorKind).
    /// - `maximize`: If true, uses the maximum possible values in calculations.
    ///   If false, uses minimum values.
    /// - `max_age`: Maximum allowed age of the earliest oracle timestamp.
    /// - `emit_event`: Whether to emit a [`GlvTokenValue`](crate::events::GlvTokenValue) event.
    ///
    /// # Errors
    /// - The [`authority`](GetMarketTokenValue::authority) must be a signer and be the authority of the `oracle` buffer account.
    /// - The [`store`](GetMarketTokenValue::store) must be initialized.
    /// - The [`token_map`](GetMarketTokenValue::token_map) must be initialized and authorized by the `store`.
    /// - The [`oracle`](GetMarketTokenValue::oracle) must be initialized and cleared.
    /// - The [`market`](GetMarketTokenValue::market) must be initialized and enabled.
    /// - The [`market_token`](GetMarketTokenValue::market_token) must be associated with the `market`.
    /// - The remaining accounts must include a specified number of valid feed accounts,
    ///   in the required order.
    /// - The `pnl_factor` must be a valid [`PnlFactorKind`](gmsol_model::PnlFactorKind).
    /// - The earliest oracle timestamp must be within `max_age`.
    /// - Any calculation errors.
    pub fn get_market_token_value<'info>(
        ctx: Context<'_, '_, 'info, 'info, GetMarketTokenValue<'info>>,
        amount: u64,
        pnl_factor: String,
        maximize: bool,
        max_age: u32,
        emit_event: bool,
    ) -> Result<u128> {
        GetMarketTokenValue::invoke(
            ctx,
            amount,
            pnl_factor
                .parse()
                .map_err(|_| error!(CoreError::InvalidArgument))?,
            maximize,
            max_age,
            emit_event,
        )
    }

    /// Initialize a market config buffer account.
    ///
    /// This instruction creates a new market config buffer account that can be used to stage market
    /// configuration changes before applying them. The buffer has an expiration time after which
    /// it cannot be used.
    ///
    /// # Accounts
    /// [*See the documentation for the accounts.*](InitializeMarketConfigBuffer)
    ///
    /// # Arguments
    /// - `expire_after_secs`: The number of seconds after which this buffer account will expire.
    ///   Once expired, the buffer can no longer be used and must be closed.
    ///
    /// # Errors
    /// - The [`authority`](InitializeMarketConfigBuffer::authority) must be a signer and will be
    ///   set as the owner of the buffer account.
    /// - The [`store`](InitializeMarketConfigBuffer::store) must be an initialized store account
    ///   owned by the program.
    /// - The [`buffer`](InitializeMarketConfigBuffer::buffer) must be an uninitialized account
    ///   that will store the market configuration data.
    /// - The expiration time must be greater than zero.
    pub fn initialize_market_config_buffer(
        ctx: Context<InitializeMarketConfigBuffer>,
        expire_after_secs: u32,
    ) -> Result<()> {
        instructions::initialize_market_config_buffer(ctx, expire_after_secs)
    }

    /// Transfer ownership of a market config buffer account to a new authority.
    ///
    /// This instruction allows the current authority to transfer ownership of the buffer
    /// account to a new authority. After the transfer, only the new authority will be able
    /// to modify or close the buffer.
    ///
    /// # Accounts
    /// [*See the documentation for the accounts.*](SetMarketConfigBufferAuthority)
    ///
    /// # Arguments
    /// - `new_authority`: The public key of the new authority that will own the buffer account.
    ///
    /// # Errors
    /// - The [`authority`](SetMarketConfigBufferAuthority::authority) must be a signer
    ///   and the current owner of the `buffer` account.
    /// - The [`buffer`](SetMarketConfigBufferAuthority::buffer) must be an initialized
    ///   market config buffer account.
    /// - The `new_authority` cannot be the same as the current authority.
    pub fn set_market_config_buffer_authority(
        ctx: Context<SetMarketConfigBufferAuthority>,
        new_authority: Pubkey,
    ) -> Result<()> {
        instructions::set_market_config_buffer_authority(ctx, new_authority)
    }

    /// Close the given market config buffer account and reclaim its rent.
    ///
    /// This instruction allows the authority to close their market config buffer account
    /// and reclaim the rent.
    ///
    /// # Accounts
    /// [*See the documentation for the accounts.*](CloseMarketConfigBuffer)
    ///
    /// # Errors
    /// - The [`authority`](CloseMarketConfigBuffer::authority) must be a signer
    ///   and the owner of the `buffer` account.
    /// - The [`buffer`](CloseMarketConfigBuffer::buffer) must be an initialized
    ///   market config buffer account.
    pub fn close_market_config_buffer(ctx: Context<CloseMarketConfigBuffer>) -> Result<()> {
        instructions::close_market_config_buffer(ctx)
    }

    /// Push config items to the given market config buffer account.
    ///
    /// This instruction allows the authority to add new configuration items to their market
    /// config buffer account. The buffer will be reallocated to accommodate the new items,
    /// with the authority paying for any additional rent.
    ///
    /// # Accounts
    /// [*See the documentation for the accounts.*](PushToMarketConfigBuffer)
    ///
    /// # Arguments
    /// - `new_configs`: The list of new config items to append to the buffer. Each item
    ///   consists of a string key and a factor value.
    ///
    /// # Errors
    /// - The [`authority`](PushToMarketConfigBuffer::authority) must be a signer
    ///   and the owner of the `buffer` account.
    /// - The [`buffer`](PushToMarketConfigBuffer::buffer) must be an initialized
    ///   market config buffer account.
    /// - The authority must have enough SOL to pay for any additional rent needed.
    /// - The keys in `new_configs` must be valid [`MarketConfigKey`](states::market::config::MarketConfigKey).
    pub fn push_to_market_config_buffer(
        ctx: Context<PushToMarketConfigBuffer>,
        new_configs: Vec<EntryArgs>,
    ) -> Result<()> {
        instructions::push_to_market_config_buffer(ctx, new_configs)
    }

    /// Updates the allow list of market configs that can be modified by a
    /// `MARKET_CONFIG_KEEPER`.
    ///
    /// # Accounts
    /// See the documentation for the accounts in [`SetMarketConfigUpdatable`].
    ///
    /// # Arguments
    /// - `is_flag`: Indicates whether the `key` refers to a market config flag.
    /// - `key`: The market config key for which update permission is being set.
    /// - `updatable`: Indicates whether the market config is updatable.
    ///
    /// # Errors
    /// - The [`authority`](SetMarketConfigUpdatable::authority) must be a signer
    ///   and a `MARKET_KEEPER` in the given `store`.
    /// - The [`store`](SetMarketConfigUpdatable::store) must be initialized.
    /// - The provided `key` must be valid.
    /// - The permission flag must change from its previous value.
    #[access_control(internal::Authenticate::only_market_keeper(&ctx))]
    pub fn set_market_config_updatable(
        ctx: Context<SetMarketConfigUpdatable>,
        is_flag: bool,
        key: String,
        updatable: bool,
    ) -> Result<()> {
        SetMarketConfigUpdatable::invoke_unchecked(ctx, is_flag, &key, updatable)
    }

    /// Enable or disable GT minting for the given market.
    ///
    /// This instruction allows a MARKET_KEEPER to control whether GT minting is enabled for the
    /// given market. When disabled, users cannot mint new GT tokens through this market.
    ///
    /// # Accounts
    /// [*See the documentation for the accounts.*](ToggleGTMinting)
    ///
    /// # Arguments
    /// - `enable`: Whether to enable (`true`) or disable (`false`) GT minting for the given market.
    ///
    /// # Errors
    /// - The [`authority`](ToggleGTMinting::authority) must be a signer and be a MARKET_KEEPER
    ///   in the store.
    /// - The [`store`](ToggleGTMinting::store) must be an initialized store account.
    /// - The [`market`](ToggleGTMinting::market) must be an initialized market account and owned
    ///   by the store.
    #[access_control(internal::Authenticate::only_market_keeper(&ctx))]
    pub fn toggle_gt_minting(ctx: Context<ToggleGTMinting>, enable: bool) -> Result<()> {
        instructions::unchecked_toggle_gt_minting(ctx, enable)
    }

    /// Claim fees from the given market.
    ///
    /// # Accounts
    /// [*See the documentation for the accounts.*](ClaimFeesFromMarket)
    ///
    /// # Return
    /// - Returns the claimed amount in base units of the token.
    ///
    /// # Errors
    /// - The [`authority`](ClaimFeesFromMarket::authority) must be a signer and be the designated
    ///   fee receiver in the given store.
    /// - The [`store`](ClaimFeesFromMarket::store) must be an initialized [`Store`](crate::states::Store)
    ///   account owned by this program.
    /// - The [`market`](ClaimFeesFromMarket::market) must be an initialized [`Market`](crate::states::Market)
    ///   account owned by this program and associated with the given store.
    /// - The token being claimed must be one of the market's configured collateral tokens.
    /// - All provided token accounts must match their expected addresses.
    /// - The market must maintain valid balance requirements after the claim.
    pub fn claim_fees_from_market(ctx: Context<ClaimFeesFromMarket>) -> Result<u64> {
        let claimed = instructions::claim_fees_from_market(ctx)?;
        Ok(claimed)
    }

    /// Initialize a new market vault for a specific token.
    ///
    /// This instruction creates a new vault account that will be used to store tokens for a market.
    /// The vault is a PDA (Program Derived Address) account that can only be controlled by this program.
    ///
    /// # Accounts
    /// [*See the documentation for the accounts.*](InitializeMarketVault)
    ///
    /// # Errors
    /// - The [`authority`](InitializeMarketVault::authority) must be a signer and have MARKET_KEEPER
    ///   permissions in the store.
    /// - The [`store`](InitializeMarketVault::store) must be an initialized store account.
    /// - The [`vault`](InitializeMarketVault::vault) must be an uninitialized account and its address
    ///   must match the PDA derived from the expected seeds.
    #[access_control(internal::Authenticate::only_market_keeper(&ctx))]
    pub fn initialize_market_vault(ctx: Context<InitializeMarketVault>) -> Result<()> {
        instructions::unchecked_initialize_market_vault(ctx)
    }

    /// Prepare a claimable account to receive tokens during order execution.
    ///
    /// This instruction serves two purposes:
    /// 1. For uninitialized accounts: Creates and prepares the account to receive tokens
    /// 2. For initialized accounts: Unlocks the funds for the owner to claim
    ///
    /// # Accounts
    /// [*See the documentation for the accounts.*](UseClaimableAccount)
    ///
    /// # Arguments
    /// - `timestamp`: The timestamp for which the claimable account was created.
    /// - `amount`: The token amount to approve for delegation.
    ///
    /// # Errors
    /// - The [`authority`](UseClaimableAccount::authority) must be a signer and have ORDER_KEEPER
    ///   permissions in the store.
    /// - The [`store`](UseClaimableAccount::store) must be an initialized store account.
    /// - The [`account`](UseClaimableAccount::account) must be a PDA derived from
    ///   the time window of the `timestamp` and other expected seeds. It can be uninitialized.
    /// - If the `account` is initialized, it must be owned by the store.
    #[access_control(internal::Authenticate::only_order_keeper(&ctx))]
    pub fn use_claimable_account(
        ctx: Context<UseClaimableAccount>,
        timestamp: i64,
        amount: u64,
    ) -> Result<()> {
        instructions::unchecked_use_claimable_account(ctx, timestamp, amount)
    }

    /// Close an empty claimable account.
    ///
    /// # Accounts
    /// [*See the documentation for the accounts.*](CloseEmptyClaimableAccount)
    ///
    /// # Arguments
    /// - `timestamp`: The timestamp for which the claimable account was created.
    ///
    /// # Errors
    /// - The [`authority`](CloseEmptyClaimableAccount::authority) must be a signer and have ORDER_KEEPER
    ///   permissions in the store.
    /// - The [`store`](CloseEmptyClaimableAccount::store) must be initialized.
    /// - The [`account`](CloseEmptyClaimableAccount::account) must be a PDA derived from
    ///   the claimable timestamp and other expected seeds.
    /// - The [`account`](CloseEmptyClaimableAccount::account) must be initialized and owned by the store.
    /// - The balance of the [`account`](CloseEmptyClaimableAccount::account) must be zero.
    #[access_control(internal::Authenticate::only_order_keeper(&ctx))]
    pub fn close_empty_claimable_account(
        ctx: Context<CloseEmptyClaimableAccount>,
        timestamp: i64,
    ) -> Result<()> {
        instructions::unchecked_close_empty_claimable_account(ctx, timestamp)
    }

    /// Prepare an associated token account.
    ///
    /// # Accounts
    /// *[See the documentation for the accounts.](PrepareAssociatedTokenAccount)*
    ///
    /// # Errors
    /// - The [`payer`](PrepareAssociatedTokenAccount::payer) must be a signer.
    /// - The [`mint`](PrepareAssociatedTokenAccount::mint) must be a [`Mint`](anchor_spl::token_interface::Mint)
    ///   account that is owned by the given token program.
    /// - The [`account`](PrepareAssociatedTokenAccount::account) must be an associated token account
    ///   with:
    ///   - mint = [`mint`](PrepareAssociatedTokenAccount::mint)
    ///   - owner = [`owner`](PrepareAssociatedTokenAccount::owner)
    ///   - It can be uninitialized.
    pub fn prepare_associated_token_account(
        ctx: Context<PrepareAssociatedTokenAccount>,
    ) -> Result<()> {
        instructions::prepare_associated_token_account(ctx)
    }

    /// Create token metadata for a token whose mint authority is `store`.
    ///
    /// # Accounts
    /// *[See the documentation for the accounts.](CreateTokenMetadata)*
    #[access_control(internal::Authenticate::only_market_keeper(&ctx))]
    pub fn create_token_metadata(
        ctx: Context<CreateTokenMetadata>,
        name: String,
        symbol: String,
        uri: String,
    ) -> Result<()> {
        CreateTokenMetadata::invoke_unchecked(ctx, name, symbol, uri)
    }

    /// Update a token metadata whose update authority is `store`.
    ///
    /// # Accounts
    /// *[See the documentation for the accounts.](UpdateTokenMetadata)*
    #[access_control(internal::Authenticate::only_market_keeper(&ctx))]
    pub fn update_token_metadata(
        ctx: Context<UpdateTokenMetadata>,
        name: String,
        symbol: String,
        uri: String,
    ) -> Result<()> {
        UpdateTokenMetadata::invoke_unchecked(ctx, name, symbol, uri)
    }

    // ===========================================
    //                  Deposit
    // ===========================================

    /// Create a deposit by the owner.
    ///
    /// # Accounts
    /// *[See the documentation for the accounts.](CreateDeposit)*
    ///
    /// # Arguments
    /// - `nonce`: Nonce bytes used to derive the deposit account address.
    /// - `params`: Parameters specifying the deposit details.
    ///
    /// # Errors
    /// This instruction will fail if:
    /// - The [`owner`](CreateDeposit::owner) is not a signer or has insufficient balance
    ///   for the execution fee and rent.
    /// - The [`store`](CreateDeposit::store) is not properly initialized.
    /// - The [`market`](CreateDeposit::market) is not initialized, not owned by the store,
    ///   or is disabled.
    /// - The [`deposit`](CreateDeposit::deposit) account is already initialized or is not
    ///   a valid PDA derived from the provided nonce and other expected seeds.
    /// - The [`market_token`](CreateDeposit::market_token) is not the market token of `market`.
    /// - Any required escrow account is not properly initialized or owned by the `deposit`.
    /// - Any source account has insufficient balance, does not match the initial tokens, or the
    ///   `owner` does not have the permission to transfer the tokens.
    /// - The remaining accounts do not form valid swap paths or reference disabled markets.
    pub fn create_deposit<'info>(
        mut ctx: Context<'_, '_, 'info, 'info, CreateDeposit<'info>>,
        nonce: [u8; 32],
        params: CreateDepositParams,
    ) -> Result<()> {
        internal::Create::create(&mut ctx, &nonce, &params, None)
    }

    /// Close a deposit, either by the owner or by keepers.
    ///
    /// # Accounts
    /// *[See the documentation for the accounts.](CloseDeposit)*
    ///
    /// # Arguments
    /// - `reason`: The reason for closing the deposit.
    ///
    /// # Errors
    /// This instruction will fail if:
    /// - The [`executor`](CloseDeposit::executor) is not a signer or is neither the deposit
    ///   owner nor an ORDER_KEEPER in the store.
    /// - The [`store`](CloseDeposit::store) is not properly initialized.
    /// - The [`owner`](CloseDeposit::owner) does not match the deposit's owner.
    /// - The provided token mint accounts do not match those recorded in the `deposit`.
    /// - The [`deposit`](CloseDeposit::deposit) is not initialized, not owned by the store,
    ///   or not owned by the specified owner.
    /// - Any escrow account is not owned by the `deposit` or does not match the `deposit` records.
    /// - Any associated token account address is invalid.
    /// - The deposit is not in a cancelled or completed state when closed by a non-owner.
    pub fn close_deposit<'info>(
        ctx: Context<'_, '_, 'info, 'info, CloseDeposit<'info>>,
        reason: String,
    ) -> Result<()> {
        internal::Close::close(&ctx, &reason)
    }

    /// Execute a deposit by keepers.
    ///
    /// # Accounts
    /// *[See the documentation for the accounts.](ExecuteDeposit)*
    ///
    /// # Arguments
    /// - `execution_fee`: The execution fee claimed to be used by the keeper.
    /// - `throw_on_execution_error`: If true, throws an error if execution fails. If false,
    ///   the deposit will be cancelled instead.
    ///
    /// # Errors
    /// This instruction will fail if:
    /// - The [`authority`](ExecuteDeposit::authority) is not a signer or is not an ORDER_KEEPER
    ///   in the store.
    /// - The [`store`](ExecuteDeposit::store) is not properly initialized.
    /// - The [`token_map`](ExecuteDeposit::token_map) is not initialized or not authorized by
    ///   the store.
    /// - The [`oracle`](ExecuteDeposit::oracle) is not initialized, cleared and owned by the
    ///   store.
    /// - The [`market`](ExecuteDeposit::market) is not initialized, is disabled, not owned by
    ///   the store, or does not match the market recorded in the `deposit`.
    /// - The [`deposit`](ExecuteDeposit::deposit) is not initialized, not owned by the store,
    ///   or not in the pending state.
    /// - Any token mint accounts do not match those recorded in the `deposit`.
    /// - Any escrow accounts are not properly owned or not recorded in the `deposit`.
    /// - Any vault accounts are not valid market vaults or do not correspond to the initial tokens.
    /// - Any feed accounts in the remaining accounts are invalid or do not match the swap parameters.
    /// - Any market accounts in the remaining accounts are disabled, not owned by the store,
    ///   or do not match the swap parameters.
    /// - Any oracle prices from the feed accounts are incomplete or invalid.
    /// - The execution fails and `throw_on_execution_error` is set to `true`.
    #[access_control(internal::Authenticate::only_order_keeper(&ctx))]
    pub fn execute_deposit<'info>(
        ctx: Context<'_, '_, 'info, 'info, ExecuteDeposit<'info>>,
        execution_fee: u64,
        throw_on_execution_error: bool,
    ) -> Result<()> {
        instructions::unchecked_execute_deposit(ctx, execution_fee, throw_on_execution_error)
    }

    // ===========================================
    //                 Withdrawal
    // ===========================================

    /// Create a withdrawal by the owner.
    ///
    /// # Accounts
    /// *[See the documentation for the accounts.](CreateWithdrawal)*
    ///
    /// # Arguments
    /// - `nonce`: Nonce bytes used to derive the address for the withdrawal.
    /// - `params`: Withdrawal Parameters containing the withdrawal configuration.
    ///
    /// # Errors
    /// This instruction will fail if:
    /// - The [`owner`](CreateWithdrawal::owner) is not a signer or has insufficient balance
    ///   for the execution fee and rent.
    /// - The [`store`](CreateWithdrawal::store) is not properly initialized.
    /// - The [`market`](CreateWithdrawal::market) is not initialized, is disabled, or not owned
    ///   by the store.
    /// - The [`withdrawal`](CreateWithdrawal::withdrawal) is already initialized or is not a valid
    ///   PDA derived from the provided `nonce` and expected seeds.
    /// - The [`market_token`](CreateWithdrawal::market_token) does not match the market token
    ///   of the specified market.
    /// - Any required escrow accounts are not properly initialized or not owned by the `withdrawal`.
    /// - The source market token account has insufficient balance, or the `owner` does not have the
    ///   permission to transfer the tokens.
    /// - Any market accounts in the remaining accounts are disabled, not owned by the store,
    ///   or do not form valid swap paths.
    pub fn create_withdrawal<'info>(
        mut ctx: Context<'_, '_, 'info, 'info, CreateWithdrawal<'info>>,
        nonce: [u8; 32],
        params: CreateWithdrawalParams,
    ) -> Result<()> {
        internal::Create::create(&mut ctx, &nonce, &params, None)
    }

    /// Close a withdrawal, either by the owner or by keepers.
    ///
    /// # Accounts
    /// *[See the documentation for the accounts.](CloseWithdrawal)*
    ///
    /// # Arguments
    /// - `reason`: The reason for closing the withdrawal.
    ///
    /// # Errors
    /// This instruction will fail if:
    /// - The [`executor`](CloseWithdrawal::executor) is not a signer or is neither the withdrawal
    ///   owner nor an ORDER_KEEPER in the store.
    /// - The [`store`](CloseWithdrawal::store) is not properly initialized.
    /// - The [`owner`](CloseWithdrawal::owner) does not match the withdrawal owner.
    /// - The token mint accounts do not match those recorded in the `withdrawal`.
    /// - The [`withdrawal`](CloseWithdrawal::withdrawal) is not initialized, not owned by the store,
    ///   or not owned by the specified `owner`.
    /// - Any required escrow accounts are not properly initialized or not owned by the `withdrawal`.
    /// - Any associated token accounts have invalid addresses.
    /// - The withdrawal is not in a cancelled or completed state when the executor is not the owner
    pub fn close_withdrawal<'info>(
        ctx: Context<'_, '_, 'info, 'info, CloseWithdrawal<'info>>,
        reason: String,
    ) -> Result<()> {
        internal::Close::close(&ctx, &reason)
    }

    /// Execute a withdrawal by keepers.
    ///
    /// # Accounts
    /// *[See the documentation for the accounts.](ExecuteWithdrawal)*
    ///
    /// # Arguments
    /// - `execution_fee`: The execution fee to be paid to the keeper for executing the withdrawal.
    /// - `throw_on_execution_error`: If true, throws an error if execution fails. If false, the
    ///   withdrawal will be cancelled instead.
    ///
    /// # Errors
    /// This instruction will fail if:
    /// - The [`authority`](ExecuteWithdrawal::authority) is not a signer or is not an ORDER_KEEPER
    ///   in the store.
    /// - The [`store`](ExecuteWithdrawal::store) is not properly initialized.
    /// - The [`token_map`](ExecuteWithdrawal::token_map) is not initialized or not authorized by
    ///   the store.
    /// - The [`oracle`](ExecuteWithdrawal::oracle) is not initialized, cleared and owned by the
    ///   store.
    /// - The [`market`](ExecuteWithdrawal::market) is not initialized, is disabled, not owned by
    ///   the store, or does not match the market recorded in the `withdrawal`.
    /// - The [`withdrawal`](ExecuteWithdrawal::withdrawal) is not initialized, not owned by the
    ///   store, or not in the pending state.
    /// - Any token mint accounts do not match those recorded in the `withdrawal`.
    /// - Any escrow accounts are not properly initialized or not owned by the `withdrawal`.
    /// - Any vault accounts are not valid market vaults or do not correspond to the final tokens.
    /// - Any feed accounts in the remaining accounts are invalid or do not match the swap parameters.
    /// - Any market accounts in the remaining accounts are disabled, not owned by the store, or do
    ///   not match the swap parameters.
    /// - Any oracle prices from the feed accounts are incomplete or invalid.
    /// - The execution fails and `throw_on_execution_error` is set to true.
    #[access_control(internal::Authenticate::only_order_keeper(&ctx))]
    pub fn execute_withdrawal<'info>(
        ctx: Context<'_, '_, 'info, 'info, ExecuteWithdrawal<'info>>,
        execution_fee: u64,
        throw_on_execution_error: bool,
    ) -> Result<()> {
        instructions::unchecked_execute_withdrawal(ctx, execution_fee, throw_on_execution_error)
    }

    // ===========================================
    //             Order and Position
    // ===========================================

    /// Prepare the position account for orders.
    ///
    /// # Accounts
    /// *[See the documentation for the accounts.](PreparePosition)*
    ///
    /// # Arguments
    /// - `params`: Order Parameters.
    ///
    /// # Errors
    /// This instruction will fail if:
    /// - The [`owner`](PreparePosition::owner) is not a signer or has insufficient balance for the
    ///   rent.
    /// - The [`store`](PreparePosition::store) is not properly initialized.
    /// - The [`market`](PreparePosition::market) is not initialized, is disabled, or not owned by
    ///   the `store`.
    /// - The [`position`](PreparePosition::position) address is not a valid PDA derived from the
    ///   `owner` and expected seeds.
    /// - The position account is neither uninitialized nor validly initialized with `store` as the
    ///   store and `owner` as the owner.
    pub fn prepare_position(
        ctx: Context<PreparePosition>,
        params: CreateOrderParams,
    ) -> Result<()> {
        instructions::prepare_position(ctx, &params)
    }

    /// Create an order by the owner.
    ///
    /// # Accounts
    /// *[See the documentation for the accounts.](CreateOrderV2)*
    ///
    /// # Arguments
    /// - `nonce`: Nonce bytes used to derive the address for the order.
    /// - `params`: Order Parameters specifying the market, order kind, and other details.
    ///
    /// # Errors
    /// This instruction will fail if:
    /// - The [`owner`](CreateOrderV2::owner) is not a signer or has insufficient balance for the
    ///   execution fee and rent.
    /// - The [`store`](CreateOrderV2::store) is not properly initialized.
    /// - The [`market`](CreateOrderV2::market) is not initialized, is disabled, or not owned by
    ///   the `store`.
    /// - The [`user`](CreateOrderV2::user) is not initialized or does not correspond to the owner.
    ///   The address must be a valid PDA derived from the `owner` and expected seeds.
    /// - The [`order`](CreateOrderV2::order) is not uninitialized or the address is not a valid
    ///   PDA derived from the `owner`, `nonce` and expected seeds.
    /// - For increase/decrease orders:
    ///   - The [`position`](CreateOrderV2::position) is missing, not validly initialized, or not
    ///     owned by both the `owner` and `store`.
    ///   - The [`long_token`](CreateOrderV2::long_token) or [`short_token`](CreateOrderV2::short_token)
    ///     are missing, or do not match the those defined in the [`market`](CreateOrderV2::market).
    ///   - The [`long_token_escrow`](CreateOrderV2::long_token_escrow) or
    ///     [`short_token_escrow`](CreateOrderV2::short_token_escrow) are missing, not valid
    ///     escrow accounts for `long_token` or `short_token` respectively, or not owned by the `order`.
    /// - For increase/swap orders:
    ///   - The [`initial_collateral_token`](CreateOrderV2::initial_collateral_token) is missing
    ///     or invalid.
    ///   - The [`initial_collateral_token_escrow`](CreateOrderV2::initial_collateral_token_escrow)
    ///     is missing, not a valid escrow account for `initial_collateral_token`, or not owned by
    ///     the `order`.
    ///   - The [`initial_collateral_token_source`](CreateOrderV2::initial_collateral_token_source)
    ///     is missing or not a valid source account with `owner` as the authority.
    /// - For decrease/swap orders:
    ///   - The [`final_output_token`](CreateOrderV2::final_output_token) is invalid.
    ///   - The [`final_output_token_escrow`](CreateOrderV2::final_output_token_escrow) is missing,
    ///     not a valid escrow account for `final_output_token`, or not owned by the `order`.
    /// - The feature for creating this kind of order is not enabled.
    /// - The remaining market accounts do not match the swap parameters, not all enabled or owned
    ///   by the `store`.
    /// - The accounts related to callback must be provided if
    ///   [`callback_authority`](CreateOrderV2::callback_authority) is provided.
    pub fn create_order_v2<'info>(
        mut ctx: Context<'_, '_, 'info, 'info, CreateOrderV2<'info>>,
        nonce: [u8; 32],
        params: CreateOrderParams,
        callback_version: Option<u8>,
    ) -> Result<()> {
        internal::Create::create(&mut ctx, &nonce, &params, callback_version)
    }

    /// Close an order, either by the owner or by keepers.
    ///
    /// # Accounts
    /// *[See the documentation for the accounts.](CloseOrderV2)*
    ///
    /// # Arguments
    /// - `reason`: The reason for the close.
    ///
    /// # Errors
    /// - The [`executor`](CloseOrderV2::executor) must be a signer and either the owner
    ///   of the `order` or a ORDER_KEEPER in the store.
    /// - The [`store`](CloseOrderV2::store) must be initialized.
    /// - The [`owner`](CloseOrderV2::owner) must be the owner of the `order`.
    /// - The [`user`](CloseOrderV2::user) must be initialized and correspond to the `owner`.
    /// - The [`referrer_user`](CloseOrderV2::referrer_user) must be present if the `owner` has a
    ///   referrer, and it must be initialized and correspond to the referrer of the `owner`.
    /// - The [`order`](CloseOrderV2::order) must be initialized and owned by the `store` and the
    ///   `owner`.
    /// - The tokens must be those recorded in the `order`.
    /// - The escrow accounts must be owned and recorded in the `order`.
    /// - The addresses of the ATAs must be valid.
    /// - The `order` must be cancelled or completed if the `executor` is not the owner.
    /// - The feature must be enabled for closing the given kind of `order`.
    /// - The accounts related to callback must be provided if
    ///   [`callback_authority`](CloseOrderV2::callback_authority) is provided.
    pub fn close_order_v2<'info>(
        ctx: Context<'_, '_, 'info, 'info, CloseOrderV2<'info>>,
        reason: String,
    ) -> Result<()> {
        internal::Close::close(&ctx, &reason)
    }

    /// Settle the builder fee of an order.
    ///
    /// Permissionless: any signer may invoke it, no role is required, and no
    /// authority within the protocol can block it. The fee token's freeze
    /// authority can, by freezing the builder's claim vault, which is the known
    /// liveness exception documented with the builder fee invariants on
    /// [`crate::states::order`]. Idempotent: a recorded builder fee amount of
    /// zero, including orders that never had a builder set, is an explicit
    /// no-op, so this may be called in any order state, before or after
    /// terminal.
    ///
    /// # Accounts
    /// *[See the documentation for the accounts.](SettleBuilderFee)*
    ///
    /// # Errors
    /// - The [`order`](SettleBuilderFee::order) must be initialized and owned by the `store`.
    /// - If the order's recorded builder fee amount is non-zero, all four of
    ///   [`final_output_token`](SettleBuilderFee::final_output_token),
    ///   [`escrow`](SettleBuilderFee::escrow),
    ///   [`builder_user`](SettleBuilderFee::builder_user) and
    ///   [`claim_vault`](SettleBuilderFee::claim_vault) must be provided: the `escrow` must be
    ///   the final output token account recorded on the order, the `builder_user` must match the
    ///   builder recorded on the order, and the `claim_vault` must be the associated token
    ///   account of the final output token owned by `builder_user`.
    pub fn settle_builder_fee(ctx: Context<SettleBuilderFee>) -> Result<()> {
        SettleBuilderFee::invoke(ctx)
    }

    /// Cancel order if the corresponding position does not exist.
    ///
    /// # Accounts
    /// *[See the documentation for the accounts.](CancelOrderIfNoPosition)*
    ///
    /// # Errors
    /// - The [`authority`](CancelOrderIfNoPosition::authority) must be a signed ORDER_KEEPER
    ///   in the store.
    /// - The [`store`](CancelOrderIfNoPosition::authority) must be initialized.
    /// - The [`order`](CancelOrderIfNoPosition::order) must be initialized and owned by the
    ///   `store`. It must be in the pending state.
    /// - The [`position`](CancelOrderIfNoPosition::position) must be recorded in the order.
    ///   It must be owned by the system program (i.e., considered to be missing).
    #[access_control(internal::Authenticate::only_order_keeper(&ctx))]
    pub fn cancel_order_if_no_position(ctx: Context<CancelOrderIfNoPosition>) -> Result<()> {
        instructions::unchecked_cancel_order_if_no_position(ctx)
    }

    /// Close an empty position account.
    ///
    /// # Accounts
    /// *[See the documentation for the accounts.](CloseEmptyPosition)*
    ///
    /// # Errors
    /// - [`owner`](CloseEmptyPosition::owner) must sign the transaction and own the `position`.
    /// - [`store`](CloseEmptyPosition::store) must be initialized.
    /// - [`position`](CloseEmptyPosition::position) must be empty and older than
    ///   [`MinPositionAgeForManualClose`](crate::states::store::AmountKey::MinPositionAgeForManualClose).
    pub fn close_empty_position(ctx: Context<CloseEmptyPosition>) -> Result<()> {
        CloseEmptyPosition::invoke(ctx)
    }

    /// Prepare a trade event buffer.
    ///
    /// # Accounts
    /// *[See the documentation for the accounts.](PrepareTradeEventBuffer)*
    ///
    /// # Arguments
    /// - `index`: The index of the trade event buffer to prepare.
    ///
    /// # Errors
    /// - The [`authority`](PrepareTradeEventBuffer::authority) must be a signer.
    /// - The [`store`](PrepareTradeEventBuffer::store) must be initialized.
    /// - The [`event`](PrepareTradeEventBuffer::event) must be either:
    ///   - Uninitialized, or
    ///   - Already initialized with the `authority` as the authority and the `store` as
    ///     the store
    // Note: There is a false positive lint for the doc link of `event`.
    #[allow(rustdoc::broken_intra_doc_links)]
    pub fn prepare_trade_event_buffer(
        ctx: Context<PrepareTradeEventBuffer>,
        index: u16,
    ) -> Result<()> {
        instructions::prepare_trade_event_buffer(ctx, index)
    }

    /// Update an order by the owner.
    ///
    /// # Accounts
    /// *[See the documentation for the accounts.](UpdateOrderV2)*
    ///
    /// # Arguments
    /// - `params`: Update Order Parameters.
    ///
    /// # Errors
    /// - The [`owner`](UpdateOrderV2::owner) must be a signer and the owner of the `order`.
    /// - The [`store`](UpdateOrderV2::store) must be initialized.
    /// - The [`market`](UpdateOrderV2::market) must be initialized, enabled and owned by the `store`.
    /// - The [`order`](UpdateOrderV2::order) must be:
    ///   - Initialized and owned by both the `store` and the `owner`
    ///   - Associated with the provided `market`
    ///   - In a pending state
    ///   - The order type must support updates
    /// - The feature must be enabled in the `store` for updating the given kind of `order`.
    /// - The updated parameters must be valid for the order type.
    pub fn update_order_v2(ctx: Context<UpdateOrderV2>, params: UpdateOrderParams) -> Result<()> {
        UpdateOrderV2::invoke(ctx, &params)
    }

    /// Set whether to keep position account for an order by the owner.
    ///
    /// # Accounts
    /// *[See the documentation for the accounts.](SetShouldKeepPositionAccount)*
    ///
    /// # Arguments
    /// - `keep`: Whether the position account should be kept.
    ///
    /// # Errors
    /// - The [`owner`](SetShouldKeepPositionAccount::owner) must be a signer and the owner of the `order`.
    /// - The [`order`](SetShouldKeepPositionAccount::order) must be:
    ///   - Initialized and owned by the `owner`
    ///   - In a pending state
    pub fn set_should_keep_position_account(
        ctx: Context<SetShouldKeepPositionAccount>,
        keep: bool,
    ) -> Result<()> {
        SetShouldKeepPositionAccount::invoke(ctx, keep)
    }

    /// Execute an increase/swap order by keepers.
    ///
    /// # Accounts
    /// *[See the documentation for the accounts.](ExecuteIncreaseOrSwapOrderV2)*
    ///
    /// # Arguments
    /// - `recent_timestamp`: A recent timestamp used for deriving the claimable accounts.
    /// - `execution_fee`: The execution fee claimed to be used the keeper.
    /// - `throw_on_execution_error`: If true, throws an error if order execution fails. If false,
    ///   silently cancels the order on execution failure.
    ///
    /// # Errors
    /// - The [`authority`](ExecuteIncreaseOrSwapOrderV2::authority) must be a signer and have the
    ///   ORDER_KEEPER role in the `store`.
    /// - The [`store`](ExecuteIncreaseOrSwapOrderV2::store) must be initialized.
    /// - The [`token_map`](ExecuteIncreaseOrSwapOrderV2::token_map) must be initialized and authorized
    ///   by the `store`.
    /// - The [`oracle`](ExecuteIncreaseOrSwapOrderV2::oracle) must be initialized, cleared and owned
    ///   by the `store`.
    /// - The [`market`](ExecuteIncreaseOrSwapOrderV2::market) must be initialized, enabled and owned
    ///   by the `store`. It must also be associated with the `order`.
    /// - The [`owner`](ExecuteIncreaseOrSwapOrderV2::owner) must be the owner of the `order`.
    /// - The [`user`](ExecuteIncreaseOrSwapOrderV2::user) must be initialized and associated with
    ///   the `owner`.
    /// - The [`order`](ExecuteIncreaseOrSwapOrderV2::order) must be:
    ///   - Initialized and owned by both the `store` and `owner`
    ///   - Associated with the provided `market`
    ///   - In a pending state
    /// - For increase orders:
    ///   - The [`initial_collateral_token`](ExecuteIncreaseOrSwapOrderV2::initial_collateral_token)
    ///     must be valid.
    ///   - The [`position`](ExecuteIncreaseOrSwapOrderV2::position) must exist and be owned by the
    ///     `owner` and `store`. It must match the `order`.
    ///   - The [`event`](ExecuteIncreaseOrSwapOrderV2::event) must be a valid trade event buffer owned
    ///     by both the `store` and `authority`.
    ///   - The [`long_token`](ExecuteIncreaseOrSwapOrderV2::long_token) and [`short_token`](ExecuteIncreaseOrSwapOrderV2::short_token)
    ///     must match those defined in the `market`.
    ///   - The corresponding token escrow and vault accounts must be valid, recorded in the `order`
    ///     and owned by the `order`.
    /// - For swap orders:
    ///   - The [`initial_collateral_token`](ExecuteIncreaseOrSwapOrderV2::initial_collateral_token)
    ///     must be valid.
    ///   - The [`final_output_token`](ExecuteIncreaseOrSwapOrderV2::final_output_token) must be valid.
    ///   - The corresponding escrow and vault accounts must be valid, recorded in the `order` and
    ///     owned by the `order`.
    /// - The remaining accounts must be valid. See the documentation for the accounts for more
    ///   details.
    /// - The feature for executing this order type must be enabled in the `store`.
    /// - If `throw_on_execution_error` is true, any execution failure will throw an error
    // Note: There is a false positive lint for the doc link of `event`.
    #[allow(rustdoc::broken_intra_doc_links)]
    #[access_control(internal::Authenticate::only_order_keeper(&ctx))]
    pub fn execute_increase_or_swap_order_v2<'info>(
        ctx: Context<'_, '_, 'info, 'info, ExecuteIncreaseOrSwapOrderV2<'info>>,
        recent_timestamp: i64,
        execution_fee: u64,
        throw_on_execution_error: bool,
    ) -> Result<()> {
        ExecuteIncreaseOrSwapOrderV2::invoke(
            ctx,
            recent_timestamp,
            execution_fee,
            throw_on_execution_error,
        )
    }

    /// Execute a decrease order by keepers.
    ///
    /// # Accounts
    /// *[See the documentation for the accounts.](ExecuteDecreaseOrderV2)*
    ///
    /// # Arguments
    /// - `recent_timestamp`: A timestamp that must be within a recent time window.
    /// - `execution_fee`: The execution fee claimed to be used by the keeper.
    /// - `throw_on_execution_error`: If true, throws an error if order execution fails. If false,
    ///   silently cancels the order on execution failure.
    ///
    /// # Errors
    /// - The [`authority`](ExecuteDecreaseOrderV2::authority) must be a signer with the ORDER_KEEPER
    ///   role in the `store`.
    /// - The [`store`](ExecuteDecreaseOrderV2::store) must be initialized.
    /// - The [`token_map`](ExecuteDecreaseOrderV2::token_map) must be initialized and authorized
    ///   by the `store`.
    /// - The [`oracle`](ExecuteDecreaseOrderV2::oracle) must be initialized, cleared and owned
    ///   by the `store`.
    /// - The [`market`](ExecuteDecreaseOrderV2::market) must be initialized, enabled and owned
    ///   by the `store`.
    /// - The [`owner`](ExecuteDecreaseOrderV2::owner) must be the owner of the `order`.
    /// - The [`user`](ExecuteDecreaseOrderV2::user) must be initialized and associated with
    ///   the `owner`.
    /// - The [`order`](ExecuteDecreaseOrderV2::order) must be:
    ///   - Initialized and owned by both the `store` and `owner`
    ///   - Associated with the provided `market`
    ///   - In the pending state
    /// - The [`position`](ExecuteDecreaseOrderV2::position) must exist and be validly owned
    ///   by the `owner` and `store`. It must match the `order`.
    /// - The [`event`](ExecuteDecreaseOrderV2::event) must be a valid trade event buffer
    ///   owned by both the `store` and `authority`.
    /// - The tokens must match those recorded in the `order`.
    /// - All escrow accounts must be valid, recorded in the `order` and owned by the `order`.
    /// - All vault accounts must be valid market vault accounts and owned by the `store`.
    /// - All claimable token accounts must be valid and properly delegated to their owners.
    /// - The remaining accounts must be valid. See the documentation for the accounts for more
    ///   details.
    /// - The feature for executing decrease orders must be enabled in the `store`.
    /// - If `throw_on_execution_error` is true, any execution failure will throw an error.
    // Note: There is a false positive lint for the doc link of `event`.
    #[allow(rustdoc::broken_intra_doc_links)]
    #[access_control(internal::Authenticate::only_order_keeper(&ctx))]
    pub fn execute_decrease_order_v2<'info>(
        ctx: Context<'_, '_, 'info, 'info, ExecuteDecreaseOrderV2<'info>>,
        recent_timestamp: i64,
        execution_fee: u64,
        throw_on_execution_error: bool,
    ) -> Result<()> {
        ExecuteDecreaseOrderV2::invoke(
            ctx,
            recent_timestamp,
            execution_fee,
            throw_on_execution_error,
        )
    }

    /// Perform a liquidation by keepers.
    ///
    /// # Accounts
    /// *[See the documentation for the accounts.](PositionCut)*
    ///
    /// # Arguments
    /// - `nonce`: The nonce used to derive the `order` PDA address.
    /// - `recent_timestamp`: A recent timestamp that must be within the valid time window.
    /// - `execution_fee`: The execution fee claimed to be used by the keeper.
    ///
    /// # Errors
    /// - The [`authority`](PositionCut::authority) must be a signer with the ORDER_KEEPER
    ///   role in the `store`.
    /// - The [`owner`](PositionCut::owner) must be the owner of the position being liquidated.
    /// - The [`user`](PositionCut::user) must be an initialized user account corresponding to the
    ///   `owner`.
    /// - The [`store`](PositionCut::store) must be initialized.
    /// - The [`token_map`](PositionCut::token_map) must be initialized and authorized by the
    ///   `store`.
    /// - The [`oracle`](PositionCut::oracle) must be initialized, cleared and owned by the `store`.
    /// - The [`market`](PositionCut::market) must be:
    ///   - Initialized and enabled
    ///   - Owned by the `store`
    ///   - Associated with the position being liquidated
    /// - The [`order`](PositionCut::order) must be:
    ///   - Uninitialized
    ///   - Have an address matching the PDA derived from the `store`, `owner`, provided
    ///     `nonce` and other expected seeds
    /// - The [`position`](PositionCut::position) must be:
    ///   - Validly initialized
    ///   - Owned by both the `owner` and `store`
    ///   - In a liquidatable state
    /// - The [`event`](PositionCut::event) must be a valid trade event buffer owned by both the
    ///   `store` and `authority`.
    /// - The [`long_token`](PositionCut::long_token) and [`short_token`](PositionCut::short_token)
    ///   must match those defined in the `market`.
    /// - Token escrow accounts must be:
    ///   - Valid for their respective tokens
    ///   - Owned by the `order`
    /// - Market vault accounts must be:
    ///   - Valid market vault accounts for their respective tokens
    ///   - Owned by the `store`
    /// - Claimable token accounts must be:
    ///   - Valid for their respective tokens
    ///   - Owned by the `store`
    ///   - Properly delegated to their owners
    /// - Price feed accounts must be:
    ///   - Valid and complete
    ///   - Provided in order matching the market's sorted token list
    /// - The liquidation feature must be enabled in the `store`.
    /// - Oracle prices must be valid and complete.
    // Note: There is a false positive lint for the doc link of `event`.
    #[allow(rustdoc::broken_intra_doc_links)]
    #[access_control(internal::Authenticate::only_order_keeper(&ctx))]
    pub fn liquidate<'info>(
        ctx: Context<'_, '_, 'info, 'info, PositionCut<'info>>,
        nonce: [u8; 32],
        recent_timestamp: i64,
        execution_fee: u64,
    ) -> Result<()> {
        instructions::unchecked_process_position_cut(
            ctx,
            &nonce,
            recent_timestamp,
            PositionCutKind::Liquidate,
            execution_fee,
            true,
        )
    }

    /// Update the ADL (Auto-Deleveraging) state for the market.
    ///
    /// # Accounts
    /// *[See the documentation for the accounts.](UpdateAdlState)*
    ///
    /// # Arguments
    /// - `is_long`: Whether to update the ADL state for the long (`true`) or short (`false`) side
    ///   of the market.
    ///
    /// # Errors
    /// - The [`authority`](UpdateAdlState::authority) must be a signer and have the ORDER_KEEPER
    ///   role in the store.
    /// - The [`store`](UpdateAdlState::store) must be an initialized [`Store`](states::Store)
    ///   account owned by the store program.
    /// - The [`oracle`](UpdateAdlState::oracle) must be an initialized [`Oracle`](states::Oracle)
    ///   account that is owned by the store.
    /// - The [`market`](UpdateAdlState::market) must be enabled and owned by the store.
    /// - Price feed accounts must be valid and provided in the market's sorted token list order.
    #[access_control(internal::Authenticate::only_order_keeper(&ctx))]
    pub fn update_adl_state<'info>(
        ctx: Context<'_, '_, 'info, 'info, UpdateAdlState<'info>>,
        is_long: bool,
    ) -> Result<()> {
        instructions::unchecked_update_adl_state(ctx, is_long)
    }

    /// Perform an ADL (Auto-Deleveraging) by keepers.
    ///
    /// # Accounts
    /// *[See the documentation for the accounts.](PositionCut)*
    ///
    /// # Arguments
    /// - `nonce`: The nonce used to derive the `order` PDA address.
    /// - `recent_timestamp`: A recent blockchain timestamp for validation.
    /// - `execution_fee`: The execution fee claimed to be used by the keeper.
    ///
    /// # Errors
    /// - The [`authority`](PositionCut::authority) must be a signer with the ORDER_KEEPER role.
    /// - The [`owner`](PositionCut::owner) must be the position owner.
    /// - The [`user`](PositionCut::user) must be initialized and corresponding to the `owner`.
    /// - The [`store`](PositionCut::store) must be initialized.
    /// - The [`token_map`](PositionCut::token_map) must be initialized and authorized by the store.
    /// - The [`oracle`](PositionCut::oracle) must be initialized, cleared and store-owned.
    /// - The [`market`](PositionCut::market) must be initialized, enabled, store-owned and match
    ///   the position's market. The market must be in ADL state.
    /// - The [`order`](PositionCut::order) must be uninitialized with address matching PDA from
    ///   the `store`, `owner`, `nonce` and other expected seeds.
    /// - The [`position`](PositionCut::position) must be initialized, owned by the `owner` and
    ///   `store` and eligible for ADL.
    /// - The [`event`](PositionCut::event) must be a valid trade event buffer owned by the `store`
    ///   and `authority`.
    /// - The [`long_token`](PositionCut::long_token) and [`short_token`](PositionCut::short_token)
    ///   must match those defined in the `market`.
    /// - The [`long_token_escrow`](PositionCut::long_token_escrow) and
    ///   [`short_token_escrow`](PositionCut::short_token_escrow) must be valid order-owned escrow
    ///   accounts for their respective tokens.
    /// - The [`long_token_vault`](PositionCut::long_token_vault) and
    ///   [`short_token_vault`](PositionCut::short_token_vault) must be valid store-owned market
    ///   vault accounts for their tokens.
    /// - The [`claimable_long_token_account_for_user`](PositionCut::claimable_long_token_account_for_user)
    ///   must be a store-owned, owner-delegated claimable account for long token.
    /// - The [`claimable_short_token_account_for_user`](PositionCut::claimable_short_token_account_for_user)
    ///   must be a store-owned, owner-delegated claimable account for short token.
    /// - The [`claimable_pnl_token_account_for_holding`](PositionCut::claimable_pnl_token_account_for_holding)
    ///   must be a store-owned, holding-delegated claimable account for PnL token.
    /// - Price feed accounts must be valid and provided in the market's sorted token list order.
    /// - The ADL feature must be enabled in the `store`.
    /// - Oracle prices must be valid and complete.
    /// - Execution must complete successfully.
    // Note: There is a false positive lint for the doc link of `event`.
    #[allow(rustdoc::broken_intra_doc_links)]
    #[access_control(internal::Authenticate::only_order_keeper(&ctx))]
    pub fn auto_deleverage<'info>(
        ctx: Context<'_, '_, 'info, 'info, PositionCut<'info>>,
        nonce: [u8; 32],
        recent_timestamp: i64,
        size_delta_in_usd: u128,
        execution_fee: u64,
    ) -> Result<()> {
        instructions::unchecked_process_position_cut(
            ctx,
            &nonce,
            recent_timestamp,
            PositionCutKind::AutoDeleverage(size_delta_in_usd),
            execution_fee,
            true,
        )
    }

    /// Update the closed state for the market.
    ///
    /// # Accounts
    /// *[See the documentation for the accounts.](UpdateClosedState)*
    ///
    /// # Errors
    /// - The [`authority`](UpdateClosedState::authority) must be a signer and have the ORDER_KEEPER
    ///   role in the store.
    /// - The [`store`](UpdateClosedState::store) must be an initialized [`Store`](states::Store)
    ///   account owned by the store program.
    /// - The [`oracle`](UpdateClosedState::oracle) must be an initialized [`Oracle`](states::Oracle)
    ///   account that is owned by the store.
    /// - The [`market`](UpdateClosedState::market) must be enabled and owned by the store.
    /// - Price feed accounts must be valid and provided in the market's sorted token list order.
    #[access_control(internal::Authenticate::only_order_keeper(&ctx))]
    pub fn update_closed_state<'info>(
        ctx: Context<'_, '_, 'info, 'info, UpdateClosedState<'info>>,
    ) -> Result<()> {
        UpdateClosedState::invoke_unchecked(ctx)
    }

    /// Update fees state for the given market.
    ///
    /// # Accounts
    /// *[See the documentation for the accounts.](UpdateFeesState)*
    ///
    /// # Errors
    /// - The [`authority`](UpdateFeesState::authority) must be a signer and have the ORDER_KEEPER
    ///   role in the store.
    /// - The [`store`](UpdateFeesState::store) must be an initialized [`Store`](states::Store)
    ///   account owned by the store program.
    /// - The [`oracle`](UpdateFeesState::oracle) must be an initialized [`Oracle`](states::Oracle)
    ///   account that is owned by the store.
    /// - The [`market`](UpdateFeesState::market) must be enabled and owned by the store.
    /// - Price feed accounts must be valid and provided in the market's sorted token list order.
    /// - Virtual inventory accounts must be valid and include the virtual inventory associate
    ///   with the market.
    #[access_control(internal::Authenticate::only_order_keeper(&ctx))]
    pub fn update_fees_state<'info>(
        ctx: Context<'_, '_, 'info, 'info, UpdateFeesState<'info>>,
    ) -> Result<()> {
        UpdateFeesState::invoke_unchecked(ctx)
    }

    // ===========================================
    //                  Shift
    // ===========================================

    /// Create a shift by the owner.
    ///
    /// # Accounts
    /// *[See the documentation for the accounts.](CreateShift)*
    ///
    /// # Arguments
    /// - `nonce`: The nonce used to derive the shift's PDA address.
    /// - `params`: The parameters for creating the shift.
    ///
    /// # Errors
    /// - The [`owner`](CreateShift::owner) must be a signer and have sufficient balance for the
    ///   execution fee and rent.
    /// - The [`store`](CreateShift::store) must be initialized.
    /// - The [`from_market`](CreateShift::from_market) must be initialized, enabled
    ///   and store-owned.
    /// - The [`to_market`](CreateShift::to_market) must be initialized, enabled
    ///   and store-owned.
    /// - The [`from_market`](CreateShift::from_market) must be shiftable to the
    ///   [`to_market`](CreateShift::to_market).
    /// - The [`shift`](CreateShift::shift) must be uninitialized. Its address must
    ///   match the PDA derived from the expected seeds.
    /// - The [`from_market_token`](CreateShift::from_market_token) must be the market
    ///   token of the [`from_market`](CreateShift::from_market).
    /// - The [`to_market_token`](CreateShift::to_market_token) must be the market
    ///   token of the [`to_market`](CreateShift::to_market).
    /// - The [`from_market_token_escrow`](CreateShift::from_market_token_escrow) must
    ///   be a valid shift-owned escrow account for the
    ///   [`from_market_token`](CreateShift::from_market_token).
    /// - The [`to_market_token_escrow`](CreateShift::to_market_token_escrow) must be
    ///   a valid shift-owned escrow account for the
    ///   [`to_market_token`](CreateShift::to_market_token).
    /// - The [`from_market_token_source`](CreateShift::from_market_token_source) must
    ///   be a token account for [`from_market_token`](CreateShift::from_market_token)
    ///   with `owner` as authority.
    /// - The [`to_market_token_ata`](CreateShift::to_market_token_ata) must be a valid
    ///   associated token account for [`to_market_token`](CreateShift::to_market_token)
    ///   owned by `owner`.
    pub fn create_shift<'info>(
        mut ctx: Context<'_, '_, 'info, 'info, CreateShift<'info>>,
        nonce: [u8; 32],
        params: CreateShiftParams,
    ) -> Result<()> {
        internal::Create::create(&mut ctx, &nonce, &params, None)
    }

    /// Execute a shift by keepers.
    ///
    /// # Accounts
    /// *[See the documentation for the accounts.](ExecuteShift)*
    ///
    /// # Arguments
    /// - `execution_lamports`: The execution fee in lamports claimed to be used by the keeper.
    /// - `throw_on_execution_error`: Whether to throw an error if the execution fails.
    ///
    /// # Errors
    /// - The [`authority`](ExecuteShift::authority) must be a signer and have the ORDER_KEEPER role
    ///   in the store.
    /// - The [`store`](ExecuteShift::store) must be initialized.
    /// - The [`token_map`](ExecuteShift::token_map) must be initialized and authorized by the store.
    /// - The [`oracle`](ExecuteShift::oracle) must be initialized, cleared and store-owned.
    /// - The [`from_market`](ExecuteShift::from_market) must be initialized, enabled and store-owned.
    ///   It must be the from market of the [`shift`](ExecuteShift::shift).
    /// - The [`to_market`](ExecuteShift::to_market) must be initialized, enabled and store-owned.
    ///   It must be the to market of the [`shift`](ExecuteShift::shift).
    /// - The [`from_market`](ExecuteShift::from_market) must be shiftable to the
    ///   [`to_market`](ExecuteShift::to_market).
    /// - The [`shift`](ExecuteShift::shift) must be initialized, store-owned and in the pending state.
    /// - The [`from_market_token`](ExecuteShift::from_market_token) must be the market token of the
    ///   [`from_market`](ExecuteShift::from_market).
    /// - The [`to_market_token`](ExecuteShift::to_market_token) must be the market token of the
    ///   [`to_market`](ExecuteShift::to_market).
    /// - The [`from_market_token_escrow`](ExecuteShift::from_market_token_escrow) must be a valid
    ///   shift-owned escrow account for the [`from_market_token`](ExecuteShift::from_market_token)
    ///   and recorded in the [`shift`](ExecuteShift::shift).
    /// - The [`to_market_token_escrow`](ExecuteShift::to_market_token_escrow) must be a valid
    ///   shift-owned escrow account for the [`to_market_token`](ExecuteShift::to_market_token)
    ///   and recorded in the [`shift`](ExecuteShift::shift).
    /// - The [`from_market_token_vault`](ExecuteShift::from_market_token_vault) must be the market
    ///   vault for the [`from_market_token`](ExecuteShift::from_market_token) and store-owned.
    /// - The feed accounts must be valid and provided in the same order as the unique sorted list
    ///   of tokens in the `from_market` and `to_market`.
    /// - The oracle prices from the feed accounts must be complete and valid.
    /// - If `throw_on_execution_error` is `true`, returns an error if execution fails.
    #[access_control(internal::Authenticate::only_order_keeper(&ctx))]
    pub fn execute_shift<'info>(
        ctx: Context<'_, '_, 'info, 'info, ExecuteShift<'info>>,
        execution_lamports: u64,
        throw_on_execution_error: bool,
    ) -> Result<()> {
        instructions::unchecked_execute_shift(ctx, execution_lamports, throw_on_execution_error)
    }

    /// Close a shift, either by the owner or by keepers.
    ///
    /// # Accounts
    /// *[See the documentation for the accounts.](CloseShift)*
    ///
    /// # Arguments
    /// - `reason`: The reason for closing the shift.
    ///
    /// # Errors
    /// - The [`executor`](CloseShift::executor) must be a signer, and either the owner or have
    ///   the ORDER_KEEPER role.
    /// - The [`store`](CloseShift::store) must be initialized.
    /// - The [`owner`](CloseShift::owner) must be the owner of the shift.
    /// - The [`shift`](CloseShift::shift) must be initialized and owned by both the `store` and
    ///   `owner`.
    /// - The [`from_market_token`](CloseShift::from_market_token) and
    ///   [`to_market_token`](CloseShift::to_market_token) must be valid and match those recorded
    ///   in the [`shift`](CloseShift::shift).
    /// - The [`from_market_token_escrow`](CloseShift::from_market_token_escrow) and
    ///   [`to_market_token_escrow`](CloseShift::to_market_token_escrow) must be valid escrow
    ///   accounts owned by the `shift` and match those recorded in the [`shift`](CloseShift::shift).
    /// - The address of the [`from_market_token_ata`](CloseShift::from_market_token_ata) must match
    ///   the derived associated token account address for the `from_market_token` and `owner`.
    /// - The address of the [`to_market_token_ata`](CloseShift::to_market_token_ata) must match
    ///   the derived associated token account address for the `to_market_token` and `owner`.
    /// - If the `executor` is not the `owner`, the `shift` must be in either cancelled or completed
    ///   state.
    pub fn close_shift<'info>(
        ctx: Context<'_, '_, 'info, 'info, CloseShift<'info>>,
        reason: String,
    ) -> Result<()> {
        internal::Close::close(&ctx, &reason)
    }

    // ===========================================
    //                The GT Model
    // ===========================================

    /// Initialize GT Mint.
    ///
    /// # Accounts
    /// *[See the documentation for the accounts.](InitializeGt)*
    ///
    /// # Arguments
    /// - `decimals`: The number of decimal places for the GT token.
    /// - `initial_minting_cost`: The initial cost for minting GT.
    /// - `grow_factor`: The multiplier that increases minting cost for each step.
    /// - `grow_step`: The step size (in GT amount) for minting cost increase.
    /// - `ranks`: Array of GT token thresholds that define user rank boundaries.
    ///
    /// # Errors
    /// - The [`authority`](InitializeGt::authority) must be a signer and have the MARKET_KEEPER role in the `store`.
    /// - The [`store`](InitializeGt::store) must be properly initialized.
    /// - The GT state must not already be initialized.
    /// - The arguments must be valid. See `init` method of [`GtState`](states::gt::GtState) for detailed validation logic.
    #[access_control(internal::Authenticate::only_market_keeper(&ctx))]
    pub fn initialize_gt(
        ctx: Context<InitializeGt>,
        decimals: u8,
        initial_minting_cost: u128,
        grow_factor: u128,
        grow_step: u64,
        ranks: Vec<u64>,
    ) -> Result<()> {
        instructions::unchecked_initialize_gt(
            ctx,
            decimals,
            initial_minting_cost,
            grow_factor,
            grow_step,
            &ranks,
        )
    }

    /// Set order fee discount factors.
    ///
    /// # Accounts
    /// *[See the documentation for the accounts.](ConfigureGt)*
    ///
    /// # Arguments
    /// - `factors`: The order fee discount factors for each user rank.
    ///
    /// # Errors
    /// - The [`authority`](ConfigureGt::authority) must be a signer and have the MARKET_KEEPER role in the `store`.
    /// - The [`store`](ConfigureGt::store) must be initialized.
    /// - The GT state of the `store` must be initialized.
    /// - The number of `factors` must match the number of ranks defined in GT state.
    /// - Each factor must be less than or equal to [`MARKET_USD_UNIT`](crate::constants::MARKET_USD_UNIT)(i.e., 100%).
    #[access_control(internal::Authenticate::only_market_keeper(&ctx))]
    pub fn gt_set_order_fee_discount_factors(
        ctx: Context<ConfigureGt>,
        factors: Vec<u128>,
    ) -> Result<()> {
        instructions::unchecked_gt_set_order_fee_discount_factors(ctx, &factors)
    }

    /// Set referral reward factors.
    ///
    /// # Accounts
    /// *[See the documentation for the accounts.](ConfigureGt)*
    ///
    /// # Arguments
    /// - `factors`: The referral reward factors for each user rank.
    ///
    /// # Errors
    /// - The [`authority`](ConfigureGt::authority) must be a signer and a
    ///   GT_CONTROLLER in the store.
    /// - The [`store`](ConfigureGt::store) must be initialized.
    /// - The GT state of the `store` must be initialized.
    /// - The number of `factors` must match the number of ranks defined in GT state.
    /// - Each factor must be less than or equal to [`MARKET_USD_UNIT`](crate::constants::MARKET_USD_UNIT)(i.e., 100%).
    #[access_control(internal::Authenticate::only_gt_controller(&ctx))]
    pub fn gt_set_referral_reward_factors(
        ctx: Context<ConfigureGt>,
        factors: Vec<u128>,
    ) -> Result<()> {
        instructions::unchecked_gt_set_referral_reward_factors(ctx, &factors)
    }

    /// Set GT exchange time window (in seconds).
    ///
    /// # Accounts
    /// *[See the documentation for the accounts.](ConfigureGt)*
    ///
    /// # Arguments
    /// - `window`: The time window in seconds for one GT exchange period.
    ///
    /// # Errors
    /// - The [`authority`](ConfigureGt::authority) must be a signer and have the GT_CONTROLLER role in the `store`.
    /// - The [`store`](ConfigureGt::store) must be properly initialized.
    /// - The GT state of the `store` must be initialized.
    /// - The `window` must be greater than 0 seconds to ensure a valid exchange period.
    #[access_control(internal::Authenticate::only_gt_controller(&ctx))]
    pub fn gt_set_exchange_time_window(ctx: Context<ConfigureGt>, window: u32) -> Result<()> {
        cfg_if::cfg_if! {
            if #[cfg(feature = "test-only")] {
                instructions::unchecked_gt_set_exchange_time_window(ctx, window)
            } else {
                msg!("Trying to set the GT exchange time window to {}, but this is a test-only instruction", window);
                Err(CoreError::Unimplemented.into())
            }
        }
    }

    /// Prepare a GT exchange vault.
    ///
    /// # Accounts
    /// *[See the documentation for the accounts.](PrepareGtExchangeVault)*
    ///
    /// # Arguments
    /// - `time_window_index`: The index of the current time window.
    /// - `time_window`: The current GT exchange time window in seconds.
    ///
    /// # Errors
    /// - The [`payer`](PrepareGtExchangeVault::payer) must be a signer.
    /// - The [`store`](PrepareGtExchangeVault::store) must be properly initialized.
    /// - The GT state of the `store` must be initialized.
    /// - The [`vault`](PrepareGtExchangeVault::vault) must be either:
    ///   - Uninitialized, or
    ///   - Properly initialized, owned by the `store`, and have matching `time_window_index`
    ///     and `time_window` values
    /// - The provided `time_window_index` must match the current time window index.
    pub fn prepare_gt_exchange_vault(
        ctx: Context<PrepareGtExchangeVault>,
        time_window_index: i64,
    ) -> Result<()> {
        instructions::prepare_gt_exchange_vault(ctx, time_window_index)
    }

    /// Confirm GT exchange vault.
    ///
    /// # Accounts
    /// *[See the documentation for the accounts.](ConfirmGtExchangeVault)*
    ///
    /// # Errors
    /// - The [`authority`](ConfirmGtExchangeVault::authority) must be a signer and have the GT_CONTROLLER role in the `store`.
    /// - The [`store`](ConfirmGtExchangeVault::store) must be properly initialized.
    /// - The GT state of the `store` must be initialized.
    /// - The [`vault`](ConfirmGtExchangeVault::vault) must be validly initialized and owned by
    ///   the `store`.
    /// - The `vault` must be in a confirmable state (deposit window has passed but not yet confirmed).
    #[access_control(internal::Authenticate::only_gt_controller(&ctx))]
    pub fn confirm_gt_exchange_vault_v2(
        ctx: Context<ConfirmGtExchangeVault>,
        buyback_value: u128,
        buyback_price: Option<u128>,
    ) -> Result<()> {
        instructions::unchecked_confirm_gt_exchange_vault(ctx, Some(buyback_value), buyback_price)
    }

    /// Request a GT exchange.
    ///
    /// # Accounts
    /// *[See the documentation for the accounts.](RequestGtExchange)*
    ///
    /// # Arguments
    /// - `amount`: The amount of GT to exchange for rewards.
    ///
    /// # Errors
    /// - The [`owner`](RequestGtExchange::owner) must be a signer.
    /// - The [`store`](RequestGtExchange::store) must be properly initialized with an initialized GT state.
    /// - The [`user`](RequestGtExchange::user) must be properly initialized and correspond to the `owner`.
    /// - The [`vault`](RequestGtExchange::vault) must be properly initialized, owned by the `store`,
    ///   and currently accepting deposits (not yet confirmed).
    /// - The [`exchange`](RequestGtExchange::exchange) must be either:
    ///   - Uninitialized, or
    ///   - Properly initialized and owned by both the `owner` and `vault`
    /// - The `amount` must be:
    ///   - Greater than 0
    ///   - Not exceed the owner's available (excluding reserved) GT balance in their user account
    pub fn request_gt_exchange(ctx: Context<RequestGtExchange>, amount: u64) -> Result<()> {
        instructions::request_gt_exchange(ctx, amount)
    }

    /// Close a confirmed GT exchange.
    ///
    /// # Accounts
    /// *[See the documentation for the accounts.](CloseGtExchange)*
    ///
    /// # Errors
    /// - The [`authority`](CloseGtExchange::authority) must be a signer and have the GT_CONTROLLER role in the `store`.
    /// - The [`store`](CloseGtExchange::store) must be properly initialized with an initialized GT state.
    /// - The [`vault`](CloseGtExchange::vault) must be properly initialized, owned by the `store`,
    ///   and confirmed.
    /// - The [`exchange`](CloseGtExchange::exchange) must be properly initialized and owned by both
    ///   the `owner` and `vault`.
    #[access_control(internal::Authenticate::only_gt_controller(&ctx))]
    pub fn close_gt_exchange(ctx: Context<CloseGtExchange>) -> Result<()> {
        instructions::unchecked_close_gt_exchange(ctx)
    }

    /// Update the GT cumulative inverse cost factor.
    ///
    /// # Accounts
    /// *[See the documentation for the accounts.](UpdateGtCumulativeInvCostFactor)*
    ///
    /// # Errors
    /// - The [`authority`](UpdateGtCumulativeInvCostFactor::authority) must be a signer and have the GT_CONTROLLER role in the `store`.
    /// - The [`store`](UpdateGtCumulativeInvCostFactor::store) must be properly initialized with an initialized GT state.
    #[access_control(internal::Authenticate::only_gt_controller(&ctx))]
    pub fn update_gt_cumulative_inv_cost_factor(
        ctx: Context<UpdateGtCumulativeInvCostFactor>,
    ) -> Result<u128> {
        UpdateGtCumulativeInvCostFactor::invoke_unchecked(ctx)
    }

    /// Mint GT directly to the given user account.
    ///
    /// # Accounts
    /// *[See the documentation for the accounts.](MintGtReward)*
    ///
    /// # Errors
    /// - The [`authority`](MintGtReward::authority) must be a signer and have the GT_CONTROLLER role in the `store`.
    /// - The [`store`](MintGtReward::store) must be properly initialized with an initialized GT state.
    /// - The [`user`](MintGtReward::user) must be properly initialized and belong to the store.
    #[access_control(internal::Authenticate::only_gt_controller(&ctx))]
    pub fn mint_gt_reward(ctx: Context<MintGtReward>, amount: u64) -> Result<()> {
        MintGtReward::invoke_unchecked(ctx, amount)
    }

    // ===========================================
    //              User & Referral
    // ===========================================

    /// Initialize or validate a User Account.
    ///
    /// # Accounts
    /// *[See the documentation for the accounts.](PrepareUser)*
    ///
    /// # Errors
    /// - The [`owner`](PrepareUser::owner) must be a signer.
    /// - The [`store`](PrepareUser::store) must be properly initialized.
    /// - The [`user`](PrepareUser::user) must be either:
    ///   - Uninitialized (for new account creation)
    ///   - Or validly initialized and correspond to the `owner`
    pub fn prepare_user(ctx: Context<PrepareUser>) -> Result<()> {
        instructions::prepare_user(ctx)
    }

    /// Initialize referral code.
    ///
    /// # Accounts
    /// *[See the documentation for the accounts.](InitializeReferralCode)*
    ///
    /// # Arguments
    /// - `code`: The referral code to initialize and associate with the user.
    ///
    /// # Errors
    /// - The [`owner`](InitializeReferralCode::owner) must be a signer.
    /// - The [`store`](InitializeReferralCode::store) must be properly initialized.
    /// - The [`referral_code`](InitializeReferralCode::referral_code) account must be uninitialized.
    /// - The [`user`](InitializeReferralCode::user) account must be:
    ///   - Properly initialized
    ///   - Correspond to the `owner`
    ///   - Not already have an associated referral code
    /// - The provided `code` must not already be in use by another user.
    pub fn initialize_referral_code(
        ctx: Context<InitializeReferralCode>,
        code: [u8; 8],
    ) -> Result<()> {
        instructions::initialize_referral_code(ctx, code)
    }

    /// Set referrer.
    ///
    /// # Accounts
    /// *[See the documentation for the accounts.](SetReferrer)*
    ///
    /// # Arguments
    /// - `code`: The referral code of the referrer.
    ///
    /// # Errors
    /// - The [`owner`](SetReferrer::owner) must be a signer.
    /// - The [`store`](SetReferrer::store) must be properly initialized.
    /// - The [`user`](SetReferrer::user) must be:
    ///   - Properly initialized
    ///   - Correspond to the `owner`
    ///   - Must not already have a referrer set
    /// - The [`referral_code`](SetReferrer::referral_code) must be:
    ///   - Properly initialized
    ///   - Owned by the `store`
    ///   - Match the provided `code`
    ///   - Correspond to the `referrer_user`
    /// - The [`referrer_user`](SetReferrer::referrer_user) must be:
    ///   - Properly initialized
    ///   - Different from the `user`
    ///   - Not have the `user` as their referrer (no circular references)
    pub fn set_referrer(ctx: Context<SetReferrer>, code: [u8; 8]) -> Result<()> {
        instructions::set_referrer(ctx, code)
    }

    /// Set the builder fee factor advertised by the user.
    ///
    /// This instruction is permissionless: any User Account owner can set the
    /// factor on their own account, and the account seeds make it impossible
    /// to target another user's account. The factor is only an advertisement:
    /// nothing is charged here, and no instruction reads it yet. A future
    /// `set_builder_fee` will checkpoint it onto an order and validate it
    /// against the cap a second time, and only a factor checkpointed that way
    /// is ever paid.
    ///
    /// # Accounts
    /// *[See the documentation for the accounts.](SetBuilderFeeFactor)*
    ///
    /// # Arguments
    /// - `factor`: The builder fee factor to advertise. `0` opts out.
    ///
    /// # Errors
    /// - The [`owner`](SetBuilderFeeFactor::owner) must be a signer.
    /// - The [`store`](SetBuilderFeeFactor::store) must be properly initialized.
    /// - The [`user`](SetBuilderFeeFactor::user) must be:
    ///   - Properly initialized
    ///   - Correspond to the `owner`
    /// - The `factor` must not exceed the store's
    ///   [`MaxBuilderFeeFactor`](crate::states::FactorKey::MaxBuilderFeeFactor),
    ///   which reads `0` until a config keeper raises it.
    pub fn set_builder_fee_factor(ctx: Context<SetBuilderFeeFactor>, factor: u128) -> Result<()> {
        SetBuilderFeeFactor::invoke(ctx, factor)
    }

    /// Checkpoint a builder and its fee factor onto a pending order.
    ///
    /// Owner-signed and separate from order creation and update on purpose: a
    /// builder fee is only ever paid because the order's owner explicitly
    /// authorized it, for this order, at a rate it could see. The checkpoint is
    /// immutable between calls, so neither an order update nor a later change to
    /// the builder's advertised factor can alter what will be charged.
    ///
    /// Submit this instruction with order creation in the same transaction if
    /// the order must carry a builder fee. With separate transactions, a keeper
    /// can execute the order before the checkpoint lands, charging no builder
    /// fee. The checkpoint cannot be attached after execution or closure.
    /// Check the order's current state before retrying a failed checkpoint;
    /// retrying it on an order that is no longer pending will fail again.
    ///
    /// Calling again on a still-pending order re-runs every validation and
    /// overwrites the checkpoint. Since a User Account advertises a zero factor
    /// until its owner sets one, checkpointing an account that advertises zero
    /// is how an owner cancels a builder fee it no longer wants, even when the
    /// BuilderFee feature is disabled.
    ///
    /// # Accounts
    /// *[See the documentation for the accounts.](SetBuilderFee)*
    ///
    /// # Arguments
    /// - `expected_factor`: The factor the caller expects the builder to be
    ///   advertising. The call fails unless it matches exactly, which is what
    ///   stops a builder from raising its rate between the owner signing and the
    ///   transaction landing.
    ///
    /// # Errors
    /// - The [`owner`](SetBuilderFee::owner) must be a signer and must own the
    ///   [`order`](SetBuilderFee::order).
    /// - The [`store`](SetBuilderFee::store) must be properly initialized and
    ///   must pass restart validation. For a nonzero factor, it must not have
    ///   the [`BuilderFee`](crate::states::feature::DomainDisabledFlag::BuilderFee)
    ///   feature disabled; a zero-factor revocation is allowed while disabled.
    /// - The [`order`](SetBuilderFee::order) must:
    ///   - Belong to the `store`
    ///   - Still be pending execution
    ///   - Be a user-initiated position order, so swap orders and the
    ///     keeper-initiated kinds are rejected
    ///   - Have an initialized final output token, equal to the passed
    ///     [`final_output_token`](SetBuilderFee::final_output_token), and an
    ///     initialized escrow account for it
    ///   - Not carry
    ///     [`CollateralToPnlToken`](gmsol_model::action::decrease_position::DecreasePositionSwapType::CollateralToPnlToken)
    ///     as its decrease position swap type, unless the factor is `0`. This
    ///     is checked on every user-initiated position order rather than only
    ///     on decrease orders, so it is stricter than the swap type's own
    ///     reach
    /// - The [`builder`](SetBuilderFee::builder) must be a properly initialized
    ///   User Account of the same `store`, advertising exactly `expected_factor`.
    /// - The factor must not exceed the store's
    ///   [`MaxBuilderFeeFactor`](crate::states::FactorKey::MaxBuilderFeeFactor).
    /// - The [`claim_vault`](SetBuilderFee::claim_vault) must already exist when
    ///   the factor is nonzero. If supplied with a zero factor, it must still be
    ///   the builder's associated token account for the final output token.
    ///   The [`user_token_controller`](SetBuilderFee::user_token_controller) must
    ///   match its PDA derivation.
    pub fn set_builder_fee(ctx: Context<SetBuilderFee>, expected_factor: u128) -> Result<()> {
        SetBuilderFee::invoke(ctx, expected_factor)
    }

    /// Transfer referral code.
    ///
    /// # Accounts
    /// *[See the documentation for the accounts.](TransferReferralCode)*
    ///
    /// # Errors
    /// - The [`owner`](TransferReferralCode::owner) must be a signer.
    /// - The [`store`](TransferReferralCode::store) must be properly initialized.
    /// - The [`user`](TransferReferralCode::user) account must be:
    ///   - Properly initialized
    ///   - Correspond to the `owner`
    ///   - Different from the [`receiver_user`](TransferReferralCode::receiver_user)
    /// - The [`referral_code`](TransferReferralCode::referral_code) account must be:
    ///   - Properly initialized
    ///   - Owned by the `store`
    ///   - Correspond to the `owner`
    /// - The [`receiver_user`](TransferReferralCode::receiver_user) account must be:
    ///   - Properly initialized
    ///   - Not have an associated referral code
    pub fn transfer_referral_code(ctx: Context<TransferReferralCode>) -> Result<()> {
        instructions::transfer_referral_code(ctx)
    }

    /// Cancel referral code transfer.
    ///
    /// # Accounts
    /// *[See the documentation for the accounts.](CancelReferralCodeTransfer)*
    ///
    /// # Errors
    /// - The [`owner`](CancelReferralCodeTransfer::owner) must be a signer.
    /// - The [`store`](CancelReferralCodeTransfer::store) must be properly initialized.
    /// - The [`user`](CancelReferralCodeTransfer::user) account must be:
    ///   - Properly initialized
    ///   - Correspond to the `owner`
    /// - The [`referral_code`](CancelReferralCodeTransfer::referral_code) account must be:
    ///   - Properly initialized
    ///   - Owned by the `store`
    ///   - Correspond to the `owner`
    ///   - The next owner must not have been the `owner`
    pub fn cancel_referral_code_transfer(ctx: Context<CancelReferralCodeTransfer>) -> Result<()> {
        instructions::cancel_referral_code_transfer(ctx)
    }

    /// Accept referral code.
    ///
    /// # Accounts
    /// *[See the documentation for the accounts.](AcceptReferralCode)*
    ///
    /// # Errors
    /// - The [`next_owner`](AcceptReferralCode::next_owner) must be a signer.
    /// - The [`store`](AcceptReferralCode::store) must be properly initialized.
    /// - The [`user`](AcceptReferralCode::user) account must be:
    ///   - Properly initialized
    ///   - Different from the [`receiver_user`](AcceptReferralCode::receiver_user)
    /// - The [`referral_code`](AcceptReferralCode::referral_code) account must be:
    ///   - Properly initialized
    ///   - Owned by the `store`
    ///   - Correspond to the owner of the `user`
    ///   - Have the next owner be the `next_owner`
    /// - The [`receiver_user`](AcceptReferralCode::receiver_user) account must be:
    ///   - Properly initialized
    ///   - Not have an associated referral code
    ///   - Correspond to the `next_owner`
    pub fn accept_referral_code(ctx: Context<AcceptReferralCode>) -> Result<()> {
        instructions::accept_referral_code(ctx)
    }

    /// Claim builder fees.
    ///
    /// Restricted to the User Account's owner. Idempotent: a claim vault
    /// with a zero balance is an explicit no-op, so this may be called
    /// freely once the vault exists. Not gated by the `BuilderFee`
    /// feature flag.
    ///
    /// # Accounts
    /// *[See the documentation for the accounts.](ClaimBuilderFees)*
    ///
    /// # Errors
    /// - The [`owner`](ClaimBuilderFees::owner) must be a signer and must
    ///   match the owner recorded on [`user_account`](ClaimBuilderFees::user_account).
    /// - The [`user_account`](ClaimBuilderFees::user_account) must be properly
    ///   initialized and belong to the `store`.
    /// - The [`claim_vault`](ClaimBuilderFees::claim_vault) must already exist and
    ///   be the associated token account of the [`token_mint`](ClaimBuilderFees::token_mint)
    ///   owned by `user_account`.
    /// - The [`destination`](ClaimBuilderFees::destination) must be a token account
    ///   for `token_mint`.
    /// - The [`user_token_controller`](ClaimBuilderFees::user_token_controller) must
    ///   match its PDA derivation from `user_account` and `token_mint`; no other
    ///   validation is performed on it.
    pub fn claim_builder_fees(ctx: Context<ClaimBuilderFees>) -> Result<()> {
        ClaimBuilderFees::invoke(ctx)
    }

    // ===========================================
    //                GLV Operations
    // ===========================================

    /// Initialize a GLV token and the corresponding GLV account.
    ///
    /// # Accounts
    /// *[See the documentation for the accounts.](InitializeGlv)*
    ///
    /// # Arguments
    /// - `index`: The index of the GLV. Used to derive the GLV token address.
    /// - `length`: The number of markets to include in the GLV.
    ///
    /// # Errors
    /// - The [`authority`](InitializeGlv::authority) must be a signer and have
    ///   MARKET_KEEPER role in the store.
    /// - The [`store`](InitializeGlv::store) must be properly initialized.
    /// - The [`glv_token`](InitializeGlv::glv_token) must be:
    ///   - Uninitialized
    ///   - Address must be PDA derived from [`GLV_TOKEN_SEED`](crate::states::Glv::GLV_TOKEN_SEED),
    ///     [`store`] and `index`
    /// - The [`glv`](InitializeGlv::glv) must be:
    ///   - Uninitialized
    ///   - Address must be PDA derived from the SEED of [`Glv`](states::Glv) and the address of the
    ///     [`glv_token`](InitializeGlv::glv_token)
    /// - The remaining required accounts are documented in [`InitializeGlv`].
    /// - The `length` must be:
    ///   - Greater than 0
    ///   - Less than or equal to [`Glv::MAX_ALLOWED_NUMBER_OF_MARKETS`](crate::states::Glv::MAX_ALLOWED_NUMBER_OF_MARKETS)
    #[access_control(internal::Authenticate::only_market_keeper(&ctx))]
    pub fn initialize_glv<'info>(
        ctx: Context<'_, '_, 'info, 'info, InitializeGlv<'info>>,
        index: u16,
        length: u16,
    ) -> Result<()> {
        instructions::unchecked_initialize_glv(ctx, index, length as usize)
    }

    /// Update the config of a market in the given GLV.
    ///
    /// # Accounts
    /// *[See the documentation for the accounts.](UpdateGlvMarketConfig)*
    ///
    /// # Arguments
    /// - `max_amount`: The maximum amount of the market token that can be stored in the GLV.
    /// - `max_value`: The maximum value of the market token that can be stored in the GLV.
    ///
    /// # Errors
    /// - The [`authority`](UpdateGlvMarketConfig::authority) must be:
    ///   - A signer
    ///   - Have MARKET_KEEPER role in the `store`
    /// - The [`store`](UpdateGlvMarketConfig::store) must be properly initialized.
    /// - The [`glv`](UpdateGlvMarketConfig::glv) must be:
    ///   - Properly initialized
    ///   - Owned by the `store`
    ///   - Have the market token in its list of market tokens
    /// - The [`market_token`](UpdateGlvMarketConfig::market_token) must be:
    ///   - Properly initialized
    ///   - Owned by the `store`
    /// - At least one of `max_amount` or `max_value` must be provided
    #[access_control(internal::Authenticate::only_market_keeper(&ctx))]
    pub fn update_glv_market_config(
        ctx: Context<UpdateGlvMarketConfig>,
        max_amount: Option<u64>,
        max_value: Option<u128>,
    ) -> Result<()> {
        instructions::unchecked_update_glv_market_config(ctx, max_amount, max_value)
    }

    /// Toggle the given flag of a market in the given GLV.
    ///
    /// # Accounts
    /// *[See the documentation for the accounts.](UpdateGlvMarketConfig)*
    ///
    /// # Arguments
    /// - `flag`: The flag to toggle.
    /// - `enable`: The value to toggle to.
    ///
    /// # Errors
    /// - The [`authority`](UpdateGlvMarketConfig::authority) must be:
    ///   - A signer
    ///   - Have MARKET_KEEPER role in the `store`
    /// - The [`store`](UpdateGlvMarketConfig::store) must be properly initialized.
    /// - The [`glv`](UpdateGlvMarketConfig::glv) must be:
    ///   - Properly initialized
    ///   - Owned by the `store`
    ///   - Have the market token in its list of market tokens
    /// - The [`market_token`](UpdateGlvMarketConfig::market_token) must be:
    ///   - Properly initialized
    ///   - Owned by the `store`
    /// - `flag` must be defined in [`GlvMarketFlag`](crate::states::glv::GlvMarketFlag).
    #[access_control(internal::Authenticate::only_market_keeper(&ctx))]
    pub fn toggle_glv_market_flag(
        ctx: Context<UpdateGlvMarketConfig>,
        flag: String,
        enable: bool,
    ) -> Result<()> {
        instructions::unchecked_toggle_glv_market_flag(ctx, &flag, enable)
    }

    /// Update GLV config.
    ///
    /// # Accounts
    /// *[See the documentation for the accounts.](UpdateGlvConfig)*
    ///
    /// # Arguments
    /// - `params`: The update of the config.
    ///
    /// # Errors
    /// - The [`authority`](UpdateGlvConfig::authority) must be:
    ///   - A signer
    ///   - Have MARKET_KEEPER role in the `store`
    /// - The [`store`](UpdateGlvConfig::store) must be properly initialized.
    /// - The [`glv`](UpdateGlvConfig::glv) must be:
    ///   - Properly initialized
    ///   - Owned by the `store`
    /// - The `params` must not non-empty.
    #[access_control(internal::Authenticate::only_market_keeper(&ctx))]
    pub fn update_glv_config(ctx: Context<UpdateGlvConfig>, params: UpdateGlvParams) -> Result<()> {
        instructions::unchecked_update_glv(ctx, &params)
    }

    /// Insert a new market to the GLV.
    ///
    /// # Accounts
    /// *[See the documentation for the accounts.](InsertGlvMarket)*
    ///
    /// # Errors
    /// - The [`authority`](InsertGlvMarket::authority) must be:
    ///   - A signer
    ///   - Have MARKET_KEEPER role in the `store`
    /// - The [`store`](InsertGlvMarket::store) must be properly initialized.
    /// - The [`glv`](InsertGlvMarket::glv) must be:
    ///   - Properly initialized
    ///   - Owned by the `store`
    /// - The [`market_token`](InsertGlvMarket::market_token) must be:
    ///   - A initialized SPL Token / Token-2022 mint
    ///   - Have `store` as its mint authority
    ///   - Not already contains in the given GLV
    /// - The [`market`](InsertGlvMarket::market) must be:
    ///   - A initialized market account owned by the `store`
    ///   - Must have `market_token` as its market token
    ///   - Must have the same long token and short token as the GLV
    ///   - Must be enabled
    /// - The [`vault`](InsertGlvMarket::vault) must be either:
    ///   - The ATA of `market_token` owned by `glv`, or
    ///   - Uninitialized ATA account of `market_token` owned by `glv`
    #[access_control(internal::Authenticate::only_market_keeper(&ctx))]
    pub fn insert_glv_market(ctx: Context<InsertGlvMarket>) -> Result<()> {
        instructions::unchecked_insert_glv_market(ctx)
    }

    /// Remove a market from the GLV.
    ///
    /// # Accounts
    /// *[See the documentation for the accounts.](RemoveGlvMarket)*
    ///
    /// # Errors
    /// - The [`authority`](RemoveGlvMarket::authority) must:
    ///   - Be a signer
    ///   - Have MARKET_KEEPER role in the `store`
    /// - The [`store`](RemoveGlvMarket::store) must be properly initialized.
    /// - The [`glv`](RemoveGlvMarket::glv) must be:
    ///   - Properly initialized
    ///   - Owned by the `store`
    /// - The [`market_token`](RemoveGlvMarket::market_token) must be:
    ///   - A initialized SPL Token mint
    ///   - Having `store` as its mint authority
    ///   - Contained in the given GLV
    ///   - Having deposit disabled in the GLV
    /// - The [`vault`](RemoveGlvMarket::vault) must be:
    ///   - The ATA of `market_token` owned by `glv`
    ///   - Having no remaining balance
    #[access_control(internal::Authenticate::only_market_keeper(&ctx))]
    pub fn remove_glv_market(ctx: Context<RemoveGlvMarket>) -> Result<()> {
        instructions::unchecked_remove_glv_market(ctx)
    }

    /// Create GLV deposit.
    ///
    /// # Accounts
    /// *[See the documentation for the accounts.](CreateGlvDeposit)*
    ///
    /// # Arguments
    /// - `nonce`: A 32-byte used to derive the address of the GLV deposit.
    /// - `params`: The parameters for creating the GLV deposit.
    ///
    /// # Errors
    /// - The [`owner`](CreateGlvDeposit::owner) must be a signer and have sufficient balance
    ///   for the execution fee and rent.
    /// - The [`store`](CreateGlvDeposit::store) must be properly initialized.
    /// - The [`market`](CreateGlvDeposit::market) must be:
    ///   - Properly initialized
    ///   - Owned by the `store`
    ///   - Listed in the [`glv`](CreateGlvDeposit::glv)
    /// - The [`glv`](CreateGlvDeposit::glv) must be:
    ///   - Properly initialized
    ///   - Owned by the `store`
    /// - The [`glv_deposit`](CreateGlvDeposit::glv_deposit) must be:
    ///   - Uninitialized
    ///   - Address must be PDA derived from the SEED of [`GlvDeposit`](states::GlvDeposit),
    ///     [`store`](CreateGlvDeposit::store), [`owner`](CreateGlvDeposit::owner) and `nonce`
    /// - The [`glv_token`](CreateGlvDeposit::glv_token) must be:
    ///   - Properly initialized
    ///   - Correspond to the provided [`glv`](CreateGlvDeposit::glv)
    /// - The [`market_token`](CreateGlvDeposit::market_token) must be:
    ///   - Properly initialized
    ///   - Correspond to the provided [`market`](CreateGlvDeposit::market)
    /// - Token mint account requirements:
    ///   - [`initial_long_token`](CreateGlvDeposit::initial_long_token) must be provided if initial long amount > 0
    ///   - [`initial_short_token`](CreateGlvDeposit::initial_short_token) must be provided if initial short amount > 0
    /// - Escrow account requirements:
    ///   - [`glv_token_escrow`](CreateGlvDeposit::glv_token_escrow) must be:
    ///     - Owned by the [`glv_deposit`](CreateGlvDeposit::glv_deposit)
    ///   - Other escrow accounts must be:
    ///     - Provided for any non-zero initial token amounts
    ///     - Owned by the [`glv_deposit`](CreateGlvDeposit::glv_deposit)
    /// - Source token account requirements:
    ///   - Must be provided for any non-zero initial token amounts
    ///   - Must have sufficient balance
    ///   - Must have the `owner` as its authority
    /// - All token programs must match their corresponding token accounts
    pub fn create_glv_deposit<'info>(
        mut ctx: Context<'_, '_, 'info, 'info, CreateGlvDeposit<'info>>,
        nonce: [u8; 32],
        params: CreateGlvDepositParams,
    ) -> Result<()> {
        internal::Create::create(&mut ctx, &nonce, &params, None)
    }

    /// Close GLV deposit.
    ///
    /// # Accounts
    /// *[See the documentation for the accounts.](CloseGlvDeposit)*
    ///
    /// # Arguments
    /// - `reason`: The reason for closing the GLV deposit.
    ///
    /// # Errors
    /// - The [`executor`](CloseGlvDeposit::executor) must be a signer, and must be
    ///   either the owner of the GLV deposit or a `ORDER_KEEPER` in the store
    /// - The [`store`](CloseGlvDeposit::store) must be properly initialized
    /// - The [`owner`](CloseGlvDeposit::owner) must be the owner of the GLV deposit
    /// - The [`glv_deposit`](CloseGlvDeposit::glv_deposit) must be:
    ///   - Properly initialized
    ///   - Owned by the `owner` and `store`
    ///   - In cancelled or executed state if the `executor` is not the `owner`
    /// - Token mint account requirements:
    ///   - All tokens must be valid and recorded in the [`glv_deposit`](CloseGlvDeposit::glv_deposit)
    ///   - [`initial_long_token`](CloseGlvDeposit::initial_long_token) must be provided if initial long amount > 0
    ///   - [`initial_short_token`](CloseGlvDeposit::initial_short_token) must be provided if initial short amount > 0
    /// - Escrow account requirements:
    ///   - Must correspond to their respective tokens
    ///   - Must be owned by the [`glv_deposit`](CloseGlvDeposit::glv_deposit)
    ///   - Must be recorded in the [`glv_deposit`](CloseGlvDeposit::glv_deposit)
    /// - The addresses of the ATAs must be valid associated token addresses derived from the respective tokens and `owner`
    /// - All token programs must match their corresponding token accounts
    pub fn close_glv_deposit<'info>(
        ctx: Context<'_, '_, 'info, 'info, CloseGlvDeposit<'info>>,
        reason: String,
    ) -> Result<()> {
        internal::Close::close(&ctx, &reason)
    }

    /// Execute GLV deposit.
    ///
    /// # Accounts
    /// *[See the documentation for the accounts.](ExecuteGlvDeposit)*
    ///
    /// # Arguments
    /// - `execution_lamports`: The execution fee claimed to be used by the keeper.
    /// - `throw_on_execution_error`: Whether to throw an error if the execution fails.
    ///
    /// # Errors
    /// - The [`authority`](ExecuteGlvDeposit::authority) must be a signer and have `ORDER_KEEPER` role in the `store`
    /// - The [`store`](ExecuteGlvDeposit::store) must be properly initialized
    /// - The [`token_map`](ExecuteGlvDeposit::token_map) must be:
    ///   - Properly initialized
    ///   - Authorized by the `store`
    /// - The [`oracle`](ExecuteGlvDeposit::oracle) must be:
    ///   - Cleared
    ///   - Owned by the `store`
    /// - The [`glv`](ExecuteGlvDeposit::glv) must be:
    ///   - Properly initialized
    ///   - Owned by the `store`
    ///   - Match the expected GLV of the deposit
    /// - The [`market`](ExecuteGlvDeposit::market) must be:
    ///   - Properly initialized
    ///   - Owned by the `store`
    ///   - Match the expected market of the deposit
    ///   - Must be enabled and listed in the [`glv`](ExecuteGlvDeposit::glv)
    /// - The [`glv_deposit`](ExecuteGlvDeposit::glv_deposit) must be:
    ///   - Properly initialized
    ///   - Owned by the `store`
    ///   - In pending state
    /// - Token requirements:
    ///   - All tokens must be valid and recorded in the [`glv_deposit`](ExecuteGlvDeposit::glv_deposit)
    ///   - [`glv_token`](ExecuteGlvDeposit::glv_token) must be the GLV token of the [`glv`](ExecuteGlvDeposit::glv)
    ///   - [`market_token`](ExecuteGlvDeposit::market_token) must be the market token of the [`market`](ExecuteGlvDeposit::market)
    /// - Vault requirements:
    ///   - [`initial_long_token_vault`](ExecuteGlvDeposit::initial_long_token_vault) must be:
    ///     - The market vault for the initial long token
    ///     - Owned by the `store`
    ///   - [`initial_short_token_vault`](ExecuteGlvDeposit::initial_short_token_vault) must be:
    ///     - The market vault for the initial short token
    ///     - Owned by the `store`
    ///   - [`market_token_vault`](ExecuteGlvDeposit::market_token_vault) must be:
    ///     - The market token vault in the [`glv`](ExecuteGlvDeposit::glv)
    ///     - Owned by the [`glv`](ExecuteGlvDeposit::glv)
    /// - Escrow requirements:
    ///   - Must correspond to their respective tokens
    ///   - Must be owned by the [`glv_deposit`](ExecuteGlvDeposit::glv_deposit)
    ///   - Must be recorded in the [`glv_deposit`](ExecuteGlvDeposit::glv_deposit)
    /// - All token programs must match their corresponding token accounts
    /// - All remaining accounts must be valid per [`ExecuteGlvDeposit`] documentation
    /// - Returns error if execution fails and `throw_on_execution_error` is `true`
    #[access_control(internal::Authenticate::only_order_keeper(&ctx))]
    pub fn execute_glv_deposit<'info>(
        ctx: Context<'_, '_, 'info, 'info, ExecuteGlvDeposit<'info>>,
        execution_lamports: u64,
        throw_on_execution_error: bool,
    ) -> Result<()> {
        instructions::unchecked_execute_glv_deposit(
            ctx,
            execution_lamports,
            throw_on_execution_error,
        )
    }

    /// Create GLV withdrawal.
    ///
    /// # Accounts
    /// *[See the documentation for the accounts.](CreateGlvWithdrawal)*
    ///
    /// # Arguments
    /// - `nonce`: A 32-byte used to derive the address of the GLV withdrawal.
    /// - `params`: The parameters for creating the GLV withdrawal.
    ///
    /// # Errors
    /// - The [`owner`](CreateGlvWithdrawal::owner) must be a signer and have sufficient balance
    ///   for the execution fee and rent.
    /// - The [`store`](CreateGlvWithdrawal::store) must be properly initialized.
    /// - The [`market`](CreateGlvWithdrawal::market) must be:
    ///   - Properly initialized
    ///   - Enabled
    ///   - Owned by the `store`
    ///   - One of the markets in the [`glv`](CreateGlvWithdrawal::glv)
    /// - The [`glv`](CreateGlvWithdrawal::glv) must be:
    ///   - Properly initialized
    ///   - Owned by the `store`
    /// - The [`glv_withdrawal`](CreateGlvWithdrawal::glv_withdrawal) must be:
    ///   - Uninitialized
    ///   - A PDA derived from:
    ///     - the SEED of [`GlvWithdrawal`](states::GlvWithdrawal)
    ///     - [`store`](CreateGlvWithdrawal::store)
    ///     - [`owner`](CreateGlvWithdrawal::owner)
    ///     - `nonce`
    /// - Token requirements:
    ///   - [`glv_token`](CreateGlvWithdrawal::glv_token) must be:
    ///     - Properly initialized
    ///     - The GLV token of the [`glv`](CreateGlvWithdrawal::glv)
    ///   - [`market_token`](CreateGlvWithdrawal::market_token) must be:
    ///     - Properly initialized
    ///     - The market token of the [`market`](CreateGlvWithdrawal::market)
    ///   - All other tokens must be properly initialized
    /// - Source requirements:
    ///   - [`glv_token_source`](CreateGlvWithdrawal::glv_token_source) must be:
    ///     - Properly initialized
    ///     - A GLV token account
    ///     - Have sufficient balance
    ///     - Have the `owner` as its authority
    /// - Escrow requirements:
    ///   - Must correspond to their respective tokens
    ///   - Must be owned by the [`glv_withdrawal`](CreateGlvWithdrawal::glv_withdrawal)
    /// - All token programs must match their corresponding token accounts
    pub fn create_glv_withdrawal<'info>(
        mut ctx: Context<'_, '_, 'info, 'info, CreateGlvWithdrawal<'info>>,
        nonce: [u8; 32],
        params: CreateGlvWithdrawalParams,
    ) -> Result<()> {
        internal::Create::create(&mut ctx, &nonce, &params, None)
    }

    /// Close GLV withdrawal.
    ///
    /// # Accounts
    /// *[See the documentation for the accounts.](CloseGlvWithdrawal)*
    ///
    /// # Arguments
    /// - `reason`: The reason for closing the GLV withdrawal.
    ///
    /// # Errors
    /// - The [`executor`](CloseGlvWithdrawal::executor) must be:
    ///   - A signer
    ///   - Either:
    ///     - The owner of the [`glv_withdrawal`](CloseGlvWithdrawal::glv_withdrawal)
    ///     - A `ORDER_KEEPER` in the `store`
    /// - The [`store`](CloseGlvWithdrawal::store) must be properly initialized
    /// - The [`owner`](CloseGlvWithdrawal::owner) must be the owner of the [`glv_withdrawal`](CloseGlvWithdrawal::glv_withdrawal)
    /// - The [`glv_withdrawal`](CloseGlvWithdrawal::glv_withdrawal) must be:
    ///   - Properly initialized
    ///   - Owned by the `owner`
    ///   - Owned by the `store`
    /// - Token requirements:
    ///   - All tokens must be valid and recorded in the [`glv_withdrawal`](CloseGlvWithdrawal::glv_withdrawal)
    /// - Escrow requirements:
    ///   - Must correspond to their respective tokens
    ///   - Must be owned by the [`glv_withdrawal`](CloseGlvWithdrawal::glv_withdrawal)
    ///   - Must be recorded in the [`glv_withdrawal`](CloseGlvWithdrawal::glv_withdrawal)
    /// - The addresses of the ATAs must be valid associated token addresses derived from the respective tokens and `owner`
    /// - All token programs must match their corresponding token accounts
    /// - If the `executor` is not the `owner`, the [`glv_withdrawal`](CloseGlvWithdrawal::glv_withdrawal) must be either cancelled or executed.
    pub fn close_glv_withdrawal<'info>(
        ctx: Context<'_, '_, 'info, 'info, CloseGlvWithdrawal<'info>>,
        reason: String,
    ) -> Result<()> {
        internal::Close::close(&ctx, &reason)
    }

    /// Execute GLV withdrawal.
    ///
    /// # Accounts
    /// *[See the documentation for the accounts.](ExecuteGlvWithdrawal)*
    ///
    /// # Arguments
    /// - `execution_lamports`: The execution fee claimed to be used by the keeper.
    /// - `throw_on_execution_error`: Whether to throw an error if the execution fails.
    ///
    /// # Errors
    /// - The [`authority`](ExecuteGlvWithdrawal::authority) must be:
    ///   - A signer
    ///   - A `ORDER_KEEPER` in the `store`
    /// - The [`store`](ExecuteGlvWithdrawal::store) must be properly initialized
    /// - The [`token_map`](ExecuteGlvWithdrawal::token_map) must be:
    ///   - Properly initialized
    ///   - Authorized by the `store`
    /// - The [`oracle`](ExecuteGlvWithdrawal::oracle) must be:
    ///   - Cleared
    ///   - Owned by the `store`
    /// - The [`glv`](ExecuteGlvWithdrawal::glv) must be:
    ///   - Properly initialized
    ///   - Owned by the `store`
    ///   - The expected GLV of the withdrawal
    /// - The [`market`](ExecuteGlvWithdrawal::market) must be:
    ///   - Properly initialized
    ///   - Owned by the `store`
    ///   - The expected market of the withdrawal
    ///   - Must be enabled and listed in the [`glv`](ExecuteGlvWithdrawal::glv)
    /// - The [`glv_withdrawal`](ExecuteGlvWithdrawal::glv_withdrawal) must be:
    ///   - Properly initialized
    ///   - Owned by the `store`
    ///   - In pending state
    /// - Token requirements:
    ///   - All tokens must be valid and recorded in the withdrawal
    ///   - [`glv_token`](ExecuteGlvWithdrawal::glv_token) must be the GLV token of the GLV
    ///   - [`market_token`](ExecuteGlvWithdrawal::market_token) must be the market token of the market
    /// - Escrow requirements:
    ///   - Escrow accounts must correspond to their tokens
    ///   - Escrow accounts must be owned by the [`glv_withdrawal`](ExecuteGlvWithdrawal::glv_withdrawal)
    ///   - Escrow accounts must be recorded in the [`glv_withdrawal`](ExecuteGlvWithdrawal::glv_withdrawal)
    /// - Vault requirements:
    ///   - [`market_token_withdrawal_vault`](ExecuteGlvWithdrawal::market_token_withdrawal_vault) must be the market vault for market token, owned by the `store`
    ///   - [`final_long_token_vault`](ExecuteGlvWithdrawal::final_long_token_vault) must be the market vault for final long token, owned by the `store`
    ///   - [`final_short_token_vault`](ExecuteGlvWithdrawal::final_short_token_vault) must be the market vault for final short token, owned by the `store`
    ///   - [`market_token_vault`](ExecuteGlvWithdrawal::market_token_vault) must be the GLV's market token vault, owned by the [`glv`](ExecuteGlvWithdrawal::glv)
    /// - All token programs must match their corresponding token accounts
    /// - All remaining accounts must be valid per [`ExecuteGlvWithdrawal`] documentation
    /// - Returns error if execution fails and `throw_on_execution_error` is `true`
    #[access_control(internal::Authenticate::only_order_keeper(&ctx))]
    pub fn execute_glv_withdrawal<'info>(
        ctx: Context<'_, '_, 'info, 'info, ExecuteGlvWithdrawal<'info>>,
        execution_lamports: u64,
        throw_on_execution_error: bool,
    ) -> Result<()> {
        instructions::unchecked_execute_glv_withdrawal(
            ctx,
            execution_lamports,
            throw_on_execution_error,
        )
    }

    /// Create GLV shift.
    ///
    /// # Accounts
    /// *[See the documentation for the accounts.](CreateGlvShift)*
    ///
    /// # Arguments
    /// - `nonce`: A 32-byte used to derive the address of the GLV shift.
    /// - `params`: The parameters for creating the GLV shift.
    ///
    /// # Errors
    /// - The [`authority`](CreateGlvShift::authority) must be:
    ///   - A signer
    ///   - A `ORDER_KEEPER` in the `store`
    /// - The [`store`](CreateGlvShift::store) must be properly initialized
    /// - The [`glv`](CreateGlvShift::glv) must be:
    ///   - Properly initialized
    ///   - Owned by the `store`
    /// - Market requirements:
    ///   - [`from_market`](CreateGlvShift::from_market) must be:
    ///     - Enabled
    ///     - Owned by the `store`
    ///     - One of the markets in the [`glv`](CreateGlvShift::glv)
    ///   - [`to_market`](CreateGlvShift::to_market) must be:
    ///     - Enabled
    ///     - Owned by the `store`
    ///     - One of the markets in the [`glv`](CreateGlvShift::glv)
    ///     - Different from `from_market`
    /// - The [`glv_shift`](CreateGlvShift::glv_shift) must be:
    ///   - Uninitialized
    ///   - PDA derived from the SEED of [`GlvShift`](states::GlvShift), `store`, `glv`, and `nonce`
    /// - Token requirements:
    ///   - [`from_market_token`](CreateGlvShift::from_market_token) must be:
    ///     - Properly initialized
    ///     - The market token of `from_market`
    ///   - [`to_market_token`](CreateGlvShift::to_market_token) must be:
    ///     - Properly initialized
    ///     - The market token of `to_market`
    /// - Vault requirements:
    ///   - [`from_market_token_vault`](CreateGlvShift::from_market_token_vault) must be:
    ///     - The market token vault for `from_market_token` in the [`glv`](CreateGlvShift::glv)
    ///     - Owned by the [`glv`](CreateGlvShift::glv)
    ///   - [`to_market_token_vault`](CreateGlvShift::to_market_token_vault) must be:
    ///     - The market token vault for `to_market_token` in the [`glv`](CreateGlvShift::glv)
    ///     - Owned by the [`glv`](CreateGlvShift::glv)
    #[access_control(internal::Authenticate::only_order_keeper(&ctx))]
    pub fn create_glv_shift<'info>(
        mut ctx: Context<'_, '_, 'info, 'info, CreateGlvShift<'info>>,
        nonce: [u8; 32],
        params: CreateShiftParams,
    ) -> Result<()> {
        internal::Create::create(&mut ctx, &nonce, &params, None)
    }

    /// Close a GLV shift.
    ///
    /// # Accounts
    /// *[See the documentation for the accounts.](CloseGlvShift)*
    ///
    /// # Arguments
    /// - `reason`: The reason for closing the GLV shift.
    ///
    /// # Errors
    /// - The [`authority`](CloseGlvShift::authority) must be:
    ///   - A signer
    ///   - A `ORDER_KEEPER` in the `store`
    /// - The [`funder`](CloseGlvShift::funder) must be the funder of the [`glv`](CloseGlvShift::glv).
    /// - The [`store`](CloseGlvShift::store) must be properly initialized.
    /// - The [`glv`](CloseGlvShift::glv) must be:
    ///   - Properly initialized
    ///   - Owned by the `store`
    ///   - The expected GLV of the GLV shift
    /// - The [`glv_shift`](CloseGlvShift::glv_shift) must be:
    ///   - Properly initialized
    ///   - Owned by the `store`
    /// - Token requirements:
    ///   - [`from_market_token`](CloseGlvShift::from_market_token) must be:
    ///     - Recorded in the GLV shift
    ///   - [`to_market_token`](CloseGlvShift::to_market_token) must be:
    ///     - Recorded in the GLV shift
    #[access_control(internal::Authenticate::only_order_keeper(&ctx))]
    pub fn close_glv_shift<'info>(
        ctx: Context<'_, '_, 'info, 'info, CloseGlvShift<'info>>,
        reason: String,
    ) -> Result<()> {
        internal::Close::close(&ctx, &reason)
    }

    /// Execute GLV shift.
    ///
    /// # Accounts
    /// *[See the documentation for the accounts.](ExecuteGlvShift)*
    ///
    /// # Arguments
    /// - `execution_lamports`: The execution fee claimed to be used by the keeper.
    /// - `throw_on_execution_error`: Whether to throw an error if execution fails.
    ///
    /// # Errors
    /// - The [`authority`](ExecuteGlvShift::authority) must be:
    ///   - A signer
    ///   - A `ORDER_KEEPER` in the `store`
    /// - The [`store`](ExecuteGlvShift::store) must be properly initialized
    /// - The [`token_map`](ExecuteGlvShift::token_map) must be:
    ///   - Properly initialized
    ///   - Authorized by the `store`
    /// - The [`oracle`](ExecuteGlvShift::oracle) must be:
    ///   - Cleared
    ///   - Owned by the `store`
    /// - The [`glv`](ExecuteGlvShift::glv) must be:
    ///   - Properly initialized
    ///   - Owned by the `store`
    ///   - The expected GLV of the GLV shift
    /// - The [`from_market`](ExecuteGlvShift::from_market) must be:
    ///   - Enabled
    ///   - Owned by the `store`
    ///   - One of the markets in the [`glv`](ExecuteGlvShift::glv)
    /// - The [`to_market`](ExecuteGlvShift::to_market) must be:
    ///   - Enabled
    ///   - Owned by the `store`
    ///   - One of the markets in the [`glv`](ExecuteGlvShift::glv)
    /// - The [`glv_shift`](ExecuteGlvShift::glv_shift) must be:
    ///   - Properly initialized
    ///   - Owned by the `store`
    /// - Token requirements:
    ///   - [`from_market_token`](ExecuteGlvShift::from_market_token) must be:
    ///     - The market token of `from_market`
    ///     - Recorded in the GLV shift
    ///   - [`to_market_token`](ExecuteGlvShift::to_market_token) must be:
    ///     - The market token of `to_market`
    ///     - Recorded in the GLV shift
    /// - Vault requirements:
    ///   - [`from_market_token_glv_vault`](ExecuteGlvShift::from_market_token_glv_vault) must be:
    ///     - The escrow account for `from_market_token` in the GLV
    ///     - Owned by the [`glv`](ExecuteGlvShift::glv)
    ///   - [`to_market_token_glv_vault`](ExecuteGlvShift::to_market_token_glv_vault) must be:
    ///     - The escrow account for `to_market_token` in the GLV
    ///     - Owned by the [`glv`](ExecuteGlvShift::glv)
    ///   - [`from_market_token_vault`](ExecuteGlvShift::from_market_token_vault) must be:
    ///     - The market vault for `from_market_token`
    ///     - Owned by the `store`
    /// - Token programs must match the tokens and token accounts
    /// - The remaining accounts must be valid (see [`ExecuteGlvShift`] docs)
    /// - Returns error if execution fails and `throw_on_execution_error` is `true`
    #[access_control(internal::Authenticate::only_order_keeper(&ctx))]
    pub fn execute_glv_shift<'info>(
        ctx: Context<'_, '_, 'info, 'info, ExecuteGlvShift<'info>>,
        execution_lamports: u64,
        throw_on_execution_error: bool,
    ) -> Result<()> {
        instructions::unchecked_execute_glv_shift(ctx, execution_lamports, throw_on_execution_error)
    }

    /// Returns the USD value for the given GLV token amount.
    ///
    /// # Accounts
    /// [*See the documentation for the accounts.*](GetGlvTokenValue)
    ///
    /// # Arguments
    /// - `amount`: Amount of the market tokens to evaluate.
    /// - `maximize`: If true, uses the maximum possible values in calculations.
    ///   If false, uses minimum values.
    /// - `max_age`: Maximum allowed age of the earliest oracle timestamp.
    /// - `emit_event`: Whether to emit a [`GlvTokenValue`](crate::events::GlvTokenValue) event.
    ///
    /// # Errors
    /// - The [`authority`](GetGlvTokenValue::authority) must be a signer and be the authority of the `oracle` buffer account.
    /// - The [`store`](GetGlvTokenValue::store) must be initialized.
    /// - The [`token_map`](GetGlvTokenValue::token_map) must be initialized and authorized by the `store`.
    /// - The [`oracle`](GetGlvTokenValue::oracle) must be initialized and cleared.
    /// - The [`glv`](GetGlvTokenValue::glv) must be initialized and enabled.
    /// - The [`glv_token`](GetGlvTokenValue::glv_token) must be associated with the `glv`.
    /// - The remaining accounts must be valid according to the accounts documentation.
    ///   in the required order.
    /// - The earliest oracle timestamp must be within `max_age`.
    /// - Any calculation errors.
    pub fn get_glv_token_value<'info>(
        ctx: Context<'_, '_, 'info, 'info, GetGlvTokenValue<'info>>,
        amount: u64,
        maximize: bool,
        max_age: u32,
        emit_event: bool,
    ) -> Result<u128> {
        GetGlvTokenValue::invoke(ctx, amount, maximize, max_age, emit_event)
    }

    // ===========================================
    //             Other Instructions
    // ===========================================

    #[access_control(internal::Authenticate::only_migration_keeper(&ctx))]
    pub fn migrate_referral_code<'info>(
        ctx: Context<'_, '_, 'info, 'info, MigrateReferralCode<'info>>,
    ) -> Result<()> {
        cfg_if::cfg_if! {
            if #[cfg(feature = "migration")] {
                instructions::unchecked_migrate_referral_code(ctx)
            } else {
                err!(CoreError::Unimplemented)
            }
        }
    }

    /// Initialize the [`CallbackAuthority`](crate::states::callback::CallbackAuthority) account.
    pub fn initialize_callback_authority(ctx: Context<InitializeCallbackAuthority>) -> Result<()> {
        InitializeCallbackAuthority::invoke(ctx)
    }

    /// Close an unused [`VirtualInventory`](crate::states::market::virtual_inventory::VirtualInventory) account.
    #[access_control(internal::Authenticate::only_market_keeper(&ctx))]
    pub fn close_virtual_inventory(ctx: Context<CloseVirtualInventory>) -> Result<()> {
        CloseVirtualInventory::invoke_unchecked(ctx)
    }

    /// Disable a [`VirtualInventory`](crate::states::market::virtual_inventory::VirtualInventory) account.
    #[access_control(internal::Authenticate::only_market_keeper(&ctx))]
    pub fn disable_virtual_inventory(ctx: Context<DisableVirtualInventory>) -> Result<()> {
        DisableVirtualInventory::invoke_unchecked(ctx)
    }

    /// Leave a disabled [`VirtualInventory`](crate::states::market::virtual_inventory::VirtualInventory) account.
    #[access_control(internal::Authenticate::only_market_keeper(&ctx))]
    pub fn leave_disabled_virtual_inventory(
        ctx: Context<LeaveDisabledVirtualInventory>,
    ) -> Result<()> {
        LeaveDisabledVirtualInventory::invoke_unchecked(ctx)
    }

    /// Create [`VirtualInventory`](crate::states::market::virtual_inventory::VirtualInventory) account for swaps.
    #[access_control(internal::Authenticate::only_market_keeper(&ctx))]
    pub fn create_virtual_inventory_for_swaps(
        ctx: Context<CreateVirtualInventoryForSwaps>,
        index: u32,
        long_amount_decimals: u8,
        short_amount_decimals: u8,
    ) -> Result<()> {
        CreateVirtualInventoryForSwaps::invoke_unchecked(
            ctx,
            index,
            long_amount_decimals,
            short_amount_decimals,
        )
    }

    /// Join a [`VirtualInventory`](crate::states::market::virtual_inventory::VirtualInventory) account for swaps.
    #[access_control(internal::Authenticate::only_market_keeper(&ctx))]
    pub fn join_virtual_inventory_for_swaps(
        ctx: Context<JoinVirtualInventoryForSwaps>,
    ) -> Result<()> {
        JoinVirtualInventoryForSwaps::invoke_unchecked(ctx)
    }

    /// Leave a [`VirtualInventory`](crate::states::market::virtual_inventory::VirtualInventory) account for swaps.
    #[access_control(internal::Authenticate::only_market_keeper(&ctx))]
    pub fn leave_virtual_inventory_for_swaps(
        ctx: Context<LeaveVirtualInventoryForSwaps>,
    ) -> Result<()> {
        LeaveVirtualInventoryForSwaps::invoke_unchecked(ctx)
    }

    /// Create [`VirtualInventory`](crate::states::market::virtual_inventory::VirtualInventory) account for positions.
    #[access_control(internal::Authenticate::only_market_keeper(&ctx))]
    pub fn create_virtual_inventory_for_positions(
        ctx: Context<CreateVirtualInventoryForPositions>,
    ) -> Result<()> {
        CreateVirtualInventoryForPositions::invoke_unchecked(ctx)
    }

    /// Join a [`VirtualInventory`](crate::states::market::virtual_inventory::VirtualInventory) account for positions.
    #[access_control(internal::Authenticate::only_market_keeper(&ctx))]
    pub fn join_virtual_inventory_for_positions(
        ctx: Context<JoinOrLeaveVirtualInventoryForPositions>,
    ) -> Result<()> {
        JoinOrLeaveVirtualInventoryForPositions::invoke_join_unchecked(ctx)
    }

    /// Leave a [`VirtualInventory`](crate::states::market::virtual_inventory::VirtualInventory) account for positions.
    #[access_control(internal::Authenticate::only_market_keeper(&ctx))]
    pub fn leave_virtual_inventory_for_positions(
        ctx: Context<JoinOrLeaveVirtualInventoryForPositions>,
    ) -> Result<()> {
        JoinOrLeaveVirtualInventoryForPositions::invoke_leave_unchecked(ctx)
    }
}

/// Result type with [`CoreError`] as error type.
pub type CoreResult<T> = std::result::Result<T, CoreError>;

#[error_code]
pub enum CoreError {
    // ===========================================
    //                Common Errors
    // ===========================================
    /// Non-default store is not allowed.
    #[msg("non-default store is not allowed")]
    NonDefaultStore,
    /// Internal error.
    #[msg("internal error")]
    Internal,
    /// Unimplemented.
    #[msg("unimplemented")]
    Unimplemented,
    /// Not an Admin.
    #[msg("not an admin")]
    NotAnAdmin,
    /// Permission denied.
    #[msg("permission denied")]
    PermissionDenied,
    /// Feature disabled.
    #[msg("feature disabled")]
    FeatureDisabled,
    /// Model Error.
    #[msg("model")]
    Model,
    /// Invalid Argument.
    #[msg("invalid argument")]
    InvalidArgument,
    /// Preconditions are not met.
    #[msg("preconditions are not met")]
    PreconditionsAreNotMet,
    /// Not found.
    #[msg("not found")]
    NotFound,
    /// Exceed max length limit.
    #[msg("exceed max length limit")]
    ExceedMaxLengthLimit,
    /// Not enough space.
    #[msg("not enough space")]
    NotEnoughSpace,
    /// Token amount overflow.
    #[msg("token amount overflow")]
    TokenAmountOverflow,
    /// Value overflow.
    #[msg("value overflow")]
    ValueOverflow,
    /// Unknown Action State.
    #[msg("unknown action state")]
    UnknownActionState,
    /// Load account error.
    #[msg("load zero-copy account error")]
    LoadAccountError,
    /// Token account is not provided.
    #[msg("required token account is not provided")]
    TokenAccountNotProvided,
    /// Token mint is not provided.
    #[msg("required token mint is not provided")]
    TokenMintNotProvided,
    /// Token decimals mismatched.
    #[msg("token decimals mismatched")]
    TokenDecimalsMismatched,
    /// Market account is not provided.
    #[msg("market account is not provided")]
    MarketAccountIsNotProvided,
    /// Store Mismatched.
    #[msg("store mismatched")]
    StoreMismatched,
    /// Owner mismatched.
    #[msg("owner mismatched")]
    OwnerMismatched,
    /// Receiver mismatched.
    #[msg("receiver mismatched")]
    ReceiverMismatched,
    /// Rent Receiver mismatched.
    #[msg("rent receiver mismatched")]
    RentReceiverMismatched,
    /// Market mismatched.
    #[msg("market mismatched")]
    MarketMismatched,
    /// Market token mint mismatched.
    #[msg("market token mint mismatched")]
    MarketTokenMintMismatched,
    /// Mint account not provided.
    #[msg("mint account not provided")]
    MintAccountNotProvided,
    /// Market token account mismatched.
    #[msg("market token account mismatched")]
    MarketTokenAccountMismatched,
    /// Token mint mismatched.
    #[msg("token mint mismatched")]
    TokenMintMismatched,
    /// Token account mismatched.
    #[msg("token account mismatched")]
    TokenAccountMismatched,
    /// Not an ATA for the given token.
    #[msg("not an ATA for the given token")]
    NotAnATA,
    /// Not enough token amounts.
    #[msg("not enough token amount")]
    NotEnoughTokenAmount,
    /// Token amount exceeds limit.
    #[msg("token amount exceeds limit")]
    TokenAmountExceedsLimit,
    /// Unknown token.
    #[msg("unknown token")]
    UnknownToken,
    /// Not enough execution fee.
    #[msg("not enough execution fee")]
    NotEnoughExecutionFee,
    /// Invalid Swap Path length.
    #[msg("invalid swap path length")]
    InvalidSwapPathLength,
    /// Not enough swap markets in the path.
    #[msg("not enough swap markets in the path")]
    NotEnoughSwapMarkets,
    /// Invalid Swap Path.
    #[msg("invalid swap path")]
    InvalidSwapPath,
    /// Insufficient output amounts.
    #[msg("insufficient output amounts")]
    InsufficientOutputAmount,
    /// Store Outdated.
    #[msg("store outdated")]
    StoreOutdated,
    // ===========================================
    //                 Store Errors
    // ===========================================
    /// Invalid Store Config Key.
    #[msg("invalid store config key")]
    InvalidStoreConfigKey,
    // ===========================================
    //                Oracle Errors
    // ===========================================
    /// Invalid Provider Kind Index.
    #[msg("invalid provider kind index")]
    InvalidProviderKindIndex,
    /// Chainlink Program is required.
    #[msg("chainlink program is required")]
    ChainlinkProgramIsRequired,
    /// Not supported price provider for custom price feed.
    #[msg("this price provider is not supported to be used with custom price feed")]
    NotSupportedCustomPriceProvider,
    /// Not enough token feeds.
    #[msg("not enough token feeds")]
    NotEnoughTokenFeeds,
    /// Oracle timestamps are larger than required.
    #[msg("oracle timestamps are larger than required")]
    OracleTimestampsAreLargerThanRequired,
    /// Oracle timestamps are smaller than required.
    #[msg("oracle timestamps are smaller than required")]
    OracleTimestampsAreSmallerThanRequired,
    /// Invalid Oracle timestamps range.
    #[msg("invalid oracle timestamps range")]
    InvalidOracleTimestampsRange,
    /// Max oracle timestamps range exceeded.
    #[msg("max oracle timestamps range exceeded")]
    MaxOracleTimestampsRangeExceeded,
    /// Oracle not updated.
    #[msg("oracle not updated")]
    OracleNotUpdated,
    /// Max price age exceeded.
    #[msg("max price age exceeded")]
    MaxPriceAgeExceeded,
    /// Max price's timestamp exceeded.
    #[msg("max price timestamp exceeded")]
    MaxPriceTimestampExceeded,
    /// Negative price.
    #[msg("negative price is not supported")]
    NegativePriceIsNotSupported,
    /// Invalid Oracle slot.
    #[msg("invalid oracle slot")]
    InvalidOracleSlot,
    /// Missing oracle price.
    #[msg("missing oracle price")]
    MissingOraclePrice,
    /// Invalid Price feed price.
    #[msg("invalid price feed price")]
    InvalidPriceFeedPrice,
    /// Price Overflow.
    #[msg("price overflow")]
    PriceOverflow,
    /// Invalid price feed account.
    #[msg("invalid price feed account")]
    InvalidPriceFeedAccount,
    /// Price feed is not updated.
    #[msg("price feed is not updated")]
    PriceFeedNotUpdated,
    /// Prices are already set.
    #[msg("prices are already set")]
    PricesAreAlreadySet,
    /// Price is already set.
    #[msg("price is already set")]
    PriceIsAlreadySet,
    /// Token config is disabled.
    #[msg("token config is disabled")]
    TokenConfigDisabled,
    /// Synthetic token price is not allowed.
    #[msg("synthetic token price is not allowed")]
    SyntheticTokenPriceIsNotAllowed,
    /// Invalid Price Report.
    #[msg("invalid price report")]
    InvalidPriceReport,
    /// Market not opened.
    #[msg("market is not open")]
    MarketNotOpen,
    // ===========================================
    //                Deposit Errors
    // ===========================================
    /// Empty Deposit.
    #[msg("empty deposit")]
    EmptyDeposit,
    /// Invalid owner for the first deposit.
    #[msg("invalid owner for the first deposit")]
    InvalidReceiverForFirstDeposit,
    /// Not enough market token amount for the first deposit.
    #[msg("not enough market token amount for the first deposit")]
    NotEnoughMarketTokenAmountForFirstDeposit,
    /// Not enough GLV token amount for the first deposit.
    #[msg("not enough GLV token amount for the first deposit")]
    NotEnoughGlvTokenAmountForFirstDeposit,
    // ===========================================
    //               Withdrawal Errors
    // ===========================================
    /// Empty Withdrawal.
    #[msg("empty withdrawal")]
    EmptyWithdrawal,
    // ===========================================
    //                 Order Errors
    // ===========================================
    /// Empty Order.
    #[msg("empty order")]
    EmptyOrder,
    /// Invalid min output amount for limit swap.
    #[msg("invalid min output amount for limit swap order")]
    InvalidMinOutputAmount,
    /// Invalid trigger price.
    #[msg("invalid trigger price")]
    InvalidTriggerPrice,
    /// Invalid position.
    #[msg("invalid position")]
    InvalidPosition,
    /// Invalid position kind.
    #[msg("invalid position kind")]
    InvalidPositionKind,
    /// Position mismatched.
    #[msg("position mismatched")]
    PositionMismatched,
    /// Position is not required.
    #[msg("position is not required")]
    PositionItNotRequired,
    /// Position is required.
    #[msg("position is required")]
    PositionIsRequired,
    /// Order kind is not allowed.
    #[msg("the order kind is not allowed by this instruction")]
    OrderKindNotAllowed,
    /// Unknown Order Kind.
    #[msg("unknown order kind")]
    UnknownOrderKind,
    /// Unknown Order Side.
    #[msg("unknown order side")]
    UnknownOrderSide,
    /// Unknown Decrease Position Swap Type.
    #[msg("unknown decrease position swap type")]
    UnknownDecreasePositionSwapType,
    /// Missing initial collateral token.
    #[msg("missing initial collateral token")]
    MissingInitialCollateralToken,
    /// Missing final output token.
    #[msg("missing final output token")]
    MissingFinalOutputToken,
    /// Missing pool tokens.
    #[msg("missing pool tokens")]
    MissingPoolTokens,
    /// Invalid Trade ID.
    #[msg("invalid trade ID")]
    InvalidTradeID,
    /// Invalid Trade delta size.
    #[msg("invalid trade delta size")]
    InvalidTradeDeltaSize,
    /// Invalid Trade delta tokens.
    #[msg("invalid trade delta tokens")]
    InvalidTradeDeltaTokens,
    /// Invalid Borrowing Factor.
    #[msg("invalid borrowing factor")]
    InvalidBorrowingFactor,
    /// Invalid funding factors.
    #[msg("invalid funding factors")]
    InvalidFundingFactors,
    /// No delegated authority is set.
    #[msg("no delegated authority is set")]
    NoDelegatedAuthorityIsSet,
    /// Claimable collateral for holding cannot be in output tokens.
    #[msg("claimable collateral for holding cannot be in output tokens")]
    ClaimableCollateralForHoldingCannotBeInOutputTokens,
    /// ADL is not enabled.
    #[msg("ADL is not enabled")]
    AdlNotEnabled,
    /// ADL is not required.
    #[msg("ADL is not required")]
    AdlNotRequired,
    /// Invalid ADL.
    #[msg("invalid ADL")]
    InvalidAdl,
    /// The output token and the secondary output token are the same,
    /// but the token amounts are not merged together.
    #[msg("same output tokens not merged")]
    SameOutputTokensNotMerged,
    /// Event buffer is not provided.
    #[msg("event buffer is not provided")]
    EventBufferNotProvided,
    // ===========================================
    //                 Shift Errors
    // ===========================================
    /// Empty Shift.
    #[msg("empty shift")]
    EmptyShift,
    /// Invalid Shift Markets
    #[msg("invalid shift markets")]
    InvalidShiftMarkets,
    // ===========================================
    //        GT and User Accounts Errors
    // ===========================================
    /// GT State has been initialized.
    #[msg("GT State has been initialized")]
    GTStateHasBeenInitialized,
    /// Invalid GT config.
    #[msg("invalid GT config")]
    InvalidGTConfig,
    /// Invalid GT discount.
    #[msg("invalid GT discount")]
    InvalidGTDiscount,
    /// User account has been initialized.
    #[msg("user account has been initialized")]
    UserAccountHasBeenInitialized,
    // ===========================================
    //               Referral Errors
    // ===========================================
    /// Referral Code has been set.
    #[msg("referral code has been set")]
    ReferralCodeHasBeenSet,
    /// Referrer has been set.
    #[msg("referrer has been set")]
    ReferrerHasBeenSet,
    /// Invalid User Account.
    #[msg("invalid user account")]
    InvalidUserAccount,
    /// Referral Code Mismatched.
    #[msg("referral code mismatched")]
    ReferralCodeMismatched,
    /// Self-referral is not allowed.
    #[msg("self-referral is not allowed")]
    SelfReferral,
    /// Mutual-referral is not allowed.
    #[msg("mutual-referral is not allowed")]
    MutualReferral,
    // ===========================================
    //                Market Errors
    // ===========================================
    /// Invalid market config key.
    #[msg("invalid market config key")]
    InvalidMarketConfigKey,
    /// Invalid collateral token.
    #[msg("invalid collateral token")]
    InvalidCollateralToken,
    /// Disabled market.
    #[msg("disabled market")]
    DisabledMarket,
    // ===========================================
    //                  GLV Errors
    // ===========================================
    /// Failed to calculate GLV value for market.
    #[msg("failed to calculate GLV value for this market")]
    FailedToCalculateGlvValueForMarket,
    /// Failed to calculate GLV amount to mint.
    #[msg("failed to calculate GLV amount to mint")]
    FailedToCalculateGlvAmountToMint,
    /// Failed to calculate market token amount to burn.
    #[msg("failed to calculate market token amount to burn")]
    FailedToCalculateMarketTokenAmountToBurn,
    /// Exceed max market token balance amount of GLV.
    #[msg("GLV max market token balance amount exceeded")]
    ExceedMaxGlvMarketTokenBalanceAmount,
    /// Exceed max market token balance value of GLV.
    #[msg("GLV max market token balance value exceeded")]
    ExceedMaxGlvMarketTokenBalanceValue,
    /// Empty GLV withdrawal.
    #[msg("empty GLV withdrawal")]
    EmptyGlvWithdrawal,
    /// Negative Market Pool Value.
    #[msg("GLV: negative market pool value")]
    GlvNegativeMarketPoolValue,
    /// Deposit is not allowed with the given market.
    #[msg("GLV: deposit is not allowed with the given market")]
    GlvDepositIsNotAllowed,
    /// Shift interval not yet passed.
    #[msg("GLV: shift interval not yet passed")]
    GlvShiftIntervalNotYetPassed,
    /// Shift max price impact exceeded.
    #[msg("GLV: shift max price impact exceeded")]
    GlvShiftMaxPriceImpactExceeded,
    /// Shift value too small.
    #[msg("GLV: shift value is not large enough")]
    GlvShiftValueNotLargeEnough,
    // ===========================================
    //                Other Errors
    // ===========================================
    /// The decimals of token is immutable.
    #[msg("the decimals of token is immutable")]
    TokenDecimalsChanged,
    /// Price is stale.
    #[msg("price is stale")]
    PriceIsStale,
    /// Deprecated.
    #[msg("deprecated")]
    Deprecated,
    /// Index overflow.
    #[msg("index overflow")]
    IndexOverflow,
    // ===========================================
    //              Market Errors (2)
    // ===========================================
    /// Market is closed.
    #[msg("market is closed")]
    MarketClosed,
    // ===========================================
    //              Oracle Errors (2)
    // ===========================================
    /// Market status flags are not yet supported for this price provider.
    #[msg("market status flags are not yet supported for this price provider")]
    ProviderDoesNotSupportMarketStatus,
    // ===========================================
    //              Builder Fee Errors
    // ===========================================
    /// Builder fee factor exceeds the max builder fee factor.
    #[msg("builder fee factor exceeds the max builder fee factor")]
    BuilderFeeFactorExceedsMaxFactor,
    /// An order cannot be closed while it still has an unsettled builder
    /// fee; settle it first via `settle_builder_fee`.
    #[msg("order has an unsettled builder fee")]
    UnsettledBuilderFee,
    /// An increase order's collateral increment cannot fully cover the
    /// builder fee. Unlike decrease, increase has no equivalent of
    /// "complete anyway at a loss" to fall back on, so this cancels the
    /// order instead of charging a partial fee.
    #[msg("builder fee exceeds the collateral increment")]
    BuilderFeeExceedsCollateral,
    /// A non-zero builder fee is being charged on an increase order that
    /// has no final output token. Initializing it is optional for
    /// increase orders, and the builder fee is charged in it, so an order
    /// that never opted in cannot pay one.
    #[msg("builder fee requires the final output token to equal the collateral token")]
    BuilderFeeFinalOutputTokenMismatch,
    /// A decrease order with a non-zero builder fee used
    /// `DecreasePositionSwapType::CollateralToPnlToken`. That swap type
    /// deterministically moves the entire collateral-token output into the
    /// pnl token before the receive-token swap runs, leaving the final
    /// output token bucket at zero every time, which would make the
    /// builder fee trivially and reliably bypassable.
    #[msg("this decrease position swap type is not allowed together with a builder fee")]
    BuilderFeeSwapTypeNotAllowed,
    /// The builder's advertised factor does not match the expected factor.
    #[msg("builder fee factor does not match the expected factor")]
    BuilderFeeFactorMismatched,
    /// Builder fee is not allowed for this order kind.
    #[msg("builder fee is not allowed for this order kind")]
    BuilderFeeOrderKindNotAllowed,
    /// The order's final output token is not initialized.
    #[msg("the order's final output token is not initialized")]
    BuilderFeeFinalOutputTokenNotInitialized,
    /// The order's escrow account for the final output token is not
    /// initialized. The builder fee is paid out of that escrow, so an order
    /// without one would revert at the transfer-out stage of `execute_order`
    /// once a fee were charged.
    #[msg("the order's final output token escrow is not initialized")]
    BuilderFeeFinalOutputTokenEscrowNotInitialized,
    // NOTE: New variants must be appended here to keep existing error codes stable.
}

#[cfg(not(feature = "no-entrypoint"))]
gmsol_utils::security_txt!("GMX-Solana Store Program");
