use anchor_lang::prelude::*;
use anchor_spl::token::{Mint, TokenAccount};
use gmsol_callback::interface::ActionKind;
use gmsol_model::{
    action::decrease_position::{DecreasePositionFlags, DecreasePositionSwapType},
    num::Unsigned,
    price::{Price, Prices},
    BaseMarket, BaseMarketExt, MarketAction, PnlFactorKind, Position as _, PositionExt,
    PositionMut, PositionMutExt, PositionState, PositionStateExt,
};
use gmsol_utils::action::ActionCallbackKind;
use typed_builder::TypedBuilder;

use crate::{
    constants,
    events::{
        BuilderFeeCharged, EventEmitter, OrderUpdated, PositionDecreased, PositionIncreased,
        TradeData,
    },
    states::{
        callback::CallbackAuthority,
        common::{
            action::{Action, ActionExt, ActionParams, On},
            swap::SwapActionParamsExt,
        },
        market::{
            revertible::{
                market::RevertibleMarket,
                revertible_position::RevertiblePosition,
                swap_market::{SwapDirection, SwapMarkets},
                Revertible, Revision,
            },
            utils::{Adl, ClosableMarket, ValidateMarketBalances},
        },
        order::{Order, OrderActionParams, OrderKind, OrderTokenAccounts, TransferOut},
        position::PositionKind,
        user::UserHeader,
        AmountKey, HasMarketMeta, Market, MarketPriceOptions, NonceBytes, Oracle, Position, Store,
        ValidateOracleTime,
    },
    CoreError, ModelError,
};

use super::{
    execution_fee::TransferExecutionFeeOperation,
    market::{MarketTransferOutOperation, RemainingAccountsForMarket},
};

pub use gmsol_utils::order::PositionCutKind;

/// Create Order Arguments.
#[derive(AnchorSerialize, AnchorDeserialize, Clone, Debug, InitSpace)]
pub struct CreateOrderParams {
    /// Order Kind.
    pub kind: OrderKind,
    /// Decrease Position Swap Type.
    pub decrease_position_swap_type: Option<DecreasePositionSwapType>,
    /// Execution fee in lamports.
    pub execution_lamports: u64,
    /// The length of the swap path.
    pub swap_path_length: u8,
    /// Initial collateral / swap in token amount.
    pub initial_collateral_delta_amount: u64,
    /// Size delta value.
    pub size_delta_value: u128,
    /// Is long.
    pub is_long: bool,
    /// Is collateral or the swap out token the long token.
    pub is_collateral_long: bool,
    /// Min output amount or value.
    pub min_output: Option<u128>,
    /// Trigger price.
    pub trigger_price: Option<u128>,
    /// Acceptable price.
    pub acceptable_price: Option<u128>,
    /// Whether to unwrap native token when sending funds back.
    pub should_unwrap_native_token: bool,
    /// Valid from timestamp.
    pub valid_from_ts: Option<i64>,
}

impl ActionParams for CreateOrderParams {
    fn execution_lamports(&self) -> u64 {
        self.execution_lamports
    }
}

impl CreateOrderParams {
    /// Get the related position kind.
    pub fn to_position_kind(&self) -> Result<PositionKind> {
        if self.kind.is_swap() {
            return err!(CoreError::PositionItNotRequired);
        }
        if self.is_long {
            Ok(PositionKind::Long)
        } else {
            Ok(PositionKind::Short)
        }
    }

    /// Get the collateral token or swap out token address.
    pub fn collateral_token<'a>(&'a self, meta: &'a impl HasMarketMeta) -> &'a Pubkey {
        let meta = meta.market_meta();
        if self.is_collateral_long {
            &meta.long_token_mint
        } else {
            &meta.short_token_mint
        }
    }
}

/// Operations for creating a new order.
#[derive(TypedBuilder)]
pub(crate) struct CreateOrderOperation<'a, 'info> {
    order: AccountLoader<'info, Order>,
    market: AccountLoader<'info, Market>,
    store: AccountLoader<'info, Store>,
    owner: AccountInfo<'info>,
    receiver: AccountInfo<'info>,
    #[builder(
        default,
        setter(
            strip_option,
            doc = "Set the creator of this order. CHECK: It must be the address deriving the order account",
        )
    )]
    creator: Option<AccountInfo<'info>>,
    nonce: &'a NonceBytes,
    bump: u8,
    params: &'a CreateOrderParams,
    swap_path: &'info [AccountInfo<'info>],
    callback_version: Option<u8>,
    callback_authority: Option<&'a Account<'info, CallbackAuthority>>,
    callback_program: Option<&'a AccountInfo<'info>>,
    callback_shared_data_account: Option<&'a AccountInfo<'info>>,
    callback_partitioned_data_account: Option<&'a AccountInfo<'info>>,
    #[builder(default)]
    allow_closed: bool,
    #[builder(setter(into))]
    event_emitter: Option<EventEmitter<'a, 'info>>,
}

impl<'a, 'info> CreateOrderOperation<'a, 'info> {
    pub(crate) fn swap(
        self,
    ) -> CreateSwapOrderOperationBuilder<'a, 'info, ((CreateOrderOperation<'a, 'info>,), (), ())>
    {
        CreateSwapOrderOperation::builder().common(self)
    }

    pub(crate) fn increase(
        self,
    ) -> CreateIncreaseOrderOperationBuilder<
        'a,
        'info,
        ((CreateOrderOperation<'a, 'info>,), (), (), (), (), ()),
    > {
        CreateIncreaseOrderOperation::builder().common(self)
    }

    pub(crate) fn decrease(
        self,
    ) -> CreateDecreaseOrderOperationBuilder<
        'a,
        'info,
        ((CreateOrderOperation<'a, 'info>,), (), (), (), ()),
    > {
        CreateDecreaseOrderOperation::builder().common(self)
    }

    fn validate(&self) -> Result<()> {
        self.market
            .load()?
            .validate_with_options(&self.store.key(), self.allow_closed)?;
        ActionExt::validate_balance(&self.order, self.params.execution_lamports)?;
        Ok(())
    }

    #[inline(never)]
    fn init_with(
        &self,
        f: impl FnOnce(
            &CreateOrderParams,
            &mut OrderTokenAccounts,
            &mut OrderActionParams,
        ) -> Result<(Pubkey, Pubkey)>,
        position: Option<&AccountInfo<'info>>,
    ) -> Result<()> {
        let id = self.market.load_mut()?.indexer_mut().next_order_id()?;
        {
            let mut order = self.order.load_init()?;
            let Order {
                header,
                market_token,
                tokens,
                params,
                swap,
                ..
            } = &mut *order;

            header.init(
                id,
                self.store.key(),
                self.market.key(),
                self.owner.key(),
                self.receiver.key(),
                *self.nonce,
                self.bump,
                self.params.execution_lamports,
                self.params.should_unwrap_native_token,
            )?;

            if let Some(creator) = self.creator.as_ref() {
                header.unchecked_set_creator(creator.key());
            }

            *market_token = self.market.load()?.meta().market_token_mint;

            let (from, to) = (f)(self.params, tokens, params)?;

            let market = self.market.load()?;
            let meta = market.meta();
            let swap_path = self.swap_path;
            // The secondary path is ignored.
            swap.validate_and_init(
                meta,
                self.params.swap_path_length,
                0,
                swap_path,
                &self.store.key(),
                (&from, &from),
                (&to, &from),
            )?;
        }
        self.handle_created(position)
    }

    #[inline(never)]
    fn handle_created(&self, position: Option<&AccountInfo<'info>>) -> Result<()> {
        // Ensure that the discriminator is written to the account data.
        self.order.exit(&crate::ID)?;
        if let Some(version) = self.callback_version.as_ref() {
            require_eq!(*version, 0, {
                msg!("[Callback] orders currently support only callback version `0`");
                CoreError::InvalidArgument
            });

            let authority = self
                .callback_authority
                .as_ref()
                .ok_or_else(|| error!(CoreError::InvalidArgument))?;
            let program = self
                .callback_program
                .as_ref()
                .ok_or_else(|| error!(CoreError::InvalidArgument))?;
            let shared_data = self
                .callback_shared_data_account
                .as_ref()
                .ok_or_else(|| error!(CoreError::InvalidArgument))?;
            let partitioned_data = self
                .callback_partitioned_data_account
                .as_ref()
                .ok_or_else(|| error!(CoreError::InvalidArgument))?;
            let position = position.unwrap_or(program);

            self.order.load_mut()?.header.set_general_callback(
                program.key,
                *version,
                shared_data.key,
                partitioned_data.key,
            )?;

            self.order.load()?.header.invoke_general_callback(
                On::Created(ActionKind::Order),
                authority,
                program,
                shared_data,
                partitioned_data,
                &self.owner,
                self.order.as_ref(),
                &[position.clone()],
            )?;
        }

        if let Some(event_emitter) = self.event_emitter {
            event_emitter.emit_cpi(&OrderUpdated::new(
                true,
                &self.order.key(),
                &*self.order.load()?,
            )?)?;
        }

        Ok(())
    }
}

/// Operation for creating a new swap order.
#[derive(TypedBuilder)]
pub(crate) struct CreateSwapOrderOperation<'a, 'info> {
    common: CreateOrderOperation<'a, 'info>,
    swap_in_token: &'a Account<'info, TokenAccount>,
    swap_out_token: &'a Account<'info, TokenAccount>,
}

impl CreateSwapOrderOperation<'_, '_> {
    pub(crate) fn execute(self) -> Result<()> {
        self.common.validate()?;
        self.validate_params_excluding_swap()?;

        self.common.init_with(
            |create, tokens, params| {
                tokens.initial_collateral.init(self.swap_in_token);
                tokens.final_output_token.init(self.swap_out_token);
                params.init_swap(
                    create.kind,
                    self.swap_out_token.mint,
                    create.initial_collateral_delta_amount,
                    create.min_output,
                    create.valid_from_ts,
                )?;
                Ok((self.swap_in_token.mint, self.swap_out_token.mint))
            },
            None,
        )?;
        Ok(())
    }

    fn validate_params_excluding_swap(&self) -> Result<()> {
        require!(self.common.params.kind.is_swap(), CoreError::Internal);
        require!(
            self.common.params.initial_collateral_delta_amount != 0,
            CoreError::EmptyOrder
        );
        require_gte!(
            self.swap_in_token.amount,
            self.common.params.initial_collateral_delta_amount,
            CoreError::NotEnoughTokenAmount
        );
        require_gte!(self.common.params.swap_path_length, 1, {
            msg!("cannot create no-op swap order");
            CoreError::InvalidSwapPathLength
        });
        require!(
            self.common
                .market
                .load()?
                .meta()
                .is_collateral_token(&self.swap_out_token.mint),
            CoreError::TokenMintMismatched
        );
        Ok(())
    }
}

/// Operation for creating a new increase position order.
#[derive(TypedBuilder)]
pub(crate) struct CreateIncreaseOrderOperation<'a, 'info> {
    common: CreateOrderOperation<'a, 'info>,
    position: &'a AccountLoader<'info, Position>,
    initial_collateral_token: &'a Account<'info, TokenAccount>,
    long_token: &'a Account<'info, TokenAccount>,
    short_token: &'a Account<'info, TokenAccount>,
    /// The escrow for the final output token.
    ///
    /// Optional for increase orders: clients that do not intend to use a builder fee can keep
    /// omitting it, and the order's final output token is then left uninitialized, exactly as
    /// before this account was read at all. When it is provided, both halves of
    /// [`OrderTokenAccounts::final_output_token`] are initialized from it, after its mint has
    /// been validated to be the collateral token.
    final_output_token: Option<&'a Account<'info, TokenAccount>>,
}

impl CreateIncreaseOrderOperation<'_, '_> {
    pub(crate) fn execute(self) -> Result<()> {
        self.common.validate()?;
        self.validate_params_excluding_swap()?;

        let collateral_token = if self.common.params.is_collateral_long {
            self.common.market.load()?.meta().long_token_mint
        } else {
            self.common.market.load()?.meta().short_token_mint
        };

        self.common.init_with(
            |create, tokens, params| {
                tokens
                    .initial_collateral
                    .init(self.initial_collateral_token);
                tokens.long_token.init(self.long_token);
                tokens.short_token.init(self.short_token);
                if let Some(escrow) = self.final_output_token {
                    // The builder fee is charged in the order's final output token, so for an
                    // increase order that token has to be the position's collateral token. The
                    // instruction layer enforces the same thing unconditionally; this is the
                    // second line of defense, and the only one that can run here, since without
                    // the escrow the ops layer never learns which mint was requested.
                    require_keys_eq!(
                        escrow.mint,
                        collateral_token,
                        CoreError::TokenMintMismatched
                    );
                    tokens.final_output_token.init(escrow);
                }
                params.init_increase(
                    create.is_long,
                    create.kind,
                    self.position.key(),
                    collateral_token,
                    create.initial_collateral_delta_amount,
                    create.size_delta_value,
                    create.trigger_price,
                    create.acceptable_price,
                    create.min_output,
                    create.valid_from_ts,
                )?;
                Ok((self.initial_collateral_token.mint, collateral_token))
            },
            Some(self.position.as_ref()),
        )?;

        Ok(())
    }

    fn validate_params_excluding_swap(&self) -> Result<()> {
        require!(
            self.common.params.kind.is_increase_position(),
            CoreError::Internal
        );
        require!(
            self.common.params.size_delta_value != 0
                || self.common.params.initial_collateral_delta_amount != 0,
            CoreError::EmptyOrder
        );
        require_gte!(
            self.initial_collateral_token.amount,
            self.common.params.initial_collateral_delta_amount,
            CoreError::NotEnoughTokenAmount
        );

        {
            let market = self.common.market.load()?;
            require_keys_eq!(
                market.meta().long_token_mint,
                self.long_token.mint,
                CoreError::TokenMintMismatched
            );
            require_keys_eq!(
                market.meta().short_token_mint,
                self.short_token.mint,
                CoreError::TokenMintMismatched
            );
            self.position
                .load()?
                .validate_for_market(&market, self.common.allow_closed)
                .map_err(ModelError::from)?;
        }

        Ok(())
    }
}

/// Operation for creating a new decrease position order.
#[derive(TypedBuilder)]
pub(crate) struct CreateDecreaseOrderOperation<'a, 'info> {
    common: CreateOrderOperation<'a, 'info>,
    position: &'a AccountLoader<'info, Position>,
    final_output_token: &'a Account<'info, TokenAccount>,
    long_token: &'a Account<'info, TokenAccount>,
    short_token: &'a Account<'info, TokenAccount>,
}

impl CreateDecreaseOrderOperation<'_, '_> {
    pub(crate) fn execute(self) -> Result<()> {
        self.common.validate()?;
        self.validate_params_excluding_swap()?;

        let collateral_token = if self.common.params.is_collateral_long {
            self.common.market.load()?.meta().long_token_mint
        } else {
            self.common.market.load()?.meta().short_token_mint
        };

        self.common.init_with(
            |create, tokens, params| {
                tokens.final_output_token.init(self.final_output_token);
                tokens.long_token.init(self.long_token);
                tokens.short_token.init(self.short_token);
                params.init_decrease(
                    create.is_long,
                    create.kind,
                    self.position.key(),
                    collateral_token,
                    create.initial_collateral_delta_amount,
                    create.size_delta_value,
                    create.trigger_price,
                    create.acceptable_price,
                    create.min_output,
                    create.decrease_position_swap_type.unwrap_or_default(),
                    create.valid_from_ts,
                )?;
                Ok((collateral_token, self.final_output_token.mint))
            },
            Some(self.position.as_ref()),
        )?;
        Ok(())
    }

    fn validate_params_excluding_swap(&self) -> Result<()> {
        require!(
            self.common.params.kind.is_decrease_position(),
            CoreError::Internal
        );

        // Note: Empty market decrease order is allowed so that the user
        // can claim funding rebates without modifying the position.
        require!(
            self.common.params.size_delta_value != 0
                || self.common.params.initial_collateral_delta_amount != 0
                || self.common.params.kind.is_market_decrease(),
            CoreError::EmptyOrder
        );

        {
            let market = self.common.market.load()?;
            require_keys_eq!(
                market.meta().long_token_mint,
                self.long_token.mint,
                CoreError::TokenMintMismatched
            );
            require_keys_eq!(
                market.meta().short_token_mint,
                self.short_token.mint,
                CoreError::TokenMintMismatched
            );
            self.position
                .load()?
                .validate_for_market(&market, self.common.allow_closed)
                .map_err(ModelError::from)?;
        }
        Ok(())
    }
}

/// Operation for processing [`TransferOut`].
#[derive(TypedBuilder)]
pub(crate) struct ProcessTransferOutOperation<'a, 'info> {
    token_program: AccountInfo<'info>,
    store: &'a AccountLoader<'info, Store>,
    market: &'a AccountLoader<'info, Market>,
    is_pnl_token_long_token: bool,
    #[builder(default, setter(strip_option))]
    final_output_market: Option<&'a AccountLoader<'info, Market>>,
    final_output_token: Option<&'a Account<'info, Mint>>,
    final_output_token_account: Option<AccountInfo<'info>>,
    final_output_token_vault: Option<&'a Account<'info, TokenAccount>>,
    long_token: Option<&'a Account<'info, Mint>>,
    long_token_account: Option<AccountInfo<'info>>,
    long_token_vault: Option<&'a Account<'info, TokenAccount>>,
    short_token: Option<&'a Account<'info, Mint>>,
    short_token_account: Option<AccountInfo<'info>>,
    short_token_vault: Option<&'a Account<'info, TokenAccount>>,
    pub(crate) claimable_long_token_account_for_user: Option<AccountInfo<'info>>,
    pub(crate) claimable_short_token_account_for_user: Option<AccountInfo<'info>>,
    pub(crate) claimable_pnl_token_account_for_holding: Option<AccountInfo<'info>>,
    transfer_out: &'a TransferOut,
    allow_closed: bool,
    #[builder(setter(into))]
    event_emitter: EventEmitter<'a, 'info>,
}

impl<'info> ProcessTransferOutOperation<'_, 'info> {
    pub(crate) fn execute(self) -> Result<()> {
        let TransferOut {
            final_output_token,
            secondary_output_token,
            long_token,
            short_token,
            long_token_for_claimable_account_of_user,
            short_token_for_claimable_account_of_user,
            long_token_for_claimable_account_of_holding,
            short_token_for_claimable_account_of_holding,
            ..
        } = self.transfer_out;

        if *final_output_token != 0 {
            let (token, market, vault, account) = self.final_output()?;
            MarketTransferOutOperation::builder()
                .store(self.store)
                .market(market)
                .amount(*final_output_token)
                .to(account.clone())
                .vault(vault.to_account_info())
                .decimals(token.decimals)
                .token_mint(token.to_account_info())
                .token_program(self.token_program.clone())
                .allow_closed(self.allow_closed)
                .event_emitter(self.event_emitter)
                .build()
                .execute()?;
        }

        let (long_token_amount, short_token_amount) = if self.is_pnl_token_long_token {
            (
                secondary_output_token
                    .checked_add(*long_token)
                    .ok_or(error!(CoreError::TokenAmountOverflow))?,
                *short_token,
            )
        } else {
            (
                *long_token,
                secondary_output_token
                    .checked_add(*short_token)
                    .ok_or(error!(CoreError::TokenAmountOverflow))?,
            )
        };

        if long_token_amount != 0 {
            let (token, vault, account) = self.long_token()?;
            MarketTransferOutOperation::builder()
                .store(self.store)
                .token_program(self.token_program.clone())
                .market(self.market)
                .amount(long_token_amount)
                .vault(vault.to_account_info())
                .decimals(token.decimals)
                .token_mint(token.to_account_info())
                .to(account.clone())
                .allow_closed(self.allow_closed)
                .event_emitter(self.event_emitter)
                .build()
                .execute()?;
        }

        if short_token_amount != 0 {
            let (token, vault, account) = self.short_token()?;
            MarketTransferOutOperation::builder()
                .store(self.store)
                .token_program(self.token_program.clone())
                .market(self.market)
                .amount(short_token_amount)
                .vault(vault.to_account_info())
                .decimals(token.decimals)
                .token_mint(token.to_account_info())
                .to(account.clone())
                .allow_closed(self.allow_closed)
                .event_emitter(self.event_emitter)
                .build()
                .execute()?;
        }

        if *long_token_for_claimable_account_of_user != 0 {
            let (token, vault, account) = self.claimable_long_token_account_for_user()?;
            MarketTransferOutOperation::builder()
                .store(self.store)
                .token_program(self.token_program.clone())
                .market(self.market)
                .amount(*long_token_for_claimable_account_of_user)
                .vault(vault.to_account_info())
                .decimals(token.decimals)
                .token_mint(token.to_account_info())
                .to(account.clone())
                .allow_closed(self.allow_closed)
                .event_emitter(self.event_emitter)
                .build()
                .execute()?;
        }

        if *short_token_for_claimable_account_of_user != 0 {
            let (token, vault, account) = self.claimable_short_token_account_for_user()?;
            MarketTransferOutOperation::builder()
                .store(self.store)
                .token_program(self.token_program.clone())
                .market(self.market)
                .amount(*short_token_for_claimable_account_of_user)
                .vault(vault.to_account_info())
                .decimals(token.decimals)
                .token_mint(token.to_account_info())
                .to(account.clone())
                .allow_closed(self.allow_closed)
                .event_emitter(self.event_emitter)
                .build()
                .execute()?;
        }

        if *long_token_for_claimable_account_of_holding != 0 {
            let (token, vault, account) = self.claimable_long_token_account_for_holding()?;
            MarketTransferOutOperation::builder()
                .store(self.store)
                .token_program(self.token_program.clone())
                .market(self.market)
                .amount(*long_token_for_claimable_account_of_holding)
                .vault(vault.to_account_info())
                .decimals(token.decimals)
                .token_mint(token.to_account_info())
                .to(account.clone())
                .allow_closed(self.allow_closed)
                .event_emitter(self.event_emitter)
                .build()
                .execute()?;
        }

        if *short_token_for_claimable_account_of_holding != 0 {
            let (token, vault, account) = self.claimable_short_token_account_for_holding()?;
            MarketTransferOutOperation::builder()
                .store(self.store)
                .token_program(self.token_program.clone())
                .market(self.market)
                .amount(*short_token_for_claimable_account_of_holding)
                .vault(vault.to_account_info())
                .decimals(token.decimals)
                .token_mint(token.to_account_info())
                .to(account.clone())
                .event_emitter(self.event_emitter)
                .allow_closed(self.allow_closed)
                .build()
                .execute()?;
        }
        Ok(())
    }

    #[allow(clippy::type_complexity)]
    fn final_output(
        &self,
    ) -> Result<(
        &Account<'info, Mint>,
        &AccountLoader<'info, Market>,
        &Account<'info, TokenAccount>,
        &AccountInfo<'info>,
    )> {
        let token = self
            .final_output_token
            .ok_or(error!(CoreError::TokenMintNotProvided))?;
        let market = self
            .final_output_market
            .ok_or(error!(CoreError::MarketMismatched))?;
        let vault = self
            .final_output_token_vault
            .as_ref()
            .ok_or(error!(CoreError::TokenAccountNotProvided))?;
        let account = self
            .final_output_token_account
            .as_ref()
            .ok_or(error!(CoreError::TokenAccountNotProvided))?;
        Ok((token, market, vault, account))
    }

    fn long_token(
        &self,
    ) -> Result<(
        &Account<'info, Mint>,
        &Account<'info, TokenAccount>,
        &AccountInfo<'info>,
    )> {
        let token = self
            .long_token
            .ok_or(error!(CoreError::TokenMintNotProvided))?;
        let vault = self
            .long_token_vault
            .as_ref()
            .ok_or(error!(CoreError::TokenAccountNotProvided))?;
        let account = self
            .long_token_account
            .as_ref()
            .ok_or(error!(CoreError::TokenAccountNotProvided))?;
        Ok((token, vault, account))
    }

    fn short_token(
        &self,
    ) -> Result<(
        &Account<'info, Mint>,
        &Account<'info, TokenAccount>,
        &AccountInfo<'info>,
    )> {
        let token = self
            .short_token
            .ok_or(error!(CoreError::TokenMintNotProvided))?;
        let vault = self
            .short_token_vault
            .as_ref()
            .ok_or(error!(CoreError::TokenAccountNotProvided))?;
        let account = self
            .short_token_account
            .as_ref()
            .ok_or(error!(CoreError::TokenAccountNotProvided))?;
        Ok((token, vault, account))
    }

    fn claimable_long_token_account_for_user(
        &self,
    ) -> Result<(
        &Account<'info, Mint>,
        &Account<'info, TokenAccount>,
        &AccountInfo<'info>,
    )> {
        let token = self
            .long_token
            .ok_or(error!(CoreError::TokenMintNotProvided))?;
        let vault = self
            .long_token_vault
            .as_ref()
            .ok_or(error!(CoreError::TokenAccountNotProvided))?;
        let account = self
            .claimable_long_token_account_for_user
            .as_ref()
            .ok_or(error!(CoreError::TokenAccountNotProvided))?;
        Ok((token, vault, account))
    }

    fn claimable_short_token_account_for_user(
        &self,
    ) -> Result<(
        &Account<'info, Mint>,
        &Account<'info, TokenAccount>,
        &AccountInfo<'info>,
    )> {
        let token = self
            .short_token
            .ok_or(error!(CoreError::TokenMintNotProvided))?;
        let vault = self
            .short_token_vault
            .as_ref()
            .ok_or(error!(CoreError::TokenAccountNotProvided))?;
        let account = self
            .claimable_short_token_account_for_user
            .as_ref()
            .ok_or(error!(CoreError::TokenAccountNotProvided))?;
        Ok((token, vault, account))
    }

    fn claimable_long_token_account_for_holding(
        &self,
    ) -> Result<(
        &Account<'info, Mint>,
        &Account<'info, TokenAccount>,
        &AccountInfo<'info>,
    )> {
        let token = self
            .long_token
            .ok_or(error!(CoreError::TokenMintNotProvided))?;
        let vault = self
            .long_token_vault
            .as_ref()
            .ok_or(error!(CoreError::TokenAccountNotProvided))?;
        let account = self
            .claimable_pnl_token_account_for_holding
            .as_ref()
            .ok_or(error!(CoreError::TokenAccountNotProvided))?;
        Ok((token, vault, account))
    }

    fn claimable_short_token_account_for_holding(
        &self,
    ) -> Result<(
        &Account<'info, Mint>,
        &Account<'info, TokenAccount>,
        &AccountInfo<'info>,
    )> {
        let token = self
            .short_token
            .ok_or(error!(CoreError::TokenMintNotProvided))?;
        let vault = self
            .short_token_vault
            .as_ref()
            .ok_or(error!(CoreError::TokenAccountNotProvided))?;
        let account = self
            .claimable_pnl_token_account_for_holding
            .as_ref()
            .ok_or(error!(CoreError::TokenAccountNotProvided))?;
        Ok((token, vault, account))
    }
}

/// Operation for executing order.
#[derive(TypedBuilder)]
pub(crate) struct ExecuteOrderOperation<'a, 'info> {
    executor: AccountInfo<'info>,
    user: &'a AccountLoader<'info, UserHeader>,
    store: &'a AccountLoader<'info, Store>,
    market: &'a AccountLoader<'info, Market>,
    order: &'a AccountLoader<'info, Order>,
    owner: AccountInfo<'info>,
    position: Option<&'a AccountLoader<'info, Position>>,
    event: Option<&'a AccountLoader<'info, TradeData>>,
    oracle: &'a Oracle,
    remaining_accounts: &'info [AccountInfo<'info>],
    throw_on_execution_error: bool,
    #[builder(default)]
    refund: u64,
    #[builder(setter(into))]
    event_emitter: EventEmitter<'a, 'info>,
    callback_authority: Option<&'a Account<'info, CallbackAuthority>>,
    callback_program: Option<&'a AccountInfo<'info>>,
    callback_shared_data_account: Option<&'a AccountInfo<'info>>,
    callback_partitioned_data_account: Option<&'a AccountInfo<'info>>,
    #[builder(default)]
    allow_closed: bool,
}

pub(crate) type RemovePosition = bool;
pub(crate) type ShouldSendTradeEvent = bool;

/// The amounts an execution computes but must not write to the [`Order`] itself.
///
/// CHECK: the `Order` is not revertible, unlike the position, the swap markets and
/// the virtual inventories, so both fields are carried out by value and applied by
/// the caller at the irreversible point rather than written where they are computed.
struct ExecutionFees {
    /// Order and borrowing fee value paid, the basis for the GT reward.
    paid_fee_value: u128,
    /// The builder fee charge, pending both its record and its announcement.
    ///
    /// `None` only when the order carries no builder fee factor. A factor that
    /// clamps to a zero payment still yields `Some`, because the event's contract
    /// is that its presence separates "no builder attached" from "builder attached,
    /// nothing collectible".
    builder_fee: Option<BuilderFeeCharge>,
}

/// A builder fee that has been computed but neither recorded nor announced yet.
///
/// CHECK: carried by value for the same reason as the rest of [`ExecutionFees`], and
/// the event is carried for one more. `emit_cpi` is a self-CPI, so the moment it
/// returns, the event sits in the transaction's inner instructions and a later `Err`
/// swallowed by the soft-failure arm cannot take it back, exactly as a write to the
/// non-revertible `Order` cannot be taken back. Announcing a charge that the order
/// never records is therefore the same defect as recording one that was never funded,
/// pointed the other way, and it is what this type exists to prevent.
struct BuilderFeeCharge {
    /// The token the fee is denominated and paid in.
    token: Pubkey,
    /// The computed amount, before shortfall clamping.
    payable_amount: u128,
    /// The amount actually charged, after shortfall clamping. Already narrowed, so
    /// that the conversion cannot fail at the irreversible point.
    paid_amount: u64,
}

enum SecondaryOrderType {
    Liquidation,
    AutoDeleveraging,
}

impl ExecuteOrderOperation<'_, '_> {
    fn price_options(&self) -> MarketPriceOptions {
        MarketPriceOptions {
            allow_index_closed: self.allow_closed,
            allow_long_closed: false,
            allow_short_closed: false,
        }
    }

    fn prices(&self) -> Result<Prices<u128>> {
        self.oracle
            .market_prices_with_options(&*self.market.load()?, self.price_options())
    }

    #[inline(never)]
    pub(crate) fn execute(
        self,
    ) -> Result<(RemovePosition, Box<TransferOut>, ShouldSendTradeEvent)> {
        let mut remove_position = false;

        self.order.load()?.validate_valid_from_ts()?;

        match self.validate_oracle() {
            Ok(()) => {}
            Err(CoreError::OracleTimestampsAreLargerThanRequired)
                if !self.throw_on_execution_error =>
            {
                msg!(
                    "Order expired at {}",
                    self.oracle_updated_before()
                        .ok()
                        .flatten()
                        .expect("must have an expiration time"),
                );
                // NOTE: Currently, the position account is not closed on order expiry.
                return Ok((false, Box::new(TransferOut::new_failed()), false));
            }
            Err(err) => {
                return Err(error!(err));
            }
        }

        let mut should_throw_error = false;
        let prices = self.prices()?;
        let discount = self.validate_and_get_order_fee_discount()?;
        let res = match self.perform_execution(&mut should_throw_error, prices, discount) {
            Ok((should_remove_position, mut transfer_out, should_send_trade_event)) => {
                transfer_out.set_executed(true);
                remove_position = should_remove_position;
                Ok((transfer_out, should_send_trade_event))
            }
            Err(err) if !(should_throw_error || self.throw_on_execution_error) => {
                msg!("Execute order error: {}", err);
                remove_position = self
                    .position
                    .as_ref()
                    .map(|a| Result::Ok(a.load()?.state.is_empty()))
                    .transpose()?
                    .unwrap_or(false);
                Ok((Default::default(), false))
            }
            Err(err) => Err(err),
        };

        let (transfer_out, should_send_trade_event) = res?;

        self.handle_executed(
            transfer_out.executed(),
            !remove_position,
            should_send_trade_event,
        )?;

        let keep_position_account = self.order.load()?.params().should_keep_position_account();
        if remove_position && !keep_position_account {
            self.close_position()?;
        }

        Ok((remove_position, transfer_out, should_send_trade_event))
    }

    #[inline(never)]
    fn validate_and_get_order_fee_discount(&self) -> Result<u128> {
        require!(
            self.user.load()?.is_initialized(),
            CoreError::InvalidUserAccount
        );
        let (rank, is_referred) = {
            let user = self.user.load()?;
            (user.gt.rank(), user.referral.referrer().is_some())
        };
        let discount_factor = self
            .store
            .load()?
            .order_fee_discount_factor(rank, is_referred)?;
        msg!(
            "[Order] apply a {} order fee discount (factor) for this {} rank {} user",
            discount_factor,
            if is_referred {
                "referred"
            } else {
                "non-referred"
            },
            rank,
        );
        Ok(discount_factor)
    }

    #[inline(never)]
    fn perform_execution(
        &self,
        should_throw_error: &mut bool,
        prices: Prices<u128>,
        order_fee_discount_factor: u128,
    ) -> Result<(RemovePosition, Box<TransferOut>, ShouldSendTradeEvent)> {
        self.validate_market()?;
        self.validate_order(should_throw_error, &prices)?;

        // Prepare execution context.
        let gt_minting_enabled = self.market.load()?.is_gt_minting_enabled();
        let current_market_token = self.market.load()?.market_meta().market_token_mint;

        let remaining_accounts = RemainingAccountsForMarket::new(
            self.remaining_accounts,
            current_market_token,
            Some(self.order.load()?.swap()),
        )?;
        let virtual_inventories = remaining_accounts.load_virtual_inventories()?;

        let mut market =
            RevertibleMarket::new(self.market, Some(&virtual_inventories), self.event_emitter)?
                .with_order_fee_discount_factor(order_fee_discount_factor);
        let mut swap_markets = SwapMarkets::new(
            &self.store.key(),
            remaining_accounts.swap_market_loaders(),
            Some(&current_market_token),
            &virtual_inventories,
            self.event_emitter,
        )?;
        let mut transfer_out = Box::default();

        market.update_fees_state(&prices)?;

        let kind = self.order.load()?.params.kind()?;
        let mut should_send_trade_event = false;
        let should_remove_position = match &kind {
            OrderKind::MarketSwap | OrderKind::LimitSwap => {
                execute_swap(
                    should_throw_error,
                    self.oracle,
                    &mut market,
                    &mut swap_markets,
                    &mut transfer_out,
                    &*self.order.load()?,
                )?;
                market.commit();
                false
            }
            OrderKind::MarketIncrease
            | OrderKind::MarketDecrease
            | OrderKind::Liquidation
            | OrderKind::AutoDeleveraging
            | OrderKind::LimitIncrease
            | OrderKind::LimitDecrease
            | OrderKind::StopLossDecrease => {
                let position_loader = self.position.as_ref().ok_or_else(|| {
                    *should_throw_error = true;
                    error!(CoreError::PositionIsRequired)
                })?;
                let event_loader = self.event.as_ref().ok_or_else(|| {
                    *should_throw_error = true;
                    error!(CoreError::EventBufferNotProvided)
                })?;
                {
                    let position = position_loader.load()?;
                    let mut event = event_loader.load_mut()?;
                    let is_collateral_long = market
                        .market_meta()
                        .to_token_side(&position.collateral_token)
                        .map_err(CoreError::from)?;
                    event.init(
                        kind.is_increase_position(),
                        is_collateral_long,
                        position_loader.key(),
                        &position,
                        self.order.key(),
                    )?;
                    should_send_trade_event = true;
                }
                let mut position =
                    RevertiblePosition::new(market, position_loader, self.allow_closed)?;

                position.on_validate().map_err(ModelError::from)?;

                // The factor checkpointed onto the order by `set_builder_fee`, not the one the
                // builder currently advertises: what the order owes is fixed when the owner signs
                // the checkpoint, and stays fixed however the builder moves its factor afterwards.
                // Orders that never took a checkpoint carry zero here, which every fee path below
                // reads as "no builder fee" and short-circuits on.
                //
                // Liquidation and ADL orders are created by the keeper rather than the owner, and
                // `set_builder_fee` accepts only user-initiated kinds, so their factor is always
                // zero; they are passed the same value for uniformity rather than as a special
                // case.
                let builder_fee_factor = self.order.load()?.builder_fee_factor();

                let (should_remove_position, fees) = match kind {
                    OrderKind::MarketIncrease | OrderKind::LimitIncrease => {
                        let fees = execute_increase_position(
                            self.oracle,
                            prices,
                            &mut position,
                            &mut swap_markets,
                            &mut transfer_out,
                            &mut *event_loader.load_mut()?,
                            &*self.order.load()?,
                            builder_fee_factor,
                        )?;
                        (false, fees)
                    }
                    OrderKind::Liquidation => execute_decrease_position(
                        self.oracle,
                        prices,
                        &mut position,
                        &mut swap_markets,
                        &mut transfer_out,
                        &mut *event_loader.load_mut()?,
                        &*self.order.load()?,
                        true,
                        Some(SecondaryOrderType::Liquidation),
                        builder_fee_factor,
                    )?,
                    OrderKind::AutoDeleveraging => execute_decrease_position(
                        self.oracle,
                        prices,
                        &mut position,
                        &mut swap_markets,
                        &mut transfer_out,
                        &mut *event_loader.load_mut()?,
                        &*self.order.load()?,
                        true,
                        Some(SecondaryOrderType::AutoDeleveraging),
                        builder_fee_factor,
                    )?,
                    OrderKind::MarketDecrease
                    | OrderKind::LimitDecrease
                    | OrderKind::StopLossDecrease => execute_decrease_position(
                        self.oracle,
                        prices,
                        &mut position,
                        &mut swap_markets,
                        &mut transfer_out,
                        &mut *event_loader.load_mut()?,
                        &*self.order.load()?,
                        false,
                        None,
                        builder_fee_factor,
                    )?,
                    _ => unreachable!(),
                };

                position.write_to_event(&mut *event_loader.load_mut()?)?;
                event_loader
                    .load_mut()?
                    .update_with_transfer_out(&transfer_out)?;

                // Overflow is checked here, while a failure is still discarded
                // cleanly, so that the write itself cannot fail. `None` when
                // nothing was charged, which keeps a fee-less execution from
                // touching the field at all. Note this is not the same condition
                // as the event's: a factor that clamps to a zero payment records
                // nothing and still announces itself.
                let next_builder_fee_amount = match &fees.builder_fee {
                    Some(charge) if charge.paid_amount != 0 => Some(
                        self.order
                            .load()?
                            .builder_fee_amount_after(charge.paid_amount)?,
                    ),
                    _ => None,
                };

                // The irreversible point. Neither account below is revertible, so
                // both writes wait until every fallible step has passed, and the
                // builder fee goes last because it is the only one that cannot
                // fail: a GT failure here still leaves the order untouched.
                {
                    let mut order = self.order.load_mut()?;

                    if gt_minting_enabled {
                        order.unchecked_process_gt(
                            &mut *self.store.load_mut()?,
                            &mut *self.user.load_mut()?,
                            fees.paid_fee_value,
                            position.event_emitter(),
                        )?;
                    } else {
                        msg!("[GT] GT minting is disabled for this market");
                    }

                    // Announced here rather than where it was computed, because
                    // `emit_cpi` is a self-CPI: once it returns the event is in
                    // the transaction and the soft-failure arm cannot take it
                    // back, so emitting early announces charges that a later
                    // failure then discards.
                    //
                    // Sits immediately before the write and after GT on purpose.
                    // The write below cannot fail, so an emitted event is always
                    // followed by its record and the two cannot disagree.
                    //
                    // Panics rather than propagating, which is what makes that
                    // hold in both directions. A `?` here would be swallowed by
                    // the soft-failure arm and committed, leaving the GT minted
                    // above standing for an execution that then cancels; a panic
                    // aborts the transaction, so nothing in this block outlives a
                    // failure in it. Neither call is reachable in practice:
                    // `BuilderFeeCharged::new` fails only if `Clock::get` does,
                    // and `emit_cpi` only if the self-CPI does. The point of
                    // spelling it `expect` is that a reader can see at a glance
                    // that no fallible-and-swallowed step remains past this line.
                    if let Some(charge) = &fees.builder_fee {
                        let event = BuilderFeeCharged::new(
                            order.header().store(),
                            &position.market().market_meta().market_token_mint,
                            &charge.token,
                            charge.payable_amount,
                            charge.paid_amount.into(),
                        )
                        .expect("clock is always available");
                        position
                            .event_emitter()
                            .emit_cpi(&event)
                            .expect("emitting the builder fee event must not be swallowed");
                    }

                    if let Some(amount) = next_builder_fee_amount {
                        order.set_builder_fee_amount(amount);
                    }
                }

                position.commit();
                msg!(
                    "[Position] executed with trade_id={}",
                    self.position
                        .as_ref()
                        .unwrap()
                        .load()
                        .unwrap()
                        .state
                        .trade_id
                );
                should_remove_position
            }
            _ => return err!(CoreError::UnknownOrderKind),
        };
        swap_markets.commit();
        virtual_inventories.commit();
        Ok((
            should_remove_position,
            transfer_out,
            should_send_trade_event,
        ))
    }

    fn close_position(&self) -> Result<()> {
        let Some(position) = self.position else {
            return err!(CoreError::PositionIsRequired);
        };

        let balance = position.to_account_info().lamports();

        if balance < self.refund {
            msg!(
                "Warn: not enough balance to pay the executor, balance = {}, refund = {}",
                balance,
                self.refund,
            );
        }

        let refund_to_owner = balance.saturating_sub(self.refund);
        let refund_to_executor = balance.checked_sub(refund_to_owner).expect("must success");

        // Since the order account must be mutable and is owned by the current program,
        // we use it as an intermediary to distribute funds.
        position.close(self.order.to_account_info())?;

        if refund_to_owner != 0 {
            self.order.sub_lamports(refund_to_owner)?;
            self.owner.add_lamports(refund_to_owner)?;
        }

        if refund_to_executor != 0 {
            self.order.sub_lamports(refund_to_executor)?;
            self.executor.add_lamports(refund_to_executor)?;
        }

        Ok(())
    }

    fn validate_oracle(&self) -> crate::CoreResult<()> {
        self.oracle.validate_time(self)?;
        let (kind, is_long) = {
            let order = self.order.load().map_err(|_| CoreError::LoadAccountError)?;
            (
                order
                    .params
                    .kind()
                    .map_err(|_| CoreError::InvalidArgument)?,
                order
                    .params
                    .side()
                    .map_err(|_| CoreError::InvalidArgument)?
                    .is_long(),
            )
        };
        // Validate ADL state.
        if let OrderKind::AutoDeleveraging = kind {
            let max_staleness = *self
                .store
                .load()
                .map_err(|_| CoreError::LoadAccountError)?
                .get_amount_by_key(AmountKey::AdlPricesMaxStaleness)
                .ok_or(CoreError::Unimplemented)?;
            self.market
                .load()
                .map_err(|_| CoreError::LoadAccountError)?
                .validate_adl(self.oracle, is_long, max_staleness)?;
        };
        // Validate closed state.
        if self.allow_closed {
            let store = self.store.load().map_err(|_| CoreError::LoadAccountError)?;
            self.market
                .load()
                .map_err(|_| CoreError::LoadAccountError)?
                .validate_open_or_nonstale_oracle_with_store(self.oracle, &store)?;
        }
        Ok(())
    }

    fn validate_market(&self) -> Result<()> {
        self.market
            .load()?
            .validate_with_options(&self.store.key(), self.allow_closed)?;
        Ok(())
    }

    fn validate_order(&self, should_throw_error: &mut bool, prices: &Prices<u128>) -> Result<()> {
        self.validate_non_empty_order()?;
        match self.validate_trigger_price(prices) {
            Ok(()) => Ok(()),
            Err(err) => {
                if !self.order.load()?.params.kind()?.is_market() {
                    *should_throw_error = true;
                }
                Err(err)
            }
        }
    }

    fn validate_non_empty_order(&self) -> Result<()> {
        let order = self.order.load()?;
        let params = &order.params;
        let kind = params.kind()?;

        if kind.is_increase_position() || kind.is_decrease_position() {
            // Note: Empty market decrease order is allowed so that the user
            // can claim funding rebates without modifying the position.
            require!(
                params.size_delta_value != 0
                    || params.initial_collateral_delta_amount != 0
                    || kind.is_market_decrease(),
                CoreError::EmptyOrder
            );
        } else if kind.is_swap() {
            require!(
                params.initial_collateral_delta_amount != 0,
                CoreError::EmptyOrder
            );
            require_gte!(order.swap().primary_length(), 1, {
                msg!("cannot execute a no-op swap order");
                CoreError::InvalidSwapPathLength
            });
        } else {
            unreachable!()
        }
        Ok(())
    }

    fn validate_trigger_price(&self, prices: &Prices<u128>) -> Result<()> {
        self.order
            .load()?
            .validate_trigger_price(&prices.index_token_price)
    }

    #[inline(never)]
    fn handle_executed(
        &self,
        success: bool,
        may_have_position: bool,
        has_trade_event: bool,
    ) -> Result<()> {
        match self.order.load()?.header.callback_kind()? {
            ActionCallbackKind::Disabled => {}
            ActionCallbackKind::General => {
                let authority = self.callback_authority.as_ref().ok_or_else(|| {
                    msg!("[Callback] callback is specified, but required accounts are missing");
                    error!(CoreError::InvalidArgument)
                })?;
                let program = self
                    .callback_program
                    .ok_or_else(|| error!(CoreError::InvalidArgument))?;
                let shared_data = self
                    .callback_shared_data_account
                    .ok_or_else(|| error!(CoreError::InvalidArgument))?;
                let partitioned_data = self
                    .callback_partitioned_data_account
                    .ok_or_else(|| error!(CoreError::InvalidArgument))?;
                let position = (may_have_position)
                    .then_some(())
                    .and_then(|_| self.position.as_ref().map(|p| p.as_ref()))
                    .unwrap_or(program);
                let trade_event = (has_trade_event)
                    .then_some(())
                    .and_then(|_| self.event.as_ref().map(|a| a.as_ref()))
                    .unwrap_or(program);

                self.order.load()?.header.invoke_general_callback(
                    On::Executed(ActionKind::Order, success),
                    authority,
                    program,
                    shared_data,
                    partitioned_data,
                    &self.owner,
                    self.order.as_ref(),
                    &[position.clone(), trade_event.clone()],
                )?;
            }
            kind => {
                msg!("[Callback] unsupported callback kind: {}", kind);
            }
        }
        Ok(())
    }
}

impl ValidateOracleTime for ExecuteOrderOperation<'_, '_> {
    fn oracle_updated_after(&self) -> crate::CoreResult<Option<i64>> {
        let (kind, updated_at, valid_from_ts) = {
            let order = self.order.load().map_err(|_| CoreError::LoadAccountError)?;
            (
                order
                    .params()
                    .kind()
                    .map_err(|_| CoreError::InvalidArgument)?,
                order.header.updated_at,
                order.params().valid_from_ts,
            )
        };

        match kind {
            OrderKind::MarketSwap | OrderKind::MarketIncrease => Ok(Some(updated_at)),
            OrderKind::MarketDecrease => {
                let position = self
                    .position
                    .as_ref()
                    .ok_or(CoreError::PositionIsRequired)?
                    .load()
                    .map_err(|_| CoreError::LoadAccountError)?;
                Ok(Some(updated_at.max(position.state.increased_at)))
            }
            OrderKind::LimitSwap | OrderKind::LimitIncrease => {
                Ok(Some(updated_at.max(valid_from_ts)))
            }
            OrderKind::LimitDecrease | OrderKind::StopLossDecrease => {
                let position = self
                    .position
                    .as_ref()
                    .ok_or(CoreError::PositionIsRequired)?
                    .load()
                    .map_err(|_| CoreError::LoadAccountError)?;
                let last_updated = updated_at.max(position.state.increased_at);
                Ok(Some(last_updated.max(valid_from_ts)))
            }
            OrderKind::Liquidation => {
                let position = self
                    .position
                    .as_ref()
                    .ok_or(CoreError::PositionIsRequired)?
                    .load()
                    .map_err(|_| CoreError::LoadAccountError)?;
                Ok(Some(
                    position.state.increased_at.max(position.state.decreased_at),
                ))
            }
            // Ignore the check of oracle ts for ADL orders.
            OrderKind::AutoDeleveraging => Ok(None),
            _ => Err(CoreError::UnknownOrderKind),
        }
    }

    fn oracle_updated_before(&self) -> crate::CoreResult<Option<i64>> {
        let (kind, updated_at) = {
            let order = self.order.load().map_err(|_| CoreError::LoadAccountError)?;
            (
                order
                    .params
                    .kind()
                    .map_err(|_| CoreError::InvalidArgument)?,
                order.header().updated_at,
            )
        };
        let ts = match kind {
            OrderKind::MarketSwap | OrderKind::MarketIncrease | OrderKind::MarketDecrease => {
                Some(updated_at)
            }
            _ => None,
        };
        ts.map(|ts| {
            self.store
                .load()
                .map_err(|_| CoreError::LoadAccountError)?
                .request_expiration_at(ts)
        })
        .transpose()
    }

    fn oracle_updated_after_slot(&self) -> crate::CoreResult<Option<u64>> {
        let (kind, updated_at_slot) = {
            let order = self.order.load().map_err(|_| CoreError::LoadAccountError)?;
            (
                order
                    .params
                    .kind()
                    .map_err(|_| CoreError::InvalidArgument)?,
                order.header().updated_at_slot,
            )
        };
        let after = match kind {
            OrderKind::Liquidation | OrderKind::AutoDeleveraging => None,
            _ => Some(updated_at_slot),
        };
        Ok(after)
    }
}

#[inline(never)]
/// Computes a builder fee amount, denominated in the token of `price`,
/// from `size_delta_usd` and the builder's fee `factor`.
///
/// The amount is rounded up so the fee is never under-collected. Returns
/// `0` without touching `price` if `factor` is zero, so callers don't need
/// a meaningful price when no builder fee applies.
///
/// Upholds the boundedness and isolation invariants; see the builder fee
/// invariants on [`crate::states::order`].
fn compute_builder_fee_amount(
    size_delta_usd: u128,
    factor: u128,
    price: &Price<u128>,
) -> Result<u128> {
    if factor == 0 {
        return Ok(0);
    }

    let fee_value = gmsol_model::utils::apply_factor::<_, { constants::MARKET_DECIMALS }>(
        &size_delta_usd,
        &factor,
    )
    .ok_or_else(|| error!(CoreError::TokenAmountOverflow))?;

    fee_value
        .checked_round_up_div(price.pick_price(false))
        .ok_or_else(|| error!(CoreError::TokenAmountOverflow))
}

/// Clamps a computed decrease builder fee to the outputs that fund the
/// final output token's escrow. A secondary output in another token cannot
/// cover the fee.
///
/// Upholds the coverage invariant on the decrease side: the recorded
/// amount cannot exceed the output that funds the escrow.
fn clamp_builder_fee_amount(
    fee_amount: u128,
    final_output_token: &Pubkey,
    output_amount: u64,
    secondary_output_token: &Pubkey,
    secondary_output_amount: u64,
) -> Result<u128> {
    let available_amount = if final_output_token == secondary_output_token {
        output_amount
            .checked_add(secondary_output_amount)
            .ok_or_else(|| error!(CoreError::TokenAmountOverflow))?
    } else {
        output_amount
    };
    Ok(fee_amount.min(u128::from(available_amount)))
}

/// Fold a builder fee into the amounts excluded from the increase path's market
/// balance validation, on the side the fee token belongs to.
///
/// Upholds the same property the decrease path gets for free by accumulating its
/// output transfers: every amount still due to leave the market is excluded, so
/// the balance is checked against the completed state rather than a state one
/// fee too high.
///
/// A pure market needs no special case here: `validate_market_balances` sums both
/// sides itself when `is_pure()`, so either side reaches the same total.
fn add_builder_fee_to_excluding_amounts(
    long_excluding_amount: u64,
    short_excluding_amount: u64,
    is_collateral_long: bool,
    fee_amount: u64,
) -> Result<(u64, u64)> {
    let overflow = || error!(CoreError::TokenAmountOverflow);
    if is_collateral_long {
        Ok((
            long_excluding_amount
                .checked_add(fee_amount)
                .ok_or_else(overflow)?,
            short_excluding_amount,
        ))
    } else {
        Ok((
            long_excluding_amount,
            short_excluding_amount
                .checked_add(fee_amount)
                .ok_or_else(overflow)?,
        ))
    }
}

fn execute_swap(
    should_throw_error: &mut bool,
    oracle: &Oracle,
    market: &mut RevertibleMarket<'_, '_>,
    swap_markets: &mut SwapMarkets<'_, '_>,
    transfer_out: &mut TransferOut,
    order: &Order,
) -> Result<()> {
    let swap_out_token = order
        .tokens
        .final_output_token
        .token()
        .ok_or(error!(CoreError::MissingFinalOutputToken))?;
    // Perform swap.
    let swap_out_amount = {
        let swap = &order.swap;
        let initial_collateral_token = order
            .tokens
            .initial_collateral
            .token()
            .ok_or(error!(CoreError::MissingInitialCollateralToken))?;
        let amount = order.params.initial_collateral_delta_amount;
        let (swap_out_amount, _) = swap_markets.revertible_swap(
            SwapDirection::Into(market),
            oracle,
            swap,
            (swap_out_token, swap_out_token),
            (Some(initial_collateral_token), None),
            (amount, 0),
        )?;
        swap_out_amount
    };
    if let Err(err) = order.validate_output_amount(swap_out_amount.into()) {
        if !order.params.kind()?.is_market() {
            *should_throw_error = true;
        }
        return Err(err);
    }
    transfer_out.transfer_out(false, swap_out_amount)?;
    Ok(())
}

/// Charges the builder fee against an increase order's collateral
/// increment, in the collateral token, after the pay token has already
/// been swapped into it. Returns the reduced collateral increment
/// together with the fee actually charged.
///
/// Unlike the decrease path, underpayment here is not tolerated: an
/// increase order has no equivalent of "complete the close anyway, at a
/// loss" to fall back on, so if the collateral increment can't fully
/// cover the fee, this returns an error instead of charging a partial
/// amount. The caller propagates this as a soft failure (the order is
/// cancelled), not a transaction revert.
///
/// Upholds the coverage invariant on the increase side.
fn charge_builder_fee_on_collateral_increment(
    collateral_increment_amount: u64,
    size_delta_usd: u128,
    builder_fee_factor: u128,
    collateral_price: &Price<u128>,
) -> Result<(u64, u64)> {
    let payable_amount =
        compute_builder_fee_amount(size_delta_usd, builder_fee_factor, collateral_price)?;
    let payable_amount =
        u64::try_from(payable_amount).map_err(|_| error!(CoreError::TokenAmountOverflow))?;
    require_gte!(
        collateral_increment_amount,
        payable_amount,
        CoreError::BuilderFeeExceedsCollateral
    );
    // The assertion above guarantees the subtraction succeeds.
    let collateral_increment_after_fee = collateral_increment_amount
        .checked_sub(payable_amount)
        .ok_or_else(|| error!(CoreError::TokenAmountOverflow))?;
    Ok((collateral_increment_after_fee, payable_amount))
}

#[inline(never)]
fn execute_increase_position(
    oracle: &Oracle,
    prices: Prices<u128>,
    position: &mut RevertiblePosition<'_, '_>,
    swap_markets: &mut SwapMarkets<'_, '_>,
    transfer_out: &mut TransferOut,
    event: &mut TradeData,
    order: &Order,
    builder_fee_factor: u128,
) -> Result<ExecutionFees> {
    // The builder fee is charged in the order's final output token, so for an increase order that
    // token, and therefore the escrow it is paid out of, must belong to the position's collateral
    // token. Orders created before the final output token was initialized at creation time carry
    // `None` here and are skipped, otherwise every one of them would stop executing.
    //
    // The escrow itself needs no check: the account passed to the execute instruction is
    // constrained to equal the one stored on the order, and to be the ATA of the passed final
    // output token mint. Since an ATA address determines its mint, a mismatching mint cannot get
    // this far.
    //
    // Once the builder fee lands, `set_builder_fee` is what requires the escrow to be present, so
    // that is what makes this validation run for every fee-bearing order.
    if let Some(final_output_token) = order.tokens.final_output_token.token() {
        require_keys_eq!(
            final_output_token,
            *position.collateral_token(),
            CoreError::TokenMintMismatched
        );
    }

    let params = &order.params;

    // Perform swap.
    let collateral_increment_amount = {
        let initial_collateral_token = order
            .tokens
            .initial_collateral
            .token()
            .ok_or(error!(CoreError::MissingInitialCollateralToken))?;
        let swap = &order.swap;
        let collateral_token = *position.collateral_token();
        let (collateral_increment_amount, _) = swap_markets.revertible_swap(
            SwapDirection::Into(position.market_mut()),
            oracle,
            swap,
            (collateral_token, collateral_token),
            (Some(initial_collateral_token), None),
            (params.initial_collateral_delta_amount, 0),
        )?;
        collateral_increment_amount
    };

    // Validate that the collateral amount swapped out is sufficient.
    // Here, `min_output` refers to the minimum amount of collateral tokens expected
    // after the swap.
    order.validate_output_amount(collateral_increment_amount.into())?;

    // Builder fee is charged in the collateral token, after the pay token
    // has already been swapped into it, and is deducted from
    // `collateral_increment_amount` before it is fed into
    // `position.increase()` below.
    //
    // Being withheld from the position does **not** keep it out of the
    // market's balances: the tokens arrived with the collateral and stay in
    // the market vault until settlement moves them to the order escrow. Its
    // presence in `TransferOut` is exactly why `validate_market_balances`
    // below must exclude it, not a reason it can be ignored, since those
    // arguments are the amounts still to leave. Leaving it out validates
    // against a balance higher than the completed state by the fee. The
    // decrease path folds its own transfers in the same way.
    let (collateral_increment_amount, builder_fee) = if builder_fee_factor != 0 {
        // Initializing the final output token is optional for increase
        // orders (see `CreateIncreaseOrderOperation`), so an order whose
        // creator did not opt in carries `None` here and cannot pay a fee.
        // The check at the top of this function already rejects a `Some`
        // that disagrees with the collateral token, so this is the same
        // condition stated positively, and it is what the fee branch
        // actually depends on.
        let final_output_token = order
            .tokens
            .final_output_token
            .token()
            .ok_or_else(|| error!(CoreError::BuilderFeeFinalOutputTokenMismatch))?;
        require_keys_eq!(
            final_output_token,
            *position.collateral_token(),
            CoreError::BuilderFeeFinalOutputTokenMismatch
        );

        let (collateral_increment_amount, payable_amount) =
            charge_builder_fee_on_collateral_increment(
                collateral_increment_amount,
                params.size_delta_value,
                builder_fee_factor,
                position.collateral_price(&prices),
            )?;

        // Upholds the conservation invariant. Routed into the final output
        // token escrow here, but only returned for recording: the two go
        // together, since settlement pays the recorded amount out of that
        // escrow, and `TransferOut` is discarded by the same failure that
        // must leave the record unwritten.
        transfer_out.transfer_out(false, payable_amount)?;
        if payable_amount != 0 {
            event.set_final_output_token(&final_output_token);
        }

        (
            collateral_increment_amount,
            Some(BuilderFeeCharge {
                token: *position.collateral_token(),
                payable_amount: payable_amount.into(),
                // Underpayment errors out above rather than charging a partial
                // amount, so the paid amount always equals the payable amount
                // here.
                paid_amount: payable_amount,
            }),
        )
    } else {
        (collateral_increment_amount, None)
    };

    // Increase position.
    let (long_amount, short_amount, paid_order_fee_value) = {
        let size_delta_usd = params.size_delta_value;
        let acceptable_price = params.acceptable_price;
        let report = position
            .increase(
                prices,
                collateral_increment_amount.into(),
                size_delta_usd,
                Some(acceptable_price),
            )
            .and_then(|a| a.execute())
            .map_err(ModelError::from)?;

        let (&long_amount, &short_amount) = report.claimable_funding_amounts();
        let paid_fee_value = *report.fees().paid_order_and_borrowing_fee_value();
        event.update_with_increase_report(&report)?;

        position
            .event_emitter()
            .emit_cpi(&PositionIncreased::from_report(
                position.market().rev(),
                position.market().market_meta().market_token_mint,
                report,
            ))?;
        msg!("[Position] increased");

        (long_amount, short_amount, paid_fee_value)
    };

    // Process output amount.
    transfer_out.transfer_out_funding_amounts(&long_amount, &short_amount)?;

    let mut long_excluding_amount: u64 = long_amount
        .try_into()
        .map_err(|_| error!(CoreError::TokenAmountOverflow))?;
    let mut short_excluding_amount: u64 = short_amount
        .try_into()
        .map_err(|_| error!(CoreError::TokenAmountOverflow))?;

    // The builder fee leaves the market at settlement, so it is excluded here
    // alongside the funding payouts.
    if let Some(charge) = builder_fee.as_ref() {
        let is_collateral_long = position
            .market()
            .market_meta()
            .to_token_side(&charge.token)
            .map_err(CoreError::from)?;
        (long_excluding_amount, short_excluding_amount) = add_builder_fee_to_excluding_amounts(
            long_excluding_amount,
            short_excluding_amount,
            is_collateral_long,
            charge.paid_amount,
        )?;
    }

    position
        .market()
        .validate_market_balances(long_excluding_amount, short_excluding_amount)?;

    Ok(ExecutionFees {
        paid_fee_value: paid_order_fee_value,
        builder_fee,
    })
}

/// Folds an estimate of the builder fee, denominated in the collateral
/// token, into a decrease order's collateral withdrawal amount, so it can
/// still be paid even when the position is closed at a loss. Returns the
/// withdrawal amount including the estimate.
///
/// This is only an estimate used to size how much extra collateral to
/// pull out of the position; the amount actually charged is computed
/// afterwards, in the final output token, once it's known how much of
/// that token the withdrawal (and any subsequent swap) actually produced.
///
/// Also rejects [`DecreasePositionSwapType::CollateralToPnlToken`]
/// whenever a builder fee factor is set. This is different from ordinary
/// underpayment: `NoSwap` can *sometimes* leave less in the final output
/// token bucket than the fee needs (when the pnl token differs from the
/// final output token), which is tolerated the same way any other
/// decrease-side shortfall is. `CollateralToPnlToken`, however,
/// deterministically moves the *entire* collateral-token output into the
/// pnl token before the receive-token swap even runs (see
/// `DecreasePosition::swap_collateral_token_to_pnl_token`), so the final
/// output token bucket would be zero on every single order that chooses
/// it. That's not variance, it's a guaranteed way to pay no fee at all,
/// so it isn't allowed.
///
/// The rejection is keyed off the factor rather than off the estimate
/// computed here. The estimate can round down to zero for a small
/// requested size delta, while the fee actually charged is computed on
/// the *executed* size delta, which a decrease may enlarge into a full
/// close. Gating on a non-zero estimate would therefore admit exactly
/// the orders that go on to incur a fee they can then bypass.
///
/// Upholds the isolation invariant: this is the one pre-existing line the
/// mechanism changed, and at a zero factor it returns its input unchanged
/// ahead of any arithmetic and of the swap-type check.
fn estimate_builder_fee_for_collateral_withdrawal(
    collateral_withdrawal_amount: u128,
    size_delta_usd: u128,
    builder_fee_factor: u128,
    collateral_price: &Price<u128>,
    decrease_position_swap_type: DecreasePositionSwapType,
) -> Result<u128> {
    if builder_fee_factor == 0 {
        return Ok(collateral_withdrawal_amount);
    }

    require_neq!(
        decrease_position_swap_type,
        DecreasePositionSwapType::CollateralToPnlToken,
        CoreError::BuilderFeeSwapTypeNotAllowed
    );

    let fee_estimate =
        compute_builder_fee_amount(size_delta_usd, builder_fee_factor, collateral_price)?;

    collateral_withdrawal_amount
        .checked_add(fee_estimate)
        .ok_or_else(|| error!(CoreError::TokenAmountOverflow))
}

#[allow(clippy::too_many_arguments)]
#[inline(never)]
fn execute_decrease_position(
    oracle: &Oracle,
    prices: Prices<u128>,
    position: &mut RevertiblePosition<'_, '_>,
    swap_markets: &mut SwapMarkets<'_, '_>,
    transfer_out: &mut TransferOut,
    event: &mut TradeData,
    order: &Order,
    is_insolvent_close_allowed: bool,
    secondary_order_type: Option<SecondaryOrderType>,
    builder_fee_factor: u128,
) -> Result<(RemovePosition, ExecutionFees)> {
    // Decrease position.
    let report = {
        let params = &order.params;
        let decrease_position_swap_type = params.decrease_position_swap_type()?;
        let size_delta_usd = params.size_delta_value;
        let acceptable_price = params.acceptable_price;
        // Fold an estimate of the builder fee into the collateral
        // withdrawal amount so it's still funded even if the position is
        // closed at a loss. This is only an estimate for sizing the
        // withdrawal; the amount actually charged is computed later, in
        // the final output token, once the receive-token swap has run.
        let collateral_withdrawal_amount = estimate_builder_fee_for_collateral_withdrawal(
            u128::from(params.initial_collateral_delta_amount),
            size_delta_usd,
            builder_fee_factor,
            position.collateral_price(&prices),
            decrease_position_swap_type,
        )?;
        let is_liquidation_order =
            matches!(secondary_order_type, Some(SecondaryOrderType::Liquidation));
        let is_adl_order = matches!(
            secondary_order_type,
            Some(SecondaryOrderType::AutoDeleveraging)
        );

        let is_cap_size_delta_usd_allowed = matches!(
            order.params().kind()?,
            OrderKind::LimitDecrease | OrderKind::StopLossDecrease
        );

        // Only required when the order is an ADL order.
        let mut pnl_factor_before_execution = None;

        // Validate the liquidation is a fully close.
        if is_liquidation_order {
            require_gte!(
                size_delta_usd,
                *position.size_in_usd(),
                CoreError::InvalidArgument
            );
        }

        // Validate that ADL is required.
        if is_adl_order {
            let Some(pnl_factor) = position
                .market()
                .pnl_factor_exceeded(&prices, PnlFactorKind::ForAdl, params.side()?.is_long())
                .map_err(ModelError::from)?
                .map(|exceeded| exceeded.pnl_factor)
            else {
                return err!(CoreError::AdlNotRequired);
            };
            pnl_factor_before_execution = Some(pnl_factor);
        }

        let report = position
            .decrease(
                prices,
                size_delta_usd,
                Some(acceptable_price),
                collateral_withdrawal_amount,
                DecreasePositionFlags {
                    is_insolvent_close_allowed,
                    is_liquidation_order,
                    is_cap_size_delta_usd_allowed,
                },
            )
            .map(|a| a.set_swap(decrease_position_swap_type))
            .and_then(|a| a.execute())
            .map_err(ModelError::from)?;

        // Validate that ADL is valid.
        if is_adl_order {
            let pnl_factor_after_execution = position
                .market()
                .pnl_factor(&prices, params.side()?.is_long(), true)
                .map_err(ModelError::from)?;
            require_gt!(
                pnl_factor_before_execution.expect("must be some"),
                pnl_factor_after_execution,
                CoreError::InvalidAdl
            );
            let min_pnl_factor = position
                .market()
                .pnl_factor_config(PnlFactorKind::MinAfterAdl, params.side()?.is_long())
                .and_then(|factor| factor.to_signed())
                .map_err(ModelError::from)?;
            require_gte!(
                pnl_factor_after_execution,
                min_pnl_factor,
                CoreError::InvalidAdl
            );
        }

        event.update_with_decrease_report(&report, &prices)?;
        report
    };
    let should_remove_position = report.should_remove();

    // Charged inside the swap block below, but carried out to the caller
    // rather than written to `order` or announced there: the steps that follow
    // it can still fail, the order is not revertible, and an emitted event is
    // not retractable either.
    let mut builder_fee = None;

    // Perform swaps.
    {
        require!(
            *report.secondary_output_amount() == 0
                || (report.is_output_token_long() != report.is_secondary_output_token_long()),
            CoreError::SameOutputTokensNotMerged,
        );
        let (is_output_token_long, output_amount, secondary_output_amount) = (
            report.is_output_token_long(),
            (*report.output_amount())
                .try_into()
                .map_err(|_| error!(CoreError::TokenAmountOverflow))?,
            (*report.secondary_output_amount())
                .try_into()
                .map_err(|_| error!(CoreError::TokenAmountOverflow))?,
        );

        // Swap output token to the expected output token.
        let meta = *position.market().market_meta();
        let token_ins = if is_output_token_long {
            (Some(meta.long_token_mint), Some(meta.short_token_mint))
        } else {
            (Some(meta.short_token_mint), Some(meta.long_token_mint))
        };

        // Since we have checked that secondary_amount must be zero if output_token == secondary_output_token,
        // the swap should still be correct.

        let final_output_token = order
            .tokens
            .final_output_token
            .token()
            .ok_or(error!(CoreError::MissingFinalOutputToken))?;
        let secondary_output_token = order.secondary_output_token()?;
        let swap = &order.swap;
        let (output_amount, secondary_output_amount) = swap_markets.revertible_swap(
            SwapDirection::From(position.market_mut()),
            oracle,
            swap,
            (final_output_token, secondary_output_token),
            token_ins,
            (output_amount, secondary_output_amount),
        )?;

        // Builder fee is charged in the final output token, after the
        // receive-token swap above. It is only *computed* here, never
        // netted out of `output_amount`: the full output amount is routed
        // into the final-output-token bucket as usual, so the fee value
        // physically lands in the order's escrow alongside the user's
        // payout, and settlement is what later moves the recorded amount
        // on to the builder. That matches the increase path, which
        // likewise transfers the fee into the escrow rather than leaving
        // it behind in the market vault, and it preserves the invariant
        // settlement relies on: the escrow always covers the recorded
        // amount. The collateral withdrawal was already topped up by an
        // estimate of the fee above, so the fee is funded even when the
        // position closes at a loss.
        //
        // Underpayment is tolerated (records whatever the outputs in the
        // final output token cover) rather than erroring: unlike increase,
        // this can't fall back to cancelling the order, since a decrease
        // order may be closing an insolvent position.
        //
        // A consequence of recording rather than netting: the amount
        // checked against the order's `min_output` below is the gross
        // payout, before the builder fee is settled out of the escrow.
        // Builders using `min_output` for slippage control must therefore
        // account for their own fee, since it is part of the output that
        // bound is checked against.
        if builder_fee_factor != 0 {
            let final_output_token_price = oracle.get_primary_price(&final_output_token, false)?;
            // The executed size delta, not the requested one: a decrease may
            // be enlarged into a full close, and in that case the whole
            // collateral is withdrawn, so the fee computed from the executed
            // size is still the maximum the withdrawal can support. The
            // slightly smaller estimate used to size the withdrawal above is
            // therefore not a constraint here.
            let payable_amount = compute_builder_fee_amount(
                *report.size_delta_usd(),
                builder_fee_factor,
                &final_output_token_price,
            )?;
            let paid_amount = clamp_builder_fee_amount(
                payable_amount,
                &final_output_token,
                output_amount,
                &secondary_output_token,
                secondary_output_amount,
            )?;

            // Upholds conservation and coverage: the recorded amount is the
            // clamped one, and both outputs land in the same escrow when
            // their tokens match, so the fee value is already sitting there.
            //
            // The fee is clamped to a checked u64 amount, so this conversion
            // cannot fail.
            builder_fee = Some(BuilderFeeCharge {
                token: final_output_token,
                payable_amount,
                paid_amount: u64::try_from(paid_amount)
                    .map_err(|_| error!(CoreError::TokenAmountOverflow))?,
            });
        }

        order.validate_decrease_output_amounts(
            oracle,
            &final_output_token,
            output_amount,
            &secondary_output_token,
            secondary_output_amount,
        )?;
        transfer_out.transfer_out(false, output_amount)?;
        transfer_out.transfer_out(true, secondary_output_amount)?;
        event.set_final_output_token(&final_output_token);
    }

    // Process other output amounts.
    {
        let (long_amount, short_amount) = report.claimable_funding_amounts();
        transfer_out.transfer_out_funding_amounts(long_amount, short_amount)?;
        transfer_out.process_claimable_collateral_for_decrease(&report)?;
    }

    // Validate market balances.
    let mut long_transfer_out = transfer_out.total_long_token_amount()?;
    let mut short_transfer_out = transfer_out.total_short_token_amount()?;
    let mut add_to_amount = |is_long_token: bool, amount: u64| {
        let acc = if is_long_token {
            &mut long_transfer_out
        } else {
            &mut short_transfer_out
        };
        *acc = acc
            .checked_add(amount)
            .ok_or(error!(CoreError::TokenAmountOverflow))?;
        Result::Ok(())
    };
    let current_market_token = position.market().key();
    let meta = position.market().market_meta();
    let tokens = &order.tokens;
    let output_token_market = order
        .swap
        .last_market_token(true)
        .unwrap_or(&current_market_token);
    let secondary_token_market = order
        .swap
        .last_market_token(false)
        .unwrap_or(&current_market_token);
    if transfer_out.final_output_token != 0 && *output_token_market == current_market_token {
        (add_to_amount)(
            meta.to_token_side(
                tokens
                    .final_output_token
                    .token()
                    .as_ref()
                    .ok_or(error!(CoreError::MissingFinalOutputToken))?,
            )
            .map_err(CoreError::from)?,
            transfer_out.final_output_token,
        )?;
    }
    if transfer_out.secondary_output_token != 0 && *secondary_token_market == current_market_token {
        (add_to_amount)(
            order.params.side()?.is_long(),
            transfer_out.secondary_output_token,
        )?;
    }
    position
        .market()
        .validate_market_balances(long_transfer_out, short_transfer_out)?;

    let paid_fee_value = *report.fees().paid_order_and_borrowing_fee_value();

    msg!("[Position] decreased");
    position
        .event_emitter()
        .emit_cpi(&PositionDecreased::from_report(
            position.market().rev(),
            position.market().market_meta().market_token_mint,
            report,
        ))?;

    Ok((
        should_remove_position,
        ExecutionFees {
            paid_fee_value,
            builder_fee,
        },
    ))
}

/// Position Cut Operation.
#[derive(TypedBuilder)]
pub struct PositionCutOperation<'a, 'info> {
    kind: PositionCutKind,
    #[builder(setter(
        doc = "Set the executor of this operation. CHECK: the address of the `order` must be derived from its address"
    ))]
    executor: AccountInfo<'info>,
    position: &'a AccountLoader<'info, Position>,
    event: &'a AccountLoader<'info, TradeData>,
    order: &'a AccountLoader<'info, Order>,
    market: &'a AccountLoader<'info, Market>,
    store: &'a AccountLoader<'info, Store>,
    oracle: &'a Oracle,
    owner: AccountInfo<'info>,
    user: &'a AccountLoader<'info, UserHeader>,
    nonce: &'a NonceBytes,
    order_bump: u8,
    long_token_mint: &'a Account<'info, Mint>,
    short_token_mint: &'a Account<'info, Mint>,
    long_token_account: &'a Account<'info, TokenAccount>,
    short_token_account: &'a Account<'info, TokenAccount>,
    long_token_vault: &'a Account<'info, TokenAccount>,
    short_token_vault: &'a Account<'info, TokenAccount>,
    claimable_long_token_account_for_user: AccountInfo<'info>,
    claimable_short_token_account_for_user: AccountInfo<'info>,
    claimable_pnl_token_account_for_holding: AccountInfo<'info>,
    token_program: AccountInfo<'info>,
    system_program: AccountInfo<'info>,
    refund: u64,
    should_unwrap_native_token: bool,
    allow_closed: bool,
    #[builder(setter(into))]
    event_emitter: EventEmitter<'a, 'info>,
    remaining_accounts: &'info [AccountInfo<'info>],
}

impl PositionCutOperation<'_, '_> {
    pub(crate) fn execute(self) -> Result<ShouldSendTradeEvent> {
        let (size_in_usd, is_long, is_collateral_long) = {
            let position = self.position.load()?;
            let market = self.market.load()?;
            let is_collateral_token_long = market
                .meta
                .to_token_side(&position.collateral_token)
                .map_err(CoreError::from)?;
            (
                position.state.size_in_usd,
                position.try_is_long()?,
                is_collateral_token_long,
            )
        };
        self.create_order(size_in_usd, is_long, is_collateral_long)?;
        let (is_position_removed, transfer_out, should_send_trade_event) = self.execute_order()?;
        require!(transfer_out.executed(), CoreError::Internal);
        self.order.load_mut()?.header.completed()?;
        if is_position_removed {
            msg!("[Position] the position is removed");
        } else {
            msg!(
                "[Position] the position is not removed, setting the rent receiver to the executor"
            );
            self.order
                .load_mut()?
                .header
                .set_rent_receiver(self.executor.key());
        }
        self.process_transfer_out(&transfer_out, is_long, is_collateral_long)?;
        Ok(should_send_trade_event)
    }

    #[inline(never)]
    fn create_order(
        &self,
        size_in_usd: u128,
        is_long: bool,
        is_collateral_long: bool,
    ) -> Result<()> {
        TransferExecutionFeeOperation::builder()
            .payment(self.order.to_account_info())
            .payer(self.executor.to_account_info())
            .execution_lamports(Order::MIN_EXECUTION_LAMPORTS)
            .system_program(self.system_program.to_account_info())
            .build()
            .execute()?;
        let params = CreateOrderParams {
            kind: self.kind.to_order_kind(),
            decrease_position_swap_type: Some(DecreasePositionSwapType::PnlTokenToCollateralToken),
            execution_lamports: Order::MIN_EXECUTION_LAMPORTS,
            swap_path_length: 0,
            initial_collateral_delta_amount: 0,
            size_delta_value: self.kind.size_delta_usd(size_in_usd),
            is_long,
            is_collateral_long,
            min_output: None,
            trigger_price: None,
            acceptable_price: None,
            should_unwrap_native_token: self.should_unwrap_native_token,
            valid_from_ts: None,
        };
        let output_token_account = if is_collateral_long {
            self.long_token_account
        } else {
            self.short_token_account
        };
        CreateOrderOperation::builder()
            .order(self.order.clone())
            .market(self.market.clone())
            .store(self.store.clone())
            .owner(self.owner.clone())
            .receiver(self.owner.clone())
            .creator(self.executor.clone())
            .nonce(self.nonce)
            .bump(self.order_bump)
            .params(&params)
            .swap_path(&[])
            .callback_version(None)
            .callback_authority(None)
            .callback_program(None)
            .callback_shared_data_account(None)
            .callback_partitioned_data_account(None)
            .allow_closed(self.allow_closed)
            .event_emitter(self.event_emitter)
            .build()
            .decrease()
            .position(self.position)
            .final_output_token(output_token_account)
            .long_token(self.long_token_account)
            .short_token(self.short_token_account)
            .build()
            .execute()?;
        // Make sure the discriminator is written to the account data.
        self.order.exit(&crate::ID)?;
        Ok(())
    }

    #[inline(never)]
    fn execute_order(&self) -> Result<(RemovePosition, Box<TransferOut>, ShouldSendTradeEvent)> {
        ExecuteOrderOperation::builder()
            .store(self.store)
            .market(self.market)
            .order(self.order)
            .owner(self.owner.clone())
            .user(self.user)
            .position(Some(self.position))
            .event(Some(self.event))
            .oracle(self.oracle)
            .remaining_accounts(self.remaining_accounts)
            .throw_on_execution_error(true)
            .refund(self.refund)
            .executor(self.executor.clone())
            .event_emitter(self.event_emitter)
            .callback_authority(None)
            .callback_program(None)
            .callback_shared_data_account(None)
            .callback_partitioned_data_account(None)
            .allow_closed(self.allow_closed)
            .build()
            .execute()
    }

    #[inline(never)]
    fn process_transfer_out(
        &self,
        transfer_out: &TransferOut,
        is_long: bool,
        is_collateral_long: bool,
    ) -> Result<()> {
        let (output_token, output_token_account, output_token_vault) = if is_collateral_long {
            (
                self.long_token_mint,
                self.long_token_account,
                self.long_token_vault,
            )
        } else {
            (
                self.short_token_mint,
                self.short_token_account,
                self.short_token_vault,
            )
        };
        ProcessTransferOutOperation::builder()
            .token_program(self.token_program.clone())
            .store(self.store)
            .market(self.market)
            .is_pnl_token_long_token(is_long)
            .final_output_market(self.market)
            .final_output_token(Some(output_token))
            .final_output_token_account(Some(output_token_account.to_account_info()))
            .final_output_token_vault(Some(output_token_vault))
            .long_token(Some(self.long_token_mint))
            .long_token_account(Some(self.long_token_account.to_account_info()))
            .long_token_vault(Some(self.long_token_vault))
            .short_token(Some(self.short_token_mint))
            .short_token_account(Some(self.short_token_account.to_account_info()))
            .short_token_vault(Some(self.short_token_vault))
            .claimable_long_token_account_for_user(Some(
                self.claimable_long_token_account_for_user.clone(),
            ))
            .claimable_short_token_account_for_user(Some(
                self.claimable_short_token_account_for_user.clone(),
            ))
            .claimable_pnl_token_account_for_holding(Some(
                self.claimable_pnl_token_account_for_holding.clone(),
            ))
            .transfer_out(transfer_out)
            .allow_closed(self.allow_closed)
            .event_emitter(self.event_emitter)
            .build()
            .execute()?;
        Ok(())
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn price(min: u128, max: u128) -> Price<u128> {
        Price { min, max }
    }

    #[test]
    fn zero_builder_fee_factor_yields_zero_fee_without_needing_a_price() {
        let fee = compute_builder_fee_amount(1_000_000, 0, &price(0, 0)).unwrap();
        assert_eq!(fee, 0);
    }

    #[test]
    fn computes_expected_builder_fee_amount() {
        // $100,000 size, 5 bps factor => $50 fee value, at $2/unit => 25 units.
        let size_delta_usd = 100_000 * constants::MARKET_USD_UNIT;
        let factor = constants::MARKET_USD_UNIT / 2_000; // 5 bps
        let unit_price = 2 * constants::MARKET_USD_UNIT;
        let fee =
            compute_builder_fee_amount(size_delta_usd, factor, &price(unit_price, unit_price))
                .unwrap();
        assert_eq!(fee, 25);
    }

    #[test]
    fn builder_fee_amount_rounds_up_on_remainder() {
        let size_delta_usd = 100_000 * constants::MARKET_USD_UNIT;
        let factor = constants::MARKET_USD_UNIT / 2_000; // 5 bps => $50 fee value
        let unit_price = 3 * constants::MARKET_USD_UNIT;
        let fee =
            compute_builder_fee_amount(size_delta_usd, factor, &price(unit_price, unit_price))
                .unwrap();
        // 50 / 3 = 16.67, rounded up.
        assert_eq!(fee, 17);
    }

    #[test]
    fn builder_fee_shortfall_clamps_to_available() {
        let token = Pubkey::new_unique();
        assert_eq!(
            clamp_builder_fee_amount(1_000, &token, 100, &token, 0).unwrap(),
            100
        );
    }

    #[test]
    fn builder_fee_clamps_to_zero_when_nothing_is_available() {
        let token = Pubkey::new_unique();
        assert_eq!(
            clamp_builder_fee_amount(1_000, &token, 0, &token, 0).unwrap(),
            0
        );
    }
    #[test]
    fn builder_fee_is_excluded_on_the_collateral_side() {
        // Funding payouts of 10/20 are already excluded. A 7-unit fee in the long
        // collateral token must join the long side and leave the short untouched;
        // putting it on the wrong side under-excludes the side that actually pays.
        let (long, short) = add_builder_fee_to_excluding_amounts(10, 20, true, 7).unwrap();
        assert_eq!((long, short), (17, 20));

        let (long, short) = add_builder_fee_to_excluding_amounts(10, 20, false, 7).unwrap();
        assert_eq!((long, short), (10, 27));
    }

    #[test]
    fn builder_fee_exclusion_rejects_an_overflowing_total() {
        // The exclusion is subtracted from the balance that must remain, so a
        // silent wrap would under-exclude and pass a market that is actually short.
        assert!(add_builder_fee_to_excluding_amounts(u64::MAX, 0, true, 1).is_err());
        assert!(add_builder_fee_to_excluding_amounts(0, u64::MAX, false, 1).is_err());
    }

    #[test]
    fn builder_fee_within_available_is_unchanged() {
        let token = Pubkey::new_unique();
        assert_eq!(
            clamp_builder_fee_amount(10, &token, 100, &token, 0).unwrap(),
            10
        );
    }

    #[test]
    fn decrease_builder_fee_counts_same_token_secondary_output() {
        let token = Pubkey::new_unique();
        // The primary output alone cannot cover the fee, but both outputs can.
        assert_eq!(
            clamp_builder_fee_amount(50, &token, 20, &token, 80).unwrap(),
            50
        );
    }

    #[test]
    fn decrease_builder_fee_shortfall_clamps_to_combined_outputs() {
        let token = Pubkey::new_unique();
        assert_eq!(
            clamp_builder_fee_amount(150, &token, 20, &token, 80).unwrap(),
            100
        );
    }

    #[test]
    fn decrease_builder_fee_can_be_funded_only_by_secondary_output() {
        let token = Pubkey::new_unique();
        assert_eq!(
            clamp_builder_fee_amount(50, &token, 0, &token, 80).unwrap(),
            50
        );
    }

    #[test]
    fn decrease_builder_fee_ignores_different_token_secondary_output() {
        let final_token = Pubkey::new_unique();
        let secondary_token = Pubkey::new_unique();
        // Even a maximum secondary balance cannot fund a fee in another token.
        // It must not be added to the primary amount or trigger overflow either.
        for primary_amount in [0, 20] {
            assert_eq!(
                clamp_builder_fee_amount(
                    50,
                    &final_token,
                    primary_amount,
                    &secondary_token,
                    u64::MAX,
                )
                .unwrap(),
                u128::from(primary_amount)
            );
        }
    }

    #[test]
    fn decrease_builder_fee_accepts_maximum_combined_output() {
        let token = Pubkey::new_unique();
        assert_eq!(
            clamp_builder_fee_amount(u128::MAX, &token, u64::MAX - 1, &token, 1).unwrap(),
            u128::from(u64::MAX)
        );
    }

    #[test]
    fn decrease_builder_fee_rejects_combined_output_overflow() {
        let token = Pubkey::new_unique();
        let err = clamp_builder_fee_amount(50, &token, u64::MAX, &token, 1).unwrap_err();
        assert_eq!(err, error!(CoreError::TokenAmountOverflow));
    }

    #[test]
    fn zero_builder_fee_factor_leaves_collateral_increment_unchanged() {
        let (collateral_increment_after_fee, fee) = charge_builder_fee_on_collateral_increment(
            1_000,
            100_000 * constants::MARKET_USD_UNIT,
            0,
            &price(
                2 * constants::MARKET_USD_UNIT,
                2 * constants::MARKET_USD_UNIT,
            ),
        )
        .unwrap();
        assert_eq!(fee, 0);
        assert_eq!(collateral_increment_after_fee, 1_000);
    }

    #[test]
    fn charges_expected_builder_fee_on_collateral_increment() {
        // $100,000 size, 5 bps factor => $50 fee value, at $2/unit => 25 units.
        let size_delta_usd = 100_000 * constants::MARKET_USD_UNIT;
        let factor = constants::MARKET_USD_UNIT / 2_000;
        let (collateral_increment_after_fee, fee) = charge_builder_fee_on_collateral_increment(
            1_000,
            size_delta_usd,
            factor,
            &price(
                2 * constants::MARKET_USD_UNIT,
                2 * constants::MARKET_USD_UNIT,
            ),
        )
        .unwrap();
        assert_eq!(fee, 25);
        assert_eq!(collateral_increment_after_fee, 975);
    }

    #[test]
    fn exact_builder_fee_consumes_the_whole_collateral_increment() {
        // Fee equals the entire collateral increment: allowed, leaves 0.
        let size_delta_usd = 100_000 * constants::MARKET_USD_UNIT;
        let factor = constants::MARKET_USD_UNIT / 2_000;
        let (collateral_increment_after_fee, fee) = charge_builder_fee_on_collateral_increment(
            25,
            size_delta_usd,
            factor,
            &price(
                2 * constants::MARKET_USD_UNIT,
                2 * constants::MARKET_USD_UNIT,
            ),
        )
        .unwrap();
        assert_eq!(fee, 25);
        assert_eq!(collateral_increment_after_fee, 0);
    }

    #[test]
    fn builder_fee_underpayment_errors_instead_of_clamping() {
        // Same fee value as above (25 units), but the swap only produced 10 units.
        let size_delta_usd = 100_000 * constants::MARKET_USD_UNIT;
        let factor = constants::MARKET_USD_UNIT / 2_000;
        let err = charge_builder_fee_on_collateral_increment(
            10,
            size_delta_usd,
            factor,
            &price(
                2 * constants::MARKET_USD_UNIT,
                2 * constants::MARKET_USD_UNIT,
            ),
        )
        .unwrap_err();
        assert_eq!(err, error!(CoreError::BuilderFeeExceedsCollateral));
    }

    #[test]
    fn zero_builder_fee_factor_leaves_withdrawal_amount_unchanged() {
        let withdrawal_amount = estimate_builder_fee_for_collateral_withdrawal(
            1_000,
            100_000 * constants::MARKET_USD_UNIT,
            0,
            &price(
                2 * constants::MARKET_USD_UNIT,
                2 * constants::MARKET_USD_UNIT,
            ),
            DecreasePositionSwapType::NoSwap,
        )
        .unwrap();
        assert_eq!(withdrawal_amount, 1_000);
    }

    #[test]
    fn tops_up_withdrawal_amount_by_builder_fee_estimate() {
        // $100,000 size, 5 bps factor => $50 fee value, at $2/unit => 25 units.
        let size_delta_usd = 100_000 * constants::MARKET_USD_UNIT;
        let factor = constants::MARKET_USD_UNIT / 2_000;
        let withdrawal_amount = estimate_builder_fee_for_collateral_withdrawal(
            1_000,
            size_delta_usd,
            factor,
            &price(
                2 * constants::MARKET_USD_UNIT,
                2 * constants::MARKET_USD_UNIT,
            ),
            DecreasePositionSwapType::PnlTokenToCollateralToken,
        )
        .unwrap();
        // The withdrawal amount grows by the estimate; it is not subtracted.
        assert_eq!(withdrawal_amount, 1_025);
    }

    #[test]
    fn no_swap_is_allowed_with_a_non_zero_builder_fee() {
        let size_delta_usd = 100_000 * constants::MARKET_USD_UNIT;
        let factor = constants::MARKET_USD_UNIT / 2_000;
        let result = estimate_builder_fee_for_collateral_withdrawal(
            1_000,
            size_delta_usd,
            factor,
            &price(
                2 * constants::MARKET_USD_UNIT,
                2 * constants::MARKET_USD_UNIT,
            ),
            DecreasePositionSwapType::NoSwap,
        );
        assert!(result.is_ok());
    }

    #[test]
    fn collateral_to_pnl_token_is_rejected_with_a_non_zero_builder_fee() {
        let size_delta_usd = 100_000 * constants::MARKET_USD_UNIT;
        let factor = constants::MARKET_USD_UNIT / 2_000;
        let result = estimate_builder_fee_for_collateral_withdrawal(
            1_000,
            size_delta_usd,
            factor,
            &price(
                2 * constants::MARKET_USD_UNIT,
                2 * constants::MARKET_USD_UNIT,
            ),
            DecreasePositionSwapType::CollateralToPnlToken,
        );
        assert!(result.is_err());
    }

    #[test]
    fn collateral_to_pnl_token_is_rejected_when_the_fee_estimate_rounds_to_zero() {
        // A dust size delta, whose fee value truncates to zero, while the
        // factor is still set: the executed size delta may be enlarged
        // into a full close and incur a real fee, so the swap type must
        // already have been rejected by then.
        let size_delta_usd = 1_000;
        let factor = constants::MARKET_USD_UNIT / 2_000;
        let result = estimate_builder_fee_for_collateral_withdrawal(
            1_000,
            size_delta_usd,
            factor,
            &price(
                2 * constants::MARKET_USD_UNIT,
                2 * constants::MARKET_USD_UNIT,
            ),
            DecreasePositionSwapType::CollateralToPnlToken,
        );
        assert_eq!(
            result.unwrap_err(),
            error!(CoreError::BuilderFeeSwapTypeNotAllowed)
        );
    }

    #[test]
    fn collateral_to_pnl_token_is_allowed_when_builder_fee_is_zero() {
        let result = estimate_builder_fee_for_collateral_withdrawal(
            1_000,
            100_000 * constants::MARKET_USD_UNIT,
            0,
            &price(
                2 * constants::MARKET_USD_UNIT,
                2 * constants::MARKET_USD_UNIT,
            ),
            DecreasePositionSwapType::CollateralToPnlToken,
        );
        assert!(result.is_ok());
    }
}
