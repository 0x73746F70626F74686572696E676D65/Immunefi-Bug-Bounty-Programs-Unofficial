module.exports = {
  skipFiles: ['test'],
};
