const sdk = require("@defillama/sdk");
const utils = require('../helper/utils');
const { unwrapUniswapLPs } = require("../helper/unwrapLPs");
const abi = require("./abi.json");

const url = 'https://api.marsecosystem.com/api/pools';

async function tvl(timestamp, chainBlocks) {
  const rows = (await utils.fetchURL(url)).data;
  const localPools = rows.filter(v => v.masterChef.includes('LiquidityMiningMaster') && !(v.baseToken == 'xms' && v.quoteToken == 'xms' ));
  const remotePools = rows.filter(v => v.masterChef.includes('MarsFarmV2') && !(v.baseToken == 'xms' && v.quoteToken == 'xms' ));
  return await calculate(chainBlocks, localPools, remotePools);
};

async function staking(timstamp, chainBlocks) {
  const balances = {};
  const rows = (await utils.fetchURL(url)).data;
  const localPools = rows.filter(v => v.masterChef.includes('LiquidityMiningMaster') && v.baseToken == 'xms' && v.quoteToken == 'xms');
  const remotePools = rows.filter(v => v.masterChef.includes('MarsFarmV2') && v.baseToken == 'xms' && v.quoteToken == 'xms');

  if (localPools.length > 0) {
    const localPoolsBalances = (
      await sdk.api.abi.multiCall({
        block: chainBlocks["bsc"],
        calls: localPools.map(v => ({ target: v.masterChefAddress })),
        abi: abi.totalSupply,
        chain: "bsc",
      })
    ).output.map(v => v.output);

    localPools.forEach((v, i) => {
      sdk.util.sumSingleBalance(
        balances,
        `bsc:${v.address.toLowerCase()}`,
        localPoolsBalances[i]
      );
    });
  }

  if (remotePools.length > 0) {
    const remotePoolsBalances = (
      await sdk.api.abi.multiCall({
        block: chainBlocks["bsc"],
        calls: remotePools.map(v => ({ target: v.masterChefAddress, params: [ v.pid ] })),
        abi: abi.sharesTotal,
        chain: "bsc",
      })
    ).output.map(v => v.output);

    localPools.forEach((v, i) => {
      sdk.util.sumSingleBalance(
        balances,
        `bsc:${v.address.toLowerCase()}`,
        remotePoolsBalances[i]
      );
    });
  }

  return balances;
};

async function calculate(chainBlocks, localPools, remotePools) {
  const balances = {};

  const localPoolsBalances = (
    await sdk.api.abi.multiCall({
      block: chainBlocks["bsc"],
      calls: localPools.map(v => ({ target: v.address, params: v.masterChefAddress })),
      abi: 'erc20:balanceOf',
      chain: "bsc",
    })
  ).output.map(v => v.output);

  const lpPositions = [];

  localPools.forEach((v, i) => {
    if (v.baseToken == v.quoteToken) {
      sdk.util.sumSingleBalance(
        balances,
        `bsc:${v.address.toLowerCase()}`,
        localPoolsBalances[i]
      );
    } else {
      lpPositions.push({
        token: v.address.toLowerCase(),
        balance: localPoolsBalances[i]
      });
    }
  });

  const remotePoolsBalances = (
    await sdk.api.abi.multiCall({
      block: chainBlocks["bsc"],
      calls: remotePools.map(v => ({ target: v.masterChefAddress, params: [ v.pid ] })),
      abi: abi.sharesTotal,
      chain: "bsc",
    })
  ).output.map(v => v.output);

  remotePools.forEach((v, i) => {
    if (v.baseToken == v.quoteToken) {
      sdk.util.sumSingleBalance(
        balances,
        `bsc:${v.address.toLowerCase()}`,
        remotePoolsBalances[i]
      );
    } else {
      lpPositions.push({
        token: v.address.toLowerCase(),
        balance: remotePoolsBalances[i]
      });
    }
  });

  await unwrapUniswapLPs(
    balances,
    lpPositions,
    chainBlocks["bsc"],
    "bsc",
    (addr) => `bsc:${addr.toLowerCase()}`
  );

  return balances;
}

module.exports = {
  bsc: {
    tvl,
    staking,
    masterchef: tvl,
  }
};
