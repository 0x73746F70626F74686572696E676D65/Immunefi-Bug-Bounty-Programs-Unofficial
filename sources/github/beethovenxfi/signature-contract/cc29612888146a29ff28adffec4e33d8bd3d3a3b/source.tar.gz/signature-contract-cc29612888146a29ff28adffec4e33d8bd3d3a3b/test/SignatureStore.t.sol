// SPDX-License-Identifier: MIT
pragma solidity ^0.8.13;

import {Test} from "forge-std/Test.sol";
import {SignatureStore} from "../src/SignatureStore.sol";

contract SignatureStoreTest is Test {
    SignatureStore public store;
    bytes32 public constant MESSAGE = keccak256("I agree to the terms");

    uint256 public aliceKey = 0x1234;
    uint256 public bobKey = 0x5678;
    address public alice;
    address public bob;

    function setUp() public {
        store = new SignatureStore(MESSAGE);
        alice = vm.addr(aliceKey);
        bob = vm.addr(bobKey);
    }

    function _signMessage(uint256 privateKey) internal view returns (bytes memory) {
        bytes32 ethSignedHash = keccak256(
            abi.encodePacked("\x19Ethereum Signed Message:\n32", MESSAGE)
        );
        (uint8 v, bytes32 r, bytes32 s) = vm.sign(privateKey, ethSignedHash);
        return abi.encodePacked(r, s, v);
    }

    function test_InitialState() public view {
        assertEq(store.signatureCount(), 0);
        assertFalse(store.hasSigned(alice));
        assertEq(store.message(), MESSAGE);
    }

    function test_Sign() public {
        bytes memory signature = _signMessage(aliceKey);

        vm.prank(alice);
        store.sign(signature);

        assertTrue(store.hasSigned(alice));
        assertEq(store.signatures(alice), signature);
        assertEq(store.signatureCount(), 1);
    }

    function test_MultipleSigners() public {
        bytes memory aliceSig = _signMessage(aliceKey);
        bytes memory bobSig = _signMessage(bobKey);

        vm.prank(alice);
        store.sign(aliceSig);

        vm.prank(bob);
        store.sign(bobSig);

        assertTrue(store.hasSigned(alice));
        assertTrue(store.hasSigned(bob));
        assertEq(store.signatureCount(), 2);
    }

    function test_RevertWhenAlreadySigned() public {
        bytes memory signature = _signMessage(aliceKey);

        vm.prank(alice);
        store.sign(signature);

        vm.prank(alice);
        vm.expectRevert(SignatureStore.AlreadySigned.selector);
        store.sign(signature);
    }

    function test_RevertWhenInvalidSignature() public {
        bytes memory bobSig = _signMessage(bobKey);

        vm.prank(alice);
        vm.expectRevert(SignatureStore.InvalidSignature.selector);
        store.sign(bobSig);
    }

    function test_RevertWhenInvalidSignatureLength() public {
        bytes memory badSig = hex"1234";

        vm.prank(alice);
        vm.expectRevert(SignatureStore.InvalidSignatureLength.selector);
        store.sign(badSig);
    }

    function test_SignEmitsEvent() public {
        bytes memory signature = _signMessage(aliceKey);

        vm.prank(alice);
        vm.expectEmit(true, false, false, true);
        emit SignatureStore.Signed(alice, signature);
        store.sign(signature);
    }
}
