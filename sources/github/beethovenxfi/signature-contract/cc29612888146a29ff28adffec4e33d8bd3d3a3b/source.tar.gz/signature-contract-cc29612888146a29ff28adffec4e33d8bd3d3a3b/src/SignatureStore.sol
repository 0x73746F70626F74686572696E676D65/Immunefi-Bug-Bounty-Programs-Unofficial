// SPDX-License-Identifier: MIT
pragma solidity ^0.8.13;

contract SignatureStore {
    error AlreadySigned();
    error InvalidSignatureLength();
    error InvalidSignature();

    mapping(address => bytes) public signatures;
    uint256 public signatureCount;
    bytes32 public immutable message;

    event Signed(address indexed signer, bytes signature);

    constructor(bytes32 _message) {
        message = _message;
    }

    function sign(bytes calldata signature) external {
        require(signatures[msg.sender].length == 0, AlreadySigned());
        require(signature.length == 65, InvalidSignatureLength());

        bytes32 ethSignedHash = keccak256(
            abi.encodePacked("\x19Ethereum Signed Message:\n32", message)
        );

        bytes32 r;
        bytes32 s;
        uint8 v;

        assembly {
            r := calldataload(signature.offset)
            s := calldataload(add(signature.offset, 32))
            v := byte(0, calldataload(add(signature.offset, 64)))
        }

        address signer = ecrecover(ethSignedHash, v, r, s);
        require(signer == msg.sender, InvalidSignature());

        signatures[msg.sender] = signature;
        signatureCount++;

        emit Signed(msg.sender, signature);
    }

    function hasSigned(address signer) external view returns (bool) {
        return signatures[signer].length > 0;
    }
}
