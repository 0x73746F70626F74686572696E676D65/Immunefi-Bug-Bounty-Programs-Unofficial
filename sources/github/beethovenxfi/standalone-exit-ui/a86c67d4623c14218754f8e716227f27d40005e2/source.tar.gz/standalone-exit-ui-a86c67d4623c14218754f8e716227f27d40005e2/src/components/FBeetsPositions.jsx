import { useState, useEffect } from 'react';
import * as fbeetsUtils from '../utils/fbeets';

export function FBeetsPositions({ provider, signer, account }) {
  const [balance, setBalance] = useState('0');
  const [loading, setLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState(false);
  const [error, setError] = useState(null);

  useEffect(() => {
    loadBalance();
  }, [account]);

  const loadBalance = async () => {
    if (!provider || !account) return;

    console.log('[FBeetsPositions] Loading fBEETS balance');
    setLoading(true);
    setError(null);

    try {
      const bal = await fbeetsUtils.getFBeetsBalance(provider, account);
      console.log('[FBeetsPositions] ✅ Balance loaded');
      setBalance(bal);
    } catch (err) {
      console.error('[FBeetsPositions] ❌ Error loading fBEETS balance:', err);
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleExit = async () => {
    console.log('═══════════════════════════════════════════════');
    console.log('[FBeetsPositions] 🔘 Exit button clicked');
    console.log('[FBeetsPositions] Signer available:', !!signer);
    console.log('[FBeetsPositions] Balance:', balance);

    if (!signer) {
      console.error('[FBeetsPositions] ❌ No signer available');
      alert('Please connect your wallet first');
      return;
    }

    const confirmed = window.confirm(
      `Exit ${balance} fBEETS?\n\nThis will convert your fBEETS back to BEETS.`
    );

    if (!confirmed) {
      console.log('[FBeetsPositions] User cancelled exit');
      return;
    }

    setActionLoading(true);
    try {
      console.log('[FBeetsPositions] Starting fBEETS exit...');
      await fbeetsUtils.exitFBeets(signer, balance);
      console.log('[FBeetsPositions] ✅ fBEETS exit successful');
      alert('Successfully exited fBEETS!');
      await loadBalance();
    } catch (err) {
      console.error('[FBeetsPositions] ❌ fBEETS exit failed:', err);
      alert(`Error exiting fBEETS: ${err.message}`);
    } finally {
      setActionLoading(false);
    }
  };

  if (loading) {
    return (
      <div style={{ padding: '15px', border: '1px solid #ccc', borderRadius: '4px' }}>
        <h4>Legacy fBEETS</h4>
        <p>Loading...</p>
      </div>
    );
  }

  if (parseFloat(balance) === 0) {
    return (
      <div style={{ padding: '15px', border: '1px solid #ccc', borderRadius: '4px' }}>
        <h4>Legacy fBEETS</h4>
        <p>No fBEETS balance found.</p>
      </div>
    );
  }

  return (
    <div style={{ padding: '15px', border: '1px solid #ccc', borderRadius: '4px' }}>
      <h4>Legacy fBEETS</h4>

      {error && <div style={{ color: 'red', marginBottom: '10px' }}>Error: {error}</div>}

      <div style={{ padding: '10px', backgroundColor: '#f9f9f9', borderRadius: '4px' }}>
        <p>fBEETS Balance: {parseFloat(balance).toFixed(6)}</p>

        <div style={{ marginTop: '10px' }}>
          <button
            onClick={handleExit}
            disabled={actionLoading || parseFloat(balance) === 0}
            style={{
              padding: '8px 16px',
              cursor: actionLoading || parseFloat(balance) === 0 ? 'not-allowed' : 'pointer',
              backgroundColor: '#f44336',
              color: 'white',
              border: 'none',
              borderRadius: '4px',
            }}
          >
            {actionLoading ? 'Exiting...' : 'Exit fBEETS'}
          </button>
        </div>
      </div>
    </div>
  );
}
