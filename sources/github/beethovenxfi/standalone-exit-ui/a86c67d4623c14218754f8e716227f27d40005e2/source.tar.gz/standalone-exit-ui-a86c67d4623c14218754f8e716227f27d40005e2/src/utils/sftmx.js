import { ethers } from 'ethers';
import { CONTRACTS } from '../config/contracts';
import SftmxStakingAbi from '../abis/FTMStaking.json';
import ERC20Abi from '../abis/ERC20.json';

/**
 * Get user's sftmx balance
 */
export async function getSftmxBalance(provider, userAddress) {
    console.log('[sftmx] Getting sftmx balance for user:', userAddress);
    const contract = new ethers.Contract(CONTRACTS.sftmx, ERC20Abi, provider);

    try {
        const balance = await contract.balanceOf(userAddress);
        const formatted = ethers.utils.formatEther(balance);
        console.log('[sftmx] Balance:', formatted, 'sftmx');
        return formatted;
    } catch (error) {
        console.error('[sftmx] ❌ Error fetching sftmx balance:', error);
        return '0';
    }
}

/**
 * Unstake sftmx (start the withdrawal process)
 * Returns the withdrawal request ID
 */
export async function unstakeSftmx(signer, amount, withdrawalId) {
    console.log('[sftmx] Starting unstake for', amount, 'sftmx with withdrawal ID:', withdrawalId);
    const contract = new ethers.Contract(CONTRACTS.sftmxStaking, SftmxStakingAbi, signer);

    try {
        const amountWei = ethers.utils.parseEther(amount);

        // Get the current exchange rate from sftmx to FTM
        console.log('[sftmx] Fetching exchange rate...');
        const exchangeRate = await contract.getExchangeRate();
        console.log('[sftmx] Exchange rate:', ethers.utils.formatEther(exchangeRate));

        // Calculate minAmountFTM: amountWei * exchangeRate / 1e18
        const minAmountFTM = amountWei.mul(exchangeRate).div(ethers.constants.WeiPerEther);

        console.log('[sftmx] Submitting undelegate transaction with ID:', withdrawalId);
        console.log(
            '[sftmx] Parameters: wrID=%s, amountFTMx=%s, minAmountFTM=%s',
            withdrawalId,
            amountWei.toString(),
            minAmountFTM.toString(),
        );
        const tx = await contract.undelegate(withdrawalId, amountWei, minAmountFTM);
        console.log('[sftmx] Transaction submitted:', tx.hash);
        console.log('[sftmx] Waiting for confirmation...');
        const receipt = await tx.wait();
        console.log('[sftmx] ✅ Unstake confirmed in block:', receipt.blockNumber);
        console.log('[sftmx] ✅ Withdrawal ID:', withdrawalId);

        return {
            withdrawalId: withdrawalId.toString(),
            receipt,
        };
    } catch (error) {
        console.error('[sftmx] ❌ Error unstaking sftmx:', error);
        throw error;
    }
}

/**
 * Complete withdrawal after the 24hr delay
 */
export async function withdrawSftmx(signer, withdrawalId) {
    console.log('[sftmx] Completing withdrawal for ID:', withdrawalId);
    const contract = new ethers.Contract(CONTRACTS.sftmxStaking, SftmxStakingAbi, signer);

    try {
        // bitmaskToSkip: set to 0 to not skip any vaults
        const bitmaskToSkip = 0;

        console.log('[sftmx] Submitting withdraw transaction...');
        console.log('[sftmx] Parameters: wrID=%s, bitmaskToSkip=%s', withdrawalId, bitmaskToSkip);
        const tx = await contract.withdraw(withdrawalId, bitmaskToSkip);
        console.log('[sftmx] Transaction submitted:', tx.hash);
        console.log('[sftmx] Waiting for confirmation...');
        const receipt = await tx.wait();
        console.log('[sftmx] ✅ Withdrawal confirmed in block:', receipt.blockNumber);
        return receipt;
    } catch (error) {
        console.error('[sftmx] ❌ Error withdrawing sftmx:', error);
        throw error;
    }
}

/**
 * Get withdrawal requests for a user
 */
export async function getWithdrawalRequests(provider, userAddress) {
    const contract = new ethers.Contract(CONTRACTS.sftmxStaking, SftmxStakingAbi, provider);

    try {
        // This function signature may vary - check the actual ABI
        const requests = await contract.getWithdrawalRequests(userAddress);
        return requests;
    } catch (error) {
        console.error('Error fetching withdrawal requests:', error);
        return [];
    }
}

/**
 * Check if a withdrawal is ready (24hr period passed)
 */
export async function isWithdrawalReady(provider, withdrawalId) {
    const contract = new ethers.Contract(CONTRACTS.sftmxStaking, SftmxStakingAbi, provider);

    try {
        // Implementation depends on the contract
        // May need to check the withdrawal request timestamp
        const request = await contract.withdrawalRequests(withdrawalId);

        if (!request) return false;

        const currentBlock = await provider.getBlock('latest');
        const currentTime = currentBlock.timestamp;
        const withdrawalTime = request.requestTime || request.timestamp;

        // 24 hours = 86400 seconds
        return currentTime >= withdrawalTime + 86400;
    } catch (error) {
        console.error('Error checking withdrawal ready status:', error);
        return false;
    }
}

/**
 * Check and approve sftmx spending if needed
 */
export async function approveSftmx(signer) {
    console.log('[sftmx] Approving sftmx for staking contract');
    const contract = new ethers.Contract(CONTRACTS.sftmx, ERC20Abi, signer);

    try {
        console.log('[sftmx] Submitting approval transaction...');
        const tx = await contract.approve(CONTRACTS.sftmxStaking, ethers.constants.MaxUint256);
        console.log('[sftmx] Transaction submitted:', tx.hash);
        console.log('[sftmx] Waiting for confirmation...');
        const receipt = await tx.wait();
        console.log('[sftmx] ✅ Approval confirmed in block:', receipt.blockNumber);
        return receipt;
    } catch (error) {
        console.error('[sftmx] ❌ Error approving sftmx:', error);
        throw error;
    }
}
