import { ethers } from 'ethers';
import { CONTRACTS } from '../config/contracts';
import VaultAbi from '../abis/Vault.json';
import ERC20Abi from '../abis/ERC20.json';

/**
 * Get user's BPT (pool token) balance
 */
export async function getPoolTokenBalance(provider, poolAddress, userAddress) {
    console.log('[Pool] Getting BPT balance for pool:', poolAddress);
    const contract = new ethers.Contract(poolAddress, ERC20Abi, provider);

    try {
        const balance = await contract.balanceOf(userAddress);
        const formatted = ethers.utils.formatEther(balance);
        console.log('[Pool] BPT balance:', formatted);
        return formatted;
    } catch (error) {
        console.error('[Pool] ❌ Error fetching pool token balance:', error);
        return '0';
    }
}

/**
 * Get pool ID from pool address by querying the pool contract
 */
export async function getPoolId(provider, poolAddress) {
    console.log('[Pool] Getting pool ID from pool contract:', poolAddress);
    try {
        // Most Balancer pools have a getPoolId() function
        const poolContract = new ethers.Contract(
            poolAddress,
            ['function getPoolId() view returns (bytes32)'],
            provider,
        );

        const poolId = await poolContract.getPoolId();
        console.log('[Pool] ✅ Pool ID:', poolId);
        return poolId;
    } catch (error) {
        console.error('[Pool] ❌ Error fetching pool ID:', error);
        return null;
    }
}

/**
 * Get pool tokens from Vault
 */
export async function getPoolTokens(provider, poolId) {
    console.log('[Pool] Getting pool tokens from Vault for pool:', poolId);
    const vaultContract = new ethers.Contract(CONTRACTS.vault, VaultAbi, provider);

    try {
        const result = await vaultContract.getPoolTokens(poolId);
        // Returns: tokens[], balances[], lastChangeBlock
        const tokens = {
            tokens: result.tokens,
            balances: result.balances.map((b) => ethers.utils.formatEther(b)),
        };
        console.log('[Pool] ✅ Pool has', tokens.tokens.length, 'tokens:', tokens.tokens);
        return tokens;
    } catch (error) {
        console.error('[Pool] ❌ Error fetching pool tokens:', error);
        return null;
    }
}

/**
 * Exit pool proportionally (get all tokens back proportionally)
 * 
 * Regular pools use ExitKind 1 (EXACT_BPT_IN_FOR_TOKENS_OUT)
 * Composable Stable Pools use ExitKind 2 (EXACT_BPT_IN_FOR_ALL_TOKENS_OUT)
 * 
 * Note: For Composable Stable Pools, include the pool's BPT in both assets and 
 * minAmountsOut arrays (with 0 at BPT position), but the BPT amount is not 
 * included in the userData encoding.
 */
export async function exitPoolProportional(signer, poolId, poolAddress, bptAmount, provider) {
    console.log('[Pool] Exiting pool proportionally with', bptAmount, 'BPT');
    const vaultContract = new ethers.Contract(CONTRACTS.vault, VaultAbi, signer);
    const userAddress = await signer.getAddress();

    try {
        // Get pool tokens to know what we're exiting to
        console.log('[Pool] Fetching pool composition...');
        const poolTokens = await getPoolTokens(provider, poolId);

        if (!poolTokens) {
            throw new Error('Could not fetch pool tokens');
        }

        const bptAmountWei = ethers.utils.parseEther(bptAmount);

        // Normalize addresses for comparison (lowercase)
        const normalizedPoolAddress = poolAddress.toLowerCase();
        
        // Check if this is a composable pool (contains its own BPT)
        const bptIndex = poolTokens.tokens.findIndex(
            token => token.toLowerCase() === normalizedPoolAddress
        );
        const isComposablePool = bptIndex !== -1;
        
        // For Composable Stable Pools, include BPT in both arrays but userData doesn't include it
        let exitAssets;
        let minAmountsOut;
        let exitKind;
        let userData;
        
        if (isComposablePool) {
            console.log('[Pool] ⚠️ Detected Composable Stable Pool (contains own BPT)');
            console.log('[Pool] BPT token at index:', bptIndex);
            console.log('[Pool] Total tokens:', poolTokens.tokens.length);
            
            // For ComposableStablePool: Include ALL tokens (including BPT)
            exitAssets = poolTokens.tokens;
            // minAmountsOut includes all positions (including BPT position as 0)
            minAmountsOut = poolTokens.tokens.map(() => 0);
            
            // For ComposableStablePool: ExitKind 2 = EXACT_BPT_IN_FOR_ALL_TOKENS_OUT
            exitKind = 2;
            userData = ethers.utils.defaultAbiCoder.encode(['uint256', 'uint256'], [exitKind, bptAmountWei]);
            
            console.log('[Pool] Exit assets (including BPT):', exitAssets.length);
            console.log('[Pool] minAmountsOut length:', minAmountsOut.length);
            console.log('[Pool] Exit kind: 2 (EXACT_BPT_IN_FOR_ALL_TOKENS_OUT)');
        } else {
            exitAssets = poolTokens.tokens;
            minAmountsOut = poolTokens.tokens.map(() => 0);
            
            // For regular pools: ExitKind 1 = EXACT_BPT_IN_FOR_TOKENS_OUT
            exitKind = 1;
            userData = ethers.utils.defaultAbiCoder.encode(['uint256', 'uint256'], [exitKind, bptAmountWei]);
            
            console.log('[Pool] Exit kind: 1 (EXACT_BPT_IN_FOR_TOKENS_OUT)');
        }

        const exitRequest = {
            assets: exitAssets,
            minAmountsOut: minAmountsOut,
            userData: userData,
            toInternalBalance: false,
        };

        console.log('[Pool] Submitting exit transaction...');
        console.log('[Pool] Exit kind: EXACT_BPT_IN_FOR_TOKENS_OUT (proportional)');
        console.log('[Pool] Assets count:', exitRequest.assets.length);
        console.log('[Pool] MinAmountsOut count:', exitRequest.minAmountsOut.length);
        const tx = await vaultContract.exitPool(poolId, userAddress, userAddress, exitRequest);

        console.log('[Pool] Transaction submitted:', tx.hash);
        console.log('[Pool] Waiting for confirmation...');
        const receipt = await tx.wait();
        console.log('[Pool] ✅ Exit confirmed in block:', receipt.blockNumber);
        return receipt;
    } catch (error) {
        console.error('[Pool] ❌ Error exiting pool:', error);
        throw error;
    }
}

/**
 * Check if user needs to approve BPT spending
 */
export async function checkApproval(provider, poolAddress, userAddress, spender) {
    const contract = new ethers.Contract(poolAddress, ERC20Abi, provider);

    try {
        const allowance = await contract.allowance(userAddress, spender);
        return allowance;
    } catch (error) {
        console.error('Error checking approval:', error);
        return ethers.constants.Zero;
    }
}

/**
 * Approve BPT spending
 */
export async function approveToken(signer, tokenAddress, spender) {
    console.log('[Pool] Approving token:', tokenAddress, 'for spender:', spender);
    const contract = new ethers.Contract(tokenAddress, ERC20Abi, signer);

    try {
        console.log('[Pool] Submitting approval transaction...');
        const tx = await contract.approve(spender, ethers.constants.MaxUint256);
        console.log('[Pool] Transaction submitted:', tx.hash);
        console.log('[Pool] Waiting for confirmation...');
        const receipt = await tx.wait();
        console.log('[Pool] ✅ Approval confirmed in block:', receipt.blockNumber);
        return receipt;
    } catch (error) {
        console.error('[Pool] ❌ Error approving token:', error);
        throw error;
    }
}
