import { useState } from 'react';
import { useWalletContext } from '../contexts/WalletContext';
import { useRpcContext } from '../contexts/RpcContext';

export function WalletConnect() {
  const { account, connect, disconnect, isConnecting, error, isConnected } = useWalletContext();
  const { rpcUrl, updateRpcUrl, resetToDefault, isCustomRpc, defaultRpcUrl } = useRpcContext();
  const [rpcInput, setRpcInput] = useState(rpcUrl);
  const [showRpcSettings, setShowRpcSettings] = useState(false);

  const handleRpcUpdate = () => {
    if (rpcInput && rpcInput.trim()) {
      updateRpcUrl(rpcInput.trim());
      setShowRpcSettings(false);
    }
  };

  const handleRpcReset = () => {
    resetToDefault();
    setRpcInput(defaultRpcUrl);
  };

  return (
    <div style={{ padding: '20px', borderBottom: '1px solid #ccc' }}>
      <h2>Beethoven X - Fantom Exit UI</h2>

      {/* RPC Configuration */}
      <div style={{ marginBottom: '20px' }}>
        <div style={{ marginBottom: '10px' }}>
          <button
            onClick={() => setShowRpcSettings(!showRpcSettings)}
            style={{
              padding: '6px 12px',
              fontSize: '14px',
              cursor: 'pointer',
              backgroundColor: '#2196F3',
              color: 'white',
              border: 'none',
              borderRadius: '4px',
              marginRight: '10px',
            }}
          >
            {showRpcSettings ? 'Hide' : 'Configure'} RPC
          </button>
          {isCustomRpc && (
            <span style={{ 
              fontSize: '12px', 
              color: '#4CAF50', 
              fontWeight: 'bold' 
            }}>
              ● Using Custom RPC
            </span>
          )}
        </div>

        {showRpcSettings && (
          <div style={{
            backgroundColor: '#f5f5f5',
            padding: '15px',
            borderRadius: '4px',
            marginBottom: '10px',
          }}>
            <div style={{ marginBottom: '10px' }}>
              <label style={{ display: 'block', marginBottom: '5px', fontWeight: 'bold' }}>
                RPC URL:
              </label>
              <input
                type="text"
                value={rpcInput}
                onChange={(e) => setRpcInput(e.target.value)}
                placeholder="https://your-rpc-url.com"
                style={{
                  width: '100%',
                  padding: '8px',
                  fontSize: '14px',
                  border: '1px solid #ccc',
                  borderRadius: '4px',
                  boxSizing: 'border-box',
                }}
              />
            </div>
            <div style={{ display: 'flex', gap: '10px' }}>
              <button
                onClick={handleRpcUpdate}
                style={{
                  padding: '6px 12px',
                  fontSize: '14px',
                  cursor: 'pointer',
                  backgroundColor: '#4CAF50',
                  color: 'white',
                  border: 'none',
                  borderRadius: '4px',
                }}
              >
                Apply
              </button>
              <button
                onClick={handleRpcReset}
                style={{
                  padding: '6px 12px',
                  fontSize: '14px',
                  cursor: 'pointer',
                  backgroundColor: '#ff9800',
                  color: 'white',
                  border: 'none',
                  borderRadius: '4px',
                }}
              >
                Reset to Default
              </button>
            </div>
            <div style={{ marginTop: '10px', fontSize: '12px', color: '#666' }}>
              <strong>Current RPC:</strong> {rpcUrl}
            </div>
            <div style={{ fontSize: '12px', color: '#666' }}>
              <strong>Default RPC:</strong> {defaultRpcUrl}
            </div>
          </div>
        )}
      </div>

      {/* Wallet Connection */}
      {!isConnected ? (
        <div>
          <button
            onClick={connect}
            disabled={isConnecting}
            style={{
              padding: '10px 20px',
              fontSize: '16px',
              cursor: isConnecting ? 'not-allowed' : 'pointer',
              backgroundColor: '#4CAF50',
              color: 'white',
              border: 'none',
              borderRadius: '4px',
            }}
          >
            {isConnecting ? 'Connecting...' : 'Connect Wallet'}
          </button>
          {error && (
            <div style={{ color: 'red', marginTop: '10px' }}>
              Error: {error}
            </div>
          )}
        </div>
      ) : (
        <div>
          <p>
            <strong>Connected:</strong>{' '}
            {account?.slice(0, 6)}...{account?.slice(-4)}
          </p>
          <button
            onClick={disconnect}
            style={{
              padding: '8px 16px',
              fontSize: '14px',
              cursor: 'pointer',
              backgroundColor: '#f44336',
              color: 'white',
              border: 'none',
              borderRadius: '4px',
            }}
          >
            Disconnect
          </button>
        </div>
      )}
    </div>
  );
}
