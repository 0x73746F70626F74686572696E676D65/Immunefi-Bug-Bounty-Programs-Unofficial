import { useState } from 'react';
import { useWalletContext } from '../contexts/WalletContext';
import { ReliquaryPositions } from './ReliquaryPositions';
import { MasterChefPositions } from './MasterChefPositions';
import { PoolPositions } from './PoolPositions';
import { FBeetsPositions } from './FBeetsPositions';
import { SftmxPositions } from './SftmxPositions';
import { BalanceScanner } from './BalanceScanner';
import * as masterchefUtils from '../utils/masterchef';
import * as poolUtils from '../utils/pool';

export function PositionManager() {
  const { account, provider, signer, isConnected } = useWalletContext();
  const [poolAddress, setPoolAddress] = useState('');
  const [loading, setLoading] = useState(false);
  const [positions, setPositions] = useState(null);
  const [error, setError] = useState(null);

  const scanPositions = async () => {
    if (!poolAddress || !provider || !account) return;

    console.log('═══════════════════════════════════════════════');
    console.log('[PositionManager] Starting position scan...');
    console.log('[PositionManager] Pool address:', poolAddress);
    console.log('[PositionManager] User account:', account);
    console.log('═══════════════════════════════════════════════');

    setLoading(true);
    setError(null);
    setPositions(null);

    try {
      const normalizedAddress = poolAddress.trim().toLowerCase();

      // Get pool ID
      console.log('[PositionManager] Step 1: Getting pool ID...');
      const poolId = await poolUtils.getPoolId(provider, normalizedAddress);

      // Get farm ID from MasterChef
      console.log('[PositionManager] Step 2: Finding farm ID...');
      const farmId = await masterchefUtils.findFarmIdByPoolAddress(provider, normalizedAddress);

      console.log('[PositionManager] ✅ Scan complete!');
      console.log('[PositionManager] Results:', { poolAddress: normalizedAddress, poolId, farmId });

      setPositions({
        poolAddress: normalizedAddress,
        poolId,
        farmId,
      });
    } catch (err) {
      console.error('[PositionManager] ❌ Error scanning positions:', err);
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const handlePoolSelect = async (selectedPoolAddress) => {
    console.log('[PositionManager] Pool selected from scanner:', selectedPoolAddress);
    setPoolAddress(selectedPoolAddress);
    
    // Automatically scan the selected pool
    if (!provider || !account) return;

    console.log('═══════════════════════════════════════════════');
    console.log('[PositionManager] Auto-scanning selected pool...');
    console.log('[PositionManager] Pool address:', selectedPoolAddress);
    console.log('═══════════════════════════════════════════════');

    setLoading(true);
    setError(null);
    setPositions(null);

    try {
      const normalizedAddress = selectedPoolAddress.trim().toLowerCase();

      // Get pool ID
      console.log('[PositionManager] Step 1: Getting pool ID...');
      const poolId = await poolUtils.getPoolId(provider, normalizedAddress);

      // Get farm ID from MasterChef
      console.log('[PositionManager] Step 2: Finding farm ID...');
      const farmId = await masterchefUtils.findFarmIdByPoolAddress(provider, normalizedAddress);

      console.log('[PositionManager] ✅ Scan complete!');
      console.log('[PositionManager] Results:', { poolAddress: normalizedAddress, poolId, farmId });

      setPositions({
        poolAddress: normalizedAddress,
        poolId,
        farmId,
      });
    } catch (err) {
      console.error('[PositionManager] ❌ Error scanning positions:', err);
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  if (!isConnected) {
    return (
      <div style={{ padding: '20px' }}>
        <p>Please connect your wallet to continue.</p>
      </div>
    );
  }

  return (
    <div style={{ padding: '20px' }}>
      {/* Balance Scanner Section */}
      <BalanceScanner 
        provider={provider}
        account={account}
        onSelectPool={handlePoolSelect}
      />

      <h3>Scan Positions</h3>

      <div style={{ marginBottom: '20px' }}>
        <input
          type="text"
          placeholder="Enter pool address (0x...)"
          value={poolAddress}
          onChange={(e) => setPoolAddress(e.target.value)}
          style={{
            padding: '10px',
            fontSize: '14px',
            width: '400px',
            marginRight: '10px',
            fontFamily: 'monospace',
          }}
        />
        <button
          onClick={scanPositions}
          disabled={loading || !poolAddress}
          style={{
            padding: '10px 20px',
            fontSize: '14px',
            cursor: loading || !poolAddress ? 'not-allowed' : 'pointer',
            backgroundColor: '#2196F3',
            color: 'white',
            border: 'none',
            borderRadius: '4px',
          }}
        >
          {loading ? 'Scanning...' : 'Scan'}
        </button>
      </div>

      {error && (
        <div style={{ color: 'red', marginBottom: '20px' }}>
          Error: {error}
        </div>
      )}

      {positions && (
        <div>
          <div style={{ marginBottom: '20px', padding: '10px', backgroundColor: '#f5f5f5', borderRadius: '4px' }}>
            <p><strong>Pool Address:</strong> <code>{positions.poolAddress}</code></p>
            {positions.poolId && <p><strong>Pool ID:</strong> <code>{positions.poolId}</code></p>}
            {positions.farmId !== null && positions.farmId !== undefined && (
              <p><strong>Farm ID:</strong> {positions.farmId}</p>
            )}
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
            {/* MasterChef Positions */}
            {positions.farmId !== null && positions.farmId !== undefined && (
              <MasterChefPositions
                provider={provider}
                signer={signer}
                account={account}
                farmId={positions.farmId}
              />
            )}

            {/* Pool Positions (BPT balance for exit) */}
            {positions.poolId && (
              <PoolPositions
                provider={provider}
                signer={signer}
                account={account}
                poolAddress={positions.poolAddress}
                poolId={positions.poolId}
              />
            )}
          </div>
        </div>
      )}

      {/* Separate sections for Reliquary, fBEETS and sftmx that don't require pool address */}
      <div style={{ marginTop: '40px', paddingTop: '20px', borderTop: '2px solid #ccc' }}>
        <h3>Other Positions</h3>

        <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
          <ReliquaryPositions
            provider={provider}
            signer={signer}
            account={account}
          />

          {/* maBEETS BPT Balance - Pool for withdrawn relics */}
          <PoolPositions
            provider={provider}
            signer={signer}
            account={account}
            poolAddress="0x9e4341acef4147196e99d648c5e43b3fc9d02678"
            poolId="0x9e4341acef4147196e99d648c5e43b3fc9d026780002000000000000000005ec"
            title="Reliquary Pool Balance"
          />

          <FBeetsPositions
            provider={provider}
            signer={signer}
            account={account}
          />

          {/* fBEETS Pool - Legacy BPT balance */}
          <PoolPositions
            provider={provider}
            signer={signer}
            account={account}
            poolAddress="0xcdE5a11a4ACB4eE4c805352Cec57E236bdBC3837"
            poolId="0xcde5a11a4acb4ee4c805352cec57e236bdbc3837000200000000000000000019"
            title="fBEETS Pool Balance (Legacy BPT)"
            alwaysShow={true}
          />

          <SftmxPositions
            provider={provider}
            signer={signer}
            account={account}
          />
        </div>
      </div>
    </div>
  );
}
