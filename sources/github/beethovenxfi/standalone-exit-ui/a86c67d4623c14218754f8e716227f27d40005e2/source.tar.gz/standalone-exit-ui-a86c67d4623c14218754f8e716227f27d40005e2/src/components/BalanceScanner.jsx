import { useState } from 'react';
import * as scannerUtils from '../utils/scanner';

export function BalanceScanner({ provider, account, onSelectPool }) {
  const [scanning, setScanning] = useState(false);
  const [progress, setProgress] = useState(null);
  const [results, setResults] = useState(null);
  const [error, setError] = useState(null);

  const handleScan = async () => {
    if (!provider || !account) {
      alert('Please connect your wallet first');
      return;
    }

    console.log('═══════════════════════════════════════════════');
    console.log('[BalanceScanner] Starting comprehensive scan...');
    console.log('═══════════════════════════════════════════════');

    setScanning(true);
    setError(null);
    setResults(null);
    setProgress({ phase: 'wallet', scanned: 0, total: 0 });

    try {
      const positions = await scannerUtils.scanAllBalances(
        provider,
        account,
        (progressData) => {
          setProgress(progressData);
        }
      );

      console.log('[BalanceScanner] ✅ Scan complete!');
      console.log('[BalanceScanner] Found', positions.length, 'positions');
      
      // Sort by total balance descending
      positions.sort((a, b) => {
        const totalA = scannerUtils.getTotalBalance(a);
        const totalB = scannerUtils.getTotalBalance(b);
        return totalB - totalA;
      });

      setResults(positions);
    } catch (err) {
      console.error('[BalanceScanner] ❌ Scan failed:', err);
      setError(err.message);
    } finally {
      setScanning(false);
      setProgress(null);
    }
  };

  return (
    <div style={{ padding: '20px', border: '2px solid #2196F3', borderRadius: '8px', marginBottom: '20px' }}>
      <h3>🔍 Scan All Farm Balances</h3>
      <p style={{ color: '#666', marginBottom: '15px' }}>
        Scan all supported pools and MasterChef farms to find your positions.
        This will check wallet BPT balances and staked MasterChef balances across all pools.
      </p>

      <button
        onClick={handleScan}
        disabled={scanning || !account}
        style={{
          padding: '12px 24px',
          fontSize: '16px',
          fontWeight: 'bold',
          cursor: scanning || !account ? 'not-allowed' : 'pointer',
          backgroundColor: '#2196F3',
          color: 'white',
          border: 'none',
          borderRadius: '6px',
          opacity: scanning || !account ? 0.6 : 1,
        }}
      >
        {scanning ? '🔄 Scanning...' : '🔍 Scan All Balances'}
      </button>

      {progress && (
        <div style={{ marginTop: '15px', padding: '10px', backgroundColor: '#e3f2fd', borderRadius: '4px' }}>
          <p style={{ margin: '5px 0' }}>
            <strong>Phase:</strong> {progress.phase === 'wallet' ? '📂 Wallet Balances' : '🚜 MasterChef Farms'}
          </p>
          <p style={{ margin: '5px 0' }}>
            <strong>Progress:</strong> {progress.scanned} / {progress.total}
          </p>
          <div style={{ 
            width: '100%', 
            height: '20px', 
            backgroundColor: '#ddd', 
            borderRadius: '10px',
            overflow: 'hidden',
            marginTop: '8px'
          }}>
            <div style={{
              width: `${(progress.scanned / progress.total) * 100}%`,
              height: '100%',
              backgroundColor: '#4CAF50',
              transition: 'width 0.3s ease'
            }}></div>
          </div>
          <p style={{ fontSize: '11px', color: '#666', marginTop: '5px', fontFamily: 'monospace' }}>
            Current: {progress.current}
          </p>
        </div>
      )}

      {error && (
        <div style={{ marginTop: '15px', padding: '10px', backgroundColor: '#ffebee', borderRadius: '4px', color: '#c62828' }}>
          <strong>Error:</strong> {error}
        </div>
      )}

      {results && results.length === 0 && (
        <div style={{ marginTop: '15px', padding: '10px', backgroundColor: '#fff3e0', borderRadius: '4px' }}>
          <p>No positions found. You don't have any BPT tokens in your wallet or staked in MasterChef farms.</p>
        </div>
      )}

      {results && results.length > 0 && (
        <div style={{ marginTop: '20px' }}>
          <h4>Found {results.length} Position{results.length !== 1 ? 's' : ''}:</h4>
          <div style={{ maxHeight: '400px', overflowY: 'auto' }}>
            <table style={{ width: '100%', borderCollapse: 'collapse', marginTop: '10px', fontSize: '13px' }}>
              <thead>
                <tr style={{ backgroundColor: '#f5f5f5', borderBottom: '2px solid #ddd' }}>
                  <th style={{ padding: '10px', textAlign: 'left' }}>Pool Name</th>
                  <th style={{ padding: '10px', textAlign: 'left' }}>Tokens</th>
                  <th style={{ padding: '10px', textAlign: 'right' }}>Wallet Balance</th>
                  <th style={{ padding: '10px', textAlign: 'right' }}>Staked (MasterChef)</th>
                  <th style={{ padding: '10px', textAlign: 'right' }}>Total</th>
                  <th style={{ padding: '10px', textAlign: 'center' }}>Farm ID</th>
                  <th style={{ padding: '10px', textAlign: 'center' }}>Action</th>
                </tr>
              </thead>
              <tbody>
                {results.map((position, index) => {
                  const total = scannerUtils.getTotalBalance(position);
                  return (
                    <tr 
                      key={position.poolAddress} 
                      style={{ 
                        borderBottom: '1px solid #eee',
                        backgroundColor: index % 2 === 0 ? 'white' : '#fafafa'
                      }}
                    >
                      <td style={{ padding: '8px', fontWeight: '500', maxWidth: '200px' }}>
                        {position.poolName || 'Unknown Pool'}
                        <div style={{ fontSize: '10px', fontFamily: 'monospace', color: '#999', marginTop: '2px' }}>
                          {position.poolAddress.substring(0, 10)}...{position.poolAddress.substring(38)}
                        </div>
                      </td>
                      <td style={{ padding: '8px', color: '#666', fontSize: '11px', maxWidth: '180px' }}>
                        {position.poolTokens || '-'}
                      </td>
                      <td style={{ padding: '8px', textAlign: 'right', fontWeight: parseFloat(position.walletBalance) > 0 ? 'bold' : 'normal' }}>
                        {parseFloat(position.walletBalance).toFixed(6)}
                      </td>
                      <td style={{ padding: '8px', textAlign: 'right', fontWeight: parseFloat(position.masterchefBalance) > 0 ? 'bold' : 'normal' }}>
                        {parseFloat(position.masterchefBalance).toFixed(6)}
                      </td>
                      <td style={{ padding: '8px', textAlign: 'right', fontWeight: 'bold', color: '#2196F3' }}>
                        {total.toFixed(6)}
                      </td>
                      <td style={{ padding: '8px', textAlign: 'center' }}>
                        {position.farmId !== null ? position.farmId : '-'}
                      </td>
                      <td style={{ padding: '8px', textAlign: 'center' }}>
                        <button
                          onClick={() => onSelectPool && onSelectPool(position.poolAddress)}
                          style={{
                            padding: '4px 12px',
                            fontSize: '12px',
                            cursor: 'pointer',
                            backgroundColor: '#4CAF50',
                            color: 'white',
                            border: 'none',
                            borderRadius: '4px',
                          }}
                        >
                          Manage
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
