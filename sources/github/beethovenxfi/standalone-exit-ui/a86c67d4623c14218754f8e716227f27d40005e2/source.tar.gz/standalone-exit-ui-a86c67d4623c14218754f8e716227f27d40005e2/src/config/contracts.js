// Contract addresses for Fantom Opera network
import { POOL_FARMS } from './poolFarms';

export const CHAIN_ID = 250;
export const RPC_URL = 'https://rpc3.fantom.network';

export const CONTRACTS = {
    // Core Balancer contracts
    vault: '0x20dd72Ed959b6147912C2e529F0a0C651c33c9ce',

    // Staking contracts
    masterChef: '0x8166994d9ebBe5829EC86Bd81258149B87faCfd3',
    reliquary: '0x1ed6411670c709f4e163854654bd52c74e66d7ec',

    // Token contracts
    fbeets: '0xfcef8a994209d6916eb2c86cdd2afd60aa6f54b1',
    fbeetsBar: '0xfcef8a994209d6916eb2c86cdd2afd60aa6f54b1', // fBEETS staking

    // sftmx
    sftmx: '0xd7028092c830b5c8fce061af2e593413ebbc1fc1',
    sftmxStaking: '0xB458BfC855ab504a8a327720FcEF98886065529b',

    // Reliquary maBEETS pool info
    reliquaryMaBeetsPool: {
        poolId: '0x9e4341acef4147196e99d648c5e43b3fc9d026780002000000000000000005ec',
        poolAddress: '0x9e4341acef4147196e99d648c5e43b3fc9d02678',
        farmId: 2,
    },

    // Legacy fBEETS pool info
    legacyFbeetsPool: {
        poolId: '0xcde5a11a4acb4ee4c805352cec57e236bdbc3837000200000000000000000019',
        poolAddress: '0xcdE5a11a4ACB4eE4c805352Cec57E236bdBC3837',
        farmId: 22,
    },
};

// Pool address to farm ID mapping - imported from poolFarms.js
// Contains all active Beethoven X MasterChef farms on Fantom (180+ pools)
export const POOL_TO_FARM_MAP = POOL_FARMS;
