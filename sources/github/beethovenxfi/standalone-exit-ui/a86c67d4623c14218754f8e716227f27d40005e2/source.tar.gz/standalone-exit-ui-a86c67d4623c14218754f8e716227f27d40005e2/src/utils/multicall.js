import { ethers } from 'ethers';

// Multicall3 contract on Fantom Opera
const MULTICALL_ADDRESS = '0xcA11bde05977b3631167028862bE2a173976CA11';

const MULTICALL_ABI = [
    {
        inputs: [
            {
                components: [
                    { name: 'target', type: 'address' },
                    { name: 'callData', type: 'bytes' },
                ],
                name: 'calls',
                type: 'tuple[]',
            },
        ],
        name: 'aggregate',
        outputs: [
            { name: 'blockNumber', type: 'uint256' },
            { name: 'returnData', type: 'bytes[]' },
        ],
        stateMutability: 'payable',
        type: 'function',
    },
    {
        inputs: [
            { name: 'requireSuccess', type: 'bool' },
            {
                components: [
                    { name: 'target', type: 'address' },
                    { name: 'callData', type: 'bytes' },
                ],
                name: 'calls',
                type: 'tuple[]',
            },
        ],
        name: 'tryAggregate',
        outputs: [
            {
                components: [
                    { name: 'success', type: 'bool' },
                    { name: 'returnData', type: 'bytes' },
                ],
                name: 'returnData',
                type: 'tuple[]',
            },
        ],
        stateMutability: 'payable',
        type: 'function',
    },
];

/**
 * Execute multiple contract calls in a single transaction using Multicall3
 * @param {object} provider - ethers provider
 * @param {Array} calls - Array of {target, callData} objects
 * @param {boolean} allowFailure - Whether to allow individual calls to fail
 * @returns {Promise<Array>} Array of decoded results
 */
export async function multicall(provider, calls, allowFailure = true) {
    const multicallContract = new ethers.Contract(MULTICALL_ADDRESS, MULTICALL_ABI, provider);

    if (allowFailure) {
        // Use tryAggregate to allow individual call failures
        // tryAggregate takes (requireSuccess, calls[])
        const multicallCalls = calls.map((call) => ({
            target: call.target,
            callData: call.callData,
        }));

        const results = await multicallContract.callStatic.tryAggregate(false, multicallCalls);
        return results.map((result, index) => ({
            success: result.success,
            returnData: result.returnData,
            callInfo: calls[index],
        }));
    } else {
        // Use aggregate - all calls must succeed
        const multicallCalls = calls.map((call) => ({
            target: call.target,
            callData: call.callData,
        }));

        const [, returnData] = await multicallContract.callStatic.aggregate(multicallCalls);
        return returnData.map((data, index) => ({
            success: true,
            returnData: data,
            callInfo: calls[index],
        }));
    }
}

/**
 * Helper to create a balanceOf call data
 * @param {string} tokenAddress - Token contract address
 * @param {string} userAddress - User wallet address
 * @returns {object} Call object for multicall
 */
export function createBalanceOfCall(tokenAddress, userAddress) {
    const iface = new ethers.utils.Interface(['function balanceOf(address) view returns (uint256)']);
    const callData = iface.encodeFunctionData('balanceOf', [userAddress]);

    return {
        target: tokenAddress,
        callData,
        decoder: (returnData) => {
            if (!returnData || returnData === '0x') return '0';
            try {
                const result = iface.decodeFunctionResult('balanceOf', returnData);
                return ethers.utils.formatEther(result[0]);
            } catch (error) {
                console.error('Error decoding balanceOf result:', error);
                return '0';
            }
        },
    };
}

/**
 * Helper to create a userInfo call for MasterChef
 * @param {string} masterchefAddress - MasterChef contract address
 * @param {number} farmId - Farm pool ID
 * @param {string} userAddress - User wallet address
 * @returns {object} Call object for multicall
 */
export function createUserInfoCall(masterchefAddress, farmId, userAddress) {
    const iface = new ethers.utils.Interface([
        'function userInfo(uint256, address) view returns (uint256 amount, uint256 rewardDebt)',
    ]);
    const callData = iface.encodeFunctionData('userInfo', [farmId, userAddress]);

    return {
        target: masterchefAddress,
        callData,
        decoder: (returnData) => {
            if (!returnData || returnData === '0x') return '0';
            try {
                const result = iface.decodeFunctionResult('userInfo', returnData);
                return ethers.utils.formatEther(result.amount);
            } catch (error) {
                console.error('Error decoding userInfo result:', error);
                return '0';
            }
        },
    };
}

/**
 * Batch multiple multicall operations into chunks to avoid RPC limits
 * @param {object} provider - ethers provider
 * @param {Array} calls - Array of call objects
 * @param {number} chunkSize - Number of calls per batch (default: 100)
 * @returns {Promise<Array>} Array of all results
 */
export async function batchMulticall(provider, calls, chunkSize = 100) {
    const chunks = [];
    for (let i = 0; i < calls.length; i += chunkSize) {
        chunks.push(calls.slice(i, i + chunkSize));
    }

    console.log(`[Multicall] Batching ${calls.length} calls into ${chunks.length} chunks of ${chunkSize}`);

    const allResults = [];
    for (let i = 0; i < chunks.length; i++) {
        console.log(`[Multicall] Processing chunk ${i + 1}/${chunks.length}...`);
        const results = await multicall(provider, chunks[i], true);
        allResults.push(...results);
    }

    return allResults;
}
