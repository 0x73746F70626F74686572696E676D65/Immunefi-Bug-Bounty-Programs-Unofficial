import { createContext, useContext } from 'react';
import { useWallet } from '../hooks/useWallet';
import { useRpcContext } from './RpcContext';

const WalletContext = createContext(null);

export function WalletProvider({ children }) {
  const { rpcUrl } = useRpcContext();
  const wallet = useWallet(rpcUrl);

  return (
    <WalletContext.Provider value={wallet}>
      {children}
    </WalletContext.Provider>
  );
}

export function useWalletContext() {
  const context = useContext(WalletContext);
  if (!context) {
    throw new Error('useWalletContext must be used within WalletProvider');
  }
  return context;
}
