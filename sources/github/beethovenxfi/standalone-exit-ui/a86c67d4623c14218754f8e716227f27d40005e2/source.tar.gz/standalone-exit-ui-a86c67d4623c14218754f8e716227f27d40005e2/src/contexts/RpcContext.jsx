import { createContext, useContext, useState, useEffect } from 'react';
import { RPC_URL as DEFAULT_RPC_URL } from '../config/contracts';

const RpcContext = createContext(null);

export function RpcProvider({ children }) {
  // Initialize from localStorage or use default
  const [rpcUrl, setRpcUrl] = useState(() => {
    const saved = localStorage.getItem('custom_rpc_url');
    return saved || DEFAULT_RPC_URL;
  });

  // Persist to localStorage whenever it changes
  useEffect(() => {
    if (rpcUrl !== DEFAULT_RPC_URL) {
      localStorage.setItem('custom_rpc_url', rpcUrl);
    } else {
      localStorage.removeItem('custom_rpc_url');
    }
  }, [rpcUrl]);

  const updateRpcUrl = (newUrl) => {
    setRpcUrl(newUrl || DEFAULT_RPC_URL);
  };

  const resetToDefault = () => {
    setRpcUrl(DEFAULT_RPC_URL);
  };

  return (
    <RpcContext.Provider value={{ 
      rpcUrl, 
      updateRpcUrl, 
      resetToDefault,
      isCustomRpc: rpcUrl !== DEFAULT_RPC_URL,
      defaultRpcUrl: DEFAULT_RPC_URL
    }}>
      {children}
    </RpcContext.Provider>
  );
}

export function useRpcContext() {
  const context = useContext(RpcContext);
  if (!context) {
    throw new Error('useRpcContext must be used within RpcProvider');
  }
  return context;
}
