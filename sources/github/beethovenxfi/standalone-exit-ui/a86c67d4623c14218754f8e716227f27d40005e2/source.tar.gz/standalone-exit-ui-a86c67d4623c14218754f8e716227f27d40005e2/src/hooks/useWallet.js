import { useState, useEffect } from 'react';
import { ethers } from 'ethers';
import { CHAIN_ID } from '../config/contracts';

export function useWallet(rpcUrl) {
  const [account, setAccount] = useState(null);
  const [provider, setProvider] = useState(null);
  const [signer, setSigner] = useState(null);
  const [isConnecting, setIsConnecting] = useState(false);
  const [error, setError] = useState(null);

  // Set up read-only provider on mount or when RPC URL changes
  useEffect(() => {
    console.log('[Wallet] Initializing read-only provider with RPC:', rpcUrl);
    const readProvider = new ethers.providers.JsonRpcProvider(rpcUrl);
    setProvider(readProvider);
    console.log('[Wallet] Read-only provider initialized');
  }, [rpcUrl]);

  // Listen for account changes
  useEffect(() => {
    if (window.ethereum) {
      window.ethereum.on('accountsChanged', (accounts) => {
        if (accounts.length === 0) {
          disconnect();
        } else {
          setAccount(accounts[0]);
        }
      });

      window.ethereum.on('chainChanged', () => {
        window.location.reload();
      });
    }

    return () => {
      if (window.ethereum) {
        window.ethereum.removeAllListeners('accountsChanged');
        window.ethereum.removeAllListeners('chainChanged');
      }
    };
  }, []);

  const connect = async () => {
    console.log('[Wallet] Starting connection process...');
    setIsConnecting(true);
    setError(null);

    try {
      if (!window.ethereum) {
        console.error('[Wallet] No ethereum provider found');
        throw new Error('Please install MetaMask or another Web3 wallet');
      }

      console.log('[Wallet] Requesting account access...');
      // Request account access
      const accounts = await window.ethereum.request({
        method: 'eth_requestAccounts',
      });

      console.log('[Wallet] Accounts received:', accounts);

      if (accounts.length === 0) {
        throw new Error('No accounts found');
      }

      // Check if on correct network
      const chainId = await window.ethereum.request({ method: 'eth_chainId' });
      const chainIdDecimal = parseInt(chainId, 16);
      console.log('[Wallet] Current chain ID:', chainIdDecimal, '| Expected:', CHAIN_ID);

      if (chainIdDecimal !== CHAIN_ID) {
        console.log('[Wallet] Wrong network, attempting to switch to chain', CHAIN_ID);
        // Try to switch network
        try {
          await window.ethereum.request({
            method: 'wallet_switchEthereumChain',
            params: [{ chainId: `0x${CHAIN_ID.toString(16)}` }],
          });
          console.log('[Wallet] Successfully switched to Fantom Opera');
        } catch (switchError) {
          // If chain not added, add it
          if (switchError.code === 4902) {
            console.log('[Wallet] Chain not found, adding Fantom Opera network...');
            await window.ethereum.request({
              method: 'wallet_addEthereumChain',
              params: [{
                chainId: `0x${CHAIN_ID.toString(16)}`,
                chainName: 'Fantom Opera',
                nativeCurrency: {
                  name: 'Fantom',
                  symbol: 'FTM',
                  decimals: 18,
                },
                rpcUrls: [rpcUrl],
                blockExplorerUrls: ['https://ftmscan.com'],
              }],
            });
            console.log('[Wallet] Fantom Opera network added successfully');
          } else {
            throw switchError;
          }
        }
      }

      // Create provider and signer
      console.log('[Wallet] Creating Web3 provider and signer...');
      const web3Provider = new ethers.providers.Web3Provider(window.ethereum);
      const web3Signer = web3Provider.getSigner();

      setProvider(web3Provider);
      setSigner(web3Signer);
      setAccount(accounts[0]);
      console.log('[Wallet] ✅ Connected successfully:', accounts[0]);
    } catch (err) {
      console.error('[Wallet] ❌ Connection error:', err);
      setError(err.message);
    } finally {
      setIsConnecting(false);
    }
  };

  const disconnect = () => {
    console.log('[Wallet] Disconnecting...');
    setAccount(null);
    setSigner(null);
    // Reset to read-only provider
    const readProvider = new ethers.providers.JsonRpcProvider(rpcUrl);
    setProvider(readProvider);
    console.log('[Wallet] Disconnected and reset to read-only provider');
  };

  return {
    account,
    provider,
    signer,
    isConnecting,
    error,
    connect,
    disconnect,
    isConnected: !!account,
  };
}
