import { ethers } from 'ethers';
import { CONTRACTS } from '../config/contracts';
import FBeetsBarAbi from '../abis/FBeetsBar.json';
import ERC20Abi from '../abis/ERC20.json';

/**
 * Get user's fBEETS balance
 */
export async function getFBeetsBalance(provider, userAddress) {
  console.log('[fBEETS] Getting fBEETS balance for user:', userAddress);
  const contract = new ethers.Contract(CONTRACTS.fbeets, ERC20Abi, provider);

  try {
    const balance = await contract.balanceOf(userAddress);
    const formatted = ethers.utils.formatEther(balance);
    console.log('[fBEETS] Balance:', formatted, 'fBEETS');
    return formatted;
  } catch (error) {
    console.error('[fBEETS] ❌ Error fetching fBEETS balance:', error);
    return '0';
  }
}

/**
 * Leave fBEETS bar (convert fBEETS back to BEETS)
 * Uses the standard SushiBar-style leave function
 */
export async function exitFBeets(signer, amount) {
  console.log('[fBEETS] Exiting', amount, 'fBEETS');
  const contract = new ethers.Contract(CONTRACTS.fbeets, FBeetsBarAbi, signer);

  try {
    const amountWei = ethers.utils.parseEther(amount);
    
    console.log('[fBEETS] Submitting leave transaction...');
    console.log('[fBEETS] Amount:', amountWei.toString());
    
    // Standard leave(uint256) function
    const tx = await contract.leave(amountWei);
    console.log('[fBEETS] Transaction submitted:', tx.hash);
    console.log('[fBEETS] Waiting for confirmation...');
    const receipt = await tx.wait();
    console.log('[fBEETS] ✅ Exit confirmed in block:', receipt.blockNumber);
    return receipt;
  } catch (error) {
    console.error('[fBEETS] ❌ Error exiting fBEETS:', error);
    throw error;
  }
}

/**
 * Get the BEETS amount user will receive for a given fBEETS amount
 */
export async function getFBeetsToBeetsRatio(provider, fbeetsAmount) {
  const contract = new ethers.Contract(CONTRACTS.fbeets, FBeetsBarAbi, provider);

  try {
    const fbeetsAmountWei = ethers.utils.parseEther(fbeetsAmount);

    // Get total fBEETS supply
    const totalSupply = await contract.totalSupply();

    // Get total BEETS in the contract
    const beetsContract = new ethers.Contract(
      CONTRACTS.fbeets, // This might need to be the actual BEETS token address
      ERC20Abi,
      provider
    );

    // The ratio calculation depends on the implementation
    // For FreshBeets: beetsOut = fbeetsIn * beetsBalance / totalSupply
    // This is a simplified version - actual implementation may vary

    return fbeetsAmount; // Placeholder - adjust based on actual contract
  } catch (error) {
    console.error('Error calculating fBEETS ratio:', error);
    return '0';
  }
}
