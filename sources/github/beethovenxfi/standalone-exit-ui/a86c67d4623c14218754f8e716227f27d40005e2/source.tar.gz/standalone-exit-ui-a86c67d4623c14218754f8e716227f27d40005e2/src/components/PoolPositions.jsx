import { useState, useEffect } from 'react';
import * as poolUtils from '../utils/pool';
import { CONTRACTS } from '../config/contracts';

export function PoolPositions({ provider, signer, account, poolAddress, poolId, title = 'Pool Balance (BPT)', alwaysShow = false }) {
  const [balance, setBalance] = useState('0');
  const [tokens, setTokens] = useState(null);
  const [loading, setLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState(false);
  const [error, setError] = useState(null);

  useEffect(() => {
    loadBalance();
  }, [account, poolAddress]);

  const loadBalance = async () => {
    if (!provider || !account || !poolAddress) return;

    console.log('[PoolPositions] Loading BPT balance and pool composition');
    setLoading(true);
    setError(null);

    try {
      const bal = await poolUtils.getPoolTokenBalance(provider, poolAddress, account);
      const poolTokens = await poolUtils.getPoolTokens(provider, poolId);

      console.log('[PoolPositions] ✅ Balance loaded');
      setBalance(bal);
      setTokens(poolTokens);
    } catch (err) {
      console.error('[PoolPositions] ❌ Error loading pool balance:', err);
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleExit = async () => {
    console.log('═══════════════════════════════════════════════');
    console.log('[PoolPositions] 🔘 Exit button clicked');
    console.log('[PoolPositions] Signer available:', !!signer);
    console.log('[PoolPositions] Pool ID:', poolId);
    console.log('[PoolPositions] Pool Address:', poolAddress);
    console.log('[PoolPositions] Balance:', balance);

    if (!signer) {
      console.error('[PoolPositions] ❌ No signer available');
      alert('Please connect your wallet first');
      return;
    }

    if (!poolId) {
      console.error('[PoolPositions] ❌ No pool ID available');
      return;
    }

    const confirmed = window.confirm(
      `Exit pool proportionally with ${balance} BPT?\n\nThis will withdraw all underlying tokens proportionally.`
    );

    if (!confirmed) {
      console.log('[PoolPositions] User cancelled exit');
      return;
    }

    setActionLoading(true);
    try {
      console.log('[PoolPositions] Checking BPT approval...');
      // Check if approval is needed
      const allowance = await poolUtils.checkApproval(provider, poolAddress, account, CONTRACTS.vault);

      if (allowance.lt(poolUtils.ethers?.utils?.parseEther(balance) || '0')) {
        console.log('[PoolPositions] Approval needed');
        alert('Approving BPT spending...');
        await poolUtils.approveToken(signer, poolAddress, CONTRACTS.vault);
        console.log('[PoolPositions] ✅ Approval successful');
        alert('Approval successful! Now exiting pool...');
      } else {
        console.log('[PoolPositions] Already approved');
      }

      console.log('[PoolPositions] Starting pool exit...');
      await poolUtils.exitPoolProportional(signer, poolId, poolAddress, balance, provider);
      console.log('[PoolPositions] ✅ Pool exit successful');
      alert('Successfully exited pool!');
      await loadBalance();
    } catch (err) {
      console.error('[PoolPositions] ❌ Pool exit failed:', err);
      alert(`Error exiting pool: ${err.message}`);
    } finally {
      setActionLoading(false);
    }
  };

  if (loading) {
    return (
      <div style={{ padding: '15px', border: '1px solid #ccc', borderRadius: '4px' }}>
        <h4>{title}</h4>
        <p>Loading...</p>
      </div>
    );
  }

  if (parseFloat(balance) === 0 && !alwaysShow) {
    return (
      <div style={{ padding: '15px', border: '1px solid #ccc', borderRadius: '4px' }}>
        <h4>{title}</h4>
        <p>No pool tokens found in wallet.</p>
      </div>
    );
  }

  return (
    <div style={{ padding: '15px', border: '1px solid #ccc', borderRadius: '4px' }}>
      <h4>{title}</h4>

      {error && <div style={{ color: 'red', marginBottom: '10px' }}>Error: {error}</div>}

      <div style={{ padding: '10px', backgroundColor: '#f9f9f9', borderRadius: '4px' }}>
        <p>BPT Balance: {parseFloat(balance).toFixed(6)}</p>

        <div style={{ marginTop: '10px' }}>
          <button
            onClick={handleExit}
            disabled={actionLoading || parseFloat(balance) === 0}
            style={{
              padding: '8px 16px',
              cursor: actionLoading || parseFloat(balance) === 0 ? 'not-allowed' : 'pointer',
              backgroundColor: '#f44336',
              color: 'white',
              border: 'none',
              borderRadius: '4px',
            }}
          >
            {actionLoading ? 'Exiting...' : 'Exit Pool Proportionally'}
          </button>
        </div>
      </div>
    </div>
  );
}
