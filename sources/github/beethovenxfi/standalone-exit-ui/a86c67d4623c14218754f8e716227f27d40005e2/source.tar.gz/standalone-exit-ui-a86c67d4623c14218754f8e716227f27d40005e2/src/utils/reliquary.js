import { ethers } from 'ethers';
import { CONTRACTS } from '../config/contracts';
import ReliquaryAbi from '../abis/Reliquary.json';

/**
 * Get all Reliquary relics (NFT positions) owned by a user
 */
export async function getUserRelics(provider, userAddress) {
    console.log('[Reliquary] Getting relics for user:', userAddress);

    if (!provider) {
        console.error('[Reliquary] ❌ No provider available');
        throw new Error('Provider is required');
    }

    if (!userAddress) {
        console.error('[Reliquary] ❌ No user address provided');
        throw new Error('User address is required');
    }

    const contract = new ethers.Contract(CONTRACTS.reliquary, ReliquaryAbi, provider);

    try {
        console.log('[Reliquary] Calling balanceOf...');
        const balance = await contract.balanceOf(userAddress);
        const relicCount = balance.toNumber();
        console.log('[Reliquary] User owns', relicCount, 'relics');

        if (relicCount === 0) {
            console.log('[Reliquary] No relics found');
            return [];
        }

        // Get all relic IDs owned by user
        console.log('[Reliquary] Fetching relic IDs...');
        const relicPromises = [];
        for (let i = 0; i < relicCount; i++) {
            relicPromises.push(contract.tokenOfOwnerByIndex(userAddress, i));
        }

        const relicIds = await Promise.all(relicPromises);
        console.log(
            '[Reliquary] Relic IDs:',
            relicIds.map((id) => id.toString()),
        );

        // Get position info for each relic
        console.log('[Reliquary] Fetching position details...');
        const positionPromises = relicIds.map((id) => contract.getPositionForId(id));
        const positions = await Promise.all(positionPromises);

        const relics = relicIds.map((id, idx) => ({
            relicId: id.toString(),
            amount: ethers.utils.formatEther(positions[idx].amount),
            poolId: positions[idx].poolId.toString(),
            level: positions[idx].level.toString(),
            entry: positions[idx].entry.toString(),
        }));

        console.log('[Reliquary] ✅ Found', relics.length, 'relics with positions');
        return relics;
    } catch (error) {
        console.error('[Reliquary] ❌ Error fetching relics:', error);
        console.error('[Reliquary] Error details:', error.message);
        console.error('[Reliquary] Error code:', error.code);
        throw error;
    }
}

/**
 * Get relics for a specific pool (farmId)
 */
export async function getRelicsForPool(provider, userAddress, farmId) {
    console.log('[Reliquary] Filtering relics for farm ID:', farmId);
    const allRelics = await getUserRelics(provider, userAddress);
    const filtered = allRelics.filter((relic) => relic.poolId === farmId.toString());
    console.log('[Reliquary] Found', filtered.length, 'relics for this farm');
    return filtered;
}

/**
 * Get pending rewards for a relic
 */
export async function getPendingRewards(provider, relicId) {
    console.log('[Reliquary] Getting pending rewards for relic:', relicId);
    const contract = new ethers.Contract(CONTRACTS.reliquary, ReliquaryAbi, provider);

    try {
        const reward = await contract.pendingReward(relicId);
        const formatted = ethers.utils.formatEther(reward);
        console.log('[Reliquary] Pending rewards:', formatted, 'BEETS');
        return formatted;
    } catch (error) {
        console.error('[Reliquary] ❌ Error fetching pending rewards:', error);
        return '0';
    }
}

/**
 * Harvest (claim) rewards from a relic
 */
export async function harvestRelic(signer, relicId) {
    console.log('[Reliquary] Harvesting rewards from relic:', relicId);
    const contract = new ethers.Contract(CONTRACTS.reliquary, ReliquaryAbi, signer);
    console.log('[Reliquary] Submitting harvest transaction...');
    const tx = await contract.harvest(relicId, await signer.getAddress());
    console.log('[Reliquary] Transaction submitted:', tx.hash);
    console.log('[Reliquary] Waiting for confirmation...');
    const receipt = await tx.wait();
    console.log('[Reliquary] ✅ Harvest confirmed in block:', receipt.blockNumber);
    return receipt;
}

/**
 * Withdraw from a relic and harvest rewards
 */
export async function withdrawAndHarvest(signer, amount, relicId) {
    console.log('[Reliquary] Withdrawing', amount, 'from relic:', relicId);
    const contract = new ethers.Contract(CONTRACTS.reliquary, ReliquaryAbi, signer);
    const amountWei = ethers.utils.parseEther(amount);
    console.log('[Reliquary] Submitting withdraw transaction...');
    const tx = await contract.withdrawAndHarvest(amountWei, relicId, await signer.getAddress());
    console.log('[Reliquary] Transaction submitted:', tx.hash);
    console.log('[Reliquary] Waiting for confirmation...');
    const receipt = await tx.wait();
    console.log('[Reliquary] ✅ Withdraw confirmed in block:', receipt.blockNumber);
    return receipt;
}

/**
 * Emergency withdraw (forfeits rewards)
 */
export async function emergencyWithdraw(signer, relicId) {
    const contract = new ethers.Contract(CONTRACTS.reliquary, ReliquaryAbi, signer);
    const tx = await contract.emergencyWithdraw(relicId);
    return tx.wait();
}
