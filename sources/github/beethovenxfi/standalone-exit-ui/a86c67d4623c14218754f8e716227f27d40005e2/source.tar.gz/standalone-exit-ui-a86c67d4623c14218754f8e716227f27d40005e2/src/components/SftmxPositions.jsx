import { useState, useEffect } from 'react';
import * as sftmxUtils from '../utils/sftmx';

// Cookie helpers
const COOKIE_NAME = 'sftmx_withdrawal_ids';

function saveWithdrawalIdToCookie(account, withdrawalId) {
  try {
    const stored = getCookie(COOKIE_NAME);
    const data = stored ? JSON.parse(stored) : {};
    if (!data[account]) data[account] = [];
    data[account].push({ id: withdrawalId, timestamp: Date.now() });
    // Keep only last 10 withdrawal IDs per account
    if (data[account].length > 10) data[account] = data[account].slice(-10);
    document.cookie = `${COOKIE_NAME}=${JSON.stringify(data)}; path=/; max-age=2592000`; // 30 days
    console.log('[Cookie] Saved withdrawal ID:', withdrawalId);
  } catch (err) {
    console.error('[Cookie] Error saving withdrawal ID:', err);
  }
}

function getWithdrawalIdsFromCookie(account) {
  try {
    const stored = getCookie(COOKIE_NAME);
    if (!stored) return [];
    const data = JSON.parse(stored);
    return data[account] || [];
  } catch (err) {
    console.error('[Cookie] Error reading withdrawal IDs:', err);
    return [];
  }
}

function removeWithdrawalIdFromCookie(account, withdrawalId) {
  try {
    const stored = getCookie(COOKIE_NAME);
    if (!stored) return;
    const data = JSON.parse(stored);
    if (!data[account]) return;
    
    // Remove the specific withdrawal ID
    data[account] = data[account].filter(item => item.id !== withdrawalId);
    
    // If no IDs left for this account, remove the account entry
    if (data[account].length === 0) {
      delete data[account];
    }
    
    // Save updated data back to cookie
    document.cookie = `${COOKIE_NAME}=${JSON.stringify(data)}; path=/; max-age=2592000`;
    console.log('[Cookie] Removed withdrawal ID:', withdrawalId);
  } catch (err) {
    console.error('[Cookie] Error removing withdrawal ID:', err);
  }
}

function getCookie(name) {
  const value = `; ${document.cookie}`;
  const parts = value.split(`; ${name}=`);
  if (parts.length === 2) return parts.pop().split(';').shift();
  return null;
}

export function SftmxPositions({ provider, signer, account }) {
  const [balance, setBalance] = useState('0');
  const [unstakeAmount, setUnstakeAmount] = useState('');
  const [withdrawalId, setWithdrawalId] = useState('');
  const [inputWithdrawalId, setInputWithdrawalId] = useState('');
  const [savedWithdrawalIds, setSavedWithdrawalIds] = useState([]);
  const [loading, setLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState(false);
  const [error, setError] = useState(null);

  useEffect(() => {
    loadBalance();
    if (account) {
      const saved = getWithdrawalIdsFromCookie(account);
      setSavedWithdrawalIds(saved);
      console.log('[SftmxPositions] Loaded', saved.length, 'saved withdrawal IDs from cookie');
    }
  }, [account]);

  const loadBalance = async () => {
    if (!provider || !account) return;

    console.log('[SftmxPositions] Loading sftmx balance');
    setLoading(true);
    setError(null);

    try {
      const bal = await sftmxUtils.getSftmxBalance(provider, account);
      console.log('[SftmxPositions] ✅ Balance loaded');
      setBalance(bal);
    } catch (err) {
      console.error('[SftmxPositions] ❌ Error loading sftmx balance:', err);
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleUnstake = async () => {
    console.log('═══════════════════════════════════════════════');
    console.log('[SftmxPositions] 🔘 Unstake button clicked');
    console.log('[SftmxPositions] Signer available:', !!signer);
    console.log('[SftmxPositions] Balance:', balance);

    if (!signer) {
      console.error('[SftmxPositions] ❌ No signer available');
      alert('Please connect your wallet first');
      return;
    }

    const amount = unstakeAmount.trim();

    if (!amount || parseFloat(amount) <= 0 || parseFloat(amount) > parseFloat(balance)) {
      console.log('[SftmxPositions] Invalid amount entered:', amount);
      alert('Invalid amount. Please enter a valid amount.');
      return;
    }

    console.log('[SftmxPositions] Unstake amount:', amount);
    setActionLoading(true);
    try {
      // Check and approve if needed
      console.log('[SftmxPositions] Checking approval...');
      await sftmxUtils.approveSftmx(signer);

      // Generate withdrawal ID from current timestamp
      const timestamp = Math.floor(Date.now() / 1000);
      const withdrawalIdToUse = timestamp.toString();
      console.log('[SftmxPositions] Generated withdrawal ID from timestamp:', withdrawalIdToUse);

      console.log('[SftmxPositions] Starting unstake...');
      const result = await sftmxUtils.unstakeSftmx(signer, amount, withdrawalIdToUse);

      if (result.withdrawalId) {
        setWithdrawalId(result.withdrawalId);
        saveWithdrawalIdToCookie(account, result.withdrawalId);
        const saved = getWithdrawalIdsFromCookie(account);
        setSavedWithdrawalIds(saved);
        
        console.log('[SftmxPositions] ✅ Unstake successful, withdrawal ID:', result.withdrawalId);
        alert(
          `Unstake initiated successfully!\n\n` +
          `Withdrawal ID: ${result.withdrawalId}\n\n` +
          `This ID has been saved automatically.\n` +
          `You will need it after the 24-hour delay to complete the withdrawal.`
        );
      } else {
        console.log('[SftmxPositions] ⚠️ Unstake successful but no withdrawal ID returned');
        alert('Unstake initiated! Check the transaction.');
      }

      setUnstakeAmount('');
      await loadBalance();
    } catch (err) {
      console.error('[SftmxPositions] ❌ Unstake failed:', err);
      alert(`Error unstaking: ${err.message}`);
    } finally {
      setActionLoading(false);
    }
  };

  const handleWithdraw = async () => {
    console.log('═══════════════════════════════════════════════');
    console.log('[SftmxPositions] 🔘 Withdraw button clicked');
    console.log('[SftmxPositions] Signer available:', !!signer);

    if (!signer) {
      console.error('[SftmxPositions] ❌ No signer available');
      alert('Please connect your wallet first');
      return;
    }

    const idToUse = inputWithdrawalId || withdrawalId;
    console.log('[SftmxPositions] Withdrawal ID to use:', idToUse);

    if (!idToUse) {
      console.error('[SftmxPositions] ❌ No withdrawal ID provided');
      alert('Please enter a withdrawal ID');
      return;
    }

    const confirmed = window.confirm(
      `Complete withdrawal for ID: ${idToUse}?\n\n` +
      `Make sure the 24-hour delay period has passed.`
    );

    if (!confirmed) {
      console.log('[SftmxPositions] User cancelled withdrawal');
      return;
    }

    setActionLoading(true);
    try {
      console.log('[SftmxPositions] Starting withdrawal for ID:', idToUse);
      await sftmxUtils.withdrawSftmx(signer, idToUse);
      console.log('[SftmxPositions] ✅ Withdrawal successful');
      
      // Remove the used withdrawal ID from cookies
      removeWithdrawalIdFromCookie(account, idToUse);
      const saved = getWithdrawalIdsFromCookie(account);
      setSavedWithdrawalIds(saved);
      console.log('[Cookie] Removed withdrawal ID:', idToUse);
      
      alert('Withdrawal completed successfully!');
      setWithdrawalId('');
      setInputWithdrawalId('');
      await loadBalance();
    } catch (err) {
      console.error('[SftmxPositions] ❌ Withdrawal failed:', err);
      alert(
        `Error completing withdrawal: ${err.message}\n\n` +
        `Make sure the 24-hour delay has passed.`
      );
    } finally {
      setActionLoading(false);
    }
  };

  if (loading) {
    return (
      <div style={{ padding: '15px', border: '1px solid #ccc', borderRadius: '4px' }}>
        <h4>sftmx Staking</h4>
        <p>Loading...</p>
      </div>
    );
  }

  return (
    <div style={{ padding: '15px', border: '1px solid #ccc', borderRadius: '4px' }}>
      <h4>sftmx Staking</h4>

      {error && <div style={{ color: 'red', marginBottom: '10px' }}>Error: {error}</div>}

      <div style={{ padding: '10px', backgroundColor: '#f9f9f9', borderRadius: '4px' }}>
        <p>sftmx Balance: {parseFloat(balance).toFixed(6)}</p>

        <div style={{ marginTop: '10px', marginBottom: '20px' }}>
          <h5>Step 1: Unstake (Start Withdrawal)</h5>
          <div style={{ marginBottom: '10px' }}>
            <input
              type="text"
              placeholder={`Amount to unstake (Max: ${parseFloat(balance).toFixed(6)})`}
              value={unstakeAmount}
              onChange={(e) => setUnstakeAmount(e.target.value)}
              disabled={actionLoading || parseFloat(balance) === 0}
              style={{
                padding: '8px',
                marginRight: '10px',
                width: '250px',
                fontFamily: 'monospace',
              }}
            />
            <button
              onClick={() => setUnstakeAmount(balance)}
              disabled={actionLoading || parseFloat(balance) === 0}
              style={{
                padding: '8px 12px',
                fontSize: '12px',
                cursor: actionLoading || parseFloat(balance) === 0 ? 'not-allowed' : 'pointer',
                backgroundColor: '#2196F3',
                color: 'white',
                border: 'none',
                borderRadius: '4px',
              }}
            >
              Max
            </button>
          </div>
          <button
            onClick={handleUnstake}
            disabled={actionLoading || parseFloat(balance) === 0 || !unstakeAmount}
            style={{
              padding: '8px 16px',
              cursor: actionLoading || parseFloat(balance) === 0 || !unstakeAmount ? 'not-allowed' : 'pointer',
              backgroundColor: '#ff9800',
              color: 'white',
              border: 'none',
              borderRadius: '4px',
            }}
          >
            {actionLoading ? 'Processing...' : 'Start Unstaking'}
          </button>

          {withdrawalId && (
            <div style={{ marginTop: '10px', padding: '10px', backgroundColor: '#fff3cd', borderRadius: '4px' }}>
              <p><strong>Withdrawal ID:</strong> <code>{withdrawalId}</code></p>
              <p style={{ fontSize: '12px' }}>
                Save this ID! You'll need it after 24 hours to complete the withdrawal.
              </p>
            </div>
          )}
        </div>

        <div style={{ paddingTop: '20px', borderTop: '1px solid #ccc' }}>
          <h5>Step 2: Complete Withdrawal (After 24h)</h5>
          
          {savedWithdrawalIds.length > 0 && (
            <div style={{ marginBottom: '10px', padding: '10px', backgroundColor: '#e3f2fd', borderRadius: '4px' }}>
              <p style={{ margin: '0 0 8px 0', fontSize: '13px', fontWeight: 'bold' }}>Saved Withdrawal IDs:</p>
              {savedWithdrawalIds.slice().reverse().map((item, idx) => (
                <div key={idx} style={{ fontSize: '12px', marginBottom: '4px' }}>
                  <code style={{ marginRight: '8px' }}>{item.id}</code>
                  <span style={{ color: '#666' }}>
                    ({new Date(item.timestamp).toLocaleString()})
                  </span>
                  <button
                    onClick={() => setInputWithdrawalId(item.id)}
                    style={{
                      marginLeft: '8px',
                      padding: '2px 8px',
                      fontSize: '11px',
                      cursor: 'pointer',
                      backgroundColor: '#2196F3',
                      color: 'white',
                      border: 'none',
                      borderRadius: '3px',
                    }}
                  >
                    Use
                  </button>
                </div>
              ))}
            </div>
          )}
          
          <input
            type="text"
            placeholder="Enter withdrawal ID"
            value={inputWithdrawalId}
            onChange={(e) => setInputWithdrawalId(e.target.value)}
            style={{
              padding: '8px',
              marginRight: '10px',
              width: '200px',
              fontFamily: 'monospace',
            }}
          />
          <button
            onClick={handleWithdraw}
            disabled={actionLoading || (!inputWithdrawalId && !withdrawalId)}
            style={{
              padding: '8px 16px',
              cursor: actionLoading || (!inputWithdrawalId && !withdrawalId) ? 'not-allowed' : 'pointer',
              backgroundColor: '#4CAF50',
              color: 'white',
              border: 'none',
              borderRadius: '4px',
            }}
          >
            {actionLoading ? 'Processing...' : 'Complete Withdrawal'}
          </button>
        </div>
      </div>
    </div>
  );
}
