import { ethers } from 'ethers';
import { POOL_FARMS } from '../config/poolFarms';
import { SUPPORTED_POOLS } from '../config/supportedPools';
import { CONTRACTS } from '../config/contracts';
import * as masterchefUtils from './masterchef';
import * as poolUtils from './pool';
import { batchMulticall, createBalanceOfCall, createUserInfoCall } from './multicall';
import poolDataRaw from '../config/poolData.json';

// Create a lookup map for pool data
const POOL_DATA_MAP = {};
if (poolDataRaw && poolDataRaw.data && poolDataRaw.data.poolGetPools) {
    poolDataRaw.data.poolGetPools.forEach((pool) => {
        POOL_DATA_MAP[pool.address.toLowerCase()] = {
            name: pool.name,
            tokens: pool.poolTokens.map((t) => t.symbol),
        };
    });
}

/**
 * Get pool information (name and token symbols)
 */
export function getPoolInfo(poolAddress) {
    const info = POOL_DATA_MAP[poolAddress.toLowerCase()];
    if (info) {
        return {
            name: info.name,
            tokens: info.tokens.join(', '),
        };
    }
    return {
        name: 'Unknown Pool',
        tokens: '',
    };
}

/**
 * Scan all supported pools and MasterChef farms for user balances
 * Returns array of positions with non-zero balances
 */
export async function scanAllBalances(provider, userAddress, onProgress = null) {
    console.log('[Scanner] Starting comprehensive balance scan with multicall...');
    console.log('[Scanner] User:', userAddress);
    console.log('[Scanner] Checking', SUPPORTED_POOLS.length, 'pools');
    console.log('[Scanner] Checking', Object.keys(POOL_FARMS).length, 'MasterChef farms');

    const results = [];
    const totalToScan = SUPPORTED_POOLS.length + Object.keys(POOL_FARMS).length;

    // Phase 1: Scan wallet BPT balances for all supported pools using multicall
    console.log('[Scanner] Phase 1: Scanning wallet BPT balances with multicall...');
    const walletCalls = SUPPORTED_POOLS.map((poolAddress) => createBalanceOfCall(poolAddress, userAddress));

    if (onProgress) {
        onProgress({
            phase: 'wallet',
            scanned: 0,
            total: totalToScan,
            current: 'Preparing multicall...',
        });
    }

    const walletResults = await batchMulticall(provider, walletCalls, 100);

    console.log('[Scanner] Processing wallet balance results...');
    walletResults.forEach((result, index) => {
        const poolAddress = SUPPORTED_POOLS[index];

        if (onProgress) {
            onProgress({
                phase: 'wallet',
                scanned: index + 1,
                total: totalToScan,
                current: poolAddress,
            });
        }

        if (result.success) {
            const balance = result.callInfo.decoder(result.returnData);
            if (parseFloat(balance) > 0) {
                console.log(`[Scanner] ✅ Found wallet balance: ${balance} BPT in pool ${poolAddress}`);
                results.push({
                    poolAddress,
                    walletBalance: balance,
                    masterchefBalance: '0',
                    farmId: POOL_FARMS[poolAddress] || null,
                    source: 'wallet',
                });
            }
        } else {
            console.warn(`[Scanner] Failed to get wallet balance for ${poolAddress}`);
        }
    });

    console.log('[Scanner] Phase 2: Scanning MasterChef staked balances with multicall...');
    const farmEntries = Object.entries(POOL_FARMS);
    const masterchefCalls = farmEntries.map(([, farmId]) =>
        createUserInfoCall(CONTRACTS.masterChef, farmId, userAddress),
    );

    if (onProgress) {
        onProgress({
            phase: 'masterchef',
            scanned: SUPPORTED_POOLS.length,
            total: totalToScan,
            current: 'Preparing multicall...',
        });
    }

    const masterchefResults = await batchMulticall(provider, masterchefCalls, 100);

    console.log('[Scanner] Processing MasterChef balance results...');
    masterchefResults.forEach((result, index) => {
        const [poolAddress, farmId] = farmEntries[index];
        const scanned = SUPPORTED_POOLS.length + index + 1;

        if (onProgress) {
            onProgress({
                phase: 'masterchef',
                scanned,
                total: totalToScan,
                current: poolAddress,
            });
        }

        if (result.success) {
            const balance = result.callInfo.decoder(result.returnData);
            if (parseFloat(balance) > 0) {
                console.log(
                    `[Scanner] ✅ Found MasterChef balance: ${balance} BPT in farm ${farmId} (pool ${poolAddress})`,
                );

                // Check if we already have this pool from wallet scan
                const existingIndex = results.findIndex((r) => r.poolAddress === poolAddress);
                if (existingIndex >= 0) {
                    results[existingIndex].masterchefBalance = balance;
                    results[existingIndex].farmId = farmId;
                } else {
                    results.push({
                        poolAddress,
                        walletBalance: '0',
                        masterchefBalance: balance,
                        farmId,
                        source: 'masterchef',
                    });
                }
            }
        } else {
            console.warn(`[Scanner] Failed to get MasterChef balance for farm ${farmId}`);
        }
    });

    console.log('[Scanner] ✅ Scan complete with multicall!');
    console.log('[Scanner] Found', results.length, 'positions with non-zero balances');

    // Enrich results with pool data
    results.forEach((result) => {
        const poolInfo = getPoolInfo(result.poolAddress);
        result.poolName = poolInfo.name;
        result.poolTokens = poolInfo.tokens;
    });

    return results;
}

/**
 * Scan specific pools for balances (both wallet and MasterChef if applicable)
 */
export async function scanSpecificPools(provider, userAddress, poolAddresses) {
    console.log('[Scanner] Scanning specific pools with multicall:', poolAddresses);
    const results = [];
    const normalizedAddresses = poolAddresses.map((addr) => addr.toLowerCase());

    // Create multicall for wallet balances
    const walletCalls = normalizedAddresses.map((poolAddress) => createBalanceOfCall(poolAddress, userAddress));

    // Create multicall for MasterChef balances (only for pools with farms)
    const farmCalls = [];
    const farmMapping = [];
    normalizedAddresses.forEach((poolAddress) => {
        const farmId = POOL_FARMS[poolAddress];
        if (farmId !== undefined) {
            farmCalls.push(createUserInfoCall(CONTRACTS.masterChef, farmId, userAddress));
            farmMapping.push({ poolAddress, farmId });
        }
    });

    // Execute multicalls
    const [walletResults, farmResults] = await Promise.all([
        batchMulticall(provider, walletCalls, 50),
        farmCalls.length > 0 ? batchMulticall(provider, farmCalls, 50) : Promise.resolve([]),
    ]);

    // Process results
    normalizedAddresses.forEach((poolAddress, index) => {
        try {
            const walletResult = walletResults[index];
            const walletBalance = walletResult.success ? walletResult.callInfo.decoder(walletResult.returnData) : '0';

            // Find corresponding MasterChef balance
            let masterchefBalance = '0';
            const farmId = POOL_FARMS[poolAddress];
            if (farmId !== undefined) {
                const farmIndex = farmMapping.findIndex((f) => f.poolAddress === poolAddress);
                if (farmIndex >= 0 && farmResults[farmIndex]) {
                    const farmResult = farmResults[farmIndex];
                    masterchefBalance = farmResult.success ? farmResult.callInfo.decoder(farmResult.returnData) : '0';
                }
            }

            // Only add if there's a non-zero balance
            if (parseFloat(walletBalance) > 0 || parseFloat(masterchefBalance) > 0) {
                results.push({
                    poolAddress,
                    walletBalance,
                    masterchefBalance,
                    farmId: farmId !== undefined ? farmId : null,
                });
            }
        } catch (error) {
            console.error(`[Scanner] Error processing results for pool ${poolAddress}:`, error.message);
        }
    });

    console.log('[Scanner] ✅ Specific pool scan complete. Found', results.length, 'positions');

    // Enrich results with pool data
    results.forEach((result) => {
        const poolInfo = getPoolInfo(result.poolAddress);
        result.poolName = poolInfo.name;
        result.poolTokens = poolInfo.tokens;
    });

    return results;
}

/**
 * Get total balance for a pool (wallet + MasterChef)
 */
export function getTotalBalance(position) {
    const wallet = parseFloat(position.walletBalance || 0);
    const masterchef = parseFloat(position.masterchefBalance || 0);
    return wallet + masterchef;
}
