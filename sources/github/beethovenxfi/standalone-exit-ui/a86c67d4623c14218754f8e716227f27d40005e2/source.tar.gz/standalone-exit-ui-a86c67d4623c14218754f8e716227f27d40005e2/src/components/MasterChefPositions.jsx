import { useState, useEffect } from 'react';
import * as masterchefUtils from '../utils/masterchef';

export function MasterChefPositions({ provider, signer, account, farmId }) {
  const [position, setPosition] = useState(null);
  const [loading, setLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState(false);
  const [error, setError] = useState(null);

  useEffect(() => {
    loadPosition();
  }, [account, farmId]);

  const loadPosition = async () => {
    if (!provider || !account || farmId === null || farmId === undefined) return;

    console.log('[MasterChefPositions] Loading position for farm', farmId);
    setLoading(true);
    setError(null);

    try {
      const balance = await masterchefUtils.getUserStakedBalance(provider, account, farmId);
      const rewards = await masterchefUtils.getPendingRewards(provider, account, farmId);

      console.log('[MasterChefPositions] ✅ Position loaded');
      setPosition({
        stakedBalance: balance,
        pendingRewards: rewards,
      });
    } catch (err) {
      console.error('[MasterChefPositions] ❌ Error loading position:', err);
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleHarvest = async () => {
    console.log('═══════════════════════════════════════════════');
    console.log('[MasterChefPositions] 🔘 Harvest button clicked');
    console.log('[MasterChefPositions] Signer available:', !!signer);
    console.log('[MasterChefPositions] Farm ID:', farmId);
    console.log('[MasterChefPositions] Pending Rewards:', position?.pendingRewards);

    if (!signer) {
      console.error('[MasterChefPositions] ❌ No signer available');
      alert('Please connect your wallet first');
      return;
    }

    setActionLoading(true);
    try {
      console.log('[MasterChefPositions] Starting harvest for farm', farmId);
      await masterchefUtils.harvest(signer, farmId);
      console.log('[MasterChefPositions] ✅ Harvest successful');
      alert('Rewards claimed successfully!');
      await loadPosition();
    } catch (err) {
      console.error('[MasterChefPositions] ❌ Harvest failed:', err);
      alert(`Error claiming rewards: ${err.message}`);
    } finally {
      setActionLoading(false);
    }
  };

  const handleWithdraw = async () => {
    console.log('═══════════════════════════════════════════════');
    console.log('[MasterChefPositions] 🔘 Withdraw button clicked');
    console.log('[MasterChefPositions] Signer available:', !!signer);
    console.log('[MasterChefPositions] Farm ID:', farmId);
    console.log('[MasterChefPositions] Staked Balance:', position?.stakedBalance);

    if (!signer) {
      console.error('[MasterChefPositions] ❌ No signer available');
      alert('Please connect your wallet first');
      return;
    }

    if (!position) {
      console.error('[MasterChefPositions] ❌ No position data');
      return;
    }

    const confirmed = window.confirm(
      `Withdraw ${position.stakedBalance} BPT from MasterChef?`
    );

    if (!confirmed) {
      console.log('[MasterChefPositions] User cancelled withdrawal');
      return;
    }

    setActionLoading(true);
    try {
      console.log('[MasterChefPositions] Starting withdrawal for farm', farmId);
      await masterchefUtils.withdraw(signer, farmId, position.stakedBalance);
      console.log('[MasterChefPositions] ✅ Withdrawal successful');
      alert('Withdrawn successfully!');
      await loadPosition();
    } catch (err) {
      console.error('[MasterChefPositions] ❌ Withdrawal failed:', err);
      alert(`Error withdrawing: ${err.message}`);
    } finally {
      setActionLoading(false);
    }
  };

  const handleEmergencyWithdraw = async () => {
    console.log('═══════════════════════════════════════════════');
    console.log('[MasterChefPositions] ⚠️ Emergency Withdraw button clicked');
    console.log('[MasterChefPositions] Signer available:', !!signer);
    console.log('[MasterChefPositions] Farm ID:', farmId);
    console.log('[MasterChefPositions] Staked Balance:', position?.stakedBalance);

    if (!signer) {
      console.error('[MasterChefPositions] ❌ No signer available');
      alert('Please connect your wallet first');
      return;
    }

    if (!position) {
      console.error('[MasterChefPositions] ❌ No position data');
      return;
    }

    const confirmed = window.confirm(
      `⚠️ EMERGENCY WITHDRAW ⚠️\n\n` +
      `This will withdraw ALL staked tokens (${position.stakedBalance} BPT) but FORFEIT all pending rewards (${position.pendingRewards} BEETS)!\n\n` +
      `This action should only be used in emergencies.\n\n` +
      `Are you ABSOLUTELY SURE you want to proceed?`
    );

    if (!confirmed) {
      console.log('[MasterChefPositions] User cancelled emergency withdrawal');
      return;
    }

    setActionLoading(true);
    try {
      console.log('[MasterChefPositions] Starting EMERGENCY withdrawal for farm', farmId);
      await masterchefUtils.emergencyWithdraw(signer, farmId);
      console.log('[MasterChefPositions] ✅ Emergency withdrawal successful');
      alert('Emergency withdrawal completed! All staked tokens have been withdrawn (rewards were forfeited).');
      await loadPosition();
    } catch (err) {
      console.error('[MasterChefPositions] ❌ Emergency withdrawal failed:', err);
      alert(`Error during emergency withdrawal: ${err.message}`);
    } finally {
      setActionLoading(false);
    }
  };

  if (loading) {
    return (
      <div style={{ padding: '15px', border: '1px solid #ccc', borderRadius: '4px' }}>
        <h4>MasterChef Position</h4>
        <p>Loading...</p>
      </div>
    );
  }

  if (!position || parseFloat(position.stakedBalance) === 0) {
    return (
      <div style={{ padding: '15px', border: '1px solid #ccc', borderRadius: '4px' }}>
        <h4>MasterChef Position</h4>
        <p>No MasterChef position found for this pool.</p>
      </div>
    );
  }

  return (
    <div style={{ padding: '15px', border: '1px solid #ccc', borderRadius: '4px' }}>
      <h4>MasterChef Position</h4>

      {error && <div style={{ color: 'red', marginBottom: '10px' }}>Error: {error}</div>}

      <div style={{ padding: '10px', backgroundColor: '#f9f9f9', borderRadius: '4px' }}>
        <p>Staked: {parseFloat(position.stakedBalance).toFixed(6)} BPT</p>
        <p>Pending Rewards: {parseFloat(position.pendingRewards).toFixed(6)} BEETS</p>
        {parseFloat(position.pendingRewards) === 0 && (
          <p style={{ fontSize: '12px', color: '#666', fontStyle: 'italic' }}>
            (Claim button disabled - no pending rewards)
          </p>
        )}

        <div style={{ marginTop: '10px', display: 'flex', gap: '10px' }}>
          <button
            onClick={handleHarvest}
            disabled={actionLoading || parseFloat(position.pendingRewards) === 0}
            style={{
              padding: '8px 16px',
              cursor: actionLoading || parseFloat(position.pendingRewards) === 0 ? 'not-allowed' : 'pointer',
              backgroundColor: '#4CAF50',
              color: 'white',
              border: 'none',
              borderRadius: '4px',
              opacity: actionLoading || parseFloat(position.pendingRewards) === 0 ? 0.6 : 1,
            }}
          >
            {actionLoading ? 'Processing...' : 'Claim Rewards'}
          </button>

          <button
            onClick={handleWithdraw}
            disabled={actionLoading || parseFloat(position.stakedBalance) === 0}
            style={{
              padding: '8px 16px',
              cursor: actionLoading || parseFloat(position.stakedBalance) === 0 ? 'not-allowed' : 'pointer',
              backgroundColor: '#ff9800',
              color: 'white',
              border: 'none',
              borderRadius: '4px',
            }}
          >
            {actionLoading ? 'Processing...' : 'Withdraw All'}
          </button>
        </div>

        <div style={{ marginTop: '15px', paddingTop: '15px', borderTop: '1px solid #ddd' }}>
          <p style={{ fontSize: '12px', color: '#666', marginBottom: '8px', fontWeight: 'bold' }}>
            ⚠️ Emergency Only:
          </p>
          <button
            onClick={handleEmergencyWithdraw}
            disabled={actionLoading || parseFloat(position.stakedBalance) === 0}
            style={{
              padding: '8px 16px',
              cursor: actionLoading || parseFloat(position.stakedBalance) === 0 ? 'not-allowed' : 'pointer',
              backgroundColor: '#d32f2f',
              color: 'white',
              border: 'none',
              borderRadius: '4px',
            }}
          >
            {actionLoading ? 'Processing...' : '⚠️ Emergency Withdraw (Forfeit Rewards)'}
          </button>
          <p style={{ fontSize: '11px', color: '#999', marginTop: '5px', fontStyle: 'italic' }}>
            Only use in emergencies. Withdraws all tokens but forfeits all pending rewards.
          </p>
        </div>
      </div>
    </div>
  );
}
