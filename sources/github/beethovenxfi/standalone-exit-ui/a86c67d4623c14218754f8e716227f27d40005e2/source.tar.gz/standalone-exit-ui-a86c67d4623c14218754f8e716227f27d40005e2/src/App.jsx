import { RpcProvider } from './contexts/RpcContext';
import { WalletProvider } from './contexts/WalletContext';
import { WalletConnect } from './components/WalletConnect';
import { PositionManager } from './components/PositionManager';
import './App.css';

function App() {
  return (
    <RpcProvider>
      <WalletProvider>
        <div className="app">
          <WalletConnect />
          <PositionManager />
        </div>
      </WalletProvider>
    </RpcProvider>
  );
}

export default App;
