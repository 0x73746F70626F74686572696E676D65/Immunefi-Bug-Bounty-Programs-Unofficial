import { ethers } from 'ethers';
import { CONTRACTS, POOL_TO_FARM_MAP } from '../config/contracts';
import MasterChefAbi from '../abis/BeethovenxMasterChef.json';

/**
 * Find farm ID for a given pool address by querying MasterChef
 * Returns null if not found
 */
export async function findFarmIdByPoolAddress(provider, poolAddress) {
    console.log('[MasterChef] Finding farm ID for pool:', poolAddress);
    const contract = new ethers.Contract(CONTRACTS.masterChef, MasterChefAbi, provider);

    // First check hardcoded mapping
    const normalizedAddress = poolAddress.toLowerCase();
    console.log('[MasterChef] Checking pre-configured pool mappings...');
    if (POOL_TO_FARM_MAP[normalizedAddress]) {
        console.log('[MasterChef] ✅ Found in mapping! Farm ID:', POOL_TO_FARM_MAP[normalizedAddress]);
        return POOL_TO_FARM_MAP[normalizedAddress];
    }

    return null;

    // console.log('[MasterChef] Not in mapping, querying MasterChef contract...');
    // try {
    //     // Get pool length (number of farms)
    //     const poolLength = await contract.poolLength();
    //     console.log('[MasterChef] Total number of farms:', poolLength.toNumber());

    //     // Search through all pools to find matching address
    //     console.log('[MasterChef] Searching through farms...');
    //     for (let farmId = 0; farmId < poolLength.toNumber(); farmId++) {
    //         try {
    //             const lpTokenAddress = await contract.lpTokens(farmId);
    //             console.log(`[MasterChef] Checking farm ID ${farmId}: LP Token Address = ${lpTokenAddress}`);

    //             // poolInfo returns: lpToken, allocPoint, lastRewardBlock, accBeetsPerShare
    //             if (lpTokenAddress.toLowerCase() === normalizedAddress) {
    //                 console.log('[MasterChef] ✅ Found matching farm! Farm ID:', farmId);
    //                 return farmId;
    //             }
    //         } catch (err) {
    //             // Skip invalid pool IDs
    //             continue;
    //         }
    //     }

    //     console.log('[MasterChef] ❌ No matching farm found');
    //     return null;
    // } catch (error) {
    //     console.error('[MasterChef] ❌ Error finding farm ID:', error);
    //     return null;
    // }
}

/**
 * Get user's staked balance in a farm
 */
export async function getUserStakedBalance(provider, userAddress, farmId) {
    console.log('[MasterChef] Getting staked balance for farm', farmId, 'user:', userAddress);
    const contract = new ethers.Contract(CONTRACTS.masterChef, MasterChefAbi, provider);

    try {
        const userInfo = await contract.userInfo(farmId, userAddress);
        const balance = ethers.utils.formatEther(userInfo.amount);
        console.log('[MasterChef] Staked balance:', balance);
        return balance;
    } catch (error) {
        console.error('[MasterChef] ❌ Error fetching staked balance:', error);
        return '0';
    }
}

/**
 * Get pending BEETS rewards for a user in a farm
 */
export async function getPendingRewards(provider, userAddress, farmId) {
    console.log('[MasterChef] Getting pending rewards for farm', farmId);
    const contract = new ethers.Contract(CONTRACTS.masterChef, MasterChefAbi, provider);

    try {
        const pending = await contract.pendingBeets(farmId, userAddress);
        const rewards = ethers.utils.formatEther(pending);
        console.log('[MasterChef] Pending rewards:', rewards, 'BEETS');
        return rewards;
    } catch (error) {
        console.error('[MasterChef] ❌ Error fetching pending rewards:', error);
        return '0';
    }
}

/**
 * Harvest (claim) rewards from a farm
 */
export async function harvest(signer, farmId) {
    console.log('[MasterChef] Harvesting rewards from farm', farmId);
    const contract = new ethers.Contract(CONTRACTS.masterChef, MasterChefAbi, signer);
    const userAddress = await signer.getAddress();
    console.log('[MasterChef] Submitting harvest transaction...');
    const tx = await contract.harvest(farmId, userAddress);
    console.log('[MasterChef] Transaction submitted:', tx.hash);
    console.log('[MasterChef] Waiting for confirmation...');
    const receipt = await tx.wait();
    console.log('[MasterChef] ✅ Harvest confirmed in block:', receipt.blockNumber);
    return receipt;
}

/**
 * Withdraw staked tokens from a farm
 */
export async function withdraw(signer, farmId, amount) {
    console.log('[MasterChef] Withdrawing', amount, 'from farm', farmId);
    const contract = new ethers.Contract(CONTRACTS.masterChef, MasterChefAbi, signer);
    const amountWei = ethers.utils.parseEther(amount);
    const userAddress = await signer.getAddress();
    console.log('[MasterChef] Submitting withdraw transaction...');
    const tx = await contract.withdrawAndHarvest(farmId, amountWei, userAddress);
    console.log('[MasterChef] Transaction submitted:', tx.hash);
    console.log('[MasterChef] Waiting for confirmation...');
    const receipt = await tx.wait();
    console.log('[MasterChef] ✅ Withdraw confirmed in block:', receipt.blockNumber);
    return receipt;
}

/**
 * Emergency withdraw (forfeits rewards) - USE WITH CAUTION
 * This withdraws all staked tokens but forfeits all pending rewards
 */
export async function emergencyWithdraw(signer, farmId) {
    console.log('⚠️ [MasterChef] EMERGENCY WITHDRAW from farm', farmId);
    console.log('⚠️ [MasterChef] WARNING: This will FORFEIT all pending rewards!');
    const contract = new ethers.Contract(CONTRACTS.masterChef, MasterChefAbi, signer);
    const userAddress = await signer.getAddress();
    console.log('[MasterChef] Submitting emergency withdraw transaction...');
    const tx = await contract.emergencyWithdraw(farmId, userAddress);
    console.log('[MasterChef] Transaction submitted:', tx.hash);
    console.log('[MasterChef] Waiting for confirmation...');
    const receipt = await tx.wait();
    console.log('[MasterChef] ✅ Emergency withdraw confirmed in block:', receipt.blockNumber);
    return receipt;
}
