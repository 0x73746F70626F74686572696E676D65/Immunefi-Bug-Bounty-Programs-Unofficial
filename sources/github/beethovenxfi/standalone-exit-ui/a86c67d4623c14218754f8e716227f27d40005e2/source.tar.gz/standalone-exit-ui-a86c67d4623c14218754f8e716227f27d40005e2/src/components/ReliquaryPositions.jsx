import { useState } from 'react';
import * as reliquaryUtils from '../utils/reliquary';

export function ReliquaryPositions({ provider, signer, account }) {
  const [relics, setRelics] = useState([]);
  const [loading, setLoading] = useState(false);
  const [actionLoading, setActionLoading] = useState(null);
  const [error, setError] = useState(null);
  const [scanned, setScanned] = useState(false);

  const loadRelics = async () => {
    if (!provider || !account) {
      alert('Please connect your wallet first');
      return;
    }

    console.log('[ReliquaryPositions] Loading all relics for user');
    setLoading(true);
    setError(null);

    try {
      const userRelics = await reliquaryUtils.getUserRelics(provider, account);

      // Get pending rewards for each relic
      console.log('[ReliquaryPositions] Fetching pending rewards for', userRelics.length, 'relics');
      const relicsWithRewards = await Promise.all(
        userRelics.map(async (relic) => {
          const rewards = await reliquaryUtils.getPendingRewards(provider, relic.relicId);
          return { ...relic, pendingRewards: rewards };
        })
      );

      // Filter out relics with 0 BPT balance
      const relicsWithBalance = relicsWithRewards.filter(relic => parseFloat(relic.amount) > 0);

      console.log('[ReliquaryPositions] ✅ Loaded', relicsWithBalance.length, 'relics with balance (filtered from', relicsWithRewards.length, 'total)');
      setRelics(relicsWithBalance);
      setScanned(true);
    } catch (err) {
      console.error('[ReliquaryPositions] ❌ Error loading relics:', err);
      setError(err.message || 'Unknown error occurred');
      setScanned(true); // Mark as scanned even on error so user can see the error message
    } finally {
      setLoading(false);
    }
  };

  const handleHarvest = async (relicId) => {
    console.log('═══════════════════════════════════════════════');
    console.log('[ReliquaryPositions] 🔘 Harvest button clicked for relic', relicId);
    console.log('[ReliquaryPositions] Signer available:', !!signer);

    if (!signer) {
      console.error('[ReliquaryPositions] ❌ No signer available');
      alert('Please connect your wallet first');
      return;
    }

    setActionLoading(`harvest-${relicId}`);
    try {
      console.log('[ReliquaryPositions] Starting harvest for relic', relicId);
      await reliquaryUtils.harvestRelic(signer, relicId);
      console.log('[ReliquaryPositions] ✅ Harvest successful');
      alert('Rewards claimed successfully!');
      await loadRelics();
    } catch (err) {
      console.error('[ReliquaryPositions] ❌ Harvest failed:', err);
      alert(`Error claiming rewards: ${err.message}`);
    } finally {
      setActionLoading(null);
    }
  };

  const handleWithdraw = async (relic) => {
    console.log('═══════════════════════════════════════════════');
    console.log('[ReliquaryPositions] 🔘 Withdraw button clicked for relic', relic.relicId);
    console.log('[ReliquaryPositions] Signer available:', !!signer);
    console.log('[ReliquaryPositions] Relic amount:', relic.amount);

    if (!signer) {
      console.error('[ReliquaryPositions] ❌ No signer available');
      alert('Please connect your wallet first');
      return;
    }

    const confirmed = window.confirm(
      `Withdraw ${relic.amount} BPT from Relic #${relic.relicId}?`
    );

    if (!confirmed) {
      console.log('[ReliquaryPositions] User cancelled withdrawal');
      return;
    }

    setActionLoading(`withdraw-${relic.relicId}`);
    try {
      console.log('[ReliquaryPositions] Starting withdrawal for relic', relic.relicId);
      await reliquaryUtils.withdrawAndHarvest(signer, relic.amount, relic.relicId);
      console.log('[ReliquaryPositions] ✅ Withdrawal successful');
      alert('Withdrawn successfully!');
      await loadRelics();
    } catch (err) {
      console.error('[ReliquaryPositions] ❌ Withdrawal failed:', err);
      alert(`Error withdrawing: ${err.message}`);
    } finally {
      setActionLoading(null);
    }
  };

  if (!scanned) {
    return (
      <div style={{ padding: '15px', border: '1px solid #ccc', borderRadius: '4px' }}>
        <h4>Reliquary Positions (maBEETS)</h4>
        <p style={{ marginBottom: '15px' }}>Scan for your Reliquary relics (maBEETS NFT positions).</p>
        <button
          onClick={loadRelics}
          disabled={loading || !account}
          style={{
            padding: '10px 20px',
            fontSize: '14px',
            cursor: loading || !account ? 'not-allowed' : 'pointer',
            backgroundColor: '#4CAF50',
            color: 'white',
            border: 'none',
            borderRadius: '4px',
          }}
        >
          {loading ? 'Scanning...' : '🔍 Scan for Relics'}
        </button>
      </div>
    );
  }

  if (relics.length === 0) {
    return (
      <div style={{ padding: '15px', border: '1px solid #ccc', borderRadius: '4px' }}>
        <h4>Reliquary Positions (maBEETS)</h4>
        <p>No reliquary positions found.</p>
        <button
          onClick={loadRelics}
          disabled={loading}
          style={{
            padding: '8px 16px',
            fontSize: '13px',
            marginTop: '10px',
            cursor: loading ? 'not-allowed' : 'pointer',
            backgroundColor: '#4CAF50',
            color: 'white',
            border: 'none',
            borderRadius: '4px',
          }}
        >
          {loading ? 'Scanning...' : 'Rescan'}
        </button>
      </div>
    );
  }

  return (
    <div style={{ padding: '15px', border: '1px solid #ccc', borderRadius: '4px' }}>
      <h4>Reliquary Positions (maBEETS)</h4>

      {error && <div style={{ color: 'red', marginBottom: '10px' }}>Error: {error}</div>}
      
      <button
        onClick={loadRelics}
        disabled={loading}
        style={{
          padding: '6px 12px',
          fontSize: '12px',
          marginBottom: '10px',
          cursor: loading ? 'not-allowed' : 'pointer',
          backgroundColor: '#2196F3',
          color: 'white',
          border: 'none',
          borderRadius: '4px',
        }}
      >
        {loading ? 'Refreshing...' : '🔄 Refresh'}
      </button>

      {relics.map((relic) => (
        <div
          key={relic.relicId}
          style={{
            padding: '10px',
            marginBottom: '10px',
            backgroundColor: '#f9f9f9',
            borderRadius: '4px',
          }}
        >
          <p>
            <strong>Relic #{relic.relicId}</strong> | Level: {relic.level}
          </p>
          <p>Staked: {parseFloat(relic.amount).toFixed(6)} BPT</p>
          <p>Pending Rewards: {parseFloat(relic.pendingRewards).toFixed(6)} BEETS</p>

          <div style={{ marginTop: '10px', display: 'flex', gap: '10px' }}>
            <button
              onClick={() => handleHarvest(relic.relicId)}
              disabled={actionLoading === `harvest-${relic.relicId}` || parseFloat(relic.pendingRewards) === 0}
              style={{
                padding: '8px 16px',
                cursor: actionLoading === `harvest-${relic.relicId}` || parseFloat(relic.pendingRewards) === 0 ? 'not-allowed' : 'pointer',
                backgroundColor: '#4CAF50',
                color: 'white',
                border: 'none',
                borderRadius: '4px',
              }}
            >
              {actionLoading === `harvest-${relic.relicId}` ? 'Claiming...' : 'Claim Rewards'}
            </button>

            <button
              onClick={() => handleWithdraw(relic)}
              disabled={actionLoading === `withdraw-${relic.relicId}` || parseFloat(relic.amount) === 0}
              style={{
                padding: '8px 16px',
                cursor: actionLoading === `withdraw-${relic.relicId}` || parseFloat(relic.amount) === 0 ? 'not-allowed' : 'pointer',
                backgroundColor: '#ff9800',
                color: 'white',
                border: 'none',
                borderRadius: '4px',
              }}
            >
              {actionLoading === `withdraw-${relic.relicId}` ? 'Withdrawing...' : 'Withdraw & Harvest'}
            </button>
          </div>
        </div>
      ))}
    </div>
  );
}
