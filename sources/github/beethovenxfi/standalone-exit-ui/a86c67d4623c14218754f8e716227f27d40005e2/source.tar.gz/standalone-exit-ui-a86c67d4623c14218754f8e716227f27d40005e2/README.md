# Beethoven X - Emergency Exit UI

A minimal, standalone UI for managing and exiting Beethoven X DeFi positions on Fantom Opera. This application uses only RPC calls and does not depend on backend services or subgraphs.

## Features

-   **Reliquary (maBEETS) Positions**: View, claim rewards, and withdraw from Reliquary relics
-   **MasterChef Positions**: View, claim rewards, and withdraw from MasterChef farms
-   **Pool Positions**: Exit pool positions proportionally (get back all underlying tokens)
-   **Legacy fBEETS**: Exit legacy fBEETS positions
-   **sftmx**: Unstake sftmx (2-step process with 24h delay)

## Prerequisites

-   Node.js 16+ and npm
-   MetaMask or another Web3 wallet browser extension
-   FTM on Fantom Opera network for gas fees

## Installation

```bash
cd standalone-exit-ui
npm install
```

## Running the App

```bash
npm run dev
```

The app will start on http://localhost:3001

## How to Use

### 1. Connect Wallet

Click "Connect Wallet" and approve the connection in MetaMask. The app will automatically switch to Fantom Opera network if you're on a different chain.

### 2. Scan for Your Positions

You have three options to find your positions:

**Option A: Scan All Balances (Recommended)**

1. Click the "🔍 Scan All Balances" button
2. The app will automatically check:
    - Wallet BPT balances for all 299 supported pools
    - Staked balances in all 163 MasterChef farms
3. View all your positions in a sortable table
4. Click "Manage" on any position to interact with it

This comprehensive scan will find all your positions across the entire protocol!

**Option B: Manual Pool Address Entry**

1. Enter a specific pool address (BPT token address) in the input field
2. Click "Scan" to search for your positions in that specific pool
3. The app will query MasterChef and check your balances

### 3. Manage Positions

#### Reliquary (maBEETS)

**Note: Reliquary positions are in the "Other Positions" section at the bottom.**

-   Click "🔍 Scan for Relics" to find your Reliquary positions
-   **Claim Rewards**: Harvest pending BEETS rewards from a relic
-   **Withdraw & Harvest**: Withdraw all staked BPT and claim rewards in one transaction

The Reliquary scanner checks ALL your relics across ALL farms.

#### MasterChef

-   **Claim Rewards**: Harvest pending BEETS rewards
-   **Withdraw All**: Withdraw all staked BPT from the farm (also claims rewards)

#### Pool Exit

-   **Exit Pool Proportionally**: Withdraw all underlying tokens proportionally to your BPT balance
    -   Automatically approves BPT spending if needed
    -   Returns all pool tokens (e.g., if pool has ETH/USDC, you get both back)

#### Legacy fBEETS

-   **Exit fBEETS**: Convert your fBEETS back to BEETS
-   This section appears at the bottom and doesn't require a pool address

#### sftmx

-   **Step 1 - Start Unstaking**:

    -   Initiates the unstaking process
    -   Returns a **Withdrawal ID** - SAVE THIS!
    -   Starts 24-hour delay period

-   **Step 2 - Complete Withdrawal**:
    -   After 24 hours, enter the Withdrawal ID
    -   Click "Complete Withdrawal" to receive your FTM

## Pool Address Examples

Common pool addresses you might need:

-   **maBEETS Pool**: `0x9e4341acef4147196e99d648c5e43b3fc9d02678`
-   **Legacy fBEETS Pool**: `0xcdE5a11a4ACB4eE4c805352Cec57E236bdBC3837`

You can find pool addresses from:

-   FTMScan by looking up pool tokens
-   Beethoven X main UI
-   Transaction history in your wallet

## Debug Logging

The application includes **comprehensive console logging** to help you track every step of the process:

### How to View Logs

1. Open your browser's **Developer Console** (F12 or Right-click → Inspect → Console tab)
2. All logs are prefixed with their component/module name in brackets (e.g., `[Wallet]`, `[MasterChef]`, `[Pool]`)
3. Key events use visual indicators:
    - ✅ Success messages
    - ❌ Error messages
    - ⚠️ Warning messages

### What Gets Logged

**Balance Scanner:**

-   Comprehensive scan progress (wallet + MasterChef phases)
-   Found positions with balances
-   Scan completion statistics

**Wallet Operations:**

-   Connection attempts and account detection
-   Network switching and addition
-   Provider initialization

**Position Scanning:**

-   Pool ID resolution
-   Farm ID lookup (from mapping or MasterChef query)
-   Position balance checks
-   Reward calculations

**Contract Interactions:**

-   Every transaction submission with hash
-   Transaction confirmation with block number
-   Contract method calls and responses
-   Approval transactions

**Example Console Output:**

```
[Wallet] Starting connection process...
[Wallet] Requesting account access...
[Wallet] ✅ Connected successfully: 0x1234...
═══════════════════════════════════════════════
[PositionManager] Starting position scan...
[PositionManager] Pool address: 0x843716...
[Pool] Getting pool ID from pool contract: 0x843716...
[Pool] ✅ Pool ID: 0x843716...0000053b
[MasterChef] Finding farm ID for pool: 0x843716...
[MasterChef] Checking pre-configured pool mappings...
[MasterChef] ✅ Found in mapping! Farm ID: 121
[Reliquary] Getting relics for user: 0x1234...
[Reliquary] ✅ Found 2 relics with positions
```

### Filtering Logs

To filter logs by component, use your browser's console filter:

-   Type `[Wallet]` to see only wallet-related logs
-   Type `[MasterChef]` to see only MasterChef operations
-   Type `✅` to see only successful operations
-   Type `❌` to see only errors

## Important Notes

### Security

-   This app only reads data and submits transactions you explicitly approve
-   All transactions require your wallet approval
-   Contract addresses are hardcoded and match production Beethoven X contracts
-   Always verify transaction details in MetaMask before confirming

### Gas Fees

-   All operations require FTM for gas
-   Make sure you have sufficient FTM in your wallet
-   Exit operations may be more gas-intensive

### Slippage Protection

-   Pool exits use minimum amount out = 0 for emergency situations
-   This means NO slippage protection - you get whatever the pool gives you
-   Use with caution if there's potential for price manipulation

### Common Issues

**"No positions found"**

-   Make sure you entered the correct pool address
-   Check that you actually have positions in that pool
-   Verify you're on the Fantom Opera network

**"Transaction Failed"**

-   Check you have enough FTM for gas
-   Make sure you're not trying to withdraw more than you have
-   For sftmx withdrawals, ensure 24 hours have passed

**"Approval Failed"**

-   Some operations require token approval first
-   The app will prompt you to approve before the main transaction
-   Approve the first transaction, then retry the operation

## Technical Details

### Dependencies

-   **React 18**: UI framework
-   **ethers.js 5**: Ethereum/blockchain interactions
-   **Vite**: Build tool and dev server

### Contract Addresses (Fantom Opera)

-   **Balancer Vault**: `0x20dd72Ed959b6147912C2e529F0a0C651c33c9ce`
-   **MasterChef**: `0x8166994d9ebBe5829EC86Bd81258149B87faCfd3`
-   **Reliquary**: `0x1ed6411670c709f4e163854654bd52c74e66d7ec`
-   **fBEETS**: `0xfcef8a994209d6916eb2c86cdd2afd60aa6f54b1`
-   **sftmx**: `0xd7028092c830b5c8fce061af2e593413ebbc1fc1`
-   **sftmx Staking**: `0xB458BfC855ab504a8a327720FcEF98886065529b`

### RPC Endpoint

-   Default: `https://rpcapi.fantom.network`
-   Can be modified in `src/config/contracts.js`

## Building for Production

```bash
npm run build
```

The built files will be in the `dist/` folder. You can serve them with any static file server or upload to IPFS.

## Deploy to Vercel

This app is ready to deploy to Vercel with zero configuration:

### Option 1: Deploy via GitHub (Recommended)

1. Push your code to a GitHub repository
2. Go to [vercel.com](https://vercel.com)
3. Click "New Project"
4. Import your GitHub repository
5. Click "Deploy" (Vercel will auto-detect the Vite configuration)

### Option 2: Deploy via Vercel CLI

```bash
# Install Vercel CLI globally
npm install -g vercel

# Deploy from your project directory
vercel

# For production deployment
vercel --prod
```

The app includes a `vercel.json` configuration file that handles:
- Automatic SPA routing
- Optimized build settings
- Proper output directory configuration

## Customization

### Pool Farm Mappings

The app includes **180+ pre-configured pool-to-farm mappings** in `src/config/poolFarms.js`, which means:

-   **Instant farm ID resolution** for known pools (no MasterChef query needed)
-   Covers virtually all active Beethoven X farms on Fantom
-   Significantly faster position scanning

The app will automatically fall back to querying MasterChef if a pool isn't in the pre-configured list.

#### Adding Custom Pool Mappings

To add custom pools, edit `src/config/poolFarms.js`:

```javascript
export const POOL_FARMS = {
    '0xpooladdress1': 10,
    '0xpooladdress2': 15,
    // ... add your custom mappings
};
```

### Changing RPC Endpoint

You can change the RPC endpoint in two ways:

**Option 1: Via UI (Recommended)**
1. Click the "Configure RPC" button at the top of the app
2. Enter your custom RPC URL
3. Click "Apply"

The custom RPC is saved in localStorage and persists across sessions.

**Option 2: Change Default in Code**

Edit `src/config/contracts.js`:

```javascript
export const RPC_URL = 'https://your-rpc-endpoint';
```

## Support

This is a minimal emergency exit UI. For the full Beethoven X experience with better UX, analytics, and more features, visit:

-   Main App: https://beets.fi
-   Docs: https://docs.beets.fi
-   Discord: https://beets.fi/discord

## License

This is a utility tool for the Beethoven X protocol. Use at your own risk.
