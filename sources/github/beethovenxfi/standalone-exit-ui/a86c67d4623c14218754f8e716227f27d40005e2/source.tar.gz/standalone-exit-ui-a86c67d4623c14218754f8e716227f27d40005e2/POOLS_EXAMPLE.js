// OPTIONAL: Pool address to Farm ID mapping
// If you have a list of pools and their farm IDs, you can add them here
// to avoid querying MasterChef every time
//
// To use this:
// 1. Copy this file to src/config/pools.js
// 2. Import it in src/config/contracts.js and merge with POOL_TO_FARM_MAP
//
// Format: [pool address (lowercase)]: farm ID (number)

export const POOLS = {
  // Example:
  // '0xcde5a11a4acb4ee4c805352cec57e236bdbc3837': 22,  // Legacy fBEETS pool
  // '0x9e4341acef4147196e99d648c5e43b3fc9d02678': 2,   // maBEETS Reliquary pool

  // Add your pool mappings here:
  // '0xpool_address_1': 10,
  // '0xpool_address_2': 15,
  // '0xpool_address_3': 20,
};
