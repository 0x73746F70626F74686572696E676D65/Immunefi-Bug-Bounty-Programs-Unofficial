const { ethers } = require('ethers');
const fs = require('fs');
const path = require('path');

// Configuration
const RPC_URL = 'https://rpc.ftm.tools';
const MASTERCHEF_ADDRESS = '0x8166994d9ebBe5829EC86Bd81258149B87faCfd3';

// MasterChef ABI - only the methods we need
const MASTERCHEF_ABI = [
  'function poolLength() external view returns (uint256)',
  'function lpTokens(uint256) external view returns (address)',
];

async function scanAllFarms() {
  console.log('═══════════════════════════════════════════════');
  console.log('Scanning MasterChef Farms');
  console.log('═══════════════════════════════════════════════');
  console.log('RPC URL:', RPC_URL);
  console.log('MasterChef Address:', MASTERCHEF_ADDRESS);
  console.log('');

  // Connect to provider with explicit network configuration
  const network = {
    name: 'fantom',
    chainId: 250,
  };
  const provider = new ethers.providers.JsonRpcProvider(RPC_URL, network);
  const contract = new ethers.Contract(MASTERCHEF_ADDRESS, MASTERCHEF_ABI, provider);

  // Get total number of pools
  console.log('Fetching pool length...');
  const poolLength = await contract.poolLength();
  console.log('✅ Total farms:', poolLength.toString());
  console.log('');

  // Scan all farms
  const poolFarms = {};
  let successCount = 0;
  let errorCount = 0;

  console.log('Scanning farms...');
  for (let farmId = 0; farmId < poolLength.toNumber(); farmId++) {
    try {
      const lpTokenAddress = await contract.lpTokens(farmId);
      const normalizedAddress = lpTokenAddress.toLowerCase();
      poolFarms[normalizedAddress] = farmId;
      successCount++;

      if ((farmId + 1) % 10 === 0) {
        console.log(`Progress: ${farmId + 1}/${poolLength} farms scanned...`);
      }
    } catch (err) {
      console.error(`❌ Error scanning farm ${farmId}:`, err.message);
      errorCount++;
    }
  }

  console.log('');
  console.log('═══════════════════════════════════════════════');
  console.log('Scan Complete!');
  console.log('═══════════════════════════════════════════════');
  console.log('Total farms scanned:', poolLength.toString());
  console.log('Successful:', successCount);
  console.log('Errors:', errorCount);
  console.log('Unique pool addresses:', Object.keys(poolFarms).length);
  console.log('');

  // Generate the JavaScript file content
  const fileContent = `// Auto-generated pool address to farm ID mapping
// Generated on: ${new Date().toISOString()}
// Total farms: ${successCount}

export const POOL_FARMS = ${JSON.stringify(poolFarms, null, 2)};
`;

  // Write to file
  const outputPath = path.join(__dirname, '../src/config/poolFarms.js');
  fs.writeFileSync(outputPath, fileContent);
  console.log('✅ File written to:', outputPath);
  console.log('');

  // Show sample entries
  console.log('Sample entries:');
  const entries = Object.entries(poolFarms).slice(0, 5);
  entries.forEach(([address, farmId]) => {
    console.log(`  ${address}: ${farmId}`);
  });
  if (Object.keys(poolFarms).length > 5) {
    console.log(`  ... and ${Object.keys(poolFarms).length - 5} more`);
  }
}

// Run the scan
scanAllFarms()
  .then(() => {
    console.log('');
    console.log('Done!');
    process.exit(0);
  })
  .catch((err) => {
    console.error('');
    console.error('❌ Fatal error:', err);
    process.exit(1);
  });
