'use client'

import { getChainId } from '@repo/lib/config/app.config'
import { getNetworkConfig } from '@repo/lib/config/networks'
import { ManagedTransactionButton } from '@repo/lib/modules/transactions/transaction-steps/TransactionButton'
import {
  ManagedResult,
  TransactionLabels,
  TransactionStep,
} from '@repo/lib/modules/transactions/transaction-steps/lib'
import { useState } from 'react'
import { ManagedTransactionInput } from '@repo/lib/modules/web3/contracts/useManagedTransaction'
import { useUserAccount } from '@repo/lib/modules/web3/UserAccountProvider'
import { noop } from 'lodash'
import type { GqlChain } from '@repo/lib/shared/services/api/generated/graphql'
import { useTokenBalances } from '@repo/lib/modules/tokens/TokenBalancesProvider'
import { useGetUserWithdraws } from './useGetUserWithdraws'
import { useGetUserNumWithdraws } from './useGetUserNumWithdraws'
import { useGetUnstakeValidators } from './useGetUnstakeValidators'
import { isTransactionSuccess } from '@repo/lib/modules/transactions/transaction-steps/transaction.helper'

export function useLstUnstakeStep(
  sharesAmount: string,
  chain: GqlChain,
  enabled: boolean,
  unstakeEnabled: boolean
) {
  const [transaction, setTransaction] = useState<ManagedResult | undefined>()
  const { isConnected } = useUserAccount()
  const { refetchBalances } = useTokenBalances()

  const { userNumWithdraws, refetch: refetchUserNumWithdraws } = useGetUserNumWithdraws(
    chain,
    enabled
  )

  const { refetch: refetchWithdrawals } = useGetUserWithdraws(chain, userNumWithdraws, enabled)
  const { validators } = useGetUnstakeValidators(sharesAmount, chain, unstakeEnabled)

  function onSuccess() {
    refetchBalances()
    refetchUserNumWithdraws()
    refetchWithdrawals()
  }

  const labels: TransactionLabels = {
    init: 'Unstake',
    title: 'Unstake',
    confirming: 'Confirming unstake...',
    confirmed: 'Unstaked!',
    tooltip: 'tooltip',
  }

  const props: ManagedTransactionInput = {
    labels,
    chainId: getChainId(chain),
    contractId: 'beets.lstStaking',
    contractAddress: getNetworkConfig(chain).contracts.beets?.lstStakingProxy || '',
    functionName: 'undelegateMany',
    args: [
      validators.map(validator => BigInt(validator.validatorId)),
      validators.map(validator => validator.unstakeAmountShares),
    ],
    enabled: isConnected && !!sharesAmount && validators.length > 0 && enabled,
    onTransactionChange: setTransaction,
  }

  const isComplete = () => isConnected && isTransactionSuccess(transaction)

  const step: TransactionStep = {
    id: 'unstakeLst',
    labels,
    stepType: 'unstakeLst',
    transaction,
    isComplete,
    onActivated: noop,
    onDeactivated: noop,
    onSuccess,
    renderAction: () => <ManagedTransactionButton id="unstakeLst" {...props} />,
  }

  return { step }
}
