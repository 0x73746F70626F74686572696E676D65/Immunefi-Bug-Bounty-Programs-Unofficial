'use client'

import { getChainId } from '@repo/lib/config/app.config'
import { getNetworkConfig } from '@repo/lib/config/networks'
import { ManagedTransactionButton } from '@repo/lib/modules/transactions/transaction-steps/TransactionButton'
import {
  ManagedResult,
  TransactionLabels,
  TransactionStep,
} from '@repo/lib/modules/transactions/transaction-steps/lib'
import { useState } from 'react'
import { ManagedTransactionInput } from '@repo/lib/modules/web3/contracts/useManagedTransaction'
import { useUserAccount } from '@repo/lib/modules/web3/UserAccountProvider'
import { BPT_DECIMALS } from '@repo/lib/modules/pool/pool.constants'
import { noop } from 'lodash'
import { bn, parseAmount } from '@repo/lib/shared/utils/numbers'
import type { GqlChain } from '@repo/lib/shared/services/api/generated/graphql'
import { useTokenBalances } from '@repo/lib/modules/tokens/TokenBalancesProvider'
import { isTransactionSuccess } from '@repo/lib/modules/transactions/transaction-steps/transaction.helper'

export function useLstStakeStep(humanAmount: string, chain: GqlChain, enabled: boolean) {
  const { isConnected } = useUserAccount()
  const { refetchBalances } = useTokenBalances()
  const [transaction, setTransaction] = useState<ManagedResult | undefined>()

  const labels: TransactionLabels = {
    init: 'Stake',
    title: 'Stake',
    confirming: 'Confirming stake...',
    confirmed: 'Staked!',
    tooltip: 'tooltip',
  }

  const props: ManagedTransactionInput = {
    labels,
    chainId: getChainId(chain),
    contractId: 'beets.lstStaking',
    contractAddress: getNetworkConfig(chain).contracts.beets?.lstStakingProxy || '',
    functionName: 'deposit',
    args: [],
    value: parseAmount(humanAmount, BPT_DECIMALS),
    enabled: humanAmount !== '' && bn(humanAmount).gte(0.01) && isConnected && enabled,
    onTransactionChange: setTransaction,
  }

  const isComplete = () => isConnected && isTransactionSuccess(transaction)

  const step: TransactionStep = {
    id: 'stakeLst',
    labels,
    stepType: 'stakeLst',
    transaction,
    isComplete,
    onActivated: noop,
    onDeactivated: noop,
    onSuccess: () => refetchBalances(),
    renderAction: () => <ManagedTransactionButton id="stakeLst" {...props} />,
  }

  return { step }
}
