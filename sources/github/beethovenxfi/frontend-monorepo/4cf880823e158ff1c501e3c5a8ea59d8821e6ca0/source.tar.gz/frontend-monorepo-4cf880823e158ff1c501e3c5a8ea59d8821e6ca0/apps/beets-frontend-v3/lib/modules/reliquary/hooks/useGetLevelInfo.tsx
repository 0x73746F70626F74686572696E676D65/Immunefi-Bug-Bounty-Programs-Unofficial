import { getNetworkConfig, getChainId } from '@repo/lib/config/app.config'
import { reliquaryAbi } from '@repo/lib/modules/web3/contracts/abi/generated'
import { useUserAccount } from '@repo/lib/modules/web3/UserAccountProvider'
import { useReadContract } from '@repo/lib/shared/utils/wagmi'
import type { GqlChain } from '@repo/lib/shared/services/api/generated/graphql'

export function useGetLevelInfo(poolId: string, chain: GqlChain) {
  const chainId = getChainId(chain)
  const config = getNetworkConfig(chainId)
  const { isConnected } = useUserAccount()

  const query = useReadContract({
    chainId,
    abi: reliquaryAbi,
    address: config.contracts.beets?.reliquary,
    functionName: 'getLevelInfo',
    args: poolId ? [BigInt(poolId)] : undefined,
    query: { enabled: isConnected && !!poolId },
  })

  return {
    ...query,
    maturityThresholds: query.data?.requiredMaturities.map(maturity => maturity.toString()) || [],
  }
}
