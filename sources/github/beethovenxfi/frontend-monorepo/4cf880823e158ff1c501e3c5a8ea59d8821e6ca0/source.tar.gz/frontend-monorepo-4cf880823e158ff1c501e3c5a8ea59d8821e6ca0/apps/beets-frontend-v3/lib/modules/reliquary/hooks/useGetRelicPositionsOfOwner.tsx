import { getNetworkConfig, getChainId } from '@repo/lib/config/app.config'
import { reliquaryAbi } from '@repo/lib/modules/web3/contracts/abi/generated'
import { useUserAccount } from '@repo/lib/modules/web3/UserAccountProvider'
import { useReadContract } from '@repo/lib/shared/utils/wagmi'
import { formatUnits } from 'viem'
import { ReliquaryPosition } from '../reliquary.types'
import type { GqlChain } from '@repo/lib/shared/services/api/generated/graphql'

export function useGetRelicPositionsOfOwner(chain: GqlChain) {
  const chainId = getChainId(chain)
  const config = getNetworkConfig(chainId)
  const { isConnected, userAddress } = useUserAccount()

  const query = useReadContract({
    chainId,
    abi: reliquaryAbi,
    address: config.contracts.beets?.reliquary,
    functionName: 'relicPositionsOfOwner',
    args: [userAddress],
    query: { enabled: isConnected && !!userAddress },
  })

  return {
    ...query,
    relics: query.data
      ? query.data[0].map((relicId, index) => {
          const position = query.data[1][index]!

          return {
            relicId: relicId.toString(),
            amount: formatUnits(position.amount, 18),
            entry: Number(position.entry.toString()),
            poolId: position.poolId.toString(),
            level: Number(position.level.toString()),
          } as ReliquaryPosition
        })
      : [],
  }
}
