import { Badge, BadgeProps, Heading, HStack, Text, Wrap } from '@chakra-ui/react'
import type { GqlChain, GqlPoolType } from '@repo/lib/shared/services/api/generated/graphql'
import { fNum } from '@repo/lib/shared/utils/numbers'
import { TokenIcon } from '../../tokens/TokenIcon'
import { TokenIconStack } from '../../tokens/TokenIconStack'
import { usePoolMetadata } from '../metadata/usePoolMetadata'
import { isLiquidityBootstrapping, isStableLike } from '../pool.helpers'
import { getUserReferenceTokens } from '../pool-tokens.utils'
import { PoolCore, PoolToken } from '../pool.types'
import { ApiToken } from '@repo/lib/modules/tokens/token.types'

type IsTokenInWallet = (tokenAddress: string) => boolean

function walletBadgeHighlightStyles(hasWalletBalance: boolean) {
  return {
    _after: hasWalletBalance
      ? {
          bg: 'green.500',
          content: '""',
          inset: 0,
          opacity: 0.08,
          pointerEvents: 'none',
          position: 'absolute' as const,
          zIndex: 0,
        }
      : undefined,
    _before: hasWalletBalance
      ? {
          border: '1px solid',
          borderColor: 'green.500',
          borderRadius: 'full',
          content: '""',
          inset: 0,
          opacity: 0.25,
          pointerEvents: 'none',
          position: 'absolute' as const,
          zIndex: 1,
        }
      : undefined,
    borderColor: hasWalletBalance ? 'transparent' : 'border.base',
  }
}

function formatTokenWeight(weight: string | null | undefined, preciseWeight: boolean) {
  if (!weight) return null

  return preciseWeight
    ? fNum('weight', weight, { abbreviated: false, decimals: 1 })
    : fNum('weight', weight)
}

function WeightedTokenPills({
  tokens,
  chain,
  iconSize = 24,
  isTokenInWallet,
  nameSize,
  preciseWeight = false,
  ...badgeProps
}: {
  tokens: (PoolToken | ApiToken)[]
  chain: GqlChain
  iconSize?: number
  isTokenInWallet?: IsTokenInWallet
  nameSize?: string
  preciseWeight?: boolean
} & BadgeProps) {
  return (
    <Wrap spacing="xs">
      {tokens.map((token, index) => {
        const hasWalletBalance = Boolean(isTokenInWallet?.(token.address))
        const tokenWeight = formatTokenWeight(token.weight, preciseWeight)

        return (
          <Badge
            key={`${token.address}-${index}`}
            {...badgeProps}
            {...walletBadgeHighlightStyles(hasWalletBalance)}
            alignItems="center"
            bg="background.level2"
            borderRadius="full"
            borderWidth={1}
            display="flex"
            overflow="hidden"
            position="relative"
            shadow="sm"
            textTransform="none"
          >
            <HStack gap={['xs', 'sm']} position="relative" zIndex={2}>
              <TokenIcon
                address={token.address}
                alt={token.symbol}
                chain={chain}
                logoURI={token.logoURI}
                size={iconSize}
              />
              <HStack gap={['xs', '1.5']}>
                {tokens.length < 5 && (
                  <Text
                    _groupHover={{ color: 'font.maxContrast' }}
                    fontWeight="bold"
                    noOfLines={1}
                    size={nameSize}
                    transition="color 0.2s var(--ease-out-cubic)"
                  >
                    {token.symbol}
                  </Text>
                )}
                {tokenWeight && (
                  <Text
                    _groupHover={{ color: 'font.maxContrast' }}
                    fontSize="xs"
                    transition="color 0.2s var(--ease-out-cubic)"
                  >
                    {tokenWeight}
                  </Text>
                )}
              </HStack>
            </HStack>
          </Badge>
        )
      })}
    </Wrap>
  )
}

function StableTokenPills({
  tokens,
  chain,
  iconSize = 24,
  isTokenInWallet,
  nameSize,
  ...badgeProps
}: {
  tokens: (PoolToken | ApiToken)[]
  chain: GqlChain
  iconSize?: number
  isTokenInWallet?: IsTokenInWallet
  nameSize?: string
} & BadgeProps) {
  const isFirstToken = (index: number) => index === 0
  const zIndices = Array.from({ length: tokens.length }, (_, index) => index + 1).reverse()

  return (
    <HStack spacing={0}>
      {tokens.map((token, i) => {
        const hasWalletBalance = Boolean(isTokenInWallet?.(token.address))

        return (
          <Badge
            key={[token.address, token.chain, i].join('-')}
            {...badgeProps}
            {...walletBadgeHighlightStyles(hasWalletBalance)}
            alignItems="center"
            bg="background.level2"
            borderRadius="full"
            borderWidth={1}
            display="flex"
            ml={isFirstToken(i) ? 0 : -10}
            overflow="hidden"
            pl={[isFirstToken(i) ? 1 : 12, isFirstToken(i) ? 2 : 12]}
            position="relative"
            shadow="sm"
            textTransform="none"
            zIndex={zIndices[i]}
          >
            <HStack gap={['xs', '1.5']} position="relative" zIndex={2}>
              <TokenIcon
                address={token.address}
                alt={token.symbol}
                chain={chain}
                logoURI={token.logoURI}
                size={iconSize}
              />
              {tokens.length < 5 && (
                <Text
                  _groupHover={{ color: 'font.maxContrast' }}
                  fontWeight="bold"
                  noOfLines={1}
                  size={nameSize}
                  transition="color 0.2s var(--ease-out-cubic)"
                >
                  {token.symbol}
                </Text>
              )}
            </HStack>
          </Badge>
        )
      })}
    </HStack>
  )
}

type PoolListTokenPillsProps = {
  pool: PoolCore
  iconSize?: number
  isTokenInWallet?: IsTokenInWallet
  nameSize?: string
} & BadgeProps

export function PoolListTokenPills({ pool, ...props }: PoolListTokenPillsProps) {
  const { name, iconUrl } = usePoolMetadata(pool)
  const tokens = getUserReferenceTokens(pool)

  return (
    <PoolTokenPills
      chain={pool.chain}
      iconUrl={iconUrl}
      poolName={name}
      poolType={pool.type}
      protocolVersion={pool.protocolVersion}
      tokens={tokens}
      {...props}
    />
  )
}

type PoolTokenPillsProps = {
  chain: GqlChain
  isTokenInWallet?: IsTokenInWallet
  poolName: string | undefined
  poolType: GqlPoolType
  protocolVersion: number
  tokens: (PoolToken | ApiToken)[]
  iconUrl?: string
  iconSize?: number
  nameSize?: string
} & BadgeProps

function PoolTokenPills({
  chain,
  isTokenInWallet,
  poolName,
  poolType,
  protocolVersion,
  tokens,
  iconSize = 24,
  iconUrl,
  nameSize = 'md',
  ...badgeProps
}: PoolTokenPillsProps) {
  const shouldUseStablePills = isStableLike(poolType)
  const isV3LBP = isLiquidityBootstrapping(poolType) && protocolVersion === 3

  if (poolName) {
    return (
      <HStack>
        {iconUrl ? (
          <TokenIcon alt={poolName} logoURI={iconUrl} size={iconSize} />
        ) : (
          <TokenIconStack chain={chain} size={iconSize} tokens={tokens} />
        )}
        <Heading size={nameSize}>{poolName}</Heading>
      </HStack>
    )
  }

  if (shouldUseStablePills) {
    return (
      <StableTokenPills
        chain={chain}
        iconSize={iconSize}
        isTokenInWallet={isTokenInWallet}
        tokens={tokens}
        {...badgeProps}
      />
    )
  }

  return (
    <WeightedTokenPills
      chain={chain}
      iconSize={iconSize}
      isTokenInWallet={isTokenInWallet}
      preciseWeight={isV3LBP}
      tokens={tokens}
      {...badgeProps}
    />
  )
}
