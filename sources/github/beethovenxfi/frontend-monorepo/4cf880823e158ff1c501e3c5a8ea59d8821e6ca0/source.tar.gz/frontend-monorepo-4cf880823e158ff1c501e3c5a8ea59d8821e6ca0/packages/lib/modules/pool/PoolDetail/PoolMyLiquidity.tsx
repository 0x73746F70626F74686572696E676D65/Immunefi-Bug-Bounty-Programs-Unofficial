import TokenRow from '../../tokens/TokenRow/TokenRow'
import ButtonGroup, {
  ButtonGroupOption,
} from '@repo/lib/shared/components/btns/button-group/ButtonGroup'
import {
  Divider,
  Button,
  Card,
  Flex,
  HStack,
  Heading,
  Skeleton,
  Text,
  VStack,
  Tooltip,
} from '@chakra-ui/react'
import { useMemo, useState, useLayoutEffect } from 'react'
import { usePool } from '../PoolProvider'
import { Address } from 'viem'
import { usePathname, useRouter } from 'next/navigation'
import { useCurrency } from '@repo/lib/shared/hooks/useCurrency'
import { keyBy } from 'lodash'
import { getProportionalExitAmountsFromScaledBptIn } from '../pool.utils'
import { useUserAccount } from '../../web3/UserAccountProvider'
import {
  getUserTotalBalanceInt,
  getUserWalletBalanceInt,
  getUserTotalBalanceUsd,
  getUserWalletBalance,
  getUserWalletBalanceUsd,
  calcStakedBalanceInt,
  calcStakedBalanceUsd,
  shouldMigrateStake,
} from '../user-balance.helpers'
import {
  shouldBlockAddLiquidity,
  getPoolAddBlockedReason,
  calcUserShareOfPool,
  getPoolRemoveBlockedReason,
  shouldBlockRemoveLiquidity,
} from '../pool.helpers'
import { getCanStake, migrateStakeTooltipLabel } from '../actions/stake.helpers'
import { InfoOutlineIcon } from '@chakra-ui/icons'
import { GqlPoolStakingTypeValues } from '@repo/lib/shared/services/api/graphql-enums'
import { getCompositionTokens } from '../pool-tokens.utils'
import { usePoolMetadata } from '../metadata/usePoolMetadata'
import { formatTextListAsItems } from '@repo/lib/shared/utils/text-format'
import { bn, fNum, ZERO_VALUE_DASH, formatFalsyValueAsDash } from '@repo/lib/shared/utils/numbers'
import { StakeUnstakeButton } from './StakeUnstakeButton'

const tabs = [
  {
    value: 'total',
    label: 'Total',
  },
  {
    value: 'unstaked',
    label: 'Unstaked',
  },
  {
    value: 'gauge',
    label: 'Staked',
  },
]

export default function PoolMyLiquidity() {
  const { pool, chain, isLoadingOnchainUserBalances, myLiquiditySectionRef } = usePool()
  const { toCurrency } = useCurrency()
  const { isConnected, isConnecting } = useUserAccount()
  const router = useRouter()

  const [activeTab, setActiveTab] = useState<ButtonGroupOption>(tabs[0]!)
  const pathname = usePathname()
  const [height, setHeight] = useState(0)
  const poolMetadata = usePoolMetadata(pool)

  const isAddLiquidityBlocked = shouldBlockAddLiquidity(pool, poolMetadata)
  const addBlockingReasons = formatTextListAsItems(getPoolAddBlockedReason(pool))

  const isRemoveLiquidityBlocked = shouldBlockRemoveLiquidity(pool)
  const removeBlockingReasons = formatTextListAsItems(getPoolRemoveBlockedReason(pool))

  useLayoutEffect(() => {
    if (myLiquiditySectionRef && myLiquiditySectionRef.current) {
      setHeight(myLiquiditySectionRef.current.offsetHeight)
    }
  }, [])

  function handleTabChanged(option: ButtonGroupOption) {
    setActiveTab(option)
  }

  function getBptBalanceForTab() {
    const rawTotalBalance = getUserTotalBalanceInt(pool)

    switch (activeTab.value) {
      case 'total':
        return rawTotalBalance
      case 'gauge':
        return calcStakedBalanceInt(pool, GqlPoolStakingTypeValues.Gauge)
      case 'unstaked':
        return getUserWalletBalanceInt(pool)
      default:
        return rawTotalBalance
    }
  }

  function calcUserPoolTokenBalances() {
    const poolTokens = pool.poolTokens.map(({ balance, decimals, address }) => ({
      balance,
      decimals,
      address,
    }))

    return keyBy(
      getProportionalExitAmountsFromScaledBptIn(
        getBptBalanceForTab(),
        poolTokens,
        pool.dynamicData.totalShares
      ),
      'address'
    )
  }

  function getTitlePrefix() {
    switch (activeTab.value) {
      case 'total':
        return 'My total balance'
      case 'gauge':
        return 'My staked balance'
      case 'unstaked':
        return 'My unstaked balance'
      default:
        return ''
    }
  }

  const stakedBalance = calcStakedBalanceUsd(pool, GqlPoolStakingTypeValues.Gauge)
  const unstakedBalance = getUserWalletBalanceUsd(pool)

  function getTotalBalanceUsd() {
    if (!isConnected || isConnecting) return 0

    switch (activeTab.value) {
      case 'total':
        return getUserTotalBalanceUsd(pool)
      case 'gauge':
        return stakedBalance
      case 'unstaked':
        return unstakedBalance
      default:
        return getUserTotalBalanceUsd(pool)
    }
  }

  const totalBalanceUsd = getTotalBalanceUsd() || 0
  const poolTokenBalancesForTab = calcUserPoolTokenBalances()

  function tokenBalanceFor(tokenAddress: string) {
    const poolTokenBalance = poolTokenBalancesForTab[tokenAddress]

    if (!isConnected || isConnecting || !poolTokenBalance) return '0'

    return poolTokenBalance.amount
  }

  const canStake = getCanStake(pool)
  const hasUnstakedBalance = bn(getUserWalletBalance(pool)).gt(0)
  const shareOfPool = calcUserShareOfPool(pool)

  const shareofPoolLabel = bn(shareOfPool).gt(0)
    ? fNum('sharePercent', shareOfPool)
    : ZERO_VALUE_DASH

  const options = useMemo(() => {
    return tabs.map(tab => ({
      ...tab,
      disabled: tab.value !== 'total' && !canStake,
    }))
  }, [tabs, pool, canStake])

  function handleAddLiquidity() {
    router.push(`${pathname}/add-liquidity`)
  }

  function handleRemoveLiquidity() {
    router.push(`${pathname}/remove-liquidity`)
  }

  const compositionTokens = getCompositionTokens(pool)

  return (
    <Card h="fit-content" ref={myLiquiditySectionRef}>
      <VStack spacing="md" width="full">
        <Flex
          alignItems="start"
          direction={{ base: 'column', sm: 'row' }}
          gap="ms"
          justifyContent="space-between"
          width="full"
        >
          <Heading backgroundClip="text" bg="font.special" fontWeight="bold" size="h5">
            My liquidity
          </Heading>
          <ButtonGroup
            currentOption={activeTab}
            groupId="my-liquidity"
            onChange={handleTabChanged}
            options={options}
            size="xxs"
            width="max-content"
          />
        </Flex>
        <Divider />
        <VStack spacing="md" width="full">
          <HStack justifyContent="space-between" width="full">
            <VStack alignItems="flex-start">
              <Heading fontWeight="bold" size="h6">
                {getTitlePrefix()}
              </Heading>
              <Text fontSize="0.85rem" variant="secondary">
                My pool share
              </Text>
            </VStack>
            <VStack alignItems="flex-end">
              {isLoadingOnchainUserBalances || isConnecting ? (
                <Skeleton h="5" w="12" />
              ) : (
                <Heading fontWeight="bold" size="h6">
                  {formatFalsyValueAsDash(totalBalanceUsd, toCurrency, {
                    showZeroAmountAsDash: true,
                  })}
                </Heading>
              )}
              <Text fontSize="0.85rem" variant="secondary">
                {shareofPoolLabel}
              </Text>
            </VStack>
          </HStack>
          <Divider />
          <VStack alignItems="flex-start" h={`${height - 270}px`} spacing="md" width="full">
            {compositionTokens.map(poolToken => {
              return (
                <VStack key={`pool-${poolToken.address}`} w="full">
                  <TokenRow
                    abbreviated={false}
                    address={poolToken.address as Address}
                    chain={chain}
                    pool={pool}
                    showZeroAmountAsDash
                    value={tokenBalanceFor(poolToken.address)}
                  />
                </VStack>
              )
            })}
          </VStack>
          <Divider />
          <HStack justifyContent="flex-start" mt="md" width="full">
            <Tooltip
              isDisabled={!addBlockingReasons}
              label={
                <Text color="primaryTextColor" whiteSpace="pre-line">
                  {addBlockingReasons}
                </Text>
              }
            >
              <Button
                flex="1"
                isDisabled={isAddLiquidityBlocked}
                maxW="120px"
                onClick={() => handleAddLiquidity()}
                variant="primary"
              >
                Add
              </Button>
            </Tooltip>
            <Tooltip
              isDisabled={!removeBlockingReasons}
              label={
                <Text color="primaryTextColor" whiteSpace="pre-line">
                  {removeBlockingReasons}
                </Text>
              }
            >
              <Button
                flex="1"
                isDisabled={isRemoveLiquidityBlocked}
                maxW="120px"
                onClick={() => handleRemoveLiquidity()}
                variant={hasUnstakedBalance ? 'tertiary' : 'disabled'}
              >
                Remove
              </Button>
            </Tooltip>
            <Text opacity="0.25" px={{ base: '0', sm: 'ms' }} variant="secondary">
              |
            </Text>

            <StakeUnstakeButton action="stake" pool={pool} />

            {shouldMigrateStake(pool) ? (
              <Tooltip label={migrateStakeTooltipLabel}>
                <Button
                  flex="1"
                  maxW="120px"
                  onClick={() => router.push(`${pathname}/migrate-stake`)}
                  rightIcon={<InfoOutlineIcon fontSize="sm" />}
                  variant="secondary"
                >
                  Migrate stake
                </Button>
              </Tooltip>
            ) : (
              <StakeUnstakeButton action="unstake" pool={pool} />
            )}
          </HStack>
        </VStack>
      </VStack>
    </Card>
  )
}
