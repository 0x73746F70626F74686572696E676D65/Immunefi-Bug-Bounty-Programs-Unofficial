export const LS_KEYS = {
  UserAddress: 'userAddress',
  HasV1Pools: 'hasV1Pools',
  UserSettings: {
    ColorMode: 'chakra-ui-color-mode', // Has to be this string to match Chakra's default
    Slippage: 'userSettings.Slippage',
    EnableSignatures: 'userSettings.EnableSignatures',
    PoolListView: 'userSettings.PoolListView',
    AcceptedPolicies: 'userSettings.AcceptedPolicies',
    AllowSounds: 'userSettings.AllowSounds',
    EnableTxBundling: 'userSettings.EnableTxBundling',
  },
  CrossChainSync: {
    TempSyncingNetworks: 'сrossChainSync.tempSyncingNetworks',
    SyncTxHashes: 'сrossChainSync.syncTxHashes',
  },
  LbpConfig: {
    SaleStructure: 'lbpConfig.saleStructure',
    ProjectInfo: 'lbpConfig.projectInfo',
    StepIndex: 'lbpConfig.stepIndex',
    PoolAddress: 'lbpConfig.poolAddress',
    IsMetadataSaved: 'lbpConfig.isMetadataSaved',
  },
  PoolCreation: {
    Form: 'poolCreation.form',
    StepIndex: 'poolCreation.stepIndex',
    Address: 'poolCreation.address',
    AutoRangeConfig: 'poolCreation.autoRangeConfig',
    EclpConfig: 'poolCreation.eclpConfig',
  },
}
