import type { GqlPoolType } from '@repo/lib/shared/services/api/generated/graphql'
import { GqlPoolTypeValues } from '@repo/lib/shared/services/api/graphql-enums'
import { useParams } from 'next/navigation'
import { createContext, PropsWithChildren, useMemo, useState } from 'react'
import { PoolVariant, BaseVariant } from '../../../pool.types'
import { usePool } from '../../../PoolProvider'
import { useMandatoryContext } from '@repo/lib/shared/utils/contexts'
import { PoolChartPeriod } from './PoolChartsProvider'
type NonEmptyPoolChartTabs = [PoolChartTypeTab, ...PoolChartTypeTab[]]

export enum PoolChartTab {
  VOLUME = 'volume',
  TVL = 'tvl',
  FEES = 'fees',
  LIQUIDITY_PROFILE = 'liquidity_profile',
  AUTORANGE = 'autorange',
  PRICE = 'price',
  FUNDS_RAISED = 'funds_raised',
}

export interface PoolChartTypeTab {
  value: PoolChartTab
  label: string
}

type PoolTabsMap = {
  [key in GqlPoolType]?: NonEmptyPoolChartTabs
} & {
  default: NonEmptyPoolChartTabs
}

const BASE_TABS: NonEmptyPoolChartTabs = [
  { value: PoolChartTab.VOLUME, label: 'Volume' },
  { value: PoolChartTab.TVL, label: 'TVL' },
]

const TABS_WITH_FEES: NonEmptyPoolChartTabs = [
  ...BASE_TABS,
  { value: PoolChartTab.FEES, label: 'Fees' },
]

const POOL_SPECIFIC_TABS: PoolTabsMap = {
  [GqlPoolTypeValues.GyroE]: [
    { value: PoolChartTab.LIQUIDITY_PROFILE, label: 'Liquidity profile' },
    ...TABS_WITH_FEES,
  ],
  [GqlPoolTypeValues.Reclamm]: [
    { value: PoolChartTab.AUTORANGE, label: 'AutoRange' },
    ...TABS_WITH_FEES,
  ],
  [GqlPoolTypeValues.LiquidityBootstrapping]: [
    { value: PoolChartTab.PRICE, label: 'Price' },
    ...TABS_WITH_FEES,
  ],
  [GqlPoolTypeValues.FixedLbp]: [
    { value: PoolChartTab.FUNDS_RAISED, label: 'Funds raised' },
    ...TABS_WITH_FEES,
  ],
  default: TABS_WITH_FEES,
}

export function getPoolTabsList({
  variant,
  poolType,
}: {
  variant: PoolVariant
  poolType: GqlPoolType
}): NonEmptyPoolChartTabs {
  // LBP pools in v2 only show base tabs
  if (poolType === GqlPoolTypeValues.LiquidityBootstrapping && variant === BaseVariant.v2) {
    return BASE_TABS
  }

  // Return pool-specific tabs or default tabs
  return POOL_SPECIFIC_TABS[poolType] || POOL_SPECIFIC_TABS.default
}

export type PoolChartTabsResponse = ReturnType<typeof usePoolChartTabsLogic>

export const PoolChartTabsContext = createContext<PoolChartTabsResponse | null>(null)

export function usePoolChartTabsLogic() {
  const { pool } = usePool()
  const { variant } = useParams<{ variant: PoolVariant }>()

  const tabsList = useMemo(
    () =>
      getPoolTabsList({
        variant,
        poolType: pool.type,
      }),
    [pool.type, variant]
  )

  const [activeTab, setActiveTab] = useState(tabsList[0])

  function getActiveTabLabel(activePeriod: PoolChartPeriod) {
    switch (activeTab.value) {
      case PoolChartTab.TVL:
        return 'Total value locked'
      case PoolChartTab.FEES:
        return `${activePeriod.label} fees`
      case PoolChartTab.FUNDS_RAISED:
        return `${activePeriod.label} funds raised`
      case PoolChartTab.VOLUME:
        return `${activePeriod.label} volume`
    }
  }

  return {
    tabsList,
    activeTab,
    setActiveTab,
    getActiveTabLabel,
  }
}

export function PoolChartTabsProvider({ children }: PropsWithChildren) {
  const hook = usePoolChartTabsLogic()
  return <PoolChartTabsContext.Provider value={hook}>{children}</PoolChartTabsContext.Provider>
}

export const usePoolChartTabs = (): PoolChartTabsResponse =>
  useMandatoryContext(PoolChartTabsContext, 'PoolChartTabs')
