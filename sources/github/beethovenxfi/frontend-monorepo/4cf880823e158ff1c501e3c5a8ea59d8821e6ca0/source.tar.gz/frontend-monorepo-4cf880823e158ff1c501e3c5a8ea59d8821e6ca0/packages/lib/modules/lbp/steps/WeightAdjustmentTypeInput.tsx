import { Control, Controller, UseFormSetValue, useFormState } from 'react-hook-form'
import { SaleStructureForm, WeightAdjustmentType } from '../lbp.types'
import { Box, HStack, Stack, Text, VStack } from '@chakra-ui/react'
import { ArrowRight } from 'lucide-react'
import { SelectInput } from '@repo/lib/shared/components/inputs/SelectInput'
import type { GqlChain } from '@repo/lib/shared/services/api/generated/graphql'
import { SliderWithSteps } from '@repo/lib/shared/components/inputs/SliderWithSteps'

export function WeightAdjustmentTypeInput({
  control,
  launchTokenSymbol,
  collateralTokenSymbol,
  setValue,
  weightAdjustmentType,
  customStartWeight,
  customEndWeight,
}: {
  control: Control<SaleStructureForm>
  launchTokenSymbol: string
  collateralTokenSymbol: string
  weightAdjustmentType: WeightAdjustmentType
  customStartWeight: number
  customEndWeight: number
  setValue: UseFormSetValue<SaleStructureForm>
}) {
  const { errors } = useFormState({ control })

  const options = [
    {
      label: (
        <HStack justify="space-between" w="full">
          <Text>Standard Linear LBP</Text>
          <HStack color="font.secondary">
            <Text color="font.secondary" fontSize="sm">
              {launchTokenSymbol} 90%
            </Text>
            <ArrowRight size={12} />
            <Text color="font.secondary" fontSize="sm">
              10%
            </Text>
          </HStack>
        </HStack>
      ),
      value: WeightAdjustmentType.LINEAR_90_10,
    },
    {
      label: (
        <HStack justify="space-between" w="full">
          <Text>Linear LBP to 50/50 pool</Text>
          <HStack color="font.secondary">
            <Text color="font.secondary" fontSize="sm">
              {launchTokenSymbol} 90%
            </Text>
            <ArrowRight size={12} />
            <Text color="font.secondary" fontSize="sm">
              50%
            </Text>
          </HStack>
        </HStack>
      ),
      value: WeightAdjustmentType.LINEAR_90_50,
    },
    {
      label: (
        <HStack justify="space-between" w="full">
          <Text>Custom sale</Text>
        </HStack>
      ),
      value: WeightAdjustmentType.CUSTOM,
    },
  ]

  return (
    <VStack align="start" w="full">
      <Text color="font.primary">Dynamic token weight adjustments</Text>
      <Controller
        control={control}
        name="weightAdjustmentType"
        render={({ field }) => (
          <SelectInput
            defaultValue={options[0]!.value}
            id="weight-adjustment-type"
            onChange={newValue => {
              field.onChange(newValue as GqlChain)
            }}
            options={options}
            value={field.value ?? options[0]!.value}
          />
        )}
      />

      {weightAdjustmentType === 'custom' && (
        <Stack gap="md" my="md" w="full">
          <WeightSlider
            collateralTokenSymbol={collateralTokenSymbol}
            customWeight={customStartWeight}
            errorMessage={errors.customStartWeight?.message}
            launchTokenSymbol={launchTokenSymbol}
            name="customStartWeight"
            setValue={setValue}
            title="Starting weights"
          />
          <WeightSlider
            collateralTokenSymbol={collateralTokenSymbol}
            customWeight={customEndWeight}
            errorMessage={errors.customEndWeight?.message}
            launchTokenSymbol={launchTokenSymbol}
            name="customEndWeight"
            setValue={setValue}
            title="Ending weights"
          />
        </Stack>
      )}
    </VStack>
  )
}

function WeightSlider({
  name,
  title,
  launchTokenSymbol,
  collateralTokenSymbol,
  customWeight,
  setValue,
  isDisabled,
  errorMessage,
}: {
  name: keyof SaleStructureForm
  title: string
  launchTokenSymbol: string
  collateralTokenSymbol: string
  customWeight: number
  setValue: UseFormSetValue<SaleStructureForm>
  isDisabled?: boolean
  errorMessage?: string
}) {
  return (
    <VStack align="start" w="full">
      <Text color="font.primary">{title}</Text>
      <Box
        bg="background.level0"
        border="white"
        borderRadius="md"
        shadow="innerBase"
        sx={{ paddingX: 'md', paddingY: 'lg' }}
        w="full"
      >
        <HStack justifyContent="space-between" spacing="md" w="full">
          <Text
            fontSize="sm"
            fontWeight="bold"
            pb="2"
          >{`${launchTokenSymbol}: ${customWeight}%`}</Text>
          <Box textAlign="right" w="100px">
            <Text
              fontSize="sm"
              fontWeight="bold"
              pb="2"
              textColor="font.secondary"
            >{`${collateralTokenSymbol}: ${100 - customWeight}%`}</Text>
          </Box>
        </HStack>
        <SliderWithSteps
          aria-label="weights-slider"
          isDisabled={isDisabled}
          max={99}
          min={1}
          onChange={value => setValue(name, value)}
          steps={[10, 20, 30, 40, 50, 60, 70, 80, 90]}
          value={customWeight}
          variant="lock"
        />
      </Box>
      {errorMessage && (
        <Text color="font.error" fontSize="sm" textAlign="start" w="full">
          {errorMessage}
        </Text>
      )}
    </VStack>
  )
}
