'use client'

import { useMandatoryContext } from '@repo/lib/shared/utils/contexts'
import { PropsWithChildren, createContext, useState } from 'react'
import { usePersistentForm } from '@repo/lib/shared/hooks/usePersistentForm'
import { ProjectInfoForm, SaleStructureForm, SeedType } from './lbp.types'
import { PROJECT_CONFIG } from '@repo/lib/config/getProjectConfig'
import { LS_KEYS } from '@repo/lib/modules/local-storage/local-storage.constants'
import { useLocalStorage } from 'usehooks-ts'
import { useTokenMetadata } from '../tokens/useTokenMetadata'
import { bn, fNum, isBnParseable } from '@repo/lib/shared/utils/numbers'
import { Address } from 'viem'
import { LbpPrice, max, min } from './pool/usePriceInfo'
import { CustomToken } from '@repo/lib/modules/tokens/token.types'
import { getNetworkConfig } from '@repo/lib/config/app.config'
import { getChainId } from '@repo/lib/config/app.config'
import { Resolver, useWatch } from 'react-hook-form'
import { useFormSteps } from '@repo/lib/shared/hooks/useFormSteps'
import { LBP_FORM_STEPS, INITIAL_SALE_STRUCTURE, INITIAL_PROJECT_INFO } from './constants.lbp'
import {
  projectInfoStepSchema,
  saleStructureStepSchema,
  validateProjectInfoStep,
  validateSaleStructureStep,
} from './lbp.validation'
import { zodResolver } from '@hookform/resolvers/zod'
import { useTokens } from '../tokens/TokensProvider'
import { useCurrency } from '@repo/lib/shared/hooks/useCurrency'
import { GqlPoolTypeValues } from '@repo/lib/shared/services/api/graphql-enums'

export type UseLbpFormResult = ReturnType<typeof useLbpFormLogic>
export const LbpFormContext = createContext<UseLbpFormResult | null>(null)

export function useLbpFormLogic() {
  const { toCurrency } = useCurrency()

  const saleStructureForm = usePersistentForm<SaleStructureForm>(
    LS_KEYS.LbpConfig.SaleStructure,
    INITIAL_SALE_STRUCTURE,
    {
      mode: 'onSubmit',
      resolver: zodResolver(saleStructureStepSchema) as unknown as Resolver<
        SaleStructureForm,
        any,
        SaleStructureForm
      >,
    }
  )

  const projectInfoForm = usePersistentForm<ProjectInfoForm>(
    LS_KEYS.LbpConfig.ProjectInfo,
    INITIAL_PROJECT_INFO,
    {
      mode: 'onSubmit',
      resolver: zodResolver(projectInfoStepSchema) as unknown as Resolver<
        ProjectInfoForm,
        any,
        ProjectInfoForm
      >,
    }
  )

  const [poolAddress, setPoolAddress] = useLocalStorage<Address | undefined>(
    LS_KEYS.LbpConfig.PoolAddress,
    undefined
  )

  const isProjectInfoLocked = !!poolAddress
  const [, setIsMetadataSaved] = useLocalStorage<boolean>(LS_KEYS.LbpConfig.IsMetadataSaved, false)

  const formSteps = useFormSteps({
    steps: LBP_FORM_STEPS,
    basePath: '/lbp/create',
    localStorageKey: LS_KEYS.LbpConfig.StepIndex,
    isFormHydrated: saleStructureForm.isHydrated && projectInfoForm.isHydrated,
    shouldSkipRedirectToSavedStep: false,
    canRenderStepFn: () => true,
  })

  const validateCurrentStep = async () => {
    if (formSteps.currentStepIndex === 0) {
      return validateSaleStructureStep(saleStructureForm)
    }

    if (formSteps.currentStepIndex === 1) {
      return validateProjectInfoStep(projectInfoForm)
    }

    const saleValid = await validateSaleStructureStep(saleStructureForm)
    const projectValid = await validateProjectInfoStep(projectInfoForm)
    return saleValid && projectValid
  }

  const resetLbpCreation = () => {
    formSteps.resetSteps()
    setPoolAddress(undefined)
    saleStructureForm.resetToInitial()
    projectInfoForm.resetToInitial()
    setIsMetadataSaved(false)
  }

  const {
    saleTokenAmount,
    launchTokenAddress,
    selectedChain,
    collateralTokenAddress,
    launchTokenRate,
    saleType,
    seedType,
  } = useWatch({
    control: saleStructureForm.control,
  })

  const { priceFor } = useTokens()

  const chain = selectedChain || PROJECT_CONFIG.defaultNetwork
  const { tokens } = getNetworkConfig(selectedChain)

  const isCollateralNativeAsset =
    (collateralTokenAddress || '').toLowerCase() === tokens.nativeAsset.address.toLowerCase()

  const hasParseableSaleTokenAmount = isBnParseable(saleTokenAmount)
  const hasParseableLaunchTokenRate = isBnParseable(launchTokenRate)
  const safeSaleTokenAmount = hasParseableSaleTokenAmount ? (saleTokenAmount ?? '0') : '0'
  const safeLaunchTokenRate = hasParseableLaunchTokenRate ? (launchTokenRate ?? '0') : '0'
  const launchTokenSeed = Number(safeSaleTokenAmount)

  const launchTokenMetadata = useTokenMetadata(launchTokenAddress || '', chain)

  const [maxPrice, setMaxPrice] = useState(0)
  const [saleMarketCap, setSaleMarketCap] = useState('')
  const [fdvMarketCap, setFdvMarketCap] = useState('')

  const collateralTokenPrice = collateralTokenAddress ? priceFor(collateralTokenAddress, chain) : 0

  const launchTokenPriceUsd =
    collateralTokenPrice && hasParseableLaunchTokenRate
      ? bn(safeLaunchTokenRate).times(collateralTokenPrice).toString()
      : '0'

  const totalValue = hasParseableSaleTokenAmount
    ? bn(safeSaleTokenAmount).times(launchTokenPriceUsd).toString()
    : '0'

  const updatePriceStats = (prices: LbpPrice[]) => {
    const minPrice = min(prices)
    const maxPrice = max(prices)
    const minSaleMarketCap = minPrice * launchTokenSeed
    const maxSaleMarketCap = maxPrice * launchTokenSeed
    const minFdvMarketCap = minPrice * (launchTokenMetadata?.totalSupply || 0)
    const maxFdvMarketCap = maxPrice * (launchTokenMetadata?.totalSupply || 0)

    setMaxPrice(maxPrice)
    setSaleMarketCap(`$${fNum('fiat', minSaleMarketCap)} - $${fNum('fiat', maxSaleMarketCap)}`)
    setFdvMarketCap(`$${fNum('fiat', minFdvMarketCap)} - $${fNum('fiat', maxFdvMarketCap)}`)
  }

  const launchToken: CustomToken = {
    name: launchTokenMetadata.name || '',
    chain,
    chainId: getChainId(chain),
    address: launchTokenAddress as Address,
    symbol: launchTokenMetadata.symbol || '',
    logoURI: projectInfoForm.getValues().tokenIconUrl || '',
    decimals: launchTokenMetadata.decimals || 0,
  }

  const isDynamicSale = saleType === GqlPoolTypeValues.LiquidityBootstrapping
  const isFixedSale = saleType === GqlPoolTypeValues.FixedLbp
  const isSeeded = seedType === SeedType.SEEDED

  return {
    ...formSteps,
    saleStructureForm,
    projectInfoForm,
    validateCurrentStep,
    maxPrice: toCurrency(maxPrice),
    saleMarketCap,
    fdvMarketCap,
    updatePriceStats,
    launchTokenSeed,
    resetLbpCreation,
    launchTokenMetadata,
    launchToken,
    isCollateralNativeAsset,
    poolAddress,
    setPoolAddress,
    isProjectInfoLocked,
    launchTokenPriceUsd: toCurrency(launchTokenPriceUsd),
    launchTokenPriceRaw: launchTokenPriceUsd,
    totalValueUsd: toCurrency(totalValue),
    totalValueRaw: totalValue,
    isDynamicSale,
    isFixedSale,
    isSeeded,
    isSeedless: !isSeeded,
  }
}

export function LbpFormProvider({ children }: PropsWithChildren) {
  const hook = useLbpFormLogic()
  return <LbpFormContext.Provider value={hook}>{children}</LbpFormContext.Provider>
}

export const useLbpForm = (): UseLbpFormResult => useMandatoryContext(LbpFormContext, 'LbpForm')
