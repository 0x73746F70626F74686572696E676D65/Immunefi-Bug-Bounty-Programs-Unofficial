'use client'

import { Grid, GridItem, Icon, Text, VStack } from '@chakra-ui/react'
import type { GqlPoolOrderBy } from '@repo/lib/shared/services/api/generated/graphql'
import { orderByHash, PoolsColumnSort } from '../../pool.types'
import { usePoolOrderByState } from '../usePoolOrderByState'
import { Globe } from 'lucide-react'
import { SortableHeader, Sorting } from '@repo/lib/shared/components/tables/SortableHeader'
import { usePoolList } from '../PoolListProvider'
import { PROJECT_CONFIG } from '@repo/lib/config/getProjectConfig'
import { PoolListPoolNamesTokens } from './PoolListPoolNamesTokens'

const setIsDesc = (id: GqlPoolOrderBy, currentSortingObj: PoolsColumnSort) =>
  currentSortingObj.id === id ? !currentSortingObj.desc : true

export function PoolListTableHeader({ ...rest }) {
  const {
    queryState: { sorting, setSorting, joinablePools },
  } = usePoolList()

  const { orderBy } = usePoolOrderByState()
  const sortingObj = sorting[0]!

  const handleSort = (newSortingBy: GqlPoolOrderBy) => {
    setSorting([
      {
        id: newSortingBy,
        desc: setIsDesc(newSortingBy, sortingObj),
      },
    ])
  }

  return (
    <Grid {...rest} p={['sm', 'md']} w="full">
      <GridItem>
        <VStack align="start" w="full">
          <Icon as={Globe} boxSize="5" color="font.primary" />
        </VStack>
      </GridItem>
      <GridItem>
        {PROJECT_CONFIG.options.showPoolName ? (
          <PoolListPoolNamesTokens />
        ) : (
          <Text fontWeight="bold">Pool name</Text>
        )}
      </GridItem>
      <GridItem justifySelf="start">
        <Text fontWeight="bold" textAlign="left">
          Details
        </Text>
      </GridItem>
      {orderBy.map((orderByItem, index) => (
        <GridItem
          justifySelf="end"
          key={orderByItem}
          position="relative"
          pr={index === orderBy.length - 1 ? { base: 'md', sm: 'lg', lg: 'sm', xl: '0' } : '0'}
          right="-6px"
        >
          <SortableHeader
            isDisabled={joinablePools}
            isSorted={sortingObj.id === orderByItem}
            label={orderByHash[orderByItem]!}
            onSort={() => handleSort(orderByItem)}
            sorting={sortingObj.desc ? Sorting.desc : Sorting.asc}
          />
        </GridItem>
      ))}
    </Grid>
  )
}
