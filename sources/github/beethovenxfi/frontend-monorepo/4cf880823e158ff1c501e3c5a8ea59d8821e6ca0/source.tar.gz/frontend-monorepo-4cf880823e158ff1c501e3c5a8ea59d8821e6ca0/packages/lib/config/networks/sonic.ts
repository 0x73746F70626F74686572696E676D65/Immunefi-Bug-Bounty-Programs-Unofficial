import { GqlChainValues } from '@repo/lib/shared/services/api/graphql-enums'
import { NetworkConfig } from '../config.types'
import { convertHexToLowerCase } from '@repo/lib/shared/utils/objects'
import { AddressProvider, PERMIT2 } from '@balancer/sdk'
import { sonic } from 'viem/chains'

const STS_TOKEN_ADDRESS = '0xe5da20f15420ad15de0fa650600afc998bbe3955'
const WS_TOKEN_ADDRESS = '0x039e2fb66102314ce7b64ce5ce3e5183bc94ad38'
const USSD_TOKEN_ADDRESS = '0x000000000eccff26b795f73fb0a70d48da657fef'

const networkConfig: NetworkConfig = {
  chainId: 146,
  name: 'Sonic',
  shortName: 'Sonic',
  chain: GqlChainValues.Sonic,
  iconPath: '/images/chains/SONIC.svg',
  blockExplorer: {
    baseUrl: 'https://sonicscan.org',
    name: 'SonicScan',
  },
  tokens: {
    addresses: {
      beets: '0x2d0e0814e62d80056181f5cd932274405966e4f0',
      wNativeAsset: '0x039e2fb66102314ce7b64ce5ce3e5183bc94ad38',
    },
    nativeAsset: {
      name: 'Sonic',
      address: '0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee',
      symbol: 'S',
      decimals: 18,
    },
    stakedAsset: {
      name: 'Beets Staked Sonic',
      address: STS_TOKEN_ADDRESS,
      symbol: 'stS',
      decimals: 18,
    },
    loopedAsset: {
      name: 'Beets Looped Sonic',
      address: '0xc76995054ce51dfbbc954840d699b2f33d2538ee',
      symbol: 'loopS',
      decimals: 18,
    },
    defaultSwapTokens: {
      tokenIn: '0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee',
    },
    popularTokens: {
      [WS_TOKEN_ADDRESS]: 'wS',
      [STS_TOKEN_ADDRESS]: 'stS',
      '0x2d0e0814e62d80056181f5cd932274405966e4f0': 'BEETS',
      '0x29219dd400f2bf60e5a23d13be72b486d4038894': 'USDC',
      [USSD_TOKEN_ADDRESS]: 'USSD',
    },
  },
  contracts: {
    multicall2: '0xc07500b9fe7bea9efd5b54341d0aa3658a33d39a',
    multicall3: '0xcA11bde05977b3631167028862bE2a173976CA11',
    balancer: {
      vaultV2: '0xba12222222228d8ba445958a75a0704d566bf2c8',
      vaultV3: AddressProvider.Vault(sonic.id),
      relayerV6: '0x7b52D5ef006E59e3227629f97F182D6442380bb6',
      router: AddressProvider.Router(sonic.id),
      batchRouter: AddressProvider.BatchRouter(sonic.id),
      compositeLiquidityRouterBoosted: AddressProvider.CompositeLiquidityRouter(sonic.id),
      vaultAdminV3: AddressProvider.VaultAdmin(sonic.id),
      unbalancedAddViaSwapRouter: AddressProvider.UnbalancedAddViaSwapRouter(sonic.id),
    },
    beets: {
      lstStaking: '0xd5f7fc8ba92756a34693baa386edcc8dd5b3f141',
      lstStakingProxy: '0xe5da20f15420ad15de0fa650600afc998bbe3955',
      sfcProxy: '0xFC00FACE00000000000000000000000000000000',
      sfc: '0x0aB8f3b709A52c096f33702fE8153776472305ed',
      lstWithdrawRequestHelper: '0x52b16e3d7d25ba64f242e59f9a74799ecc432d78',
      reliquary: '0x973670ce19594f857a7cd85ee834c7a74a941684',
      magpieLoopedSonicRouter: '0xd1e0b8dc3a4cd1a892fe1b46e0aed30c35f6a087',
      loopedSonicVault: '0xc76995054ce51dfbbc954840d699b2f33d2538ee',
    },
    permit2: PERMIT2[sonic.id],
  },
  pools: convertHexToLowerCase({ issues: {} }),
  snapshot: {
    contractAddress: '0x469788fe6e9e9681c6ebf3bf78e7fd26fc015446',
    delegateAddress: '0x641e10cd6132d3e3fa01bfd65d2e0afcf64b136a', // MD delegator address
    id: '0x62656574732D6761756765732E65746800000000000000000000000000000000', // BeethovenX Snapshot id
  },
  reliquary: {
    address: '0x973670ce19594f857a7cd85ee834c7a74a941684',
    fbeets: {
      poolId: '0x10ac2f9dae6539e77e372adb14b1bf8fbd16b3e8000200000000000000000005',
      poolAddress: '0x10ac2f9dae6539e77e372adb14b1bf8fbd16b3e8',
      farmId: 0,
      maxLevel: 10,
    },
  },
  lbps: {
    collateralTokens: [USSD_TOKEN_ADDRESS, WS_TOKEN_ADDRESS, STS_TOKEN_ADDRESS],
  },
}

export default networkConfig
