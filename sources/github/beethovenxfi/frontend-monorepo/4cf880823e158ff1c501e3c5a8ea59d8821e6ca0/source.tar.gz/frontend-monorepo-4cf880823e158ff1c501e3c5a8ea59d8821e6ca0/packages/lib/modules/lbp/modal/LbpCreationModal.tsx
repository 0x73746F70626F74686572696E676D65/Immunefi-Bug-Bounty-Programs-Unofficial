import { DesktopStepTracker } from '@repo/lib/modules/transactions/transaction-steps/step-tracker/DesktopStepTracker'
import { Modal, ModalBody, ModalCloseButton, ModalContent, ModalProps } from '@chakra-ui/react'
import { RefObject, useRef, useEffect } from 'react'
import { TransactionModalHeader } from '@repo/lib/shared/components/modals/TransactionModalHeader'
import { SuccessOverlay } from '@repo/lib/shared/components/modals/SuccessOverlay'
import { useLbpForm } from '../LbpFormProvider'
import { LbpSummary } from './LbpSummary'
import { useBreakpoints } from '@repo/lib/shared/hooks/useBreakpoints'
import { VStack, Button, HStack, Text } from '@chakra-ui/react'
import { getPoolPath } from '@repo/lib/modules/pool/pool.utils'
import { useRedirect } from '@repo/lib/shared/hooks/useRedirect'
import { useLocalStorage } from 'usehooks-ts'
import { LS_KEYS } from '@repo/lib/modules/local-storage/local-storage.constants'
import { ActionModalFooter } from '@repo/lib/shared/components/modals/ActionModalFooter'
import { Address } from 'viem'
import { useLbpMetadata } from '../useLbpMetadata'
import { useIsPoolInitialized } from '@repo/lib/modules/pool/queries/useIsPoolInitialized'
import { getChainId } from '@repo/lib/config/app.config'
import { BalAlert } from '@repo/lib/shared/components/alerts/BalAlert'
import { useShouldBatchTransactions } from '@repo/lib/modules/transactions/transaction-steps/tx-batch.hooks'
import { PoolCreationModalFooter } from '@repo/lib/shared/components/modals/PoolCreationModalFooter'

import { useCreateLbpInput } from '../useCreateLbpInput'
import { useInitializeLbpInput } from '../useInitializeLbpInput'
import { usePoolCreationTransactions } from '@repo/lib/modules/pool/actions/create/modal/usePoolCreationTransactions'
import { PROJECT_CONFIG } from '@repo/lib/config/getProjectConfig'

type Props = {
  isOpen: boolean
  onClose(): void
  onOpen(): void
  finalFocusRef?: RefObject<HTMLInputElement | null>
}

export function LbpCreationModal({
  isOpen,
  onClose,
  finalFocusRef,
  ...rest
}: Props & Omit<ModalProps, 'children'>) {
  const [poolAddress, setPoolAddress] = useLocalStorage<Address | undefined>(
    LS_KEYS.LbpConfig.PoolAddress,
    undefined
  )

  const initialFocusRef = useRef(null)
  const hasAttemptedSaveMetadata = useRef(false)
  const { isDesktop } = useBreakpoints()
  const { saleStructureForm, resetLbpCreation, isFixedSale, isSeeded } = useLbpForm()
  const createPoolInput = useCreateLbpInput()
  const initPoolInput = useInitializeLbpInput()

  const { transactionSteps, initPoolTxHash, urlTxHash } = usePoolCreationTransactions({
    poolAddress,
    setPoolAddress,
    createPoolInput,
    initPoolInput,
  })

  const shouldBatchTransactions = useShouldBatchTransactions()

  const {
    saveMetadata,
    error: saveMetadataError,
    isMetadataSaved,
    reset: resetSaveMetadata,
  } = useLbpMetadata()

  const [selectedChain, saleType] = saleStructureForm.getValues(['selectedChain', 'saleType'])
  const chainId = getChainId(selectedChain)
  const { isPoolInitialized } = useIsPoolInitialized({ chainId, poolAddress })

  const handleReset = () => {
    transactionSteps.resetTransactionSteps()
    resetLbpCreation()
    resetSaveMetadata()
    onClose()
  }

  const path = getPoolPath({
    id: poolAddress as Address,
    chain: selectedChain,
    type: saleType,
    protocolVersion: 3 as const,
  })

  const { redirectToPage: redirectToPoolPage } = useRedirect(path)

  useEffect(() => {
    const handleSaveMetadata = async () => {
      if (poolAddress && !isMetadataSaved && !hasAttemptedSaveMetadata.current) {
        hasAttemptedSaveMetadata.current = true

        try {
          await saveMetadata()
        } catch (error) {
          console.error('Error saving metadata:', error)
        }
      }
    }

    handleSaveMetadata()
  }, [poolAddress, isMetadataSaved, saveMetadata])

  if (saveMetadataError && !transactionSteps.steps.some(step => step.id === 'save-metadata')) {
    transactionSteps.steps.push({
      id: 'save-metadata',
      stepType: 'sendLbpMetadata' as const,
      details: {
        gasless: true,
        type: 'Offchain action',
      },
      labels: { init: 'Save metadata', title: 'Save metadata', tooltip: 'Save metadata' },
      isComplete: () => isMetadataSaved,
      renderAction: () => undefined,
    })
  }

  const isSuccess = !!isPoolInitialized && isMetadataSaved

  return (
    <Modal
      finalFocusRef={finalFocusRef}
      initialFocusRef={initialFocusRef}
      isCentered
      isOpen={isOpen}
      onClose={onClose}
      preserveScrollBarGap
      trapFocus={!isSuccess}
      {...rest}
    >
      <SuccessOverlay startAnimation={!!initPoolTxHash} />

      <ModalContent>
        {isDesktop && (
          <DesktopStepTracker
            chain={selectedChain}
            isTxBatch={shouldBatchTransactions}
            transactionSteps={transactionSteps}
          />
        )}
        <TransactionModalHeader
          chain={selectedChain}
          label={`Preview: Create a '${isFixedSale ? "fixed price'" : isSeeded ? "seeded'" : "seedless'"} LBP`}
          txHash={initPoolTxHash}
        />
        <ModalCloseButton />
        <ModalBody>
          <LbpSummary transactionSteps={transactionSteps} />

          {isSuccess && (
            <VStack width="full">
              <Button
                isDisabled={false}
                isLoading={false}
                marginTop="4"
                onClick={() => window.open(path, '_blank')}
                size="lg"
                variant="secondary"
                w="full"
                width="full"
              >
                <HStack justifyContent="center" spacing="sm" width="100%">
                  <Text color="font.primaryGradient" fontWeight="bold">
                    View LBP page
                  </Text>
                </HStack>
              </Button>
              <Button
                isDisabled={false}
                isLoading={false}
                marginTop="2"
                onClick={handleReset}
                size="lg"
                variant="primary"
                w="full"
                width="full"
              >
                <HStack justifyContent="center" spacing="sm" width="100%">
                  <Text color="font.primaryGradient" fontWeight="bold">
                    Create another LBP
                  </Text>
                </HStack>
              </Button>
            </VStack>
          )}

          {!!saveMetadataError && (
            <VStack marginTop="4" spacing="3" width="full">
              <BalAlert
                content={`The pool has been created and seeded onchain. However, there was an error syncing the metadata to the ${PROJECT_CONFIG.projectName} API. Your pool will not display on the ${PROJECT_CONFIG.projectName} UI until the sync is completed.`}
                status="error"
                title="Error syncing metadata"
              />
              <Button
                isDisabled={false}
                isLoading={false}
                onClick={saveMetadata}
                size="lg"
                variant="secondary"
                w="full"
              >
                <HStack justifyContent="center" spacing="sm" width="100%">
                  <Text color="font.primaryGradient" fontWeight="bold">
                    Retry sync metadata
                  </Text>
                </HStack>
              </Button>
            </VStack>
          )}
        </ModalBody>

        {!saveMetadataError ? (
          <ActionModalFooter
            currentStep={transactionSteps.currentStep}
            isSuccess={isSuccess}
            returnAction={redirectToPoolPage}
            returnLabel="View pool page"
            urlTxHash={urlTxHash}
          />
        ) : null}

        {!isSuccess && <PoolCreationModalFooter onReset={handleReset} />}
      </ModalContent>
    </Modal>
  )
}
