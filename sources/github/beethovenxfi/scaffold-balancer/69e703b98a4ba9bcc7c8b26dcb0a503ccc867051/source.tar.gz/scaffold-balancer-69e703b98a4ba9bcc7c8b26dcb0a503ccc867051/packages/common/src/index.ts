export const packageName = 'common';
