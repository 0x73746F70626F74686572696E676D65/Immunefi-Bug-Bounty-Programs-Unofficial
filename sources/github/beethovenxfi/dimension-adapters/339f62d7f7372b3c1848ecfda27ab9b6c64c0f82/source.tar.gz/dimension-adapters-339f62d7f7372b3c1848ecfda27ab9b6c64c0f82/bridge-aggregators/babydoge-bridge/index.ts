import { FetchOptions, SimpleAdapter } from "../../adapters/types";
import { httpGet } from "../../utils/fetchURL";
import { CHAIN } from "../../helpers/chains";

const API_BASE = "https://axelar-bridge-connector-backend-main.babybulldog.xyz/lama-api";
const API_TON = "https://defillama-bsc-ton-bridge-backend-main.babybulldog.xyz";
const API_SOL = "https://wormhole-bridge-defilama-connector-backend-main.babybulldog.xyz";

const chainIds: Record<string, string> = {
  [CHAIN.BSC]: "56",
  [CHAIN.SOLANA]: "sol_mainnet_beta",
  [CHAIN.BASE]: "8453",
  [CHAIN.TON]: "ton_0",
};

const apis: Record<string, string[]> = {
  [CHAIN.BSC]: [API_BASE, API_TON, API_SOL],
  [CHAIN.SOLANA]: [API_SOL],
  [CHAIN.BASE]: [API_BASE],
  [CHAIN.TON]: [API_TON],
};

const fetch = async (_a: any, _b: any, options: FetchOptions) => {
  const chainId = chainIds[options.chain];
  const apiList = apis[options.chain];

  let dailyBridgeVolume = 0;

  for (const api of apiList) {
    const data = await httpGet(`${api}/volume?chain_id=${chainId}`);
    dailyBridgeVolume += data.dailyVolume || 0;
  }

  return {
    dailyBridgeVolume,
  };
};

const adapter: SimpleAdapter = {
  version: 1,
  fetch,
  runAtCurrTime: true,
  adapter: {
    [CHAIN.BSC]: { start: "2024-01-01" },
    [CHAIN.SOLANA]: { start: "2024-01-01" },
    [CHAIN.TON]: { start: "2024-01-01" },
    [CHAIN.BASE]: { start: "2024-01-01" },
  },
};

export default adapter;
