import { FetchResultV2, SimpleAdapter } from "../../adapters/types";
import { CHAIN } from '../../helpers/chains';
import { httpGet } from "../../utils/fetchURL"
import { Agent } from "https"

const agent = new Agent({ family: 4 });

const fetch = async (): Promise<FetchResultV2> => {
  const response = await httpGet(`https://api2.byreal.io/byreal/api/dex/v2/overview/global`, { httpsAgent: agent })
  const data = response.result.data

  return {
    dailyVolume: data.volumeUsd24h,
    dailyFees: data.feeUsd24h,
    dailyUserFees: data.feeUsd24h,
    dailyRevenue: data.feeUsd24h * 0.12, // 12%
    dailyProtocolRevenue: data.feeUsd24h * 0.12, // 12% Treasury
    dailySupplySideRevenue: data.feeUsd24h * 0.88, // 88%
  };
};

const adapter: SimpleAdapter = {
  adapter: {
    [CHAIN.SOLANA]: {
      fetch: fetch,
      runAtCurrTime: true,
      start: '2025-06-27',
    },
  },
  methodology: {
    Volume: 'Total token swap volumes retrieved from Byreal API.',
    Fees: 'All fees from token swaps.',
    UserFees: 'Users pay fees on every token swap.',
    Revenue: 'Amount of 12% swap fees to Byreal treasury.',
    ProtocolRevenue: 'Amount of 12% swap fees to Byreal treasury.',
    SupplySideRevenue: 'Amount of 88% swap fees distributed to LPs.',
  }
};

export default adapter;
