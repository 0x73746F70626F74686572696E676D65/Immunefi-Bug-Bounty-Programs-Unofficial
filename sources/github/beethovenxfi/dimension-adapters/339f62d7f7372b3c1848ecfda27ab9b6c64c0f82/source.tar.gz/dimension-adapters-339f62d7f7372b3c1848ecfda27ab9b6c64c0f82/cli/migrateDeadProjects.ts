import { readdir, writeFile, rm, mkdir } from "fs/promises";
import { existsSync, readFileSync, statSync } from "fs";
import { execSync } from "child_process";
import { ADAPTER_TYPES, AdapterType } from "../adapters/types";
import { setModuleDefaults } from "../adapters/utils/runAdapter";

const extensions = ['ts', 'md', 'js']
const baseFolderPath = __dirname + "/.."
const outputPath = `${baseFolderPath}/factory/deadAdapters.json`

// Get current git commit hash
const currentCommit = execSync('git rev-parse HEAD', { cwd: baseFolderPath }).toString().trim()

// Load existing dead adapters if file exists
let deadAdapters: Record<string, Record<string, any>> = {}
if (existsSync(outputPath)) {
  try {
    deadAdapters = JSON.parse(readFileSync(outputPath, 'utf-8'))
  } catch (e) {
    deadAdapters = {}
  }
}

// Track which adapters have been processed
const processedAdapters = new Set<string>()

// Store dead adapter info for dependency resolution
interface DeadAdapterInfo {
  adapterType: string
  path: string
  fileKey: string
  fullPath: string
  // imports: string[] // list of imported adapter paths (e.g., "dexs/uniswap")
}
const deadAdapterInfos: Map<string, DeadAdapterInfo> = new Map()

function sortObjectByKey(obj: Record<string, any>) {
  return Object.keys(obj).sort().reduce((sorted: Record<string, any>, key) => {
    sorted[key] = obj[key]
    return sorted
  }, {})
}

function mockFunctions(obj: any): any {
  if (typeof obj === "function") {
    return '_f'
  } else if (typeof obj === "object" && obj !== null) {
    Object.keys(obj).forEach((key) => obj[key] = mockFunctions(obj[key]))
  }
  return obj
}

function removeDotTs(s: string) {
  const splitted = s.split('.')
  if (splitted.length > 1 && extensions.includes(splitted[splitted.length - 1]))
    splitted.pop()
  return splitted.join('.')
}

async function getDirectoriesAsync(source: string): Promise<string[]> {
  const dirents = await readdir(source, { withFileTypes: true });
  return dirents.map(dirent => dirent.name);
}

async function deleteAdapter(info: DeadAdapterInfo): Promise<boolean> {
  const moduleKey = `${info.adapterType}/${info.fileKey}`

  if (processedAdapters.has(moduleKey)) {
    return false // Already processed
  }

  try {
    const importPath = `../${info.adapterType}/${info.fileKey}`
    let module = await import(importPath)
    if (!module.default) return false

    await setModuleDefaults(module.default)
    delete module.default._randomUID

    // Initialize adapter type in deadAdapters if not exists
    if (!deadAdapters[info.adapterType]) {
      deadAdapters[info.adapterType] = {}
    }

    const mockedModule = mockFunctions({ ...module.default })
    deadAdapters[info.adapterType][info.fileKey] = {
      commit: currentCommit,
      codePath: `${info.adapterType}/${info.path}`,
      module: mockedModule
    }

    console.log(`Found dead adapter: ${moduleKey} (deadFrom: ${module.default.deadFrom})`)

    // Delete the adapter file/folder
    const isDir = existsSync(info.fullPath) && statSync(info.fullPath).isDirectory()
    await rm(info.fullPath, { recursive: isDir })
    console.log(`  Deleted: ${info.fullPath}`)

    processedAdapters.add(moduleKey)
    return true
  } catch (error: any) {
    console.log(error)
    // Skip modules that fail to import
  }
  return false
}

async function scanAdapter(adapterType: string, path: string): Promise<DeadAdapterInfo | null> {
  const excludeKeys = new Set(["index", "README", '.gitkeep'])
  if (excludeKeys.has(path)) return null

  try {
    const fileKey = removeDotTs(path)
    const moduleKey = `${adapterType}/${fileKey}`
    const importPath = `../${adapterType}/${fileKey}`
    const fullPath = `${baseFolderPath}/${adapterType}/${path}`

    let module = await import(importPath)
    if (!module.default) return null

    await setModuleDefaults(module.default)
    const adapterChainExports = Object.values(module.default.adapter || {})
    let allChainsAreDead = false
    if (adapterChainExports.length > 0 && adapterChainExports.every((chainExport: any) => chainExport.deadFrom))
      allChainsAreDead = true

    if (allChainsAreDead)
      console.log(`Scanned ${moduleKey}, all chains dead: ${allChainsAreDead}`)


    if (module.default.deadFrom !== undefined || allChainsAreDead) {
      // const imports = extractImports(fullPath)
      return {
        adapterType,
        path,
        fileKey,
        fullPath,
        // imports
      }
    }
  } catch (error: any) {
    // Skip modules that fail to import
  }
  return null
}

async function run() {
  // Phase 1: Scan all adapters and identify dead ones with their dependencies
  console.log('Scanning for dead adapters...\n')

  for (const adapterType of ADAPTER_TYPES) {
    if (adapterType === AdapterType.DERIVATIVES) {
      continue // skip derivatives as they use the same folder as dexs
    }

    const folderPath = `${baseFolderPath}/${adapterType}`

    try {
      const entries = await getDirectoriesAsync(folderPath)

      for (const entry of entries) {
        const info = await scanAdapter(adapterType, entry)
        if (info) {
          const moduleKey = `${info.adapterType}/${info.fileKey}`
          deadAdapterInfos.set(moduleKey, info)
        }
      }
    } catch (error) {
      // Folder doesn't exist, skip
    }
  }

  console.log(`Found ${deadAdapterInfos.size} dead adapters\n`)

  // Phase 2: Delete dead adapters and record their info
  let totalDead = 0
  for (const [_, info] of deadAdapterInfos) {
    const deleted = await deleteAdapter(info)
    if (deleted) totalDead++
  }

  // Sort dead adapters by key
  for (const adapterType of Object.keys(deadAdapters)) {
    deadAdapters[adapterType] = sortObjectByKey(deadAdapters[adapterType])
  }
  deadAdapters = sortObjectByKey(deadAdapters)

  // Ensure the output directory exists
  const outputDir = outputPath.substring(0, outputPath.lastIndexOf('/'))
  if (!existsSync(outputDir)) {
    await mkdir(outputDir, { recursive: true })
  }

  await writeFile(outputPath, JSON.stringify(deadAdapters, null, 2))

  console.log(`\nDeleted ${totalDead} dead adapters, wrote registry to ${outputPath}`)
  console.log(`Total dead adapters in registry: ${Object.values(deadAdapters).reduce((acc, obj) => acc + Object.keys(obj).length, 0)}`)

  process.exit(0)
}

run().catch((e) => {
  console.error(e)
  process.exit(1)
})
