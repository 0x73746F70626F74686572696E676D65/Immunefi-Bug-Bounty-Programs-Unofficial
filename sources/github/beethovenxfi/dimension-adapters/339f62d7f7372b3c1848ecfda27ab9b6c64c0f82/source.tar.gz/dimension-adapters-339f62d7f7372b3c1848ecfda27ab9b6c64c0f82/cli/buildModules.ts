// console.log("Building import files for tvl/dimensions/emissions/liquidations adapters")

import { readdir, writeFile } from "fs/promises";
import { ADAPTER_TYPES, AdapterType, whitelistedBaseAdapterKeys } from "../adapters/types";
import { setModuleDefaults } from "../adapters/utils/runAdapter";
import { listHelperProtocols, deadAdapters } from "../factory/registry";

const extensions = ['ts', 'md', 'js']


run().catch(console.error).then(() => process.exit(0))

async function run() {
  const outputFile = __dirname + "/dimensionModules.json"



  const excludeKeys = new Set(["index", "README", '.gitkeep'])
  const baseFolderPath = __dirname + "/.." // path relative to current working directory -> `cd /defi`
  const dimensionsImports: any = {}

  for (const folderPath of ADAPTER_TYPES)
    await addAdapterType(folderPath)

  // Add helper-based adapters for all adapter types
  await addFactoryAdapters()
  addDeadAdapters()

  await writeFile(outputFile, JSON.stringify(dimensionsImports))

  async function addAdapterType(folderPath: string) {
    if (folderPath === AdapterType.DERIVATIVES) {
      return; // skip derivatives as they use the same folder as dexs
    }

    dimensionsImports[folderPath] = {}

    try {
      const paths_keys = await getDirectoriesAsync(`${baseFolderPath}/${folderPath}`)
      // console.log(`Found ${paths_keys.length} adapters in ${folderPath}`)

      const promises = paths_keys.map(async (path) => {
        if (excludeKeys.has(path)) return;
        await createDimensionAdaptersModule(path, folderPath)
      })

      return Promise.all(promises)

    } catch (error) {
      console.error(`Error getting directories for ${folderPath}:`, error)
    }
  }

  async function addFactoryAdapters() {
    // Get all protocols from factory registry
    const factoryProtocols = listHelperProtocols();

    for (const { protocolName, factoryName, adapterType, sourcePath, exportName } of factoryProtocols) {
      if (!dimensionsImports[adapterType]) {
        dimensionsImports[adapterType] = {};
      }

      // Guard: Skip if file-based adapter already exists (file-based takes precedence)
      if (dimensionsImports[adapterType][protocolName]) {
        // console.log(`Skipping factory adapter ${protocolName} in ${adapterType} - file-based adapter already exists`);
        continue;
      }

      try {
        // Import based on source path
        let helperModule = sourcePath.startsWith('factory/')
          ? await import(`../${sourcePath.replace('.ts', '')}`)
          : await import(`../helpers/${factoryName}`);

        if (exportName) helperModule = helperModule[exportName];

        const adapter = helperModule.getAdapter(protocolName);

        if (adapter.adapter) {
          Object.keys(adapter.adapter).forEach(chain => {
            const obj = adapter.adapter[chain]
            const keys = Object.keys(obj)
            for (const key of keys) {
              if (!whitelistedBaseAdapterKeys.has(key)) {
                delete obj[key] // remove non base adapter keys to avoid confusion, we only want the fetch/start/runAtCurrTime keys for the dimension modules
              }
            }
          })
        }

        if (!adapter) continue;

        await setModuleDefaults(adapter);
        const mockedAdapter = mockFunctions({ default: adapter });

        dimensionsImports[adapterType][protocolName] = {
          moduleFilePath: `${adapterType}/${protocolName}`,
          codePath: sourcePath,
          module: mockedAdapter.default,
        };
      } catch (error: any) {
        console.log(`Error creating helper module for ${protocolName} from ${factoryName}:`, error.message);
      }
    }
  }

  async function createDimensionAdaptersModule(path: string, adapterType: string) {
    try {
      const fileKey = removeDotTs(path)
      const moduleFilePath = `${adapterType}/${fileKey}`
      const importPath = `../${adapterType}/${fileKey}`

      let module = await import(importPath)
      if (!module.default) {
        throw new Error(`Module ${moduleFilePath} does not have a default export`)
      }
      await setModuleDefaults(module.default)
      module = mockFunctions(module)
      dimensionsImports[adapterType][fileKey] = {
        moduleFilePath,
        codePath: `${adapterType}/${path}`,
        module: module.default,
      }
    } catch (error: any) {
      console.log(`Error creating module for ${path} in ${adapterType}:`, error.message)
      return ''
    }
  }

  function addDeadAdapters() {

    const defaultCommitHash = "1e8620166b5772c02e5e68e9dcd2cbb818724d69"  // /dead folder is deleted after this step

    for (const [adapterType, adapters] of Object.entries(deadAdapters)) {
      if (!dimensionsImports[adapterType]) {
        dimensionsImports[adapterType] = {};
      }
      for (const [protocolName, adapterInfo] of Object.entries(adapters as any)) {
        if (dimensionsImports[adapterType][protocolName])
          continue;

        (adapterInfo as any).commit = (adapterInfo as any).commit ?? defaultCommitHash
        

        dimensionsImports[adapterType][protocolName] = adapterInfo;
      }
    }
  }
}

//Replace all fuctions with mock functions in an object all the way down
function mockFunctions(obj: any) {
  if (typeof obj === "function") {
    return '_f'  // llamaMockedTVLFunction
  } else if (typeof obj === "object") {
    Object.keys(obj).forEach((key) => obj[key] = mockFunctions(obj[key]))
  }
  return obj
}

function removeDotTs(s: string) {
  const splitted = s.split('.')
  if (splitted.length > 1 && extensions.includes(splitted[splitted.length - 1]))
    splitted.pop()
  return splitted.join('.')
}

// Async version of getDirectories
async function getDirectoriesAsync(source: string): Promise<string[]> {
  const dirents = await readdir(source, { withFileTypes: true });
  return dirents.map(dirent => dirent.name);
}
