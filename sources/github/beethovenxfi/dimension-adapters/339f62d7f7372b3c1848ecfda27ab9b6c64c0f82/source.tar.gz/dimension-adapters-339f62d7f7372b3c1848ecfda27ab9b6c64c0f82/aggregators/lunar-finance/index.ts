import fetchURL from "../../utils/fetchURL";
import { FetchOptions, SimpleAdapter } from "../../adapters/types";
import { CHAIN } from "../../helpers/chains";

const LUNA_API_BASE = "https://api.lunarfinance.io";
const SWAP_ANALYTICS_ENDPOINT = `${LUNA_API_BASE}/api/analytics/dexs`;

interface LunaAnalyticsResponse {
  success: boolean;
  data: {
    dailySwapVolume?: {
      usd: string;
    };
    dailyFees?: {
      usd: string;
    };
    dailyRevenue?: {
      usd: string;
    };
  };
}

const fetch = async (options: FetchOptions) => {
  const url = `${SWAP_ANALYTICS_ENDPOINT}?startTime=${options.startTimestamp + 1}&endTime=${options.endTimestamp}`;
  const data: LunaAnalyticsResponse = await fetchURL(url);

  const { dailySwapVolume, dailyFees, dailyRevenue } = data.data;

  return {
    dailyVolume: Number(dailySwapVolume?.usd) / 1e18 || 0,
    dailyFees: Number(dailyFees?.usd) / 1e18 || 0,
    dailyRevenue: Number(dailyRevenue?.usd) / 1e18 || 0,
    dailyProtocolRevenue: Number(dailyRevenue?.usd) / 1e18 || 0,
  };
};

const adapter: SimpleAdapter = {
  version: 2,
  chains: [CHAIN.SOLANA],
  fetch,
  start: '2025-05-01',
  methodology: {
    Fees: "Swap fees include protocol fees charged by Luna Finance plus underlying DEX protocol fees paid by users.",
    Revenue: "Revenue represents fees collected by Luna Finance protocol from swap transactions, typically 0.1-0.3% of transaction value.",
    ProtocolRevenue: "Protocol revenue is the portion of fees that goes to Luna Finance treasury.",
  }
};

export default adapter;