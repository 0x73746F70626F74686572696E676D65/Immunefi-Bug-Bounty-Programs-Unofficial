declare module 'formatic';
