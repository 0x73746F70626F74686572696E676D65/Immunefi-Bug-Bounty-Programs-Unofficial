import { BigintIsh, Token, TokenAmount } from '@balancer/sdk';

export class BasePoolToken extends TokenAmount {
    public readonly index: number;

    public constructor(token: Token, amount: BigintIsh, index: number) {
        super(token, amount);
        this.index = index;
    }

    public add(amount: TokenAmount): TokenAmount {
        this.amount = this.amount + amount.amount;
        this.scale18 = this.amount * this.scalar;
        return this;
    }

    public sub(amount: TokenAmount): TokenAmount {
        this.amount = this.amount - amount.amount;
        this.scale18 = this.amount * this.scalar;
        return this;
    }

    public copy(): BasePoolToken {
        return new BasePoolToken(this.token, this.amount, this.index);
    }
}
