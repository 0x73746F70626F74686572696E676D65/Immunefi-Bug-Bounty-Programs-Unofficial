import { PriceHandler, PriceItem, TokenPriceData } from './types';
import { reportFailure, reportRecovery } from '../common/failure-reporter';

export class PricingManager {
    constructor(private readonly handlers: PriceHandler[]) {}

    async calculatePricesForTokens(tokens: TokenPriceData[]): Promise<PriceItem[]> {
        if (tokens.length === 0) {
            return [];
        }

        // Build initial price map from tokens' currentPrice
        const allPrices = new Map<string, { price: number; updatedBy: string }>();
        tokens.forEach((token) => {
            if (typeof token.currentPrice === 'number' && Number.isFinite(token.currentPrice)) {
                allPrices.set(token.address, {
                    price: token.currentPrice,
                    updatedBy: token.pricedBy || '',
                });
            }
        });

        let remainingTokens = [...tokens];
        const allPriceItems: PriceItem[] = [];

        for (const handler of this.handlers) {
            if (remainingTokens.length === 0) {
                break;
            }

            try {
                const priceItems = await handler.calculatePricesForTokens(remainingTokens, allPrices);
                reportRecovery(`price-handler-${handler.id}`);
                allPriceItems.push(...priceItems);

                // Update allPrices map with new prices from this handler
                priceItems.forEach((item) => {
                    allPrices.set(item.address, { price: item.price, updatedBy: item.updatedBy });
                });

                // Remove successfully priced tokens from remaining tokens
                const pricedAddresses = new Set(priceItems.map((item) => item.address));
                remainingTokens = remainingTokens.filter((token) => !pricedAddresses.has(token.address));
            } catch (error) {
                console.error(`Price handler ${handler.id} failed:`, error);
                reportFailure(`price-handler-${handler.id}`, error, { handler: handler.id });

                if (handler.exitIfFails) {
                    throw error;
                }
            }
        }

        return allPriceItems;
    }
}
