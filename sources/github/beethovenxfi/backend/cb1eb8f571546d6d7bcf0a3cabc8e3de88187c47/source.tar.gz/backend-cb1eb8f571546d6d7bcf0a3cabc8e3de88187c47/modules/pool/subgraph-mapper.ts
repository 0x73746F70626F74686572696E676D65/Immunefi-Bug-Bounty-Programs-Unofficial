import { Chain, PrismaPoolType } from '@prisma/client';
import { BalancerPoolFragment } from '../subgraphs/balancer-subgraph/generated/balancer-subgraph-types';
import { zeroAddress as AddressZero } from 'viem';
import { gyro, stable, quantAmmWeighted, reclamm } from './pool-data';

export const subgraphToPrismaCreate = (
    pool: BalancerPoolFragment,
    chain: Chain,
    blockNumber: number,
) => {
    const dbData = subgraphMapper(pool, chain, blockNumber);

    const prismaPoolRecordWithAssociations = {
        data: {
            ...dbData.base,
            typeData: dbData.typeData,
            tokens: {
                createMany: {
                    data: dbData.tokens,
                },
            },
            dynamicData: {
                create: {
                    id: dbData.base.id,
                    ...dbData.dynamicData,
                },
            },
        },
    };

    return prismaPoolRecordWithAssociations;
};

export const subgraphToPrismaUpdate = (
    pool: BalancerPoolFragment,
    chain: Chain,
    blockNumber: number,
) => {
    const dbData = subgraphMapper(pool, chain, blockNumber);
    const { id, ...baseWithoutId } = dbData.base;

    const prismaPoolRecordWithDataAssociations = {
        ...baseWithoutId,
        typeData: dbData.typeData,
        tokens: {
            update: dbData.tokens.map((token) => ({
                where: {
                    id_chain: {
                        id: token.id,
                        chain: chain,
                    },
                },
                data: {
                    ...token,
                },
            })),
        },
    };

    return prismaPoolRecordWithDataAssociations;
};

const subgraphMapper = (
    pool: BalancerPoolFragment,
    chain: Chain,
    blockNumber: number,
) => {
    const type = mapSubgraphPoolTypeToPoolType(pool.poolType!);
    const version = mapPoolTypeVersion(pool.poolType!, pool.poolTypeVersion!);

    const base = {
        id: pool.id,
        chain: chain,
        createTime: pool.createTime,
        address: pool.address,
        symbol: pool.symbol || '',
        name: pool.name || '',
        type: type,
        version: version,
        swapFeeManager: pool.owner || AddressZero,
        factory: pool.factory,
    };

    const dynamicData = {
        blockNumber,
        swapFee: pool.swapFee,
        swapEnabled: pool.swapEnabled,
        totalShares: pool.totalShares,
        totalSharesNum: parseFloat(pool.totalShares),
        totalLiquidity: 0,
    };

    const typeData: ReturnType<(typeof typeDataMapper)[keyof typeof typeDataMapper]> | {} = Object.keys(
        typeDataMapper,
    ).includes(type)
        ? typeDataMapper[type as keyof typeof typeDataMapper](pool)
        : {};

    const tokens =
        pool.tokens?.map((token) => {
            let priceRateProvider;
            if (pool.priceRateProviders) {
                const data = pool.priceRateProviders.find((provider) => provider.token.address === token.address);
                priceRateProvider = data?.address;
            }

            return {
                id: token.id,
                address: token.address,
                priceRateProvider,
                exemptFromProtocolYieldFee: token.isExemptFromYieldProtocolFee
                    ? token.isExemptFromYieldProtocolFee
                    : false,
                index: token.index || pool.tokensList.findIndex((address) => address === token.address),
                balance: token.balance,
                balanceUSD: 0,
                weight: token.weight,
                priceRate: token.priceRate || '1.0',
            };
        }) ?? [];

    return {
        base,
        dynamicData,
        tokens,
        typeData,
    };
};

const mapSubgraphPoolTypeToPoolType = (poolType: string): PrismaPoolType => {
    switch (poolType) {
        case 'Weighted':
            return 'WEIGHTED';
        case 'LiquidityBootstrapping':
            return 'LIQUIDITY_BOOTSTRAPPING';
        case 'Stable':
            return 'STABLE';
        case 'ComposableStable':
            return 'COMPOSABLE_STABLE';
        case 'Gyro2':
            return 'GYRO';
        case 'Gyro3':
            return 'GYRO3';
        case 'GyroE':
            return 'GYROE';
    }

    return 'UNKNOWN';
};

const mapPoolTypeVersion = (poolType: string, poolTypeVersion: number): number => {
    // for the old phantom stable pool, we add it to the DB as type COMPOSABLE_STABLE with version 0
    let version = poolTypeVersion ? poolTypeVersion : 1;
    if (poolType === 'StablePhantom') {
        version = 0;
    }

    return version;
};

// v2 types
export const typeDataMapper = {
    GYRO: gyro,
    GYRO3: gyro,
    GYROE: gyro,
    STABLE: stable,
    COMPOSABLE_STABLE: stable,
};

export type GyroData = ReturnType<typeof gyro>;
export type StableData = ReturnType<typeof stable>;
export type QuantAmmWeightedData = ReturnType<typeof quantAmmWeighted> & {
    firstFourWeightsAndMultipliers?: string[];
    secondFourWeightsAndMultipliers?: string[];
};
export type ReclammData = ReturnType<typeof reclamm>;
