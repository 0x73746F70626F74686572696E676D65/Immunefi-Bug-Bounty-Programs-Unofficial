export type Maybe<T> = T | null;
export type InputMaybe<T> = Maybe<T>;
export type Exact<T extends { [key: string]: unknown }> = { [K in keyof T]: T[K] };
export type MakeOptional<T, K extends keyof T> = Omit<T, K> & { [SubKey in K]?: Maybe<T[SubKey]> };
export type MakeMaybe<T, K extends keyof T> = Omit<T, K> & { [SubKey in K]: Maybe<T[SubKey]> };
/** All built-in and custom scalars, mapped to their actual values */
export type Scalars = {
    ID: string;
    String: string;
    Boolean: boolean;
    Int: number;
    Float: number;
    AmountHumanReadable: any;
    BigDecimal: any;
    BigInt: any;
    Bytes: any;
    Date: any;
    GqlBigNumber: any;
    JSON: any;
};

export type CreateLbpInput = {
    metadata: LbpMetadataInput;
    poolContract: LbPoolInput;
};

/** The review data for the ERC4626 token */
export type Erc4626ReviewData = {
    __typename?: 'Erc4626ReviewData';
    /** If it is an ERC4626 token, this defines whether we can use wrap/unwrap through the buffer in swap paths for this token. */
    canUseBufferForSwaps?: Maybe<Scalars['Boolean']>;
    /** The filename of the review of the ERC4626 */
    reviewFile: Scalars['String'];
    /** A summary of the ERC4626 review, usually just says safe or unsafe */
    summary: Scalars['String'];
    /** If it is an ERC4626 token, this defines whether we allow underlying tokens to be used for add/remove operations. */
    useUnderlyingForAddRemove?: Maybe<Scalars['Boolean']>;
    /** If it is an ERC4626 token, this defines whether we allow the wrapped tokens to be used for add/remove operations. */
    useWrappedForAddRemove?: Maybe<Scalars['Boolean']>;
    /** Warnings associated with the ERC4626 */
    warnings: Array<Scalars['String']>;
};

/** ExitFee hook specific params. Percentage format is 0.01 -> 0.01%. */
export type ExitFeeHookParams = {
    __typename?: 'ExitFeeHookParams';
    exitFeePercentage?: Maybe<Scalars['String']>;
};

/** FeeTaking hook specific params. Percentage format is 0.01 -> 0.01% */
export type FeeTakingHookParams = {
    __typename?: 'FeeTakingHookParams';
    addLiquidityFeePercentage?: Maybe<Scalars['String']>;
    removeLiquidityFeePercentage?: Maybe<Scalars['String']>;
    swapFeePercentage?: Maybe<Scalars['String']>;
};

export type GqlAggregatorPoolFilter = {
    chainIn?: InputMaybe<Array<GqlChain>>;
    idIn?: InputMaybe<Array<Scalars['String']>>;
    includeHooks?: InputMaybe<Array<GqlHookType>>;
    minTvl?: InputMaybe<Scalars['Float']>;
    poolTypeIn?: InputMaybe<Array<GqlPoolType>>;
    protocolVersionIn?: InputMaybe<Array<Scalars['Int']>>;
    tokensIn?: InputMaybe<Array<Scalars['String']>>;
};

export enum GqlChain {
    SONIC = 'SONIC',
}

/** Hook data */
export type GqlHook = {
    __typename?: 'GqlHook';
    address: Scalars['String'];
    config?: Maybe<HookConfig>;
    /** Hook type specific params */
    params?: Maybe<HookParams>;
    /** The review for this hook if applicable. */
    reviewData?: Maybe<GqlHookReviewData>;
    type: GqlHookType;
};

/** Represents the review data for the hook */
export type GqlHookReviewData = {
    __typename?: 'GqlHookReviewData';
    /** The filename of the review of the hook */
    reviewFile: Scalars['String'];
    /** A summary of the hook review, usually just says safe or unsafe */
    summary: Scalars['String'];
    /** Warnings associated with the hook */
    warnings: Array<Scalars['String']>;
};

export enum GqlHookType {
    AKRON = 'AKRON',
    DIRECTIONAL_FEE = 'DIRECTIONAL_FEE',
    EXIT_FEE = 'EXIT_FEE',
    FEE_TAKING = 'FEE_TAKING',
    FIXED_LBP = 'FIXED_LBP',
    LBP = 'LBP',
    LOTTERY = 'LOTTERY',
    MEV_TAX = 'MEV_TAX',
    NFTLIQUIDITY_POSITION = 'NFTLIQUIDITY_POSITION',
    RECLAMM = 'RECLAMM',
    STABLE_SURGE = 'STABLE_SURGE',
    UNKNOWN = 'UNKNOWN',
    VEBAL_DISCOUNT = 'VEBAL_DISCOUNT',
}

export type GqlLbpTopTrade = {
    __typename?: 'GqlLBPTopTrade';
    address: Scalars['String'];
    timestamp: Scalars['String'];
    value: Scalars['String'];
};

export type GqlLoopsData = {
    __typename?: 'GqlLoopsData';
    /** Actual TotalSupply of LoopS. */
    actualSupply: Scalars['String'];
    /** The total APR for LoopS */
    apr: Scalars['Float'];
    /** The amount of stS provided to Aave. */
    collateralAmount: Scalars['String'];
    /** The amount of stS provided to Aave in S. */
    collateralAmountInEth: Scalars['String'];
    /** The total S debt amount of the position */
    debtAmount: Scalars['String'];
    /** The health factor of the Aave position */
    healthFactor: Scalars['String'];
    /** The amount of leverage the current position has. */
    leverage: Scalars['Float'];
    /** Net Asset Value. The amount of collateral minus the amount of debt. */
    nav: Scalars['String'];
    /** The current rate of LoopS against S. */
    rate: Scalars['String'];
    /** The current amount of stS supplied to the Aave market */
    stSAaveMarketSupply: Scalars['String'];
    /** The current cap on the stS market on Aave */
    stSAaveMarketSupplyCap: Scalars['String'];
    /** Net Asset Value in USD. */
    tvl: Scalars['String'];
};

/** Represents an event that occurs when liquidity is added or removed from a pool. */
export type GqlPoolAddRemoveEventV3 = GqlPoolEvent & {
    __typename?: 'GqlPoolAddRemoveEventV3';
    /** The block number of the event. */
    blockNumber: Scalars['Int'];
    /** The block timestamp of the event. */
    blockTimestamp: Scalars['Int'];
    /** The chain on which the event occurred. */
    chain: GqlChain;
    /** The unique identifier of the event. */
    id: Scalars['ID'];
    /** The log index of the event. */
    logIndex: Scalars['Int'];
    /** The pool ID associated with the event. */
    poolId: Scalars['String'];
    /** The sender of the event. */
    sender: Scalars['String'];
    /** The timestamp of the event. */
    timestamp: Scalars['Int'];
    /** The tokens involved in the event. Ordered by poolToken index. */
    tokens: Array<GqlPoolEventAmount>;
    /** The transaction hash of the event. */
    tx: Scalars['String'];
    /** The type of the event. */
    type: GqlPoolEventType;
    /** The user address associated with the event. */
    userAddress: Scalars['String'];
    /** The value of the event in USD. */
    valueUSD: Scalars['Float'];
};

export type GqlPoolAggregator = {
    __typename?: 'GqlPoolAggregator';
    /** The contract address of the pool. */
    address: Scalars['Bytes'];
    /** Data specific to gyro/fx pools */
    alpha?: Maybe<Scalars['String']>;
    /** Data specific to stable pools */
    amp?: Maybe<Scalars['BigInt']>;
    /** Data specific to gyro/fx pools */
    beta?: Maybe<Scalars['String']>;
    /** Data specific to gyro pools */
    c?: Maybe<Scalars['String']>;
    /** ReClamm: The centeredness margin of the pool */
    centerednessMargin?: Maybe<Scalars['BigDecimal']>;
    /** The chain on which the pool is deployed */
    chain: GqlChain;
    /** The timestamp the pool was created. */
    createTime: Scalars['Int'];
    /** ReClamm: The current fourth root price ratio, an interpolation of the price ratio state */
    currentFourthRootPriceRatio?: Maybe<Scalars['BigDecimal']>;
    /** Data specific to gyro pools */
    dSq?: Maybe<Scalars['String']>;
    /** ReClamm: Represents how fast the pool can move the virtual balances per day */
    dailyPriceShiftBase?: Maybe<Scalars['BigDecimal']>;
    /** The decimals of the BPT, usually 18 */
    decimals: Scalars['Int'];
    /** Data specific to fx pools */
    delta?: Maybe<Scalars['String']>;
    /** Dynamic data such as token balances, swap fees or volume */
    dynamicData: GqlPoolDynamicData;
    /** ReClamm: The fourth root price ratio at the end of an update */
    endFourthRootPriceRatio?: Maybe<Scalars['BigDecimal']>;
    /** Data specific to fx pools */
    epsilon?: Maybe<Scalars['String']>;
    /** The factory contract address from which the pool was created. */
    factory?: Maybe<Scalars['Bytes']>;
    /** Hook assigned to a pool */
    hook?: Maybe<GqlHook>;
    /** The pool id. This is equal to the address for protocolVersion 3 pools */
    id: Scalars['ID'];
    /** Data specific to gyro/fx pools */
    lambda?: Maybe<Scalars['String']>;
    /** The timestamp of the last user interaction */
    lastTimestamp?: Maybe<Scalars['Int']>;
    /** ReClamm: The last virtual balances of the pool */
    lastVirtualBalances?: Maybe<Array<Scalars['BigDecimal']>>;
    /** Liquidity management settings for v3 pools. */
    liquidityManagement?: Maybe<LiquidityManagement>;
    /** The name of the pool as per contract */
    name: Scalars['String'];
    /** Account empowered to pause/unpause the pool (or 0 to delegate to governance) */
    pauseManager?: Maybe<Scalars['Bytes']>;
    /** Account empowered to set the pool creator fee percentage */
    poolCreator?: Maybe<Scalars['Bytes']>;
    /** Returns all pool tokens, including BPTs and nested pools if there are any. Only one nested level deep. */
    poolTokens: Array<GqlPoolTokenDetail>;
    /** ReClamm: The timestamp when the update ends */
    priceRatioUpdateEndTime?: Maybe<Scalars['Int']>;
    /** ReClamm: The timestamp when the update begins */
    priceRatioUpdateStartTime?: Maybe<Scalars['Int']>;
    /** The protocol version on which the pool is deployed, 1, 2 or 3 */
    protocolVersion: Scalars['Int'];
    /** QuantAmmWeighted specific fields */
    quantAmmWeightedParams?: Maybe<QuantAmmWeightedParams>;
    /** Data specific to gyro pools */
    root3Alpha?: Maybe<Scalars['String']>;
    /** Data specific to gyro pools */
    s?: Maybe<Scalars['String']>;
    /** Data specific to gyro pools */
    sqrtAlpha?: Maybe<Scalars['String']>;
    /** Data specific to gyro pools */
    sqrtBeta?: Maybe<Scalars['String']>;
    /** ReClamm: The fourth root price ratio at the start of an update */
    startFourthRootPriceRatio?: Maybe<Scalars['BigDecimal']>;
    /** Account empowered to set static swap fees for a pool (when 0 on V2 swap fees are immutable, on V3 delegate to governance) */
    swapFeeManager?: Maybe<Scalars['Bytes']>;
    /** The token symbol of the pool as per contract */
    symbol: Scalars['String'];
    /** Data specific to gyro pools */
    tauAlphaX?: Maybe<Scalars['String']>;
    /** Data specific to gyro pools */
    tauAlphaY?: Maybe<Scalars['String']>;
    /** Data specific to gyro pools */
    tauBetaX?: Maybe<Scalars['String']>;
    /** Data specific to gyro pools */
    tauBetaY?: Maybe<Scalars['String']>;
    /** The pool type, such as weighted, stable, etc. */
    type: GqlPoolType;
    /** Data specific to gyro pools */
    u?: Maybe<Scalars['String']>;
    /** Data specific to gyro pools */
    v?: Maybe<Scalars['String']>;
    /** The version of the pool type. */
    version: Scalars['Int'];
    /** Data specific to gyro pools */
    w?: Maybe<Scalars['String']>;
    /** Data specific to gyro pools */
    z?: Maybe<Scalars['String']>;
};

/** All APRs for a pool */
export type GqlPoolAprItem = {
    __typename?: 'GqlPoolAprItem';
    /** The APR value in % -> 0.2 = 20% */
    apr: Scalars['Float'];
    /** The id of the APR item */
    id: Scalars['ID'];
    /** The reward token address, if the APR originates from token emissions */
    rewardTokenAddress?: Maybe<Scalars['String']>;
    /** The reward token symbol, if the APR originates from token emissions */
    rewardTokenSymbol?: Maybe<Scalars['String']>;
    /** Specific type of this APR */
    type: GqlPoolAprItemType;
};

/** Enum representing the different types of the APR in a pool. */
export enum GqlPoolAprItemType {
    /** Dynamic swap fee APR based on data from the last 24h */
    DYNAMIC_SWAP_FEE_24H = 'DYNAMIC_SWAP_FEE_24H',
    /** Represents the yield from an IB (Interest-Bearing) asset APR in a pool. */
    IB_YIELD = 'IB_YIELD',
    /** Reward APR in a pool from maBEETS emissions allocated by gauge votes. Emitted in BEETS. */
    MABEETS_EMISSIONS = 'MABEETS_EMISSIONS',
    /** Rewards distributed by merkl.xyz */
    MERKL = 'MERKL',
    /** APR calculated for QUANT-AMM pools based on performance measurements over a month */
    QUANT_AMM_UPLIFT = 'QUANT_AMM_UPLIFT',
    /** Staking reward APR in a pool from a reward token. */
    STAKING = 'STAKING',
    /** APR boost that can be earned, i.e. via maBEETS. */
    STAKING_BOOST = 'STAKING_BOOST',
    /** Swap fee APR based on data from the last 24h */
    SWAP_FEE_24H = 'SWAP_FEE_24H',
    /** APR that can be earned thourgh voting, i.e. gauge votes */
    VOTING = 'VOTING',
}

/** The base type as returned by poolGetPool (specific pool query) */
export type GqlPoolBase = {
    /** The contract address of the pool. */
    address: Scalars['Bytes'];
    /** The chain on which the pool is deployed */
    chain: GqlChain;
    /** The timestamp the pool was created. */
    createTime: Scalars['Int'];
    /** The decimals of the BPT, usually 18 */
    decimals: Scalars['Int'];
    /** Dynamic data such as token balances, swap fees or volume */
    dynamicData: GqlPoolDynamicData;
    /** The factory contract address from which the pool was created. */
    factory?: Maybe<Scalars['Bytes']>;
    /** Whether at least one token in this pool is considered an ERC4626 token and the buffer is allowed. */
    hasAnyAllowedBuffer: Scalars['Boolean'];
    /** Whether at least one token in this pool is considered an ERC4626 token. */
    hasErc4626: Scalars['Boolean'];
    /** Hook assigned to a pool */
    hook?: Maybe<GqlHook>;
    /** The pool id. This is equal to the address for protocolVersion 3 pools */
    id: Scalars['ID'];
    /** Liquidity management settings for v3 pools. */
    liquidityManagement?: Maybe<LiquidityManagement>;
    /** The name of the pool as per contract */
    name: Scalars['String'];
    /** Account empowered to pause/unpause the pool (or 0 to delegate to governance) */
    pauseManager?: Maybe<Scalars['Bytes']>;
    /** Account empowered to set the pool creator fee percentage */
    poolCreator?: Maybe<Scalars['Bytes']>;
    /** Returns pool tokens, including BPTs and nested pools and their pool tokens if there are any. Only one nested level deep. */
    poolTokens: Array<GqlPoolTokenDetail>;
    /** The protocol version on which the pool is deployed, 1, 2 or 3 */
    protocolVersion: Scalars['Int'];
    /** Staking options of this pool which emit additional rewards */
    staking?: Maybe<GqlPoolStaking>;
    /** Account empowered to set static swap fees for a pool (when 0 on V2 swap fees are immutable, on V3 delegate to governance) */
    swapFeeManager?: Maybe<Scalars['Bytes']>;
    /** The token symbol of the pool as per contract */
    symbol: Scalars['String'];
    /** List of tags assigned by the team based on external factors */
    tags?: Maybe<Array<Maybe<Scalars['String']>>>;
    /** The pool type, such as weighted, stable, etc. */
    type: GqlPoolType;
    /** If a user address was provided in the query, the user balance is populated here */
    userBalance?: Maybe<GqlPoolUserBalance>;
    /** The version of the pool type. */
    version: Scalars['Int'];
};

export type GqlPoolComposableStable = GqlPoolBase & {
    __typename?: 'GqlPoolComposableStable';
    address: Scalars['Bytes'];
    amp: Scalars['BigInt'];
    bptPriceRate: Scalars['BigDecimal'];
    chain: GqlChain;
    createTime: Scalars['Int'];
    decimals: Scalars['Int'];
    dynamicData: GqlPoolDynamicData;
    factory?: Maybe<Scalars['Bytes']>;
    hasAnyAllowedBuffer: Scalars['Boolean'];
    hasErc4626: Scalars['Boolean'];
    hook?: Maybe<GqlHook>;
    id: Scalars['ID'];
    liquidityManagement?: Maybe<LiquidityManagement>;
    name: Scalars['String'];
    /** Account empowered to pause/unpause the pool (or 0 to delegate to governance) */
    pauseManager?: Maybe<Scalars['Bytes']>;
    /** Account empowered to set the pool creator fee percentage */
    poolCreator?: Maybe<Scalars['Bytes']>;
    poolTokens: Array<GqlPoolTokenDetail>;
    protocolVersion: Scalars['Int'];
    staking?: Maybe<GqlPoolStaking>;
    /** Account empowered to set static swap fees for a pool (when 0 on V2 swap fees are immutable, on V3 delegate to governance) */
    swapFeeManager?: Maybe<Scalars['Bytes']>;
    symbol: Scalars['String'];
    tags?: Maybe<Array<Maybe<Scalars['String']>>>;
    type: GqlPoolType;
    userBalance?: Maybe<GqlPoolUserBalance>;
    version: Scalars['Int'];
};

export type GqlPoolDynamicData = {
    __typename?: 'GqlPoolDynamicData';
    /** Protocol and pool creator fees combined */
    aggregateSwapFee: Scalars['BigDecimal'];
    /** Protocol and pool creator fees combined */
    aggregateYieldFee: Scalars['BigDecimal'];
    aprItems: Array<GqlPoolAprItem>;
    fees24h: Scalars['BigDecimal'];
    fees48h: Scalars['BigDecimal'];
    holdersCount: Scalars['BigInt'];
    /** True for bricked pools */
    isInRecoveryMode: Scalars['Boolean'];
    isPaused: Scalars['Boolean'];
    lifetimeSwapFees: Scalars['BigDecimal'];
    lifetimeVolume: Scalars['BigDecimal'];
    poolId: Scalars['ID'];
    protocolFees24h: Scalars['BigDecimal'];
    protocolFees48h: Scalars['BigDecimal'];
    protocolYieldCapture24h: Scalars['BigDecimal'];
    protocolYieldCapture48h: Scalars['BigDecimal'];
    /** Disabled for bricked pools */
    swapEnabled: Scalars['Boolean'];
    swapFee: Scalars['BigDecimal'];
    totalLiquidity: Scalars['BigDecimal'];
    totalLiquidity24hAgo: Scalars['BigDecimal'];
    totalShares: Scalars['BigDecimal'];
    totalShares24hAgo: Scalars['BigDecimal'];
    totalSupply: Scalars['BigDecimal'];
    volume24h: Scalars['BigDecimal'];
    volume48h: Scalars['BigDecimal'];
    yieldCapture24h: Scalars['BigDecimal'];
    yieldCapture48h: Scalars['BigDecimal'];
};

/** Represents an event that occurs in a pool. */
export type GqlPoolEvent = {
    /** The block number of the event. */
    blockNumber: Scalars['Int'];
    /** The block timestamp of the event. */
    blockTimestamp: Scalars['Int'];
    /** The chain on which the event occurred. */
    chain: GqlChain;
    /** The unique identifier of the event. */
    id: Scalars['ID'];
    /** The log index of the event. */
    logIndex: Scalars['Int'];
    /** The pool ID associated with the event. */
    poolId: Scalars['String'];
    /** The sender of the event. */
    sender: Scalars['String'];
    /** The timestamp of the event. */
    timestamp: Scalars['Int'];
    /** The transaction hash of the event. */
    tx: Scalars['String'];
    /** The type of the event. */
    type: GqlPoolEventType;
    /** The user address associated with the event. */
    userAddress: Scalars['String'];
    /** The USD value of this event. */
    valueUSD: Scalars['Float'];
};

export type GqlPoolEventAmount = {
    __typename?: 'GqlPoolEventAmount';
    address: Scalars['String'];
    amount: Scalars['String'];
    valueUSD: Scalars['Float'];
};

export enum GqlPoolEventType {
    ADD = 'ADD',
    REMOVE = 'REMOVE',
    SWAP = 'SWAP',
}

export type GqlPoolEventsFilter = {
    chainIn?: InputMaybe<Array<InputMaybe<GqlChain>>>;
    poolId?: InputMaybe<Scalars['String']>;
    type?: InputMaybe<GqlPoolEventType>;
    userAddress?: InputMaybe<Scalars['String']>;
};

export type GqlPoolFeaturedPool = {
    __typename?: 'GqlPoolFeaturedPool';
    description: Scalars['String'];
    pool: GqlPoolBase;
    poolId: Scalars['ID'];
    primary: Scalars['Boolean'];
};

export type GqlPoolFilter = {
    chainIn?: InputMaybe<Array<GqlChain>>;
    chainNotIn?: InputMaybe<Array<GqlChain>>;
    createTime?: InputMaybe<GqlPoolTimePeriod>;
    idIn?: InputMaybe<Array<Scalars['String']>>;
    idNotIn?: InputMaybe<Array<Scalars['String']>>;
    minTvl?: InputMaybe<Scalars['Float']>;
    poolTypeIn?: InputMaybe<Array<GqlPoolType>>;
    poolTypeNotIn?: InputMaybe<Array<GqlPoolType>>;
    protocolVersionIn?: InputMaybe<Array<Scalars['Int']>>;
    /** Only returns pools where the rateproviders are reviewed. Default: false */
    reviewedOnly?: InputMaybe<Scalars['Boolean']>;
    /**
     * For list of tags see: https://github.com/balancer/metadata/blob/main/pools/index.json
     * Use uppercase
     */
    tagIn?: InputMaybe<Array<Scalars['String']>>;
    /**
     * For list of tags see: https://github.com/balancer/metadata/blob/main/pools/index.json
     * Use uppercase
     */
    tagNotIn?: InputMaybe<Array<Scalars['String']>>;
    tokensIn?: InputMaybe<Array<Scalars['String']>>;
    tokensNotIn?: InputMaybe<Array<Scalars['String']>>;
    userAddress?: InputMaybe<Scalars['String']>;
};

export type GqlPoolFixedPriceLbp = GqlPoolBase & {
    __typename?: 'GqlPoolFixedPriceLBP';
    address: Scalars['Bytes'];
    chain: GqlChain;
    createTime: Scalars['Int'];
    decimals: Scalars['Int'];
    description?: Maybe<Scalars['String']>;
    discord?: Maybe<Scalars['String']>;
    dynamicData: GqlPoolDynamicData;
    endTime: Scalars['Int'];
    factory?: Maybe<Scalars['Bytes']>;
    farcaster?: Maybe<Scalars['String']>;
    hasAnyAllowedBuffer: Scalars['Boolean'];
    hasErc4626: Scalars['Boolean'];
    hook?: Maybe<GqlHook>;
    id: Scalars['ID'];
    isProjectTokenSwapInBlocked: Scalars['Boolean'];
    lbpName?: Maybe<Scalars['String']>;
    lbpOwner: Scalars['String'];
    liquidityManagement?: Maybe<LiquidityManagement>;
    name: Scalars['String'];
    /** Account empowered to pause/unpause the pool (or 0 to delegate to governance) */
    pauseManager?: Maybe<Scalars['Bytes']>;
    /** Account empowered to set the pool creator fee percentage */
    poolCreator?: Maybe<Scalars['Bytes']>;
    poolTokens: Array<GqlPoolTokenDetail>;
    projectToken: Scalars['String'];
    projectTokenIndex: Scalars['Int'];
    projectTokenRate: Scalars['BigDecimal'];
    protocolVersion: Scalars['Int'];
    reserveToken: Scalars['String'];
    reserveTokenIndex: Scalars['Int'];
    /** All tokens of the pool. If it is a nested pool, the nested pool is expanded with its own tokens again. */
    staking?: Maybe<GqlPoolStaking>;
    startTime: Scalars['Int'];
    /** Account empowered to set static swap fees for a pool (when 0 on V2 swap fees are immutable, on V3 delegate to governance) */
    swapFeeManager?: Maybe<Scalars['Bytes']>;
    symbol: Scalars['String'];
    tags?: Maybe<Array<Maybe<Scalars['String']>>>;
    telegram?: Maybe<Scalars['String']>;
    topTrades?: Maybe<Array<GqlLbpTopTrade>>;
    type: GqlPoolType;
    userBalance?: Maybe<GqlPoolUserBalance>;
    version: Scalars['Int'];
    website?: Maybe<Scalars['String']>;
    x?: Maybe<Scalars['String']>;
};

export type GqlPoolGyro = GqlPoolBase & {
    __typename?: 'GqlPoolGyro';
    address: Scalars['Bytes'];
    alpha: Scalars['String'];
    beta: Scalars['String'];
    c: Scalars['String'];
    chain: GqlChain;
    createTime: Scalars['Int'];
    dSq: Scalars['String'];
    decimals: Scalars['Int'];
    dynamicData: GqlPoolDynamicData;
    factory?: Maybe<Scalars['Bytes']>;
    hasAnyAllowedBuffer: Scalars['Boolean'];
    hasErc4626: Scalars['Boolean'];
    hook?: Maybe<GqlHook>;
    id: Scalars['ID'];
    lambda: Scalars['String'];
    liquidityManagement?: Maybe<LiquidityManagement>;
    name: Scalars['String'];
    /** Account empowered to pause/unpause the pool (or 0 to delegate to governance) */
    pauseManager?: Maybe<Scalars['Bytes']>;
    /** Account empowered to set the pool creator fee percentage */
    poolCreator?: Maybe<Scalars['Bytes']>;
    poolTokens: Array<GqlPoolTokenDetail>;
    protocolVersion: Scalars['Int'];
    root3Alpha: Scalars['String'];
    s: Scalars['String'];
    sqrtAlpha: Scalars['String'];
    sqrtBeta: Scalars['String'];
    staking?: Maybe<GqlPoolStaking>;
    /** Account empowered to set static swap fees for a pool (when 0 on V2 swap fees are immutable, on V3 delegate to governance) */
    swapFeeManager?: Maybe<Scalars['Bytes']>;
    symbol: Scalars['String'];
    tags?: Maybe<Array<Maybe<Scalars['String']>>>;
    tauAlphaX: Scalars['String'];
    tauAlphaY: Scalars['String'];
    tauBetaX: Scalars['String'];
    tauBetaY: Scalars['String'];
    type: GqlPoolType;
    u: Scalars['String'];
    userBalance?: Maybe<GqlPoolUserBalance>;
    v: Scalars['String'];
    version: Scalars['Int'];
    w: Scalars['String'];
    z: Scalars['String'];
};

export type GqlPoolLiquidityBootstrapping = GqlPoolBase & {
    __typename?: 'GqlPoolLiquidityBootstrapping';
    address: Scalars['Bytes'];
    chain: GqlChain;
    createTime: Scalars['Int'];
    decimals: Scalars['Int'];
    dynamicData: GqlPoolDynamicData;
    factory?: Maybe<Scalars['Bytes']>;
    hasAnyAllowedBuffer: Scalars['Boolean'];
    hasErc4626: Scalars['Boolean'];
    hook?: Maybe<GqlHook>;
    id: Scalars['ID'];
    liquidityManagement?: Maybe<LiquidityManagement>;
    name: Scalars['String'];
    /** Account empowered to pause/unpause the pool (or 0 to delegate to governance) */
    pauseManager?: Maybe<Scalars['Bytes']>;
    /** Account empowered to set the pool creator fee percentage */
    poolCreator?: Maybe<Scalars['Bytes']>;
    poolTokens: Array<GqlPoolTokenDetail>;
    protocolVersion: Scalars['Int'];
    staking?: Maybe<GqlPoolStaking>;
    /** Account empowered to set static swap fees for a pool (when 0 on V2 swap fees are immutable, on V3 delegate to governance) */
    swapFeeManager?: Maybe<Scalars['Bytes']>;
    symbol: Scalars['String'];
    tags?: Maybe<Array<Maybe<Scalars['String']>>>;
    type: GqlPoolType;
    userBalance?: Maybe<GqlPoolUserBalance>;
    version: Scalars['Int'];
};

export type GqlPoolLiquidityBootstrappingV3 = GqlPoolBase & {
    __typename?: 'GqlPoolLiquidityBootstrappingV3';
    address: Scalars['Bytes'];
    chain: GqlChain;
    createTime: Scalars['Int'];
    decimals: Scalars['Int'];
    description?: Maybe<Scalars['String']>;
    discord?: Maybe<Scalars['String']>;
    dynamicData: GqlPoolDynamicData;
    endTime: Scalars['Int'];
    factory?: Maybe<Scalars['Bytes']>;
    farcaster?: Maybe<Scalars['String']>;
    hasAnyAllowedBuffer: Scalars['Boolean'];
    hasErc4626: Scalars['Boolean'];
    hook?: Maybe<GqlHook>;
    id: Scalars['ID'];
    isProjectTokenSwapInBlocked: Scalars['Boolean'];
    isSeedless: Scalars['Boolean'];
    lbpName?: Maybe<Scalars['String']>;
    lbpOwner: Scalars['String'];
    liquidityManagement?: Maybe<LiquidityManagement>;
    name: Scalars['String'];
    /** Account empowered to pause/unpause the pool (or 0 to delegate to governance) */
    pauseManager?: Maybe<Scalars['Bytes']>;
    /** Account empowered to set the pool creator fee percentage */
    poolCreator?: Maybe<Scalars['Bytes']>;
    poolTokens: Array<GqlPoolTokenDetail>;
    projectToken: Scalars['String'];
    projectTokenEndWeight: Scalars['Float'];
    projectTokenIndex: Scalars['Int'];
    projectTokenStartWeight: Scalars['Float'];
    protocolVersion: Scalars['Int'];
    reserveToken: Scalars['String'];
    reserveTokenEndWeight: Scalars['Float'];
    reserveTokenIndex: Scalars['Int'];
    reserveTokenStartWeight: Scalars['Float'];
    reserveTokenVirtualBalance: Scalars['Float'];
    /** All tokens of the pool. If it is a nested pool, the nested pool is expanded with its own tokens again. */
    staking?: Maybe<GqlPoolStaking>;
    startTime: Scalars['Int'];
    /** Account empowered to set static swap fees for a pool (when 0 on V2 swap fees are immutable, on V3 delegate to governance) */
    swapFeeManager?: Maybe<Scalars['Bytes']>;
    symbol: Scalars['String'];
    tags?: Maybe<Array<Maybe<Scalars['String']>>>;
    telegram?: Maybe<Scalars['String']>;
    topTrades?: Maybe<Array<GqlLbpTopTrade>>;
    type: GqlPoolType;
    userBalance?: Maybe<GqlPoolUserBalance>;
    version: Scalars['Int'];
    website?: Maybe<Scalars['String']>;
    x?: Maybe<Scalars['String']>;
};

/** The pool schema returned for poolGetPools (pool list query) */
export type GqlPoolMinimal = {
    __typename?: 'GqlPoolMinimal';
    /** The contract address of the pool. */
    address: Scalars['Bytes'];
    /** The chain on which the pool is deployed */
    chain: GqlChain;
    /** The timestamp the pool was created. */
    createTime: Scalars['Int'];
    /** The decimals of the BPT, usually 18 */
    decimals: Scalars['Int'];
    /** Dynamic data such as token balances, swap fees or volume */
    dynamicData: GqlPoolDynamicData;
    /** The factory contract address from which the pool was created. */
    factory?: Maybe<Scalars['Bytes']>;
    /** Whether at least one token in this pool is considered an ERC4626 token and the buffer is allowed. */
    hasAnyAllowedBuffer: Scalars['Boolean'];
    /** Whether at least one token in this pool is considered an ERC4626 token. */
    hasErc4626: Scalars['Boolean'];
    /** Hook assigned to a pool */
    hook?: Maybe<GqlHook>;
    /** The pool id. This is equal to the address for protocolVersion 3 pools */
    id: Scalars['ID'];
    /** Pool is receiving rewards when liquidity tokens are staked */
    incentivized: Scalars['Boolean'];
    /** LBP specific params for v3 pools only. */
    lbpParams?: Maybe<LiquidityBootstrappingPoolV3Params>;
    /** Liquidity management settings for v3 pools. */
    liquidityManagement?: Maybe<LiquidityManagement>;
    /** The name of the pool as per contract */
    name: Scalars['String'];
    /** Account empowered to pause/unpause the pool (or 0 to delegate to governance) */
    pauseManager?: Maybe<Scalars['Bytes']>;
    /** Account empowered to set the pool creator fee percentage */
    poolCreator?: Maybe<Scalars['Bytes']>;
    /** Returns all pool tokens, including BPTs and nested pools if there are any. Only one nested level deep. */
    poolTokens: Array<GqlPoolTokenDetail>;
    /** The protocol version on which the pool is deployed, 1, 2 or 3 */
    protocolVersion: Scalars['Int'];
    /** Staking options of this pool which emit additional rewards */
    staking?: Maybe<GqlPoolStaking>;
    /** Account empowered to set static swap fees for a pool (when 0 on V2 swap fees are immutable, on V3 delegate to governance) */
    swapFeeManager?: Maybe<Scalars['Bytes']>;
    /** The token symbol of the pool as per contract */
    symbol: Scalars['String'];
    /** List of tags assigned by the team based on external factors */
    tags?: Maybe<Array<Maybe<Scalars['String']>>>;
    /** The pool type, such as weighted, stable, etc. */
    type: GqlPoolType;
    /** If a user address was provided in the query, the user balance is populated here */
    userBalance?: Maybe<GqlPoolUserBalance>;
    /** The version of the pool type. */
    version: Scalars['Int'];
};

/** Result of the poolReloadPools mutation */
export type GqlPoolMutationResult = {
    __typename?: 'GqlPoolMutationResult';
    /** The chain that was reloaded. */
    chain: GqlChain;
    /** The error message */
    error?: Maybe<Scalars['String']>;
    /** Whether it was successful or not. */
    success: Scalars['Boolean'];
    /** The type of pools that were reloaded. */
    type: Scalars['String'];
};

export enum GqlPoolOrderBy {
    apr = 'apr',
    fees24h = 'fees24h',
    totalLiquidity = 'totalLiquidity',
    totalShares = 'totalShares',
    userbalanceUsd = 'userbalanceUsd',
    volume24h = 'volume24h',
}

export enum GqlPoolOrderDirection {
    asc = 'asc',
    desc = 'desc',
}

export type GqlPoolQuantAmmWeighted = GqlPoolBase & {
    __typename?: 'GqlPoolQuantAmmWeighted';
    address: Scalars['Bytes'];
    chain: GqlChain;
    createTime: Scalars['Int'];
    decimals: Scalars['Int'];
    dynamicData: GqlPoolDynamicData;
    factory?: Maybe<Scalars['Bytes']>;
    hasAnyAllowedBuffer: Scalars['Boolean'];
    hasErc4626: Scalars['Boolean'];
    hook?: Maybe<GqlHook>;
    id: Scalars['ID'];
    liquidityManagement?: Maybe<LiquidityManagement>;
    name: Scalars['String'];
    /** Account empowered to pause/unpause the pool (or 0 to delegate to governance) */
    pauseManager?: Maybe<Scalars['Bytes']>;
    /** Account empowered to set the pool creator fee percentage */
    poolCreator?: Maybe<Scalars['Bytes']>;
    poolTokens: Array<GqlPoolTokenDetail>;
    protocolVersion: Scalars['Int'];
    quantAmmWeightedParams?: Maybe<QuantAmmWeightedParams>;
    staking?: Maybe<GqlPoolStaking>;
    /** Account empowered to set static swap fees for a pool (when 0 on V2 swap fees are immutable, on V3 delegate to governance) */
    swapFeeManager?: Maybe<Scalars['Bytes']>;
    symbol: Scalars['String'];
    tags?: Maybe<Array<Maybe<Scalars['String']>>>;
    type: GqlPoolType;
    userBalance?: Maybe<GqlPoolUserBalance>;
    version: Scalars['Int'];
    weightSnapshots?: Maybe<Array<QuantAmmWeightSnapshot>>;
};

export type GqlPoolReClamm = GqlPoolBase & {
    __typename?: 'GqlPoolReClamm';
    address: Scalars['Bytes'];
    /** The centeredness margin of the pool */
    centerednessMargin: Scalars['BigDecimal'];
    chain: GqlChain;
    createTime: Scalars['Int'];
    /** The current fourth root price ratio, an interpolation of the price ratio state */
    currentFourthRootPriceRatio: Scalars['BigDecimal'];
    /** Represents how fast the pool can move the virtual balances per day */
    dailyPriceShiftBase: Scalars['BigDecimal'];
    decimals: Scalars['Int'];
    dynamicData: GqlPoolDynamicData;
    /** The fourth root price ratio at the end of an update */
    endFourthRootPriceRatio: Scalars['BigDecimal'];
    factory?: Maybe<Scalars['Bytes']>;
    hasAnyAllowedBuffer: Scalars['Boolean'];
    hasErc4626: Scalars['Boolean'];
    hook?: Maybe<GqlHook>;
    id: Scalars['ID'];
    /** The timestamp of the last user interaction */
    lastTimestamp: Scalars['Int'];
    /** The last virtual balances of the pool */
    lastVirtualBalances: Array<Scalars['BigDecimal']>;
    liquidityManagement?: Maybe<LiquidityManagement>;
    name: Scalars['String'];
    /** Account empowered to pause/unpause the pool (or 0 to delegate to governance) */
    pauseManager?: Maybe<Scalars['Bytes']>;
    /** Account empowered to set the pool creator fee percentage */
    poolCreator?: Maybe<Scalars['Bytes']>;
    poolTokens: Array<GqlPoolTokenDetail>;
    /** The timestamp when the update ends */
    priceRatioUpdateEndTime: Scalars['Int'];
    /** The timestamp when the update begins */
    priceRatioUpdateStartTime: Scalars['Int'];
    protocolVersion: Scalars['Int'];
    staking?: Maybe<GqlPoolStaking>;
    /** The fourth root price ratio at the start of an update */
    startFourthRootPriceRatio: Scalars['BigDecimal'];
    /** Account empowered to set static swap fees for a pool (when 0 on V2 swap fees are immutable, on V3 delegate to governance) */
    swapFeeManager?: Maybe<Scalars['Bytes']>;
    symbol: Scalars['String'];
    tags?: Maybe<Array<Maybe<Scalars['String']>>>;
    type: GqlPoolType;
    userBalance?: Maybe<GqlPoolUserBalance>;
    version: Scalars['Int'];
};

export type GqlPoolSnapshot = {
    __typename?: 'GqlPoolSnapshot';
    amounts: Array<Scalars['String']>;
    chain: GqlChain;
    fees24h: Scalars['String'];
    id: Scalars['ID'];
    poolId: Scalars['String'];
    sharePrice: Scalars['String'];
    swapsCount: Scalars['String'];
    timestamp: Scalars['Int'];
    totalLiquidity: Scalars['String'];
    totalShares: Scalars['String'];
    volume24h: Scalars['String'];
};

export enum GqlPoolSnapshotDataRange {
    ALL_TIME = 'ALL_TIME',
    NINETY_DAYS = 'NINETY_DAYS',
    ONE_HUNDRED_EIGHTY_DAYS = 'ONE_HUNDRED_EIGHTY_DAYS',
    ONE_YEAR = 'ONE_YEAR',
    THIRTY_DAYS = 'THIRTY_DAYS',
}

export type GqlPoolStable = GqlPoolBase & {
    __typename?: 'GqlPoolStable';
    address: Scalars['Bytes'];
    amp: Scalars['BigInt'];
    bptPriceRate: Scalars['BigDecimal'];
    chain: GqlChain;
    createTime: Scalars['Int'];
    decimals: Scalars['Int'];
    dynamicData: GqlPoolDynamicData;
    factory?: Maybe<Scalars['Bytes']>;
    hasAnyAllowedBuffer: Scalars['Boolean'];
    hasErc4626: Scalars['Boolean'];
    hook?: Maybe<GqlHook>;
    id: Scalars['ID'];
    liquidityManagement?: Maybe<LiquidityManagement>;
    name: Scalars['String'];
    /** Account empowered to pause/unpause the pool (or 0 to delegate to governance) */
    pauseManager?: Maybe<Scalars['Bytes']>;
    /** Account empowered to set the pool creator fee percentage */
    poolCreator?: Maybe<Scalars['Bytes']>;
    poolTokens: Array<GqlPoolTokenDetail>;
    protocolVersion: Scalars['Int'];
    staking?: Maybe<GqlPoolStaking>;
    /** Account empowered to set static swap fees for a pool (when 0 on V2 swap fees are immutable, on V3 delegate to governance) */
    swapFeeManager?: Maybe<Scalars['Bytes']>;
    symbol: Scalars['String'];
    tags?: Maybe<Array<Maybe<Scalars['String']>>>;
    type: GqlPoolType;
    userBalance?: Maybe<GqlPoolUserBalance>;
    version: Scalars['Int'];
};

export type GqlPoolStaking = {
    __typename?: 'GqlPoolStaking';
    address: Scalars['String'];
    chain: GqlChain;
    gauge?: Maybe<GqlPoolStakingGauge>;
    id: Scalars['ID'];
    reliquary?: Maybe<GqlPoolStakingReliquaryFarm>;
    type: GqlPoolStakingType;
};

export type GqlPoolStakingGauge = {
    __typename?: 'GqlPoolStakingGauge';
    gaugeAddress: Scalars['String'];
    id: Scalars['ID'];
    otherGauges?: Maybe<Array<GqlPoolStakingOtherGauge>>;
    rewards: Array<GqlPoolStakingGaugeReward>;
    status: GqlPoolStakingGaugeStatus;
    version: Scalars['Int'];
    workingSupply: Scalars['String'];
};

export type GqlPoolStakingGaugeReward = {
    __typename?: 'GqlPoolStakingGaugeReward';
    id: Scalars['ID'];
    rewardPerSecond: Scalars['String'];
    tokenAddress: Scalars['String'];
};

export enum GqlPoolStakingGaugeStatus {
    ACTIVE = 'ACTIVE',
    KILLED = 'KILLED',
    PREFERRED = 'PREFERRED',
}

export type GqlPoolStakingOtherGauge = {
    __typename?: 'GqlPoolStakingOtherGauge';
    gaugeAddress: Scalars['String'];
    id: Scalars['ID'];
    rewards: Array<GqlPoolStakingGaugeReward>;
    status: GqlPoolStakingGaugeStatus;
    version: Scalars['Int'];
};

export type GqlPoolStakingReliquaryFarm = {
    __typename?: 'GqlPoolStakingReliquaryFarm';
    beetsPerSecond: Scalars['String'];
    id: Scalars['ID'];
    levels?: Maybe<Array<GqlPoolStakingReliquaryFarmLevel>>;
    totalBalance: Scalars['String'];
    totalWeightedBalance: Scalars['String'];
};

export type GqlPoolStakingReliquaryFarmLevel = {
    __typename?: 'GqlPoolStakingReliquaryFarmLevel';
    allocationPoints: Scalars['Int'];
    apr: Scalars['BigDecimal'];
    balance: Scalars['BigDecimal'];
    id: Scalars['ID'];
    level: Scalars['Int'];
    requiredMaturity: Scalars['Int'];
};

export enum GqlPoolStakingType {
    GAUGE = 'GAUGE',
    RELIQUARY = 'RELIQUARY',
}

/** Represents an event that occurs when a swap is made in a pool using the CowAmm protocol. */
export type GqlPoolSwapEventCowAmm = GqlPoolEvent & {
    __typename?: 'GqlPoolSwapEventCowAmm';
    /** The block number of the event. */
    blockNumber: Scalars['Int'];
    /** The block timestamp of the event. */
    blockTimestamp: Scalars['Int'];
    /** The chain on which the event occurred. */
    chain: GqlChain;
    /** The fee that this swap generated. */
    fee: GqlPoolEventAmount;
    /** The unique identifier of the event. */
    id: Scalars['ID'];
    /** The log index of the event. */
    logIndex: Scalars['Int'];
    /** The pool ID associated with the event. */
    poolId: Scalars['String'];
    /** The sender of the event. */
    sender: Scalars['String'];
    /** The timestamp of the event. */
    timestamp: Scalars['Int'];
    /** The token that was swapped in the event. */
    tokenIn: GqlPoolEventAmount;
    /** The token that was swapped out in the event. */
    tokenOut: GqlPoolEventAmount;
    /** The transaction hash of the event. */
    tx: Scalars['String'];
    /** The type of the event. */
    type: GqlPoolEventType;
    /** The user address associated with the event. */
    userAddress: Scalars['String'];
    /** The value of the event in USD. */
    valueUSD: Scalars['Float'];
};

/** Represents an event that occurs when a swap is made in a pool. */
export type GqlPoolSwapEventV3 = GqlPoolEvent & {
    __typename?: 'GqlPoolSwapEventV3';
    /** The block number of the event. */
    blockNumber: Scalars['Int'];
    /** The block timestamp of the event. */
    blockTimestamp: Scalars['Int'];
    /** The chain on which the event occurred. */
    chain: GqlChain;
    /** The fee that this swap generated. */
    fee: GqlPoolEventAmount;
    /** The unique identifier of the event. */
    id: Scalars['ID'];
    /** The log index of the event. */
    logIndex: Scalars['Int'];
    /** The pool ID associated with the event. */
    poolId: Scalars['String'];
    /** The sender of the event. */
    sender: Scalars['String'];
    /** The timestamp of the event. */
    timestamp: Scalars['Int'];
    /** The token that was swapped in the event. */
    tokenIn: GqlPoolEventAmount;
    /** The token that was swapped out in the event. */
    tokenOut: GqlPoolEventAmount;
    /** The transaction hash of the event. */
    tx: Scalars['String'];
    /** The type of the event. */
    type: GqlPoolEventType;
    /** The user address associated with the event. */
    userAddress: Scalars['String'];
    /** The value of the event in USD. */
    valueUSD: Scalars['Float'];
};

export type GqlPoolTimePeriod = {
    gt?: InputMaybe<Scalars['Int']>;
    lt?: InputMaybe<Scalars['Int']>;
};

/** All info on the pool token. */
export type GqlPoolTokenDetail = {
    __typename?: 'GqlPoolTokenDetail';
    /** Address of the pool token. */
    address: Scalars['String'];
    /** Balance of the pool token inside the pool. */
    balance: Scalars['BigDecimal'];
    /** USD Balance of the pool token. */
    balanceUSD: Scalars['BigDecimal'];
    /** If it is an ERC4626 token, this defines whether we can use wrap/unwrap through the buffer in swap paths for this token. */
    canUseBufferForSwaps?: Maybe<Scalars['Boolean']>;
    chain?: Maybe<GqlChain>;
    chainId?: Maybe<Scalars['Int']>;
    /** Coingecko ID */
    coingeckoId?: Maybe<Scalars['String']>;
    /** Decimals of the pool token. */
    decimals: Scalars['Int'];
    /** The ERC4626 review data for the token */
    erc4626ReviewData?: Maybe<Erc4626ReviewData>;
    /** Id of the token. A combination of pool id and token address. */
    id: Scalars['ID'];
    /** Index of the pool token in the pool as returned by the vault. */
    index: Scalars['Int'];
    /** Whether the token is in the allow list. */
    isAllowed: Scalars['Boolean'];
    /** Whether the token is considered an ERC4626 token. */
    isErc4626: Scalars['Boolean'];
    /** Whether the token is exempted from taking a protocol yield fee. */
    isExemptFromProtocolYieldFee: Scalars['Boolean'];
    /** Token logo */
    logoURI?: Maybe<Scalars['String']>;
    /** If it is an ERC4626 token, this  defines how much can be deposited into the ERC4626 vault. */
    maxDeposit?: Maybe<Scalars['String']>;
    /** If it is an ERC4626 token, this  defines how much can be withdrawn from the ERC4626 vault. */
    maxWithdraw?: Maybe<Scalars['String']>;
    /** Name of the pool token. */
    name: Scalars['String'];
    /** If it is an appreciating token, it shows the current price rate. 1 otherwise. */
    priceRate: Scalars['BigDecimal'];
    /** The address of the price rate provider. */
    priceRateProvider?: Maybe<Scalars['String']>;
    /** Additional data for the price rate provider, such as reviews or warnings. */
    priceRateProviderData?: Maybe<GqlPriceRateProviderData>;
    /** Conversion factor used to adjust for token decimals for uniform precision in calculations. V3 only. */
    scalingFactor?: Maybe<Scalars['BigDecimal']>;
    /** Symbol of the pool token. */
    symbol: Scalars['String'];
    /** If it is an ERC4626, this will be the underlying token if present in the API. */
    underlyingToken?: Maybe<GqlToken>;
    /** If it is an ERC4626 token, this defines whether we allow underlying tokens to be used for add/remove operations. */
    useUnderlyingForAddRemove?: Maybe<Scalars['Boolean']>;
    /** If it is an ERC4626 token, this defines whether we allow the wrapped tokens to be used for add/remove operations. */
    useWrappedForAddRemove?: Maybe<Scalars['Boolean']>;
    /** The weight of the token in the pool if it is a weighted pool, null otherwise */
    weight?: Maybe<Scalars['BigDecimal']>;
};

/** Supported pool types */
export enum GqlPoolType {
    COMPOSABLE_STABLE = 'COMPOSABLE_STABLE',
    FIXED_LBP = 'FIXED_LBP',
    GYRO = 'GYRO',
    GYRO3 = 'GYRO3',
    GYROE = 'GYROE',
    LIQUIDITY_BOOTSTRAPPING = 'LIQUIDITY_BOOTSTRAPPING',
    QUANT_AMM_WEIGHTED = 'QUANT_AMM_WEIGHTED',
    RECLAMM = 'RECLAMM',
    STABLE = 'STABLE',
    UNKNOWN = 'UNKNOWN',
    WEIGHTED = 'WEIGHTED',
}

export type GqlPoolUnion =
    | GqlPoolComposableStable
    | GqlPoolFixedPriceLbp
    | GqlPoolGyro
    | GqlPoolLiquidityBootstrapping
    | GqlPoolLiquidityBootstrappingV3
    | GqlPoolQuantAmmWeighted
    | GqlPoolReClamm
    | GqlPoolStable
    | GqlPoolWeighted;

/** If a user address was provided in the query, the user balance is populated here */
export type GqlPoolUserBalance = {
    __typename?: 'GqlPoolUserBalance';
    /** The staked BPT balances of the user. */
    stakedBalances: Array<GqlUserStakedBalance>;
    /** Total balance (wallet + staked) as float */
    totalBalance: Scalars['AmountHumanReadable'];
    /** Total balance (wallet + staked) in USD as float */
    totalBalanceUsd: Scalars['Float'];
    /** The wallet balance (BPT in wallet) as float. */
    walletBalance: Scalars['AmountHumanReadable'];
    /** The wallet balance (BPT in wallet) in USD as float. */
    walletBalanceUsd: Scalars['Float'];
};

export type GqlPoolWeighted = GqlPoolBase & {
    __typename?: 'GqlPoolWeighted';
    address: Scalars['Bytes'];
    chain: GqlChain;
    createTime: Scalars['Int'];
    decimals: Scalars['Int'];
    dynamicData: GqlPoolDynamicData;
    factory?: Maybe<Scalars['Bytes']>;
    hasAnyAllowedBuffer: Scalars['Boolean'];
    hasErc4626: Scalars['Boolean'];
    hook?: Maybe<GqlHook>;
    id: Scalars['ID'];
    liquidityManagement?: Maybe<LiquidityManagement>;
    name: Scalars['String'];
    /** Account empowered to pause/unpause the pool (or 0 to delegate to governance) */
    pauseManager?: Maybe<Scalars['Bytes']>;
    /** Account empowered to set the pool creator fee percentage */
    poolCreator?: Maybe<Scalars['Bytes']>;
    poolTokens: Array<GqlPoolTokenDetail>;
    protocolVersion: Scalars['Int'];
    staking?: Maybe<GqlPoolStaking>;
    /** Account empowered to set static swap fees for a pool (when 0 on V2 swap fees are immutable, on V3 delegate to governance) */
    swapFeeManager?: Maybe<Scalars['Bytes']>;
    symbol: Scalars['String'];
    tags?: Maybe<Array<Maybe<Scalars['String']>>>;
    type: GqlPoolType;
    userBalance?: Maybe<GqlPoolUserBalance>;
    version: Scalars['Int'];
};

/** Returns the price impact of the path. If there is an error in the price impact calculation, priceImpact will be undefined but the error string is populated. */
export type GqlPriceImpact = {
    __typename?: 'GqlPriceImpact';
    /** If priceImpact cant be calculated and is returned as undefined, the error string will be populated. */
    error?: Maybe<Scalars['String']>;
    /** Price impact in percent 0.01 -> 0.01%; undefined if an error happened. */
    priceImpact?: Maybe<Scalars['AmountHumanReadable']>;
};

/** Represents the data of a price rate provider */
export type GqlPriceRateProviderData = {
    __typename?: 'GqlPriceRateProviderData';
    /** The address of the price rate provider */
    address: Scalars['String'];
    /** The factory used to create the price rate provider, if applicable */
    factory?: Maybe<Scalars['String']>;
    /** The name of the price rate provider */
    name?: Maybe<Scalars['String']>;
    /** The filename of the review of the price rate provider */
    reviewFile?: Maybe<Scalars['String']>;
    /** Indicates if the price rate provider has been reviewed */
    reviewed: Scalars['Boolean'];
    /** A summary of the price rate provider, usually just says safe or unsafe */
    summary?: Maybe<Scalars['String']>;
    /** Upgradeable components of the price rate provider */
    upgradeableComponents?: Maybe<Array<Maybe<GqlPriceRateProviderUpgradeableComponent>>>;
    /** Warnings associated with the price rate provider */
    warnings?: Maybe<Array<Scalars['String']>>;
};

/** Represents an upgradeable component of a price rate provider */
export type GqlPriceRateProviderUpgradeableComponent = {
    __typename?: 'GqlPriceRateProviderUpgradeableComponent';
    /** The entry point / proxy of the upgradeable component */
    entryPoint: Scalars['String'];
    /** Indicates if the implementation of the component has been reviewed */
    implementationReviewed: Scalars['String'];
};

export type GqlProtocolMetricsAggregated = {
    __typename?: 'GqlProtocolMetricsAggregated';
    chains: Array<GqlProtocolMetricsChain>;
    numLiquidityProviders: Scalars['BigInt'];
    poolCount: Scalars['BigInt'];
    swapFee24h: Scalars['BigDecimal'];
    swapVolume24h: Scalars['BigDecimal'];
    totalLiquidity: Scalars['BigDecimal'];
    yieldCapture24h: Scalars['BigDecimal'];
};

export type GqlProtocolMetricsChain = {
    __typename?: 'GqlProtocolMetricsChain';
    chainId: Scalars['String'];
    numLiquidityProviders: Scalars['BigInt'];
    poolCount: Scalars['BigInt'];
    swapFee24h: Scalars['BigDecimal'];
    swapVolume24h: Scalars['BigDecimal'];
    totalLiquidity: Scalars['BigDecimal'];
    yieldCapture24h: Scalars['BigDecimal'];
};

export type GqlReliquaryFarmSnapshot = {
    __typename?: 'GqlReliquaryFarmSnapshot';
    farmId: Scalars['String'];
    id: Scalars['ID'];
    relicCount: Scalars['String'];
    timestamp: Scalars['Int'];
    totalBalance: Scalars['String'];
    totalLiquidity: Scalars['String'];
    userCount: Scalars['String'];
};

/** The swap paths for a swap */
export type GqlSorGetSwapPaths = {
    __typename?: 'GqlSorGetSwapPaths';
    /** The price of tokenOut in tokenIn. */
    effectivePrice: Scalars['AmountHumanReadable'];
    /** The price of tokenIn in tokenOut. */
    effectivePriceReversed: Scalars['AmountHumanReadable'];
    /** The found paths as needed as input for the b-sdk to execute the swap */
    paths: Array<GqlSorPath>;
    /** Price impact of the path */
    priceImpact: GqlPriceImpact;
    /** The version of the protocol these paths are from */
    protocolVersion: Scalars['Int'];
    /** The return amount in human form. Return amount is either tokenOutAmount (if swapType is exactIn) or tokenInAmount (if swapType is exactOut) */
    returnAmount: Scalars['AmountHumanReadable'];
    /** The return amount in a raw form */
    returnAmountRaw: Scalars['BigDecimal'];
    /** The swap routes including pool information. Used to display by the UI */
    routes: Array<GqlSorSwapRoute>;
    /** The swap amount in human form. Swap amount is either tokenInAmount (if swapType is exactIn) or tokenOutAmount (if swapType is exactOut) */
    swapAmount: Scalars['AmountHumanReadable'];
    /** The swap amount in a raw form */
    swapAmountRaw: Scalars['BigDecimal'];
    /** The swapType that was provided, exact_in vs exact_out (givenIn vs givenOut) */
    swapType: GqlSorSwapType;
    /** Swaps as needed for the vault swap input to execute the swap */
    swaps: Array<GqlSorSwap>;
    /** All token addresses (or assets) as needed for the vault swap input to execute the swap */
    tokenAddresses: Array<Scalars['String']>;
    /** The token address of the tokenIn provided */
    tokenIn: Scalars['String'];
    /** The amount of tokenIn in human form */
    tokenInAmount: Scalars['AmountHumanReadable'];
    /** The token address of the tokenOut provided */
    tokenOut: Scalars['String'];
    /** The amount of tokenOut in human form */
    tokenOutAmount: Scalars['AmountHumanReadable'];
};

/** A path of a swap. A swap can have multiple paths. Used as input to execute the swap via b-sdk */
export type GqlSorPath = {
    __typename?: 'GqlSorPath';
    /** Input amount of this path in scaled form */
    inputAmountRaw: Scalars['String'];
    /** A sorted list of booleans that indicate if the respective pool is a buffer */
    isBuffer: Array<Scalars['Boolean']>;
    /** Output amount of this path in scaled form */
    outputAmountRaw: Scalars['String'];
    /** A sorted list of pool ids that are used in this path */
    pools: Array<Scalars['String']>;
    /** The version of the protocol these paths are from */
    protocolVersion: Scalars['Int'];
    /** A sorted list of tokens that are ussed in this path */
    tokens: Array<Token>;
};

/** A single swap step as used for input to the vault to execute a swap */
export type GqlSorSwap = {
    __typename?: 'GqlSorSwap';
    /** Amount to be swapped in this step. 0 for chained swap. */
    amount: Scalars['String'];
    /** Index of the asset used in the tokenAddress array. */
    assetInIndex: Scalars['Int'];
    /** Index of the asset used in the tokenAddress array. */
    assetOutIndex: Scalars['Int'];
    /** Pool id used in this swap step */
    poolId: Scalars['String'];
    /** UserData used in this swap, generally uses defaults. */
    userData: Scalars['String'];
};

/** The swap routes including pool information. Used to display by the UI */
export type GqlSorSwapRoute = {
    __typename?: 'GqlSorSwapRoute';
    /** The hops this route takes */
    hops: Array<GqlSorSwapRouteHop>;
    /** Share of this route of the total swap */
    share: Scalars['Float'];
    /** Address of the tokenIn */
    tokenIn: Scalars['String'];
    /** Amount of the tokenIn in human form */
    tokenInAmount: Scalars['AmountHumanReadable'];
    /** Address of the tokenOut */
    tokenOut: Scalars['String'];
    /** Amount of the tokenOut in human form */
    tokenOutAmount: Scalars['AmountHumanReadable'];
};

/** A hop of a route. A route can have many hops meaning it traverses more than one pool. */
export type GqlSorSwapRouteHop = {
    __typename?: 'GqlSorSwapRouteHop';
    /** The pool id of this hop. */
    poolId: Scalars['String'];
    /** Address of the tokenIn */
    tokenIn: Scalars['String'];
    /** Amount of the tokenIn in human form */
    tokenInAmount: Scalars['AmountHumanReadable'];
    /** Address of the tokenOut */
    tokenOut: Scalars['String'];
    /** Amount of the tokenOut in human form */
    tokenOutAmount: Scalars['AmountHumanReadable'];
};

export enum GqlSorSwapType {
    EXACT_IN = 'EXACT_IN',
    EXACT_OUT = 'EXACT_OUT',
}

export type GqlStakedSonicData = {
    __typename?: 'GqlStakedSonicData';
    /** A list of all the delegated validators. */
    delegatedValidators: Array<GqlStakedSonicDelegatedValidator>;
    /** Current exchange rate for stS -> S */
    exchangeRate: Scalars['String'];
    /** The total protocol fee collected in the last 24 hours. */
    protocolFee24h: Scalars['String'];
    /** The total rewards claimed in the last 24 hours. */
    rewardsClaimed24h: Scalars['String'];
    /** The current rebasing APR for stS. */
    stakingApr: Scalars['String'];
    /** Total amount of S in custody of stS. Delegated S plus pool S. */
    totalAssets: Scalars['AmountHumanReadable'];
    /** Total amount of S elegated to validators. */
    totalAssetsDelegated: Scalars['AmountHumanReadable'];
    /** Total amount of S in the pool to be delegated. */
    totalAssetsPool: Scalars['AmountHumanReadable'];
};

export type GqlStakedSonicDelegatedValidator = {
    __typename?: 'GqlStakedSonicDelegatedValidator';
    /** The amount of S that has been delegated to this validator. */
    assetsDelegated: Scalars['AmountHumanReadable'];
    /** The id of the validator. */
    validatorId: Scalars['String'];
};

/** Represents a token in the system */
export type GqlToken = {
    __typename?: 'GqlToken';
    /** The address of the token */
    address: Scalars['String'];
    /** The chain of the token */
    chain: GqlChain;
    /** The chain ID of the token */
    chainId: Scalars['Int'];
    /** The coingecko ID for this token, if present */
    coingeckoId?: Maybe<Scalars['String']>;
    /** The number of decimal places for the token */
    decimals: Scalars['Int'];
    /** The description of the token */
    description?: Maybe<Scalars['String']>;
    /** The Discord URL of the token */
    discordUrl?: Maybe<Scalars['String']>;
    /** The ERC4626 review data for the token */
    erc4626ReviewData?: Maybe<Erc4626ReviewData>;
    /** If it is an ERC4626 token, this defines whether we allow it to use the buffer for pool operations. */
    isBufferAllowed: Scalars['Boolean'];
    /** Whether the token is considered an ERC4626 token. */
    isErc4626: Scalars['Boolean'];
    /** The logo URI of the token */
    logoURI?: Maybe<Scalars['String']>;
    /** If it is an ERC4626 token, this  defines how much can be deposited into the ERC4626 vault. */
    maxDeposit?: Maybe<Scalars['String']>;
    /** The name of the token */
    name: Scalars['String'];
    /** The rate provider data for the token */
    priceRateProviderData?: Maybe<GqlPriceRateProviderData>;
    /** The priority of the token, can be used for sorting. */
    priority: Scalars['Int'];
    /** The symbol of the token */
    symbol: Scalars['String'];
    /** The Telegram URL of the token */
    telegramUrl?: Maybe<Scalars['String']>;
    /** Indicates if the token is tradable */
    tradable: Scalars['Boolean'];
    /** The Twitter username of the token */
    twitterUsername?: Maybe<Scalars['String']>;
    types?: Maybe<Array<GqlTokenType>>;
    /** The ERC4626 underlying token address, if applicable. */
    underlyingTokenAddress?: Maybe<Scalars['String']>;
    /** The website URL of the token */
    websiteUrl?: Maybe<Scalars['String']>;
};

export type GqlTokenAmountHumanReadable = {
    address: Scalars['String'];
    amount: Scalars['AmountHumanReadable'];
};

/** Provide filters for tokens */
export type GqlTokenFilter = {
    /** Only return tokens with these addresses */
    tokensIn?: InputMaybe<Array<Scalars['String']>>;
    /** Filter by token type */
    typeIn?: InputMaybe<Array<GqlTokenType>>;
};

/** Result of the poolReloadPools mutation */
export type GqlTokenMutationResult = {
    __typename?: 'GqlTokenMutationResult';
    /** The chain that was reloaded. */
    chain: GqlChain;
    /** The error message */
    error?: Maybe<Scalars['String']>;
    /** Whether it was successful or not. */
    success: Scalars['Boolean'];
};

export type GqlTokenPrice = {
    __typename?: 'GqlTokenPrice';
    address: Scalars['String'];
    chain: GqlChain;
    price: Scalars['Float'];
    updatedAt: Scalars['Int'];
    updatedBy?: Maybe<Scalars['String']>;
};

export enum GqlTokenType {
    BLOCKED_V2 = 'BLOCKED_V2',
    BLOCKED_V3 = 'BLOCKED_V3',
    BPT = 'BPT',
    ERC4626 = 'ERC4626',
    PHANTOM_BPT = 'PHANTOM_BPT',
}

export type GqlUserStakedBalance = {
    __typename?: 'GqlUserStakedBalance';
    /** The staked BPT balance as float. */
    balance: Scalars['AmountHumanReadable'];
    /** The steaked BPT balance in USD as float. */
    balanceUsd: Scalars['Float'];
    /** The id of the staking to match with GqlPoolStaking.id. */
    stakingId: Scalars['String'];
    /** The staking type (Gauge, farm, aura, etc.) in which this balance is staked. */
    stakingType: GqlPoolStakingType;
};

export type HookConfig = {
    __typename?: 'HookConfig';
    /** True when hook can change the amounts send to the vault. Necessary to deduct the fees. */
    enableHookAdjustedAmounts: Scalars['Boolean'];
    shouldCallAfterAddLiquidity: Scalars['Boolean'];
    shouldCallAfterInitialize: Scalars['Boolean'];
    shouldCallAfterRemoveLiquidity: Scalars['Boolean'];
    shouldCallAfterSwap: Scalars['Boolean'];
    shouldCallBeforeAddLiquidity: Scalars['Boolean'];
    shouldCallBeforeInitialize: Scalars['Boolean'];
    shouldCallBeforeRemoveLiquidity: Scalars['Boolean'];
    shouldCallBeforeSwap: Scalars['Boolean'];
    shouldCallComputeDynamicSwapFee: Scalars['Boolean'];
};

export type HookParams = ExitFeeHookParams | FeeTakingHookParams | MevTaxHookParams | StableSurgeHookParams;

export type LbpMetadataInput = {
    description: Scalars['String'];
    discord?: InputMaybe<Scalars['String']>;
    farcaster?: InputMaybe<Scalars['String']>;
    lbpName: Scalars['String'];
    telegram?: InputMaybe<Scalars['String']>;
    tokenLogo: Scalars['String'];
    website: Scalars['String'];
    x?: InputMaybe<Scalars['String']>;
};

export type LbpPriceChartData = {
    __typename?: 'LBPPriceChartData';
    buyVolume: Scalars['Float'];
    cumulativeFees: Scalars['Float'];
    cumulativeVolume: Scalars['Float'];
    fees: Scalars['Float'];
    projectTokenBalance: Scalars['Float'];
    projectTokenPrice: Scalars['Float'];
    reservePrice: Scalars['Float'];
    reserveTokenBalance: Scalars['Float'];
    sellVolume: Scalars['Float'];
    swapCount: Scalars['Int'];
    timestamp: Scalars['Int'];
    tvl: Scalars['Float'];
    volume: Scalars['Float'];
};

export type LbPoolInput = {
    address: Scalars['String'];
    chain: GqlChain;
};

/** LBP specific params for v3 pools only. */
export type LiquidityBootstrappingPoolV3Params = {
    __typename?: 'LiquidityBootstrappingPoolV3Params';
    endTime: Scalars['Int'];
    startTime: Scalars['Int'];
};

/** Liquidity management settings for v3 pools. */
export type LiquidityManagement = {
    __typename?: 'LiquidityManagement';
    /** Indicates whether this pool has disabled add and removes of unbalanced/non-proportional liquidity. Meaning it will only support proportional add and remove liquidity. */
    disableUnbalancedLiquidity?: Maybe<Scalars['Boolean']>;
    /** Whether this pool support additional, custom add liquditiy operations apart from proportional, unbalanced and single asset. */
    enableAddLiquidityCustom?: Maybe<Scalars['Boolean']>;
    /** Indicates whether donation is enabled. Meaning you can send funds to the pool without receiving a BPT. */
    enableDonation?: Maybe<Scalars['Boolean']>;
    /** Whether this pool support additional, custom remove liquditiy operations apart from proportional, unbalanced and single asset. */
    enableRemoveLiquidityCustom?: Maybe<Scalars['Boolean']>;
};

/** MevTax hook specific params. Percentage format is 0.01 -> 0.01%. */
export type MevTaxHookParams = {
    __typename?: 'MevTaxHookParams';
    maxMevSwapFeePercentage?: Maybe<Scalars['String']>;
    mevTaxMultiplier?: Maybe<Scalars['String']>;
    mevTaxThreshold?: Maybe<Scalars['String']>;
};

export type Mutation = {
    __typename?: 'Mutation';
    createLBP: Scalars['Boolean'];
    lbpReloadFixedLbps: Scalars['String'];
    lbpReloadLbps: Scalars['String'];
    poolLoadOnChainDataForAllPools: Array<GqlPoolMutationResult>;
    poolLoadSnapshotsForPools: Scalars['String'];
    poolReloadAllPoolAprs: Scalars['String'];
    poolReloadPools: Array<GqlPoolMutationResult>;
    poolReloadStakingForAllPools: Scalars['String'];
    poolReloadSwaps: Scalars['String'];
    poolSyncAllPoolsFromSubgraph: Array<Scalars['String']>;
    protocolCacheMetrics: Scalars['String'];
    tokenDeleteTokenType: Scalars['String'];
    tokenReloadAllTokenTypes: Scalars['String'];
    tokenReloadErc4626Tokens: Array<GqlTokenMutationResult>;
    tokenReloadTokenPrices?: Maybe<Scalars['Boolean']>;
    tokenSyncTokenDefinitions: Scalars['String'];
    userInitStakedBalances: Scalars['String'];
    userInitWalletBalancesForAllPools: Scalars['String'];
    userSyncChangedStakedBalances: Scalars['String'];
    userSyncChangedWalletBalancesForAllPools: Scalars['String'];
};

export type MutationCreateLbpArgs = {
    input: CreateLbpInput;
    type?: InputMaybe<GqlPoolType>;
};

export type MutationLbpReloadFixedLbpsArgs = {
    chains: Array<GqlChain>;
};

export type MutationLbpReloadLbpsArgs = {
    chains: Array<GqlChain>;
};

export type MutationPoolLoadOnChainDataForAllPoolsArgs = {
    chains: Array<GqlChain>;
};

export type MutationPoolLoadSnapshotsForPoolsArgs = {
    chain: GqlChain;
    poolId: Scalars['String'];
};

export type MutationPoolReloadAllPoolAprsArgs = {
    chain: GqlChain;
};

export type MutationPoolReloadPoolsArgs = {
    chains: Array<GqlChain>;
};

export type MutationPoolReloadStakingForAllPoolsArgs = {
    chain: GqlChain;
    stakingTypes: Array<GqlPoolStakingType>;
};

export type MutationPoolReloadSwapsArgs = {
    chain: GqlChain;
    poolId: Scalars['String'];
};

export type MutationPoolSyncAllPoolsFromSubgraphArgs = {
    chain: GqlChain;
};

export type MutationProtocolCacheMetricsArgs = {
    chain: GqlChain;
};

export type MutationTokenDeleteTokenTypeArgs = {
    chain: GqlChain;
    tokenAddress: Scalars['String'];
    type: GqlTokenType;
};

export type MutationTokenReloadAllTokenTypesArgs = {
    chain: GqlChain;
};

export type MutationTokenReloadErc4626TokensArgs = {
    chains: Array<GqlChain>;
};

export type MutationTokenReloadTokenPricesArgs = {
    chains: Array<GqlChain>;
};

export type MutationUserInitStakedBalancesArgs = {
    chain: GqlChain;
    stakingTypes: Array<GqlPoolStakingType>;
};

export type MutationUserInitWalletBalancesForAllPoolsArgs = {
    chain: GqlChain;
};

export type MutationUserSyncChangedStakedBalancesArgs = {
    chain: GqlChain;
};

export type MutationUserSyncChangedWalletBalancesForAllPoolsArgs = {
    chain: GqlChain;
};

export type QuantAmmWeightedDetail = {
    __typename?: 'QuantAMMWeightedDetail';
    category: Scalars['String'];
    name: Scalars['String'];
    type: Scalars['String'];
    value: Scalars['String'];
};

export type QuantAmmWeightSnapshot = {
    __typename?: 'QuantAmmWeightSnapshot';
    timestamp: Scalars['Int'];
    weights?: Maybe<Array<Scalars['Float']>>;
};

export type QuantAmmWeightedParams = {
    __typename?: 'QuantAmmWeightedParams';
    absoluteWeightGuardRail: Scalars['String'];
    details: Array<QuantAmmWeightedDetail>;
    epsilonMax: Scalars['String'];
    lambda: Array<Scalars['String']>;
    lastInterpolationTimePossible: Scalars['String'];
    lastUpdateIntervalTime: Scalars['String'];
    maxTradeSizeRatio: Scalars['String'];
    oracleStalenessThreshold: Scalars['String'];
    poolRegistry: Scalars['String'];
    updateInterval: Scalars['String'];
    weightBlockMultipliers: Array<Scalars['String']>;
    weightsAtLastUpdateInterval: Array<Scalars['String']>;
};

export type Query = {
    __typename?: 'Query';
    /** Returns all pools for a given filter, specific for aggregators */
    aggregatorPools: Array<GqlPoolAggregator>;
    beetsPoolGetReliquaryFarmSnapshots: Array<GqlReliquaryFarmSnapshot>;
    fixedLbpPriceChart?: Maybe<Array<LbpPriceChartData>>;
    lbpPriceChart?: Maybe<Array<LbpPriceChartData>>;
    /** Get the LoopS data */
    loopsGetData: GqlLoopsData;
    /** Getting swap, add and remove events with paging */
    poolEvents: Array<GqlPoolEvent>;
    /** Returns the list of featured pools for chains */
    poolGetFeaturedPools: Array<GqlPoolFeaturedPool>;
    /** Returns one pool. If a user address is provided, the user balances for the given pool will also be returned. */
    poolGetPool: GqlPoolBase;
    /** Returns all pools for a given filter */
    poolGetPools: Array<GqlPoolMinimal>;
    /** Returns the number of pools for a given filter. */
    poolGetPoolsCount: Scalars['Int'];
    /** Gets all the snapshots for a given pool on a chain for a certain range */
    poolGetSnapshots: Array<GqlPoolSnapshot>;
    protocolMetricsAggregated: GqlProtocolMetricsAggregated;
    protocolMetricsChain: GqlProtocolMetricsChain;
    /** Get swap quote from the SOR v2 */
    sorGetSwapPaths: GqlSorGetSwapPaths;
    /** Get the staking data and status for stS */
    stsGetGqlStakedSonicData: GqlStakedSonicData;
    /** Returns all current prices for allowed tokens for a given chain or chains */
    tokenGetCurrentPrices: Array<GqlTokenPrice>;
    /** Returns all allowed tokens for a given chain or chains */
    tokenGetTokens: Array<GqlToken>;
};

export type QueryAggregatorPoolsArgs = {
    first?: InputMaybe<Scalars['Int']>;
    orderBy?: InputMaybe<GqlPoolOrderBy>;
    orderDirection?: InputMaybe<GqlPoolOrderDirection>;
    skip?: InputMaybe<Scalars['Int']>;
    where?: InputMaybe<GqlAggregatorPoolFilter>;
};

export type QueryBeetsPoolGetReliquaryFarmSnapshotsArgs = {
    chain: GqlChain;
    id: Scalars['String'];
    range: GqlPoolSnapshotDataRange;
};

export type QueryFixedLbpPriceChartArgs = {
    chain: GqlChain;
    dataPoints?: InputMaybe<Scalars['Int']>;
    id: Scalars['String'];
};

export type QueryLbpPriceChartArgs = {
    chain: GqlChain;
    dataPoints?: InputMaybe<Scalars['Int']>;
    id: Scalars['String'];
};

export type QueryPoolEventsArgs = {
    first?: InputMaybe<Scalars['Int']>;
    skip?: InputMaybe<Scalars['Int']>;
    where?: InputMaybe<GqlPoolEventsFilter>;
};

export type QueryPoolGetFeaturedPoolsArgs = {
    chains: Array<GqlChain>;
};

export type QueryPoolGetPoolArgs = {
    chain: GqlChain;
    id: Scalars['String'];
    userAddress?: InputMaybe<Scalars['String']>;
};

export type QueryPoolGetPoolsArgs = {
    first?: InputMaybe<Scalars['Int']>;
    orderBy?: InputMaybe<GqlPoolOrderBy>;
    orderDirection?: InputMaybe<GqlPoolOrderDirection>;
    skip?: InputMaybe<Scalars['Int']>;
    textSearch?: InputMaybe<Scalars['String']>;
    where?: InputMaybe<GqlPoolFilter>;
};

export type QueryPoolGetPoolsCountArgs = {
    first?: InputMaybe<Scalars['Int']>;
    orderBy?: InputMaybe<GqlPoolOrderBy>;
    orderDirection?: InputMaybe<GqlPoolOrderDirection>;
    skip?: InputMaybe<Scalars['Int']>;
    textSearch?: InputMaybe<Scalars['String']>;
    where?: InputMaybe<GqlPoolFilter>;
};

export type QueryPoolGetSnapshotsArgs = {
    chain: GqlChain;
    id: Scalars['String'];
    range: GqlPoolSnapshotDataRange;
};

export type QueryProtocolMetricsAggregatedArgs = {
    chains: Array<GqlChain>;
};

export type QueryProtocolMetricsChainArgs = {
    chain: GqlChain;
};

export type QuerySorGetSwapPathsArgs = {
    chain: GqlChain;
    considerPoolsWithHooks?: InputMaybe<Scalars['Boolean']>;
    poolIds?: InputMaybe<Array<Scalars['String']>>;
    swapAmount: Scalars['AmountHumanReadable'];
    swapType: GqlSorSwapType;
    tokenIn: Scalars['String'];
    tokenOut: Scalars['String'];
    useProtocolVersion?: InputMaybe<Scalars['Int']>;
};

export type QueryTokenGetCurrentPricesArgs = {
    chains: Array<GqlChain>;
};

export type QueryTokenGetTokensArgs = {
    chains: Array<GqlChain>;
    where?: InputMaybe<GqlTokenFilter>;
};

/** StableSurge hook specific params. Percentage format is 0.01 -> 0.01%. */
export type StableSurgeHookParams = {
    __typename?: 'StableSurgeHookParams';
    maxSurgeFeePercentage?: Maybe<Scalars['String']>;
    surgeThresholdPercentage?: Maybe<Scalars['String']>;
};

export type Token = {
    __typename?: 'Token';
    address: Scalars['String'];
    decimals: Scalars['Int'];
};
