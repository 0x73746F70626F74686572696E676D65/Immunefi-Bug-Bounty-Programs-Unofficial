import {
    CreateLbpInput,
    Erc4626ReviewData,
    ExitFeeHookParams,
    FeeTakingHookParams,
    GqlAggregatorPoolFilter,
    GqlHook,
    GqlHookReviewData,
    GqlLbpTopTrade,
    GqlLoopsData,
    GqlPoolAddRemoveEventV3,
    GqlPoolAggregator,
    GqlPoolAprItem,
    GqlPoolBase,
    GqlPoolComposableStable,
    GqlPoolDynamicData,
    GqlPoolEvent,
    GqlPoolEventAmount,
    GqlPoolEventsFilter,
    GqlPoolFeaturedPool,
    GqlPoolFilter,
    GqlPoolFixedPriceLbp,
    GqlPoolGyro,
    GqlPoolLiquidityBootstrapping,
    GqlPoolLiquidityBootstrappingV3,
    GqlPoolMinimal,
    GqlPoolMutationResult,
    GqlPoolQuantAmmWeighted,
    GqlPoolReClamm,
    GqlPoolSnapshot,
    GqlPoolStable,
    GqlPoolStaking,
    GqlPoolStakingGauge,
    GqlPoolStakingGaugeReward,
    GqlPoolStakingOtherGauge,
    GqlPoolStakingReliquaryFarm,
    GqlPoolStakingReliquaryFarmLevel,
    GqlPoolSwapEventCowAmm,
    GqlPoolSwapEventV3,
    GqlPoolTimePeriod,
    GqlPoolTokenDetail,
    GqlPoolUserBalance,
    GqlPoolWeighted,
    GqlPriceImpact,
    GqlPriceRateProviderData,
    GqlPriceRateProviderUpgradeableComponent,
    GqlProtocolMetricsAggregated,
    GqlProtocolMetricsChain,
    GqlReliquaryFarmSnapshot,
    GqlSorGetSwapPaths,
    GqlSorPath,
    GqlSorSwap,
    GqlSorSwapRoute,
    GqlSorSwapRouteHop,
    GqlStakedSonicData,
    GqlStakedSonicDelegatedValidator,
    GqlToken,
    GqlTokenAmountHumanReadable,
    GqlTokenFilter,
    GqlTokenMutationResult,
    GqlTokenPrice,
    GqlUserStakedBalance,
    HookConfig,
    LbpMetadataInput,
    LbpPriceChartData,
    LbPoolInput,
    LiquidityBootstrappingPoolV3Params,
    LiquidityManagement,
    MevTaxHookParams,
    Mutation,
    QuantAmmWeightedDetail,
    QuantAmmWeightSnapshot,
    QuantAmmWeightedParams,
    Query,
    StableSurgeHookParams,
    Token,
    GqlChain,
    GqlHookType,
    GqlPoolAprItemType,
    GqlPoolEventType,
    GqlPoolOrderBy,
    GqlPoolOrderDirection,
    GqlPoolSnapshotDataRange,
    GqlPoolStakingGaugeStatus,
    GqlPoolStakingType,
    GqlPoolType,
    GqlSorSwapType,
    GqlTokenType,
} from './types';

export const aCreateLbpInput = (overrides?: Partial<CreateLbpInput>): CreateLbpInput => {
    return {
        metadata: overrides && overrides.hasOwnProperty('metadata') ? overrides.metadata! : aLbpMetadataInput(),
        poolContract: overrides && overrides.hasOwnProperty('poolContract') ? overrides.poolContract! : aLbPoolInput(),
    };
};

export const anErc4626ReviewData = (overrides?: Partial<Erc4626ReviewData>): Erc4626ReviewData => {
    return {
        canUseBufferForSwaps:
            overrides && overrides.hasOwnProperty('canUseBufferForSwaps') ? overrides.canUseBufferForSwaps! : true,
        reviewFile: overrides && overrides.hasOwnProperty('reviewFile') ? overrides.reviewFile! : 'abeo',
        summary: overrides && overrides.hasOwnProperty('summary') ? overrides.summary! : 'solium',
        useUnderlyingForAddRemove:
            overrides && overrides.hasOwnProperty('useUnderlyingForAddRemove')
                ? overrides.useUnderlyingForAddRemove!
                : true,
        useWrappedForAddRemove:
            overrides && overrides.hasOwnProperty('useWrappedForAddRemove') ? overrides.useWrappedForAddRemove! : false,
        warnings: overrides && overrides.hasOwnProperty('warnings') ? overrides.warnings! : ['qui'],
    };
};

export const anExitFeeHookParams = (overrides?: Partial<ExitFeeHookParams>): ExitFeeHookParams => {
    return {
        exitFeePercentage:
            overrides && overrides.hasOwnProperty('exitFeePercentage') ? overrides.exitFeePercentage! : 'aspernatur',
    };
};

export const aFeeTakingHookParams = (overrides?: Partial<FeeTakingHookParams>): FeeTakingHookParams => {
    return {
        addLiquidityFeePercentage:
            overrides && overrides.hasOwnProperty('addLiquidityFeePercentage')
                ? overrides.addLiquidityFeePercentage!
                : 'laboriosam',
        removeLiquidityFeePercentage:
            overrides && overrides.hasOwnProperty('removeLiquidityFeePercentage')
                ? overrides.removeLiquidityFeePercentage!
                : 'confugo',
        swapFeePercentage:
            overrides && overrides.hasOwnProperty('swapFeePercentage') ? overrides.swapFeePercentage! : 'delectatio',
    };
};

export const aGqlAggregatorPoolFilter = (overrides?: Partial<GqlAggregatorPoolFilter>): GqlAggregatorPoolFilter => {
    return {
        chainIn: overrides && overrides.hasOwnProperty('chainIn') ? overrides.chainIn! : [GqlChain.SONIC],
        idIn: overrides && overrides.hasOwnProperty('idIn') ? overrides.idIn! : ['cognatus'],
        includeHooks:
            overrides && overrides.hasOwnProperty('includeHooks') ? overrides.includeHooks! : [GqlHookType.AKRON],
        minTvl: overrides && overrides.hasOwnProperty('minTvl') ? overrides.minTvl! : 8.5,
        poolTypeIn:
            overrides && overrides.hasOwnProperty('poolTypeIn')
                ? overrides.poolTypeIn!
                : [GqlPoolType.COMPOSABLE_STABLE],
        protocolVersionIn:
            overrides && overrides.hasOwnProperty('protocolVersionIn') ? overrides.protocolVersionIn! : [9819],
        tokensIn: overrides && overrides.hasOwnProperty('tokensIn') ? overrides.tokensIn! : ['canonicus'],
    };
};

export const aGqlHook = (overrides?: Partial<GqlHook>): GqlHook => {
    return {
        address: overrides && overrides.hasOwnProperty('address') ? overrides.address! : 'conor',
        config: overrides && overrides.hasOwnProperty('config') ? overrides.config! : aHookConfig(),
        params: overrides && overrides.hasOwnProperty('params') ? overrides.params! : anExitFeeHookParams(),
        reviewData: overrides && overrides.hasOwnProperty('reviewData') ? overrides.reviewData! : aGqlHookReviewData(),
        type: overrides && overrides.hasOwnProperty('type') ? overrides.type! : GqlHookType.AKRON,
    };
};

export const aGqlHookReviewData = (overrides?: Partial<GqlHookReviewData>): GqlHookReviewData => {
    return {
        reviewFile: overrides && overrides.hasOwnProperty('reviewFile') ? overrides.reviewFile! : 'curvo',
        summary: overrides && overrides.hasOwnProperty('summary') ? overrides.summary! : 'coniecto',
        warnings: overrides && overrides.hasOwnProperty('warnings') ? overrides.warnings! : ['pecto'],
    };
};

export const aGqlLbpTopTrade = (overrides?: Partial<GqlLbpTopTrade>): GqlLbpTopTrade => {
    return {
        address: overrides && overrides.hasOwnProperty('address') ? overrides.address! : 'denique',
        timestamp: overrides && overrides.hasOwnProperty('timestamp') ? overrides.timestamp! : 'centum',
        value: overrides && overrides.hasOwnProperty('value') ? overrides.value! : 'stips',
    };
};

export const aGqlLoopsData = (overrides?: Partial<GqlLoopsData>): GqlLoopsData => {
    return {
        actualSupply: overrides && overrides.hasOwnProperty('actualSupply') ? overrides.actualSupply! : 'varietas',
        apr: overrides && overrides.hasOwnProperty('apr') ? overrides.apr! : 8,
        collateralAmount:
            overrides && overrides.hasOwnProperty('collateralAmount') ? overrides.collateralAmount! : 'acidus',
        collateralAmountInEth:
            overrides && overrides.hasOwnProperty('collateralAmountInEth')
                ? overrides.collateralAmountInEth!
                : 'agnosco',
        debtAmount: overrides && overrides.hasOwnProperty('debtAmount') ? overrides.debtAmount! : 'uxor',
        healthFactor: overrides && overrides.hasOwnProperty('healthFactor') ? overrides.healthFactor! : 'asper',
        leverage: overrides && overrides.hasOwnProperty('leverage') ? overrides.leverage! : 2.8,
        nav: overrides && overrides.hasOwnProperty('nav') ? overrides.nav! : 'praesentium',
        rate: overrides && overrides.hasOwnProperty('rate') ? overrides.rate! : 'acceptus',
        stSAaveMarketSupply:
            overrides && overrides.hasOwnProperty('stSAaveMarketSupply') ? overrides.stSAaveMarketSupply! : 'absorbeo',
        stSAaveMarketSupplyCap:
            overrides && overrides.hasOwnProperty('stSAaveMarketSupplyCap')
                ? overrides.stSAaveMarketSupplyCap!
                : 'volaticus',
        tvl: overrides && overrides.hasOwnProperty('tvl') ? overrides.tvl! : 'apud',
    };
};

export const aGqlPoolAddRemoveEventV3 = (overrides?: Partial<GqlPoolAddRemoveEventV3>): GqlPoolAddRemoveEventV3 => {
    return {
        blockNumber: overrides && overrides.hasOwnProperty('blockNumber') ? overrides.blockNumber! : 7419,
        blockTimestamp: overrides && overrides.hasOwnProperty('blockTimestamp') ? overrides.blockTimestamp! : 3691,
        chain: overrides && overrides.hasOwnProperty('chain') ? overrides.chain! : GqlChain.SONIC,
        id: overrides && overrides.hasOwnProperty('id') ? overrides.id! : '1c522128-0a83-4c14-bc33-fb2cde2ada36',
        logIndex: overrides && overrides.hasOwnProperty('logIndex') ? overrides.logIndex! : 2895,
        poolId: overrides && overrides.hasOwnProperty('poolId') ? overrides.poolId! : 'venia',
        sender: overrides && overrides.hasOwnProperty('sender') ? overrides.sender! : 'amita',
        timestamp: overrides && overrides.hasOwnProperty('timestamp') ? overrides.timestamp! : 26,
        tokens: overrides && overrides.hasOwnProperty('tokens') ? overrides.tokens! : [aGqlPoolEventAmount()],
        tx: overrides && overrides.hasOwnProperty('tx') ? overrides.tx! : 'delego',
        type: overrides && overrides.hasOwnProperty('type') ? overrides.type! : GqlPoolEventType.ADD,
        userAddress: overrides && overrides.hasOwnProperty('userAddress') ? overrides.userAddress! : 'cui',
        valueUSD: overrides && overrides.hasOwnProperty('valueUSD') ? overrides.valueUSD! : 1,
    };
};

export const aGqlPoolAggregator = (overrides?: Partial<GqlPoolAggregator>): GqlPoolAggregator => {
    return {
        address: overrides && overrides.hasOwnProperty('address') ? overrides.address! : 'venio',
        alpha: overrides && overrides.hasOwnProperty('alpha') ? overrides.alpha! : 'qui',
        amp: overrides && overrides.hasOwnProperty('amp') ? overrides.amp! : 'vilicus',
        beta: overrides && overrides.hasOwnProperty('beta') ? overrides.beta! : 'tredecim',
        c: overrides && overrides.hasOwnProperty('c') ? overrides.c! : 'cena',
        centerednessMargin:
            overrides && overrides.hasOwnProperty('centerednessMargin') ? overrides.centerednessMargin! : 'carmen',
        chain: overrides && overrides.hasOwnProperty('chain') ? overrides.chain! : GqlChain.SONIC,
        createTime: overrides && overrides.hasOwnProperty('createTime') ? overrides.createTime! : 1115,
        currentFourthRootPriceRatio:
            overrides && overrides.hasOwnProperty('currentFourthRootPriceRatio')
                ? overrides.currentFourthRootPriceRatio!
                : 'turpis',
        dSq: overrides && overrides.hasOwnProperty('dSq') ? overrides.dSq! : 'comedo',
        dailyPriceShiftBase:
            overrides && overrides.hasOwnProperty('dailyPriceShiftBase') ? overrides.dailyPriceShiftBase! : 'iure',
        decimals: overrides && overrides.hasOwnProperty('decimals') ? overrides.decimals! : 1272,
        delta: overrides && overrides.hasOwnProperty('delta') ? overrides.delta! : 'calcar',
        dynamicData:
            overrides && overrides.hasOwnProperty('dynamicData') ? overrides.dynamicData! : aGqlPoolDynamicData(),
        endFourthRootPriceRatio:
            overrides && overrides.hasOwnProperty('endFourthRootPriceRatio')
                ? overrides.endFourthRootPriceRatio!
                : 'vinitor',
        epsilon: overrides && overrides.hasOwnProperty('epsilon') ? overrides.epsilon! : 'traho',
        factory: overrides && overrides.hasOwnProperty('factory') ? overrides.factory! : 'territo',
        hook: overrides && overrides.hasOwnProperty('hook') ? overrides.hook! : aGqlHook(),
        id: overrides && overrides.hasOwnProperty('id') ? overrides.id! : 'a295074e-2d9d-4f2a-ae6f-884b6022963d',
        lambda: overrides && overrides.hasOwnProperty('lambda') ? overrides.lambda! : 'fugiat',
        lastTimestamp: overrides && overrides.hasOwnProperty('lastTimestamp') ? overrides.lastTimestamp! : 3879,
        lastVirtualBalances:
            overrides && overrides.hasOwnProperty('lastVirtualBalances') ? overrides.lastVirtualBalances! : ['defaeco'],
        liquidityManagement:
            overrides && overrides.hasOwnProperty('liquidityManagement')
                ? overrides.liquidityManagement!
                : aLiquidityManagement(),
        name: overrides && overrides.hasOwnProperty('name') ? overrides.name! : 'claudeo',
        pauseManager: overrides && overrides.hasOwnProperty('pauseManager') ? overrides.pauseManager! : 'solutio',
        poolCreator: overrides && overrides.hasOwnProperty('poolCreator') ? overrides.poolCreator! : 'curis',
        poolTokens:
            overrides && overrides.hasOwnProperty('poolTokens') ? overrides.poolTokens! : [aGqlPoolTokenDetail()],
        priceRatioUpdateEndTime:
            overrides && overrides.hasOwnProperty('priceRatioUpdateEndTime')
                ? overrides.priceRatioUpdateEndTime!
                : 9161,
        priceRatioUpdateStartTime:
            overrides && overrides.hasOwnProperty('priceRatioUpdateStartTime')
                ? overrides.priceRatioUpdateStartTime!
                : 5224,
        protocolVersion: overrides && overrides.hasOwnProperty('protocolVersion') ? overrides.protocolVersion! : 2767,
        quantAmmWeightedParams:
            overrides && overrides.hasOwnProperty('quantAmmWeightedParams')
                ? overrides.quantAmmWeightedParams!
                : aQuantAmmWeightedParams(),
        root3Alpha: overrides && overrides.hasOwnProperty('root3Alpha') ? overrides.root3Alpha! : 'vae',
        s: overrides && overrides.hasOwnProperty('s') ? overrides.s! : 'vix',
        sqrtAlpha: overrides && overrides.hasOwnProperty('sqrtAlpha') ? overrides.sqrtAlpha! : 'decet',
        sqrtBeta: overrides && overrides.hasOwnProperty('sqrtBeta') ? overrides.sqrtBeta! : 'aiunt',
        startFourthRootPriceRatio:
            overrides && overrides.hasOwnProperty('startFourthRootPriceRatio')
                ? overrides.startFourthRootPriceRatio!
                : 'somniculosus',
        swapFeeManager:
            overrides && overrides.hasOwnProperty('swapFeeManager') ? overrides.swapFeeManager! : 'victoria',
        symbol: overrides && overrides.hasOwnProperty('symbol') ? overrides.symbol! : 'verumtamen',
        tauAlphaX: overrides && overrides.hasOwnProperty('tauAlphaX') ? overrides.tauAlphaX! : 'conscendo',
        tauAlphaY: overrides && overrides.hasOwnProperty('tauAlphaY') ? overrides.tauAlphaY! : 'amplexus',
        tauBetaX: overrides && overrides.hasOwnProperty('tauBetaX') ? overrides.tauBetaX! : 'cubitum',
        tauBetaY: overrides && overrides.hasOwnProperty('tauBetaY') ? overrides.tauBetaY! : 'appono',
        type: overrides && overrides.hasOwnProperty('type') ? overrides.type! : GqlPoolType.COMPOSABLE_STABLE,
        u: overrides && overrides.hasOwnProperty('u') ? overrides.u! : 'conforto',
        v: overrides && overrides.hasOwnProperty('v') ? overrides.v! : 'argumentum',
        version: overrides && overrides.hasOwnProperty('version') ? overrides.version! : 1793,
        w: overrides && overrides.hasOwnProperty('w') ? overrides.w! : 'clamo',
        z: overrides && overrides.hasOwnProperty('z') ? overrides.z! : 'subnecto',
    };
};

export const aGqlPoolAprItem = (overrides?: Partial<GqlPoolAprItem>): GqlPoolAprItem => {
    return {
        apr: overrides && overrides.hasOwnProperty('apr') ? overrides.apr! : 3.3,
        id: overrides && overrides.hasOwnProperty('id') ? overrides.id! : '4a8386be-3f18-419e-8052-a59ea5b5e6d9',
        rewardTokenAddress:
            overrides && overrides.hasOwnProperty('rewardTokenAddress') ? overrides.rewardTokenAddress! : 'video',
        rewardTokenSymbol:
            overrides && overrides.hasOwnProperty('rewardTokenSymbol') ? overrides.rewardTokenSymbol! : 'adduco',
        type: overrides && overrides.hasOwnProperty('type') ? overrides.type! : GqlPoolAprItemType.DYNAMIC_SWAP_FEE_24H,
    };
};

export const aGqlPoolBase = (overrides?: Partial<GqlPoolBase>): GqlPoolBase => {
    return {
        address: overrides && overrides.hasOwnProperty('address') ? overrides.address! : 'terminatio',
        chain: overrides && overrides.hasOwnProperty('chain') ? overrides.chain! : GqlChain.SONIC,
        createTime: overrides && overrides.hasOwnProperty('createTime') ? overrides.createTime! : 480,
        decimals: overrides && overrides.hasOwnProperty('decimals') ? overrides.decimals! : 7138,
        dynamicData:
            overrides && overrides.hasOwnProperty('dynamicData') ? overrides.dynamicData! : aGqlPoolDynamicData(),
        factory: overrides && overrides.hasOwnProperty('factory') ? overrides.factory! : 'vehemens',
        hasAnyAllowedBuffer:
            overrides && overrides.hasOwnProperty('hasAnyAllowedBuffer') ? overrides.hasAnyAllowedBuffer! : false,
        hasErc4626: overrides && overrides.hasOwnProperty('hasErc4626') ? overrides.hasErc4626! : true,
        hook: overrides && overrides.hasOwnProperty('hook') ? overrides.hook! : aGqlHook(),
        id: overrides && overrides.hasOwnProperty('id') ? overrides.id! : 'da48fb0a-0c12-43a4-a034-d4dce7b6001c',
        liquidityManagement:
            overrides && overrides.hasOwnProperty('liquidityManagement')
                ? overrides.liquidityManagement!
                : aLiquidityManagement(),
        name: overrides && overrides.hasOwnProperty('name') ? overrides.name! : 'umbra',
        pauseManager: overrides && overrides.hasOwnProperty('pauseManager') ? overrides.pauseManager! : 'suasoria',
        poolCreator: overrides && overrides.hasOwnProperty('poolCreator') ? overrides.poolCreator! : 'ubi',
        poolTokens:
            overrides && overrides.hasOwnProperty('poolTokens') ? overrides.poolTokens! : [aGqlPoolTokenDetail()],
        protocolVersion: overrides && overrides.hasOwnProperty('protocolVersion') ? overrides.protocolVersion! : 6915,
        staking: overrides && overrides.hasOwnProperty('staking') ? overrides.staking! : aGqlPoolStaking(),
        swapFeeManager:
            overrides && overrides.hasOwnProperty('swapFeeManager') ? overrides.swapFeeManager! : 'acceptus',
        symbol: overrides && overrides.hasOwnProperty('symbol') ? overrides.symbol! : 'desino',
        tags: overrides && overrides.hasOwnProperty('tags') ? overrides.tags! : ['spectaculum'],
        type: overrides && overrides.hasOwnProperty('type') ? overrides.type! : GqlPoolType.COMPOSABLE_STABLE,
        userBalance:
            overrides && overrides.hasOwnProperty('userBalance') ? overrides.userBalance! : aGqlPoolUserBalance(),
        version: overrides && overrides.hasOwnProperty('version') ? overrides.version! : 6596,
    };
};

export const aGqlPoolComposableStable = (overrides?: Partial<GqlPoolComposableStable>): GqlPoolComposableStable => {
    return {
        address: overrides && overrides.hasOwnProperty('address') ? overrides.address! : 'demonstro',
        amp: overrides && overrides.hasOwnProperty('amp') ? overrides.amp! : 'vacuus',
        bptPriceRate: overrides && overrides.hasOwnProperty('bptPriceRate') ? overrides.bptPriceRate! : 'utrimque',
        chain: overrides && overrides.hasOwnProperty('chain') ? overrides.chain! : GqlChain.SONIC,
        createTime: overrides && overrides.hasOwnProperty('createTime') ? overrides.createTime! : 2374,
        decimals: overrides && overrides.hasOwnProperty('decimals') ? overrides.decimals! : 4357,
        dynamicData:
            overrides && overrides.hasOwnProperty('dynamicData') ? overrides.dynamicData! : aGqlPoolDynamicData(),
        factory: overrides && overrides.hasOwnProperty('factory') ? overrides.factory! : 'timidus',
        hasAnyAllowedBuffer:
            overrides && overrides.hasOwnProperty('hasAnyAllowedBuffer') ? overrides.hasAnyAllowedBuffer! : false,
        hasErc4626: overrides && overrides.hasOwnProperty('hasErc4626') ? overrides.hasErc4626! : false,
        hook: overrides && overrides.hasOwnProperty('hook') ? overrides.hook! : aGqlHook(),
        id: overrides && overrides.hasOwnProperty('id') ? overrides.id! : 'c132904a-450c-44f0-a791-f295cba2cff6',
        liquidityManagement:
            overrides && overrides.hasOwnProperty('liquidityManagement')
                ? overrides.liquidityManagement!
                : aLiquidityManagement(),
        name: overrides && overrides.hasOwnProperty('name') ? overrides.name! : 'thesaurus',
        pauseManager: overrides && overrides.hasOwnProperty('pauseManager') ? overrides.pauseManager! : 'aiunt',
        poolCreator: overrides && overrides.hasOwnProperty('poolCreator') ? overrides.poolCreator! : 'enim',
        poolTokens:
            overrides && overrides.hasOwnProperty('poolTokens') ? overrides.poolTokens! : [aGqlPoolTokenDetail()],
        protocolVersion: overrides && overrides.hasOwnProperty('protocolVersion') ? overrides.protocolVersion! : 5105,
        staking: overrides && overrides.hasOwnProperty('staking') ? overrides.staking! : aGqlPoolStaking(),
        swapFeeManager: overrides && overrides.hasOwnProperty('swapFeeManager') ? overrides.swapFeeManager! : 'solutio',
        symbol: overrides && overrides.hasOwnProperty('symbol') ? overrides.symbol! : 'deduco',
        tags: overrides && overrides.hasOwnProperty('tags') ? overrides.tags! : ['averto'],
        type: overrides && overrides.hasOwnProperty('type') ? overrides.type! : GqlPoolType.COMPOSABLE_STABLE,
        userBalance:
            overrides && overrides.hasOwnProperty('userBalance') ? overrides.userBalance! : aGqlPoolUserBalance(),
        version: overrides && overrides.hasOwnProperty('version') ? overrides.version! : 4219,
    };
};

export const aGqlPoolDynamicData = (overrides?: Partial<GqlPoolDynamicData>): GqlPoolDynamicData => {
    return {
        aggregateSwapFee:
            overrides && overrides.hasOwnProperty('aggregateSwapFee') ? overrides.aggregateSwapFee! : 'turpis',
        aggregateYieldFee:
            overrides && overrides.hasOwnProperty('aggregateYieldFee') ? overrides.aggregateYieldFee! : 'tertius',
        aprItems: overrides && overrides.hasOwnProperty('aprItems') ? overrides.aprItems! : [aGqlPoolAprItem()],
        fees24h: overrides && overrides.hasOwnProperty('fees24h') ? overrides.fees24h! : 'iusto',
        fees48h: overrides && overrides.hasOwnProperty('fees48h') ? overrides.fees48h! : 'tristis',
        holdersCount: overrides && overrides.hasOwnProperty('holdersCount') ? overrides.holdersCount! : 'eveniet',
        isInRecoveryMode:
            overrides && overrides.hasOwnProperty('isInRecoveryMode') ? overrides.isInRecoveryMode! : true,
        isPaused: overrides && overrides.hasOwnProperty('isPaused') ? overrides.isPaused! : false,
        lifetimeSwapFees:
            overrides && overrides.hasOwnProperty('lifetimeSwapFees') ? overrides.lifetimeSwapFees! : 'coadunatio',
        lifetimeVolume: overrides && overrides.hasOwnProperty('lifetimeVolume') ? overrides.lifetimeVolume! : 'statim',
        poolId:
            overrides && overrides.hasOwnProperty('poolId')
                ? overrides.poolId!
                : '9accbc9f-7c4d-43bd-babe-358b6a23e287',
        protocolFees24h:
            overrides && overrides.hasOwnProperty('protocolFees24h') ? overrides.protocolFees24h! : 'assumenda',
        protocolFees48h:
            overrides && overrides.hasOwnProperty('protocolFees48h') ? overrides.protocolFees48h! : 'suadeo',
        protocolYieldCapture24h:
            overrides && overrides.hasOwnProperty('protocolYieldCapture24h')
                ? overrides.protocolYieldCapture24h!
                : 'balbus',
        protocolYieldCapture48h:
            overrides && overrides.hasOwnProperty('protocolYieldCapture48h')
                ? overrides.protocolYieldCapture48h!
                : 'aegre',
        swapEnabled: overrides && overrides.hasOwnProperty('swapEnabled') ? overrides.swapEnabled! : true,
        swapFee: overrides && overrides.hasOwnProperty('swapFee') ? overrides.swapFee! : 'sponte',
        totalLiquidity:
            overrides && overrides.hasOwnProperty('totalLiquidity') ? overrides.totalLiquidity! : 'adimpleo',
        totalLiquidity24hAgo:
            overrides && overrides.hasOwnProperty('totalLiquidity24hAgo') ? overrides.totalLiquidity24hAgo! : 'denique',
        totalShares: overrides && overrides.hasOwnProperty('totalShares') ? overrides.totalShares! : 'abbas',
        totalShares24hAgo:
            overrides && overrides.hasOwnProperty('totalShares24hAgo') ? overrides.totalShares24hAgo! : 'adimpleo',
        totalSupply: overrides && overrides.hasOwnProperty('totalSupply') ? overrides.totalSupply! : 'tubineus',
        volume24h: overrides && overrides.hasOwnProperty('volume24h') ? overrides.volume24h! : 'thymbra',
        volume48h: overrides && overrides.hasOwnProperty('volume48h') ? overrides.volume48h! : 'perferendis',
        yieldCapture24h:
            overrides && overrides.hasOwnProperty('yieldCapture24h') ? overrides.yieldCapture24h! : 'similique',
        yieldCapture48h:
            overrides && overrides.hasOwnProperty('yieldCapture48h') ? overrides.yieldCapture48h! : 'cinis',
    };
};

export const aGqlPoolEvent = (overrides?: Partial<GqlPoolEvent>): GqlPoolEvent => {
    return {
        blockNumber: overrides && overrides.hasOwnProperty('blockNumber') ? overrides.blockNumber! : 173,
        blockTimestamp: overrides && overrides.hasOwnProperty('blockTimestamp') ? overrides.blockTimestamp! : 2199,
        chain: overrides && overrides.hasOwnProperty('chain') ? overrides.chain! : GqlChain.SONIC,
        id: overrides && overrides.hasOwnProperty('id') ? overrides.id! : '0fbcd1b6-21f3-421e-954e-10737e9500df',
        logIndex: overrides && overrides.hasOwnProperty('logIndex') ? overrides.logIndex! : 6040,
        poolId: overrides && overrides.hasOwnProperty('poolId') ? overrides.poolId! : 'debilito',
        sender: overrides && overrides.hasOwnProperty('sender') ? overrides.sender! : 'ademptio',
        timestamp: overrides && overrides.hasOwnProperty('timestamp') ? overrides.timestamp! : 4617,
        tx: overrides && overrides.hasOwnProperty('tx') ? overrides.tx! : 'crepusculum',
        type: overrides && overrides.hasOwnProperty('type') ? overrides.type! : GqlPoolEventType.ADD,
        userAddress: overrides && overrides.hasOwnProperty('userAddress') ? overrides.userAddress! : 'clibanus',
        valueUSD: overrides && overrides.hasOwnProperty('valueUSD') ? overrides.valueUSD! : 5.6,
    };
};

export const aGqlPoolEventAmount = (overrides?: Partial<GqlPoolEventAmount>): GqlPoolEventAmount => {
    return {
        address: overrides && overrides.hasOwnProperty('address') ? overrides.address! : 'approbo',
        amount: overrides && overrides.hasOwnProperty('amount') ? overrides.amount! : 'considero',
        valueUSD: overrides && overrides.hasOwnProperty('valueUSD') ? overrides.valueUSD! : 4.8,
    };
};

export const aGqlPoolEventsFilter = (overrides?: Partial<GqlPoolEventsFilter>): GqlPoolEventsFilter => {
    return {
        chainIn: overrides && overrides.hasOwnProperty('chainIn') ? overrides.chainIn! : [GqlChain.SONIC],
        poolId: overrides && overrides.hasOwnProperty('poolId') ? overrides.poolId! : 'censura',
        type: overrides && overrides.hasOwnProperty('type') ? overrides.type! : GqlPoolEventType.ADD,
        userAddress: overrides && overrides.hasOwnProperty('userAddress') ? overrides.userAddress! : 'cruciamentum',
    };
};

export const aGqlPoolFeaturedPool = (overrides?: Partial<GqlPoolFeaturedPool>): GqlPoolFeaturedPool => {
    return {
        description: overrides && overrides.hasOwnProperty('description') ? overrides.description! : 'cervus',
        pool: overrides && overrides.hasOwnProperty('pool') ? overrides.pool! : aGqlPoolBase(),
        poolId:
            overrides && overrides.hasOwnProperty('poolId')
                ? overrides.poolId!
                : '63d328f4-4aa0-4235-b1b5-32ab0282fe49',
        primary: overrides && overrides.hasOwnProperty('primary') ? overrides.primary! : false,
    };
};

export const aGqlPoolFilter = (overrides?: Partial<GqlPoolFilter>): GqlPoolFilter => {
    return {
        chainIn: overrides && overrides.hasOwnProperty('chainIn') ? overrides.chainIn! : [GqlChain.SONIC],
        chainNotIn: overrides && overrides.hasOwnProperty('chainNotIn') ? overrides.chainNotIn! : [GqlChain.SONIC],
        createTime: overrides && overrides.hasOwnProperty('createTime') ? overrides.createTime! : aGqlPoolTimePeriod(),
        idIn: overrides && overrides.hasOwnProperty('idIn') ? overrides.idIn! : ['cogito'],
        idNotIn: overrides && overrides.hasOwnProperty('idNotIn') ? overrides.idNotIn! : ['theatrum'],
        minTvl: overrides && overrides.hasOwnProperty('minTvl') ? overrides.minTvl! : 6.8,
        poolTypeIn:
            overrides && overrides.hasOwnProperty('poolTypeIn')
                ? overrides.poolTypeIn!
                : [GqlPoolType.COMPOSABLE_STABLE],
        poolTypeNotIn:
            overrides && overrides.hasOwnProperty('poolTypeNotIn')
                ? overrides.poolTypeNotIn!
                : [GqlPoolType.COMPOSABLE_STABLE],
        protocolVersionIn:
            overrides && overrides.hasOwnProperty('protocolVersionIn') ? overrides.protocolVersionIn! : [508],
        reviewedOnly: overrides && overrides.hasOwnProperty('reviewedOnly') ? overrides.reviewedOnly! : false,
        tagIn: overrides && overrides.hasOwnProperty('tagIn') ? overrides.tagIn! : ['totam'],
        tagNotIn: overrides && overrides.hasOwnProperty('tagNotIn') ? overrides.tagNotIn! : ['cuppedia'],
        tokensIn: overrides && overrides.hasOwnProperty('tokensIn') ? overrides.tokensIn! : ['tabella'],
        tokensNotIn: overrides && overrides.hasOwnProperty('tokensNotIn') ? overrides.tokensNotIn! : ['subnecto'],
        userAddress: overrides && overrides.hasOwnProperty('userAddress') ? overrides.userAddress! : 'utrimque',
    };
};

export const aGqlPoolFixedPriceLbp = (overrides?: Partial<GqlPoolFixedPriceLbp>): GqlPoolFixedPriceLbp => {
    return {
        address: overrides && overrides.hasOwnProperty('address') ? overrides.address! : 'audacia',
        chain: overrides && overrides.hasOwnProperty('chain') ? overrides.chain! : GqlChain.SONIC,
        createTime: overrides && overrides.hasOwnProperty('createTime') ? overrides.createTime! : 9201,
        decimals: overrides && overrides.hasOwnProperty('decimals') ? overrides.decimals! : 8695,
        description: overrides && overrides.hasOwnProperty('description') ? overrides.description! : 'acies',
        discord: overrides && overrides.hasOwnProperty('discord') ? overrides.discord! : 'vobis',
        dynamicData:
            overrides && overrides.hasOwnProperty('dynamicData') ? overrides.dynamicData! : aGqlPoolDynamicData(),
        endTime: overrides && overrides.hasOwnProperty('endTime') ? overrides.endTime! : 2019,
        factory: overrides && overrides.hasOwnProperty('factory') ? overrides.factory! : 'derideo',
        farcaster: overrides && overrides.hasOwnProperty('farcaster') ? overrides.farcaster! : 'vix',
        hasAnyAllowedBuffer:
            overrides && overrides.hasOwnProperty('hasAnyAllowedBuffer') ? overrides.hasAnyAllowedBuffer! : false,
        hasErc4626: overrides && overrides.hasOwnProperty('hasErc4626') ? overrides.hasErc4626! : true,
        hook: overrides && overrides.hasOwnProperty('hook') ? overrides.hook! : aGqlHook(),
        id: overrides && overrides.hasOwnProperty('id') ? overrides.id! : '7508ef5f-7a1e-4843-8a47-5b93f9fe5b5c',
        isProjectTokenSwapInBlocked:
            overrides && overrides.hasOwnProperty('isProjectTokenSwapInBlocked')
                ? overrides.isProjectTokenSwapInBlocked!
                : false,
        lbpName: overrides && overrides.hasOwnProperty('lbpName') ? overrides.lbpName! : 'pecco',
        lbpOwner: overrides && overrides.hasOwnProperty('lbpOwner') ? overrides.lbpOwner! : 'curto',
        liquidityManagement:
            overrides && overrides.hasOwnProperty('liquidityManagement')
                ? overrides.liquidityManagement!
                : aLiquidityManagement(),
        name: overrides && overrides.hasOwnProperty('name') ? overrides.name! : 'ipsa',
        pauseManager: overrides && overrides.hasOwnProperty('pauseManager') ? overrides.pauseManager! : 'contigo',
        poolCreator: overrides && overrides.hasOwnProperty('poolCreator') ? overrides.poolCreator! : 'thorax',
        poolTokens:
            overrides && overrides.hasOwnProperty('poolTokens') ? overrides.poolTokens! : [aGqlPoolTokenDetail()],
        projectToken: overrides && overrides.hasOwnProperty('projectToken') ? overrides.projectToken! : 'magnam',
        projectTokenIndex:
            overrides && overrides.hasOwnProperty('projectTokenIndex') ? overrides.projectTokenIndex! : 5153,
        projectTokenRate:
            overrides && overrides.hasOwnProperty('projectTokenRate') ? overrides.projectTokenRate! : 'absum',
        protocolVersion: overrides && overrides.hasOwnProperty('protocolVersion') ? overrides.protocolVersion! : 7659,
        reserveToken: overrides && overrides.hasOwnProperty('reserveToken') ? overrides.reserveToken! : 'terreo',
        reserveTokenIndex:
            overrides && overrides.hasOwnProperty('reserveTokenIndex') ? overrides.reserveTokenIndex! : 6012,
        staking: overrides && overrides.hasOwnProperty('staking') ? overrides.staking! : aGqlPoolStaking(),
        startTime: overrides && overrides.hasOwnProperty('startTime') ? overrides.startTime! : 7139,
        swapFeeManager:
            overrides && overrides.hasOwnProperty('swapFeeManager') ? overrides.swapFeeManager! : 'abundans',
        symbol: overrides && overrides.hasOwnProperty('symbol') ? overrides.symbol! : 'stillicidium',
        tags: overrides && overrides.hasOwnProperty('tags') ? overrides.tags! : ['similique'],
        telegram: overrides && overrides.hasOwnProperty('telegram') ? overrides.telegram! : 'colligo',
        topTrades: overrides && overrides.hasOwnProperty('topTrades') ? overrides.topTrades! : [aGqlLbpTopTrade()],
        type: overrides && overrides.hasOwnProperty('type') ? overrides.type! : GqlPoolType.COMPOSABLE_STABLE,
        userBalance:
            overrides && overrides.hasOwnProperty('userBalance') ? overrides.userBalance! : aGqlPoolUserBalance(),
        version: overrides && overrides.hasOwnProperty('version') ? overrides.version! : 8290,
        website: overrides && overrides.hasOwnProperty('website') ? overrides.website! : 'delego',
        x: overrides && overrides.hasOwnProperty('x') ? overrides.x! : 'numquam',
    };
};

export const aGqlPoolGyro = (overrides?: Partial<GqlPoolGyro>): GqlPoolGyro => {
    return {
        address: overrides && overrides.hasOwnProperty('address') ? overrides.address! : 'coniuratio',
        alpha: overrides && overrides.hasOwnProperty('alpha') ? overrides.alpha! : 'sum',
        beta: overrides && overrides.hasOwnProperty('beta') ? overrides.beta! : 'templum',
        c: overrides && overrides.hasOwnProperty('c') ? overrides.c! : 'veritatis',
        chain: overrides && overrides.hasOwnProperty('chain') ? overrides.chain! : GqlChain.SONIC,
        createTime: overrides && overrides.hasOwnProperty('createTime') ? overrides.createTime! : 2116,
        dSq: overrides && overrides.hasOwnProperty('dSq') ? overrides.dSq! : 'tolero',
        decimals: overrides && overrides.hasOwnProperty('decimals') ? overrides.decimals! : 4118,
        dynamicData:
            overrides && overrides.hasOwnProperty('dynamicData') ? overrides.dynamicData! : aGqlPoolDynamicData(),
        factory: overrides && overrides.hasOwnProperty('factory') ? overrides.factory! : 'aggero',
        hasAnyAllowedBuffer:
            overrides && overrides.hasOwnProperty('hasAnyAllowedBuffer') ? overrides.hasAnyAllowedBuffer! : false,
        hasErc4626: overrides && overrides.hasOwnProperty('hasErc4626') ? overrides.hasErc4626! : true,
        hook: overrides && overrides.hasOwnProperty('hook') ? overrides.hook! : aGqlHook(),
        id: overrides && overrides.hasOwnProperty('id') ? overrides.id! : '0e1fe74f-62f9-4538-82f6-d5229c23fd5d',
        lambda: overrides && overrides.hasOwnProperty('lambda') ? overrides.lambda! : 'clamo',
        liquidityManagement:
            overrides && overrides.hasOwnProperty('liquidityManagement')
                ? overrides.liquidityManagement!
                : aLiquidityManagement(),
        name: overrides && overrides.hasOwnProperty('name') ? overrides.name! : 'clibanus',
        pauseManager: overrides && overrides.hasOwnProperty('pauseManager') ? overrides.pauseManager! : 'corpus',
        poolCreator: overrides && overrides.hasOwnProperty('poolCreator') ? overrides.poolCreator! : 'antepono',
        poolTokens:
            overrides && overrides.hasOwnProperty('poolTokens') ? overrides.poolTokens! : [aGqlPoolTokenDetail()],
        protocolVersion: overrides && overrides.hasOwnProperty('protocolVersion') ? overrides.protocolVersion! : 2705,
        root3Alpha: overrides && overrides.hasOwnProperty('root3Alpha') ? overrides.root3Alpha! : 'cruciamentum',
        s: overrides && overrides.hasOwnProperty('s') ? overrides.s! : 'aiunt',
        sqrtAlpha: overrides && overrides.hasOwnProperty('sqrtAlpha') ? overrides.sqrtAlpha! : 'cauda',
        sqrtBeta: overrides && overrides.hasOwnProperty('sqrtBeta') ? overrides.sqrtBeta! : 'amplexus',
        staking: overrides && overrides.hasOwnProperty('staking') ? overrides.staking! : aGqlPoolStaking(),
        swapFeeManager: overrides && overrides.hasOwnProperty('swapFeeManager') ? overrides.swapFeeManager! : 'tepesco',
        symbol: overrides && overrides.hasOwnProperty('symbol') ? overrides.symbol! : 'caterva',
        tags: overrides && overrides.hasOwnProperty('tags') ? overrides.tags! : ['stips'],
        tauAlphaX: overrides && overrides.hasOwnProperty('tauAlphaX') ? overrides.tauAlphaX! : 'torrens',
        tauAlphaY: overrides && overrides.hasOwnProperty('tauAlphaY') ? overrides.tauAlphaY! : 'comes',
        tauBetaX: overrides && overrides.hasOwnProperty('tauBetaX') ? overrides.tauBetaX! : 'acer',
        tauBetaY: overrides && overrides.hasOwnProperty('tauBetaY') ? overrides.tauBetaY! : 'conatus',
        type: overrides && overrides.hasOwnProperty('type') ? overrides.type! : GqlPoolType.COMPOSABLE_STABLE,
        u: overrides && overrides.hasOwnProperty('u') ? overrides.u! : 'admitto',
        userBalance:
            overrides && overrides.hasOwnProperty('userBalance') ? overrides.userBalance! : aGqlPoolUserBalance(),
        v: overrides && overrides.hasOwnProperty('v') ? overrides.v! : 'aperio',
        version: overrides && overrides.hasOwnProperty('version') ? overrides.version! : 9363,
        w: overrides && overrides.hasOwnProperty('w') ? overrides.w! : 'praesentium',
        z: overrides && overrides.hasOwnProperty('z') ? overrides.z! : 'enim',
    };
};

export const aGqlPoolLiquidityBootstrapping = (
    overrides?: Partial<GqlPoolLiquidityBootstrapping>,
): GqlPoolLiquidityBootstrapping => {
    return {
        address: overrides && overrides.hasOwnProperty('address') ? overrides.address! : 'vitium',
        chain: overrides && overrides.hasOwnProperty('chain') ? overrides.chain! : GqlChain.SONIC,
        createTime: overrides && overrides.hasOwnProperty('createTime') ? overrides.createTime! : 2673,
        decimals: overrides && overrides.hasOwnProperty('decimals') ? overrides.decimals! : 4836,
        dynamicData:
            overrides && overrides.hasOwnProperty('dynamicData') ? overrides.dynamicData! : aGqlPoolDynamicData(),
        factory: overrides && overrides.hasOwnProperty('factory') ? overrides.factory! : 'sub',
        hasAnyAllowedBuffer:
            overrides && overrides.hasOwnProperty('hasAnyAllowedBuffer') ? overrides.hasAnyAllowedBuffer! : true,
        hasErc4626: overrides && overrides.hasOwnProperty('hasErc4626') ? overrides.hasErc4626! : true,
        hook: overrides && overrides.hasOwnProperty('hook') ? overrides.hook! : aGqlHook(),
        id: overrides && overrides.hasOwnProperty('id') ? overrides.id! : 'b7b2bee3-3d0c-4708-9a92-8f8c97c36549',
        liquidityManagement:
            overrides && overrides.hasOwnProperty('liquidityManagement')
                ? overrides.liquidityManagement!
                : aLiquidityManagement(),
        name: overrides && overrides.hasOwnProperty('name') ? overrides.name! : 'quas',
        pauseManager: overrides && overrides.hasOwnProperty('pauseManager') ? overrides.pauseManager! : 'cubicularis',
        poolCreator: overrides && overrides.hasOwnProperty('poolCreator') ? overrides.poolCreator! : 'celo',
        poolTokens:
            overrides && overrides.hasOwnProperty('poolTokens') ? overrides.poolTokens! : [aGqlPoolTokenDetail()],
        protocolVersion: overrides && overrides.hasOwnProperty('protocolVersion') ? overrides.protocolVersion! : 7081,
        staking: overrides && overrides.hasOwnProperty('staking') ? overrides.staking! : aGqlPoolStaking(),
        swapFeeManager: overrides && overrides.hasOwnProperty('swapFeeManager') ? overrides.swapFeeManager! : 'trucido',
        symbol: overrides && overrides.hasOwnProperty('symbol') ? overrides.symbol! : 'colo',
        tags: overrides && overrides.hasOwnProperty('tags') ? overrides.tags! : ['adsuesco'],
        type: overrides && overrides.hasOwnProperty('type') ? overrides.type! : GqlPoolType.COMPOSABLE_STABLE,
        userBalance:
            overrides && overrides.hasOwnProperty('userBalance') ? overrides.userBalance! : aGqlPoolUserBalance(),
        version: overrides && overrides.hasOwnProperty('version') ? overrides.version! : 782,
    };
};

export const aGqlPoolLiquidityBootstrappingV3 = (
    overrides?: Partial<GqlPoolLiquidityBootstrappingV3>,
): GqlPoolLiquidityBootstrappingV3 => {
    return {
        address: overrides && overrides.hasOwnProperty('address') ? overrides.address! : 'ago',
        chain: overrides && overrides.hasOwnProperty('chain') ? overrides.chain! : GqlChain.SONIC,
        createTime: overrides && overrides.hasOwnProperty('createTime') ? overrides.createTime! : 4357,
        decimals: overrides && overrides.hasOwnProperty('decimals') ? overrides.decimals! : 9639,
        description: overrides && overrides.hasOwnProperty('description') ? overrides.description! : 'aliquam',
        discord: overrides && overrides.hasOwnProperty('discord') ? overrides.discord! : 'stabilis',
        dynamicData:
            overrides && overrides.hasOwnProperty('dynamicData') ? overrides.dynamicData! : aGqlPoolDynamicData(),
        endTime: overrides && overrides.hasOwnProperty('endTime') ? overrides.endTime! : 1917,
        factory: overrides && overrides.hasOwnProperty('factory') ? overrides.factory! : 'vomica',
        farcaster: overrides && overrides.hasOwnProperty('farcaster') ? overrides.farcaster! : 'alter',
        hasAnyAllowedBuffer:
            overrides && overrides.hasOwnProperty('hasAnyAllowedBuffer') ? overrides.hasAnyAllowedBuffer! : true,
        hasErc4626: overrides && overrides.hasOwnProperty('hasErc4626') ? overrides.hasErc4626! : true,
        hook: overrides && overrides.hasOwnProperty('hook') ? overrides.hook! : aGqlHook(),
        id: overrides && overrides.hasOwnProperty('id') ? overrides.id! : '97ba1b39-8f9e-4946-98c6-7e1cc860e5b9',
        isProjectTokenSwapInBlocked:
            overrides && overrides.hasOwnProperty('isProjectTokenSwapInBlocked')
                ? overrides.isProjectTokenSwapInBlocked!
                : false,
        isSeedless: overrides && overrides.hasOwnProperty('isSeedless') ? overrides.isSeedless! : false,
        lbpName: overrides && overrides.hasOwnProperty('lbpName') ? overrides.lbpName! : 'conscendo',
        lbpOwner: overrides && overrides.hasOwnProperty('lbpOwner') ? overrides.lbpOwner! : 'coma',
        liquidityManagement:
            overrides && overrides.hasOwnProperty('liquidityManagement')
                ? overrides.liquidityManagement!
                : aLiquidityManagement(),
        name: overrides && overrides.hasOwnProperty('name') ? overrides.name! : 'corroboro',
        pauseManager: overrides && overrides.hasOwnProperty('pauseManager') ? overrides.pauseManager! : 'sordeo',
        poolCreator: overrides && overrides.hasOwnProperty('poolCreator') ? overrides.poolCreator! : 'velociter',
        poolTokens:
            overrides && overrides.hasOwnProperty('poolTokens') ? overrides.poolTokens! : [aGqlPoolTokenDetail()],
        projectToken: overrides && overrides.hasOwnProperty('projectToken') ? overrides.projectToken! : 'iure',
        projectTokenEndWeight:
            overrides && overrides.hasOwnProperty('projectTokenEndWeight') ? overrides.projectTokenEndWeight! : 1.9,
        projectTokenIndex:
            overrides && overrides.hasOwnProperty('projectTokenIndex') ? overrides.projectTokenIndex! : 251,
        projectTokenStartWeight:
            overrides && overrides.hasOwnProperty('projectTokenStartWeight') ? overrides.projectTokenStartWeight! : 7.2,
        protocolVersion: overrides && overrides.hasOwnProperty('protocolVersion') ? overrides.protocolVersion! : 2653,
        reserveToken: overrides && overrides.hasOwnProperty('reserveToken') ? overrides.reserveToken! : 'caritas',
        reserveTokenEndWeight:
            overrides && overrides.hasOwnProperty('reserveTokenEndWeight') ? overrides.reserveTokenEndWeight! : 6.8,
        reserveTokenIndex:
            overrides && overrides.hasOwnProperty('reserveTokenIndex') ? overrides.reserveTokenIndex! : 8092,
        reserveTokenStartWeight:
            overrides && overrides.hasOwnProperty('reserveTokenStartWeight') ? overrides.reserveTokenStartWeight! : 5.5,
        reserveTokenVirtualBalance:
            overrides && overrides.hasOwnProperty('reserveTokenVirtualBalance')
                ? overrides.reserveTokenVirtualBalance!
                : 6.3,
        staking: overrides && overrides.hasOwnProperty('staking') ? overrides.staking! : aGqlPoolStaking(),
        startTime: overrides && overrides.hasOwnProperty('startTime') ? overrides.startTime! : 3725,
        swapFeeManager:
            overrides && overrides.hasOwnProperty('swapFeeManager') ? overrides.swapFeeManager! : 'bellicus',
        symbol: overrides && overrides.hasOwnProperty('symbol') ? overrides.symbol! : 'clamo',
        tags: overrides && overrides.hasOwnProperty('tags') ? overrides.tags! : ['attollo'],
        telegram: overrides && overrides.hasOwnProperty('telegram') ? overrides.telegram! : 'cohibeo',
        topTrades: overrides && overrides.hasOwnProperty('topTrades') ? overrides.topTrades! : [aGqlLbpTopTrade()],
        type: overrides && overrides.hasOwnProperty('type') ? overrides.type! : GqlPoolType.COMPOSABLE_STABLE,
        userBalance:
            overrides && overrides.hasOwnProperty('userBalance') ? overrides.userBalance! : aGqlPoolUserBalance(),
        version: overrides && overrides.hasOwnProperty('version') ? overrides.version! : 9337,
        website: overrides && overrides.hasOwnProperty('website') ? overrides.website! : 'terror',
        x: overrides && overrides.hasOwnProperty('x') ? overrides.x! : 'sint',
    };
};

export const aGqlPoolMinimal = (overrides?: Partial<GqlPoolMinimal>): GqlPoolMinimal => {
    return {
        address: overrides && overrides.hasOwnProperty('address') ? overrides.address! : 'exercitationem',
        chain: overrides && overrides.hasOwnProperty('chain') ? overrides.chain! : GqlChain.SONIC,
        createTime: overrides && overrides.hasOwnProperty('createTime') ? overrides.createTime! : 8328,
        decimals: overrides && overrides.hasOwnProperty('decimals') ? overrides.decimals! : 7389,
        dynamicData:
            overrides && overrides.hasOwnProperty('dynamicData') ? overrides.dynamicData! : aGqlPoolDynamicData(),
        factory: overrides && overrides.hasOwnProperty('factory') ? overrides.factory! : 'ducimus',
        hasAnyAllowedBuffer:
            overrides && overrides.hasOwnProperty('hasAnyAllowedBuffer') ? overrides.hasAnyAllowedBuffer! : false,
        hasErc4626: overrides && overrides.hasOwnProperty('hasErc4626') ? overrides.hasErc4626! : true,
        hook: overrides && overrides.hasOwnProperty('hook') ? overrides.hook! : aGqlHook(),
        id: overrides && overrides.hasOwnProperty('id') ? overrides.id! : '55063821-2313-4ba6-92ce-8d0f9817605c',
        incentivized: overrides && overrides.hasOwnProperty('incentivized') ? overrides.incentivized! : false,
        lbpParams:
            overrides && overrides.hasOwnProperty('lbpParams')
                ? overrides.lbpParams!
                : aLiquidityBootstrappingPoolV3Params(),
        liquidityManagement:
            overrides && overrides.hasOwnProperty('liquidityManagement')
                ? overrides.liquidityManagement!
                : aLiquidityManagement(),
        name: overrides && overrides.hasOwnProperty('name') ? overrides.name! : 'accendo',
        pauseManager: overrides && overrides.hasOwnProperty('pauseManager') ? overrides.pauseManager! : 'suffoco',
        poolCreator: overrides && overrides.hasOwnProperty('poolCreator') ? overrides.poolCreator! : 'summisse',
        poolTokens:
            overrides && overrides.hasOwnProperty('poolTokens') ? overrides.poolTokens! : [aGqlPoolTokenDetail()],
        protocolVersion: overrides && overrides.hasOwnProperty('protocolVersion') ? overrides.protocolVersion! : 4791,
        staking: overrides && overrides.hasOwnProperty('staking') ? overrides.staking! : aGqlPoolStaking(),
        swapFeeManager: overrides && overrides.hasOwnProperty('swapFeeManager') ? overrides.swapFeeManager! : 'sponte',
        symbol: overrides && overrides.hasOwnProperty('symbol') ? overrides.symbol! : 'decumbo',
        tags: overrides && overrides.hasOwnProperty('tags') ? overrides.tags! : ['delicate'],
        type: overrides && overrides.hasOwnProperty('type') ? overrides.type! : GqlPoolType.COMPOSABLE_STABLE,
        userBalance:
            overrides && overrides.hasOwnProperty('userBalance') ? overrides.userBalance! : aGqlPoolUserBalance(),
        version: overrides && overrides.hasOwnProperty('version') ? overrides.version! : 6568,
    };
};

export const aGqlPoolMutationResult = (overrides?: Partial<GqlPoolMutationResult>): GqlPoolMutationResult => {
    return {
        chain: overrides && overrides.hasOwnProperty('chain') ? overrides.chain! : GqlChain.SONIC,
        error: overrides && overrides.hasOwnProperty('error') ? overrides.error! : 'alveus',
        success: overrides && overrides.hasOwnProperty('success') ? overrides.success! : true,
        type: overrides && overrides.hasOwnProperty('type') ? overrides.type! : 'animadverto',
    };
};

export const aGqlPoolQuantAmmWeighted = (overrides?: Partial<GqlPoolQuantAmmWeighted>): GqlPoolQuantAmmWeighted => {
    return {
        address: overrides && overrides.hasOwnProperty('address') ? overrides.address! : 'pauci',
        chain: overrides && overrides.hasOwnProperty('chain') ? overrides.chain! : GqlChain.SONIC,
        createTime: overrides && overrides.hasOwnProperty('createTime') ? overrides.createTime! : 1409,
        decimals: overrides && overrides.hasOwnProperty('decimals') ? overrides.decimals! : 5290,
        dynamicData:
            overrides && overrides.hasOwnProperty('dynamicData') ? overrides.dynamicData! : aGqlPoolDynamicData(),
        factory: overrides && overrides.hasOwnProperty('factory') ? overrides.factory! : 'accommodo',
        hasAnyAllowedBuffer:
            overrides && overrides.hasOwnProperty('hasAnyAllowedBuffer') ? overrides.hasAnyAllowedBuffer! : true,
        hasErc4626: overrides && overrides.hasOwnProperty('hasErc4626') ? overrides.hasErc4626! : true,
        hook: overrides && overrides.hasOwnProperty('hook') ? overrides.hook! : aGqlHook(),
        id: overrides && overrides.hasOwnProperty('id') ? overrides.id! : 'aac81436-8dd8-4197-bf33-cc82f7ea4570',
        liquidityManagement:
            overrides && overrides.hasOwnProperty('liquidityManagement')
                ? overrides.liquidityManagement!
                : aLiquidityManagement(),
        name: overrides && overrides.hasOwnProperty('name') ? overrides.name! : 'verbera',
        pauseManager: overrides && overrides.hasOwnProperty('pauseManager') ? overrides.pauseManager! : 'viduo',
        poolCreator: overrides && overrides.hasOwnProperty('poolCreator') ? overrides.poolCreator! : 'vinum',
        poolTokens:
            overrides && overrides.hasOwnProperty('poolTokens') ? overrides.poolTokens! : [aGqlPoolTokenDetail()],
        protocolVersion: overrides && overrides.hasOwnProperty('protocolVersion') ? overrides.protocolVersion! : 860,
        quantAmmWeightedParams:
            overrides && overrides.hasOwnProperty('quantAmmWeightedParams')
                ? overrides.quantAmmWeightedParams!
                : aQuantAmmWeightedParams(),
        staking: overrides && overrides.hasOwnProperty('staking') ? overrides.staking! : aGqlPoolStaking(),
        swapFeeManager: overrides && overrides.hasOwnProperty('swapFeeManager') ? overrides.swapFeeManager! : 'modi',
        symbol: overrides && overrides.hasOwnProperty('symbol') ? overrides.symbol! : 'alioqui',
        tags: overrides && overrides.hasOwnProperty('tags') ? overrides.tags! : ['alius'],
        type: overrides && overrides.hasOwnProperty('type') ? overrides.type! : GqlPoolType.COMPOSABLE_STABLE,
        userBalance:
            overrides && overrides.hasOwnProperty('userBalance') ? overrides.userBalance! : aGqlPoolUserBalance(),
        version: overrides && overrides.hasOwnProperty('version') ? overrides.version! : 2389,
        weightSnapshots:
            overrides && overrides.hasOwnProperty('weightSnapshots')
                ? overrides.weightSnapshots!
                : [aQuantAmmWeightSnapshot()],
    };
};

export const aGqlPoolReClamm = (overrides?: Partial<GqlPoolReClamm>): GqlPoolReClamm => {
    return {
        address: overrides && overrides.hasOwnProperty('address') ? overrides.address! : 'tego',
        centerednessMargin:
            overrides && overrides.hasOwnProperty('centerednessMargin') ? overrides.centerednessMargin! : 'brevis',
        chain: overrides && overrides.hasOwnProperty('chain') ? overrides.chain! : GqlChain.SONIC,
        createTime: overrides && overrides.hasOwnProperty('createTime') ? overrides.createTime! : 3260,
        currentFourthRootPriceRatio:
            overrides && overrides.hasOwnProperty('currentFourthRootPriceRatio')
                ? overrides.currentFourthRootPriceRatio!
                : 'cubicularis',
        dailyPriceShiftBase:
            overrides && overrides.hasOwnProperty('dailyPriceShiftBase') ? overrides.dailyPriceShiftBase! : 'aspicio',
        decimals: overrides && overrides.hasOwnProperty('decimals') ? overrides.decimals! : 5667,
        dynamicData:
            overrides && overrides.hasOwnProperty('dynamicData') ? overrides.dynamicData! : aGqlPoolDynamicData(),
        endFourthRootPriceRatio:
            overrides && overrides.hasOwnProperty('endFourthRootPriceRatio')
                ? overrides.endFourthRootPriceRatio!
                : 'atqui',
        factory: overrides && overrides.hasOwnProperty('factory') ? overrides.factory! : 'argentum',
        hasAnyAllowedBuffer:
            overrides && overrides.hasOwnProperty('hasAnyAllowedBuffer') ? overrides.hasAnyAllowedBuffer! : false,
        hasErc4626: overrides && overrides.hasOwnProperty('hasErc4626') ? overrides.hasErc4626! : false,
        hook: overrides && overrides.hasOwnProperty('hook') ? overrides.hook! : aGqlHook(),
        id: overrides && overrides.hasOwnProperty('id') ? overrides.id! : 'ad8dc60f-51dc-44d3-a1a8-785b5a3ac1b4',
        lastTimestamp: overrides && overrides.hasOwnProperty('lastTimestamp') ? overrides.lastTimestamp! : 7233,
        lastVirtualBalances:
            overrides && overrides.hasOwnProperty('lastVirtualBalances') ? overrides.lastVirtualBalances! : ['tabula'],
        liquidityManagement:
            overrides && overrides.hasOwnProperty('liquidityManagement')
                ? overrides.liquidityManagement!
                : aLiquidityManagement(),
        name: overrides && overrides.hasOwnProperty('name') ? overrides.name! : 'veritas',
        pauseManager: overrides && overrides.hasOwnProperty('pauseManager') ? overrides.pauseManager! : 'trado',
        poolCreator: overrides && overrides.hasOwnProperty('poolCreator') ? overrides.poolCreator! : 'cunabula',
        poolTokens:
            overrides && overrides.hasOwnProperty('poolTokens') ? overrides.poolTokens! : [aGqlPoolTokenDetail()],
        priceRatioUpdateEndTime:
            overrides && overrides.hasOwnProperty('priceRatioUpdateEndTime')
                ? overrides.priceRatioUpdateEndTime!
                : 9355,
        priceRatioUpdateStartTime:
            overrides && overrides.hasOwnProperty('priceRatioUpdateStartTime')
                ? overrides.priceRatioUpdateStartTime!
                : 225,
        protocolVersion: overrides && overrides.hasOwnProperty('protocolVersion') ? overrides.protocolVersion! : 9552,
        staking: overrides && overrides.hasOwnProperty('staking') ? overrides.staking! : aGqlPoolStaking(),
        startFourthRootPriceRatio:
            overrides && overrides.hasOwnProperty('startFourthRootPriceRatio')
                ? overrides.startFourthRootPriceRatio!
                : 'coadunatio',
        swapFeeManager: overrides && overrides.hasOwnProperty('swapFeeManager') ? overrides.swapFeeManager! : 'amita',
        symbol: overrides && overrides.hasOwnProperty('symbol') ? overrides.symbol! : 'acidus',
        tags: overrides && overrides.hasOwnProperty('tags') ? overrides.tags! : ['audeo'],
        type: overrides && overrides.hasOwnProperty('type') ? overrides.type! : GqlPoolType.COMPOSABLE_STABLE,
        userBalance:
            overrides && overrides.hasOwnProperty('userBalance') ? overrides.userBalance! : aGqlPoolUserBalance(),
        version: overrides && overrides.hasOwnProperty('version') ? overrides.version! : 1366,
    };
};

export const aGqlPoolSnapshot = (overrides?: Partial<GqlPoolSnapshot>): GqlPoolSnapshot => {
    return {
        amounts: overrides && overrides.hasOwnProperty('amounts') ? overrides.amounts! : ['cunae'],
        chain: overrides && overrides.hasOwnProperty('chain') ? overrides.chain! : GqlChain.SONIC,
        fees24h: overrides && overrides.hasOwnProperty('fees24h') ? overrides.fees24h! : 'speculum',
        id: overrides && overrides.hasOwnProperty('id') ? overrides.id! : '8cc4c0f8-67ae-4d67-b35f-6b673f0af3a1',
        poolId: overrides && overrides.hasOwnProperty('poolId') ? overrides.poolId! : 'adiuvo',
        sharePrice: overrides && overrides.hasOwnProperty('sharePrice') ? overrides.sharePrice! : 'totus',
        swapsCount: overrides && overrides.hasOwnProperty('swapsCount') ? overrides.swapsCount! : 'acidus',
        timestamp: overrides && overrides.hasOwnProperty('timestamp') ? overrides.timestamp! : 702,
        totalLiquidity:
            overrides && overrides.hasOwnProperty('totalLiquidity') ? overrides.totalLiquidity! : 'synagoga',
        totalShares: overrides && overrides.hasOwnProperty('totalShares') ? overrides.totalShares! : 'angelus',
        volume24h: overrides && overrides.hasOwnProperty('volume24h') ? overrides.volume24h! : 'defaeco',
    };
};

export const aGqlPoolStable = (overrides?: Partial<GqlPoolStable>): GqlPoolStable => {
    return {
        address: overrides && overrides.hasOwnProperty('address') ? overrides.address! : 'valde',
        amp: overrides && overrides.hasOwnProperty('amp') ? overrides.amp! : 'ascisco',
        bptPriceRate: overrides && overrides.hasOwnProperty('bptPriceRate') ? overrides.bptPriceRate! : 'tabgo',
        chain: overrides && overrides.hasOwnProperty('chain') ? overrides.chain! : GqlChain.SONIC,
        createTime: overrides && overrides.hasOwnProperty('createTime') ? overrides.createTime! : 9737,
        decimals: overrides && overrides.hasOwnProperty('decimals') ? overrides.decimals! : 6134,
        dynamicData:
            overrides && overrides.hasOwnProperty('dynamicData') ? overrides.dynamicData! : aGqlPoolDynamicData(),
        factory: overrides && overrides.hasOwnProperty('factory') ? overrides.factory! : 'cogito',
        hasAnyAllowedBuffer:
            overrides && overrides.hasOwnProperty('hasAnyAllowedBuffer') ? overrides.hasAnyAllowedBuffer! : true,
        hasErc4626: overrides && overrides.hasOwnProperty('hasErc4626') ? overrides.hasErc4626! : false,
        hook: overrides && overrides.hasOwnProperty('hook') ? overrides.hook! : aGqlHook(),
        id: overrides && overrides.hasOwnProperty('id') ? overrides.id! : '0c3723eb-d9a9-4c8b-a09c-3a81cb8da8b4',
        liquidityManagement:
            overrides && overrides.hasOwnProperty('liquidityManagement')
                ? overrides.liquidityManagement!
                : aLiquidityManagement(),
        name: overrides && overrides.hasOwnProperty('name') ? overrides.name! : 'consectetur',
        pauseManager: overrides && overrides.hasOwnProperty('pauseManager') ? overrides.pauseManager! : 'tyrannus',
        poolCreator: overrides && overrides.hasOwnProperty('poolCreator') ? overrides.poolCreator! : 'summisse',
        poolTokens:
            overrides && overrides.hasOwnProperty('poolTokens') ? overrides.poolTokens! : [aGqlPoolTokenDetail()],
        protocolVersion: overrides && overrides.hasOwnProperty('protocolVersion') ? overrides.protocolVersion! : 6728,
        staking: overrides && overrides.hasOwnProperty('staking') ? overrides.staking! : aGqlPoolStaking(),
        swapFeeManager: overrides && overrides.hasOwnProperty('swapFeeManager') ? overrides.swapFeeManager! : 'depereo',
        symbol: overrides && overrides.hasOwnProperty('symbol') ? overrides.symbol! : 'claudeo',
        tags: overrides && overrides.hasOwnProperty('tags') ? overrides.tags! : ['deputo'],
        type: overrides && overrides.hasOwnProperty('type') ? overrides.type! : GqlPoolType.COMPOSABLE_STABLE,
        userBalance:
            overrides && overrides.hasOwnProperty('userBalance') ? overrides.userBalance! : aGqlPoolUserBalance(),
        version: overrides && overrides.hasOwnProperty('version') ? overrides.version! : 3295,
    };
};

export const aGqlPoolStaking = (overrides?: Partial<GqlPoolStaking>): GqlPoolStaking => {
    return {
        address: overrides && overrides.hasOwnProperty('address') ? overrides.address! : 'tricesimus',
        chain: overrides && overrides.hasOwnProperty('chain') ? overrides.chain! : GqlChain.SONIC,
        gauge: overrides && overrides.hasOwnProperty('gauge') ? overrides.gauge! : aGqlPoolStakingGauge(),
        id: overrides && overrides.hasOwnProperty('id') ? overrides.id! : '78deac1b-3fa9-4e03-abb0-e09ed3e79cbf',
        reliquary:
            overrides && overrides.hasOwnProperty('reliquary') ? overrides.reliquary! : aGqlPoolStakingReliquaryFarm(),
        type: overrides && overrides.hasOwnProperty('type') ? overrides.type! : GqlPoolStakingType.GAUGE,
    };
};

export const aGqlPoolStakingGauge = (overrides?: Partial<GqlPoolStakingGauge>): GqlPoolStakingGauge => {
    return {
        gaugeAddress: overrides && overrides.hasOwnProperty('gaugeAddress') ? overrides.gaugeAddress! : 'color',
        id: overrides && overrides.hasOwnProperty('id') ? overrides.id! : 'a6dea17a-5c42-430d-96f7-5f55701008cb',
        otherGauges:
            overrides && overrides.hasOwnProperty('otherGauges')
                ? overrides.otherGauges!
                : [aGqlPoolStakingOtherGauge()],
        rewards: overrides && overrides.hasOwnProperty('rewards') ? overrides.rewards! : [aGqlPoolStakingGaugeReward()],
        status: overrides && overrides.hasOwnProperty('status') ? overrides.status! : GqlPoolStakingGaugeStatus.ACTIVE,
        version: overrides && overrides.hasOwnProperty('version') ? overrides.version! : 9663,
        workingSupply: overrides && overrides.hasOwnProperty('workingSupply') ? overrides.workingSupply! : 'cruentus',
    };
};

export const aGqlPoolStakingGaugeReward = (
    overrides?: Partial<GqlPoolStakingGaugeReward>,
): GqlPoolStakingGaugeReward => {
    return {
        id: overrides && overrides.hasOwnProperty('id') ? overrides.id! : '623a9753-4f35-4c7b-a84b-59d9196e026c',
        rewardPerSecond: overrides && overrides.hasOwnProperty('rewardPerSecond') ? overrides.rewardPerSecond! : 'acer',
        tokenAddress: overrides && overrides.hasOwnProperty('tokenAddress') ? overrides.tokenAddress! : 'cribro',
    };
};

export const aGqlPoolStakingOtherGauge = (overrides?: Partial<GqlPoolStakingOtherGauge>): GqlPoolStakingOtherGauge => {
    return {
        gaugeAddress: overrides && overrides.hasOwnProperty('gaugeAddress') ? overrides.gaugeAddress! : 'delicate',
        id: overrides && overrides.hasOwnProperty('id') ? overrides.id! : '37f91a30-78c2-46f2-8980-92a87434ade9',
        rewards: overrides && overrides.hasOwnProperty('rewards') ? overrides.rewards! : [aGqlPoolStakingGaugeReward()],
        status: overrides && overrides.hasOwnProperty('status') ? overrides.status! : GqlPoolStakingGaugeStatus.ACTIVE,
        version: overrides && overrides.hasOwnProperty('version') ? overrides.version! : 9412,
    };
};

export const aGqlPoolStakingReliquaryFarm = (
    overrides?: Partial<GqlPoolStakingReliquaryFarm>,
): GqlPoolStakingReliquaryFarm => {
    return {
        beetsPerSecond: overrides && overrides.hasOwnProperty('beetsPerSecond') ? overrides.beetsPerSecond! : 'aegre',
        id: overrides && overrides.hasOwnProperty('id') ? overrides.id! : '3c3f2723-d62c-4a04-8204-40926a8be3f4',
        levels:
            overrides && overrides.hasOwnProperty('levels') ? overrides.levels! : [aGqlPoolStakingReliquaryFarmLevel()],
        totalBalance: overrides && overrides.hasOwnProperty('totalBalance') ? overrides.totalBalance! : 'cognatus',
        totalWeightedBalance:
            overrides && overrides.hasOwnProperty('totalWeightedBalance') ? overrides.totalWeightedBalance! : 'corona',
    };
};

export const aGqlPoolStakingReliquaryFarmLevel = (
    overrides?: Partial<GqlPoolStakingReliquaryFarmLevel>,
): GqlPoolStakingReliquaryFarmLevel => {
    return {
        allocationPoints:
            overrides && overrides.hasOwnProperty('allocationPoints') ? overrides.allocationPoints! : 5987,
        apr: overrides && overrides.hasOwnProperty('apr') ? overrides.apr! : 'combibo',
        balance: overrides && overrides.hasOwnProperty('balance') ? overrides.balance! : 'patruus',
        id: overrides && overrides.hasOwnProperty('id') ? overrides.id! : '6407853d-0dea-4b1d-a872-16a1e8fc0f2d',
        level: overrides && overrides.hasOwnProperty('level') ? overrides.level! : 5143,
        requiredMaturity:
            overrides && overrides.hasOwnProperty('requiredMaturity') ? overrides.requiredMaturity! : 2222,
    };
};

export const aGqlPoolSwapEventCowAmm = (overrides?: Partial<GqlPoolSwapEventCowAmm>): GqlPoolSwapEventCowAmm => {
    return {
        blockNumber: overrides && overrides.hasOwnProperty('blockNumber') ? overrides.blockNumber! : 2032,
        blockTimestamp: overrides && overrides.hasOwnProperty('blockTimestamp') ? overrides.blockTimestamp! : 9782,
        chain: overrides && overrides.hasOwnProperty('chain') ? overrides.chain! : GqlChain.SONIC,
        fee: overrides && overrides.hasOwnProperty('fee') ? overrides.fee! : aGqlPoolEventAmount(),
        id: overrides && overrides.hasOwnProperty('id') ? overrides.id! : '19819e50-4e81-4033-9554-107d50e103ac',
        logIndex: overrides && overrides.hasOwnProperty('logIndex') ? overrides.logIndex! : 6105,
        poolId: overrides && overrides.hasOwnProperty('poolId') ? overrides.poolId! : 'cras',
        sender: overrides && overrides.hasOwnProperty('sender') ? overrides.sender! : 'canonicus',
        timestamp: overrides && overrides.hasOwnProperty('timestamp') ? overrides.timestamp! : 7300,
        tokenIn: overrides && overrides.hasOwnProperty('tokenIn') ? overrides.tokenIn! : aGqlPoolEventAmount(),
        tokenOut: overrides && overrides.hasOwnProperty('tokenOut') ? overrides.tokenOut! : aGqlPoolEventAmount(),
        tx: overrides && overrides.hasOwnProperty('tx') ? overrides.tx! : 'tripudio',
        type: overrides && overrides.hasOwnProperty('type') ? overrides.type! : GqlPoolEventType.ADD,
        userAddress: overrides && overrides.hasOwnProperty('userAddress') ? overrides.userAddress! : 'cerno',
        valueUSD: overrides && overrides.hasOwnProperty('valueUSD') ? overrides.valueUSD! : 7.4,
    };
};

export const aGqlPoolSwapEventV3 = (overrides?: Partial<GqlPoolSwapEventV3>): GqlPoolSwapEventV3 => {
    return {
        blockNumber: overrides && overrides.hasOwnProperty('blockNumber') ? overrides.blockNumber! : 9222,
        blockTimestamp: overrides && overrides.hasOwnProperty('blockTimestamp') ? overrides.blockTimestamp! : 5370,
        chain: overrides && overrides.hasOwnProperty('chain') ? overrides.chain! : GqlChain.SONIC,
        fee: overrides && overrides.hasOwnProperty('fee') ? overrides.fee! : aGqlPoolEventAmount(),
        id: overrides && overrides.hasOwnProperty('id') ? overrides.id! : '22c54e65-0361-439f-b6fe-451c3ee62aca',
        logIndex: overrides && overrides.hasOwnProperty('logIndex') ? overrides.logIndex! : 2586,
        poolId: overrides && overrides.hasOwnProperty('poolId') ? overrides.poolId! : 'claro',
        sender: overrides && overrides.hasOwnProperty('sender') ? overrides.sender! : 'sit',
        timestamp: overrides && overrides.hasOwnProperty('timestamp') ? overrides.timestamp! : 8582,
        tokenIn: overrides && overrides.hasOwnProperty('tokenIn') ? overrides.tokenIn! : aGqlPoolEventAmount(),
        tokenOut: overrides && overrides.hasOwnProperty('tokenOut') ? overrides.tokenOut! : aGqlPoolEventAmount(),
        tx: overrides && overrides.hasOwnProperty('tx') ? overrides.tx! : 'curvo',
        type: overrides && overrides.hasOwnProperty('type') ? overrides.type! : GqlPoolEventType.ADD,
        userAddress: overrides && overrides.hasOwnProperty('userAddress') ? overrides.userAddress! : 'conor',
        valueUSD: overrides && overrides.hasOwnProperty('valueUSD') ? overrides.valueUSD! : 6.1,
    };
};

export const aGqlPoolTimePeriod = (overrides?: Partial<GqlPoolTimePeriod>): GqlPoolTimePeriod => {
    return {
        gt: overrides && overrides.hasOwnProperty('gt') ? overrides.gt! : 1642,
        lt: overrides && overrides.hasOwnProperty('lt') ? overrides.lt! : 7069,
    };
};

export const aGqlPoolTokenDetail = (overrides?: Partial<GqlPoolTokenDetail>): GqlPoolTokenDetail => {
    return {
        address: overrides && overrides.hasOwnProperty('address') ? overrides.address! : 'vestrum',
        balance: overrides && overrides.hasOwnProperty('balance') ? overrides.balance! : 'vere',
        balanceUSD: overrides && overrides.hasOwnProperty('balanceUSD') ? overrides.balanceUSD! : 'vilicus',
        canUseBufferForSwaps:
            overrides && overrides.hasOwnProperty('canUseBufferForSwaps') ? overrides.canUseBufferForSwaps! : true,
        chain: overrides && overrides.hasOwnProperty('chain') ? overrides.chain! : GqlChain.SONIC,
        chainId: overrides && overrides.hasOwnProperty('chainId') ? overrides.chainId! : 9332,
        coingeckoId: overrides && overrides.hasOwnProperty('coingeckoId') ? overrides.coingeckoId! : 'audeo',
        decimals: overrides && overrides.hasOwnProperty('decimals') ? overrides.decimals! : 4979,
        erc4626ReviewData:
            overrides && overrides.hasOwnProperty('erc4626ReviewData')
                ? overrides.erc4626ReviewData!
                : anErc4626ReviewData(),
        id: overrides && overrides.hasOwnProperty('id') ? overrides.id! : 'e40423b1-03be-4c55-bc71-724120b91514',
        index: overrides && overrides.hasOwnProperty('index') ? overrides.index! : 7065,
        isAllowed: overrides && overrides.hasOwnProperty('isAllowed') ? overrides.isAllowed! : true,
        isErc4626: overrides && overrides.hasOwnProperty('isErc4626') ? overrides.isErc4626! : false,
        isExemptFromProtocolYieldFee:
            overrides && overrides.hasOwnProperty('isExemptFromProtocolYieldFee')
                ? overrides.isExemptFromProtocolYieldFee!
                : true,
        logoURI: overrides && overrides.hasOwnProperty('logoURI') ? overrides.logoURI! : 'circumvenio',
        maxDeposit: overrides && overrides.hasOwnProperty('maxDeposit') ? overrides.maxDeposit! : 'arto',
        maxWithdraw: overrides && overrides.hasOwnProperty('maxWithdraw') ? overrides.maxWithdraw! : 'acidus',
        name: overrides && overrides.hasOwnProperty('name') ? overrides.name! : 'tergum',
        priceRate: overrides && overrides.hasOwnProperty('priceRate') ? overrides.priceRate! : 'super',
        priceRateProvider:
            overrides && overrides.hasOwnProperty('priceRateProvider') ? overrides.priceRateProvider! : 'strues',
        priceRateProviderData:
            overrides && overrides.hasOwnProperty('priceRateProviderData')
                ? overrides.priceRateProviderData!
                : aGqlPriceRateProviderData(),
        scalingFactor: overrides && overrides.hasOwnProperty('scalingFactor') ? overrides.scalingFactor! : 'apto',
        symbol: overrides && overrides.hasOwnProperty('symbol') ? overrides.symbol! : 'adsuesco',
        underlyingToken:
            overrides && overrides.hasOwnProperty('underlyingToken') ? overrides.underlyingToken! : aGqlToken(),
        useUnderlyingForAddRemove:
            overrides && overrides.hasOwnProperty('useUnderlyingForAddRemove')
                ? overrides.useUnderlyingForAddRemove!
                : false,
        useWrappedForAddRemove:
            overrides && overrides.hasOwnProperty('useWrappedForAddRemove') ? overrides.useWrappedForAddRemove! : true,
        weight: overrides && overrides.hasOwnProperty('weight') ? overrides.weight! : 'blandior',
    };
};

export const aGqlPoolUserBalance = (overrides?: Partial<GqlPoolUserBalance>): GqlPoolUserBalance => {
    return {
        stakedBalances:
            overrides && overrides.hasOwnProperty('stakedBalances')
                ? overrides.stakedBalances!
                : [aGqlUserStakedBalance()],
        totalBalance: overrides && overrides.hasOwnProperty('totalBalance') ? overrides.totalBalance! : 'abundans',
        totalBalanceUsd: overrides && overrides.hasOwnProperty('totalBalanceUsd') ? overrides.totalBalanceUsd! : 8.9,
        walletBalance: overrides && overrides.hasOwnProperty('walletBalance') ? overrides.walletBalance! : 'verus',
        walletBalanceUsd: overrides && overrides.hasOwnProperty('walletBalanceUsd') ? overrides.walletBalanceUsd! : 3.4,
    };
};

export const aGqlPoolWeighted = (overrides?: Partial<GqlPoolWeighted>): GqlPoolWeighted => {
    return {
        address: overrides && overrides.hasOwnProperty('address') ? overrides.address! : 'vox',
        chain: overrides && overrides.hasOwnProperty('chain') ? overrides.chain! : GqlChain.SONIC,
        createTime: overrides && overrides.hasOwnProperty('createTime') ? overrides.createTime! : 9021,
        decimals: overrides && overrides.hasOwnProperty('decimals') ? overrides.decimals! : 1563,
        dynamicData:
            overrides && overrides.hasOwnProperty('dynamicData') ? overrides.dynamicData! : aGqlPoolDynamicData(),
        factory: overrides && overrides.hasOwnProperty('factory') ? overrides.factory! : 'subseco',
        hasAnyAllowedBuffer:
            overrides && overrides.hasOwnProperty('hasAnyAllowedBuffer') ? overrides.hasAnyAllowedBuffer! : true,
        hasErc4626: overrides && overrides.hasOwnProperty('hasErc4626') ? overrides.hasErc4626! : true,
        hook: overrides && overrides.hasOwnProperty('hook') ? overrides.hook! : aGqlHook(),
        id: overrides && overrides.hasOwnProperty('id') ? overrides.id! : '97be5e24-4087-449c-8acb-81315052c9a8',
        liquidityManagement:
            overrides && overrides.hasOwnProperty('liquidityManagement')
                ? overrides.liquidityManagement!
                : aLiquidityManagement(),
        name: overrides && overrides.hasOwnProperty('name') ? overrides.name! : 'ab',
        pauseManager: overrides && overrides.hasOwnProperty('pauseManager') ? overrides.pauseManager! : 'surgo',
        poolCreator: overrides && overrides.hasOwnProperty('poolCreator') ? overrides.poolCreator! : 'avaritia',
        poolTokens:
            overrides && overrides.hasOwnProperty('poolTokens') ? overrides.poolTokens! : [aGqlPoolTokenDetail()],
        protocolVersion: overrides && overrides.hasOwnProperty('protocolVersion') ? overrides.protocolVersion! : 4192,
        staking: overrides && overrides.hasOwnProperty('staking') ? overrides.staking! : aGqlPoolStaking(),
        swapFeeManager: overrides && overrides.hasOwnProperty('swapFeeManager') ? overrides.swapFeeManager! : 'alius',
        symbol: overrides && overrides.hasOwnProperty('symbol') ? overrides.symbol! : 'adsuesco',
        tags: overrides && overrides.hasOwnProperty('tags') ? overrides.tags! : ['tamquam'],
        type: overrides && overrides.hasOwnProperty('type') ? overrides.type! : GqlPoolType.COMPOSABLE_STABLE,
        userBalance:
            overrides && overrides.hasOwnProperty('userBalance') ? overrides.userBalance! : aGqlPoolUserBalance(),
        version: overrides && overrides.hasOwnProperty('version') ? overrides.version! : 3149,
    };
};

export const aGqlPriceImpact = (overrides?: Partial<GqlPriceImpact>): GqlPriceImpact => {
    return {
        error: overrides && overrides.hasOwnProperty('error') ? overrides.error! : 'carmen',
        priceImpact: overrides && overrides.hasOwnProperty('priceImpact') ? overrides.priceImpact! : 'tantum',
    };
};

export const aGqlPriceRateProviderData = (overrides?: Partial<GqlPriceRateProviderData>): GqlPriceRateProviderData => {
    return {
        address: overrides && overrides.hasOwnProperty('address') ? overrides.address! : 'absque',
        factory: overrides && overrides.hasOwnProperty('factory') ? overrides.factory! : 'bibo',
        name: overrides && overrides.hasOwnProperty('name') ? overrides.name! : 'eaque',
        reviewFile: overrides && overrides.hasOwnProperty('reviewFile') ? overrides.reviewFile! : 'venio',
        reviewed: overrides && overrides.hasOwnProperty('reviewed') ? overrides.reviewed! : true,
        summary: overrides && overrides.hasOwnProperty('summary') ? overrides.summary! : 'tergo',
        upgradeableComponents:
            overrides && overrides.hasOwnProperty('upgradeableComponents')
                ? overrides.upgradeableComponents!
                : [aGqlPriceRateProviderUpgradeableComponent()],
        warnings: overrides && overrides.hasOwnProperty('warnings') ? overrides.warnings! : ['statim'],
    };
};

export const aGqlPriceRateProviderUpgradeableComponent = (
    overrides?: Partial<GqlPriceRateProviderUpgradeableComponent>,
): GqlPriceRateProviderUpgradeableComponent => {
    return {
        entryPoint: overrides && overrides.hasOwnProperty('entryPoint') ? overrides.entryPoint! : 'delicate',
        implementationReviewed:
            overrides && overrides.hasOwnProperty('implementationReviewed')
                ? overrides.implementationReviewed!
                : 'sufficio',
    };
};

export const aGqlProtocolMetricsAggregated = (
    overrides?: Partial<GqlProtocolMetricsAggregated>,
): GqlProtocolMetricsAggregated => {
    return {
        chains: overrides && overrides.hasOwnProperty('chains') ? overrides.chains! : [aGqlProtocolMetricsChain()],
        numLiquidityProviders:
            overrides && overrides.hasOwnProperty('numLiquidityProviders')
                ? overrides.numLiquidityProviders!
                : 'tabesco',
        poolCount: overrides && overrides.hasOwnProperty('poolCount') ? overrides.poolCount! : 'conturbo',
        swapFee24h: overrides && overrides.hasOwnProperty('swapFee24h') ? overrides.swapFee24h! : 'pecto',
        swapVolume24h: overrides && overrides.hasOwnProperty('swapVolume24h') ? overrides.swapVolume24h! : 'impedit',
        totalLiquidity: overrides && overrides.hasOwnProperty('totalLiquidity') ? overrides.totalLiquidity! : 'audio',
        yieldCapture24h: overrides && overrides.hasOwnProperty('yieldCapture24h') ? overrides.yieldCapture24h! : 'iste',
    };
};

export const aGqlProtocolMetricsChain = (overrides?: Partial<GqlProtocolMetricsChain>): GqlProtocolMetricsChain => {
    return {
        chainId: overrides && overrides.hasOwnProperty('chainId') ? overrides.chainId! : 'calcar',
        numLiquidityProviders:
            overrides && overrides.hasOwnProperty('numLiquidityProviders') ? overrides.numLiquidityProviders! : 'arto',
        poolCount: overrides && overrides.hasOwnProperty('poolCount') ? overrides.poolCount! : 'cicuta',
        swapFee24h: overrides && overrides.hasOwnProperty('swapFee24h') ? overrides.swapFee24h! : 'artificiose',
        swapVolume24h: overrides && overrides.hasOwnProperty('swapVolume24h') ? overrides.swapVolume24h! : 'cicuta',
        totalLiquidity:
            overrides && overrides.hasOwnProperty('totalLiquidity') ? overrides.totalLiquidity! : 'temeritas',
        yieldCapture24h:
            overrides && overrides.hasOwnProperty('yieldCapture24h') ? overrides.yieldCapture24h! : 'trepide',
    };
};

export const aGqlReliquaryFarmSnapshot = (overrides?: Partial<GqlReliquaryFarmSnapshot>): GqlReliquaryFarmSnapshot => {
    return {
        farmId: overrides && overrides.hasOwnProperty('farmId') ? overrides.farmId! : 'arca',
        id: overrides && overrides.hasOwnProperty('id') ? overrides.id! : '2bbe0f78-8fc7-4c93-a195-b52a873f3c17',
        relicCount: overrides && overrides.hasOwnProperty('relicCount') ? overrides.relicCount! : 'aetas',
        timestamp: overrides && overrides.hasOwnProperty('timestamp') ? overrides.timestamp! : 6195,
        totalBalance: overrides && overrides.hasOwnProperty('totalBalance') ? overrides.totalBalance! : 'carpo',
        totalLiquidity:
            overrides && overrides.hasOwnProperty('totalLiquidity') ? overrides.totalLiquidity! : 'adipisci',
        userCount: overrides && overrides.hasOwnProperty('userCount') ? overrides.userCount! : 'velum',
    };
};

export const aGqlSorGetSwapPaths = (overrides?: Partial<GqlSorGetSwapPaths>): GqlSorGetSwapPaths => {
    return {
        effectivePrice:
            overrides && overrides.hasOwnProperty('effectivePrice') ? overrides.effectivePrice! : 'volutabrum',
        effectivePriceReversed:
            overrides && overrides.hasOwnProperty('effectivePriceReversed')
                ? overrides.effectivePriceReversed!
                : 'contego',
        paths: overrides && overrides.hasOwnProperty('paths') ? overrides.paths! : [aGqlSorPath()],
        priceImpact: overrides && overrides.hasOwnProperty('priceImpact') ? overrides.priceImpact! : aGqlPriceImpact(),
        protocolVersion: overrides && overrides.hasOwnProperty('protocolVersion') ? overrides.protocolVersion! : 5291,
        returnAmount: overrides && overrides.hasOwnProperty('returnAmount') ? overrides.returnAmount! : 'audio',
        returnAmountRaw:
            overrides && overrides.hasOwnProperty('returnAmountRaw') ? overrides.returnAmountRaw! : 'vulgus',
        routes: overrides && overrides.hasOwnProperty('routes') ? overrides.routes! : [aGqlSorSwapRoute()],
        swapAmount: overrides && overrides.hasOwnProperty('swapAmount') ? overrides.swapAmount! : 'vigilo',
        swapAmountRaw: overrides && overrides.hasOwnProperty('swapAmountRaw') ? overrides.swapAmountRaw! : 'conatus',
        swapType: overrides && overrides.hasOwnProperty('swapType') ? overrides.swapType! : GqlSorSwapType.EXACT_IN,
        swaps: overrides && overrides.hasOwnProperty('swaps') ? overrides.swaps! : [aGqlSorSwap()],
        tokenAddresses: overrides && overrides.hasOwnProperty('tokenAddresses') ? overrides.tokenAddresses! : ['arma'],
        tokenIn: overrides && overrides.hasOwnProperty('tokenIn') ? overrides.tokenIn! : 'umbra',
        tokenInAmount: overrides && overrides.hasOwnProperty('tokenInAmount') ? overrides.tokenInAmount! : 'odit',
        tokenOut: overrides && overrides.hasOwnProperty('tokenOut') ? overrides.tokenOut! : 'argentum',
        tokenOutAmount: overrides && overrides.hasOwnProperty('tokenOutAmount') ? overrides.tokenOutAmount! : 'appono',
    };
};

export const aGqlSorPath = (overrides?: Partial<GqlSorPath>): GqlSorPath => {
    return {
        inputAmountRaw: overrides && overrides.hasOwnProperty('inputAmountRaw') ? overrides.inputAmountRaw! : 'aggero',
        isBuffer: overrides && overrides.hasOwnProperty('isBuffer') ? overrides.isBuffer! : [true],
        outputAmountRaw:
            overrides && overrides.hasOwnProperty('outputAmountRaw') ? overrides.outputAmountRaw! : 'calcar',
        pools: overrides && overrides.hasOwnProperty('pools') ? overrides.pools! : ['civis'],
        protocolVersion: overrides && overrides.hasOwnProperty('protocolVersion') ? overrides.protocolVersion! : 6867,
        tokens: overrides && overrides.hasOwnProperty('tokens') ? overrides.tokens! : [aToken()],
    };
};

export const aGqlSorSwap = (overrides?: Partial<GqlSorSwap>): GqlSorSwap => {
    return {
        amount: overrides && overrides.hasOwnProperty('amount') ? overrides.amount! : 'fugiat',
        assetInIndex: overrides && overrides.hasOwnProperty('assetInIndex') ? overrides.assetInIndex! : 4773,
        assetOutIndex: overrides && overrides.hasOwnProperty('assetOutIndex') ? overrides.assetOutIndex! : 8666,
        poolId: overrides && overrides.hasOwnProperty('poolId') ? overrides.poolId! : 'barba',
        userData: overrides && overrides.hasOwnProperty('userData') ? overrides.userData! : 'reiciendis',
    };
};

export const aGqlSorSwapRoute = (overrides?: Partial<GqlSorSwapRoute>): GqlSorSwapRoute => {
    return {
        hops: overrides && overrides.hasOwnProperty('hops') ? overrides.hops! : [aGqlSorSwapRouteHop()],
        share: overrides && overrides.hasOwnProperty('share') ? overrides.share! : 3.1,
        tokenIn: overrides && overrides.hasOwnProperty('tokenIn') ? overrides.tokenIn! : 'congregatio',
        tokenInAmount: overrides && overrides.hasOwnProperty('tokenInAmount') ? overrides.tokenInAmount! : 'aspicio',
        tokenOut: overrides && overrides.hasOwnProperty('tokenOut') ? overrides.tokenOut! : 'tutamen',
        tokenOutAmount:
            overrides && overrides.hasOwnProperty('tokenOutAmount') ? overrides.tokenOutAmount! : 'deprecator',
    };
};

export const aGqlSorSwapRouteHop = (overrides?: Partial<GqlSorSwapRouteHop>): GqlSorSwapRouteHop => {
    return {
        poolId: overrides && overrides.hasOwnProperty('poolId') ? overrides.poolId! : 'depulso',
        tokenIn: overrides && overrides.hasOwnProperty('tokenIn') ? overrides.tokenIn! : 'valens',
        tokenInAmount: overrides && overrides.hasOwnProperty('tokenInAmount') ? overrides.tokenInAmount! : 'ait',
        tokenOut: overrides && overrides.hasOwnProperty('tokenOut') ? overrides.tokenOut! : 'arto',
        tokenOutAmount: overrides && overrides.hasOwnProperty('tokenOutAmount') ? overrides.tokenOutAmount! : 'dolor',
    };
};

export const aGqlStakedSonicData = (overrides?: Partial<GqlStakedSonicData>): GqlStakedSonicData => {
    return {
        delegatedValidators:
            overrides && overrides.hasOwnProperty('delegatedValidators')
                ? overrides.delegatedValidators!
                : [aGqlStakedSonicDelegatedValidator()],
        exchangeRate: overrides && overrides.hasOwnProperty('exchangeRate') ? overrides.exchangeRate! : 'delego',
        protocolFee24h:
            overrides && overrides.hasOwnProperty('protocolFee24h') ? overrides.protocolFee24h! : 'laboriosam',
        rewardsClaimed24h:
            overrides && overrides.hasOwnProperty('rewardsClaimed24h') ? overrides.rewardsClaimed24h! : 'dignissimos',
        stakingApr: overrides && overrides.hasOwnProperty('stakingApr') ? overrides.stakingApr! : 'ut',
        totalAssets: overrides && overrides.hasOwnProperty('totalAssets') ? overrides.totalAssets! : 'contabesco',
        totalAssetsDelegated:
            overrides && overrides.hasOwnProperty('totalAssetsDelegated') ? overrides.totalAssetsDelegated! : 'crebro',
        totalAssetsPool: overrides && overrides.hasOwnProperty('totalAssetsPool') ? overrides.totalAssetsPool! : 'ait',
    };
};

export const aGqlStakedSonicDelegatedValidator = (
    overrides?: Partial<GqlStakedSonicDelegatedValidator>,
): GqlStakedSonicDelegatedValidator => {
    return {
        assetsDelegated:
            overrides && overrides.hasOwnProperty('assetsDelegated') ? overrides.assetsDelegated! : 'derelinquo',
        validatorId: overrides && overrides.hasOwnProperty('validatorId') ? overrides.validatorId! : 'assentator',
    };
};

export const aGqlToken = (overrides?: Partial<GqlToken>): GqlToken => {
    return {
        address: overrides && overrides.hasOwnProperty('address') ? overrides.address! : 'vinculum',
        chain: overrides && overrides.hasOwnProperty('chain') ? overrides.chain! : GqlChain.SONIC,
        chainId: overrides && overrides.hasOwnProperty('chainId') ? overrides.chainId! : 8759,
        coingeckoId: overrides && overrides.hasOwnProperty('coingeckoId') ? overrides.coingeckoId! : 'clibanus',
        decimals: overrides && overrides.hasOwnProperty('decimals') ? overrides.decimals! : 5655,
        description: overrides && overrides.hasOwnProperty('description') ? overrides.description! : 'arma',
        discordUrl: overrides && overrides.hasOwnProperty('discordUrl') ? overrides.discordUrl! : 'volutabrum',
        erc4626ReviewData:
            overrides && overrides.hasOwnProperty('erc4626ReviewData')
                ? overrides.erc4626ReviewData!
                : anErc4626ReviewData(),
        isBufferAllowed: overrides && overrides.hasOwnProperty('isBufferAllowed') ? overrides.isBufferAllowed! : true,
        isErc4626: overrides && overrides.hasOwnProperty('isErc4626') ? overrides.isErc4626! : true,
        logoURI: overrides && overrides.hasOwnProperty('logoURI') ? overrides.logoURI! : 'calco',
        maxDeposit: overrides && overrides.hasOwnProperty('maxDeposit') ? overrides.maxDeposit! : 'ultra',
        name: overrides && overrides.hasOwnProperty('name') ? overrides.name! : 'bos',
        priceRateProviderData:
            overrides && overrides.hasOwnProperty('priceRateProviderData')
                ? overrides.priceRateProviderData!
                : aGqlPriceRateProviderData(),
        priority: overrides && overrides.hasOwnProperty('priority') ? overrides.priority! : 6873,
        symbol: overrides && overrides.hasOwnProperty('symbol') ? overrides.symbol! : 'torqueo',
        telegramUrl: overrides && overrides.hasOwnProperty('telegramUrl') ? overrides.telegramUrl! : 'accusamus',
        tradable: overrides && overrides.hasOwnProperty('tradable') ? overrides.tradable! : false,
        twitterUsername:
            overrides && overrides.hasOwnProperty('twitterUsername') ? overrides.twitterUsername! : 'antepono',
        types: overrides && overrides.hasOwnProperty('types') ? overrides.types! : [GqlTokenType.BLOCKED_V2],
        underlyingTokenAddress:
            overrides && overrides.hasOwnProperty('underlyingTokenAddress')
                ? overrides.underlyingTokenAddress!
                : 'victus',
        websiteUrl: overrides && overrides.hasOwnProperty('websiteUrl') ? overrides.websiteUrl! : 'asporto',
    };
};

export const aGqlTokenAmountHumanReadable = (
    overrides?: Partial<GqlTokenAmountHumanReadable>,
): GqlTokenAmountHumanReadable => {
    return {
        address: overrides && overrides.hasOwnProperty('address') ? overrides.address! : 'ducimus',
        amount: overrides && overrides.hasOwnProperty('amount') ? overrides.amount! : 'thesis',
    };
};

export const aGqlTokenFilter = (overrides?: Partial<GqlTokenFilter>): GqlTokenFilter => {
    return {
        tokensIn: overrides && overrides.hasOwnProperty('tokensIn') ? overrides.tokensIn! : ['talus'],
        typeIn: overrides && overrides.hasOwnProperty('typeIn') ? overrides.typeIn! : [GqlTokenType.BLOCKED_V2],
    };
};

export const aGqlTokenMutationResult = (overrides?: Partial<GqlTokenMutationResult>): GqlTokenMutationResult => {
    return {
        chain: overrides && overrides.hasOwnProperty('chain') ? overrides.chain! : GqlChain.SONIC,
        error: overrides && overrides.hasOwnProperty('error') ? overrides.error! : 'eos',
        success: overrides && overrides.hasOwnProperty('success') ? overrides.success! : false,
    };
};

export const aGqlTokenPrice = (overrides?: Partial<GqlTokenPrice>): GqlTokenPrice => {
    return {
        address: overrides && overrides.hasOwnProperty('address') ? overrides.address! : 'surculus',
        chain: overrides && overrides.hasOwnProperty('chain') ? overrides.chain! : GqlChain.SONIC,
        price: overrides && overrides.hasOwnProperty('price') ? overrides.price! : 9.5,
        updatedAt: overrides && overrides.hasOwnProperty('updatedAt') ? overrides.updatedAt! : 1169,
        updatedBy: overrides && overrides.hasOwnProperty('updatedBy') ? overrides.updatedBy! : 'dignissimos',
    };
};

export const aGqlUserStakedBalance = (overrides?: Partial<GqlUserStakedBalance>): GqlUserStakedBalance => {
    return {
        balance: overrides && overrides.hasOwnProperty('balance') ? overrides.balance! : 'iusto',
        balanceUsd: overrides && overrides.hasOwnProperty('balanceUsd') ? overrides.balanceUsd! : 2.3,
        stakingId: overrides && overrides.hasOwnProperty('stakingId') ? overrides.stakingId! : 'nostrum',
        stakingType:
            overrides && overrides.hasOwnProperty('stakingType') ? overrides.stakingType! : GqlPoolStakingType.GAUGE,
    };
};

export const aHookConfig = (overrides?: Partial<HookConfig>): HookConfig => {
    return {
        enableHookAdjustedAmounts:
            overrides && overrides.hasOwnProperty('enableHookAdjustedAmounts')
                ? overrides.enableHookAdjustedAmounts!
                : true,
        shouldCallAfterAddLiquidity:
            overrides && overrides.hasOwnProperty('shouldCallAfterAddLiquidity')
                ? overrides.shouldCallAfterAddLiquidity!
                : false,
        shouldCallAfterInitialize:
            overrides && overrides.hasOwnProperty('shouldCallAfterInitialize')
                ? overrides.shouldCallAfterInitialize!
                : true,
        shouldCallAfterRemoveLiquidity:
            overrides && overrides.hasOwnProperty('shouldCallAfterRemoveLiquidity')
                ? overrides.shouldCallAfterRemoveLiquidity!
                : true,
        shouldCallAfterSwap:
            overrides && overrides.hasOwnProperty('shouldCallAfterSwap') ? overrides.shouldCallAfterSwap! : false,
        shouldCallBeforeAddLiquidity:
            overrides && overrides.hasOwnProperty('shouldCallBeforeAddLiquidity')
                ? overrides.shouldCallBeforeAddLiquidity!
                : true,
        shouldCallBeforeInitialize:
            overrides && overrides.hasOwnProperty('shouldCallBeforeInitialize')
                ? overrides.shouldCallBeforeInitialize!
                : true,
        shouldCallBeforeRemoveLiquidity:
            overrides && overrides.hasOwnProperty('shouldCallBeforeRemoveLiquidity')
                ? overrides.shouldCallBeforeRemoveLiquidity!
                : false,
        shouldCallBeforeSwap:
            overrides && overrides.hasOwnProperty('shouldCallBeforeSwap') ? overrides.shouldCallBeforeSwap! : true,
        shouldCallComputeDynamicSwapFee:
            overrides && overrides.hasOwnProperty('shouldCallComputeDynamicSwapFee')
                ? overrides.shouldCallComputeDynamicSwapFee!
                : false,
    };
};

export const aLbpMetadataInput = (overrides?: Partial<LbpMetadataInput>): LbpMetadataInput => {
    return {
        description: overrides && overrides.hasOwnProperty('description') ? overrides.description! : 'mollitia',
        discord: overrides && overrides.hasOwnProperty('discord') ? overrides.discord! : 'usque',
        farcaster: overrides && overrides.hasOwnProperty('farcaster') ? overrides.farcaster! : 'conqueror',
        lbpName: overrides && overrides.hasOwnProperty('lbpName') ? overrides.lbpName! : 'damno',
        telegram: overrides && overrides.hasOwnProperty('telegram') ? overrides.telegram! : 'utpote',
        tokenLogo: overrides && overrides.hasOwnProperty('tokenLogo') ? overrides.tokenLogo! : 'celo',
        website: overrides && overrides.hasOwnProperty('website') ? overrides.website! : 'voveo',
        x: overrides && overrides.hasOwnProperty('x') ? overrides.x! : 'cui',
    };
};

export const aLbpPriceChartData = (overrides?: Partial<LbpPriceChartData>): LbpPriceChartData => {
    return {
        buyVolume: overrides && overrides.hasOwnProperty('buyVolume') ? overrides.buyVolume! : 2.2,
        cumulativeFees: overrides && overrides.hasOwnProperty('cumulativeFees') ? overrides.cumulativeFees! : 4.7,
        cumulativeVolume: overrides && overrides.hasOwnProperty('cumulativeVolume') ? overrides.cumulativeVolume! : 0.6,
        fees: overrides && overrides.hasOwnProperty('fees') ? overrides.fees! : 9.3,
        projectTokenBalance:
            overrides && overrides.hasOwnProperty('projectTokenBalance') ? overrides.projectTokenBalance! : 9.7,
        projectTokenPrice:
            overrides && overrides.hasOwnProperty('projectTokenPrice') ? overrides.projectTokenPrice! : 5.9,
        reservePrice: overrides && overrides.hasOwnProperty('reservePrice') ? overrides.reservePrice! : 6.5,
        reserveTokenBalance:
            overrides && overrides.hasOwnProperty('reserveTokenBalance') ? overrides.reserveTokenBalance! : 6.3,
        sellVolume: overrides && overrides.hasOwnProperty('sellVolume') ? overrides.sellVolume! : 7.4,
        swapCount: overrides && overrides.hasOwnProperty('swapCount') ? overrides.swapCount! : 1390,
        timestamp: overrides && overrides.hasOwnProperty('timestamp') ? overrides.timestamp! : 8936,
        tvl: overrides && overrides.hasOwnProperty('tvl') ? overrides.tvl! : 9.4,
        volume: overrides && overrides.hasOwnProperty('volume') ? overrides.volume! : 3.4,
    };
};

export const aLbPoolInput = (overrides?: Partial<LbPoolInput>): LbPoolInput => {
    return {
        address: overrides && overrides.hasOwnProperty('address') ? overrides.address! : 'sursum',
        chain: overrides && overrides.hasOwnProperty('chain') ? overrides.chain! : GqlChain.SONIC,
    };
};

export const aLiquidityBootstrappingPoolV3Params = (
    overrides?: Partial<LiquidityBootstrappingPoolV3Params>,
): LiquidityBootstrappingPoolV3Params => {
    return {
        endTime: overrides && overrides.hasOwnProperty('endTime') ? overrides.endTime! : 4758,
        startTime: overrides && overrides.hasOwnProperty('startTime') ? overrides.startTime! : 1614,
    };
};

export const aLiquidityManagement = (overrides?: Partial<LiquidityManagement>): LiquidityManagement => {
    return {
        disableUnbalancedLiquidity:
            overrides && overrides.hasOwnProperty('disableUnbalancedLiquidity')
                ? overrides.disableUnbalancedLiquidity!
                : true,
        enableAddLiquidityCustom:
            overrides && overrides.hasOwnProperty('enableAddLiquidityCustom')
                ? overrides.enableAddLiquidityCustom!
                : false,
        enableDonation: overrides && overrides.hasOwnProperty('enableDonation') ? overrides.enableDonation! : false,
        enableRemoveLiquidityCustom:
            overrides && overrides.hasOwnProperty('enableRemoveLiquidityCustom')
                ? overrides.enableRemoveLiquidityCustom!
                : false,
    };
};

export const aMevTaxHookParams = (overrides?: Partial<MevTaxHookParams>): MevTaxHookParams => {
    return {
        maxMevSwapFeePercentage:
            overrides && overrides.hasOwnProperty('maxMevSwapFeePercentage')
                ? overrides.maxMevSwapFeePercentage!
                : 'ancilla',
        mevTaxMultiplier:
            overrides && overrides.hasOwnProperty('mevTaxMultiplier') ? overrides.mevTaxMultiplier! : 'adhuc',
        mevTaxThreshold:
            overrides && overrides.hasOwnProperty('mevTaxThreshold') ? overrides.mevTaxThreshold! : 'crapula',
    };
};

export const aMutation = (overrides?: Partial<Mutation>): Mutation => {
    return {
        createLBP: overrides && overrides.hasOwnProperty('createLBP') ? overrides.createLBP! : true,
        lbpReloadFixedLbps:
            overrides && overrides.hasOwnProperty('lbpReloadFixedLbps') ? overrides.lbpReloadFixedLbps! : 'clamo',
        lbpReloadLbps: overrides && overrides.hasOwnProperty('lbpReloadLbps') ? overrides.lbpReloadLbps! : 'summa',
        poolLoadOnChainDataForAllPools:
            overrides && overrides.hasOwnProperty('poolLoadOnChainDataForAllPools')
                ? overrides.poolLoadOnChainDataForAllPools!
                : [aGqlPoolMutationResult()],
        poolLoadSnapshotsForPools:
            overrides && overrides.hasOwnProperty('poolLoadSnapshotsForPools')
                ? overrides.poolLoadSnapshotsForPools!
                : 'quidem',
        poolReloadAllPoolAprs:
            overrides && overrides.hasOwnProperty('poolReloadAllPoolAprs')
                ? overrides.poolReloadAllPoolAprs!
                : 'ducimus',
        poolReloadPools:
            overrides && overrides.hasOwnProperty('poolReloadPools')
                ? overrides.poolReloadPools!
                : [aGqlPoolMutationResult()],
        poolReloadStakingForAllPools:
            overrides && overrides.hasOwnProperty('poolReloadStakingForAllPools')
                ? overrides.poolReloadStakingForAllPools!
                : 'anser',
        poolReloadSwaps:
            overrides && overrides.hasOwnProperty('poolReloadSwaps') ? overrides.poolReloadSwaps! : 'cubitum',
        poolSyncAllPoolsFromSubgraph:
            overrides && overrides.hasOwnProperty('poolSyncAllPoolsFromSubgraph')
                ? overrides.poolSyncAllPoolsFromSubgraph!
                : ['quos'],
        protocolCacheMetrics:
            overrides && overrides.hasOwnProperty('protocolCacheMetrics') ? overrides.protocolCacheMetrics! : 'creator',
        tokenDeleteTokenType:
            overrides && overrides.hasOwnProperty('tokenDeleteTokenType')
                ? overrides.tokenDeleteTokenType!
                : 'summisse',
        tokenReloadAllTokenTypes:
            overrides && overrides.hasOwnProperty('tokenReloadAllTokenTypes')
                ? overrides.tokenReloadAllTokenTypes!
                : 'placeat',
        tokenReloadErc4626Tokens:
            overrides && overrides.hasOwnProperty('tokenReloadErc4626Tokens')
                ? overrides.tokenReloadErc4626Tokens!
                : [aGqlTokenMutationResult()],
        tokenReloadTokenPrices:
            overrides && overrides.hasOwnProperty('tokenReloadTokenPrices') ? overrides.tokenReloadTokenPrices! : false,
        tokenSyncTokenDefinitions:
            overrides && overrides.hasOwnProperty('tokenSyncTokenDefinitions')
                ? overrides.tokenSyncTokenDefinitions!
                : 'cultellus',
        userInitStakedBalances:
            overrides && overrides.hasOwnProperty('userInitStakedBalances')
                ? overrides.userInitStakedBalances!
                : 'contigo',
        userInitWalletBalancesForAllPools:
            overrides && overrides.hasOwnProperty('userInitWalletBalancesForAllPools')
                ? overrides.userInitWalletBalancesForAllPools!
                : 'absens',
        userSyncChangedStakedBalances:
            overrides && overrides.hasOwnProperty('userSyncChangedStakedBalances')
                ? overrides.userSyncChangedStakedBalances!
                : 'porro',
        userSyncChangedWalletBalancesForAllPools:
            overrides && overrides.hasOwnProperty('userSyncChangedWalletBalancesForAllPools')
                ? overrides.userSyncChangedWalletBalancesForAllPools!
                : 'apud',
    };
};

export const aQuantAmmWeightedDetail = (overrides?: Partial<QuantAmmWeightedDetail>): QuantAmmWeightedDetail => {
    return {
        category: overrides && overrides.hasOwnProperty('category') ? overrides.category! : 'perferendis',
        name: overrides && overrides.hasOwnProperty('name') ? overrides.name! : 'brevis',
        type: overrides && overrides.hasOwnProperty('type') ? overrides.type! : 'angustus',
        value: overrides && overrides.hasOwnProperty('value') ? overrides.value! : 'ventito',
    };
};

export const aQuantAmmWeightSnapshot = (overrides?: Partial<QuantAmmWeightSnapshot>): QuantAmmWeightSnapshot => {
    return {
        timestamp: overrides && overrides.hasOwnProperty('timestamp') ? overrides.timestamp! : 8852,
        weights: overrides && overrides.hasOwnProperty('weights') ? overrides.weights! : [9.6],
    };
};

export const aQuantAmmWeightedParams = (overrides?: Partial<QuantAmmWeightedParams>): QuantAmmWeightedParams => {
    return {
        absoluteWeightGuardRail:
            overrides && overrides.hasOwnProperty('absoluteWeightGuardRail')
                ? overrides.absoluteWeightGuardRail!
                : 'supellex',
        details: overrides && overrides.hasOwnProperty('details') ? overrides.details! : [aQuantAmmWeightedDetail()],
        epsilonMax: overrides && overrides.hasOwnProperty('epsilonMax') ? overrides.epsilonMax! : 'deludo',
        lambda: overrides && overrides.hasOwnProperty('lambda') ? overrides.lambda! : ['comminor'],
        lastInterpolationTimePossible:
            overrides && overrides.hasOwnProperty('lastInterpolationTimePossible')
                ? overrides.lastInterpolationTimePossible!
                : 'appono',
        lastUpdateIntervalTime:
            overrides && overrides.hasOwnProperty('lastUpdateIntervalTime')
                ? overrides.lastUpdateIntervalTime!
                : 'vesica',
        maxTradeSizeRatio:
            overrides && overrides.hasOwnProperty('maxTradeSizeRatio') ? overrides.maxTradeSizeRatio! : 'basium',
        oracleStalenessThreshold:
            overrides && overrides.hasOwnProperty('oracleStalenessThreshold')
                ? overrides.oracleStalenessThreshold!
                : 'odit',
        poolRegistry: overrides && overrides.hasOwnProperty('poolRegistry') ? overrides.poolRegistry! : 'venustas',
        updateInterval: overrides && overrides.hasOwnProperty('updateInterval') ? overrides.updateInterval! : 'bis',
        weightBlockMultipliers:
            overrides && overrides.hasOwnProperty('weightBlockMultipliers')
                ? overrides.weightBlockMultipliers!
                : ['suscipit'],
        weightsAtLastUpdateInterval:
            overrides && overrides.hasOwnProperty('weightsAtLastUpdateInterval')
                ? overrides.weightsAtLastUpdateInterval!
                : ['aegrus'],
    };
};

export const aQuery = (overrides?: Partial<Query>): Query => {
    return {
        aggregatorPools:
            overrides && overrides.hasOwnProperty('aggregatorPools')
                ? overrides.aggregatorPools!
                : [aGqlPoolAggregator()],
        beetsPoolGetReliquaryFarmSnapshots:
            overrides && overrides.hasOwnProperty('beetsPoolGetReliquaryFarmSnapshots')
                ? overrides.beetsPoolGetReliquaryFarmSnapshots!
                : [aGqlReliquaryFarmSnapshot()],
        fixedLbpPriceChart:
            overrides && overrides.hasOwnProperty('fixedLbpPriceChart')
                ? overrides.fixedLbpPriceChart!
                : [aLbpPriceChartData()],
        lbpPriceChart:
            overrides && overrides.hasOwnProperty('lbpPriceChart') ? overrides.lbpPriceChart! : [aLbpPriceChartData()],
        loopsGetData: overrides && overrides.hasOwnProperty('loopsGetData') ? overrides.loopsGetData! : aGqlLoopsData(),
        poolEvents: overrides && overrides.hasOwnProperty('poolEvents') ? overrides.poolEvents! : [aGqlPoolEvent()],
        poolGetFeaturedPools:
            overrides && overrides.hasOwnProperty('poolGetFeaturedPools')
                ? overrides.poolGetFeaturedPools!
                : [aGqlPoolFeaturedPool()],
        poolGetPool: overrides && overrides.hasOwnProperty('poolGetPool') ? overrides.poolGetPool! : aGqlPoolBase(),
        poolGetPools:
            overrides && overrides.hasOwnProperty('poolGetPools') ? overrides.poolGetPools! : [aGqlPoolMinimal()],
        poolGetPoolsCount:
            overrides && overrides.hasOwnProperty('poolGetPoolsCount') ? overrides.poolGetPoolsCount! : 5502,
        poolGetSnapshots:
            overrides && overrides.hasOwnProperty('poolGetSnapshots')
                ? overrides.poolGetSnapshots!
                : [aGqlPoolSnapshot()],
        protocolMetricsAggregated:
            overrides && overrides.hasOwnProperty('protocolMetricsAggregated')
                ? overrides.protocolMetricsAggregated!
                : aGqlProtocolMetricsAggregated(),
        protocolMetricsChain:
            overrides && overrides.hasOwnProperty('protocolMetricsChain')
                ? overrides.protocolMetricsChain!
                : aGqlProtocolMetricsChain(),
        sorGetSwapPaths:
            overrides && overrides.hasOwnProperty('sorGetSwapPaths')
                ? overrides.sorGetSwapPaths!
                : aGqlSorGetSwapPaths(),
        stsGetGqlStakedSonicData:
            overrides && overrides.hasOwnProperty('stsGetGqlStakedSonicData')
                ? overrides.stsGetGqlStakedSonicData!
                : aGqlStakedSonicData(),
        tokenGetCurrentPrices:
            overrides && overrides.hasOwnProperty('tokenGetCurrentPrices')
                ? overrides.tokenGetCurrentPrices!
                : [aGqlTokenPrice()],
        tokenGetTokens:
            overrides && overrides.hasOwnProperty('tokenGetTokens') ? overrides.tokenGetTokens! : [aGqlToken()],
    };
};

export const aStableSurgeHookParams = (overrides?: Partial<StableSurgeHookParams>): StableSurgeHookParams => {
    return {
        maxSurgeFeePercentage:
            overrides && overrides.hasOwnProperty('maxSurgeFeePercentage')
                ? overrides.maxSurgeFeePercentage!
                : 'demonstro',
        surgeThresholdPercentage:
            overrides && overrides.hasOwnProperty('surgeThresholdPercentage')
                ? overrides.surgeThresholdPercentage!
                : 'pectus',
    };
};

export const aToken = (overrides?: Partial<Token>): Token => {
    return {
        address: overrides && overrides.hasOwnProperty('address') ? overrides.address! : 'super',
        decimals: overrides && overrides.hasOwnProperty('decimals') ? overrides.decimals! : 2903,
    };
};
