import { PrismaToken } from '@prisma/client';
import { Factory } from 'fishery';
import { createRandomAddress } from '../utils';
import { PrismaPoolTokenWithDynamicData } from '../../prisma/prisma-types';
import { ZERO_ADDRESS } from '@balancer/sdk';

export const prismaPoolTokenFactory = Factory.define<PrismaPoolTokenWithDynamicData>(({ sequence, params }) => {
    const tokenAddress = params?.address || createRandomAddress();
    const poolId = params?.poolId || createRandomAddress();
    const decimals = params?.token?.decimals ?? 18;
    const chain = params?.chain ?? 'SONIC';
    return {
        id: poolId + '-' + tokenAddress,
        address: tokenAddress,
        poolId: poolId,
        chain: 'SONIC',
        index: sequence ? sequence - 1 : 0,
        priceRateProvider: ZERO_ADDRESS,
        exemptFromProtocolYieldFee: false,
        token: prismaTokenFactory.build({ address: tokenAddress, decimals, chain }),
        balance: '10.000000000000000000',
        balanceUSD: 10,
        weight: '0.5',
        priceRate: '1',
        scalingFactor: null,
        updatedAt: new Date(),
    };
});

export const prismaTokenFactory = Factory.define<PrismaToken>(() => {
    return {
        address: createRandomAddress(),
        chain: 'SONIC',
        symbol: 'TestToken',
        name: 'testToken',
        description: '',
        decimals: 18,
        logoURI: '',
        websiteUrl: '',
        discordUrl: '',
        telegramUrl: null,
        twitterUsername: null,
        coingeckoTokenId: null,
        priority: 0,
        coingeckoPlatformId: null,
        excludedFromCoingecko: false,
        underlyingTokenAddress: null,
        isBufferAllowed: true,
        unwrapRate: '1',
        maxDeposit: '0',
        maxWithdraw: '0',
        bufferBalanceUnderlying: '0',
        bufferBalanceWrapped: '0',
        tvl: 0,
    };
});
