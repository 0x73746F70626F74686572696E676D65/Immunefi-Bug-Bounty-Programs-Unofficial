__all__ = ["TrimmedAmountLib"]
