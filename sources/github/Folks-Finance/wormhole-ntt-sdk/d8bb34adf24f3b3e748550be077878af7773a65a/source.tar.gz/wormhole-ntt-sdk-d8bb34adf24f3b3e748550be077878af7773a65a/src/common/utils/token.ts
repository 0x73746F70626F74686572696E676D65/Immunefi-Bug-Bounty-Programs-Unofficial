import { isAddressEqual } from "viem";

import { FolksCore } from "../../ntt/core/folks-core.js";
import { AddressType } from "../types/address.js";
import { ChainType } from "../types/chain.js";

import { convertFromGenericAddress } from "./address.js";
import { getFolksChain } from "./chain.js";
import { exhaustiveCheck } from "./exhaustive-check.js";
import { doesTransferHaveDust } from "./formulae.js";

import type { GenericAddress } from "../types/address.js";
import type { FolksChainId, AVMChainType, EVMChainType, FolksChainIdType } from "../types/chain.js";
import type { ChainToken, NTTTokenId } from "../types/ntt.js";

export function isNttTokenSupported(nttTokenId: NTTTokenId, folksChainId: FolksChainId): boolean {
  return FolksCore.getTokens(folksChainId).find((token) => token.nttTokenId === nttTokenId) !== undefined;
}

export function assertNttTokenSupported(nttTokenId: NTTTokenId, folksChainId: FolksChainId): void {
  if (!isNttTokenSupported(nttTokenId, folksChainId)) {
    throw new Error(`NTT Token ${nttTokenId} not found for chain ${folksChainId}`);
  }
}

export function getNttChainToken<T extends ChainType>(
  nttTokenId: NTTTokenId,
  folksChainId: FolksChainIdType<T>,
): ChainToken<T> {
  return FolksCore.getToken<T>(folksChainId, nttTokenId);
}

export function isWrappedNttToken<T extends ChainType>(
  nttTokenId: NTTTokenId,
  folksChainId: FolksChainIdType<T>,
): boolean {
  const { chainType } = getFolksChain(folksChainId);

  switch (chainType) {
    case ChainType.EVM: {
      const token = FolksCore.getToken(folksChainId, nttTokenId) as ChainToken<EVMChainType>;
      return token.wrappedNttTokenId !== undefined;
    }
    case ChainType.AVM: {
      return false;
    }
    default:
      return exhaustiveCheck(chainType);
  }
}

export function getWrappedNttTokenId<T extends ChainType>(
  nttTokenId: NTTTokenId,
  folksChainId: FolksChainIdType<T>,
): NTTTokenId {
  const { chainType } = getFolksChain(folksChainId);

  let wrappedNttTokenId: NTTTokenId | undefined;
  switch (chainType) {
    case ChainType.EVM: {
      const token = FolksCore.getToken(folksChainId, nttTokenId) as ChainToken<EVMChainType>;
      wrappedNttTokenId = token.wrappedNttTokenId;
      break;
    }
    case ChainType.AVM: {
      break;
    }
    default:
      return exhaustiveCheck(chainType);
  }

  if (!wrappedNttTokenId)
    throw new Error(`Wrapped NTT Token Id not found for ${nttTokenId} on folks chain ${folksChainId}`);
  return wrappedNttTokenId;
}

export function isAddressAnNttToken(folksChainId: FolksChainId, address: GenericAddress): boolean {
  const { chainType } = getFolksChain(folksChainId);
  const nttTokens = FolksCore.getTokens(folksChainId);

  switch (chainType) {
    case ChainType.EVM: {
      const tokenAddress = convertFromGenericAddress(address, chainType, AddressType.TOKEN);
      return nttTokens.some((nttToken) =>
        isAddressEqual(tokenAddress, (nttToken as ChainToken<EVMChainType>).nttTokenAddress),
      );
    }
    case ChainType.AVM: {
      const tokenAddress = convertFromGenericAddress(address, chainType, AddressType.TOKEN);
      return nttTokens.some((nttToken) => tokenAddress === (nttToken as ChainToken<AVMChainType>).assetId);
    }
    default:
      return exhaustiveCheck(chainType);
  }
}

export function getNttTokenFromAddress<T extends ChainType>(
  folksChainId: FolksChainIdType<T>,
  address: GenericAddress,
): ChainToken<T> {
  const { chainType } = getFolksChain(folksChainId);
  const nttTokens = FolksCore.getTokens<T>(folksChainId);

  let chainToken: ChainToken<T> | undefined;
  switch (chainType) {
    case ChainType.EVM: {
      const tokenAddress = convertFromGenericAddress(address, chainType, AddressType.TOKEN);
      chainToken = nttTokens.find((nttToken) =>
        isAddressEqual(tokenAddress, (nttToken as ChainToken<EVMChainType>).nttTokenAddress),
      );
      break;
    }
    case ChainType.AVM: {
      const tokenAddress = convertFromGenericAddress(address, chainType, AddressType.TOKEN);
      chainToken = nttTokens.find((nttToken) => tokenAddress === (nttToken as ChainToken<AVMChainType>).assetId);
      break;
    }
    default:
      return exhaustiveCheck(chainType);
  }

  if (!chainToken) throw new Error(`NTT Token not found for ${address} on folks chain ${folksChainId}`);
  return chainToken;
}

export function assertTransferHasZeroDust(
  nttTokenId: NTTTokenId,
  sourceFolksChainId: FolksChainId,
  destFolksChainId: FolksChainId,
  amount: bigint,
) {
  const { decimals: sourceDecimals } = getNttChainToken(nttTokenId, sourceFolksChainId);
  const destNttTokenId = isWrappedNttToken(nttTokenId, sourceFolksChainId)
    ? getWrappedNttTokenId(nttTokenId, sourceFolksChainId)
    : nttTokenId;
  const { decimals: destDecimals } = getNttChainToken(destNttTokenId, destFolksChainId);

  if (doesTransferHaveDust(amount, sourceDecimals, destDecimals))
    throw new Error(
      `Amount ${amount} has dust when transferring from chain with ${sourceDecimals} decimals to chain with ${destDecimals} decimals`,
    );
}
