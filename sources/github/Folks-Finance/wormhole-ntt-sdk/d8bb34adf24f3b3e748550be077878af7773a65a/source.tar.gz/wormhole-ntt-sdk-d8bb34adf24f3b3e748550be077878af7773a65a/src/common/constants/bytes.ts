export const UINT8_LENGTH = 1;

export const UINT16_LENGTH = 2;

export const UINT64_LENGTH = 8;

export const UINT128_LENGTH = 16;

export const UINT256_LENGTH = 32;

export const BYTES4_LENGTH = 4;

export const BYTES16_LENGTH = 16;

export const BYTES32_LENGTH = 32;

export const BYTES64_LENGTH = 64;

export const EVM_ADDRESS_BYTES_LENGTH = 20;
