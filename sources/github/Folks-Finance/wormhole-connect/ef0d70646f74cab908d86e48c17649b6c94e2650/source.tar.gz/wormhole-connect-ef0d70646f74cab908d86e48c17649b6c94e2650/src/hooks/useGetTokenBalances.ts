import { useEffect, useState, useRef, useCallback, useMemo } from 'react';
import type { Balances } from 'utils/wallet/types';
import config, { getWormholeContextV2 } from 'config';
import type { Token } from 'config/tokens';
import { chainToPlatform } from '@wormhole-foundation/sdk-base';
import type { Chain } from '@wormhole-foundation/sdk';
import {
  Wormhole,
  amount,
  supportsIndexerUtils,
} from '@wormhole-foundation/sdk';
import type { WalletData } from 'store/wallet';
import { useTokens } from 'contexts/TokensContext';
import { processBatches } from 'utils/batch';
import { getCached, isFailed, markFailed, setCached } from 'utils/balanceCache';

export interface ChainBalanceRequest {
  chain: Chain;
  wallet: WalletData;
  tokens: Token[];
}

// Map of chain+wallet -> balances
type BalanceMap = Record<string, Balances>;

// Constants
const BATCH_SIZE = 5;
const BATCH_DELAY_MS = 100;
const MAX_TOKENS_TO_PROCESS = 100;

// Helper to create request key
const getRequestKey = (chain: Chain, wallet: WalletData) =>
  `${chain}-${wallet.address}`;

interface UseGetTokenBalancesParams {
  source?: ChainBalanceRequest;
  destination?: ChainBalanceRequest;
}

interface ChainBalanceResult {
  balances: Balances;
}

interface UseGetTokenBalancesResult {
  isFetching: boolean;
  source: ChainBalanceResult;
  destination: ChainBalanceResult;
}

const useGetTokenBalances = ({
  source,
  destination,
}: UseGetTokenBalancesParams): UseGetTokenBalancesResult => {
  const [balances, setBalances] = useState<BalanceMap>({});
  const [fetchingKeys, setFetchingKeys] = useState<Set<string>>(new Set());

  const { getOrFetchToken } = useTokens();

  // Keep track of current request keys to avoid stale updates
  const currentRequestKeysRef = useRef<Set<string>>(new Set());

  // Process results from indexer
  const processIndexerResults = useCallback(
    async (
      result: Record<string, bigint | null>,
      chain: Chain,
      wallet: WalletData,
      updatedBalances: Balances,
      tokensToFetch: Token[],
    ) => {
      // Sort tokens by balance units to prioritize tokens that are likely higher value
      const sortedTokens = Object.entries(result)
        .filter(([_, bus]) => bus !== null && bus > 1n)
        .sort(([, a], [, b]) => {
          const balanceA = a ?? 0n;
          const balanceB = b ?? 0n;
          return balanceA > balanceB ? -1 : balanceA < balanceB ? 1 : 0;
        });

      const unknownTokens: Array<[string, bigint]> = [];

      // Process known tokens
      for (const [address, bus] of sortedTokens) {
        if (bus === null) continue;

        const token = config.tokens.get(chain, address);
        if (token) {
          const balance = amount.fromBaseUnits(bus, token.decimals);
          const balanceData = {
            balance,
            lastUpdated: Date.now(),
          };
          updatedBalances[token.key] = balanceData;
          setCached(wallet, token, balance);
        } else if (!isFailed(chain, address)) {
          unknownTokens.push([address, bus]);
        }
      }

      // Process unknown tokens in batches
      if (unknownTokens.length > 0) {
        await processBatches(
          unknownTokens,
          async ([tokenAddress, bus]) => {
            try {
              const token = await getOrFetchToken(
                Wormhole.tokenId(chain, tokenAddress),
              );
              if (token) {
                const balance = amount.fromBaseUnits(bus, token.decimals);
                const balanceData = {
                  balance,
                  lastUpdated: Date.now(),
                };
                updatedBalances[token.key] = balanceData;
                setCached(wallet, token, balance);
              } else {
                markFailed(chain, tokenAddress);
              }
            } catch (e) {
              console.error(
                `Failed to fetch token metadata for ${tokenAddress}:`,
                e,
              );
              markFailed(chain, tokenAddress);
            }
          },
          {
            batchSize: BATCH_SIZE,
            delayMs: BATCH_DELAY_MS,
            maxItems: MAX_TOKENS_TO_PROCESS,
          },
        );
      }

      // Finally, set 0 balance values for tokens we wanted to check balances for which were not in the indexer result
      for (const token of tokensToFetch) {
        if (updatedBalances[token.key] === undefined) {
          const balance = amount.fromBaseUnits(0n, token.decimals);
          updatedBalances[token.key] = {
            balance,
            lastUpdated: Date.now(),
          };
          setCached(wallet, token, balance);
        }
      }
    },
    [getOrFetchToken],
  );

  // Fetch balances for a single chain
  const fetchBalancesForChain = useCallback(
    async (
      chain: Chain,
      wallet: WalletData,
      tokens: Token[],
    ): Promise<Balances> => {
      const chainConfig = config.chains[chain];
      if (
        !chainConfig ||
        chainToPlatform(chainConfig.sdkName) !== wallet.type
      ) {
        return {};
      }

      const updatedBalances: Balances = {};

      // Check cache first
      const tokensToFetch: Token[] = [];
      for (const token of tokens) {
        const cached = getCached(wallet, token);
        if (cached) {
          updatedBalances[token.key] = cached;
        } else {
          tokensToFetch.push(token);
        }
      }

      if (tokensToFetch.length === 0) {
        return updatedBalances;
      }

      // Fetch balances
      const wh = await getWormholeContextV2();
      const platformName = chainToPlatform(chain);
      const platform = wh.getPlatform(platformName);
      const rpc = platform.getRpc(chain);
      const platformUtils = platform.utils();

      // Try indexed balance fetching first
      if (supportsIndexerUtils(platformUtils)) {
        const canUseIndexer =
          platformName !== 'Evm' ||
          (config.evmIndexers &&
            (config.evmIndexers.alchemy || config.evmIndexers.goldRush));

        if (canUseIndexer) {
          try {
            const result = await platformUtils.getBalances(
              config.network,
              chain,
              rpc,
              wallet.address,
              platformName === 'Evm' ? config.evmIndexers : undefined,
            );

            await processIndexerResults(
              result,
              chain,
              wallet,
              updatedBalances,
              tokensToFetch,
            );
            return updatedBalances;
          } catch (e) {
            console.error(`Error calling getBalances on ${chain}:`, e);
            // Fall through to individual fetching
          }
        }
      }

      // Fallback to individual token fetching with batching
      await processBatches(
        tokensToFetch,
        async (token) => {
          try {
            const balanceValue = await platformUtils.getBalance(
              config.network,
              chain,
              rpc,
              wallet.address,
              token.address,
            );
            const balance = amount.fromBaseUnits(
              balanceValue ?? 0n,
              token.decimals,
            );
            updatedBalances[token.key] = {
              balance,
              lastUpdated: Date.now(),
            };
            setCached(wallet, token, balance);
          } catch (e) {
            console.error(`Failed to fetch balance for token ${token.key}`, e);
          }
        },
        {
          batchSize: BATCH_SIZE,
          delayMs: BATCH_DELAY_MS,
        },
      );

      return updatedBalances;
    },
    [processIndexerResults],
  );

  // Effect to fetch balances
  useEffect(() => {
    // Build current request keys
    const newRequestKeys = new Set<string>();
    if (source) {
      newRequestKeys.add(getRequestKey(source.chain, source.wallet));
    }
    if (destination) {
      newRequestKeys.add(getRequestKey(destination.chain, destination.wallet));
    }

    // Update current keys ref
    currentRequestKeysRef.current = newRequestKeys;

    // Clear fetching states for removed keys
    setFetchingKeys((prev) => {
      const updated = new Set(prev);
      for (const key of prev) {
        if (!newRequestKeys.has(key)) {
          updated.delete(key);
        }
      }
      return updated;
    });

    if (newRequestKeys.size === 0) {
      return;
    }

    // Fetch balances for each request
    const fetchAll = async () => {
      const requests: ChainBalanceRequest[] = [];
      if (source) requests.push(source);
      if (destination) requests.push(destination);

      // Mark as fetching
      setFetchingKeys(new Set(newRequestKeys));

      try {
        const results = await Promise.all(
          requests.map(async (request) => {
            const key = getRequestKey(request.chain, request.wallet);

            // Check if this key is still current
            if (!currentRequestKeysRef.current.has(key)) {
              return { key, balances: {} };
            }

            const balances = await fetchBalancesForChain(
              request.chain,
              request.wallet,
              request.tokens,
            );
            return { key, balances };
          }),
        );

        // Update balances only for current requests
        setBalances((prevBalances) => {
          const newBalances: BalanceMap = { ...prevBalances };

          for (const { key, balances } of results) {
            if (
              currentRequestKeysRef.current.has(key) &&
              Object.keys(balances).length > 0
            ) {
              newBalances[key] = balances;
            }
          }

          // Remove balances for keys that are no longer current
          for (const key in newBalances) {
            if (!currentRequestKeysRef.current.has(key)) {
              delete newBalances[key];
            }
          }

          return newBalances;
        });
      } finally {
        // Clear fetching state
        setFetchingKeys((prev) => {
          const updated = new Set(prev);
          for (const key of newRequestKeys) {
            updated.delete(key);
          }
          return updated;
        });
      }
    };

    fetchAll();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [
    source?.chain,
    source?.wallet?.address,
    destination?.chain,
    destination?.wallet?.address,
  ]);

  // Extract results for source and destination
  const sourceKey = source ? getRequestKey(source.chain, source.wallet) : null;
  const destKey = destination
    ? getRequestKey(destination.chain, destination.wallet)
    : null;

  const sourceResult: ChainBalanceResult = useMemo(() => {
    return {
      balances: sourceKey ? balances[sourceKey] || {} : {},
    };
  }, [balances, sourceKey]);

  const destinationResult: ChainBalanceResult = useMemo(() => {
    return {
      balances: destKey ? balances[destKey] || {} : {},
    };
  }, [balances, destKey]);

  const isFetching = fetchingKeys.size > 0;

  return {
    isFetching,
    source: sourceResult,
    destination: destinationResult,
  };
};

export default useGetTokenBalances;
