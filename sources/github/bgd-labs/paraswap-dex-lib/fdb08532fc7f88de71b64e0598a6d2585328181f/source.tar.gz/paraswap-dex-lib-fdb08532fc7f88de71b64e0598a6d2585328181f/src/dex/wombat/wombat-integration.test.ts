import dotenv from 'dotenv';

dotenv.config();

import { Interface, Result } from '@ethersproject/abi';
import { DummyDexHelper } from '../../dex-helper';
import { Network, SwapSide } from '../../constants';
import { BI_POWS } from '../../bigint-constants';
import { Wombat } from './wombat';
import { checkPoolPrices, checkConstantPoolPrices } from '../../../tests/utils';
import { Tokens } from '../../../tests/constants-e2e';
import { Token } from '../../types';
import { Address } from '@paraswap/core';
import { WombatConfig } from './config';

function getReaderCalldata(
  exchangeAddress: string,
  readerIface: Interface,
  side: SwapSide,
  fromToken: Token,
  toToken: Token,
  amounts: bigint[],
  funcName: string,
) {
  return amounts.map(amount => ({
    target: exchangeAddress,
    callData: readerIface.encodeFunctionData(
      funcName,
      side == SwapSide.SELL
        ? [fromToken.address, toToken.address, amount]
        : [toToken.address, fromToken.address, -amount],
    ),
  }));
}

function decodeReaderResult(
  results: Result,
  readerIface: Interface,
  funcName: string,
) {
  return results.map(result => {
    const parsed = readerIface.decodeFunctionResult(funcName, result);
    return BigInt(parsed[0]._hex);
  });
}

async function checkOnChainPricing(
  wombat: Wombat,
  pool: Address,
  fromToken: Token,
  toToken: Token,
  side: SwapSide,
  funcName: string,
  blockNumber: number,
  prices: bigint[],
  amounts: bigint[],
) {
  const exchangeAddress = pool; // TODO: Put here the real exchange address

  const readerIface = Wombat.poolInterface;

  const readerCallData = getReaderCalldata(
    exchangeAddress,
    readerIface,
    side,
    fromToken,
    toToken,
    amounts.slice(1),
    funcName,
  );
  const readerResult = (
    await wombat.dexHelper.multiContract.methods
      .aggregate(readerCallData)
      .call({}, blockNumber)
  ).returnData;

  const expectedPrices = [0n].concat(
    decodeReaderResult(readerResult, readerIface, funcName),
  );

  expect(prices).toEqual(expectedPrices);
}

async function testPricingOnNetwork(
  wombat: Wombat,
  network: Network,
  dexKey: string,
  blockNumber: number,
  srcTokenSymbol: string,
  destTokenSymbol: string,
  side: SwapSide,
  amounts: bigint[],
  funcNameToCheck: string,
) {
  const networkTokens = Tokens[network];

  const pools = await wombat.getPoolIdentifiers(
    networkTokens[srcTokenSymbol],
    networkTokens[destTokenSymbol],
    side,
    blockNumber,
  );
  console.log(
    `${srcTokenSymbol} <> ${destTokenSymbol} Pool Identifiers: `,
    pools,
  );

  expect(pools.length).toBeGreaterThan(0);

  const poolPrices = await wombat.getPricesVolume(
    networkTokens[srcTokenSymbol],
    networkTokens[destTokenSymbol],
    amounts,
    side,
    blockNumber,
    pools,
  );
  console.log(
    `${srcTokenSymbol} <> ${destTokenSymbol} Pool Prices: `,
    poolPrices,
  );

  expect(poolPrices).not.toBeNull();
  if (wombat.hasConstantPriceLargeAmounts) {
    checkConstantPoolPrices(poolPrices!, amounts, dexKey);
  } else {
    checkPoolPrices(poolPrices!, amounts, side, dexKey);
  }

  // Check if onchain pricing equals to calculated ones
  await checkOnChainPricing(
    wombat,
    poolPrices![0].data.exchange,
    networkTokens[srcTokenSymbol],
    networkTokens[destTokenSymbol],
    side,
    funcNameToCheck,
    blockNumber,
    poolPrices![0].prices,
    amounts,
  );
}

describe('Wombat', function () {
  const dexKey = 'Wombat';
  let blockNumber: number;
  let wombat: Wombat;

  Object.keys(WombatConfig[dexKey]).forEach(key => {
    describe(`network ${key}`, () => {
      const network = Number(key) as Network;
      const dexHelper = new DummyDexHelper(network);

      const tokens = Tokens[network];

      const srcTokenSymbol = 'USDC';
      const destTokenSymbol = network == Network.BASE ? 'USDbC' : 'USDT';

      let amountsForSell = [
        0n,
        1n * BI_POWS[tokens[srcTokenSymbol].decimals],
        2n * BI_POWS[tokens[srcTokenSymbol].decimals],
        3n * BI_POWS[tokens[srcTokenSymbol].decimals],
        4n * BI_POWS[tokens[srcTokenSymbol].decimals],
        5n * BI_POWS[tokens[srcTokenSymbol].decimals],
        6n * BI_POWS[tokens[srcTokenSymbol].decimals],
        7n * BI_POWS[tokens[srcTokenSymbol].decimals],
        8n * BI_POWS[tokens[srcTokenSymbol].decimals],
        9n * BI_POWS[tokens[srcTokenSymbol].decimals],
        10n * BI_POWS[tokens[srcTokenSymbol].decimals],
      ];

      beforeAll(async () => {
        blockNumber = await dexHelper.web3Provider.eth.getBlockNumber();
        wombat = new Wombat(network, dexKey, dexHelper);
      });

      // it('getTopPoolsForToken', async function () {
      //   // We have to check without calling initializePricing, because
      //   // pool-tracker is not calling that function
      //   if (wombat.updatePoolState) {
      //     await wombat.updatePoolState();
      //   }
      //   const poolLiquidity = await wombat.getTopPoolsForToken(
      //     tokens[srcTokenSymbol].address,
      //     10,
      //   );
      //   console.log(`${srcTokenSymbol} Top Pools:`, poolLiquidity);
      //
      //   if (!wombat.hasConstantPriceLargeAmounts) {
      //     checkPoolsLiquidity(
      //       poolLiquidity,
      //       Tokens[network][srcTokenSymbol].address,
      //       dexKey,
      //     );
      //   }
      // });

      it('getPoolIdentifiers and getPricesVolume SELL', async function () {
        if (wombat.initializePricing) {
          await wombat.initializePricing(blockNumber);
        }
        await testPricingOnNetwork(
          wombat,
          network,
          dexKey,
          blockNumber,
          srcTokenSymbol,
          destTokenSymbol,
          SwapSide.SELL,
          amountsForSell,
          'quotePotentialSwap',
        );
      });
    });
  });
});
