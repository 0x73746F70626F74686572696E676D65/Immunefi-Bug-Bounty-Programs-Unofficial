```diff
diff --git a/reports/StakedTokenV2Rev3_layout.md b/reports/StakedTokenV2Rev4_layout.md
index 47bc150..3d19fb3 100644
--- a/reports/StakedTokenV2Rev3_layout.md
+++ b/reports/StakedTokenV2Rev4_layout.md
@@ -1,22 +1,22 @@
-| Name                             | Type                                                                                   | Slot | Offset | Bytes | Contract                                                   |
-|----------------------------------|----------------------------------------------------------------------------------------|------|--------|-------|------------------------------------------------------------|
-| _balances                        | mapping(address => uint256)                                                            | 0    | 0      | 32    | etherscan/StakedTokenV2Rev3/Contract.sol:StakedTokenV2Rev3 |
-| _allowances                      | mapping(address => mapping(address => uint256))                                        | 1    | 0      | 32    | etherscan/StakedTokenV2Rev3/Contract.sol:StakedTokenV2Rev3 |
-| _totalSupply                     | uint256                                                                                | 2    | 0      | 32    | etherscan/StakedTokenV2Rev3/Contract.sol:StakedTokenV2Rev3 |
-| _name                            | string                                                                                 | 3    | 0      | 32    | etherscan/StakedTokenV2Rev3/Contract.sol:StakedTokenV2Rev3 |
-| _symbol                          | string                                                                                 | 4    | 0      | 32    | etherscan/StakedTokenV2Rev3/Contract.sol:StakedTokenV2Rev3 |
-| _decimals                        | uint8                                                                                  | 5    | 0      | 1     | etherscan/StakedTokenV2Rev3/Contract.sol:StakedTokenV2Rev3 |
-| _votingSnapshots                 | mapping(address => mapping(uint256 => struct GovernancePowerDelegationERC20.Snapshot)) | 6    | 0      | 32    | etherscan/StakedTokenV2Rev3/Contract.sol:StakedTokenV2Rev3 |
-| _votingSnapshotsCounts           | mapping(address => uint256)                                                            | 7    | 0      | 32    | etherscan/StakedTokenV2Rev3/Contract.sol:StakedTokenV2Rev3 |
-| _aaveGovernance                  | contract ITransferHook                                                                 | 8    | 0      | 20    | etherscan/StakedTokenV2Rev3/Contract.sol:StakedTokenV2Rev3 |
-| lastInitializedRevision          | uint256                                                                                | 9    | 0      | 32    | etherscan/StakedTokenV2Rev3/Contract.sol:StakedTokenV2Rev3 |
-| ______gap                        | uint256[50]                                                                            | 10   | 0      | 1600  | etherscan/StakedTokenV2Rev3/Contract.sol:StakedTokenV2Rev3 |
-| assets                           | mapping(address => struct AaveDistributionManager.AssetData)                           | 60   | 0      | 32    | etherscan/StakedTokenV2Rev3/Contract.sol:StakedTokenV2Rev3 |
-| stakerRewardsToClaim             | mapping(address => uint256)                                                            | 61   | 0      | 32    | etherscan/StakedTokenV2Rev3/Contract.sol:StakedTokenV2Rev3 |
-| stakersCooldowns                 | mapping(address => uint256)                                                            | 62   | 0      | 32    | etherscan/StakedTokenV2Rev3/Contract.sol:StakedTokenV2Rev3 |
-| _votingDelegates                 | mapping(address => address)                                                            | 63   | 0      | 32    | etherscan/StakedTokenV2Rev3/Contract.sol:StakedTokenV2Rev3 |
-| _propositionPowerSnapshots       | mapping(address => mapping(uint256 => struct GovernancePowerDelegationERC20.Snapshot)) | 64   | 0      | 32    | etherscan/StakedTokenV2Rev3/Contract.sol:StakedTokenV2Rev3 |
-| _propositionPowerSnapshotsCounts | mapping(address => uint256)                                                            | 65   | 0      | 32    | etherscan/StakedTokenV2Rev3/Contract.sol:StakedTokenV2Rev3 |
-| _propositionPowerDelegates       | mapping(address => address)                                                            | 66   | 0      | 32    | etherscan/StakedTokenV2Rev3/Contract.sol:StakedTokenV2Rev3 |
-| DOMAIN_SEPARATOR                 | bytes32                                                                                | 67   | 0      | 32    | etherscan/StakedTokenV2Rev3/Contract.sol:StakedTokenV2Rev3 |
-| _nonces                          | mapping(address => uint256)                                                            | 68   | 0      | 32    | etherscan/StakedTokenV2Rev3/Contract.sol:StakedTokenV2Rev3 |
+| Name                             | Type                                                                                   | Slot | Offset | Bytes | Contract                                              |
+|----------------------------------|----------------------------------------------------------------------------------------|------|--------|-------|-------------------------------------------------------|
+| _balances                        | mapping(address => uint256)                                                            | 0    | 0      | 32    | src/contracts/StakedTokenV2Rev4.sol:StakedTokenV2Rev4 |
+| _allowances                      | mapping(address => mapping(address => uint256))                                        | 1    | 0      | 32    | src/contracts/StakedTokenV2Rev4.sol:StakedTokenV2Rev4 |
+| _totalSupply                     | uint256                                                                                | 2    | 0      | 32    | src/contracts/StakedTokenV2Rev4.sol:StakedTokenV2Rev4 |
+| _name                            | string                                                                                 | 3    | 0      | 32    | src/contracts/StakedTokenV2Rev4.sol:StakedTokenV2Rev4 |
+| _symbol                          | string                                                                                 | 4    | 0      | 32    | src/contracts/StakedTokenV2Rev4.sol:StakedTokenV2Rev4 |
+| _decimals                        | uint8                                                                                  | 5    | 0      | 1     | src/contracts/StakedTokenV2Rev4.sol:StakedTokenV2Rev4 |
+| _votingSnapshots                 | mapping(address => mapping(uint256 => struct GovernancePowerDelegationERC20.Snapshot)) | 6    | 0      | 32    | src/contracts/StakedTokenV2Rev4.sol:StakedTokenV2Rev4 |
+| _votingSnapshotsCounts           | mapping(address => uint256)                                                            | 7    | 0      | 32    | src/contracts/StakedTokenV2Rev4.sol:StakedTokenV2Rev4 |
+| _aaveGovernance                  | contract ITransferHook                                                                 | 8    | 0      | 20    | src/contracts/StakedTokenV2Rev4.sol:StakedTokenV2Rev4 |
+| lastInitializedRevision          | uint256                                                                                | 9    | 0      | 32    | src/contracts/StakedTokenV2Rev4.sol:StakedTokenV2Rev4 |
+| ______gap                        | uint256[50]                                                                            | 10   | 0      | 1600  | src/contracts/StakedTokenV2Rev4.sol:StakedTokenV2Rev4 |
+| assets                           | mapping(address => struct AaveDistributionManager.AssetData)                           | 60   | 0      | 32    | src/contracts/StakedTokenV2Rev4.sol:StakedTokenV2Rev4 |
+| stakerRewardsToClaim             | mapping(address => uint256)                                                            | 61   | 0      | 32    | src/contracts/StakedTokenV2Rev4.sol:StakedTokenV2Rev4 |
+| stakersCooldowns                 | mapping(address => uint256)                                                            | 62   | 0      | 32    | src/contracts/StakedTokenV2Rev4.sol:StakedTokenV2Rev4 |
+| _votingDelegates                 | mapping(address => address)                                                            | 63   | 0      | 32    | src/contracts/StakedTokenV2Rev4.sol:StakedTokenV2Rev4 |
+| _propositionPowerSnapshots       | mapping(address => mapping(uint256 => struct GovernancePowerDelegationERC20.Snapshot)) | 64   | 0      | 32    | src/contracts/StakedTokenV2Rev4.sol:StakedTokenV2Rev4 |
+| _propositionPowerSnapshotsCounts | mapping(address => uint256)                                                            | 65   | 0      | 32    | src/contracts/StakedTokenV2Rev4.sol:StakedTokenV2Rev4 |
+| _propositionPowerDelegates       | mapping(address => address)                                                            | 66   | 0      | 32    | src/contracts/StakedTokenV2Rev4.sol:StakedTokenV2Rev4 |
+| DOMAIN_SEPARATOR                 | bytes32                                                                                | 67   | 0      | 32    | src/contracts/StakedTokenV2Rev4.sol:StakedTokenV2Rev4 |
+| _nonces                          | mapping(address => uint256)                                                            | 68   | 0      | 32    | src/contracts/StakedTokenV2Rev4.sol:StakedTokenV2Rev4 |
```
