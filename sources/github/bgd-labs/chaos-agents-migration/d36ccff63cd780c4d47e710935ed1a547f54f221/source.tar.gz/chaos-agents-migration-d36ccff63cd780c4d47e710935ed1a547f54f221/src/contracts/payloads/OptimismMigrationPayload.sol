// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;

import {AaveV3Optimism, AaveV3OptimismAssets} from 'aave-address-book/AaveV3Optimism.sol';
import {GovernanceV3Optimism} from 'aave-address-book/GovernanceV3Optimism.sol';
import {MiscOptimism} from 'aave-address-book/MiscOptimism.sol';

import {BaseMigrationPayload} from '../BaseMigrationPayload.sol';
import {AgentConfigLib} from '../AgentConfigLib.sol';

contract OptimismMigrationPayload is BaseMigrationPayload {
  address public constant SUPPLY_CAP_AGENT = 0x8963Abfb008A668346B18d0BeE82b171F3b2Be24;
  address public constant BORROW_CAP_AGENT = 0x3993695F48d64076C5Df1EeC9490501F9bB400C8;

  // https://automation.chain.link/optimism/26453377087659412746610762326968907049030779685850640095454880679068159883314
  uint256 public constant CAPS_INJECTOR_AUTOMATION_ID = 26453377087659412746610762326968907049030779685850640095454880679068159883314;

  constructor()
    BaseMigrationPayload(
      Constants({
        governanceExecutor: GovernanceV3Optimism.EXECUTOR_LVL_1,
        riskOracle: AaveV3Optimism.EDGE_RISK_ORACLE,
        aaveCollector: address(AaveV3Optimism.COLLECTOR),
        aaveAclManager: address(AaveV3Optimism.ACL_MANAGER),
        aavePoolForLinkWithdraw: address(AaveV3Optimism.POOL),
        agentHub: MiscOptimism.AGENT_HUB,
        automationHubWrapper: MiscOptimism.AGENT_HUB_AUTOMATION,
        rangeValidationModule: MiscOptimism.RANGE_VALIDATION_MODULE,
        chainlinkRobotOperator: MiscOptimism.AAVE_CL_ROBOT_OPERATOR,
        linkToken: AaveV3OptimismAssets.LINK_UNDERLYING
      })
    )
  {}

  function getAgentsMigrationInput() public view override returns (AgentMigrationInput[] memory) {
    AgentMigrationInput[] memory agentMigrationInputs = new AgentMigrationInput[](2);
    address[] memory markets = _convertATokensMarketsToUnderlying(
      AaveV3Optimism.EDGE_INJECTOR_CAPS
    );

    // Supply Cap Agent
    agentMigrationInputs[0] = AgentMigrationInput({
      genericInput: AgentConfigLib.supplyCapAgentConfig(),
      agentAddress: SUPPLY_CAP_AGENT,
      agentContext: abi.encode(AaveV3Optimism.CONFIG_ENGINE),
      allowedMarkets: markets,
      withdrawLinkFromCollector: true,
      linkAmountToFund: 50 ether,
      automationIdToCancel: CAPS_INJECTOR_AUTOMATION_ID,
      existingStewardToRevoke: AaveV3Optimism.EDGE_RISK_STEWARD_CAPS
    });

    // Borrow Cap Agent
    agentMigrationInputs[1] = AgentMigrationInput({
      genericInput: AgentConfigLib.borrowCapAgentConfig(),
      agentAddress: BORROW_CAP_AGENT,
      agentContext: abi.encode(AaveV3Optimism.CONFIG_ENGINE),
      allowedMarkets: markets,
      withdrawLinkFromCollector: true,
      linkAmountToFund: 50 ether,
      automationIdToCancel: 0, // cancelled in supplyCap agent so none here
      existingStewardToRevoke: address(0) // revoked already in supplyCap agent so none here
    });

    return agentMigrationInputs;
  }
}
