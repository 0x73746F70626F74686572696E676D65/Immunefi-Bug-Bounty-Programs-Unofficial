// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;

import {AaveV3Polygon, AaveV3PolygonAssets} from 'aave-address-book/AaveV3Polygon.sol';
import {GovernanceV3Polygon} from 'aave-address-book/GovernanceV3Polygon.sol';
import {MiscPolygon} from 'aave-address-book/MiscPolygon.sol';
import {CollectorUtils} from 'aave-helpers/src/CollectorUtils.sol';
import {SafeERC20} from 'openzeppelin-contracts/contracts/token/ERC20/utils/SafeERC20.sol';
import {IERC20} from 'openzeppelin-contracts/contracts/token/ERC20/IERC20.sol';

import {IPegSwap} from '../../interfaces/IPegSwap.sol';
import {BaseMigrationPayload} from '../BaseMigrationPayload.sol';
import {AgentConfigLib} from '../AgentConfigLib.sol';

contract PolygonMigrationPayload is BaseMigrationPayload {
  using SafeERC20 for IERC20;

  IPegSwap public constant PEGSWAP = IPegSwap(0xAA1DC356dc4B18f30C347798FD5379F3D77ABC5b);
  address public constant ERC_677_LINK_TOKEN = 0xb0897686c545045aFc77CF20eC7A532E3120E0F1;
  address public constant SUPPLY_CAP_AGENT = 0xd99D0A740AF7B68f1CB635294C013552423666b1;
  address public constant BORROW_CAP_AGENT = 0xA512909edCf6D9aE46b0414ce0aD724968448177;

  // https://automation.chain.link/polygon/33447308739366671404172934284614627466722998797397039941419803376909487943582
  uint256 public constant CAPS_INJECTOR_AUTOMATION_ID = 33447308739366671404172934284614627466722998797397039941419803376909487943582;

  constructor()
    BaseMigrationPayload(
      Constants({
        governanceExecutor: GovernanceV3Polygon.EXECUTOR_LVL_1,
        riskOracle: AaveV3Polygon.EDGE_RISK_ORACLE,
        aaveCollector: address(AaveV3Polygon.COLLECTOR),
        aaveAclManager: address(AaveV3Polygon.ACL_MANAGER),
        aavePoolForLinkWithdraw: address(AaveV3Polygon.POOL),
        agentHub: MiscPolygon.AGENT_HUB,
        automationHubWrapper: MiscPolygon.AGENT_HUB_AUTOMATION,
        rangeValidationModule: MiscPolygon.RANGE_VALIDATION_MODULE,
        chainlinkRobotOperator: MiscPolygon.AAVE_CL_ROBOT_OPERATOR,
        linkToken: ERC_677_LINK_TOKEN
      })
    )
  {}

  function getAgentsMigrationInput() public view override returns (AgentMigrationInput[] memory) {
    AgentMigrationInput[] memory agentMigrationInputs = new AgentMigrationInput[](2);
    address[] memory markets = _convertATokensMarketsToUnderlying(AaveV3Polygon.EDGE_INJECTOR_CAPS);

    // Supply Cap Agent
    agentMigrationInputs[0] = AgentMigrationInput({
      genericInput: AgentConfigLib.supplyCapAgentConfig(),
      agentAddress: SUPPLY_CAP_AGENT,
      agentContext: abi.encode(AaveV3Polygon.CONFIG_ENGINE),
      allowedMarkets: markets,
      withdrawLinkFromCollector: true,
      linkAmountToFund: 50 ether,
      automationIdToCancel: CAPS_INJECTOR_AUTOMATION_ID,
      existingStewardToRevoke: AaveV3Polygon.EDGE_RISK_STEWARD_CAPS
    });

    // Borrow Cap Agent
    agentMigrationInputs[1] = AgentMigrationInput({
      genericInput: AgentConfigLib.borrowCapAgentConfig(),
      agentAddress: BORROW_CAP_AGENT,
      agentContext: abi.encode(AaveV3Polygon.CONFIG_ENGINE),
      allowedMarkets: markets,
      withdrawLinkFromCollector: true,
      linkAmountToFund: 50 ether,
      automationIdToCancel: 0, // cancelled in supplyCap agent so none here
      existingStewardToRevoke: address(0) // revoked already in supplyCap agent so none here
    });

    return agentMigrationInputs;
  }

  function _fundExecutorWithLink(uint256 linkAmount) internal override returns (uint256) {
    // withdraw aLink to ERC20 link
    linkAmount = CollectorUtils.withdrawFromV3(
      COLLECTOR,
      CollectorUtils.IOInput({
        pool: AAVE_POOL_FOR_LINK_WITHDRAW,
        underlying: AaveV3PolygonAssets.LINK_UNDERLYING,
        amount: linkAmount
      }),
      address(this)
    );

    // Swap ERC-20 link to ERC-677 link which is used to fund automation
    IERC20(AaveV3PolygonAssets.LINK_UNDERLYING).forceApprove(address(PEGSWAP), linkAmount);
    PEGSWAP.swap(linkAmount, AaveV3PolygonAssets.LINK_UNDERLYING, ERC_677_LINK_TOKEN);

    return linkAmount;
  }
}
