// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;

import {AaveV3Ethereum, AaveV3EthereumAssets} from 'aave-address-book/AaveV3Ethereum.sol';
import {GovernanceV3Ethereum} from 'aave-address-book/GovernanceV3Ethereum.sol';
import {MiscEthereum} from 'aave-address-book/MiscEthereum.sol';

import {IAaveStewardInjector} from '../../interfaces/IAaveStewardInjector.sol';
import {BaseMigrationPayload} from '../BaseMigrationPayload.sol';
import {AgentConfigLib} from '../AgentConfigLib.sol';

contract EthereumCoreMigrationPayload is BaseMigrationPayload {

  address public constant EMODE_AGENT = 0x4F2858d4A4e4464b34Aa4a22C41B2Ef540a59BF4;
  address public constant PENDLE_DISCOUNT_RATE_AGENT = 0x1B3bD355c43d2247946b8e0889d4b4e701bf430d;
  address public constant INTEREST_RATE_AGENT = 0xdA626E64f34f24e0236E0C9cD2F11ce4549a08c6;

  // http://automation.chain.link/mainnet/110472841560466679957591885262036842690879875947899365339544642292605710260981
  uint256 public constant EMODE_INJECTOR_AUTOMATION_ID = 110472841560466679957591885262036842690879875947899365339544642292605710260981;

  // http://automation.chain.link/mainnet/67212566536318463823591337419618301027015983403872083445459201079159188810376
  uint256 public constant PENDLE_DISCOUNT_RATE_INJECTOR_AUTOMATION_ID = 67212566536318463823591337419618301027015983403872083445459201079159188810376;

  // http://automation.chain.link/mainnet/47322033008995691030360570391072485200303255862545787307644776058072915700759
  uint256 public constant INTEREST_RATE_INJECTOR_AUTOMATION_ID = 47322033008995691030360570391072485200303255862545787307644776058072915700759;

  constructor()
    BaseMigrationPayload(
      Constants({
        governanceExecutor: GovernanceV3Ethereum.EXECUTOR_LVL_1,
        riskOracle: AaveV3Ethereum.EDGE_RISK_ORACLE,
        aaveCollector: address(AaveV3Ethereum.COLLECTOR),
        aaveAclManager: address(AaveV3Ethereum.ACL_MANAGER),
        aavePoolForLinkWithdraw: address(AaveV3Ethereum.POOL),
        agentHub: MiscEthereum.AGENT_HUB,
        automationHubWrapper: MiscEthereum.AGENT_HUB_AUTOMATION,
        rangeValidationModule: MiscEthereum.RANGE_VALIDATION_MODULE,
        chainlinkRobotOperator: MiscEthereum.AAVE_CL_ROBOT_OPERATOR,
        linkToken: AaveV3EthereumAssets.LINK_UNDERLYING
      })
    )
  {}

  function getAgentsMigrationInput() public view override returns (AgentMigrationInput[] memory) {
    AgentMigrationInput[] memory agentMigrationInputs = new AgentMigrationInput[](3);

    // EMode Agent
    agentMigrationInputs[0] = AgentMigrationInput({
      genericInput: AgentConfigLib.eModeAgentConfigEthCore(),
      agentAddress: EMODE_AGENT,
      agentContext: abi.encode(AaveV3Ethereum.CONFIG_ENGINE),
      allowedMarkets: IAaveStewardInjector(AaveV3Ethereum.EDGE_INJECTOR_PENDLE_EMODE).getMarkets(),
      withdrawLinkFromCollector: true,
      linkAmountToFund: 400 ether,
      automationIdToCancel: EMODE_INJECTOR_AUTOMATION_ID,
      existingStewardToRevoke: AaveV3Ethereum.EDGE_RISK_STEWARD_PENDLE_EMODE
    });

    // Pendle Discount Rate Agent
    agentMigrationInputs[1] = AgentMigrationInput({
      genericInput: AgentConfigLib.pendleDiscountRateAgentConfigEthCore(),
      agentAddress: PENDLE_DISCOUNT_RATE_AGENT,
      agentContext: '',
      allowedMarkets: IAaveStewardInjector(AaveV3Ethereum.EDGE_INJECTOR_DISCOUNT_RATE).getMarkets(),
      withdrawLinkFromCollector: true,
      linkAmountToFund: 400 ether,
      automationIdToCancel: PENDLE_DISCOUNT_RATE_INJECTOR_AUTOMATION_ID,
      existingStewardToRevoke: AaveV3Ethereum.EDGE_RISK_STEWARD_DISCOUNT_RATE
    });

    // Interest Rate Agent - Slope2
    agentMigrationInputs[2] = AgentMigrationInput({
      genericInput: AgentConfigLib.slope2InterestRateAgentConfigEthCore(),
      agentAddress: INTEREST_RATE_AGENT,
      agentContext: abi.encode(AaveV3Ethereum.CONFIG_ENGINE),
      allowedMarkets: IAaveStewardInjector(AaveV3Ethereum.EDGE_INJECTOR_RATES).getMarkets(),
      withdrawLinkFromCollector: true,
      linkAmountToFund: 500 ether,
      automationIdToCancel: INTEREST_RATE_INJECTOR_AUTOMATION_ID,
      existingStewardToRevoke: AaveV3Ethereum.EDGE_RISK_STEWARD_RATES
    });

    return agentMigrationInputs;
  }
}
