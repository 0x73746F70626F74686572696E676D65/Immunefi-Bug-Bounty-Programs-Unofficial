// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;

import {AaveV3Gnosis} from 'aave-address-book/AaveV3Gnosis.sol';
import {GovernanceV3Gnosis} from 'aave-address-book/GovernanceV3Gnosis.sol';
import {MiscGnosis} from 'aave-address-book/MiscGnosis.sol';

import {BaseMigrationPayload} from '../BaseMigrationPayload.sol';
import {AgentConfigLib} from '../AgentConfigLib.sol';

contract GnosisMigrationPayload is BaseMigrationPayload {
  address public constant SUPPLY_CAP_AGENT = 0x8d3C192BC8D0913Ecc4eAACf0Fe99B6F6226B486;
  address public constant BORROW_CAP_AGENT = 0xcCeb5996cF9976168fdbE6fF88B1d89e1180A0EA;

  constructor()
    BaseMigrationPayload(
      Constants({
        governanceExecutor: GovernanceV3Gnosis.EXECUTOR_LVL_1,
        riskOracle: AaveV3Gnosis.EDGE_RISK_ORACLE,
        aaveCollector: address(AaveV3Gnosis.COLLECTOR),
        aaveAclManager: address(AaveV3Gnosis.ACL_MANAGER),
        aavePoolForLinkWithdraw: address(AaveV3Gnosis.POOL),
        agentHub: MiscGnosis.AGENT_HUB,
        automationHubWrapper: MiscGnosis.AGENT_HUB_AUTOMATION,
        rangeValidationModule: MiscGnosis.RANGE_VALIDATION_MODULE,
        chainlinkRobotOperator: address(0), // none, as we use gelato automation for gnosis
        linkToken: address(0) // unused on gnosis network
      })
    )
  {}

  function getAgentsMigrationInput() public view override returns (AgentMigrationInput[] memory) {
    AgentMigrationInput[] memory agentMigrationInputs = new AgentMigrationInput[](2);
    address[] memory markets = _convertATokensMarketsToUnderlying(AaveV3Gnosis.EDGE_INJECTOR_CAPS);

    // Supply Cap Agent
    agentMigrationInputs[0] = AgentMigrationInput({
      genericInput: AgentConfigLib.supplyCapAgentConfig(),
      agentAddress: SUPPLY_CAP_AGENT,
      agentContext: abi.encode(AaveV3Gnosis.CONFIG_ENGINE),
      allowedMarkets: markets,
      withdrawLinkFromCollector: false,
      linkAmountToFund: 0,
      automationIdToCancel: 0, // none, as gelato automation is being used
      existingStewardToRevoke: AaveV3Gnosis.EDGE_RISK_STEWARD_CAPS
    });

    // Borrow Cap Agent
    agentMigrationInputs[1] = AgentMigrationInput({
      genericInput: AgentConfigLib.borrowCapAgentConfig(),
      agentAddress: BORROW_CAP_AGENT,
      agentContext: abi.encode(AaveV3Gnosis.CONFIG_ENGINE),
      allowedMarkets: markets,
      withdrawLinkFromCollector: false,
      linkAmountToFund: 0,
      automationIdToCancel: 0, // none, as gelato automation is being used
      existingStewardToRevoke: address(0) // revoked already in supplyCap agent so none here
    });

    return agentMigrationInputs;
  }
}
