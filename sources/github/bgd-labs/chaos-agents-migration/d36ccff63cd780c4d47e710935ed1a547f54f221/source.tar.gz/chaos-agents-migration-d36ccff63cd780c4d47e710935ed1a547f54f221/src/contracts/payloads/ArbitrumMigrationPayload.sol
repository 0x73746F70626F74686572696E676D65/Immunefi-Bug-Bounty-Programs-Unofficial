// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;

import {AaveV3Arbitrum, AaveV3ArbitrumAssets} from 'aave-address-book/AaveV3Arbitrum.sol';
import {GovernanceV3Arbitrum} from 'aave-address-book/GovernanceV3Arbitrum.sol';
import {MiscArbitrum} from 'aave-address-book/MiscArbitrum.sol';

import {BaseMigrationPayload} from '../BaseMigrationPayload.sol';
import {AgentConfigLib} from '../AgentConfigLib.sol';

contract ArbitrumMigrationPayload is BaseMigrationPayload {
  address public constant SUPPLY_CAP_AGENT = 0xeBe545478709d4388e36Bb706CF11e2f89898541;
  address public constant BORROW_CAP_AGENT = 0x8963Abfb008A668346B18d0BeE82b171F3b2Be24;

  // http://automation.chain.link/arbitrum/88299248543870016015934290037410165151364647367386443287615367722657163688018
  uint256 public constant CAPS_INJECTOR_AUTOMATION_ID = 88299248543870016015934290037410165151364647367386443287615367722657163688018;

  constructor()
    BaseMigrationPayload(
      Constants({
        governanceExecutor: GovernanceV3Arbitrum.EXECUTOR_LVL_1,
        riskOracle: AaveV3Arbitrum.EDGE_RISK_ORACLE,
        aaveCollector: address(AaveV3Arbitrum.COLLECTOR),
        aaveAclManager: address(AaveV3Arbitrum.ACL_MANAGER),
        aavePoolForLinkWithdraw: address(AaveV3Arbitrum.POOL),
        agentHub: MiscArbitrum.AGENT_HUB,
        automationHubWrapper: MiscArbitrum.AGENT_HUB_AUTOMATION,
        rangeValidationModule: MiscArbitrum.RANGE_VALIDATION_MODULE,
        chainlinkRobotOperator: MiscArbitrum.AAVE_CL_ROBOT_OPERATOR,
        linkToken: AaveV3ArbitrumAssets.LINK_UNDERLYING
      })
    )
  {}

  function getAgentsMigrationInput() public view override returns (AgentMigrationInput[] memory) {
    AgentMigrationInput[] memory agentMigrationInputs = new AgentMigrationInput[](2);
    address[] memory markets = _convertATokensMarketsToUnderlying(
      AaveV3Arbitrum.EDGE_INJECTOR_CAPS
    );

    // Supply Cap Agent
    agentMigrationInputs[0] = AgentMigrationInput({
      genericInput: AgentConfigLib.supplyCapAgentConfig(),
      agentAddress: SUPPLY_CAP_AGENT,
      agentContext: abi.encode(AaveV3Arbitrum.CONFIG_ENGINE),
      allowedMarkets: markets,
      withdrawLinkFromCollector: true,
      linkAmountToFund: 50 ether,
      automationIdToCancel: CAPS_INJECTOR_AUTOMATION_ID,
      existingStewardToRevoke: AaveV3Arbitrum.EDGE_RISK_STEWARD_CAPS
    });

    // Borrow Cap Agent
    agentMigrationInputs[1] = AgentMigrationInput({
      genericInput: AgentConfigLib.borrowCapAgentConfig(),
      agentAddress: BORROW_CAP_AGENT,
      agentContext: abi.encode(AaveV3Arbitrum.CONFIG_ENGINE),
      allowedMarkets: markets,
      withdrawLinkFromCollector: true,
      linkAmountToFund: 50 ether,
      automationIdToCancel: 0, // cancelled in supplyCap agent so none here
      existingStewardToRevoke: address(0) // revoked already in supplyCap agent so none here
    });

    return agentMigrationInputs;
  }
}
