// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;

import {AaveV3Ethereum, AaveV3EthereumAssets} from 'aave-address-book/AaveV3Ethereum.sol';
import {AaveV3EthereumLido, AaveV3EthereumLidoAssets} from 'aave-address-book/AaveV3EthereumLido.sol';
import {GovernanceV3Ethereum} from 'aave-address-book/GovernanceV3Ethereum.sol';
import {MiscEthereum} from 'aave-address-book/MiscEthereum.sol';

import {BaseMigrationPayload} from '../BaseMigrationPayload.sol';
import {AgentConfigLib} from '../AgentConfigLib.sol';

contract EthereumPrimeMigrationPayload is BaseMigrationPayload {
  address public constant INTEREST_RATE_AGENT = 0x52E652182b22C41d0202bB8D834982F43B12Cd21;

  // http://automation.chain.link/mainnet/45753824297025885902624238758791309143317614233946089696664195067098722041622
  uint256 public constant INTEREST_RATE_INJECTOR_AUTOMATION_ID = 45753824297025885902624238758791309143317614233946089696664195067098722041622;

  constructor()
    BaseMigrationPayload(
      Constants({
        governanceExecutor: GovernanceV3Ethereum.EXECUTOR_LVL_1,
        riskOracle: AaveV3Ethereum.EDGE_RISK_ORACLE,
        aaveCollector: address(AaveV3EthereumLido.COLLECTOR),
        aaveAclManager: address(AaveV3EthereumLido.ACL_MANAGER),
        aavePoolForLinkWithdraw: address(AaveV3Ethereum.POOL), // we use core pool to withdraw aLink
        agentHub: MiscEthereum.AGENT_HUB,
        automationHubWrapper: MiscEthereum.AGENT_HUB_AUTOMATION,
        rangeValidationModule: MiscEthereum.RANGE_VALIDATION_MODULE,
        chainlinkRobotOperator: MiscEthereum.AAVE_CL_ROBOT_OPERATOR,
        linkToken: AaveV3EthereumAssets.LINK_UNDERLYING
      })
    )
  {}

  function getAgentsMigrationInput() public pure override returns (AgentMigrationInput[] memory) {
    AgentMigrationInput[] memory agentMigrationInputs = new AgentMigrationInput[](1);

    // Interest Rate Agent
    agentMigrationInputs[0] = AgentMigrationInput({
      genericInput: AgentConfigLib.interestRateAgentConfigEthPrime(),
      agentAddress: INTEREST_RATE_AGENT,
      agentContext: abi.encode(AaveV3EthereumLido.CONFIG_ENGINE),
      allowedMarkets: _getMarkets(),
      withdrawLinkFromCollector: true,
      linkAmountToFund: 500 ether,
      automationIdToCancel: INTEREST_RATE_INJECTOR_AUTOMATION_ID,
      existingStewardToRevoke: AaveV3EthereumLido.EDGE_RISK_STEWARD_RATES
    });

    return agentMigrationInputs;
  }

  function _getMarkets() internal pure returns (address[] memory) {
    address[] memory markets = new address[](1);
    markets[0] = AaveV3EthereumLidoAssets.WETH_UNDERLYING;

    return markets;
  }
}
