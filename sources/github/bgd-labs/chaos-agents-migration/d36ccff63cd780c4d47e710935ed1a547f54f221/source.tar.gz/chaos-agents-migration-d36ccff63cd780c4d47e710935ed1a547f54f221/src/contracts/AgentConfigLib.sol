// SPDX-License-Identifier: MIT
pragma solidity ^0.8.10;

import {IRangeValidationModule} from 'chaos-agents/src/interfaces/IRangeValidationModule.sol';
import {BaseMigrationPayload as Base} from './BaseMigrationPayload.sol';

/**
 * @title AgentConfigLib
 * @author BGD Labs
 * @notice Stores generic configurations of the agent
 */
library AgentConfigLib {
  struct GenericAgentConfig {
    string updateType;
    string robotName;
    uint256 expirationPeriod;
    uint256 minimumDelay;
    Base.RangeConfiguration[] rangeConfigs;
  }

  function supplyCapAgentConfig() internal pure returns (GenericAgentConfig memory) {
    Base.RangeConfiguration[] memory rangeValidationConfigs = new Base.RangeConfiguration[](1);
    rangeValidationConfigs[0] = Base.RangeConfiguration({
      rangeUpdateType: 'SupplyCapUpdate',
      config: IRangeValidationModule.RangeConfig({
        maxIncrease: 30_00, // 30% increase
        maxDecrease: 30_00, // 30% decrease
        isIncreaseRelative: true,
        isDecreaseRelative: true
      })
    });

    return
      GenericAgentConfig({
        updateType: 'SupplyCapUpdate',
        robotName: 'Supply Cap Agent',
        expirationPeriod: 3 days,
        minimumDelay: 3 days,
        rangeConfigs: rangeValidationConfigs
      });
  }

  function borrowCapAgentConfig() internal pure returns (GenericAgentConfig memory) {
    Base.RangeConfiguration[] memory rangeValidationConfigs = new Base.RangeConfiguration[](1);
    rangeValidationConfigs[0] = Base.RangeConfiguration({
      rangeUpdateType: 'BorrowCapUpdate',
      config: IRangeValidationModule.RangeConfig({
        maxIncrease: 30_00, // 30% increase
        maxDecrease: 30_00, // 30% decrease
        isIncreaseRelative: true,
        isDecreaseRelative: true
      })
    });

    return
      GenericAgentConfig({
        updateType: 'BorrowCapUpdate',
        robotName: 'Borrow Cap Agent',
        expirationPeriod: 3 days,
        minimumDelay: 3 days,
        rangeConfigs: rangeValidationConfigs
      });
  }

  function eModeAgentConfig() internal pure returns (GenericAgentConfig memory) {
    Base.RangeConfiguration[] memory rangeValidationConfigs = new Base.RangeConfiguration[](3);
    rangeValidationConfigs[0] = Base.RangeConfiguration({
      rangeUpdateType: 'EModeLTV',
      config: IRangeValidationModule.RangeConfig({
        maxIncrease: 50, // 0.5% increase
        maxDecrease: 50, // 0.5% decrease
        isIncreaseRelative: false,
        isDecreaseRelative: false
      })
    });
    rangeValidationConfigs[1] = Base.RangeConfiguration({
      rangeUpdateType: 'EModeLiquidationThreshold',
      config: IRangeValidationModule.RangeConfig({
        maxIncrease: 50, // 0.5% increase
        maxDecrease: 50, // 0.5% decrease
        isIncreaseRelative: false,
        isDecreaseRelative: false
      })
    });
    rangeValidationConfigs[2] = Base.RangeConfiguration({
      rangeUpdateType: 'EModeLiquidationBonus',
      config: IRangeValidationModule.RangeConfig({
        maxIncrease: 50, // 0.5% increase
        maxDecrease: 50, // 0.5% decrease
        isIncreaseRelative: false,
        isDecreaseRelative: false
      })
    });

    return
      GenericAgentConfig({
        updateType: 'EModeCategoryUpdate',
        robotName: 'EMode Agent',
        expirationPeriod: 3 days,
        minimumDelay: 3 days,
        rangeConfigs: rangeValidationConfigs
      });
  }

  function pendleDiscountRateAgentConfig() internal pure returns (GenericAgentConfig memory) {
    Base.RangeConfiguration[] memory rangeValidationConfigs = new Base.RangeConfiguration[](1);
    rangeValidationConfigs[0] = Base.RangeConfiguration({
      rangeUpdateType: 'PendleDiscountRateUpdate',
      config: IRangeValidationModule.RangeConfig({
        maxIncrease: 0.01e18, // 1% increase
        maxDecrease: 0.01e18, // 1% decrease
        isIncreaseRelative: false,
        isDecreaseRelative: false
      })
    });

    return
      GenericAgentConfig({
        updateType: 'PendleDiscountRateUpdate',
        robotName: 'Pendle PT DiscountRate Agent',
        expirationPeriod: 2 days,
        minimumDelay: 2 days,
        rangeConfigs: rangeValidationConfigs
      });
  }

  function slope2InterestRateAgentConfig() internal pure returns (GenericAgentConfig memory) {
    Base.RangeConfiguration[] memory rangeValidationConfigs = new Base.RangeConfiguration[](1);
    rangeValidationConfigs[0] = Base.RangeConfiguration({
      rangeUpdateType: 'VariableRateSlope2',
      config: IRangeValidationModule.RangeConfig({
        maxIncrease: 4_00, // 4% increase
        maxDecrease: 4_00, // 4% decrease
        isIncreaseRelative: false,
        isDecreaseRelative: false
      })
    });

    return
      GenericAgentConfig({
        updateType: 'RateStrategyUpdate',
        robotName: 'Interest Rate Agent',
        expirationPeriod: 8 hours,
        minimumDelay: 8 hours,
        rangeConfigs: rangeValidationConfigs
      });
  }

  function interestRateAgentConfigEthPrime() internal pure returns (GenericAgentConfig memory) {
    Base.RangeConfiguration[] memory rangeValidationConfigs = new Base.RangeConfiguration[](4);
    rangeValidationConfigs[0] = Base.RangeConfiguration({
      rangeUpdateType: 'OptimalUsageRatio',
      config: IRangeValidationModule.RangeConfig({
        maxIncrease: 3_00, // 3% increase
        maxDecrease: 3_00, // 3% decrease
        isIncreaseRelative: false,
        isDecreaseRelative: false
      })
    });
    rangeValidationConfigs[1] = Base.RangeConfiguration({
      rangeUpdateType: 'BaseVariableBorrowRate',
      config: IRangeValidationModule.RangeConfig({
        maxIncrease: 50, // 0.5% increase
        maxDecrease: 50, // 0.5% decrease
        isIncreaseRelative: false,
        isDecreaseRelative: false
      })
    });
    rangeValidationConfigs[2] = Base.RangeConfiguration({
      rangeUpdateType: 'VariableRateSlope1',
      config: IRangeValidationModule.RangeConfig({
        maxIncrease: 50, // 0.5% increase
        maxDecrease: 50, // 0.5% decrease
        isIncreaseRelative: false,
        isDecreaseRelative: false
      })
    });
    rangeValidationConfigs[3] = Base.RangeConfiguration({
      rangeUpdateType: 'VariableRateSlope2',
      config: IRangeValidationModule.RangeConfig({
        maxIncrease: 5_00, // 5% increase
        maxDecrease: 5_00, // 5% decrease
        isIncreaseRelative: false,
        isDecreaseRelative: false
      })
    });

    return
      GenericAgentConfig({
        updateType: 'RateStrategyUpdate_Prime',
        robotName: 'Prime Interest Rate Agent',
        expirationPeriod: 1 days,
        minimumDelay: 1 days,
        rangeConfigs: rangeValidationConfigs
      });
  }

  function pendleDiscountRateAgentConfigEthCore()
    internal
    pure
    returns (GenericAgentConfig memory)
  {
    GenericAgentConfig memory config = pendleDiscountRateAgentConfig();
    config.rangeConfigs[0].rangeUpdateType = 'PendleDiscountRateUpdate_Core';
    config.updateType = 'PendleDiscountRateUpdate_Core';
    config.robotName = 'Core Pendle PT DiscountRate Agent';

    return config;
  }

  function eModeAgentConfigEthCore() internal pure returns (GenericAgentConfig memory) {
    GenericAgentConfig memory config = eModeAgentConfig();
    config.updateType = 'EModeCategoryUpdate_Core';
    config.robotName = 'Core EMode Agent';

    return config;
  }

  function slope2InterestRateAgentConfigEthCore()
    internal
    pure
    returns (GenericAgentConfig memory)
  {
    GenericAgentConfig memory config = slope2InterestRateAgentConfig();
    config.updateType = 'RateStrategyUpdate_Core';
    config.robotName = 'Core Interest Rate Agent';

    return config;
  }
}
