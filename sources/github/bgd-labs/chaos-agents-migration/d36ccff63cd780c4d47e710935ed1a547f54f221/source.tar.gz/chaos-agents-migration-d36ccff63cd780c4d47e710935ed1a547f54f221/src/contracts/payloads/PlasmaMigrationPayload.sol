// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;

import {AaveV3Plasma, AaveV3PlasmaAssets} from 'aave-address-book/AaveV3Plasma.sol';
import {GovernanceV3Plasma} from 'aave-address-book/GovernanceV3Plasma.sol';
import {MiscPlasma} from 'aave-address-book/MiscPlasma.sol';

import {IAaveStewardInjector} from '../../interfaces/IAaveStewardInjector.sol';
import {BaseMigrationPayload} from '../BaseMigrationPayload.sol';
import {AgentConfigLib} from '../AgentConfigLib.sol';

contract PlasmaMigrationPayload is BaseMigrationPayload {
  address public constant EMODE_AGENT = 0x3999d49Bbad3A7375B0376BDF2bA4f2e3c9F5177;
  address public constant PENDLE_DISCOUNT_RATE_AGENT = 0x4e8984D11A47Ff89CD67c7651eCaB6C00a74B4A9;

  constructor()
    BaseMigrationPayload(
      Constants({
        governanceExecutor: GovernanceV3Plasma.EXECUTOR_LVL_1,
        riskOracle: AaveV3Plasma.EDGE_RISK_ORACLE,
        aaveCollector: address(AaveV3Plasma.COLLECTOR),
        aaveAclManager: address(AaveV3Plasma.ACL_MANAGER),
        aavePoolForLinkWithdraw: address(AaveV3Plasma.POOL),
        agentHub: MiscPlasma.AGENT_HUB,
        automationHubWrapper: MiscPlasma.AGENT_HUB_AUTOMATION,
        rangeValidationModule: MiscPlasma.RANGE_VALIDATION_MODULE,
        chainlinkRobotOperator: address(0), // none, as we use gelato automation for Plasma
        linkToken: address(0) // unused on Plasma network
      })
    )
  {}

  function getAgentsMigrationInput() public view override returns (AgentMigrationInput[] memory) {
    AgentMigrationInput[] memory agentMigrationInputs = new AgentMigrationInput[](2);

    // EMode Agent
    agentMigrationInputs[0] = AgentMigrationInput({
      genericInput: AgentConfigLib.eModeAgentConfig(),
      agentAddress: EMODE_AGENT,
      agentContext: abi.encode(AaveV3Plasma.CONFIG_ENGINE),
      allowedMarkets: IAaveStewardInjector(AaveV3Plasma.EDGE_INJECTOR_PENDLE_EMODE).getMarkets(),
      withdrawLinkFromCollector: false,
      linkAmountToFund: 0,
      automationIdToCancel: 0, // none, as gelato automation is being used
      existingStewardToRevoke: AaveV3Plasma.EDGE_RISK_STEWARD_PENDLE_EMODE
    });

    // Pendle Discount Rate Agent
    agentMigrationInputs[1] = AgentMigrationInput({
      genericInput: AgentConfigLib.pendleDiscountRateAgentConfig(),
      agentAddress: PENDLE_DISCOUNT_RATE_AGENT,
      agentContext: '',
      allowedMarkets: IAaveStewardInjector(AaveV3Plasma.EDGE_INJECTOR_DISCOUNT_RATE).getMarkets(),
      withdrawLinkFromCollector: false,
      linkAmountToFund: 0,
      automationIdToCancel: 0, // none, as gelato automation is being used
      existingStewardToRevoke: AaveV3Plasma.EDGE_RISK_STEWARD_DISCOUNT_RATE
    });

    return agentMigrationInputs;
  }
}
