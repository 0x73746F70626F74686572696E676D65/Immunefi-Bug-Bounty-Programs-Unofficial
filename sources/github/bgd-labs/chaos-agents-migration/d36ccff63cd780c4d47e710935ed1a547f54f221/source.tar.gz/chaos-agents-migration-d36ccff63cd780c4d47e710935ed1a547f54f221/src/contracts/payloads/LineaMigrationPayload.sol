// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;

import {AaveV3Linea} from 'aave-address-book/AaveV3Linea.sol';
import {GovernanceV3Linea} from 'aave-address-book/GovernanceV3Linea.sol';
import {MiscLinea} from 'aave-address-book/MiscLinea.sol';

import {IAaveStewardInjector} from '../../interfaces/IAaveStewardInjector.sol';
import {BaseMigrationPayload} from '../BaseMigrationPayload.sol';
import {AgentConfigLib} from '../AgentConfigLib.sol';

contract LineaMigrationPayload is BaseMigrationPayload {
  address public constant INTEREST_RATE_AGENT = 0x58226D26658F19724cB881E9F747EeDC846BB1c9;

  constructor()
    BaseMigrationPayload(
      Constants({
        governanceExecutor: GovernanceV3Linea.EXECUTOR_LVL_1,
        riskOracle: AaveV3Linea.EDGE_RISK_ORACLE,
        aaveCollector: address(AaveV3Linea.COLLECTOR),
        aaveAclManager: address(AaveV3Linea.ACL_MANAGER),
        aavePoolForLinkWithdraw: address(AaveV3Linea.POOL),
        agentHub: MiscLinea.AGENT_HUB,
        automationHubWrapper: MiscLinea.AGENT_HUB_AUTOMATION,
        rangeValidationModule: MiscLinea.RANGE_VALIDATION_MODULE,
        chainlinkRobotOperator: address(0), // none, as we use gelato automation for Linea
        linkToken: address(0) // unused on Linea network
      })
    )
  {}

  function getAgentsMigrationInput() public view override returns (AgentMigrationInput[] memory) {
    AgentMigrationInput[] memory agentMigrationInputs = new AgentMigrationInput[](1);

    // Interest Rate Agent
    agentMigrationInputs[0] = AgentMigrationInput({
      genericInput: AgentConfigLib.slope2InterestRateAgentConfig(),
      agentAddress: INTEREST_RATE_AGENT,
      agentContext: abi.encode(AaveV3Linea.CONFIG_ENGINE),
      allowedMarkets: IAaveStewardInjector(AaveV3Linea.EDGE_INJECTOR_RATES).getMarkets(),
      withdrawLinkFromCollector: false,
      linkAmountToFund: 0,
      automationIdToCancel: 0, // none, as gelato automation is being used
      existingStewardToRevoke: AaveV3Linea.EDGE_RISK_STEWARD_RATES
    });

    return agentMigrationInputs;
  }
}
