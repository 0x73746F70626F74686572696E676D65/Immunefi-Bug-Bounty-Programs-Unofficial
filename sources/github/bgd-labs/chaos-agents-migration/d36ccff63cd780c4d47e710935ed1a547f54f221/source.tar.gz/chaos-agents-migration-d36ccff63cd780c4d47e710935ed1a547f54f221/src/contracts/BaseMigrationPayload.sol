// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;

import {IProposalGenericExecutor} from 'aave-helpers/src/interfaces/IProposalGenericExecutor.sol';
import {IAgentHub, IAgentConfigurator} from 'chaos-agents/src/interfaces/IAgentHub.sol';
import {IRangeValidationModule} from 'chaos-agents/src/interfaces/IRangeValidationModule.sol';
import {IACLManager} from 'aave-v3-origin/src/contracts/interfaces/IACLManager.sol';
import {IAToken} from 'aave-v3-origin/src/contracts/interfaces/IAToken.sol';
import {ICollector, CollectorUtils} from 'aave-helpers/src/CollectorUtils.sol';
import {SafeERC20} from 'openzeppelin-contracts/contracts/token/ERC20/utils/SafeERC20.sol';
import {SafeCast} from 'openzeppelin-contracts/contracts/utils/math/SafeCast.sol';
import {IERC20} from 'openzeppelin-contracts/contracts/token/ERC20/IERC20.sol';

import {IAaveStewardInjector} from '../interfaces/IAaveStewardInjector.sol';
import {IAaveCLRobotOperator} from '../interfaces/IAaveCLRobotOperator.sol';
import {AgentConfigLib} from './AgentConfigLib.sol';

/**
 * @title BaseMigrationPayload
 * @author BGD Labs
 * @notice Base contract containing logic to migrate aave edge agrs systems to chaos-agent
 */
abstract contract BaseMigrationPayload is IProposalGenericExecutor {
  using SafeERC20 for IERC20;
  using SafeCast for uint256;

  struct AgentMigrationInput {
    AgentConfigLib.GenericAgentConfig genericInput;
    address agentAddress;
    bytes agentContext;
    address[] allowedMarkets;
    bool withdrawLinkFromCollector;
    uint256 linkAmountToFund;
    uint256 automationIdToCancel;
    address existingStewardToRevoke;
  }

  struct RangeConfiguration {
    IRangeValidationModule.RangeConfig config;
    string rangeUpdateType;
  }

  struct Constants {
    address governanceExecutor;
    address riskOracle;
    address aaveCollector;
    address aavePoolForLinkWithdraw;
    address aaveAclManager;
    address agentHub;
    address automationHubWrapper;
    address rangeValidationModule;
    address chainlinkRobotOperator;
    address linkToken;
  }

  ICollector public immutable COLLECTOR;
  IACLManager public immutable ACL_MANAGER;
  address public immutable AAVE_POOL_FOR_LINK_WITHDRAW;
  address public immutable RISK_ORACLE;
  address public immutable GOVERNANCE_EXECUTOR;

  IAgentHub public immutable AGENT_HUB;
  address public immutable AUTOMATION_HUB_WRAPPER;
  IRangeValidationModule public immutable RANGE_VALIDATION_MODULE;
  IAaveCLRobotOperator public immutable ROBOT_OPERATOR;
  address public immutable LINK_TOKEN;

  constructor(Constants memory constants) {
    GOVERNANCE_EXECUTOR = constants.governanceExecutor;
    RISK_ORACLE = constants.riskOracle;
    COLLECTOR = ICollector(constants.aaveCollector);
    ACL_MANAGER = IACLManager(constants.aaveAclManager);
    AAVE_POOL_FOR_LINK_WITHDRAW = constants.aavePoolForLinkWithdraw;
    AGENT_HUB = IAgentHub(constants.agentHub);
    AUTOMATION_HUB_WRAPPER = constants.automationHubWrapper;
    RANGE_VALIDATION_MODULE = IRangeValidationModule(constants.rangeValidationModule);
    ROBOT_OPERATOR = IAaveCLRobotOperator(constants.chainlinkRobotOperator);
    LINK_TOKEN = constants.linkToken;
  }

  function getAgentsMigrationInput() public view virtual returns (AgentMigrationInput[] memory);

  function execute() external {
    AgentMigrationInput[] memory agentInput = getAgentsMigrationInput();
    uint256[] memory agentIds = new uint256[](agentInput.length);

    for (uint256 i = 0; i < agentInput.length; i++) {
      // 1. register chaos-agents on the agent-hub
      agentIds[i] = AGENT_HUB.registerAgent(_repackRegistrationInput(agentInput[i]));

      // 2. configure range on the range-validation-module
      RangeConfiguration[] memory rangeConfigs = agentInput[i].genericInput.rangeConfigs;

      for (uint256 j = 0; j < rangeConfigs.length; j++) {
        RANGE_VALIDATION_MODULE.setDefaultRangeConfig(
          address(AGENT_HUB),
          agentIds[i],
          rangeConfigs[j].rangeUpdateType,
          rangeConfigs[j].config
        );
      }

      // 3. give permissions to new agent contracts
      ACL_MANAGER.addRiskAdmin(agentInput[i].agentAddress);

      // 4. revoke existing automated agrs permissions if it exists
      if (agentInput[i].existingStewardToRevoke != address(0)) {
        ACL_MANAGER.removeRiskAdmin(agentInput[i].existingStewardToRevoke);
      }

      if (address(ROBOT_OPERATOR) != address(0)) {
        // 5. cancel existing automation if it exists
        if (agentInput[i].automationIdToCancel != 0) {
          ROBOT_OPERATOR.cancel(agentInput[i].automationIdToCancel);
        }

        // 6. register new automation for the chaos-agents
        uint256 linkAmount = agentInput[i].linkAmountToFund;
        if (agentInput[i].withdrawLinkFromCollector) {
          // custom hook to fund the executor with link
          linkAmount = _fundExecutorWithLink(linkAmount);
        }

        IERC20(LINK_TOKEN).forceApprove(address(ROBOT_OPERATOR), linkAmount);
        ROBOT_OPERATOR.register(
          agentInput[i].genericInput.robotName, // name
          address(AUTOMATION_HUB_WRAPPER), // upkeepContract
          _encodeAgentIdToBytes(agentIds[i]), // upkeepCheckData
          5_000_000, // gasLimit
          linkAmount.toUint96(), // amountToFund
          0, // triggerType
          '' // triggerConfig
        );
      }
    }
  }

  // custom hook to fund the executor with link
  function _fundExecutorWithLink(uint256 linkAmount) internal virtual returns (uint256) {
    return CollectorUtils.withdrawFromV3(
      COLLECTOR,
      CollectorUtils.IOInput({
        pool: AAVE_POOL_FOR_LINK_WITHDRAW,
        underlying: LINK_TOKEN,
        amount: linkAmount
      }),
      address(this)
    );
  }

  function _repackRegistrationInput(
    AgentMigrationInput memory input
  ) internal view returns (IAgentConfigurator.AgentRegistrationInput memory) {
    return
      IAgentConfigurator.AgentRegistrationInput({
        admin: GOVERNANCE_EXECUTOR,
        riskOracle: RISK_ORACLE,
        isAgentEnabled: true, // default
        isAgentPermissioned: false, // default
        isMarketsFromAgentEnabled: false, // default
        agentAddress: input.agentAddress,
        expirationPeriod: input.genericInput.expirationPeriod,
        minimumDelay: input.genericInput.minimumDelay,
        updateType: input.genericInput.updateType,
        agentContext: input.agentContext,
        allowedMarkets: input.allowedMarkets,
        restrictedMarkets: new address[](0), // default
        permissionedSenders: new address[](0) // default
      });
  }

  // on the new chaos agent, we now will use the underlying address as the market address. risk-oracle after the migration
  // will use the underlying address instead of aToken as well for consistency. this method will be used for migration of caps agent.
  function _convertATokensMarketsToUnderlying(
    address injector
  ) internal view returns (address[] memory) {
    address[] memory currentATokenMarkets = IAaveStewardInjector(injector).getMarkets();
    address[] memory underlyingTokenMarkets = new address[](currentATokenMarkets.length);

    for (uint256 i = 0; i < currentATokenMarkets.length; i++) {
      underlyingTokenMarkets[i] = IAToken(currentATokenMarkets[i]).UNDERLYING_ASSET_ADDRESS();
    }
    return underlyingTokenMarkets;
  }

  function _encodeAgentIdToBytes(uint256 agentId) internal pure returns (bytes memory) {
    uint256[] memory agentIds = new uint256[](1);
    agentIds[0] = agentId;
    return abi.encode(agentIds);
  }
}
