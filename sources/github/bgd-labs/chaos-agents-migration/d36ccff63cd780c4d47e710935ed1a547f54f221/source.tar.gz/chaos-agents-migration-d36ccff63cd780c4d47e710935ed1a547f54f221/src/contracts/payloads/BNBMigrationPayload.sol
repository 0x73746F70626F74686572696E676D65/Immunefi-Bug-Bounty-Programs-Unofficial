// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;

import {AaveV3BNB} from 'aave-address-book/AaveV3BNB.sol';
import {GovernanceV3BNB} from 'aave-address-book/GovernanceV3BNB.sol';
import {MiscBNB} from 'aave-address-book/MiscBNB.sol';

import {BaseMigrationPayload} from '../BaseMigrationPayload.sol';
import {AgentConfigLib} from '../AgentConfigLib.sol';

contract BNBMigrationPayload is BaseMigrationPayload {
  address public constant ERC_677_LINK_TOKEN = 0x404460C6A5EdE2D891e8297795264fDe62ADBB75;

  address public constant SUPPLY_CAP_AGENT = 0x2cf0fA5b36F0f89a5EA18F835d1375974a7720B8;
  address public constant BORROW_CAP_AGENT = 0x970dDfF6c38B29D67DFe282306f7c0e1f5f31207;

  // https://automation.chain.link/bsc/39868774339380773402469695755921387745320300940048972111337976505038090169555
  uint256 public constant CAPS_INJECTOR_AUTOMATION_ID = 39868774339380773402469695755921387745320300940048972111337976505038090169555;

  constructor()
    BaseMigrationPayload(
      Constants({
        governanceExecutor: GovernanceV3BNB.EXECUTOR_LVL_1,
        riskOracle: AaveV3BNB.EDGE_RISK_ORACLE,
        aaveCollector: address(AaveV3BNB.COLLECTOR),
        aaveAclManager: address(AaveV3BNB.ACL_MANAGER),
        aavePoolForLinkWithdraw: address(AaveV3BNB.POOL),
        agentHub: MiscBNB.AGENT_HUB,
        automationHubWrapper: MiscBNB.AGENT_HUB_AUTOMATION,
        rangeValidationModule: MiscBNB.RANGE_VALIDATION_MODULE,
        chainlinkRobotOperator: MiscBNB.AAVE_CL_ROBOT_OPERATOR,
        linkToken: ERC_677_LINK_TOKEN
      })
    )
  {}

  function getAgentsMigrationInput() public view override returns (AgentMigrationInput[] memory) {
    AgentMigrationInput[] memory agentMigrationInputs = new AgentMigrationInput[](2);
    address[] memory markets = _convertATokensMarketsToUnderlying(AaveV3BNB.EDGE_INJECTOR_CAPS);

    // Supply Cap Agent
    agentMigrationInputs[0] = AgentMigrationInput({
      genericInput: AgentConfigLib.supplyCapAgentConfig(),
      agentAddress: SUPPLY_CAP_AGENT,
      agentContext: abi.encode(AaveV3BNB.CONFIG_ENGINE),
      allowedMarkets: markets,
      withdrawLinkFromCollector: false,
      linkAmountToFund: 30 ether,
      automationIdToCancel: CAPS_INJECTOR_AUTOMATION_ID,
      existingStewardToRevoke: AaveV3BNB.EDGE_RISK_STEWARD_CAPS
    });

    // Borrow Cap Agent
    agentMigrationInputs[1] = AgentMigrationInput({
      genericInput: AgentConfigLib.borrowCapAgentConfig(),
      agentAddress: BORROW_CAP_AGENT,
      agentContext: abi.encode(AaveV3BNB.CONFIG_ENGINE),
      allowedMarkets: markets,
      withdrawLinkFromCollector: false,
      linkAmountToFund: 30 ether,
      automationIdToCancel: 0, // cancelled in supplyCap agent so none here
      existingStewardToRevoke: address(0) // revoked already in supplyCap agent so none here
    });

    return agentMigrationInputs;
  }
}
