// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;

import {AaveV3Avalanche, AaveV3AvalancheAssets} from 'aave-address-book/AaveV3Avalanche.sol';
import {GovernanceV3Avalanche} from 'aave-address-book/GovernanceV3Avalanche.sol';
import {MiscAvalanche} from 'aave-address-book/MiscAvalanche.sol';

import {BaseMigrationPayload} from '../BaseMigrationPayload.sol';
import {AgentConfigLib} from '../AgentConfigLib.sol';

contract AvalancheMigrationPayload is BaseMigrationPayload {
  address public constant SUPPLY_CAP_AGENT = 0x38753B4D5116b12bC3524e334bC76AE57fA42fFB;
  address public constant BORROW_CAP_AGENT = 0xb57C37F48d1De2DACBefed69679Ba0b7DC43A394;

  // https://automation.chain.link/avalanche/58979017884852952105802365841622172342311193368376669156090246547607375727894
  uint256 public constant CAPS_INJECTOR_AUTOMATION_ID = 58979017884852952105802365841622172342311193368376669156090246547607375727894;

  constructor()
    BaseMigrationPayload(
      Constants({
        governanceExecutor: GovernanceV3Avalanche.EXECUTOR_LVL_1,
        riskOracle: AaveV3Avalanche.EDGE_RISK_ORACLE,
        aaveCollector: address(AaveV3Avalanche.COLLECTOR),
        aaveAclManager: address(AaveV3Avalanche.ACL_MANAGER),
        aavePoolForLinkWithdraw: address(AaveV3Avalanche.POOL),
        agentHub: MiscAvalanche.AGENT_HUB,
        automationHubWrapper: MiscAvalanche.AGENT_HUB_AUTOMATION,
        rangeValidationModule: MiscAvalanche.RANGE_VALIDATION_MODULE,
        chainlinkRobotOperator: MiscAvalanche.AAVE_CL_ROBOT_OPERATOR,
        linkToken: AaveV3AvalancheAssets.LINKe_UNDERLYING
      })
    )
  {}

  function getAgentsMigrationInput() public view override returns (AgentMigrationInput[] memory) {
    AgentMigrationInput[] memory agentMigrationInputs = new AgentMigrationInput[](2);
    address[] memory markets = _convertATokensMarketsToUnderlying(
      AaveV3Avalanche.EDGE_INJECTOR_CAPS
    );

    // Supply Cap Agent
    agentMigrationInputs[0] = AgentMigrationInput({
      genericInput: AgentConfigLib.supplyCapAgentConfig(),
      agentAddress: SUPPLY_CAP_AGENT,
      agentContext: abi.encode(AaveV3Avalanche.CONFIG_ENGINE),
      allowedMarkets: markets,
      withdrawLinkFromCollector: true,
      linkAmountToFund: 50 ether,
      automationIdToCancel: CAPS_INJECTOR_AUTOMATION_ID,
      existingStewardToRevoke: AaveV3Avalanche.EDGE_RISK_STEWARD_CAPS
    });

    // Borrow Cap Agent
    agentMigrationInputs[1] = AgentMigrationInput({
      genericInput: AgentConfigLib.borrowCapAgentConfig(),
      agentAddress: BORROW_CAP_AGENT,
      agentContext: abi.encode(AaveV3Avalanche.CONFIG_ENGINE),
      allowedMarkets: markets,
      withdrawLinkFromCollector: true,
      linkAmountToFund: 50 ether,
      automationIdToCancel: 0, // cancelled in supplyCap agent so none here
      existingStewardToRevoke: address(0) // revoked already in supplyCap agent so none here
    });

    return agentMigrationInputs;
  }
}
