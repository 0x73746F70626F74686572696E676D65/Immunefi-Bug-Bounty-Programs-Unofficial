// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;

import {AaveV3Base} from 'aave-address-book/AaveV3Base.sol';
import {GovernanceV3Base} from 'aave-address-book/GovernanceV3Base.sol';
import {MiscBase} from 'aave-address-book/MiscBase.sol';

import {BaseMigrationPayload} from '../BaseMigrationPayload.sol';
import {AgentConfigLib} from '../AgentConfigLib.sol';

contract BaseNetworkMigrationPayload is BaseMigrationPayload {
  address public constant ERC_677_LINK_TOKEN = 0x88Fb150BDc53A65fe94Dea0c9BA0a6dAf8C6e196;

  address public constant SUPPLY_CAP_AGENT = 0x42ca9E62C9B61d01Bb222d6E69f095eE98e61cE8;
  address public constant BORROW_CAP_AGENT = 0x0ae2815b1f607EfEe34C15E63c72Cd6C99d1D6fa;

  // https://automation.chain.link/base/54509807890437362809825188947209555677965553335551150241349001097422205821886
  uint256 public constant CAPS_INJECTOR_AUTOMATION_ID = 54509807890437362809825188947209555677965553335551150241349001097422205821886;

  constructor()
    BaseMigrationPayload(
      Constants({
        governanceExecutor: GovernanceV3Base.EXECUTOR_LVL_1,
        riskOracle: AaveV3Base.EDGE_RISK_ORACLE,
        aaveCollector: address(AaveV3Base.COLLECTOR),
        aaveAclManager: address(AaveV3Base.ACL_MANAGER),
        aavePoolForLinkWithdraw: address(AaveV3Base.POOL),
        agentHub: MiscBase.AGENT_HUB,
        automationHubWrapper: MiscBase.AGENT_HUB_AUTOMATION,
        rangeValidationModule: MiscBase.RANGE_VALIDATION_MODULE,
        chainlinkRobotOperator: MiscBase.AAVE_CL_ROBOT_OPERATOR,
        linkToken: ERC_677_LINK_TOKEN
      })
    )
  {}

  function getAgentsMigrationInput() public view override returns (AgentMigrationInput[] memory) {
    AgentMigrationInput[] memory agentMigrationInputs = new AgentMigrationInput[](2);
    address[] memory markets = _convertATokensMarketsToUnderlying(AaveV3Base.EDGE_INJECTOR_CAPS);

    // Supply Cap Agent
    agentMigrationInputs[0] = AgentMigrationInput({
      genericInput: AgentConfigLib.supplyCapAgentConfig(),
      agentAddress: SUPPLY_CAP_AGENT,
      agentContext: abi.encode(AaveV3Base.CONFIG_ENGINE),
      allowedMarkets: markets,
      withdrawLinkFromCollector: false,
      linkAmountToFund: 30 ether,
      automationIdToCancel: CAPS_INJECTOR_AUTOMATION_ID,
      existingStewardToRevoke: AaveV3Base.EDGE_RISK_STEWARD_CAPS
    });

    // Borrow Cap Agent
    agentMigrationInputs[1] = AgentMigrationInput({
      genericInput: AgentConfigLib.borrowCapAgentConfig(),
      agentAddress: BORROW_CAP_AGENT,
      agentContext: abi.encode(AaveV3Base.CONFIG_ENGINE),
      allowedMarkets: markets,
      withdrawLinkFromCollector: false,
      linkAmountToFund: 30 ether,
      automationIdToCancel: 0, // cancelled in supplyCap agent so none here
      existingStewardToRevoke: address(0) // revoked already in supplyCap agent so none here
    });

    return agentMigrationInputs;
  }
}
