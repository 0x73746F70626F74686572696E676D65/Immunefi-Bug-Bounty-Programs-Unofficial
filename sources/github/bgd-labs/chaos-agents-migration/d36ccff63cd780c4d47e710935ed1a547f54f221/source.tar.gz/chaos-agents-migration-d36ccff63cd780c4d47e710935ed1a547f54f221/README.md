# Chaos Agent Migration

This repository contains governance proposal payloads for migrating Aave's risk parameter automation from the legacy
[Edge AGRS middleware](https://github.com/aave-dao/aave-v3-risk-stewards/blob/main/src/contracts/AaveStewardInjectorBase.sol) to the new [Chaos Agent](https://github.com/ChaosLabsInc/chaos-agents) middleware.

## Architecture

<img width="971" height="589" alt="Screenshot 2025-10-28 at 6 32 20 PM" src="https://github.com/user-attachments/assets/be982284-1638-4532-8a53-7bf52035284a" />

Currently, the Aave protocol uses the Edge AGRS middleware infrastructure to pull updates from the Chaos risk oracle and apply them to the protocol.
The payloads in this repository contain configurations and operations to migrate to the new system.

At the moment, the Edge AGRS middleware automates the following risk parameters on the Aave protocol:

| Risk Param                                    | Network Instance                                     |
| --------------------------------------------- | ---------------------------------------------------- |
| Supply and Borrow Caps                        | Arbitrum, Avax, Base, BNB, Gnosis, Optimism, Polygon |
| Pendle EMode Collateral Param                 | EthereumCore, Plasma                                 |
| Pendle Discount Rate                          | EthereumCore, Plasma                                 |
| Interest Rate: Base, Slope1, Slope2, uOptimal | EthereumPrime                                        |
| Interest Rate: Slope2                         | EthereumCore, Linea                                  |

### [Base Migration Payload](./src/contracts/BaseMigrationPayload.sol):

The base migration payload performs the following actions:
1. Registers the new agents on the Agent Hub of the Chaos Agent infrastructure.
2. Sets up risk parameter validation ranges in the range validation module to be used by the new Chaos Agent system.
3. Assigns RISK_ADMIN role to the new agent contract, enabling the Agent Hub to call it to inject updates into the protocol.
4. Revokes RISK_ADMIN role from the previous Edge AGRS injector middleware contract, as it is no longer needed.
5. Disables Chainlink automation for the current Edge AGRS system where it exists.
6. Sets up new Chainlink automation for the Chaos Agent system. Link tokens will be withdrawn from the collector as needed to fund the automation. **Note**: For networks using Gelato, automation cancellation and registration will be handled manually outside of this payload.

### [AgentConfigLib](./src/contracts/AgentConfigLib.sol):

A library that contains the generic configuration for each agent, including the new range configurations which will be used by the migration payload when registering the new agents.

## Risk Oracle Migration:

To better align data on the risk oracle, the following changes will be applied to the Chaos risk oracle for the migration:

- CapsUpdate:
  - Change updateType from `supplyCap`, `borrowCap` to `SupplyCapUpdate`, `BorrowCapUpdate`
  - Change market address from aToken address to underlying reserve address
  - Change cap value encoded in uint256 with decimals to without decimals

- RatesUpdate:
  - Change updateType from `RateStrategyUpdate` to `RateStrategyUpdate_Prime` for prime instance

***Note**: Only on mainnet, the updateType will include Core and Prime appendices, enabling the use of market as underlying reserve address instead of aToken addresses. The risk oracle changes will be implemented (in coordination with Chaos Labs) just before governance executes the payloads to avoid breaking the existing Edge AGRS middleware.*

### Setup

```sh
cp .env.example .env
forge install
```

### Test

```sh
forge test
```

## License

This project is released under the [MIT license](./LICENSE). Copyright © 2025, Aave DAO, represented by its governance smart contracts.
