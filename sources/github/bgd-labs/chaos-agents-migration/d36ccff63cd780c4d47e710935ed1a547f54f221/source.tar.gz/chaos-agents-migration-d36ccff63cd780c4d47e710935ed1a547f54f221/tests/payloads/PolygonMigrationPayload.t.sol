// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;

import {BaseMigrationPayloadTest} from '../BaseMigrationPayload.t.sol';
import '../../src/contracts/payloads/PolygonMigrationPayload.sol';

contract PolygonMigrationPayloadTest is BaseMigrationPayloadTest {
  constructor()
    BaseMigrationPayloadTest(
      BaseMigrationPayloadTest.ForkParams({
        testName: 'PolygonMigrationPayloadTest',
        network: 'polygon',
        blockNumber: 80176349
      })
    )
  {}

  function _getPayloadBytecode() internal pure override returns (bytes memory) {
    return type(PolygonMigrationPayload).creationCode;
  }

  function _getRiskOracleUpdatesToInject()
    internal
    view
    override
    returns (RiskParameterUpdate[] memory)
  {
    RiskParameterUpdate[] memory updatesToInject = new RiskParameterUpdate[](2);
    (uint256 currentBorrowCap, uint256 currentSupplyCap) = AaveV3Polygon
      .AAVE_PROTOCOL_DATA_PROVIDER
      .getReserveCaps(AaveV3PolygonAssets.WETH_UNDERLYING);
    uint256 newBorrowCap = (currentBorrowCap * 130) / 100;
    uint256 newSupplyCap = (currentSupplyCap * 130) / 100;

    updatesToInject[0] = RiskParameterUpdate({
      newValue: abi.encodePacked(newSupplyCap),
      updateType: 'SupplyCapUpdate',
      market: AaveV3PolygonAssets.WETH_UNDERLYING
    });
    updatesToInject[1] = RiskParameterUpdate({
      newValue: abi.encodePacked(newBorrowCap),
      updateType: 'BorrowCapUpdate',
      market: AaveV3PolygonAssets.WETH_UNDERLYING
    });

    return updatesToInject;
  }

  function _getIncorrectRiskOracleUpdatesToNotInject()
    internal
    view
    override
    returns (RiskParameterUpdate[] memory)
  {
    RiskParameterUpdate[] memory updatesToNotInject = new RiskParameterUpdate[](2);
    (uint256 currentBorrowCap, uint256 currentSupplyCap) = AaveV3Polygon
      .AAVE_PROTOCOL_DATA_PROVIDER
      .getReserveCaps(AaveV3PolygonAssets.WETH_UNDERLYING);
    uint256 newBorrowCap = ((currentBorrowCap * 130) / 100) + 1;
    uint256 newSupplyCap = ((currentSupplyCap * 130) / 100) + 1;

    updatesToNotInject[0] = RiskParameterUpdate({
      newValue: abi.encodePacked(newSupplyCap),
      updateType: 'SupplyCapUpdate',
      market: AaveV3PolygonAssets.WETH_UNDERLYING
    });
    updatesToNotInject[1] = RiskParameterUpdate({
      newValue: abi.encodePacked(newBorrowCap),
      updateType: 'BorrowCapUpdate',
      market: AaveV3PolygonAssets.WETH_UNDERLYING
    });

    return updatesToNotInject;
  }
}
