// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;

import {AaveV3BaseAssets} from 'aave-address-book/AaveV3Base.sol';

import {BaseMigrationPayloadTest, IRiskOracle} from '../BaseMigrationPayload.t.sol';
import '../../src/contracts/payloads/BaseNetworkMigrationPayload.sol';

contract BaseNetworkMigrationPayloadTest is BaseMigrationPayloadTest {
  constructor()
    BaseMigrationPayloadTest(
      BaseMigrationPayloadTest.ForkParams({
        testName: 'BaseMigrationPayloadTest',
        network: 'base',
        blockNumber: 39333861
      })
    )
  {}

  function _postSetUp() internal override {
    // TODO: fund link manually as collector on base does not have link
    deal(payload.LINK_TOKEN(), GovernanceV3Base.EXECUTOR_LVL_1, 60 ether);
  }

  function _getPayloadBytecode() internal pure override returns (bytes memory) {
    return type(BaseNetworkMigrationPayload).creationCode;
  }

  function _getRiskOracleUpdatesToInject()
    internal
    view
    override
    returns (RiskParameterUpdate[] memory)
  {
    RiskParameterUpdate[] memory updatesToInject = new RiskParameterUpdate[](2);
    (uint256 currentBorrowCap, uint256 currentSupplyCap) = AaveV3Base
      .AAVE_PROTOCOL_DATA_PROVIDER
      .getReserveCaps(AaveV3BaseAssets.WETH_UNDERLYING);
    uint256 newBorrowCap = (currentBorrowCap * 130) / 100;
    uint256 newSupplyCap = (currentSupplyCap * 130) / 100;

    updatesToInject[0] = RiskParameterUpdate({
      newValue: abi.encodePacked(newSupplyCap),
      updateType: 'SupplyCapUpdate',
      market: AaveV3BaseAssets.WETH_UNDERLYING
    });
    updatesToInject[1] = RiskParameterUpdate({
      newValue: abi.encodePacked(newBorrowCap),
      updateType: 'BorrowCapUpdate',
      market: AaveV3BaseAssets.WETH_UNDERLYING
    });

    return updatesToInject;
  }

  function _getIncorrectRiskOracleUpdatesToNotInject()
    internal
    view
    override
    returns (RiskParameterUpdate[] memory)
  {
    RiskParameterUpdate[] memory updatesToNotInject = new RiskParameterUpdate[](2);
    (uint256 currentBorrowCap, uint256 currentSupplyCap) = AaveV3Base
      .AAVE_PROTOCOL_DATA_PROVIDER
      .getReserveCaps(AaveV3BaseAssets.WETH_UNDERLYING);
    uint256 newBorrowCap = ((currentBorrowCap * 130) / 100) + 1;
    uint256 newSupplyCap = ((currentSupplyCap * 130) / 100) + 1;

    updatesToNotInject[0] = RiskParameterUpdate({
      newValue: abi.encodePacked(newSupplyCap),
      updateType: 'SupplyCapUpdate',
      market: AaveV3BaseAssets.WETH_UNDERLYING
    });
    updatesToNotInject[1] = RiskParameterUpdate({
      newValue: abi.encodePacked(newBorrowCap),
      updateType: 'BorrowCapUpdate',
      market: AaveV3BaseAssets.WETH_UNDERLYING
    });

    return updatesToNotInject;
  }
}
