// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;

import {IAaveV3ConfigEngine as IEngine} from 'aave-v3-origin/src/contracts/extensions/v3-config-engine/IAaveV3ConfigEngine.sol';
import {IDefaultInterestRateStrategyV2} from 'aave-v3-origin/src/contracts/interfaces/IDefaultInterestRateStrategyV2.sol';
import {DataTypes} from 'aave-v3-origin/src/contracts/protocol/libraries/types/DataTypes.sol';

import {BaseMigrationPayloadTest} from '../BaseMigrationPayload.t.sol';
import '../../src/contracts/payloads/EthereumCoreMigrationPayload.sol';

contract EthereumCoreMigrationPayloadTest is BaseMigrationPayloadTest {
  constructor()
    BaseMigrationPayloadTest(
      BaseMigrationPayloadTest.ForkParams({
        testName: 'EthereumCoreMigrationPayloadTest',
        network: 'mainnet',
        blockNumber: 23989455
      })
    )
  {}

  function _getPayloadBytecode() internal pure override returns (bytes memory) {
    return type(EthereumCoreMigrationPayload).creationCode;
  }

  function _getRiskOracleUpdatesToInject()
    internal
    view
    override
    returns (RiskParameterUpdate[] memory)
  {
    RiskParameterUpdate[] memory updatesToInject = new RiskParameterUpdate[](3);

    // interest rate update
    address rateStrategyAddress = AaveV3Ethereum
      .AAVE_PROTOCOL_DATA_PROVIDER
      .getInterestRateStrategyAddress(AaveV3EthereumAssets.WETH_UNDERLYING);

    IDefaultInterestRateStrategyV2.InterestRateData
      memory currentRate = IDefaultInterestRateStrategyV2(rateStrategyAddress)
        .getInterestRateDataBps(AaveV3EthereumAssets.WETH_UNDERLYING);

    IEngine.InterestRateInputData memory newRate = IEngine.InterestRateInputData({
      optimalUsageRatio: currentRate.optimalUsageRatio,
      baseVariableBorrowRate: currentRate.baseVariableBorrowRate,
      variableRateSlope1: currentRate.variableRateSlope1,
      variableRateSlope2: currentRate.variableRateSlope2 + 4_00
    });

    updatesToInject[0] = RiskParameterUpdate({
      newValue: abi.encode(newRate),
      updateType: 'RateStrategyUpdate_Core',
      market: AaveV3EthereumAssets.WETH_UNDERLYING
    });

    // discount rate update
    address discountRateMarket = AaveV3EthereumAssets.PT_USDe_5FEB2026_UNDERLYING;
    uint256 currentDiscountRate = IPendlePriceCapAdapter(
      AaveV3Ethereum.ORACLE.getSourceOfAsset(discountRateMarket)
    ).discountRatePerYear();
    updatesToInject[1] = RiskParameterUpdate({
      newValue: abi.encodePacked(currentDiscountRate + 0.01e18), // increase by 1% absolute value
      updateType: 'PendleDiscountRateUpdate_Core',
      market: discountRateMarket
    });

    // emode update
    DataTypes.EModeCategoryLegacy memory eModeData = AaveV3Ethereum.POOL.getEModeCategoryData(25);
    updatesToInject[2] = RiskParameterUpdate({
      newValue: abi.encode(
        IAaveEModeAgent.EModeCategoryUpdate({
          ltv: eModeData.ltv + 50,
          liquidationThreshold: eModeData.liquidationThreshold + 50,
          liquidationBonus: (eModeData.liquidationBonus - 100_00) + 50
        })
      ),
      updateType: 'EModeCategoryUpdate_Core',
      market: address(uint160(25))
    });

    return updatesToInject;
  }

  function _getIncorrectRiskOracleUpdatesToNotInject()
    internal
    view
    override
    returns (RiskParameterUpdate[] memory)
  {
    RiskParameterUpdate[] memory updatesToNotInject = new RiskParameterUpdate[](3);

    // interest rate update
    address rateStrategyAddress = AaveV3Ethereum
      .AAVE_PROTOCOL_DATA_PROVIDER
      .getInterestRateStrategyAddress(AaveV3EthereumAssets.WETH_UNDERLYING);

    IDefaultInterestRateStrategyV2.InterestRateData
      memory currentRate = IDefaultInterestRateStrategyV2(rateStrategyAddress)
        .getInterestRateDataBps(AaveV3EthereumAssets.WETH_UNDERLYING);

    IEngine.InterestRateInputData memory newRate = IEngine.InterestRateInputData({
      optimalUsageRatio: currentRate.optimalUsageRatio,
      baseVariableBorrowRate: currentRate.baseVariableBorrowRate,
      variableRateSlope1: currentRate.variableRateSlope1,
      variableRateSlope2: currentRate.variableRateSlope2 + 4_00 + 1
    });

    updatesToNotInject[0] = RiskParameterUpdate({
      newValue: abi.encode(newRate),
      updateType: 'RateStrategyUpdate_Core',
      market: AaveV3EthereumAssets.WETH_UNDERLYING
    });

    // discount rate update
    address discountRateMarket = AaveV3EthereumAssets.PT_USDe_5FEB2026_UNDERLYING;
    uint256 currentDiscountRate = IPendlePriceCapAdapter(
      AaveV3Ethereum.ORACLE.getSourceOfAsset(discountRateMarket)
    ).discountRatePerYear();
    updatesToNotInject[1] = RiskParameterUpdate({
      newValue: abi.encodePacked(currentDiscountRate + 0.01e18 + 1), // increase by 1% absolute value + 1
      updateType: 'PendleDiscountRateUpdate_Core',
      market: discountRateMarket
    });

    // emode update
    DataTypes.EModeCategoryLegacy memory eModeData = AaveV3Ethereum.POOL.getEModeCategoryData(25);
    updatesToNotInject[2] = RiskParameterUpdate({
      newValue: abi.encode(
        IAaveEModeAgent.EModeCategoryUpdate({
          ltv: eModeData.ltv + 50 + 1,
          liquidationThreshold: eModeData.liquidationThreshold + 50 + 1,
          liquidationBonus: (eModeData.liquidationBonus - 100_00) + 50 + 1
        })
      ),
      updateType: 'EModeCategoryUpdate_Core',
      market: address(uint160(25))
    });

    return updatesToNotInject;
  }
}

interface IPendlePriceCapAdapter {
  function discountRatePerYear() external view returns (uint64 discountRatePerYear);
}

interface IAaveEModeAgent {
  struct EModeCategoryUpdate {
    uint256 ltv;
    uint256 liquidationThreshold;
    uint256 liquidationBonus;
  }
}
