// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;

import {BaseMigrationPayloadTest, IRiskOracle} from '../BaseMigrationPayload.t.sol';
import '../../src/contracts/payloads/ArbitrumMigrationPayload.sol';

contract ArbitrumMigrationPayloadTest is BaseMigrationPayloadTest {
  address public constant ARB_SYS = 0x0000000000000000000000000000000000000064;

  constructor()
    BaseMigrationPayloadTest(
      BaseMigrationPayloadTest.ForkParams({
        testName: 'ArbitrumMigrationPayloadTest',
        network: 'arbitrum',
        blockNumber: 409537419
      })
    )
  {}

  function setUp() public override {
    super.setUp();

    // https://github.com/foundry-rs/foundry/issues/5085
    vm.mockCall(
      ARB_SYS,
      abi.encodeWithSelector(ArbSys.arbBlockNumber.selector),
      abi.encode(forkParams.blockNumber)
    );
    vm.mockCall(
      ARB_SYS,
      abi.encodeWithSelector(ArbSys.arbBlockHash.selector, forkParams.blockNumber - 1),
      abi.encode(0xbe6f5dfa9ce3324bd677f5195ecd8d1a258cbf3800f24621d0e0d2724224704f)
    );
  }

  function _getPayloadBytecode() internal pure override returns (bytes memory) {
    return type(ArbitrumMigrationPayload).creationCode;
  }

  function _getRiskOracleUpdatesToInject()
    internal
    view
    override
    returns (RiskParameterUpdate[] memory)
  {
    RiskParameterUpdate[] memory updatesToInject = new RiskParameterUpdate[](2);
    (uint256 currentBorrowCap, uint256 currentSupplyCap) = AaveV3Arbitrum
      .AAVE_PROTOCOL_DATA_PROVIDER
      .getReserveCaps(AaveV3ArbitrumAssets.WETH_UNDERLYING);
    uint256 newBorrowCap = (currentBorrowCap * 130) / 100;
    uint256 newSupplyCap = (currentSupplyCap * 130) / 100;

    updatesToInject[0] = RiskParameterUpdate({
      newValue: abi.encodePacked(newSupplyCap),
      updateType: 'SupplyCapUpdate',
      market: AaveV3ArbitrumAssets.WETH_UNDERLYING
    });
    updatesToInject[1] = RiskParameterUpdate({
      newValue: abi.encodePacked(newBorrowCap),
      updateType: 'BorrowCapUpdate',
      market: AaveV3ArbitrumAssets.WETH_UNDERLYING
    });

    return updatesToInject;
  }

  function _getIncorrectRiskOracleUpdatesToNotInject() internal view override returns (RiskParameterUpdate[] memory) {
    RiskParameterUpdate[] memory updatesToInject = new RiskParameterUpdate[](2);
    (uint256 currentBorrowCap, uint256 currentSupplyCap) = AaveV3Arbitrum
      .AAVE_PROTOCOL_DATA_PROVIDER
      .getReserveCaps(AaveV3ArbitrumAssets.WETH_UNDERLYING);
    uint256 newBorrowCap = ((currentBorrowCap * 130) / 100) + 1;
    uint256 newSupplyCap = ((currentSupplyCap * 130) / 100) + 1;

    updatesToInject[0] = RiskParameterUpdate({
      newValue: abi.encodePacked(newSupplyCap),
      updateType: 'SupplyCapUpdate',
      market: AaveV3ArbitrumAssets.WETH_UNDERLYING
    });
    updatesToInject[1] = RiskParameterUpdate({
      newValue: abi.encodePacked(newBorrowCap),
      updateType: 'BorrowCapUpdate',
      market: AaveV3ArbitrumAssets.WETH_UNDERLYING
    });

    return updatesToInject;
  }
}

/**
 * @title System level functionality
 * @notice For use by contracts to interact with core L2-specific functionality.
 * Precompiled contract that exists in every Arbitrum chain at address(100), 0x0000000000000000000000000000000000000064.
 */
interface ArbSys {
  /**
   * @notice Get Arbitrum block number (distinct from L1 block number; Arbitrum genesis block has block number 0)
   * @return block number as int
   */
  function arbBlockNumber() external view returns (uint256);

  /**
   * @notice Get Arbitrum block hash (reverts unless currentBlockNum-256 <= arbBlockNum < currentBlockNum)
   * @return block hash
   */
  function arbBlockHash(uint256 arbBlockNum) external view returns (bytes32);
}
