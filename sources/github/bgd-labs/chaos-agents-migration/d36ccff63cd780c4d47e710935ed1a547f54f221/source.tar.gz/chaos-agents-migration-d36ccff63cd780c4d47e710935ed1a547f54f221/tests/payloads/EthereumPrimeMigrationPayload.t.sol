// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;

import {IAaveV3ConfigEngine as IEngine} from 'aave-v3-origin/src/contracts/extensions/v3-config-engine/IAaveV3ConfigEngine.sol';
import {IDefaultInterestRateStrategyV2} from 'aave-v3-origin/src/contracts/interfaces/IDefaultInterestRateStrategyV2.sol';

import {BaseMigrationPayloadTest, GovV3Helpers, IBaseAaveAgent} from '../BaseMigrationPayload.t.sol';
import '../../src/contracts/payloads/EthereumPrimeMigrationPayload.sol';

contract EthereumPrimeMigrationPayloadTest is BaseMigrationPayloadTest {
  constructor()
    BaseMigrationPayloadTest(
      BaseMigrationPayloadTest.ForkParams({
        testName: 'EthereumPrimeMigrationPayloadTest',
        network: 'mainnet',
        blockNumber: 23989455
      })
    )
  {}

  function _getPayloadBytecode() internal pure override returns (bytes memory) {
    return type(EthereumPrimeMigrationPayload).creationCode;
  }

  function _getRiskOracleUpdatesToInject()
    internal
    view
    override
    returns (RiskParameterUpdate[] memory)
  {
    RiskParameterUpdate[] memory updatesToInject = new RiskParameterUpdate[](1);

    address rateStrategyAddress = AaveV3EthereumLido
      .AAVE_PROTOCOL_DATA_PROVIDER
      .getInterestRateStrategyAddress(AaveV3EthereumLidoAssets.WETH_UNDERLYING);

    IDefaultInterestRateStrategyV2.InterestRateData
      memory currentRate = IDefaultInterestRateStrategyV2(rateStrategyAddress)
        .getInterestRateDataBps(AaveV3EthereumLidoAssets.WETH_UNDERLYING);

    IEngine.InterestRateInputData memory newRate = IEngine.InterestRateInputData({
      optimalUsageRatio: currentRate.optimalUsageRatio + 3_00,
      baseVariableBorrowRate: currentRate.baseVariableBorrowRate + 50,
      variableRateSlope1: currentRate.variableRateSlope1 + 50,
      variableRateSlope2: currentRate.variableRateSlope2 + 5_00
    });

    updatesToInject[0] = RiskParameterUpdate({
      newValue: abi.encode(newRate),
      updateType: 'RateStrategyUpdate_Prime',
      market: AaveV3EthereumLidoAssets.WETH_UNDERLYING
    });
    return updatesToInject;
  }

  function _getIncorrectRiskOracleUpdatesToNotInject()
    internal
    view
    override
    returns (RiskParameterUpdate[] memory)
  {
    RiskParameterUpdate[] memory updatesToNotInject = new RiskParameterUpdate[](1);

    address rateStrategyAddress = AaveV3EthereumLido
      .AAVE_PROTOCOL_DATA_PROVIDER
      .getInterestRateStrategyAddress(AaveV3EthereumLidoAssets.WETH_UNDERLYING);

    IDefaultInterestRateStrategyV2.InterestRateData
      memory currentRate = IDefaultInterestRateStrategyV2(rateStrategyAddress)
        .getInterestRateDataBps(AaveV3EthereumLidoAssets.WETH_UNDERLYING);

    IEngine.InterestRateInputData memory newRate = IEngine.InterestRateInputData({
      optimalUsageRatio: currentRate.optimalUsageRatio + 3_00 + 1,
      baseVariableBorrowRate: currentRate.baseVariableBorrowRate + 50 + 1,
      variableRateSlope1: currentRate.variableRateSlope1 + 50 + 1,
      variableRateSlope2: currentRate.variableRateSlope2 + 5_00 + 1
    });

    updatesToNotInject[0] = RiskParameterUpdate({
      newValue: abi.encode(newRate),
      updateType: 'RateStrategyUpdate_Prime',
      market: AaveV3EthereumLidoAssets.WETH_UNDERLYING
    });
    return updatesToNotInject;
  }

  // we override this test as the pool address on payload is of core instance to withdraw aLink
  function test_validateAgentContractImmutables() public override {
    GovV3Helpers.executePayload(vm, address(payload));
    uint256 agentCount = payload.AGENT_HUB().getAgentCount();

    for (uint256 i = 0; i < agentCount; i++) {
      address agentContract = payload.AGENT_HUB().getAgentAddress(i);
      assertEq(
        address(IBaseAaveAgent(agentContract).RANGE_VALIDATION_MODULE()),
        address(payload.RANGE_VALIDATION_MODULE())
      );
      assertEq(address(IBaseAaveAgent(agentContract).POOL()), address(AaveV3EthereumLido.POOL));
      assertEq(address(IBaseAaveAgent(agentContract).AGENT_HUB()), address(payload.AGENT_HUB()));
    }
  }
}
