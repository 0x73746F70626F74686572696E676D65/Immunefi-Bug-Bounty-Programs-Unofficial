// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;

import {IDefaultInterestRateStrategyV2} from 'aave-v3-origin/src/contracts/interfaces/IDefaultInterestRateStrategyV2.sol';
import {IAaveV3ConfigEngine as IEngine} from 'aave-v3-origin/src/contracts/extensions/v3-config-engine/IAaveV3ConfigEngine.sol';
import {AaveV3LineaAssets} from 'aave-address-book/AaveV3Linea.sol';

import {BaseMigrationPayloadTest} from '../BaseMigrationPayload.t.sol';
import '../../src/contracts/payloads/LineaMigrationPayload.sol';

contract LineaMigrationPayloadTest is BaseMigrationPayloadTest {
  constructor()
    BaseMigrationPayloadTest(
      BaseMigrationPayloadTest.ForkParams({
        testName: 'LineaMigrationPayloadTest',
        network: 'linea',
        blockNumber: 26566734
      })
    )
  {}

  function _getPayloadBytecode() internal pure override returns (bytes memory) {
    return type(LineaMigrationPayload).creationCode;
  }

  function _getRiskOracleUpdatesToInject()
    internal
    view
    override
    returns (RiskParameterUpdate[] memory)
  {
    RiskParameterUpdate[] memory updatesToInject = new RiskParameterUpdate[](1);

    // push slope2 rate update
    address rateStrategyAddress = AaveV3Linea
      .AAVE_PROTOCOL_DATA_PROVIDER
      .getInterestRateStrategyAddress(AaveV3LineaAssets.WETH_UNDERLYING);

    IDefaultInterestRateStrategyV2.InterestRateData
      memory currentRate = IDefaultInterestRateStrategyV2(rateStrategyAddress)
        .getInterestRateDataBps(AaveV3LineaAssets.WETH_UNDERLYING);

    IEngine.InterestRateInputData memory newRate = IEngine.InterestRateInputData({
      optimalUsageRatio: currentRate.optimalUsageRatio,
      baseVariableBorrowRate: currentRate.baseVariableBorrowRate,
      variableRateSlope1: currentRate.variableRateSlope1,
      variableRateSlope2: currentRate.variableRateSlope2 + 4_00
    });

    updatesToInject[0] = RiskParameterUpdate({
      newValue: abi.encode(newRate),
      updateType: 'RateStrategyUpdate',
      market: AaveV3LineaAssets.WETH_UNDERLYING
    });

    return updatesToInject;
  }

  function _getIncorrectRiskOracleUpdatesToNotInject()
    internal
    view
    override
    returns (RiskParameterUpdate[] memory)
  {
    RiskParameterUpdate[] memory updatesToNotInject = new RiskParameterUpdate[](1);

    // push slope2 rate update
    address rateStrategyAddress = AaveV3Linea
      .AAVE_PROTOCOL_DATA_PROVIDER
      .getInterestRateStrategyAddress(AaveV3LineaAssets.WETH_UNDERLYING);

    IDefaultInterestRateStrategyV2.InterestRateData
      memory currentRate = IDefaultInterestRateStrategyV2(rateStrategyAddress)
        .getInterestRateDataBps(AaveV3LineaAssets.WETH_UNDERLYING);

    IEngine.InterestRateInputData memory newRate = IEngine.InterestRateInputData({
      optimalUsageRatio: currentRate.optimalUsageRatio,
      baseVariableBorrowRate: currentRate.baseVariableBorrowRate,
      variableRateSlope1: currentRate.variableRateSlope1,
      variableRateSlope2: currentRate.variableRateSlope2 + 4_00 + 1
    });

    updatesToNotInject[0] = RiskParameterUpdate({
      newValue: abi.encode(newRate),
      updateType: 'RateStrategyUpdate',
      market: AaveV3LineaAssets.WETH_UNDERLYING
    });

    return updatesToNotInject;
  }
}
