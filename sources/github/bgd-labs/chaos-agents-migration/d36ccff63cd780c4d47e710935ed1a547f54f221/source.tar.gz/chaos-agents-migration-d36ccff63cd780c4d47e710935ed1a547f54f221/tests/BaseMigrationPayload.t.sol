// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;

import {IChainlinkAutomationHub} from 'chaos-agents/src/interfaces/IChainlinkAutomationHub.sol';
import {IGelatoAutomationHub} from 'chaos-agents/src/interfaces/IGelatoAutomationHub.sol';
import {IRiskOracle} from 'chaos-agents/src/contracts/dependencies/IRiskOracle.sol';
import {ProtocolV3TestBase, IPool, GovV3Helpers} from 'aave-helpers/src/ProtocolV3TestBase.sol';
import {AaveV3PolygonAssets} from 'aave-address-book/AaveV3Polygon.sol';
import {Ownable} from 'aave-v3-origin/src/contracts/dependencies/openzeppelin/contracts/Ownable.sol';
import {Strings} from 'openzeppelin-contracts/contracts/utils/Strings.sol';
import '../src/contracts/BaseMigrationPayload.sol';

abstract contract BaseMigrationPayloadTest is ProtocolV3TestBase {
  using Strings for string;

  struct ForkParams {
    string testName;
    string network;
    uint256 blockNumber;
  }

  struct RiskParameterUpdate {
    bytes newValue;
    string updateType;
    address market;
  }

  BaseMigrationPayload internal payload;
  ForkParams public forkParams;

  constructor(ForkParams memory _forkParams) {
    forkParams = _forkParams;
  }

  function setUp() public virtual {
    vm.createSelectFork(vm.rpcUrl(forkParams.network), forkParams.blockNumber);
    payload = BaseMigrationPayload(GovV3Helpers.deployDeterministic(_getPayloadBytecode()));

    _postSetUp(); // for adding custom post-setup
  }

  function _postSetUp() internal virtual {}

  function _getPayloadBytecode() internal virtual returns (bytes memory);

  function _getRiskOracleUpdatesToInject() internal virtual returns (RiskParameterUpdate[] memory);

  function _getIncorrectRiskOracleUpdatesToNotInject() internal virtual returns (RiskParameterUpdate[] memory) {}

  function test_defaultProposalExecution() public {
    defaultTest(forkParams.testName, IPool(payload.AAVE_POOL_FOR_LINK_WITHDRAW()), address(payload));
  }

  function test_agentsRegistered() public {
    GovV3Helpers.executePayload(vm, address(payload));

    BaseMigrationPayload.AgentMigrationInput[] memory inputs = payload.getAgentsMigrationInput();
    uint256 agentCount = payload.AGENT_HUB().getAgentCount();
    assertEq(agentCount, inputs.length);

    for (uint256 i = 0; i < agentCount; i++) {
      assertEq(payload.AGENT_HUB().getUpdateType(i), inputs[i].genericInput.updateType);
    }
  }

  function test_rangeValidationConfiguration() public {
    GovV3Helpers.executePayload(vm, address(payload));

    BaseMigrationPayload.AgentMigrationInput[] memory inputs = payload.getAgentsMigrationInput();
    uint256 agentCount = payload.AGENT_HUB().getAgentCount();

    for (uint256 i = 0; i < agentCount; i++) {
      BaseMigrationPayload.RangeConfiguration[] memory inputRanges = inputs[i]
        .genericInput
        .rangeConfigs;

      for (uint256 j = 0; j < inputRanges.length; j++) {
        IRangeValidationModule.RangeConfig memory configuredRange = payload
          .RANGE_VALIDATION_MODULE()
          .getDefaultRangeConfig(
            address(payload.AGENT_HUB()),
            i, // agentId
            inputRanges[j].rangeUpdateType
          );

        // validate that the ranges from the payload input is same as the one configured on the module
        assertEq(inputRanges[j].config.maxIncrease, configuredRange.maxIncrease);
        assertEq(inputRanges[j].config.maxDecrease, configuredRange.maxDecrease);
        assertEq(inputRanges[j].config.isIncreaseRelative, configuredRange.isIncreaseRelative);
        assertEq(inputRanges[j].config.isDecreaseRelative, configuredRange.isDecreaseRelative);
      }
    }
  }

  function test_validateAgentContractImmutables() public virtual {
    GovV3Helpers.executePayload(vm, address(payload));
    uint256 agentCount = payload.AGENT_HUB().getAgentCount();

    for (uint256 i = 0; i < agentCount; i++) {
      address agentContract = payload.AGENT_HUB().getAgentAddress(i);
      assertEq(
        address(IBaseAaveAgent(agentContract).RANGE_VALIDATION_MODULE()),
        address(payload.RANGE_VALIDATION_MODULE())
      );
      assertEq(address(IBaseAaveAgent(agentContract).POOL()), address(payload.AAVE_POOL_FOR_LINK_WITHDRAW()));
      assertEq(address(IBaseAaveAgent(agentContract).AGENT_HUB()), address(payload.AGENT_HUB()));
    }
  }

  function test_riskAdminRole() public {
    BaseMigrationPayload.AgentMigrationInput[] memory inputs = payload.getAgentsMigrationInput();

    for (uint256 i = 0; i < inputs.length; i++) {
      if (inputs[i].existingStewardToRevoke != address(0)) {
        assertTrue(payload.ACL_MANAGER().isRiskAdmin(inputs[i].existingStewardToRevoke));
      }
      assertFalse(payload.ACL_MANAGER().isRiskAdmin(inputs[i].agentAddress));
    }

    GovV3Helpers.executePayload(vm, address(payload));

    for (uint256 i = 0; i < inputs.length; i++) {
      if (inputs[i].existingStewardToRevoke != address(0)) {
        assertFalse(payload.ACL_MANAGER().isRiskAdmin(inputs[i].existingStewardToRevoke));
      }
      assertTrue(payload.ACL_MANAGER().isRiskAdmin(inputs[i].agentAddress));
    }
  }

  function test_oldAutomationCancelledAndNewRegistered() public {
    BaseMigrationPayload.AgentMigrationInput[] memory inputs = payload.getAgentsMigrationInput();

    for (uint256 i = 0; i < inputs.length; i++) {
      if (inputs[i].automationIdToCancel != 0) {
        // old automation cancelled
        vm.expectEmit(true, false, true, true, address(payload.ROBOT_OPERATOR()));
        emit IAaveCLRobotOperator.KeeperCancelled(inputs[i].automationIdToCancel, address(0));
      }

      if (address(payload.ROBOT_OPERATOR()) != address(0)) {
        // new automation registered
        vm.expectEmit(false, true, true, true, address(payload.ROBOT_OPERATOR()));
        emit IAaveCLRobotOperator.KeeperRegistered(
          0,
          payload.AUTOMATION_HUB_WRAPPER(),
          uint96(inputs[i].linkAmountToFund)
        );
      }
    }

    GovV3Helpers.executePayload(vm, address(payload));
  }

  function test_validateAutomationWrapperImmutable() public view {
    assertEq(
      address(IChainlinkAutomationHub(payload.AUTOMATION_HUB_WRAPPER()).AGENT_HUB()),
      address(payload.AGENT_HUB())
    );
  }

  function test_agentUpdateTypeExistsOnRiskOracle() public view {
    BaseMigrationPayload.AgentMigrationInput[] memory inputs = payload.getAgentsMigrationInput();

    for (uint256 i = 0; i < inputs.length; i++) {
      IRiskOracle riskOracle = IRiskOracle(payload.RISK_ORACLE());
      string memory agentUpdateType = inputs[i].genericInput.updateType;

      string[] memory riskOracleUpdateTypes = riskOracle.getAllUpdateTypes();
      bool updateTypeExists;

      for (uint256 j = 0; j < riskOracleUpdateTypes.length; j++) {
        if (
          riskOracleUpdateTypes[j].equal(agentUpdateType) ||
          // as updateType on riskOracle will be migrated from supplyCap to SupplyCapUpdate
          agentUpdateType.equal('SupplyCapUpdate') ||
          // as updateType on riskOracle will be migrated from borrowCap to BorrowCapUpdate
          agentUpdateType.equal('BorrowCapUpdate') ||
          // as updateType on riskOracle will be migrated from RateStrategyUpdate to RateStrategyUpdate_Prime
          agentUpdateType.equal('RateStrategyUpdate_Prime')
        ) {
          updateTypeExists = true;
          break;
        }
      }
      assertTrue(updateTypeExists, 'Update Type does not exist on the Chaos Risk Oracle');
    }
  }

  function test_collectorLinkBalance() public {
    BaseMigrationPayload.AgentMigrationInput[] memory inputs = payload.getAgentsMigrationInput();
    address executor = payload.GOVERNANCE_EXECUTOR();
    uint256 totalLinkAmountToWithdraw;

    for (uint256 i = 0; i < inputs.length; i++) {
      if (inputs[i].withdrawLinkFromCollector == true) {
        totalLinkAmountToWithdraw += inputs[i].linkAmountToFund;
      }
    }

    if (totalLinkAmountToWithdraw != 0 && (address(payload.ROBOT_OPERATOR()) != address(0))) {
      address linkToken = payload.LINK_TOKEN();
      if (block.chainid == 137) linkToken = AaveV3PolygonAssets.LINK_UNDERLYING;

      address aLink = IPool(payload.AAVE_POOL_FOR_LINK_WITHDRAW()).getReserveAToken(linkToken);
      uint256 collectorALinkBalanceBefore = IERC20(aLink).balanceOf(address(payload.COLLECTOR()));

      GovV3Helpers.executePayload(vm, address(payload));

      uint256 collectorALinkBalanceAfter = IERC20(aLink).balanceOf(address(payload.COLLECTOR()));
      assertApproxEqAbs(
        collectorALinkBalanceBefore - collectorALinkBalanceAfter,
        totalLinkAmountToWithdraw,
        2
      );

      // no dust left behind on executor
      assertEq(IERC20(aLink).balanceOf(executor), 0);
      assertEq(IERC20(linkToken).balanceOf(executor), 0);
    }
  }

  function test_checkLinkTokenIsERC677() public {
    if (payload.LINK_TOKEN() != address(0)) {
      bytes memory data = abi.encodeWithSignature(
        'transferAndCall(address,uint256,bytes)',
        address(1),
        0,
        ''
      );
      (bool success, ) = payload.LINK_TOKEN().call(data);
      assertTrue(success, 'Link token not ERC 677');
    }
  }

  function test_agentHubProxyAdmin() public view {
    bytes32 proxyAdminSlot = 0xb53127684a568b3173ae13b9f8a6016e243e63b6e8ee1178d6a717850b5d6103;
    address proxyAdmin = address(
      uint160(uint256(vm.load(address(payload.AGENT_HUB()), proxyAdminSlot)))
    );
    address proxyAdminOwner = Ownable(proxyAdmin).owner();

    // owner of agent-hub should be same as proxyAdmin owner. i.e executor lvl 1
    assertEq(Ownable(address(payload.AGENT_HUB())).owner(), proxyAdminOwner);

    // proxy-admin owner should be same as the admin of all agents. i.e executor lvl 1
    assertEq(payload.GOVERNANCE_EXECUTOR(), proxyAdminOwner);
  }

  function test_injection() public {
    GovV3Helpers.executePayload(vm, address(payload));

    // push risk-oracle updates
    RiskParameterUpdate[] memory updates = _getRiskOracleUpdatesToInject();
    BaseMigrationPayload.AgentMigrationInput[] memory inputs = payload.getAgentsMigrationInput();
    IRiskOracle riskOracle = IRiskOracle(payload.RISK_ORACLE());

    vm.startPrank(0x42939e82DF15afc586bb95f7dD69Afb6Dc24A6f9);
    for (uint256 i = 0; i < updates.length; i++) {
      riskOracle.publishRiskParameterUpdate(
        'referenceId',
        updates[i].newValue,
        updates[i].updateType,
        updates[i].market,
        'additionalData'
      );
    }
    vm.stopPrank();

    for (uint256 agentId = 0; agentId < inputs.length; agentId++) {
      assertTrue(_checkAndPerformAutomation(agentId));
    }
  }

  function test_injection_wrongUpdates() public {
    GovV3Helpers.executePayload(vm, address(payload));

    // push risk-oracle updates
    RiskParameterUpdate[] memory updates = _getIncorrectRiskOracleUpdatesToNotInject();
    BaseMigrationPayload.AgentMigrationInput[] memory inputs = payload.getAgentsMigrationInput();
    IRiskOracle riskOracle = IRiskOracle(payload.RISK_ORACLE());

    vm.startPrank(0x42939e82DF15afc586bb95f7dD69Afb6Dc24A6f9);
    for (uint256 i = 0; i < updates.length; i++) {
      riskOracle.publishRiskParameterUpdate(
        'referenceId',
        updates[i].newValue,
        updates[i].updateType,
        updates[i].market,
        'additionalData'
      );
    }
    vm.stopPrank();

    for (uint256 agentId = 0; agentId < inputs.length; agentId++) {
      assertFalse(_checkAndPerformAutomation(agentId));
    }
  }

  function _checkAndPerformAutomation(uint256 agentId) public returns (bool) {
    uint256[] memory agentIds = new uint256[](1);
    agentIds[0] = agentId;
    address automationHub = payload.AUTOMATION_HUB_WRAPPER();

    if (address(payload.ROBOT_OPERATOR()) != address(0)) {
      // uses chainlink automation
      (bool upkeepNeeded, bytes memory performData) = IChainlinkAutomationHub(automationHub)
        .checkUpkeep(abi.encode(agentIds));

      if (upkeepNeeded) {
        IChainlinkAutomationHub(automationHub).performUpkeep(performData);
      }
      return upkeepNeeded;
    } else {
      // uses gelato automation
      (bool upkeepNeeded, bytes memory encodedPerformData) = IGelatoAutomationHub(automationHub)
        .check(agentIds);

      if (upkeepNeeded) {
        (bool status, ) = address(automationHub).call(encodedPerformData);
        assertTrue(status);
      }
      return upkeepNeeded;
    }
  }
}

interface IBaseAaveAgent {
  function RANGE_VALIDATION_MODULE() external view returns (address);
  function POOL() external view returns (address);
  function AGENT_HUB() external view returns (address);
}
