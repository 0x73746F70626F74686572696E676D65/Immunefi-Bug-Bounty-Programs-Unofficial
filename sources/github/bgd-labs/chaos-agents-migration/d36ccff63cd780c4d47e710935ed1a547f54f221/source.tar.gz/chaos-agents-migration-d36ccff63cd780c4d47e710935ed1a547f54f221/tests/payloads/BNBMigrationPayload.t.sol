// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;

import {AaveV3BNBAssets} from 'aave-address-book/AaveV3BNB.sol';
import {BaseMigrationPayloadTest} from '../BaseMigrationPayload.t.sol';
import '../../src/contracts/payloads/BNBMigrationPayload.sol';

contract BNBMigrationPayloadTest is BaseMigrationPayloadTest {
  constructor()
    BaseMigrationPayloadTest(
      BaseMigrationPayloadTest.ForkParams({
        testName: 'BNBMigrationPayloadTest',
        network: 'bnb',
        blockNumber: 71273983
      })
    )
  {}

  function _getPayloadBytecode() internal pure override returns (bytes memory) {
    return type(BNBMigrationPayload).creationCode;
  }

  function _postSetUp() internal override {
    // TODO: fund link manually as collector on bnb does not have link
    deal(payload.LINK_TOKEN(), GovernanceV3BNB.EXECUTOR_LVL_1, 60 ether);
  }

  function _getRiskOracleUpdatesToInject()
    internal
    view
    override
    returns (RiskParameterUpdate[] memory)
  {
    RiskParameterUpdate[] memory updatesToInject = new RiskParameterUpdate[](2);
    (uint256 currentBorrowCap, uint256 currentSupplyCap) = AaveV3BNB
      .AAVE_PROTOCOL_DATA_PROVIDER
      .getReserveCaps(AaveV3BNBAssets.ETH_UNDERLYING);
    uint256 newBorrowCap = (currentBorrowCap * 130) / 100;
    uint256 newSupplyCap = (currentSupplyCap * 130) / 100;

    updatesToInject[0] = RiskParameterUpdate({
      newValue: abi.encodePacked(newSupplyCap),
      updateType: 'SupplyCapUpdate',
      market: AaveV3BNBAssets.ETH_UNDERLYING
    });
    updatesToInject[1] = RiskParameterUpdate({
      newValue: abi.encodePacked(newBorrowCap),
      updateType: 'BorrowCapUpdate',
      market: AaveV3BNBAssets.ETH_UNDERLYING
    });

    return updatesToInject;
  }

  function _getIncorrectRiskOracleUpdatesToNotInject()
    internal
    view
    override
    returns (RiskParameterUpdate[] memory)
  {
    RiskParameterUpdate[] memory updatesToNotInject = new RiskParameterUpdate[](2);
    (uint256 currentBorrowCap, uint256 currentSupplyCap) = AaveV3BNB
      .AAVE_PROTOCOL_DATA_PROVIDER
      .getReserveCaps(AaveV3BNBAssets.ETH_UNDERLYING);
    uint256 newBorrowCap = ((currentBorrowCap * 130) / 100) + 1;
    uint256 newSupplyCap = ((currentSupplyCap * 130) / 100) + 1;

    updatesToNotInject[0] = RiskParameterUpdate({
      newValue: abi.encodePacked(newSupplyCap),
      updateType: 'SupplyCapUpdate',
      market: AaveV3BNBAssets.ETH_UNDERLYING
    });
    updatesToNotInject[1] = RiskParameterUpdate({
      newValue: abi.encodePacked(newBorrowCap),
      updateType: 'BorrowCapUpdate',
      market: AaveV3BNBAssets.ETH_UNDERLYING
    });

    return updatesToNotInject;
  }
}
