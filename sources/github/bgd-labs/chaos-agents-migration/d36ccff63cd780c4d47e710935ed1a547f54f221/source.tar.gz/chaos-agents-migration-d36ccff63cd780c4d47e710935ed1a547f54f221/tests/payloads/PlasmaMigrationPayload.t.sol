// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;

import {DataTypes} from 'aave-v3-origin/src/contracts/protocol/libraries/types/DataTypes.sol';
import {AaveV3PlasmaEModes} from 'aave-address-book/AaveV3Plasma.sol';

import {BaseMigrationPayloadTest} from '../BaseMigrationPayload.t.sol';
import '../../src/contracts/payloads/PlasmaMigrationPayload.sol';

contract PlasmaMigrationPayloadTest is BaseMigrationPayloadTest {
  constructor()
    BaseMigrationPayloadTest(
      BaseMigrationPayloadTest.ForkParams({
        testName: 'PlasmaMigrationPayloadTest',
        network: 'plasma',
        blockNumber: 8527681
      })
    )
  {}

  function _getPayloadBytecode() internal pure override returns (bytes memory) {
    return type(PlasmaMigrationPayload).creationCode;
  }

  function _getRiskOracleUpdatesToInject()
    internal
    view
    override
    returns (RiskParameterUpdate[] memory)
  {
    RiskParameterUpdate[] memory updatesToInject = new RiskParameterUpdate[](2);

    // discount rate update
    address discountRateMarket = AaveV3PlasmaAssets.PT_sUSDE_15JAN2026_UNDERLYING;
    uint256 currentDiscountRate = IPendlePriceCapAdapter(
      AaveV3Plasma.ORACLE.getSourceOfAsset(discountRateMarket)
    ).discountRatePerYear();
    updatesToInject[0] = RiskParameterUpdate({
      newValue: abi.encodePacked(currentDiscountRate + 0.01e18), // increase by 1% absolute value
      updateType: 'PendleDiscountRateUpdate',
      market: discountRateMarket
    });

    // emode update
    DataTypes.EModeCategoryLegacy memory eModeData = AaveV3Plasma.POOL.getEModeCategoryData(
      AaveV3PlasmaEModes.PT_sUSDE_15JAN2026__USDe
    );
    updatesToInject[1] = RiskParameterUpdate({
      newValue: abi.encode(
        IAaveEModeAgent.EModeCategoryUpdate({
          ltv: eModeData.ltv + 50,
          liquidationThreshold: eModeData.liquidationThreshold + 50,
          liquidationBonus: (eModeData.liquidationBonus - 100_00) + 50
        })
      ),
      updateType: 'EModeCategoryUpdate',
      market: address(uint160(AaveV3PlasmaEModes.PT_sUSDE_15JAN2026__USDe))
    });

    return updatesToInject;
  }

  function _getIncorrectRiskOracleUpdatesToNotInject()
    internal
    view
    override
    returns (RiskParameterUpdate[] memory)
  {
    RiskParameterUpdate[] memory updatesToInject = new RiskParameterUpdate[](2);

    // discount rate update
    address discountRateMarket = AaveV3PlasmaAssets.PT_sUSDE_15JAN2026_UNDERLYING;
    uint256 currentDiscountRate = IPendlePriceCapAdapter(
      AaveV3Plasma.ORACLE.getSourceOfAsset(discountRateMarket)
    ).discountRatePerYear();
    updatesToInject[0] = RiskParameterUpdate({
      newValue: abi.encodePacked(currentDiscountRate + 0.01e18 + 1), // increase by 1% absolute value
      updateType: 'PendleDiscountRateUpdate',
      market: discountRateMarket
    });

    // emode update
    DataTypes.EModeCategoryLegacy memory eModeData = AaveV3Plasma.POOL.getEModeCategoryData(
      AaveV3PlasmaEModes.PT_sUSDE_15JAN2026__USDe
    );
    updatesToInject[1] = RiskParameterUpdate({
      newValue: abi.encode(
        IAaveEModeAgent.EModeCategoryUpdate({
          ltv: eModeData.ltv + 50 + 1,
          liquidationThreshold: eModeData.liquidationThreshold + 50 + 1,
          liquidationBonus: (eModeData.liquidationBonus - 100_00) + 50 + 1
        })
      ),
      updateType: 'EModeCategoryUpdate',
      market: address(uint160(AaveV3PlasmaEModes.PT_sUSDE_15JAN2026__USDe))
    });

    return updatesToInject;
  }
}

interface IPendlePriceCapAdapter {
  function discountRatePerYear() external view returns (uint64 discountRatePerYear);
}

interface IAaveEModeAgent {
  struct EModeCategoryUpdate {
    uint256 ltv;
    uint256 liquidationThreshold;
    uint256 liquidationBonus;
  }
}
