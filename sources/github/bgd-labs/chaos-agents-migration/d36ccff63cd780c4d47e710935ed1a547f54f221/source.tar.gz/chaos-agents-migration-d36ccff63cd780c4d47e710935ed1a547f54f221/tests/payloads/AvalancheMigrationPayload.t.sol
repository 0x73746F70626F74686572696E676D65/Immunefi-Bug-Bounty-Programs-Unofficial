// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;

import {BaseMigrationPayloadTest} from '../BaseMigrationPayload.t.sol';
import '../../src/contracts/payloads/AvalancheMigrationPayload.sol';

contract AvalancheMigrationPayloadTest is BaseMigrationPayloadTest {
  constructor()
    BaseMigrationPayloadTest(
      BaseMigrationPayloadTest.ForkParams({
        testName: 'AvalancheMigrationPayloadTest',
        network: 'avalanche',
        blockNumber: 73532237
      })
    )
  {}

  function _getPayloadBytecode() internal pure override returns (bytes memory) {
    return type(AvalancheMigrationPayload).creationCode;
  }

  function _getRiskOracleUpdatesToInject()
    internal
    view
    override
    returns (RiskParameterUpdate[] memory)
  {
    RiskParameterUpdate[] memory updatesToInject = new RiskParameterUpdate[](2);
    (uint256 currentBorrowCap, uint256 currentSupplyCap) = AaveV3Avalanche
      .AAVE_PROTOCOL_DATA_PROVIDER
      .getReserveCaps(AaveV3AvalancheAssets.WETHe_UNDERLYING);
    uint256 newBorrowCap = (currentBorrowCap * 130) / 100;
    uint256 newSupplyCap = (currentSupplyCap * 130) / 100;

    updatesToInject[0] = RiskParameterUpdate({
      newValue: abi.encodePacked(newSupplyCap),
      updateType: 'SupplyCapUpdate',
      market: AaveV3AvalancheAssets.WETHe_UNDERLYING
    });
    updatesToInject[1] = RiskParameterUpdate({
      newValue: abi.encodePacked(newBorrowCap),
      updateType: 'BorrowCapUpdate',
      market: AaveV3AvalancheAssets.WETHe_UNDERLYING
    });

    return updatesToInject;
  }

  function _getIncorrectRiskOracleUpdatesToNotInject()
    internal
    view
    override
    returns (RiskParameterUpdate[] memory)
  {
    RiskParameterUpdate[] memory updatesToNotInject = new RiskParameterUpdate[](2);
    (uint256 currentBorrowCap, uint256 currentSupplyCap) = AaveV3Avalanche
      .AAVE_PROTOCOL_DATA_PROVIDER
      .getReserveCaps(AaveV3AvalancheAssets.WETHe_UNDERLYING);
    uint256 newBorrowCap = ((currentBorrowCap * 130) / 100) + 1;
    uint256 newSupplyCap = ((currentSupplyCap * 130) / 100) + 1;

    updatesToNotInject[0] = RiskParameterUpdate({
      newValue: abi.encodePacked(newSupplyCap),
      updateType: 'SupplyCapUpdate',
      market: AaveV3AvalancheAssets.WETHe_UNDERLYING
    });
    updatesToNotInject[1] = RiskParameterUpdate({
      newValue: abi.encodePacked(newBorrowCap),
      updateType: 'BorrowCapUpdate',
      market: AaveV3AvalancheAssets.WETHe_UNDERLYING
    });

    return updatesToNotInject;
  }
}
