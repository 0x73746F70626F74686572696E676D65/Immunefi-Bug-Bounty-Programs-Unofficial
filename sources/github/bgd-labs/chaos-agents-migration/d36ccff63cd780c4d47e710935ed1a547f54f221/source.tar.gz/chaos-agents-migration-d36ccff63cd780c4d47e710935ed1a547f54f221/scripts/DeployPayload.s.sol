// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;

import {GovV3Helpers} from 'aave-helpers/src/GovV3Helpers.sol';
import {EthereumScript, PolygonScript, AvalancheScript, OptimismScript, ArbitrumScript, BaseScript, LineaScript, PlasmaScript, GnosisScript, BNBScript} from 'solidity-utils/contracts/utils/ScriptUtils.sol';

import {EthereumCoreMigrationPayload} from '../src/contracts/payloads/EthereumCoreMigrationPayload.sol';
import {EthereumPrimeMigrationPayload} from '../src/contracts/payloads/EthereumPrimeMigrationPayload.sol';
import {ArbitrumMigrationPayload} from '../src/contracts/payloads/ArbitrumMigrationPayload.sol';
import {AvalancheMigrationPayload} from '../src/contracts/payloads/AvalancheMigrationPayload.sol';
import {BaseNetworkMigrationPayload} from '../src/contracts/payloads/BaseNetworkMigrationPayload.sol';
import {BNBMigrationPayload} from '../src/contracts/payloads/BNBMigrationPayload.sol';
import {GnosisMigrationPayload} from '../src/contracts/payloads/GnosisMigrationPayload.sol';
import {LineaMigrationPayload} from '../src/contracts/payloads/LineaMigrationPayload.sol';
import {OptimismMigrationPayload} from '../src/contracts/payloads/OptimismMigrationPayload.sol';
import {PlasmaMigrationPayload} from '../src/contracts/payloads/PlasmaMigrationPayload.sol';
import {PolygonMigrationPayload} from '../src/contracts/payloads/PolygonMigrationPayload.sol';

// make deploy-ledger contract=scripts/DeployPayload.s.sol:DeployEthereumCore chain=mainnet
contract DeployEthereumCore is EthereumScript {
  function run() external broadcast {
    GovV3Helpers.deployDeterministic(type(EthereumCoreMigrationPayload).creationCode);
  }
}

// make deploy-ledger contract=scripts/DeployPayload.s.sol:DeployEthereumPrime chain=mainnet
contract DeployEthereumPrime is EthereumScript {
  function run() external broadcast {
    GovV3Helpers.deployDeterministic(type(EthereumPrimeMigrationPayload).creationCode);
  }
}

// make deploy-ledger contract=scripts/DeployPayload.s.sol:DeployArbitrum chain=arbitrum
contract DeployArbitrum is ArbitrumScript {
  function run() external broadcast {
    GovV3Helpers.deployDeterministic(type(ArbitrumMigrationPayload).creationCode);
  }
}

// make deploy-ledger contract=scripts/DeployPayload.s.sol:DeployAvalanche chain=avalanche
contract DeployAvalanche is AvalancheScript {
  function run() external broadcast {
    GovV3Helpers.deployDeterministic(type(AvalancheMigrationPayload).creationCode);
  }
}

// make deploy-ledger contract=scripts/DeployPayload.s.sol:DeployBase chain=base
contract DeployBase is BaseScript {
  function run() external broadcast {
    GovV3Helpers.deployDeterministic(type(BaseNetworkMigrationPayload).creationCode);
  }
}

// make deploy-ledger contract=scripts/DeployPayload.s.sol:DeployBNB chain=bnb
contract DeployBNB is BNBScript {
  function run() external broadcast {
    GovV3Helpers.deployDeterministic(type(BNBMigrationPayload).creationCode);
  }
}

// make deploy-ledger contract=scripts/DeployPayload.s.sol:DeployGnosis chain=gnosis
contract DeployGnosis is GnosisScript {
  function run() external broadcast {
    GovV3Helpers.deployDeterministic(type(GnosisMigrationPayload).creationCode);
  }
}

// make deploy-ledger contract=scripts/DeployPayload.s.sol:DeployLinea chain=linea
contract DeployLinea is LineaScript {
  function run() external broadcast {
    GovV3Helpers.deployDeterministic(type(LineaMigrationPayload).creationCode);
  }
}

// make deploy-ledger contract=scripts/DeployPayload.s.sol:DeployOptimism chain=optimism
contract DeployOptimism is OptimismScript {
  function run() external broadcast {
    GovV3Helpers.deployDeterministic(type(OptimismMigrationPayload).creationCode);
  }
}

// make deploy-ledger contract=scripts/DeployPayload.s.sol:DeployPlasma chain=plasma
contract DeployPlasma is PlasmaScript {
  function run() external broadcast {
    GovV3Helpers.deployDeterministic(type(PlasmaMigrationPayload).creationCode);
  }
}

// make deploy-ledger contract=scripts/DeployPayload.s.sol:DeployPolygon chain=polygon
contract DeployPolygon is PolygonScript {
  function run() external broadcast {
    GovV3Helpers.deployDeterministic(type(PolygonMigrationPayload).creationCode);
  }
}
