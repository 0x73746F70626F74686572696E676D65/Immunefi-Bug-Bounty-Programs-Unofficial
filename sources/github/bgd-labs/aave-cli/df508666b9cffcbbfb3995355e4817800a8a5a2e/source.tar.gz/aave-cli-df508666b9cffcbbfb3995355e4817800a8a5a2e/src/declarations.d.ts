declare module 'json-bigint';
