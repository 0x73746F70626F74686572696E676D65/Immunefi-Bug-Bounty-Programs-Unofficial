/*
    This is a specification file for the verification of AaveTokenV3.sol 
    smart contract using the Certora prover. The rules in this spec have been
    contributed by the community. Individual attribution is given in the comments
    to each rule.

    For more information, visit: https://www.certora.com/

    This file is run with scripts/verifyCommunity.sh
    On AaveTokenV3Harness.sol

    Run results: https://prover.certora.com/output/67509/d36b2357623beec546c1?anonymousKey=f6fb866df18e6bc9ed880806375e7861cde8274f

*/

//import "base_token_v3.spec";
import "base.spec";

methods {
    function ecrecoverWrapper(bytes32, uint8, bytes32, bytes32) external returns (address) envfree;
    function computeMetaDelegateHash(address delegator,  address delegatee, uint256 deadline, uint256 nonce) external returns (bytes32) envfree;
    function computeMetaDelegateByTypeHash(address delegator,  address delegatee, IGovernancePowerDelegationToken.GovernancePowerType delegationType, uint256 deadline, uint256 nonce) external returns (bytes32) envfree;
    function _nonces(address addr) external returns (uint256) envfree;
    function getNonce(address) external returns (uint256) envfree;
    function getPowerCurrent_BaseDelegation(address, IGovernancePowerDelegationToken.GovernancePowerType) external returns (uint256) envfree;
    function mul_div_munged(uint256 x, uint256 denominator) external returns (uint256) envfree;
}

definition ZERO_ADDRESS() returns address = 0;

/*===================================================================
  Normalize the balance according to the ER (ExchangeRate)
  =================================================================*/
function norER(uint256 bal) returns mathint {
    return bal * EXCHANGE_RATE_FACTOR() / getExchangeRate();
}


/*
    @Rule

    @Description:
    Integrity of permit function
    Successful permit function increases the nonce of owner by 1 and also changes the allowance of owner to spender

    @Formula:
    {
        nonceBefore = getNonce(owner)
    }
    <
        permit(owner, spender, value, deadline, v, r, s)
    >
    {
        allowance(owner, spender) == value && getNonce(owner) == nonceBefore + 1
    }

    @Note:
        Written by https://github.com/parth-15

    @Link:
*/
rule permitIntegrity() {
    env e;
    address owner;
    address spender;
    uint256 value;
    uint256 deadline;
    uint8 v;
    bytes32 r;
    bytes32 s;

    uint256 allowanceBefore = allowance(owner, spender);
    mathint nonceBefore = getNonce(owner);

    //checking this because function is using unchecked math and such a high nonce is unrealistic
    require nonceBefore < max_uint;

    permit(e, owner, spender, value, deadline, v, r, s);

    uint256 allowanceAfter = allowance(owner, spender);
    mathint nonceAfter = getNonce(owner);

    assert allowanceAfter == value, "permit increases allowance of owner to spender on success";
    assert nonceAfter == nonceBefore + 1, "successful call to permit function increases nonce of owner by 1";
}


/*
    @Rule

    @Description:
        Address 0 has no voting or proposition power

    @Formula:
    {
        getPowerCurrent(0, VOTING_POWER) == 0 && getPowerCurrent(0, PROPOSITION_POWER) == && balanceOf(0) == 0
    }

    @Note:
        Written by https://github.com/JayP11

    @Link:
*/
invariant addressZeroNoPower()
    getPowerCurrent(0, VOTING_POWER()) == 0 && getPowerCurrent(0, PROPOSITION_POWER()) == 0 && balanceOf(0) == 0 && getPowerCurrent_BaseDelegation(0, VOTING_POWER())==0 && getPowerCurrent_BaseDelegation(0, PROPOSITION_POWER())==0;
//    filtered {f -> f.selector != sig:returnFunds(uint256).selector }



/*
    @Rule

    @Description:
        Verify that `metaDelegateByType` can only be called with a signed request.

    @Formula:
    {
        ecrecover(v,r,s) != delegator
    }
    <
        metaDelegateByType@withrevert(delegator, delegatee, delegationType, deadline, v, r, s)
    >
    {
        lastReverted == true
    }

    @Note:
        Written by https://github.com/kustosz

    @Link:
*/
rule metaDelegateByTypeOnlyCallableWithProperlySignedArguments(env e, address delegator, address delegatee, IGovernancePowerDelegationToken.GovernancePowerType delegationType, uint256 deadline, uint8 v, bytes32 r, bytes32 s) {
    require ecrecoverWrapper(computeMetaDelegateByTypeHash(delegator, delegatee, delegationType, deadline, _nonces(delegator)), v, r, s) != delegator;
    metaDelegateByType@withrevert(e, delegator, delegatee, delegationType, deadline, v, r, s);
    assert lastReverted;
}

 /*
    @Rule

    @Description:
        Verify that it's impossible to use the same arguments to call `metaDalegate` twice.

    @Formula:
    {
        hash1 = computeMetaDelegateHash(delegator, delegatee, deadline, nonce)
        hash2 = computeMetaDelegateHash(delegator, delegatee, deadline, nonce + 1)
        ecrecover(hash1, v, r, s) == delegator
    }
    <
        metaDelegate(e1, delegator, delegatee, v, r, s)
        metaDelegate@withrevert(e2, delegator, delegatee, delegationType, deadline, v, r, s)
    >
    {
        lastReverted == true
    }

    @Note:
        Written by https://github.com/kustosz

    @Link:
*/
rule metaDelegateNonRepeatable(env e1, env e2, address delegator, address delegatee, uint256 deadline, uint8 v, bytes32 r, bytes32 s) {
    uint256 nonce = _nonces(delegator);
    bytes32 hash1 = computeMetaDelegateHash(delegator, delegatee, deadline, nonce);
    bytes32 hash2 = computeMetaDelegateHash(delegator, delegatee, deadline, require_uint256(nonce+1));
    // assume no hash collisions
    require hash1 != hash2;
    // assume first call is properly signed
    require ecrecoverWrapper(hash1, v, r, s) == delegator;
    // assume ecrecover is sane: cannot sign two different messages with the same (v,r,s)
    require ecrecoverWrapper(hash2, v, r, s) != ecrecoverWrapper(hash1, v, r, s);
    metaDelegate(e1, delegator, delegatee, deadline, v, r, s);
    metaDelegate@withrevert(e2, delegator, delegatee, deadline, v, r, s);
    assert lastReverted;
}


/*
    @Rule

    @Description:
        Power of the previous delegate is removed when the delegatee delegates to another delegate

    @Formula:
    {
        _votingBalance = getDelegatedVotingBalance(alice)
    }
    <
        delegateByType(alice, VOTING_POWER)
        delegateByType(bob, VOTING_POWER)
    >
    {
        alice != bob => getDelegatedVotingBalance(alice) == _votingBalance
    }

    @Note:
        Written by https://github.com/priyankabhanderi

    @Link:
*/
rule delegatingToAnotherUserRemovesPowerFromOldDelegatee(env e, address alice, address bob) {

    require e.msg.sender != ZERO_ADDRESS(); 
    require e.msg.sender != alice && e.msg.sender != bob;
    require alice != ZERO_ADDRESS() && bob != ZERO_ADDRESS();

    require getVotingDelegatee(e.msg.sender) != alice;

    uint72 _votingBalance = getDelegatedVotingBalance(alice);

    delegateByType(e, alice, VOTING_POWER());

    assert getVotingDelegatee(e.msg.sender) == alice;

    delegateByType(e, bob, VOTING_POWER());

    assert getVotingDelegatee(e.msg.sender) == bob;
    uint72 votingBalance_ = getDelegatedVotingBalance(alice);
    assert alice != bob => votingBalance_ == _votingBalance;
}

/*
    @Rule

    @Description:
        Voting and proposition power change only as a result of specific functions

    @Formula:
    {
        powerBefore = getPowerCurrent(alice, type)
    }
    <
        f(e, args)
    >
    {
       powerAfter = getPowerCurrent(alice, type)
       powerAfter != powerBefore =>
        f.selector == sig:delegate(address).selector ||
        f.selector == sig:delegateByType(address, uint8).selector ||
        f.selector == sig:metaDelegate(address, address, uint256, uint8, bytes32, bytes32).selector ||
        f.selector == sig:metaDelegateByType(address, address, uint8, uint256, uint8, bytes32, bytes32).selector ||
        f.selector == sig:transfer(address, uint256).selector ||
        f.selector == sig:transferFrom(address, address, uint256).selector
    }

    @Note:
        Written by https://github.com/top-sekret

    @Link:
*/

rule powerChanges(address alice, method f) {
    // This rule is identical to votingPowerChanges of token-v3-delegate.spec
    env e;
    calldataarg args;

    IGovernancePowerDelegationToken.GovernancePowerType type;
    uint256 powerBefore = getPowerCurrent(alice, type);

    f(e, args);

    uint256 powerAfter = getPowerCurrent(alice, type);

    assert powerBefore != powerAfter =>
        f.selector == sig:delegate(address).selector ||
        f.selector == sig:delegateByType(address, IGovernancePowerDelegationToken.GovernancePowerType).selector ||
        f.selector == sig:metaDelegate(address, address, uint256, uint8, bytes32, bytes32).selector ||
        f.selector == sig:metaDelegateByType(address, address, IGovernancePowerDelegationToken.GovernancePowerType, uint256, uint8, bytes32, bytes32).selector ||
        f.selector == sig:transfer(address, uint256).selector ||
        f.selector == sig:transferFrom(address, address, uint256).selector ||
        f.selector == sig:slash(address,uint256).selector ||
        f.selector == sig:returnFunds(uint256).selector ||
        is_redeem_method(f) ||
        is_stake_method(f)
        ;
}



/*
    @Rule

    @Description:
        Changing a delegate of one type doesn't influence the delegate of the other type

    @Formula:
    {
        delegateBefore = type == 1 ? getPropositionDelegatee(e.msg.sender) : getVotingDelegatee(e.msg.sender)
    }
    <
        delegateByType(e, delegatee, 1 - type)
    >
    {
       delegateBefore = type == 1 ? getPropositionDelegatee(e.msg.sender) : getVotingDelegatee(e.msg.sender)
       delegateBefore == delegateAfter
    }

    @Note:
        Written by https://github.com/top-sekret

    @Link:
*/
rule delegateIndependence(method f) {
    env e;

    IGovernancePowerDelegationToken.GovernancePowerType type;

    address delegateBefore = type == IGovernancePowerDelegationToken.GovernancePowerType.PROPOSITION ? getPropositionDelegatee(e.msg.sender) : getVotingDelegatee(e.msg.sender);

    IGovernancePowerDelegationToken.GovernancePowerType otherType = type == IGovernancePowerDelegationToken.GovernancePowerType.PROPOSITION ? IGovernancePowerDelegationToken.GovernancePowerType.VOTING : IGovernancePowerDelegationToken.GovernancePowerType.PROPOSITION;
    delegateByType(e, _, otherType);

    address delegateAfter = type == IGovernancePowerDelegationToken.GovernancePowerType.PROPOSITION ? getPropositionDelegatee(e.msg.sender) : getVotingDelegatee(e.msg.sender);

    assert delegateBefore == delegateAfter;
}

/*
    @Rule

    @Description:
        Verifying voting power increases/decreases while not being a voting delegatee yourself

    @Formula:
    {
        votingPowerBefore = getPowerCurrent(a, VOTING_POWER)
        balanceBefore = balanceOf(a)
        isVotingDelegatorBefore = getDelegatingVoting(a)
        isVotingDelegateeBefore = getDelegatedVotingBalance(a) != 0
    }
    <
        f(e, args)
    >
    {
        votingPowerAfter = getPowerCurrent(a, VOTING_POWER()
        balanceAfter = getBalance(a)
        isVotingDelegatorAfter = getDelegatingVoting(a);
        isVotingDelegateeAfter = getDelegatedVotingBalance(a) != 0

        votingPowerBefore < votingPowerAfter <=> 
        (!isVotingDelegatorBefore && !isVotingDelegatorAfter && (balanceBefore < balanceAfter)) ||
        (isVotingDelegatorBefore && !isVotingDelegatorAfter && (balanceBefore != 0))
        &&
        votingPowerBefore > votingPowerAfter <=> 
        (!isVotingDelegatorBefore && !isVotingDelegatorAfter && (balanceBefore > balanceAfter)) ||
        (!isVotingDelegatorBefore && isVotingDelegatorAfter && (balanceBefore != 0))
    }

    @Note:
        Written by https://github.com/Zarfsec

    @Link:
*/

/*
rule votingPowerChangesWhileNotBeingADelegatee(address a) {
    require a != 0;

    uint256 _votingPower = getPowerCurrent(a, VOTING_POWER());
    uint256 _balance = getBalance(a);
    uint256 _exchangeRate = getExchangeRate();
    bool _isVotingDelegator = getDelegatingVoting(a);
    bool _isVotingDelegatee = getDelegatedVotingBalance(a) != 0;

    method f;
    env e;
    calldataarg args;
    f(e, args);

    uint256 votingPower_ = getPowerCurrent(a, VOTING_POWER());
    uint256 balance_ = getBalance(a);
    uint256 exchangeRate_ = getExchangeRate();
    bool isVotingDelegator_ = getDelegatingVoting(a);
    bool isVotingDelegatee_ = getDelegatedVotingBalance(a) != 0;

    require !_isVotingDelegatee && !isVotingDelegatee_;

   
    //If you're not a delegatee, your voting power only increases when
    //    1. You're not delegating and your balance increases
    //    2. You're delegating and stop delegating and your _balance != 0
    
    assert _votingPower < votingPower_ <=> 
        (!_isVotingDelegator && !isVotingDelegator_ && norER(_balance)<norER(balance_) )
        ||
        (_isVotingDelegator  && !isVotingDelegator_ && norER(_balance)!=0)
        ;

    
    //If you're not a delegatee, your voting power only decreases when
    //    1. You're not delegating and your balance decreases
    //    2. You're not delegating and start delegating and your _balance != 0
    
    if (f.selector == sig:slash(address,uint256).selector || 
        f.selector == sig:returnFunds(uint256).selector) {
        assert _votingPower > votingPower_ =>
            (!_isVotingDelegator && !isVotingDelegator_ && norER(_balance)>norER(balance_) ) ||
            (!_isVotingDelegator && isVotingDelegator_  && norER(_balance)!=0) ||
            _exchangeRate != exchangeRate_
            ;
        assert
            (!_isVotingDelegator && !isVotingDelegator_ && norER(_balance)>norER(balance_) ) ||
            (!_isVotingDelegator && isVotingDelegator_  && norER(_balance)!=0 )
            => _votingPower > votingPower_;
    }
    else {
        assert _votingPower > votingPower_ <=> 
            (!_isVotingDelegator && !isVotingDelegator_ && norER(_balance)>norER(balance_) ) ||
            (!_isVotingDelegator && isVotingDelegator_  && norER(_balance)!=0 );
    }
}
*/

/*
    @Rule

    @Description:
        Verifying proposition power increases/decreases while not being a proposition delegatee yourself

    @Formula:
    {
        propositionPowerBefore = getPowerCurrent(a, PROPOSITION_POWER)
        balanceBefore = balanceOf(a)
        isPropositionDelegatorBefore = getDelegatingProposition(a)
        isPropositionDelegateeBefore = getDelegatedPropositionBalance(a) != 0
    }
    <
        f(e, args)
    >
    {
        propositionPowerAfter = getPowerCurrent(a, PROPOSITION_POWER()
        balance_ = getBalance(a)
        isPropositionDelegatorAfter = getDelegatingProposition(a);
        isPropositionDelegateeAfter = getDelegatedPropositionBalance(a) != 0

        propositionPowerBefore < propositionPowerAfter <=> 
        (!isPropositionDelegatorBefore && !isPropositionDelegatorAfter && (balanceBefore < balance_)) ||
        (isPropositionDelegatorBefore && !isPropositionDelegatorAfter && (balanceBefore != 0))
        &&
        propositionPowerBefore > propositionPowerAfter <=> 
        (!isPropositionDelegatorBefore && !isPropositionDelegatorAfter && (balanceBefore > balance_)) ||
        (!isPropositionDelegatorBefore && isPropositionDelegatorAfter && (balanceBefore != 0))
    }

    @Note:
        Written by https://github.com/Zarfsec

    @Link:
*/

/*
rule propositionPowerChangesWhileNotBeingADelegatee(address a) {
    require a != 0;

    uint256 _propPower = getPowerCurrent(a, PROPOSITION_POWER());
    uint256 _balance = getBalance(a);
    bool _isPropDelegator = getDelegatingProposition(a);
    bool _isPropDelegatee = getDelegatedPropositionBalance(a) != 0;
    uint256 _exchangeRate = getExchangeRate();

    method f;
    env e;
    calldataarg args;
    f(e, args);

    uint256 propPower_ = getPowerCurrent(a, PROPOSITION_POWER());
    uint256 balance_ = getBalance(a);
    uint256 exchangeRate_ = getExchangeRate();
    bool isPropDelegator_ = getDelegatingProposition(a);
    bool isPropDelegatee_ = getDelegatedPropositionBalance(a) != 0;

    require !_isPropDelegatee && !isPropDelegatee_;

    
    //If you're not a delegatee, your proposition power only increases when
    //    1. You're not delegating and your balance increases
    //    2. You're delegating and stop delegating and your _balance != 0
    
    assert _propPower < propPower_ <=> 
        (!_isPropDelegator && !isPropDelegator_ && norER(_balance)<norER(balance_)) ||
        (_isPropDelegator  && !isPropDelegator_ && norER(_balance)!=0);
    
    
    //If you're not a delegatee, your proposition power only decreases when
    //    1. You're not delegating and your balance decreases
    //    2. You're not delegating and start delegating and your _balance != 0
    
    if (f.selector == sig:slash(address,uint256).selector || 
        f.selector == sig:returnFunds(uint256).selector) {
        assert _propPower > propPower_ =>
            (!_isPropDelegator && !_isPropDelegator && norER(_balance)>norER(balance_)) ||
            (!_isPropDelegator && isPropDelegator_  && norER(_balance)!=0) ||
            _exchangeRate != exchangeRate_;
        assert 
            (!_isPropDelegator && !_isPropDelegator && norER(_balance)>norER(balance_)) ||
            (!_isPropDelegator && isPropDelegator_  && norER(_balance)!=0)
            => _propPower > propPower_ ;
    }
    else
        assert _propPower > propPower_ <=> 
            (!_isPropDelegator && !_isPropDelegator && norER(_balance)>norER(balance_)) ||
            (!_isPropDelegator && isPropDelegator_  && norER(_balance)!=0);
            }*/

/*
    @Rule

    @Description:
        Allowance only changes as a result of specific subset of functions

    @Formula:
    {
        allowanceBefore = allowance(owner, spender)
    }
    <
        f(e, args)
    >
    {
       allowance(owner, spender) != allowanceBefore =>f.selector==sig:approve(address,uint256).selector 
            || f.selector==sig:increaseAllowance(address,uint256).selector
            || f.selector==sig:decreaseAllowance(address,uint256).selector
            || f.selector==sig:transferFrom(address,address,uint256).selector
            || f.selector==sig:permit(address,address,uint256,uint256,uint8,bytes32,bytes32).selector

    }

    @Note:
        Written by https://github.com/oracleorb

    @Link:
*/
rule allowanceStateChange(env e){
    address owner;
    address user;
    method f;
    calldataarg args;

    uint256 allowanceBefore=allowance(owner,user);
    f(e, args);
    uint256 allowanceAfter=allowance(owner,user);

    assert allowanceBefore!=allowanceAfter => f.selector==sig:approve(address,uint256).selector 
    || f.selector==sig:increaseAllowance(address,uint256).selector
    || f.selector==sig:decreaseAllowance(address,uint256).selector
    || f.selector==sig:transferFrom(address,address,uint256).selector
    || f.selector==sig:permit(address,address,uint256,uint256,uint8,bytes32,bytes32).selector;
}
