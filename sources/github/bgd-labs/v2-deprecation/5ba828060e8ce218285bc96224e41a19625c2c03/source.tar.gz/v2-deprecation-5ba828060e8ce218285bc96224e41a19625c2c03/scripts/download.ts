import child_process, {execSync} from 'child_process';
import {
  AaveV2Ethereum,
  AaveV2Avalanche,
  AaveV2EthereumAMM,
  AaveV2Polygon,
} from '@bgd-labs/aave-address-book';
import {getClient, getImplementationSlot} from '@bgd-labs/toolbox';
import {getAddress, slice, Hex} from 'viem';

function runCmd(cmd: string) {
  var resp = child_process.execSync(cmd);
  var result = resp.toString();
  return result;
}

function downloadPool(
  name: string,
  {
    CHAIN_ID,
    LENDING_POOL_COLLATERAL_MANAGER,
  }: {CHAIN_ID: number; LENDING_POOL_COLLATERAL_MANAGER: string},
) {}

// downloadPool('core', AaveV2Ethereum);
// downloadPool('amm', AaveV2EthereumAMM);
// downloadPool('avalanche', AaveV2Avalanche);
// downloadPool('polygon', AaveV2Polygon);

const pools = {
  core: AaveV2Ethereum,
  amm: AaveV2EthereumAMM,
  avalanche: AaveV2Avalanche,
  polygon: AaveV2Polygon,
} as const;

const contracts = {
  LendingPoolCollateralManager: 'LENDING_POOL_COLLATERAL_MANAGER',
  Pool: 'POOL_IMPL',
} as const;

function bytes32ToAddress(bytes32: Hex) {
  return getAddress(slice(bytes32, 12, 32));
}

async function diffPools() {
  const contractKeys = Object.keys(contracts) as (keyof typeof contracts)[];
  for (let j = 0; j < contractKeys.length; j++) {
    const poolKeys = Object.keys(pools) as (keyof typeof pools)[];
    for (let i = 0; i < poolKeys.length; i++) {
      // execSync(
      //   `npx @bgd-labs/cli@0.0.47 codeDiff \
      //   --address1 ${pools[poolKeys[0]][contracts[contractKeys[j]]]} --chainId1 ${
      //     pools[poolKeys[0]].CHAIN_ID
      //   } \
      //   --address2 ${pools[poolKeys[i]][contracts[contractKeys[j]]]} --chainId2 ${
      //     pools[poolKeys[i]].CHAIN_ID
      //   } -o file`
      // );
      runCmd(
        `cast source --chain-id ${pools[poolKeys[i]].CHAIN_ID} -d src/${poolKeys[i]}/${contractKeys[j]} ${pools[poolKeys[i]][contracts[contractKeys[j]]]}`,
      );
    }
  }

  runCmd(
    `cast source --chain-id 1 -d src/core/AToken ${bytes32ToAddress(
      (await getImplementationSlot(
        getClient(1, {providerConfig: {alchemyKey: process.env.ALCHEMY_API_KEY}}),
        AaveV2Ethereum.ASSETS.WBTC.A_TOKEN,
      )) as Hex,
    )}`,
  );
  runCmd(
    `cast source --chain-id 1 -d src/amm/AToken ${bytes32ToAddress(
      (await getImplementationSlot(
        getClient(1, {providerConfig: {alchemyKey: process.env.ALCHEMY_API_KEY}}),
        AaveV2EthereumAMM.ASSETS.WBTC.A_TOKEN,
      )) as Hex,
    )}`,
  );
  runCmd(
    `cast source --chain-id 137 -d src/polygon/AToken ${bytes32ToAddress(
      (await getImplementationSlot(
        getClient(137, {providerConfig: {alchemyKey: process.env.ALCHEMY_API_KEY}}),
        AaveV2Polygon.ASSETS.WBTC.A_TOKEN,
      )) as Hex,
    )}`,
  );
  runCmd(
    `cast source --chain-id 43114 -d src/avalanche/AToken ${bytes32ToAddress(
      (await getImplementationSlot(
        getClient(43114, {providerConfig: {alchemyKey: process.env.ALCHEMY_API_KEY}}),
        AaveV2Avalanche.ASSETS.WBTCe.A_TOKEN,
      )) as Hex,
    )}`,
  );
}

diffPools();
