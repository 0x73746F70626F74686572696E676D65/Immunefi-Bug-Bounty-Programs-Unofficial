# Aave v3 Celo Activation Proposal Simulation

Repo for simulating the celo activation proposal using foundry anvil.

## Setup

This will install the npm packages

```sh
npm install
```

Please also put celo rpc on the .env as `RPC_CELO`

## Fork simulation

1. Create an anvil fork of the celo mainnet that runs on locally on your machine.
```
make start-anvil
```

2. Open another terminal and run the following command. This will execute the payload and activate celo aave v3 market.
```
make execute-proposal
```

3. You can now use the era-test-node url (generally `http://127.0.0.1:8545`) instead of the rpc to test stuff on the UI or any other places.
