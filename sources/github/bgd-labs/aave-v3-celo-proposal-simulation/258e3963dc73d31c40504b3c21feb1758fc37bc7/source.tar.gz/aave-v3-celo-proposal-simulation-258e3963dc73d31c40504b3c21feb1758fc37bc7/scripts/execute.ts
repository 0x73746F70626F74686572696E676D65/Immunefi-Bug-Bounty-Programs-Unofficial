import hre from 'hardhat';
import {ethers} from 'hardhat';
import {AaveV3Celo, GovernanceV3Celo} from '@bgd-labs/aave-address-book';

async function main() {
  // deployed celo activation proposal address
  const payloadAddress = "0xb7611d8A3Bba119ACb6E97614e1022dC3Fde4298";

  await hre.network.provider.request({
    method: "hardhat_impersonateAccount",
    params: [GovernanceV3Celo.EXECUTOR_LVL_1],
  });
  const signer = await ethers.getSigner(GovernanceV3Celo.EXECUTOR_LVL_1);

  // for CELO token seeding we set the balance
  await hre.network.provider.request({
    method: "hardhat_setBalance",
    params: [payloadAddress, ethers.toBeHex(ethers.parseUnits('10', 18))]
  });

  const tokenAddresses = {
    usdc: "0xcebA9300f2b948710d2653dD7B07f33A8B32118C",
    usdt: "0x48065fbBE25f71C9282ddf5e1cD6D6A887483D5e",
    ceur: "0xD8763CBa276a3738E6DE85b4b3bF5FDed6D6cA73",
    cusd: "0x765DE816845861e75A25fCA122bb6898B8B1282a"
  };

  // We transfer tokens from the executor to the payload as the payload needs to hold token balances to seed tokens to the pool
  // after listing and as the payload is not being executed via delegate-call
  for (const [tokenName, address] of Object.entries(tokenAddresses)) {
    const token = await ethers.getContractAt("IERC20", address, signer);
    const amount = tokenName === 'usdc' || tokenName === 'usdt' ? ethers.parseUnits('10', 6) : ethers.parseUnits('10', 18);
    await token.transfer(payloadAddress, amount.toString());
  }

  // We give pool admin and risk admin role to the payload so the activation payload can list the assets and give roles
  const acl = await ethers.getContractAt("IACLManager", AaveV3Celo.ACL_MANAGER, signer);
  await acl.addPoolAdmin(payloadAddress);
  await acl.addRiskAdmin(payloadAddress);
  const POOL_ADMIN_ROLE = "0x12ad05bde78c5ab75238ce885307f96ecd482bb402ef831f99e7018a0f169b7b";
  const RISK_ADMIN_ROLE = "0x8aa855a911518ecfbe5bc3088c8f3dda7badf130faaf8ace33fdc33828e18167";
  await acl.setRoleAdmin(POOL_ADMIN_ROLE, POOL_ADMIN_ROLE);
  await acl.setRoleAdmin(RISK_ADMIN_ROLE, RISK_ADMIN_ROLE);

  // We transfer the ownership of emission manager to the payload as the payload sets emission admin and 
  // the payload needs to be the owner in order to do so
  const ownable = await ethers.getContractAt("IOwnable", AaveV3Celo.EMISSION_MANAGER, signer);
  await ownable.transferOwnership(payloadAddress);

  // Execute payload
  const executor = await ethers.getContractAt("IProposalGenericExecutor", payloadAddress, signer);
  await executor.execute();
}

main();