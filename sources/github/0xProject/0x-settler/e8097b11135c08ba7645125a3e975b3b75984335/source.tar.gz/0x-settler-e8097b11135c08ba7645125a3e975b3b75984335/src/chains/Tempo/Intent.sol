// SPDX-License-Identifier: MIT
pragma solidity =0.8.34;

import {TempoSettlerMetaTxn} from "./MetaTxn.sol";
import {SettlerIntent} from "../../SettlerIntent.sol";
import {BlockTempoSystemContracts} from "./BlockTempoSystemContracts.sol";

import {IERC20} from "@forge-std/interfaces/IERC20.sol";
import {ISignatureTransfer} from "@permit2/interfaces/ISignatureTransfer.sol";
import {ISettlerActions} from "../../ISettlerActions.sol";

import {ReceivePolicyBlocked} from "../../core/SettlerErrors.sol";

interface ITempoAddressRegistry {
    function resolveRecipient(address to) external view returns (address);
}

interface ITempoReceivePolicy {
    function validateReceivePolicy(address token, address sender, address receiver)
        external
        view
        returns (bool authorized, uint8 blockedReason);
}

// Solidity inheritance is stupid
import {SettlerAbstract, SettlerSwapAbstract} from "../../SettlerAbstract.sol";
import {SettlerBase} from "../../SettlerBase.sol";
import {SettlerMetaTxn} from "../../SettlerMetaTxn.sol";
import {SettlerIntent} from "../../SettlerIntent.sol";
import {AbstractContext, Context} from "../../Context.sol";
import {Permit2PaymentAbstract} from "../../core/Permit2PaymentAbstract.sol";
import {Permit2PaymentMetaTxn} from "../../core/Permit2Payment.sol";

/// @custom:security-contact security@0x.org
contract TempoSettlerIntent is SettlerIntent, TempoSettlerMetaTxn {
    constructor(bytes20 gitCommit) TempoSettlerMetaTxn(gitCommit) {}

    // A recipient's TIP-1028 receive policy would send a TIP-20 payout to the ReceivePolicyGuard
    // rather than the recipient. Revert instead.
    function _transferBuyToken(IERC20 buyToken, address recipient, uint256 amountOut)
        internal
        virtual
        override(SettlerSwapAbstract, SettlerBase)
    {
        if (uint160(address(buyToken)) >> 64 == 0x20c000000000000000000000) {
            address resolved = ITempoAddressRegistry(_TEMPO_ADDRESS_REGISTRY).resolveRecipient(recipient);
            (bool authorized,) = ITempoReceivePolicy(_TEMPO_TIP403_REGISTRY)
                .validateReceivePolicy(address(buyToken), address(this), resolved);
            if (!authorized) revert ReceivePolicyBlocked(recipient);
        }
        super._transferBuyToken(buyToken, recipient, amountOut);
    }

    // Solidity inheritance is stupid
    function executeMetaTxn(
        AllowedSlippage memory slippage,
        bytes[] calldata actions,
        bytes32, /* zid & affiliate */
        address msgSender,
        bytes calldata sig
    ) public override(SettlerIntent, SettlerMetaTxn) returns (bool) {
        return super.executeMetaTxn(slippage, actions, bytes32(0), msgSender, sig);
    }

    function _dispatch(uint256 i, uint256 action, bytes calldata data, AllowedSlippage memory slippage)
        internal
        override(TempoSettlerMetaTxn, SettlerBase)
        returns (bool)
    {
        return super._dispatch(i, action, data, slippage);
    }

    function _isForwarded() internal view override(AbstractContext, Context, SettlerIntent) returns (bool) {
        return super._isForwarded();
    }

    function _msgData() internal view override(AbstractContext, Context, SettlerIntent) returns (bytes calldata) {
        return super._msgData();
    }

    function _msgSender() internal view override(SettlerIntent, TempoSettlerMetaTxn) returns (address) {
        return super._msgSender();
    }

    function _witnessTypeSuffix() internal pure override(SettlerIntent, Permit2PaymentMetaTxn) returns (string memory) {
        return super._witnessTypeSuffix();
    }

    function _mandatorySlippageCheck() internal pure override(SettlerBase, SettlerIntent) returns (bool) {
        return super._mandatorySlippageCheck();
    }

    function _tokenId() internal pure override(SettlerIntent, SettlerMetaTxn, SettlerAbstract) returns (uint256) {
        return super._tokenId();
    }

    function _dispatchVIP(uint256 action, bytes calldata data, bytes calldata sig)
        internal
        override(TempoSettlerMetaTxn, SettlerMetaTxn)
        returns (bool)
    {
        return super._dispatchVIP(action, data, sig);
    }

    function _permitToSellAmountCalldata(ISignatureTransfer.PermitTransferFrom calldata permit)
        internal
        view
        override(SettlerIntent, Permit2PaymentAbstract, Permit2PaymentMetaTxn)
        returns (uint256)
    {
        return super._permitToSellAmountCalldata(permit);
    }

    function _permitToSellAmount(ISignatureTransfer.PermitTransferFrom memory permit)
        internal
        view
        override(SettlerIntent, Permit2PaymentAbstract, Permit2PaymentMetaTxn)
        returns (uint256)
    {
        return super._permitToSellAmount(permit);
    }

    function _isRestrictedTarget(address target)
        internal
        view
        virtual
        override(TempoSettlerMetaTxn, SettlerIntent)
        returns (bool)
    {
        return super._isRestrictedTarget(target);
    }

    function _fallback(bytes calldata data)
        internal
        virtual
        override(Permit2PaymentAbstract, TempoSettlerMetaTxn)
        returns (bool, bytes memory)
    {
        return super._fallback(data);
    }
}
