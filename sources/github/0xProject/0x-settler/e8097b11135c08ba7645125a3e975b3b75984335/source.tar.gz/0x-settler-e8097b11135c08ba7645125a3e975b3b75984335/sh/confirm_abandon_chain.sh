#!/usr/bin/env bash

## POSIX Bash implementation of realpath
## Copied and modified from https://github.com/mkropat/sh-realpath and https://github.com/AsymLabs/realpath-lib/
## Copyright (c) 2014 Michael Kropat - MIT License
## Copyright (c) 2013 Asymmetry Laboratories - MIT License

function realpath {
    _resolve_symlinks "$(_canonicalize "$1")"
}

function _directory {
    local out slsh
    slsh=/
    out="$1"
    out="${out//$slsh$slsh/$slsh}"
    if [ "$out" = / ]; then
        echo /
        return
    fi
    out="${out%/}"
    case "$out" in
        */*)
            out="${out%/*}"
        ;;
        *)
            out=.
        ;;
    esac
    if [ "$out" ]; then
        printf '%s\n' "$out"
    else
        echo /
    fi
}

function _file {
    local out slsh
    slsh=/
    out="$1"
    out="${out//$slsh$slsh/$slsh}"
    if [ "$out" = / ]; then
        echo /
        return
    fi
    out="${out%/}"
    out="${out##*/}"
    printf '%s\n' "$out"
}

function _resolve_symlinks {
    local path pattern context
    while [ -L "$1" ]; do
        context="$(_directory "$1")"
        path="$(POSIXLY_CORRECT=y ls -ld -- "$1" 2>/dev/null)"
        pattern='*'"$(_escape "$1")"' -> '
        path="${path#$pattern}"
        set -- "$(_canonicalize "$(_prepend_context "$context" "$path")")" "$@"
        _assert_no_path_cycles "$@" || return 1
    done
    printf '%s\n' "$1"
}

function _escape {
    local out
    out=''
    local -i i
    for ((i=0; i < ${#1}; i+=1)); do
        out+='\'"${1:$i:1}"
    done
    printf '%s\n' "$out"
}

function _prepend_context {
    if [ "$1" = . ]; then
        printf '%s\n' "$2"
    else
        case "$2" in
            /* ) printf '%s\n' "$2" ;;
             * ) printf '%s\n' "$1/$2" ;;
        esac
    fi
}

function _assert_no_path_cycles {
    local target path

    if [ $# -gt 16 ]; then
        return 1
    fi

    target="$1"
    shift

    for path in "$@"; do
        if [ "$path" = "$target" ]; then
            return 1
        fi
    done
}

function _canonicalize {
    local d f
    if [ -d "$1" ]; then
        (CDPATH= cd -P "$1" 2>/dev/null && pwd -P)
    else
        d="$(_directory "$1")"
        f="$(_file "$1")"
        (CDPATH= cd -P "$d" 2>/dev/null && printf '%s/%s\n' "$(pwd -P)" "$f")
    fi
}

## end POSIX Bash implementation of realpath

set -Eeufo pipefail -o posix

declare project_root
project_root="$(_directory "$(_directory "$(realpath "${BASH_SOURCE[0]}")")")"
declare -r project_root
cd "$project_root"

. "$project_root"/sh/common.sh
. "$project_root"/sh/common_secrets.sh

decrypt_secrets

# Determine which safe to abandon based on last argument
declare safe_address
declare initial_owner
if [[ ${@: -1} = [Uu]pgrade ]] ; then
    safe_address="$(get_config governance.upgradeSafe)"
    # Upgrade safe goes back to deployer.deployer (the deployer proxy deployer)
    initial_owner="$(get_secret deployer deployer)"
else
    safe_address="$(get_config governance.deploymentSafe)"
    # Deployment safe goes back to iceColdCoffee.deployer
    initial_owner="$(get_secret iceColdCoffee deployer)"
fi
declare -r safe_address
declare -r initial_owner

echo "Abandoning Safe: $safe_address" >&2
echo "Will set sole owner to: $initial_owner" >&2

. "$project_root"/sh/common_safe.sh

# Verify the initial owner is not already the only owner
if (( ${#owners_array[@]} == 1 )) && [[ $(cast to-checksum "${owners_array[0]}") = $(cast to-checksum "$initial_owner") ]] ; then
    echo 'Safe is already abandoned (initial owner is the only owner)' >&2
    exit 0
fi

. "$project_root"/sh/common_safe_owner.sh
. "$project_root"/sh/common_wallet_type.sh

if [[ ${SAFE_GUARD_OVERRIDE:-${safe_guard:-null}} != [nN][uU][lL][lL] ]] ; then
    declare -r setGuard_sig='setGuard(address)'
    declare remove_guard_call
    remove_guard_call="$(cast calldata "$setGuard_sig" "$(cast address-zero)")"
    declare -r remove_guard_call

    declare struct_json
    struct_json="$(eip712_json "$remove_guard_call" 0 "$safe_address")"

    declare signature
    signature="$(sign_call "$struct_json")"

    save_signature abandon_chain_guard_removal "$remove_guard_call" "$signature" 0 "$safe_address"
    echo 'SafeGuard removal signed. Now signing the abandonment transaction for the next nonce.' >&2

    # The abandonment executes at the next nonce, after the Guard is removed, so its
    # multisend must not contain check() sub-calls
    SAFE_NONCE_INCREMENT=$((${SAFE_NONCE_INCREMENT:-0} + 1))
    SAFE_GUARD_OVERRIDE=null
fi

declare -r removeOwner_sig='removeOwner(address,address,uint256)'
declare -r swapOwner_sig='swapOwner(address,address,address)'
declare -r sentinel='0x0000000000000000000000000000000000000001'

declare -a calls=()

# Remove owners until only one remains
declare -a current_owners=("${owners_array[@]}")

while (( ${#current_owners[@]} > 1 )) ; do
    declare owner_to_remove="${current_owners[0]}"

    declare removeOwner_call
    removeOwner_call="$(cast calldata "$removeOwner_sig" "$sentinel" "$owner_to_remove" 1)"

    calls+=("$safe_address" "$removeOwner_call")

    # Update working state
    current_owners=("${current_owners[@]:1}")
done

declare last_owner="${current_owners[0]}"

if [[ $(cast to-checksum "$last_owner") != "$(cast to-checksum "$initial_owner")" ]] ; then
    declare swapOwner_call
    swapOwner_call="$(cast calldata "$swapOwner_sig" "$sentinel" "$last_owner" "$initial_owner")"

    calls+=("$safe_address" "$swapOwner_call")
fi

# Wrap in multiSend call
declare multisend_calldata
multisend_calldata="$(build_multisend_calldata "${calls[@]}")"
declare -r multisend_calldata

# Sign the transaction (operation=1 for delegatecall to multicall)
declare struct_json
struct_json="$(eip712_json "$multisend_calldata" 1)"
declare -r struct_json

declare signature
signature="$(sign_call "$struct_json")"
declare -r signature

save_signature abandon_chain "$multisend_calldata" "$signature" 1
