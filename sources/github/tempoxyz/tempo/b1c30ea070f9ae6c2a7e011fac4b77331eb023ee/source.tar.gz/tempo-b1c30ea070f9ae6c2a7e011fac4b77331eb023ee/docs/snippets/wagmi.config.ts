// @ts-nocheck
// biome-ignore-all lint: snippet
// biome-ignore-all format: snippet

// [!region setup]
import { tempoTestnet } from 'viem/chains'
import { createConfig, http } from 'wagmi'
import { KeyManager, webAuthn } from 'wagmi/tempo'

export const config = createConfig({
  connectors: [
    webAuthn({
      keyManager: KeyManager.localStorage(),
    }),
  ],
  chains: [tempoTestnet],
  multiInjectedProviderDiscovery: false,
  transports: {
    [tempoTestnet.id]: http(),
  },
})

// [!endregion setup]

// [!region withFeePayer]
import { tempoTestnet } from 'viem/chains'
import { withFeePayer } from 'viem/tempo'
import { createConfig, http } from 'wagmi'
import { KeyManager, webAuthn } from 'wagmi/tempo'

export const config = createConfig({
  connectors: [
    webAuthn({
      keyManager: KeyManager.localStorage(),
    }),
  ],
  chains: [tempoTestnet],
  multiInjectedProviderDiscovery: false,
  transports: {
    [tempoTestnet.id]: withFeePayer(
      http(),
      http('https://sponsor.testnet.tempo.xyz'),
    ),
  },
})
// [!endregion withFeePayer]
