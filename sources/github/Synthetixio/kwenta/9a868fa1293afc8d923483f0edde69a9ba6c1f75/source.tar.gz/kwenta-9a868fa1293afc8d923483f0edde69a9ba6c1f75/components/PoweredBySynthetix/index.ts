export { default } from './PoweredBySynthetix';
