export { default } from './MarketClosureIcon';
