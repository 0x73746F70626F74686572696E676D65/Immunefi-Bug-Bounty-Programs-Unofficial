export { default } from './RechartsResponsiveContainer';
