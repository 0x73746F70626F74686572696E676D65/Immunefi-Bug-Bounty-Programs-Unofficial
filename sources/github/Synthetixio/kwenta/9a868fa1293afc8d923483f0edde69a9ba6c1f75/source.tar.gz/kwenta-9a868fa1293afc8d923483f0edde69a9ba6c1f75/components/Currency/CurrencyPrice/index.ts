export { default } from './CurrencyPrice';
