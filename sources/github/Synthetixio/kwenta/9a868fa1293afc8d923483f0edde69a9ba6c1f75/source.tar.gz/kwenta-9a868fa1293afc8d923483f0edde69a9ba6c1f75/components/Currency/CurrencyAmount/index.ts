export { default } from './CurrencyAmount';
