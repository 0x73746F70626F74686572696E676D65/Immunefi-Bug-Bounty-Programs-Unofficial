export { default } from './CurrencyIcon';
