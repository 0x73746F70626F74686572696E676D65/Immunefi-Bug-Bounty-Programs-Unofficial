export { default } from './TrendingSynths';
