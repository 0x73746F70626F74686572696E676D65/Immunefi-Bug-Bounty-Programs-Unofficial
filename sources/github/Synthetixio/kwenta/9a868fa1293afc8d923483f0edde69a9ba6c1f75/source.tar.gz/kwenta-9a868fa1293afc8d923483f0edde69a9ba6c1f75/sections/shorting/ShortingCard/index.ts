export { default } from './ShortingCard';
