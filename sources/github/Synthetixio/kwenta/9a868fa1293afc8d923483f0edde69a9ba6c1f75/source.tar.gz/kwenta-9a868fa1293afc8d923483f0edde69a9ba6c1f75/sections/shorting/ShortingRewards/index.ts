export { default } from './ShortingRewards';
