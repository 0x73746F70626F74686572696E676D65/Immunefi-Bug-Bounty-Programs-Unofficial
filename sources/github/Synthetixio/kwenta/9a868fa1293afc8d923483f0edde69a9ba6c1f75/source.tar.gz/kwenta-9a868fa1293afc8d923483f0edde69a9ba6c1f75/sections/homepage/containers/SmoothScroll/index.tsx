export { default } from './SmoothScroll';
