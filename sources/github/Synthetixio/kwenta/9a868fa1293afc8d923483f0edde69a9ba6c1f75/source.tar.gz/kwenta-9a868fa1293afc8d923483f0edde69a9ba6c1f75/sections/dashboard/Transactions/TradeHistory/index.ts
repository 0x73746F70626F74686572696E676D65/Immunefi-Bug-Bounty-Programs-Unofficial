export { default } from './TradeHistory';
