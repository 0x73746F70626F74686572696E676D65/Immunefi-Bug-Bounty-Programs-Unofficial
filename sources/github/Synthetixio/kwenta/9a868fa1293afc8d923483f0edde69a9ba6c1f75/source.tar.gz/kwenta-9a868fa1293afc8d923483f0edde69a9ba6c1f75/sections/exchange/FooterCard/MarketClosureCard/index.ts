export { default } from './MarketClosureCard';
