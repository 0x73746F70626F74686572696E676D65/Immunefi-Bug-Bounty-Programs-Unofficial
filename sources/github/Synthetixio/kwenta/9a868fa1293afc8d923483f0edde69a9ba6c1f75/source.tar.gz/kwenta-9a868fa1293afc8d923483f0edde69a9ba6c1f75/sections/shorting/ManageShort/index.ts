export { default } from './ManageShort';
