export { default } from './FeeReclaimingSynths';
