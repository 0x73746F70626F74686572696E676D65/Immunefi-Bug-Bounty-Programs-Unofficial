export { default } from './NoSynthsCard';
