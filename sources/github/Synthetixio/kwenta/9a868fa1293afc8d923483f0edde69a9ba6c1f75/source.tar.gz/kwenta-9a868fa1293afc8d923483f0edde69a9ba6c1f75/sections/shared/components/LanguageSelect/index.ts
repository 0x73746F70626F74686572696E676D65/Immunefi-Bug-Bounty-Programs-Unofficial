export { default } from './LanguageSelect';
