# Changelog

All notable changes to this project are documented here. The format is based on
[Keep a Changelog](https://keepachangelog.com/en/1.1.0/) and this project follows
[Semantic Versioning](https://semver.org/spec/v2.0.0.html).

While the SDK is pre-1.0 (`0.x.y`), minor version bumps may include breaking
changes. Pin to a compatible range (e.g. `synthetix-sdk>=0.1,<0.2`) to opt out
of breaking updates.

<!-- changelog-next -->

## [0.7.0] - 2026-08-17

### Breaking Changes

- Delegated-signer requests now use the `params`-based envelope. `add_delegated_signer()`
  and `remove_delegated_signer()` (and their `ws_` equivalents) previously sent
  `subaccountId` and the signer's `walletAddress` at the top level of the request body,
  alongside `params`. Both now ride inside `params`, where `subaccountId` sits for every
  other signed action; `params.walletAddress` continues to carry the delegate's address.

  **No Python API change** — method signatures, arguments, and return values are all
  unchanged. This only affects the JSON sent on the wire, so most integrators need to do
  nothing beyond upgrading. Anyone inspecting, proxying, or asserting on the raw request
  body for these two actions will see the new shape.

  This removes the SDK's last dependency on the legacy request structure that the server
  accepts behind `ProvideRequestStructureBackwardsCompatibility`, which is slated for
  removal. The new shape is accepted by the server both before and after that flag is
  turned off, so upgrading early is safe — and necessary before it flips.

### Documentation

- Document the new `periodStats` field on `get_market_prices()` responses.

## [0.6.0] - 2026-07-30

### Breaking Changes

- `get_exchange_status()` / `ws_get_exchange_status()` now query `GET /status` instead
  of `GET /exchange/status`. The return value is still `{"rest": {...}, "ws": {...}}`,
  but each entry is now `{"maintenance": bool, "message": str}` (`message` present only
  while maintenance is on) instead of
  `{"exchange_status": "RUNNING"|"MAINTENANCE", "timestamp_ms": int}` (#126)

### Features

- Capture free rate-limit snapshots from response envelopes (#108)
- Sync getOpenInterest/withdrawCollateral changes + add getCollaterals wrapper (#111)
- Add modify_order_by_cloid (REST + WS) (#118)

### Bug Fixes

- Remove non-functional subaccount_id override from WS mutations (#119)
- Repoint get_exchange_status at the edge-served GET /status endpoint (#126)

## [0.5.0] - 2026-06-16

### Features

- Add TWAP slice randomization via `interval_variance_bps` and `size_variance_bps` (0–2000 bps) on `twap_order`/`place_orders` and their `ws_` equivalents to vary each child slice's timing and size (#98)
- Add `transfer_types` filter to `get_balance_updates`/`ws_get_balance_updates` (#98)

### Changed

- **Breaking:** `get_exchange_status`/`ws_get_exchange_status` now return only `exchange_status` and `timestamp_ms`; the `accepting_orders`, `code`, and `message` fields were removed (OFF-1106) (#98)

## [0.4.0] - 2026-06-08

### Features

- Add voluntaryCollateralExchange SDK wrapper — convert a non-USDT collateral to USDT to cover USDT debt, over REST and WS (#93)

### Documentation

- Note manager/delegated withdrawCollateral access control: delegated/manager signers may only withdraw to the subaccount owner's wallet, otherwise the server returns 403 (#93)

## [0.3.0] - 2026-06-02

### Features

- Add symbol filter to get_positions wrapper (#87)
- Add getFeeRate SDK wrapper, remove getFees (#89)

### Documentation

- Surface new usdtNotional field on getBalanceUpdates (#78)
- Document optional onHours field on getMarketPrices (#82)

### Miscellaneous

- Replace USDC with USDT as default collateral symbol (#79)
- Bump idna from 3.13 to 3.15 (#83)

## [0.2.0] - 2026-05-18

### Changed

- Switch project build and dependency tooling from Poetry to uv (#72). Contributors should now use `uv sync --group dev` and `uv run pytest …` in place of the Poetry equivalents. No impact for `pip install synthetix-sdk` consumers — the published wheel is unchanged.

### Documentation

- Fix PyPI sidebar links, drop duplicate Homepage URL, and bump Development Status classifier to Production/Stable (#69).

### Security

- Bump `urllib3` (transitive via `requests`) from 2.6.3 to 2.7.0 to pick up two high-severity security fixes (GHSA-mf9v-mfxr-j63j, GHSA-qccp-gfcp-xxvc) (#74).

## [0.1.2] - 2026-05-08

### Features

- Add getTiers SDK wrapper (#66)

### Documentation

- Comprehensive PyPI page (README, tagline, sidebar links) (#67)



## [0.1.1] - 2026-05-07

First release published via the automated PyPI publishing pipeline. No SDK code changes versus `0.1.0`.

## [0.1.0] - 2026-05-06

Initial public release on PyPI.

### Added
- `Synthetix` client with REST and WebSocket support for Synthetix V4 perps trading
- Public market data endpoints via `MarketAPI` (`/info`)
- Authenticated account and trading endpoints via `AccountAPI` (`/trade`)
- EIP-712 signing via `Signer`
- Async WebSocket manager with auto-reconnect, auth replay, and subscription replay
- Order placement helpers: `place_orders`, `market_order`, `limit_order`, `twap_order`, `stop_loss_order`, `take_profit_order`
- WebSocket-based async equivalents (`ws_*`) for trade endpoints
- Example scripts under `examples/rest/` and `examples/ws/`
