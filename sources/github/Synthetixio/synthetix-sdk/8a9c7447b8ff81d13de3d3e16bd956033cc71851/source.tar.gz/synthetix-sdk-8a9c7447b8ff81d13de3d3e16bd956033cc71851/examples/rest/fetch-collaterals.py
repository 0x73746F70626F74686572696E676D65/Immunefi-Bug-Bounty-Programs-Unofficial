"""
Fetch the exchange's collateral asset configuration.
"""

import os

from dotenv import load_dotenv

from synthetix import Synthetix

load_dotenv()

snx = Synthetix(rest_url=os.environ.get("REST_URL_OVERRIDE"))

collaterals = snx.get_collaterals()
print(f"{len(collaterals)} collateral asset(s) configured\n")

for c in collaterals:
    print(
        f"  {c['collateral']:8s}"
        f"  ltv={c['ltv']:>6s}"
        f"  lltv={c['lltv']:>6s}"
        f"  depositCap={c['depositCap']:>14s}"
        f"  withdrawFee={c['withdrawFee']:>6s}"
        f"  ({len(c['tiers'])} tier(s))"
    )
