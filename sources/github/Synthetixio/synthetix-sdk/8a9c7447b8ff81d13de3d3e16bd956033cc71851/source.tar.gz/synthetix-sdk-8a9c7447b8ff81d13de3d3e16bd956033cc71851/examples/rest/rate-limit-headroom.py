"""
Monitor rate-limit headroom for free by reading the snapshots the Synthetix
exchange attaches to every response envelope.

Unlike get_rate_limits() — which consumes rate-limit tokens itself — the
`snx.last_rate_limits` property is refreshed as a side effect of every REST
call and WS post, so reading it costs nothing.

Requires: PRIVATE_KEY environment variable.
"""

import os
from pprint import pprint

from dotenv import load_dotenv

from synthetix import Synthetix

load_dotenv()

snx = Synthetix(private_key=os.environ["PRIVATE_KEY"], rest_url=os.environ.get("REST_URL_OVERRIDE"))
print(f"Wallet:     {snx.address}")
print(f"Subaccount: {snx.subaccount_id}\n")

# Nothing captured yet — no trade-endpoint call has been made
print("Before any request:")
pprint(snx.last_rate_limits)

# Any authenticated call refreshes the snapshots as a side effect
snx.get_positions()

print("\nAfter a /trade request:")
pprint(snx.last_rate_limits)

snap = snx.last_rate_limits["rest"]["rateLimit"]
if snap:
    used_pct = 100 * (1 - snap["remainingTokens"] / snap["requestsCap"])
    print(f"\nSubaccount bucket: {snap['remainingTokens']}/{snap['requestsCap']} tokens left ({used_pct:.1f}% used)")

# A 429 reject also carries the snapshots — on the raised exception:
#
#   from synthetix.rest.api import ClientError
#   try:
#       snx.place_order(...)
#   except ClientError as e:
#       if e.status_code == 429:
#           print("throttled; bucket:", e.rate_limit, "ip bucket:", e.ip_rate_limit)
#
# A 429 is authoritative — back off even if remainingTokens is still positive.
