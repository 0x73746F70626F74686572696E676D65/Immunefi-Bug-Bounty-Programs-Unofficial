"""
Fetch current prices for all markets.
"""

import os

from dotenv import load_dotenv

from synthetix import Synthetix

load_dotenv()

snx = Synthetix(rest_url=os.environ.get("REST_URL_OVERRIDE"))

prices = snx.get_market_prices()
print(f"Prices for {len(prices)} markets\n")

for symbol, data in prices.items():
    print(f"  {symbol:20s}  bid={data['bestBid']:>12s}  ask={data['bestAsk']:>12s}  mark={data['markPrice']:>12s}")

with_period_stats = {sym: data["periodStats"] for sym, data in prices.items() if data.get("periodStats")}
print(f"\nPeriod stats ({len(with_period_stats)} of {len(prices)} markets):")
for symbol, period_stats in with_period_stats.items():
    print(f"  {symbol}")
    for window, stats in sorted(period_stats.items()):
        print(
            f"    {window:5s}"
            f"  ref={stats['referencePrice']:>12s}"
            f"  vol={stats['volume']:>14s}"
            f"  quoteVol={stats['quoteVolume']:>16s}"
        )
