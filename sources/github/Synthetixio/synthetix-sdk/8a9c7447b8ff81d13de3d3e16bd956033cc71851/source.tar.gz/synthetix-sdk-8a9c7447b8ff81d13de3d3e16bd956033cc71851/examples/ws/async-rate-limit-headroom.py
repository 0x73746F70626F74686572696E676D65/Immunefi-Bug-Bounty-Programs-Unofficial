"""
Monitor rate-limit headroom over WebSocket for free.

The Synthetix exchange attaches rateLimit (subaccount order bucket) and
ipRateLimit (per-IP bucket) snapshots top-level on every WS post response.
The SDK captures them as a side effect, so reading ``snx.last_rate_limits``
costs nothing — unlike ``ws_get_rate_limits()``, which consumes tokens.

Requires: PRIVATE_KEY environment variable.
"""

import asyncio
import os
from pprint import pprint

from dotenv import load_dotenv

from synthetix import Synthetix

load_dotenv()


async def main():
    snx = Synthetix(
        private_key=os.environ["PRIVATE_KEY"],
        rest_url=os.environ.get("REST_URL_OVERRIDE"),
        ws_url=os.environ.get("WS_URL_OVERRIDE"),
    )
    print(f"Wallet:     {snx.address}")
    print(f"Subaccount: {snx.subaccount_id}\n")

    try:
        # Any WS post refreshes the snapshots as a side effect
        await snx.ws_get_positions()

        print("After a WS post:")
        pprint(snx.last_rate_limits)

        snap = snx.last_rate_limits["ws"]["rateLimit"]
        if snap:
            used_pct = 100 * (1 - snap["remainingTokens"] / snap["requestsCap"])
            print(
                f"\nSubaccount bucket: {snap['remainingTokens']}/{snap['requestsCap']}"
                f" tokens left ({used_pct:.1f}% used)"
            )
    finally:
        await snx.close()


if __name__ == "__main__":
    asyncio.run(main())
