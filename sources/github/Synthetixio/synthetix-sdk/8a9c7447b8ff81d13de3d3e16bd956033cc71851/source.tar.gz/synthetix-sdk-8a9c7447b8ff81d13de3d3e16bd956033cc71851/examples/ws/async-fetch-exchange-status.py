"""
Check exchange maintenance status from both REST and WS servers via GET /status
(async, parallel).

No authentication required.
"""

import asyncio
import os

from dotenv import load_dotenv

from synthetix import Synthetix

load_dotenv()


async def main():
    snx = Synthetix(
        rest_url=os.environ.get("REST_URL_OVERRIDE"),
        ws_url=os.environ.get("WS_URL_OVERRIDE"),
    )

    status = await snx.ws_get_exchange_status()

    for server in ("rest", "ws"):
        s = status[server]
        if s["maintenance"]:
            print(f"[{server.upper()}] MAINTENANCE — {s.get('message', '')}")
        else:
            print(f"[{server.upper()}] up")


if __name__ == "__main__":
    asyncio.run(main())
