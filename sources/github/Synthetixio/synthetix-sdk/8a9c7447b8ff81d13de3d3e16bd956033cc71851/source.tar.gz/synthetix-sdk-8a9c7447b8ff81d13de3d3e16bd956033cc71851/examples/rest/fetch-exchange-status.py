"""
Check whether the exchange is operational or in maintenance via GET /status.
Queries both the REST and WebSocket servers.
"""

import os

from dotenv import load_dotenv

from synthetix import Synthetix

load_dotenv()

snx = Synthetix(
    rest_url=os.environ.get("REST_URL_OVERRIDE"),
    ws_url=os.environ.get("WS_URL_OVERRIDE"),
)

status = snx.get_exchange_status()

for server in ("rest", "ws"):
    s = status[server]
    if s["maintenance"]:
        print(f"[{server.upper()}] MAINTENANCE — {s.get('message', '')}")
    else:
        print(f"[{server.upper()}] up")
