"""
Authenticated account and trading endpoints (POST /v1/trade).
All requests require EIP-712 signatures.
"""

from typing import Any, Dict, List, Optional

from synthetix.rest.api import API
from synthetix.signing import Signer
from synthetix.utils.constants import DEFAULT_EXPIRES_AFTER_MS


class AccountAPI:
    """Authenticated trading and account endpoints — all POST to /trade."""

    def __init__(
        self,
        api: API,
        signer: Signer,
        subaccount_id: int,
        expires_after_ms: int = DEFAULT_EXPIRES_AFTER_MS,
    ) -> None:
        self._api = api
        self._signer = signer
        self.subaccount_id = subaccount_id
        self.expires_after_ms = expires_after_ms

    @property
    def last_rate_limit(self) -> Optional[Dict]:
        """Most recent subaccount rateLimit snapshot from a response envelope.

        ``{"requestsCap": int, "remainingTokens": int}`` or None if the server
        has not sent one yet. Updated for free on every /trade response.
        """
        return self._api.last_rate_limit

    @property
    def last_ip_rate_limit(self) -> Optional[Dict]:
        """Most recent per-IP ipRateLimit snapshot from a response envelope.

        ``{"requestsCap": int, "remainingTokens": int}`` or None if the server
        has not sent one yet.
        """
        return self._api.last_ip_rate_limit

    def _trade(self, request: Dict[str, Any]) -> Any:
        """Send a signed request to /trade."""
        return self._api.post("/trade", request)

    def _action(
        self,
        action: str,
        subaccount_id: Optional[int] = None,
        **params: Any,
    ) -> Any:
        """Sign and send a generic subaccount action (get* queries)."""
        sid = subaccount_id if subaccount_id is not None else self.subaccount_id
        action_params = params if params else None
        request = self._signer.sign_action(
            sid, action, action_params=action_params, expires_after_ms=self.expires_after_ms
        )
        return self._trade(request)

    # ── Order Management ────────────────────────────────────────────

    def place_orders(
        self,
        orders: List[Dict[str, Any]],
        grouping: str = "na",
    ) -> Dict:
        """Place one or more orders in a single request.

        Args:
            orders: List of order dicts with camelCase keys. Common fields:
                ``symbol``, ``side``, ``orderType``, ``quantity``, ``price``.

                ``orderType`` values:
                - ``"limitGtc"`` — rests until filled or canceled
                - ``"limitIoc"`` — fills immediately, cancels remainder
                - ``"limitGtd"`` — rests until filled, canceled, or ``expiresAt``;
                  include ``expiresAt`` (Unix seconds, 10–86400 s in the future)
                - ``"market"`` — fills at best available price
                - ``"triggerTp"`` / ``"triggerSl"`` — trigger orders
                - ``"twap"`` — time-weighted execution; requires
                  ``durationSeconds`` (300–86400 s) and optionally
                  ``intervalSeconds``, ``intervalVarianceBps``, and
                  ``sizeVarianceBps`` (variance fields 0–2000 bps)

            grouping: ``"na"`` (default), ``"positionTpsl"``, or ``"twap"``.
                Use ``"twap"`` when placing a ``twap`` order type.

        Returns ``{"statuses": [...]}``.
        """
        request = self._signer.sign_place_orders(
            self.subaccount_id, orders, grouping=grouping, expires_after_ms=self.expires_after_ms
        )
        return self._trade(request)

    def modify_order(
        self,
        order_id: int,
        price: Optional[str] = None,
        quantity: Optional[str] = None,
        trigger_price: Optional[str] = None,
    ) -> Dict:
        """Modify an existing order."""
        request = self._signer.sign_modify_order(
            self.subaccount_id,
            order_id,
            price=price or "",
            quantity=quantity or "",
            trigger_price=trigger_price or "",
            expires_after_ms=self.expires_after_ms,
        )
        return self._trade(request)

    def modify_order_by_cloid(
        self,
        client_order_id: str,
        price: Optional[str] = None,
        quantity: Optional[str] = None,
        trigger_price: Optional[str] = None,
    ) -> Dict:
        """Modify an existing order by client order ID.

        Identifies the order by its client order ID (cloid) rather than the
        venue-assigned order ID. ``orderId`` and ``clientOrderId`` are mutually
        exclusive — the server rejects a request carrying both.
        """
        request = self._signer.sign_modify_order_by_cloid(
            self.subaccount_id,
            client_order_id,
            price=price or "",
            quantity=quantity or "",
            trigger_price=trigger_price or "",
            expires_after_ms=self.expires_after_ms,
        )
        return self._trade(request)

    def cancel_orders(self, order_ids: List[int]) -> Dict:
        """Cancel orders by ID."""
        request = self._signer.sign_cancel_orders(self.subaccount_id, order_ids, expires_after_ms=self.expires_after_ms)
        return self._trade(request)

    def cancel_orders_by_cloid(self, client_order_ids: List[str]) -> Dict:
        """Cancel orders by client order ID."""
        request = self._signer.sign_cancel_orders_by_cloid(
            self.subaccount_id, client_order_ids, expires_after_ms=self.expires_after_ms
        )
        return self._trade(request)

    def cancel_all_orders(self, symbol: str) -> Dict:
        """Cancel all open orders for the given symbol."""
        request = self._signer.sign_cancel_all_orders(
            self.subaccount_id, symbols=[symbol], expires_after_ms=self.expires_after_ms
        )
        return self._trade(request)

    # ── Account/Position Queries ────────────────────────────────────

    def get_sub_accounts(self) -> Any:
        """List all subaccounts.

        Returns ``{"subAccounts": [{subAccountId, masterAccountId,
        subAccountName, collaterals, crossMarginSummary, positions,
        marketPreferences, feeRates, delegatedSigners}]}``.
        """
        return self._action("getSubAccounts")

    def get_sub_account(self, subaccount_id: Optional[int] = None) -> Dict:
        """Get detailed info for a single subaccount.

        Returns a dict with: subAccountId, masterAccountId, subAccountName,
        collaterals (symbol, quantity, withdrawable, pendingWithdraw),
        crossMarginSummary (accountValue, availableMargin, totalUnrealizedPnl,
        maintenanceMargin, initialMargin, withdrawable, adjustedAccountValue),
        positions, marketPreferences, feeRates.
        """
        return self._action("getSubAccount", subaccount_id=subaccount_id)

    def get_positions(
        self,
        symbol: Optional[str] = None,
        subaccount_id: Optional[int] = None,
    ) -> List[Dict]:
        """Get open positions.

        Args:
            symbol: Optional market symbol filter (e.g. ``"BTC-USDT"``).
                When set, only positions for the given market are returned.
            subaccount_id: Subaccount ID (defaults to active).

        Each position contains: positionId, subAccountId, symbol, side,
        entryPrice, quantity, unrealizedPnl, usedMargin, maintenanceMargin,
        liquidationPrice, status, netFunding, updatedAt, createdAt.
        """
        kwargs: Dict[str, Any] = {}
        if symbol:
            kwargs["symbol"] = symbol
        return self._action("getPositions", subaccount_id=subaccount_id, **kwargs)

    def get_open_orders(self, subaccount_id: Optional[int] = None) -> List[Dict]:
        """Get open orders.

        Each order contains: order (``{"venueId": str}``), symbol, side, type,
        quantity, price, triggerPrice, triggerPriceType, timeInForce, reduceOnly,
        postOnly, createdTime, updatedTime, filledQuantity, closePosition,
        expiresAt (optional ISO timestamp for GTD order expiry),
        twapDetails (optional, present only for TWAP orders) — dict with keys:
        averagePrice, intervalMs, intervalVarianceBps, sizeVarianceBps,
        totalTrades, tradesFilled, totalFees, startedAtMs, totalDurationMs.
        """
        return self._action("getOpenOrders", subaccount_id=subaccount_id)

    def get_order_history(
        self,
        start_time: int = 0,
        end_time: int = 0,
        limit: int = 0,
        subaccount_id: Optional[int] = None,
    ) -> List[Dict]:
        """Get historical orders (filled, canceled, etc.).

        Args:
            start_time: Start timestamp in milliseconds. Pair with ``end_time``
                to define a window (max 7 days).
            end_time: End timestamp in milliseconds.
            limit: Max number of results (default 50, max 1000).
            subaccount_id: Subaccount ID (defaults to active).

        Each order contains the same fields as ``get_open_orders()`` plus:
        expiresAt (optional ISO timestamp for GTD order expiry),
        cancelReason (optional string explaining why the order was canceled),
        triggerPrice (optional string, stop/trigger price for the order),
        triggerPriceType (optional string, e.g. ``"last"`` or ``"mark"``),
        tpOrder (optional dict ``{"venueId": str}``, present when a take-profit linked order exists), and
        slOrder (optional dict ``{"venueId": str}``, present when a stop-loss linked order exists).
        """
        kwargs: Dict[str, Any] = {}
        if start_time:
            kwargs["startTime"] = start_time
        if end_time:
            kwargs["endTime"] = end_time
        if limit:
            kwargs["limit"] = limit
        return self._action("getOrderHistory", subaccount_id=subaccount_id, **kwargs)

    def get_trades(
        self,
        order_id: Optional[str] = None,
        subaccount_id: Optional[int] = None,
    ) -> Dict:
        """Get trade history.

        Args:
            order_id: Optional venue order ID to filter trades for a specific
                order. Must be a valid positive integer string up to 2^63-1.
            subaccount_id: Subaccount ID (defaults to active).

        Returns ``{"trades": [...], "hasMore": bool, "total": int}``.
        Each trade contains: tradeId, order (``{"venueId": str}``), symbol,
        side, price, quantity, realizedPnl, fee, feeRate, timestamp, maker,
        reduceOnly, markPrice, entryPrice, triggeredByLiquidation, direction,
        postOnly.
        """
        kwargs: Dict[str, Any] = {}
        if order_id:
            kwargs["orderId"] = order_id
        return self._action("getTrades", subaccount_id=subaccount_id, **kwargs)

    def get_trades_for_position(
        self,
        position_id: str,
        limit: int = 0,
        offset: int = 0,
        subaccount_id: Optional[int] = None,
    ) -> Dict:
        """Get trade fills for a specific position.

        Args:
            position_id: Position ID to fetch trades for.
            limit: Max number of trades to return (default 100, max 1000).
            offset: Pagination offset (default 0).
            subaccount_id: Subaccount ID (defaults to active).

        Returns ``{"trades": [...], "hasMore": bool}``.
        Each trade contains: tradeId, order (``{"venueId": str}``), symbol,
        orderType, side, price, quantity, realizedPnl, fee, feeRate, timestamp,
        maker, reduceOnly, markPrice, entryPrice, triggeredByLiquidation,
        direction, postOnly.
        """
        kwargs: Dict[str, Any] = {"positionId": position_id}
        if limit:
            kwargs["limit"] = limit
        if offset:
            kwargs["offset"] = offset
        return self._action("getTradesForPosition", subaccount_id=subaccount_id, **kwargs)

    def get_portfolio(self, subaccount_id: Optional[int] = None) -> List[Dict]:
        """Get portfolio snapshots. Each entry has assets and timestamp."""
        return self._action("getPortfolio", subaccount_id=subaccount_id)

    def get_balance_updates(
        self,
        start_time: int = 0,
        end_time: int = 0,
        action_filter: Optional[str] = None,
        limit: int = 0,
        offset: int = 0,
        subaccount_id: Optional[int] = None,
        transfer_types: Optional[List[str]] = None,
    ) -> Dict:
        """Get balance change history.

        Args:
            start_time: Start timestamp in milliseconds (optional, Synthetix
                defaults to 7 days ago; max window is 365 days).
            end_time: End timestamp in milliseconds (optional, Synthetix
                defaults to now).
            action_filter: Comma-separated list of actions to filter on.
                Valid values: ``DEPOSIT``, ``WITHDRAWAL``, ``TRANSFER``
                (e.g. ``"DEPOSIT,TRANSFER"``). Default: all actions.
            limit: Max number of results (default 50, max 1000).
            offset: Pagination offset (default 0, max 10000).
            subaccount_id: Subaccount ID (defaults to active).
            transfer_types: Optional list of transfer-type slugs to filter
                TRANSFER rows by. Valid slugs: ``"user"``, ``"slp_takeover"``,
                ``"collateral_exchange"``, ``"admin"``, ``"referral_commission"``.
                Only applies to TRANSFER actions. Default: all transfer types.

        Returns ``{"balanceUpdates": [...]}``, each with: id, subAccountId,
        action (``DEPOSIT`` | ``WITHDRAWAL`` | ``TRANSFER``), status
        (``success`` | ``completed`` | ``pending``), amount, grossAmount,
        fee, usdtNotional, collateral, timestamp. ``grossAmount`` is
        amount plus fee; ``fee`` is the fee charged for the balance
        update; ``usdtNotional`` is the spot USDT value at the time
        of the transaction. Additional fields vary by action: TRANSFER
        includes ``fromSubAccountId`` / ``toSubAccountId``; deposits
        and withdrawals include ``destinationAddress`` / ``txHash``.
        """
        kwargs: Dict[str, Any] = {}
        if start_time:
            kwargs["startTime"] = start_time
        if end_time:
            kwargs["endTime"] = end_time
        if action_filter:
            kwargs["actionFilter"] = action_filter
        if limit:
            kwargs["limit"] = limit
        if offset:
            kwargs["offset"] = offset
        if transfer_types:
            kwargs["transferTypes"] = transfer_types
        return self._action("getBalanceUpdates", subaccount_id=subaccount_id, **kwargs)

    def get_transfers(
        self,
        subaccount_id: Optional[int] = None,
        transfer_types: Optional[List[str]] = None,
    ) -> Dict:
        """Get transfer history.

        Args:
            subaccount_id: Subaccount ID (defaults to active).
            transfer_types: Optional list of transfer-type slugs to filter by.
                Valid slugs: ``"user"``, ``"slp_takeover"``,
                ``"collateral_exchange"``, ``"admin"``, ``"referral_commission"``.
                Default: all transfer types.

        Returns ``{"transfers": [...], "total": int}``, each with:
        transferId, from, to, symbol, amount, usdtNotional, transferType,
        status, timestamp.
        """
        kwargs: Dict[str, Any] = {}
        if transfer_types:
            kwargs["transferTypes"] = transfer_types
        return self._action("getTransfers", subaccount_id=subaccount_id, **kwargs)

    def get_position_history(
        self,
        symbol: Optional[str] = None,
        start_time: int = 0,
        end_time: int = 0,
        limit: int = 0,
        offset: int = 0,
        subaccount_id: Optional[int] = None,
    ) -> Dict:
        """Get historical (closed) positions.

        Returns ``{"positions": [...], "hasMore": bool}``.
        """
        kwargs: Dict[str, Any] = {}
        if symbol:
            kwargs["symbol"] = symbol
        if start_time:
            kwargs["startTime"] = start_time
        if end_time:
            kwargs["endTime"] = end_time
        if limit:
            kwargs["limit"] = limit
        if offset:
            kwargs["offset"] = offset
        return self._action("getPositionHistory", subaccount_id=subaccount_id, **kwargs)

    def get_performance_history(
        self,
        period: Optional[str] = None,
        subaccount_id: Optional[int] = None,
    ) -> Dict:
        """Get account performance history for a given period.

        Args:
            period: One of ``"day"``, ``"week"``, ``"month"``, ``"year"``
                (default ``"day"``).
            subaccount_id: Subaccount ID (defaults to active).

        Returns a dict with:
        - **subAccountId** — string ID
        - **period** — the requested period string
        - **performanceHistory** — ``{"history": [{"sampledAt": int,
          "accountValue": str, "pnl": str}], "volume": str}``
        """
        kwargs: Dict[str, Any] = {}
        if period:
            kwargs["period"] = period
        return self._action("getPerformanceHistory", subaccount_id=subaccount_id, **kwargs)

    # ── Account Management ──────────────────────────────────────────

    def create_subaccount(self, name: Optional[str] = None) -> Dict:
        """Create a new subaccount (uses current subaccount as master)."""
        request = self._signer.sign_create_subaccount(
            self.subaccount_id, name=name or "", expires_after_ms=self.expires_after_ms
        )
        return self._trade(request)

    def update_sub_account_name(self, name: str, subaccount_id: Optional[int] = None) -> Dict:
        """Rename a subaccount."""
        sid = subaccount_id if subaccount_id is not None else self.subaccount_id
        request = self._signer.sign_update_sub_account_name(sid, name, expires_after_ms=self.expires_after_ms)
        return self._trade(request)

    def update_leverage(self, symbol: str, leverage: int, subaccount_id: Optional[int] = None) -> Dict:
        """Set leverage for a symbol."""
        sid = subaccount_id if subaccount_id is not None else self.subaccount_id
        request = self._signer.sign_update_leverage(sid, symbol, str(leverage), expires_after_ms=self.expires_after_ms)
        return self._trade(request)

    def withdraw_collateral(
        self,
        amount: str,
        symbol: str = "USDT",
        destination: Optional[str] = None,
        subaccount_id: Optional[int] = None,
    ) -> Dict:
        """Withdraw collateral to destination address (defaults to wallet address).

        When signing as a manager/delegated wallet (i.e. not the subaccount
        owner), withdrawals are only permitted to the owner's wallet address;
        any other ``destination`` is rejected with a 403 Forbidden error.

        Returns ``{"requestId", "symbol", "amount", "destination",
        "usdtNotional"}``. ``amount`` is the gross amount reserved (includes the
        withdrawal fee); ``usdtNotional`` is the spot USDT value of the net
        disbursement (gross amount minus the withdrawal fee) at request time.
        """
        sid = subaccount_id if subaccount_id is not None else self.subaccount_id
        dest = destination or self._signer.address
        request = self._signer.sign_withdraw_collateral(
            sid, symbol, amount, dest, expires_after_ms=self.expires_after_ms
        )
        return self._trade(request)

    def transfer_collateral(
        self,
        amount: str,
        to_subaccount_id: int,
        symbol: str = "USDT",
        subaccount_id: Optional[int] = None,
    ) -> Dict:
        """Transfer collateral between subaccounts."""
        sid = subaccount_id if subaccount_id is not None else self.subaccount_id
        request = self._signer.sign_transfer_collateral(
            sid, to_subaccount_id, symbol, amount, expires_after_ms=self.expires_after_ms
        )
        return self._trade(request)

    def voluntary_collateral_exchange(
        self,
        source_asset: str,
        target_usdt_amount: str,
        subaccount_id: Optional[int] = None,
    ) -> Dict:
        """Voluntarily exchange a non-USDT collateral for USDT.

        Args:
            source_asset: Collateral symbol to exchange from (e.g. ``"BTC"``).
                Cannot be ``"USDT"``.
            target_usdt_amount: Either the literal string ``"all"`` to exchange
                the maximum available, or a positive decimal string of the
                target USDT amount to receive (e.g. ``"100"``).
            subaccount_id: Subaccount ID (defaults to active).

        Returns a dict with:
        - **sourceAsset** — collateral symbol exchanged from
        - **sourceAmountTaken** — decimal string, amount of ``sourceAsset`` consumed
        - **targetAsset** — destination collateral symbol (always ``"USDT"``)
        - **targetAmount** — decimal string, USDT received
        - **indexPrice** — decimal string, index price used for the exchange
        - **effectiveHaircut** — decimal string, haircut applied to the source
        - **collateral** — list of resulting collateral balances, each
          ``{"symbol": str, "quantity": str}``
        """
        sid = subaccount_id if subaccount_id is not None else self.subaccount_id
        request = self._signer.sign_voluntary_collateral_exchange(
            sid, source_asset, target_usdt_amount, expires_after_ms=self.expires_after_ms
        )
        return self._trade(request)

    # ── Fees & Funding ──────────────────────────────────────────────

    def get_fee_rate(self, subaccount_id: Optional[int] = None) -> Dict:
        """Get the current maker/taker fee rate and tier schedule.

        Returns ``{"volume14d": str, "currentTier": {...}, "makerFeeRate": str,
        "takerFeeRate": str, "tiers": [...], "referralDiscountApplied": bool,
        "referralDiscount": str}``.

        ``currentTier`` contains: ``tierId``, ``tierLevel`` (int), ``tierName``,
        ``tierType``, ``minTradeVolume``, ``makerFeeRate``, ``takerFeeRate``.
        Each entry in ``tiers`` contains: ``tierId``, ``tierLevel`` (int),
        ``tierName``, ``minTradeVolume``, ``makerFeeRate``, ``takerFeeRate``.

        ``makerFeeRate``/``takerFeeRate`` include the referral discount when
        ``referralDiscountApplied`` is true; ``referralDiscount`` is the
        multiplier applied (e.g. ``"0.9"``), ``"0"`` when no discount applies.
        """
        return self._action("getFeeRate", subaccount_id=subaccount_id)

    def get_funding_payments(self, subaccount_id: Optional[int] = None) -> Dict:
        """Get funding payment history.

        Returns ``{"summary": {"totalFundingReceived", "totalFundingPaid",
        "netFunding", "totalPayments", "averagePaymentSize"},
        "fundingHistory": [...]}``.
        """
        return self._action("getFundingPayments", subaccount_id=subaccount_id)

    def get_rate_limits(self, subaccount_id: Optional[int] = None) -> Dict:
        """Get rate limit status. Returns ``{"requestsUsed": int, "requestsCap": int}``."""
        return self._action("getRateLimits", subaccount_id=subaccount_id)

    # ── Delegation ──────────────────────────────────────────────────

    def add_delegated_signer(
        self,
        delegate_address: str,
        subaccount_id: Optional[int] = None,
        permissions: Optional[List[str]] = None,
    ) -> Dict:
        """Add a delegated signer. permissions must contain exactly one value (e.g. ['session'])."""
        sid = subaccount_id if subaccount_id is not None else self.subaccount_id
        request = self._signer.sign_add_delegated_signer(
            sid, delegate_address, permissions=permissions, expires_after_ms=self.expires_after_ms
        )
        return self._trade(request)

    def get_delegated_signers(self, subaccount_id: Optional[int] = None) -> Dict:
        """Get list of delegated signers.

        Returns ``{"delegatedSigners": [{"subAccountId", "walletAddress",
        "permissions", "expiresAt"}]}``.
        """
        return self._action("getDelegatedSigners", subaccount_id=subaccount_id)

    def remove_delegated_signer(self, delegate_address: str, subaccount_id: Optional[int] = None) -> Dict:
        """Remove a delegated signer."""
        sid = subaccount_id if subaccount_id is not None else self.subaccount_id
        request = self._signer.sign_remove_delegated_signer(
            sid, delegate_address, expires_after_ms=self.expires_after_ms
        )
        return self._trade(request)

    def remove_all_delegated_signers(self, subaccount_id: Optional[int] = None) -> Dict:
        """Remove all delegated signers."""
        sid = subaccount_id if subaccount_id is not None else self.subaccount_id
        request = self._signer.sign_remove_all_delegated_signers(sid, expires_after_ms=self.expires_after_ms)
        return self._trade(request)

    def schedule_cancel(
        self,
        timeout_seconds: int,
        subaccount_id: Optional[int] = None,
    ) -> Dict:
        """Configure the dead-man switch (schedule cancel).

        When active, all open orders will be canceled if the server does not
        receive a heartbeat within ``timeout_seconds``. Pass ``0`` to disable.

        Args:
            timeout_seconds: Inactivity timeout in seconds. Use ``0`` to
                disable the dead-man switch.
            subaccount_id: Subaccount ID (defaults to active).

        Returns a dict with:
        - **isActive** — ``bool`` — whether the dead-man switch is armed
        - **message** — human-readable status message
        - **timeoutSeconds** — configured timeout
        - **triggerTime** — millisecond timestamp when it will fire, or ``null``
        """
        sid = subaccount_id if subaccount_id is not None else self.subaccount_id
        request = self._signer.sign_schedule_cancel(sid, timeout_seconds, expires_after_ms=self.expires_after_ms)
        return self._trade(request)

    def get_delegations_for_delegate(self, subaccount_id: Optional[int] = None) -> Dict:
        """Get delegations from the perspective of the delegate.

        Returns ``{"delegatedAccounts": [...]}``.
        """
        return self._action("getDelegationsForDelegate", subaccount_id=subaccount_id)

    # ── Collateral & Withdrawals ────────────────────────────────────

    def get_withdrawable_amounts(
        self,
        symbols: List[str],
        subaccount_id: Optional[int] = None,
    ) -> Dict:
        """Get withdrawable amounts for one or more collateral symbols.

        Args:
            symbols: List of collateral symbols to query (e.g. ``["USDT"]``).
                At least one symbol is required.
            subaccount_id: Subaccount ID (defaults to active).

        Returns ``{"items": [...], "totalWithdrawableUsdt": str}``.
        Each item contains: symbol, withdrawableAmount, quantity,
        pendingWithdraw, withdrawFee.
        """
        return self._action("getWithdrawableAmounts", subaccount_id=subaccount_id, symbols=symbols)
