"""URL utilities."""

from urllib.parse import urlparse, urlunparse

_WS_TO_HTTP_SCHEME = {"wss": "https", "ws": "http"}


def ws_edge_http(ws_url: str) -> str:
    """Convert a WebSocket URL to the HTTP base that serves ``GET /status``.

    ``wss://`` becomes ``https://``, ``ws://`` becomes ``http://`` (other
    schemes are kept), and the trailing ``/ws`` path segment is stripped:
    ``wss://host/v1/ws`` → ``https://host/v1``.
    """
    parsed = urlparse(ws_url)
    scheme = _WS_TO_HTTP_SCHEME.get(parsed.scheme, parsed.scheme)
    path = parsed.path.rstrip("/")
    if path.endswith("/ws"):
        path = path[: -len("/ws")]
    return urlunparse(parsed._replace(scheme=scheme, path=path))
