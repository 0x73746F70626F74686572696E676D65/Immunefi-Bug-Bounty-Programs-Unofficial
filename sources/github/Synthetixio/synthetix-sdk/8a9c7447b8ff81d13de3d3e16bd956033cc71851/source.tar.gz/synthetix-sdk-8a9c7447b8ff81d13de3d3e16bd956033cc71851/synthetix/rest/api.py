"""
Base REST client for Synthetix V4 API.
"""

from typing import Any, Optional

import requests


class SynthetixAPIError(Exception):
    """Raised when the API returns a 200 with an error payload."""

    def __init__(self, message: str, response: Any = None):
        super().__init__(message)
        self.response = response


class ClientError(Exception):
    """Raised on 4xx HTTP responses.

    ``rate_limit`` (subaccount order bucket) and ``ip_rate_limit`` (per-IP
    bucket) carry the Synthetix exchange's rate-limit snapshots
    (``{"requestsCap": int, "remainingTokens": int}``) when the error body
    included them — most notably on 429 rejects. ``None`` otherwise.
    """

    def __init__(
        self,
        status_code: int,
        message: str,
        rate_limit: Optional[dict] = None,
        ip_rate_limit: Optional[dict] = None,
    ):
        super().__init__(f"HTTP {status_code}: {message}")
        self.status_code = status_code
        self.rate_limit = rate_limit
        self.ip_rate_limit = ip_rate_limit


class ServerError(Exception):
    """Raised on 5xx HTTP responses."""

    def __init__(self, status_code: int, message: str):
        super().__init__(f"HTTP {status_code}: {message}")
        self.status_code = status_code


class API:
    """Synchronous REST client using requests.Session."""

    def __init__(self, base_url: str, timeout: Optional[float] = None) -> None:
        self.base_url = base_url.rstrip("/")
        self.session = requests.Session()
        self.timeout = timeout
        # Most recent rate-limit snapshots scraped from response envelopes.
        # Each is {"requestsCap": int, "remainingTokens": int} or None if the
        # exchange has not yet sent one. The exchange omits a key when that
        # limiter did not run, so each value keeps its last known snapshot.
        self.last_rate_limit: Optional[dict] = None  # subaccount order bucket
        self.last_ip_rate_limit: Optional[dict] = None  # per-IP bucket

    def _capture_rate_limits(self, data: Any) -> None:
        """Scrape rateLimit / ipRateLimit envelope snapshots when present."""
        if not isinstance(data, dict):
            return
        rate_limit = data.get("rateLimit")
        if isinstance(rate_limit, dict):
            self.last_rate_limit = rate_limit
        ip_rate_limit = data.get("ipRateLimit")
        if isinstance(ip_rate_limit, dict):
            self.last_ip_rate_limit = ip_rate_limit

    def _handle_response(self, resp: requests.Response) -> Any:
        """Shared response handling: errors, JSON parsing, envelope unwrapping."""
        # HTTP-level errors
        if 400 <= resp.status_code < 500:
            try:
                body = resp.json()
            except Exception:
                body = None
            if not isinstance(body, dict):
                body = {}
            self._capture_rate_limits(body)
            rate_limit = body.get("rateLimit")
            ip_rate_limit = body.get("ipRateLimit")
            raise ClientError(
                resp.status_code,
                resp.text,
                rate_limit=rate_limit if isinstance(rate_limit, dict) else None,
                ip_rate_limit=ip_rate_limit if isinstance(ip_rate_limit, dict) else None,
            )
        if resp.status_code >= 500:
            # 503 timeout envelopes also carry rate-limit snapshots — scrape
            # them before raising, same as the 4xx path.
            try:
                body = resp.json()
            except Exception:
                body = None
            self._capture_rate_limits(body)
            raise ServerError(resp.status_code, resp.text)

        try:
            data = resp.json()
        except Exception:
            raise ServerError(resp.status_code, f"Non-JSON response: {resp.text[:200]}")

        self._capture_rate_limits(data)

        # Application-level errors (200 with error payload)
        if isinstance(data, dict):
            if data.get("status") == "error":
                msg = data.get("error", {}).get("message", "") or data.get("reason", str(data))
                raise SynthetixAPIError(msg, response=data)
            if "error" in data and "result" not in data:
                err = data["error"]
                msg = err.get("message", str(err)) if isinstance(err, dict) else str(err)
                raise SynthetixAPIError(msg, response=data)

        # Unwrap standard envelope: {"status": "ok", "response": <data>}
        if isinstance(data, dict) and "response" in data and data.get("status") == "ok":
            return data["response"]

        return data

    def get(self, path: str) -> Any:
        """GET base_url + path. Returns parsed response data."""
        url = f"{self.base_url}{path}"
        resp = self.session.get(url, timeout=self.timeout)
        return self._handle_response(resp)

    def post(self, path: str, payload: dict) -> Any:
        """POST JSON to base_url + path. Returns parsed response data."""
        url = f"{self.base_url}{path}"
        resp = self.session.post(url, json=payload, timeout=self.timeout)
        return self._handle_response(resp)
