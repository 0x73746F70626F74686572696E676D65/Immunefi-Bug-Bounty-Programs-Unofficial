declare module 'synthetix';
