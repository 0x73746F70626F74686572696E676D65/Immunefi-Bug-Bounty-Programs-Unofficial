export { default } from './Synthetix';
