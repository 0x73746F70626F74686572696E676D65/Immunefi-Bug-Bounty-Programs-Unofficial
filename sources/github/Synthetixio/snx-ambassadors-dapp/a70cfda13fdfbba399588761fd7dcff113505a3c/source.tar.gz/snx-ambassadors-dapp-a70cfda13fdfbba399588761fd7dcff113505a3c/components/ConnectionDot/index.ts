export { default } from './ConnectionDot';
