export { default } from './Ghost';
