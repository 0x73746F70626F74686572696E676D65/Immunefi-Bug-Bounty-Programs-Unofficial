export { default } from './MobileLanding';
