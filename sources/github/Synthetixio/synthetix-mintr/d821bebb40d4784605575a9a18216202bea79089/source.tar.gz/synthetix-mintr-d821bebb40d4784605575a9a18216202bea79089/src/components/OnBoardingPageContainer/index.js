export { default } from './OnBoardingPageContainer';
