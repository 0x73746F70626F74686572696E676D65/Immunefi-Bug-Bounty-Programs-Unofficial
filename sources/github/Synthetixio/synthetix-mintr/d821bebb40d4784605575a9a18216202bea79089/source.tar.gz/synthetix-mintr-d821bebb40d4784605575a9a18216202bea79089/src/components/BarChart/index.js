export { default } from './BarChart';
