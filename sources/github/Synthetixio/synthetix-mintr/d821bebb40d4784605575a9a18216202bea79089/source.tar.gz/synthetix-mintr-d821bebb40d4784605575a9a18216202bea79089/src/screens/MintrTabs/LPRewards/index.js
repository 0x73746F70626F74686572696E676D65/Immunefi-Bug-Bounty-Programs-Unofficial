export { default } from './LPRewards';
