module.exports = {
  networks: false
};
