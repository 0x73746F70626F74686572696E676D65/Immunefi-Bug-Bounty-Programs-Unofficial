import { CompilerOutputBytecode } from "./compiler-types";
import { Opcode } from "./opcodes";

export function getLibraryAddressPositions(
  bytecodeOutput: CompilerOutputBytecode
): number[] {
  const positions = [];
  for (const libs of Object.values(bytecodeOutput.linkReferences)) {
    for (const references of Object.values(libs)) {
      for (const ref of references) {
        positions.push(ref.start);
      }
    }
  }

  return positions;
}

export function normalizeCompilerOutputBytecode(
  compilerOutputBytecodeObject: string,
  addressesPositions: number[]
): Buffer {
  const ZERO_ADDRESS = "0000000000000000000000000000000000000000";
  for (const position of addressesPositions) {
    compilerOutputBytecodeObject = linkHexStringBytecode(
      compilerOutputBytecodeObject,
      ZERO_ADDRESS,
      position
    );
  }

  return Buffer.from(compilerOutputBytecodeObject, "hex");
}

export function linkHexStringBytecode(
  code: string,
  address: string,
  position: number
) {
  if (address.startsWith("0x")) {
    address = address.substring(2);
  }

  return (
    code.substring(0, position * 2) +
    address +
    code.slice(position * 2 + address.length)
  );
}

export function zeroOutAddresses(
  code: Buffer,
  addressesPositions: number[]
): Buffer {
  for (const position of addressesPositions) {
    code = Buffer.concat([
      code.slice(0, position),
      Buffer.alloc(20, 0),
      code.slice(position + 20)
    ]);
  }

  return code;
}

export function normalizeLibraryRuntimeBytecodeIfNecessary(
  code: Buffer
): Buffer {
  // Libraries' protection normalization:
  // Solidity 0.4.20 introduced a protection to prevent libraries from being called directly.
  // This is done by modifying the code on deployment, and hard-coding the contract address.
  // The first instruction is a PUSH20 of the address, which we zero-out as a way of normalizing
  // it. Note that it's also zeroed-out in the compiler output.
  if (code[0] === Opcode.PUSH20) {
    return zeroOutAddresses(code, [1]);
  }

  return code;
}
