declare module 'synthetix-js';
