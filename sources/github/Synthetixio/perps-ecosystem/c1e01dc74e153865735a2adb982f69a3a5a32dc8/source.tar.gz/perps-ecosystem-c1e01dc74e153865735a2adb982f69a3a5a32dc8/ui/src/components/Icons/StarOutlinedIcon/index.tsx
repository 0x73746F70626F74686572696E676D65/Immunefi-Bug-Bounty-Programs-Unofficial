export * from './StarOutlineIcon';
