export * from './PolynomialIcon';
