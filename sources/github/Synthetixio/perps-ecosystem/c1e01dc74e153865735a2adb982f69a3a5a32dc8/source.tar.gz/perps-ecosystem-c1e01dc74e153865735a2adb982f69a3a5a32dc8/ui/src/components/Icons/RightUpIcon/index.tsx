export * from './RightUpIcon';
