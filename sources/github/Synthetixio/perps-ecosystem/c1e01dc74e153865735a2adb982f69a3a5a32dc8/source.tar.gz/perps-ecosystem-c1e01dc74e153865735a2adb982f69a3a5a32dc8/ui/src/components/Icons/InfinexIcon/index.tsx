export * from './InfinexIcon';
