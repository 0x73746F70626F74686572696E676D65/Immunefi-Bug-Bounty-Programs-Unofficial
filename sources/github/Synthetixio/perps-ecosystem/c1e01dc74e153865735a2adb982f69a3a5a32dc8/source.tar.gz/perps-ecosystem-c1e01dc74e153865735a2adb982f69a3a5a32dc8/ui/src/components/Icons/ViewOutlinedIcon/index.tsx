export * from './ViewOutlinedIcon';
