declare module 'url-loader';
