export { default } from './MyLoans';
