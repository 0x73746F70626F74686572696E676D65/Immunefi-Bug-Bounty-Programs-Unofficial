export { default } from './CurrencyPair';
