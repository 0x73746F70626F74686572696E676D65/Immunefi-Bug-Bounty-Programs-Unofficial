export { default } from './Synths';
