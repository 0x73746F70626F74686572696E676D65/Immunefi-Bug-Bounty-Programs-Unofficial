export { default } from './WalletPopup';
