export { default } from './SideIcon';
