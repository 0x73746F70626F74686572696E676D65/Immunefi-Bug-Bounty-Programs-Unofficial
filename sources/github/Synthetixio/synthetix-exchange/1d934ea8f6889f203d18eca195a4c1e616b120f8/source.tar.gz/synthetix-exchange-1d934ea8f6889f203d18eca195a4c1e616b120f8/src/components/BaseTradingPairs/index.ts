export { default } from './BaseTradingPairs';
