export { default } from './SynthInfo';
