export { default } from './OptionResult';
