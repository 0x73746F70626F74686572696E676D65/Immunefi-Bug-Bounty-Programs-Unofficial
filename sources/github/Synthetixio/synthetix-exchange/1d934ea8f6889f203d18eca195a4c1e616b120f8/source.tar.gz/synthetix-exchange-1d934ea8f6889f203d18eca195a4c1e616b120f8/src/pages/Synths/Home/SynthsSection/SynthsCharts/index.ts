export { default } from './SynthsCharts';
