export { default } from './NewUserPromo';
