export { default } from './SynthsTable';
