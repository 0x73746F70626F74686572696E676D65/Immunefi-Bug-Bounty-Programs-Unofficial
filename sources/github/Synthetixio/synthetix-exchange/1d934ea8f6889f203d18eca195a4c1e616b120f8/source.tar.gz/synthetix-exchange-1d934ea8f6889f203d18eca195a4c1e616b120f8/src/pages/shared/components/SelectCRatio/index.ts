export { default } from './SelectCRatio';
