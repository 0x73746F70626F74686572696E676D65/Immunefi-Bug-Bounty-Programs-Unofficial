declare module 'synthetix-data';
