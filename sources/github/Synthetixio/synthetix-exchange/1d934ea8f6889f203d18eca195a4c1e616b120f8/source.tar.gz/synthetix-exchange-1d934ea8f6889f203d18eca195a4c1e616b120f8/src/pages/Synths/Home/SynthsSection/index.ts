export { default } from './SynthsSection';
