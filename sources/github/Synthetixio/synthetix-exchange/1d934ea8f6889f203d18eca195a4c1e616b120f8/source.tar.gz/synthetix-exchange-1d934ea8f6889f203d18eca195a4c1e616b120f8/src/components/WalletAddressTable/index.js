export { default } from './WalletAddressTable';
