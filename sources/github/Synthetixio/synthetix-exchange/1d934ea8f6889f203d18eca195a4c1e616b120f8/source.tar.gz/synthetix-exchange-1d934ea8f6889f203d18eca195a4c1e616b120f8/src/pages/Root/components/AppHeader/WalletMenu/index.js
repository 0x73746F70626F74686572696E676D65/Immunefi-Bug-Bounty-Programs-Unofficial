export { default } from './WalletMenu';
