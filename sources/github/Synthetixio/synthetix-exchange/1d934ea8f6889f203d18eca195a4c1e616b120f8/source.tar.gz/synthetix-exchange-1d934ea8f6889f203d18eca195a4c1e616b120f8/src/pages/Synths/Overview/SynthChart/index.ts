export { default } from './SynthChart';
