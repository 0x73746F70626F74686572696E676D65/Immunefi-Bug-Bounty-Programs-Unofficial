export { default } from './ResultCard';
