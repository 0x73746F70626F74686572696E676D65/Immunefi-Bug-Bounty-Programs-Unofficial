export { default } from './WalletPaginator';
