export { default } from './HotMarkets';
