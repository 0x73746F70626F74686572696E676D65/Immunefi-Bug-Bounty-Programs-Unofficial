import React from 'react';
import { connect } from 'react-redux';
import {
	setPeriod,
	fetchSnxCharts,
	fetchSusdCharts,
	fetchSynthsCharts,
} from '../../actions/charts';
import {
	fetchBinaryOptionsMarkets,
	fetchBinaryOptionsTransactions,
} from '../../actions/binaryOptions';
import { fetchSnx, fetchSnxPrice, fetchSethPrice, fetchSusdPrice } from '../../actions/markets';
import { fetchOpenInterest, fetchTradingVolume, fetchUniswapData } from '../../actions/exchange';
import { fetchNetworkData, fetchNetworkFees, fetchNetworkDepot } from '../../actions/network';
import AreaChart from '../../components/AreaChart';
import PieChart from '../../components/PieChart';
import HorizontalBarChart from '../../components/HorizontalBarChart';
import TopNavBar from '../../components/TopNavBar';
import SingleStatBox from '../../components/SingleStatBox';
import { switchTheme } from '../../actions/theme';
import { CHARTS, twoDigitNumber } from '../../utils';
import cx from 'classnames';
import numeral from 'numeral';
import { scroller } from 'react-scroll';

const SNX_CHART = {
	SnxPrice: 'SnxPrice',
	SnxVolume24h: 'SnxVolume24h',
};
const sUSD_CHART = {
	sUSDPrice: 'sUSDPrice',
	sUSDVolume24h: 'sUSDVolume24h',
};
const SYNTHS_CHART = {
	synthsFees: 'synthsFees',
	synthsVolume: 'synthsVolume',
};

const DECIMALS = {
	SnxPrice: { Val: 3, Eth: 7 },
	SnxVolume24h: { Val: 0, Eth: 0 },
	sUSDPrice: { Val: 3 },
	sUSDVolume24h: { Val: 2 },
	synthsFees: { Val: 2 },
	synthsVolume: { Val: 2 },
};

class App extends React.Component {
	constructor(props) {
		super(props);
	}

	state = {
		snxButton: 'usd',
		snxChartName: SNX_CHART.SnxPrice,
		sUSDChartName: sUSD_CHART.sUSDPrice,
		synthsChartName: SYNTHS_CHART.synthsVolume,
	};

	componentDidMount() {
		const { snxjs, charts } = this.props;

		this.fetchData();

		if (!charts.chartsStartedLoading) {
			this.fetchCharts(CHARTS.DAY);
			this.fetchCharts(CHARTS.MONTH);
		}

		this.setState({
			checkEmptyIntervalId: setInterval(() => this.checkEmptyResults(), 2000),
			intervalId: setInterval(() => fetchCharts(CHARTS.MONTH), 10 * 60 * 1000),
			sethProxyAddress: snxjs.sETH.contract.address,
			checkEmptyCount: 1,
		});
	}

	checkEmptyResults = () => {
		const { markets } = this.props;
		const { checkEmptyIntervalId, checkEmptyCount } = this.state;
		if (
			checkEmptyCount < 5 &&
			((markets?.snx?.snxPrice ?? 0) === 0 || (markets?.snx?.snxTotalSupply ?? 0) === 0)
		) {
			this.fetchData();
			this.setState({ checkEmptyCount: checkEmptyCount + 1 });
		} else {
			if (checkEmptyIntervalId) {
				clearInterval(checkEmptyIntervalId);
			}
		}
	};

	fetchData = () => {
		const {
			snxjs,
			fetchSnxPrice,
			fetchSethPrice,
			fetchSusdPrice,
			fetchSnx,
			fetchOpenInterest,
			fetchTradingVolume,
			fetchUniswapData,
			fetchNetworkData,
			fetchNetworkFees,
			fetchNetworkDepot,
			fetchBinaryOptionsTransactions,
			fetchBinaryOptionsMarkets,
		} = this.props;

		fetchSnxPrice(snxjs);
		fetchSethPrice(snxjs);
		fetchSusdPrice(snxjs);
		fetchSnx();
		fetchOpenInterest(snxjs);
		fetchTradingVolume();
		fetchBinaryOptionsTransactions();
		fetchBinaryOptionsMarkets();

		fetchUniswapData(snxjs);
		fetchNetworkData(snxjs);
		fetchNetworkFees(snxjs);
		fetchNetworkDepot(snxjs);
	};

	fetchCharts = timePeriod => {
		const { fetchSynthsCharts, fetchSusdCharts, fetchSnxCharts } = this.props;

		fetchSynthsCharts(timePeriod);
		fetchSusdCharts(timePeriod);
		fetchSnxCharts(timePeriod);
	};

	setSnxChart = chartName => {
		this.setState({ snxChartName: chartName });
	};

	setsUSDChart = chartName => {
		this.setState({ sUSDChartName: chartName });
	};

	setSynthsChart = chartName => {
		this.setState({ synthsChartName: chartName });
	};

	componentWillUnmount() {
		if (checkEmptyIntervalId) {
			clearInterval(checkEmptyIntervalId);
		}
		if (this.state.intervalId) {
			clearInterval(this.state.intervalId);
		}
	}

	getMarketsData() {
		const { markets } = this.props;
		const data = { snxMarketData: {} };
		['snx'].forEach(currency => {
			if (markets[currency] && markets[currency].quote && markets[currency].quote.USD) {
				data[`${currency}MarketData`] = {
					...markets[currency].quote.USD,
					total_supply: markets[currency].total_supply,
				};
			}
		});
		return data;
	}

	render() {
		const { charts, theme, exchange, network, setPeriod, binaryOptions, markets } = this.props;
		const { snxPeriod, sUSDPeriod, synthsPeriod } = charts;
		const {
			snxButton,
			snxChartName,
			sUSDChartName,
			synthsChartName,
			sethProxyAddress,
		} = this.state;
		const { SnxVolume24h, SnxPrice } = SNX_CHART;
		const { sUSDVolume24h, sUSDPrice } = sUSD_CHART;
		const { synthsVolume, synthsFees } = SYNTHS_CHART;

		const { snxMarketData } = this.getMarketsData();
		const scrollToOptions = {
			duration: 500,
			delay: 100,
			smooth: 'easeInOutQuint',
			offset: -110,
		};

		const formattedDistribution = [];
		let totalDistribution = 0;
		let sUSDTotalSupply = 0;

		if (exchange.openInterest) {
			totalDistribution = exchange.openInterest.reduce((acc, val) => acc + val.value, 0);
			let cumulativeDistributionValue = 0;
			let otherDistributionValue = 0;
			let hasReached = false;
			exchange.openInterest
				.sort((a, b) => b.value - a.value)
				.forEach(synth => {
					if (synth.name === 'sUSD') {
						sUSDTotalSupply = synth.totalSupply;
					}
					if (!hasReached && cumulativeDistributionValue / totalDistribution < 0.9) {
						formattedDistribution.push(synth);
						cumulativeDistributionValue += synth.value;
					} else {
						hasReached = true;
						otherDistributionValue += synth.value;
					}
				});
			formattedDistribution.push({
				name: 'Others',
				value: otherDistributionValue,
			});
		}

		const snxMarketCap =
			markets.snx.snxPrice && markets.snx.snxTotalSupply
				? markets.snx.snxPrice * markets.snx.snxTotalSupply
				: null;
		const sETHPrice = markets.seth.sethPrice ? markets.seth.sethPrice : null;
		const sETHMarketCap =
			exchange.openInterest && exchange.openInterest.find(s => s.name === 'sETH');

		const sETHPool = exchange.uniswap;
		const sETHtoETHRate = sETHPool ? parseFloat(sETHPool.eth) / parseFloat(sETHPool.synth) : null;
		return (
			<div className="dashboard-root">
				<TopNavBar selectedSection="stats" />
				<div className="container main-content">
					<div className="columns is-multiline" id="stats">
						<SingleStatBox
							value={snxMarketCap}
							label="SNX MARKET CAP"
							desc="The total value of all SNX."
							decimals={0}
							isClickable={true}
						/>
						<SingleStatBox
							value={markets.snx.snxPrice ? markets.snx.snxPrice : null}
							trend={snxMarketData ? snxMarketData.percent_change_24h : null}
							label="SNX PRICE"
							desc="The current price of SNX."
							decimals={3}
							onClick={() => {
								this.setSnxChart(SnxPrice);
								scroller.scrollTo('snx-main-chart', scrollToOptions);
							}}
							isClickable={true}
						/>
						<div className="column is-half-tablet is-one-quarter-desktop markets-link">
							<SingleStatBox
								value={network.percentLocked ? twoDigitNumber(network.percentLocked) : null}
								type="percentage"
								label="LOCKED SNX RATIO"
								desc="The percentage of SNX tokens that are staked."
								onClick={() => {}}
								decimals={2}
							/>
						</div>
						<div className="column is-half-tablet is-one-quarter-desktop markets-link">
							<SingleStatBox
								value={
									network.percentLocked && snxMarketData && snxMarketCap
										? twoDigitNumber((network.percentLocked / 100) * snxMarketCap)
										: null
								}
								label="LOCKED SNX VALUE"
								desc="The total value of all staked SNX."
								onClick={() => {}}
								decimals={0}
							/>
						</div>

						<SingleStatBox
							value={
								sUSDTotalSupply > 0 && markets.susd.susdPrice
									? markets.susd.susdPrice * sUSDTotalSupply
									: null
							}
							label="sUSD MARKET CAP"
							desc="The total value of all circulating sUSD."
							decimals={0}
							isClickable={true}
						/>
						<SingleStatBox
							value={markets.susd.susdPrice ? markets.susd.susdPrice : null}
							label="sUSD PRICE"
							desc="The exchange rate for USDC on Curve.fi"
							decimals={3}
							onClick={() => {
								this.setsUSDChart(sUSDPrice);
								scroller.scrollTo('susd-main-chart', scrollToOptions);
							}}
							isClickable={true}
						/>
						<div className="column is-half-tablet is-one-quarter-desktop markets-link">
							<SingleStatBox
								value={sETHMarketCap ? sETHMarketCap.value : null}
								label="sETH MARKET CAP"
								desc="The total value of all circulating sETH."
								onClick={() => {}}
								decimals={0}
							/>
						</div>
						<div className="column is-half-tablet is-one-quarter-desktop markets-link">
							<SingleStatBox
								value={sETHPrice ? sETHPrice : null}
								label="sETH PRICE"
								desc="The price of sETH on Uniswap V2."
								onClick={() => {}}
								decimals={3}
							/>
						</div>
						<div className="column is-half-tablet is-one-quarter-desktop markets-link">
							<SingleStatBox
								value={sETHtoETHRate ? sETHtoETHRate : null}
								label="sETH UNISWAP RATE"
								desc={
									'Pool size: ' +
									(sETHPool
										? `${parseFloat(sETHPool.synth).toFixed(2)} sETH / ${parseFloat(
												sETHPool.eth
										  ).toFixed(2)} ETH`
										: '')
								}
								type="number"
								onClick={() => {
									window.open(`https://uniswap.exchange/swap/${sethProxyAddress}`, '__blank');
								}}
								decimals={3}
							/>
						</div>
						<div className="column is-half-tablet is-one-quarter-desktop markets-link">
							<SingleStatBox
								value={totalDistribution ? totalDistribution : null}
								label="TOTAL SYNTH SUPPLY"
								desc="The total value of all circulating synths."
								onClick={() => {}}
								decimals={0}
							/>
						</div>
						<div className="column is-half-tablet is-one-quarter-desktop markets-link">
							<SingleStatBox
								value={
									network.totalIssuedSynths && snxMarketCap
										? twoDigitNumber(Number((snxMarketCap / network.totalIssuedSynths) * 100))
										: null
								}
								type="percentage"
								label="NETWORK COLLATERALIZATION RATIO"
								desc="The aggregate collateralisation ratio of all SNX wallets."
								onClick={() => {}}
								decimals={2}
							/>
						</div>
						<div className="column is-half-tablet is-one-quarter-desktop markets-link">
							<SingleStatBox
								value={
									network.activeCollateralizationRatio
										? twoDigitNumber(network.activeCollateralizationRatio)
										: null
								}
								type="percentage"
								label="ACTIVE COLLATERALIZATION RATIO"
								desc="The aggregate collateralisation ratio of SNX wallets that are currently staking."
								onClick={() => {}}
								decimals={2}
							/>
						</div>
						<div className="column is-half-tablet is-one-quarter-desktop markets-link">
							<SingleStatBox
								value={
									exchange.volume && exchange.volume.last24Hours > 0
										? exchange.volume.last24Hours
										: null
								}
								label="SYNTHETIX.EXCHANGE VOLUME"
								desc="Synthetix.Exchange 24h trading volume."
								onClick={() => {
									this.setSynthsChart(synthsVolume);
									scroller.scrollTo('synths-main-chart', scrollToOptions);
								}}
								decimals={0}
							/>
						</div>
						<div className="column is-half-tablet is-one-quarter-desktop markets-link">
							<SingleStatBox
								value={
									network.totalFeesAvailable && network.totalFeesAvailable > 0
										? network.totalFeesAvailable
										: null
								}
								label="CURRENT FEE POOL"
								desc="Total trading fees in the pool."
								onClick={() => {}}
								decimals={0}
							/>
						</div>
						<div className="column is-half-tablet is-one-quarter-desktop markets-link">
							<SingleStatBox
								value={
									network.unclaimedFees && network.unclaimedFees > 0 ? network.unclaimedFees : null
								}
								label="UNCLAIMED FEES IN POOL"
								desc="Trading fees currently claimable in the pool."
								onClick={() => {}}
								decimals={0}
							/>
						</div>
						<div className="column is-half-tablet is-one-quarter-desktop markets-link">
							<SingleStatBox
								value={exchange.totalFeesGenerated > 0 ? exchange.totalFeesGenerated : null}
								label="TOTAL FEES GENERATED"
								desc="Fees generated since launch (Dec 2018)."
								onClick={() => {
									this.setSynthsChart(synthsFees);
									scroller.scrollTo('synths-main-chart', scrollToOptions);
								}}
								decimals={0}
							/>
						</div>
						<div className="column is-half-tablet is-one-quarter-desktop markets-link">
							<SingleStatBox
								value={exchange.volume && exchange.volume.total > 0 ? exchange.volume.total : null}
								label="SYNTHETIX.EXCHANGE TOTAL VOL."
								desc="Synthetix.Exchange all time volume."
								onClick={() => {
									this.setSynthsChart(synthsVolume);
									scroller.scrollTo('synths-main-chart', scrollToOptions);
								}}
								decimals={0}
							/>
						</div>

						<div className="column is-half-tablet is-one-quarter-desktop markets-link">
							<SingleStatBox
								value={
									network.totalRewardsAvailable &&
									network.totalRewardsAvailable > 0 &&
									markets.snx.snxPrice
										? network.totalRewardsAvailable * markets.snx.snxPrice
										: null
								}
								label="CURRENT REWARDS POOL"
								desc="Total SNX rewards claimable this period."
								onClick={() => {}}
								decimals={0}
							/>
						</div>
						<div className="column is-half-tablet is-one-quarter-desktop markets-link">
							<SingleStatBox
								value={
									network.unclaimedRewards && network.unclaimedRewards > 0 && markets.snx.snxPrice
										? network.unclaimedRewards * markets.snx.snxPrice
										: null
								}
								label="UNCLAIMED REWARDS IN POOL"
								desc="SNX rewards currently claimable in the pool."
								onClick={() => {}}
								decimals={0}
							/>
						</div>
						<div className="column is-half-tablet is-one-quarter-desktop markets-link">
							<SingleStatBox
								value={
									snxMarketData.volume_24h && snxMarketData.volume_24h > 0
										? snxMarketData.volume_24h
										: null
								}
								label="24HR SNX Trading Volume"
								desc="24HR SNX Trading Volume from Coinmarketcap API."
								onClick={() => {}}
								decimals={0}
							/>
						</div>
						<div className="column is-half-tablet is-one-quarter-desktop markets-link">
							<SingleStatBox
								value={binaryOptions.numMarkets}
								label="Active Binary Options Markets"
								desc="Number of Binary Options Markets currently active."
								onClick={() => {}}
								type="number"
								decimals={0}
							/>
						</div>
						<div className="column is-half-tablet is-one-quarter-desktop markets-link">
							<SingleStatBox
								value={binaryOptions.largestMarketPoolSize}
								label="Largest Active Binary Options Market"
								desc={`${binaryOptions.largestMarket} has the Largest Active Pool Size`}
								onClick={() => {}}
								decimals={0}
							/>
						</div>
						<div className="column is-half-tablet is-one-quarter-desktop markets-link">
							<SingleStatBox
								value={binaryOptions.totalPoolSizes}
								label="Binary Options Markets Total Pools"
								desc="Sum of Pool Sizes for all Active Binary Options Markets."
								onClick={() => {}}
								decimals={0}
							/>
						</div>
						<div className="column is-half-tablet is-one-quarter-desktop markets-link">
							<SingleStatBox
								value={binaryOptions.numOptionsTransactions}
								label="24HR Binary Options Transactions"
								desc="Total Binary Options Transactions from the Past day."
								onClick={() => {}}
								type="number"
								decimals={0}
							/>
						</div>
					</div>
				</div>
				<div className="container chart-section" id="snx">
					<div>
						<div className="level is-mobile chart-section__heading">
							<div className="level-left">
								<div className="level-item title">
									<h2>SNX</h2>
									<span>(UNISWAP V1)</span>
								</div>
							</div>
							<div className="level-right">
								<div className="level-item">
									<button
										className={cx('button', 'is-link', {
											'is-active': snxChartName === SnxPrice,
										})}
										onClick={() => {
											this.setSnxChart(SnxPrice);
										}}
									>
										Price
									</button>
								</div>
								<div className="level-item">
									<button
										className={cx('button', 'is-link', {
											'is-active': snxChartName === SnxVolume24h,
										})}
										onClick={() => {
											this.setSnxChart(SnxVolume24h);
										}}
									>
										Volume
									</button>
								</div>
							</div>
						</div>
						<div className="columns">
							<div className="column">
								<div className="chart-box chart-box--main" id="snx-main-chart">
									<div className="chart-box__stat is-positive" />
									<div className="time-toggles is-hidden-mobile">
										<button
											onClick={() => setPeriod(CHARTS.DAY, 'SNX')}
											className={cx({
												'is-active': snxPeriod === CHARTS.DAY,
											})}
										>
											1D
										</button>
										{charts.snxPeriodLoaded === CHARTS.MONTH ? (
											<>
												<button
													onClick={() => setPeriod(CHARTS.WEEK, 'SNX')}
													className={cx({
														'is-active': snxPeriod === CHARTS.WEEK,
													})}
												>
													1W
												</button>
												<button
													onClick={() => setPeriod(CHARTS.MONTH, 'SNX')}
													className={cx({
														'is-active': snxPeriod === CHARTS.MONTH,
													})}
												>
													1M
												</button>
											</>
										) : null}
									</div>
									<div>
										<AreaChart
											isLightMode={theme === 'light'}
											period={snxPeriod}
											info={charts[snxChartName]}
											activeButton={snxButton}
										/>
									</div>
								</div>
							</div>
						</div>
						<div className="time-toggles is-hidden-tablet">
							<button
								onClick={() => setPeriod(CHARTS.DAY, 'SNX')}
								className={cx({
									'is-active': snxPeriod === CHARTS.DAY,
								})}
							>
								1D
							</button>
							{charts.snxPeriodLoaded === CHARTS.MONTH ? (
								<>
									<button
										onClick={() => setPeriod(CHARTS.WEEK, 'SNX')}
										className={cx({
											'is-active': snxPeriod === CHARTS.WEEK,
										})}
									>
										1W
									</button>
									<button
										onClick={() => setPeriod(CHARTS.MONTH, 'SNX')}
										className={cx({
											'is-active': snxPeriod === CHARTS.MONTH,
										})}
									>
										1M
									</button>
								</>
							) : null}
						</div>
						<div className="level is-mobile justified-content-center">
							<div className="level-left" />
							<div className="level-right currency-toggles">
								<div className="level-item">
									<button
										className={cx('button is-link usd', {
											'is-active': snxButton === 'usd',
										})}
										onClick={() => this.setState({ snxButton: 'usd' })}
									>
										USD
									</button>
								</div>
								<div className="level-item">
									<button
										className={cx('button is-link eth', {
											'is-active': snxButton === 'eth',
										})}
										onClick={() => this.setState({ snxButton: 'eth' })}
									>
										ETH
									</button>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div className="container chart-section" id="susd">
					<div>
						<div className="level is-mobile chart-section__heading">
							<div className="level-left">
								<div className="level-item title">
									<h2>sUSD</h2>
									<span className>(UNISWAP V1)</span>
								</div>
							</div>
							<div className="level-right">
								<div className="level-item">
									<button
										className={cx('button', 'is-link', {
											'is-active': sUSDChartName === sUSDPrice,
										})}
										onClick={() => {
											this.setsUSDChart(sUSDPrice);
										}}
									>
										Price
									</button>
								</div>
								<div className="level-item">
									<button
										className={cx('button', 'is-link', {
											'is-active': sUSDChartName === sUSDVolume24h,
										})}
										onClick={() => {
											this.setsUSDChart(sUSDVolume24h);
										}}
									>
										Volume
									</button>
								</div>
							</div>
						</div>

						<div className="columns">
							<div className="column">
								<div className="chart-box chart-box--main" id="susd-main-chart">
									<div className="chart-box__stat is-positive" />
									<div className="time-toggles is-hidden-mobile">
										<button
											onClick={() => setPeriod(CHARTS.DAY, 'sUSD')}
											className={cx({
												'is-active': sUSDPeriod === CHARTS.DAY,
											})}
										>
											1D
										</button>
										{charts.sUSDPeriodLoaded === CHARTS.MONTH ? (
											<>
												<button
													onClick={() => setPeriod(CHARTS.WEEK, 'sUSD')}
													className={cx({
														'is-active': sUSDPeriod === CHARTS.WEEK,
													})}
												>
													1W
												</button>
												<button
													onClick={() => setPeriod(CHARTS.MONTH, 'sUSD')}
													className={cx({
														'is-active': sUSDPeriod === CHARTS.MONTH,
													})}
												>
													1M
												</button>
											</>
										) : null}
									</div>
									<div>
										<AreaChart
											isLightMode={theme === 'light'}
											period={sUSDPeriod}
											info={charts[sUSDChartName]}
										/>
									</div>
								</div>
							</div>
						</div>
						<div className="time-toggles is-hidden-tablet">
							<button
								onClick={() => setPeriod(CHARTS.DAY, 'sUSD')}
								className={cx({
									'is-active': sUSDPeriod === CHARTS.DAY,
								})}
							>
								1D
							</button>
							{charts.sUSDPeriodLoaded === CHARTS.MONTH ? (
								<>
									<button
										onClick={() => setPeriod(CHARTS.WEEK, 'sUSD')}
										className={cx({
											'is-active': sUSDPeriod === CHARTS.WEEK,
										})}
									>
										1W
									</button>
									<button
										onClick={() => setPeriod(CHARTS.MONTH, 'sUSD')}
										className={cx({
											'is-active': sUSDPeriod === CHARTS.MONTH,
										})}
									>
										1M
									</button>
								</>
							) : null}
						</div>
					</div>
				</div>
				<div className="container chart-section" id="synths">
					<div>
						<div className="level is-mobile chart-section__heading">
							<div className="level-left">
								<div className="level-item title">
									<h2>Synths</h2>
									<span>(SYNTHETIX)</span>
								</div>
							</div>
							<div className="level-right">
								<div className="level-item">
									<button
										className={cx('button', 'is-link', {
											'is-active': synthsChartName === synthsVolume,
										})}
										onClick={() => {
											this.setSynthsChart(synthsVolume);
										}}
									>
										Volume
									</button>
								</div>
								<div className="level-item">
									<button
										className={cx('button', 'is-link', {
											'is-active': synthsChartName === synthsFees,
										})}
										onClick={() => {
											this.setSynthsChart(synthsFees);
										}}
									>
										Fees
									</button>
								</div>
							</div>
						</div>
						<div className="columns">
							<div className="column">
								<div className="chart-box chart-box--main" id="synths-main-chart">
									<div className="chart-box__stat is-positive" />
									<div className="time-toggles is-hidden-mobile">
										<button
											onClick={() => setPeriod(CHARTS.DAY, 'synths')}
											className={cx({
												'is-active': synthsPeriod === CHARTS.DAY,
											})}
										>
											1D
										</button>
										{charts.synthsPeriodLoaded === CHARTS.MONTH ? (
											<>
												<button
													onClick={() => setPeriod(CHARTS.WEEK, 'synths')}
													className={cx({
														'is-active': synthsPeriod === CHARTS.WEEK,
													})}
												>
													1W
												</button>
												<button
													onClick={() => setPeriod(CHARTS.MONTH, 'synths')}
													className={cx({
														'is-active': synthsPeriod === CHARTS.MONTH,
													})}
												>
													1M
												</button>
											</>
										) : null}
									</div>
									<div>
										<AreaChart
											isLightMode={theme === 'light'}
											period={synthsPeriod}
											info={charts[synthsChartName]}
										/>
									</div>
								</div>
							</div>
						</div>
						<div className="time-toggles is-hidden-tablet">
							<button
								onClick={() => setPeriod(CHARTS.DAY, 'synths')}
								className={cx({
									'is-active': synthsPeriod === CHARTS.DAY,
								})}
							>
								1D
							</button>
							{charts.synthsPeriodLoaded === CHARTS.MONTH ? (
								<>
									<button
										onClick={() => setPeriod(CHARTS.WEEK, 'synths')}
										className={cx({
											'is-active': synthsPeriod === CHARTS.WEEK,
										})}
									>
										1W
									</button>
									<button
										onClick={() => setPeriod(CHARTS.MONTH, 'synths')}
										className={cx({
											'is-active': synthsPeriod === CHARTS.MONTH,
										})}
									>
										1M
									</button>
								</>
							) : null}
						</div>
						<div className="columns">
							<div className="column">
								<div style={{ height: '100%' }} className="chart-box">
									<div className="chart-box__info">
										<div className="chart-box-title">
											<h3>OPEN INTEREST</h3>
											<span className="chart-box__number" />
										</div>
										<div className="chart-box-desc">Long/short interest on cryptoassets</div>
									</div>

									{exchange.shortsAndLongs ? (
										<HorizontalBarChart
											isLightMode={theme === 'light'}
											data={exchange.shortsAndLongs.map(synth => ({
												x: synth.longs || 0,
												y: synth.shorts || 0,
												z: (synth.longs || 0) + (synth.shorts || 0),
												label: synth.name,
												totalSupplyLong: synth.totalSupplyLong || 0,
												totalSupplyShort: synth.totalSupplyShort || 0,
											}))}
										/>
									) : null}
								</div>
							</div>
							<div className="column">
								<div className="chart-box">
									<div className="chart-box__info">
										<div className="chart-box-title">
											<h3>SYNTHS DISTRIBUTION</h3>
											<span className="chart-box__number" />
										</div>
										<div className="chart-box-desc">Distribution of synths within the network</div>
									</div>
									{formattedDistribution && totalDistribution ? (
										<PieChart
											isLightMode={theme === 'light'}
											data={formattedDistribution.map(v => {
												return {
													x: v.name,
													y: v.value,
													label: `${((100 * v.value) / totalDistribution).toFixed(1)}%`,
												};
											})}
										/>
									) : null}
									<div
										style={{
											width: '100%',
											textAlign: 'center',
											marginBottom: '20px',
										}}
									>
										Total Synth supply: {numeral(totalDistribution).format('$0,(0)')}
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div className="container main-content">
					<div className="columns">
						<div className="column">
							<div className="footer-info">
								<div
									className={cx('theme-switcher', theme)}
									onClick={() => this.props.switchTheme(theme === 'dark' ? 'light' : 'dark')}
								>
									<label>{theme}</label>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		);
	}
}

const mapStateToProps = state => {
	const { charts, theme, markets, exchange, network, binaryOptions } = state;
	return {
		charts,
		theme: theme.theme,
		markets,
		exchange,
		network,
		binaryOptions,
	};
};

const ConnectedApp = connect(
	mapStateToProps,
	{
		switchTheme,
		fetchSynthsCharts,
		fetchSusdCharts,
		fetchSnxCharts,
		fetchOpenInterest,
		fetchTradingVolume,
		fetchUniswapData,
		fetchSnx,
		setPeriod,
		fetchNetworkData,
		fetchNetworkFees,
		fetchNetworkDepot,
		fetchBinaryOptionsMarkets,
		fetchBinaryOptionsTransactions,
		fetchSnxPrice,
		fetchSethPrice,
		fetchSusdPrice,
	}
)(App);
export default ConnectedApp;
