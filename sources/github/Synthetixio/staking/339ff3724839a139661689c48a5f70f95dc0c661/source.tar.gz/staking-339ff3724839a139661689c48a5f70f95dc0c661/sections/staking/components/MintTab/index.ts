export { default } from './MintTab';
