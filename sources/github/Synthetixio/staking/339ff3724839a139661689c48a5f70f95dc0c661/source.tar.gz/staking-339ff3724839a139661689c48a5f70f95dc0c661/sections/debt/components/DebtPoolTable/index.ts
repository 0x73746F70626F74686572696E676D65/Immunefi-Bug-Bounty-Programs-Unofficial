export { default } from './DebtPoolTable';
