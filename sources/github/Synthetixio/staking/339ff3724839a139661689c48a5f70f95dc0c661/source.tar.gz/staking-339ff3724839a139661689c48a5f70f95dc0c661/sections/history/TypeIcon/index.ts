export { default } from './TypeIcon';
