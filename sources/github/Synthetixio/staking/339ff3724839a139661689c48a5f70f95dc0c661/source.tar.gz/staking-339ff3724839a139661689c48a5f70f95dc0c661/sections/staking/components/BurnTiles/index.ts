export { default } from './BurnTiles';
