export { default } from './ExternalLink';
