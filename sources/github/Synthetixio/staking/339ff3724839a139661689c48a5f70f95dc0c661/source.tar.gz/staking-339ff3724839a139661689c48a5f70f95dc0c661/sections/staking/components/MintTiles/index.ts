export { default } from './MintTiles';
