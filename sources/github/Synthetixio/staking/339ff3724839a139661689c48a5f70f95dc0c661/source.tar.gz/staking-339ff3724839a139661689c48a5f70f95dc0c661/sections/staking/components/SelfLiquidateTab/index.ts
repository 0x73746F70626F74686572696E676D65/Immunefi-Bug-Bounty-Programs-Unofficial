export { default } from './SelfLiquidateTab';
