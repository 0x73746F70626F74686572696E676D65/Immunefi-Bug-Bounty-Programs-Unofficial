export { default } from './StakingInput';
