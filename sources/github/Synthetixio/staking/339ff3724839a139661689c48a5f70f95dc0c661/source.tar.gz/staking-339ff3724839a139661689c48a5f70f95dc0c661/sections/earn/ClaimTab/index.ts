export { default } from './ClaimTab';
