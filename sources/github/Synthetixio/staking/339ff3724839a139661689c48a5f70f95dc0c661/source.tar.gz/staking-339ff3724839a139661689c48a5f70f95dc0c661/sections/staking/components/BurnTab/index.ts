export { default } from './BurnTab';
