export { default } from './StakingRewardsTab';
