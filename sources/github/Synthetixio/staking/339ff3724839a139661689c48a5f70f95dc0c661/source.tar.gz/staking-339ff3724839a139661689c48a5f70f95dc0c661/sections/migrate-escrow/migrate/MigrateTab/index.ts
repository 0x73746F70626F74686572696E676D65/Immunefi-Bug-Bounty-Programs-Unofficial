export { default } from './MigrateTab';
