export { default } from './SynthHolding';
