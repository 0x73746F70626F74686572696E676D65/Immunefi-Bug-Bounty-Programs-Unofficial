export { default } from './ClaimedTag';
