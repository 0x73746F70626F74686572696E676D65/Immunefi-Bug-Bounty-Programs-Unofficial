export { default } from './KwentaBanner';
