export { default } from './StructuredTab';
