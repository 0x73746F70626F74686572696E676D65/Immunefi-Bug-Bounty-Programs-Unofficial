package config

type ChainListEntry struct {
	Name                 string               `json:"name" toml:"name"`
	Identifier           string               `json:"identifier" toml:"identifier"`
	ChainID              uint64               `json:"chainId" toml:"chain_id"`
	RPC                  []string             `json:"rpc" toml:"rpc"`
	Explorers            []string             `json:"explorers" toml:"explorers"`
	GovernedByOptimism   bool                 `json:"governedByOptimism" toml:"governed_by_optimism"`
	DataAvailabilityType string               `json:"dataAvailabilityType" toml:"data_availability_type"`
	Parent               ChainListEntryParent `json:"parent" toml:"parent"`
	GasPayingToken       *ChecksummedAddress  `json:"gasPayingToken,omitempty" toml:"gas_paying_token,omitempty"`
	FaultProofs          FaultProofs          `json:"faultProofs,omitempty" toml:"fault_proofs,omitempty"`
}

type FaultProofs struct {
	Status string `json:"status" toml:"status"`
}

type ChainListEntryParent struct {
	Type  string     `json:"type" toml:"type"`
	Chain Superchain `json:"chain" toml:"chain"`
}

type ChainListTOML struct {
	Chains []ChainListEntry `toml:"chains"`
}
