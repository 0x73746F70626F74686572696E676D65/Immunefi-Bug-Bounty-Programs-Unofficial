// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {IHooks} from "@uniswap/v4-core/src/interfaces/IHooks.sol";
import {Currency, CurrencyLibrary} from "@uniswap/v4-core/src/types/Currency.sol";
import {PoolKey} from "@uniswap/v4-core/src/types/PoolKey.sol";
import {IERC20} from "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import {ModifyLiquidityParams} from "@uniswap/v4-core/src/types/PoolOperation.sol";
import {IAllowanceTransfer} from "permit2/src/interfaces/IAllowanceTransfer.sol";
import {DeployPermit2} from "permit2/test/utils/DeployPermit2.sol";
import {WETH} from "solmate/src/tokens/WETH.sol";
import {MockERC20} from "solmate/src/test/utils/mocks/MockERC20.sol";

import {Deploy} from "test/shared/Deploy.sol";
import {MockPermissionedRouter} from "../../../mocks/MockPermissionedRouter.sol";
import {Plan, Planner} from "../../../shared/Planner.sol";
import {PathKey} from "../../../../src/libraries/PathKey.sol";
import {Actions} from "../../../../src/libraries/Actions.sol";
import {PermissionsAdapter} from "../../../../src/hooks/permissionedPools/PermissionsAdapter.sol";
import {MockAllowlistChecker, MockPermissionedToken} from "../PermissionedPoolsBase.sol";
import {IAllowlistChecker} from "../../../../src/hooks/permissionedPools/interfaces/IAllowlistChecker.sol";
import {IPositionManager} from "../../../../src/interfaces/IPositionManager.sol";
import {
    IPermissionsAdapterFactory
} from "../../../../src/hooks/permissionedPools/interfaces/IPermissionsAdapterFactory.sol";
import {IWETH9} from "../../../../src/interfaces/external/IWETH9.sol";
import {IPositionDescriptor} from "../../../../src/interfaces/IPositionDescriptor.sol";
import {IV4Router} from "../../../../src/interfaces/IV4Router.sol";
import {ActionConstants} from "../../../../src/libraries/ActionConstants.sol";
import {PermissionedDeployers} from "./PermissionedDeployers.sol";
import {PermissionFlags} from "../../../../src/hooks/permissionedPools/libraries/PermissionFlags.sol";

/// @notice A shared test contract that wraps the v4-core deployers contract and exposes basic helpers for swapping with the permissioned router.
contract PermissionedRoutingTestHelpers is PermissionedDeployers, DeployPermit2 {
    uint256 public constant MAX_SETTLE_AMOUNT = type(uint256).max;
    uint256 public constant MIN_TAKE_AMOUNT = 0;

    // Permissioned components
    MockPermissionedRouter public permissionedRouter;
    IAllowanceTransfer public permit2;
    MockAllowlistChecker public mockAllowlistChecker;
    IAllowlistChecker public allowListChecker;
    IPositionDescriptor public tokenDescriptor;
    IWETH9 public weth9;

    // nativeKey is already defined in Deployers.sol
    PoolKey public key0;
    PoolKey public key1;
    PoolKey public key2;
    PoolKey public key3;
    PoolKey public insecureKey;

    // currency0 and currency1 are defined in Deployers.sol
    Currency public currency2;
    Currency public currency3;
    Currency public currency4;

    PermissionsAdapter public permissionsAdapter0;
    PermissionsAdapter public permissionsAdapter1;

    Currency[] public tokenPath;
    Plan public plan;

    address public positionManager;
    /// @dev Plain (non-permissioned) PositionManager used to mint liquidity into ordinary
    ///      ERC-20/ERC-20 pools (e.g. `key2`) for routing tests. The PermissionedPositionManager
    ///      now rejects mints where neither side is a verified permissions adapter.
    address public ordinaryPositionManager;

    mapping(Currency permissionsAdapter => Currency permissionedCurrency) public adapterToPermissioned;

    function setupPermissionedRouterCurrenciesAndPoolsWithLiquidity(address spender) public {
        _deployFreshManager();
        _deployWETH();
        _deployPositionDescriptor();
        _deployPermit2();
        _deployPermissionsAdapterFactory();
        _deployPermissionedHooks();
        _deployInsecureHook();
        _deployMockPermissionedRouter();
        _deployPositionManager();
        MockERC20[] memory tokens = _deployTokensMintAndApprove(5, 2);
        _deployAndSetupTokens(tokens);
        _setupPermissionedTokens(spender);
        _setupApprovals(tokens, spender);
        _createPoolsWithLiquidity();
    }

    function approveAllCurrencies(MockERC20[] memory currencies) internal {
        for (uint256 i = 0; i < currencies.length; i++) {
            approveAllContracts(address(currencies[i]));
        }
    }

    function approveAllContracts(address token) internal {
        approveBoth(token, address(permissionedHooks));
        approveBoth(token, address(permissionedRouter));
        approveBoth(token, address(positionManager));
        approveBoth(token, address(manager));
        approveBoth(token, address(permit2));
    }

    function approveBoth(address token, address approved) internal {
        permit2.approve(token, address(approved), type(uint160).max, 2 ** 47);
        IERC20(token).approve(address(approved), type(uint256).max);
    }

    function getPermissionedCurrency(Currency currency) public view returns (Currency) {
        Currency permissionedCurrency = adapterToPermissioned[currency];
        if (permissionedCurrency == Currency.wrap(address(0))) {
            return currency;
        }
        return permissionedCurrency;
    }

    function setupPermissionedTokens(address spender) internal {
        _setupMockAllowList(currency0, spender);
        _setupMockAllowList(currency1, spender);
        while (true) {
            permissionsAdapter0 = PermissionsAdapter(
                permissionsAdapterFactory.createPermissionsAdapter(
                    IERC20(Currency.unwrap(currency0)), address(this), mockAllowlistChecker
                )
            );
            permissionsAdapter1 = PermissionsAdapter(
                permissionsAdapterFactory.createPermissionsAdapter(
                    IERC20(Currency.unwrap(currency1)), address(this), mockAllowlistChecker
                )
            );
            if (address(permissionsAdapter0) > address(permissionsAdapter1)) {
                break;
            }
        }
        MockPermissionedToken(Currency.unwrap(currency0))
            .setAllowlist(address(permissionsAdapter0), PermissionFlags.ALL_ALLOWED);
        MockPermissionedToken(Currency.unwrap(currency1))
            .setAllowlist(address(permissionsAdapter1), PermissionFlags.ALL_ALLOWED);

        // Deposit some underlying tokens into the permissions adapter for verification
        IERC20(Currency.unwrap(currency0)).approve(address(permissionsAdapter0), 1);
        permissionsAdapter0.depositForVerification(1);
        IERC20(Currency.unwrap(currency1)).approve(address(permissionsAdapter1), 1);
        permissionsAdapter1.depositForVerification(1);

        verifyTokensAndAddWrappers();

        adapterToPermissioned[Currency.wrap(address(permissionsAdapter0))] = currency0;
        adapterToPermissioned[Currency.wrap(address(permissionsAdapter1))] = currency1;
    }

    function verifyTokensAndAddWrappers() private {
        permissionsAdapterFactory.verifyPermissionsAdapter(address(permissionsAdapter0));
        permissionsAdapterFactory.verifyPermissionsAdapter(address(permissionsAdapter1));

        permissionsAdapter0.updateAllowedWrapper(address(this), true);
        permissionsAdapter1.updateAllowedWrapper(address(this), true);
        permissionsAdapter0.updateAllowedWrapper(positionManager, true);
        permissionsAdapter1.updateAllowedWrapper(positionManager, true);
        permissionsAdapter0.updateAllowedWrapper(address(permissionedRouter), true);
        permissionsAdapter1.updateAllowedWrapper(address(permissionedRouter), true);
        permissionsAdapter0.updateAllowedWrapper(address(permissionedHooks), true);
        permissionsAdapter1.updateAllowedWrapper(address(permissionedHooks), true);

        setAllowedHooks(
            IPositionManager(positionManager), Currency.wrap(address(permissionsAdapter0)), permissionedHooks
        );
        setAllowedHooks(
            IPositionManager(positionManager), Currency.wrap(address(permissionsAdapter1)), permissionedHooks
        );

        setAllowedHooks(IPositionManager(positionManager), Currency.wrap(address(permissionsAdapter0)), insecureHooks);
        setAllowedHooks(IPositionManager(positionManager), Currency.wrap(address(permissionsAdapter1)), insecureHooks);
    }

    function setAllowedHooks(IPositionManager posm, Currency currency, IHooks permissionedHooks_) internal {
        // addPermissionedHooks selector
        bytes4 selector = 0xb5cdc484;
        bytes memory data = abi.encodeWithSelector(selector, currency, permissionedHooks_, true);
        (bool success,) = address(posm).call(data);
        require(success, "Failed to set hooks");
    }

    function createPoolWithLiquidity(Currency currencyA, Currency currencyB, address hookAddr)
        internal
        returns (PoolKey memory _key)
    {
        if (Currency.unwrap(currencyA) > Currency.unwrap(currencyB)) {
            (currencyA, currencyB) = (currencyB, currencyA);
        }
        _key = PoolKey(currencyA, currencyB, 3000, 60, IHooks(hookAddr));
        manager.initialize(_key, SQRT_PRICE_1_1);

        // Pools where neither side is a verified permissions adapter must use the plain PositionManager —
        // PermissionedPositionManager rejects mints into those pools (positions would be untransferable).
        bool currency0Verified =
            permissionsAdapterFactory.verifiedPermissionsAdapterOf(Currency.unwrap(currencyA)) != address(0);
        bool currency1Verified =
            permissionsAdapterFactory.verifiedPermissionsAdapterOf(Currency.unwrap(currencyB)) != address(0);
        address posm = (currency0Verified || currency1Verified) ? positionManager : ordinaryPositionManager;

        MockERC20(Currency.unwrap(currencyA)).approve(posm, type(uint256).max);
        MockERC20(Currency.unwrap(currencyB)).approve(posm, type(uint256).max);
        MockERC20(Currency.unwrap(currencyA)).approve(address(permit2), type(uint256).max);
        MockERC20(Currency.unwrap(currencyB)).approve(address(permit2), type(uint256).max);
        permit2.approve(Currency.unwrap(currencyA), posm, type(uint160).max, type(uint48).max);
        permit2.approve(Currency.unwrap(currencyB), posm, type(uint160).max, type(uint48).max);
        modifyLiquidityVia(posm, _key, ModifyLiquidityParams(-887220, 887220, 200 ether, 0), "0x", 0);
    }

    function createNativePoolWithLiquidity(Currency currency, address hookAddr) internal returns (PoolKey memory _key) {
        _key = PoolKey(CurrencyLibrary.ADDRESS_ZERO, currency, 3000, 60, IHooks(hookAddr));
        manager.initialize(_key, SQRT_PRICE_1_1);
        MockERC20(Currency.unwrap(currency)).approve(positionManager, type(uint256).max);
        modifyLiquidity(_key, ModifyLiquidityParams(-887220, 887220, 200 ether, 0), "0x", 200 ether);
    }

    function generatePermitDigest(IAllowanceTransfer.PermitSingle memory permitSingle) internal view returns (bytes32) {
        bytes32 domainSeparator = permit2.DOMAIN_SEPARATOR();

        bytes32 PERMIT_SINGLE_TYPEHASH = keccak256(
            "PermitSingle(PermitDetails details,address spender,uint256 sigDeadline)PermitDetails(address token,uint160 amount,uint48 expiration,uint48 nonce)"
        );

        // Hash the permit details
        bytes32 permitDetailsHash = keccak256(
            abi.encode(
                keccak256("PermitDetails(address token,uint160 amount,uint48 expiration,uint48 nonce)"),
                permitSingle.details.token,
                permitSingle.details.amount,
                permitSingle.details.expiration,
                permitSingle.details.nonce
            )
        );

        // Hash the permit single data
        bytes32 permitSingleHash = keccak256(
            abi.encode(PERMIT_SINGLE_TYPEHASH, permitDetailsHash, permitSingle.spender, permitSingle.sigDeadline)
        );

        // Create the final digest
        return keccak256(abi.encodePacked("\x19\x01", domainSeparator, permitSingleHash));
    }

    function _getExactInputParams(Currency[] memory _tokenPath, uint256 amountIn)
        internal
        pure
        returns (IV4Router.ExactInputParams memory params)
    {
        PathKey[] memory path = new PathKey[](_tokenPath.length - 1);
        for (uint256 i = 0; i < _tokenPath.length - 1; i++) {
            path[i] = PathKey(_tokenPath[i + 1], 3000, 60, IHooks(address(0)), bytes(""));
        }

        params.currencyIn = _tokenPath[0];
        params.path = path;
        params.amountIn = uint128(amountIn);
        params.amountOutMinimum = 0;
    }

    function _getExactInputParamsWithHook(Currency[] memory _tokenPath, uint256 amountIn, address hookAddr)
        internal
        pure
        returns (IV4Router.ExactInputParams memory params)
    {
        return _getExactInputParamsWithHook(_tokenPath, amountIn, hookAddr, 0);
    }

    function _getExactInputParamsWithHook(
        Currency[] memory _tokenPath,
        uint256 amountIn,
        address hookAddr,
        uint256 amountOutMinimum
    ) internal pure returns (IV4Router.ExactInputParams memory params) {
        PathKey[] memory path = new PathKey[](_tokenPath.length - 1);
        for (uint256 i = 0; i < _tokenPath.length - 1; i++) {
            path[i] = PathKey(_tokenPath[i + 1], 3000, 60, IHooks(hookAddr), bytes(""));
        }

        params.currencyIn = _tokenPath[0];
        params.path = path;
        params.minHopPriceX36 = new uint256[](0);
        params.amountIn = uint128(amountIn);
        params.amountOutMinimum = uint128(amountOutMinimum);
    }

    function _getExactOutputParams(Currency[] memory _tokenPath, uint256 amountOut)
        internal
        pure
        returns (IV4Router.ExactOutputParams memory params)
    {
        return _getExactOutputParamsWithHook(_tokenPath, amountOut, address(0), type(uint128).max);
    }

    function _getExactOutputParamsWithHook(
        Currency[] memory _tokenPath,
        uint256 amountOut,
        address hookAddr,
        uint256 amountInMaximum
    ) internal pure returns (IV4Router.ExactOutputParams memory params) {
        PathKey[] memory path = new PathKey[](_tokenPath.length - 1);
        for (uint256 i = _tokenPath.length - 1; i > 0; i--) {
            path[i - 1] = PathKey(_tokenPath[i - 1], 3000, 60, IHooks(hookAddr), bytes(""));
        }

        params.currencyOut = _tokenPath[_tokenPath.length - 1];
        params.path = path;
        params.minHopPriceX36 = new uint256[](0);
        params.amountOut = uint128(amountOut);
        params.amountInMaximum = uint128(amountInMaximum);
    }

    function modifyLiquidity(
        PoolKey memory key,
        ModifyLiquidityParams memory params,
        bytes memory hookData,
        uint256 value
    ) public {
        modifyLiquidityVia(positionManager, key, params, hookData, value);
    }

    function modifyLiquidityVia(
        address posm,
        PoolKey memory key,
        ModifyLiquidityParams memory params,
        bytes memory hookData,
        uint256 value
    ) public {
        // Create a plan with the mint position action
        plan = Planner.init();
        plan = plan.add(
            Actions.MINT_POSITION,
            abi.encode(key, params.tickLower, params.tickUpper, 20000, 100000, 100000, msg.sender, hookData)
        );

        // Finalize the plan with proper settlement
        bytes memory unlockData = plan.finalizeModifyLiquidityWithSettlePair(key);
        uint256 deadline = block.timestamp + 3600;

        // Call modifyLiquidities with the properly encoded data
        IPositionManager(posm).modifyLiquidities{value: value}(unlockData, deadline);
    }

    function _finalizeAndExecuteSwap(
        Currency inputCurrency,
        Currency outputCurrency,
        uint256 amountIn,
        address takeRecipient
    )
        internal
        returns (
            uint256 inputBalanceBefore,
            uint256 outputBalanceBefore,
            uint256 inputBalanceAfter,
            uint256 outputBalanceAfter
        )
    {
        inputBalanceBefore = getPermissionedCurrency(inputCurrency).balanceOfSelf();
        outputBalanceBefore = getPermissionedCurrency(outputCurrency).balanceOfSelf();

        bytes memory data = plan.finalizeSwap(inputCurrency, outputCurrency, takeRecipient);
        uint256 value = (inputCurrency.isAddressZero()) ? amountIn : 0;
        bytes memory command = hex"10";

        permissionedRouter.execute{value: value}(command, toBytesArray(data), type(uint256).max);

        inputBalanceAfter = getPermissionedCurrency(inputCurrency).balanceOfSelf();
        outputBalanceAfter = getPermissionedCurrency(outputCurrency).balanceOfSelf();
    }

    function _finalizeAndExecuteSwap(Currency inputCurrency, Currency outputCurrency, uint256 amountIn)
        internal
        returns (
            uint256 inputBalanceBefore,
            uint256 outputBalanceBefore,
            uint256 inputBalanceAfter,
            uint256 outputBalanceAfter
        )
    {
        return _finalizeAndExecuteSwap(inputCurrency, outputCurrency, amountIn, ActionConstants.MSG_SENDER);
    }

    // ===== PRIVATE HELPER FUNCTIONS =====

    function _deployFreshManager() private {
        deployFreshManager();
    }

    function _deployWETH() private {
        WETH wethImpl = new WETH();
        address wethAddr = makeAddr("WETH");
        vm.etch(wethAddr, address(wethImpl).code);
        weth9 = IWETH9(wethAddr);
    }

    function _deployPositionDescriptor() private {
        tokenDescriptor = Deploy.positionDescriptor(address(manager), address(weth9), "ETH", hex"00");
    }

    function _deployPermit2() private {
        permit2 = IAllowanceTransfer(deployPermit2());
    }

    function _deployPermissionsAdapterFactory() private {
        bytes memory permissionsAdapterFactoryBytecode = abi.encodePacked(
            vm.getCode("PermissionsAdapterFactory.sol:PermissionsAdapterFactory"), abi.encode(address(manager))
        );
        permissionsAdapterFactory = IPermissionsAdapterFactory(
            Deploy.create2(permissionsAdapterFactoryBytecode, keccak256("permissionsAdapterFactory"))
        );
    }

    function _deployPermissionedHooks() private {
        permissionedHooks = IHooks(deployPermissionedHooks(address(manager), address(permissionsAdapterFactory)));
    }

    function _deployInsecureHook() private {
        insecureHooks = IHooks(deployInsecureHooks(address(manager)));
    }

    function _deployMockPermissionedRouter() private {
        bytes memory routerBytecode = abi.encodePacked(
            vm.getCode("MockPermissionedRouter.sol:MockPermissionedRouter"),
            abi.encode(manager, permit2, permissionsAdapterFactory, weth9)
        );
        permissionedRouter =
            MockPermissionedRouter(payable(Deploy.create2(routerBytecode, keccak256("permissionedSwapRouter"))));
    }

    function _deployPositionManager() private {
        bytes memory posmBytecode = abi.encodePacked(
            vm.getCode("PermissionedPositionManager.sol:PermissionedPositionManager"),
            abi.encode(manager, permit2, 1e18, address(tokenDescriptor), address(weth9), permissionsAdapterFactory)
        );
        positionManager = Deploy.create2(posmBytecode, keccak256("permissionedPosm"));

        // Plain PositionManager — used to mint liquidity into ordinary pools (no verified adapter).
        ordinaryPositionManager = address(
            Deploy.positionManager(
                address(manager),
                address(permit2),
                1e18,
                address(tokenDescriptor),
                address(weth9),
                bytes.concat(keccak256("ordinaryPosm"))
            )
        );
    }

    function _deployAndSetupTokens(MockERC20[] memory tokens) private {
        currency0 = Currency.wrap(address(tokens[0]));
        currency1 = Currency.wrap(address(tokens[1]));
        currency2 = Currency.wrap(address(tokens[2]));
        currency3 = Currency.wrap(address(tokens[3]));
        currency4 = Currency.wrap(address(tokens[4]));
    }

    function _setupPermissionedTokens(address spender) private {
        setupPermissionedTokens(spender);
    }

    function _setupApprovals(MockERC20[] memory tokens, address alice) private {
        approveAllCurrencies(tokens);
        vm.startPrank(alice);
        approveAllCurrencies(tokens);
        vm.stopPrank();
    }

    function _createPoolsWithLiquidity() private {
        nativeKey =
            createNativePoolWithLiquidity(Currency.wrap(address(permissionsAdapter0)), address(permissionedHooks));
        key0 = createPoolWithLiquidity(
            Currency.wrap(address(permissionsAdapter0)),
            Currency.wrap(address(permissionsAdapter1)),
            address(permissionedHooks)
        );
        key1 =
            createPoolWithLiquidity(Currency.wrap(address(permissionsAdapter1)), currency2, address(permissionedHooks));
        key2 = createPoolWithLiquidity(currency2, currency3, address(0));
        key3 =
            createPoolWithLiquidity(Currency.wrap(address(permissionsAdapter0)), currency4, address(permissionedHooks));
        insecureKey = createPoolWithLiquidity(
            Currency.wrap(address(permissionsAdapter0)),
            Currency.wrap(address(permissionsAdapter1)),
            address(insecureHooks)
        );
    }

    function _setupMockAllowList(Currency currency, address spender) private {
        MockPermissionedToken mockPermissionedToken = MockPermissionedToken(Currency.unwrap(currency));
        mockAllowlistChecker = new MockAllowlistChecker();
        mockPermissionedToken.setAllowlist(address(this), PermissionFlags.ALL_ALLOWED);
        mockPermissionedToken.setAllowlist(msg.sender, PermissionFlags.ALL_ALLOWED);
        mockPermissionedToken.setAllowlist(address(permissionedRouter), PermissionFlags.ALL_ALLOWED);
        mockPermissionedToken.setAllowlist(address(permissionedHooks), PermissionFlags.ALL_ALLOWED);
        mockPermissionedToken.setAllowlist(address(positionManager), PermissionFlags.ALL_ALLOWED);
        mockPermissionedToken.setAllowlist(address(permissionsAdapterFactory), PermissionFlags.ALL_ALLOWED);
        mockPermissionedToken.setAllowlist(address(manager), PermissionFlags.ALL_ALLOWED);
        mockPermissionedToken.setAllowlist(address(permit2), PermissionFlags.ALL_ALLOWED);
        mockPermissionedToken.setAllowlist(spender, PermissionFlags.ALL_ALLOWED);
    }

    function _deployTokensMintAndApprove(uint8 count, uint8 permissionedCount) internal returns (MockERC20[] memory) {
        MockERC20[] memory permissionedTokens = deployTokens(permissionedCount, 2 ** 128, true);
        MockERC20[] memory unpermissionedTokens = deployTokens(count - permissionedCount, 2 ** 128, false);
        MockERC20[] memory tokens = new MockERC20[](count);
        for (uint256 i = 0; i < permissionedCount; i++) {
            tokens[i] = permissionedTokens[i];
        }
        for (uint256 i = 0; i < count - permissionedCount; i++) {
            tokens[i + permissionedCount] = unpermissionedTokens[i];
        }
        for (uint256 i = 0; i < count; i++) {
            tokens[i].approve(address(permissionedRouter), type(uint256).max);
            tokens[i].approve(address(positionManager), type(uint256).max);
        }
        return tokens;
    }
}
