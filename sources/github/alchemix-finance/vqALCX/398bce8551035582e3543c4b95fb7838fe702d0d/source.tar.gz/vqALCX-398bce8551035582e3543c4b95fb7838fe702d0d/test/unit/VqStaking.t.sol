// SPDX-License-Identifier: MIT
pragma solidity 0.8.36;

import {Test} from "@forge-std/Test.sol";
import {VqALCX} from "../../src/VqALCX.sol";
import {VqStaking} from "../../src/VqStaking.sol";
import {MockALCX, MockReward} from "../mocks/Mocks.sol";

contract VqStakingTest is Test {
    VqALCX public vault;
    VqStaking public staking;
    MockALCX public alcx;
    MockReward public rewardToken;

    address public governance = address(0xCAFE);
    address public alice = address(0x1111);
    address public bob = address(0x2222);
    address public delegate1 = address(0x3333);

    uint256 constant RATE = 1000e18;
    uint256 constant CAPACITY = 1_000_000e18;

    function setUp() public {
        alcx = new MockALCX();
        rewardToken = new MockReward();
        vault = new VqALCX(address(alcx), governance, address(0));
        staking = new VqStaking(address(vault), address(rewardToken));

        vm.prank(governance);
        vault.setDepositBucketParams(RATE, CAPACITY);
        vm.prank(governance);
        vault.setWithdrawBucketParams(RATE, CAPACITY);

        alcx.mint(alice, 1_000_000e18);
        alcx.mint(bob, 1_000_000e18);

        vm.startPrank(alice);
        alcx.approve(address(vault), type(uint256).max);
        vault.approve(address(staking), type(uint256).max);
        vm.stopPrank();

        vm.startPrank(bob);
        alcx.approve(address(vault), type(uint256).max);
        vault.approve(address(staking), type(uint256).max);
        vm.stopPrank();

        rewardToken.mint(address(this), 1_000_000e18);
    }

    function _depositVqALCX(address user, uint256 amount) internal {
        vm.startPrank(user);
        vault.requestDeposit(amount);
        vm.warp(block.timestamp + (amount / RATE) + 1);
        vault.deposit(amount, user);
        vm.stopPrank();
    }

    /// Stake, wait out the reward warm-up, then poke (zero-reward claim) so the
    /// batch joins the earning pool.
    function _season(address user) internal {
        vm.warp(block.timestamp + staking.REWARD_WARMUP() + 1);
        vm.prank(user);
        staking.claimRewards();
    }

    // ------------------------------------------------------------------
    // Construction
    // ------------------------------------------------------------------

    function test_Construction() public view {
        assertEq(address(staking.vqALCX()), address(vault));
        assertEq(address(staking.rewardToken()), address(rewardToken));
        assertEq(staking.clock(), block.timestamp);
        // ERC-6372 canonical descriptor for a timestamp clock
        assertEq(staking.CLOCK_MODE(), "mode=timestamp");
    }

    function test_ConstructorRejectsStakedTokenAsRewardToken() public {
        vm.expectRevert(VqStaking.SameRewardToken.selector);
        new VqStaking(address(vault), address(vault));
    }

    // ------------------------------------------------------------------
    // Staking
    // ------------------------------------------------------------------

    function test_Stake() public {
        _depositVqALCX(alice, 1000e18);

        vm.prank(alice);
        staking.stake(1000e18);

        assertEq(staking.stakedBalanceOf(alice), 1000e18);
        assertEq(staking.totalStaked(), 1000e18);
        assertEq(vault.balanceOf(address(staking)), 1000e18);
    }

    function test_Unstake() public {
        _depositVqALCX(alice, 1000e18);

        vm.startPrank(alice);
        staking.stake(1000e18);
        staking.unstake(500e18);
        vm.stopPrank();

        assertEq(staking.stakedBalanceOf(alice), 500e18);
        assertEq(vault.balanceOf(alice), 500e18);
    }

    function test_UnstakeInsufficientBalance() public {
        _depositVqALCX(alice, 1000e18);

        vm.startPrank(alice);
        staking.stake(500e18);
        vm.expectRevert(VqStaking.InsufficientBalance.selector);
        staking.unstake(501e18);
        vm.stopPrank();
    }

    // ------------------------------------------------------------------
    // Voting power (VotesExtended)
    // ------------------------------------------------------------------

    function test_StakeAutoSelfDelegates() public {
        _depositVqALCX(alice, 1000e18);

        vm.prank(alice);
        staking.stake(1000e18);

        // First stake defaults to self-delegation, votes are live
        assertEq(staking.delegates(alice), alice);
        assertEq(staking.getVotes(alice), 1000e18);
    }

    function test_DelegateSelf() public {
        _depositVqALCX(alice, 1000e18);

        vm.startPrank(alice);
        staking.stake(1000e18);
        staking.delegate(alice);
        vm.stopPrank();

        assertEq(staking.getVotes(alice), 1000e18);
    }

    function test_DelegateToOther() public {
        _depositVqALCX(alice, 1000e18);

        vm.startPrank(alice);
        staking.stake(1000e18);
        staking.delegate(delegate1);
        vm.stopPrank();

        assertEq(staking.getVotes(delegate1), 1000e18);
        assertEq(staking.getVotes(alice), 0);
    }

    function test_GetPastVotes() public {
        _depositVqALCX(alice, 1000e18);

        vm.startPrank(alice);
        staking.stake(1000e18);
        staking.delegate(alice);
        vm.stopPrank();

        uint256 snapshotTime = block.timestamp;
        vm.warp(block.timestamp + 100);

        assertEq(staking.getPastVotes(alice, snapshotTime), 1000e18);
    }

    function test_GetPastBalanceOf() public {
        _depositVqALCX(alice, 1000e18);

        vm.startPrank(alice);
        staking.stake(1000e18);
        vm.stopPrank();

        uint256 snapshotTime = block.timestamp;
        vm.warp(block.timestamp + 100);

        assertEq(staking.getPastBalanceOf(alice, snapshotTime), 1000e18);
    }

    function test_GetPastDelegate() public {
        _depositVqALCX(alice, 1000e18);

        vm.startPrank(alice);
        staking.stake(1000e18);
        staking.delegate(delegate1);
        vm.stopPrank();

        uint256 snapshotTime = block.timestamp;
        vm.warp(block.timestamp + 100);

        assertEq(staking.getPastDelegate(alice, snapshotTime), delegate1);
    }

    function test_CurrentTimeViews() public {
        _depositVqALCX(alice, 1000e18);
        _depositVqALCX(bob, 500e18);

        vm.prank(alice);
        staking.stake(1000e18);
        vm.prank(bob);
        staking.stake(500e18);
        vm.warp(block.timestamp + 100);

        vm.prank(alice);
        staking.unstake(400e18);

        assertEq(staking.balanceOf(alice), 600e18);
        assertEq(staking.balanceOf(bob), 500e18);
        assertEq(staking.getTotalSupply(), 1100e18);

        assertEq(staking.name(), vault.name());
        assertEq(staking.symbol(), vault.symbol());
        assertEq(staking.decimals(), vault.decimals());
    }

    // ------------------------------------------------------------------
    // Checkpoint on stake/unstake
    // ------------------------------------------------------------------

    function test_CheckpointOnStake() public {
        _depositVqALCX(alice, 1000e18);

        vm.prank(alice);
        staking.stake(1000e18);

        uint256 snapshotTime = block.timestamp;
        vm.warp(block.timestamp + 50);

        _depositVqALCX(alice, 500e18);
        vm.prank(alice);
        staking.stake(500e18);

        assertEq(staking.getPastBalanceOf(alice, snapshotTime), 1000e18);
        assertEq(staking.stakedBalanceOf(alice), 1500e18);
    }

    function test_CheckpointOnUnstake() public {
        _depositVqALCX(alice, 1000e18);

        vm.startPrank(alice);
        staking.stake(1000e18);
        vm.stopPrank();

        uint256 snapshotTime = block.timestamp;
        vm.warp(block.timestamp + 50);

        vm.prank(alice);
        staking.unstake(400e18);

        assertEq(staking.getPastBalanceOf(alice, snapshotTime), 1000e18);
        assertEq(staking.stakedBalanceOf(alice), 600e18);
    }

    // ------------------------------------------------------------------
    // Rewards — push-based, lazy accrual
    // ------------------------------------------------------------------

    function test_PushRewardsDetectedOnNextInteraction() public {
        _depositVqALCX(alice, 1000e18);
        _depositVqALCX(bob, 1000e18);

        vm.prank(alice);
        staking.stake(1000e18);

        vm.prank(bob);
        staking.stake(1000e18);

        _season(alice);
        _season(bob);

        // Push rewards: a plain transfer, no function call needed
        rewardToken.transfer(address(staking), 100e18);

        vm.prank(alice);
        staking.claimRewards();
        assertApproxEqAbs(rewardToken.balanceOf(alice), 50e18, 1);

        vm.prank(bob);
        staking.claimRewards();
        assertApproxEqAbs(rewardToken.balanceOf(bob), 50e18, 1);
    }

    function test_AccrueRewardsCallableByAnyone() public {
        _depositVqALCX(alice, 1000e18);

        vm.prank(alice);
        staking.stake(1000e18);
        _season(alice);

        // Push rewards
        rewardToken.transfer(address(staking), 100e18);

        // Anyone can accrue — updates global rewardPerShare
        address randomCaller = address(0x9999);
        vm.prank(randomCaller);
        staking.accrueRewards();

        assertGt(staking.rewardPerShare(), 0);

        vm.prank(alice);
        staking.claimRewards();
        assertApproxEqAbs(rewardToken.balanceOf(alice), 100e18, 1);
    }

    function test_RewardsAccrueBeforeStake() public {
        // Push rewards when nobody is staked — carried to the next staker
        rewardToken.transfer(address(staking), 100e18);

        _depositVqALCX(alice, 1000e18);

        vm.prank(alice);
        staking.stake(1000e18);

        // Nothing accrued yet at stake time
        assertEq(staking.earned(alice), 0);

        _season(alice);

        // Alice receives both the carried rewards and the new rewards
        rewardToken.transfer(address(staking), 50e18);

        vm.prank(alice);
        staking.claimRewards();
        assertApproxEqAbs(rewardToken.balanceOf(alice), 150e18, 1);
    }

    function test_RewardsDuringZeroStakeWindowCarryToNextStaker() public {
        _depositVqALCX(alice, 1000e18);

        vm.prank(alice);
        staking.stake(1000e18);
        _season(alice);

        vm.prank(alice);
        staking.unstake(1000e18);

        rewardToken.transfer(address(staking), 700e18);

        _depositVqALCX(bob, 500e18);

        vm.prank(bob);
        staking.stake(500e18);
        _season(bob);

        vm.prank(bob);
        staking.claimRewards();
        assertApproxEqAbs(rewardToken.balanceOf(bob), 700e18, 1);
    }

    function test_RewardsProportionalToStake() public {
        _depositVqALCX(alice, 3000e18);
        _depositVqALCX(bob, 1000e18);

        vm.prank(alice);
        staking.stake(3000e18);

        vm.prank(bob);
        staking.stake(1000e18);

        _season(alice);
        _season(bob);

        // Push 400 reward tokens — Alice should get 75%, Bob 25%
        rewardToken.transfer(address(staking), 400e18);

        vm.prank(alice);
        staking.claimRewards();
        assertApproxEqAbs(rewardToken.balanceOf(alice), 300e18, 1);

        vm.prank(bob);
        staking.claimRewards();
        assertApproxEqAbs(rewardToken.balanceOf(bob), 100e18, 1);
    }

    // ------------------------------------------------------------------
    // Reward warm-up (anti-JIT-sniping): new stakes earn nothing for
    // REWARD_WARMUP; unstake stays instant.
    // ------------------------------------------------------------------

    function test_NewStakeEarnsNothingDuringWarmup() public {
        _depositVqALCX(alice, 1000e18);

        vm.prank(alice);
        staking.stake(1000e18);

        // Donation during the warm-up goes to nobody (distribution base is 0).
        rewardToken.transfer(address(staking), 100e18);
        vm.prank(alice);
        staking.claimRewards();
        assertEq(staking.earned(alice), 0, "warming stake earns nothing");
    }

    function test_UnstakeIsInstantDuringWarmup() public {
        _depositVqALCX(alice, 1000e18);

        vm.prank(alice);
        staking.stake(1000e18);

        // No lockup: full unstake immediately after staking.
        vm.prank(alice);
        staking.unstake(1000e18);
        assertEq(vault.balanceOf(alice), 1000e18);
        assertEq(staking.stakedBalanceOf(alice), 0);
        assertEq(staking.getVotes(alice), 0);
    }

    // ------------------------------------------------------------------
    // Non-rebalancing invariant check
    // ------------------------------------------------------------------

    function test_VqALCXBalanceDoesNotChangeOnStake() public {
        _depositVqALCX(alice, 1000e18);

        uint256 balanceBefore = vault.balanceOf(alice);

        vm.prank(alice);
        staking.stake(500e18);

        assertEq(vault.balanceOf(alice), balanceBefore - 500e18);
    }

    // ------------------------------------------------------------------
    // INV-T-9: sum of staked balances = vqALCX held by staking contract
    // ------------------------------------------------------------------

    function test_StakingAccountingInvariant() public {
        _depositVqALCX(alice, 1000e18);
        _depositVqALCX(bob, 2000e18);

        vm.prank(alice);
        staking.stake(800e18);

        vm.prank(bob);
        staking.stake(1500e18);

        vm.prank(alice);
        staking.unstake(300e18);

        uint256 totalStaked = staking.totalStaked();
        uint256 heldByStaking = vault.balanceOf(address(staking));
        assertEq(totalStaked, heldByStaking, "INV-T-9: staked sum != held vqALCX");

        assertEq(staking.stakedBalanceOf(alice), 500e18);
        assertEq(staking.stakedBalanceOf(bob), 1500e18);
        assertEq(totalStaked, 2000e18);
    }

    // ------------------------------------------------------------------
    // Delegate checkpoint consistency
    // ------------------------------------------------------------------

    function test_DelegateCheckpointConsistency() public {
        _depositVqALCX(alice, 1000e18);
        _depositVqALCX(bob, 500e18);

        vm.startPrank(alice);
        staking.stake(1000e18);
        staking.delegate(alice);
        vm.stopPrank();

        vm.startPrank(bob);
        staking.stake(500e18);
        staking.delegate(bob);
        vm.stopPrank();

        assertEq(staking.getVotes(alice), 1000e18);
        assertEq(staking.getVotes(bob), 500e18);

        uint256 snap = block.timestamp;
        vm.warp(block.timestamp + 50);

        assertEq(staking.getPastBalanceOf(alice, snap), 1000e18);
        assertEq(staking.getPastVotes(alice, snap), 1000e18);
    }
}
