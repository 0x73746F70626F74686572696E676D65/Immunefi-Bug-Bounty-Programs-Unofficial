// SPDX-License-Identifier: MIT
pragma solidity 0.8.36;

import {Test} from "@forge-std/Test.sol";
import {VqALCX} from "../../src/VqALCX.sol";
import {VqAuctioner} from "../../src/VqAuctioner.sol";
import {MockALCX} from "../mocks/Mocks.sol";

contract VqAuctionerTest is Test {
    VqALCX public vault;
    VqAuctioner public auctioner;
    MockALCX public alcx;

    address public governance = address(0xCAFE);
    address public treasury = address(0xDEAD);
    address public alice = address(0x1111);
    address public bob = address(0x2222);

    uint256 constant RATE = 100e18;
    uint256 constant CAPACITY = 10_000e18;
    uint256 constant ROUND_DURATION = 3600; // 1 hour

    function setUp() public {
        alcx = new MockALCX();
        vault = new VqALCX(address(alcx), governance, address(0)); // no auctioneer yet

        auctioner = new VqAuctioner(address(alcx), address(vault), treasury, ROUND_DURATION);

        // Set auctioneer on vault via two-step transfer (real acceptance path)
        vm.prank(governance);
        vault.proposeAuctioneer(address(auctioner));
        auctioner.acceptVaultAuctioneer();

        vm.prank(governance);
        vault.setDepositBucketParams(RATE, CAPACITY);
        vm.prank(governance);
        vault.setWithdrawBucketParams(RATE, CAPACITY);

        alcx.mint(alice, 1_000_000e18);
        alcx.mint(bob, 1_000_000e18);

        vm.startPrank(alice);
        alcx.approve(address(vault), type(uint256).max);
        alcx.approve(address(auctioner), type(uint256).max);
        vm.stopPrank();

        vm.startPrank(bob);
        alcx.approve(address(vault), type(uint256).max);
        alcx.approve(address(auctioner), type(uint256).max);
        vm.stopPrank();
    }

    function _deploySlowBuckets() internal returns (VqALCX vault2, VqAuctioner auctioner2, MockALCX alcx2) {
        alcx2 = new MockALCX();
        vault2 = new VqALCX(address(alcx2), governance, address(0));
        auctioner2 = new VqAuctioner(address(alcx2), address(vault2), treasury, 100);
        vm.prank(governance);
        vault2.proposeAuctioneer(address(auctioner2));
        auctioner2.acceptVaultAuctioneer();
        vm.prank(governance);
        vault2.setDepositBucketParams(10e18, 10_000e18);
        vm.prank(governance);
        vault2.setWithdrawBucketParams(10e18, 10_000e18);

        alcx2.mint(alice, 1_000_000e18);
        alcx2.mint(bob, 1_000_000e18);
        alcx2.mint(address(vault2), 10_000e18);
        vm.startPrank(alice);
        alcx2.approve(address(vault2), type(uint256).max);
        alcx2.approve(address(auctioner2), type(uint256).max);
        vault2.approve(address(auctioner2), type(uint256).max);
        vm.stopPrank();
        vm.startPrank(bob);
        alcx2.approve(address(vault2), type(uint256).max);
        alcx2.approve(address(auctioner2), type(uint256).max);
        vm.stopPrank();

        return (vault2, auctioner2, alcx2);
    }

    // ------------------------------------------------------------------
    // Construction
    // ------------------------------------------------------------------

    function test_Construction() public view {
        assertEq(address(auctioner.alcx()), address(alcx));
        assertEq(address(auctioner.vqALCX()), address(vault));
        assertEq(auctioner.daoTreasury(), treasury);
        assertEq(auctioner.roundDuration(), ROUND_DURATION);
    }

    // ------------------------------------------------------------------
    // Deposit auction
    // ------------------------------------------------------------------

    function test_DepositBid() public {
        vm.warp(block.timestamp + 100); // 100 * 100 = 10,000 capacity

        uint256 roundId = auctioner.ensureDepositRound();
        assertEq(roundId, 1);

        vm.prank(alice);
        auctioner.bidDeposit(1000e18, 1050e18); // pay 1050 for 1000 vqALCX

        VqAuctioner.Round memory round = auctioner.getDepositRound(1);
        assertEq(round.highestBidder, alice);
        assertEq(round.highestBidAmount, 1000e18);
        assertEq(round.highestBidPrice, 1050e18);
    }

    function test_DepositBidRequiresPriceAboveBase() public {
        vm.prank(alice);
        vm.expectRevert(VqAuctioner.InvalidPrice.selector);
        auctioner.bidDeposit(1000e18, 999e18);
    }

    function test_DepositBidOutbids() public {
        vm.warp(block.timestamp + 100);

        auctioner.ensureDepositRound();

        vm.prank(alice);
        auctioner.bidDeposit(1000e18, 1050e18);

        uint256 aliceBalBefore = alcx.balanceOf(alice);

        vm.prank(bob);
        auctioner.bidDeposit(1000e18, 1100e18);

        assertEq(alcx.balanceOf(alice), aliceBalBefore + 1050e18);

        VqAuctioner.Round memory round = auctioner.getDepositRound(1);
        assertEq(round.highestBidder, bob);
        assertEq(round.highestBidPrice, 1100e18);
    }

    function test_DepositBidTooLow() public {
        vm.warp(block.timestamp + 100);
        auctioner.ensureDepositRound();

        vm.prank(alice);
        auctioner.bidDeposit(1000e18, 1050e18);

        vm.prank(bob);
        vm.expectRevert(VqAuctioner.BidTooLow.selector);
        auctioner.bidDeposit(1000e18, 1050e18); // same price, not higher
    }

    function test_DepositAuctionSettlement() public {
        vm.warp(block.timestamp + 100);
        auctioner.ensureDepositRound();

        vm.prank(alice);
        auctioner.bidDeposit(1000e18, 1050e18);

        vm.warp(block.timestamp + ROUND_DURATION + 1);

        uint256 treasuryBefore = alcx.balanceOf(treasury);
        auctioner.settleDepositRound(1);

        assertEq(vault.balanceOf(alice), 1000e18);
        assertEq(alcx.balanceOf(treasury), treasuryBefore + 50e18);
        assertEq(alcx.balanceOf(address(vault)), 1000e18);
    }

    function test_DepositRoundStartsNextAfterSettlement() public {
        vm.warp(block.timestamp + 100);
        auctioner.ensureDepositRound();

        vm.warp(block.timestamp + ROUND_DURATION + 1);
        auctioner.settleDepositRound(1);

        assertEq(auctioner.currentDepositRound(), 2);
    }

    // ------------------------------------------------------------------
    // Withdraw auction
    // ------------------------------------------------------------------

    function test_WithdrawBid() public {
        vm.warp(block.timestamp + 100);
        auctioner.ensureDepositRound();

        vm.prank(alice);
        auctioner.bidDeposit(1000e18, 1050e18);

        vm.warp(block.timestamp + ROUND_DURATION + 1);
        auctioner.settleDepositRound(1);

        // Alice now has 1000 vqALCX
        assertEq(vault.balanceOf(alice), 1000e18);

        vm.startPrank(alice);
        vault.approve(address(auctioner), type(uint256).max);

        // Bid in withdraw auction: burn 1000 vqALCX, want at least 970 ALCX
        auctioner.ensureWithdrawRound();
        auctioner.bidWithdraw(1000e18, 970e18);
        vm.stopPrank();

        VqAuctioner.Round memory round = auctioner.getWithdrawRound(1);
        assertEq(round.highestBidder, alice);
        assertEq(round.highestBidAmount, 1000e18);
        assertEq(round.highestBidPrice, 970e18);
    }

    function test_WithdrawBidRequiresPayoutAtOrBelowBase() public {
        vm.prank(alice);
        vm.expectRevert(VqAuctioner.InvalidPrice.selector);
        auctioner.bidWithdraw(1000e18, 1001e18);
    }

    function test_WithdrawAuctionSettlement() public {
        vm.warp(block.timestamp + 100);
        auctioner.ensureDepositRound();
        vm.prank(alice);
        auctioner.bidDeposit(1000e18, 1050e18);
        vm.warp(block.timestamp + ROUND_DURATION + 1);
        auctioner.settleDepositRound(1);

        assertEq(vault.balanceOf(alice), 1000e18);

        vm.warp(block.timestamp + 100);
        vm.startPrank(alice);
        vault.approve(address(auctioner), type(uint256).max);
        auctioner.ensureWithdrawRound();
        auctioner.bidWithdraw(1000e18, 970e18);
        vm.stopPrank();

        vm.warp(block.timestamp + ROUND_DURATION + 1);

        uint256 aliceAlcxBefore = alcx.balanceOf(alice);
        auctioner.settleWithdrawRound(1);

        assertEq(alcx.balanceOf(alice), aliceAlcxBefore + 970e18);
        assertEq(vault.balanceOf(alice), 0);
        // 30 ALCX stays in vault (discount = protocol profit)
        assertGe(alcx.balanceOf(address(vault)), 30e18);
    }

    // ------------------------------------------------------------------
    // Partial settlement when auction capacity is short
    // ------------------------------------------------------------------

    function test_DepositSettlementPartiallyFillsWhenCapacityIsShort() public {
        (VqALCX vault2, VqAuctioner auctioner2, MockALCX alcx2) = _deploySlowBuckets();

        vm.prank(bob);
        vault2.requestDeposit(900e18);

        vm.prank(alice);
        auctioner2.bidDeposit(1000e18, 1100e18);

        vm.warp(block.timestamp + 101);

        uint256 aliceBefore = alcx2.balanceOf(alice);
        uint256 treasuryBefore = alcx2.balanceOf(treasury);
        auctioner2.settleDepositRound(1);

        // 1010 budget - 900 queue = 110 capacity: partial fill
        assertEq(vault2.balanceOf(alice), 110e18);
        assertEq(alcx2.balanceOf(treasury), treasuryBefore + 11e18);
        assertEq(alcx2.balanceOf(alice), aliceBefore + 979e18);
        assertEq(alcx2.balanceOf(address(auctioner2)), 0);

        VqAuctioner.Round memory round = auctioner2.getDepositRound(1);
        assertTrue(round.settled);
        assertEq(round.totalFilled, 110e18);
        assertEq(auctioner2.currentDepositRound(), 2);
    }

    function test_DepositSettlementRefundsWinnerWhenCapacityIsZero() public {
        (VqALCX vault2, VqAuctioner auctioner2, MockALCX alcx2) = _deploySlowBuckets();

        vm.prank(bob);
        vault2.requestDeposit(2000e18);

        vm.prank(alice);
        auctioner2.bidDeposit(1000e18, 1100e18);

        vm.warp(block.timestamp + 101);

        uint256 aliceBefore = alcx2.balanceOf(alice);
        auctioner2.settleDepositRound(1);

        assertEq(vault2.balanceOf(alice), 0);
        assertEq(alcx2.balanceOf(alice), aliceBefore + 1100e18);
        assertEq(alcx2.balanceOf(address(auctioner2)), 0);

        VqAuctioner.Round memory round = auctioner2.getDepositRound(1);
        assertTrue(round.settled);
        assertEq(round.totalFilled, 0);
        assertEq(auctioner2.currentDepositRound(), 2);
    }

    function test_WithdrawSettlementPartiallyFillsWhenCapacityIsShort() public {
        (VqALCX vault2, VqAuctioner auctioner2, MockALCX alcx2) = _deploySlowBuckets();

        deal(address(vault2), bob, 100e18);
        deal(address(vault2), alice, 1000e18);

        vm.prank(bob);
        vault2.requestWithdraw(100e18);

        vm.prank(alice);
        auctioner2.bidWithdraw(1000e18, 1000e18);

        vm.warp(block.timestamp + 101);

        uint256 aliceAlcxBefore = alcx2.balanceOf(alice);
        auctioner2.settleWithdrawRound(1);

        // 1010 budget - 100 queue = 910 capacity: partial fill
        assertEq(alcx2.balanceOf(alice), aliceAlcxBefore + 910e18);
        assertEq(vault2.balanceOf(alice), 90e18);
        assertEq(vault2.balanceOf(address(auctioner2)), 0);

        VqAuctioner.Round memory round = auctioner2.getWithdrawRound(1);
        assertTrue(round.settled);
        assertEq(round.totalFilled, 910e18);
        assertEq(auctioner2.currentWithdrawRound(), 2);
    }

    function test_WithdrawSettlementRefundsWinnerWhenCapacityIsZero() public {
        (VqALCX vault2, VqAuctioner auctioner2, MockALCX alcx2) = _deploySlowBuckets();

        deal(address(vault2), bob, 1100e18);
        deal(address(vault2), alice, 1000e18);

        vm.prank(bob);
        vault2.requestWithdraw(1100e18);

        vm.prank(alice);
        auctioner2.bidWithdraw(1000e18, 1000e18);

        vm.warp(block.timestamp + 101);

        uint256 aliceAlcxBefore = alcx2.balanceOf(alice);
        auctioner2.settleWithdrawRound(1);

        assertEq(vault2.balanceOf(alice), 1000e18);
        assertEq(alcx2.balanceOf(alice), aliceAlcxBefore);
        assertEq(vault2.balanceOf(address(auctioner2)), 0);

        VqAuctioner.Round memory round = auctioner2.getWithdrawRound(1);
        assertTrue(round.settled);
        assertEq(round.totalFilled, 0);
        assertEq(auctioner2.currentWithdrawRound(), 2);
    }

    // ------------------------------------------------------------------
    // Round expiry
    // ------------------------------------------------------------------

    function test_BidAfterRoundExpiry() public {
        vm.warp(block.timestamp + 100);
        auctioner.ensureDepositRound();

        vm.warp(block.timestamp + ROUND_DURATION + 1);

        vm.prank(alice);
        vm.expectRevert(VqAuctioner.RoundNotActive.selector);
        auctioner.bidDeposit(1000e18, 1050e18);
    }

    function test_NoBidsSettlement() public {
        vm.warp(block.timestamp + 100);
        auctioner.ensureDepositRound();

        vm.warp(block.timestamp + ROUND_DURATION + 1);
        auctioner.settleDepositRound(1); // no bids

        assertEq(auctioner.currentDepositRound(), 2);
    }

    // ------------------------------------------------------------------
    // Auction capacity bounded by bucket rate
    // ------------------------------------------------------------------

    function test_AuctionCapacityBoundedByRate() public {
        vm.warp(block.timestamp + 100); // 100s * 100/s = 10,000 capacity

        auctioner.ensureDepositRound();

        VqAuctioner.Round memory round = auctioner.getDepositRound(1);
        assertEq(round.capacity, RATE * ROUND_DURATION);
    }

    // ------------------------------------------------------------------
    // INV-A-3: Auctioneer ALCX balance = 0 after settlement
    // ------------------------------------------------------------------

    function test_AuctioneerAlcxBalanceZeroAfterDepositSettlement() public {
        vm.warp(block.timestamp + 100);
        auctioner.ensureDepositRound();

        vm.prank(alice);
        auctioner.bidDeposit(1000e18, 1050e18);

        vm.warp(block.timestamp + ROUND_DURATION + 1);
        auctioner.settleDepositRound(1);

        assertEq(alcx.balanceOf(address(auctioner)), 0, "INV-A-3: ALCX left in auctioneer");
    }

    function test_AuctioneerVqALCXBalanceZeroAfterWithdrawSettlement() public {
        vm.warp(block.timestamp + 100);
        auctioner.ensureDepositRound();
        vm.prank(alice);
        auctioner.bidDeposit(1000e18, 1050e18);
        vm.warp(block.timestamp + ROUND_DURATION + 1);
        auctioner.settleDepositRound(1);

        vm.warp(block.timestamp + 100);
        vm.startPrank(alice);
        vault.approve(address(auctioner), type(uint256).max);
        auctioner.ensureWithdrawRound();
        auctioner.bidWithdraw(1000e18, 970e18);
        vm.stopPrank();

        vm.warp(block.timestamp + ROUND_DURATION + 1);
        auctioner.settleWithdrawRound(1);

        assertEq(vault.balanceOf(address(auctioner)), 0, "INV-A-3: vqALCX left in auctioneer");
    }

    // ------------------------------------------------------------------
    // Settlement restricted to the live round
    // ------------------------------------------------------------------

    function test_SettleDepositRoundRejectsNonCurrentRoundId() public {
        vm.warp(block.timestamp + 100);
        auctioner.ensureDepositRound();

        vm.prank(alice);
        auctioner.bidDeposit(1000e18, 1050e18);

        vm.expectRevert(VqAuctioner.RoundNotActive.selector);
        auctioner.settleDepositRound(0);

        vm.expectRevert(VqAuctioner.RoundNotActive.selector);
        auctioner.settleDepositRound(2);

        assertEq(auctioner.currentDepositRound(), 1);

        VqAuctioner.Round memory round = auctioner.getDepositRound(1);
        assertFalse(round.settled);
        assertEq(round.highestBidder, alice);
    }

    function test_SettleWithdrawRoundRejectsNonCurrentRoundId() public {
        vm.warp(block.timestamp + 100);
        auctioner.ensureWithdrawRound();

        vm.expectRevert(VqAuctioner.RoundNotActive.selector);
        auctioner.settleWithdrawRound(0);

        vm.expectRevert(VqAuctioner.RoundNotActive.selector);
        auctioner.settleWithdrawRound(2);

        assertEq(auctioner.currentWithdrawRound(), 1);

        VqAuctioner.Round memory round = auctioner.getWithdrawRound(1);
        assertFalse(round.settled);
    }
}
