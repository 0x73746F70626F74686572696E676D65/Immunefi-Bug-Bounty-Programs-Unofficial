<script>
  import settings from '@stores/settings';
  import * as jdenticon from 'jdenticon';

  export let hash;
  export let bgColor = 'red1';
  export let showIndicator = true;

  $: pfp = jdenticon.toSvg(hash || {}, 24);
</script>

<div class="flex flex-row relative">
  <div class="rounded-full overflow-hidden">
    {@html pfp}
  </div>
  <div
    class="absolute border-2 {$settings.invertColors
      ? 'border-grey10inverse'
      : 'border-grey10'} -bottom-0.5 -right-0.5 rounded-full w-2.5 h-2.5 {showIndicator
      ? `bg-${bgColor}`
      : ''}"
  ></div>
</div>
