import type { VaultTypes } from './types';
import { contractWrapper, erc20Contract } from '@helpers/contractWrapper';
import { Signer, BigNumber, ContractTransaction, utils } from 'ethers';
import { VaultConstants } from './constants';
import {
  setPendingWallet,
  setPendingTx,
  setSuccessTx,
  setError,
  setPendingApproval,
} from '@helpers/setToast';
import { limitChecker } from '@stores/v2/vaultActions';

const paramLookup = Object.freeze({
  0: {
    pool: '0x43b4FdFD4Ff969587185cDB6f0BD875c5Fc83f8c',
    poolInputIndex: '0',
    poolOutputIndex: '1',
    yieldToken: '0xdA816459F1AB5631232FE5e97a05BBBb94970c95',
    underlyingToken: '0x6B175474E89094C44Da98b954EedeAC495271d0F',
    abi: 'AutoleverageCurveMetapool',
  },
  1: {
    pool: '0xC4C319E2D4d66CcA4464C0c2B32c9Bd23ebe784e',
    poolInputIndex: '1',
    poolOutputIndex: '0',
    yieldToken: '0xa258C4606Ca8206D8aA700cE2143D7db854D168c',
    underlyingToken: '0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2',
    abi: 'AutoleverageCurveFactoryethpool',
  },
});

export async function hasMigrated(_vaultType: VaultTypes, [_userAddress, _signer]: [string, Signer]) {
  try {
    const { instance: _transferInstance } = await contractWrapper(
      VaultConstants[_vaultType].transferAdapter,
      _signer,
      'ethereum',
    );
    return _transferInstance.hasMigrated(_userAddress);
  } catch (error) {
    setError(error.data ? await error.data.message : error.message, error);
    console.error(`[flashloanActions/hasMigrated]: ${error}`);
    throw Error(error);
  }
}

export async function legacyDeposit(_vaultType: VaultTypes, [_userAddress, _signer]: [string, Signer]) {
  try {
    const { instance: _legacyInstance } = await contractWrapper(
      VaultConstants[_vaultType].legacy,
      _signer,
      'ethereum',
    );
    return _legacyInstance.getCdpTotalDeposited(_userAddress);
  } catch (error) {
    setError(error.data ? await error.data.message : error.message, error);
    console.error(`[flashloanActions/legacyDeposit]: ${error}`);
    throw Error(error);
  }
}

export async function limitCheck(_vaultType: VaultTypes, [userAddress, signer]: [string, Signer]) {
  try {
    const param = paramLookup[_vaultType];
    const { instance: alchemistInstance } = await contractWrapper(
      VaultConstants[_vaultType].alchemistContractSelector,
      signer,
      'ethereum',
    );
    const { instance: legacyInstance } = await contractWrapper(
      VaultConstants[_vaultType].legacy,
      signer,
      'ethereum',
    );
    const openDebt = await legacyInstance.getCdpTotalDebt(userAddress);
    const interest = await legacyInstance.getCdpTotalCredit(userAddress);
    const yieldParams = await alchemistInstance.getYieldTokenParameters(param.yieldToken);
    const expectedValue = yieldParams.expectedValue;
    const mintLimit = await alchemistInstance.getMintLimitInfo();
    const liquidationLimit = await alchemistInstance.getLiquidationLimitInfo(param.underlyingToken);
    return {
      openDebt: openDebt.sub(utils.parseUnits('1', 'gwei')),
      interest,
      expectedValue,
      mintLimit,
      liquidationLimit,
    };
  } catch (error) {
    setError(error.data ? await error.data.message : error.message, error);
    console.error(`[flashloanActions/limitCheck]: ${error}`);
    throw Error(error);
  }
}

async function mintLegacy(_vaultType: VaultTypes, _interest: BigNumber, [signer]: [Signer]) {
  try {
    const { instance: alchemistInstance } = await contractWrapper(
      VaultConstants[_vaultType].legacy,
      signer,
      'ethereum',
    );
    setPendingWallet();
    const tx = (await alchemistInstance.mint(_interest)) as ContractTransaction;
    setPendingTx();
    return await tx.wait().then((transaction) => {
      setSuccessTx(transaction.transactionHash, false);
      return _interest;
    });
  } catch (error) {
    setError(error.data ? await error.data.message : error.message, error);
    console.error(`[flashloanActions/mintLegacy]: ${error}`);
    throw Error(error);
  }
}

async function liquidateLegacy(_vaultType: VaultTypes, _debt: BigNumber, [signer]: [Signer]) {
  try {
    const { instance: alchemistInstance } = await contractWrapper(
      VaultConstants[_vaultType].legacy,
      signer,
      'ethereum',
    );
    setPendingWallet();
    const tx = (await alchemistInstance.liquidate(
      _debt.sub(utils.parseUnits('1', 'gwei')),
    )) as ContractTransaction;
    setPendingTx();
    return await tx.wait().then((transaction) => {
      setSuccessTx(transaction.transactionHash, false);
      return true;
    });
  } catch (error) {
    setError(error.data ? await error.data.message : error.message, error);
    console.error(`[flashloanActions/liquidateLegacy]: ${error}`);
    throw Error(error);
  }
}

export async function sweepLegacy(_vaultType: VaultTypes, [signer]: [Signer]) {
  try {
    const { instance: alchemistInstance } = await contractWrapper(
      VaultConstants[_vaultType].legacy,
      signer,
      'ethereum',
    );
    const param = paramLookup[_vaultType];
    setPendingWallet();
    let tx;
    if (_vaultType === 0) {
      tx = (await alchemistInstance.withdraw(BigNumber.from(1))) as ContractTransaction;
    } else {
      tx = (await alchemistInstance.withdraw(BigNumber.from(1), false)) as ContractTransaction;
    }
    setPendingTx();
    return await tx.wait().then((transaction) => {
      setSuccessTx(transaction.transactionHash);
      return {
        underlying: param.underlyingToken,
        yield: param.yieldToken,
      };
    });
  } catch (error) {
    setError(error.data ? await error.data.message : error.message, error);
    console.error(`[flashloanActions/sweepLegacy]: ${error}`);
  }
}

export async function liquidateWrap(_vaultType: VaultTypes, [userAddress, signer]: [string, Signer]) {
  try {
    const { instance: alchemistInstance } = await contractWrapper(
      VaultConstants[_vaultType].legacy,
      signer,
      'ethereum',
    );
    const debt = await alchemistInstance.getCdpTotalDebt(userAddress);
    const interest = await alchemistInstance.getCdpTotalCredit(userAddress);
    let mintedInterest = BigNumber.from(0);

    if (interest.gt(BigNumber.from(0))) {
      await mintLegacy(_vaultType, interest, [signer]).then((minted) => {
        mintedInterest = minted;
      });
    }

    if (interest.sub(mintedInterest).eq(BigNumber.from(0)) && debt.gt(utils.parseUnits('1', 'gwei'))) {
      await liquidateLegacy(_vaultType, debt, [signer]);
    }

    return true;
  } catch (error) {
    setError(error.data ? await error.data.message : error.message, error);
    console.error(`[flashloanActions/liquidateWrap]: ${error}`);
    throw Error(error);
  }
}

export async function withdrawLegacy(_vaultType: VaultTypes, [userAddress, signer]: [string, Signer]) {
  try {
    const { instance: alchemistInstance } = await contractWrapper(
      VaultConstants[_vaultType].legacy,
      signer,
      'ethereum',
    );
    const debtDust = await alchemistInstance.getCdpTotalDebt(userAddress);
    const deposit = await alchemistInstance.getCdpTotalDeposited(userAddress);
    if (deposit.gt(0)) {
      const payload = {
        0: [deposit.sub(debtDust.mul(2))],
        1: [deposit.sub(debtDust.mul(4)), false],
      };
      const param = paramLookup[_vaultType];
      if (payload[_vaultType][0].gt(0)) {
        setPendingWallet();
        const tx = (await alchemistInstance.withdraw(...payload[_vaultType])) as ContractTransaction;
        setPendingTx();
        return await tx.wait().then((transaction) => {
          setSuccessTx(transaction.transactionHash);
          return {
            withdrawAmount: payload[_vaultType][0],
            underlyingToken: param.underlyingToken,
          };
        });
      }
      return true;
    }
    return true;
  } catch (error) {
    setError(error.data ? await error.data.message : error.message, error);
    console.error(`[flashloanActions/withdrawLegacy]: ${error}`);
    throw Error(error);
  }
}

export async function flashloanDeposit(
  _vaultType: VaultTypes,
  _collateralInitial: BigNumber,
  _targetLTV: BigNumber,
  _slippage: BigNumber,
  [userAddress, signer]: [string, Signer],
) {
  const collateralTotal = _collateralInitial.div(BigNumber.from(100)).mul(_targetLTV).add(_collateralInitial);
  const targetDebt = collateralTotal.sub(_collateralInitial).mul(_slippage).div(BigNumber.from(100000));
  const param = paramLookup[_vaultType];
  try {
    const underlyingTokenInstance = erc20Contract(param.underlyingToken, signer);
    const { instance: flashloanInstance, address: flashloanAddress } = await contractWrapper(
      param.abi,
      signer,
      'ethereum',
    );
    const { instance: alchemistInstance, address: alchemistAddress } = await contractWrapper(
      VaultConstants[_vaultType].alchemistContractSelector,
      signer,
      'ethereum',
    );

    const yieldPerShare = await alchemistInstance.getYieldTokensPerShare(param.yieldToken);
    const underlyingPerShare = await alchemistInstance.getUnderlyingTokensPerShare(param.yieldToken);
    const amountUnderlying = collateralTotal.mul(underlyingPerShare).div(yieldPerShare);

    await limitChecker(amountUnderlying, param.yieldToken, _vaultType, [signer], '0x1');

    const underlyingAllowance = await underlyingTokenInstance.allowanceOf(userAddress, flashloanAddress);
    if (BigNumber.from(underlyingAllowance).lt(collateralTotal)) {
      setPendingApproval();
      const sendApe = (await underlyingTokenInstance.approve(flashloanAddress)) as ContractTransaction;
      await sendApe.wait();
    }
    setPendingApproval();
    const sendApe = (await alchemistInstance.approveMint(
      flashloanAddress,
      collateralTotal,
    )) as ContractTransaction;
    await sendApe.wait();
    setPendingWallet();
    const tx = (await flashloanInstance.autoleverage(
      param.pool,
      param.poolInputIndex,
      param.poolOutputIndex,
      alchemistAddress,
      param.yieldToken,
      _collateralInitial,
      collateralTotal,
      targetDebt,
      {
        gasLimit: BigNumber.from(3000000),
      },
    )) as ContractTransaction;
    setPendingTx();
    return await tx.wait().then((transaction) => {
      setSuccessTx(transaction.transactionHash);
      return {
        underlyingToken: param.underlyingToken,
        alchemistAddress,
        vaultType: _vaultType,
      };
    });
  } catch (error) {
    setError(error.data ? await error.data.message : error.message, error);
    console.error(`[flashloanActions/flashloanDeposit]: ${error}`);
    throw Error(error);
  }
}
