"use client";
import "./chunk-256EKJAK.js";

// node_modules/@rainbow-me/rainbowkit/dist/wallets/walletConnectors/iopayWallet-IJHJ7NYT.js
var iopayWallet_default = 'data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 40 40"><path fill="%23363647" d="M22.302 40q-5.082 0-9.087-2.108c-2.67-1.406-4.783-3.404-6.297-5.993-1.515-2.59-2.272-5.623-2.272-9.137s.757-6.548 2.272-9.137 3.627-4.587 6.297-5.993 5.739-2.109 9.167-2.109 6.457.703 9.127 2.109q3.945 2.109 6.218 5.993c1.514 2.589 2.271 5.623 2.271 9.137s-.757 6.547-2.271 9.137c-1.515 2.589-3.627 4.587-6.258 5.993C28.759 39.297 25.73 40 22.302 40"/><defs><linearGradient id="a" x1=".913" x2=".224" y1="1" y2=".166"><stop offset="0" stop-color="%2344FFB2"/><stop offset=".194" stop-color="rgba(71, 252, 181, 1)"/><stop offset="1" stop-color="%23855EFF"/></linearGradient></defs><path fill="url(%23a)" stroke="%23363647" stroke-miterlimit="8.333" stroke-width=".67" d="M36.829 20.191c0 9.679-8.158 17.548-18.248 17.548S.333 29.87.333 20.191 8.491 2.643 18.581 2.643s18.248 7.869 18.248 17.548Z"/><path fill="%23292936" d="M19.515 25.21c3.109 0 5.58-2.386 5.58-5.303s-2.511-5.304-5.58-5.304-5.58 2.387-5.58 5.304 2.471 5.303 5.58 5.303"/><path fill="%23FFF" stroke="%23343439" stroke-miterlimit="8.333" stroke-width=".4" d="m32.262 11.372 5.261-5c1.149-1.092.888-3.008-.438-4.268C35.76.845 33.763.605 32.624 1.687l-5.261 5.001c-1.148 1.092-.887 3.007.439 4.268 1.324 1.259 3.322 1.499 4.46.416Z"/></svg>';
export {
  iopayWallet_default as default
};
//# sourceMappingURL=iopayWallet-IJHJ7NYT-VB3OJDWZ.js.map
