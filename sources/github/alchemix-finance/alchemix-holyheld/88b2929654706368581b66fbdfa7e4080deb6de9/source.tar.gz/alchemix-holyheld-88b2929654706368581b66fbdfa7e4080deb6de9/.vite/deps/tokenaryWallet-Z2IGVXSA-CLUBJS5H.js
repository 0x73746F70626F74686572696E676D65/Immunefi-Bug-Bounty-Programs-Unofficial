"use client";
import "./chunk-256EKJAK.js";

// node_modules/@rainbow-me/rainbowkit/dist/wallets/walletConnectors/tokenaryWallet-Z2IGVXSA.js
var tokenaryWallet_default = 'data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 28 28"><g clip-path="url(%23a)"><path fill="%23fff" d="M28 0H0v28h28V0Z"/><path fill="%232C7CF5" d="M14 22.941A8.941 8.941 0 1 0 14 5.06a8.941 8.941 0 0 0 0 17.882Z"/></g><defs><clipPath id="a"><path fill="%23fff" d="M0 0h28v28H0z"/></clipPath></defs></svg>';
export {
  tokenaryWallet_default as default
};
//# sourceMappingURL=tokenaryWallet-Z2IGVXSA-CLUBJS5H.js.map
