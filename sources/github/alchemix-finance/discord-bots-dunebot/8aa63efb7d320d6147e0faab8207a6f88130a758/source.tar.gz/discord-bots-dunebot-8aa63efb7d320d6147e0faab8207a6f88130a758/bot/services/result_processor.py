"""Result processing utilities for Dune query results.

Provides functions to filter and sort query results.
"""

from __future__ import annotations

from typing import Any

from bot.services.dune_client import QueryResult
from bot.utils.logging import get_logger


logger = get_logger("services.result_processor")


def filter_top_results_by_amount_usd(
    result: QueryResult,
    limit: int,
) -> QueryResult:
    """Filter and sort query results by amount_usd in descending order.
    
    Returns the top N rows sorted by amount_usd in descending order.
    If fewer rows than the limit exist, returns all available rows.
    If zero rows exist, returns an empty result.
    
    Args:
        result: The QueryResult from Dune query execution.
        limit: Maximum number of rows to return (must be positive).
        
    Returns:
        A new QueryResult with filtered and sorted rows.
        
    Raises:
        ValueError: If limit is not positive.
    """
    if limit <= 0:
        raise ValueError(f"limit must be positive, got: {limit}")
    
    if result.is_empty:
        logger.debug(f"Query {result.query_id} returned no results")
        return result
    
    # Extract and sort rows by amount_usd descending
    rows = result.rows.copy()
    
    # Sort by amount_usd in descending order
    # Handle missing or None values by treating them as 0
    def get_amount_usd(row: dict[str, Any]) -> float:
        """Extract amount_usd from row, defaulting to 0.0 if missing or invalid."""
        value = row.get("amount_usd")
        if value is None:
            return 0.0
        try:
            return float(value)
        except (TypeError, ValueError):
            logger.warning(
                f"Invalid amount_usd value in row: {value}, treating as 0.0"
            )
            return 0.0
    
    # Sort rows by amount_usd descending
    sorted_rows = sorted(rows, key=get_amount_usd, reverse=True)
    
    # Take top N rows
    filtered_rows = sorted_rows[:limit]
    
    logger.info(
        f"Filtered query {result.query_id} results: "
        f"{len(result.rows)} -> {len(filtered_rows)} rows "
        f"(limit={limit}, sorted by amount_usd descending)"
    )
    
    # Create new QueryResult with filtered rows
    return QueryResult(
        query_id=result.query_id,
        execution_id=result.execution_id,
        rows=filtered_rows,
        metadata=result.metadata,
    )

