"""Shared utilities."""




