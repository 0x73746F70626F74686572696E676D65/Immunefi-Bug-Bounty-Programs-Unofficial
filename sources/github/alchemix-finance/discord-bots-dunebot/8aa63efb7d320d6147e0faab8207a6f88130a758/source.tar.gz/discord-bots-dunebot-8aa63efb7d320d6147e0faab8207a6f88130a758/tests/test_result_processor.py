"""Tests for result processor filtering logic."""

import pytest

from bot.services.dune_client import QueryResult
from bot.services.result_processor import filter_top_results_by_amount_usd


class TestFilterTopResultsByAmountUsd:
    """Test filter_top_results_by_amount_usd function."""
    
    def test_sorting_by_amount_usd_descending(self):
        """Test that results are sorted by amount_usd in descending order."""
        result = QueryResult(
            query_id=12345,
            execution_id="exec-1",
            rows=[
                {"amount_usd": 100.0, "name": "A"},
                {"amount_usd": 500.0, "name": "B"},
                {"amount_usd": 200.0, "name": "C"},
                {"amount_usd": 300.0, "name": "D"},
            ],
            metadata={},
        )
        
        filtered = filter_top_results_by_amount_usd(result, limit=4)
        
        assert len(filtered.rows) == 4
        assert filtered.rows[0]["amount_usd"] == 500.0
        assert filtered.rows[1]["amount_usd"] == 300.0
        assert filtered.rows[2]["amount_usd"] == 200.0
        assert filtered.rows[3]["amount_usd"] == 100.0
    
    def test_limiting_to_top_n_rows(self):
        """Test that only top N rows are returned."""
        result = QueryResult(
            query_id=12345,
            execution_id="exec-1",
            rows=[
                {"amount_usd": 100.0, "name": "A"},
                {"amount_usd": 500.0, "name": "B"},
                {"amount_usd": 200.0, "name": "C"},
                {"amount_usd": 300.0, "name": "D"},
            ],
            metadata={},
        )
        
        filtered = filter_top_results_by_amount_usd(result, limit=2)
        
        assert len(filtered.rows) == 2
        assert filtered.rows[0]["amount_usd"] == 500.0
        assert filtered.rows[1]["amount_usd"] == 300.0
    
    def test_fewer_rows_than_limit(self):
        """Test that all rows are returned if fewer than limit exist."""
        result = QueryResult(
            query_id=12345,
            execution_id="exec-1",
            rows=[
                {"amount_usd": 100.0, "name": "A"},
                {"amount_usd": 500.0, "name": "B"},
            ],
            metadata={},
        )
        
        filtered = filter_top_results_by_amount_usd(result, limit=5)
        
        assert len(filtered.rows) == 2
        assert filtered.rows[0]["amount_usd"] == 500.0
        assert filtered.rows[1]["amount_usd"] == 100.0
    
    def test_zero_rows(self):
        """Test that zero rows returns empty result."""
        result = QueryResult(
            query_id=12345,
            execution_id="exec-1",
            rows=[],
            metadata={},
        )
        
        filtered = filter_top_results_by_amount_usd(result, limit=3)
        
        assert len(filtered.rows) == 0
        assert filtered.is_empty
        assert filtered.query_id == 12345
    
    def test_missing_amount_usd_field(self):
        """Test that rows with missing amount_usd are handled gracefully."""
        result = QueryResult(
            query_id=12345,
            execution_id="exec-1",
            rows=[
                {"amount_usd": 100.0, "name": "A"},
                {"name": "B"},  # Missing amount_usd
                {"amount_usd": 500.0, "name": "C"},
                {"amount_usd": None, "name": "D"},  # None value
            ],
            metadata={},
        )
        
        filtered = filter_top_results_by_amount_usd(result, limit=4)
        
        # Rows with missing or None amount_usd should be treated as 0.0
        # So they should appear at the end
        assert len(filtered.rows) == 4
        assert filtered.rows[0]["amount_usd"] == 500.0
        assert filtered.rows[1]["amount_usd"] == 100.0
        # The last two should be the ones with missing/None amount_usd
        assert filtered.rows[2].get("amount_usd") is None or filtered.rows[2].get("amount_usd") == 0.0
        assert filtered.rows[3].get("amount_usd") is None or filtered.rows[3].get("amount_usd") == 0.0
    
    def test_invalid_amount_usd_value(self):
        """Test that invalid amount_usd values are handled gracefully."""
        result = QueryResult(
            query_id=12345,
            execution_id="exec-1",
            rows=[
                {"amount_usd": 100.0, "name": "A"},
                {"amount_usd": "invalid", "name": "B"},  # Invalid value
                {"amount_usd": 500.0, "name": "C"},
            ],
            metadata={},
        )
        
        filtered = filter_top_results_by_amount_usd(result, limit=3)
        
        # Invalid values should be treated as 0.0
        assert len(filtered.rows) == 3
        assert filtered.rows[0]["amount_usd"] == 500.0
        assert filtered.rows[1]["amount_usd"] == 100.0
        # Invalid value should be last
        assert filtered.rows[2]["amount_usd"] == "invalid"
    
    def test_negative_limit_raises_error(self):
        """Test that negative limit raises ValueError."""
        result = QueryResult(
            query_id=12345,
            execution_id="exec-1",
            rows=[{"amount_usd": 100.0, "name": "A"}],
            metadata={},
        )
        
        with pytest.raises(ValueError, match="limit must be positive"):
            filter_top_results_by_amount_usd(result, limit=-1)
    
    def test_zero_limit_raises_error(self):
        """Test that zero limit raises ValueError."""
        result = QueryResult(
            query_id=12345,
            execution_id="exec-1",
            rows=[{"amount_usd": 100.0, "name": "A"}],
            metadata={},
        )
        
        with pytest.raises(ValueError, match="limit must be positive"):
            filter_top_results_by_amount_usd(result, limit=0)
    
    def test_preserves_metadata(self):
        """Test that metadata is preserved in filtered result."""
        result = QueryResult(
            query_id=12345,
            execution_id="exec-1",
            rows=[
                {"amount_usd": 100.0, "name": "A"},
                {"amount_usd": 500.0, "name": "B"},
            ],
            metadata={"state": "completed", "custom": "value"},
        )
        
        filtered = filter_top_results_by_amount_usd(result, limit=2)
        
        assert filtered.metadata == result.metadata
        assert filtered.query_id == result.query_id
        assert filtered.execution_id == result.execution_id
    
    def test_string_amount_usd_values(self):
        """Test that string numeric values are converted correctly."""
        result = QueryResult(
            query_id=12345,
            execution_id="exec-1",
            rows=[
                {"amount_usd": "100.5", "name": "A"},
                {"amount_usd": "500.2", "name": "B"},
                {"amount_usd": "200.0", "name": "C"},
            ],
            metadata={},
        )
        
        filtered = filter_top_results_by_amount_usd(result, limit=3)
        
        assert len(filtered.rows) == 3
        # Values should be sorted correctly even as strings
        assert float(filtered.rows[0]["amount_usd"]) == 500.2
        assert float(filtered.rows[1]["amount_usd"]) == 200.0
        assert float(filtered.rows[2]["amount_usd"]) == 100.5

