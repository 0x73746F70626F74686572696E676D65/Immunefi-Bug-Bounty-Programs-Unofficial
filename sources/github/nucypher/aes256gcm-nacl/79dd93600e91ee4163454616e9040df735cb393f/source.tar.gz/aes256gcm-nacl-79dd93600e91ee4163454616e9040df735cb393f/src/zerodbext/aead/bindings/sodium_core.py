# Copyright 2013 Donald Stufft and individual contributors
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
from __future__ import absolute_import, division, print_function

from zerodbext._aes256gcm_sodium import lib
from zerodbext.aead.exceptions import CryptoError


def sodium_init():
    """
    Initializes sodium, picking the best implementations available for this
    machine.
    """
    if lib.sodium_init() != 0:
        raise CryptoError("Could not initialize sodium")
