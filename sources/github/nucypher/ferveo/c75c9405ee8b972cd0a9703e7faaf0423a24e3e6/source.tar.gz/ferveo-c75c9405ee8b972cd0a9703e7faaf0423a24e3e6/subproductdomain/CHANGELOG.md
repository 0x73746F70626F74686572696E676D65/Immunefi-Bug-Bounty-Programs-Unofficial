# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## v0.4.0 (2025-08-15)

### Chore

 - <csr-id-983110c4dbb41eb7f0fba2c06f561b68718d0f29/> move shared dependencies to workspace crate
 - <csr-id-ca43921af214903e2d1345bb05b5f9c6e1987919/> adjust changelogs for cargo-smart-release

### Commit Statistics

<csr-read-only-do-not-edit/>

 - 42 commits contributed to the release.
 - 2 commits were understood as [conventional](https://www.conventionalcommits.org).
 - 1 unique issue was worked on: [#72](https://github.com/nucypher/ferveo/issues/72)

### Commit Details

<csr-read-only-do-not-edit/>

<details><summary>view details</summary>

 * **[#72](https://github.com/nucypher/ferveo/issues/72)**
    - Refactor subproductdomain ([`2d8026b`](https://github.com/nucypher/ferveo/commit/2d8026b2299fd9b67c77fb3b4e565ff9f4e6505b))
 * **Uncategorized**
    - Merge pull request #188 from nucypher/rocknroll ([`1e66268`](https://github.com/nucypher/ferveo/commit/1e66268dfbfbf76566b4bcf6c25a9852692bb380))
    - Merge pull request #211 from derekpierre/mrkrabs ([`763e06b`](https://github.com/nucypher/ferveo/commit/763e06bb2375e2ded95b409e282ae1f491e16d59))
    - Merge pull request #205 from cygnusv/mrkrabs ([`bb51e96`](https://github.com/nucypher/ferveo/commit/bb51e963f552d2ced387d0ac5c4b311f13715eb4))
    - Update cargo.toml of all ferveo packages for public release. ([`d21ea18`](https://github.com/nucypher/ferveo/commit/d21ea1826f81f47ee88a64dcb98678560e691e57))
    - Update cargo.toml of all ferveo packages for test release. ([`000dc17`](https://github.com/nucypher/ferveo/commit/000dc1715c31f2a32f2366feb6ca652b57d40130))
    - Update wasm-bindgen ([`19e228b`](https://github.com/nucypher/ferveo/commit/19e228b70920b359d93175dfcc5470062832102c))
    - Update cargo.toml of all ferveo packages ([`4e03d43`](https://github.com/nucypher/ferveo/commit/4e03d43255c2fceb729bf2227bff396a25d700c5))
    - Update authors ([`380e984`](https://github.com/nucypher/ferveo/commit/380e9840f0b491da002ff02b863230f5824b500e))
    - Merge pull request #189 from piotr-roslaniec/workspace-deps ([`be98542`](https://github.com/nucypher/ferveo/commit/be9854252fdff297d99a63eb443a473ecfd41f5a))
    - Move shared dependencies to workspace crate ([`983110c`](https://github.com/nucypher/ferveo/commit/983110c4dbb41eb7f0fba2c06f561b68718d0f29))
    - Merge pull request #138 from nucypher/development ([`434fd5d`](https://github.com/nucypher/ferveo/commit/434fd5d07b54e72d120e9aa06cbc3e47848e6bcf))
    - Release ferveo-common-pre-release v0.1.0, subproductdomain-pre-release v0.1.0, group-threshold-cryptography-pre-release v0.1.0, ferveo-pre-release v0.2.0 ([`ffb9b21`](https://github.com/nucypher/ferveo/commit/ffb9b21619d0f5dc0fb309bf2f493d3c0c25e1f0))
    - Release ferveo-common-pre-release v0.1.0, subproductdomain-pre-release v0.1.0, group-threshold-cryptography-pre-release v0.1.0, ferveo-pre-release v0.2.0 ([`a7b889e`](https://github.com/nucypher/ferveo/commit/a7b889e3a20cfffc96bcb801dfb0946227cb32d9))
    - Adjust changelogs for cargo-smart-release ([`ca43921`](https://github.com/nucypher/ferveo/commit/ca43921af214903e2d1345bb05b5f9c6e1987919))
    - Release 0.1.0 crate versions ([`c02e305`](https://github.com/nucypher/ferveo/commit/c02e3050b7a9dcf0260a5eb4e42ff74f3788c3bf))
    - Merge pull request #134 from piotr-roslaniec/remove-ftt-opt ([`2338213`](https://github.com/nucypher/ferveo/commit/23382139265bc043769d41f4da9e0998f9ba9757))
    - Use general evaluation domain ([`2c20efb`](https://github.com/nucypher/ferveo/commit/2c20efb59d7d1075d6b1413b2ae7fbb55c422143))
    - Fix using bad number of domain points ([`d5ec5e0`](https://github.com/nucypher/ferveo/commit/d5ec5e0f9d1303e51a805c4dafbab7ed2efcb7be))
    - Merge pull request #119 from nucypher/nucypher-core-integration ([`52c1f27`](https://github.com/nucypher/ferveo/commit/52c1f27627798fa266d2e5079f5121cc71e8e284))
    - Merge pull request #118 from nucypher/expose-bindings-from-main-crate ([`11d6cea`](https://github.com/nucypher/ferveo/commit/11d6ceaf26f45c76dec0c5a9fcf5eae5301502d3))
    - Release pre-release crates ([`8df87ff`](https://github.com/nucypher/ferveo/commit/8df87ff36ac81bd9e60013cda892d31ddf402868))
    - Update crates to 2021 edition #111 ([`591c05e`](https://github.com/nucypher/ferveo/commit/591c05e64ef9d2f7218418b6aa9d33181c60c88f))
    - Merge pull request #102 from piotr-roslaniec/local-verification-wasm ([`aacdf04`](https://github.com/nucypher/ferveo/commit/aacdf0462d73720e97c1d7924fc49e3d252a691a))
    - Js bindings fail to correctly decrypt the ciphertext ([`ae79060`](https://github.com/nucypher/ferveo/commit/ae790601f691a7727489dbd8606dcd6ed0e4106d))
    - Js bindings fail to correctly decrypt the ciphertext ([`3e7db72`](https://github.com/nucypher/ferveo/commit/3e7db72e5878bfc54b0324c4c79a2a058fc9e0e9))
    - Merge pull request #75 from nucypher/release-ferveo-py ([`2529f74`](https://github.com/nucypher/ferveo/commit/2529f743fe6f07935938cbef81faa0230e478f87))
    - Merge pull request #56 from nucypher/ferveo-light-tdec ([`8fa25b6`](https://github.com/nucypher/ferveo/commit/8fa25b66bf32585b2ef406bbec3999fd9ce75225))
    - Merge pull request #62 from nucypher/client-server-api ([`3a6e3c4`](https://github.com/nucypher/ferveo/commit/3a6e3c4b59c192289f86c0e37f119b29ccd3d620))
    - Merge pull request #67 from nucypher/arkworks-0.4 ([`bd78f97`](https://github.com/nucypher/ferveo/commit/bd78f9741246a2118bf6e3fdf48c72d6adf51b9e))
    - Merge pull request #68 from nucypher/error-handling ([`093f17e`](https://github.com/nucypher/ferveo/commit/093f17e22f606b33a468bd62ad37cf22f3dda265))
    - Merge branch 'error-handling' into tpke-wasm-api-example ([`707f460`](https://github.com/nucypher/ferveo/commit/707f460666acc2781d6dcfa49e0f75f1159f466f))
    - Replace cargo-udeps with cargo-machete ([`9d38a03`](https://github.com/nucypher/ferveo/commit/9d38a03f0f229ff91c5c9d21cc290b30e88ad993))
    - Merge branch 'error-handling' into release-ferveo-py ([`d2a0ca0`](https://github.com/nucypher/ferveo/commit/d2a0ca045beb4dd298f2c06b20b313456a1e81f9))
    - Sketch error handling in ferveo ([`a68d2d9`](https://github.com/nucypher/ferveo/commit/a68d2d9b62414fd06afa234f240508d1c41e68a8))
    - Self review ([`2d926de`](https://github.com/nucypher/ferveo/commit/2d926de9a96a9492063fe4ad69a4dee51d5cae88))
    - Update arkworks to 0.4.0 - first pass ([`b1999b8`](https://github.com/nucypher/ferveo/commit/b1999b86a2b04c719ec29b1263612de88a0cfd49))
    - Fix import style ([`6d92b01`](https://github.com/nucypher/ferveo/commit/6d92b010139b915da1a89ffa686bf24871c7afd1))
    - Merge branch 'main' into use-sha256 ([`fa1c1a8`](https://github.com/nucypher/ferveo/commit/fa1c1a8bf2b338cb379a481d8b042c45af23c470))
    - Merge pull request #27 from nucypher/dkg-pvss-flow ([`e842b8a`](https://github.com/nucypher/ferveo/commit/e842b8a5bb2cafe2e768ca29e5f0210f969ea748))
    - Fix clippy ([`cca3270`](https://github.com/nucypher/ferveo/commit/cca32700b3b13aafab6fcb899f852d3643dddcfd))
    - Fix clippy ([`7cad9ae`](https://github.com/nucypher/ferveo/commit/7cad9aea331ed8e510bca6afd043fe61a466ef08))
</details>

## v0.1.0 (2023-07-07)

<csr-id-ca43921af214903e2d1345bb05b5f9c6e1987919/>

### Chore

 - <csr-id-ca43921af214903e2d1345bb05b5f9c6e1987919/> adjust changelogs for cargo-smart-release

