import { NextResponse } from "next/server";
import { promises as fs } from "fs";
import path from "path";

export async function GET() {
  try {
    const filePath = path.join(
      process.cwd(),
      "docs",
      "SEQUENCE-DIAGRAM-HIGH-LEVEL.md",
    );
    const content = await fs.readFile(filePath, "utf8");

    return new NextResponse(content, {
      headers: {
        "Content-Type": "text/plain; charset=utf-8",
      },
    });
  } catch (error) {
    console.error("Error reading SEQUENCE-DIAGRAM-HIGH-LEVEL.md:", error);
    return NextResponse.json(
      { error: "Failed to read documentation" },
      { status: 500 },
    );
  }
}
