import os

import ape
import pytest
from eth.constants import ZERO_ADDRESS
from eth_account.messages import _hash_eip191_message, encode_defunct
from web3 import Web3

from tests.conftest import ERC1271_INVALID_SIGNATURE, ERC1271_MAGIC_VALUE_BYTES, SigningRitualState

TIMEOUT = 1000
MAX_DKG_SIZE = 20
DURATION = 48 * 60 * 60

OTHER_CHAIN_ID_FOR_BRIDGE = 112233445566

TOTAL_SUPPLY = Web3.to_wei(11_000_000_000, "ether")


@pytest.fixture(scope="module")
def nodes(accounts):
    return sorted(accounts[:MAX_DKG_SIZE], key=lambda x: x.address.lower())


@pytest.fixture(scope="module")
def signers(accounts):
    return sorted(accounts[MAX_DKG_SIZE : 2 * MAX_DKG_SIZE], key=lambda x: x.address.lower())


@pytest.fixture(scope="module")
def initiator(accounts):
    initiator_index = 2 * MAX_DKG_SIZE + 1
    assert len(accounts) >= initiator_index
    return accounts[initiator_index]


@pytest.fixture(scope="module")
def deployer(accounts):
    deployer_index = 2 * MAX_DKG_SIZE + 2
    assert len(accounts) >= deployer_index
    return accounts[deployer_index]


@pytest.fixture()
def token(project, deployer):
    # Create an ERC20 token
    token = deployer.deploy(project.TestToken, TOTAL_SUPPLY)
    return token


@pytest.fixture()
def application(project, oz_dependency, deployer, token, nodes):
    min_auth = Web3.to_wei(40_000, "ether")
    taco_application_impl = deployer.deploy(
        project.TACoApplication,
        token.address,
        min_auth,
        60 * 60 * 24,
    )
    proxy = oz_dependency.TransparentUpgradeableProxy.deploy(
        taco_application_impl.address,
        deployer,
        b"",
        sender=deployer,
    )
    taco_application = project.TACoApplication.at(proxy.address)

    taco_application.initialize(sender=deployer)

    child_application = project.ChildApplicationForTACoApplicationMock.deploy(
        taco_application.address, sender=deployer
    )
    taco_application.setChildApplication(child_application.address, sender=deployer)

    # setup stakes / nodes
    for n in nodes:
        token.transfer(n, min_auth, sender=deployer)
        token.approve(taco_application.address, min_auth, sender=n)
        taco_application.initializeStake(n, n, n, sender=deployer)
        taco_application.bondOperator(n, n, sender=n)
        child_application.confirmOperatorAddress(n, sender=deployer)

    return taco_application


@pytest.fixture()
def signing_coordinator(
    project,
    deployer,
    initiator,
    application,
    oz_dependency,
):
    contract = project.SigningCoordinator.deploy(
        application.address,
        sender=deployer,
    )
    coordinator_proxy = oz_dependency.TransparentUpgradeableProxy.deploy(
        contract.address,
        deployer,
        b"",
        sender=deployer,
    )
    signing_coordinator_proxy = project.SigningCoordinator.at(coordinator_proxy.address)

    # deploy proxied dispatcher
    signing_coordinator_dispatcher = project.SigningCoordinatorDispatcher.deploy(
        signing_coordinator_proxy.address,
        sender=deployer,
    )
    encoded_initializer_function = signing_coordinator_dispatcher.initialize.encode_input()
    dispatcher_proxy = oz_dependency.TransparentUpgradeableProxy.deploy(
        signing_coordinator_dispatcher.address,
        deployer,
        encoded_initializer_function,
        sender=deployer,
    )
    dispatcher_proxy_contract = project.SigningCoordinatorDispatcher.at(dispatcher_proxy.address)

    # initialize signing coordinator proxy
    signing_coordinator_proxy.initialize(
        TIMEOUT,
        MAX_DKG_SIZE,
        dispatcher_proxy_contract.address,
        deployer.address,
        sender=deployer,
    )

    signing_coordinator_proxy.grantRole(
        signing_coordinator_proxy.INITIATOR_ROLE(), initiator, sender=deployer
    )

    return signing_coordinator_proxy


def _signing_coordinator_child_deployment(project, oz_dependency, deployer, allowed_caller):
    contract = project.SigningCoordinatorChild.deploy(
        sender=deployer,
    )
    proxy = oz_dependency.TransparentUpgradeableProxy.deploy(
        contract.address,
        deployer,
        b"",
        sender=deployer,
    )
    proxy_contract = project.SigningCoordinatorChild.at(proxy.address)

    threshold_signing_multisig = project.ThresholdSigningMultisig.deploy(
        sender=deployer,
    )
    signing_factory_contract = project.ThresholdSigningMultisigCloneFactory.deploy(
        threshold_signing_multisig.address,
        proxy_contract.address,
        sender=deployer,
    )

    proxy_contract.initialize(signing_factory_contract.address, allowed_caller, sender=deployer)

    return proxy_contract


@pytest.fixture()
def signing_coordinator_child(chain, project, oz_dependency, deployer, signing_coordinator):
    signing_coordinator_dispatcher = project.SigningCoordinatorDispatcher.at(
        signing_coordinator.signingCoordinatorDispatcher()
    )

    _signing_coordinator_child = _signing_coordinator_child_deployment(
        project, oz_dependency, deployer, signing_coordinator_dispatcher.address
    )

    # don't need a L1Sender for the same chain as signing coordinator
    # current chain
    signing_coordinator_dispatcher.register(
        chain.chain_id, ZERO_ADDRESS, _signing_coordinator_child.address, sender=deployer
    )

    return _signing_coordinator_child


@pytest.fixture()
def mock_bridge_contracts(project, deployer, signing_coordinator):
    mock_bridge_messenger = deployer.deploy(project.MockOpBridgeMessenger)

    l1_sender = deployer.deploy(
        project.OpL1Sender,
        signing_coordinator.signingCoordinatorDispatcher(),
        mock_bridge_messenger.address,
        500_000,
    )

    l2_receiver = deployer.deploy(project.OpL2Receiver, mock_bridge_messenger.address)
    l2_receiver.initialize(l1_sender.address, sender=deployer)

    l1_sender.initialize(l2_receiver.address, sender=deployer)
    mock_bridge_messenger.initialize(l1_sender.address, sender=deployer)

    yield mock_bridge_messenger, l1_sender, l2_receiver


@pytest.fixture()
def other_chain_signing_coordinator_child(
    project, oz_dependency, deployer, signing_coordinator, mock_bridge_contracts
):
    _, l1_sender, l2_receiver = mock_bridge_contracts

    signing_coordinator_dispatcher = project.SigningCoordinatorDispatcher.at(
        signing_coordinator.signingCoordinatorDispatcher()
    )

    _other_signing_coordinator_child = _signing_coordinator_child_deployment(
        project, oz_dependency, deployer, l2_receiver.address
    )

    # need a L1Sender for the other chain
    signing_coordinator_dispatcher.register(
        OTHER_CHAIN_ID_FOR_BRIDGE,
        l1_sender.address,
        _other_signing_coordinator_child.address,
        sender=deployer,
    )

    return _other_signing_coordinator_child


#
# Signing
#


def test_signing_ritual(
    project,
    chain,
    deployer,
    initiator,
    nodes,
    signers,
    signing_coordinator,
    signing_coordinator_child,
    other_chain_signing_coordinator_child,
):
    threshold = len(nodes) // 2 + 1
    tx = signing_coordinator.initiateSigningCohort(
        chain.chain_id, initiator, nodes, threshold, DURATION, sender=initiator
    )

    signing_cohort_id = 0
    events = [event for event in tx.events if event.event_name == "InitiateSigningCohort"]
    assert len(events) == 1
    event = events[0]
    assert event.cohortId == signing_cohort_id
    assert event.authority == initiator
    assert event.chainId == chain.chain_id
    assert event.participants == [n.address for n in nodes]

    signing_cohort_struct = signing_coordinator.signingCohorts(signing_cohort_id)
    assert signing_cohort_struct["initiator"] == initiator
    init, end = signing_cohort_struct[1], signing_cohort_struct["endTimestamp"]
    assert end - init == DURATION
    assert signing_cohort_struct["authority"] == initiator
    assert signing_cohort_struct["totalSignatures"] == 0

    assert signing_cohort_struct["numSigners"] == len(nodes)
    assert signing_cohort_struct["threshold"] == threshold

    assert signing_coordinator.getChains(signing_cohort_id) == [chain.chain_id]

    for n in nodes:
        assert signing_coordinator.isSigner(signing_cohort_id, n.address)
        assert not signing_coordinator.getSigner(
            signing_cohort_id, n.address
        ).signingRequestStaticKey

    assert (
        signing_coordinator.getSigningCohortState(signing_cohort_id)
        == SigningRitualState.AWAITING_SIGNATURES
    )

    signable_message = None

    # submit signatures
    signing_request_static_keys = [os.urandom(42) for _ in nodes]
    for i, node in enumerate(nodes):
        signer = signers[i]
        data_hash = signing_coordinator.getSigningCohortDataHash(signing_cohort_id, node.address)
        signable_message = encode_defunct(data_hash)
        signature = signer.sign_message(signable_message).encode_rsv()
        tx = signing_coordinator.postSigningCohortData(
            signing_cohort_id, signature, signing_request_static_keys[i], sender=node
        )

        events = [
            event for event in tx.events if event.event_name == "SigningCohortSignaturePosted"
        ]
        assert events == [
            signing_coordinator.SigningCohortSignaturePosted(
                cohortId=signing_cohort_id, provider=node, signer=signer, signature=signature
            )
        ]

    events = [event for event in tx.events if event.event_name == "SigningCohortDeployed"]
    assert events == [
        signing_coordinator.SigningCohortDeployed(
            cohortId=signing_cohort_id,
            chainId=chain.chain_id,
        )
    ]

    assert signing_coordinator.getSigningCohortState(signing_cohort_id) == SigningRitualState.ACTIVE
    assert signing_coordinator.isCohortActive(signing_cohort_id)

    # submit conditions
    time_condition = (
        b'{"version": "1.0.0", "condition": {"chain": 80002, "method": "blocktime", '
        b'"returnValueTest": {"comparator": ">", "value": 0}, "conditionType": "time"}}'
    )

    tx = signing_coordinator.setSigningCohortConditions(
        signing_cohort_id, chain.chain_id, time_condition, sender=initiator
    )
    events = [event for event in tx.events if event.event_name == "SigningCohortConditionsSet"]
    assert events == [
        signing_coordinator.SigningCohortConditionsSet(
            cohortId=signing_cohort_id,
            chainId=chain.chain_id,
            conditions=time_condition,
        )
    ]

    assert signing_coordinator.getSigningCohortState(signing_cohort_id) == SigningRitualState.ACTIVE
    assert signing_coordinator.isCohortActive(signing_cohort_id)

    for i, node in enumerate(nodes):
        assert signing_coordinator.isSigner(signing_cohort_id, node.address)
        signer = signing_coordinator.getSigner(signing_cohort_id, node.address)
        assert signer.provider == node.address
        assert signer.signerAddress == signers[i]
        assert signer.signingRequestStaticKey == signing_request_static_keys[i]

    # check deployed multisig
    assert (
        signing_coordinator.getSigningCoordinatorChild(chain.chain_id)
        == signing_coordinator_child.address
    )
    expected_multisig_address = project.ThresholdSigningMultisigCloneFactory.at(
        signing_coordinator_child.signingMultisigFactory()
    ).getCloneAddress(signing_cohort_id)
    assert signing_coordinator_child.cohortMultisigs(signing_cohort_id) == expected_multisig_address

    cohort_multisig = project.ThresholdSigningMultisig.at(expected_multisig_address)
    assert cohort_multisig.getSigners() == [n.address for n in signers]
    assert cohort_multisig.threshold() == threshold
    assert cohort_multisig.owner() == signing_coordinator_child.address

    # ensure signatures are valid for deployed cohort multisig
    submitted_signatures = []
    data_hash = signing_coordinator.getSigningCohortDataHash(signing_cohort_id, node.address)
    signable_message = encode_defunct(data_hash)

    # submit signatures
    for i, node in enumerate(nodes):
        signer = signers[i]
        signature = signer.sign_message(signable_message).encode_rsv()
        submitted_signatures.append(signature)

    data_hash = _hash_eip191_message(signable_message)

    # signatures must be all unique (no repeats)
    repeated_signature = b"".join([submitted_signatures[0]] * threshold)
    assert (
        cohort_multisig.isValidSignature(data_hash, repeated_signature) == ERC1271_INVALID_SIGNATURE
    )

    assert (
        cohort_multisig.isValidSignature(data_hash, b"".join(submitted_signatures[:threshold]))
        == ERC1271_MAGIC_VALUE_BYTES
    )

    #
    # deploy multisig to another chain (cross-chain test)
    #

    # deploy multisig to another chain
    tx = signing_coordinator.deployAdditionalChainForSigningMultisig(
        OTHER_CHAIN_ID_FOR_BRIDGE, signing_cohort_id, sender=initiator
    )
    events = [event for event in tx.events if event.event_name == "SigningCohortDeployed"]
    assert events == [
        signing_coordinator.SigningCohortDeployed(
            cohortId=signing_cohort_id,
            chainId=OTHER_CHAIN_ID_FOR_BRIDGE,
        )
    ]
    # new chain added
    assert signing_coordinator.getChains(signing_cohort_id) == [
        chain.chain_id,
        OTHER_CHAIN_ID_FOR_BRIDGE,
    ]

    # try deploying to same chain again
    with ape.reverts("Already deployed"):
        signing_coordinator.deployAdditionalChainForSigningMultisig(
            chain.chain_id, signing_cohort_id, sender=initiator
        )

    with ape.reverts("Already deployed"):
        signing_coordinator.deployAdditionalChainForSigningMultisig(
            OTHER_CHAIN_ID_FOR_BRIDGE, signing_cohort_id, sender=initiator
        )

    tx = signing_coordinator.setSigningCohortConditions(
        signing_cohort_id, OTHER_CHAIN_ID_FOR_BRIDGE, time_condition, sender=initiator
    )
    events = [event for event in tx.events if event.event_name == "SigningCohortConditionsSet"]
    assert events == [
        signing_coordinator.SigningCohortConditionsSet(
            cohortId=signing_cohort_id,
            chainId=OTHER_CHAIN_ID_FOR_BRIDGE,
            conditions=time_condition,
        )
    ]
    assert (
        signing_coordinator.getSigningCohortConditions(signing_cohort_id, OTHER_CHAIN_ID_FOR_BRIDGE)
        == time_condition
    )

    # try setting conditions for undeployed chain
    with ape.reverts("Not already deployed"):
        signing_coordinator.setSigningCohortConditions(
            signing_cohort_id, 999999, time_condition, sender=initiator
        )

    assert (
        signing_coordinator.getSigningCoordinatorChild(OTHER_CHAIN_ID_FOR_BRIDGE)
        == other_chain_signing_coordinator_child.address
    )
    other_chain_expected_multisig_address = project.ThresholdSigningMultisigCloneFactory.at(
        other_chain_signing_coordinator_child.signingMultisigFactory()
    ).getCloneAddress(signing_cohort_id)
    assert (
        other_chain_signing_coordinator_child.cohortMultisigs(signing_cohort_id)
        == other_chain_expected_multisig_address
    )

    # extend duration
    additional_duration = 60 * 60 * 24

    with ape.reverts("Cohort not active"):
        signing_coordinator.extendSigningCohortDuration(999, additional_duration, sender=deployer)

    with ape.reverts("Invalid duration"):
        signing_coordinator.extendSigningCohortDuration(signing_cohort_id, 0, sender=deployer)

    current_end = signing_coordinator.signingCohorts(signing_cohort_id)["endTimestamp"]
    tx = signing_coordinator.extendSigningCohortDuration(
        signing_cohort_id, additional_duration, sender=deployer
    )
    updated_end_timestamp = signing_coordinator.signingCohorts(signing_cohort_id)["endTimestamp"]
    assert updated_end_timestamp == current_end + additional_duration
    events = [event for event in tx.events if event.event_name == "SigningCohortExtended"]
    assert events == [
        signing_coordinator.SigningCohortExtended(
            cohortId=signing_cohort_id,
            endTimestamp=updated_end_timestamp,
        )
    ]

    # transfer cohort authority
    with ape.reverts("Cohort is not active"):
        signing_coordinator.transferCohortAuthority(999, deployer.address, sender=initiator)

    with ape.reverts("Invalid new authority"):
        signing_coordinator.transferCohortAuthority(
            signing_cohort_id, "0x" + "0" * 40, sender=initiator
        )

    with ape.reverts("Sender not cohort authority"):
        signing_coordinator.transferCohortAuthority(
            signing_cohort_id, deployer.address, sender=deployer
        )

    tx = signing_coordinator.transferCohortAuthority(
        signing_cohort_id, deployer.address, sender=initiator
    )
    events = [event for event in tx.events if event.event_name == "CohortAuthorityTransferred"]
    assert events == [
        signing_coordinator.CohortAuthorityTransferred(
            cohortId=signing_cohort_id,
            previousAuthority=initiator.address,
            newAuthority=deployer.address,
        )
    ]
    assert signing_coordinator.getAuthority(signing_cohort_id) == deployer.address
    with ape.reverts("Sender not cohort authority"):
        # initiator no longer authority and can't set conditions
        tx = signing_coordinator.setSigningCohortConditions(
            signing_cohort_id, chain.chain_id, time_condition, sender=initiator
        )

    tx = signing_coordinator.setSigningCohortConditions(
        # deployer can set conditions
        signing_cohort_id,
        chain.chain_id,
        time_condition,
        sender=deployer,
    )
    events = [event for event in tx.events if event.event_name == "SigningCohortConditionsSet"]
    assert events == [
        signing_coordinator.SigningCohortConditionsSet(
            cohortId=signing_cohort_id,
            chainId=chain.chain_id,
            conditions=time_condition,
        )
    ]
