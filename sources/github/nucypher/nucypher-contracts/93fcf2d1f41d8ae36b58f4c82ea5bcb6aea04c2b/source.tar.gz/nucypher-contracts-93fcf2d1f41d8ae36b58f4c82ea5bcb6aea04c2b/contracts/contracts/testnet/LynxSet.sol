// SPDX-License-Identifier: AGPL-3.0-or-later

pragma solidity ^0.8.0;

import "@openzeppelin/contracts/access/Ownable.sol";
import "@openzeppelin/contracts/token/ERC20/ERC20.sol";

import "../coordination/ITACoRootToChild.sol";
import "../coordination/ITACoChildToRoot.sol";
import "../coordination/TACoChildApplication.sol";
import "../TACoApplication.sol";

//       [Sepolia]                              <--------->             [Amoy]
//
// TACoApplication <---> MockPolygonRoot |   <deployer_account>   | MockPolygonChild <--> TACoChildApplication
//

contract MockPolygonRoot is Ownable, ITACoChildToRoot, ITACoRootToChild {
    ITACoChildToRoot public rootApplication;

    constructor(ITACoChildToRoot _rootApplication) Ownable(msg.sender) {
        require(
            address(_rootApplication) != address(0),
            "Address for root application must be specified"
        );
        rootApplication = _rootApplication;
    }

    function setRootApplication(ITACoChildToRoot application) external onlyOwner {
        rootApplication = application;
    }

    function confirmOperatorAddress(address operator) external override onlyOwner {
        rootApplication.confirmOperatorAddress(operator);
    }

    function penalize(address _stakingProvider) external override onlyOwner {
        rootApplication.penalize(_stakingProvider);
    }

    function rootRelease(address _stakingProvider) external onlyOwner {
        rootApplication.release(_stakingProvider);
    }

    function release(
        address _stakingProvider
    )
        external
        override(ITACoChildToRoot, ITACoRootToChild)
    // solhint-disable-next-line no-empty-blocks
    {

    }

    // solhint-disable-next-line no-empty-blocks
    function updateOperator(address stakingProvider, address operator) external {}

    // solhint-disable-next-line no-empty-blocks
    function updateAuthorization(address stakingProvider, uint96 authorized) external {}

    function updateAuthorization(
        address stakingProvider,
        uint96 authorized,
        uint96 deauthorizing,
        uint64 endDeauthorization // solhint-disable-next-line no-empty-blocks
    ) external {}
}

contract MockPolygonChild is Ownable, ITACoChildToRoot, ITACoRootToChild {
    ITACoRootToChild public childApplication;

    constructor() Ownable(msg.sender) {}

    function setChildApplication(ITACoRootToChild _childApplication) external onlyOwner {
        childApplication = _childApplication;
    }

    function updateOperator(
        address _stakingProvider,
        address _operator
    ) external override onlyOwner {
        childApplication.updateOperator(_stakingProvider, _operator);
    }

    function updateAuthorization(
        address _stakingProvider,
        uint96 _amount
    ) external override onlyOwner {
        childApplication.updateAuthorization(_stakingProvider, _amount);
    }

    function updateAuthorization(
        address _stakingProvider,
        uint96 _authorized,
        uint96 _deauthorizing,
        uint64 _endDeauthorization
    ) external override onlyOwner {
        childApplication.updateAuthorization(
            _stakingProvider,
            _authorized,
            _deauthorizing,
            _endDeauthorization
        );
    }

    function childRelease(address _stakingProvider) external {
        childApplication.release(_stakingProvider);
    }

    // solhint-disable-next-line no-empty-blocks
    function confirmOperatorAddress(address _operator) external override {}

    // solhint-disable-next-line no-empty-blocks
    function penalize(address _stakingProvider) external override {}

    function release(
        address _stakingProvider
    )
        external
        override(ITACoChildToRoot, ITACoRootToChild)
    // solhint-disable-next-line no-empty-blocks
    {

    }
}

contract LynxRitualToken is ERC20("LynxRitualToken", "LRT") {
    constructor(uint256 _totalSupplyOfTokens) {
        _mint(msg.sender, _totalSupplyOfTokens);
    }
}

contract LynxStakingToken is ERC20("LynxStakingToken", "LST") {
    constructor(uint256 _totalSupplyOfTokens) {
        _mint(msg.sender, _totalSupplyOfTokens);
    }
}

contract LynxTACoApplication is TACoApplication {
    constructor(
        IERC20 _token,
        uint96 _minimumAuthorization,
        uint256 _minOperatorSeconds
    ) TACoApplication(_token, _minimumAuthorization, _minOperatorSeconds) {}

    /**
     * Admin function to set information for a stake in testnet
     */
    function adminSetExistingStake(
        address _stakingProvider,
        address _owner,
        address _beneficiary
    ) external onlyOwner {
        require(
            _stakingProvider != address(0) && _owner != address(0) && _beneficiary != address(0),
            "Parameters are empty"
        );
        StakingProviderInfo storage info = stakingProviderInfo[_stakingProvider];
        require(
            _stakingProviderFromOperator[_stakingProvider] == address(0),
            "Staker is an operator"
        );

        info.owner = _owner;
        info.beneficiary = _beneficiary;
        info.authorized = minimumAuthorization;
        info.stakeless = false;
        emit Staked(_stakingProvider, _owner, _beneficiary, info.authorized);
        _updateAuthorization(_stakingProvider, info);
    }

    /**
     * Admin function to set a existing stake in testnet as stakeless
     */
    function adminSetToStakeless(address _stakingProvider) external onlyOwner {
        require(_stakingProvider != address(0), "Parameters are empty");
        StakingProviderInfo storage info = stakingProviderInfo[_stakingProvider];

        info.beneficiary = address(0);
        info.authorized = minimumAuthorization;
        info.stakeless = true;
        _updateAuthorization(_stakingProvider, info);
    }
}
