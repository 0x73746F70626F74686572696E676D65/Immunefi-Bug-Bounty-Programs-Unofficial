# ⚠️ Inactive Project

The NuCypher organization is no longer active and will not continue development or maintenance of this code base. The code remains available for reference and historical purposes, but no updates, fixes, or support should be expected.

_The original TACo project is expected to be forked and relaunched by the World Ethical Data Forum (WEDF) in the latter half of 2026, supported by a coalition of node operators drawn from organizations with deep experience in privacy advocacy, anti-surveillance technologies, human rights, encryption, whistleblower protection, and academic research._

# Protocol structures of TACo Network

This repo contains Rust implementation of the protocol classes that can be shared between Python server and JS clients of the TACo Network.

* [Rust](https://github.com/nucypher/nucypher-core/tree/main/nucypher-core) (primary) [![crate][rust-crate-image]][rust-crate-link] [![Docs][rust-docs-image]][rust-docs-link] ![License][rust-license-image] [![Build Status][rust-build-image]][rust-build-link] [![Coverage][rust-coverage-image]][rust-coverage-link]
* [JavaScript](https://github.com/nucypher/nucypher-core/tree/main/nucypher-core-wasm) (WASM-based) [![npm package][js-npm-image]][js-npm-link] ![License][js-license-image]
* [Python](https://github.com/nucypher/nucypher-core/tree/main/nucypher-core-python) [![pypi package][pypi-image]][pypi-link] [![Docs][rtd-image]][rtd-link] ![License][pypi-license-image]

[rust-crate-image]: https://img.shields.io/crates/v/nucypher-core.svg
[rust-crate-link]: https://crates.io/crates/nucypher-core
[rust-docs-image]: https://docs.rs/nucypher-core/badge.svg
[rust-docs-link]: https://docs.rs/nucypher-core/
[rust-license-image]: https://img.shields.io/crates/l/nucypher-core
[rust-build-image]: https://github.com/nucypher/nucypher-core/workflows/nucypher-core/badge.svg?branch=main&event=push
[rust-build-link]: https://github.com/nucypher/nucypher-core/actions?query=workflow%3Anucypher-core
[rust-coverage-image]: https://codecov.io/gh/nucypher/nucypher-core/branch/main/graph/badge.svg
[rust-coverage-link]: https://codecov.io/gh/nucypher/nucypher-core
[js-npm-image]: https://img.shields.io/npm/v/@nucypher/nucypher-core
[js-npm-link]: https://www.npmjs.com/package/@nucypher/nucypher-core
[js-license-image]: https://img.shields.io/npm/l/@nucypher/nucypher-core
[pypi-image]: https://img.shields.io/pypi/v/nucypher-core
[pypi-link]: https://pypi.org/project/nucypher-core/
[pypi-license-image]: https://img.shields.io/pypi/l/nucypher-core
[rtd-image]: https://readthedocs.org/projects/nucypher-core/badge/?version=latest
[rtd-link]: https://nucypher-core.readthedocs.io/en/latest/

## Ensure Correct Rust Version

A Rust toolchain with version `>= 1.87.0` is required. You can use [rustup](https://rustup.rs/) to manage and switch between Rust versions. To install the required version, run:
```bash
rustup install <version>
rustup override set <version>
```
Replace `<version>` with the relevant version.


## Build and Test

Run the following commands to ensure everything is working correctly:
- `cargo build`
- `cargo test`
