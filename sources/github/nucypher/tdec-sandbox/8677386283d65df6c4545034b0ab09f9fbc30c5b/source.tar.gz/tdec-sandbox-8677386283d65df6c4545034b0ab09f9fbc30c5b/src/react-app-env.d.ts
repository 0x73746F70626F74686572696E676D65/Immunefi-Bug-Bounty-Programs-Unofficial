interface Window {
  ethereum: any
}