class WrongKeyError(Exception):
    pass
