![](nucypher.png)

# ⚠️ Inactive Project

The NuCypher organization is no longer active and will not continue development or maintenance of this code base. The code remains available for reference and historical purposes, but no updates, fixes, or support should be expected.

_The original TACo project is expected to be forked and relaunched by the World Ethical Data Forum (WEDF) in the latter half of 2026, supported by a coalition of node operators drawn from organizations with deep experience in privacy advocacy, anti-surveillance technologies, human rights, encryption, whistleblower protection, and academic research._

----

*Cryptographic primitives, hosted on the decentralized nodes of the TACo network, offering accessible, intuitive, and extensible runtimes and interfaces for
secrets management and dynamic access control.*

[![pypi](https://img.shields.io/pypi/v/nucypher.svg?style=flat)](https://pypi.org/project/nucypher/)
[![pyversions](https://img.shields.io/pypi/pyversions/nucypher.svg)](https://pypi.org/project/nucypher/)
[![codecov](https://codecov.io/gh/nucypher/nucypher/branch/development/graph/badge.svg?token=9w1dAFqog5)](https://codecov.io/gh/nucypher/nucypher)
[![discord](https://img.shields.io/discord/411401661714792449.svg?logo=discord)](https://discord.gg/7rmXa3S)
[![license](https://img.shields.io/pypi/l/nucypher.svg)](https://www.gnu.org/licenses/gpl-3.0.html)

----

# Threshold Access Control (TACo)

TACo is end-to-end encrypted data sharing and communication, without the requirement of
trusting a centralized authority, who might unilaterally deny service or even decrypt private user data. It is the only
access control layer available to Web3 developers that can offer a decentralized service, through a live,
well-collateralized and battle-tested network.

See more in the [TACo docs](https://docs.taco.build/).

# Getting Involved

NuCypher is a community-driven project and we're very open to outside contributions.

All our development discussions happen in our [Discord server](https://discord.gg/buildwithtaco), where we're happy to answer
technical questions, discuss feature requests,
and accept bug reports.

If you're interested in contributing code, please check out
our [Contribution Guide](CONTRIBUTING.rst)
and browse our [Open Issues](https://github.com/nucypher/nucypher/issues) for potential areas to contribute.

# Security

If you identify vulnerabilities with _any_ nucypher code, please email security@nucypher.com with relevant information
to your findings.
We will work with researchers to coordinate vulnerability disclosure between our stakers, partners, and users to ensure
successful mitigation of vulnerabilities.

Throughout the reporting process, we expect researchers to honor an embargo period that may vary depending on the
severity of the disclosure.
This ensures that we have the opportunity to fix any issues, identify further issues (if any), and inform our users.

Sometimes vulnerabilities are of a more sensitive nature and require extra precautions.
We are happy to work together to use a more secure medium, such as Signal.
Email security@nucypher.com and we will coordinate a communication channel that we're both comfortable with.

A great place to begin your research is by working on our testnet.
Please see our [documentation](https://docs.threshold.network) to get started.
We ask that you please respect testnet machines and their owners.
If you find a vulnerability that you suspect has given you access to a machine against the owner's permission, stop what
you're doing and immediately email security@nucypher.com.

# Cryptography Notice

This distribution includes cryptographic software. The country in which you currently reside may have restrictions on the import, possession, use, and/or re-export to another country of encryption software. BEFORE using any encryption software, please check your country's laws, regulations and policies concerning the import, possession, or use, and re-export of encryption software, to see if this is permitted. See http://www.wassenaar.org/ for more information.

This software may be subject to the U.S. Export Administration Regulations
(EAR), including ECCN 5D002, which covers information security software using or performing cryptographic functions with asymmetric algorithms. The source code is publicly available and is
intended to qualify for treatment under EAR §742.15 and §734.3(b)(3).

The project maintainers have submitted notification of this source code to:
- crypt@bis.doc.gov
- enc@nsa.gov

The maintainers make no representation regarding your ability to import, export, or use this software in compliance with the laws of your jurisdiction. Users are responsible for complying with all applicable laws and regulations.
