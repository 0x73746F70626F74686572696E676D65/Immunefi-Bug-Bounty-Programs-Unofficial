#!/usr/bin/env bash
set -euo pipefail

# Usage: scripts/prepare-pages.sh <category>
# category: "daily" or "analysis"

CATEGORY="${1:?Usage: prepare-pages.sh <daily|analysis>}"
SITE_DIR="_site"

mkdir -p "$SITE_DIR/daily" "$SITE_DIR/analysis"

# Copy new reports into the right category
cp results/reports/*.html "$SITE_DIR/$CATEGORY/" 2>/dev/null || true

# Fetch existing gh-pages content and merge in
git fetch origin gh-pages:gh-pages 2>/dev/null || true
for dir in daily analysis; do
  if git show "gh-pages:$dir/" >/dev/null 2>&1; then
    for f in $(git ls-tree --name-only "gh-pages:$dir/"); do
      if [ ! -f "$SITE_DIR/$dir/$f" ]; then
        git show "gh-pages:$dir/$f" > "$SITE_DIR/$dir/$f" 2>/dev/null || true
      fi
    done
  fi
done

# Parse filename into: date, mode, rate, duration, cohort
# New format: 2026-02-16-163106_steady_1rps_10s_c3.html  (underscore-delimited metadata)
# Old format: 2026-02-16-163106.html
parse_filename() {
  local fname="$1"
  local base="${fname%.html}"

  # Date/time is always the first 17 chars: 2026-02-16-163106
  local datetime="${base:0:17}"
  if echo "$datetime" | grep -qE '^[0-9]{4}-[0-9]{2}-[0-9]{2}-[0-9]{6}$'; then
    local year="${datetime:0:4}"
    local month="${datetime:5:2}"
    local day="${datetime:8:2}"
    local hour="${datetime:11:2}"
    local min="${datetime:13:2}"
    local months=("" "Jan" "Feb" "Mar" "Apr" "May" "Jun" "Jul" "Aug" "Sep" "Oct" "Nov" "Dec")
    local mi=$((10#$month))
    F_DATE="${day} ${months[$mi]} ${year}, ${hour}:${min}"
  else
    F_DATE="$base"
    F_MODE="" ; F_RATE="" ; F_DURATION="" ; F_COHORT="" ; F_NETWORK=""
    return
  fi

  # Metadata: everything after timestamp, separated by underscores
  local rest="${base:17}"
  rest="${rest#_}"  # strip leading underscore
  F_MODE="" ; F_RATE="" ; F_DURATION="" ; F_COHORT="" ; F_NETWORK=""

  if [ -z "$rest" ]; then
    return
  fi

  local IFS='_'
  local parts=($rest)
  unset IFS
  for part in "${parts[@]}"; do
    if [[ "$part" =~ ^(steady|sweep|burst)$ ]]; then
      F_MODE="$part"
    elif [[ "$part" =~ ^([0-9.]+)rps$ ]]; then
      F_RATE="${BASH_REMATCH[1]} req/s"
    elif [[ "$part" =~ ^([0-9]+)s$ ]]; then
      F_DURATION="${BASH_REMATCH[1]}s"
    elif [[ "$part" =~ ^c([0-9]+)$ ]]; then
      local cid="${BASH_REMATCH[1]}"
      case "$cid" in
        1) F_COHORT="minimal" ;;
        3) F_COHORT="discord" ;;
        4) F_COHORT="discord" ;;
        *) F_COHORT="cohort $cid" ;;
      esac
    elif [[ "$part" =~ ^(devnet|mainnet)$ ]]; then
      case "$part" in
        devnet)  F_NETWORK="testnet" ;;
        mainnet) F_NETWORK="mainnet" ;;
      esac
    fi
  done
}

# Generate a table of report rows for a category
# Args: $1=category dir path, $2=url prefix
generate_rows() {
  local dir="$1"
  local prefix="$2"
  local files
  files=$(ls "$dir/"*.html 2>/dev/null | xargs -I{} basename {} | sort -r || true)
  if [ -z "$files" ]; then
    echo '<tr><td colspan="6" class="empty">No reports yet.</td></tr>'
    return
  fi
  for f in $files; do
    parse_filename "$f"
    echo "<tr>"
    echo "  <td><a href=\"${prefix}${f}\">${F_DATE}</a></td>"
    echo "  <td>${F_MODE:--}</td>"
    echo "  <td>${F_RATE:--}</td>"
    echo "  <td>${F_DURATION:--}</td>"
    echo "  <td>${F_COHORT:--}</td>"
    echo "  <td>${F_NETWORK:--}</td>"
    echo "</tr>"
  done
}

# Build index.html
cat > "$SITE_DIR/index.html" << 'HTMLEOF'
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>TACo Performance</title>
<link rel="icon" type="image/svg+xml" href="data:image/svg+xml,%3Csvg%20id%3D%22Calque_1%22%20data-name%3D%22Calque%201%22%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20viewBox%3D%220%200%20512%20512%22%3E%0A%20%20%3Cdefs%3E%0A%20%20%20%20%3Cstyle%3E%0A%20%20%20%20%20%20.cls-1%20%7B%0A%20%20%20%20%20%20%20%20fill%3A%20%23fff%3B%0A%20%20%20%20%20%20%7D%0A%20%20%20%20%3C%2Fstyle%3E%0A%20%20%3C%2Fdefs%3E%0A%20%20%3Crect%20class%3D%22cls-1%22%20x%3D%2270.93%22%20y%3D%22105.16%22%20width%3D%2217.78%22%20height%3D%22301.71%22%2F%3E%0A%20%20%3Crect%20class%3D%22cls-1%22%20x%3D%22423.29%22%20y%3D%22105.16%22%20width%3D%2217.78%22%20height%3D%22301.71%22%2F%3E%0A%20%20%3Crect%20class%3D%22cls-1%22%20x%3D%22105.15%22%20y%3D%22423.29%22%20width%3D%22301.69%22%20height%3D%2217.78%22%2F%3E%0A%20%20%3Crect%20class%3D%22cls-1%22%20x%3D%22105.15%22%20y%3D%2270.93%22%20width%3D%22301.69%22%20height%3D%2217.78%22%2F%3E%0A%20%20%3Cpath%20class%3D%22cls-1%22%20d%3D%22M301.47%2C189.34h-33.94v144.95c0%2C7.39-3.23%2C11.54-11.54%2C11.54s-11.54-4.15-11.54-11.54v-144.95h-33.92c-6.38%2C0-11.54-5.17-11.54-11.54h0c0-6.38%2C5.17-11.54%2C11.54-11.54h90.94c6.38%2C0%2C11.54%2C5.17%2C11.54%2C11.54h0c0%2C6.38-5.17%2C11.54-11.54%2C11.54Z%22%2F%3E%0A%3C%2Fsvg%3E">
<style>
  * { margin: 0; padding: 0; box-sizing: border-box; }
  body {
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', system-ui, sans-serif;
    background: #000;
    color: #e0e0e0;
    min-height: 100vh;
  }
  .container { max-width: 960px; margin: 0 auto; padding: 3em 2em; }
  .header { display: flex; align-items: center; gap: 1.5em; margin-bottom: 0.5em; }
  .header svg { height: 72px; width: auto; }
  .header h1 { color: #fff; font-size: 2em; font-weight: 400; letter-spacing: 0.05em; }
  .subtitle { color: #666; font-size: 1em; margin-bottom: 3em; }
  h2 {
    color: #96FF5E;
    font-size: 0.9em;
    font-weight: 600;
    letter-spacing: 0.15em;
    text-transform: uppercase;
    margin-bottom: 0.75em;
  }
  .section { margin-bottom: 3em; }
  table { width: 100%; border-collapse: collapse; table-layout: fixed; }
  th:nth-child(1) { width: 35%; }
  th:nth-child(2), th:nth-child(3), th:nth-child(4), th:nth-child(5), th:nth-child(6) { width: 13%; }
  thead th {
    text-align: left;
    color: #666;
    font-size: 0.8em;
    font-weight: 500;
    letter-spacing: 0.08em;
    text-transform: uppercase;
    padding: 0.6em 1em;
    border-bottom: 1px solid #222;
  }
  tbody tr { border-bottom: 1px solid #111; transition: background 0.15s; }
  tbody tr:hover { background: #0a0a0a; }
  tbody td {
    padding: 0.75em 1em;
    font-size: 1em;
    color: #999;
  }
  tbody td:first-child { color: #ccc; }
  tbody td a {
    color: #ccc;
    text-decoration: none;
    transition: color 0.15s;
  }
  tbody td a:hover { color: #96FF5E; }
  .empty { color: #444; font-style: italic; text-align: center; padding: 1.5em 1em; }
  .footer { margin-top: 3em; padding-top: 1.5em; border-top: 1px solid #1a1a1a; color: #444; font-size: 0.85em; }
  .footer a { color: #666; }
</style>
</head>
<body>
<div class="container">
<div class="header">
<svg width="301" height="128" viewBox="0 0 301 128" fill="none" xmlns="http://www.w3.org/2000/svg">
<g clip-path="url(#clip0_2309_654)">
<path d="M35.9287 40.8643H33V86.8327H35.9287V40.8643Z" fill="white"/>
<path d="M93.9414 40.8643H91.0127V86.8327H93.9414V40.8643Z" fill="white"/>
<path d="M151.964 40.8643H149.035V86.8327H151.964V40.8643Z" fill="white"/>
<path d="M209.977 40.8643H207.048V86.8327H209.977V40.8643Z" fill="white"/>
<path d="M267.999 40.8643H265.07V86.8327H267.999V40.8643Z" fill="white"/>
<path d="M86.4775 33.4H40.4727V36.3252H86.4775V33.4Z" fill="white"/>
<path d="M144.492 33.4H98.4873V36.3252H144.492V33.4Z" fill="white"/>
<path d="M202.513 33.4H156.508V36.3252H202.513V33.4Z" fill="white"/>
<path d="M260.527 33.4H214.522V36.3252H260.527V33.4Z" fill="white"/>
<path d="M86.4775 91.3719H40.4727V94.2971H86.4775V91.3719Z" fill="white"/>
<path d="M144.492 91.3719H98.4873V94.2971H144.492V91.3719Z" fill="white"/>
<path d="M202.513 91.3719H156.508V94.2971H202.513V91.3719Z" fill="white"/>
<path d="M260.527 91.3719H214.522V94.2971H260.527V91.3719Z" fill="white"/>
<path d="M61.5334 76.8008V52.7666H54.6479C53.6563 52.7666 52.876 51.9872 52.876 50.9968V50.8501C52.876 49.8598 53.6563 49.0803 54.6479 49.0803H72.3117C73.3032 49.0803 74.0835 49.8598 74.0835 50.8501V50.9968C74.0835 51.9872 73.3032 52.7666 72.3117 52.7666H65.4261V76.8008C65.4261 77.837 64.6457 78.6164 63.5257 78.6164H63.443C62.3413 78.6164 61.5426 77.837 61.5426 76.8008H61.5334Z" fill="white"/>
<path d="M110.88 76.7551C110.88 76.4525 110.926 76.1315 111.027 75.7923L117.747 52.0148C118.234 50.2634 119.519 49.0621 121.318 49.0621C123.118 49.0621 124.321 50.2634 124.844 52.0148L132.023 75.8564C132.115 76.1682 132.161 76.4708 132.161 76.7459C132.161 77.8555 131.445 78.6257 130.224 78.6257H130.095C129.232 78.6257 128.571 78.2223 128.305 77.2961L126.781 72.3627H116.113L114.672 77.3878C114.414 78.2498 113.744 78.6349 112.946 78.6349H112.817C111.523 78.6349 110.88 77.8646 110.88 76.7643V76.7551ZM125.762 68.6581L121.346 53.4637H121.217L117.013 68.6581H125.762Z" fill="white"/>
<path d="M175.118 75.3154L171.317 68.4747C170.325 66.7049 170.096 65.3936 170.096 63.8348C170.096 62.2759 170.334 60.9646 171.317 59.1948L175.118 52.3541C176.109 50.5843 177.358 49.0621 179.974 49.0621H187.245C188.255 49.0621 189.017 49.8416 189.017 50.8319V50.9786C189.017 51.969 188.255 52.7484 187.245 52.7484H180.571C179.68 52.7484 179.175 52.9593 178.358 54.4357L174.897 60.6345C174.264 61.7716 174.007 62.661 174.007 63.8164C174.007 64.9718 174.264 65.8613 174.897 67.0075L178.358 73.2064C179.185 74.6827 179.69 74.8936 180.571 74.8936H187.245C188.255 74.8936 189.017 75.6731 189.017 76.6634V76.8101C189.017 77.8005 188.255 78.5799 187.245 78.5799H179.974C177.358 78.5799 176.109 77.0577 175.118 75.2879V75.3154Z" fill="white"/>
<path d="M230.771 59.7818L231.937 58.874C233.103 57.9662 234.141 57.526 235.784 57.526H239.42C241.063 57.526 242.1 57.9662 243.266 58.874L244.432 59.7818C246.269 61.2215 246.902 62.1018 246.902 64.275V71.8768C246.902 74.0501 246.269 74.9396 244.432 76.3701L243.266 77.2779C242.1 78.1857 241.063 78.6258 239.42 78.6258H235.784C234.132 78.6258 233.103 78.1857 231.937 77.2779L230.771 76.3701C228.935 74.9304 228.302 74.0501 228.302 71.8768V64.275C228.302 62.1018 228.935 61.2123 230.771 59.7818ZM233.094 73.6283L233.709 74.1143C234.49 74.7286 235.105 74.9396 236.16 74.9396H239.034C240.09 74.9396 240.696 74.7286 241.485 74.1143L242.1 73.6283C243.138 72.803 243.386 72.2344 243.386 70.8865V65.247C243.386 63.899 243.138 63.3489 242.1 62.5236L241.485 62.0376C240.705 61.4232 240.09 61.2123 239.034 61.2123H236.16C235.105 61.2123 234.49 61.4232 233.709 62.0376L233.094 62.5236C232.057 63.3489 231.809 63.899 231.809 65.247V70.8865C231.809 72.2344 232.066 72.8121 233.094 73.6283Z" fill="white"/>
</g>
<defs>
<clipPath id="clip0_2309_654">
<rect width="235" height="60.897" fill="white" transform="translate(33 33.4)"/>
</clipPath>
</defs>
</svg>
<h1>Performance</h1>
</div>
<p class="subtitle">Threshold signing network health &amp; analysis reports</p>
HTMLEOF

# Daily section
{
  echo '<div class="section">'
  echo '<h2>Daily Health Checks</h2>'
  echo '<table><thead><tr><th>Date</th><th>Mode</th><th>Rate</th><th>Duration</th><th>Condition</th><th>Network</th></tr></thead><tbody>'
  generate_rows "$SITE_DIR/daily" "daily/"
  echo '</tbody></table></div>'
} >> "$SITE_DIR/index.html"

# Analysis section
{
  echo '<div class="section">'
  echo '<h2>Ad-hoc Analysis</h2>'
  echo '<table><thead><tr><th>Date</th><th>Mode</th><th>Rate</th><th>Duration</th><th>Condition</th><th>Network</th></tr></thead><tbody>'
  generate_rows "$SITE_DIR/analysis" "analysis/"
  echo '</tbody></table></div>'
} >> "$SITE_DIR/index.html"

cat >> "$SITE_DIR/index.html" << 'HTMLEOF'
<div class="footer">
  <a href="https://github.com/nucypher/taco-performance">nucypher/taco-performance</a>
</div>
</div>
</body>
</html>
HTMLEOF

touch "$SITE_DIR/.nojekyll"

echo "[prepare-pages] Done. Category: $CATEGORY"
