interface Window {
  ethereum: any;
}
