#!/bin/bash

pytest
