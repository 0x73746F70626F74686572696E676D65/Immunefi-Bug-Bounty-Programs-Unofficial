// SPDX-License-Identifier: MIT
pragma solidity >=0.7.6 <0.9.0;

interface IWETH {
  function deposit() external payable;

  function withdraw(uint256 wad) external;

  function approve(address guy, uint256 wad) external returns (bool);

  function transfer(address dst, uint256 wad) external returns (bool);

  function balanceOf(address user) external view returns (uint256);
}
