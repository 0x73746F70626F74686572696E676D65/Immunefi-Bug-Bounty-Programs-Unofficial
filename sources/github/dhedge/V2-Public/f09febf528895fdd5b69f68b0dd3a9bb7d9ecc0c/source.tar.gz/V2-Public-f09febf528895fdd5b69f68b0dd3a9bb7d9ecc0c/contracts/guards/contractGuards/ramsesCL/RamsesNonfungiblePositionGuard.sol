// SPDX-License-Identifier: MIT
pragma solidity 0.7.6;
pragma experimental ABIEncoderV2;

import {SafeMath} from "@openzeppelin/contracts/math/SafeMath.sol";
import {IMulticall} from "@uniswap/v3-periphery/contracts/interfaces/IMulticall.sol";

import {ITxTrackingGuard} from "../../../interfaces/guards/ITxTrackingGuard.sol";
import {IRamsesNonfungiblePositionManager} from "../../../interfaces/ramses/IRamsesNonfungiblePositionManager.sol";
import {UniswapV3PriceLibrary} from "../../../utils/uniswap/UniswapV3PriceLibrary.sol";
import {IPoolManagerLogic} from "../../../interfaces/IPoolManagerLogic.sol";
import {IPoolLogic} from "../../../interfaces/IPoolLogic.sol";
import {IHasSupportedAsset} from "../../../interfaces/IHasSupportedAsset.sol";
import {IUniswapV3Factory} from "@uniswap/v3-core/contracts/interfaces/IUniswapV3Factory.sol";
import {IRamsesGaugeV2} from "../../../interfaces/ramses/IRamsesGaugeV2.sol";
import {IHasAssetInfo} from "../../../interfaces/IHasAssetInfo.sol";
import {IRamsesVoter} from "../../../interfaces/ramses/IRamsesVoter.sol";
import {NftTrackerConsumerGuard} from "../shared/NftTrackerConsumerGuard.sol";

/// @title Transaction guard for Ramses CL NonfungiblePositionManager contract
contract RamsesNonfungiblePositionGuard is NftTrackerConsumerGuard, ITxTrackingGuard {
  using SafeMath for uint256;

  bool public override isTxTrackingGuard = true;

  /// @notice Initialiser for the contract
  /// @dev Set up the position count limit and the nft tracker
  /// @param _maxPositions Velodrome Cl liquidity position count limit
  /// @param _nftTracker Address of the DhedgeNftTrackerStorage
  constructor(
    uint256 _maxPositions,
    address _nftTracker
  ) NftTrackerConsumerGuard(_nftTracker, keccak256("RAMSES_CL_NFT_TYPE"), _maxPositions) {}

  /// @notice Transaction guard for Ramses CL non-fungible Position Manager
  /// @dev Parses the manager transaction data to ensure transaction is valid
  /// @param poolManagerLogic address
  /// @param data Transaction call data attempt by manager
  /// @return txType transaction type described in PoolLogic
  /// @return isPublic if the transaction is public or private
  function txGuard(
    address poolManagerLogic,
    address to,
    bytes memory data
  ) public view override returns (uint16 txType, bool) {
    bytes4 method = getMethod(data);
    bytes memory params = getParams(data);
    address pool = IPoolManagerLogic(poolManagerLogic).poolLogic();
    address factory = IPoolLogic(pool).factory();

    if (method == IRamsesNonfungiblePositionManager.mint.selector) {
      IRamsesNonfungiblePositionManager.MintParams memory mintParams = abi.decode(
        params,
        (IRamsesNonfungiblePositionManager.MintParams)
      );

      require(IHasSupportedAsset(poolManagerLogic).isSupportedAsset(mintParams.token0), "unsupported asset: tokenA");
      require(IHasSupportedAsset(poolManagerLogic).isSupportedAsset(mintParams.token1), "unsupported asset: tokenB");
      require(IHasSupportedAsset(poolManagerLogic).isSupportedAsset(to), "ramses cl asset not enabled");
      require(mintParams.veRamTokenId == 0, "veRamTokenId must be 0"); // CL Boosting deprecated
      require(pool == mintParams.recipient, "recipient is not pool");

      address ramsesFactory = IRamsesNonfungiblePositionManager(to).factory();
      // can use UniswapV3PriceLibrary
      UniswapV3PriceLibrary.assertFairPrice(
        factory,
        ramsesFactory,
        mintParams.token0,
        mintParams.token1,
        mintParams.fee
      );

      IRamsesVoter voter = IRamsesVoter(IRamsesNonfungiblePositionManager(to).voter());
      IRamsesGaugeV2 gauge = IRamsesGaugeV2(
        voter.gauges(IUniswapV3Factory((ramsesFactory)).getPool(mintParams.token0, mintParams.token1, mintParams.fee))
      );
      address[] memory rewardTokens = gauge.getRewardTokens();
      for (uint256 i = 0; i < rewardTokens.length; ++i) {
        // staking-equivalent checks
        if (IHasAssetInfo(factory).isValidAsset(rewardTokens[i])) {
          require(IHasSupportedAsset(poolManagerLogic).isSupportedAsset(rewardTokens[i]), "reward asset not enabled");
        }
      }

      txType = uint16(TransactionType.RamsesCLMint);
    } else if (method == IRamsesNonfungiblePositionManager.increaseLiquidity.selector) {
      IRamsesNonfungiblePositionManager.IncreaseLiquidityParams memory increaseLiquidityParams = abi.decode(
        params,
        (IRamsesNonfungiblePositionManager.IncreaseLiquidityParams)
      );

      // validate token id from nft tracker
      bool isValidTokenId = isValidOwnedTokenId(pool, increaseLiquidityParams.tokenId);
      require(isValidTokenId, "position is not in track");

      (, , address token0, address token1, uint24 fee, , , , , , , ) = IRamsesNonfungiblePositionManager(to).positions(
        increaseLiquidityParams.tokenId
      );

      // can use UniswapV3PriceLibrary
      UniswapV3PriceLibrary.assertFairPrice(
        factory,
        IRamsesNonfungiblePositionManager(to).factory(),
        token0,
        token1,
        fee
      );

      txType = uint16(TransactionType.RamsesCLIncreaseLiquidity);
    } else if (method == IRamsesNonfungiblePositionManager.decreaseLiquidity.selector) {
      txType = uint16(TransactionType.RamsesCLDecreaseLiquidity);
    } else if (method == IRamsesNonfungiblePositionManager.burn.selector) {
      txType = uint16(TransactionType.RamsesCLBurn);
    } else if (method == IRamsesNonfungiblePositionManager.collect.selector) {
      IRamsesNonfungiblePositionManager.CollectParams memory collectParams = abi.decode(
        params,
        (IRamsesNonfungiblePositionManager.CollectParams)
      );
      (, , address token0, address token1, , , , , , , , ) = IRamsesNonfungiblePositionManager(to).positions(
        collectParams.tokenId
      );

      require(IHasSupportedAsset(poolManagerLogic).isSupportedAsset(token0), "unsupported asset: tokenA");
      require(IHasSupportedAsset(poolManagerLogic).isSupportedAsset(token1), "unsupported asset: tokenB");
      require(pool == collectParams.recipient, "recipient is not pool");

      txType = uint16(TransactionType.RamsesCLCollect);
    } else if (method == IRamsesNonfungiblePositionManager.getReward.selector) {
      uint256 tokenId = abi.decode(params, (uint256));

      bool isValidTokenId = isValidOwnedTokenId(pool, tokenId);
      require(isValidTokenId, "position is not in track");

      txType = uint16(TransactionType.RamsesCLGetReward);
    } else if (method == IMulticall.multicall.selector) {
      bytes[] memory multicallParams = abi.decode(params, (bytes[]));

      for (uint256 i = 0; i < multicallParams.length; i++) {
        (txType, ) = txGuard(poolManagerLogic, to, multicallParams[i]);
        require(txType > 0, "invalid transaction");
      }

      txType = uint16(TransactionType.RamsesCLMulticall);
    }
    return (txType, false);
  }

  /// @notice This function is called after execution transaction (used to track transactions)
  /// @dev Necessary for tracking minted NFT tokenIds and removing them upon burning the NFT position
  /// @dev Can be called only by PoolLogic during execTransaction
  /// @param poolManagerLogic Pool manager logic address
  /// @param to Ramses CL NonfungiblePositionManager address
  /// @param data Transaction data
  function afterTxGuard(address poolManagerLogic, address to, bytes memory data) public override {
    _afterTxGuardHandle(poolManagerLogic, to, data);
  }

  function _afterTxGuardHandle(
    address poolManagerLogic,
    address to,
    bytes memory data
  ) internal returns (bool isMintOrBurn) {
    address poolLogic = _accessControl(poolManagerLogic);
    bytes4 method = getMethod(data);

    if (method == IRamsesNonfungiblePositionManager.mint.selector) {
      uint256 index = IRamsesNonfungiblePositionManager(to).totalSupply();
      nftTracker.addUintId(
        to,
        nftType,
        poolLogic,
        IRamsesNonfungiblePositionManager(to).tokenByIndex(index - 1), // revert if index is zero
        positionsLimit
      );

      return true;
    } else if (method == IRamsesNonfungiblePositionManager.burn.selector) {
      uint256 tokenId = abi.decode(getParams(data), (uint256));

      // validate token id from nft tracker
      bool isValidTokenId = isValidOwnedTokenId(poolLogic, tokenId);
      require(isValidTokenId, "position is not in track");

      nftTracker.removeUintId(to, nftType, poolLogic, tokenId);

      return true;
    } else if (method == IMulticall.multicall.selector) {
      bytes[] memory params = abi.decode(getParams(data), (bytes[]));

      bool includeMintOrBurn;
      for (uint256 i = 0; i < params.length; i++) {
        if (_afterTxGuardHandle(poolManagerLogic, to, params[i])) {
          require(!includeMintOrBurn, "invalid multicall");
          includeMintOrBurn = true;
        }
      }

      return includeMintOrBurn;
    }

    return false;
  }
}
