// SPDX-License-Identifier: BUSL-1.1

pragma solidity ^0.7.6;
pragma experimental ABIEncoderV2;

import {Order} from "./IGmxOrder.sol";

interface IGmxBaseOrderUtils {
  // @dev CreateOrderParams struct used in createOrder to avoid stack
  // too deep errors
  //
  // @param addresses address values
  // @param numbers number values
  // @param orderType for order.orderType
  // @param decreasePositionSwapType for order.decreasePositionSwapType
  // @param isLong for order.isLong
  // @param shouldUnwrapNativeToken for order.shouldUnwrapNativeToken
  // @param dataList a list of bytes32 values that can be used for additional data
  // @note all params except should be part of the corresponding struct hash in all relay contracts
  struct CreateOrderParams {
    CreateOrderParamsAddresses addresses;
    CreateOrderParamsNumbers numbers;
    Order.OrderType orderType;
    Order.DecreasePositionSwapType decreasePositionSwapType;
    bool isLong;
    bool shouldUnwrapNativeToken;
    bool autoCancel;
    bytes32 referralCode;
    bytes32[] dataList;
  }

  // @note all params except should be part of the corresponding struct hash in all relay contracts
  struct CreateOrderParamsAddresses {
    address receiver;
    address cancellationReceiver;
    address callbackContract;
    address uiFeeReceiver;
    address market;
    address initialCollateralToken;
    address[] swapPath;
  }

  // @param sizeDeltaUsd for order.sizeDeltaUsd
  // @param triggerPrice for order.triggerPrice
  // @param acceptablePrice for order.acceptablePrice
  // @param executionFee for order.executionFee
  // @param callbackGasLimit for order.callbackGasLimit
  // @param minOutputAmount for order.minOutputAmount
  // @param validFromTime for order.validFromTime
  // @note all params except should be part of the corresponding struct hash in all relay contracts
  struct CreateOrderParamsNumbers {
    uint256 sizeDeltaUsd;
    uint256 initialCollateralDeltaAmount;
    uint256 triggerPrice;
    uint256 acceptablePrice;
    uint256 executionFee;
    uint256 callbackGasLimit;
    uint256 minOutputAmount;
    uint256 validFromTime;
  }
}
