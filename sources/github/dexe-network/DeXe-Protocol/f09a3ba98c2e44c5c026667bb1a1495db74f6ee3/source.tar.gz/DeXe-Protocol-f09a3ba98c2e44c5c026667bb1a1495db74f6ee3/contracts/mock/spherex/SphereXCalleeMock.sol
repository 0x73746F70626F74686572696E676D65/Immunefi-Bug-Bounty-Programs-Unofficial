// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

contract SphereXCalleeMock {
    function protectedMethod() external {}
}
