# Changelog

All notable changes to SSV Network contracts will be documented in this file.

This project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).


## [Released]
### [v2.0.0] 2026-03-23

Major protocol upgrade introducing ETH-based accounting, effective-balance-aware fee charging, SSV staking, and the legacy SSV-to-ETH migration path.

See also:

- [RELEASE_NOTES.md](RELEASE_NOTES.md)
- [docs/SPEC.md](docs/SPEC.md)
- [docs/FLOWS.md](docs/FLOWS.md)
- [docs/UPGRADE_PLAYBOOK.md](docs/UPGRADE_PLAYBOOK.md)

#### Added

- ETH-based cluster accounting for new clusters
- Effective-balance-aware fee accounting through `vUnits`
- Oracle-committed Merkle root flow for effective balance updates
- SSV staking with `cSSV`, including stake, unstake-request, unlock-withdraw, fee sync, and ETH reward claim flows
- One-way `migrateClusterToETH` flow for legacy SSV clusters
- Expanded deployment, SAFE-batch, attestation, smoke-test, and verification tooling for staged and mainnet rollout

#### Changed

- New clusters now use ETH as the fee asset instead of SSV
- Legacy SSV clusters continue in a restricted compatibility mode rather than as full-featured pre-upgrade clusters
- ETH cluster solvency, liquidation, and fee burn are now tied to effective balance rather than flat validator-count-only charging
- Environment-driven operations are centered on `just` recipes and `deployments/<env>/config.json`
- The repository documentation is reorganized around architecture, setup, tasks, local development, roles, operators, specification, flows, and upgrade playbooks

#### Behavioral changes

- Depositing into a liquidated ETH cluster is allowed
- Withdrawing from a liquidated ETH cluster is allowed
- Reactivation can depend on a stale on-chain effective balance snapshot until the next valid EB update
- Removed operators may be skipped during migration or reactivation flows, allowing continued operation with reduced operator coverage where valid

#### Operational notes

- The production upgrade path is designed around the `v1.2.0 -> v2.0.0` rollout
- Mainnet rollout uses the repository deployment scripts, deployment attestation, and SAFE batch generation flow
- Post-upgrade verification is part of the intended release process, not an optional follow-up step

### [v1.2.0] 2024-07-01
- [b7cfe2f] (https://github.com/ssvlabs/ssv-network/commit/11b4e67) - Support for mulitple whitelist addresses for operators (see [docs/operators.md](docs/operators.md)).
- [b7cfe2f] (https://github.com/ssvlabs/ssv-network/commit/11b4e67) - Support for external whitelisting contracts (see [docs/operators.md](docs/operators.md)).
- [11b4e67] (https://github.com/ssvlabs/ssv-network/commit/11b4e67) - Set the privacy status when registering an operator (see [docs/operators.md](docs/operators.md)).
- [add2434] (https://github.com/ssvlabs/ssv-network/commit/add2434) - [Fix] Check MINIMAL_OPERATOR_FEE in reduceOperatorFee function.

### [v1.1.1] 2024-04-17
- [3c12e52](https://github.com/ssvlabs/ssv-network/commit/3c12e52) - [Fix] Revert when passing an empty public keys list.

### [v1.1.0] 2024-01-08
- [c80dc3b](https://github.com/bloxapp/ssv-network/commit/c80dc3b) - [Feature] Bulk exit of validators.
- [6431a00](https://github.com/bloxapp/ssv-network/commit/6431a00) - [Feature] Bulk removal of validators.
- [9c609cd](https://github.com/bloxapp/ssv-network/commit/9c609cd) - [Feature] Bulk registration of validators.
- [c9a90b1](https://github.com/bloxapp/ssv-network/commit/c9a90b1) - [Update] Added triggers for compilation in a few tasks (upgrading / updating).
- [4471f05](https://github.com/bloxapp/ssv-network/commit/4471f05) - [Update] Deployment tests and update task and documentation.
- [7564dfe](https://github.com/bloxapp/ssv-network/commit/7564dfe) - [Feature] Integration ssv-keys in ssv-network for generating keyshares.
- [8647401](https://github.com/bloxapp/ssv-network/commit/8647401) - [Update]: Configuration for publishing npm package.

### [v1.0.2] 2023-11-08
- [8f5df42](https://github.com/bloxapp/ssv-network/commit/8f5df42633d2b92c6bb70253a41e6afa80b9f111) - Change ValidatorExited signature: owner indexed.

### [v1.0.1] 2023-11-08
#### Added
- [0ab954e](https://github.com/bloxapp/ssv-network/commit/0ab954ec24fc0b32b51c278958c3d51480940f1a) - Permissionless audited version.


### [v1.0.0-rc3-permissionless-validators] 2023-11-08
Takes v1.0.0-rc3 as the base tag.
- [8878241](https://github.com/bloxapp/ssv-network/commit/88782410ad3223c75f205484811a010231c64152) Enable permissionless validator registration.


### [v1.0.0] - 2023-10-30

#### Fixed
- [22d2859](https://github.com/bloxapp/ssv-network/pull/262/commits/22d2859d8fe6267b09c7a1c9c645df19bdaa03ff) Fix bug in network earnings withdrawals.
- [d25d188](https://github.com/bloxapp/ssv-network/pull/265/commits/d25d18886459e631fb4453df7a47db19982ec80e) Fix Types.shrink() bug.

#### Added
- [bf0c51d](https://github.com/bloxapp/ssv-network/pull/263/commits/bf0c51d4df191018052d11425c9fcc252de61431) A validator can voluntarily exit.


### [v1.0.0.rc4] - 2023-08-31

- Audit fixes/recommendations
- Validate a cluster with 0 validators can not be liquidated
- Deployment process now uses hardhat tasks
- The DAO can set a maximum operator fee (SSV)
- Remove the setRegisterAuth function (register operator/validator without restrictions)
- SSVNetworkViews contract does not throw an error as a way of return.
