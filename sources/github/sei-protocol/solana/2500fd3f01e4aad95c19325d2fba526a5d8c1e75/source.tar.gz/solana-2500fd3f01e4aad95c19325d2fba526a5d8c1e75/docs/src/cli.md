---
title: Command-line Guide
---

In this section, we will describe how to use the Solana command-line tools to
create a _wallet_, to send and receive SOL tokens, and to participate in
the cluster by delegating stake.

To interact with a Solana cluster, we will use its command-line interface, also
known as the CLI. We use the command-line because it is the first place the
Solana core team deploys new functionality. The command-line interface is not
necessarily the easiest to use, but it provides the most direct, flexible, and
secure access to your Solana accounts.

## Getting Started

To get started using the Solana Command Line (CLI) tools:

- [Install the Solana Tools](cli/install-solana-cli-tools.md)
- [Choose a Cluster](cli/choose-a-cluster.md)
- [Create a Wallet](wallet-guide/cli.md)
- [Check out our CLI conventions](cli/conventions.md)
