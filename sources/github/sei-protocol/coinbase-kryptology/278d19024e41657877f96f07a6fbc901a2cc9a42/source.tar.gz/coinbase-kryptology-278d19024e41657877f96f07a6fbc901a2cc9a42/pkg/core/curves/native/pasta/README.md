# Pallas and Pasta curve
