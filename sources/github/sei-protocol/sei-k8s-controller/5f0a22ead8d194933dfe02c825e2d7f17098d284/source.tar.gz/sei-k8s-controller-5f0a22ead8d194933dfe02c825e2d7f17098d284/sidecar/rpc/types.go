package rpc

// StatusResult is the inner "result" of the CometBFT /status response,
// after the JSON-RPC envelope has been stripped by Client.Get.
type StatusResult struct {
	NodeInfo NodeInfo `json:"node_info"`
	SyncInfo SyncInfo `json:"sync_info"`
}

// NodeInfo identifies a CometBFT node.
type NodeInfo struct {
	ID string `json:"id"`
	// Network is the chain ID the node is configured for; CometBFT's
	// protocol term. Compared against task params.chainId for the
	// chain-confusion guard in sidecar/tasks/sign_and_broadcast.go.
	Network string `json:"network"`
}

// SyncInfo reports chain sync state.
type SyncInfo struct {
	LatestBlockHeight string `json:"latest_block_height"`
	CatchingUp        bool   `json:"catching_up"`
}

// BlockResult is the inner "result" of the CometBFT /block response.
type BlockResult struct {
	BlockID BlockID `json:"block_id"`
}

// BlockID identifies a block by hash.
type BlockID struct {
	Hash string `json:"hash"`
}
