//go:build integration

// Package integration holds the Sei nightly integration suites as plain `go test`
// targets. Every suite the nightly schedule runs is named TestNightly<Suite>
// (TestNightlyBenchmark, TestNightlyChaosSuite, TestNightlyChainUpgrade,
// TestNightlyRelease, TestNightlyWorkflowStateSync, TestNightlyGigaStoreMigration,
// TestNightlyGigaMixedRelease); a new suite joins the nightly schedule by taking
// that name, with no other wiring required. TestGenesisCeremonyProducesBlocks is
// the one suite deliberately outside the prefix — an onboarding-validation check,
// run standalone, never nightly. Orchestration within one run is statement order
// in one process; cross-step state is local Go values, not external config. A
// suite whose required image can't be the shared SEID_IMAGE default (a different
// flavor, or a pinned version pair) reads its own env var name, since one process
// has one environment.
//
// Everything lives in *_test.go behind //go:build integration, so it never links
// into a production binary and is excluded from the default `go test ./...`. The
// nightly compiles it once (go test -c -tags integration) and runs the whole set
// in one in-cluster CronJob (-test.run '^TestNightly').
//
// Depends on sdk/sei (+ the k8s provider blank import), api/v1alpha1 (public API
// types, for reading status.plan), and k8s.io/apimachinery/.../metav1 (for a
// condition constant); never internal/seitask or internal/taskruntime.
package integration

import (
	"context"
	"errors"
	"fmt"
	"maps"
	"net/http"
	"net/url"
	"os"
	"regexp"
	"strconv"
	"strings"
	"sync/atomic"
	"testing"
	"time"

	"github.com/sei-protocol/sei-k8s-controller/sdk/sei"

	// Register the k8s provisioning provider for the SDK (database/sql-style
	// blank import; sei.Open(ctx, "k8s") needs it present).
	_ "github.com/sei-protocol/sei-k8s-controller/sdk/sei/provider/k8s"
)

// runLabelKey marks a run's resources for the abnormal-exit reaper (t.Cleanup is
// skipped on SIGKILL / a -test.timeout breach). provision stamps it on the
// network + every node; a suite's directly-applied seiload Job + fault CRs stamp
// it too. The nightly-gc CronJob reaps these by label (resources older than 5h —
// above the longest suite deadline, so it never races a live run), cascading a
// SeiNetwork delete to its validators + PVCs; normal-exit t.Cleanup is the fast
// path.
const runLabelKey = "sei.io/harness-run"

// memiavlStorageConfig pins state commitment to memiavl for the load/release/chaos
// suites (the major-upgrade suite omits it — it tests the migration path). The
// controller default write-mode is rejected by the nightly image, so it must be
// set explicitly; the state store is left at its image default.
var memiavlStorageConfig = map[string]string{
	"storage.state_commit.write_mode": "memiavl_only",
}

// runChainID appends a per-run token to the base chain id so every run gets a
// fresh genesis and node keys. A static id reused across runs (e.g. "bench")
// collides with the prior run's persisted genesis: the nodes boot with new keys
// but the genesis — keyed by chain id — still names the prior run's validator
// set, so the live nodes are not the validators genesis expects and consensus
// halts at height 1. Nanosecond resolution so a same-second manual re-trigger
// can't alias a prior run's not-yet-reaped chain.
func runChainID(base string) string {
	return base + "-" + strconv.FormatInt(time.Now().UnixNano(), 36)
}

// mergeConfig returns base overlaid with extra; extra wins on key collision.
func mergeConfig(base, extra map[string]string) map[string]string {
	out := make(map[string]string, len(base)+len(extra))
	maps.Copy(out, base)
	maps.Copy(out, extra)
	return out
}

// spec is the typed input shared by the suites — the local-Go-state replacement
// for the per-run workflow-vars contract.
type spec struct {
	chainID       string               // SeiNetwork name == genesis chain id; also peer-selector value + run discriminator
	runID         string               // unique per run; the sei.io/harness-run label value
	namespace     string               // shared nightly namespace; "" => the SDK client's resolved default
	seidImage     string               // seid container image under test
	sidecarImage  string               // seictl sidecar image under test; "" => platform default
	validators    int                  // genesis validator count (>= 1)
	rpcNodes      int                  // standalone RPC followers; named <chain>-rpc-0..N-1
	timeout       time.Duration        // overall scenario deadline (drives ctx, kept < CronJob activeDeadlineSeconds)
	storageConfig map[string]string    // per-suite seid storage config (load/release set memiavl; upgrade omits it)
	rpcConfig     map[string]string    // extra per-RPC-node config overlaid on storageConfig (e.g. EVM tuning)
	accounts      []sei.GenesisAccount // genesis-funded non-validator accounts (release funds an admin); nil funds none

	// seiload inputs (load suite)
	seiloadImage    string // sei-load benchmark image
	seiloadProfile  string // profile name in the seiload-profiles ConfigMap
	seiloadCommit   string // sei-chain commit label for the run's metrics
	seiloadWorkload string // the workload label on the run's metrics
	seiloadRootKey  string // sei-load's hex funding root key (fund its address via accounts); "" for none
	durationMin     int    // seiload run length, minutes
	// share of accepted txs whose execution status seiload must read; 0 skips
	minReceiptCoverage float64
}

// chain is the live provisioned topology a suite runs load against and asserts
// on, held in local Go state.
type chain struct {
	network  *sei.Network
	rpcNodes []*sei.Node
}

// rpcNodeName is the load-bearing selector contract: chaos fault CRs target
// followers by sei.io/node=<chain>-rpc-<ordinal>. The SDK NodeSpec has no
// Replicas field (the caller loops CreateNode), so the suite reproduces the
// <base>-<ordinal> naming the old `provision-node --replicas` produced.
func rpcNodeName(chainID string, ordinal int) string {
	return fmt.Sprintf("%s-rpc-%d", chainID, ordinal)
}

// witnessNamespace derives the namespace for per-node witness service hostnames
// from a network's aggregate RPC host: <chainID>-internal.<ns>.svc[.cluster.local],
// and chainID carries no dots, so the second label is the namespace. The
// authoritative source is the served endpoint, not the spec namespace, which the
// SDK may resolve to a kubeconfig/SA default only the endpoint reflects.
func witnessNamespace(t *testing.T, network *sei.Network) string {
	t.Helper()
	u, err := url.Parse(network.TendermintRPC())
	if err != nil {
		t.Fatalf("parse network TM RPC %q: %v", network.TendermintRPC(), err)
	}
	labels := strings.Split(u.Hostname(), ".")
	if len(labels) < 2 || labels[1] == "" {
		t.Fatalf("cannot derive namespace from aggregate RPC host %q", u.Host)
	}
	return labels[1]
}

// assertWitnessFresh fails the suite unless the state-sync witness sits within one
// snapshot interval of the validator head. A witness must be at head to serve
// light blocks at the snapshot height a bootstrap cross-checks; catching_up cannot
// certify that (a one-way latch meaning "left blocksync once", never "at head
// now"), so freshness is asserted directly on the RPC heights. validatorRPC and
// witnessRPC are bare host:port (nodeRPC output).
func assertWitnessFresh(ctx context.Context, t *testing.T, hc *http.Client, validatorRPC, witnessRPC string, interval int) {
	t.Helper()
	vHeight, vOK := sei.LatestHeight(ctx, hc, "http://"+validatorRPC)
	wHeight, wOK := sei.LatestHeight(ctx, hc, "http://"+witnessRPC)
	if !vOK || !wOK {
		t.Fatalf("witness freshness read: validator %s ok=%v, witness %s ok=%v", validatorRPC, vOK, witnessRPC, wOK)
	}
	if gap := vHeight - wHeight; gap > int64(interval) {
		t.Fatalf("witness %s lags validator head by %d blocks (> interval %d): a diverging follower cannot serve state-sync light blocks", witnessRPC, gap, interval)
	}
}

// provision stands up the genesis SeiNetwork + N standalone RPC SeiNodes via the
// SDK in-process (not a seictl subprocess), waiting each follower
// to Running + caught-up + EVM-serving before returning. The returned chain is
// non-nil even on error so the caller can still tear down whatever was created
// (pair every provision with a t.Cleanup(teardown)).
func provision(ctx context.Context, t *testing.T, c *sei.Client, s spec) (*chain, error) {
	t.Helper()
	ch := &chain{}

	// Stamped on the network + every node so the label-GC sweep can reap this
	// run's resources on an abnormal exit t.Cleanup can't cover.
	runLabels := map[string]string{runLabelKey: s.runID}

	net, err := c.CreateNetwork(ctx, sei.NetworkSpec{
		Name:         s.chainID,
		Namespace:    s.namespace,
		Image:        s.seidImage,
		SidecarImage: s.sidecarImage,
		Validators:   s.validators,
		Labels:       runLabels,
		Config:       maps.Clone(s.storageConfig),
		Accounts:     s.accounts,
		// Ephemeral chain: cascade-delete the controller-created validators (+
		// their PVCs) on teardown. The CRD default Retain would orphan them —
		// they never carry sei.io/harness-run, so neither t.Cleanup nor the
		// label-GC sweep would reap them.
		DeletionPolicy: sei.DeletionDelete,
	})
	if err != nil {
		return ch, fmt.Errorf("create network %q: %w", s.chainID, err)
	}
	ch.network = net
	if err := net.WaitReady(ctx); err != nil {
		return ch, fmt.Errorf("network %q ready: %w", s.chainID, err)
	}
	t.Logf("network %s: ready", s.chainID)

	// Two phases: create every rpc node, then gate each on caught-up + EVM
	// serving. blocksync's caught-up check (sei-tendermint pool.IsCaughtUp)
	// returns false unconditionally for a single-peer node, so every peer a
	// follower will have — validators and sibling followers alike — must
	// exist before its gate runs.
	hc := &http.Client{Timeout: 10 * time.Second}
	for i := range s.rpcNodes {
		name := rpcNodeName(s.chainID, i)
		node, err := createRPCNode(ctx, t, c, sei.NodeSpec{
			Name:      name,
			Network:   s.chainID,
			Namespace: s.namespace,
			Image:     s.seidImage,
			Labels:    runLabels,
			Config:    mergeConfig(s.storageConfig, s.rpcConfig),
		})
		if node != nil {
			ch.rpcNodes = append(ch.rpcNodes, node)
		}
		if err != nil {
			return ch, err
		}
	}
	for _, node := range ch.rpcNodes {
		if err := gateRPCNode(ctx, t, hc, node); err != nil {
			return ch, err
		}
	}
	return ch, nil
}

// createRPCNode creates an RPC SeiNode and blocks until it is running (config
// applied, sidecar ready — discoverability, not serve-readiness). Returns the
// node non-nil once created — even if the running gate fails — so the caller
// can still register it for teardown; nil only when creation itself fails.
func createRPCNode(
	ctx context.Context, t *testing.T, c *sei.Client, nodeSpec sei.NodeSpec,
) (*sei.Node, error) {
	t.Helper()
	node, err := c.CreateNode(ctx, nodeSpec)
	if err != nil {
		return nil, fmt.Errorf("create rpc node %q: %w", nodeSpec.Name, err)
	}
	if err := node.WaitReady(ctx); err != nil {
		return node, fmt.Errorf("rpc node %q running: %w", nodeSpec.Name, err)
	}
	t.Logf("rpc node %s: running", nodeSpec.Name)
	return node, nil
}

// gateRPCNode blocks until a running RPC node is fully serving: caught up to
// the chain, then answering EVM RPC. Each gate is logged as it passes so a
// stall is localizable in real time from the pod log (which node, which gate)
// rather than a single terminal error.
func gateRPCNode(ctx context.Context, t *testing.T, hc *http.Client, node *sei.Node) error {
	t.Helper()
	if err := sei.WaitCaughtUp(ctx, hc, node.TendermintRPC()); err != nil {
		return fmt.Errorf("rpc node %q caught up: %w", node.Name(), err)
	}
	t.Logf("rpc node %s: caught up", node.Name())
	if err := sei.WaitEVMServing(ctx, hc, node.EVMRPC()); err != nil {
		return fmt.Errorf("rpc node %q EVM serving: %w", node.Name(), err)
	}
	t.Logf("rpc node %s: EVM serving", node.Name())
	return nil
}

// teardown deletes the provisioned resources — the normal-exit fast path, wired
// via t.Cleanup. Best-effort and idempotent (the SDK treats not-found as
// success): every delete is attempted and errors joined, so one failure never
// strands the rest. The harness-run label sweep is the backstop when this never
// runs (SIGKILL).
func (ch *chain) teardown(ctx context.Context) error {
	var errs []error
	for _, n := range ch.rpcNodes {
		if n == nil {
			continue
		}
		if err := n.Delete(ctx); err != nil {
			errs = append(errs, fmt.Errorf("delete node %q: %w", n.Name(), err))
		}
	}
	if ch.network != nil {
		if err := ch.network.Delete(ctx); err != nil {
			errs = append(errs, fmt.Errorf("delete network %q: %w", ch.network.Name(), err))
		}
	}
	return errors.Join(errs...)
}

// cleanupChain registers best-effort teardown on a fresh context, so it still
// runs when the scenario ctx is already expired.
func cleanupChain(t *testing.T, ch *chain) {
	t.Helper()
	t.Cleanup(func() {
		ctx, cancel := context.WithTimeout(context.Background(), 10*time.Minute)
		defer cancel()
		if err := ch.teardown(ctx); err != nil {
			t.Errorf("teardown: %v", err)
		}
	})
}

// suitesStarted counts suites that began executing against a live cluster
// (incremented past requireCluster's skip). TestMain reads it to turn go test's
// silent exit-0-on-zero-match into a hard failure — see TestMain.
var suitesStarted atomic.Int64

// TestMain runs the suites, then guards the one failure mode go test hides: a
// -test.run pattern that matches nothing exits 0. Against a live cluster
// (SEI_NODE_CLUSTER set — the nightly's environment) a run that started zero
// suites means the pattern selected none of them, the classic false-healthy from
// a harness binary built before a suite rename, or a mistyped -test.run in the
// manifest. Fail loud instead of reporting green. Locally (SEI_NODE_CLUSTER
// unset) every suite t.Skips, so a zero count is expected and not enforced. This
// bounds only the zero-match case; positive proof that every expected suite ran
// is a completion-count SLI owned by the metrics layer, not this binary.
func TestMain(m *testing.M) {
	if msg := staleSeidImages(time.Now().UTC()); msg != "" {
		fmt.Fprintln(os.Stderr, msg)
		os.Exit(1)
	}

	code := m.Run()
	if code == 0 && os.Getenv("SEI_NODE_CLUSTER") != "" && suitesStarted.Load() == 0 {
		fmt.Fprintln(os.Stderr, "integration guard: -test.run selected zero suites against a live cluster — "+
			"refusing to report green (the harness binary and the -test.run pattern are out of sync; "+
			"an image built before a suite rename is the usual cause)")
		code = 1
	}
	os.Exit(code)
}

// requireCluster skips a suite unless it is pointed at a real cluster, and
// counts started suites for TestMain's zero-match guard. The SDK selects its
// k8s provider on SEI_NODE_CLUSTER presence; without it there is nothing to
// provision against.
func requireCluster(t *testing.T) {
	t.Helper()
	if os.Getenv("SEI_NODE_CLUSTER") == "" {
		t.Skip("integration suite: set SEI_NODE_CLUSTER to run against a cluster")
	}
	// The one universal suite entry point: every suite gates on requireCluster
	// first, so counting here needs no per-suite wiring and upholds the
	// "a new suite joins by taking the TestNightly prefix, nothing else" rule.
	suitesStarted.Add(1)
}

// openClient opens the SDK in k8s mode (config resolved from the ambient
// kubeconfig / in-cluster SA chain).
func openClient(ctx context.Context, t *testing.T) *sei.Client {
	t.Helper()
	c, err := sei.Open(ctx, "k8s")
	if err != nil {
		t.Fatalf("open sei SDK (k8s): %v", err)
	}
	return c
}

// The Flux-advanced seid image inputs, one per nightly image flavor.
const (
	seidImageEnv      = "SEID_IMAGE"       // vanilla
	seidImageMockEnv  = "SEID_IMAGE_MOCK"  // mock_balances
	seidImageChaosEnv = "SEID_IMAGE_CHAOS" // mock_chain_validation + mock_balances
)

// seidImageEnvVars are the image inputs Flux's image automation advances. The
// upgrade-suite images are deliberately absent: they pin specific commits, carry
// no date, and must not be read as stale.
var seidImageEnvVars = []string{seidImageEnv, seidImageMockEnv, seidImageChaosEnv}

// nightlyTagDate extracts the date from a nightly tag. The alternation mirrors the
// three filterTags patterns in the platform repo's
// clusters/harbor/flux-system/image-automation.yaml; a tag shape added there needs
// adding here, or its image silently stops being freshness-checked. A tag that does
// not match — a pinned commit SHA, a local build — is skipped rather than failed,
// which is what keeps this from firing on the upgrade images or on a developer
// pointing the suite at their own build.
var nightlyTagDate = regexp.MustCompile(
	`:(?:mock-|mock_chain_validation-mock_balances-)?nightly-([0-9]{8})-[0-9a-f]{7}$`)

// seidImageMaxAge is how far behind the image under test may fall before the run is
// refused. The bump lands about 01:40 UTC and the suite runs at 08:00, so a healthy
// image is hours old; 36h tolerates one skipped upstream build without tolerating a
// stopped pipeline. Override with SEID_IMAGE_MAX_AGE_HOURS.
const seidImageMaxAge = 36 * time.Hour

// staleSeidImages returns a diagnostic if any image input carries a nightly tag
// older than the budget, and "" if every one is fresh, unset, or not nightly-tagged.
// A stalled image bump otherwise reads as a green suite against an old build, since
// nothing downstream distinguishes that from a healthy run.
//
// The date comes from the tag, which the selecting ImagePolicy guarantees carries
// one, so this needs no registry call, no cluster read and no added RBAC. Local runs
// are exempt: without SEI_NODE_CLUSTER every suite skips anyway.
func staleSeidImages(now time.Time) string {
	if os.Getenv("SEI_NODE_CLUSTER") == "" {
		return ""
	}
	maxAge := seidImageMaxAge
	if h, err := strconv.Atoi(os.Getenv("SEID_IMAGE_MAX_AGE_HOURS")); err == nil && h > 0 {
		maxAge = time.Duration(h) * time.Hour
	}
	var stale []string
	for _, key := range seidImageEnvVars {
		m := nightlyTagDate.FindStringSubmatch(os.Getenv(key))
		if m == nil {
			continue
		}
		built, err := time.Parse("20060102", m[1])
		if err != nil {
			continue
		}
		if age := now.Sub(built); age > maxAge {
			stale = append(stale, fmt.Sprintf("  %s is %s old (%s)", key, age.Round(time.Hour), os.Getenv(key)))
		}
	}
	if len(stale) == 0 {
		return ""
	}
	return "integration guard: refusing to run against a stale sei-chain image — the image bump is stuck, " +
		"not the chain. Every suite would pass and report green on a build nobody has advanced.\n" +
		strings.Join(stale, "\n") +
		"\nCheck Flux's harbor image automation and whether its bump PR merged: " +
		"`flux get image update -n flux-system` and any open flux-image-updates PR."
}

// envOr returns the env var or a fallback (for local runs).
func envOr(key, fallback string) string {
	if v := os.Getenv(key); v != "" {
		return v
	}
	return fallback
}

// mustEnv fails the suite if a required input is missing.
func mustEnv(t *testing.T, key string) string {
	t.Helper()
	v := os.Getenv(key)
	if v == "" {
		t.Fatalf("integration suite: required env %s is unset", key)
	}
	return v
}

// envInt reads an integer env var or a fallback; a non-integer value fails fast.
func envInt(t *testing.T, key string, fallback int) int {
	t.Helper()
	v := os.Getenv(key)
	if v == "" {
		return fallback
	}
	n, err := strconv.Atoi(v)
	if err != nil {
		t.Fatalf("integration suite: env %s=%q is not an integer: %v", key, v, err)
	}
	return n
}
