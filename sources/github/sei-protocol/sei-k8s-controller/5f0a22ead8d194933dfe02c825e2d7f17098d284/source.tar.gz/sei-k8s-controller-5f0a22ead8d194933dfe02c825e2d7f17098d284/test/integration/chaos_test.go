//go:build integration

package integration

import (
	"context"
	"testing"
	"time"

	apierrors "k8s.io/apimachinery/pkg/api/errors"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/apis/meta/v1/unstructured"
	"k8s.io/apimachinery/pkg/runtime/schema"
	"k8s.io/client-go/dynamic"
	ctrl "sigs.k8s.io/controller-runtime"
	"sigs.k8s.io/yaml"

	"github.com/sei-protocol/sei-k8s-controller/test/manifests/faults"
)

// injectWindow bounds fault injection independently of the per-scenario
// timeout: if a fault hasn't reached AllInjected within this window, fail fast
// rather than poll the never-flipping condition until the scenario budget
// expires (a stuck chaos-daemon retry loop would otherwise silently eat the
// full 40m scenario timeout). This is a blast-radius bound, not a
// stuck-vs-slow classifier: chaos-mesh's own retry backoff and a cold-starting
// daemon on a freshly scaled node can legitimately take a while, so an expiry
// here isn't proof of a stuck daemon, just a signal to stop waiting. Sized
// well above steady-state inject latency (seconds) while staying below
// CHAOS_DURATION's default (3m) — see TestNightlyChaosSuite's injectWindow-vs-faultDur
// guard, which exists so a late-but-successful injection still leaves real
// time for the under-fault liveness check.
const injectWindow = 90 * time.Second

// chaosGVR is the GroupVersionResource for a Chaos-Mesh fault kind. Faults are
// applied unstructured so the chaos-mesh API stays out of the module's deps.
func chaosGVR(resource string) schema.GroupVersionResource {
	return schema.GroupVersionResource{Group: "chaos-mesh.org", Version: "v1alpha1", Resource: resource}
}

// fault is a rendered Chaos-Mesh fault CR plus the resource name its dynamic
// client needs.
type fault struct {
	resource string // GVR resource, e.g. "networkchaos"
	obj      *unstructured.Unstructured
}

// hasDuration reports whether the fault self-expires (carries spec.duration). A
// duration-less fault would block gateRecovered until the scenario deadline, so
// every ported fault must currently carry one.
func (f fault) hasDuration() bool {
	_, found, _ := unstructured.NestedString(f.obj.Object, "spec", "duration")
	return found
}

// dynClient builds a dynamic client from the ambient config — the harness
// applies fault CRs unstructured through it.
func dynClient(t *testing.T) dynamic.Interface {
	t.Helper()
	cfg, err := ctrl.GetConfig()
	if err != nil {
		t.Fatalf("load kubeconfig: %v", err)
	}
	dc, err := dynamic.NewForConfig(cfg)
	if err != nil {
		t.Fatalf("build dynamic client: %v", err)
	}
	return dc
}

// renderFault renders a catalog fault and decodes it to an unstructured object.
func renderFault(t *testing.T, cf faults.Fault, p faults.Params) fault {
	t.Helper()
	out, err := cf.Render(p)
	if err != nil {
		t.Fatalf("render fault: %v", err)
	}
	var m map[string]any
	if err := yaml.Unmarshal(out, &m); err != nil {
		t.Fatalf("unmarshal fault: %v", err)
	}
	return fault{resource: cf.Resource(), obj: &unstructured.Unstructured{Object: m}}
}

// applyFault creates the fault CR and registers best-effort deletion. Deletion
// is also what stops a duration-less fault; duration-bearing faults self-expire.
func applyFault(ctx context.Context, t *testing.T, dc dynamic.Interface, ns string, f fault) {
	t.Helper()
	ri := dc.Resource(chaosGVR(f.resource)).Namespace(ns)
	if _, err := ri.Create(ctx, f.obj, metav1.CreateOptions{}); err != nil {
		t.Fatalf("apply %s/%s: %v", f.resource, f.obj.GetName(), err)
	}
	t.Cleanup(func() {
		ctx, cancel := context.WithTimeout(context.Background(), time.Minute)
		defer cancel()
		_ = ri.Delete(ctx, f.obj.GetName(), metav1.DeleteOptions{})
	})
}

// gateInjected blocks until AllInjected, then asserts the fault hit the right
// number of targets. AllInjected is set after chaos-mesh writes the per-target
// records to the (durable) CR status, so a single read here doesn't race the
// injection. oneShot kills must hit EXACTLY one validator (mode:one): ≥1 alone
// wouldn't catch a future selector edit that killed 2/4 and halted the chain.
func gateInjected(ctx context.Context, t *testing.T, dc dynamic.Interface, ns string, f fault, oneShot bool) {
	t.Helper()
	injectCtx, cancel := context.WithTimeout(ctx, injectWindow)
	defer cancel()
	waitFaultCondition(injectCtx, t, dc, ns, f, "AllInjected")
	// Deliberately ctx here, not injectCtx: a fault that injects near the
	// injectWindow boundary can leave injectCtx with almost no time left, and
	// this single fast read shouldn't spuriously fail on that race — only the
	// poll loop above is time-boxed.
	u, err := dc.Resource(chaosGVR(f.resource)).Namespace(ns).Get(ctx, f.obj.GetName(), metav1.GetOptions{})
	if err != nil {
		t.Fatalf("read injected targets for %s/%s: %v", f.resource, f.obj.GetName(), err)
	}
	n := faultInjectedTargets(u)
	if n < 1 {
		t.Fatalf("fault %s/%s injected 0 targets — selector matched nothing (false-green guard)", f.resource, f.obj.GetName())
	}
	if oneShot && n != 1 {
		t.Fatalf("one-shot fault %s/%s injected %d targets, want exactly 1 — quorum risk", f.resource, f.obj.GetName(), n)
	}
	t.Logf("%s/%s injected %d target(s)", f.resource, f.obj.GetName(), n)
}

// faultInjectedTargets counts the targets chaos-mesh actually injected. The
// count lives per-target in status.experiment.containerRecords[].injectedCount
// (there is no top-level injectedCount), so a 0-match selector yields no records.
func faultInjectedTargets(u *unstructured.Unstructured) int {
	recs, _, _ := unstructured.NestedSlice(u.Object, "status", "experiment", "containerRecords")
	n := 0
	for _, r := range recs {
		m, ok := r.(map[string]any)
		if !ok {
			continue
		}
		if ic, _, _ := unstructured.NestedInt64(m, "injectedCount"); ic > 0 {
			n++
		}
	}
	return n
}

// gateRecovered blocks until AllRecovered=True, catching chaos-mesh finalizers
// stuck on leftover tc/tproxy rules before teardown. Runs on the scenario ctx
// (gated on the fault's own spec.duration, not a fixed budget) — unlike
// gateInjected, there's no separate fail-fast window here. If gateInjected
// fails fast instead, this never runs, so a stuck-daemon abort skips this
// teardown assertion; cleanupChain still tears down the ephemeral namespace
// regardless.
func gateRecovered(ctx context.Context, t *testing.T, dc dynamic.Interface, ns string, f fault) {
	t.Helper()
	waitFaultCondition(ctx, t, dc, ns, f, "AllRecovered")
}

func waitFaultCondition(ctx context.Context, t *testing.T, dc dynamic.Interface, ns string, f fault, condType string) {
	t.Helper()
	ri := dc.Resource(chaosGVR(f.resource)).Namespace(ns)
	tick := time.NewTicker(5 * time.Second)
	defer tick.Stop()
	var lastErr error // a real (non-NotFound) Get error, surfaced on timeout
	for {
		u, err := ri.Get(ctx, f.obj.GetName(), metav1.GetOptions{})
		switch {
		case err == nil && faultConditionTrue(u, condType):
			return
		case err != nil && !apierrors.IsNotFound(err): // NotFound is transient post-create cache lag
			lastErr = err
		}
		select {
		case <-ctx.Done():
			t.Fatalf("fault %s/%s: %s not True before deadline: %v (last get: %v)",
				f.resource, f.obj.GetName(), condType, ctx.Err(), lastErr)
		case <-tick.C:
		}
	}
}

// faultConditionTrue reports whether the fault CR carries condType=True.
func faultConditionTrue(u *unstructured.Unstructured, condType string) bool {
	conds, found, err := unstructured.NestedSlice(u.Object, "status", "conditions")
	if !found || err != nil {
		return false
	}
	for _, c := range conds {
		m, ok := c.(map[string]any)
		if ok && m["type"] == condType && m["status"] == "True" {
			return true
		}
	}
	return false
}
