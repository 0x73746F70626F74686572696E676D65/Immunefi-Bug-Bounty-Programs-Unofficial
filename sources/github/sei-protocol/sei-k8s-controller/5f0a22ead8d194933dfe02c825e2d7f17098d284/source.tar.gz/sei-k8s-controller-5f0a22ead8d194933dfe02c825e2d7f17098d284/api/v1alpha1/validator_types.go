package v1alpha1

// DefaultOperatorKeyName matches the +kubebuilder:default on
// SecretOperatorKeyringSource.KeyName. Referenced by the planner and
// noderesource packages so defaulting stays consistent when admission
// webhooks haven't run (e.g. in-memory specs in tests).
const DefaultOperatorKeyName = "node_admin"

// GentxOperatorKeyName is the keyring uid the seictl generate-gentx task
// writes the validator key under during a genesis ceremony. Mirrored here
// so consumers resolving signing identity for the test-backend (no .secret)
// path stay in sync without importing seictl.
const GentxOperatorKeyName = "validator"

// ResolveOperatorKeyringUID returns the keyring uid the sidecar should use
// for operator-account signing on the given SeiNode. With .secret set, the
// explicit Secret.KeyName wins (defaulting to DefaultOperatorKeyName for
// in-memory specs that bypassed admission). Otherwise the gentx convention
// applies — generate-gentx writes the validator key under GentxOperatorKeyName.
func ResolveOperatorKeyringUID(node *SeiNode) string {
	if node == nil ||
		node.Spec.Validator == nil ||
		node.Spec.Validator.OperatorKeyring == nil ||
		node.Spec.Validator.OperatorKeyring.Secret == nil {
		return GentxOperatorKeyName
	}
	s := node.Spec.Validator.OperatorKeyring.Secret
	if s.KeyName == "" {
		return DefaultOperatorKeyName
	}
	return s.KeyName
}

// ValidatorSpec configures a consensus-participating validator node.
// Validators bootstrap the same way as full nodes but participate in consensus.
//
// +kubebuilder:validation:XValidation:rule="has(self.signingKey) == has(self.nodeKey)",message="signingKey and nodeKey must be set together (validators get both or neither)"
// +kubebuilder:validation:XValidation:rule="!has(self.signingKey) || !has(self.nodeKey) || self.signingKey.secret.secretName != self.nodeKey.secret.secretName",message="signingKey and nodeKey must reference distinct Secrets — packing both keys in one Secret collapses their isolation"
// +kubebuilder:validation:XValidation:rule="!has(self.operatorKeyring) || !has(self.signingKey) || self.operatorKeyring.secret.secretName != self.signingKey.secret.secretName",message="operatorKeyring and signingKey must reference distinct Secrets — collapsing them into one Secret would force the sidecar/seid trust boundary to evaporate"
// +kubebuilder:validation:XValidation:rule="!has(self.operatorKeyring) || !has(self.nodeKey) || self.operatorKeyring.secret.secretName != self.nodeKey.secret.secretName",message="operatorKeyring and nodeKey must reference distinct Secrets"
// +kubebuilder:validation:XValidation:rule="!has(self.operatorKeyring) || self.operatorKeyring.secret.secretName != self.operatorKeyring.secret.passphraseSecretRef.secretName",message="operatorKeyring data Secret and passphrase Secret must be distinct"
// +kubebuilder:validation:XValidation:rule="!has(self.operatorKeyring) || !has(self.signingKey) || self.operatorKeyring.secret.passphraseSecretRef.secretName != self.signingKey.secret.secretName",message="operatorKeyring passphrase Secret must not equal signingKey Secret"
// +kubebuilder:validation:XValidation:rule="!has(self.operatorKeyring) || !has(self.nodeKey) || self.operatorKeyring.secret.passphraseSecretRef.secretName != self.nodeKey.secret.secretName",message="operatorKeyring passphrase Secret must not equal nodeKey Secret"
type ValidatorSpec struct {
	// Snapshot configures how the node obtains its initial chain state.
	// When absent the node block-syncs from genesis.
	// +optional
	Snapshot *SnapshotSource `json:"snapshot,omitempty"`

	// GenesisCeremony indicates this validator participates in a network genesis
	// ceremony. Set by the SeiNetwork controller — not intended for direct use.
	// +optional
	GenesisCeremony *GenesisCeremonyNodeConfig `json:"genesisCeremony,omitempty"`

	// SigningKey declares the source of this validator's consensus signing
	// key (priv_validator_key.json). When omitted, the node runs as a
	// non-signing observer — pre-sync before cutover, or genesis-ceremony
	// bootstraps that produce keys on-cluster. Mutually exclusive with
	// GenesisCeremony. Must be paired with NodeKey.
	// +optional
	SigningKey *SigningKeySource `json:"signingKey,omitempty"`

	// NodeKey declares the source of this validator's P2P node key
	// (node_key.json). Determines the validator's permanent libp2p node ID
	// for peer connections. Must be paired with SigningKey — validators
	// without consensus identity have no need for a stable network identity.
	// +optional
	NodeKey *NodeKeySource `json:"nodeKey,omitempty"`

	// OperatorKeyring declares the source of this validator's operator-account
	// keyring used by the sidecar to sign and broadcast governance,
	// MsgEditValidator, withdraw-rewards, and other operator-account
	// transactions.
	//
	// Independently optional from signingKey/nodeKey: a validator may run as a
	// non-signing observer with operatorKeyring set (governance-only
	// operations), or as a consensus-signing validator without operatorKeyring
	// (governance performed out-of-band).
	//
	// Mounted on the sidecar container. The seid main container is excluded
	// by default — see
	// SecretOperatorKeyringSource.SeidMount for the explicit opt-in.
	// +optional
	OperatorKeyring *OperatorKeyringSource `json:"operatorKeyring,omitempty"`
}

// SigningKeySource declares where a validator's consensus signing key
// material comes from. Exactly one variant must be set. Variants are
// mutually exclusive — a validator has one consensus identity.
//
// +kubebuilder:validation:XValidation:rule="(has(self.secret) ? 1 : 0) == 1",message="exactly one signing key source must be set"
type SigningKeySource struct {
	// Secret loads the signing key from a Kubernetes Secret in the
	// SeiNode's namespace.
	// +optional
	Secret *SecretSigningKeySource `json:"secret,omitempty"`

	// Future siblings: TMKMS, Remote, Vault. When added, update the
	// XValidation exactly-one rule.
}

// SecretSigningKeySource references a Kubernetes Secret containing the
// validator's consensus signing key. The Secret must contain a data key
// `priv_validator_key.json` holding the Tendermint validator key
// (consensus identity), mounted read-only at
// $SEI_HOME/config/priv_validator_key.json. Rotating this value without
// a paired on-chain MsgEditValidator will cause the validator to miss
// blocks.
//
// priv_validator_state.json (CometBFT's slashing-protection ledger) is
// owned by seid on the data PVC and is created automatically on first
// start. The controller does not inject this file.
type SecretSigningKeySource struct {
	// SecretName is the name of a Secret in the SeiNode's namespace.
	// The controller never creates, mutates, or deletes this Secret —
	// its lifecycle is fully external (kubectl, ESO, CSI Secrets Store, etc.).
	// Immutable: re-pointing the consensus key on a running validator
	// is a slashing risk; force delete-and-recreate to rotate.
	//
	// +kubebuilder:validation:MinLength=1
	// +kubebuilder:validation:MaxLength=253
	// +kubebuilder:validation:Pattern=`^[a-z0-9]([-a-z0-9]*[a-z0-9])?$`
	// +kubebuilder:validation:XValidation:rule="self == oldSelf",message="secretName is immutable"
	SecretName string `json:"secretName"`
}

// NodeKeySource declares where a node's P2P node key (node_key.json) comes
// from. Exactly one variant must be set. Used by validator and seed modes.
//
// +kubebuilder:validation:XValidation:rule="(has(self.secret) ? 1 : 0) == 1",message="exactly one node key source must be set"
type NodeKeySource struct {
	// Secret loads the node key from a Kubernetes Secret in the
	// SeiNode's namespace.
	// +optional
	Secret *SecretNodeKeySource `json:"secret,omitempty"`
}

// SecretNodeKeySource references a Kubernetes Secret containing a node's P2P
// node key. The Secret must contain a data key `node_key.json` holding the
// Tendermint node key, mounted read-only at $SEI_HOME/config/node_key.json.
//
// How much the key matters depends on the mode that references it. For a
// validator it is identity-bearing but not slashing-relevant — losing it costs
// only accumulated peer-graph reputation, not stake — and is Secret-grade for
// handling consistency with SigningKey. For a seed the derived NodeID is
// published and dialed by strangers, which makes it a one-way door; see
// SeedSpec.NodeKey before treating it as low-stakes.
type SecretNodeKeySource struct {
	// SecretName is the name of a Secret in the SeiNode's namespace.
	// The controller never creates, mutates, or deletes this Secret.
	// Immutable: re-pointing the node ID on a running validator costs
	// peer reputation and forces a peer-graph reset; force delete-and-recreate.
	//
	// +kubebuilder:validation:MinLength=1
	// +kubebuilder:validation:MaxLength=253
	// +kubebuilder:validation:Pattern=`^[a-z0-9]([-a-z0-9]*[a-z0-9])?$`
	// +kubebuilder:validation:XValidation:rule="self == oldSelf",message="secretName is immutable"
	SecretName string `json:"secretName"`
}

// OperatorKeyringSource configures the keyring the sidecar uses to sign
// operator-account transactions (governance, MsgEditValidator, withdraw-
// rewards, etc).
//
// Unset: sidecar reads a test-backend keyring at $SEI_HOME/keyring-test/
// on the data PVC — the path generate-gentx writes the validator key to
// during a genesis ceremony. Unencrypted.
//
// Set .secret: source the keyring from a passphrase-locked Secret (file
// backend). Use when the operator key is rotated externally, sourced from
// an HSM, or shared across infrastructure the controller doesn't own.
type OperatorKeyringSource struct {
	// Secret sources the keyring from a file-backend Secret in the SeiNode's
	// namespace, projected at $SEI_HOME/keyring-file/.
	// +optional
	Secret *SecretOperatorKeyringSource `json:"secret,omitempty"`
}

// SecretOperatorKeyringSource references the Kubernetes Secrets that supply
// the operator-account keyring directory and its unlock passphrase. The
// controller never creates, mutates, or deletes either Secret — their
// lifecycles are fully external (kubectl + SOPS, ESO, CSI Secrets Store).
//
// The keyring data and passphrase live in deliberately separate Secrets:
// the data Secret is projected as a directory-shaped volume mount, so
// co-locating the passphrase as a data key would project it as a file
// under the keyring directory and the file-backend would treat it as
// keyring contents.
type SecretOperatorKeyringSource struct {
	// SecretName names a Secret in the SeiNode's namespace whose data keys
	// are the on-disk Cosmos SDK file-keyring layout. Minimum required:
	//   <keyname>.info        (armored encrypted key blob)
	//   <hex-of-address>.address  (name→address index)
	//
	// +kubebuilder:validation:MinLength=1
	// +kubebuilder:validation:MaxLength=253
	// +kubebuilder:validation:Pattern=`^[a-z0-9]([-a-z0-9]*[a-z0-9])?$`
	// +kubebuilder:validation:XValidation:rule="self == oldSelf",message="secretName is immutable"
	SecretName string `json:"secretName"`

	// KeyName is the name of the keyring entry to use when signing
	// (the name passed to `seid keys add <name>`). Defaults to
	// "node_admin" to preserve continuity with the seienv convention.
	// Mutable — rotating to a different entry within the same Secret
	// is a routine operator-account change, not a slashing risk.
	//
	// The default literal below MUST match DefaultOperatorKeyName —
	// kubebuilder markers cannot reference Go constants.
	//
	// +optional
	// +kubebuilder:default="node_admin"
	// +kubebuilder:validation:MaxLength=64
	// +kubebuilder:validation:Pattern=`^[a-zA-Z0-9_-]+$`
	KeyName string `json:"keyName,omitempty"`

	// PassphraseSecretRef names a separate Secret containing the keyring
	// unlock passphrase. Required for the file backend.
	PassphraseSecretRef PassphraseSecretRef `json:"passphraseSecretRef"`

	// SeidMount additionally mounts this keyring directory and its unlock
	// passphrase onto the seid main container, in addition to the sidecar,
	// so an operator can run `seid keys` / `seid tx sign` directly against
	// the operator account for ad-hoc debugging (e.g. `seid keys list`
	// coming back empty against a mounted data dir).
	//
	// This is a deliberate security trade-off, not a routine toggle: it
	// makes the operator account key reachable from seid's larger,
	// network-facing attack surface (P2P/RPC) instead of only the sidecar's
	// loopback-bound one. Set per-node, at the operator's discretion — there
	// is no chain-id or environment restriction; the node owner is trusted
	// to make this call. Off by default.
	// +optional
	SeidMount bool `json:"seidMount,omitempty"`
}

// PassphraseSecretRef points at a single data key inside a Secret.
type PassphraseSecretRef struct {
	// SecretName names the passphrase Secret in the SeiNode's namespace.
	//
	// +kubebuilder:validation:MinLength=1
	// +kubebuilder:validation:MaxLength=253
	// +kubebuilder:validation:Pattern=`^[a-z0-9]([-a-z0-9]*[a-z0-9])?$`
	// +kubebuilder:validation:XValidation:rule="self == oldSelf",message="passphrase secretName is immutable"
	SecretName string `json:"secretName"`

	// Key is the data key inside the Secret holding the passphrase.
	// Required — operators declare this explicitly rather than relying on
	// a default that hides where the passphrase actually lives.
	//
	// +kubebuilder:validation:MinLength=1
	// +kubebuilder:validation:MaxLength=253
	Key string `json:"key"`
}

// GenesisCeremonyNodeConfig holds per-node genesis ceremony parameters.
// Populated by the SeiNetwork controller when genesis is configured.
type GenesisCeremonyNodeConfig struct {
	// ChainID of the genesis network.
	// +kubebuilder:validation:MinLength=1
	ChainID string `json:"chainId"`

	// StakingAmount is the self-delegation amount for this validator's gentx.
	// +kubebuilder:validation:MinLength=1
	StakingAmount string `json:"stakingAmount"`

	// AccountBalance is the initial coin balance to fund this validator's
	// genesis account. The node's own address is discovered during identity
	// generation — no cross-node coordination needed.
	// +kubebuilder:validation:MinLength=1
	AccountBalance string `json:"accountBalance"`

	// Index is the node's ordinal within the group (0-based).
	// +kubebuilder:validation:Minimum=0
	Index int32 `json:"index"`
}
