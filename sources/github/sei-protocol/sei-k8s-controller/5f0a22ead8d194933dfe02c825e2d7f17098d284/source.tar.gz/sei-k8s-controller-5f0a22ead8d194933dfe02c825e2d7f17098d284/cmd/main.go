package main

import (
	"context"
	"crypto/tls"
	"errors"
	"flag"
	"fmt"
	"net/http"
	"os"
	"sort"
	"time"

	_ "k8s.io/client-go/plugin/pkg/client/auth"

	"k8s.io/apimachinery/pkg/runtime"
	utilruntime "k8s.io/apimachinery/pkg/util/runtime"
	clientgoscheme "k8s.io/client-go/kubernetes/scheme"
	ctrl "sigs.k8s.io/controller-runtime"
	"sigs.k8s.io/controller-runtime/pkg/client"
	"sigs.k8s.io/controller-runtime/pkg/healthz"
	"sigs.k8s.io/controller-runtime/pkg/log/zap"
	"sigs.k8s.io/controller-runtime/pkg/metrics/filters"
	metricsserver "sigs.k8s.io/controller-runtime/pkg/metrics/server"
	gatewayv1 "sigs.k8s.io/gateway-api/apis/v1"

	seiv1alpha1 "github.com/sei-protocol/sei-k8s-controller/api/v1alpha1"
	nodecontroller "github.com/sei-protocol/sei-k8s-controller/internal/controller/node"
	nodetaskcontroller "github.com/sei-protocol/sei-k8s-controller/internal/controller/nodetask"
	seinetworkcontroller "github.com/sei-protocol/sei-k8s-controller/internal/controller/seinetwork"
	"github.com/sei-protocol/sei-k8s-controller/internal/noderesource"
	"github.com/sei-protocol/sei-k8s-controller/internal/peering"
	"github.com/sei-protocol/sei-k8s-controller/internal/planner"
	"github.com/sei-protocol/sei-k8s-controller/internal/platform"
	"github.com/sei-protocol/sei-k8s-controller/internal/sidecartransport"
	"github.com/sei-protocol/sei-k8s-controller/internal/task"
	sidecar "github.com/sei-protocol/sei-k8s-controller/sidecarapi/client"
)

var (
	scheme   = runtime.NewScheme()
	setupLog = ctrl.Log.WithName("setup")
)

func init() {
	utilruntime.Must(clientgoscheme.AddToScheme(scheme))
	utilruntime.Must(seiv1alpha1.AddToScheme(scheme))
	utilruntime.Must(gatewayv1.Install(scheme))
}

func main() {
	var metricsAddr string
	var metricsCertPath, metricsCertName, metricsCertKey string
	var enableLeaderElection bool
	var probeAddr string
	var secureMetrics bool
	var enableHTTP2 bool
	var tlsOpts []func(*tls.Config)

	flag.StringVar(&metricsAddr, "metrics-bind-address", ":8080",
		"The address the metrics endpoint binds to. Use 0 to disable.")
	flag.StringVar(&probeAddr, "health-probe-bind-address", ":8081",
		"The address the probe endpoint binds to.")
	flag.BoolVar(&enableLeaderElection, "leader-elect", true,
		"Enable leader election for controller manager.")
	flag.BoolVar(&secureMetrics, "metrics-secure", false,
		"If set, the metrics endpoint is served securely via HTTPS. Use --metrics-secure=false to use HTTP instead.")
	flag.StringVar(&metricsCertPath, "metrics-cert-path", "",
		"The directory that contains the metrics server certificate.")
	flag.StringVar(&metricsCertName, "metrics-cert-name", "tls.crt",
		"The name of the metrics server certificate file.")
	flag.StringVar(&metricsCertKey, "metrics-cert-key", "tls.key",
		"The name of the metrics server key file.")
	flag.BoolVar(&enableHTTP2, "enable-http2", false,
		"If set, HTTP/2 will be enabled for the metrics server.")

	opts := zap.Options{}
	opts.BindFlags(flag.CommandLine)
	flag.Parse()

	ctrl.SetLogger(zap.New(zap.UseFlagOptions(&opts)))

	// Disable HTTP/2 by default due to HTTP/2 Stream Cancellation and Rapid Reset CVEs:
	// https://github.com/advisories/GHSA-qppj-fm5r-hxr3
	// https://github.com/advisories/GHSA-4374-p667-p6c8
	if !enableHTTP2 {
		tlsOpts = append(tlsOpts, func(c *tls.Config) {
			c.NextProtos = []string{"http/1.1"}
		})
	}

	metricsServerOptions := metricsserver.Options{
		BindAddress:   metricsAddr,
		SecureServing: secureMetrics,
		TLSOpts:       tlsOpts,
	}

	if secureMetrics {
		metricsServerOptions.FilterProvider = filters.WithAuthenticationAndAuthorization
	}

	if len(metricsCertPath) > 0 {
		setupLog.Info("Using provided metrics certificates",
			"metrics-cert-path", metricsCertPath, "metrics-cert-name", metricsCertName, "metrics-cert-key", metricsCertKey)
		metricsServerOptions.CertDir = metricsCertPath
		metricsServerOptions.CertName = metricsCertName
		metricsServerOptions.KeyName = metricsCertKey
	}

	ctx := ctrl.SetupSignalHandler()

	mp, err := initMeterProvider(ctx)
	if err != nil {
		setupLog.Error(err, "Failed to initialize OTel MeterProvider")
		os.Exit(1)
	}
	defer func() {
		shutdownCtx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
		defer cancel()
		if err := mp.Shutdown(shutdownCtx); err != nil {
			setupLog.Error(err, "Failed to shutdown MeterProvider")
		}
	}()

	mgr, err := ctrl.NewManager(ctrl.GetConfigOrDie(), ctrl.Options{
		Scheme:                        scheme,
		Metrics:                       metricsServerOptions,
		HealthProbeBindAddress:        probeAddr,
		LeaderElection:                enableLeaderElection,
		LeaderElectionID:              "bc1f5b0a.sei.io",
		LeaderElectionReleaseOnCancel: true,
	})
	if err != nil {
		setupLog.Error(err, "Failed to start manager")
		os.Exit(1)
	}

	platformCfg, err := platform.Load()
	if err != nil {
		setupLog.Error(err, "Failed to load platform configuration")
		os.Exit(1)
	}
	if err := platformCfg.Validate(); err != nil {
		setupLog.Error(err, "Invalid platform configuration")
		os.Exit(1)
	}
	setupLog.Info("Resolved sidecar image", "image", platformCfg.SidecarImage)

	objectStore := platform.NewS3ObjectStore()
	kc := mgr.GetClient()

	// One transport per process: keepalive pool and SA-token cache
	// shared across reconciles. Bearer token authn for kube-rbac-proxy.
	sharedDoer := &http.Client{Transport: sidecartransport.New(sidecartransport.Config{})}

	newSidecarClient := func(node *seiv1alpha1.SeiNode) (*sidecar.SidecarClient, error) {
		return sidecar.NewSidecarClient(noderesource.SidecarURLForNode(node), sidecar.WithHTTPDoer(sharedDoer))
	}
	buildSidecarClient := func(node *seiv1alpha1.SeiNode) (task.SidecarClient, error) {
		return newSidecarClient(node)
	}

	// EC2 peer resolution rides the controller's IRSA role. The
	// ec2:DescribeInstances grant is provisioned out-of-band in Terraform (like
	// S3 — see config/rbac/service_account.yaml); that grant, not a code flag, is
	// the rollout switch. Before it lands, resolveEC2 fails closed (preserve-prior),
	// so persistent_peers does not churn.

	//nolint:staticcheck // TODO: migrate to GetEventRecorder (new events API)
	nodeRecorder := mgr.GetEventRecorderFor("seinode-controller")
	if err := (&nodecontroller.SeiNodeReconciler{
		Client:   kc,
		Scheme:   mgr.GetScheme(),
		Recorder: nodeRecorder,
		Platform: platformCfg,
		HeightReader: func(ctx context.Context, node *seiv1alpha1.SeiNode) (int64, error) {
			c, err := newSidecarClient(node)
			if err != nil {
				return 0, err
			}
			st, err := c.Status(ctx)
			if err != nil {
				return 0, err
			}
			if st.CommittedHeight == nil {
				return 0, errors.New("sidecar reported no committed height")
			}
			return *st.CommittedHeight, nil
		},
		Planner: &planner.NodeResolver{
			BuildSidecarClient: buildSidecarClient,
			Platform:           platformCfg,
		},
		EC2Peers: peering.NewAWSEC2Resolver(),
		PlanExecutor: &planner.Executor[*seiv1alpha1.SeiNode]{
			ConfigFor: func(_ context.Context, node *seiv1alpha1.SeiNode) task.ExecutionConfig {
				return task.ExecutionConfig{
					BuildSidecarClient: func() (task.SidecarClient, error) {
						return buildSidecarClient(node)
					},
					NewSidecarClient: newSidecarClient,
					KubeClient:       kc,
					APIReader:        mgr.GetAPIReader(),
					Scheme:           mgr.GetScheme(),
					Resource:         node,
					Platform:         platformCfg,
					ObjectStore:      objectStore,
				}
			},
		},
		// Adopted-workflow plans execute against the target node's sidecar
		// (the reconcile's own node), so Resource and the sidecar client
		// resolve to it — the workflow object is not itself an execution
		// surface.
		WorkflowConfigFor: func(
			_ context.Context, node *seiv1alpha1.SeiNode, _ *seiv1alpha1.SeiNodeTaskWorkflow,
		) task.ExecutionConfig {
			return task.ExecutionConfig{
				BuildSidecarClient: func() (task.SidecarClient, error) {
					return buildSidecarClient(node)
				},
				NewSidecarClient: newSidecarClient,
				KubeClient:       kc,
				APIReader:        mgr.GetAPIReader(),
				Scheme:           mgr.GetScheme(),
				Resource:         node,
				Platform:         platformCfg,
				ObjectStore:      objectStore,
			}
		},
	}).SetupWithManager(mgr); err != nil {
		setupLog.Error(err, "Failed to create controller", "controller", "SeiNode")
		os.Exit(1)
	}

	//nolint:staticcheck // migrating to events.EventRecorder API is a separate effort
	recorder := mgr.GetEventRecorderFor("seinetwork-controller")
	if err := (&seinetworkcontroller.SeiNetworkReconciler{
		Client:   kc,
		Scheme:   mgr.GetScheme(),
		Recorder: recorder,
		PlanExecutor: &planner.Executor[*seiv1alpha1.SeiNetwork]{
			ConfigFor: func(ctx context.Context, network *seiv1alpha1.SeiNetwork) task.ExecutionConfig {
				var assemblerNode *seiv1alpha1.SeiNode
				nodes := &seiv1alpha1.SeiNodeList{}
				if err := kc.List(ctx, nodes,
					client.InNamespace(network.Namespace),
					// Canonical seinetwork CR-selection key (both key families
					// are stamped on every SeiNetwork child).
					client.MatchingLabels{"sei.io/seinetwork": network.Name},
				); err == nil && len(nodes.Items) > 0 {
					sort.Slice(nodes.Items, func(i, j int) bool {
						return nodes.Items[i].Name < nodes.Items[j].Name
					})
					assemblerNode = &nodes.Items[0]
				}
				return task.ExecutionConfig{
					BuildSidecarClient: func() (task.SidecarClient, error) {
						if assemblerNode == nil {
							return nil, fmt.Errorf("no assembler node found for network %s", network.Name)
						}
						return buildSidecarClient(assemblerNode)
					},
					NewSidecarClient: newSidecarClient,
					KubeClient:       kc,
					APIReader:        mgr.GetAPIReader(),
					Scheme:           mgr.GetScheme(),
					Resource:         network,
					Platform:         platformCfg,
					ObjectStore:      objectStore,
				}
			},
		},
	}).SetupWithManager(mgr); err != nil {
		setupLog.Error(err, "Failed to create controller", "controller", "SeiNetwork")
		os.Exit(1)
	}

	//nolint:staticcheck // TODO: migrate to GetEventRecorder (new events API)
	taskRecorder := mgr.GetEventRecorderFor("seinodetask-controller")
	if err := (&nodetaskcontroller.SeiNodeTaskReconciler{
		Client:   kc,
		Scheme:   mgr.GetScheme(),
		Recorder: taskRecorder,
		Platform: platformCfg,
		ConfigFor: func(_ context.Context, _ *seiv1alpha1.SeiNodeTask, target *seiv1alpha1.SeiNode) task.ExecutionConfig {
			return task.ExecutionConfig{
				BuildSidecarClient: func() (task.SidecarClient, error) {
					return buildSidecarClient(target)
				},
				NewSidecarClient: newSidecarClient,
				KubeClient:       kc,
				APIReader:        mgr.GetAPIReader(),
				Scheme:           mgr.GetScheme(),
				Resource:         target,
				Platform:         platformCfg,
				ObjectStore:      objectStore,
			}
		},
	}).SetupWithManager(mgr); err != nil {
		setupLog.Error(err, "Failed to create controller", "controller", "SeiNodeTask")
		os.Exit(1)
	}

	if err := mgr.AddHealthzCheck("healthz", healthz.Ping); err != nil {
		setupLog.Error(err, "Failed to set up health check")
		os.Exit(1)
	}
	if err := mgr.AddReadyzCheck("readyz", healthz.Ping); err != nil {
		setupLog.Error(err, "Failed to set up ready check")
		os.Exit(1)
	}

	setupLog.Info("Starting manager")
	if err := mgr.Start(ctx); err != nil {
		setupLog.Error(err, "Failed to run manager")
		os.Exit(1)
	}
}
