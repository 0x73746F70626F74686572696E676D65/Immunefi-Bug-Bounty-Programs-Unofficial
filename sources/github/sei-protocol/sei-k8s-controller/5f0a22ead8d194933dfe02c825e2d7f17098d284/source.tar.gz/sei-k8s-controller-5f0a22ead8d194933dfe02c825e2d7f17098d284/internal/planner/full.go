package planner

import (
	"fmt"

	seiconfig "github.com/sei-protocol/sei-config"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"

	seiv1alpha1 "github.com/sei-protocol/sei-k8s-controller/api/v1alpha1"
	"github.com/sei-protocol/sei-k8s-controller/internal/platform"
	"github.com/sei-protocol/sei-k8s-controller/internal/task"
)

type fullNodePlanner struct {
	platform platform.Config
}

func (p *fullNodePlanner) Mode() string { return string(seiconfig.ModeFull) }

func (p *fullNodePlanner) Validate(node *seiv1alpha1.SeiNode) error {
	if node.Spec.FullNode == nil {
		return fmt.Errorf("fullNode sub-spec is nil")
	}
	if err := validateSnapshotGeneration(node.Spec.FullNode.SnapshotGeneration); err != nil {
		return fmt.Errorf("fullNode: %w", err)
	}
	return nil
}

func (p *fullNodePlanner) BuildPlan(node *seiv1alpha1.SeiNode) (*seiv1alpha1.TaskPlan, error) {
	if node.Status.Phase == seiv1alpha1.PhaseRunning {
		return p.buildRunningPlan(node)
	}
	fn := node.Spec.FullNode
	intent := &seiconfig.ConfigIntent{
		Mode:      seiconfig.ModeFull,
		Overrides: mergeOverrides(mergeOverrides(commonOverrides(node), p.controllerOverrides(node)), node.Spec.Overrides),
	}
	return buildBasePlan(node, fn.Snapshot, intent)
}

// buildRunningPlan returns the update plan for a Running full node, or
// nil if no drift. pelletier/go-toml/v2 does not preserve comments on
// re-encode — the first config-patch erases operator-added comments.
func (p *fullNodePlanner) buildRunningPlan(node *seiv1alpha1.SeiNode) (*seiv1alpha1.TaskPlan, error) {
	if podTemplateDrifted(node, p.platform) {
		prog := []string{
			task.TaskTypeApplyStatefulSet,
			task.TaskTypeApplyService,
			TaskConfigPatch,
			TaskConfigValidate,
			task.TaskTypeReplacePod,
			task.TaskTypeObserveImage,
			TaskMarkReady,
		}
		plan, err := assembleUpdatePlan(node, prog, p2pConfigPatch(node))
		if err != nil {
			return nil, err
		}
		setNodeUpdateCondition(node, metav1.ConditionTrue, "UpdateStarted", podTemplateDriftMessage(node, p.platform))
		return plan, nil
	}
	if configValuesDrifted(node) {
		return buildConfigUpdatePlan(node)
	}
	if sidecarNeedsReapproval(node) {
		return buildMarkReadyPlan(node)
	}
	return nil, nil
}

func (p *fullNodePlanner) controllerOverrides(node *seiv1alpha1.SeiNode) map[string]string {
	// A frozen node produces no new blocks, so it never generates snapshots.
	// FullNodeSpec's CEL rule rejects both fields together, so this returns
	// rather than merging.
	if freeze := node.Spec.FullNode.Freeze; freeze != nil {
		return freezeOverrides(freeze)
	}
	sg := node.Spec.FullNode.SnapshotGeneration
	if sg == nil || sg.Tendermint == nil {
		return nil
	}
	return seiconfig.SnapshotGenerationOverrides(sg.Tendermint.KeepRecent)
}
