package planner

import (
	"slices"
	"strings"
	"testing"

	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"

	seiv1alpha1 "github.com/sei-protocol/sei-k8s-controller/api/v1alpha1"
	"github.com/sei-protocol/sei-k8s-controller/internal/task"
)

func TestValidatorPlanner_Validate_SigningKey(t *testing.T) {
	cases := []struct {
		name    string
		spec    seiv1alpha1.ValidatorSpec
		wantErr string
	}{
		{
			name: "no signingKey is fine",
			spec: seiv1alpha1.ValidatorSpec{},
		},
		{
			name: "signingKey + nodeKey with distinct secretNames is valid",
			spec: seiv1alpha1.ValidatorSpec{
				SigningKey: &seiv1alpha1.SigningKeySource{
					Secret: &seiv1alpha1.SecretSigningKeySource{SecretName: "validator-0-key"},
				},
				NodeKey: &seiv1alpha1.NodeKeySource{
					Secret: &seiv1alpha1.SecretNodeKeySource{SecretName: "validator-0-nodekey"},
				},
			},
		},
		{
			name: "signingKey + nodeKey + s3 snapshot is valid (migration use case)",
			spec: seiv1alpha1.ValidatorSpec{
				Snapshot: &seiv1alpha1.SnapshotSource{
					S3: &seiv1alpha1.S3SnapshotSource{TargetHeight: 12345678},
				},
				SigningKey: &seiv1alpha1.SigningKeySource{
					Secret: &seiv1alpha1.SecretSigningKeySource{SecretName: "validator-0-key"},
				},
				NodeKey: &seiv1alpha1.NodeKeySource{
					Secret: &seiv1alpha1.SecretNodeKeySource{SecretName: "validator-0-nodekey"},
				},
			},
		},
		{
			name: "signingKey without nodeKey is rejected",
			spec: seiv1alpha1.ValidatorSpec{
				SigningKey: &seiv1alpha1.SigningKeySource{
					Secret: &seiv1alpha1.SecretSigningKeySource{SecretName: "validator-0-key"},
				},
			},
			wantErr: "nodeKey is required when signingKey is set",
		},
		{
			name: "nodeKey without signingKey is rejected",
			spec: seiv1alpha1.ValidatorSpec{
				NodeKey: &seiv1alpha1.NodeKeySource{
					Secret: &seiv1alpha1.SecretNodeKeySource{SecretName: "validator-0-nodekey"},
				},
			},
			wantErr: "nodeKey requires signingKey to be set",
		},
		{
			name: "signingKey and nodeKey sharing a secretName is rejected",
			spec: seiv1alpha1.ValidatorSpec{
				SigningKey: &seiv1alpha1.SigningKeySource{
					Secret: &seiv1alpha1.SecretSigningKeySource{SecretName: "shared-keys"},
				},
				NodeKey: &seiv1alpha1.NodeKeySource{
					Secret: &seiv1alpha1.SecretNodeKeySource{SecretName: "shared-keys"},
				},
			},
			wantErr: "must reference distinct Secrets",
		},
		{
			name: "signingKey with empty secretName is rejected",
			spec: seiv1alpha1.ValidatorSpec{
				SigningKey: &seiv1alpha1.SigningKeySource{
					Secret: &seiv1alpha1.SecretSigningKeySource{SecretName: ""},
				},
			},
			wantErr: "signingKey.secret.secretName is required",
		},
		{
			name: "signingKey with nil secret variant is rejected",
			spec: seiv1alpha1.ValidatorSpec{
				SigningKey: &seiv1alpha1.SigningKeySource{},
			},
			wantErr: "signingKey.secret.secretName is required",
		},
		{
			name: "signingKey + genesisCeremony is rejected",
			spec: seiv1alpha1.ValidatorSpec{
				GenesisCeremony: &seiv1alpha1.GenesisCeremonyNodeConfig{
					ChainID:        "pacific-1",
					StakingAmount:  "1000000usei",
					AccountBalance: "1000000usei",
				},
				SigningKey: &seiv1alpha1.SigningKeySource{
					Secret: &seiv1alpha1.SecretSigningKeySource{SecretName: "validator-0-key"},
				},
				NodeKey: &seiv1alpha1.NodeKeySource{
					Secret: &seiv1alpha1.SecretNodeKeySource{SecretName: "validator-0-nodekey"},
				},
			},
			wantErr: "signingKey is mutually exclusive with genesisCeremony",
		},
	}

	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			node := &seiv1alpha1.SeiNode{
				ObjectMeta: metav1.ObjectMeta{Name: "validator-0", Namespace: "pacific-1"},
				Spec: seiv1alpha1.SeiNodeSpec{
					ChainID:   "pacific-1",
					Image:     "seid:v6.4.1",
					Validator: &tc.spec,
				},
			}
			err := (&validatorPlanner{}).Validate(node)
			if tc.wantErr == "" {
				if err != nil {
					t.Fatalf("Validate: unexpected error: %v", err)
				}
				return
			}
			if err == nil {
				t.Fatalf("Validate: expected error containing %q, got nil", tc.wantErr)
			}
			if !strings.Contains(err.Error(), tc.wantErr) {
				t.Fatalf("Validate: error = %q, want containing %q", err.Error(), tc.wantErr)
			}
		})
	}
}

func TestValidatorPlanner_Validate_OperatorKeyringDistinctness(t *testing.T) {
	const (
		sk   = "validator-0-signing"
		nk   = "validator-0-nodekey"
		opk  = "validator-0-opk"
		pass = "validator-0-opk-pass"
	)
	cases := []struct {
		name    string
		spec    seiv1alpha1.ValidatorSpec
		wantErr string
	}{
		{
			name: "all four secrets distinct is valid",
			spec: seiv1alpha1.ValidatorSpec{
				SigningKey: &seiv1alpha1.SigningKeySource{Secret: &seiv1alpha1.SecretSigningKeySource{SecretName: sk}},
				NodeKey:    &seiv1alpha1.NodeKeySource{Secret: &seiv1alpha1.SecretNodeKeySource{SecretName: nk}},
				OperatorKeyring: &seiv1alpha1.OperatorKeyringSource{
					Secret: &seiv1alpha1.SecretOperatorKeyringSource{
						SecretName:          opk,
						PassphraseSecretRef: seiv1alpha1.PassphraseSecretRef{SecretName: pass},
					},
				},
			},
		},
		{
			name: "operatorKeyring Secret equals signingKey Secret is rejected",
			spec: seiv1alpha1.ValidatorSpec{
				SigningKey: &seiv1alpha1.SigningKeySource{Secret: &seiv1alpha1.SecretSigningKeySource{SecretName: sk}},
				NodeKey:    &seiv1alpha1.NodeKeySource{Secret: &seiv1alpha1.SecretNodeKeySource{SecretName: nk}},
				OperatorKeyring: &seiv1alpha1.OperatorKeyringSource{
					Secret: &seiv1alpha1.SecretOperatorKeyringSource{
						SecretName:          sk,
						PassphraseSecretRef: seiv1alpha1.PassphraseSecretRef{SecretName: pass},
					},
				},
			},
			wantErr: "operatorKeyring Secret",
		},
		{
			name: "operatorKeyring Secret equals nodeKey Secret is rejected",
			spec: seiv1alpha1.ValidatorSpec{
				SigningKey: &seiv1alpha1.SigningKeySource{Secret: &seiv1alpha1.SecretSigningKeySource{SecretName: sk}},
				NodeKey:    &seiv1alpha1.NodeKeySource{Secret: &seiv1alpha1.SecretNodeKeySource{SecretName: nk}},
				OperatorKeyring: &seiv1alpha1.OperatorKeyringSource{
					Secret: &seiv1alpha1.SecretOperatorKeyringSource{
						SecretName:          nk,
						PassphraseSecretRef: seiv1alpha1.PassphraseSecretRef{SecretName: pass},
					},
				},
			},
			wantErr: "must differ from nodeKey Secret",
		},
		{
			name: "operatorKeyring Secret equals its own passphrase Secret is rejected",
			spec: seiv1alpha1.ValidatorSpec{
				OperatorKeyring: &seiv1alpha1.OperatorKeyringSource{
					Secret: &seiv1alpha1.SecretOperatorKeyringSource{
						SecretName:          opk,
						PassphraseSecretRef: seiv1alpha1.PassphraseSecretRef{SecretName: opk},
					},
				},
			},
			wantErr: "must differ from its passphrase Secret",
		},
		{
			name: "passphrase Secret equals signingKey Secret is rejected",
			spec: seiv1alpha1.ValidatorSpec{
				SigningKey: &seiv1alpha1.SigningKeySource{Secret: &seiv1alpha1.SecretSigningKeySource{SecretName: sk}},
				NodeKey:    &seiv1alpha1.NodeKeySource{Secret: &seiv1alpha1.SecretNodeKeySource{SecretName: nk}},
				OperatorKeyring: &seiv1alpha1.OperatorKeyringSource{
					Secret: &seiv1alpha1.SecretOperatorKeyringSource{
						SecretName:          opk,
						PassphraseSecretRef: seiv1alpha1.PassphraseSecretRef{SecretName: sk},
					},
				},
			},
			wantErr: "passphrase Secret",
		},
		{
			name: "passphrase Secret equals nodeKey Secret is rejected",
			spec: seiv1alpha1.ValidatorSpec{
				SigningKey: &seiv1alpha1.SigningKeySource{Secret: &seiv1alpha1.SecretSigningKeySource{SecretName: sk}},
				NodeKey:    &seiv1alpha1.NodeKeySource{Secret: &seiv1alpha1.SecretNodeKeySource{SecretName: nk}},
				OperatorKeyring: &seiv1alpha1.OperatorKeyringSource{
					Secret: &seiv1alpha1.SecretOperatorKeyringSource{
						SecretName:          opk,
						PassphraseSecretRef: seiv1alpha1.PassphraseSecretRef{SecretName: nk},
					},
				},
			},
			wantErr: "passphrase Secret",
		},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			node := &seiv1alpha1.SeiNode{
				ObjectMeta: metav1.ObjectMeta{Name: "validator-0", Namespace: "pacific-1"},
				Spec: seiv1alpha1.SeiNodeSpec{
					ChainID:   "pacific-1",
					Image:     "seid:v6.4.1",
					Validator: &tc.spec,
				},
			}
			err := (&validatorPlanner{}).Validate(node)
			if tc.wantErr == "" {
				if err != nil {
					t.Fatalf("Validate: unexpected error: %v", err)
				}
				return
			}
			if err == nil {
				t.Fatalf("Validate: expected error containing %q, got nil", tc.wantErr)
			}
			if !strings.Contains(err.Error(), tc.wantErr) {
				t.Fatalf("Validate: error = %q, want containing %q", err.Error(), tc.wantErr)
			}
		})
	}
}

// taskTypes returns the ordered list of task types in a plan, for assertions.
func taskTypes(plan *seiv1alpha1.TaskPlan) []string {
	out := make([]string, len(plan.Tasks))
	for i, t := range plan.Tasks {
		out[i] = t.Type
	}
	return out
}

// indexOfTaskType returns the position of taskType in plan, or -1.
func indexOfTaskType(plan *seiv1alpha1.TaskPlan, taskType string) int {
	return slices.Index(taskTypes(plan), taskType)
}

func TestValidatorPlanner_BuildPlan_IdentityInsertsValidateTasks_Base(t *testing.T) {
	node := &seiv1alpha1.SeiNode{
		ObjectMeta: metav1.ObjectMeta{Name: "validator-0", Namespace: "pacific-1"},
		Spec: seiv1alpha1.SeiNodeSpec{
			ChainID: "pacific-1",
			Image:   "seid:v6.4.1",
			Validator: &seiv1alpha1.ValidatorSpec{
				SigningKey: &seiv1alpha1.SigningKeySource{
					Secret: &seiv1alpha1.SecretSigningKeySource{SecretName: "validator-0-key"},
				},
				NodeKey: &seiv1alpha1.NodeKeySource{
					Secret: &seiv1alpha1.SecretNodeKeySource{SecretName: "validator-0-nodekey"},
				},
			},
		},
	}
	plan, err := (&validatorPlanner{}).BuildPlan(node)
	if err != nil {
		t.Fatalf("BuildPlan: %v", err)
	}

	pvcIdx := indexOfTaskType(plan, task.TaskTypeEnsureDataPVC)
	signingIdx := indexOfTaskType(plan, task.TaskTypeValidateSigningKey)
	nodeKeyIdx := indexOfTaskType(plan, task.TaskTypeValidateNodeKey)
	stsIdx := indexOfTaskType(plan, task.TaskTypeApplyStatefulSet)

	if signingIdx < 0 || nodeKeyIdx < 0 {
		t.Fatalf("plan must contain both validate-signing-key and validate-node-key; got %v", taskTypes(plan))
	}
	if pvcIdx >= signingIdx || signingIdx >= nodeKeyIdx || nodeKeyIdx >= stsIdx {
		t.Fatalf("expected ordering pvc(%d) < signing(%d) < nodeKey(%d) < apply-statefulset(%d); got %v",
			pvcIdx, signingIdx, nodeKeyIdx, stsIdx, taskTypes(plan))
	}
}

func TestValidatorPlanner_BuildPlan_OperatorKeyringInsertsValidateTask_Base(t *testing.T) {
	node := &seiv1alpha1.SeiNode{
		ObjectMeta: metav1.ObjectMeta{Name: "validator-0", Namespace: "pacific-1"},
		Spec: seiv1alpha1.SeiNodeSpec{
			ChainID: "pacific-1",
			Image:   "seid:v6.4.1",
			Validator: &seiv1alpha1.ValidatorSpec{
				SigningKey: &seiv1alpha1.SigningKeySource{
					Secret: &seiv1alpha1.SecretSigningKeySource{SecretName: "validator-0-key"},
				},
				NodeKey: &seiv1alpha1.NodeKeySource{
					Secret: &seiv1alpha1.SecretNodeKeySource{SecretName: "validator-0-nodekey"},
				},
				OperatorKeyring: &seiv1alpha1.OperatorKeyringSource{
					Secret: &seiv1alpha1.SecretOperatorKeyringSource{
						SecretName: "validator-0-opk",
						KeyName:    "node_admin",
						PassphraseSecretRef: seiv1alpha1.PassphraseSecretRef{
							SecretName: "validator-0-opk-passphrase",
							Key:        "passphrase",
						},
					},
				},
			},
		},
	}
	plan, err := (&validatorPlanner{}).BuildPlan(node)
	if err != nil {
		t.Fatalf("BuildPlan: %v", err)
	}

	nodeKeyIdx := indexOfTaskType(plan, task.TaskTypeValidateNodeKey)
	keyringIdx := indexOfTaskType(plan, task.TaskTypeValidateOperatorKeyring)
	stsIdx := indexOfTaskType(plan, task.TaskTypeApplyStatefulSet)
	if keyringIdx < 0 {
		t.Fatalf("plan must contain %s; got %v", task.TaskTypeValidateOperatorKeyring, taskTypes(plan))
	}
	if nodeKeyIdx >= keyringIdx || keyringIdx >= stsIdx {
		t.Fatalf("expected ordering nodeKey(%d) < operatorKeyring(%d) < apply-statefulset(%d); got %v",
			nodeKeyIdx, keyringIdx, stsIdx, taskTypes(plan))
	}

	for _, pt := range plan.Tasks {
		if pt.Type != task.TaskTypeValidateOperatorKeyring {
			continue
		}
		raw := string(pt.Params.Raw)
		if !strings.Contains(raw, "validator-0-opk") {
			t.Fatalf("validate-operator-keyring params must reference data secretName; got %q", raw)
		}
		if !strings.Contains(raw, "validator-0-opk-passphrase") {
			t.Fatalf("validate-operator-keyring params must reference passphrase secretName; got %q", raw)
		}
		if !strings.Contains(raw, "node_admin") {
			t.Fatalf("validate-operator-keyring params must reference keyName; got %q", raw)
		}
	}
}

func TestValidatorPlanner_BuildPlan_NoOperatorKeyringOmitsValidateTask(t *testing.T) {
	node := &seiv1alpha1.SeiNode{
		ObjectMeta: metav1.ObjectMeta{Name: "validator-0", Namespace: "pacific-1"},
		Spec: seiv1alpha1.SeiNodeSpec{
			ChainID: "pacific-1",
			Image:   "seid:v6.4.1",
			Validator: &seiv1alpha1.ValidatorSpec{
				SigningKey: &seiv1alpha1.SigningKeySource{
					Secret: &seiv1alpha1.SecretSigningKeySource{SecretName: "validator-0-key"},
				},
				NodeKey: &seiv1alpha1.NodeKeySource{
					Secret: &seiv1alpha1.SecretNodeKeySource{SecretName: "validator-0-nodekey"},
				},
			},
		},
	}
	plan, err := (&validatorPlanner{}).BuildPlan(node)
	if err != nil {
		t.Fatalf("BuildPlan: %v", err)
	}
	if idx := indexOfTaskType(plan, task.TaskTypeValidateOperatorKeyring); idx >= 0 {
		t.Fatalf("plan must not contain %s when OperatorKeyring is unset; got %v at index %d",
			task.TaskTypeValidateOperatorKeyring, taskTypes(plan), idx)
	}
}

func TestValidatorPlanner_BuildPlan_NoSigningKeyOmitsValidateTask(t *testing.T) {
	node := &seiv1alpha1.SeiNode{
		ObjectMeta: metav1.ObjectMeta{Name: "validator-0", Namespace: "pacific-1"},
		Spec: seiv1alpha1.SeiNodeSpec{
			ChainID:   "pacific-1",
			Image:     "seid:v6.4.1",
			Validator: &seiv1alpha1.ValidatorSpec{},
		},
	}
	plan, err := (&validatorPlanner{}).BuildPlan(node)
	if err != nil {
		t.Fatalf("BuildPlan: %v", err)
	}
	if idx := indexOfTaskType(plan, task.TaskTypeValidateSigningKey); idx >= 0 {
		t.Fatalf("plan must not contain %s when SigningKey is unset; got %v at index %d",
			task.TaskTypeValidateSigningKey, taskTypes(plan), idx)
	}
}
