package noderesource

import (
	"context"
	"testing"

	. "github.com/onsi/gomega"

	appsv1 "k8s.io/api/apps/v1"
	apierrors "k8s.io/apimachinery/pkg/api/errors"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	k8sruntime "k8s.io/apimachinery/pkg/runtime"
	"k8s.io/apimachinery/pkg/types"
	clientgoscheme "k8s.io/client-go/kubernetes/scheme"
	"sigs.k8s.io/controller-runtime/pkg/client/fake"

	seiv1alpha1 "github.com/sei-protocol/sei-k8s-controller/api/v1alpha1"
	"github.com/sei-protocol/sei-k8s-controller/internal/platform/platformtest"
)

const (
	testNamespace   = "default"
	impostorName    = "impostor-swap"
	steadyStateName = "steady-state"
	originalTestUID = "uid-A"
	impostorTestUID = "uid-B"
)

// newSyncTestScheme builds a scheme with both core and sei.io types.
// SyncStatefulSet writes appsv1.StatefulSet and reads seiv1alpha1.SeiNode,
// so both must be registered for the fake client to encode/decode.
func newSyncTestScheme(t *testing.T) *k8sruntime.Scheme {
	t.Helper()
	s := k8sruntime.NewScheme()
	if err := clientgoscheme.AddToScheme(s); err != nil {
		t.Fatal(err)
	}
	if err := seiv1alpha1.AddToScheme(s); err != nil {
		t.Fatal(err)
	}
	return s
}

// TestSyncStatefulSet_FirstCreate exercises the cold-start path: no
// tracked Status, no live StatefulSet. SyncStatefulSet renders the
// desired object and Server-Side-Applies it, returning the live result
// for the caller to record on Status.
func TestSyncStatefulSet_FirstCreate(t *testing.T) {
	g := NewWithT(t)
	s := newSyncTestScheme(t)

	node := newGenesisNode("first-create", testNamespace)
	c := fake.NewClientBuilder().
		WithScheme(s).
		WithObjects(node).
		WithStatusSubresource(&seiv1alpha1.SeiNode{}).
		Build()

	sts, err := SyncStatefulSet(context.Background(), c, s, node, platformtest.Config())
	g.Expect(err).NotTo(HaveOccurred())
	g.Expect(sts).NotTo(BeNil(), "first-create must return the applied StatefulSet")
	g.Expect(sts.Name).To(Equal("first-create"))
	g.Expect(sts.Namespace).To(Equal(testNamespace))

	live := &appsv1.StatefulSet{}
	g.Expect(c.Get(context.Background(), types.NamespacedName{Name: "first-create", Namespace: testNamespace}, live)).To(Succeed())
}

// TestSyncStatefulSet_ImpostorDeletes covers the UID-mismatch branch.
// Status.StatefulSet tracks UID-A. A live StatefulSet with the same
// name but UID-B (the "impostor") is present. SyncStatefulSet must
// Delete the impostor and return (nil, nil) — leaving the Apply to the
// next reconcile, when Get will observe NotFound and the Apply lands
// as a fresh Create. Splitting Delete and Apply across reconciles
// avoids applying onto a still-deleting object.
func TestSyncStatefulSet_ImpostorDeletes(t *testing.T) {
	g := NewWithT(t)
	s := newSyncTestScheme(t)

	node := newGenesisNode(impostorName, testNamespace)
	node.Status.StatefulSet = &seiv1alpha1.StatefulSetRef{
		Name: impostorName,
		UID:  originalTestUID,
	}

	impostor := &appsv1.StatefulSet{
		ObjectMeta: metav1.ObjectMeta{
			Name:      impostorName,
			Namespace: testNamespace,
			UID:       impostorTestUID,
		},
	}

	c := fake.NewClientBuilder().
		WithScheme(s).
		WithObjects(node, impostor).
		WithStatusSubresource(&seiv1alpha1.SeiNode{}).
		Build()

	sts, err := SyncStatefulSet(context.Background(), c, s, node, platformtest.Config())
	g.Expect(err).NotTo(HaveOccurred())
	g.Expect(sts).To(BeNil(), "impostor branch returns nil so caller requeues without applying")

	// The impostor must be gone from the apiserver (fake client honors
	// Background-propagation Delete on objects with no finalizers).
	live := &appsv1.StatefulSet{}
	err = c.Get(context.Background(), types.NamespacedName{Name: impostorName, Namespace: testNamespace}, live)
	g.Expect(apierrors.IsNotFound(err)).To(BeTrue(), "impostor must be deleted; got err=%v", err)
}

// TestSyncStatefulSet_ImpostorThenApply simulates the two-reconcile
// recovery sequence end-to-end on the fake client. Reconcile 1 deletes
// the impostor and returns nil. Reconcile 2 observes NotFound and
// Applies fresh; the returned StatefulSet has a new identity that the
// caller stamps onto Status.
func TestSyncStatefulSet_ImpostorThenApply(t *testing.T) {
	g := NewWithT(t)
	s := newSyncTestScheme(t)

	node := newGenesisNode("impostor-2reconcile", testNamespace)
	node.Status.StatefulSet = &seiv1alpha1.StatefulSetRef{
		Name: "impostor-2reconcile",
		UID:  originalTestUID,
	}

	impostor := &appsv1.StatefulSet{
		ObjectMeta: metav1.ObjectMeta{
			Name:      "impostor-2reconcile",
			Namespace: testNamespace,
			UID:       impostorTestUID,
		},
	}

	c := fake.NewClientBuilder().
		WithScheme(s).
		WithObjects(node, impostor).
		WithStatusSubresource(&seiv1alpha1.SeiNode{}).
		Build()

	// Reconcile 1: detect mismatch, Delete, clear stale tracking,
	// return nil.
	sts, err := SyncStatefulSet(context.Background(), c, s, node, platformtest.Config())
	g.Expect(err).NotTo(HaveOccurred())
	g.Expect(sts).To(BeNil())
	g.Expect(node.Status.StatefulSet).To(BeNil(),
		"impostor delete must clear Status.StatefulSet so a subsequent Apply is not misclassified")

	// Reconcile 2: Status was cleared, falls into adopt-on-observe.
	// Get sees NotFound (impostor deleted), Apply creates fresh.
	sts, err = SyncStatefulSet(context.Background(), c, s, node, platformtest.Config())
	g.Expect(err).NotTo(HaveOccurred())
	g.Expect(sts).NotTo(BeNil(), "second reconcile must Apply fresh")
	g.Expect(sts.UID).NotTo(Equal(types.UID(originalTestUID)))
	g.Expect(sts.UID).NotTo(Equal(types.UID(impostorTestUID)))
}

// TestSyncStatefulSet_ImpostorClearPreventsChurn pins the cross-
// reconcile invariant: when the controller deletes an impostor and
// the plan executor Applies fresh in the same pass, the next reconcile
// must adopt that fresh StatefulSet rather than delete it as another
// impostor. Clearing Status.StatefulSet on impostor delete is what
// routes the next reconcile through adopt-on-observe.
func TestSyncStatefulSet_ImpostorClearPreventsChurn(t *testing.T) {
	g := NewWithT(t)
	s := newSyncTestScheme(t)

	node := newGenesisNode(impostorName, testNamespace)
	node.Status.StatefulSet = &seiv1alpha1.StatefulSetRef{
		Name: impostorName,
		UID:  originalTestUID,
	}
	impostor := &appsv1.StatefulSet{
		ObjectMeta: metav1.ObjectMeta{
			Name:      impostorName,
			Namespace: testNamespace,
			UID:       impostorTestUID,
		},
	}
	c := fake.NewClientBuilder().
		WithScheme(s).
		WithObjects(node, impostor).
		WithStatusSubresource(&seiv1alpha1.SeiNode{}).
		Build()

	// Reconcile N (controller wrapper): impostor detected, Deleted,
	// Status.StatefulSet cleared.
	_, err := SyncStatefulSet(context.Background(), c, s, node, platformtest.Config())
	g.Expect(err).NotTo(HaveOccurred())
	g.Expect(node.Status.StatefulSet).To(BeNil())

	// Still inside reconcile N (plan task): SyncStatefulSet again.
	// Status is nil, impostor check skipped, Get NotFound, Apply lands.
	taskSTS, err := SyncStatefulSet(context.Background(), c, s, node, platformtest.Config())
	g.Expect(err).NotTo(HaveOccurred())
	g.Expect(taskSTS).NotTo(BeNil(), "task call after impostor clear must Apply a fresh StatefulSet")
	newUID := taskSTS.UID

	// Reconcile N+1 (controller wrapper): would-be-bug scenario.
	// Status.StatefulSet still nil (controller wrapper does not stamp
	// when SyncStatefulSet returned nil in reconcile N). With the
	// clear, this call adopts the freshly Applied STS rather than
	// deleting it as another impostor.
	adopted, err := SyncStatefulSet(context.Background(), c, s, node, platformtest.Config())
	g.Expect(err).NotTo(HaveOccurred())
	g.Expect(adopted).NotTo(BeNil())
	g.Expect(adopted.UID).To(Equal(newUID),
		"reconcile N+1 must adopt the task-Applied StatefulSet, not delete it as another impostor")
}

// TestSyncStatefulSet_MatchingUID is the steady-state path. A live
// StatefulSet exists whose UID matches Status.StatefulSet. Sync must
// not delete; it Applies (idempotent) and returns the live object.
func TestSyncStatefulSet_MatchingUID(t *testing.T) {
	g := NewWithT(t)
	s := newSyncTestScheme(t)

	node := newGenesisNode(steadyStateName, testNamespace)
	node.Status.StatefulSet = &seiv1alpha1.StatefulSetRef{
		Name: steadyStateName,
		UID:  originalTestUID,
	}

	existing := &appsv1.StatefulSet{
		ObjectMeta: metav1.ObjectMeta{
			Name:      steadyStateName,
			Namespace: testNamespace,
			UID:       originalTestUID,
		},
	}

	c := fake.NewClientBuilder().
		WithScheme(s).
		WithObjects(node, existing).
		WithStatusSubresource(&seiv1alpha1.SeiNode{}).
		Build()

	sts, err := SyncStatefulSet(context.Background(), c, s, node, platformtest.Config())
	g.Expect(err).NotTo(HaveOccurred())
	g.Expect(sts).NotTo(BeNil())

	// The original object must still be present (UID preserved means
	// no delete occurred).
	live := &appsv1.StatefulSet{}
	g.Expect(c.Get(context.Background(), types.NamespacedName{Name: steadyStateName, Namespace: testNamespace}, live)).To(Succeed())
	g.Expect(live.UID).To(Equal(types.UID(originalTestUID)))
}

// TestSyncStatefulSet_TrackedButMissing covers the "controller restarts
// after operator delete" path. Status tracks a UID but the live STS is
// gone. Sync skips the impostor branch and Applies fresh.
func TestSyncStatefulSet_TrackedButMissing(t *testing.T) {
	g := NewWithT(t)
	s := newSyncTestScheme(t)

	node := newGenesisNode("tracked-missing", testNamespace)
	node.Status.StatefulSet = &seiv1alpha1.StatefulSetRef{
		Name: "tracked-missing",
		UID:  originalTestUID,
	}

	c := fake.NewClientBuilder().
		WithScheme(s).
		WithObjects(node).
		WithStatusSubresource(&seiv1alpha1.SeiNode{}).
		Build()

	sts, err := SyncStatefulSet(context.Background(), c, s, node, platformtest.Config())
	g.Expect(err).NotTo(HaveOccurred())
	g.Expect(sts).NotTo(BeNil(), "tracked-but-missing must Apply fresh on the same reconcile")
}

// TestSyncStatefulSet_PausedReplicasZero asserts the pause behavior:
// Spec.Paused=true forces Replicas=0 in the Applied object regardless
// of whether the node is in the impostor branch path.
func TestSyncStatefulSet_PausedReplicasZero(t *testing.T) {
	g := NewWithT(t)
	s := newSyncTestScheme(t)

	node := newGenesisNode("paused-zero", testNamespace)
	node.Spec.Paused = true

	c := fake.NewClientBuilder().
		WithScheme(s).
		WithObjects(node).
		WithStatusSubresource(&seiv1alpha1.SeiNode{}).
		Build()

	sts, err := SyncStatefulSet(context.Background(), c, s, node, platformtest.Config())
	g.Expect(err).NotTo(HaveOccurred())
	g.Expect(sts).NotTo(BeNil())
	g.Expect(sts.Spec.Replicas).NotTo(BeNil())
	g.Expect(*sts.Spec.Replicas).To(Equal(int32(0)))
}

// TestSyncStatefulSet_SetsControllerReferenceToNode is the middle hop of the
// SeiNetwork -> SeiNode -> StatefulSet -> pod ownership chain. Without this
// reference nothing links the workload to the node that renders it, so
// deleting a SeiNetwork garbage-collects the SeiNodes and leaves their
// StatefulSets — and their validator pods — running.
//
// The pod hop below is set by the StatefulSet controller, not by us; asserting
// the selector here is the closest this layer gets to it, since a StatefulSet
// with no selector owns no pods.
func TestSyncStatefulSet_SetsControllerReferenceToNode(t *testing.T) {
	g := NewWithT(t)
	s := newSyncTestScheme(t)

	node := newGenesisNode("owned-sts", testNamespace)
	node.UID = "node-uid-owned"
	c := fake.NewClientBuilder().
		WithScheme(s).
		WithObjects(node).
		WithStatusSubresource(&seiv1alpha1.SeiNode{}).
		Build()

	_, err := SyncStatefulSet(context.Background(), c, s, node, platformtest.Config())
	g.Expect(err).NotTo(HaveOccurred())

	live := &appsv1.StatefulSet{}
	g.Expect(c.Get(context.Background(),
		types.NamespacedName{Name: "owned-sts", Namespace: testNamespace}, live)).To(Succeed())

	ref := metav1.GetControllerOf(live)
	g.Expect(ref).NotTo(BeNil(), "the StatefulSet must name its SeiNode as controller")
	g.Expect(ref.Kind).To(Equal("SeiNode"))
	g.Expect(ref.Name).To(Equal(node.Name))
	g.Expect(ref.UID).To(Equal(node.UID))

	g.Expect(live.Spec.Selector).NotTo(BeNil())
	g.Expect(live.Spec.Selector.MatchLabels).NotTo(BeEmpty(),
		"a StatefulSet with no selector owns no pods, so the pod hop would be broken")
}

// A re-Apply must not drop the controller reference. SyncStatefulSet renders a
// fresh object every call and Server-Side-Applies it with ForceOwnership, so a
// render that stopped carrying the reference would silently strip it from the
// live object and break the chain on an already-running node.
func TestSyncStatefulSet_ReApplyKeepsControllerReference(t *testing.T) {
	g := NewWithT(t)
	s := newSyncTestScheme(t)
	ctx := context.Background()

	node := newGenesisNode("reapply-sts", testNamespace)
	node.UID = "node-uid-reapply"
	c := fake.NewClientBuilder().
		WithScheme(s).
		WithObjects(node).
		WithStatusSubresource(&seiv1alpha1.SeiNode{}).
		Build()

	first, err := SyncStatefulSet(ctx, c, s, node, platformtest.Config())
	g.Expect(err).NotTo(HaveOccurred())
	node.Status.StatefulSet = &seiv1alpha1.StatefulSetRef{Name: first.Name, UID: first.UID}

	_, err = SyncStatefulSet(ctx, c, s, node, platformtest.Config())
	g.Expect(err).NotTo(HaveOccurred())

	live := &appsv1.StatefulSet{}
	g.Expect(c.Get(ctx, types.NamespacedName{Name: "reapply-sts", Namespace: testNamespace}, live)).To(Succeed())
	g.Expect(metav1.GetControllerOf(live)).NotTo(BeNil(),
		"re-Apply must not strip the SeiNode controller reference")
}
