package seinetwork

import (
	"context"
	"fmt"
	"time"

	corev1 "k8s.io/api/core/v1"
	apimeta "k8s.io/apimachinery/pkg/api/meta"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"sigs.k8s.io/controller-runtime/pkg/client"
	"sigs.k8s.io/controller-runtime/pkg/log"

	seiv1alpha1 "github.com/sei-protocol/sei-k8s-controller/api/v1alpha1"
	"github.com/sei-protocol/sei-k8s-controller/internal/noderesource"
	"github.com/sei-protocol/sei-k8s-controller/internal/planner"
)

func (r *SeiNetworkReconciler) updateStatus(ctx context.Context, network *seiv1alpha1.SeiNetwork, statusBase client.Patch) error {
	nodes, err := r.listChildSeiNodes(ctx, network)
	if err != nil {
		return err
	}
	workerNodes, err := r.childWorkerNodes(ctx, network)
	if err != nil {
		// Placement is two fields of the report; a failed pod list degrades
		// them to Pending rather than holding back phase, replicas and
		// conditions, which are computed from the children alone.
		log.FromContext(ctx).Error(err, "reading validator placement; reporting every child as pending")
		workerNodes = nil
	}

	var readyReplicas, upToDateReplicas int32
	nodeStatuses := make([]seiv1alpha1.GroupNodeStatus, 0, len(nodes))
	for i := range nodes {
		node := &nodes[i]
		ready := childReady(node)
		if ready {
			readyReplicas++
		}
		if node.Status.CurrentImage == network.Spec.Image {
			upToDateReplicas++
		}
		placement := seiv1alpha1.PlacementPending
		if workerNodes[node.Name] != "" {
			placement = seiv1alpha1.PlacementScheduled
		}
		nodeStatuses = append(nodeStatuses, seiv1alpha1.GroupNodeStatus{
			Name:         node.Name,
			Phase:        node.Status.Phase,
			Ready:        ready,
			CurrentImage: node.Status.CurrentImage,
			WorkerNode:   workerNodes[node.Name],
			Placement:    placement,
		})
	}

	// ObservedGeneration tracks "controller has processed this spec" and
	// must advance on every reconcile that runs to completion, including
	// paused ones — generation-drift consumers (kubectl wait, ArgoCD,
	// Flux) depend on it. It defers to completePlan during plan execution.
	if !hasConditionTrue(network, seiv1alpha1.ConditionPlanInProgress) {
		network.Status.ObservedGeneration = network.Generation
	}
	network.Status.Replicas = network.Spec.Replicas
	network.Status.ReadyReplicas = readyReplicas
	network.Status.UpToDateReplicas = upToDateReplicas
	network.Status.Nodes = nodeStatuses
	network.Status.PerPodServices = populatePerPodServices(log.FromContext(ctx), nodes)
	network.Status.Endpoints = composeEndpoints(network, nodes)

	network.Status.Phase = computeGroupPhase(network, readyReplicas, network.Spec.Replicas, nodes)

	setNodesReadyCondition(network, readyReplicas, network.Spec.Replicas, nodes)
	setRolloutInProgressCondition(network, upToDateReplicas, network.Spec.Replicas, len(nodes))
	setProducingCondition(network, nodes, time.Now())

	return r.Status().Patch(ctx, network, statusBase)
}

// childReady is the network's notion of a ready child: Running, and — for an
// EVM-only child whose listener is enabled — EvmServing True. Running alone
// says seid is up; it does not say the EVM JSON-RPC surface the network
// publishes for that child answers, and a network must not read Ready while
// pointing consumers at a refused listener. An EVM-only child with its
// listener disabled serves nothing to publish, so Running is the whole story.
func childReady(node *seiv1alpha1.SeiNode) bool {
	if node.Status.Phase != seiv1alpha1.PhaseRunning {
		return false
	}
	engine := node.Spec.EffectiveExecutionEngine()
	if !engine.IsEvmOnly() || !engine.EvmHTTPEnabled() {
		return true
	}
	return apimeta.IsStatusConditionTrue(node.Status.Conditions, seiv1alpha1.ConditionEvmServing)
}

// childWorkerNodes maps each child SeiNode name to the worker node its pod is
// bound to, read from the pods rather than from any cached status so a
// reschedule is reflected on the next reconcile. A child with no bound pod is
// absent from the map. The pods are found by the sei.io/seinetwork label the
// network stamps into every child's podLabels; the sei.io/node label names the
// child.
func (r *SeiNetworkReconciler) childWorkerNodes(ctx context.Context, network *seiv1alpha1.SeiNetwork) (map[string]string, error) {
	var pods corev1.PodList
	if err := r.List(ctx, &pods,
		client.InNamespace(network.Namespace),
		client.MatchingLabels(seinetworkSelector(network)),
	); err != nil {
		return nil, fmt.Errorf("listing child pods: %w", err)
	}
	workerNodes := make(map[string]string, len(pods.Items))
	for i := range pods.Items {
		pod := &pods.Items[i]
		child := pod.Labels[noderesource.NodeLabel]
		if child == "" || pod.Spec.NodeName == "" || pod.DeletionTimestamp != nil {
			continue
		}
		// A pod in a terminal phase keeps its nodeName but no longer runs there.
		if pod.Status.Phase == corev1.PodSucceeded || pod.Status.Phase == corev1.PodFailed {
			continue
		}
		workerNodes[child] = pod.Spec.NodeName
	}
	return workerNodes, nil
}

// setRolloutInProgressCondition stamps the DERIVED RolloutInProgress
// projection each reconcile. True when a child's reported image lags
// spec.image (mid-roll or wedged on a bad tag); False/AllUpToDate at steady
// state. No plan or revision tracking owns this — it is pure computation from
// the child snapshot. Before any children exist there is nothing to roll, so
// it reads False/AllUpToDate (matching the seed in seedAlwaysPresentConditions).
func setRolloutInProgressCondition(network *seiv1alpha1.SeiNetwork, upToDate, desired int32, childCount int) {
	if childCount > 0 && upToDate < desired {
		setCondition(network, seiv1alpha1.ConditionRolloutInProgress, metav1.ConditionTrue,
			"ImageRolling", fmt.Sprintf("%d/%d replicas on spec.image", upToDate, desired))
		return
	}
	setCondition(network, seiv1alpha1.ConditionRolloutInProgress, metav1.ConditionFalse,
		"AllUpToDate", fmt.Sprintf("%d/%d replicas on spec.image", upToDate, desired))
}

func computeGroupPhase(network *seiv1alpha1.SeiNetwork, ready, desired int32, nodes []seiv1alpha1.SeiNode) seiv1alpha1.SeiNetworkPhase {
	if network.Spec.Paused {
		return seiv1alpha1.GroupPhasePaused
	}
	if hasConditionTrue(network, seiv1alpha1.ConditionPlanInProgress) {
		return seiv1alpha1.GroupPhaseInitializing
	}
	// A failed genesis ceremony is terminal for the network: failPlan latches
	// GenesisCeremonyComplete=False/CeremonyFailed. Honor it here so the
	// failure surfaces as GroupPhaseFailed instead of being masked by the
	// child-derived phase below (a ceremony failure typically leaves no/healthy
	// children, which would otherwise resolve to Pending/Initializing).
	if hasConditionReason(network, seiv1alpha1.ConditionGenesisCeremonyComplete, "CeremonyFailed") {
		return seiv1alpha1.GroupPhaseFailed
	}

	if len(nodes) == 0 {
		return seiv1alpha1.GroupPhasePending
	}
	if ready == desired {
		return seiv1alpha1.GroupPhaseReady
	}

	var failedCount, notServingCount int32
	for i := range nodes {
		switch {
		case nodes[i].Status.Phase == seiv1alpha1.PhaseFailed:
			failedCount++
		case childNotServing(&nodes[i]):
			notServingCount++
		}
	}

	if failedCount == int32(len(nodes)) {
		return seiv1alpha1.GroupPhaseFailed
	}
	// A Running child that has stopped serving is a degradation of an
	// established network, not a node still coming up; fold it in with Failed
	// so the Degraded phase — not Initializing — is what alerting sees.
	if (failedCount > 0 || notServingCount > 0) && ready > 0 {
		return seiv1alpha1.GroupPhaseDegraded
	}
	return seiv1alpha1.GroupPhaseInitializing
}

// childNotServing is a Running child the network does not count as ready:
// an EVM-only child whose EvmServing condition is not True.
func childNotServing(node *seiv1alpha1.SeiNode) bool {
	return node.Status.Phase == seiv1alpha1.PhaseRunning && !childReady(node)
}

func setNodesReadyCondition(network *seiv1alpha1.SeiNetwork, ready, desired int32, nodes []seiv1alpha1.SeiNode) {
	status := metav1.ConditionTrue
	reason := "AllNodesReady"
	message := fmt.Sprintf("%d/%d nodes ready", ready, desired)

	if ready < desired {
		status = metav1.ConditionFalse
		initializing := int32(0)
		failed := int32(0)
		notServing := int32(0)
		for i := range nodes {
			switch nodes[i].Status.Phase {
			case seiv1alpha1.PhaseFailed:
				failed++
			case seiv1alpha1.PhasePending, seiv1alpha1.PhaseInitializing:
				initializing++
			case seiv1alpha1.PhaseRunning:
				if childNotServing(&nodes[i]) {
					notServing++
				}
			}
		}
		switch {
		case failed > 0:
			reason = "NodesFailed"
			message = fmt.Sprintf("%d/%d nodes ready (%d failed, %d initializing)", ready, desired, failed, initializing)
		case notServing > 0:
			reason = "NodesNotServing"
			message = fmt.Sprintf("%d/%d nodes ready (%d running but not serving, %d initializing)", ready, desired, notServing, initializing)
		default:
			reason = "NodesInitializing"
			message = fmt.Sprintf("%d/%d nodes ready (%d initializing)", ready, desired, initializing)
		}
	}

	setCondition(network, seiv1alpha1.ConditionNodesReady, status, reason, message)
}

// ReasonNotStarted is the seed reason for always-present lifecycle
// conditions before any transition has occurred. Used by PlanInProgress
// and GenesisCeremonyComplete. NodesReady seeds Pending and
// RolloutInProgress seeds AllUpToDate instead.
const ReasonNotStarted = "NotStarted"

// ReasonValidatorLost marks a genesis ceremony abandoned because a founding
// validator was deleted mid-plan. Unlike CeremonyFailed it is not terminal:
// the set is recreated and the ceremony rebuilt on the next reconciles.
const ReasonValidatorLost = "ValidatorLost"

// ReasonFoundingSetTornDown is the event reason for each surviving founding
// child deleted after a validator loss so the ceremony can restart over a
// recreated set. Distinct from the scale-down SeiNodeDeleted so an
// irreversible teardown never reads like routine excess-replica removal.
const ReasonFoundingSetTornDown = "FoundingSetTornDown"

// ReasonAdoptedSet latches GenesisCeremonyComplete=True when a ceremony plan
// over adopted (Retain-released) validators is abandoned after a loss: those
// validators already carry a genesis, and rebuilding the ceremony over a set
// that includes a marker-less replacement would republish a divergent one.
const ReasonAdoptedSet = "AdoptedSet"

// seedAlwaysPresentConditions stamps the seeded always-present conditions so
// the full set — GenesisCeremonyComplete, NodesReady, RolloutInProgress,
// Paused, PlanInProgress — is present after the first reconcile and no
// consumer ever sees a network missing one. Seeds use seedConditionIfAbsent,
// so the live values that updateStatus computes later in the same reconcile
// (NodesReady, RolloutInProgress) override these defaults; they only fill the
// gap on early-return paths that exit before updateStatus.
func (r *SeiNetworkReconciler) seedAlwaysPresentConditions(network *seiv1alpha1.SeiNetwork) {
	r.setGenesisCeremonyCondition(network)
	r.setPausedCondition(network)
	r.setConfigValuesValidCondition(network)
	seedConditionIfAbsent(network, seiv1alpha1.ConditionPlanInProgress,
		ReasonNotStarted, "no plan has run yet")
	seedConditionIfAbsent(network, seiv1alpha1.ConditionNodesReady,
		"Pending", "no child nodes observed yet")
	seedConditionIfAbsent(network, seiv1alpha1.ConditionRolloutInProgress,
		"AllUpToDate", "no child nodes observed yet")
	seedConditionIfAbsent(network, seiv1alpha1.ConditionProducing,
		seiv1alpha1.ReasonNoNodes, "no child nodes observed yet")
}

// setPausedCondition mirrors spec.paused and emits an event on each
// Paused↔Unpaused transition.
func (r *SeiNetworkReconciler) setPausedCondition(network *seiv1alpha1.SeiNetwork) {
	prev := apimeta.FindStatusCondition(network.Status.Conditions, seiv1alpha1.ConditionPaused)
	wasPaused := prev != nil && prev.Status == metav1.ConditionTrue

	if network.Spec.Paused {
		setCondition(network, seiv1alpha1.ConditionPaused, metav1.ConditionTrue,
			"Paused", "spec.paused is true; plan-driven orchestration is frozen")
		// Emit on the False→True transition only. A network created
		// already paused has prev=nil and doesn't need an event — its
		// condition already tells the story.
		if r.Recorder != nil && prev != nil && !wasPaused {
			msg := "operator set spec.paused; controller will not advance plans, rollouts, or template changes until unpaused"
			if network.Status.Plan != nil {
				msg = fmt.Sprintf("operator set spec.paused with active plan %s; plan freezes in place until unpaused", network.Status.Plan.ID)
			}
			r.Recorder.Event(network, corev1.EventTypeNormal, "Paused", msg)
		}
		return
	}
	setCondition(network, seiv1alpha1.ConditionPaused, metav1.ConditionFalse,
		"NotPaused", "spec.paused is unset or false")
	if wasPaused && r.Recorder != nil {
		r.Recorder.Event(network, corev1.EventTypeNormal, "Unpaused",
			"operator cleared spec.paused; controller resumes plan-driven orchestration")
	}
}

// setConfigValuesValidCondition builds the child's TOML overlay from the
// network's set once per reconcile and reports the result. The CRD schema
// admits values the overlay cannot represent (a null nested in a table, a
// number outside int64 and float64, overlapping dotted paths under one file),
// and such a set fails identically on every validator, so the network is where
// the operator should read the error instead of N children. ensureSeiNode
// consults this condition and leaves the children on their last good set.
func (r *SeiNetworkReconciler) setConfigValuesValidCondition(network *seiv1alpha1.SeiNetwork) {
	err := planner.ValidateConfigValues(network.Spec.ConfigValues)
	if err == nil {
		setCondition(network, seiv1alpha1.ConditionConfigValuesValid, metav1.ConditionTrue,
			"Valid", fmt.Sprintf("%d config values build a TOML overlay", len(network.Spec.ConfigValues)))
		return
	}
	// Event on the transition only: the condition already carries the standing
	// state, and a rejected set survives every reconcile until it is edited.
	if r.Recorder != nil && !configValuesRejected(network) {
		r.Recorder.Event(network, corev1.EventTypeWarning, "InvalidConfigValues",
			fmt.Sprintf("spec.configValues cannot build a TOML overlay; children keep their current set: %v", err))
	}
	setCondition(network, seiv1alpha1.ConditionConfigValuesValid, metav1.ConditionFalse,
		"InvalidConfigValues", err.Error())
}

// configValuesRejected reports the standing verdict of the condition above.
// Absent counts as accepted: the value is only ever consulted after
// setConfigValuesValidCondition has run on the same object.
func configValuesRejected(network *seiv1alpha1.SeiNetwork) bool {
	c := apimeta.FindStatusCondition(network.Status.Conditions, seiv1alpha1.ConditionConfigValuesValid)
	return c != nil && c.Status == metav1.ConditionFalse
}

// seedConditionIfAbsent writes False/<reason>/<message> only when the
// condition is absent from the network.
func seedConditionIfAbsent(network *seiv1alpha1.SeiNetwork, condType, reason, message string) {
	if apimeta.FindStatusCondition(network.Status.Conditions, condType) != nil {
		return
	}
	setCondition(network, condType, metav1.ConditionFalse, reason, message)
}

func hasConditionTrue(network *seiv1alpha1.SeiNetwork, condType string) bool { //nolint:unparam // general-purpose utility
	c := apimeta.FindStatusCondition(network.Status.Conditions, condType)
	return c != nil && c.Status == metav1.ConditionTrue
}

// hasConditionReason reports whether the named condition is present with the
// given Reason, regardless of Status. Used to recognize the latched
// CeremonyFailed state when deriving the group phase.
func hasConditionReason(network *seiv1alpha1.SeiNetwork, condType, reason string) bool {
	c := apimeta.FindStatusCondition(network.Status.Conditions, condType)
	return c != nil && c.Reason == reason
}

func setCondition(network *seiv1alpha1.SeiNetwork, condType string, status metav1.ConditionStatus, reason, message string) {
	apimeta.SetStatusCondition(&network.Status.Conditions, metav1.Condition{
		Type:               condType,
		Status:             status,
		Reason:             reason,
		Message:            message,
		ObservedGeneration: network.Generation,
	})
}
