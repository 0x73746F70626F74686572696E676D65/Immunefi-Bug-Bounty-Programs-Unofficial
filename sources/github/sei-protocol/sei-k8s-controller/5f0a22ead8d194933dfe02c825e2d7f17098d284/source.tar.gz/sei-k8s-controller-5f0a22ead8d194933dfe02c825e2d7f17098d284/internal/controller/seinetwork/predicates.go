package seinetwork

import (
	corev1 "k8s.io/api/core/v1"
	apiequality "k8s.io/apimachinery/pkg/api/equality"
	apimeta "k8s.io/apimachinery/pkg/api/meta"
	"sigs.k8s.io/controller-runtime/pkg/event"
	"sigs.k8s.io/controller-runtime/pkg/predicate"

	seiv1alpha1 "github.com/sei-protocol/sei-k8s-controller/api/v1alpha1"
)

// childPhaseChangedPredicate filters Update events from owned SeiNodes to
// only pass through phase transitions (e.g. Initializing → Running), and
// changes to the child's EvmServing verdict or published endpoint, which feed
// the network's readiness and endpoint reports. This
// prevents the high-frequency task retry status patches on child nodes from
// triggering network reconciliation, which would bypass the executor's
// exponential backoff on retried network-level tasks.
//
// Create, Delete, and Generic events always pass through. Update events
// also pass through if the child's spec changed (generation bump).
func childPhaseChangedPredicate() predicate.Predicate {
	return predicate.Funcs{
		CreateFunc:  func(_ event.CreateEvent) bool { return true },
		DeleteFunc:  func(_ event.DeleteEvent) bool { return true },
		GenericFunc: func(_ event.GenericEvent) bool { return true },
		UpdateFunc: func(e event.UpdateEvent) bool {
			oldNode, ok := e.ObjectOld.(*seiv1alpha1.SeiNode)
			if !ok {
				return true
			}
			newNode, ok := e.ObjectNew.(*seiv1alpha1.SeiNode)
			if !ok {
				return true
			}
			if e.ObjectOld.GetGeneration() != e.ObjectNew.GetGeneration() {
				return true
			}
			if oldNode.Status.Phase != newNode.Status.Phase {
				return true
			}
			if apimeta.IsStatusConditionTrue(oldNode.Status.Conditions, seiv1alpha1.ConditionEvmServing) !=
				apimeta.IsStatusConditionTrue(newNode.Status.Conditions, seiv1alpha1.ConditionEvmServing) {
				return true
			}
			return !apiequality.Semantic.DeepEqual(oldNode.Status.Endpoint, newNode.Status.Endpoint)
		},
	}
}

// podPlacementChangedPredicate admits only the pod events that can change the
// status placement report: a pod appearing or disappearing, or its binding
// (spec.nodeName) or phase changing. Every other pod update — container
// restarts, condition flaps, readiness — is dropped so the pod watch does not
// fan the network's reconcile rate out to its pods' churn.
func podPlacementChangedPredicate() predicate.Predicate {
	return predicate.Funcs{
		CreateFunc:  func(_ event.CreateEvent) bool { return true },
		DeleteFunc:  func(_ event.DeleteEvent) bool { return true },
		GenericFunc: func(_ event.GenericEvent) bool { return true },
		UpdateFunc: func(e event.UpdateEvent) bool {
			oldPod, ok := e.ObjectOld.(*corev1.Pod)
			if !ok {
				return true
			}
			newPod, ok := e.ObjectNew.(*corev1.Pod)
			if !ok {
				return true
			}
			return oldPod.Spec.NodeName != newPod.Spec.NodeName ||
				oldPod.Status.Phase != newPod.Status.Phase ||
				oldPod.DeletionTimestamp.IsZero() != newPod.DeletionTimestamp.IsZero()
		},
	}
}
