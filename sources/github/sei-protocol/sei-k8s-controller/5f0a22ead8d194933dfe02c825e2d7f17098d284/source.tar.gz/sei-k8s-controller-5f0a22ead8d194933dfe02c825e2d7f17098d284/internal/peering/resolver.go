// Package peering resolves a SeiNode's spec.peers into the fully-composed
// `<node_id>@<host>:<port>` persistent_peers set. The controller is the sole
// owner of peer resolution. State-sync witnesses are NOT resolved here — they
// come from the controller-level canonical-syncer ConfigMap (see the node
// controller's StateSyncReady gate), not label-matched fleet peers.
//
// Resolve handles all three source kinds in-controller:
//   - Label  — list matching SeiNodes, fetch each peer's node_id via its
//     sidecar, compose against the peer's external or in-cluster P2P address.
//   - Static — verbatim, already `<node_id>@<host>:<port>`.
//   - EC2Tags — DescribeInstances by tag filters, compose each instance's
//     P2P address from its node_id tag + IP/DNS.
//
// Resolution is level-triggered and idempotent, and transient failures never
// shrink the set: a Label peer whose node_id can't be fetched keeps its prior
// entry, and a transient EC2 DescribeInstances failure unions the prior set
// wholesale (the flat prior set can't be split per source). So a peer
// mid-restart or a brief AWS hiccup never churns the fleet's persistent_peers.
package peering

import (
	"context"
	"errors"
	"fmt"
	"slices"
	"strings"

	seiconfig "github.com/sei-protocol/sei-config"
	"sigs.k8s.io/controller-runtime/pkg/client"
	"sigs.k8s.io/controller-runtime/pkg/log"

	seiv1alpha1 "github.com/sei-protocol/sei-k8s-controller/api/v1alpha1"
	"github.com/sei-protocol/sei-k8s-controller/internal/task"
)

// errNoSidecarFactory marks a nil BuildSidecarClient. It is treated as a
// transient per-peer failure (preserve-prior or skip), never a panic, so a
// degraded or test environment without a sidecar factory still reconciles.
var errNoSidecarFactory = errors.New("sidecar client factory is nil")

// Resolver resolves spec.peers into the persistent_peers set. All dependencies
// are injected so it is unit-testable without a cluster or AWS.
type Resolver struct {
	// Reader lists SeiNodes for Label sources.
	Reader client.Reader

	// BuildSidecarClient fetches a peer's Tendermint node_id via its sidecar.
	// Nil is tolerated (transient failure, not a panic) so tests and degraded
	// environments still reconcile.
	BuildSidecarClient func(node *seiv1alpha1.SeiNode) (task.SidecarClient, error)

	// EC2 resolves EC2Tags sources. Nil is treated as a transient failure
	// (preserve-prior), matching the Label-path stability rule.
	EC2 EC2Resolver
}

// Result is the resolved peering state for a SeiNode.
type Result struct {
	// Peers are the fully-composed `<node_id>@<host>:<port>` persistent_peers,
	// sorted and de-duplicated.
	Peers []string
}

// Resolve resolves all of node.Spec.Peers. prior is the node's last resolved
// peer set (node.Status.ResolvedPeers); it is consulted to preserve a peer's
// composed entry when its node_id can't be fetched this reconcile. Resolve
// never returns an error for a per-peer transient failure — it preserves or
// skips — so it only errors on a hard failure (e.g. a List call).
func (r *Resolver) Resolve(ctx context.Context, node *seiv1alpha1.SeiNode, prior []string) (Result, error) {
	priorByHost := indexResolvedPeersByHost(prior)

	var peers []string
	var preserveEC2Prior bool
	for i := range node.Spec.Peers {
		src := &node.Spec.Peers[i]
		switch {
		case src.Label != nil:
			endpoints, err := r.resolveLabel(ctx, node, src.Label, priorByHost)
			if err != nil {
				return Result{}, err
			}
			peers = append(peers, endpoints...)
		case src.Static != nil:
			peers = append(peers, src.Static.Addresses...)
		case src.EC2Tags != nil:
			endpoints, preservePrior := r.resolveEC2(ctx, src.EC2Tags)
			preserveEC2Prior = preserveEC2Prior || preservePrior
			peers = append(peers, endpoints...)
		}
	}

	// A transient EC2 failure yields no fresh entries and the flat prior set
	// can't be split per-source, so union prior to guarantee no-shrink while
	// every other source still contributes its fresh results. Wrinkle: a Label
	// peer legitimately removed in the same reconcile where EC2 also transiently
	// fails is retained for one reconcile.
	if preserveEC2Prior {
		peers = append(peers, prior...)
	}

	slices.Sort(peers)
	peers = slices.Compact(peers)
	return Result{Peers: peers}, nil
}

// resolveLabel lists SeiNodes matching the selector and composes each peer's
// `<node_id>@<host>:<port>` entry. A per-peer node_id fetch failure preserves
// the prior composed entry (from priorByHost) or skips the peer until it is
// resolvable — transients never wedge the fleet.
func (r *Resolver) resolveLabel(
	ctx context.Context,
	node *seiv1alpha1.SeiNode,
	src *seiv1alpha1.LabelPeerSource,
	priorByHost map[string]string,
) ([]string, error) {
	logger := log.FromContext(ctx)
	ns := node.Namespace
	if src.Namespace != "" {
		ns = src.Namespace
	}

	var nodeList seiv1alpha1.SeiNodeList
	if err := r.Reader.List(ctx, &nodeList,
		client.InNamespace(ns),
		client.MatchingLabels(src.Selector),
	); err != nil {
		return nil, fmt.Errorf("listing peers by label: %w", err)
	}

	var endpoints []string
	for i := range nodeList.Items {
		peer := &nodeList.Items[i]
		if peer.Name == node.Name && peer.Namespace == node.Namespace {
			continue
		}

		address := peerAddress(peer)
		var sc task.SidecarClient
		err := errNoSidecarFactory
		if r.BuildSidecarClient != nil {
			sc, err = r.BuildSidecarClient(peer)
		}
		if err == nil {
			var nodeID string
			nodeID, err = sc.GetNodeID(ctx)
			if err == nil {
				endpoints = append(endpoints, fmt.Sprintf("%s@%s", nodeID, address))
				continue
			}
		}
		if existing, ok := priorByHost[address]; ok {
			logger.Info("preserving prior peer entry; node_id fetch failed", "peer", peer.Name, "err", err)
			endpoints = append(endpoints, existing)
			continue
		}
		logger.Info("skipping peer until node_id is resolvable", "peer", peer.Name, "err", err)
	}
	return endpoints, nil
}

// indexResolvedPeersByHost maps `host:port` → `<node_id>@host:port` for O(1)
// lookup of the prior composed entry on transient failure.
func indexResolvedPeersByHost(peers []string) map[string]string {
	out := make(map[string]string, len(peers))
	for _, p := range peers {
		at := strings.Index(p, "@")
		if at <= 0 || at == len(p)-1 {
			continue
		}
		out[p[at+1:]] = p
	}
	return out
}

// peerAddress returns Spec.ExternalAddress (already host:port) when set,
// otherwise the headless Service DNS at the standard P2P port.
func peerAddress(peer *seiv1alpha1.SeiNode) string {
	if peer.Spec.ExternalAddress != "" {
		return peer.Spec.ExternalAddress
	}
	return fmt.Sprintf("%s-0.%s.%s.svc.cluster.local:%d",
		peer.Name, peer.Name, peer.Namespace, seiconfig.PortP2P)
}
