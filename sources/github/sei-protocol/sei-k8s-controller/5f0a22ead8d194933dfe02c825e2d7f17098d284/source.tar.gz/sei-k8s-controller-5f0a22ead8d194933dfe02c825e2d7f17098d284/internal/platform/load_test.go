package platform

import (
	"os"
	"path/filepath"
	"strings"
	"testing"
)

// fullConfig is a complete, valid app-config file — every required infra field set.
const fullConfig = `
scheduling:
  nodepoolName: file-nodepool
  nodepoolArchive: file-nodepool-archive
  nodepoolValidator: file-nodepool-validator
  nodepoolSeed: file-nodepool-seed
  tolerationKey: file-toleration
  serviceAccount: file-sa
  dedicated:
    nodepoolValidator: file-nodepool-validator-dedicated
storage:
  classPerf: file-perf
  classDefault: file-default
  classArchive: file-archive
  sizeDefault: file-size-default
  sizeArchive: file-size-archive
resources:
snapshot:
  bucket: file-snap-bucket
  region: file-snap-region
genesis:
  bucket: file-genesis-bucket
  region: file-genesis-region
images:
  sidecar: file-sidecar
  kubeRBACProxy: file-rbac-proxy
  cosmosExporter: file-cosmos-exporter
`

func setGatewayEnv(t *testing.T) {
	t.Helper()
	t.Setenv(envGatewayName, "env-gw-name")
	t.Setenv(envGatewayNamespace, "env-gw-ns")
	t.Setenv(envGatewayDomain, "env-gw-domain")
}

func writeConfig(t *testing.T, body string) string {
	t.Helper()
	path := filepath.Join(t.TempDir(), "config.yaml")
	if err := os.WriteFile(path, []byte(body), 0o600); err != nil {
		t.Fatalf("write config: %v", err)
	}
	return path
}

// Infra config is sourced from the file (authoritative); gateway from env. An
// infra env var, even when set, is ignored — there is no fallback.
func TestLoad_InfraFromFile_GatewayFromEnv(t *testing.T) {
	setGatewayEnv(t)
	t.Setenv("SEI_NODEPOOL_NAME", "env-ignored") // no longer consulted
	path := writeConfig(t, fullConfig)
	t.Setenv(envControllerConfig, path)

	cfg, err := Load()
	if err != nil {
		t.Fatalf("Load: %v", err)
	}
	if err := cfg.Validate(); err != nil {
		t.Fatalf("Validate: %v", err)
	}
	if cfg.NodepoolName != "file-nodepool" {
		t.Errorf("NodepoolName = %q, want file-nodepool (infra env must be ignored)", cfg.NodepoolName)
	}
	if cfg.NodepoolValidator != "file-nodepool-validator" {
		t.Errorf("NodepoolValidator = %q, want file-nodepool-validator", cfg.NodepoolValidator)
	}
	if got := cfg.DedicatedNodepoolForMode("validator"); got != "file-nodepool-validator-dedicated" {
		t.Errorf("DedicatedNodepoolForMode(validator) = %q, want file-nodepool-validator-dedicated", got)
	}
	if got := cfg.DedicatedNodepoolForMode("archive"); got != "" {
		t.Errorf("DedicatedNodepoolForMode(archive) = %q, want \"\" (none configured)", got)
	}
	if cfg.CosmosExporterImage != "file-cosmos-exporter" {
		t.Errorf("CosmosExporterImage = %q, want file-cosmos-exporter", cfg.CosmosExporterImage)
	}
	if cfg.GatewayName != "env-gw-name" {
		t.Errorf("GatewayName = %q, want env-gw-name", cfg.GatewayName)
	}
	if cfg.ControllerConfigFile != path {
		t.Errorf("ControllerConfigFile = %q, want %q", cfg.ControllerConfigFile, path)
	}
}

// No file means no infra config — Validate fails at startup (no env fallback),
// naming the file key.
func TestLoad_NoFile_FailsValidate(t *testing.T) {
	setGatewayEnv(t)
	t.Setenv("SEI_NODEPOOL_NAME", "env-ignored")
	t.Setenv(envControllerConfig, "")

	cfg, err := Load()
	if err != nil {
		t.Fatalf("Load: %v", err)
	}
	err = cfg.Validate()
	if err == nil {
		t.Fatal("expected Validate to fail with no infra config, got nil")
	}
	if !strings.Contains(err.Error(), "scheduling.nodepoolName") {
		t.Errorf("error should name the file key, got %q", err.Error())
	}
}

// A required field absent from the file fails Validate, naming the file key.
// Covers the CosmosExporterImage fold-in (now required at startup).
func TestLoad_MissingField_FailsValidate(t *testing.T) {
	setGatewayEnv(t)
	body := strings.Replace(fullConfig, "  cosmosExporter: file-cosmos-exporter\n", "", 1)
	path := writeConfig(t, body)
	t.Setenv(envControllerConfig, path)

	cfg, err := Load()
	if err != nil {
		t.Fatalf("Load: %v", err)
	}
	if err := cfg.Validate(); err == nil || !strings.Contains(err.Error(), "images.cosmosExporter") {
		t.Fatalf("want Validate error naming images.cosmosExporter, got %v", err)
	}
}

// scheduling.nodepoolValidator is required (mirrors nodepoolArchive): a file
// omitting it fails Validate at startup, naming the file key. This is the
// fail-closed guard that keeps validators from silently falling back to the
// shared pool when the validator pool key is missing.
func TestLoad_MissingNodepoolValidator_FailsValidate(t *testing.T) {
	setGatewayEnv(t)
	body := strings.Replace(fullConfig, "  nodepoolValidator: file-nodepool-validator\n", "", 1)
	path := writeConfig(t, body)
	t.Setenv(envControllerConfig, path)

	cfg, err := Load()
	if err != nil {
		t.Fatalf("Load: %v", err)
	}
	if err := cfg.Validate(); err == nil || !strings.Contains(err.Error(), "scheduling.nodepoolValidator") {
		t.Fatalf("want Validate error naming scheduling.nodepoolValidator, got %v", err)
	}
}

// scheduling.nodepoolSeed is required on the same terms as the archive and
// validator pools — whether or not the cluster runs seeds. NodepoolForMode gives
// a seed no fallback, so an unset key would otherwise put a small seed on the
// RPC-class default pool.
func TestLoad_MissingNodepoolSeed_FailsValidate(t *testing.T) {
	setGatewayEnv(t)
	body := strings.Replace(fullConfig, "  nodepoolSeed: file-nodepool-seed\n", "", 1)
	path := writeConfig(t, body)
	t.Setenv(envControllerConfig, path)

	cfg, err := Load()
	if err != nil {
		t.Fatalf("Load: %v", err)
	}
	if err := cfg.Validate(); err == nil || !strings.Contains(err.Error(), "scheduling.nodepoolSeed") {
		t.Fatalf("want Validate error naming scheduling.nodepoolSeed, got %v", err)
	}
}

// A missing gateway env var fails Validate, naming the env var (gateway is still
// env-sourced pending PLT-451).
func TestLoad_MissingGateway_FailsValidate(t *testing.T) {
	path := writeConfig(t, fullConfig)
	t.Setenv(envControllerConfig, path)
	// gateway env deliberately unset

	cfg, err := Load()
	if err != nil {
		t.Fatalf("Load: %v", err)
	}
	if err := cfg.Validate(); err == nil || !strings.Contains(err.Error(), envGatewayName) {
		t.Fatalf("want Validate error naming %s, got %v", envGatewayName, err)
	}
}

// Malformed YAML is a hard error — a present-but-broken file must not resolve to
// an empty (and silently invalid) Config.
func TestLoad_MalformedFile_Errors(t *testing.T) {
	path := writeConfig(t, "scheduling: [not-a-map")
	t.Setenv(envControllerConfig, path)

	if _, err := Load(); err == nil {
		t.Fatal("expected error for malformed config file, got nil")
	}
}

// Backward compat: an app-config file with no resources.<role> blocks loads
// and validates, leaving the per-role overrides empty (the node container then
// falls back to the code defaults).
func TestLoad_NoResourceOverrides_ValidatesEmpty(t *testing.T) {
	setGatewayEnv(t)
	path := writeConfig(t, fullConfig)
	t.Setenv(envControllerConfig, path)

	cfg, err := Load()
	if err != nil {
		t.Fatalf("Load: %v", err)
	}
	if err := cfg.Validate(); err != nil {
		t.Fatalf("Validate: %v", err)
	}
	if cfg.NodeResourcesValidator != (ResourceOverride{}) || cfg.NodeResourcesArchive != (ResourceOverride{}) {
		t.Errorf("expected empty per-role overrides, got validator=%+v archive=%+v",
			cfg.NodeResourcesValidator, cfg.NodeResourcesArchive)
	}
}

// A resources.<mode> block is parsed onto the matching per-mode Config field.
func TestLoad_ResourceOverrides_FromFile(t *testing.T) {
	setGatewayEnv(t)
	body := strings.Replace(fullConfig,
		"resources:\n",
		"resources:\n  validator:\n    cpuRequest: \"8\"\n    memory: 120Gi\n",
		1)
	path := writeConfig(t, body)
	t.Setenv(envControllerConfig, path)

	cfg, err := Load()
	if err != nil {
		t.Fatalf("Load: %v", err)
	}
	if err := cfg.Validate(); err != nil {
		t.Fatalf("Validate: %v", err)
	}
	want := ResourceOverride{CPURequest: "8", Memory: "120Gi"}
	if cfg.NodeResourcesValidator != want {
		t.Errorf("NodeResourcesValidator = %+v, want %+v", cfg.NodeResourcesValidator, want)
	}
}

// An empty override is valid (all sub-fields fall back to code defaults).
func TestResourceOverride_Validate(t *testing.T) {
	if err := (ResourceOverride{}).validate("resources.node"); err != nil {
		t.Fatalf("empty override should validate, got %v", err)
	}
	if err := (ResourceOverride{CPURequest: "8", Memory: "120Gi"}).validate("resources.validator"); err != nil {
		t.Fatalf("valid override should validate, got %v", err)
	}

	// An unparseable quantity fails, naming the field.
	err := ResourceOverride{Memory: "not-a-quantity"}.validate("resources.archive")
	if err == nil || !strings.Contains(err.Error(), "resources.archive.memory") {
		t.Fatalf("want error naming resources.archive.memory, got %v", err)
	}
}

func TestReadFileConfig_EmptyPath(t *testing.T) {
	cfg, err := ReadFileConfig("")
	if err != nil {
		t.Fatalf("ReadFileConfig(\"\"): %v", err)
	}
	if cfg.StateSync.Syncers != nil || cfg.Scheduling.NodepoolName != "" {
		t.Errorf("empty path should yield zero FileConfig, got %+v", cfg)
	}
}
