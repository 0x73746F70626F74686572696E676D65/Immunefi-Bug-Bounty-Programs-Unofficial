package planner

import (
	"context"
	"encoding/json"
	"fmt"
	"maps"
	"slices"
	"strconv"
	"strings"
	"time"

	"github.com/google/uuid"
	seiconfig "github.com/sei-protocol/sei-config"
	"go.opentelemetry.io/otel/metric"
	apiextensionsv1 "k8s.io/apiextensions-apiserver/pkg/apis/apiextensions/v1"
	"k8s.io/apimachinery/pkg/api/meta"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"

	seiv1alpha1 "github.com/sei-protocol/sei-k8s-controller/api/v1alpha1"
	"github.com/sei-protocol/sei-k8s-controller/internal/controller/observability"
	"github.com/sei-protocol/sei-k8s-controller/internal/noderesource"
	"github.com/sei-protocol/sei-k8s-controller/internal/platform"
	"github.com/sei-protocol/sei-k8s-controller/internal/task"
	sidecar "github.com/sei-protocol/sei-k8s-controller/sidecarapi/client"
)

const unknownValue = "unknown"

// Update failure reasons are shared by writers and the diagnostic-preservation guard.
// Add new failure reasons to isUpdateFailureReason as well.
const (
	reasonUpdateFailed          = "UpdateFailed"
	reasonUpdatePlanBuildFailed = "UpdatePlanBuildFailed"
)

// isUpdateFailureReason identifies actionable diagnostics that a baseline notice
// must not replace on a no-op reconcile.
func isUpdateFailureReason(reason string) bool {
	switch reason {
	case reasonUpdateFailed, reasonUpdatePlanBuildFailed:
		return true
	default:
		return false
	}
}

const (
	TaskSnapshotRestore    = sidecar.TaskTypeSnapshotRestore
	TaskConfigureGenesis   = sidecar.TaskTypeConfigureGenesis
	TaskConfigureStateSync = sidecar.TaskTypeConfigureStateSync
	TaskConfigApply        = sidecar.TaskTypeConfigApply
	TaskConfigPatch        = sidecar.TaskTypeConfigPatch
	TaskConfigValidate     = sidecar.TaskTypeConfigValidate
	TaskMarkReady          = sidecar.TaskTypeMarkReady
	TaskAwaitCondition     = sidecar.TaskTypeAwaitCondition

	TaskGenerateIdentity       = sidecar.TaskTypeGenerateIdentity
	TaskGenerateGentx          = sidecar.TaskTypeGenerateGentx
	TaskUploadGenesisArtifacts = sidecar.TaskTypeUploadGenesisArtifacts
	TaskAssembleGenesis        = sidecar.TaskTypeAssembleGenesis
	TaskSetGenesisPeers        = sidecar.TaskTypeSetGenesisPeers
	TaskAwaitNodesRunning      = task.TaskTypeAwaitNodesRunning
)

const (
	overrideKeyLoggingLevel = "logging.level"
	defaultLoggingLevel     = "error"

	// keyP2PPersistentPeers is the sei-config enrichment key for
	// network.p2p.persistent_peers (WithHotReload). sei-config v0.0.19
	// exposes no exported constant for it, so it is named here.
	keyP2PPersistentPeers = "network.p2p.persistent_peers"

	// keyFreezeHeight is the sei-config key for seid's app.toml freeze-height.
	// sei-config v0.0.27 exposes no exported constant for it, so it is named
	// here. The same literal appears in the SeiNodeSpec CEL guard, which cannot
	// reference a Go constant; TestFreezeHeightKeyMatchesCELGuard pins them
	// together.
	keyFreezeHeight = "chain.freeze_height"
)

// baseProgression defines the ordered task sequence for each bootstrap mode.
var baseProgression = map[string][]string{
	"snapshot":   {TaskSnapshotRestore, TaskConfigApply, TaskConfigValidate, TaskMarkReady},
	"state-sync": {TaskConfigApply, TaskConfigValidate, TaskMarkReady},
	"genesis":    {TaskConfigApply, TaskConfigValidate, TaskMarkReady},
}

// NodePlanner encapsulates mode-specific plan construction. BuildPlan
// dispatches internally between startup (init) and an existing
// running resource — callers don't see the distinction.
//
// Convention: init writes the whole config via TaskConfigApply; an
// existing resource patches config on image updates and regenerates it on
// configValues drift, applying the operator overlay last in both cases.
type NodePlanner interface {
	Validate(node *seiv1alpha1.SeiNode) error
	BuildPlan(node *seiv1alpha1.SeiNode) (*seiv1alpha1.TaskPlan, error)
	Mode() string
}

// GroupPlanner encapsulates logic for building a network-level task plan.
type GroupPlanner interface {
	BuildPlan(network *seiv1alpha1.SeiNetwork) (*seiv1alpha1.TaskPlan, error)
}

// ForGroup returns the appropriate GroupPlanner based on the network's
// current state and spec. Returns (nil, nil) when no plan is needed.
func ForGroup(network *seiv1alpha1.SeiNetwork) (GroupPlanner, error) {
	if needsGenesisPlan(network) {
		return &genesisGroupPlanner{}, nil
	}

	// No deployment planner: image (and other propagatable) changes flow
	// to children in-place via ensureSeiNode every reconcile, and each
	// child's SeiNode controller rolls its own StatefulSet. The network's
	// RolloutInProgress condition is a derived projection (see updateStatus),
	// not a plan.
	return nil, nil
}

// needsGenesisPlan returns true when the genesis ceremony has not yet
// completed. Every SeiNetwork runs the ceremony (genesis is required), so
// there is no genesis-absent short-circuit. Reads
// ConditionGenesisCeremonyComplete: any value other than True/Complete
// means "ceremony still needs to run."
func needsGenesisPlan(network *seiv1alpha1.SeiNetwork) bool {
	if network.Status.Plan != nil {
		return false
	}
	if isConditionTrue(network, seiv1alpha1.ConditionGenesisCeremonyComplete) {
		return false
	}
	return allReplicasCreated(network)
}

func allReplicasCreated(network *seiv1alpha1.SeiNetwork) bool {
	return int32(len(network.Status.IncumbentNodes)) >= network.Spec.Replicas
}

// isConditionTrue returns whether the named condition is present with
// Status=True. The name distinguishes this from a presence check —
// always-present conditions (per CLAUDE.md `### Conditions`) require
// callers to assert on Status, not on presence.
func isConditionTrue(network *seiv1alpha1.SeiNetwork, condType string) bool {
	for _, c := range network.Status.Conditions {
		if c.Type == condType && c.Status == metav1.ConditionTrue {
			return true
		}
	}
	return false
}

type NodeResolver struct {
	// Nil factory skips the sidecar probe; used by tests.
	BuildSidecarClient func(node *seiv1alpha1.SeiNode) (task.SidecarClient, error)
	// Platform supplies the controller-wide sidecar image fallback used
	// by sidecarImageDrifted when Spec.Sidecar.Image is unset.
	Platform platform.Config
}

func (p *NodeResolver) ResolvePlan(ctx context.Context, node *seiv1alpha1.SeiNode) error {
	// Skip the probe during Initializing — the init plan owns the sidecar there.
	if p.BuildSidecarClient != nil && node.Status.Phase == seiv1alpha1.PhaseRunning {
		client, err := p.BuildSidecarClient(node)
		if err == nil {
			probeSidecarHealth(ctx, node, client)
		}
	}

	if node.Status.Plan != nil && node.Status.Plan.Phase == seiv1alpha1.TaskPlanActive {
		return nil
	}

	handleTerminalPlan(ctx, node)

	// Fail-closed state-sync gate. Runs after handleTerminalPlan (so terminal
	// plans still clear) but before building: a state-sync node whose
	// StateSyncReady condition isn't True must never get a state-sync-bearing
	// plan (CometBFT needs >=2 rpc-servers; we never fall back to peers).
	if StateSyncBlocksPlan(node) {
		return nil
	}

	mode, err := p.plannerFor(node)
	if err != nil {
		return err
	}
	if err := mode.Validate(node); err != nil {
		return err
	}

	plan, err := mode.BuildPlan(node)
	if err != nil {
		return err
	}
	if writer := mountedConfigWriterInPlan(node, plan); writer != "" {
		err := fmt.Errorf("plan carries %s on a node that mounts config.toml and app.toml from ConfigMaps: "+
			"the task renames over the mount, which detaches it and leaves seid reading the task's file", writer)
		// BuildPlan may already have stamped UpdateStarted. The plan is refused
		// and never persisted, so clear the claim rather than leave a node
		// reporting an update it does not have.
		setNodeUpdateCondition(node, metav1.ConditionFalse, reasonUpdatePlanBuildFailed, err.Error())
		return err
	}
	if plan == nil {
		if shouldExplainUnobservedConfig(node) {
			setNodeUpdateCondition(node, metav1.ConditionFalse, "ConfigBaselineUnobserved",
				"configValues changes are deferred until an image update regenerates configuration and establishes an observed baseline")
		}
		return nil
	}

	node.Status.Plan = plan
	if node.Status.Phase == "" || node.Status.Phase == seiv1alpha1.PhasePending {
		node.Status.Phase = seiv1alpha1.PhaseInitializing
		now := metav1.Now()
		node.Status.PhaseTransitionTime = &now
	}
	return nil
}

// StateSyncBlocksPlan reports whether the fail-closed state-sync gate must
// suppress plan construction this reconcile. Exported because the node
// controller uses the same predicate to hold initial StatefulSet creation: a
// suppressed init plan means EnsureDataPVC won't run, and an STS created
// anyway would strand a Pending pod on a claim nothing creates.
// It fires only on the init path
// (pre-Running), which is the only path that builds a ConfigureStateSync-bearing
// plan via buildSidecarProgression — a Running node's update plans carry no
// state-sync task, so an image roll must not be blocked by a syncer-source
// blip. The gate trips when the node carries a ConfigureStateSync task (any
// snapshot source — both stateSync and s3-restore apply via CometBFT state-sync
// and need rpc-server witnesses) and the controller-resolved StateSyncReady
// condition is not True (NoSyncersConfigured or the transient SyncerSourceError).
// A missing condition (not yet resolved) does not gate.
func StateSyncBlocksPlan(node *seiv1alpha1.SeiNode) bool {
	if node.Status.Phase == seiv1alpha1.PhaseRunning {
		return false
	}
	if !needsStateSyncWitnesses(node.Spec.SnapshotSource()) {
		return false
	}
	cond := meta.FindStatusCondition(node.Status.Conditions, seiv1alpha1.ConditionStateSyncReady)
	return cond != nil && cond.Status != metav1.ConditionTrue
}

// shouldExplainUnobservedConfig gates the baseline notice on no-op reconciles.
func shouldExplainUnobservedConfig(node *seiv1alpha1.SeiNode) bool {
	// Preserve both execution and assembly failures across no-op reconciles.
	condition := meta.FindStatusCondition(node.Status.Conditions, seiv1alpha1.ConditionNodeUpdateInProgress)
	failureReason := condition != nil && isUpdateFailureReason(condition.Reason)
	return node.Status.Phase == seiv1alpha1.PhaseRunning && node.Status.CurrentConfigValuesHash == "" &&
		len(node.Spec.ConfigValues) > 0 && !failureReason
}

// handleTerminalPlan handles completed or failed plans: clears conditions
// and nils the plan so the planner can build the next one if needed.
func handleTerminalPlan(ctx context.Context, node *seiv1alpha1.SeiNode) {
	plan := node.Status.Plan
	if plan == nil {
		return
	}

	cn := "seinode"
	planType := classifyPlan(plan)

	switch plan.Phase {
	case seiv1alpha1.TaskPlanComplete:
		if hasNodeUpdateCondition(node) {
			setNodeUpdateCondition(node, metav1.ConditionFalse, "UpdateComplete",
				fmt.Sprintf("plan %s completed", plan.ID))
		}
		emitPlanDuration(ctx, cn, node.Namespace, planType, "complete", plan)
		node.Status.Plan = nil

	case seiv1alpha1.TaskPlanFailed:
		if hasNodeUpdateCondition(node) {
			setNodeUpdateCondition(node, metav1.ConditionFalse, reasonUpdateFailed,
				fmt.Sprintf("plan %s failed: %s", plan.ID, planFailureMessage(plan)))
		}
		emitPlanDuration(ctx, cn, node.Namespace, planType, "failed", plan)
		node.Status.Plan = nil
	}
}

// hasNodeUpdateCondition returns true if NodeUpdateInProgress is currently True.
func hasNodeUpdateCondition(node *seiv1alpha1.SeiNode) bool {
	cond := meta.FindStatusCondition(node.Status.Conditions, seiv1alpha1.ConditionNodeUpdateInProgress)
	return cond != nil && cond.Status == metav1.ConditionTrue
}

// setNodeUpdateCondition sets or updates the NodeUpdateInProgress condition.
func setNodeUpdateCondition(node *seiv1alpha1.SeiNode, status metav1.ConditionStatus, reason, message string) {
	meta.SetStatusCondition(&node.Status.Conditions, metav1.Condition{
		Type:               seiv1alpha1.ConditionNodeUpdateInProgress,
		Status:             status,
		Reason:             reason,
		Message:            message,
		ObservedGeneration: node.Generation,
	})
}

// classifyPlan returns the plan type for metrics.
func classifyPlan(plan *seiv1alpha1.TaskPlan) string {
	for _, t := range plan.Tasks {
		switch t.Type {
		case task.TaskTypeObserveImage:
			return "node-update"
		case task.TaskTypeEnsureDataPVC:
			return "init"
		case sidecar.TaskTypeRestartSeid:
			return "config-update"
		}
	}
	if len(plan.Tasks) == 1 && plan.Tasks[0].Type == sidecar.TaskTypeMarkReady {
		return "mark-ready-reapply"
	}
	return unknownValue
}

// emitPlanDuration records the wall-clock time from the first task's
// submission to now. This approximates plan duration.
func emitPlanDuration(ctx context.Context, controller, namespace, planType, outcome string, plan *seiv1alpha1.TaskPlan) {
	if len(plan.Tasks) == 0 {
		return
	}
	first := plan.Tasks[0]
	if first.SubmittedAt == nil {
		return
	}
	dur := time.Since(first.SubmittedAt.Time).Seconds()
	planDuration.Record(ctx, dur,
		metric.WithAttributes(
			observability.AttrController.String(controller),
			observability.AttrNamespace.String(namespace),
			observability.AttrPlanType.String(planType),
			observability.AttrOutcome.String(outcome),
		),
	)
}

func planFailureMessage(plan *seiv1alpha1.TaskPlan) string {
	if plan.FailedTaskDetail != nil {
		return fmt.Sprintf("task %s: %s", plan.FailedTaskDetail.Type, plan.FailedTaskDetail.Error)
	}
	return unknownValue
}

// plannerFor returns the NodePlanner for a SeiNode. A node whose config.toml
// and app.toml come from operator ConfigMaps gets its mode planner wrapped in
// staticConfigPlanner, which keeps the mode's own Validate and init plans and
// replaces only the Running arm.
func (r *NodeResolver) plannerFor(node *seiv1alpha1.SeiNode) (NodePlanner, error) {
	mode, err := r.plannerForMode(node)
	if err != nil {
		return nil, err
	}
	if !MountsNodeConfig(node) {
		return mode, nil
	}
	return &staticConfigPlanner{base: mode, platform: r.Platform}, nil
}

// plannerForMode returns the appropriate NodePlanner for the SeiNode's
// mode sub-spec, threaded with the resolver's Platform config so each
// planner can resolve the effective sidecar image for drift detection.
func (r *NodeResolver) plannerForMode(node *seiv1alpha1.SeiNode) (NodePlanner, error) {
	switch {
	case node.Spec.FullNode != nil:
		return &fullNodePlanner{platform: r.Platform}, nil
	case node.Spec.Archive != nil:
		return &archiveNodePlanner{platform: r.Platform}, nil
	case node.Spec.Replayer != nil:
		return &replayerPlanner{platform: r.Platform}, nil
	case node.Spec.Validator != nil:
		return &validatorPlanner{platform: r.Platform}, nil
	case node.Spec.Seed != nil:
		return &seedPlanner{platform: r.Platform}, nil
	default:
		return nil, fmt.Errorf("no mode sub-spec set on SeiNode %s/%s", node.Namespace, node.Name)
	}
}

// insertBefore inserts taskType into prog immediately before target.
// Returns an error if the target is not found — this catches plan
// construction bugs rather than producing silently incomplete plans.
// No-op if taskType is already present.
func insertBefore(prog []string, target, taskType string) ([]string, error) {
	if slices.Contains(prog, taskType) {
		return prog, nil
	}
	for i, t := range prog {
		if t == target {
			return slices.Insert(prog, i, taskType), nil
		}
	}
	return nil, fmt.Errorf("insertBefore: target %q not found in progression %v", target, prog)
}

// buildSidecarProgression constructs the sidecar task sequence for the given
// bootstrap mode, inserting optional tasks (genesis, state-sync) at the
// correct positions. persistent_peers is no longer a sidecar task — the
// controller writes it via the config-apply override (see commonOverrides).
func buildSidecarProgression(snap *seiv1alpha1.SnapshotSource) ([]string, error) {
	mode := bootstrapMode(snap)
	prog := slices.Clone(baseProgression[mode])

	var err error
	if prog, err = insertBefore(prog, TaskConfigApply, TaskConfigureGenesis); err != nil {
		return nil, err
	}
	if needsStateSyncWitnesses(snap) {
		if prog, err = insertBefore(prog, TaskConfigValidate, TaskConfigureStateSync); err != nil {
			return nil, err
		}
	}
	return prog, nil
}

func needsValidateSigningKey(node *seiv1alpha1.SeiNode) bool {
	if node.Spec.Validator == nil || node.Spec.Validator.SigningKey == nil {
		return false
	}
	return node.Spec.Validator.SigningKey.Secret != nil &&
		node.Spec.Validator.SigningKey.Secret.SecretName != ""
}

func validateSigningKeyParams(node *seiv1alpha1.SeiNode) any {
	if !needsValidateSigningKey(node) {
		return nil
	}
	return &task.ValidateSigningKeyParams{
		SecretName: node.Spec.Validator.SigningKey.Secret.SecretName,
		Namespace:  node.Namespace,
	}
}

// needsValidateNodeKey reports whether the node sources its P2P identity from a
// Secret and so needs the pre-flight validation task. Mode-blind: it asks the
// spec which Secret holds the node key, not which mode is set, so validator and
// seed are covered by the same gate.
func needsValidateNodeKey(node *seiv1alpha1.SeiNode) bool {
	s := node.Spec.NodeKeySecret()
	return s != nil && s.SecretName != ""
}

func validateNodeKeyParams(node *seiv1alpha1.SeiNode) any {
	if !needsValidateNodeKey(node) {
		return nil
	}
	return &task.ValidateNodeKeyParams{
		SecretName: node.Spec.NodeKeySecret().SecretName,
		Namespace:  node.Namespace,
	}
}

func needsValidateOperatorKeyring(node *seiv1alpha1.SeiNode) bool {
	if node.Spec.Validator == nil || node.Spec.Validator.OperatorKeyring == nil {
		return false
	}
	s := node.Spec.Validator.OperatorKeyring.Secret
	return s != nil && s.SecretName != ""
}

func validateOperatorKeyringParams(node *seiv1alpha1.SeiNode) any {
	if !needsValidateOperatorKeyring(node) {
		return nil
	}
	s := node.Spec.Validator.OperatorKeyring.Secret
	// KeyName falls back to the CRD default for in-memory specs that
	// haven't been through admission defaulting; PassphraseSecretRef.Key
	// is required (no fallback).
	keyName := s.KeyName
	if keyName == "" {
		keyName = seiv1alpha1.DefaultOperatorKeyName
	}
	return &task.ValidateOperatorKeyringParams{
		SecretName:           s.SecretName,
		KeyName:              keyName,
		PassphraseSecretName: s.PassphraseSecretRef.SecretName,
		PassphraseSecretKey:  s.PassphraseSecretRef.Key,
		Namespace:            node.Namespace,
	}
}

// isGenesisCeremonyNode returns true when the node participates in a group genesis ceremony.
func isGenesisCeremonyNode(node *seiv1alpha1.SeiNode) bool {
	return node.Spec.Validator != nil && node.Spec.Validator.GenesisCeremony != nil
}

// validateSnapshotGeneration returns errors without a mode prefix; callers
// wrap with their own (e.g., fmt.Errorf("fullNode: %w", err)).
func validateSnapshotGeneration(sg *seiv1alpha1.SnapshotGenerationConfig) error {
	if sg == nil {
		return nil
	}
	if sg.Tendermint == nil {
		return fmt.Errorf("snapshotGeneration is set but has no sub-struct (e.g., tendermint); omit it to disable snapshot generation")
	}
	if sg.Tendermint.Publish != nil && sg.Tendermint.KeepRecent < 2 {
		return fmt.Errorf("snapshotGeneration.tendermint.keepRecent must be >= 2 when publish is set (upload algorithm requires the second-to-latest snapshot)")
	}
	return nil
}

func hasS3Snapshot(snap *seiv1alpha1.SnapshotSource) bool {
	return snap != nil && snap.S3 != nil
}

func hasStateSync(snap *seiv1alpha1.SnapshotSource) bool {
	return snap != nil && snap.StateSync != nil
}

// needsStateSyncWitnesses reports whether the node's plan carries a
// ConfigureStateSync task and therefore requires canonical rpc-server witnesses.
// Both bootstrap-from-snapshot modes apply the snapshot through CometBFT
// state-sync — stateSync fetches chunks from peers; s3 stages a snapshot under
// data/snapshots and applies it with use-local-snapshot=true — and both verify
// the trust point against >=2 reachable rpc-servers. A genesis node
// (snap == nil) carries no such task and needs no witnesses.
//
// This is the single predicate behind both the ConfigureStateSync insertion
// (buildSidecarProgression) and the fail-closed gate (StateSyncBlocksPlan),
// keeping plan-insertion and witness-resolution in lockstep.
func needsStateSyncWitnesses(snap *seiv1alpha1.SnapshotSource) bool {
	return snap != nil
}

func bootstrapMode(snap *seiv1alpha1.SnapshotSource) string {
	if hasS3Snapshot(snap) {
		return "snapshot"
	}
	if hasStateSync(snap) {
		return "state-sync"
	}
	return "genesis"
}

// SidecarURLForNode re-exports noderesource.SidecarURLForNode for callers
// that already depend on the planner package.
var SidecarURLForNode = noderesource.SidecarURLForNode

// marshalParams serializes a task params struct to apiextensionsv1.JSON.
func marshalParams(v any) (*apiextensionsv1.JSON, error) {
	raw, err := json.Marshal(v)
	if err != nil {
		return nil, fmt.Errorf("marshaling %T: %w", v, err)
	}
	return &apiextensionsv1.JSON{Raw: raw}, nil
}

// buildPlannedTask constructs a PlannedTask with deterministic ID,
// serialized params, and the task type's intrinsic retry budget.
func buildPlannedTask(planID, taskType string, planIndex int, params any) (seiv1alpha1.PlannedTask, error) {
	id := task.DeterministicTaskID(planID, taskType, planIndex)
	p, err := marshalParams(params)
	if err != nil {
		return seiv1alpha1.PlannedTask{}, fmt.Errorf("task %s: %w", taskType, err)
	}
	return seiv1alpha1.PlannedTask{
		Type:       taskType,
		ID:         id,
		Status:     seiv1alpha1.TaskPending,
		Params:     p,
		MaxRetries: taskMaxRetries(taskType),
	}, nil
}

// taskMaxRetries is the executor's retry budget per task type. Default 0
// makes the first ExecutionFailed terminal. Wall-clock per N retries
// (RetryCount is incremented before retryBackoff is called):
// 10s for N=1; 10s + 20s + 30s*(N-2) for N>=2.
func taskMaxRetries(taskType string) int {
	switch taskType {
	case TaskConfigureGenesis:
		return genesisConfigureMaxRetries
	case TaskAssembleGenesis:
		return groupAssemblyMaxRetries
	case task.TaskTypeReplacePod:
		return 3
	default:
		return 0
	}
}

// buildBasePlan builds a TaskPlan by starting with infrastructure tasks,
// then the base sidecar progression for the node's bootstrap mode.
func buildBasePlan(
	node *seiv1alpha1.SeiNode,
	snap *seiv1alpha1.SnapshotSource,
	configIntent *seiconfig.ConfigIntent,
) (*seiv1alpha1.TaskPlan, error) {
	sidecarProg, err := buildSidecarProgression(snap)
	if err != nil {
		return nil, err
	}
	sidecarProg = withoutManagedConfigTasks(node, sidecarProg)

	// Infrastructure tasks run before sidecar tasks.
	prog := make([]string, 0, 4+len(sidecarProg))
	prog = append(prog, task.TaskTypeEnsureDataPVC)
	if needsValidateSigningKey(node) {
		// Surfaces missing/malformed key material via SigningKeyReady before
		// kubelet attempts the volume mount.
		prog = append(prog, task.TaskTypeValidateSigningKey)
	}
	if needsValidateNodeKey(node) {
		prog = append(prog, task.TaskTypeValidateNodeKey)
	}
	if needsValidateOperatorKeyring(node) {
		prog = append(prog, task.TaskTypeValidateOperatorKeyring)
	}
	prog = append(prog, task.TaskTypeApplyRBACProxyConfig)
	prog = append(prog, task.TaskTypeApplyStatefulSet, task.TaskTypeApplyService)
	prog = append(prog, sidecarProg...)

	planID := uuid.New().String()
	tasks := make([]seiv1alpha1.PlannedTask, len(prog))
	for i, taskType := range prog {
		t, err := buildPlannedTask(planID, taskType, i, paramsForTaskType(node, taskType, snap, configIntent))
		if err != nil {
			return nil, err
		}
		tasks[i] = t
	}
	return withConfigValues(&seiv1alpha1.TaskPlan{
		ID:          planID,
		Phase:       seiv1alpha1.TaskPlanActive,
		Tasks:       tasks,
		TargetPhase: seiv1alpha1.PhaseRunning,
		FailedPhase: seiv1alpha1.PhaseFailed,
	}, node)
}

// paramsForTaskType constructs the appropriate params struct for a task type.
// This is the single factory for all task params — every plan builder uses it.
// Sidecar tasks return seictl client.*Task wrappers directly; config-apply
// returns *seiconfig.ConfigIntent — see task.configApplyTask for why.
func paramsForTaskType(
	node *seiv1alpha1.SeiNode,
	taskType string,
	snap *seiv1alpha1.SnapshotSource,
	configIntent *seiconfig.ConfigIntent,
) any {
	switch taskType {
	// Infrastructure tasks
	case task.TaskTypeEnsureDataPVC:
		return &task.EnsureDataPVCParams{NodeName: node.Name, Namespace: node.Namespace}
	case task.TaskTypeApplyStatefulSet:
		return &task.ApplyStatefulSetParams{NodeName: node.Name, Namespace: node.Namespace}
	case task.TaskTypeApplyService:
		return &task.ApplyServiceParams{NodeName: node.Name, Namespace: node.Namespace}
	case task.TaskTypeApplyRBACProxyConfig:
		return &task.ApplyRBACProxyConfigParams{NodeName: node.Name, Namespace: node.Namespace}
	case task.TaskTypeReplacePod:
		return &task.ReplacePodParams{NodeName: node.Name, Namespace: node.Namespace}
	case task.TaskTypeObserveImage:
		return &task.ObserveImageParams{NodeName: node.Name, Namespace: node.Namespace}
	case task.TaskTypeValidateSigningKey:
		return validateSigningKeyParams(node)
	case task.TaskTypeValidateNodeKey:
		return validateNodeKeyParams(node)
	case task.TaskTypeValidateOperatorKeyring:
		return validateOperatorKeyringParams(node)

	// Sidecar tasks
	case TaskSnapshotRestore:
		return snapshotRestoreTask(snap)
	case TaskConfigureGenesis:
		return sidecar.ConfigureGenesisTask{Autobahn: node.Spec.Consensus.IsAutobahn()}
	case TaskConfigApply:
		if configIntent != nil {
			return configIntent
		}
		return &seiconfig.ConfigIntent{}
	case TaskConfigureStateSync:
		return configureStateSyncTask(node)
	case TaskConfigValidate:
		return sidecar.ConfigValidateTask{}
	case TaskMarkReady:
		return sidecar.MarkReadyTask{}
	case sidecar.TaskTypeRestartSeid:
		up := noderesource.UpCheckForNode(node)
		return sidecar.RestartSeidTask{UpCheck: &up}

	// Genesis ceremony tasks — only valid when Validator.GenesisCeremony is set.
	case TaskGenerateIdentity, TaskGenerateGentx, TaskUploadGenesisArtifacts, TaskSetGenesisPeers:
		return genesisCeremonyTaskParams(node, taskType)

	default:
		return nil
	}
}

func genesisCeremonyTaskParams(node *seiv1alpha1.SeiNode, taskType string) any {
	if node.Spec.Validator == nil || node.Spec.Validator.GenesisCeremony == nil {
		return nil
	}
	gc := node.Spec.Validator.GenesisCeremony
	switch taskType {
	case TaskGenerateIdentity:
		return sidecar.GenerateIdentityTask{ChainID: gc.ChainID, Moniker: node.Name}
	case TaskGenerateGentx:
		return sidecar.GenerateGentxTask{
			ChainID:        gc.ChainID,
			StakingAmount:  gc.StakingAmount,
			AccountBalance: gc.AccountBalance,
		}
	case TaskUploadGenesisArtifacts:
		return sidecar.UploadGenesisArtifactsTask{
			NodeName:  node.Name,
			Namespace: node.Namespace,
			Autobahn:  node.Spec.Consensus.IsAutobahn(),
		}
	case TaskSetGenesisPeers:
		return sidecar.SetGenesisPeersTask{}
	default:
		return nil
	}
}

func snapshotRestoreTask(snap *seiv1alpha1.SnapshotSource) sidecar.SnapshotRestoreTask {
	if snap == nil || snap.S3 == nil {
		return sidecar.SnapshotRestoreTask{}
	}
	return sidecar.SnapshotRestoreTask{TargetHeight: snap.S3.TargetHeight}
}

func configureStateSyncTask(node *seiv1alpha1.SeiNode) sidecar.ConfigureStateSyncTask {
	snap := node.Spec.SnapshotSource()
	// RpcServers come from Status.ResolvedStateSyncers — resolved by the gate
	// from spec-declared snapshot.rpcServers or, absent those, the
	// controller-level canonical-syncer ConfigMap (peers are never witnesses).
	// This runs only when StateSyncBlocksPlan passed, i.e. StateSyncReady=True,
	// which guarantees >=2 entries. The set is snapshotted into the task params
	// here and never re-read at execution — so neither a transient ConfigMap
	// blip nor a spec edit can change an in-flight witness list.
	t := sidecar.ConfigureStateSyncTask{
		UseLocalSnapshot: hasS3Snapshot(snap),
		RpcServers:       node.Status.ResolvedStateSyncers,
	}
	if snap != nil {
		if snap.TrustPeriod != "" {
			t.TrustPeriod = snap.TrustPeriod
		}
		t.BackfillBlocks = snap.BackfillBlocks
	}
	return t
}

// freezeOverrides returns the override that holds a node at a block height, or
// nil when the node is not frozen. The controller owns this key: SeiNodeSpec's
// CEL guard rejects it in spec.overrides, because mergeOverrides lets a user
// override outrank a controller one.
//
// Init plans and Running-path base regeneration both carry this override in
// their ConfigIntent. The mode sub-specs continue to make freeze create-only.
func freezeOverrides(freeze *seiv1alpha1.FreezeSpec) map[string]string {
	if freeze == nil {
		return nil
	}
	return map[string]string{keyFreezeHeight: strconv.FormatInt(freeze.Height, 10)}
}

// commonOverrides returns controller overrides that apply to all node modes.
// logging.level defaults to defaultLoggingLevel ("error") here; because
// mergeOverrides lets user overrides win, a spec.Overrides entry for
// logging.level takes precedence over this default.
//
// persistent_peers is stamped from Status.ResolvedPeers ("" when none — a valid
// no-peers config). On an init plan it's frozen at build time and refreshes only
// on the next deployment: peers update on deployments, not on churn.
func commonOverrides(node *seiv1alpha1.SeiNode) map[string]string {
	out := map[string]string{
		overrideKeyLoggingLevel: defaultLoggingLevel,
		keyP2PPersistentPeers:   strings.Join(node.Status.ResolvedPeers, ","),
	}
	if node.Spec.ExternalAddress != "" {
		out[seiconfig.KeyP2PExternalAddress] = node.Spec.ExternalAddress
	}
	return out
}

// sidecarNeedsReapproval reports whether the sidecar has been observed
// to have lost readiness. Mode-agnostic.
func sidecarNeedsReapproval(node *seiv1alpha1.SeiNode) bool {
	cond := meta.FindStatusCondition(node.Status.Conditions, seiv1alpha1.ConditionSidecarReady)
	return cond != nil && cond.Status == metav1.ConditionFalse && cond.Reason == "NotReady"
}

// buildMarkReadyPlan is the single-task plan that re-marks sidecar readiness.
func buildMarkReadyPlan(node *seiv1alpha1.SeiNode) (*seiv1alpha1.TaskPlan, error) {
	planID := uuid.New().String()
	t, err := buildPlannedTask(planID, sidecar.TaskTypeMarkReady, 0, paramsForTaskType(node, sidecar.TaskTypeMarkReady, nil, nil))
	if err != nil {
		return nil, err
	}
	return &seiv1alpha1.TaskPlan{
		ID:          planID,
		Phase:       seiv1alpha1.TaskPlanActive,
		Tasks:       []seiv1alpha1.PlannedTask{t},
		TargetPhase: seiv1alpha1.PhaseRunning,
	}, nil
}

func imageDrifted(node *seiv1alpha1.SeiNode) bool {
	return node.Spec.Image != node.Status.CurrentImage
}

// configValuesDrifted mirrors image observation. Never restart an unobserved
// node during a controller upgrade; its next materialization establishes baseline.
// A hashing error triggers assembly, which reports the actual rejection in
// NodeUpdateInProgress and the controller's PlanBuildFailed event.
func configValuesDrifted(node *seiv1alpha1.SeiNode) bool {
	if node.Status.CurrentConfigValuesHash == "" {
		return false
	}
	hash, err := configValuesHash(node.Spec.ConfigValues)
	return err != nil || hash != node.Status.CurrentConfigValuesHash
}

// sidecarImageDrifted reports whether the effective sidecar image diverges
// from what was last observed. Empty Status.CurrentSidecarImage means
// "not yet observed" and is treated as no-drift so a controller upgrade
// doesn't fleet-roll every node before ObserveImage backfills the field.
func sidecarImageDrifted(node *seiv1alpha1.SeiNode, p platform.Config) bool {
	if node.Status.CurrentSidecarImage == "" {
		return false
	}
	return task.EffectiveSidecarImage(node, p) != node.Status.CurrentSidecarImage
}

// nodeIsolationDrifted reports whether the effective node isolation diverges
// from what the running pod was rolled with. Isolation lives in the pod
// template (anti-affinity, nodepool, dedicated label) and StatefulSets are
// OnDelete, so without a roll a Shared->Dedicated request never moves the
// pod. Empty Status.CurrentNodeIsolation means "not yet observed" and is
// treated as no-drift so a controller upgrade doesn't fleet-roll every node.
func nodeIsolationDrifted(node *seiv1alpha1.SeiNode) bool {
	if node.Status.CurrentNodeIsolation == "" {
		return false
	}
	return noderesource.EffectiveNodeIsolation(node) != node.Status.CurrentNodeIsolation
}

// podTemplateDrifted reports whether an observed pod-template input has
// drifted: seid image, sidecar image, or node isolation. The rendered nodepool
// is not observed, so an app-config scheduling.dedicated.* change alone does
// not roll.
func podTemplateDrifted(node *seiv1alpha1.SeiNode, p platform.Config) bool {
	return imageDrifted(node) || sidecarImageDrifted(node, p) || nodeIsolationDrifted(node)
}

// podTemplateDriftMessage formats the NodeUpdateInProgress message every mode
// planner stamps after building an update plan. Names which input(s) drifted so
// an operator reading the condition can tell seid bumps from sidecar bumps from
// an isolation change.
func podTemplateDriftMessage(node *seiv1alpha1.SeiNode, p platform.Config) string {
	seid := imageDrifted(node)
	sc := sidecarImageDrifted(node, p)
	iso := nodeIsolationDrifted(node)
	var parts []string
	if seid {
		parts = append(parts, fmt.Sprintf("seid spec=%s current=%s", node.Spec.Image, node.Status.CurrentImage))
	}
	if sc {
		parts = append(parts, fmt.Sprintf("sidecar spec=%s current=%s",
			task.EffectiveSidecarImage(node, p), node.Status.CurrentSidecarImage))
	}
	if iso {
		parts = append(parts, fmt.Sprintf("nodeIsolation spec=%s current=%s",
			noderesource.EffectiveNodeIsolation(node), node.Status.CurrentNodeIsolation))
	}
	detail := strings.Join(parts, "; ")
	switch {
	case iso && !seid && !sc:
		return "node isolation drift detected: " + detail
	case iso:
		return "image and node isolation drift detected: " + detail
	case sc && !seid:
		return "sidecar image drift detected: " + detail
	default:
		return "image drift detected: " + detail
	}
}

// p2pConfigPatch is the config.toml patch a running-node update plan applies
// to the controller-owned [p2p] keys. It stamps the publishable external
// address AND folds in the latest controller-resolved persistent_peers, so an
// already-firing update plan (image drift) carries the freshest observed peer
// set. Peer churn alone does NOT trigger a plan — this only piggybacks the
// latest valid state onto a deployment we are doing anyway. Both values stamp
// empty when unset/none, so opt-out and no-peers reach the pod symmetrically.
//
// config.toml uses hyphenated keys (external-address, persistent-peers), unlike
// the dotted enrichment keys used on the init-path config-apply override.
func p2pConfigPatch(node *seiv1alpha1.SeiNode) map[string]map[string]any {
	return map[string]map[string]any{
		"config.toml": {
			"p2p": map[string]any{
				"external-address": node.Spec.ExternalAddress,
				"persistent-peers": strings.Join(node.Status.ResolvedPeers, ","),
			},
		},
	}
}

// assembleUpdatePlan composes a per-mode task progression into a TaskPlan.
// Callers own the successful NodeUpdateInProgress trigger reason/message.
// Any assembly error records the actual failure,
// including for config-only callers and nodes carrying a stale True. FailedPhase
// stays empty so a failure retries on next reconcile.
func assembleUpdatePlan(node *seiv1alpha1.SeiNode, prog []string, patch map[string]map[string]any) (_ *seiv1alpha1.TaskPlan, retErr error) {
	defer func() {
		if retErr != nil {
			setNodeUpdateCondition(node, metav1.ConditionFalse, reasonUpdatePlanBuildFailed, retErr.Error())
		}
	}()

	// First observation must also restore the base: an unobserved node may
	// carry removed piece-1 overlay keys. This does not trigger a plan; it
	// only strengthens materialization in an update already being performed.
	// Regeneration also recurs on every configValues edit, including removals.
	// It resets out-of-band first-party StateSync giga-store migration keys
	// (known defect B1; see the B1 severity analysis on PR #534).
	if node.Status.CurrentConfigValuesHash == "" || configValuesDrifted(node) {
		var err error
		prog, err = insertBefore(prog, TaskConfigPatch, TaskConfigApply)
		if err != nil {
			return nil, err
		}
	}
	planID := uuid.New().String()
	tasks := make([]seiv1alpha1.PlannedTask, len(prog))
	for i, taskType := range prog {
		params := paramsForUpdateTask(node, taskType, patch)
		t, err := buildPlannedTask(planID, taskType, i, params)
		if err != nil {
			return nil, err
		}
		tasks[i] = t
	}
	return withConfigValues(&seiv1alpha1.TaskPlan{
		ID:          planID,
		Phase:       seiv1alpha1.TaskPlanActive,
		Tasks:       tasks,
		TargetPhase: seiv1alpha1.PhaseRunning,
	}, node)
}

// paramsForUpdateTask returns ConfigPatchTask params for TaskConfigPatch
// and the full base intent when configValues drift or an unobserved baseline
// requires regeneration.
//
// WHAT KEEPS marshalParams SAFE HERE IS THE CALL SITE, NOT THE DECLARED TYPES.
// buildPlannedTask marshals whatever this returns, and marshalParams takes
// any, so a package-wide "no float fields are declared" claim does not cover
// the ways a params struct actually fails to marshal. The genesis path in this
// package makes the point: genesisGroupPlanner fills
// AssembleAndUploadGenesisTask.Overrides, a map[string]json.RawMessage built by
// toRawMessages, from SeiNetwork.spec.genesis.overrides. RawMessage.MarshalJSON
// returns non-nil bytes unchanged (nil becomes null); json.Marshal validates
// those bytes and rejects malformed JSON. Declaring no floats likewise says
// nothing about
// resource.Quantity, which marshals as a string rather than a number.
//
// For the current production update progressions, every entry resolves to one
// of four shapes:
//
//   - an empty sidecar task struct (ConfigValidateTask, MarkReadyTask, RestartSeidTask);
//   - a controller-built struct of node name/namespace strings (ApplyStatefulSet,
//     ApplyService, ReplacePod, ObserveImage, and the validator/seed
//     key-validation params, which reduce Secret references and key names to strings);
//   - ConfigPatchTask wrapping p2pConfigPatch, whose leaves are
//     spec.externalAddress and a strings.Join of resolved peers, both strings;
//   - runningConfigIntent's *seiconfig.ConfigIntent for the TaskConfigApply entry
//     that assembleUpdatePlan inserts itself, whose Overrides carries
//     user-supplied spec.overrides but is typed map[string]string. Its remaining
//     fields are a string-based mode, an integer, and a boolean.
//
// These call-site values cannot fail json.Marshal. This is not a guarantee for
// arbitrary patch arguments: a progression entry whose params carry malformed
// json.RawMessage, a NaN or ±Inf float, a channel, or a func would change that;
// ordinary finite floats marshal fine.
func paramsForUpdateTask(node *seiv1alpha1.SeiNode, taskType string, patch map[string]map[string]any) any {
	if taskType == TaskConfigApply {
		return runningConfigIntent(node)
	}
	if taskType == TaskConfigPatch {
		return task.ConfigPatchTask{Files: patch}
	}
	return paramsForTaskType(node, taskType, nil, nil)
}

// mergeOverrides combines controller-generated overrides with user-specified
// overrides. User overrides take precedence — including logging.level, whose
// "error" default is seeded by commonOverrides and can be overridden here.
func mergeOverrides(controllerOverrides, userOverrides map[string]string) map[string]string {
	merged := make(map[string]string, len(controllerOverrides)+len(userOverrides))
	maps.Copy(merged, controllerOverrides)
	maps.Copy(merged, userOverrides)
	return merged
}
