// Package noderesource contains pure generation functions for Kubernetes
// resources owned by a SeiNode. Both the node controller and plan task
// implementations import this package to produce StatefulSets, Services,
// and PVCs from a SeiNode spec.
package noderesource

import (
	"fmt"
	"maps"
	"strings"

	seiconfig "github.com/sei-protocol/sei-config"
	appsv1 "k8s.io/api/apps/v1"
	corev1 "k8s.io/api/core/v1"
	"k8s.io/apimachinery/pkg/api/resource"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/util/intstr"
	"k8s.io/utils/ptr"

	seiv1alpha1 "github.com/sei-protocol/sei-k8s-controller/api/v1alpha1"
	"github.com/sei-protocol/sei-k8s-controller/internal/platform"
	"github.com/sei-protocol/sei-k8s-controller/sidecarapi/wire"
)

const (
	// NodeLabel is the standard label key used on all SeiNode-owned resources.
	NodeLabel = "sei.io/node"

	// chainLabel and roleLabel are observability identity labels lifted
	// into `chain_id` and `component` metric labels by platform-owned
	// (Pod|Service)Monitor relabelings. Pod-template only, never in the
	// StatefulSet selector.
	chainLabel = "sei.io/chain"
	roleLabel  = "sei.io/role"

	// snapshotPublishLabel marks a pod whose node publishes Tendermint
	// snapshots to S3. Stamped (value "true") only when
	// spec.<mode>.snapshotGeneration.tendermint.publish is set — absence is
	// the signal, matching the CRD's presence-as-toggle pattern. The external
	// snapshot-upload CronJob discovers publish-enabled pods by selector
	// sei.io/snapshot-publish=true + sei.io/chain=<chainID> (seictl
	// task/client.go). Never appears in the immutable StatefulSet/Service
	// selectors (which carry only sei.io/node).
	snapshotPublishLabel = "sei.io/snapshot-publish"
	snapshotPublishValue = "true"

	// frozenLabel marks a node held at a block height. Every "is it keeping up"
	// signal is dead by design on such a node, so the height-based alerts must
	// exclude it or they fire forever without resolving: NodeFellBehind trips
	// once the chain advances past its threshold beyond the freeze height and
	// never clears. Never appears in the immutable StatefulSet/Service
	// selectors (which carry only sei.io/node).
	frozenLabel = "sei.io/frozen"
	frozenValue = "true"

	// DedicatedNodeKey is the well-known key used both as the legacy SeiNode
	// annotation (the pre-spec-006 opt-in) and as the pod-template label it is
	// mirrored to. Value "true" on the pod marks single-tenant scheduling: the
	// pod refuses to share a Kubernetes node with any other Sei-managed pod, and
	// every other Sei-managed pod refuses to share a node with it. The typed
	// spec.scheduling.nodeIsolation field supersedes the annotation as the
	// opt-in (see EffectiveNodeIsolation); the label key is unchanged so a
	// rolling upgrade never splits running and new pods across two keys. It is
	// a label because pod anti-affinity selects on labels, not annotations.
	DedicatedNodeKey   = "sei.io/dedicated-node"
	dedicatedNodeValue = "true"

	// hostnameTopologyKey is the standard per-node topology domain; anti-affinity
	// keyed on it enforces isolation at the granularity of a single K8s node.
	hostnameTopologyKey = "kubernetes.io/hostname"

	roleValidator = "validator"
	roleArchive   = "archive"
	roleReplayer  = "replayer"
	roleFullNode  = "node"
	roleSeed      = "seed"

	// Per-mode seid-container footprint: memory and CPU request are both set to
	// the full sei-infra / verified-prod instance envelope for the role (memory
	// is also the limit; CPU has no limit). See defaultNodeResourceProfiles for
	// the full rationale.
	memValidator = "128Gi" // full r5.4xlarge envelope; provisioned on the next size up (r5.8xlarge)
	memRPCClass  = "256Gi" // full r7i.8xlarge envelope (fullNode + replayer); provisioned on r7i.12xlarge
	memArchive   = "512Gi" // full r7i.16xlarge envelope (verified live prod); provisioned on r7i.24xlarge
	memSeed      = "2Gi"   // RFC 006 Appendix A; see defaultNodeResourceProfiles
	cpuValidator = "16"    // r5.4xlarge vCPU; request-only, no CPU limit
	cpuRPCClass  = "32"    // r7i.8xlarge vCPU (fullNode + replayer); request-only, no CPU limit
	cpuArchive   = "64"    // r7i.16xlarge vCPU; request-only, no CPU limit
	cpuSeed      = "1"     // PEX gossip is light and spiky; request-only, no CPU limit

	// goMemLimitPercentOfLimit is the seed's GOMEMLIMIT as a percentage of its
	// memory limit; the remainder is the non-heap margin. See goMemLimitEnv.
	goMemLimitPercentOfLimit = 87

	dataDir = platform.DataDir

	// homeMountPath aliases platform.HomeDir (the container HOME). dataDir must
	// be homeMountPath + "/.sei" (TestHomeDirIsDataDirParent locks it) so a bare
	// seid resolving $HOME/.sei lands on the data dir. See platform.HomeDir for
	// the rationale.
	homeMountPath  = platform.HomeDir
	homeVolumeName = "home"
	// homeEnvVar is the container HOME; set to homeMountPath on every
	// seid-touching container so a bare seid resolves $HOME/.sei onto the data dir.
	homeEnvVar = "HOME"

	// seidHomeFlag is the cosmos-sdk flag that sets seid's working dir.
	seidHomeFlag = "--home"

	// seidStartSubcommand is the seid subcommand that boots the node.
	seidStartSubcommand = "start"

	shellBash = "/bin/bash"

	// Pod-spec container names. Used as both the .Name on built containers
	// and the lookup key for the operator-keyring containment guard.
	containerNameSeid                 = "seid"
	containerNameSidecar              = "sei-sidecar"
	containerNameRBACProxy            = "kube-rbac-proxy"
	containerNameCosmosExporter       = "cosmos-exporter"
	servicePortNameAPI                = "api"
	rbacProxyConfigVolumeName         = "rbac-proxy-config"
	rbacProxyConfigMountPath          = "/etc/kube-rbac-proxy"
	RBACProxyPort               int32 = 8443

	pathHealthz  = "/v0/healthz"
	pathLivez    = "/v0/livez"
	pathStartupz = "/v0/startupz"
	pathMetrics  = "/v0/metrics"

	signingKeyVolumeName    = "signing-key"
	privValidatorKeyDataKey = "priv_validator_key.json"

	nodeKeyVolumeName = "node-key"
	nodeKeyDataKey    = "node_key.json"

	nodeConfigConfigVolumeName = "node-config-config"
	nodeConfigAppVolumeName    = "node-config-app"
	configTomlDataKey          = ConfigTomlKey
	appTomlDataKey             = AppTomlKey

	operatorKeyringVolumeName = "operator-keyring"
	// keyring.New(BackendFile, rootDir) opens rootDir/keyring-file/.
	// Used as the mount path for the projected .secret Secret.
	operatorKeyringDirName = "keyring-file"

	keyringPassphraseEnvVar = "SEI_KEYRING_PASSPHRASE"
	// Required — the SDK's "os" compile-time default has no distroless analogue.
	keyringBackendEnvVar = "SEI_KEYRING_BACKEND"
	// SDK appends "keyring-<backend>"; passing $SEI_HOME resolves to
	// $SEI_HOME/keyring-file/ or $SEI_HOME/keyring-test/.
	keyringDirEnvVar   = "SEI_KEYRING_DIR"
	keyringBackendFile = "file"
	keyringBackendTest = "test"

	// sidecarTmpVolumeName backs an emptyDir at /tmp — required because the
	// sidecar runs with ReadOnlyRootFilesystem and Go stdlib defaults to /tmp.
	sidecarTmpVolumeName = "sidecar-tmp"
	sidecarTmpMountPath  = "/tmp"

	// sidecarNonRootUID is the nonroot UID/GID baked into distroless and
	// chainguard static-debian12 base images. Pod-level fsGroup matches so
	// the non-root sidecar can read kubelet-projected 0o400 Secret files.
	sidecarNonRootUID int64 = 65532

	// defaultCosmosExporterPort matches sei-cosmos-exporter's upstream
	// default. Platform PodMonitors target the named port `cosmos-metrics`.
	defaultCosmosExporterPort int32 = 9300
)

// PlatformConfig is an alias for platform.Config.
type PlatformConfig = platform.Config

// DataPVCName returns the PVC name for a node's data volume.
func DataPVCName(node *seiv1alpha1.SeiNode) string {
	if dv := node.Spec.DataVolume; dv != nil && dv.Import != nil && dv.Import.PVCName != "" {
		return dv.Import.PVCName
	}
	return fmt.Sprintf("data-%s", node.Name)
}

// SelectorLabels returns the minimal, immutable label set used as the
// StatefulSet selector. Only sei.io/node is included because each SeiNode
// has a unique name within a namespace, making it sufficient to select its
// pods. Mutable labels must NOT appear here because Kubernetes forbids
// changing a StatefulSet's selector after creation.
func SelectorLabels(node *seiv1alpha1.SeiNode) map[string]string {
	return map[string]string{NodeLabel: node.Name}
}

// ResourceLabels returns labels for the StatefulSet pod template.
// User-provided podLabels are applied first; system labels win.
func ResourceLabels(node *seiv1alpha1.SeiNode) map[string]string {
	labels := make(map[string]string, len(node.Spec.PodLabels)+4)
	maps.Copy(labels, node.Spec.PodLabels)
	labels[NodeLabel] = node.Name
	if node.Spec.ChainID != "" {
		labels[chainLabel] = node.Spec.ChainID
	}
	labels[roleLabel] = deriveRole(node)
	if IsDedicatedNode(node) {
		labels[DedicatedNodeKey] = dedicatedNodeValue
	}
	if snapshotPublishEnabled(node) {
		labels[snapshotPublishLabel] = snapshotPublishValue
	}
	if node.Spec.Freeze() != nil {
		labels[frozenLabel] = frozenValue
	}
	return labels
}

// snapshotPublishEnabled reports whether the node opts into snapshot
// publishing (spec.<mode>.snapshotGeneration.tendermint.publish set),
// reaching through the FullNode/Archive mode sub-specs that carry a
// SnapshotGeneration config. Drives the sei.io/snapshot-publish label so the
// external snapshot-upload CronJob can discover publish-enabled pods.
func snapshotPublishEnabled(node *seiv1alpha1.SeiNode) bool {
	var sg *seiv1alpha1.SnapshotGenerationConfig
	switch {
	case node.Spec.FullNode != nil:
		sg = node.Spec.FullNode.SnapshotGeneration
	case node.Spec.Archive != nil:
		sg = node.Spec.Archive.SnapshotGeneration
	}
	return sg != nil && sg.Tendermint != nil && sg.Tendermint.Publish != nil
}

// EffectiveNodeIsolation resolves the node isolation the controller acts on,
// by one uniform path for every SeiNode: spec.scheduling.nodeIsolation when
// set; otherwise the legacy sei.io/dedicated-node annotation; otherwise
// Shared. The field has no schema default on purpose — a default would
// materialize Shared onto every existing annotation-only node on upgrade and
// kill the fallback.
func EffectiveNodeIsolation(node *seiv1alpha1.SeiNode) seiv1alpha1.NodeIsolation {
	if s := node.Spec.Scheduling; s != nil && s.NodeIsolation != "" {
		return s.NodeIsolation
	}
	if node.Annotations[DedicatedNodeKey] == dedicatedNodeValue {
		return seiv1alpha1.NodeIsolationDedicated
	}
	return seiv1alpha1.NodeIsolationShared
}

// PodNodeIsolation reports the isolation a running pod was rolled with, read
// from the sei.io/dedicated-node label ResourceLabels stamps on the pod
// template. Pod labels are fixed at creation, so this reflects the template
// the pod actually came from, not the current spec.
func PodNodeIsolation(pod *corev1.Pod) seiv1alpha1.NodeIsolation {
	if pod.Labels[DedicatedNodeKey] == dedicatedNodeValue {
		return seiv1alpha1.NodeIsolationDedicated
	}
	return seiv1alpha1.NodeIsolationShared
}

// IsDedicatedNode reports whether the SeiNode's effective node isolation is
// Dedicated (single-tenant scheduling).
//
// A pod that can never be scheduled (no available single-tenant node) stays
// Pending with no SeiNode condition reflecting it; the owning SeiNetwork
// reports it as pending on status.nodes, or check the pod's own PodScheduled
// condition or events directly.
func IsDedicatedNode(node *seiv1alpha1.SeiNode) bool {
	return EffectiveNodeIsolation(node) == seiv1alpha1.NodeIsolationDedicated
}

// BuildPodAntiAffinity assembles the pod anti-affinity for a Sei pod.
//
// The isolation guarantee is bidirectional and requires two terms because a
// pod anti-affinity is evaluated only from the perspective of the pod being
// scheduled — a running pod does not retroactively repel later arrivals.
//
//   - The defensive term is on EVERY Sei pod (dedicated or not): don't land on
//     a node already hosting a dedicated-node pod. This is what protects a
//     dedicated pod from a LATER pod scheduling next to it. It is near-free —
//     its selector matches nothing unless a dedicated pod exists.
//   - The requester term is added only when dedicated is true: don't land on a
//     node already hosting ANY Sei-managed pod. This protects the dedicated pod
//     at its own schedule time. It keys on sei.io/node via Exists, so it
//     catches every Sei pod, not just those with a sei.io/role value.
//
// Both terms match across all namespaces (an empty, non-nil NamespaceSelector)
// because co-tenants routinely live in other namespaces (per-engineer
// namespaces on shared benchmarking nodepools); the default same-namespace
// scope would silently miss them.
func BuildPodAntiAffinity(dedicated bool) *corev1.PodAntiAffinity {
	terms := []corev1.PodAffinityTerm{{
		TopologyKey:       hostnameTopologyKey,
		NamespaceSelector: &metav1.LabelSelector{},
		LabelSelector: &metav1.LabelSelector{
			MatchExpressions: []metav1.LabelSelectorRequirement{{
				Key:      DedicatedNodeKey,
				Operator: metav1.LabelSelectorOpIn,
				Values:   []string{dedicatedNodeValue},
			}},
		},
	}}
	if dedicated {
		terms = append(terms, corev1.PodAffinityTerm{
			TopologyKey:       hostnameTopologyKey,
			NamespaceSelector: &metav1.LabelSelector{},
			LabelSelector: &metav1.LabelSelector{
				MatchExpressions: []metav1.LabelSelectorRequirement{{
					Key:      NodeLabel,
					Operator: metav1.LabelSelectorOpExists,
				}},
			},
		})
	}
	return &corev1.PodAntiAffinity{
		RequiredDuringSchedulingIgnoredDuringExecution: terms,
	}
}

// NodepoolForMode returns the Karpenter NodePool a pod of the given mode is
// pinned to. A Dedicated node lands on its mode's single-tenant pool when
// app-config names one, replacing (not widening) the per-mode shared pool so the
// pod cannot fall back onto a shared instance. With no single-tenant pool named
// for the mode, the pod stays on the shared per-mode pool and the requester
// anti-affinity term alone keeps it apart from other Sei pods — not from a
// non-Sei co-tenant. The StatefulSet pod picks its pool here so a
// WaitForFirstConsumer volume lands in a zone that pool can serve.
func NodepoolForMode(mode string, p PlatformConfig, dedicated bool) string {
	if dedicated {
		if pool := p.DedicatedNodepoolForMode(mode); pool != "" {
			return pool
		}
	}
	return p.NodepoolForMode(mode)
}

// deriveRole returns the role label value for the node's mode. Stamped
// onto the pod template as `sei.io/role` and lifted into the `sei_role`
// metric label by the platform PodMonitor (see
// platform/clusters/*/monitoring/podmonitor-seid.yaml). Total — a node with
// no mode sub-spec is a full node — so `sei.io/role` is never empty and the
// metric series never drops.
func deriveRole(node *seiv1alpha1.SeiNode) string {
	switch {
	case node.Spec.Validator != nil:
		return roleValidator
	case node.Spec.Archive != nil:
		return roleArchive
	case node.Spec.Replayer != nil:
		return roleReplayer
	case node.Spec.Seed != nil:
		return roleSeed
	default:
		return roleFullNode
	}
}

// NodeMode returns the sei-config mode string for the node based on which
// sub-spec is populated. Falls back to "full" if none is set.
func NodeMode(node *seiv1alpha1.SeiNode) string {
	switch {
	case node.Spec.Archive != nil:
		return string(seiconfig.ModeArchive)
	case node.Spec.Validator != nil:
		return string(seiconfig.ModeValidator)
	case node.Spec.Seed != nil:
		return string(seiconfig.ModeSeed)
	case node.Spec.Replayer != nil:
		return string(seiconfig.ModeFull)
	default:
		return string(seiconfig.ModeFull)
	}
}

// servesSeidRPC reports whether seid binds its RPC and gRPC listeners. True for
// every mode but seed, which runs the P2P transport and PEX reactor only.
//
// It gates the two pod-spec decisions that poll those ports — the readiness probe
// target, and whether cosmos-exporter is attached. On a seed both wait forever:
// readiness never passes, and cosmos-exporter's wait loop never reaches its own
// listener, so its liveness probe kills it. Named for the property rather than
// the mode so the call sites read as intent.
func servesSeidRPC(node *seiv1alpha1.SeiNode) bool {
	return node.Spec.Seed == nil && !node.Spec.EffectiveExecutionEngine().IsEvmOnly()
}

// NeedsLongStartup returns true when the node's bootstrap strategy involves
// replaying blocks, requiring extended startup probe thresholds.
func NeedsLongStartup(node *seiv1alpha1.SeiNode) bool {
	switch {
	case node.Spec.FullNode != nil:
		return node.Spec.FullNode.Snapshot != nil
	case node.Spec.Validator != nil:
		return node.Spec.Validator.Snapshot != nil
	case node.Spec.Replayer != nil:
		return true
	case node.Spec.Archive != nil:
		return true
	default:
		return false
	}
}

// StorageForNode resolves a node's data-volume class and size; the PVC generator
// and the import floor both route through here so they cannot drift.
// spec.dataVolume.storage overrides the per-mode size; the class has no CRD rung
// yet. Returns a string so callers keep their existing parse handling.
func StorageForNode(node *seiv1alpha1.SeiNode, p PlatformConfig) (storageClass string, size string) {
	storageClass, size = DefaultStorageForMode(NodeMode(node), p)
	if q := crdStorageSize(node); q != nil {
		size = q.String()
	}
	return storageClass, size
}

// crdStorageSize returns the CRD-set size, or nil to fall through. An importing
// node never reaches the non-nil branch (storage and import are exclusive).
func crdStorageSize(node *seiv1alpha1.SeiNode) *resource.Quantity {
	dv := node.Spec.DataVolume
	if dv == nil || dv.Storage == nil || dv.Storage.Resources == nil {
		return nil
	}
	if q, ok := dv.Storage.Resources.Requests[corev1.ResourceStorage]; ok {
		return &q
	}
	return nil
}

// VolumeAttributesClassForNode returns the VolumeAttributesClass name the node
// selects for the volume the controller provisions, or nil to leave the PVC's
// volumeAttributesClassName unset — the mode-default StorageClass then supplies
// the baseline performance. There is no app-config or per-mode rung below the
// CRD field: the ladder for this name is one rung deep by design (DR-001).
//
// An importing node never reaches the non-nil branch (storage and import are
// mutually exclusive), so an imported volume keeps the importer's parameters.
// The returned pointer is a copy, so a caller cannot alias the node's spec.
func VolumeAttributesClassForNode(node *seiv1alpha1.SeiNode) *string {
	dv := node.Spec.DataVolume
	if dv == nil || dv.Storage == nil || dv.Storage.VolumeAttributesClassName == nil {
		return nil
	}
	name := *dv.Storage.VolumeAttributesClassName
	return &name
}

// DefaultStorageForMode returns the StorageClass name and PVC size for a
// node based on its operating mode. Lowest size rung; see StorageForNode.
func DefaultStorageForMode(mode string, p PlatformConfig) (storageClass string, size string) {
	switch mode {
	case string(seiconfig.ModeArchive):
		return p.StorageClassArchive, p.StorageSizeArchive
	case string(seiconfig.ModeFull), string(seiconfig.ModeValidator):
		return p.StorageClassPerf, p.StorageSizeDefault
	case string(seiconfig.ModeSeed):
		// A seed stores a peer store and two DBs it never writes, so it needs
		// orders of magnitude less than StorageSizeDefault (sized for a chain's
		// full state) and no performance class.
		return p.StorageClassDefault, p.SeedStorageSize()
	default:
		return p.StorageClassDefault, p.StorageSizeDefault
	}
}

// nodeResourceProfile is a resolved per-mode seid-container footprint: a CPU
// request and a single memory value used as BOTH request and limit. CPU is
// request-only — seid is work-conserving and CPU is compressible, so a CPU
// limit would only throttle its 10–12 core consensus/replay bursts; there is no
// CPU-limit field.
//
// This is the LOWEST of three sizing sources; see ResourcesForNode for the
// ladder above it.
type nodeResourceProfile struct {
	cpuRequest string
	// memory is set as both the memory request and the memory limit
	// (memory-Guaranteed: the mode's footprint is hard-reserved and hard-capped).
	memory string
}

// defaultNodeResourceProfiles is the per-mode seid-container footprint, applied
// whenever neither the node's spec.resources field nor the app-config file's
// resources.<mode> override supplies a dimension. One uniform profile per CRD
// mode, keyed off deriveRole (the CRD sub-spec) — NOT the 3-way seiconfig mode,
// which collapses replayer and fullNode into "full" though they take distinct
// footprints.
//
// These values are the PROD-SAFE fallback for every cluster, not a benchmark
// default. A cheap "quick test" shape belongs on spec.resources at the point of
// use; lowering a figure here shrinks every production node of that mode and
// breaks the Karpenter contract described below.
//
// Each mode's memory (request==limit, memory-Guaranteed) and CPU (request-only)
// equal the full RAM/vCPU of its sei-infra reference instance. The Karpenter
// pool (platform side) provisions one instance size larger, so the footprint
// fits node allocatable (~95% of advertised, less DaemonSets/sidecars) and the
// unrequested surplus serves as seid page cache:
//
//	role                 reference instance     request      provisioned node
//	validator            r5.4xlarge   (128/16)  128Gi / 16   r*.8xlarge  (256)
//	fullNode / replayer  r7i.8xlarge  (256/32)  256Gi / 32   r*.12xlarge (384)
//	archive              r7i.16xlarge (512/64)  512Gi / 64   r*.24xlarge (768)
//
// The request and the pool's instance size are a provider/consumer contract:
// each request stays ≤ the provisioned node's allocatable and below Karpenter's
// provisioning estimate (advertised × (1 − VM_MEMORY_OVERHEAD_PERCENT)); keep
// both sides in sync when either changes. Memory (request==limit at ~half the
// node) is the binding dimension, so one seid schedules per node.
//
// A value change reaches a running pod only on pod recreation: the StatefulSets
// use UpdateStrategy: OnDelete, so the pod template updates but a live pod keeps
// its footprint until a replace-pod, drain, or eviction.
//
// Every deriveRole output MUST have an entry here (a missing key yields a
// zero-value profile → firstNonEmpty("","") → resource.MustParse("") panics in
// reconcile). A new role means a new entry AND a case in
// TestResourcesForNode_DefaultsPerMode.
var defaultNodeResourceProfiles = map[string]nodeResourceProfile{
	// Signing node — OOM means missed blocks / slashing; hard-capped at the full
	// r5.4xlarge envelope.
	roleValidator: {cpuRequest: cpuValidator, memory: memValidator},
	// Absorbs public-RPC + snapshotter + state-syncer; full r7i.8xlarge envelope.
	roleFullNode: {cpuRequest: cpuRPCClass, memory: memRPCClass},
	// Same footprint as fullNode (r7i.8xlarge).
	roleReplayer: {cpuRequest: cpuRPCClass, memory: memRPCClass},
	// Full r7i.16xlarge envelope — the live-prod snapshotter shape (the sei-infra
	// TF's m7i.8xlarge is stale).
	roleArchive: {cpuRequest: cpuArchive, memory: memArchive},
	// Peer discovery only: no block execution, no state commitment, no query
	// surface. The exception to the "request == the reference instance's full
	// envelope" rule above — a seed is deliberately small, and this is RFC 006
	// Appendix A's figure, which also keeps it on the t-class instances and
	// inside the cost line that RFC budgets.
	//
	// Accepted risk while PLT-850 is open: seid's pre-auth handshake read is
	// bounded far above what a legitimate handshake needs, and the seed's
	// connection cap scales it, so a remote unauthenticated flood can allocate
	// well past this footprint. That memory is live, so GOMEMLIMIT cannot reclaim
	// it and only absolute headroom would absorb it — which no figure in the RFC
	// provides. Sizing around it would break the instance class and the budget,
	// so the exposure is tracked upstream rather than bought off here. When
	// PLT-850 lands this figure carries real headroom.
	roleSeed: {cpuRequest: cpuSeed, memory: memSeed},
}

// overrideForRole returns the app-config resource override for a node's mode.
func overrideForRole(role string, p PlatformConfig) platform.ResourceOverride {
	switch role {
	case roleValidator:
		return p.NodeResourcesValidator
	case roleArchive:
		return p.NodeResourcesArchive
	case roleReplayer:
		return p.NodeResourcesReplayer
	case roleSeed:
		return p.NodeResourcesSeed
	default:
		return p.NodeResourcesNode
	}
}

// ResourcesForNode returns the seid-container resource requirements for a node:
// a CPU request and a memory request==limit (no CPU limit — see
// nodeResourceProfile).
//
// Three sizing sources, resolved PER-DIMENSION (highest first), so raising one
// axis never forces an operator to restate the rest:
//
//  1. the node's spec.resources field       — typed, per-object (benchmark knob)
//  2. the app-config resources.<mode> block — per-cluster (overrideForRole)
//  3. defaultNodeResourceProfiles[role]     — code-authoritative, prod-safe
//
// Both per-mode couplings survive the new source unchanged: memory is emitted as
// request AND limit, and CPU never carries a limit. The CRD's own
// resources.limits.memory is therefore not read here — admission already pins it
// equal to the request (see Resources), and the limit below is derived from
// the request regardless of whether the operator spelled it out.
//
// Only sources 2 and 3 reach MustParse, and both are pre-validated: the
// app-config strings are parse-checked at startup by Config.Validate, and the
// code defaults are compile-time constants. Source 1 arrives as an
// apiserver-validated resource.Quantity, so the CRD path adds no panic risk to
// the reconcile.
func ResourcesForNode(node *seiv1alpha1.SeiNode, p PlatformConfig) corev1.ResourceRequirements {
	role := deriveRole(node)
	d := defaultNodeResourceProfiles[role]
	o := overrideForRole(role, p)
	crdCPU, crdMem := resourcesFrom(node)

	cpuReq := resolveQuantity(crdCPU, o.CPURequest, d.cpuRequest)
	mem := resolveQuantity(crdMem, o.Memory, d.memory)

	return corev1.ResourceRequirements{
		Requests: corev1.ResourceList{
			corev1.ResourceCPU:    cpuReq,
			corev1.ResourceMemory: mem,
		},
		Limits: corev1.ResourceList{
			// Memory limit == request: hard-reserved and hard-capped per mode.
			corev1.ResourceMemory: mem,
		},
	}
}

// resourcesFrom returns the CPU and memory requests the node's spec.resources
// field sets, or nil for a dimension it leaves unset. A nil return is the signal
// to fall through to the next source, which is why this reports presence rather
// than a zero Quantity — an explicit "0" and an absent key are different
// intents, and only the absent one should fall through.
func resourcesFrom(node *seiv1alpha1.SeiNode) (cpu, mem *resource.Quantity) {
	r := node.Spec.Resources
	if r == nil {
		return nil, nil
	}
	if q, ok := r.Requests[corev1.ResourceCPU]; ok {
		cpu = &q
	}
	if q, ok := r.Requests[corev1.ResourceMemory]; ok {
		mem = &q
	}
	return cpu, mem
}

// resolveQuantity picks one dimension off the sizing ladder in ResourcesForNode:
// the CRD field when it sets this dimension, else the app-config override, else
// the per-mode code default.
func resolveQuantity(crd *resource.Quantity, override, codeDefault string) resource.Quantity {
	if crd != nil {
		return *crd
	}
	return resource.MustParse(firstNonEmpty(override, codeDefault))
}

func firstNonEmpty(a, b string) string {
	if strings.TrimSpace(a) != "" {
		return a
	}
	return b
}

// ---------------------------------------------------------------------------
// StatefulSet generation
// ---------------------------------------------------------------------------

// GenerateStatefulSet produces the desired StatefulSet for a SeiNode.
//
// Returns an error if the resulting pod-spec violates the operator-keyring
// containment invariant — only the sidecar container may mount that volume,
// plus the seid main container when the node has explicitly opted in via
// .secret.SeidMount. Never a non-sidecar init container, regardless.
func GenerateStatefulSet(node *seiv1alpha1.SeiNode, p PlatformConfig) (*appsv1.StatefulSet, error) {
	if p.KubeRBACProxyImage == "" {
		return nil, fmt.Errorf("images.kubeRBACProxy is not configured in the app-config file")
	}
	// Unreachable in a running controller — Config.Validate requires
	// scheduling.nodepoolSeed at startup. Kept for the same reason the check
	// above is: NodepoolForMode gives a seed no fallback, so an empty value here
	// would silently schedule it onto the RPC-class default pool.
	if !servesSeidRPC(node) && p.NodepoolSeed == "" {
		return nil, fmt.Errorf("scheduling.nodepoolSeed is not configured in the app-config file")
	}
	one := int32(1)
	labels := ResourceLabels(node)
	podSpec, err := buildNodePodSpec(node, p)
	if err != nil {
		return nil, err
	}

	if err := assertOperatorKeyringContainment(node, &podSpec); err != nil {
		return nil, err
	}

	return &appsv1.StatefulSet{
		ObjectMeta: metav1.ObjectMeta{
			Name:      node.Name,
			Namespace: node.Namespace,
			Labels:    labels,
		},
		Spec: appsv1.StatefulSetSpec{
			Replicas:    &one,
			ServiceName: node.Name,
			Selector: &metav1.LabelSelector{
				MatchLabels: SelectorLabels(node),
			},
			PodManagementPolicy: podManagementPolicy(node),
			UpdateStrategy:      updateStrategy(node),
			Template: corev1.PodTemplateSpec{
				ObjectMeta: metav1.ObjectMeta{
					Labels: labels,
					Annotations: map[string]string{
						"karpenter.sh/do-not-disrupt": "true",
					},
				},
				Spec: podSpec,
			},
		},
	}, nil
}

// updateStrategy returns who rolls the pod. For a controller-configured node
// that is the controller (replace-pod), because config tasks must be ordered
// around the roll. A node with spec.nodeConfig has no config tasks, so the
// StatefulSet controller rolls it on any template change.
func updateStrategy(node *seiv1alpha1.SeiNode) appsv1.StatefulSetUpdateStrategy {
	if node.Spec.NodeConfig != nil {
		return appsv1.StatefulSetUpdateStrategy{Type: appsv1.RollingUpdateStatefulSetStrategyType}
	}
	return appsv1.StatefulSetUpdateStrategy{Type: appsv1.OnDeleteStatefulSetStrategyType}
}

// podManagementPolicy is Parallel for a RollingUpdate node. Under OrderedReady
// the StatefulSet controller will not update a pod that is not Ready, so a seid
// halted at an upgrade height would never take the new image. The API server
// refuses to change this field on an existing StatefulSet, which is why
// spec.nodeConfig is fixed at creation. Empty leaves the API default.
func podManagementPolicy(node *seiv1alpha1.SeiNode) appsv1.PodManagementPolicyType {
	if node.Spec.NodeConfig != nil {
		return appsv1.ParallelPodManagement
	}
	return ""
}

// assertOperatorKeyringContainment fails closed if a pod-spec lands
// operator-keyring material anywhere outside its permitted containers: the
// sidecar always, and the seid main container only when the node has
// explicitly opted in via .secret.SeidMount. seid-init and every other
// container are forbidden regardless of exposure — a future refactor
// mis-mounting the keyring there is still a bug, not a debug convenience.
// Checks both the keyring volume mount AND env-var references to the
// passphrase Secret — either alone is enough to recover the unlocked
// operator key.
//
// Scoped to the .secret path: the test-backend keyring shares the data PVC
// seid already owns, so the guard has nothing to assert. Operators who need
// keyring/seid isolation set .secret, which engages this check.
func assertOperatorKeyringContainment(node *seiv1alpha1.SeiNode, spec *corev1.PodSpec) error {
	src := operatorKeyringSecretSource(node)
	if src == nil {
		return nil
	}
	passphraseSecretName := src.PassphraseSecretRef.SecretName

	permitted := map[string]bool{containerNameSidecar: true}
	if src.SeidMount {
		permitted[containerNameSeid] = true
	}

	check := func(c *corev1.Container) error {
		for _, m := range c.VolumeMounts {
			if m.Name == operatorKeyringVolumeName {
				return fmt.Errorf("pod-spec for %s/%s mounts operator-keyring volume on container %q; "+
					"operator-keyring is exclusively the sidecar's (plus seid main when .secret.seidMount is set) — mounting elsewhere would collapse containment",
					node.Namespace, node.Name, c.Name)
			}
		}
		for _, ev := range c.Env {
			if ev.ValueFrom != nil && ev.ValueFrom.SecretKeyRef != nil &&
				ev.ValueFrom.SecretKeyRef.Name == passphraseSecretName {
				return fmt.Errorf("pod-spec for %s/%s references operator-keyring passphrase Secret %q in env %q on container %q; "+
					"the passphrase is exclusively the sidecar's (plus seid main when .secret.seidMount is set)",
					node.Namespace, node.Name, passphraseSecretName, ev.Name, c.Name)
			}
		}
		for _, ef := range c.EnvFrom {
			if ef.SecretRef != nil && ef.SecretRef.Name == passphraseSecretName {
				return fmt.Errorf("pod-spec for %s/%s references operator-keyring passphrase Secret %q via envFrom on container %q; "+
					"the passphrase is exclusively the sidecar's (plus seid main when .secret.seidMount is set)",
					node.Namespace, node.Name, passphraseSecretName, c.Name)
			}
		}
		return nil
	}

	for i := range spec.Containers {
		if permitted[spec.Containers[i].Name] {
			continue
		}
		if err := check(&spec.Containers[i]); err != nil {
			return err
		}
	}
	for i := range spec.InitContainers {
		if permitted[spec.InitContainers[i].Name] {
			continue
		}
		if err := check(&spec.InitContainers[i]); err != nil {
			return err
		}
	}
	return nil
}

// ---------------------------------------------------------------------------
// Service generation
// ---------------------------------------------------------------------------

// GenerateHeadlessService produces the desired headless Service for a SeiNode.
func GenerateHeadlessService(node *seiv1alpha1.SeiNode) *corev1.Service {
	ports := append(ServicePorts(), corev1.ServicePort{
		Name:       servicePortNameAPI,
		Port:       RBACProxyPort,
		TargetPort: intstr.FromInt32(RBACProxyPort),
		Protocol:   corev1.ProtocolTCP,
	})
	return &corev1.Service{
		ObjectMeta: metav1.ObjectMeta{
			Name:      node.Name,
			Namespace: node.Namespace,
			Labels:    ResourceLabels(node),
		},
		Spec: corev1.ServiceSpec{
			ClusterIP:                corev1.ClusterIPNone,
			Selector:                 SelectorLabels(node),
			Ports:                    ports,
			PublishNotReadyAddresses: true,
		},
	}
}

// ---------------------------------------------------------------------------
// PVC generation
// ---------------------------------------------------------------------------

// GenerateDataPVC produces the desired PersistentVolumeClaim for a SeiNode's
// data volume. Size resolved by StorageForNode, performance selection by
// VolumeAttributesClassForNode — nil there leaves volumeAttributesClassName off
// the claim entirely, which is the no-selection case, not an empty selection.
func GenerateDataPVC(node *seiv1alpha1.SeiNode, p PlatformConfig) *corev1.PersistentVolumeClaim {
	sc, size := StorageForNode(node, p)

	return &corev1.PersistentVolumeClaim{
		ObjectMeta: metav1.ObjectMeta{
			Name:      DataPVCName(node),
			Namespace: node.Namespace,
			Labels:    ResourceLabels(node),
		},
		Spec: corev1.PersistentVolumeClaimSpec{
			AccessModes:      []corev1.PersistentVolumeAccessMode{corev1.ReadWriteOnce},
			StorageClassName: &sc,
			Resources: corev1.VolumeResourceRequirements{
				Requests: corev1.ResourceList{
					corev1.ResourceStorage: resource.MustParse(size),
				},
			},
			VolumeAttributesClassName: VolumeAttributesClassForNode(node),
		},
	}
}

// ---------------------------------------------------------------------------
// Ports
// ---------------------------------------------------------------------------

// ContainerPorts returns the container port list for seid.
func ContainerPorts() []corev1.ContainerPort {
	np := seiconfig.NodePorts()
	ports := make([]corev1.ContainerPort, len(np))
	for i, p := range np {
		ports[i] = corev1.ContainerPort{Name: p.Name, ContainerPort: p.Port, Protocol: corev1.ProtocolTCP}
	}
	return ports
}

// ServicePorts returns the service port list for the headless Service.
func ServicePorts() []corev1.ServicePort {
	np := seiconfig.NodePorts()
	ports := make([]corev1.ServicePort, len(np))
	for i, p := range np {
		ports[i] = corev1.ServicePort{Name: p.Name, Port: p.Port, TargetPort: intstr.FromInt32(p.Port), Protocol: corev1.ProtocolTCP}
		if p.Name == seiconfig.PortNameGRPC {
			h2c := "kubernetes.io/h2c"
			ports[i].AppProtocol = &h2c
		}
	}
	return ports
}

// ---------------------------------------------------------------------------
// Internal helpers
// ---------------------------------------------------------------------------

func buildNodePodSpec(node *seiv1alpha1.SeiNode, p PlatformConfig) (corev1.PodSpec, error) {
	dataVolume := corev1.Volume{
		Name: "data",
		VolumeSource: corev1.VolumeSource{
			PersistentVolumeClaim: &corev1.PersistentVolumeClaimVolumeSource{
				ClaimName: DataPVCName(node),
			},
		},
	}

	signingVolumes := signingKeyVolumes(node)
	nodeVolumes := nodeKeyVolumes(node)
	keyringVolumes := operatorKeyringVolumes(node)
	proxyConfigVolume := corev1.Volume{
		Name: rbacProxyConfigVolumeName,
		VolumeSource: corev1.VolumeSource{
			ConfigMap: &corev1.ConfigMapVolumeSource{
				LocalObjectReference: corev1.LocalObjectReference{Name: RBACProxyConfigMapName(node)},
			},
		},
	}
	sidecarTmpVolume := corev1.Volume{
		Name:         sidecarTmpVolumeName,
		VolumeSource: corev1.VolumeSource{EmptyDir: &corev1.EmptyDirVolumeSource{}},
	}
	// homeVolume is the writable emptyDir backing HOME at homeMountPath. Shell
	// and home writes land here, not on the data PVC (which nests at
	// homeMountPath/.sei). See platform.HomeDir for the rationale.
	homeVolume := corev1.Volume{
		Name:         homeVolumeName,
		VolumeSource: corev1.VolumeSource{EmptyDir: &corev1.EmptyDirVolumeSource{}},
	}
	configVolumes := nodeConfigVolumes(node)
	volumes := make([]corev1.Volume, 0, 4+len(signingVolumes)+len(nodeVolumes)+len(keyringVolumes)+len(configVolumes))
	volumes = append(volumes, dataVolume, sidecarTmpVolume, homeVolume, proxyConfigVolume)
	volumes = append(volumes, signingVolumes...)
	volumes = append(volumes, nodeVolumes...)
	volumes = append(volumes, keyringVolumes...)
	volumes = append(volumes, configVolumes...)

	dedicated := IsDedicatedNode(node)
	pool := NodepoolForMode(NodeMode(node), p, dedicated)

	spec := corev1.PodSpec{
		// AutomountServiceAccountToken is explicit here because the
		// kube-rbac-proxy fronting the sidecar API calls TokenReview +
		// SubjectAccessReview against the K8s API using the pod's
		// projected SA token. Cluster-default flips that silently
		// disable this would break the auth path.
		AutomountServiceAccountToken: ptr.To(true), //nolint:modernize // ptr.To(true) is idiomatic; new(true) is invalid Go
		ServiceAccountName:           p.ServiceAccount,
		Tolerations: []corev1.Toleration{
			{Key: p.TolerationKey, Value: pool, Effect: corev1.TaintEffectNoSchedule},
		},
		Affinity: &corev1.Affinity{
			NodeAffinity: &corev1.NodeAffinity{
				RequiredDuringSchedulingIgnoredDuringExecution: &corev1.NodeSelector{
					NodeSelectorTerms: []corev1.NodeSelectorTerm{{
						MatchExpressions: []corev1.NodeSelectorRequirement{{
							Key:      "karpenter.sh/nodepool",
							Operator: corev1.NodeSelectorOpIn,
							Values:   []string{pool},
						}},
					}},
				},
			},
			PodAntiAffinity: BuildPodAntiAffinity(dedicated),
		},
		Volumes: volumes,
	}

	// ShareProcessNamespace is currently enabled across all SeiNode pods. A
	// compromised seid container can therefore read /proc/<sidecar>/environ
	// and /proc/<sidecar>/mem, including the operator-keyring passphrase and
	// the unlocked in-memory keyring. This is a known limitation of the v1
	// trust boundary; tightening it (drop shareProcessNamespace, harden the
	// seid SecurityContext, separate sidecar SA) is a separate workstream.
	spec.ShareProcessNamespace = ptr.To(true)
	// Kubelet handles PVC ownership migration: on first mount of a legacy
	// root-owned volume, OnRootMismatch triggers a recursive `chown :65532`
	// + `chmod g+rwX`. Subsequent mounts skip the walk.
	fsGroup := sidecarNonRootUID
	fsGroupChangePolicy := corev1.FSGroupChangeOnRootMismatch
	spec.SecurityContext = &corev1.PodSecurityContext{
		FSGroup:             &fsGroup,
		FSGroupChangePolicy: &fsGroupChangePolicy,
	}
	spec.InitContainers = []corev1.Container{
		buildSeidInitContainer(node),
		buildSidecarContainer(node, p),
		buildRBACProxyContainer(node, p),
	}
	seidContainer := buildSidecarMainContainer(node, p)
	// Refuse to render a gated seid container that carries an RPC-based
	// liveness/startup probe: a held seid answers neither port, so such a probe
	// would let the kubelet kill the held pod and release the hold.
	if err := ValidateGatedSeidProbes(seidContainer); err != nil {
		return corev1.PodSpec{}, err
	}
	// A seed's readiness must not depend on seid's RPC/gRPC, which it never binds.
	if err := ValidateSeedProbes(node, seidContainer); err != nil {
		return corev1.PodSpec{}, err
	}
	spec.Containers = []corev1.Container{seidContainer}

	// cosmos-exporter scrapes staking and validator state over seid's gRPC. A
	// seed serves neither, so attaching it there would leave it blocked in its
	// wait loop until its own liveness probe killed it.
	if servesSeidRPC(node) {
		ceContainer, err := buildCosmosExporterContainer(p)
		if err != nil {
			return corev1.PodSpec{}, err
		}
		spec.Containers = append(spec.Containers, ceContainer)
	}

	return spec, nil
}

func sidecarImage(node *seiv1alpha1.SeiNode, p PlatformConfig) string {
	if node.Spec.Sidecar != nil && node.Spec.Sidecar.Image != "" {
		return node.Spec.Sidecar.Image
	}
	return p.SidecarImage
}

// SidecarPort returns the sidecar HTTP port for the node.
func SidecarPort(node *seiv1alpha1.SeiNode) int32 {
	if node.Spec.Sidecar != nil && node.Spec.Sidecar.Port != 0 {
		return node.Spec.Sidecar.Port
	}
	return seiconfig.PortSidecar
}

func buildSidecarContainer(node *seiv1alpha1.SeiNode, p PlatformConfig) corev1.Container {
	port := SidecarPort(node)
	keyringEnv := operatorKeyringEnvVars(node)
	env := make([]corev1.EnvVar, 0, 9+len(keyringEnv))
	env = append(env,
		corev1.EnvVar{Name: "SEI_CHAIN_ID", Value: node.Spec.ChainID},
		corev1.EnvVar{Name: "SEI_SIDECAR_PORT", Value: fmt.Sprintf("%d", port)},
		corev1.EnvVar{Name: "SEI_HOME", Value: dataDir},
		// HOME mirrors the seid containers (the writable `home` emptyDir, parent
		// of the data dir). seictl signs via SEI_HOME, so this env is only for
		// symmetry (the home mount below is load-bearing, not cosmetic — see
		// there). It also lets a bare seid exec'd in the sidecar resolve
		// $HOME/.sei onto the data dir, with $HOME writable under the RO rootfs.
		corev1.EnvVar{Name: homeEnvVar, Value: homeMountPath},
		corev1.EnvVar{Name: "SEI_GENESIS_BUCKET", Value: p.GenesisBucket},
		corev1.EnvVar{Name: "SEI_GENESIS_REGION", Value: p.GenesisRegion},
		corev1.EnvVar{Name: "SEI_SNAPSHOT_BUCKET", Value: p.SnapshotBucket},
		corev1.EnvVar{Name: "SEI_SNAPSHOT_REGION", Value: p.SnapshotRegion},
	)
	// Sidecar binds loopback and trusts the X-Remote-User header from
	// kube-rbac-proxy. The proxy is the only client reachable on the
	// sidecar's port inside the pod's net ns.
	env = append(env, corev1.EnvVar{Name: "SEI_SIDECAR_AUTHN_MODE", Value: "trusted-header"})
	env = append(env, keyringEnv...)

	keyringMounts := operatorKeyringMounts(node)
	configMounts := nodeConfigMounts(node)
	mounts := make([]corev1.VolumeMount, 0, 3+len(keyringMounts)+len(configMounts))
	mounts = append(mounts,
		// The `home` emptyDir backs homeMountPath so the nested data-PVC mount
		// has a writable-volume parent, rather than depending on the RO rootfs
		// shipping /home/nonroot. Mirrors the seid containers.
		corev1.VolumeMount{Name: homeVolumeName, MountPath: homeMountPath},
		// Mounted RW so generate-gentx can write the operator key the sidecar later reads.
		corev1.VolumeMount{Name: "data", MountPath: dataDir},
		corev1.VolumeMount{Name: sidecarTmpVolumeName, MountPath: sidecarTmpMountPath},
	)
	mounts = append(mounts, keyringMounts...)
	mounts = append(mounts, configMounts...)

	// No Command — the sidecar image's ENTRYPOINT is the command.
	c := corev1.Container{
		Name:          containerNameSidecar,
		Image:         sidecarImage(node, p),
		RestartPolicy: ptr.To(corev1.ContainerRestartPolicyAlways),
		Env:           env,
		Ports: []corev1.ContainerPort{
			{Name: "sidecar", ContainerPort: port, Protocol: corev1.ProtocolTCP},
		},
		VolumeMounts:    mounts,
		SecurityContext: sidecarSecurityContext(),
	}
	if node.Spec.Sidecar != nil && node.Spec.Sidecar.Resources != nil {
		c.Resources = *node.Spec.Sidecar.Resources
	}
	return c
}

func buildSidecarMainContainer(node *seiv1alpha1.SeiNode, p PlatformConfig) corev1.Container {
	container := buildNodeMainContainer(node)
	container.Command, container.Args = sidecarWaitCommand(node)
	container.Resources = ResourcesForNode(node, p)
	if env, ok := goMemLimitEnv(node, container.Resources); ok {
		container.Env = append(container.Env, env)
	}
	// Sidecar binds loopback; gate startup on the proxy's /v0/healthz
	// (a bypass path that forwards through to the sidecar).
	container.StartupProbe = &corev1.Probe{
		ProbeHandler: corev1.ProbeHandler{HTTPGet: &corev1.HTTPGetAction{
			Path: pathHealthz,
			Port: intstr.FromInt32(RBACProxyPort),
		}},
		InitialDelaySeconds: 5,
		PeriodSeconds:       5,
		FailureThreshold:    86400,
	}
	container.ReadinessProbe = readinessProbeForNode(node)
	return container
}

// goMemLimitEnv returns the GOMEMLIMIT env var for a seed's seid container.
//
// The Go runtime targets a heap roughly twice the live set and cannot see the
// cgroup limit, so with memory request==limit reclaimable growth becomes an
// OOMKill rather than a throttle. A soft limit below the hard cap makes the GC
// spend CPU to stay resident instead.
//
// What it does and does not cover: it governs churn — buffers allocated and
// freed at rate, which GOGC alone would let balloon toward twice the live set.
// It cannot shrink memory that is genuinely live, and it does not account for
// non-heap RSS at all: thread stacks, cgo allocations, mmap'd memIAVL pages, or
// the kernel socket buffers a thousand connections charge to the cgroup. The
// concurrent pre-auth handshake burst that sizes this mode is live memory, so
// absolute headroom is what defends it — not this limit. The margin below the
// cap exists for the non-heap share.
//
// Scoped to seed as a matter of caution rather than principle: GC slack is
// proportional to the live set, so any mode with request==limit would benefit.
// The other modes are tuned and prod-proven, and changing their runtime
// behaviour is not this change's business.
//
// Derived from the resolved limit, so an app-config resources.seed override
// keeps it consistent. Reports false when no memory limit is set, or when the
// limit is small enough that the computed soft cap would be useless.
func goMemLimitEnv(node *seiv1alpha1.SeiNode, res corev1.ResourceRequirements) (corev1.EnvVar, bool) {
	if servesSeidRPC(node) {
		return corev1.EnvVar{}, false
	}
	lim, ok := res.Limits[corev1.ResourceMemory]
	if !ok {
		return corev1.EnvVar{}, false
	}
	// Multiply first: the truncation from dividing first is harmless but the
	// product cannot overflow int64 at any schedulable memory limit.
	soft := lim.Value() * goMemLimitPercentOfLimit / 100
	if soft <= 0 {
		return corev1.EnvVar{}, false
	}
	return corev1.EnvVar{Name: "GOMEMLIMIT", Value: fmt.Sprintf("%dB", soft)}, true
}

// readinessProbeForNode returns the seid readiness probe for the node's mode.
// Three cases, in the order the function tests them.
//
// An UNFROZEN chain-following mode gates on seid's /lag_status, which reports
// sync distance — the meaningful "ready to serve" signal.
//
// A FROZEN node gates on /status instead. Its lag is a constant, not a
// shrinking quantity: block sync hands off at the freeze height and the peer
// pool keeps the tip it last observed, so /lag_status reports the same distance
// forever and the pod would never become Ready. /status stays valid at a pinned
// height and, unlike a bare TCP connect, it proves the RPC server answers
// rather than that a socket is bound. It does not prove the node has REACHED
// the freeze height: /status answers throughout the initial block sync, so a
// frozen node reads Ready while it is still catching up.
//
// A SEED serves no RPC, so its only in-band signal is that the P2P transport is
// bound: it distinguishes a crashed seid or a failed bind from a live one, and
// nothing more.
//
// Two limits an operator must know about the seed case. It proves nothing about
// EXTERNAL reachability — a seed with no DNS record, no load balancer, or a
// closed security group reads Ready while no stranger can dial it. And each
// probe completes a TCP connect without the secret handshake, so it increments
// tendermint_p2p_new_connections{direction="in"} and books a handshake failure
// roughly 6/min; alerts on those series need that baseline subtracted, and
// inbound connections alone do not prove a seed is publicly reachable.
func readinessProbeForNode(node *seiv1alpha1.SeiNode) *corev1.Probe {
	if servesSeidRPC(node) && node.Spec.Freeze() == nil {
		return httpReadinessProbe(pathLagStatus, seiconfig.PortRPC)
	}
	up := UpCheckForNode(node)
	if up.Scheme == wire.UpCheckTCP {
		return tcpReadinessProbe(up.Port)
	}
	return httpReadinessProbe(up.Path, up.Port)
}

// UpCheckForNode returns the signal that proves seid answers for this node's
// engine and mode: HTTP GET / on the EVM listener for an EVM-only node whose
// listener is enabled, TCP on the P2P port for a seed or an EVM-only node with
// its listener off (nothing else is bound), HTTP GET /status on the RPC port
// for every mode that serves RPC. The readiness probe and the sidecar's
// restart-seid/stop-seid up-checks derive their port and path from it. The
// kubelet dials the pod IP and the sidecar dials loopback, so agreement also
// rests on seid binding 0.0.0.0, the shipped default.
func UpCheckForNode(node *seiv1alpha1.SeiNode) wire.UpCheck {
	if engine := node.Spec.EffectiveExecutionEngine(); engine.IsEvmOnly() && engine.EvmHTTPEnabled() {
		return wire.UpCheck{Scheme: wire.UpCheckHTTP, Port: seiconfig.PortEVMHTTP, Path: pathRoot}
	}
	if !servesSeidRPC(node) {
		return wire.UpCheck{Scheme: wire.UpCheckTCP, Port: seiconfig.PortP2P}
	}
	return wire.UpCheck{Scheme: wire.UpCheckHTTP, Port: seiconfig.PortRPC, Path: pathStatus}
}

// CometBFT RPC paths the readiness probe and up-check read.
const (
	pathStatus    = "/status"
	pathLagStatus = "/lag_status"
	// pathRoot is the EVM-only listener's bare GET, which answers 200 once the
	// JSON-RPC server is up; that mode serves no CometBFT RPC.
	pathRoot = "/"
)

// httpReadinessProbe reports a node as ready when seid answers path with a 2xx.
func httpReadinessProbe(path string, port int32) *corev1.Probe {
	return &corev1.Probe{
		ProbeHandler: corev1.ProbeHandler{
			HTTPGet: &corev1.HTTPGetAction{
				Path: path,
				Port: intstr.FromInt32(port),
			},
		},
		InitialDelaySeconds: 30,
		PeriodSeconds:       10,
		FailureThreshold:    3,
		TimeoutSeconds:      5,
	}
}

// tcpReadinessProbe reports a listener as ready once it accepts a connection.
// Timings match the HTTP readiness probe so a mode switch does not change how
// quickly the kubelet reacts.
func tcpReadinessProbe(port int32) *corev1.Probe {
	return &corev1.Probe{
		ProbeHandler: corev1.ProbeHandler{
			TCPSocket: &corev1.TCPSocketAction{
				Port: intstr.FromInt32(port),
			},
		},
		InitialDelaySeconds: 30,
		PeriodSeconds:       10,
		FailureThreshold:    3,
		TimeoutSeconds:      5,
	}
}

// defaultCosmosExporterResources: no CPU limit — cosmos-exporter calls
// seid's gRPC on every scrape; throttling turns into visible scrape gaps.
func defaultCosmosExporterResources() corev1.ResourceRequirements {
	return corev1.ResourceRequirements{
		Requests: corev1.ResourceList{
			corev1.ResourceCPU:    resource.MustParse("50m"),
			corev1.ResourceMemory: resource.MustParse("64Mi"),
		},
		Limits: corev1.ResourceList{
			corev1.ResourceMemory: resource.MustParse("384Mi"),
		},
	}
}

// cosmosExporterWaitCommand renders bash that waits for seid's gRPC port,
// then exec's cosmos-exporter. Container.Command overrides ENTRYPOINT, so
// the binary path is spelled out.
func cosmosExporterWaitCommand() (command []string, args []string) {
	exporter := "/usr/local/bin/sei-cosmos-exporter"
	exporterArgs := []string{
		"--denom", "usei",
		"--denom-coefficient", "1000000",
		"--bech-prefix", "sei",
		"--listen-address", fmt.Sprintf(":%d", defaultCosmosExporterPort),
	}

	var b strings.Builder
	b.WriteString(exporter)
	for _, a := range exporterArgs {
		fmt.Fprintf(&b, " %q", a)
	}

	script := fmt.Sprintf(
		`echo "waiting for gRPC :%d to be available..."; `+
			`until (exec 3<>/dev/tcp/localhost/%d) 2>/dev/null; do `+
			`sleep 5; done; `+
			`echo "gRPC available, starting cosmos-exporter"; `+
			`exec %s`,
		seiconfig.PortGRPC, seiconfig.PortGRPC, b.String(),
	)

	return []string{shellBash, "-c"}, []string{script}
}

// buildCosmosExporterContainer renders the cosmos-exporter sidecar.
func buildCosmosExporterContainer(p PlatformConfig) (corev1.Container, error) {
	if p.CosmosExporterImage == "" {
		return corev1.Container{}, fmt.Errorf("images.cosmosExporter is required in the app-config file")
	}
	command, args := cosmosExporterWaitCommand()
	return corev1.Container{
		Name:    containerNameCosmosExporter,
		Image:   p.CosmosExporterImage,
		Command: command,
		Args:    args,
		Ports: []corev1.ContainerPort{
			{Name: "cosmos-metrics", ContainerPort: defaultCosmosExporterPort, Protocol: corev1.ProtocolTCP},
		},
		SecurityContext: sidecarSecurityContext(),
		Resources:       defaultCosmosExporterResources(),
		// /tmp: ReadOnlyRootFilesystem EROFS insurance.
		VolumeMounts: []corev1.VolumeMount{
			{Name: sidecarTmpVolumeName, MountPath: sidecarTmpMountPath},
		},
		// Generous failureThreshold so Prometheus targets don't flap while
		// the wait loop holds :9300 off during cold start.
		ReadinessProbe: &corev1.Probe{
			ProbeHandler: corev1.ProbeHandler{
				TCPSocket: &corev1.TCPSocketAction{
					Port: intstr.FromInt32(defaultCosmosExporterPort),
				},
			},
			PeriodSeconds:    10,
			FailureThreshold: 6,
		},
		// InitialDelaySeconds: 600 gives the wait loop room before kubelet probes.
		LivenessProbe: &corev1.Probe{
			ProbeHandler: corev1.ProbeHandler{
				TCPSocket: &corev1.TCPSocketAction{
					Port: intstr.FromInt32(defaultCosmosExporterPort),
				},
			},
			InitialDelaySeconds: 600,
			PeriodSeconds:       10,
			FailureThreshold:    3,
		},
	}, nil
}

func sidecarWaitCommand(node *seiv1alpha1.SeiNode) (command []string, args []string) {
	// Canonical seid invocation with an explicit --home <dataDir>. HOME is the
	// parent of dataDir, so a bare seid would also resolve here; --home is kept
	// explicit so the server's home is unambiguous regardless of $HOME.
	cmd := "seid"
	cmdArgs := []string{seidStartSubcommand, seidHomeFlag, dataDir}

	var b strings.Builder
	b.WriteString(cmd)
	for _, a := range cmdArgs {
		fmt.Fprintf(&b, " %q", a)
	}

	script := fmt.Sprintf(
		`echo "waiting for sidecar to become ready..."; `+
			`while true; do `+
			`if (exec 3<>/dev/tcp/localhost/%d && printf "GET /v0/healthz HTTP/1.0\r\nHost: localhost\r\n\r\n" >&3 && head -1 <&3 | grep -q "200") 2>/dev/null; then `+
			`break; `+
			`fi; `+
			`sleep 5; done; `+
			`echo "sidecar ready, starting seid"; `+
			`exec %s`,
		SidecarPort(node), b.String(),
	)

	return []string{shellBash, "-c"}, []string{script}
}

func buildNodeMainContainer(node *seiv1alpha1.SeiNode) corev1.Container {
	signingMounts := signingKeyMounts(node)
	nodeMounts := nodeKeyMounts(node)
	configMounts := nodeConfigMounts(node)
	seidMountEnabled := operatorKeyringSeidMountEnabled(node)
	mounts := make([]corev1.VolumeMount, 0, 3+len(signingMounts)+len(nodeMounts)+len(configMounts))
	mounts = append(mounts, corev1.VolumeMount{Name: "data", MountPath: dataDir})
	mounts = append(mounts, corev1.VolumeMount{Name: homeVolumeName, MountPath: homeMountPath})
	mounts = append(mounts, signingMounts...)
	mounts = append(mounts, nodeMounts...)
	mounts = append(mounts, configMounts...)
	if seidMountEnabled {
		mounts = append(mounts, operatorKeyringMounts(node)...)
	}

	// HOME is homeMountPath (the emptyDir parent of dataDir); TMPDIR is the data
	// dir's tmp. seid start is invoked with an explicit --home <dataDir> (see
	// sidecarWaitCommand); HOME=homeMountPath additionally makes a bare
	// `seid keys list`/`seid tx sign` resolve $HOME/.sei onto the data dir.
	env := []corev1.EnvVar{
		{Name: homeEnvVar, Value: homeMountPath},
		{Name: "TMPDIR", Value: dataDir + "/tmp"},
	}
	if seidMountEnabled {
		// operator.secret.SeidMount: deliberate opt-in, see
		// operatorKeyringSeidMountEnabled and assertOperatorKeyringContainment.
		env = append(env, operatorKeyringEnvVars(node)...)
	}

	container := corev1.Container{
		Name:            containerNameSeid,
		Image:           node.Spec.Image,
		SecurityContext: seidNonRootSecurityContext(),
		Env:             env,
		// Explicit --home <dataDir>; overridden at the call site by
		// sidecarWaitCommand, kept here for a coherent standalone container.
		Command:      []string{"seid"},
		Args:         []string{seidStartSubcommand, seidHomeFlag, dataDir},
		VolumeMounts: mounts,
		Ports:        ContainerPorts(),
		StartupProbe: &corev1.Probe{
			ProbeHandler: corev1.ProbeHandler{
				TCPSocket: &corev1.TCPSocketAction{
					Port: intstr.FromInt32(seiconfig.PortRPC),
				},
			},
			InitialDelaySeconds: 10,
			PeriodSeconds:       10,
			FailureThreshold:    30,
		},
	}

	if NeedsLongStartup(node) {
		container.StartupProbe.FailureThreshold = 1800
	}

	return container
}

// buildSeidInitContainer materializes <dataDir>/config on first boot via
// `seid init` and ensures <dataDir>/tmp exists. Paths are the literal data
// dir so the guard and init target the seid home explicitly (HOME is the
// parent emptyDir; --home makes it unambiguous). For validator nodes it also
// writes keyring-backend into <dataDir>/config/client.toml on EVERY boot
// (outside the init skip-guard) so a bare `seid keys list`/`seid tx sign`
// resolves the right backend — and so already-provisioned PVCs get the write
// too. See clientTomlKeyringBackendWrite.
func buildSeidInitContainer(node *seiv1alpha1.SeiNode) corev1.Container {
	script := fmt.Sprintf(
		`if [ -f "%s/config/genesis.json" ]; then echo "data directory already initialized, skipping seid init"; else seid init %s --chain-id %s --home "%s" --overwrite; fi && mkdir -p "%s/tmp"`,
		dataDir, node.Spec.ChainID, node.Spec.ChainID, dataDir, dataDir,
	)
	if node.Spec.Validator != nil {
		script += " && " + clientTomlKeyringBackendWrite(dataDir, validatorKeyringBackend(node))
	}
	return corev1.Container{
		Name:  "seid-init",
		Image: node.Spec.Image,
		Command: []string{
			"/bin/sh", "-c", script,
		},
		Env: []corev1.EnvVar{
			{Name: homeEnvVar, Value: homeMountPath},
		},
		VolumeMounts: []corev1.VolumeMount{
			{Name: "data", MountPath: dataDir},
			{Name: homeVolumeName, MountPath: homeMountPath},
		},
		SecurityContext: seidNonRootSecurityContext(),
	}
}

// validatorKeyringBackend returns the client.toml keyring-backend value for a
// validator node: "file" when an operator keyring .secret is configured (the
// encrypted file keyring the sidecar mounts), "test" otherwise (the
// unencrypted keyring generate-gentx writes onto the data PVC). Mirrors the
// SEI_KEYRING_BACKEND decision in operatorKeyringEnvVars. Caller guards for
// node.Spec.Validator != nil.
func validatorKeyringBackend(node *seiv1alpha1.SeiNode) string {
	if operatorKeyringSecretSource(node) != nil {
		return keyringBackendFile
	}
	return keyringBackendTest
}

// clientTomlKeyringBackendWrite renders a POSIX-sh snippet (no bashisms; the
// init container runs /bin/sh) that idempotently sets keyring-backend in
// <dir>/config/client.toml to backend. It anchored-replaces an existing
// `keyring-backend = ...` line and appends one (creating the file) if absent,
// touching no other field or comment.
//
// A pure sed/echo write is used rather than `seid config keyring-backend`
// because that subcommand (a) round-trips the whole file through a Go template,
// dropping comments and any non-standard field rather than doing a field-
// targeted edit, and (b) runs through seid's root PersistentPreRunE, which
// calls config.ReadFromClientConfig -> NewKeyringFromBackend on the file's
// current (possibly "os") backend — a step with no distroless analogue that can
// fail the command before the set ever runs. Plain text edit is boot-safe.
//
// In practice client.toml always exists here: seid's PersistentPreRunE creates
// it (with the "os" default) on the preceding `seid init`, and on an
// already-provisioned PVC it was created on the original init — which is why
// this write runs on every boot to correct the stale backend.
func clientTomlKeyringBackendWrite(dir, backend string) string {
	clientToml := dir + "/config/client.toml"
	line := fmt.Sprintf(`keyring-backend = %q`, backend)
	return fmt.Sprintf(
		`CLIENT_TOML=%q && if [ -f "$CLIENT_TOML" ] && grep -q '^keyring-backend[[:space:]]*=' "$CLIENT_TOML"; then `+
			`sed -i 's#^keyring-backend[[:space:]]*=.*#%s#' "$CLIENT_TOML"; else `+
			`mkdir -p %q && echo '%s' >> "$CLIENT_TOML"; fi`,
		clientToml, line, dir+"/config", line,
	)
}

// seidNonRootSecurityContext is shared by seid main and seid-init (same
// binary, same mount, same privilege floor). PSA `restricted`-eligible.
// ReadOnlyRootFilesystem omitted: seid's Go runtime may use /tmp on the
// rootfs and no emptyDir is wired for it on seid containers.
func seidNonRootSecurityContext() *corev1.SecurityContext {
	return &corev1.SecurityContext{
		RunAsNonRoot:             ptr.To(true),              //nolint:modernize // ptr.To(true) is idiomatic; new(true) is invalid Go
		RunAsUser:                ptr.To(sidecarNonRootUID), //nolint:modernize // ptr.To(65532) is idiomatic; new(int64) would zero
		RunAsGroup:               ptr.To(sidecarNonRootUID), //nolint:modernize // ptr.To(65532) is idiomatic; new(int64) would zero
		AllowPrivilegeEscalation: ptr.To(false),             //nolint:modernize // ptr.To(false) is idiomatic; new(false) is invalid Go
		Capabilities:             &corev1.Capabilities{Drop: []corev1.Capability{"ALL"}},
		SeccompProfile:           &corev1.SeccompProfile{Type: corev1.SeccompProfileTypeRuntimeDefault},
	}
}

// signingKeyVolumes is called only from the production StatefulSet pod-spec.
func signingKeyVolumes(node *seiv1alpha1.SeiNode) []corev1.Volume {
	src := signingKeySecretSource(node)
	if src == nil {
		return nil
	}
	return []corev1.Volume{{
		Name: signingKeyVolumeName,
		VolumeSource: corev1.VolumeSource{
			Secret: &corev1.SecretVolumeSource{
				SecretName:  src.SecretName,
				DefaultMode: ptr.To[int32](0o400),
				Items: []corev1.KeyToPath{
					{Key: privValidatorKeyDataKey, Path: privValidatorKeyDataKey},
				},
			},
		},
	}}
}

// signingKeyMounts uses subPath deliberately: kubelet does not auto-refresh
// subPath mounts, so a Secret edit cannot hot-swap the consensus key under
// a running seid — which would risk signing two different blocks at the
// same height. Rotating the key requires a deliberate pod restart paired
// with on-chain MsgEditValidator.
func signingKeyMounts(node *seiv1alpha1.SeiNode) []corev1.VolumeMount {
	if signingKeySecretSource(node) == nil {
		return nil
	}
	return []corev1.VolumeMount{{
		Name:      signingKeyVolumeName,
		MountPath: dataDir + "/config/" + privValidatorKeyDataKey,
		SubPath:   privValidatorKeyDataKey,
		ReadOnly:  true,
	}}
}

func signingKeySecretSource(node *seiv1alpha1.SeiNode) *seiv1alpha1.SecretSigningKeySource {
	if node.Spec.Validator == nil || node.Spec.Validator.SigningKey == nil {
		return nil
	}
	return node.Spec.Validator.SigningKey.Secret
}

// nodeKeyVolumes mounts the node-key Secret on the production pod only.
func nodeKeyVolumes(node *seiv1alpha1.SeiNode) []corev1.Volume {
	src := nodeKeySecretSource(node)
	if src == nil {
		return nil
	}
	return []corev1.Volume{{
		Name: nodeKeyVolumeName,
		VolumeSource: corev1.VolumeSource{
			Secret: &corev1.SecretVolumeSource{
				SecretName:  src.SecretName,
				DefaultMode: ptr.To[int32](0o400),
				Items: []corev1.KeyToPath{
					{Key: nodeKeyDataKey, Path: nodeKeyDataKey},
				},
			},
		},
	}}
}

// nodeKeyMounts uses subPath for symmetry with signingKeyMounts. Kubelet
// pins subPath mounts at pod start, so a Secret edit cannot hot-swap the
// node ID under a running seid — which would force a peer-graph reset.
func nodeKeyMounts(node *seiv1alpha1.SeiNode) []corev1.VolumeMount {
	if nodeKeySecretSource(node) == nil {
		return nil
	}
	return []corev1.VolumeMount{{
		Name:      nodeKeyVolumeName,
		MountPath: dataDir + "/config/" + nodeKeyDataKey,
		SubPath:   nodeKeyDataKey,
		ReadOnly:  true,
	}}
}

// ConfigTomlKey and AppTomlKey are the ConfigMap keys a spec.nodeConfig
// reference must carry. They are the mount contract, so anything that checks a
// referenced ConfigMap reads them from here rather than restating them.
const (
	ConfigTomlKey = "config.toml"
	AppTomlKey    = "app.toml"
)

// nodeConfigVolumes projects the operator's seid config files, one volume per
// file so the two references may name different ConfigMaps. Items names the
// single key, so a ConfigMap missing it fails the kubelet mount and
// `kubectl describe pod` says which key is absent.
func nodeConfigVolumes(node *seiv1alpha1.SeiNode) []corev1.Volume {
	cfg := node.Spec.NodeConfig
	if cfg == nil {
		return nil
	}
	return []corev1.Volume{
		nodeConfigVolume(nodeConfigConfigVolumeName, cfg.ConfigRef.Name, configTomlDataKey),
		nodeConfigVolume(nodeConfigAppVolumeName, cfg.AppRef.Name, appTomlDataKey),
	}
}

func nodeConfigVolume(volumeName, configMapName, dataKey string) corev1.Volume {
	return corev1.Volume{
		Name: volumeName,
		VolumeSource: corev1.VolumeSource{
			ConfigMap: &corev1.ConfigMapVolumeSource{
				LocalObjectReference: corev1.LocalObjectReference{Name: configMapName},
				DefaultMode:          ptr.To[int32](0o444),
				Items:                []corev1.KeyToPath{{Key: dataKey, Path: dataKey}},
			},
		},
	}
}

// nodeConfigMounts places the operator's files over the data volume's copies.
// subPath matches signingKeyMounts and nodeKeyMounts: kubelet pins the content
// at pod start, and seid re-reads config.toml only on a restart, so a
// hot-refreshing directory mount would buy nothing.
//
// Both the seid container and the sidecar carry these mounts, and the
// sidecar's is a safety property rather than a convenience. A rename onto a
// mounted path from a container that does NOT hold the mount succeeds and
// detaches it, after which seid reads the writer's file with nothing reporting
// the swap. From a container that DOES hold the mount the same rename returns
// EBUSY and fails the task.
// TestNodeConfigMountsOnSidecarIsASafetyProperty guards the sidecar mount.
func nodeConfigMounts(node *seiv1alpha1.SeiNode) []corev1.VolumeMount {
	if node.Spec.NodeConfig == nil {
		return nil
	}
	return []corev1.VolumeMount{
		nodeConfigMount(nodeConfigConfigVolumeName, configTomlDataKey),
		nodeConfigMount(nodeConfigAppVolumeName, appTomlDataKey),
	}
}

func nodeConfigMount(volumeName, dataKey string) corev1.VolumeMount {
	return corev1.VolumeMount{
		Name:      volumeName,
		MountPath: dataDir + "/config/" + dataKey,
		SubPath:   dataKey,
		ReadOnly:  true,
	}
}

// nodeKeySecretSource returns the Secret holding this node's P2P identity, from
// whichever mode sub-spec carries one (validator or seed). Mode-blind by
// delegation, so the node-key volume and mount below serve both.
func nodeKeySecretSource(node *seiv1alpha1.SeiNode) *seiv1alpha1.SecretNodeKeySource {
	return node.Spec.NodeKeySecret()
}

// operatorKeyringVolumes projects the operator-keyring Secret as a directory
// under $SEI_HOME/keyring-file/ — the Cosmos SDK file-backend layout.
// Mounted on the sidecar container. The seid main container is excluded
// unless the node has opted in via .secret.SeidMount — see operatorKeyringSeidMountEnabled.
func operatorKeyringVolumes(node *seiv1alpha1.SeiNode) []corev1.Volume {
	src := operatorKeyringSecretSource(node)
	if src == nil {
		return nil
	}
	return []corev1.Volume{{
		Name: operatorKeyringVolumeName,
		VolumeSource: corev1.VolumeSource{
			Secret: &corev1.SecretVolumeSource{
				SecretName:  src.SecretName,
				DefaultMode: ptr.To[int32](0o400),
			},
		},
	}}
}

func operatorKeyringMounts(node *seiv1alpha1.SeiNode) []corev1.VolumeMount {
	if operatorKeyringSecretSource(node) == nil {
		return nil
	}
	return []corev1.VolumeMount{{
		Name:      operatorKeyringVolumeName,
		MountPath: dataDir + "/" + operatorKeyringDirName,
		ReadOnly:  true,
	}}
}

// operatorKeyringEnvVars configures the keyring for whichever container
// carries it — the sidecar always, and the seid main container too when
// .secret.SeidMount is set. Branches:
//
//   - Non-validator: no env vars.
//   - Validator with .secret: file backend; passphrase from the referenced
//     Secret; keyring projected at $SEI_HOME/keyring-file/ by
//     operatorKeyringVolumes.
//   - Validator without .secret: test backend on the data PVC at
//     $SEI_HOME/keyring-test/ — where generate-gentx writes the validator
//     key during a genesis ceremony. Unencrypted.
//
// SEI_KEYRING_DIR is $SEI_HOME on both validator branches; the SDK appends
// "keyring-<backend>" itself.
//
// The passphrase lives in its own Secret because the keyring data Secret is
// projected as a directory — embedding the passphrase would land it inside
// that directory, and the file backend would read it as keyring contents.
func operatorKeyringEnvVars(node *seiv1alpha1.SeiNode) []corev1.EnvVar {
	if node.Spec.Validator == nil {
		return nil
	}
	src := operatorKeyringSecretSource(node)
	if src == nil {
		return []corev1.EnvVar{
			{Name: keyringBackendEnvVar, Value: keyringBackendTest},
			{Name: keyringDirEnvVar, Value: dataDir},
		}
	}
	return []corev1.EnvVar{
		{Name: keyringBackendEnvVar, Value: keyringBackendFile},
		{Name: keyringDirEnvVar, Value: dataDir},
		{
			Name: keyringPassphraseEnvVar,
			ValueFrom: &corev1.EnvVarSource{
				SecretKeyRef: &corev1.SecretKeySelector{
					LocalObjectReference: corev1.LocalObjectReference{Name: src.PassphraseSecretRef.SecretName},
					Key:                  src.PassphraseSecretRef.Key,
				},
			},
		},
	}
}

func operatorKeyringSecretSource(node *seiv1alpha1.SeiNode) *seiv1alpha1.SecretOperatorKeyringSource {
	if node.Spec.Validator == nil || node.Spec.Validator.OperatorKeyring == nil {
		return nil
	}
	return node.Spec.Validator.OperatorKeyring.Secret
}

// operatorKeyringSeidMountEnabled reports whether the node has explicitly opted
// into mounting the operator keyring (and its passphrase) onto the seid main
// container. Only reachable via the .secret path — the test-backend keyring
// already lives on the data PVC that seid mounts, so there is nothing to
// additionally expose there.
func operatorKeyringSeidMountEnabled(node *seiv1alpha1.SeiNode) bool {
	src := operatorKeyringSecretSource(node)
	return src != nil && src.SeidMount
}

// sidecarSecurityContext locks the sidecar to non-root, read-only rootfs,
// no privilege escalation, all caps dropped, and the runtime's default
// seccomp profile. Scope is deliberately the sidecar only — applying the
// same to the seid main container is a larger blast-radius change owned
// by a different workstream.
func sidecarSecurityContext() *corev1.SecurityContext {
	return &corev1.SecurityContext{
		RunAsNonRoot:             ptr.To(true),              //nolint:modernize // ptr.To(true) is idiomatic; new(true) is invalid Go
		RunAsUser:                ptr.To(sidecarNonRootUID), //nolint:modernize // false-positive: new() takes a type, not a value
		RunAsGroup:               ptr.To(sidecarNonRootUID), //nolint:modernize // false-positive: new() takes a type, not a value
		AllowPrivilegeEscalation: ptr.To(false),             //nolint:modernize // ptr.To(false) is idiomatic; new(false) is invalid Go
		ReadOnlyRootFilesystem:   ptr.To(true),              //nolint:modernize // ptr.To(true) is idiomatic; new(true) is invalid Go
		Capabilities:             &corev1.Capabilities{Drop: []corev1.Capability{"ALL"}},
		SeccompProfile:           &corev1.SeccompProfile{Type: corev1.SeccompProfileTypeRuntimeDefault},
	}
}

// RBACProxyConfigMapName returns the name of the ConfigMap carrying the
// kube-rbac-proxy authorization config for a given SeiNode.
func RBACProxyConfigMapName(node *seiv1alpha1.SeiNode) string {
	return node.Name + "-rbac-proxy-config"
}

// buildRBACProxyContainer fronts the loopback-bound sidecar with
// kube-rbac-proxy on plaintext :8443. The proxy performs TokenReview +
// SubjectAccessReview against the K8s API and forwards passing requests
// upstream; the private cluster network provides confidentiality.
//
// --ignore-paths bypasses authn AND authz for healthz/metrics so
// kubelet probes don't need a bearer token.
func buildRBACProxyContainer(node *seiv1alpha1.SeiNode, p PlatformConfig) corev1.Container {
	return corev1.Container{
		Name:          containerNameRBACProxy,
		Image:         p.KubeRBACProxyImage,
		RestartPolicy: ptr.To(corev1.ContainerRestartPolicyAlways),
		Args: []string{
			fmt.Sprintf("--insecure-listen-address=0.0.0.0:%d", RBACProxyPort),
			fmt.Sprintf("--upstream=http://127.0.0.1:%d/", SidecarPort(node)),
			"--config-file=" + rbacProxyConfigMountPath + "/config.yaml",
			"--ignore-paths=" + strings.Join(bypassPaths(), ","),
			"--auth-header-fields-enabled=true",
			"--v=0",
		},
		Ports: []corev1.ContainerPort{
			{Name: servicePortNameAPI, ContainerPort: RBACProxyPort, Protocol: corev1.ProtocolTCP},
		},
		VolumeMounts: []corev1.VolumeMount{
			{Name: rbacProxyConfigVolumeName, MountPath: rbacProxyConfigMountPath, ReadOnly: true},
		},
		StartupProbe:    proxyStartupProbe(),
		LivenessProbe:   proxyLivenessProbe(),
		ReadinessProbe:  proxyReadinessProbe(),
		SecurityContext: sidecarSecurityContext(),
	}
}

// bypassPaths are skipped by kube-rbac-proxy authn AND authz. Must
// match the sidecar's middleware bypass list (sidecar/server/auth.go).
// SECURITY: only public health/metrics paths — never state, keyring,
// or operator actions.
func bypassPaths() []string {
	return []string{pathHealthz, pathStartupz, pathLivez, pathMetrics}
}

func proxyStartupProbe() *corev1.Probe {
	return &corev1.Probe{
		ProbeHandler: corev1.ProbeHandler{
			TCPSocket: &corev1.TCPSocketAction{Port: intstr.FromInt32(RBACProxyPort)},
		},
		InitialDelaySeconds: 5,
		PeriodSeconds:       5,
		FailureThreshold:    60,
	}
}

func proxyLivenessProbe() *corev1.Probe {
	return &corev1.Probe{
		ProbeHandler: corev1.ProbeHandler{HTTPGet: &corev1.HTTPGetAction{
			Path: pathLivez,
			Port: intstr.FromInt32(RBACProxyPort),
		}},
		InitialDelaySeconds: 5,
		PeriodSeconds:       10,
		FailureThreshold:    3,
	}
}

// proxyReadinessProbe gates pod readiness on the sidecar via the
// proxy: --ignore-paths skips authn, but the proxy still forwards
// upstream, so a wedged sidecar surfaces as 5xx here.
func proxyReadinessProbe() *corev1.Probe {
	return &corev1.Probe{
		ProbeHandler: corev1.ProbeHandler{HTTPGet: &corev1.HTTPGetAction{
			Path: pathHealthz,
			Port: intstr.FromInt32(RBACProxyPort),
		}},
		InitialDelaySeconds: 2,
		PeriodSeconds:       5,
		FailureThreshold:    6,
	}
}

// GenerateRBACProxyConfigMap produces the ConfigMap carrying the
// kube-rbac-proxy authorization config — a single coarse SAR scoped
// to (apiGroup=sei.io, resource=seinodetasks, namespace=<ns>, name=<node>).
// Verb is derived from HTTP method by the proxy. The field name is
// `apiGroup`, matching kube-rbac-proxy's authz.ResourceAttributes
// struct (pkg/authz/auth.go).
//
// `name` scopes the SAR to the specific SeiNode so operators can bind
// ClusterRoles with resourceNames to narrow access per-validator;
// empty resourceNames still matches.
func GenerateRBACProxyConfigMap(node *seiv1alpha1.SeiNode) *corev1.ConfigMap {
	config := strings.Join([]string{
		"authorization:",
		"  resourceAttributes:",
		"    apiGroup: sei.io",
		"    resource: seinodetasks",
		"    namespace: " + node.Namespace,
		"    name: " + node.Name,
		"",
	}, "\n")
	return &corev1.ConfigMap{
		ObjectMeta: metav1.ObjectMeta{
			Name:      RBACProxyConfigMapName(node),
			Namespace: node.Namespace,
			Labels:    ResourceLabels(node),
		},
		Data: map[string]string{"config.yaml": config},
	}
}

// SidecarURLForNode returns the in-cluster URL for a node's sidecar.
// All traffic flows through kube-rbac-proxy on plaintext :8443; the
// SAR authz check is the trust boundary, the private cluster network
// provides confidentiality.
func SidecarURLForNode(node *seiv1alpha1.SeiNode) string {
	return fmt.Sprintf("http://%s-0.%s.%s.svc.cluster.local:%d",
		node.Name, node.Name, node.Namespace, RBACProxyPort)
}
