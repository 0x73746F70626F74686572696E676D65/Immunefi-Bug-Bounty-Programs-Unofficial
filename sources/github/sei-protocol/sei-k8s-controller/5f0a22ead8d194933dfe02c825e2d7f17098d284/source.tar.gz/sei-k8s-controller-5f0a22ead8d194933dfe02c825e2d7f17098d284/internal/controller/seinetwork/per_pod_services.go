package seinetwork

import (
	"cmp"
	"slices"
	"strconv"

	"github.com/go-logr/logr"
	seiconfig "github.com/sei-protocol/sei-config"

	seiv1alpha1 "github.com/sei-protocol/sei-k8s-controller/api/v1alpha1"
)

// populatePerPodServices builds the PerPodServices status from child SeiNodes,
// sorted by ordinal. Returns nil when empty so omitempty drops the field.
// This is pure status derivation from the child node set — it does not manage
// any per-pod networking resources (those are GitOps-owned since PLT-451).
func populatePerPodServices(log logr.Logger, nodes []seiv1alpha1.SeiNode) []seiv1alpha1.PerPodServiceStatus {
	type entry struct {
		status  seiv1alpha1.PerPodServiceStatus
		ordinal int
	}
	entries := make([]entry, 0, len(nodes))
	for i := range nodes {
		node := &nodes[i]
		ordStr, ok := node.Labels[seinetworkOrdinalLabel]
		if !ok {
			log.V(1).Info("per-pod service: skipping node missing ordinal label", "node", node.Name)
			continue
		}
		ord, err := strconv.Atoi(ordStr)
		if err != nil {
			log.V(1).Info("per-pod service: skipping node with unparseable ordinal label",
				"node", node.Name, "label", ordStr)
			continue
		}
		entries = append(entries, entry{
			status: seiv1alpha1.PerPodServiceStatus{
				Name:      node.Name,
				Namespace: node.Namespace,
				Ports: seiv1alpha1.PerPodServicePorts{
					EvmHttp: seiconfig.PortEVMHTTP,
					EvmWs:   seiconfig.PortEVMWS,
				},
			},
			ordinal: ord,
		})
	}
	if len(entries) == 0 {
		return nil
	}
	slices.SortFunc(entries, func(a, b entry) int { return cmp.Compare(a.ordinal, b.ordinal) })
	out := make([]seiv1alpha1.PerPodServiceStatus, len(entries))
	for i := range entries {
		out[i] = entries[i].status
	}
	return out
}
