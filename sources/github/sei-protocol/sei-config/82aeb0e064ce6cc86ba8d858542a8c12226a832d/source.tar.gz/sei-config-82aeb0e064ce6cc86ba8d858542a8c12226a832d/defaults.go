package seiconfig

import (
	"os"
	"strconv"
	"time"
)

// p2pListenAddrAllInterfaces is the P2P listen address for every mode that
// accepts inbound peer connections. baseDefaults binds loopback instead, so a
// mode that omits this override is reachable by nobody — and fails silently,
// since the node still boots clean.
const p2pListenAddrAllInterfaces = "tcp://0.0.0.0:26656"

// Default returns a SeiConfig populated with baseline defaults (mode=full).
// Use DefaultForMode to get defaults tailored to a specific node mode.
func Default() *SeiConfig {
	return DefaultForMode(ModeFull)
}

// DefaultForMode returns a SeiConfig with defaults appropriate for the given mode.
func DefaultForMode(mode NodeMode) *SeiConfig {
	cfg := baseDefaults()
	cfg.Mode = mode
	applyModeOverrides(cfg, mode)
	return cfg
}

// baseDefaults returns the shared baseline configuration before mode overrides.
func baseDefaults() *SeiConfig {
	return &SeiConfig{
		Version: CurrentVersion,
		Mode:    ModeFull,

		Chain: ChainConfig{
			Moniker:            defaultMoniker(),
			ProxyApp:           "tcp://127.0.0.1:26658",
			ABCI:               "socket",
			MinGasPrices:       "0.01usei",
			InterBlockCache:    true,
			ConcurrencyWorkers: defaultConcurrencyWorkers(),
			OccEnabled:         true,
		},

		Network: NetworkConfig{
			RPC: RPCConfig{
				ListenAddress:             "tcp://127.0.0.1:26657",
				CORSOrigins:               []string{},
				CORSMethods:               []string{"HEAD", "GET", "POST"},
				CORSHeaders:               []string{"Origin", "Accept", "Content-Type", "X-Requested-With", "X-Server-Time"},
				Unsafe:                    false,
				MaxOpenConnections:        900,
				MaxSubscriptionClients:    100,
				MaxSubscriptionsPerClient: 5,
				EventLogWindowSize:        Dur(30 * time.Second),
				TimeoutBroadcastTxCommit:  Dur(10 * time.Second),
				MaxBodyBytes:              1_000_000,
				MaxHeaderBytes:            1 << 20,
				LagThreshold:              300,
				TimeoutRead:               Dur(10 * time.Second),
			},
			P2P: P2PConfig{
				ListenAddress:                 "tcp://127.0.0.1:26656",
				MaxConnections:                100,
				MaxIncomingConnectionAttempts: 100,
				FlushThrottleTimeout:          Dur(100 * time.Millisecond),
				MaxPacketMsgPayloadSize:       1_000_000,
				SendRate:                      20_971_520,
				RecvRate:                      20_971_520,
				PexReactor:                    true,
				HandshakeTimeout:              Dur(10 * time.Second),
				DialTimeout:                   Dur(3 * time.Second),
				DialInterval:                  Dur(10 * time.Second),
				AcceptInterval:                Dur(10 * time.Millisecond),
				QueueType:                     "simple-priority",
			},
		},

		Consensus: ConsensusConfig{
			WALPath:                     "data/cs.wal/wal",
			CreateEmptyBlocks:           true,
			GossipTransactionKeyOnly:    true,
			PeerGossipSleepDuration:     Dur(100 * time.Millisecond),
			PeerQueryMaj23SleepDuration: Dur(2000 * time.Millisecond),
		},

		Mempool: MempoolConfig{
			Broadcast:                    true,
			Size:                         5000,
			MaxTxsBytes:                  1 << 30,
			CacheSize:                    10_000,
			DuplicateTxsCacheSize:        100_000,
			MaxTxBytes:                   1 << 20,
			TTLDuration:                  Dur(5 * time.Second),
			TTLNumBlocks:                 10,
			CheckTxErrorBlacklistEnabled: true,
			CheckTxErrorThreshold:        50,
			PendingSize:                  5000,
			MaxPendingTxsBytes:           1 << 30,
			RemoveExpiredTxsFromQueue:    true,
			DropPriorityThreshold:        0.1,
			DropUtilisationThreshold:     1.0,
			DropPriorityReservoirSize:    10_240,
		},

		StateSync: StateSyncConfig{
			TrustPeriod:               Dur(168 * time.Hour),
			DiscoveryTime:             Dur(15 * time.Second),
			ChunkRequestTimeout:       Dur(15 * time.Second),
			Fetchers:                  2,
			VerifyLightBlockTimeout:   Dur(60 * time.Second),
			BlacklistTTL:              Dur(5 * time.Minute),
			LightBlockResponseTimeout: Dur(10 * time.Second),
		},

		Storage: StorageConfig{
			DBBackend:           "goleveldb",
			DBPath:              "data",
			PruningStrategy:     PruningNothing,
			PruningKeepRecent:   "0",
			PruningKeepEvery:    "0",
			PruningInterval:     "0",
			SnapshotKeepRecent:  2,
			IAVLDisableFastNode: true,
			// WriteMode/ReadMode are left unset so render omits them and each seid
			// binary applies its own native default. Their valid values differ
			// across binary versions, so no single rendered value boots every
			// target; a caller that needs a specific mode sets it explicitly.
			StateCommit: StateCommitConfig{
				Enable: true,
			},
			StateStore: StateStoreConfig{
				Enable:               true,
				Backend:              BackendPebbleDB,
				AsyncWriteBuffer:     100,
				KeepRecent:           100_000,
				PruneIntervalSeconds: 600,
				ImportNumWorkers:     1,
				KeepLastVersion:      true,
			},
			ReceiptStore: ReceiptStoreConfig{
				Backend:              BackendPebbleDB,
				AsyncWriteBuffer:     100,
				KeepRecent:           100_000,
				PruneIntervalSeconds: 600,
				TxIndexBackend:       BackendPebbleDB,
			},
		},

		TxIndex: TxIndexConfig{
			Indexer: []string{"kv"},
		},

		EVM: EVMConfig{
			HTTPEnabled:                  true,
			HTTPPort:                     int(PortEVMHTTP),
			WSEnabled:                    true,
			WSPort:                       int(PortEVMWS),
			ReadTimeout:                  Dur(30 * time.Second),
			ReadHeaderTimeout:            Dur(30 * time.Second),
			WriteTimeout:                 Dur(30 * time.Second),
			IdleTimeout:                  Dur(120 * time.Second),
			SimulationGasLimit:           10_000_000,
			SimulationEVMTimeout:         Dur(60 * time.Second),
			CORSOrigins:                  "*",
			WSOrigins:                    "*",
			FilterTimeout:                Dur(120 * time.Second),
			CheckTxTimeout:               Dur(5 * time.Second),
			MaxTxPoolTxs:                 1000,
			DenyList:                     []string{},
			EnabledLegacySeiApis:         []string{},
			MaxLogNoBlock:                10_000,
			MaxBlocksForLog:              2000,
			MaxSubscriptionsNewHead:      10_000,
			MaxConcurrentTraceCalls:      10,
			MaxConcurrentSimulationCalls: defaultEVMWorkerPoolSize(),
			MaxTraceLookbackBlocks:       10_000,
			TraceTimeout:                 Dur(30 * time.Second),
			RPCStatsInterval:             Dur(10 * time.Second),
			WorkerPoolSize:               defaultEVMWorkerPoolSize(),
			WorkerQueueSize:              1000,
			Query: EVMQueryConfig{
				GasLimit: 300_000,
			},
			Replay: EVMReplayConfig{
				EthRPC:     "http://44.234.105.54:18545",
				EthDataDir: "/root/.ethereum/chaindata",
			},
			BlockTest: EVMBlockTestConfig{
				TestDataPath: "~/testdata/",
			},
		},

		API: APIConfig{
			REST: RESTAPIConfig{
				Enable:             false,
				Swagger:            true,
				Address:            "tcp://0.0.0.0:1317",
				MaxOpenConnections: 1000,
				RPCReadTimeout:     10,
				RPCMaxBodyBytes:    1_000_000,
			},
			GRPC: GRPCConfig{
				Enable:  true,
				Address: "0.0.0.0:9090",
			},
			GRPCWeb: GRPCWebConfig{
				Enable:  true,
				Address: "0.0.0.0:9091",
			},
		},

		Metrics: MetricsConfig{
			Enabled:                 true,
			PrometheusListenAddr:    ":26660",
			MaxOpenConnections:      3,
			Namespace:               "tendermint",
			PrometheusRetentionTime: 7200,
			GlobalLabels:            [][]string{},
		},

		Logging: LogConfig{
			Level:  "info",
			Format: "plain",
		},

		WASM: WASMConfig{
			QueryGasLimit: 300_000,
			LruSize:       1,
		},

		// Mirrors seid's own DefaultConfig (giga/executor/config). Left at the Go
		// zero value this field renders enabled=false into every app.toml and
		// overrides the binary's own default; a node that must stay on the v2
		// executor pins giga_executor.enabled=false explicitly.
		GigaExecutor: GigaExecutorConfig{
			Enabled:    true,
			OccEnabled: true,
		},

		LightInvariance: LightInvarianceConfig{
			SupplyEnabled: true,
		},

		PrivValidator: PrivValidatorConfig{
			KeyFile:   "config/priv_validator_key.json",
			StateFile: "data/priv_validator_state.json",
		},

		SelfRemediation: SelfRemediationConfig{
			BlocksBehindCheckIntervalSeconds: 60,
			RestartCooldownSeconds:           600,
		},
	}
}

// applyModeOverrides mutates cfg in-place with mode-specific settings.
func applyModeOverrides(cfg *SeiConfig, mode NodeMode) {
	switch mode {
	case ModeValidator:
		applyValidatorOverrides(cfg)
	case ModeSeed:
		applySeedOverrides(cfg)
	case ModeFull:
		applyFullOverrides(cfg)
	case ModeArchive:
		applyArchiveOverrides(cfg)
	}
}

func applyValidatorOverrides(cfg *SeiConfig) {
	cfg.TxIndex.Indexer = []string{"null"}
	cfg.Network.RPC.ListenAddress = "tcp://0.0.0.0:26657"
	cfg.Network.P2P.ListenAddress = p2pListenAddrAllInterfaces
	cfg.Network.P2P.AllowDuplicateIP = false

	cfg.API.REST.Enable = false
	cfg.API.GRPCWeb.Enable = false
	cfg.Storage.StateStore.Enable = false

	cfg.EVM.HTTPEnabled = false
	cfg.EVM.WSEnabled = false
}

// applySeedOverrides configures a CometBFT seed node: P2P transport and PEX
// reactor only.
//
// RPC.ListenAddress stays at the baseDefaults loopback because seed mode starts
// no RPC listener, so 0.0.0.0 would advertise a port nothing serves. The
// asymmetry with validator/full is deliberate.
func applySeedOverrides(cfg *SeiConfig) {
	cfg.TxIndex.Indexer = []string{"null"}
	cfg.Network.P2P.ListenAddress = p2pListenAddrAllInterfaces
	cfg.Network.P2P.MaxConnections = 1000
	// Inert in sei-tendermint: declared and rendered into config.toml, never read.
	// Kept because true is the right intent for a seed, but the limit that actually
	// applies is MaxIncomingConnectionAttempts below.
	cfg.Network.P2P.AllowDuplicateIP = true
	// Caps CONCURRENT connections per source IP despite the name, and rejects
	// silently: seed mode serves no metrics, so a wrong value yields no error and no
	// counter. Tightens the inherited 100 to 32 — ~3% of the ~980 inbound to any one
	// source, against a measured fleet maximum of 8 real peers per address, forcing a
	// flood across ~31 addresses. Correct only while the load balancer preserves
	// client IPs: under SNAT the cap applies per LB address instead, collapsing the
	// ceiling to 32 x (LB addresses) and dropping legitimate peers. The accept path
	// is NodeID-blind, so this also bounds inbound persistent/unconditional peers.
	cfg.Network.P2P.MaxIncomingConnectionAttempts = 32
	// Bounds the PEX recv path only, where ReadSizedMsg allocates a peer-declared
	// size before the channel's ~26 KB RecvMessageCapacity can reject it. The
	// multiplier is maxInbound (max_connections less the outbound reserve), so at
	// the 1 MB baseline this path alone reaches roughly a gigabyte of concurrent
	// transient allocation.
	//
	// It is NOT the seed's worst case. The pre-auth handshake read is a separate,
	// larger surface with a size limit hardcoded in sei-tendermint that no config
	// key reaches, and max_connections scales both. Sizing a seed's memory means
	// accounting for that path too.
	cfg.Network.P2P.MaxPacketMsgPayloadSize = 102_400

	cfg.API.REST.Enable = false
	cfg.API.GRPC.Enable = false
	cfg.API.GRPCWeb.Enable = false
	// StateStore is safe to disable — a seed answers no queries. StateCommit is
	// not: seid builds the cosmos app before dispatching on mode, and SetupSeiDB
	// panics when SC is off, so a seed carries a memIAVL store it never advances.
	cfg.Storage.StateStore.Enable = false
	cfg.Storage.PruningStrategy = PruningEverything

	cfg.EVM.HTTPEnabled = false
	cfg.EVM.WSEnabled = false
}

func applyFullOverrides(cfg *SeiConfig) {
	cfg.TxIndex.Indexer = []string{"kv"}
	cfg.Network.RPC.ListenAddress = "tcp://0.0.0.0:26657"
	cfg.Network.P2P.ListenAddress = p2pListenAddrAllInterfaces

	cfg.Chain.ConcurrencyWorkers = 500
	cfg.Storage.PruningStrategy = PruningCustom
	cfg.Storage.PruningKeepRecent = "86400"
	cfg.Storage.PruningKeepEvery = "500"
	cfg.Storage.PruningInterval = "10"

	cfg.API.REST.Enable = true
	cfg.API.GRPC.Enable = true
	cfg.API.GRPCWeb.Enable = true
	cfg.Storage.StateStore.Enable = true
	// RPC/full nodes default to the split SS layout (EVM state in its own SS DB).
	// Scoped here, not baseDefaults: only modes that run the SS store may set it,
	// and per giga_store_migration.md the split is supported for RPC nodes only
	// (validator/seed run no SS store; archive resets it below). A fresh node
	// builds the split on bootstrap; an existing unsplit node adopts it only via a
	// state-sync, so this default touches new nodes, not a migration path.
	cfg.Storage.StateStore.EVMSSSplit = true
	cfg.Storage.StateStore.KeepRecent = 100_000
	cfg.Storage.StateCommit.AsyncCommitBuffer = 100
	cfg.Chain.MinRetainBlocks = 100_000

	cfg.EVM.HTTPEnabled = true
	cfg.EVM.WSEnabled = true
}

func applyArchiveOverrides(cfg *SeiConfig) {
	applyFullOverrides(cfg)

	cfg.Storage.PruningStrategy = PruningNothing
	cfg.Storage.StateStore.KeepRecent = 0
	// Archive inherits full's overrides but the giga SS split is not supported for
	// archive nodes yet (giga_store_migration.md: RPC nodes only), so reset it.
	cfg.Storage.StateStore.EVMSSSplit = false
	// Only MinRetainBlocks disables receipt pruning at runtime; the next two
	// are emitted to document intent (see ReceiptStoreConfig).
	cfg.Chain.MinRetainBlocks = 0
	cfg.Storage.ReceiptStore.KeepRecent = 0
	cfg.Storage.ReceiptStore.PruneIntervalSeconds = 0
	cfg.EVM.MaxTraceLookbackBlocks = -1

	cfg.Storage.StateCommit.AsyncCommitBuffer = 100
	cfg.Storage.StateCommit.MemIAVL.SnapshotKeepRecent = 1
	cfg.Storage.StateCommit.MemIAVL.SnapshotMinTimeInterval = 20000
}

// SnapshotGenerationOverrides returns overrides for full-mode nodes that
// generate CometBFT state-sync snapshots. Includes snapshot creation,
// tighter pruning than the full-node default, and elevated P2P capacity
// for serving snapshot chunks to peers.
func SnapshotGenerationOverrides(keepRecent int32) map[string]string {
	return map[string]string{
		KeySnapshotInterval:   strconv.FormatInt(DefaultSnapshotInterval, 10),
		KeySnapshotKeepRecent: strconv.FormatInt(int64(keepRecent), 10),
		KeyPruningKeepRecent:  "50000",
		KeyPruningKeepEvery:   "0",
		KeyMinRetainBlocks:    "50000",
		KeyP2PMaxConnections:  "500",
		KeyP2PSendRate:        "20971520",
		KeyP2PRecvRate:        "20971520",
	}
}

func defaultMoniker() string {
	name, err := os.Hostname()
	if err != nil {
		return "anonymous"
	}
	return name
}
