(module
  (import "\0"))

