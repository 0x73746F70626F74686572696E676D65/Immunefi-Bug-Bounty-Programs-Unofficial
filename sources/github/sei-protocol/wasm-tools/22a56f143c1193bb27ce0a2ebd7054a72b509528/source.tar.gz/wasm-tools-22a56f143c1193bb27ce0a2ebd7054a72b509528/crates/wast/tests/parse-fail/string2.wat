(module
  (import "\x"))
