(module
  (func (export "thunk"))
)
