(component
  (import "a" (instance))
)
