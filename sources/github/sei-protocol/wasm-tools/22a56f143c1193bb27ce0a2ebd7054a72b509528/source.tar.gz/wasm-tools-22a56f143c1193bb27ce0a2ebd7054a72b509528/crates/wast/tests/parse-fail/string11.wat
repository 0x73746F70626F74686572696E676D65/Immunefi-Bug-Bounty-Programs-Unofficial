"\u{fffffffffffffffff}"
