# Sei Skill

A comprehensive AI skill for the Sei Network, covering three domains: **contracts** (smart contracts and tooling), **frontend** (UI stack and Sei site awareness), and **ecosystem** (apps, integrations, participation roles).

## Overview

This skill provides AI coding assistants with deep knowledge of the Sei ecosystem across three domains:

### Contracts — smart contracts and tooling
- **EVM Contracts**: Foundry + Hardhat setup, deployment, fork testing
- **Precompiles**: All 11 Sei precompiles (Staking, Governance, Bank, Addr, Pointer, P256, etc.; Oracle and IBC are retired/closed)
- **Pointer Contracts**: Cross-VM asset bridging between EVM and Cosmos
- **Verification**: Seiscan (Sourcify) verification flows for Foundry and Hardhat
- **Performance**: Load testing, OCC-aware design, Sei-specific gas optimization
- **Account abstraction (ERC-4337)**: Pimlico, Particle, smart-account flows
- **Upgradeability**: UUPS, Transparent, Beacon, Diamond
- **Migration**: From Ethereum/other EVMs and from Solana

### Frontend — UI stack and site awareness
- **Frontend stack**: Wagmi + Viem default, Ethers.js v6 alternative, RainbowKit
- **Wallets**: Sei Global Wallet, MetaMask, Compass, Ledger; EIP-6963 detection
- **Dual-address UX**: surfacing `sei1...` ↔ `0x...` cleanly
- **sei.io / docs.sei.io map**: pointing users to the right page
- **Docs contribution**: Nextra MDX, `_meta.js`, build flow
- **Brand assets**: logos, media kit, press contacts

### Ecosystem — apps, integration, participation
- **dApps directory**: DEX, lending, perps, RWA, NFT, gaming, infra
- **DeFi integrations**: DragonSwap, Yei, Takara, Saphyre, Pyth oracles, USDC
- **Bridges**: LayerZero V2 (OFT), Wormhole, Axelar, CCTP, ThirdWeb (IBC is closed in both directions)
- **RPC endpoints**: public, community, paid SaaS providers with failover patterns
- **Oracles**: Chainlink, Pyth (+ VRF), API3, RedStone, native oracle precompile
- **Indexers**: The Graph, Goldsky, Dune Analytics, Moralis, Goldrush
- **Participation roles**: validator, RPC provider, indexer operator, oracle relayer
- **Grants**: Sei Foundation Grants, Ecosystem Fund, Creator Fund
- **AI Tooling**: Sei MCP Server, Cambrian Agent Kit, x402

## Installation

The installer supports two modes: a **directory install for Claude Code** (default) and a **flattened single-file output for all other AI agents**.

### Claude Code

`install.sh` installs the skill into Claude Code's skill directory (`~/.claude/skills/`). Running it with no arguments installs the full skill — the recommended default.

```bash
git clone https://github.com/sei-protocol/sei-skill
cd sei-skill
./install.sh
```

That installs to `~/.claude/skills/sei`. No flags needed.

**Re-running the installer merges** — new and updated files are copied in, and anything you've added to the skill directory is left untouched. Use `--force` for a clean reinstall that removes and replaces the existing directory (prompts for confirmation):

```bash
./install.sh --force
```

### Windows

| Environment | Works? | Notes |
|---|---|---|
| **Git Bash** (Git for Windows) | ✅ Yes | Recommended. GNU coreutils ship with it; paths resolve correctly to where Claude Code looks. |
| **WSL** | ⚠️ With caveat | The script runs, but the default global install lands inside the Linux filesystem where Claude Code (a native Windows app) can't find it. Use `--path` to target your Windows home directory instead. |
| **PowerShell / cmd** | ❌ No | Bash is required. Use Git Bash or WSL. |

**Git Bash** is the recommended shell for Windows. Clone and run the installer the same way as on macOS/Linux:

```bash
git clone https://github.com/sei-protocol/sei-skill
cd sei-skill
./install.sh
```

**WSL users** — pass `--path` to install into your Windows home directory so Claude Code can find the skill:

```bash
./install.sh --path "/mnt/c/Users/$USER/.claude/skills/sei"
```

Or use `--project` to install into the current project directory (as long as the project lives on the Windows filesystem under `/mnt/c/`).

### Other AI Agents

Use `--agent <name>` to install for a specific agent. The correct output path, directory structure, and any required formatting are handled automatically.

```bash
./install.sh --agent cursor      # → .cursor/rules/sei.mdc  (MDC frontmatter)
./install.sh --agent copilot     # → .github/copilot-instructions.md
./install.sh --agent windsurf    # → .windsurf/rules/sei.md
./install.sh --agent aider       # → ~/.aider/sei.md  (+ config instructions printed)
./install.sh --agent openhands   # → .openhands/SKILL.md  (YAML frontmatter)
./install.sh --agent codex       # → AGENTS.md
./install.sh --agent gemini      # → GEMINI.md
```

Agent installs always overwrite the output file — no prompt, no merge logic. Each install produces a single self-contained file, so overwriting is the only sensible behaviour. `--force` is not valid with `--agent` or `--flatten` and will error.

Use `--output` to override the default path for any agent:

```bash
./install.sh --agent codex --output ~/.codex/AGENTS.md
```

Use `--flatten` without `--agent` to generate a plain markdown file at any path:

```bash
./install.sh --flatten --output ./sei-context.md
```

> **Size limits:** Some agents cap total context size. Cursor recommends ≤500 lines for always-apply rules; Codex CLI caps at 32 KiB total. The installer warns when output exceeds known limits — use a focused `--variant` to reduce size.

### Variants

All install modes support the same four variants. Use a focused variant to reduce context size when you only need one domain.

| Variant | Scope | Best for |
|---|---|---|
| **full** (default) | All three domains | Comprehensive coverage across contracts, frontend, and ecosystem |
| `contracts` / `sei-contracts` | Smart contracts + tooling | Contract development teams |
| `frontend` / `sei-frontend` | UI stack + site awareness | Frontend / dApp teams |
| `ecosystem` / `sei-ecosystem` | Apps, integrations, infra | Integration and infrastructure work |

Both `--variant` and `--name` accept either the short alias (`contracts`, `frontend`, `ecosystem`) or the actual skill name (`sei-contracts`, `sei-frontend`, `sei-ecosystem`).

```bash
# Claude Code variants (merge by default)
./install.sh --variant contracts
./install.sh --variant contracts --project     # install to current project's .claude/
./install.sh --path /tmp/sei-test              # custom path

# Clean reinstall (removes existing skill dir first, prompts for confirmation)
./install.sh --force
./install.sh --variant contracts --force

# Flattened variants for other agents
./install.sh --flatten --variant contracts
./install.sh --flatten --variant frontend --output .cursorrules
```

> **Upgrading from `sei-dev` (the old single-skill name)?** This skill was renamed `sei-dev` → `sei` to reflect its broader scope. The dev-focused variant is now `sei-contracts` (formerly `sei-dev`) and the UI-focused variant is `sei-frontend` (formerly `sei-website`). Install the `full` skill for broader coverage, or pick one of the variants. Remove `~/.claude/skills/sei-dev` before installing if you previously had the legacy version.

## Skill Structure

References are organised into three domain folders (`contracts/`, `frontend/`, `ecosystem/`) plus a small set of cross-cutting foundational files at the references root.

```
skill/
├── SKILL.md                              # Main skill definition (3-domain index)
├── SKILL-CONTRACTS.md                    # Contracts variant entry point
├── SKILL-FRONTEND.md                     # Frontend variant entry point
├── SKILL-ECOSYSTEM.md                    # Ecosystem variant entry point
└── references/
    ├── architecture.md                   # Twin Turbo, OCC, SeiDB, Sei Giga
    ├── networks.md                       # Chain IDs, RPC URLs, explorers, faucet
    ├── addresses-wallets.md              # Dual address system, wallets, HD paths
    ├── resources.md                      # Curated reference links
    │
    ├── contracts/                        # ── Domain: Contracts ──────────────────
    │   ├── contract-verification.md      # Seiscan verification via Sourcify (Foundry + Hardhat)
    │   ├── performance-testing.md        # Load testing, OCC scheduler benchmarking
    │   ├── occ-aware-design.md           # Parallelization-friendly storage layouts
    │   ├── gas-optimization-sei.md       # SSTORE costs, calldata, multicall
    │   ├── account-abstraction.md        # ERC-4337 with Pimlico, Particle
    │   ├── upgradeability.md             # UUPS, Transparent, Beacon, Diamond
    │   ├── tokens.md                     # SEI denominations, ERC standards, TokenFactory
    │   ├── security.md                   # Sei-specific + standard Solidity checklist
    │   └── common-errors.md              # Error → cause → solution
    │
    ├── evm/                              # EVM smart contracts (contracts-domain)
    │   ├── overview.md
    │   ├── hardhat.md
    │   ├── foundry.md
    │   ├── testing.md
    │   └── best-practices.md
    │
    ├── precompiles/                      # Sei precompiles (contracts-domain)
    │   ├── overview.md
    │   ├── staking-distribution.md
    │   ├── governance.md
    │   ├── json-p256.md
    │   └── cosmwasm-bridge.md
    │
    ├── pointers/                         # Cross-VM bridging (contracts-domain)
    │   ├── overview.md
    │   └── token-factory.md
    │
    ├── migration/                        # Migration guides (contracts-domain)
    │   ├── from-ethereum.md
    │   └── from-solana.md
    │
    ├── frontend/                         # ── Domain: Frontend ───────────────────
    │   ├── frontend-stack.md             # Wagmi/Viem, sei-js, EIP-6963, dual-address UX
    │   ├── sites-map.md                  # sei.io / docs.sei.io page index
    │   ├── docs-contributing.md          # Nextra + MDX contribution guide
    │   └── branding-media.md             # Brand kit, logos, press
    │
    └── ecosystem/                        # ── Domain: Ecosystem ──────────────────
        ├── apps-directory.md             # dApps grouped by category
        ├── integration-defi.md           # DEX/lending integration patterns
        ├── bridges.md                    # LayerZero, Wormhole, Axelar, CCTP
        ├── ibc-bridging.md               # IBC closed-state reference
        ├── rpc-providers.md              # Public + paid RPC endpoints
        ├── rpc-agent-skills.md           # 17 canonical RPC skills, retry, response shapes
        ├── oracles.md                    # Chainlink, Pyth, API3, RedStone, VRF
        ├── indexers.md                   # The Graph, Dune, Goldsky, Moralis, Goldrush
        ├── node-operations.md            # Node setup, sync, snapshots, seictl
        ├── validators.md                 # Key management, HSM, jailing, monitoring
        ├── staking-governance.md         # Delegation, unbonding, proposals
        ├── ai-tooling.md                 # Sei MCP Server, Cambrian Agent Kit
        └── participation-roles.md        # Validator, RPC, indexer, oracle, grants
    │
    └── cli/                              # ── Cross-cutting: CLI ─────────────────
        └── seid-cli.md                   # seid setup, wallet, queries, txns, JSON-RPC
```

## Usage

Once installed, your AI assistant automatically uses this skill when you ask about Sei development. Example prompts:

### Contracts — Smart Contracts
```
"Deploy a Solidity contract on Sei testnet"
"Why is SSTORE so expensive on Sei?"
"Set up Foundry for Sei"
"How do I verify my contract on Seiscan?"
"Load test my contract against the OCC scheduler"
"Optimize gas for my Sei contract"
"Use ERC-4337 account abstraction on Sei"
"Make my contract upgradeable with UUPS proxy"
```

### Contracts — Precompiles and Cross-VM
```
"How do I stake SEI from a Solidity contract?"
"Use the governance precompile to vote on a proposal"
"Create a pointer contract for my ERC20 token"
"How does the dual address system work?"
```

### Frontend — UI and Site Awareness
```
"Set up Wagmi with Sei mainnet and testnet"
"How do I use Sei Global Wallet for social login?"
"Why do I need gasPrice instead of maxFeePerGas on Sei?"
"Display both EVM and Cosmos addresses for a user"
"Where on docs.sei.io is the precompile reference?"
"How do I contribute a page to docs.sei.io?"
"Where is the Sei brand kit?"
```

### Ecosystem — Apps, Integration, Participation
```
"What dApps are live on Sei mainnet?"
"How do I integrate with a Sei DEX?"
"What bridges work with Sei?"
"What are good RPC endpoints for Sei?"
"How do I become a Sei validator?"
"Apply for a Sei Foundation grant"
"Set up a Sei full node with state sync"
"How do I create and register a validator?"
"Submit a governance proposal via CLI"
"Set up the Sei MCP server in Claude Code"
```

### CLI — seid and JSON-RPC
```
"How do I install seid?"
"Query the EVM address for a sei1... address"
"Generate an ERC20 transfer payload with seid"
"Look up a pointer contract for a native denom"
"Send a transaction with seid"
"Call a precompile with seid"
"How do I make a raw eth_call with curl?"
"What JSON-RPC methods are deprecated on Sei?"
```

### Architecture
```
"Explain Twin Turbo Consensus"
"How does OCC parallel execution work?"
"What is SeiDB?"
"Tell me about Sei Giga"
```

### Migration
```
"I'm migrating my Ethereum dApp to Sei — what do I need to change?"
"Coming from Solana — how do programs map to Solidity contracts?"
"What are the differences between Sei and Ethereum?"
```

## Stack Decisions

| Layer | Default | Alternative |
|---|---|---|
| Smart contracts | **Foundry** | Hardhat |
| Frontend | **Wagmi + Viem** (React) | Ethers.js v6 |
| Wallet | **Sei Global Wallet** + MetaMask | Compass, Ledger |
| Chain config | **@sei-js/precompiles** | Manual RPC config |
| Randomness | **Pyth VRF** | Chainlink VRF |
| Oracles | **Native precompile** (free) → Pyth (pull) → Chainlink (push) | — |
| Indexers | **The Graph** (custom queries) / **Goldsky** (real-time) | Dune (analytics) |

## Key Technical Facts

Every answer from this skill applies these Sei-specific facts:

1. 400ms block time, **instant finality** → use `tx.wait(1)`
2. **SSTORE gas is 72,000 on Sei**: both mainnet (pacific-1) and testnet (atlantic-2) charge 72,000 gas per write (governance-adjustable)
3. **Use `gasPrice`** (legacy) — Sei does not support EIP-1559 `maxFeePerGas`
4. **Minimum gas price: 50 gwei**
5. **Block gas limit: 12.5 M** per block
6. `PREVRANDAO` is NOT random — use Pyth VRF or Chainlink VRF
7. `COINBASE` = global fee collector, not block proposer
8. No base fee burn — all fees to validators
9. **Dual address system**: `sei1...` + `0x...` from the same key
10. **CosmWasm deprecated** per SIP-3 — use EVM for new contracts
11. Chain IDs: Mainnet `pacific-1`/`1329`, Testnet `atlantic-2`/`1328`
12. No `safe`/`finalized` block tags — use `latest`

## Relationship to Sei Docs

This skill complements [docs.sei.io](https://docs.sei.io). The official docs are authoritative for the latest protocol changes. This skill is optimized for AI coding assistant consumption — structured for progressive disclosure, with code-first examples and decision trees rather than narrative prose.

## Content Sources

Built from:
- [sei-chain](https://github.com/sei-protocol/sei-chain) — core protocol
- [sei-docs](https://github.com/sei-protocol/sei-docs) — official documentation (Nextra + MDX)
- [seid](https://github.com/sei-protocol/seid) — CLI tooling
- [sei.io](https://www.sei.io) — ecosystem directory and brand assets
- [docs.sei.io/llms.txt](https://docs.sei.io/llms.txt) — LLM-friendly site nav

## Contributing

1. Fork and clone the repository
2. Update the relevant reference file in `skill/references/`
3. If adding a new file, add a link to `skill/SKILL.md` under "Reference Files"
4. Run `./install.sh` to test locally
5. Run the trigger tests to verify skill triggers correctly:
   ```bash
   cd tests && npm install
   ANTHROPIC_API_KEY=your_key npm test
   ```
6. Open a pull request

## License

MIT — see [LICENSE](LICENSE)
