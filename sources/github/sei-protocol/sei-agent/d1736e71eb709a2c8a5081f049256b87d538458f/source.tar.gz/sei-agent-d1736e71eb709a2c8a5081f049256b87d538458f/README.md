# Sei Agent 🤖

**An intelligent AI-powered Twitter bot that autonomously generates content, engages with users, and provides real-time market insights for the Sei blockchain ecosystem.**

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Node.js](https://img.shields.io/badge/Node.js-v23.3.0-green.svg)](https://nodejs.org/)
[![TypeScript](https://img.shields.io/badge/TypeScript-Ready-blue.svg)](https://www.typescriptlang.org/)

---

## Table of Contents

1. [What is Sei Agent?](#what-is-sei-agent)
2. [Key Features](#key-features)
3. [Quick Start](#quick-start)
4. [Character System](#character-system)
5. [Contributing](#contributing)

---

## What is Sei Agent?

Sei Agent is an autonomous AI Twitter bot built specifically for the Sei blockchain ecosystem. It combines advanced AI capabilities with real-time market data to create engaging, informative content while maintaining authentic interactions with the crypto community.

### Why Sei Agent?

- **🎯 Purpose-Built**: Designed specifically for blockchain and DeFi communities
- **🧠 Intelligent**: Uses advanced AI to generate contextual, relevant content
- **⏰ Autonomous**: Runs 24/7 with smart scheduling and content planning
- **📊 Data-Driven**: Integrates real-time market data, news, and analytics
- **🎭 Personality**: Customizable character aspects for authentic engagement
- **🔧 Extensible**: Plugin-based architecture for easy customization  

---

## Key Features

### 🤖 Autonomous Content Generation
- **Smart Scheduling**: Automated posting with customizable timing
- **Market Intelligence**: Real-time crypto market data and analysis
- **News Integration**: Automated business and world news updates
- **Dynamic Personality**: Multiple character aspects that activate based on time and context

### 🐦 Advanced Twitter Integration
- **Intelligent Replies**: Context-aware responses to mentions and interactions
- **Target Engagement**: Actively engages with specified accounts
- **Anti-Spam Protection**: Built-in similarity detection and rate limiting
- **Dry Run Mode**: Test your bot without actually posting

### 📊 Data & Analytics
- **Stock Market Data**: Automated stock and crypto market updates
- **Dune Analytics**: On-chain data insights and metrics
- **Sei Network Stats**: Real-time blockchain analytics
- **Custom Data Sources**: Extensible plugin system for new data feeds

### ⚙️ Easy Configuration
- **Character Profiles**: JSON-based character configuration
- **Flexible Scheduling**: Cron-style job scheduling
- **Environment Variables**: Simple `.env` file configuration
- **Multiple Personalities**: Switch between different character aspects

---

## Quick Start

### Prerequisites
- Node.js v23.3.0 (use `nvm use` to switch versions)
- pnpm package manager
- OpenAI API key
- Twitter account credentials
- Docker (optional, for containerized setup)

### Installation

1. **Clone and install**
   ```bash
   git clone https://github.com/your-org/sei-agent.git
   cd sei-agent
   nvm use  # Switch to Node v23.3.0
   pnpm install # export SHARP_IGNORE_GLOBAL_LIBVIPS=1 if sharp error
   ```

2. **Configure environment**
   ```bash
   cp .env.example .env
   # Add your OpenAI API key and Twitter credentials to .env
   ```

3. **Create database**
   ```bash
   mkdir -p data
   touch data/db.sqlite
   ```

4. **Build Project**
   ```bash
   pnpm run build
   ```

5. **Start the agent**
   ```bash
   pnpm start --character=characters/sensei1202.character.json
   ```

   That's it! Your Sei Agent will start posting and engaging automatically. 🎉

### Docker Setup (Alternative)

You can also run Sei Agent in a Docker container:

1. **Ensure Docker daemon is running** on your system

2. **Build and start the Docker container**
   ```bash
   pnpm docker
   ```
   This command builds the Docker image, starts the container, and gives you a bash shell inside the container.

3. **Start the agent inside the container**
   ```bash
   pnpm start --character=characters/sensei1202.character.json
   ```

### VS Code Development Container

For VS Code users, this project includes devcontainer support for an integrated development experience:

1. Install the **Remote - Containers** extension in VS Code
2. Open the project folder in VS Code
3. Click the green button in the lower left corner or run the **Remote-Containers: Reopen in Container** command
4. VS Code will build and start the container, then connect to it automatically

> **Need detailed setup help?** See our comprehensive [Setup Guide](SETUP.md) for environment variables, troubleshooting, and advanced configuration.



---

## Character System

Sei Agent uses a sophisticated character system that enables dynamic personality switching and contextual behavior.

### Character Aspects

Each character can have multiple "aspects" that activate based on time and context:

#### Example Aspects

- **🏪 Trader**: Market analysis and trading insights
- **🧘 Meditation**: Zen philosophy and mindfulness content  
- **💨 Breathwork**: Breathing techniques and wellness
- **₿ Crypto Enthusiast**: General crypto market commentary
- **☯️ Zen Practitioner**: Philosophical and spiritual content

### Dynamic Scheduling

Aspects activate automatically based on:
- **Time of day**: Different personalities for different hours
- **Day of week**: Weekend vs weekday behavior
- **Intensity levels**: How active each aspect should be
- **Weights**: Priority when multiple aspects overlap

### Customization

Create your own character by editing JSON files:

```json
{
  "name": "YourBot",
  "bio": "Your bot's personality...",
  "characterBios": {
    "aspects": {
      "trader": {
        "bio": "Market expert personality",
        "weight": 5,
        "schedules": [
          {
            "days": [1, 2, 3, 4, 5],
            "hours": [9, 15],
            "intensity": 0.8
          }
        ]
      }
    }
  }
}
```





---

## Contributing

We welcome contributions to Sei Agent! Here's how you can help:

### Development Setup

1. Fork the repository
2. Create a feature branch: `git checkout -b feature/amazing-feature`
3. Make your changes and test thoroughly
4. Submit a pull request

### Areas for Contribution

- **New Plugins**: Add support for additional data sources or platforms
- **Character Templates**: Create new personality templates
- **Analytics**: Improve data visualization and reporting
- **Security**: Enhance safety and rate limiting features
- **Documentation**: Improve guides and examples

### Code Style

- Use TypeScript for type safety
- Follow existing code patterns
- Add tests for new features
- Update documentation as needed

---

## License

MIT License - see [LICENSE](LICENSE) file for details.

---

## Support

- **Documentation**: [Setup Guide](SETUP.md)
- **Issues**: [GitHub Issues](https://github.com/your-org/sei-agent/issues)
- **Discussions**: [GitHub Discussions](https://github.com/your-org/sei-agent/discussions)
- **Star the repo** if you find it useful!

---

**Built with ❤️ for the Sei ecosystem**

*Powered by [ElizaOS](https://github.com/ai16z/eliza) and the open source community*
