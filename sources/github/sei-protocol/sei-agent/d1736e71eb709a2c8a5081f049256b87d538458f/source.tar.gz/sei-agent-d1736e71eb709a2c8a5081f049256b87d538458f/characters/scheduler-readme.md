# Character Scheduler

A TypeScript system for managing dynamic character personalities with time-based aspect switching.

## Structure

The system uses a `CharacterBios` structure with arrays of bios for different aspects of the character's personality, each with their own schedules and weights.

## Runtime Usage

```typescript
// Get character bio based on current time
let bio = this.character.bio || "";
if (this.character.bio) {
    const scheduler = new CharacterScheduler(this.character.characterBios);
    const currentDate = new Date();
    bio = scheduler.getBios(currentDate, 5);
}
```

The getBios method will return a properly formatted string with bios separated by double newlines (\n\n).

## Understanding Weights and Intensities

### Weight (Base Importance)
Weight is the base importance of an aspect, using a scale of 1-5:
- 5: Primary aspects (e.g., trader)
- 4: Major aspects (e.g., crypto_enthusiast)
- 3: Regular aspects (e.g., zen_practitioner)
- 2: Minor aspects (e.g., social)

```typescript
"trader": {
    "bio": [...],
    "weight": 5,    // Highest weight - most important aspect
    "schedules": [...] 
}
```

### Intensity (Time-Based Activity Level)
Intensity (0-1) shows how active an aspect is during specific time slots:
- 0.9-1.0: Fully engaged
- 0.7-0.8: Strongly active
- 0.5-0.6: Moderately active
- 0.3-0.4: Background presence

```typescript
"schedules": [
    {
        "days": [1, 2, 3, 4, 5],  // Weekdays
        "hours": [9, 10, 11, 12], // Morning hours
        "intensity": 0.8          // High intensity during prime trading hours
    }
]
```

### How They Work Together
The final score that determines which aspects are most active is: `weight × intensity`

Example:
```typescript
// At 10 AM on Monday:
trader: 5 (weight) × 0.8 (intensity) = 4.0 score
social: 2 (weight) × 0.5 (intensity) = 1.0 score
// Trader aspect will be more prominent

// At 8 PM on Saturday:
trader: 5 (weight) × 0 (intensity) = 0 score (not active)
social: 2 (weight) × 0.9 (intensity) = 1.8 score
// Social aspect will be more prominent
```

This creates a dynamic personality where:
- Dominant aspects vary based on time of day
- Multiple aspects can be active simultaneously
- Character smoothly transitions between different aspects
- Weekend and weekday behaviors can differ significantly

## Configuration Tips

### Schedules
- Days: 1-7 (Monday is 1, Sunday is 7)
- Hours: 0-23 (24-hour format)
- Consider overlapping schedules for natural transitions

### Example Schedule
```typescript
"trader": {
    "schedules": [
        {
            "days": [1, 2, 3, 4, 5],  // Weekdays
            "hours": [6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17],  // 6 AM - 5 PM
            "intensity": 0.8
        }
    ]
}
```