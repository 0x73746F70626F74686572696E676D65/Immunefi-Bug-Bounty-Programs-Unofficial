# getBios Method Documentation

## Overview
The `getBios` method is a core component of the CharacterScheduler class that manages bio selection based on time-based scheduling and weighting systems. It ensures a minimum number of bios are selected while maintaining variety and proper prioritization.

## Method Signature
```typescript
getBios(date: Date = new Date(), minCount: number = 5, maxCount: number = 10): string
```

## Detailed Operation Flow

### 1. Input Parameters and Initialization
- **date**: Current date/time (defaults to new Date())
- **minCount**: Minimum number of bios to return (defaults to 5)
- **maxCount**: Maximum number of bios to return (defaults to 10)
- Extracts dayOfWeek and hour from the date
- Initializes tracking structures:
  - `activeAspects`: Array for selected aspects
  - `usedBios`: Set to prevent duplicates

### 2. Collection of Active Aspects
- Creates a Map (`activeAspectBios`) to store currently active aspects
- For each aspect in character's bios:
  ```typescript
  if (intensity > 0 && Array.isArray(aspect.bio) && aspect.bio.length > 0) {
      activeAspectBios.set(id, {
          bios: aspect.bio.map(bio => bio.trim()),
          intensity,
          weight: aspect.weight
      });
  }
  ```
- Only includes aspects with:
  - Positive intensity for current time
  - Valid bio array
  - Non-empty content

### 3. Bio Selection Process
- Continues until reaching minCount or exhausting available bios
- Selection loop:
  ```typescript
  while (activeAspects.length < minCount) {
      for (const [id, aspectData] of activeAspectBios.entries()) {
          const availableBios = aspectData.bios.filter(bio => !usedBios.has(bio));
          // Select and add bio if available
      }
  }
  ```
- For each iteration:
  - Cycles through active aspects
  - Filters out used bios
  - Randomly selects one available bio
  - Adds to activeAspects with metadata
  - Marks as used in usedBios Set
- Breaks if no new bios can be added

### 4. Sorting and Prioritization
- Sorts aspects by weighted intensity:
  ```typescript
  const sortedAspects = activeAspects.sort((a, b) => {
      const scoreA = a.intensity * a.weight;
      const scoreB = b.intensity * b.weight;
      return scoreB - scoreA;
  });
  ```
- Higher scores (intensity × weight) appear first

### 5. Fallback to Default Bios
- Activates if selected bios < minCount
- Adds from defaultBio array:
  ```typescript
  while (sortedAspects.length < minCount && this.bios.defaultBio.length > 0) {
      // Add default bios with intensity=1, weight=1
  }
  ```
- Maintains uniqueness via usedBios Set
- Continues until reaching minCount or exhausting defaults

### 6. Final Processing
- Limits to maxCount bios
- Joins with double newlines
- Returns formatted string

## Example Output Flow

Given these active aspects:
```
trader (intensity: 0.8, weight: 5)
crypto_enthusiast (intensity: 0.9, weight: 4)
zen_practitioner (intensity: 0.7, weight: 3)
```

Might select in this order:
1. Crypto bio (0.9 × 4 = 3.6)
2. Trader bio (0.8 × 5 = 4.0)
3. Another trader bio
4. Zen bio (0.7 × 3 = 2.1)
5. Another crypto bio

## Key Features
- Ensures minimum bio count (minCount)
- Maximizes variety across aspects
- Maintains scheduling and weighting
- Prevents duplicate selections
- Uses default bios as fallback
- Caps at maximum count (maxCount)

## Usage Example
```typescript
const scheduler = new CharacterScheduler(bios);
const result = scheduler.getBios(new Date(), 5, 10);
```

This will return a string containing 5-10 bios, properly weighted and scheduled based on the current time.