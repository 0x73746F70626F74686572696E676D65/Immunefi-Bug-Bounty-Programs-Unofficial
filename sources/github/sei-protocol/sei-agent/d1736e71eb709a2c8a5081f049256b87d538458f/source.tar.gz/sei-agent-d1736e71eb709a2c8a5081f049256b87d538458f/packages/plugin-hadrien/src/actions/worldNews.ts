import {
    type ActionExample,
    type IAgentRuntime,
    type Memory,
    type State,
    type Action,
    type HandlerCallback,
    elizaLogger,
    generateText,
    ModelClass,
} from "@elizaos/core";
import type {HadrienClient} from "../hadrienClient.ts";


async function generateTweetForKeywordInurl(
    articles: { id: number; title: string; text: string; url: string; publish_date: string; }[],
    _runtime: IAgentRuntime
): Promise<string> {
    const character = _runtime.character || {};
    const agentName = _runtime.character?.name || "Sensei";

    if (!articles || articles.length === 0) {
        console.warn("No articles available.");
        return "";
    }

    // Sort articles by publish date to get the latest news
    articles.sort((a, b) => new Date(b.publish_date).getTime() - new Date(a.publish_date).getTime());

    const summarizationPrompt = `
    # TASK: Extract high-signal insights from the latest finance or crypto-moving news.

    ## News Articles:
    ${articles.map(article => `- ${article.title}: ${article.text}`).join("\n")}

    # INSTRUCTIONS:
    - Identify the **most alpha-rich** news—something that shifts narratives, unlocks asymmetric upside, or signals a macro trend shift.
    - Prioritize **crypto & finance** news. If none, pick the **most impactful global macro signal.**
    - What’s the alpha here? Extract the **most asymmetric insight**.
    - No generic news summaries. **Inject a degen VC mindset.** Think:
      - "What does this unlock?"
      - "What’s the hidden second-order effect?"
      - "Is the crowd reading this wrong?"
    - **Use high-signal, internet-native language.** Degen finance, not corporate speak.
    - the post should be 180 characters max
    - **Enforce lowercase at the beginning of every sentence**, unless it's a proper noun, acronym, or intentionally capitalized brand or title.

    - **No hashtags, no emojis. Just raw insight.**
`;
    try {
        console.log("Generating tweet using AI...");
        const generatedSummary = await generateText({
            runtime: _runtime,
            context: summarizationPrompt,
            modelClass: ModelClass.SMALL,
            stop: ["\n"],
        });

        if (!generatedSummary || !generatedSummary.trim()) {
            console.error("Generated summary is empty! AI response:", generatedSummary);
            return "";
        }
        console.log("Generated summary:", generatedSummary.trim());
        return generatedSummary.trim();
    } catch (error) {
        console.error("Error generating tweet:", error);
        return "";
    }
}

let lastTopic: string | null = null; // Store last topic globally

export const worldNewsAction: Action = {
    name: "WORLD_NEWS",
    similes: ["WORLD_NEWS"],
    validate: async (_runtime: IAgentRuntime, _message: Memory) => {
        return true;
    },
    description: "Fetch and summarize an article from the Business API and post as a tweet thread.",
    handler: async (
        _runtime: IAgentRuntime,
        _message: Memory,
        _state?: State,
        _options?: { [key: string]: unknown },
        _callback?: HandlerCallback
    ): Promise<boolean> => {
        const API_KEY = process.env.WORLD_NEWS_API_KEY;
        const BASE_URL = 'https://api.worldnewsapi.com/search-news';
        // List of potential topics
        const topicsList = ["business", "crypto", "finance", "stock market", "economy", "investing", "startups", "technology", "innovation", "entrepreneurship"];
        // const topic = topicsList[Math.floor(Math.random() * topicsList.length)];
        // Ensure the next topic is different from the last one
        let topic: string;
        do {
            topic = topicsList[Math.floor(Math.random() * topicsList.length)];
        } while (topic === lastTopic);

        lastTopic = topic; // Update the last used topic
        const apiUrl = `${BASE_URL}?api-key=${API_KEY}&text=${encodeURIComponent(topic)}&source-country=us&sort=publish-time&language=en&sort-direction=DESC`;

        elizaLogger.log(`Fetching article with topic '${topic}' from: ${apiUrl}`);

        try {
            // Fetch the next unshared article
            const response = await fetch(apiUrl);
            elizaLogger.debug(`Fetched ${response} `);

            const data = await response.json();
            elizaLogger.debug(`Fetched ${data.news.length} articles for topic: ${topic}`);


            if (!data || !data.news) {
                _callback?.({ text: `No relevant articles found for topic: ${topic}` });
                return true;
            }

            // Use the first article from the response
            const articles = data.news;
            // Generate tweet threads
            const tweet = await generateTweetForKeywordInurl(articles, _runtime);
            elizaLogger.log('Checked here')
            if (!tweet) {
                _callback?.({ text: "Failed to generate tweet for the article." });
                return true;
            }


            _callback({ text: tweet.trim() }, []);
            const hadrienClient = _runtime.clients?.hadrien as HadrienClient | undefined;
            if (hadrienClient) {
                await hadrienClient.triggerWorldNews();
                elizaLogger.log('World news is triggered');
                _callback?.({ text: "Triggered world news via HadrienClient!" });
            } else {
                elizaLogger.log('HadrienClient is not available');
                _callback?.({ text: "HadrienClient not available." });
            }

            for (const article of articles) {
                const articleMemory: Memory = {
                    userId: _message.agentId,
                    agentId: _message.agentId,
                    roomId: _message.roomId,
                    content: {
                        text: article.title,
                        action: "ARTICLE",
                        source: article.source_name || "Unknown Source",
                        url: article.url,
                        metadata: {
                            publishedDate: article.publish_date,
                            section: topic,
                            fullContent: article.content,
                            tweetText: tweet

                        },
                    },
                };
                elizaLogger.debug(`Creating memory for article: ${article.title}`);

                const memoryWithEmbedding = await _runtime.messageManager.addEmbeddingToMemory(articleMemory);
                if (!memoryWithEmbedding.embedding || memoryWithEmbedding.embedding.length === 0) {
                    elizaLogger.warn(`Embedding is empty for article: ${article.title}, skipping memory storage.`);
                    continue;
                }
                await _runtime.messageManager.createMemory(memoryWithEmbedding);
                elizaLogger.debug(`Memory successfully stored for article: ${article.title}`);
            }
        } catch (error) {
            console.error("Error fetching or processing article:", error);
            _callback?.({ text: "no news is good news... or not" });
            return false;
        }

        return true;
    },
    examples: [
        [
            {
                user: "{{user1}}",
                content: { text: "What's happening in the news?", action: "WORLD_NEWS" },
            },
            {
                user: "{{user2}}",
                content: { text: "Let me fetch the latest article for you!", action: "BUSINESS_NEWS" },
            },
        ],
    ] as ActionExample[][],
};
