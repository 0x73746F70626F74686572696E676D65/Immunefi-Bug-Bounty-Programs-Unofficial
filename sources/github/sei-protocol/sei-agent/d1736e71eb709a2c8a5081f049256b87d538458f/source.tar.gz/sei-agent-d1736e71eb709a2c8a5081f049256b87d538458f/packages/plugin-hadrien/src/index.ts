import type { Plugin } from "@elizaos/core";
import { businessNewsAction } from "./actions/buisnessNews";
import { generateMemeAction, generateMemeActionHandler, Meme } from "./actions/generate-meme";
import { getCryptoAnalysis } from "./actions/duneAnalytics";
import { stockDataAction } from "./actions/getStockAction";
import { processImageAction } from "./actions/processImage";
import { koiFunFactsAction } from "./actions/koiFunFacts";
import { processImageTameshigiriAction } from "./actions/processImageTameshigiri";
import { processImageOnsenAction } from "./actions/processImageOnsen";
import { processImageReadingAction } from "./actions/processImageReading";
import { processImageWeekendsAction } from "./actions/processImageWeekend";
import { processImageWorkAction } from "./actions/processImageWork";
import { processImageYogaAction } from "./actions/processImageYoga";
import { processImageArtAction } from "./actions/processImageArt";
import { worldNewsAction } from "./actions/worldNews";
import { processImageSkiiingAction } from "./actions/processImageSkiiing";
import { getSeiAnalysis } from "./actions/seiAnalytics";
import { processImageKoiAction } from "./actions/processImageKoi";
import { processImageNightAction } from "./actions/processImageNight";
import { processImageFoodAction } from "./actions/processImageFood";
import { SEIACTION } from "./actions/SEIAction";
import { seiPricetProvider } from "./providers/SEIProvider";
import { processImageTokyoAction } from "./actions/processImageTokyo";
import { walletBalanceAction } from "./actions/walletBalance";
export { generateMemeAction, generateMemeActionHandler, Meme };

export const hadrienPlugin: Plugin = {
    name: "hadrien",
    description: "A plugin for Hadrien integration.",
    actions: [
        businessNewsAction,
        generateMemeAction,
        processImageAction,
        stockDataAction,
        getSeiAnalysis,
        getCryptoAnalysis,
        koiFunFactsAction,
        processImageSkiiingAction,
        processImageKoiAction,
        processImageTameshigiriAction,
        processImageOnsenAction,
        processImageReadingAction,
        processImageWeekendsAction,
        processImageWorkAction,
        processImageYogaAction,
        processImageArtAction,
        processImageTokyoAction,
        worldNewsAction,
        processImageNightAction,
        processImageFoodAction,
        SEIACTION,
        walletBalanceAction,
    ],
    providers: [
        seiPricetProvider
    ]
};
