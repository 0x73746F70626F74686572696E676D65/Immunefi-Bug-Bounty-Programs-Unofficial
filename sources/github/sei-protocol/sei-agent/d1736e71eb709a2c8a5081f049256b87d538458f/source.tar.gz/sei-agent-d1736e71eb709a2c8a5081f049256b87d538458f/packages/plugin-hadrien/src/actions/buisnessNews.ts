import {
    type ActionExample,
    type IAgentRuntime,
    type Memory,
    type State,
    type Action,
    type HandlerCallback,
    elizaLogger,
    generateText,
    ModelClass,
} from "@elizaos/core";

// Generate tweet threads for an article
async function generateTweet(article: { title: string; content: string }, _runtime: IAgentRuntime): Promise<string> {
    // Step 1: Extract key themes and insights from the article
    const extractedThemesPrompt = `
    # TASK: Extract the key themes and high-signal takeaways from the article below.

    ## News Headline: ${article.title}

    ## Article Content:
    ${article.content}

    # INSTRUCTIONS:
    - Identify the **core theme** in **one sentence**.
    - Extract **one sharp, high-signal insight**.
    - Output must be structured in this format:
      **Theme:** [single sentence]
      **Insight:** [single sentence]
`;

    let extractedThemes = "";
    try {
        extractedThemes = await generateText({
            runtime: _runtime,
            context: extractedThemesPrompt,
            modelClass: ModelClass.MEDIUM,
            stop: ["\n"],
        });
    } catch (error) {
        console.error("Error extracting themes:", error);
    }

    const tweetOpeners = [
        "got this news:",
        "today's headline:",
        "this just in:",
        "we got news:",
        "this!",
        "damn:",
        "thoughts on this?",
        "this news:",
        "did you see this?",
        "doomscrolling:",
        "what's going on?",
        "what's your take?",
        "what's the lowdown?"
    ];
    const randomOpener = tweetOpeners[Math.floor(Math.random() * tweetOpeners.length)];

    // Step 2: Generate a single, high-impact tweet
    const summarizationPrompt = `
    # TASK: Transform the article into a concise, high-signal Twitter post as **Sensei**, the koi-obsessed, slightly degen VC investor.

    ## Extracted Theme & Insight:
    ${extractedThemes}

   # INSTRUCTIONS:
    - Write **one tweet (180 characters max)** summarizing the news.
    - Start with **${randomOpener}**.
    - Keep it **precise, slightly degen, and no-nonsense**.
    - The **subject of the news must be clear**—no vague takes.
    - the post should be 180 characters max
    - **Enforce lowercase at the beginning of every sentence**, unless it's a proper noun, acronym, or intentionally capitalized brand or title.

    - No hashtags, no emojis. Just pure signal.
`;

    try {
        const generatedText = await generateText({
            runtime: _runtime,
            context: summarizationPrompt,
            modelClass: ModelClass.SMALL,
            stop: ["\n"],
        });

        return generatedText.trim();
    } catch (error) {
        console.error("Error generating tweet:", error);
        return "";
    }
}


let lastTopic: string | null = null;


export const businessNewsAction: Action = {
    name: "BUSINESS_NEWS",
    similes: ["FETCH_BUSINESS_NEWS", "BUSINESS_NEWS"],
    validate: async (_runtime: IAgentRuntime, _message: Memory) => {
        return true;
    },
    description: "Fetch and summarize an article from the Business API and post as a tweet thread.",
    handler: async (
        _runtime: IAgentRuntime,
        _message: Memory,
        _state?: State,
        _options?: { [key: string]: unknown },
        _callback?: HandlerCallback
    ): Promise<boolean> => {
        // List of potential topics
        const topicsList = ["business", "crypto", "finance", "markets"];
        // const topic = topicsList[Math.floor(Math.random() * topicsList.length)];
        const apiKey = process.env.NEWS_API_KEY;
        // Ensure the next topic is different from the last one
        let topic: string;
        do {
            topic = topicsList[Math.floor(Math.random() * topicsList.length)];
        } while (topic === lastTopic); // Repeat selection if it's the same as the last topic

        lastTopic = topic; // Update the last used topic
        const apiUrl = `https://newsapi.org/v2/everything?q=${topic}&apiKey=${apiKey}`;

        try {
            const response = await fetch(apiUrl);
            const data = await response.json();

            if (!data || !data.articles || data.articles.length === 0) {
                _callback?.({ text: `No relevant articles found for topic: ${topic}` });
                return true;
            }

            const article = data.articles[0];
            if (!article.content) {
                _callback?.({ text: "The fetched article has no content to summarize." });
                return true;
            }

            elizaLogger.debug(`Fetched article BUSINESS NEWS:::::::::::::::: Title: ${article.title} Content: ${article.content}`);

            const tweet = await generateTweet({ title: article.title, content: article.content }, _runtime);
            if (!tweet) {
                _callback?.({ text: "no news today" });
                return true;
            }


            _callback({ text: tweet.trim() });


            const articleMemory: Memory = {
                userId: _message.agentId,
                agentId: _message.agentId,
                roomId: _message.roomId,
                content: {
                    text: article.title,
                    action: "ARTICLE",
                    source: article.source.name || "Unknown Source",
                    url: article.url,
                    metadata: {
                        publishedDate: article.publishedAt,
                        section: topic,
                        fullContent: article.content,
                        tweetText: tweet

                    },
                },
            };

            const memoryWithEmbedding = await _runtime.messageManager.addEmbeddingToMemory(articleMemory);
            if (!memoryWithEmbedding.embedding || memoryWithEmbedding.embedding.length === 0) {
                elizaLogger.warn("Embedding is empty, skipping memory creation:", memoryWithEmbedding);
                return true;
            }

            await _runtime.messageManager.createMemory(memoryWithEmbedding);
        } catch (error) {
            console.error("Error fetching or processing article:", error);
            _callback?.({ text: "An error occurred while fetching or summarizing the article." });
            return false;
        }

        return true;
    },
    examples: [
        [
            {
                user: "{{user1}}",
                content: { text: "What's happening in the news?" },
            },
            {
                user: "{{user2}}",
                content: { text: "Let me fetch the latest article for you!", action: "BUSINESS_NEWS" },
            },
        ],
    ] as ActionExample[][],
};
