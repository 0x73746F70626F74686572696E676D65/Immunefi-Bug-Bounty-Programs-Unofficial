import {
    type ActionExample,
    type IAgentRuntime,
    type Memory,
    type State,
    type Action,
    type HandlerCallback,
    elizaLogger,
    generateText,
    ModelClass,
} from "@elizaos/core";

const apiUrl = `https://maitreapi-production.up.railway.app/mongodb/random`;

async function fetchRandomFunFact(): Promise<string | null> {
    try {
        console.log(`📡 Fetching fun fact from: ${apiUrl}`);
        const response = await fetch(apiUrl);
        const fact = await response.json();

        if (!fact || !fact.text) {
            console.warn("⚠️ Invalid or empty fun fact:", fact);
            return null;
        }

        console.log(`🎉 Retrieved Fun Fact: "${fact.text}"`);
        return fact.text;
    } catch (error) {
        console.error("🚨 Error fetching fun fact:", error);
        return null;
    }
}

async function generateTweetFromFunFact(funFact: string, _runtime: IAgentRuntime): Promise<string> {

    const tweetPrompt = `
    # TASK: Convert the fun fact below into a witty, engaging tweet in the voice of **Sensei** who is enamoured by Bubbles, his $1.8M Kohaku koi fish.

    ## Koi Fun Fact:
    ${funFact}

    # INSTRUCTIONS:
    - Make the tweet **concise, engaging, and fun**.
    - Choose one of these angles:
      - **Make it relatable** (connect it to everyday experiences).
      - **Add a humorous twist** (wordplay, irony, exaggeration).
      - **Pose it as a rhetorical question** to spark engagement.
    - Maintain a **limit of 180 characters**.
    - No hashtags, no emojis.
    - Enforce lowercase at the beginning of every sentence, unless it's a proper noun, acronym, or intentionally capitalized brand or title.
`;

    try {
        const generatedTweet = await generateText({
            runtime: _runtime,
            context: tweetPrompt,
            modelClass: ModelClass.SMALL,
            stop: ["\n"],
        });

        return generatedTweet.trim();
    } catch (error) {
        console.error("🚨 Error generating tweet:", error);
        return `"Science says Koi recognize their owners. Meanwhile, my cat pretends not to know me."`; // Fallback tweet
    }
}

export const koiFunFactsAction: Action = {
    name: "FETCH_FUN_FACT",
    similes: ["KOI_FUN_FACTS"],
    validate: async (_runtime: IAgentRuntime, _message: Memory) => {
        return true; // Always valid
    },
    description: "Fetch a random fun fact, transform it into a tweet, and share it.",
    handler: async (
        _runtime: IAgentRuntime,
        _message: Memory,
        _state?: State,
        _options?: { [key: string]: unknown },
        _callback?: HandlerCallback
    ): Promise<boolean> => {

        try {

            const response = await fetch(apiUrl);
            const funFact = await response.json();


            if (!funFact || !funFact.text) {
                console.warn("⚠️ No valid fun fact found.");
                _callback({ text: "No fun facts available at the moment. Try again later!" });
                return true;
            }

            console.log(`🛠 Generating tweet for: ${funFact.text}`);

            // Generate a witty tweet from the fun fact
            const tweet = await generateTweetFromFunFact(funFact.text, _runtime);

            if (!tweet || tweet.length === 0) {
                console.warn("⚠️ Failed to generate a tweet.");
                _callback({ text: "no bubbles fun fact today" });
                return true;
            }

            // Send the tweet
            _callback({ text: tweet.trim() });

        } catch (error) {
            console.error("🚨 Error fetching or processing fun fact:", error);
            _callback({ text: "An error occurred while processing the fun fact." });
            return false;
        }

        return true;
    },
    examples: [
        [
            {
                user: "{{user1}}",
                content: { text: "Tell me something cool!" },
            },
            {
                user: "{{user2}}",
                content: { text: "Octopuses have three hearts. Imagine getting dumped three times at once." },
            },
        ],
    ] as ActionExample[][],
};
