import {
    type Client,
    type IAgentRuntime,
    elizaLogger,
    type Memory,
    type State,
    type HandlerCallback,
    type Content,
    type Media,
} from "@elizaos/core";

import cron from "node-cron";

// Import your Guardian News action
import fs from "fs";
import path from "path";
import type { MediaData } from "./types";

export async function fetchMediaData(
    attachments: Media[]
): Promise<MediaData[]> {
    return Promise.all(
        attachments.map(async (attachment: Media) => {
            if (/^(http|https):\/\//.test(attachment.url)) {
                // Handle HTTP URLs

                const response = await fetch(`${attachment.url}`);
                if (!response.ok) {
                    throw new Error(`Failed to fetch file: ${attachment.url}`);
                }
                const mediaBuffer = Buffer.from(await response.arrayBuffer());
                const mediaType = attachment.contentType;
                return { data: mediaBuffer, mediaType };
            } else if (fs.existsSync(attachment.url)) {
                // Handle local file paths
                const mediaBuffer = await fs.promises.readFile(
                    path.resolve(attachment.url)
                );
                const mediaType = attachment.contentType;
                return { data: mediaBuffer, mediaType };
            } else {
                throw new Error(
                    `File not found: ${attachment.url}. Make sure the path is correct.`
                );
            }
        })
    );
}

export class HadrienClient implements Client {
    private timer: NodeJS.Timeout | null = null;
    private runtime: IAgentRuntime;
    private twitterClient: any | null;
    private cronJobs: cron.ScheduledTask[] = [];

    constructor(runtime: IAgentRuntime, twitterClient: any | null = null) {
        this.runtime = runtime;
        this.twitterClient = twitterClient;

    }
    //     /**
    //  * 📌 Scheduled Tasks (Using Cron Expressions)
    //  *
    //  * ┌───────── Minute (0 - 59)
    //  * │ ┌───────── Hour (0 - 23, UTC)
    //  * │ │ ┌───────── Day of Month (1 - 31)
    //  * │ │ │ ┌───────── Month (1 - 12)
    //  * │ │ │ │ ┌───────── Day of Week (0 - 6, Sunday = 0)
    //  * │ │ │ │ │
    //  * │ │ │ │ │
    //  * │ │ │ │ │
    //  * 0  9  * * *  → Runs **every day at 9 AM** (Business News)
    //  * 0 12  * * 1  → Runs **every Monday at 12 PM** (Fun Fact)
    //  * 0 15  * * *  → Runs **every day at 3 PM** (Meme Post)
    //  * 0 18  * * *  → Runs **every day at 6 PM** (Stock Data)
    //  * 0 22  * * 5  → Runs **every Friday at 10 PM** (Dune Analytics)
    //  * 0  8  * * *  → Runs **every day at 8 AM** (Image Processing)
    //  * 0 14  * * *  → Runs **every day at 2 PM** (Koi Shitpost)
    //  *
    //  * 🕒 NOTE: All times are in **UTC**.
    //  * 🌍 To adjust for your timezone, use `{ timezone: "Your/Timezone" }`.
    //  */

    async scheduleTasks(): Promise<void> {
        const schedules = [
            //API DATA ACTIONS
            { cronTime: "50 14 * * 1,2,3,4,5,7", action: this.triggerBusinessNews.bind(this), name: "Business News" },
            { cronTime: "53 14 * * 1,2,3,4,5,6,7", action: this.triggerKoiFunFact.bind(this), name: "Fun Fact" },
            { cronTime: "05 15 * * *", action: this.triggerWorldNews.bind(this), name: "World News" },
            { cronTime: "08 15 * * *", action: this.triggerWorldNews.bind(this), name: "World News2" },

            //IMAGE PROCESSING ACTIONS
            { cronTime: "11 15 * * 1,2,3,4,5,6,7", action: this.triggerImageProcessingKoi.bind(this), name: "Image Processing" },
            { cronTime: "00 15 * * 7", action: this.triggerImageProcessingOnsen.bind(this), name: "Image Processing" },
            { cronTime: "00 15 * * 7", action: this.triggerImageProcessingReading.bind(this), name: "Image Processing " },
            { cronTime: "01 15 * * 1,5,7", action: this.triggerImageProcessingTameshigiri.bind(this), name: "Image Processing " },
            { cronTime: "00 14 * * 0,7", action: this.triggerImageProcessingWeekend.bind(this), name: "Image Processing)" },
            { cronTime: "42 14 * * 2,3,4", action: this.triggerImageProcessingWork.bind(this), name: "Image Processing" },
            { cronTime: "44 14 * * 5", action: this.triggerImageProcessingYoga.bind(this), name: "Image Processing " },
            { cronTime: "46 14 * * 3", action: this.triggerImageProcessingFood.bind(this), name: "Image Processing" },
            { cronTime: "30 22 * * 6", action: this.triggerImageProcessingNight.bind(this), name: "Image Processing" },
            { cronTime: "45 19 * * 5", action: this.triggerImageProcessingArt.bind(this), name: "Image Processing" },
            { cronTime: "30 16 * * 0", action: this.triggerImageProcessingSkiiing.bind(this), name: "Image Processing" },
            { cronTime: "15 20 * * 3", action: this.triggerImageProcessingTokyo.bind(this), name: "Image Processing" },
            //SUNRISE RITUAL ACTIONS
            { cronTime: "32 15 * * 1,2,3,4,5,7", action: this.triggerStockData.bind(this), name: "Stock Data (Mon-Fri at 7:30 AM CST)" },
            { cronTime: "09 16 * * 1,2,3,4,5,7", action: this.triggerDuneAnalytics.bind(this), name: "Dune Analytics (Mon-Fri at 8:00 AM CST)" },
            { cronTime: "12 16 * * 1,2,3,4,5,7", action: this.triggerSeiAnalytics.bind(this), name: "Sei Analytics (Daily at 9 AM CST)" },
        ];

        for (const { cronTime, action, name } of schedules) {
            const job = cron.schedule(cronTime, async () => {
                elizaLogger.log(`⏰ Running scheduled task: ${name}`);
                try {
                    await action();
                    elizaLogger.log(`✅ Task completed: ${name}`);
                } catch (error) {
                    elizaLogger.error(`🚨 Error in task: ${name}`, error);
                }
            }, { timezone: "America/Mexico_City" }); // ✅ Adjusted to CST (Mexico City)

            this.cronJobs.push(job);
            elizaLogger.log(`✅ Scheduled: ${name} at ${cronTime} CST`);
        }
    }
    //API DATA ACTIONS
    async triggerWorldNews(): Promise<void> {
        elizaLogger.info("triggering world news action");
        try {
            const username =
                this.twitterClient?.client?.twitterConfig?.TWITTER_USERNAME ||
                "Unknown";
            elizaLogger.info("username", username);

            // Prepare the message and state as before
            const message: Memory = {
                userId: this.runtime.agentId,
                agentId: this.runtime.agentId,
                roomId: "00000000-0000-0000-0000-000000000001",
                content: { text: "Triggered by automated polling.", action: "WORLD_NEWS" },
            };

            const state: State = {
                bio: Array.isArray(this.runtime.character.bio)
                    ? this.runtime.character.bio.join(" ")
                    : this.runtime.character.bio || "No bio available",
                lore: Array.isArray(this.runtime.character.lore)
                    ? this.runtime.character.lore.join(" ")
                    : this.runtime.character.lore || "No lore available",
                messageDirections: "Process message",
                postDirections: "Generate posts",
                actors: this.runtime.character.name || "Unknown Actor",
                recentMessages: "Recent messages here",
                recentMessagesData: [],
                roomId: message.roomId,
                agentId: message.agentId,
                userId: message.userId,
            };

            const callback: HandlerCallback = async (
                response: Content
            ): Promise<Memory[]> => {
                if (response.text && this.twitterClient) {
                    try {
                        const tweetContent = response.text;
                        const roomId = message.roomId;
                        const twitterUsername =
                            this.twitterClient.client.twitterConfig
                                .TWITTER_USERNAME;

                        // Post the tweet using the TwitterManager's postTweet method
                        await this.twitterClient.post.postTweet(
                            this.runtime,
                            this.twitterClient.client,
                            tweetContent,
                            roomId,
                            twitterUsername
                        );

                        elizaLogger.log(
                            "✅ World News tweeted successfully:",
                            tweetContent
                        );
                    } catch (error) {
                        elizaLogger.error("🚨 Error posting World News tweet:", error);
                    }
                } else {
                    elizaLogger.warn(
                        "⚠️ No text generated by the World News action or Twitter client is not initialized."
                    );
                }

                return [];
            };

            // Use processActions instead of direct handler call
            await this.runtime.processActions(
                message,
                [message], // responses array with the action set
                state,
                callback
            );
        } catch (error) {
            elizaLogger.error("🚨 Error triggering World News action:", error);
        }
    }
    async triggerKoiFunFact(): Promise<void> {
        elizaLogger.log("Triggering Fun Fact action...");

        try {
            const username =
                this.twitterClient?.client?.twitterConfig?.TWITTER_USERNAME ||
                "Unknown";

            // Find the Fun Fact action
            const action = this.runtime.actions.find(
                (action) => action.name === "FETCH_FUN_FACT"
            );

            if (action?.handler) {
                const message: Memory = {
                    userId: this.runtime.agentId,
                    agentId: this.runtime.agentId,
                    roomId: "00000000-0000-0000-0000-000000000001",
                    content: { text: "Triggered by automated polling." },
                };

                const state: State = {
                    bio: Array.isArray(this.runtime.character.bio)
                        ? this.runtime.character.bio.join(" ")
                        : this.runtime.character.bio || "No bio available",
                    lore: Array.isArray(this.runtime.character.lore)
                        ? this.runtime.character.lore.join(" ")
                        : this.runtime.character.lore || "No lore available",
                    messageDirections: "Process message",
                    postDirections: "Generate posts",
                    actors: this.runtime.character.name || "Unknown Actor",
                    recentMessages: "Recent messages here",
                    recentMessagesData: [],
                    roomId: message.roomId,
                    agentId: message.agentId,
                    userId: message.userId,
                };

                const callback: HandlerCallback = async (
                    response: Content
                ): Promise<Memory[]> => {
                    // elizaLogger.log(
                    //     "Callback triggered with response:",
                    //     response
                    // );

                    if (response.text && this.twitterClient) {
                        try {
                            const tweetContent = response.text;
                            const roomId = message.roomId;
                            const twitterUsername =
                                this.twitterClient.client.twitterConfig
                                    .TWITTER_USERNAME;

                            // Post the tweet using the TwitterManager's postTweet method
                            await this.twitterClient.post.postTweet(
                                this.runtime,
                                this.twitterClient.client,
                                tweetContent,
                                roomId,
                                twitterUsername
                            );

                            elizaLogger.log(
                                "✅ Fun Fact tweeted successfully:",
                                tweetContent
                            );
                        } catch (error) {
                            elizaLogger.error("🚨 Error posting Fun Fact tweet:", error);
                        }
                    } else {
                        elizaLogger.warn(
                            "⚠️ No text generated by the Fun Fact action or Twitter client is not initialized."
                        );
                    }

                    return [];
                };

                const options = {};
                const result = await action.handler(
                    this.runtime,
                    message,
                    state,
                    options,
                    callback
                );

                if (result) {
                    elizaLogger.log("✅ Fun Fact action executed successfully.");
                } else {
                    elizaLogger.warn("⚠️ Fun Fact action failed.");
                }
            }
        } catch (error) {
            elizaLogger.error("🚨 Error triggering Fun Fact action:", error);
        }
    }
    async triggerBusinessNews(): Promise<void> {
        elizaLogger.log("Triggering Business News action...");

        try {
            const action = this.runtime.actions.find(
                (action) => action.name === "BUSINESS_NEWS"
            );

            if (action?.handler) {
                const message: Memory = {
                    userId: this.runtime.agentId,
                    agentId: this.runtime.agentId,
                    roomId: "00000000-0000-0000-0000-000000000001",
                    content: { text: "Triggered by HadrienClient polling." },
                };

                const state: State = {
                    bio: Array.isArray(this.runtime.character.bio)
                        ? this.runtime.character.bio.join(" ")
                        : this.runtime.character.bio || "No bio available",
                    lore: Array.isArray(this.runtime.character.lore)
                        ? this.runtime.character.lore.join(" ")
                        : this.runtime.character.lore || "No lore available",
                    messageDirections: "Process message",
                    postDirections: "Generate posts",
                    actors: this.runtime.character.name || "Unknown Actor",
                    recentMessages: "Recent messages here",
                    recentMessagesData: [],
                    roomId: message.roomId,
                    agentId: message.agentId,
                    userId: message.userId,
                };

                const callback: HandlerCallback = async (
                    response: Content
                ): Promise<Memory[]> => {
                    if (response.text && this.twitterClient) {
                        try {
                            const tweetContent = response.text;
                            const roomId = message.roomId;
                            const twitterUsername =
                                this.twitterClient.client.twitterConfig
                                    .TWITTER_USERNAME;

                            // Post the tweet using the TwitterManager's postTweet method
                            await this.twitterClient.post.postTweet(
                                this.runtime,
                                this.twitterClient.client,
                                tweetContent,
                                roomId,
                                twitterUsername
                            );

                            elizaLogger.log(
                                "Tweet posted successfully:",
                                tweetContent
                            );
                        } catch (error) {
                            elizaLogger.error("Error posting tweet:", error);
                        }
                    } else {
                        elizaLogger.warn(
                            "Either no text was generated by the Business News action or Twitter client is not initialized."
                        );
                    }

                    return [];
                };

                const options = {};
                const result = await action.handler(
                    this.runtime,
                    message,
                    state,
                    options,
                    callback
                );

                if (result) {
                    elizaLogger.log(
                        "Business News action executed successfully."
                    );
                } else {
                    elizaLogger.warn("Business News action failed.");
                }
            } else {
                elizaLogger.warn("Business News action not found.");
            }
        } catch (error) {
            elizaLogger.error("Error triggering Business News action:", error);
        }
    }
    async triggerMeme(): Promise<void> {

        try {
            if (!this.twitterClient) {
                elizaLogger.error("Twitter client is not initialized. Cannot post meme.");
                return;
            }

            const action = this.runtime.actions.find(
                (action) => action.name === "GENERATE_MEME"
            );


            if (action?.handler) {
                const message: Memory = {
                    userId: this.runtime.agentId,
                    agentId: this.runtime.agentId,
                    roomId: "00000000-0000-0000-0000-000000000001",
                    content: { text: `Make a meme about movies.` },

                    // content: { text: `Make a meme about an ${aspectText}.` },
                };
                // elizaLogger.debug("Selected aspect!!!!!!!!!!!!:", aspectText);

                const state: State = {
                    bio: Array.isArray(this.runtime.character.bio)
                        ? this.runtime.character.bio.join(" ")
                        : this.runtime.character.bio || "No bio available",
                    lore: Array.isArray(this.runtime.character.lore)
                        ? this.runtime.character.lore.join(" ")
                        : this.runtime.character.lore || "No lore available",
                    messageDirections: "Process message",
                    postDirections: "Generate posts",
                    actors: this.runtime.character.name || "Unknown Actor",
                    recentMessages: "Recent messages here",
                    recentMessagesData: [],
                    roomId: message.roomId,
                    agentId: message.agentId,
                    userId: message.userId,
                    // memeTopics: this.runtime.character.memeTopics,
                };

                const callback: HandlerCallback = async (response: Content): Promise<Memory[]> => {
                    // elizaLogger.log("Callback triggered with response:", response);

                    if (!response.attachments || response.attachments.length === 0) {
                        elizaLogger.error("No attachments found, skipping tweet.");
                        return [];
                    }

                    const captionText = response.text?.trim() || "";

                    try {
                        // Fetch media data from attachments
                        const mediaData = await fetchMediaData(response.attachments);

                        // elizaLogger.log("Media data retrieved:", mediaData);

                        // Post tweet with media attachments
                        const roomId = message.roomId;
                        const twitterUsername = this.twitterClient.client.twitterConfig.TWITTER_USERNAME;

                        await this.twitterClient.post.postTweet(
                            this.runtime,
                            this.twitterClient.client,
                            captionText,
                            roomId,
                            response.text, // raw tweet content
                            twitterUsername,
                            mediaData // Pass the media attachments
                        );

                        // elizaLogger.log("Octopus meme posted successfully with media attachment.");
                    } catch (error) {
                        elizaLogger.error("Error posting octopus meme:", error);
                    }

                    return [];
                };

                const options = {};
                await action.handler(this.runtime, message, state, options, callback);
            } else {
                elizaLogger.warn("Meme action not found.");
            }
        } catch (error) {
            elizaLogger.error("Error triggering Octopus Meme action:", error);
        }
    }

    //IMAGE PROCESSING ACTIONS

    async triggerImageProcessingKoi(): Promise<void> {
        elizaLogger.log("Triggering Image Processing action...");

        try {
            const action = this.runtime.actions.find(
                (action) => action.name === "PROCESS_IMAGE_KOI"
            );

            if (action?.handler) {
                console.log("action handler found");
                const message: Memory = {
                    userId: this.runtime.agentId,
                    agentId: this.runtime.agentId,
                    roomId: "00000000-0000-0000-0000-000000000001",
                    content: { text: "Triggered by HadrienClient polling." },
                };

                const state: State = {
                    bio: Array.isArray(this.runtime.character.bio)
                        ? this.runtime.character.bio.join(" ")
                        : this.runtime.character.bio || "No bio available",
                    lore: Array.isArray(this.runtime.character.lore)
                        ? this.runtime.character.lore.join(" ")
                        : this.runtime.character.lore || "No lore available",
                    messageDirections: "Process message",
                    postDirections: "Generate posts",
                    actors: this.runtime.character.name || "Unknown Actor",
                    recentMessages: "Recent messages here",
                    recentMessagesData: [],
                    roomId: message.roomId,
                    agentId: message.agentId,
                    userId: message.userId,
                };

                const callback: HandlerCallback = async (
                    response: Content
                ): Promise<Memory[]> => {
                    if (
                        response.text &&
                        response.attachments &&
                        response.attachments[0] &&
                        response.attachments[0].url &&
                        response.attachments[0].description &&
                        response.attachments[0].title &&
                        this.twitterClient
                    ) {
                        const roomId = message.roomId;
                        const twitterUsername =
                            this.twitterClient.client.twitterConfig
                                .TWITTER_USERNAME;

                        const mediaData = await fetchMediaData(response.attachments);

                        const tweetContent = response.attachments[0].description;

                        await this.twitterClient.post.postTweet(
                            this.runtime,
                            this.twitterClient.client,
                            tweetContent,
                            roomId,
                            twitterUsername,
                            tweetContent,
                            mediaData
                        );
                    } else {
                        elizaLogger.warn(
                            "Either no text was generated by the Business News action or Twitter client is not initialized."
                        );
                    }

                    return [];
                };

                const options = {};
                const result = await action.handler(
                    this.runtime,
                    message,
                    state,
                    options,
                    callback
                );

                if (result) {
                    elizaLogger.log("Koi Image processed successfully.");
                } else {
                    elizaLogger.warn("Koi Image processing failed.");
                }
            } else {
                elizaLogger.warn("Koi Image processing action not found.");
            }
        } catch (error) {
            elizaLogger.error(
                "Error triggering Koi Image processing action:",
                error
            );
        }
    }
    async triggerImageProcessingOnsen(): Promise<void> {

        try {
            const action = this.runtime.actions.find(
                (action) => action.name === "PROCESS_IMAGE_ONSEN"
            );

            if (action?.handler) {
                console.log("action handler found");
                const message: Memory = {
                    userId: this.runtime.agentId,
                    agentId: this.runtime.agentId,
                    roomId: "00000000-0000-0000-0000-000000000001",
                    content: { text: "Triggered by HadrienClient polling." },
                };

                const state: State = {
                    bio: Array.isArray(this.runtime.character.bio)
                        ? this.runtime.character.bio.join(" ")
                        : this.runtime.character.bio || "No bio available",
                    lore: Array.isArray(this.runtime.character.lore)
                        ? this.runtime.character.lore.join(" ")
                        : this.runtime.character.lore || "No lore available",
                    messageDirections: "Process message",
                    postDirections: "Generate posts",
                    actors: this.runtime.character.name || "Unknown Actor",
                    recentMessages: "Recent messages here",
                    recentMessagesData: [],
                    roomId: message.roomId,
                    agentId: message.agentId,
                    userId: message.userId,
                };

                const callback: HandlerCallback = async (
                    response: Content
                ): Promise<Memory[]> => {

                    if (
                        response.text &&
                        response.attachments &&
                        response.attachments[0] &&
                        response.attachments[0].url &&
                        response.attachments[0].description &&
                        response.attachments[0].title &&
                        this.twitterClient
                    ) {
                        const roomId = message.roomId;
                        const twitterUsername =
                            this.twitterClient.client.twitterConfig
                                .TWITTER_USERNAME;

                        const mediaData = await fetchMediaData(response.attachments);

                        const tweetContent = response.attachments[0].description;

                        await this.twitterClient.post.postTweet(
                            this.runtime,
                            this.twitterClient.client,
                            tweetContent,
                            roomId,
                            twitterUsername,
                            tweetContent,
                            mediaData
                        );
                    } else {
                        elizaLogger.warn(
                            "Either no text was generated by the Business News action or Twitter client is not initialized."
                        );
                    }

                    return [];
                };

                const options = {};
                const result = await action.handler(
                    this.runtime,
                    message,
                    state,
                    options,
                    callback
                );

                if (result) {
                    elizaLogger.log("Onsen Image processed successfully.");
                } else {
                    elizaLogger.warn("Onsen Image processing failed.");
                }
            } else {
                elizaLogger.warn("Onsen Image processing action not found.");
            }
        } catch (error) {
            elizaLogger.error(
                "Error triggering Onsen Image processing action:",
                error
            );
        }
    }
    async triggerImageProcessingReading(): Promise<void> {

        try {
            const action = this.runtime.actions.find(
                (action) => action.name === "PROCESS_IMAGE_READING"
            );

            if (action?.handler) {
                console.log("action handler found");
                const message: Memory = {
                    userId: this.runtime.agentId,
                    agentId: this.runtime.agentId,
                    roomId: "00000000-0000-0000-0000-000000000001",
                    content: { text: "Triggered by HadrienClient polling." },
                };

                const state: State = {
                    bio: Array.isArray(this.runtime.character.bio)
                        ? this.runtime.character.bio.join(" ")
                        : this.runtime.character.bio || "No bio available",
                    lore: Array.isArray(this.runtime.character.lore)
                        ? this.runtime.character.lore.join(" ")
                        : this.runtime.character.lore || "No lore available",
                    messageDirections: "Process message",
                    postDirections: "Generate posts",
                    actors: this.runtime.character.name || "Unknown Actor",
                    recentMessages: "Recent messages here",
                    recentMessagesData: [],
                    roomId: message.roomId,
                    agentId: message.agentId,
                    userId: message.userId,
                };

                const callback: HandlerCallback = async (
                    response: Content
                ): Promise<Memory[]> => {
                    if (
                        response.text &&
                        response.attachments &&
                        response.attachments[0] &&
                        response.attachments[0].url &&
                        response.attachments[0].description &&
                        response.attachments[0].title &&
                        this.twitterClient
                    ) {
                        const roomId = message.roomId;
                        const twitterUsername =
                            this.twitterClient.client.twitterConfig
                                .TWITTER_USERNAME;

                        const mediaData = await fetchMediaData(response.attachments);

                        const tweetContent = response.attachments[0].description;

                        await this.twitterClient.post.postTweet(
                            this.runtime,
                            this.twitterClient.client,
                            tweetContent,
                            roomId,
                            twitterUsername,
                            tweetContent,
                            mediaData
                        );
                    } else {
                        elizaLogger.warn(
                            "Either no text was generated by the Business News action or Twitter client is not initialized."
                        );
                    }

                    return [];
                };

                const options = {};
                const result = await action.handler(
                    this.runtime,
                    message,
                    state,
                    options,
                    callback
                );

                if (result) {
                    elizaLogger.log("Reading Image processed successfully.");
                } else {
                    elizaLogger.warn("Reading Image processing failed.");
                }
            } else {
                elizaLogger.warn("Reading Image processing action not found.");
            }
        } catch (error) {
            elizaLogger.error(
                "Error triggering Reading Image processing action:",
                error
            );
        }
    }
    async triggerImageProcessingTameshigiri(): Promise<void> {

        try {
            const action = this.runtime.actions.find(
                (action) => action.name === "PROCESS_IMAGE_TAMESHIGIRI"
            );

            if (action?.handler) {
                console.log("action handler found");
                const message: Memory = {
                    userId: this.runtime.agentId,
                    agentId: this.runtime.agentId,
                    roomId: "00000000-0000-0000-0000-000000000001",
                    content: { text: "Triggered by HadrienClient polling." },
                };

                const state: State = {
                    bio: Array.isArray(this.runtime.character.bio)
                        ? this.runtime.character.bio.join(" ")
                        : this.runtime.character.bio || "No bio available",
                    lore: Array.isArray(this.runtime.character.lore)
                        ? this.runtime.character.lore.join(" ")
                        : this.runtime.character.lore || "No lore available",
                    messageDirections: "Process message",
                    postDirections: "Generate posts",
                    actors: this.runtime.character.name || "Unknown Actor",
                    recentMessages: "Recent messages here",
                    recentMessagesData: [],
                    roomId: message.roomId,
                    agentId: message.agentId,
                    userId: message.userId,
                };

                const callback: HandlerCallback = async (
                    response: Content
                ): Promise<Memory[]> => {
                    if (
                        response.text &&
                        response.attachments &&
                        response.attachments[0] &&
                        response.attachments[0].url &&
                        response.attachments[0].description &&
                        response.attachments[0].title &&
                        this.twitterClient
                    ) {
                        const roomId = message.roomId;
                        const twitterUsername =
                            this.twitterClient.client.twitterConfig
                                .TWITTER_USERNAME;

                        const mediaData = await fetchMediaData(response.attachments);

                        const tweetContent = response.attachments[0].description;

                        await this.twitterClient.post.postTweet(
                            this.runtime,
                            this.twitterClient.client,
                            tweetContent,
                            roomId,
                            twitterUsername,
                            tweetContent,
                            mediaData
                        );
                    } else {
                        elizaLogger.warn(
                            "Either no text was generated by the Business News action or Twitter client is not initialized."
                        );
                    }

                    return [];
                };

                const options = {};
                const result = await action.handler(
                    this.runtime,
                    message,
                    state,
                    options,
                    callback
                );

                if (result) {
                    elizaLogger.log("Tameshigiri Image processed successfully.");
                } else {
                    elizaLogger.warn("Tameshigiri Image processing failed.");
                }
            } else {
                elizaLogger.warn("Tameshigiri Image processing action not found.");
            }
        } catch (error) {
            elizaLogger.error(
                "Error triggering Tameshigiri Image processing action:",
                error
            );
        }
    }
    async triggerImageProcessingWeekend(): Promise<void> {

        try {
            const action = this.runtime.actions.find(
                (action) => action.name === "PROCESS_IMAGE_WEEKEND"
            );

            if (action?.handler) {
                console.log("action handler found");
                const message: Memory = {
                    userId: this.runtime.agentId,
                    agentId: this.runtime.agentId,
                    roomId: "00000000-0000-0000-0000-000000000001",
                    content: { text: "Triggered by HadrienClient polling." },
                };

                const state: State = {
                    bio: Array.isArray(this.runtime.character.bio)
                        ? this.runtime.character.bio.join(" ")
                        : this.runtime.character.bio || "No bio available",
                    lore: Array.isArray(this.runtime.character.lore)
                        ? this.runtime.character.lore.join(" ")
                        : this.runtime.character.lore || "No lore available",
                    messageDirections: "Process message",
                    postDirections: "Generate posts",
                    actors: this.runtime.character.name || "Unknown Actor",
                    recentMessages: "Recent messages here",
                    recentMessagesData: [],
                    roomId: message.roomId,
                    agentId: message.agentId,
                    userId: message.userId,
                };

                const callback: HandlerCallback = async (
                    response: Content
                ): Promise<Memory[]> => {

                    if (
                        response.text &&
                        response.attachments &&
                        response.attachments[0] &&
                        response.attachments[0].url &&
                        response.attachments[0].description &&
                        response.attachments[0].title &&
                        this.twitterClient
                    ) {
                        const roomId = message.roomId;
                        const twitterUsername =
                            this.twitterClient.client.twitterConfig
                                .TWITTER_USERNAME;

                        const mediaData = await fetchMediaData(response.attachments);

                        const tweetContent = response.attachments[0].description;

                        await this.twitterClient.post.postTweet(
                            this.runtime,
                            this.twitterClient.client,
                            tweetContent,
                            roomId,
                            twitterUsername,
                            tweetContent,
                            mediaData
                        );
                    } else {
                        elizaLogger.warn(
                            "Either no text was generated by the Business News action or Twitter client is not initialized."
                        );
                    }

                    return [];
                };

                const options = {};
                const result = await action.handler(
                    this.runtime,
                    message,
                    state,
                    options,
                    callback
                );

                if (result) {
                    elizaLogger.log("Weekend Image processed successfully.");
                } else {
                    elizaLogger.warn("Weekend Image processing failed.");
                }
            } else {
                elizaLogger.warn("Weekend Image processing action not found.");
            }
        } catch (error) {
            elizaLogger.error(
                "Error triggering Weekend Image processing action:",
                error
            );
        }
    }
    async triggerImageProcessingWork(): Promise<void> {

        try {
            const action = this.runtime.actions.find(
                (action) => action.name === "PROCESS_IMAGE_WORK"
            );

            if (action?.handler) {
                console.log("action handler found");
                const message: Memory = {
                    userId: this.runtime.agentId,
                    agentId: this.runtime.agentId,
                    roomId: "00000000-0000-0000-0000-000000000001",
                    content: { text: "Triggered by HadrienClient polling." },
                };

                const state: State = {
                    bio: Array.isArray(this.runtime.character.bio)
                        ? this.runtime.character.bio.join(" ")
                        : this.runtime.character.bio || "No bio available",
                    lore: Array.isArray(this.runtime.character.lore)
                        ? this.runtime.character.lore.join(" ")
                        : this.runtime.character.lore || "No lore available",
                    messageDirections: "Process message",
                    postDirections: "Generate posts",
                    actors: this.runtime.character.name || "Unknown Actor",
                    recentMessages: "Recent messages here",
                    recentMessagesData: [],
                    roomId: message.roomId,
                    agentId: message.agentId,
                    userId: message.userId,
                };

                const callback: HandlerCallback = async (
                    response: Content
                ): Promise<Memory[]> => {
                    if (
                        response.text &&
                        response.attachments &&
                        response.attachments[0] &&
                        response.attachments[0].url &&
                        response.attachments[0].description &&
                        response.attachments[0].title &&
                        this.twitterClient
                    ) {
                        const roomId = message.roomId;
                        const twitterUsername =
                            this.twitterClient.client.twitterConfig
                                .TWITTER_USERNAME;

                        const mediaData = await fetchMediaData(response.attachments);

                        const tweetContent = response.attachments[0].description;

                        await this.twitterClient.post.postTweet(
                            this.runtime,
                            this.twitterClient.client,
                            tweetContent,
                            roomId,
                            twitterUsername,
                            tweetContent,
                            mediaData
                        );
                    } else {
                        elizaLogger.warn(
                            "Either no text was generated by the Business News action or Twitter client is not initialized."
                        );
                    }

                    return [];
                };

                const options = {};
                const result = await action.handler(
                    this.runtime,
                    message,
                    state,
                    options,
                    callback
                );

                if (result) {
                    elizaLogger.log("Work Image processed successfully.");
                } else {
                    elizaLogger.warn("Work Image processing failed.");
                }
            } else {
                elizaLogger.warn("Work Image processing action not found.");
            }
        } catch (error) {
            elizaLogger.error(
                "Error triggering Work Image processing action:",
                error
            );
        }
    }
    async triggerImageProcessingYoga(): Promise<void> {

        try {
            const action = this.runtime.actions.find(
                (action) => action.name === "PROCESS_IMAGE_YOGA"
            );

            if (action?.handler) {
                console.log("action handler found");
                const message: Memory = {
                    userId: this.runtime.agentId,
                    agentId: this.runtime.agentId,
                    roomId: "00000000-0000-0000-0000-000000000001",
                    content: { text: "Triggered by HadrienClient polling." },
                };

                const state: State = {
                    bio: Array.isArray(this.runtime.character.bio)
                        ? this.runtime.character.bio.join(" ")
                        : this.runtime.character.bio || "No bio available",
                    lore: Array.isArray(this.runtime.character.lore)
                        ? this.runtime.character.lore.join(" ")
                        : this.runtime.character.lore || "No lore available",
                    messageDirections: "Process message",
                    postDirections: "Generate posts",
                    actors: this.runtime.character.name || "Unknown Actor",
                    recentMessages: "Recent messages here",
                    recentMessagesData: [],
                    roomId: message.roomId,
                    agentId: message.agentId,
                    userId: message.userId,
                };

                const callback: HandlerCallback = async (
                    response: Content
                ): Promise<Memory[]> => {
                    if (
                        response.text &&
                        response.attachments &&
                        response.attachments[0] &&
                        response.attachments[0].url &&
                        response.attachments[0].description &&
                        response.attachments[0].title &&
                        this.twitterClient
                    ) {
                        const roomId = message.roomId;
                        const twitterUsername =
                            this.twitterClient.client.twitterConfig
                                .TWITTER_USERNAME;

                        const mediaData = await fetchMediaData(response.attachments);

                        const tweetContent = response.attachments[0].description;

                        await this.twitterClient.post.postTweet(
                            this.runtime,
                            this.twitterClient.client,
                            tweetContent,
                            roomId,
                            twitterUsername,
                            tweetContent,
                            mediaData
                        );
                    } else {
                        elizaLogger.warn(
                            "Either no text was generated by the Business News action or Twitter client is not initialized."
                        );
                    }

                    return [];
                };

                const options = {};
                const result = await action.handler(
                    this.runtime,
                    message,
                    state,
                    options,
                    callback
                );

                if (result) {
                    elizaLogger.log("Yoga Image processed successfully.");
                } else {
                    elizaLogger.warn("Yoga Image processing failed.");
                }
            } else {
                elizaLogger.warn("Yoga Image processing action not found.");
            }
        } catch (error) {
            elizaLogger.error(
                "Error triggering Yoga Image processing action:",
                error
            );
        }
    }
    async triggerImageProcessingFood(): Promise<void> {

        try {
            const action = this.runtime.actions.find(
                (action) => action.name === "PROCESS_IMAGE_FOOD"
            );

            if (action?.handler) {
                console.log("action handler found");
                const message: Memory = {
                    userId: this.runtime.agentId,
                    agentId: this.runtime.agentId,
                    roomId: "00000000-0000-0000-0000-000000000001",
                    content: { text: "Triggered by HadrienClient polling." },
                };

                const state: State = {
                    bio: Array.isArray(this.runtime.character.bio)
                        ? this.runtime.character.bio.join(" ")
                        : this.runtime.character.bio || "No bio available",
                    lore: Array.isArray(this.runtime.character.lore)
                        ? this.runtime.character.lore.join(" ")
                        : this.runtime.character.lore || "No lore available",
                    messageDirections: "Process message",
                    postDirections: "Generate posts",
                    actors: this.runtime.character.name || "Unknown Actor",
                    recentMessages: "Recent messages here",
                    recentMessagesData: [],
                    roomId: message.roomId,
                    agentId: message.agentId,
                    userId: message.userId,
                };

                const callback: HandlerCallback = async (
                    response: Content
                ): Promise<Memory[]> => {

                    if (
                        response.text &&
                        response.attachments &&
                        response.attachments[0] &&
                        response.attachments[0].url &&
                        response.attachments[0].description &&
                        response.attachments[0].title &&
                        this.twitterClient
                    ) {
                        const roomId = message.roomId;
                        const twitterUsername =
                            this.twitterClient.client.twitterConfig
                                .TWITTER_USERNAME;

                        const mediaData = await fetchMediaData(response.attachments);

                        const tweetContent = response.attachments[0].description;

                        await this.twitterClient.post.postTweet(
                            this.runtime,
                            this.twitterClient.client,
                            tweetContent,
                            roomId,
                            twitterUsername,
                            tweetContent,
                            mediaData
                        );
                    } else {
                        elizaLogger.warn(
                            "Either no text was generated by the Business News action or Twitter client is not initialized."
                        );
                    }

                    return [];
                };

                const options = {};
                const result = await action.handler(
                    this.runtime,
                    message,
                    state,
                    options,
                    callback
                );

                if (result) {
                    elizaLogger.log("Food Image processed successfully.");
                } else {
                    elizaLogger.warn("Food Image processing failed.");
                }
            } else {
                elizaLogger.warn("Food Image processing action not found.");
            }
        } catch (error) {
            elizaLogger.error(
                "Error triggering Food Image processing action:",
                error
            );
        }
    }
    async triggerImageProcessingNight(): Promise<void> {
        try {
            const action = this.runtime.actions.find(
                (action) => action.name === "PROCESS_IMAGE_NIGHT"
            );

            if (action?.handler) {
                console.log("action handler found");
                const message: Memory = {
                    userId: this.runtime.agentId,
                    agentId: this.runtime.agentId,
                    roomId: "00000000-0000-0000-0000-000000000001",
                    content: { text: "Triggered by HadrienClient polling." },
                };

                const state: State = {
                    bio: Array.isArray(this.runtime.character.bio)
                        ? this.runtime.character.bio.join(" ")
                        : this.runtime.character.bio || "No bio available",
                    lore: Array.isArray(this.runtime.character.lore)
                        ? this.runtime.character.lore.join(" ")
                        : this.runtime.character.lore || "No lore available",
                    messageDirections: "Process message",
                    postDirections: "Generate posts",
                    actors: this.runtime.character.name || "Unknown Actor",
                    recentMessages: "Recent messages here",
                    recentMessagesData: [],
                    roomId: message.roomId,
                    agentId: message.agentId,
                    userId: message.userId,
                };

                const callback: HandlerCallback = async (
                    response: Content
                ): Promise<Memory[]> => {

                    if (
                        response.text &&
                        response.attachments &&
                        response.attachments[0] &&
                        response.attachments[0].url &&
                        response.attachments[0].description &&
                        response.attachments[0].title &&
                        this.twitterClient
                    ) {
                        const roomId = message.roomId;
                        const twitterUsername =
                            this.twitterClient.client.twitterConfig
                                .TWITTER_USERNAME;

                        const mediaData = await fetchMediaData(response.attachments);

                        const tweetContent = response.attachments[0].description;

                        await this.twitterClient.post.postTweet(
                            this.runtime,
                            this.twitterClient.client,
                            tweetContent,
                            roomId,
                            twitterUsername,
                            tweetContent,
                            mediaData
                        );
                    } else {
                        elizaLogger.warn(
                            "Either no text was generated by the Business News action or Twitter client is not initialized."
                        );
                    }

                    return [];
                };

                const options = {};
                const result = await action.handler(
                    this.runtime,
                    message,
                    state,
                    options,
                    callback
                );

                if (result) {
                    elizaLogger.log("Night Image processed successfully.");
                } else {
                    elizaLogger.warn("Night Image processing failed.");
                }
            } else {
                elizaLogger.warn("Night Image processing action not found.");
            }
        } catch (error) {
            elizaLogger.error(
                "Error triggering Night Image processing action:",
                error
            );
        }
    }
    async triggerImageProcessingArt(): Promise<void> {

        try {
            const action = this.runtime.actions.find(
                (action) => action.name === "PROCESS_IMAGE_ART"
            );

            if (action?.handler) {
                console.log("action handler found");
                const message: Memory = {
                    userId: this.runtime.agentId,
                    agentId: this.runtime.agentId,
                    roomId: "00000000-0000-0000-0000-000000000001",
                    content: { text: "Triggered by HadrienClient polling." },
                };

                const state: State = {
                    bio: Array.isArray(this.runtime.character.bio)
                        ? this.runtime.character.bio.join(" ")
                        : this.runtime.character.bio || "No bio available",
                    lore: Array.isArray(this.runtime.character.lore)
                        ? this.runtime.character.lore.join(" ")
                        : this.runtime.character.lore || "No lore available",
                    messageDirections: "Process message",
                    postDirections: "Generate posts",
                    actors: this.runtime.character.name || "Unknown Actor",
                    recentMessages: "Recent messages here",
                    recentMessagesData: [],
                    roomId: message.roomId,
                    agentId: message.agentId,
                    userId: message.userId,
                };

                const callback: HandlerCallback = async (
                    response: Content
                ): Promise<Memory[]> => {

                    if (
                        response.text &&
                        response.attachments &&
                        response.attachments[0] &&
                        response.attachments[0].url &&
                        response.attachments[0].description &&
                        response.attachments[0].title &&
                        this.twitterClient
                    ) {
                        const roomId = message.roomId;
                        const twitterUsername =
                            this.twitterClient.client.twitterConfig
                                .TWITTER_USERNAME;

                        const mediaData = await fetchMediaData(response.attachments);

                        const tweetContent = response.attachments[0].description;

                        await this.twitterClient.post.postTweet(
                            this.runtime,
                            this.twitterClient.client,
                            tweetContent,
                            roomId,
                            twitterUsername,
                            tweetContent,
                            mediaData
                        );
                    } else {
                        elizaLogger.warn(
                            "Either no text was generated by the Business News action or Twitter client is not initialized."
                        );
                    }

                    return [];
                };

                const options = {};
                const result = await action.handler(
                    this.runtime,
                    message,
                    state,
                    options,
                    callback
                );

                if (result) {
                    elizaLogger.log("Art Image processed successfully.");
                } else {
                    elizaLogger.warn("Art Image processing failed.");
                }
            } else {
                elizaLogger.warn("Art Image processing action not found.");
            }
        } catch (error) {
            elizaLogger.error(
                "Error triggering Art Image processing action:",
                error
            );
        }
    }
    async triggerImageProcessingSkiiing(): Promise<void> {

        try {
            const action = this.runtime.actions.find(
                (action) => action.name === "PROCESS_IMAGE_SKIIING"
            );

            if (action?.handler) {
                console.log("action handler found");
                const message: Memory = {
                    userId: this.runtime.agentId,
                    agentId: this.runtime.agentId,
                    roomId: "00000000-0000-0000-0000-000000000001",
                    content: { text: "Triggered by HadrienClient polling." },
                };

                const state: State = {
                    bio: Array.isArray(this.runtime.character.bio)
                        ? this.runtime.character.bio.join(" ")
                        : this.runtime.character.bio || "No bio available",
                    lore: Array.isArray(this.runtime.character.lore)
                        ? this.runtime.character.lore.join(" ")
                        : this.runtime.character.lore || "No lore available",
                    messageDirections: "Process message",
                    postDirections: "Generate posts",
                    actors: this.runtime.character.name || "Unknown Actor",
                    recentMessages: "Recent messages here",
                    recentMessagesData: [],
                    roomId: message.roomId,
                    agentId: message.agentId,
                    userId: message.userId,
                };

                const callback: HandlerCallback = async (
                    response: Content
                ): Promise<Memory[]> => {

                    if (
                        response.text &&
                        response.attachments &&
                        response.attachments[0] &&
                        response.attachments[0].url &&
                        response.attachments[0].description &&
                        response.attachments[0].title &&
                        this.twitterClient
                    ) {
                        const roomId = message.roomId;
                        const twitterUsername =
                            this.twitterClient.client.twitterConfig
                                .TWITTER_USERNAME;

                        const mediaData = await fetchMediaData(response.attachments);

                        const tweetContent = response.attachments[0].description;

                        await this.twitterClient.post.postTweet(
                            this.runtime,
                            this.twitterClient.client,
                            tweetContent,
                            roomId,
                            twitterUsername,
                            tweetContent,
                            mediaData
                        );
                    } else {
                        elizaLogger.warn(
                            "Either no text was generated by the Business News action or Twitter client is not initialized."
                        );
                    }

                    return [];
                };

                const options = {};
                const result = await action.handler(
                    this.runtime,
                    message,
                    state,
                    options,
                    callback
                );

                if (result) {
                    elizaLogger.log("Skiiing Image processed successfully.");
                } else {
                    elizaLogger.warn("Skiiing Image processing failed.");
                }
            } else {
                elizaLogger.warn("Skiiing Image processing action not found.");
            }
        } catch (error) {
            elizaLogger.error(
                "Error triggering Skiiing Image processing action:",
                error
            );
        }
    }
    async triggerImageProcessingTokyo(): Promise<void> {

        try {
            const action = this.runtime.actions.find(
                (action) => action.name === "PROCESS_IMAGE_TOKYO"
            );

            if (action?.handler) {
                console.log("action handler found");
                const message: Memory = {
                    userId: this.runtime.agentId,
                    agentId: this.runtime.agentId,
                    roomId: "00000000-0000-0000-0000-000000000001",
                    content: { text: "Triggered by HadrienClient polling." },
                };

                const state: State = {
                    bio: Array.isArray(this.runtime.character.bio)
                        ? this.runtime.character.bio.join(" ")
                        : this.runtime.character.bio || "No bio available",
                    lore: Array.isArray(this.runtime.character.lore)
                        ? this.runtime.character.lore.join(" ")
                        : this.runtime.character.lore || "No lore available",
                    messageDirections: "Process message",
                    postDirections: "Generate posts",
                    actors: this.runtime.character.name || "Unknown Actor",
                    recentMessages: "Recent messages here",
                    recentMessagesData: [],
                    roomId: message.roomId,
                    agentId: message.agentId,
                    userId: message.userId,
                };

                const callback: HandlerCallback = async (
                    response: Content
                ): Promise<Memory[]> => {
                    if (
                        response.text &&
                        response.attachments &&
                        response.attachments[0] &&
                        response.attachments[0].url &&
                        response.attachments[0].description &&
                        response.attachments[0].title &&
                        this.twitterClient
                    ) {
                        const roomId = message.roomId;
                        const twitterUsername =
                            this.twitterClient.client.twitterConfig
                                .TWITTER_USERNAME;

                        const mediaData = await fetchMediaData(response.attachments);

                        const tweetContent = response.attachments[0].description;

                        await this.twitterClient.post.postTweet(
                            this.runtime,
                            this.twitterClient.client,
                            tweetContent,
                            roomId,
                            twitterUsername,
                            tweetContent,
                            mediaData
                        );
                    } else {
                        elizaLogger.warn(
                            "Either no text was generated by the Business News action or Twitter client is not initialized."
                        );
                    }

                    return [];
                };

                const options = {};
                const result = await action.handler(
                    this.runtime,
                    message,
                    state,
                    options,
                    callback
                );

                if (result) {
                    elizaLogger.log("Tokyo Image processed successfully.");
                } else {
                    elizaLogger.warn("Tokyo Image processing failed.");
                }
            } else {
                elizaLogger.warn("Tokyo Image processing action not found.");
            }
        } catch (error) {
            elizaLogger.error(
                "Error triggering Tokyo Image processing action:",
                error
            );
        }
    }

    async triggerDuneAnalytics(): Promise<void> {
        elizaLogger.log("🔍 Searching for getCryptoAnalysis action...");

        const action = this.runtime.actions.find(
            (action) => action.name === "getCryptoAnalysis"
        );

        if (action?.handler) {
            const message: Memory = {
                userId: this.runtime.agentId,
                agentId: this.runtime.agentId,
                roomId: "00000000-0000-0000-0000-000000000001",
                content: { text: "Triggered by HadrienClient polling." },
            };

            const state: State = {
                bio: Array.isArray(this.runtime.character.bio)
                    ? this.runtime.character.bio.join(" ")
                    : this.runtime.character.bio || "No bio available",
                lore: Array.isArray(this.runtime.character.lore)
                    ? this.runtime.character.lore.join(" ")
                    : this.runtime.character.lore || "No lore available",
                messageDirections: "Process message",
                postDirections: "Generate posts",
                actors: this.runtime.character.name || "Unknown Actor",
                recentMessages: "Recent messages here",
                recentMessagesData: [],
                roomId: message.roomId,
                agentId: message.agentId,
                userId: message.userId,
                // Hardcoding this to trigger action processing.
                symbol: "SEI",
            };

            const callback: HandlerCallback = async (response: Content): Promise<Memory[]> => {

                if (
                    response.text
                ) {
                    const roomId = message.roomId;
                    const twitterUsername =
                        this.twitterClient.client.twitterConfig
                            .TWITTER_USERNAME;

                    const tweetContent = response.text;
                    const mediaData = await fetchMediaData(response.attachments);

                    await this.twitterClient.post.postTweet(
                        this.runtime,
                        this.twitterClient.client,
                        tweetContent,
                        roomId,
                        twitterUsername,
                        tweetContent,
                        mediaData
                    );
                } else {
                    elizaLogger.warn(
                        "Either no text was generated by the Dune Analytics action or Twitter client is not initialized."
                    );
                }

                return [];
            };

            const options = {};
            const result = await action.handler(this.runtime, message, state, options, callback);

            if (result) {
                elizaLogger.log("✅ Dune Analytics action executed successfully.");
            } else {
                elizaLogger.warn("⚠️ Dune Analytics action failed.");
            }
        } else {
            elizaLogger.warn("❌ Dune Analytics action not found. Available actions:", this.runtime.actions.map(a => a.name));
        }
    }
    async triggerStockData(): Promise<void> {
        const action = this.runtime.actions.find(
            (action) => action.name === "STOCK_DATA"  // Updated to match the name in the action
        );

        if (!action?.handler) {
            elizaLogger.warn("Stock Data action not found.");
            return;
        }

        elizaLogger.log("Triggering Stock Data action...");

        const message: Memory = {
            userId: this.runtime.agentId,
            agentId: this.runtime.agentId,
            roomId: "00000000-0000-0000-0000-000000000001",
            content: { text: "Triggered by HadrienClient polling." },
        };

        const state: State = {
            bio: Array.isArray(this.runtime.character.bio)
                ? this.runtime.character.bio.join(" ")
                : this.runtime.character.bio || "No bio available",
            lore: Array.isArray(this.runtime.character.lore)
                ? this.runtime.character.lore.join(" ")
                : this.runtime.character.lore || "No lore available",
            messageDirections: "Process message",
            postDirections: "Generate posts",
            actors: this.runtime.character.name || "Unknown Actor",
            recentMessages: "Recent messages here",
            recentMessagesData: [],
            roomId: message.roomId,
            agentId: message.agentId,
            userId: message.userId,
        };

        const callback: HandlerCallback = async (response: Content): Promise<Memory[]> => {

            if (response.text && this.twitterClient) {
                try {
                    const roomId = message.roomId;
                    const twitterUsername =
                        this.twitterClient.client.twitterConfig
                            .TWITTER_USERNAME;

                    // Decision logic - you can add conditions here to decide whether to post
                    const shouldPost = true; // Example condition - could be based on time, content quality, etc.
                    const mediaData = await fetchMediaData(response.attachments);

                    if (shouldPost) {
                        await this.twitterClient.post.postTweet(
                            this.runtime,
                            this.twitterClient.client,
                            response.text,
                            roomId,
                            twitterUsername,
                            response.text,
                            mediaData
                        );
                    } else {
                        elizaLogger.log("Decided not to post stock data to Twitter");
                    }
                } catch (error) {
                    elizaLogger.error("Error posting stock data tweet:", error);
                }
            } else {
                elizaLogger.warn("No text was generated by the Stock Data action or Twitter client is not initialized.");
            }
            return [];
        };

        const options = {};
        await action.handler(this.runtime, message, state, options, callback);
    }
    async triggerSeiAnalytics(): Promise<void> {
        const action = this.runtime.actions.find(
            (action) => action.name === "getSeiAnalysis"
        );

        if (action?.handler) {
            console.log("ACTION HANDLER FOUND");
            const message: Memory = {
                userId: this.runtime.agentId,
                agentId: this.runtime.agentId,
                roomId: "00000000-0000-0000-0000-000000000001",
                content: { text: "Triggered by HadrienClient polling." },
            };

            const state: State = {
                bio: Array.isArray(this.runtime.character.bio)
                    ? this.runtime.character.bio.join(" ")
                    : this.runtime.character.bio || "No bio available",
                lore: Array.isArray(this.runtime.character.lore)
                    ? this.runtime.character.lore.join(" ")
                    : this.runtime.character.lore || "No lore available",
                messageDirections: "Process message",
                postDirections: "Generate posts",
                actors: this.runtime.character.name || "Unknown Actor",
                recentMessages: "Recent messages here",
                recentMessagesData: [],
                roomId: message.roomId,
                agentId: message.agentId,
                userId: message.userId,
                // Hardcoding this to trigger action processing.
                symbol: "SEI",
            };

            const callback: HandlerCallback = async (response: Content): Promise<Memory[]> => {
                if (
                    response.text
                ) {
                    const roomId = message.roomId;
                    const twitterUsername =
                        this.twitterClient.client.twitterConfig
                            .TWITTER_USERNAME;

                    const tweetContent = response.text;

                    await this.twitterClient.post.postTweet(
                        this.runtime,
                        this.twitterClient.client,
                        tweetContent,
                        roomId,
                        twitterUsername,
                        tweetContent,
                        // mediaData
                    );
                } else {
                    elizaLogger.warn(
                        "Either no text was generated by the Sei action or Twitter client is not initialized."
                    );
                }
                return [];
            };

            const options = {};
            await action.handler(this.runtime, message, state, options, callback);
        } else {
            elizaLogger.warn("Sei Analytics action not found.");
        }
    }
    async triggerSeiProviderAction(): Promise<void> {
        elizaLogger.log("Triggering SEI Provider action...");

        try {
            const action = this.runtime.actions.find((action) => action.name === "SEIACTION");

            if (!action?.handler) {
                elizaLogger.warn("SEI Provider action not found.");
                return;
            }

            const message: Memory = {
                userId: this.runtime.agentId,
                agentId: this.runtime.agentId,
                roomId: "00000000-0000-0000-0000-000000000001",
                content: { text: "Triggered by automated polling for SEI price." },
            };

            const state: State = {
                bio: Array.isArray(this.runtime.character.bio)
                    ? this.runtime.character.bio.join(" ")
                    : this.runtime.character.bio || "No bio available",
                lore: Array.isArray(this.runtime.character.lore)
                    ? this.runtime.character.lore.join(" ")
                    : this.runtime.character.lore || "No lore available",
                messageDirections: "Process message",
                postDirections: "Generate posts",
                actors: this.runtime.character.name || "Unknown Actor",
                recentMessages: "Recent messages here",
                recentMessagesData: [],
                roomId: message.roomId,
                agentId: message.agentId,
                userId: message.userId,
            };

            const callback: HandlerCallback = async (response: Content): Promise<Memory[]> => {
                elizaLogger.log("Callback triggered with SEI Price response:", response);

                if (response.text && this.twitterClient) {
                    try {
                        const roomId = message.roomId;
                        const twitterUsername = this.twitterClient.client.twitterConfig.TWITTER_USERNAME;

                        await this.twitterClient.post.postTweet(
                            this.runtime,
                            this.twitterClient.client,
                            response.text,
                            roomId,
                            twitterUsername
                        );

                        elizaLogger.log("✅ SEI Price tweeted successfully:", response.text);
                    } catch (error) {
                        elizaLogger.error("🚨 Error posting SEI Price tweet:", error);
                    }
                } else {
                    elizaLogger.warn("⚠️ No text generated by the SEI Price action or Twitter client is not initialized.");
                }
                return [];
            };

            const options = {};
            const result = await action.handler(this.runtime, message, state, options, callback);

            if (result) {
                elizaLogger.log("✅ SEI Provider action executed successfully.");
            } else {
                elizaLogger.warn("⚠️ SEI Provider action failed.");
            }
        } catch (error) {
            elizaLogger.error("🚨 Error triggering SEI Provider action:", error);
        }
    }

    async start(): Promise<void> {
        if (!this.runtime.clients) {
            this.runtime.clients = {};
        }

        await this.scheduleTasks();
        elizaLogger.info("HadrienClient started and polling initialized.");
    }

    async stop(): Promise<void> {
        if (this.timer) {
            clearInterval(this.timer);
            this.timer = null;
        }
        elizaLogger.log("HadrienClient stopped.");
    }
}
