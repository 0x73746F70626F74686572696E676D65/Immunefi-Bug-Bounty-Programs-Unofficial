import { composeContext, embed } from "@elizaos/core";
import { generateObjectArray } from "@elizaos/core";
import {
    type ActionExample,
    type IAgentRuntime,
    type Memory,
    ModelClass,
    type Evaluator,
} from "@elizaos/core";

// Template for prompting the LLM to classify emotion
const emotionTemplate = `
TASK: Analyze the emotional tone of the provided text and classify it as positive, negative, or neutral.

# EXAMPLES
Example 1:
Text: "I’m so excited about this!"
Output:
\`\`\`json
[{"emotion": "positive"}]
\`\`\`

Example 2:
Text: "This is absolutely terrible."
Output:
\`\`\`json
[{"emotion": "negative"}]
\`\`\`

Example 3:
Text: "The event is happening tomorrow."
Output:
\`\`\`json
[{"emotion": "neutral"}]
\`\`\`
# END OF EXAMPLES

# INSTRUCTIONS
- Classify the emotional tone of the following text.
- Respond with a JSON array containing a single object with the emotion type.

Text to analyze:
{{inputText}}

Response should be a JSON array with a single object inside a JSON markdown block. Correct response format:
\`\`\`json
[{"emotion": "positive" | "negative" | "neutral"}]
\`\`\`
`;

// Handler function to process the message and determine response action
async function emotionHandler(runtime: IAgentRuntime, message: Memory) {
    // Compose the initial state from the message
    const state = await runtime.composeState(message);
    
    // Add the input text to the state for the template
    state.inputText = message.content.text;
    
    // Generate the context by filling the template with state values
    const context = composeContext({
        state,
        template: emotionTemplate,
    });

    // Query the LLM to get the emotion classification
    const emotionResponse = await generateObjectArray({
        runtime,
        context,
        modelClass: ModelClass.LARGE,
    });

    // Handle case where LLM response is invalid or empty
    if (!emotionResponse || emotionResponse.length === 0) {
        return { shouldRespond: false, emotion: "unknown" };
    }

    // Extract the emotion and decide if the agent should respond
    const emotion = emotionResponse[0].emotion.toLowerCase();
    const shouldRespond = emotion === "positive" || emotion === "neutral";
    
    return { shouldRespond, emotion };
}

// The emotion evaluator object
export const emotionEvaluator: Evaluator = {
    name: "ASSESS_EMOTION",
    similes: [
        "CHECK_EMOTION",
        "ANALYZE_TONE",
        "EVALUATE_SENTIMENT",
    ],
    validate: async () => true,
    description: "Analyze the emotional tone of a Twitter interaction and decide whether the agent should respond based on the emotion.",
    handler: emotionHandler,
    examples: [
        {
            context: "Emotional analysis of a Twitter interaction",
            messages: [
                {
                    user: "twitterUser",
                    content: { text: "I love your product!" }
                }
            ] as ActionExample[],
            outcome: `\`\`\`json\n[{"emotion": "positive"}]\n\`\`\``
        },
        {
            context: "Emotional analysis of a Twitter interaction",
            messages: [
                {
                    user: "twitterUser",
                    content: { text: "This service is awful!" }
                }
            ] as ActionExample[],
            outcome: `\`\`\`json\n[{"emotion": "negative"}]\n\`\`\``
        },
        {
            context: "Emotional analysis of a Twitter interaction",
            messages: [
                {
                    user: "twitterUser",
                    content: { text: "The update is out today." }
                }
            ] as ActionExample[],
            outcome: `\`\`\`json\n[{"emotion": "neutral"}]\n\`\`\``
        }
    ],
};