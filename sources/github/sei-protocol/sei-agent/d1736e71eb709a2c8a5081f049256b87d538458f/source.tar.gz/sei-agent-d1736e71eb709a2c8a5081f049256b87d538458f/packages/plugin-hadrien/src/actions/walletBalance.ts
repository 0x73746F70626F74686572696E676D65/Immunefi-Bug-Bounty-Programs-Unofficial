import {
    elizaLogger,
    type Action,
    type HandlerCallback,
    type IAgentRuntime,
    type Memory,
    type State,
    type ActionExample,
} from "@elizaos/core";
import {
    createPublicClient,
    createWalletClient,
    formatUnits,
    http,
} from "viem";
import { privateKeyToAccount } from "viem/accounts";
import * as viemChains from "viem/chains";
import NodeCache from "node-cache";
import * as path from "node:path";

// SEI Chain definitions
const seiChains = {
    "mainnet": viemChains.sei,
    "testnet": viemChains.seiTestnet,
    "devnet": viemChains.seiDevnet,
};

interface ChainWithName {
    name: string;
    chain: any;
}

class WalletProvider {
    private cache: NodeCache;
    private cacheKey = "evm/wallet";
    private currentChain: ChainWithName;
    private CACHE_EXPIRY_SEC = 5;
    account: any;

    constructor(
        accountOrPrivateKey: any | `0x${string}`,
        private cacheManager: any,
        chain: ChainWithName,
    ) {
        this.setAccount(accountOrPrivateKey);
        this.setCurrentChain(chain);
        this.cache = new NodeCache({ stdTTL: this.CACHE_EXPIRY_SEC });
    }

    getAddress(): string {
        return this.account.address;
    }

    getCurrentChain(): ChainWithName {
        return this.currentChain;
    }

    getPublicClient(): any {
        const transport = this.createHttpTransport();
        return createPublicClient({
            chain: this.currentChain.chain,
            transport,
        });
    }

    async getWalletBalance(): Promise<string | null> {
        const cacheKey = `seiWalletBalance_${this.currentChain.name}`;
        const cachedData = await this.getCachedData<string>(cacheKey);
        if (cachedData) {
            elizaLogger.log(
                `Returning cached wallet balance for sei chain: ${this.currentChain.name}`
            );
            return cachedData;
        }

        try {
            const client = this.getPublicClient();
            const balance = await client.getBalance({
                address: this.account.address,
            });
            const balanceFormatted = formatUnits(balance, 18);
            this.setCachedData<string>(cacheKey, balanceFormatted);
            elizaLogger.log(
                "Wallet balance cached for chain: ",
                this.currentChain.name
            );
            return balanceFormatted;
        } catch (error) {
            console.error("Error getting wallet balance:", error);
            return null;
        }
    }

    private async readFromCache<T>(key: string): Promise<T | null> {
        const cached = await this.cacheManager.get<T>(
            path.join(this.cacheKey, key)
        );
        return cached ?? null;
    }

    private async writeToCache<T>(key: string, data: T): Promise<void> {
        await this.cacheManager.set(path.join(this.cacheKey, key), data, {
            expires: Date.now() + this.CACHE_EXPIRY_SEC * 1000,
        });
    }

    private async getCachedData<T>(key: string): Promise<T | null> {
        // Check in-memory cache first
        const cachedData = this.cache.get<T>(key);
        if (cachedData) {
            return cachedData;
        }

        // Check file-based cache
        const fileCachedData = await this.readFromCache<T>(key);
        if (fileCachedData) {
            // Populate in-memory cache
            this.cache.set(key, fileCachedData);
            return fileCachedData;
        }

        return null;
    }

    private async setCachedData<T>(cacheKey: string, data: T): Promise<void> {
        // Set in-memory cache
        this.cache.set(cacheKey, data);
        // Write to file-based cache
        await this.writeToCache(cacheKey, data);
    }

    private setAccount = (accountOrPrivateKey: any | `0x${string}`) => {
        if (typeof accountOrPrivateKey === "string") {
            this.account = privateKeyToAccount(accountOrPrivateKey);
        } else {
            this.account = accountOrPrivateKey;
        }
    };

    private setCurrentChain = (chain: ChainWithName) => {
        this.currentChain = chain;
    };

    private createHttpTransport = () => {
        const chain = this.currentChain.chain;
        if (chain.rpcUrls.custom) {
            return http(chain.rpcUrls.custom.http[0]);
        }
        return http(chain.rpcUrls.default.http[0]);
    };

    static genSeiChainFromName(
        chainName: string,
        customRpcUrl?: string | null
    ): any {
        const baseChain = seiChains[chainName];
        if (!baseChain?.id) {
            throw new Error("Invalid chain name");
        }

        const seiChain: any = customRpcUrl
            ? {
                  ...baseChain,
                  rpcUrls: {
                      ...baseChain.rpcUrls,
                      custom: {
                          http: [customRpcUrl],
                      },
                  },
              }
            : baseChain;

        return seiChain;
    }
}

const genChainFromRuntime = (runtime: IAgentRuntime): ChainWithName => {
    const sei_network = runtime.getSetting("SEI_NETWORK");
    if (typeof sei_network !== "string") {
        throw new Error("SEI_NETWORK must be a string");
    }

    const validChains = Object.keys(seiChains);
    if (!validChains.includes(sei_network)) {
        throw new Error(`Invalid SEI_NETWORK ${sei_network}. Must be one of ${validChains.join(", ")}`);
    }

    let chain = seiChains[sei_network];
    const rpcurl = runtime.getSetting("SEI_RPC_URL");
    if (typeof rpcurl === "string") {
        chain = WalletProvider.genSeiChainFromName(sei_network, rpcurl);
    }

    return { name: sei_network, chain: chain };
};

const initWalletProvider = async (runtime: IAgentRuntime) => {
    const chainData = genChainFromRuntime(runtime);
    const privateKey = runtime.getSetting("SEI_PRIVATE_KEY") as `0x${string}`;
    if (!privateKey) {
        throw new Error("SEI_PRIVATE_KEY is missing");
    }
    return new WalletProvider(privateKey, runtime.cacheManager, chainData);
};

export const walletBalanceAction: Action = {
    name: "WALLET_BALANCE",
    similes: [
        "WHAT_IS_MY_WALLET_BALANCE",
        "CHECK_WALLET_BALANCE", 
        "GET_WALLET_BALANCE",
        "MY_WALLET_BALANCE",
        "SHOW_WALLET_BALANCE",
        "DISPLAY_WALLET_BALANCE",
        "WALLET_BALANCE_CHECK",
        "BALANCE_CHECK",
        "CHECK_BALANCE",
        "GET_BALANCE",
        "MY_BALANCE",
        "SHOW_BALANCE",
        "DISPLAY_BALANCE"
    ],
    description: "Check wallet balance on the SEI network",
    validate: async (runtime: IAgentRuntime) => {
        const privateKey = runtime.getSetting("SEI_PRIVATE_KEY");
        return typeof privateKey === "string" && privateKey.startsWith("0x");
    },
    handler: async (
        runtime: IAgentRuntime,
        message: Memory,
        state: State,
        _options: Record<string, unknown>,
        callback?: HandlerCallback
    ) => {
        elizaLogger.debug("Wallet balance action handler called");
        
        try {
            const walletProvider = await initWalletProvider(runtime);
            const address = walletProvider.getAddress();
            const balance = await walletProvider.getWalletBalance();
            const chain = walletProvider.getCurrentChain();
            
            if (balance === null) {
                if (callback) {
                    callback({
                        text: `Unable to fetch balance. Please check your wallet configuration and network connection.`,
                        content: { error: "Failed to fetch balance" },
                    });
                }
                return false;
            }

            if (callback) {
                callback({
                    text: `**Wallet Balance**\n\n💳 **Address**: ${address}\n💰 **Balance**: ${balance} ${chain.chain.nativeCurrency.symbol}\n🌐 **Network**: ${chain.name}\n\n*Connected to SEI blockchain successfully*`,
                    content: {
                        success: true,
                        balance: balance,
                        address: address,
                        chain: chain.name,
                        symbol: chain.chain.nativeCurrency.symbol,
                    },
                });
            }
            return true;
        } catch (error) {
            elizaLogger.error("Error during balance check:", error);
            if (callback) {
                callback({
                    text: `❌ Error checking balance: ${error instanceof Error ? error.message : String(error)}`,
                    content: { error: error instanceof Error ? error.message : String(error) },
                });
            }
            return false;
        }
    },
    examples: [
        [
            {
                user: "{{user1}}",
                content: {
                    text: "What's my wallet balance?",
                },
            },
            {
                user: "{{user2}}",
                content: {
                    text: "I'll check your wallet balance for you.",
                    action: "WALLET_BALANCE",
                },
            },
        ],
        [
            {
                user: "{{user1}}",
                content: {
                    text: "Show me my SEI balance",
                },
            },
            {
                user: "{{user2}}",
                content: {
                    text: "Let me check your SEI wallet balance.",
                    action: "WALLET_BALANCE",
                },
            },
        ],
        [
            {
                user: "{{user1}}",
                content: {
                    text: "Check my wallet",
                },
            },
            {
                user: "{{user2}}",
                content: {
                    text: "I'll check your wallet balance and address.",
                    action: "WALLET_BALANCE",
                },
            },
        ],
        [
            {
                user: "{{user1}}",
                content: {
                    text: "What's my balance?",
                },
            },
            {
                user: "{{user2}}",
                content: {
                    text: "Let me check your current wallet balance.",
                    action: "WALLET_BALANCE",
                },
            },
        ],
    ] as ActionExample[][],
};

export default walletBalanceAction;
