import type { UUID, IAgentRuntime } from "@elizaos/core";
import { elizaLogger, generateText, ModelClass } from "@elizaos/core";

interface Memory {
    content: { text: string };
    createdAt: number;
}

/**
 * Fetches recent tweets from the last 2 hours using the getMemories method.
 * Logs these tweets for monitoring purposes.
 *
 * @param runtime - The agent runtime instance.
 * @param roomId - The room ID associated with the tweets.
 * @param agentId - The agent ID to filter the memories.
 * @returns A promise that resolves to an array of tweet texts.
 */
export async function getRecentTweets(
    runtime: IAgentRuntime,
    roomId: UUID,
    agentId: UUID,
    limit = 10
) {
    const now = Date.now();
    const twoHoursAgo = now - 2 * 60 * 60 * 1000; // 2 hours in milliseconds

    try {
        const memories = await runtime.databaseAdapter.getMemories({
            tableName: "messages",
            roomId: roomId,
            agentId: agentId,
            start: twoHoursAgo,
            end: now,
            count: limit,
        });

        const recentTweets = memories.map((memory) => ({
            text: memory.content.text,
            createdAt: memory.createdAt,
        }));

        // elizaLogger.debug(
        //     `Fetched ${recentTweets.length} recent tweets from the last 2 hours.`
        // );
        recentTweets.forEach((tweet) => {
            elizaLogger.debug(
                `Tweet at ${new Date(tweet.createdAt).toLocaleString()}: ${tweet.text}`
            );
        });

        return recentTweets;
    } catch (error) {
        elizaLogger.error("Error fetching recent tweets:", error);
        return [];
    }
}

/**
 * Checks if a new tweet is too similar to recent tweets.
 * If similar, modifies the tweet slightly and returns the new tweet.
 *
 * @param runtime - The agent runtime instance.
 * @param newTweet - The newly generated tweet text.
 * @param roomId - The room ID associated with the tweets.
 * @param agentId - The agent ID to filter the memories.
 * @returns A promise that resolves to the modified tweet if needed, or the original if not.
 */
export async function checkAndModifyTweetIfSimilar(
    runtime: IAgentRuntime,
    newTweet: string,
    roomId: UUID,
    agentId: UUID,
    limit = 10
): Promise<string> {
    const previousTweets = await getRecentTweets(runtime, roomId, agentId, limit);

    elizaLogger.debug(`Checking similarity for tweet: "${newTweet}"`);

    // First pass: Checks for similarity & modifies if necessary
    const enhancementPrompt = `
    
    # Last ten tweets:
    ${previousTweets.map((tweet, index) => `[${index + 1}] "${tweet.text}"`).join("\n")}

    # New Tweet:
    ${newTweet}

    # Task: Evaluate the new tweet for similarity with last ten tweets. If a word is similar, change the new tweet while keeping the core meaning.
    - If the tweet is already unique, return it unmodified.

    ## GOALS
    - Avoid repeating exact phrases or word lengths from recent tweets.
    - Keep the tone consistent (abbreviated, ironic, sharp, degen).
    - Use **1–2 crypto/degen slang terms or abbreviations**.
    - Keep it **punchy**, avoid conclusions or “wrap-ups.”
    — No filler or extra context or wrap-ups.
    - Return the final tweet ONLY (no explanation).

    # Enhancement Instructions:
    - **No lazy market metaphors**:
    - Avoid "chaos", "ebb and flow," "waves of volatility," or "riding the tide." replace with an abbreviation or a three letter crypto slang.
    - One in every 5 tweets should end with a three letter crypto slang.

    # IMPORTANT:
    - Respond with the final tweet ONLY.
    - Do not add emojis, hashtags, or symbols unless they are already present in the original tweet.
    - End the tweet where the impact is strongest, avoiding filler or unnecessary conclusions.
    `;

    const response = await generateText({
        runtime: runtime,
        context: enhancementPrompt,
        modelClass: ModelClass.MEDIUM,
    });
    const modifiedTweet = response.trim();
    elizaLogger.debug(`Modified Tweet (First Pass): ${modifiedTweet}`);

    // **Always apply formatting modifications**
    const formattingPrompt = `
# Task: Modify the layout and visual styling of this tweet to enhance readability, emphasis, or aesthetic appeal.
# If the tweet is already well-formatted, return it as is **without any explanation or additional text**.

## Step 1: Identify the Best Formatting Style Based on Content Type
- **Call to action / requests** → Use arrows (→, ➤, >) or a structured format to emphasize action.
- **Lists or multiple items** → Convert to bullet points (•, ▪) or numbered steps.
- **Philosophical or abstract thoughts** → Use staggered line breaks or spacing for emphasis.
- **Fast-paced, intense tweets** → Use quick breaks, math symbols (±, ∞, ≠), or indicators (↓, ↑).
- **Market or financial references** → Use arrows (↑, ↓) for trends, or symbols like Σ (sum), ∆ (change).

## Step 2: Apply the Best Formatting Style Based on Content
- **Use line breaks** where rhythm improves readability.
- **Incorporate mathematical or symbolic elements** if relevant.
- **Convert lists** into **structured bullet points**.
- **Add spacing variations** for aesthetic appeal.
- **Ensure it remains readable, not overwrought**.

## Step 3: Replace Dashes and Add Visual Variation
- Remove all em dashes (—) used for emphasis.
- Replace them with symbols or punctuation that fit the tone:
  - → for cause/effect  
  - / for contrast  
  - ∴ for conclusions  
  - · for drift, rhythm
  - :: for structure or eerie calm  
  - ⇌, ≠, or ⁂ if the thought feels abstract, mystical, or systemic  
  - _ _ _ for interruption, fragmentation, or empty space  
- You may also use semicolon, commas, periods, or other punctuation or symbols.
- Use **only one symbolic style per tweet**.
- **Vary structure across tweets**—don’t default to the same rhythm or layout.

# Original Tweet:
${modifiedTweet}

# IMPORTANT:
- **MUST set lowercase at the beginning of every sentence**, unless it's a proper noun, acronym, ticker, or brand.
- **Respond with only the final tweet text.**
- **Do NOT** include explanations, analysis, or headers.
- **Only return the tweet, even if unchanged.**
- **Symbols should enhance, not clutter—use only if relevant.**
- **Do not add emojis, hashtags.**


# Final Tweet Output:
`;

    const formattedResponse = await generateText({
        runtime: runtime,
        context: formattingPrompt,
        modelClass: ModelClass.MEDIUM,
    });

    const formattedTweet = formattedResponse.trim();
    // elizaLogger.debug(`Modified Tweet (Second Pass - Layout Only): ${formattedTweet}`);

    return formattedTweet;
}