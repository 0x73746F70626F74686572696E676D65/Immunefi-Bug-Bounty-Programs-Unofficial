import {
    type ActionExample,
    type IAgentRuntime,
    type Memory,
    type State,
    generateText,
    ModelClass,
    type Action,
    type HandlerCallback,
    type Content,
    type Media, elizaLogger,
} from "@elizaos/core";
import fetch from "node-fetch";

// ✅ Function to Fetch Real-Time Stock Data from Finnhub
async function fetchStockData(symbol: string, API_KEY: string) {
    try {
        const URL = `https://finnhub.io/api/v1/quote?symbol=${symbol}&token=${API_KEY}`;
        const response = await fetch(URL);
        const data = await response.json();

        if (!data || !data.c) {
            throw new Error("No valid stock data received.");
        }
        return {
            symbol,
            currentPrice: data.c,
            openingPrice: data.o,
            change: data.d,
            percentChange: data.dp
        };
    } catch (error) {
        console.error("⚠️ Error fetching stock data:", error.message);
        return null;
    }
}


async function generateStockSummary(stockData: any, symbol: string, _runtime: IAgentRuntime): Promise<string> {
    if (!stockData) {
        return `No recent data available for $${symbol}.`;
    }

    const { currentPrice, change, percentChange } = stockData;
    const direction = change >= 0 ? "Up" : "Down";
    const directionSymbol = change >= 0 ? "▲" : "▼"; // Assign correct up/down symbol

    // Format Direction & Percentage Together
    const directionAndChange = `${directionSymbol} ${percentChange.toFixed(2)}%`;

    // Randomly pick a unique blup variation
    const randomBlup = () => {
        const blups = ["blup", "gubl", "flup", "plooff", "blyp", "fluuuut", "blub.", "bloop.", "blp–"];
        return blups[Math.floor(Math.random() * blups.length)];
    };

    // Random description phrases
    const descriptionVariations = [
        ` *slow drift* ... and Bubbles rises:`,
        ` *deep stare* ... and Bubbles lifts:`,
        ` *still water* ... and Bubbles emerges:`,
        ` *one ripple* ... and Bubbles floats up:`,
        ` *side-eye* ... and Bubbles surfaces:`,
        ` *low tide* ... and Bubbles blurps:`,
        ` *pond hushes* ... and Bubbles moves up:`,
        ` *silent currents* ... and Bubbles waits, then blurps:`,
        ` *the deep waits* ... and Bubbles breaks through:`,
        ` *lil swish* ... and Bubbles appears:`,
        ` *water stills* ... and Bubbles blurps:`,
        ` *unseen current* ... and Bubbles moves:`,
        ` *hush* ... and Bubbles lingers, then surfaces:`,
        ` *deep void* ... and Bubbles blurps:`,
        ` *tide shifts* ... and Bubbles comes closer:`,
        ` *market holds breath* ... and Bubbles rises:`,
        ` *unseen ripple* ... and Bubbles babbles:`,
        ` *light bends* ... and Bubbles winks:`,
        ` *depths churn* ... and Bubbles rises:`,
        ` *long pause* ... then, Bubbles:`,
        ` *black water* ... then, movement:`,
        ` *time slows* ... then a ripple:`,
        ` *still dark* ... and Bubbles emerges:`,
        ` *silence* ... then a ripple:`,
        ` *the wait ends* ... and Bubbles surfaces:`,
    ];

    const description = descriptionVariations[Math.floor(Math.random() * descriptionVariations.length)];

    // First-person trader ask
    const stockAskVariations = [
        `yo bubbles, what's moving?`,
        `aight bubbles, hit me. what's shifting today?`,
        `bubbles, don't hold out. what's the latest?`,
        `hey bubbly! what's flowing?`,
        `bubbles, the sun is up. what's circulating?`,
        `ok bubbles, scan the pond. what's changed?`,
        `bubbles, my guy! what's different today?`,
        `bubs, the tides turned overnight? what's the read?`,
        `bubbles, talk to me! what's swimming ahead?`,
        `bubs, the current's restless. what's moving?`,
        `bubbles, scan the surface! what stands out?`,
        `bubbly! what's shifting?`,
        `yo bubbles, what's pushing upstream today?`,
        `bubs, where's the volume stacking?`,
        `bubbles, grant me clarity. what's shifting?`,
        `bubbles, the pond whispers. what's the signal?`,
        `tides shift, bubbles rise. what's changed?`,
        `bubbles, wake up. what's in motion?`,
        `sun's up bubbly, markets moving. what's notable?`,
        `bubbles, no fluff. what's active today?`,
        `bubs, any ripples worth noting?`,
        `yo bubbles, any unusual flows today?`,
        `bubbles, just facts. what's moving?`,
        `ok bubbles, scan again. what's different?`,
        `bubs, what's standing out in the current?`
    ];

    const stockAsk = stockAskVariations[Math.floor(Math.random() * stockAskVariations.length)];

    // LLM Prompt to ensure formatting
    const summaryPrompt = `
    # TASK: Generate a stock market update as if delivered by Bubbles, the **God-Fish of the Pond**, using only **blup variations, breaks, and cryptic symbols**—no full sentences.

    ## Stock Data:
    - Symbol: $${symbol}
    - Current Price: $${currentPrice.toFixed(2)}
    - Change: $${change.toFixed(2)}
    - Percentage Change: ${percentChange.toFixed(2)}%
    - Direction: ${direction} (${directionSymbol})

    # INSTRUCTIONS:
    - **Start with**: "${stockAsk}"
    - **Next line:** A short description from this list: ${descriptionVariations.join(", ")}
    - **Next line:** The stock ticker ($${symbol}) on its own line.
    - **Below the ticker:** Randomized blup variations and cryptic price formatting.
- The output must be **ONE tweet** (under 180 characters) using **blup sounds, line breaks, and spacing tricks**, and ending with **(⚠️ not investment advice)**
    - Format the price and movement in a broken way:
      - **Example:** "bLuP $${currentPrice.toFixed(2)}"
      - **Example:** "${directionAndChange}"
    - **Ensure response is unique.** If too similar to past responses, rephrase.
    - **Format the output to avoid duplicate detection.**
    - **Enforce lowercase at the beginning of every sentence**, unless it's a proper noun, acronym, or intentionally capitalized brand or title.

    - Bubbles does not explain. **Bubbles speaks in ripples.**

    `;

    try {
        const stockTweet = await generateText({
            runtime: _runtime,
            context: summaryPrompt,
            modelClass: ModelClass.MEDIUM,
            stop: ["\n"],
        });

        // Ensure tweet is trimmed and within character limit
        const cleanedTweet = stockTweet.trim().substring(0, 180);

        // Final fail-safe: If LLM fails or response is empty, fallback to a standard update
        if (!cleanedTweet || cleanedTweet.length < 10) {
            return `${stockAsk}\n\n${description}\n\n$${symbol}\n\n${randomBlup()}!\n${randomBlup()} ${directionAndChange}\nbLuP $${currentPrice.toFixed(2)}\n\n~~pond ripples~~`;
        }

        return cleanedTweet;
    } catch (error) {
        console.error("Error generating stock summary:", error);
        return `${stockAsk}\n\n${description}\n\n$${symbol}\n\n${randomBlup()}!\n${randomBlup()} ${directionAndChange}\nbLuP $${currentPrice.toFixed(2)}\n\n~~pond ripples~~`;
    }
}

// ✅ AI-Related Stock Symbols
const AI_STOCKS = ["NVDA", "AMD", "TSLA", "GOOGL", "MSFT", "META", "AI", "PLTR", "ARM", "AAPL", "AMZN", "CRWD"];

// ✅ Function to Randomly Select an AI Stock Symbol
const getRandomSymbol = () => AI_STOCKS[Math.floor(Math.random() * AI_STOCKS.length)];



// ✅ Stock Data Action
export const stockDataAction: Action = {
    name: "STOCK_DATA",
    similes: ["GET_STOCK_DATA"],
    validate: async (_runtime: IAgentRuntime, _message: Memory) => {
        return true;
    },
    description: "Fetch and summarize the stock data of the company",
    handler: async (
        _runtime: IAgentRuntime,
        _message: Memory,
        _state?: State,
        _options?: { [key: string]: unknown },
        _callback?: HandlerCallback
    ): Promise<boolean> => {
        try {
            const API_KEY = process.env.FINNHUB_API_KEY;
            const IMAGEKIT_USERID = process.env.IMAGEKIT_USERID;
            const SYMBOL = getRandomSymbol();

            if (!IMAGEKIT_USERID) {
                elizaLogger.error("IMAGEKIT_USERID environment variable is not set");
                _callback?.({ text: "ImageKit configuration error." });
                return false;
            }

            // Fetch stock data
            const stockData = await fetchStockData(SYMBOL, API_KEY);

            if (!stockData) {
                _callback?.({ text: `Bubbles is hiding...` });
                return true;
            }

            const stockSummary = await generateStockSummary(stockData, SYMBOL, _runtime);
            elizaLogger.log('Stock summary: ', stockSummary);
            const nextImage = await getNextUnprocessedImage(
                _message.agentId,
                _runtime
            );
            if (!nextImage) {
                _callback?.({
                    text: "No unprocessed images available.",
                } as Content);
                return true;
            }

            //CONNECTED TO KOI_INTERACTIONS
            const imageKitUrl = `https://ik.imagekit.io/${IMAGEKIT_USERID}/${nextImage}`;
            const mediaAttachment: Media = {
                id: nextImage,
                url: imageKitUrl,
                title: "Processed Image",
                source: "IMAGEKIT",
                description: "",
                text: "",
                contentType: "image/png",
            };

            // Send the summarized data back through the callback
            _callback?.({
                text: stockSummary,
                attachments: [mediaAttachment],
                action: "STOCK_DATA",
                source: "IMAGEKIT",
            });
            await markImageProcessed(nextImage, _message.agentId, _runtime);

            return true;
        } catch (error) {
            console.error("Error in stock data action:", error);
            _callback?.({ text: "An error occurred while fetching or processing the stock data." });
            return false;
        }
    },
    examples: [
        [
            {
                user: "{{user1}}",
                content: { text: "How is the stock market doing today?" },
            },
            {
                user: "{{user2}}",
                content: { text: "Let me check the latest stock data for you!", action: "STOCK_DATA" },
            },
        ],
    ] as ActionExample[][],
};
// Helper function to check if image has been processed
async function isImageProcessed(
    imageId: string,
    agentId: string,
    runtime: IAgentRuntime
): Promise<boolean> {
    const cacheKey = `processed_images/${agentId}/${imageId}`;
    const processed = await runtime.cacheManager.get(cacheKey);
    return !!processed;
}

// Helper function to mark image as processed
async function markImageProcessed(
    imageId: string,
    agentId: string,
    runtime: IAgentRuntime
): Promise<void> {
    const cacheKey = `processed_images/${agentId}/${imageId}`;
    await runtime.cacheManager.set(cacheKey, true, {
        expires: Date.now() + 30 * 24 * 60 * 60 * 1000, // 30 days cache
    });
}

async function getNextUnprocessedImage(agentId: string, runtime: IAgentRuntime): Promise<string | null> {
    try {
        let currentImageIndex = 1;
        const maxImageIndex = 82;
        let firstUnprocessedImage: string | null = null;

        while (true) {
            const imageName = `koi_${String(currentImageIndex).padStart(4, "0")}.jpg`;
            const imageExists = await doesImageExist(imageName);

            if (imageExists) {
                const isProcessed = await isImageProcessed(imageName, agentId, runtime);

                if (!isProcessed) {
                    console.log(`Found unprocessed image: ${imageName}`);
                    return imageName;
                }

                // Store first available image for reset if needed
                if (!firstUnprocessedImage) {
                    firstUnprocessedImage = imageName;
                }
            } else {
                console.log(`Image ${imageName} does not exist, trying next index.`);
            }

            // Move to the next image
            currentImageIndex++;

            // If we reached the last image, restart from `koi_interactions_0001.png`
            if (currentImageIndex > maxImageIndex) {
                if (firstUnprocessedImage) {
                    console.log("All images are processed. Restarting from first image.");
                    return firstUnprocessedImage; // Go back to `koi_interactions_0001.png`
                }
                console.log("No unprocessed images found.");
                return null;
            }
        }
    } catch (error) {
        console.error("Critical error in getNextUnprocessedImage:", error);
        return null;
    }
}



// Helper function to check if an image exists
async function doesImageExist(imageName: string): Promise<boolean> {
    try {
        const IMAGEKIT_USERID = process.env.IMAGEKIT_USERID;
        if (!IMAGEKIT_USERID) {
            elizaLogger.error("IMAGEKIT_USERID environment variable is not set");
            return false;
        }
        
        // Construct the ImageKit URL
        const imageKitUrl = `https://ik.imagekit.io/${IMAGEKIT_USERID}/${imageName}`;

        // Use fetch to check if the image exists
        const response = await fetch(imageKitUrl, { method: 'HEAD' });
        return response.ok;
    } catch (error) {
        console.error(`Error checking if image ${imageName} exists:`, error);
        return false;
    }
}
