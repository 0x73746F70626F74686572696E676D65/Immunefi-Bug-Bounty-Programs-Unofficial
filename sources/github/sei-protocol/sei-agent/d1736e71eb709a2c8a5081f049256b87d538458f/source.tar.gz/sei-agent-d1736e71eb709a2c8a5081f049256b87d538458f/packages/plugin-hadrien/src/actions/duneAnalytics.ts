import {
    composeContext,
    type Content,
    generateObject,
    generateText,
    type HandlerCallback,
    type Action,
    type ActionExample,
    type IAgentRuntime,
    type Memory,
    ModelClass,
    type State,
    elizaLogger,
    type Media
} from "@elizaos/core";
import { DuneClient, QueryParameter } from "@duneanalytics/client-sdk";

const DUNE_API_KEY: string = process.env.DUNE_API_KEY || "ldGI7aVKrlhzIlSaATp5MTh0exJkidWN";
const DUNE_QUERY_ID: number = 3600318; // Alpha screener 24H Relative Strength of Coins from L1 Narrative

const duneClient = new DuneClient(DUNE_API_KEY);

/**
 * Fetches query results from Dune Analytics
 *
 * @returns Query result rows or undefined on error
 */
export const fetchQueryResult = async (): Promise<any[] | undefined> => {
    try {
        const executionResult = await duneClient.getLatestResult({ queryId: DUNE_QUERY_ID });
        return executionResult.result?.rows;
    } catch (error) {
        console.error("Error running Dune query:", error);
        return undefined;
    }
};

/**
 * Generates a structured market analysis context to pass to LLM
 *
 * @param data - Market data
 * @returns Structured text for LLM processing
 */


const generateTweetContext = (data: any): string => {
    if (!data || !Array.isArray(data) || data.length === 0) {
        return "Market flat. No major moves. Either rotate, wait, or touch grass.";
    }

    // Only include these coins
    const trackedCoins = new Set(["SOL", "SEI", "SUI", "NEAR", "APT", "BERA", "TIA", "ROSE"]);

    // Filter data for tracked coins & ensure required fields exist
    const filteredData = data.filter(coin =>
        coin?.coin && trackedCoins.has(coin.coin.toUpperCase()) &&
        coin?.price_today !== undefined &&
        coin?.token_growth !== undefined &&
        coin?.relative_strength !== undefined
    );

    if (filteredData.length === 0) {
        return "No strong market moves for $SOL, $SEI, $SUI, $NEAR, $APT, $BERA, $TIA, or $ROSE today. Check back later.";
    }

    // Parse & format relevant data
    const parsedData = filteredData.map((coin) => {
        const directionSymbol = coin.token_growth >= 0 ? "▲" : "▼"; // Assigns ▲ for up and ▼ for down
        const formattedChange = `${directionSymbol} ${Math.abs(coin.token_growth).toFixed(2)}%`; // Ensures no double negatives

        return {
            symbol: `$${coin.coin.toUpperCase()}`,
            priceChange: formattedChange, // Uses correct ▲ or ▼
            relativeStrength: coin.relative_strength.toFixed(2),
        };
    });

    // Sort by relative strength (strongest first)
    const sortedByStrength = parsedData.sort((a, b) => Number.parseFloat(b.relativeStrength) - Number.parseFloat(a.relativeStrength));

    // Get top 3 gainers (strongest relative strength)
    const leaders = sortedByStrength
        .slice(0, 1)
        .map((coin) => `${coin.symbol} ${coin.priceChange} pwr: ${coin.relativeStrength}`)
        .join("\n"); // Each coin now appears on a new line

    // Get bottom 3 laggards (weakest relative strength)
    const laggards = sortedByStrength
        .slice(-1)
        .map((coin) => `${coin.symbol} ${coin.priceChange} pwr: ${coin.relativeStrength}`)
        .join("\n"); // Each coin now appears on a new line
    const marketMood = leaders ? "cobra style:" : "no cobras today...:";

    return `
today's L1 sunrise ritual (Tracked Coins Only):
${marketMood}
${leaders || "no clear winners today"}

downward dogs:
${laggards || "no major declines"}

Summarize this data in a **concise, punchy, high-signal tweet (under 280 characters).**
- **Start with: "Today's L1 Sunrise Ritual:" as the first line.**
- **Ensure a full blank line after the Cobra Style section before Downward Dogs.**
- **List each coin on its own line—no inline formatting.**
- **DO NOT use hashtags or emojis.**
- **Preface all coins with "$"** (e.g., "$SOL", "$TIA").
- **DO NOT mention full chain names—only ticker symbols (e.g., use "$SOL", NOT "Solana").**
- No generic market summaries—make it feel **real and actionable.**
- **Enforce lowercase at the beginning of every sentence**, unless it's a proper noun, acronym, or intentionally capitalized brand or title.

- End with a **clear statement on liquidity shifts or trend movement.**
`;
};
/**
 * Cleans tweet output by removing full chain names
 */
const removeChainNames = (text: string): string => {
    const chainNameMap: { [key: string]: string } = {
        "Solana": "SOL",
        "Sei": "SEI",
        "Sui": "SUI",
        "Near": "NEAR",
        "Aptos": "APT",
        "Berachain": "BERA",
        "Tia": "TIA",
        "Rose": "ROSE"
    };

    Object.keys(chainNameMap).forEach(chain => {
        const regex = new RegExp(`\\b${chain}\\b`, "gi");
        text = text.replace(regex, chainNameMap[chain]);
    });

    return text;
};




export const getCryptoAnalysis: Action = {
    name: "getCryptoAnalysis",
    similes: ["GET_CRYPTO_ANALYSIS"],
    description: "Get the analysis of cryptocurrency market data",

    validate: async (_runtime: IAgentRuntime, _message: Memory): Promise<boolean> => {
        return true;
    },

    handler: async (
        runtime: IAgentRuntime,
        message: Memory,
        state: State,
        _options: { [key: string]: unknown },
        callback?: HandlerCallback
    ): Promise<boolean> => {
        try {
            const l1Analytics = await fetchQueryResult();
            // console.log("Dune Analytics l1Analytics::::::::::::::::::", l1Analytics);

            // Generate structured context for LLM
            const context = generateTweetContext(l1Analytics);

            // Pass structured data to LLM for tweet generation
            let tweetText = await generateText({
                runtime,
                context: context,
                modelClass: ModelClass.MEDIUM, // Adjust model size as needed
                stop: ["\n"], // Ensures clean formatting
            });
            tweetText = removeChainNames(tweetText);
            tweetText = tweetText.trim();



            const nextImage = await getNextUnprocessedImage(
                message.agentId,
                runtime
            );
            if (!nextImage) {
                callback?.({
                    text: "It is a dark day..today",
                } as Content);
                return true;
            }

            //CONNECTED TO DUNE
            const IMAGEKIT_USERID = process.env.IMAGEKIT_USERID;
            if (!IMAGEKIT_USERID) {
                elizaLogger.error("IMAGEKIT_USERID environment variable is not set");
                callback?.({ text: "ImageKit configuration error." });
                return false;
            }

            const imageKitUrl = `https://ik.imagekit.io/${IMAGEKIT_USERID}/${nextImage}`;
            const mediaAttachment: Media = {
                id: nextImage,
                url: imageKitUrl,
                title: "Processed Image",
                source: "IMAGEKIT",
                description: "",
                text: "",
                contentType: "image/png",
            };


            callback?.(
                {
                    text: tweetText.trim(),
                    attachments: [mediaAttachment],
                    action: "DUNE_ANALYTICS",
                    source: "IMAGEKIT",
                });
            await markImageProcessed(nextImage, message.agentId, runtime);

            return true; // Return true on success
        } catch (error) {
            console.error("Error in getCryptoAnalysis handler:", error);
            callback?.(
                { text: `It is a dark day...` },
                []
            );
            return false; // Return false on error
        }
    },

    examples: [
        [
            {
                "user": "{{user1}}",
                "content": {
                    "text": "How's the market today?"
                }
            },
            {
                "user": "{{user2}}",
                "content": {
                    "action": "getCryptoAnalysis"
                }
            }
        ],
        [
            {
                "user": "{{user1}}",
                "content": {
                    "text": "What's the status of BNB?"
                }
            },
            {
                "user": "{{user2}}",
                "content": {
                    "action": "getCryptoAnalysis"
                }
            }
        ]


    ] as ActionExample[][],
};

export default getCryptoAnalysis;


// Helper function to check if image has been processed
async function isImageProcessed(
    imageId: string,
    agentId: string,
    runtime: IAgentRuntime
): Promise<boolean> {
    const cacheKey = `processed_images/${agentId}/${imageId}`;
    const processed = await runtime.cacheManager.get(cacheKey);
    return !!processed;
}

// Helper function to mark image as processed
async function markImageProcessed(
    imageId: string,
    agentId: string,
    runtime: IAgentRuntime
): Promise<void> {
    const cacheKey = `processed_images/${agentId}/${imageId}`;
    await runtime.cacheManager.set(cacheKey, true, {
        expires: Date.now() + 30 * 24 * 60 * 60 * 1000, // 30 days cache
    });
}

async function getNextUnprocessedImage(agentId: string, runtime: IAgentRuntime): Promise<string | null> {
    try {
        let currentImageIndex = 1;
        const maxImageIndex = 71;
        let firstUnprocessedImage: string | null = null;

        while (true) {
            const imageName = `yoga_${String(currentImageIndex).padStart(4, "0")}.jpg`;
            const imageExists = await doesImageExist(imageName);

            if (imageExists) {
                const isProcessed = await isImageProcessed(imageName, agentId, runtime);

                if (!isProcessed) {
                    console.log(`Found unprocessed image: ${imageName}`);
                    return imageName;
                }

                // Store first available image for reset if needed
                if (!firstUnprocessedImage) {
                    firstUnprocessedImage = imageName;
                }
            } else {
                console.log(`Image ${imageName} does not exist, trying next index.`);
            }

            // Move to the next image
            currentImageIndex++;

            // If we reached the last image, restart from `koi_interactions_0001.png`
            if (currentImageIndex > maxImageIndex) {
                if (firstUnprocessedImage) {
                    console.log("All images are processed. Restarting from first image.");
                    return firstUnprocessedImage; // Go back to `koi_interactions_0001.png`
                }
                console.log("No unprocessed images found.");
                return null;
            }
        }
    } catch (error) {
        console.error("Critical error in getNextUnprocessedImage:", error);
        return null;
    }
}

// Helper function to check if an image exists
async function doesImageExist(imageName: string): Promise<boolean> {
    try {
        const IMAGEKIT_USERID = process.env.IMAGEKIT_USERID;
        if (!IMAGEKIT_USERID) {
            elizaLogger.error("IMAGEKIT_USERID environment variable is not set");
            return false;
        }

        // Construct the ImageKit URL
        const imageKitUrl = `https://ik.imagekit.io/${IMAGEKIT_USERID}/${imageName}`;

        // Use fetch to check if the image exists
        const response = await fetch(imageKitUrl, { method: 'HEAD' });
        return response.ok;
    } catch (error) {
        console.error(`Error checking if image ${imageName} exists:`, error);
        return false;
    }
}
