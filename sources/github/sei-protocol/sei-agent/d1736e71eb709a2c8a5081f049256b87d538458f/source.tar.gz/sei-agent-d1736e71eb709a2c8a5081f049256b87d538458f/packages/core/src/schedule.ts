import { elizaLogger } from "./logger";

interface AspectSchedule {
    days: number[];
    hours: number[];
    intensity: number;
}

interface CharacterAspect {
    bio: string[];
    weight: number;
    schedules: AspectSchedule[];
    templates?: { [key: string]: string }; // Add templates to CharacterAspect

}

export interface CharacterBios {
    defaultBio: string[];
    aspects: { [key: string]: CharacterAspect };
    templates?: { [key: string]: string }; // Ensure global templates exist
}

interface SelectedAspect {
    id: string;
    bio: string;
    intensity: number;
    weight: number;
    templates?: {
        [key: string]: string;
    };
}

export class CharacterScheduler {
    bios: CharacterBios;
    selectedAspectId?: string;
    activeAspects: SelectedAspect[] = []; // Persist active aspects
    // selectedAspectId: string | null = null;

    constructor(bios: CharacterBios) {
        if (!this.selectedAspectId) {
            this.selectedAspectId = null;
        }
        this.bios = bios;

        // elizaLogger.debug(`CharacterScheduler initialized. SelectedAspectId: ${this.selectedAspectId}`);
    }

    private getRandomBio(bios: string[]): string {
        // elizaLogger.debug("[CharacterScheduler] Getting random bio from:", bios);
        const selectedBio = bios[Math.floor(Math.random() * bios.length)];
        // elizaLogger.debug("[CharacterScheduler] Selected bio:", selectedBio);
        return selectedBio;
    }

    private getAspectIntensity(
        aspect: CharacterAspect,
        dayOfWeek: number,
        hour: number
    ): number {
        // elizaLogger.debug("[CharacterScheduler] Getting aspect intensity for:", {
        //     aspect,
        //     dayOfWeek,
        //     hour
        // });

        let maxIntensity = 0;

        for (const schedule of aspect.schedules) {
            // elizaLogger.debug("[CharacterScheduler] Checking schedule:", schedule);
            if (
                schedule.days.includes(dayOfWeek) &&
                schedule.hours.includes(hour)
            ) {
                maxIntensity = Math.max(maxIntensity, schedule.intensity);
                // elizaLogger.debug("[CharacterScheduler] Updated maxIntensity:", maxIntensity);
            }
        }

        // elizaLogger.debug("[CharacterScheduler] Final intensity:", maxIntensity);
        return maxIntensity;
    }




    getBios(
        date: Date = new Date(),
        minCount = 1,
        maxCount = 1,
        timeZone = 'America/Mexico_City'
    ): CharacterBios {
        // elizaLogger.debug("[CharacterScheduler] Getting bios for:", { timeZone });

        // Safely convert the date to the specified timezone
        const zonedDate = new Date(date.toLocaleString('en-US', { timeZone }));

        // Maintain the original method of getting day and hour
        const dayOfWeek = zonedDate.getDay() || 7; // Sunday as 7
        const hour = zonedDate.getHours();

        // elizaLogger.debug("[CharacterScheduler] Calculated dayOfWeek (1=Mon, 7=Sun):", dayOfWeek);
        // elizaLogger.debug("[CharacterScheduler] Calculated hour:", hour);

        const activeAspects: SelectedAspect[] = [];
        const usedBios = new Set<string>();

        const activeAspectList: { aspect: SelectedAspect; weight: number }[] = [];

        // Collect active aspects based on intensity and weight
        for (const [id, aspect] of Object.entries(this.bios.aspects)) {
            const intensity = this.getAspectIntensity(aspect, dayOfWeek, hour);

            // elizaLogger.debug(`[CharacterScheduler] Aspect ${id} - Intensity: ${intensity} (Day: ${dayOfWeek}, Hour: ${hour})`);

            if (intensity > 0 && Array.isArray(aspect.bio) && aspect.bio.length > 0) {
                activeAspectList.push({
                    aspect: {
                        id,
                        bio: "",
                        intensity,
                        weight: aspect.weight,
                        templates: aspect.templates || {},
                    },
                    weight: intensity * aspect.weight,
                });
            }
        }

        // Randomly select an active aspect based on weighted probability
        if (activeAspectList.length > 0) {
            // Add this line to shuffle the activeAspectList array
            activeAspectList.sort(() => Math.random() - 0.5);
            const totalWeight = activeAspectList.reduce((sum, item) => sum + item.weight, 0);
            let randomPick = Math.random() * totalWeight;
            let selectedAspect: SelectedAspect | null = null;

            for (const item of activeAspectList) {
                randomPick -= item.weight;
                if (randomPick <= 0) {
                    selectedAspect = item.aspect;
                    break;
                }
            }

            if (!selectedAspect) {
                selectedAspect = activeAspectList[0].aspect;
            }

            this.selectedAspectId = selectedAspect.id;
            elizaLogger.debug(`[SCHEDULER] Selected aspectId: ${this.selectedAspectId}`);

            const selectedBios = this.bios.aspects[selectedAspect.id].bio.map(b => b.trim());
            while (activeAspects.length < minCount && selectedBios.length > 0) {
                const bio = this.getRandomBio(selectedBios);
                if (!usedBios.has(bio)) {
                    activeAspects.push({ ...selectedAspect, bio });
                    usedBios.add(bio);
                }
            }
        }

        // Fallback to default bios if needed
        while (activeAspects.length < minCount && this.bios.defaultBio.length > 0) {
            const defaultBio = this.getRandomBio(this.bios.defaultBio).trim();
            if (!usedBios.has(defaultBio)) {
                activeAspects.push({ id: "default", bio: defaultBio, intensity: 1, weight: 1 });
                usedBios.add(defaultBio);
            }
        }

        this.activeAspects = activeAspects;

        return {
            defaultBio: this.bios.defaultBio,
            aspects: this.bios.aspects,
            templates: this.bios.templates,
        };
    }




    getCurrentActivities(date: Date = new Date()): string {
        // elizaLogger.debug("[CharacterScheduler] Getting current activities for date:", date);

        const bios = this.getBios(date);
        const dayOfWeek = date.getDay() || 7;
        const hour = date.getHours();

        // elizaLogger.debug("[CharacterScheduler] Time calculations:", { dayOfWeek, hour });

        const timeOfDay =
            hour < 12 ? "morning" : hour < 17 ? "afternoon" : "evening";

        // elizaLogger.debug("[CharacterScheduler] Determined time of day:", timeOfDay);

        const result = `Currently ${timeOfDay} (${hour}:00) on ${[
            "Sunday",
            "Monday",
            "Tuesday",
            "Wednesday",
            "Thursday",
            "Friday",
            "Saturday",
        ][dayOfWeek % 7]
            }. Active aspects:\n${bios}`;




        // elizaLogger.debug("[CharacterScheduler] Final activities result:", result);
        return result;
    }


}
