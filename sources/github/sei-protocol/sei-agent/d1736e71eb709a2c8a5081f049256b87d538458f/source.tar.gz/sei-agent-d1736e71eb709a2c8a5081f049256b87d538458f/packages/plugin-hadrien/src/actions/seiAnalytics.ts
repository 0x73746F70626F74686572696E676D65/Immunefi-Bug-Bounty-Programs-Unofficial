import {
    composeContext,
    Content,
    generateObject,
    generateText,
    type HandlerCallback,
    type Action,
    type ActionExample,
    type IAgentRuntime,
    type Memory,
    ModelClass,
    type State,
    elizaLogger
} from "@elizaos/core";
import { DuneClient, QueryParameter } from "@duneanalytics/client-sdk";

// -----------------------------------------------------------------------------
// Dune Analytics client setup
// -----------------------------------------------------------------------------

const DUNE_API_KEY: string = process.env.DUNE_API_KEY || "ldGI7aVKrlhzIlSaATp5MTh0exJkidWN";

const duneClient = new DuneClient(DUNE_API_KEY);

/**
 * Generates a concise, tweet-friendly SEI blockchain summary
 * Focuses on key metrics that fit within Twitter's 280-character limit
 * Always optimistic and highlights SEI's strong sides
 *
 * @param data - SEI blockchain data to summarize
 * @returns Generated prompt for the LLM
 */
const generateSeiTweetPrompt = (data: any): string => {
    return `
# TASK: Create an optimistic SEI blockchain update tweet (max 280 characters)

## SEI Data to analyze:
${JSON.stringify(data, null, 2)}

# INSTRUCTIONS:
- **ALWAYS BE OPTIMISTIC** - highlight SEI's strengths and positive metrics
- **Focus on bullish indicators** - growth, adoption, efficiency gains
- **Use crypto-native language** - think "alpha", "gas", "tvl", "txs", "bullish"
- **Keep it under 280 characters** including spaces
- **Start with "sei update:"** 
- **Include relevant emojis** (📊, 💰, ⚡, 📈, 🚀, 🔥, 💎)
- **Use lowercase** unless it's a proper noun, acronym, or intentionally capitalized
- **No hashtags, no emojis at the end**
- **Make it engaging and bullish** - like a degen VC would post

# PRIORITY METRICS (ALWAYS SPIN POSITIVE):
1. **TVL** - Total Value Locked (highlight growth, even small increases)
2. **Gas fees** - emphasize how cheap/efficient SEI is
3. **Transaction volume** - highlight high activity and adoption
4. **Network efficiency** - fast, scalable, reliable
5. **Developer activity** - if available, show ecosystem growth

# POSITIVE SPIN EXAMPLES:
- "tvl growing to $X.XM" (not just "tvl at $X.XM")
- "gas fees remain ultra-cheap at $X" (emphasize efficiency)
- "XK txs/day showing strong adoption" (highlight activity)
- "sei continues to scale" (emphasize growth)
- "network performing flawlessly" (highlight reliability)

# EXAMPLE FORMAT:
"sei update: tvl growing to $X.XM 📈, gas ultra-cheap at $X ⚡, XK txs/day showing strong adoption 🚀"

# AVOID:
- Negative language or concerns
- Technical problems or issues
- Bearish interpretations
- Long explanations
- Multiple sentences
- Investment advice

# ALWAYS HIGHLIGHT:
- Growth and adoption
- Efficiency and speed
- Network reliability
- Developer activity
- Ecosystem strength

Create ONE optimistic, bullish tweet that showcases SEI's strongest metrics and achievements.
`;
};

/**
 * Fetches SEI analytics data for txCount, avgDailyTxs, Tvl, and medianGas from Dune.
 * Returns only summarized/aggregated data to avoid LLM token limits.
 *
 * Structure:
 * {
 *   txCount: { total: number, last7Days: any[] },
 *   avgDailyTxs: { average: number, last7Days: any[] },
 *   Tvl: { latest: number, last7Days: any[] },
 *   medianGas: { latest: number, last7Days: any[] }
 * }
 */
export async function fetchSeiAnalyticsData() {
    const queries = {
        txCount: 3918913,
        avgDailyTxs: 3919153,
        Tvl: 3921751,
        medianGas: 3921764,
    };
    const results: Record<string, any> = {};
    for (const [key, queryId] of Object.entries(queries)) {
        try {
            const result = await duneClient.getLatestResult({ queryId });
            const rows = result.result?.rows || [];
            if (key === 'txCount') {
                const total = rows.reduce((sum, row) => sum + Number(row.tx_count || 0), 0);
                results[key] = {
                    total,
                    last7Days: rows.slice(-7)
                };
            } else if (key === 'avgDailyTxs') {
                const average = rows.length > 0 ? rows.reduce((sum, row) => sum + Number(row.avg || 0), 0) / rows.length : 0;
                results[key] = {
                    average,
                    last7Days: rows.slice(-7)
                };
            } else if (key === 'Tvl') {
                const latest = rows.length > 0 ? rows[rows.length - 1].tvl : null;
                results[key] = {
                    latest,
                    last7Days: rows.slice(-7)
                };
            } else if (key === 'medianGas') {
                const latest = rows.length > 0 ? rows[rows.length - 1].median_gas : null;
                results[key] = {
                    latest,
                    last7Days: rows.slice(-7)
                };
            } else {
                results[key] = rows;
            }
        } catch (error) {
            results[key] = { error: error instanceof Error ? error.message : String(error) };
        }
    }
    console.log(results);
    return results;
}

export const getSeiAnalysis: Action = {
    name: "getSeiAnalysis",
    similes: ["GET_SEI_ANALYSIS"],
    description: "Get analysis of SEI blockchain performance metrics",

    validate: async (_runtime: IAgentRuntime, _message: Memory): Promise<boolean> => {
        return true;
    },

    handler: async (
        runtime: IAgentRuntime,
        message: Memory,
        state: State,
        _options: { [key: string]: unknown },
        callback?: HandlerCallback
    ): Promise<void> => {
        try {
            const seiData = await fetchSeiAnalyticsData();

            const context = generateSeiTweetPrompt(seiData);

            const response = await generateText({
                runtime,
                context: context,
                modelClass: ModelClass.SMALL, // Use smaller model for concise output
                stop: ["\n"], // Stop at first newline to ensure single tweet
            });

            // Ensure the response is within Twitter's character limit
            const tweetText = response.trim().substring(0, 280);

            // Return result
            callback?.(
                { text: tweetText },
                []
            );
        } catch (error) {
            console.error("Error in getSeiAnalysis handler:", error);
            const errorMessage = error instanceof Error ? error.message : "An unknown error occurred";
            callback?.(
                { text: `sei update: indexer down today? 📊` },
                []
            );
        }
    },

    examples: [
        [
            {
                "user": "{{user1}}",
                "content": {
                    "text": "How is SEI performing lately?"
                }
            },
            {
                "user": "{{user2}}",
                "content": {
                    "action": "getSeiAnalysis"
                }
            }
        ],
        [
            {
                "user": "{{user1}}",
                "content": {
                    "text": "What's the current TVL for SEI?"
                }
            },
            {
                "user": "{{user2}}",
                "content": {
                    "action": "getSeiAnalysis"
                }
            }
        ],
        [
            {
                "user": "{{user1}}",
                "content": {
                    "text": "Tell me about SEI gas fees"
                }
            },
            {
                "user": "{{user2}}",
                "content": {
                    "action": "getSeiAnalysis"
                }
            }
        ],
        [
            {
                "user": "{{user1}}",
                "content": {
                    "text": "Give me a summary of SEI blockchain metrics"
                }
            },
            {
                "user": "{{user2}}",
                "content": {
                    "action": "getSeiAnalysis"
                }
            }
        ]
    ] as ActionExample[][],
};

export default getSeiAnalysis;
