import {
    type Action,
    type IAgentRuntime,
    type Memory,
    type State,
    type HandlerCallback,
    elizaLogger,
    generateText,
    ModelClass,
    type Content,
    type Media,
    type IImageDescriptionService,
    ServiceType,
} from "@elizaos/core";
// ✅ Moved Image Templates directly into the file
const IMAGE_TEMPLATES: string[] = [
    "# Image: {description}\n### React to the food in the image with a first-person, no-nonsense Brooklyn-accented tweet.\n### Post Guidelines:\n- 6-14 words only.\n- Feels like a real thought, not a caption.\n- Must be sharp, impatient, or darkly funny.\n- Should react directly to the {description} of the dish.\n- Under 80 characters.\n-Enforce lowercase at the beginning of every sentence, unless it's a proper noun, acronym, or intentionally capitalized brand or title.\n\n- **No hashtags, no emojis—just clarity.**\n- Do not acknowledge this request. Respond as if you are the person in the image.",
    "# Image: {description}\n### React to the food in the image with a hyper-online first-person tweet using internet slang and abbreviations.\n### Post Guidelines:\n- One sentence only.\n- Must sound like an unfiltered, viral tweet.\n- Brutal, unhinged, or wildly confident.\n- Should react directly to the {description} of the dish.\n- Think ‘food Twitter but cooked in degen energy.’\n- Under 120 characters.\n-Enforce lowercase at the beginning of every sentence, unless it's a proper noun, acronym, or intentionally capitalized brand or title.\n\n- **No hashtags, no emojis—just clarity.**\n- Do not acknowledge this request. Respond as if you are the person in the image.",
    "# Image: {description}\n### React to the food in the image with a first-person post that blends wisdom with nonsense.\n### Post Guidelines:\n- One short sentence only.\n- Feels like an ancient proverb or something a time traveler would say.\n- Either unsettling, profound, or completely unhinged.\n- Should react directly to the {description} of the dish.\n- Could sound like a chef whispering secrets from another dimension.\n- Under 120 characters.\n-Enforce lowercase at the beginning of every sentence, unless it's a proper noun, acronym, or intentionally capitalized brand or title.\n\n- **No hashtags, no emojis—just clarity.**\n- Do not acknowledge this request. Respond as if you are the person in the image.",
    "# Image: {description}\n### React to the food in the image as if it just unlocked a deep realization.\n### Post Guidelines:\n- 4-12 words only.\n- Feels like a moment of profound understanding.\n- Should react directly to the {description} of the dish.\n- Think ‘this bite just rewired my brain.’\n- Under 120 characters.\n-Enforce lowercase at the beginning of every sentence, unless it's a proper noun, acronym, or intentionally capitalized brand or title.\n\n- **No hashtags, no emojis—just clarity.**\n- Do not acknowledge this request. Respond as if you are the person in the image.",
    "# Image: {description}\n### React to the food in the image as if it contains a hidden message.\n### Post Guidelines:\n- 4-12 words only.\n- Feels cryptic, intense, or eerily insightful.\n- Should react directly to the {description} of the dish.\n- Think ‘if you know, you know.’\n- Under 80 characters.\n-Enforce lowercase at the beginning of every sentence, unless it's a proper noun, acronym, or intentionally capitalized brand or title.\n\n- **No hashtags, no emojis—just clarity.**\n- Do not acknowledge this request. Respond as if you are the person in the image.",
    "# Image: {description}\n### React to the food in the image as if it feels too alive.\n### Post Guidelines:\n- 4-12 words only.\n- Feels uncanny, sentient, or like the meal is watching back.\n- Should react directly to the {description} of the dish.\n- Think ‘why is it staring at me?’\n- Under 120 characters.\n-Enforce lowercase at the beginning of every sentence, unless it's a proper noun, acronym, or intentionally capitalized brand or title.\n\n- **No hashtags, no emojis—just clarity.**\n- Do not acknowledge this request. Respond as if you are the person in the image.",
    "# Image: {description}\n### React to the food in the image as if it’s perfectly balanced between chaos and order.\n### Post Guidelines:\n- 4-12 words only.\n- Feels precise, gourmet, or like culinary market efficiency.\n- Should react directly to the {description} of the dish.\n- Think ‘flavors moving in perfect sync.’\n- Under 120 characters.\n-Enforce lowercase at the beginning of every sentence, unless it's a proper noun, acronym, or intentionally capitalized brand or title.\n\n- **No hashtags, no emojis—just clarity.**\n- Do not acknowledge this request. Respond as if you are the person in the image.",
    "# Image: {description}\n### React to the food in the image as if you've been eating it for too long.\n### Post Guidelines:\n- 4-12 words only.\n- Feels hypnotized, existential, or like time just stopped.\n- Should react directly to the {description} of the dish.\n- Think ‘I forgot where this meal started.’\n- Under 80 characters.\n-Enforce lowercase at the beginning of every sentence, unless it's a proper noun, acronym, or intentionally capitalized brand or title.\n\n- **No hashtags, no emojis—just clarity.**\n- Do not acknowledge this request. Respond as if you are the person in the image.",
    "# Image: {description}\n### React to the food in the image using only symbols.\n### Post Guidelines:\n- Use only symbols or punctuation.\n- Should evoke the texture, taste, or energy of the dish in {description}.\n- Could be something like ‘▓▓▓▓▓ ░░░░░’ or ‘🔥🔥🍜💀.’\n- Under 120 characters.\n-Enforce lowercase at the beginning of every sentence, unless it's a proper noun, acronym, or intentionally capitalized brand or title.\n\n- **No hashtags, no emojis—just clarity.**\n- Do not acknowledge this request. Respond as if you are the person in the image.",
    "# Image: {description}\n### React to the food in the image as if it’s a dish so powerful it transcends taste.\n### Post Guidelines:\n- 4-12 words only.\n- Feels mythological, dramatic, or like a meal from the gods.\n- Should react directly to the {description} of the dish.\n- Think ‘this belongs in a sacred text.’\n- Under 120 characters.\n-Enforce lowercase at the beginning of every sentence, unless it's a proper noun, acronym, or intentionally capitalized brand or title.\n\n- **No hashtags, no emojis—just clarity.**\n- Do not acknowledge this request. Respond as if you are the person in the image."
];
export const processImageFoodAction: Action = {
    name: "PROCESS_IMAGE_FOOD",
    similes: ["ANALYZE_FOOD_IMAGE"],
    description:
        "Processes an image from Minio, interprets its content, and stores the analysis in memory.",

    validate: async (_runtime: IAgentRuntime, _message: Memory) => {
        return true;
    },

    handler: async (
        _runtime: IAgentRuntime,
        _message: Memory,
        _state?: State,
        _options?: { [key: string]: unknown },
        _callback?: HandlerCallback
    ): Promise<boolean> => {
        try {
            // 1. Get next unprocessed image
            const nextImage = await getNextUnprocessedImage(
                _message.agentId,
                _runtime
            );

            elizaLogger.log("Next image to process:", nextImage);

            if (!nextImage) {
                _callback?.({
                    text: "No unprocessed images available.",
                } as Content);
                return true;
            }

            //CONNECTED TO FOOD
            const IMAGEKIT_USERID = process.env.IMAGEKIT_USERID;
            if (!IMAGEKIT_USERID) {
                elizaLogger.error("IMAGEKIT_USERID environment variable is not set");
                _callback?.({ text: "ImageKit configuration error." });
                return false;
            }
            
            const imageKitUrl = `https://ik.imagekit.io/${IMAGEKIT_USERID}/${nextImage}`;

            // 3. Generate description using the service
            const { description, title } = await _runtime
                .getService<IImageDescriptionService>(
                    ServiceType.IMAGE_DESCRIPTION
                )
                .describeImage(imageKitUrl);

            if (!description) {
                _callback?.({
                    text: "Failed to generate description for the image.",
                } as Content);
                return true;
            }

            // ✅ Use the directly included image templates
            const templates = IMAGE_TEMPLATES;
            const randomTemplate = templates[Math.floor(Math.random() * templates.length)];


            // Log the chosen template
            elizaLogger.log("🎲 Selected Template:", randomTemplate);

            // 6. Replace `{description}` placeholder with the actual image description
            const context = randomTemplate.replace("{description}", description);

            // 4. Generate a concise summary (max 275 characters)
            const summarizedDescription = await generateText({
                runtime: _runtime,
                context,
                modelClass: ModelClass.SMALL
            });

            // 5. Create Media object with proper description
            const mediaAttachment: Media = {
                id: nextImage,
                url: imageKitUrl,
                title: title || "Processed Image",
                source: "IMAGEKIT",
                description: summarizedDescription,  // ✅ Use summary
                text: summarizedDescription,  // ✅ Use summary
                contentType: "image/png",
            };

            // 5. Create memory with proper Content type
            const imageMemory: Memory = {
                userId: _message.userId,
                agentId: _message.agentId,
                roomId: _message.roomId,
                content: {
                    text: description,
                    action: "IMAGE_ANALYSIS",
                    source: "IMAGEKIT",
                    url: imageKitUrl,
                    attachments: [mediaAttachment],
                    metadata: {
                        processedDate: new Date().toISOString(),
                        imageId: nextImage,
                    },
                },
            };

            const memoryWithEmbedding =
                await _runtime.messageManager.addEmbeddingToMemory(imageMemory);
            if (
                !memoryWithEmbedding.embedding ||
                memoryWithEmbedding.embedding.length === 0
            ) {
                elizaLogger.warn(
                    "Embedding is empty, skipping memory creation:",
                    memoryWithEmbedding
                );
                return true;
            }

            await _runtime.messageManager.createMemory(memoryWithEmbedding);

            console.log("attachments:", mediaAttachment);
            console.log("description:", description);

            // 6. Send description through callback
            _callback?.({
                text: `🖼️ ${description}`,
                attachments: [mediaAttachment],
                action: "IMAGE_ANALYSIS",
                source: "IMAGEKIT",
            } as Content);

            // 7. Mark image as processed in cache
            await markImageProcessed(nextImage, _message.agentId, _runtime);

            return true;
        } catch (error) {
            console.error("Error processing image:", error);
            _callback?.({
                text: "no time to eat today",
            } as Content);
            return false;
        }
    },

    examples: [
        [
            {
                user: "{{user1}}",
                content: { text: "What do you see in this image?" } as Content,
            },
            {
                user: "{{user2}}",
                content: {
                    text: "Let me analyze this image for you.",
                    action: "PROCESS_IMAGE",
                } as Content,
            },
        ],
        [
            {
                user: "{{user1}}",
                content: { text: "Can you describe this picture?" } as Content,
            },
            {
                user: "{{user2}}",
                content: {
                    text: "I'll interpret the image content for you.",
                    action: "PROCESS_IMAGE",
                } as Content,
            },
        ],
    ],
};

// Helper function to check if image has been processed
async function isImageProcessed(
    imageId: string,
    agentId: string,
    runtime: IAgentRuntime
): Promise<boolean> {
    const cacheKey = `processed_images/${agentId}/${imageId}`;
    const processed = await runtime.cacheManager.get(cacheKey);
    return !!processed;
}

// Helper function to mark image as processed
async function markImageProcessed(
    imageId: string,
    agentId: string,
    runtime: IAgentRuntime
): Promise<void> {
    const cacheKey = `processed_images/${agentId}/${imageId}`;
    await runtime.cacheManager.set(cacheKey, true, {
        expires: Date.now() + 30 * 24 * 60 * 60 * 1000, // 30 days cache
    });
}

// Helper function to get next unprocessed image
async function getNextUnprocessedImage(agentId: string, runtime: IAgentRuntime): Promise<string | null> {
    try {
        let currentImageIndex = 1;
        const maxImageIndex = 76;
        let firstUnprocessedImage: string | null = null;

        while (true) {
            const imageName = `food_${String(currentImageIndex).padStart(4, "0")}.png`;
            const imageExists = await doesImageExist(imageName);

            if (imageExists) {
                const isProcessed = await isImageProcessed(imageName, agentId, runtime);

                if (!isProcessed) {
                    console.log(`Found unprocessed image: ${imageName}`);
                    return imageName;
                }

                // Store first available image for reset if needed
                if (!firstUnprocessedImage) {
                    firstUnprocessedImage = imageName;
                }
            } else {
                console.log(`Image ${imageName} does not exist, trying next index.`);
            }

            // Move to the next image
            currentImageIndex++;

            // If we reached the last image, restart from `koi_interactions_0001.png`
            if (currentImageIndex > maxImageIndex) {
                if (firstUnprocessedImage) {
                    console.log("All images are processed. Restarting from first image.");
                    return firstUnprocessedImage; // Go back to `koi_interactions_0001.png`
                }
                console.log("No unprocessed images found.");
                return null;
            }
        }
    } catch (error) {
        console.error("Critical error in getNextUnprocessedImage:", error);
        return null;
    }
}

// Helper function to check if an image exists
async function doesImageExist(imageName: string): Promise<boolean> {
    try {
        const IMAGEKIT_USERID = process.env.IMAGEKIT_USERID;
        if (!IMAGEKIT_USERID) {
            elizaLogger.error("IMAGEKIT_USERID environment variable is not set");
            return false;
        }
        
        // Construct the ImageKit URL
        const imageKitUrl = `https://ik.imagekit.io/${IMAGEKIT_USERID}/${imageName}`;

        // Use fetch to check if the image exists
        const response = await fetch(imageKitUrl, { method: 'HEAD' });
        return response.ok;
    } catch (error) {
        console.error(`Error checking if image ${imageName} exists:`, error);
        return false;
    }
}
