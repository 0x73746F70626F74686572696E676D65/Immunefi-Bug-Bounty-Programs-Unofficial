import DirectClientInterface from "../src/index";

// This test will fail to run if the TypeScript compiler can not successfully compile the module.
describe("Type instantiation regression", () => {
  it("compiles without type instantiation overflow", () => {
    // The test body can remain empty – merely importing the module forces the
    // TypeScript compiler (via ts-jest) to type-check it. If the previous
    // “Type instantiation is excessively deep and possibly infinite” error
    // resurfaces, this spec will never execute.
    expect(true).toBe(true);
  });
});
