import {
    elizaLogger,
    type Action,
    type HandlerCallback,
    type IAgentRuntime,
    type Memory,
    type State,
} from "@elizaos/core";

import { initWalletProvider } from "../providers/wallet";

export const balanceAction: Action = {
    name: "balance",
    description: "Check wallet balance on the SEI network",
    handler: async (
        runtime: IAgentRuntime,
        message: Memory,
        state: State,
        _options: Record<string, unknown>,
        callback?: HandlerCallback
    ) => {
        elizaLogger.debug("Balance action handler called");
        
        try {
            const walletProvider = await initWalletProvider(runtime);
            const address = walletProvider.getAddress();
            const balance = await walletProvider.getWalletBalance();
            const chain = walletProvider.getCurrentChain();
            
            if (balance === null) {
                if (callback) {
                    callback({
                        text: `Unable to fetch balance. Please check your wallet configuration and network connection.`,
                        content: { error: "Failed to fetch balance" },
                    });
                }
                return false;
            }

            if (callback) {
                callback({
                    text: `Wallet Balance: ${balance} ${chain.chain.nativeCurrency.symbol}\nAddress: ${address}\nChain: ${chain.name}`,
                    content: {
                        success: true,
                        balance: balance,
                        address: address,
                        chain: chain.name,
                        symbol: chain.chain.nativeCurrency.symbol,
                    },
                });
            }
            return true;
        } catch (error) {
            elizaLogger.error("Error during balance check:", error);
            if (callback) {
                callback({
                    text: `Error checking balance: ${error.message}`,
                    content: { error: error.message },
                });
            }
            return false;
        }
    },
    validate: async (runtime: IAgentRuntime) => {
        const privateKey = runtime.getSetting("SEI_PRIVATE_KEY");
        return typeof privateKey === "string" && privateKey.startsWith("0x");
    },
    examples: [
        [
            {
                user: "user",
                content: {
                    text: "What's my wallet balance?",
                },
            },
            {
                user: "assistant",
                content: {
                    text: "I'll check your wallet balance for you.",
                    action: "BALANCE",
                },
            },
        ],
        [
            {
                user: "user",
                content: {
                    text: "Show me my SEI balance",
                },
            },
            {
                user: "assistant",
                content: {
                    text: "Let me check your SEI wallet balance.",
                    action: "BALANCE",
                },
            },
        ],
    ],
    similes: ["SEI_WALLET_BALANCE", "CHECK_SEI_BALANCE", "GET_SEI_WALLET_BALANCE", "MY_SEI_BALANCE", "WALLET_BALANCE_SEI", "SEI_BALANCE_CHECK"],
}; 