# plugin-hadrien

A plugin for Hadrien integration, providing scheduled content generation, image analysis, meme creation, and Twitter automation.

---

## Running Hadrien Client

- Copy .env.example to .env
- Set these env variables
- `DUNE_API_KEY`, `WORLD_NEWS_API_KEY`, `NEWS_API_KEY`, `IMGFLIP_USERNAME`, `IMGFLIP_PASSWORD`, `FINNHUB_API_KEY`
- `TWITTER_USERNAME`, `TWITTER_PASSWORD`, `TWITTER_EMAIL`, `ACTION_INTERVAL`
- These next data can be retrieved from application/cookies tab of your browser.
- `TWITTER_COOKIES_AUTH_TOKEN`, `TWITTER_COOKIES_CT0`, `TWITTER_COOKIES_GUEST_ID`
- Then set the target users in a comma seperated string only, like `coinbase,VitalikButerin,....`
- On env variables `ACTION_INTERVAL` sets the time between each round of timeline processing.
- On env variables `TWITTER_POLL_INTERVAL` sets the time between each round of selected users and mentions.

With these enabled,
first run
- `nvm use` It expects node version higher than 23
- `pnpm build`
- `pnpm start --character=characters/sensei1202.character.json`
- on a different terminal run `pnpm start:client`

- For scheduled workflows: first check the dates and times set on hadrienClient.ts file. Update your timezone and update the cron 
schedule. Then the scheduled actions will run. Tested worklfows are: 
  - World news,
  - Stock News: Also looks for the imagekit io. Must have relevant image contents with koi_0001.jpg ... and so on,
  - Sei Analytics
  - Business News,
  - Dune Analytics: Also looks for the imagekit io. Must have relevant image contents with yoga_0001.jpg ... and so on,
  - Image processing koi
- Generate meme. For this I have modified the character json and the generateMeme actions. It will fetch a template, use llm
  to get the context and then it will generate a meme.
- Twitter Actions: 
  - It will process the timeline of the user and interact with one of the selected tweet. 
  - It will process and check the tweets of the target user list and interact with them. 
  - It will process and check the interactions of the bots tweets and reply and interact with them.
  - The intervals can be set on the env file.
- Image processing: 
  - It is currently uses imagekit to fetch and process images. For koi it expects koi_0001.jpg ... and so on. The naming
  of the images should be checked. 

## Environment Variables

### Required for plugin-hadrien:
- `DUNE_API_KEY` — API key for Dune Analytics (blockchain analytics)
- `DUNE_QUERY_ID` - Query ID for sei chain analytics (Needs multiple so I ended up hardcoding on sei analytics)
- `WORLD_NEWS_API_KEY` — API key for World News API
- `NEWS_API_KEY` — API key for Business News API
- `IMGFLIP_USERNAME` — Username for Imgflip meme generation
- `IMGFLIP_PASSWORD` — Password for Imgflip meme generation
- `FINNHUB_API_KEY` — API key for Finnhub (stock data)
- 
### Required for client-twitter (Twitter automation):

- `TWITTER_DRY_RUN` — (boolean) If true, no tweets are actually posted
- `TWITTER_USERNAME` — Twitter/X username
- `TWITTER_PASSWORD` — Twitter/X password
- `TWITTER_EMAIL` — Twitter/X email
- `TWITTER_2FA_SECRET` — Twitter/X 2FA secret (if enabled)
- `TWITTER_RETRY_LIMIT` — Number of login retries
- `TWITTER_POLL_INTERVAL` — Polling interval (seconds) for fetching mentions/interactions
- `TWITTER_TARGET_USERS` — Comma-separated list of usernames to prioritize
- `ENABLE_TWITTER_POST_GENERATION` — (boolean) Enable/disable autonomous posting
- `POST_INTERVAL_MIN` — Minimum interval (minutes) between posts
- `POST_INTERVAL_MAX` — Maximum interval (minutes) between posts
- `ENABLE_ACTION_PROCESSING` — (boolean) Enable/disable action processing
- `ACTION_INTERVAL` — Interval (minutes) for action processing
- `POST_IMMEDIATELY` — (boolean) Post immediately after generation
- `TWITTER_SPACES_ENABLE` — (boolean) Enable Twitter Spaces features
- `MAX_ACTIONS_PROCESSING` — Max actions processed per cycle
- `ACTION_TIMELINE_TYPE` — Timeline type for action processing
- `QUIET_HOURS_START` — Start of quiet hours (hour, 0-23)
- `QUIET_HOURS_END` — End of quiet hours (hour, 0-23)
- `TWITTER_APPROVAL_ENABLED` — (boolean) Enable Discord approval workflow
- `TWITTER_APPROVAL_DISCORD_BOT_TOKEN` — Discord bot token for approval
- `TWITTER_APPROVAL_DISCORD_CHANNEL_ID` — Discord channel ID for approval
- `TWITTER_APPROVAL_CHECK_INTERVAL` — Interval (ms) for approval checks
---

## Cron Jobs Overview

plugin-hadrien uses `node-cron` to schedule a variety of content and image processing tasks. Each job is defined with a cron expression and runs in the configured timezone (e.g., Europe/Istanbul).

**Examples of scheduled tasks:**
- **Business News:** Fetch and summarize business news, post as a thread.
- **Fun Fact:** Post a random fun fact.
- **World News:** Fetch and summarize world news.
- **Image Processing:** Analyze and describe themed images (koi, work, art, yoga, etc.) and store results in memory.
- **Stock Data:** Fetch and summarize stock data for a random company.
- **Dune Analytics:** Fetch and summarize blockchain analytics data.
- **Sei Analytics:** Fetch and summarize sei analytics data.
