# Sei Agent Setup Guide

This comprehensive guide will walk you through setting up your Sei Agent from scratch, including troubleshooting common issues and advanced configuration options.

## Table of Contents

1. [Prerequisites](#prerequisites)
2. [Installation](#installation)
3. [Environment Configuration](#environment-configuration)
4. [Database Setup](#database-setup)
5. [Character Configuration](#character-configuration)
6. [API Keys](#api-keys)
7. [Twitter Configuration](#twitter-configuration)
8. [Job Scheduling](#job-scheduling)
9. [Testing & Debugging](#testing--debugging)
10. [Troubleshooting](#troubleshooting)
11. [Advanced Configuration](#advanced-configuration)

---

## Prerequisites

### Required Software

- **Node.js v23.3.0**: The project requires this specific version
  ```bash
  # Install and use Node v23.3.0
  nvm install 23.3.0
  nvm use 23.3.0
  ```

- **pnpm**: Package manager
  ```bash
  npm install -g pnpm
  ```

### Required Accounts & API Keys

- **OpenAI Platform Account**: For AI text generation
- **Twitter Account**: For the bot to operate (create a dedicated account)
- **Optional**: Various data provider accounts (see API Keys section)

---

## Installation

1. **Clone the repository**
   ```bash
   git clone https://github.com/your-org/sei-agent.git
   cd sei-agent
   ```

2. **Switch to correct Node version**
   ```bash
   nvm use  # Uses version from .nvmrc file
   ```

3. **Install dependencies**
   ```bash
   pnpm install
   ```

---

## Environment Configuration

1. **Create environment file**
   ```bash
   cp .env.example .env
   ```

2. **Edit the `.env` file** with your configuration:
   ```env
   # Database Configuration (REQUIRED)
   SQLITE_FILE=./data/db.sqlite
   
   # OpenAI Configuration (REQUIRED)
   OPENAI_API_KEY=sk-proj-your-key-here
   
   # Twitter Configuration (REQUIRED)
   TWITTER_USERNAME=your_bot_username
   TWITTER_PASSWORD=your_bot_password
   TWITTER_EMAIL=your_bot_email
   TWITTER_DRY_RUN=false
   
   # Target Users for Engagement (REQUIRED)
   TWITTER_TARGET_USERS=ethereum,binance,coinbase,unusual_whales
   
   # SEI Network Configuration (REQUIRED)
   SEI_PRIVATE_KEY=your_private_key_here
   SEI_NETWORK=mainnet
   SEI_RPC_URL=
   
   # Optional API Keys (for enhanced features)
   S3_BUCKET=
   FINNHUB_API_KEY=
   WORLD_NEWS_API_KEY=
   NEWS_API_KEY=
   IMAGEKIT_USERID=
   IMGFLIP_USERNAME=
   IMGFLIP_PASSWORD=
   ```

### Important Environment Variables

| Variable | Required | Description |
|----------|----------|-------------|
| `OPENAI_API_KEY` | ✅ | OpenAI Platform API key for text generation |
| `TWITTER_USERNAME` | ✅ | Twitter username for the bot account |
| `TWITTER_PASSWORD` | ✅ | Twitter password for the bot account |
| `TWITTER_EMAIL` | ✅ | Twitter email for the bot account |
| `SQLITE_FILE` | ✅ | SQLite database file path |
| `TWITTER_TARGET_USERS` | ✅ | Comma-separated list of accounts to engage with |
| `SEI_PRIVATE_KEY` | ✅ | Private key for Sei network interactions |
| `SEI_NETWORK` | ✅ | Sei network (mainnet/testnet/devnet) |
| `TWITTER_DRY_RUN` | ❌ | Set to `true` to test without posting |
| `S3_BUCKET` | ❌ | AWS S3 bucket for image storage |
| `FINNHUB_API_KEY` | ❌ | Stock market data API key |
| `NEWS_API_KEY` | ❌ | News API key for content generation |

---

## Database Setup

The agent uses SQLite for data storage. You need to create the database file:

```bash
# Create the data directory and SQLite file
mkdir -p data
touch data/db.sqlite

# Verify the file was created
ls -la data/db.sqlite
```

## Character Configuration

### Using Existing Characters

The agent comes with pre-built character files:

```bash
# Start with the default Sei character
pnpm start --character=characters/sensei1202.character.json
```

### Character File Structure

Character files define the bot's personality, behavior, and scheduling:

```json
{
  "name": "Sensei1202",
  "bio": "A zen master of crypto markets...",
  "characterBios": {
    "aspects": {
      "trader": {
        "bio": "Primary trading personality",
        "weight": 5,
        "templates": ["Market analysis templates..."]
      },
      "meditation": {
        "bio": "Zen and mindfulness content",
        "weight": 4,
        "schedules": [
          {
            "days": [6, 7],
            "hours": [5],
            "intensity": 0.8
          }
        ]
      }
    }
  }
}
```

### Creating Custom Characters

1. Copy an existing character file
2. Modify the `name`, `bio`, and aspects
3. Adjust schedules and templates
4. Test with dry run mode

---

## API Keys

### OpenAI API Key (Required)

1. Go to [OpenAI Platform](https://platform.openai.com/account/api-keys)
2. Create a new API key
3. Add to `.env` file:
   ```env
   OPENAI_API_KEY=sk-proj-your-key-here
   ```

**Important**: Format correctly without quotes or extra characters!

### Optional API Keys

.env.example.full contains most of the optional API keys. You can copy the file to .env and fill in the values.

---

## Twitter Configuration

### Basic Setup

1. **Create a dedicated Twitter account** for your bot
2. **Add credentials to `.env`**:
   ```env
   TWITTER_USERNAME=your_bot_username
   TWITTER_PASSWORD=your_bot_password
   TWITTER_EMAIL=your_bot_email
   ```

### Engagement Modes

#### Mode 1: Mention-Only (Default)
- Bot only responds to mentions
- No target users needed
- Safer for testing

#### Mode 2: Active Engagement
- Bot actively engages with specified accounts
- Configure target users:
  ```env
  TWITTER_TARGET_USERS=ethereum,binance,coinbase,unusual_whales
  ```

---

## Job Scheduling

### Understanding Schedules

Jobs are defined in the packages/plugin-hadrien/src/hadrienClient.ts file.
```ts
{ cronTime: "11 15 * * 1,2,3,4,5,6,7", action: this.triggerImageProcessingKoi.bind(this), name: "Image Processing" }
{ cronTime: "00 15 * * 7", action: this.triggerImageProcessingOnsen.bind(this), name: "Image Processing" }
```

### Current Default Jobs

| Job | Schedule | Description |
|-----|----------|-------------|
| Business News | Mon-Fri + Sun at 2:50 PM CST | Market and business updates |
| Fun Fact | Daily at 2:53 PM CST | Engaging educational content |
| World News | Daily at 3:05 PM CST | Global news updates |
| Stock Data | Mon-Fri + Sun at 3:32 PM CST | Market data and analysis |
| Dune Analytics | Mon-Fri + Sun at 4:09 PM CST | On-chain analytics |
| Sei Analytics | Mon-Fri + Sun at 4:12 PM CST | Sei network statistics |

### Customizing Schedules

#### To Disable a Job
Remove or comment out the schedule entry:
```ts
const schedules = [
    // { cronTime: "50 14 * * 1,2,3,4,5,7", action: this.triggerBusinessNews.bind(this), name: "Business News" },
    { cronTime: "12 16 * * 1,2,3,4,5,7", action: this.triggerSeiAnalytics.bind(this), name: "Sei Analytics (Daily at 9 AM CST)" },
]
```

#### To Add a New Job
1. Create an action on plugin-hadrien/src/actions file.
2. Define triggers.
3. Add a schedule on plugin-hadrien/src/hadrienClient.ts file.

#### To Modify Timing
Change the `days`, `hours` values:
```ts
{ cronTime: "50 14 * * 1,2,3,4,5,7", action: this.triggerBusinessNews.bind(this), name: "Business News" }
```
Here 50 is the minute, 14 is the hour, and * is for every day of month and every month. 1,2,3,4,5,7 are the days of the week.
---

## Testing & Debugging

### Dry Run Mode

Test your bot without actually posting to Twitter:

```env
TWITTER_DRY_RUN=true
```

### Starting the Agent

```bash
# Start with character file
pnpm start --character=characters/sensei1202.character.json

# Start the client interface (optional)
pnpm start:client
```

## Troubleshooting

### Common Issues

#### 1. "aspects" Error with Default Character
**Problem**: Using default Eliza character causes runtime errors
**Solution**: Always specify a character file:
```bash
pnpm start --character=characters/sensei1202.character.json
```

#### 2. Database Directory Error
**Problem**: "Cannot open database because the directory does not exist"
**Solution**: Create the data directory:
```bash
mkdir -p data
```

#### 3. Node Version Issues
**Problem**: Compatibility errors or unexpected behavior
**Solution**: Ensure you're using Node v23.3.0:
```bash
nvm use 23.3.0
node --version  # Should show v23.3.0
```

#### 4. Twitter Login Issues
**Problem**: Bot can't log into Twitter
**Solutions**:
- Verify credentials in `.env`
- Check if account is locked/suspended
- Ensure 2FA is disabled or properly configured
- Try clearing cookies (delete any cached session files)

#### 5. No Posts Generated
**Problem**: Bot starts but doesn't post
**Solutions**:
- Check `ENABLE_TWITTER_POST_GENERATION=true`
- Verify `TWITTER_DRY_RUN=false`
- Ensure OpenAI API key is valid
- Check if it's during quiet hours

### Getting Help

1. **Check the logs** for specific error messages
2. **Verify your `.env` configuration**
3. **Test with dry run mode** first
4. **Review the character file** for syntax errors
5. **Check API key validity** and rate limits

### Debug Commands

```bash
# Check Node version
node --version

# Verify dependencies
pnpm list

# Test environment variables
echo $OPENAI_API_KEY

# Check database permissions
ls -la data/
```

---

## Advanced Configuration

### Multiple Agents

Run multiple agents with different characters:
```bash
# Terminal 1
pnpm start --character=characters/trader.character.json

# Terminal 2  
SERVER_PORT=3001 pnpm start --character=characters/analyst.character.json
```

### Custom Plugins

Extend functionality by creating custom plugins in the `plugins/` directory.

### Performance Tuning

Adjust these settings for better performance:
```env
# Reduce API calls
POST_INTERVAL_MIN=120
POST_INTERVAL_MAX=240

# Limit concurrent operations
MAX_ACTIONS_PROCESSING=1

# Adjust polling frequency
TWITTER_POLL_INTERVAL=300
```

---

## Next Steps

Once your agent is running successfully:

1. **Monitor performance** and adjust settings
2. **Customize the character** to match your brand
3. **Add new data sources** via plugins
4. **Scale with multiple agents** for different purposes
5. **Contribute back** to the open source project

Happy botting! 🤖✨
