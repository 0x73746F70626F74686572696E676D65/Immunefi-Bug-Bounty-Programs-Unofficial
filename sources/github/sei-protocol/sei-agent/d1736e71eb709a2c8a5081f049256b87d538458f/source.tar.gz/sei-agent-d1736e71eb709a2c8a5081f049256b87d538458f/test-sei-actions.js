const fs = require('fs');
const path = require('path');

async function testSeiActions() {
    console.log('Testing SEI Plugin Actions...');
    
    try {
        // Load character configuration
        const characterPath = path.join(__dirname, 'characters/sensei1202.character.json');
        const characterData = fs.readFileSync(characterPath, 'utf8');
        const character = JSON.parse(characterData);
        
        console.log('Character loaded successfully');
        console.log('Character name:', character.name);
        console.log('Plugins:', character.plugins);
        
        // Check if SEI plugin is loaded
        if (character.plugins && character.plugins.includes('@elizaos/plugin-sei')) {
            console.log('✅ SEI plugin is configured');
        } else {
            console.log('❌ SEI plugin is not configured');
        }
        
        // Check if actions are configured
        if (character.actions && character.actions.length > 0) {
            console.log('✅ Actions are configured:');
            character.actions.forEach(action => {
                console.log(`  - ${action.name}: ${action.description}`);
                console.log(`    Similes: ${action.similes.join(', ')}`);
            });
        } else {
            console.log('❌ No actions configured');
        }
        
        // Check SEI settings
        if (character.settings && character.settings.secrets) {
            const secrets = character.settings.secrets;
            console.log('SEI Settings:');
            console.log(`  - SEI_PRIVATE_KEY: ${secrets.SEI_PRIVATE_KEY ? 'Set' : 'Not set'}`);
            console.log(`  - SEI_NETWORK: ${secrets.SEI_NETWORK || 'Not set'}`);
            console.log(`  - SEI_RPC_URL: ${secrets.SEI_RPC_URL || 'Not set'}`);
            
            // Check if the private key is the default placeholder
            if (secrets.SEI_PRIVATE_KEY === "0x0000000000000000000000000000000000000000000000000000000000000000") {
                console.log('⚠️  Warning: SEI_PRIVATE_KEY is set to default placeholder. You need to set a real private key.');
            }
        } else {
            console.log('❌ No SEI settings found');
        }
        
        console.log('\nSummary:');
        console.log('- To use transfer action: Ask "Transfer 1 SEI to 0x742d35Cc6634C0532925a3b844Bc454e4438f44e"');
        console.log('- To use balance action: Ask "What is my wallet balance?" or "Check my SEI balance"');
        console.log('- Make sure to set a real SEI_PRIVATE_KEY in the character configuration');
        
    } catch (error) {
        console.error('Error testing SEI actions:', error);
    }
}

testSeiActions(); 