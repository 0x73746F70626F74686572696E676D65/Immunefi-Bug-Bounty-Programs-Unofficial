const fs = require('fs');
const path = require('path');

// Simulate the dotenv loading that the application does
const dotenv = require('dotenv');

console.log('🔍 Testing .env file loading...');

// Load the .env file
const envPath = path.resolve(__dirname, '.env');
console.log('Loading .env from:', envPath);

const result = dotenv.config({ path: envPath });

if (result.error) {
    console.error('❌ Error loading .env file:', result.error);
} else {
    console.log('✅ .env file loaded successfully');
}

// Check if SEI_NETWORK is available
console.log('SEI_NETWORK from process.env:', process.env.SEI_NETWORK);

// Test the chain info action with the loaded environment
const chainInfoAction = {
    name: "CHAIN_INFO",
    handler: async (runtime, message, state, options, callback) => {
        try {
            // Get the chain information from environment variable
            const chainInfo = process.env.SEI_NETWORK || "Chain information not available";
            
            console.log('🔍 Action handler called');
            console.log('🔍 SEI_NETWORK value:', process.env.SEI_NETWORK);
            console.log('🔍 Chain info:', chainInfo);
            
            callback?.(
                {
                    text: `Your chain is: ${chainInfo}`,
                },
                []
            );
            return true;
        } catch (error) {
            console.error('❌ Error in action handler:', error);
            return false;
        }
    }
};

// Test the action
async function testAction() {
    console.log('\n--- Testing Chain Info Action ---');
    
    const result = await chainInfoAction.handler(
        null, // runtime
        { content: { text: "What is my chain?" } }, // message
        {}, // state
        {}, // options
        (response) => {
            console.log('✅ Response:', response.text);
        }
    );
    
    console.log('✅ Action result:', result);
}

testAction(); 