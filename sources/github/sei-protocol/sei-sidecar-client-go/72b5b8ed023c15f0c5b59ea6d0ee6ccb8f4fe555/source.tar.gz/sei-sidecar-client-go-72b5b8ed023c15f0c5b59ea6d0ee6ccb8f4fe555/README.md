# sei-sidecar-client-go

Go client library for the **sei-sidecar** HTTP API, generated from an [OpenAPI 3.1 spec](api/openapi.yaml) using [oapi-codegen](https://github.com/oapi-codegen/oapi-codegen).

## Installation

```bash
go get github.com/sei-protocol/sei-sidecar-client-go
```

## Usage

```go
import sidecar "github.com/sei-protocol/sei-sidecar-client-go"

client, err := sidecar.NewClientWithResponses("http://localhost:7777")
if err != nil {
    log.Fatal(err)
}

resp, err := client.GetStatusWithResponse(ctx)
if err != nil {
    log.Fatal(err)
}
fmt.Println(resp.JSON200.Status)
```

## Regenerating the client

After editing `api/openapi.yaml`:

```bash
make generate
```

This runs `oapi-codegen` via the `go:generate` directive in `generate.go`.

## API overview

| Endpoint                    | Method | Description                          |
|-----------------------------|--------|--------------------------------------|
| `/healthz`                  | GET    | Liveness / readiness probe           |
| `/status`                   | GET    | Current sidecar status + last task   |
| `/task`                     | POST   | Submit a task or create a schedule   |
| `/schedules`                | GET    | List active cron schedules           |
| `/schedules/{scheduleId}`   | DELETE | Remove a cron schedule               |
