module github.com/sei-protocol/sei-sidecar-client-go

go 1.25.6

require (
	github.com/google/uuid v1.5.0
	github.com/leanovate/gopter v0.2.11
	github.com/oapi-codegen/runtime v1.2.0
)

require github.com/apapsch/go-jsonmerge/v2 v2.0.0 // indirect
