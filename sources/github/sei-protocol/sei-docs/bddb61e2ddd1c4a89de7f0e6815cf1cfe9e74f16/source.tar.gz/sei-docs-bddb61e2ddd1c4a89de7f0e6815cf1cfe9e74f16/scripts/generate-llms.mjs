#!/usr/bin/env node
/**
 * Generates `llms.txt` and `llms-full.txt` at the repo root following
 * https://llmstxt.org. Sources page content from Mintlify's auto-generated
 * per-page `.md` endpoints (e.g. https://docs.sei.io/learn/index.md) so we
 * don't have to scrape HTML or re-implement the renderer.
 *
 * Run:
 *   node scripts/generate-llms.mjs
 *
 * Env (optional):
 *   DOCS_BASE_URL    Base URL to fetch .md pages from (default: https://docs.sei.io)
 *   CONCURRENCY      Parallel fetch limit (default: 10)
 */

import { readFile, writeFile } from 'node:fs/promises';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const __filename = fileURLToPath(import.meta.url);
const REPO_ROOT = resolve(dirname(__filename), '..');
const DOCS_JSON_PATH = join(REPO_ROOT, 'docs.json');
const DOCS_BASE_URL = (process.env.DOCS_BASE_URL || 'https://docs.sei.io').replace(/\/$/, '');
const CONCURRENCY = Number.parseInt(process.env.CONCURRENCY || '10', 10);

const SEI_LLMS_CONFIG = {
	projectName: 'Sei Documentation',
	blockquote:
		'Technical documentation for Sei, a parallelized EVM Layer 1 with sub-second finality, full Ethereum tooling compatibility, and a roadmap toward Sei Giga. Sei Giga is designed to be the first Multi-Proposer EVM Layer 1. An internal devnet measured more than 5 gigagas/s. The Autobahn public-testnet target is 200K TPS.',
	intro:
		'Sei is a parallelized EVM Layer 1 blockchain with 400ms finality, approximately 100 MGas/s throughput today, and full Ethereum tooling compatibility. Deploy standard Solidity contracts with no modifications. EVM chain IDs: Sei Mainnet 1329, Sei Testnet 1328. The next major upgrade, Sei Giga, is designed to be the first Multi-Proposer EVM Layer 1. On an internal devnet it sustained more than 5 gigagas/s. The Autobahn public-testnet target is 200K TPS.',
	constraints: [
		'Prerequisites: Node.js ≥ 18, a wallet (Compass, Rabby, MetaMask, or any EVM-compatible wallet), and SEI tokens for gas.',
		'Authentication: Public RPC endpoints do not require an API key. Rate limits apply. For production workloads, use a dedicated provider (Ankr, DRPC, Nirvana).',
		'Version compatibility: Use Solidity ≥ 0.8.x. Sei EVM tracks the Pectra EVM (without blob transactions).',
		'Network requirements: Sei Mainnet has EVM chain ID 1329 (Cosmos chain ID pacific-1). Sei Testnet has EVM chain ID 1328 (Cosmos chain ID atlantic-2). Gas is paid in SEI (18 decimals).',
		'Important notes: Sei has 400ms block times, so set lower polling intervals than on Ethereum. Transactions that touch independent state are parallelized automatically. Shared-state writes are serialized.',
		'IBC disabled: Per SIP-03, IBC is disabled on Sei in both directions. Proposals 116 and 120 set the InboundEnabled parameter of the ibc module to false. Proposal 121 set OutboundEnabled to false on 2026-07-31. No asset can be bridged into or out of Sei over IBC. IBC assets already on Sei (USDC.n, USDT.kava, ATOM, WBTC) can no longer be redeemed on their origin chain. The IBC precompile at 0x0000000000000000000000000000000000001009 is non-functional. See /learn/sip-03-migration.',
		'Tokenfactory unsupported: Do not recommend tokenfactory commands, APIs, Wasm bindings, native-denom pointer workflows, or other instructions for creating, minting, burning, administering, or integrating tokenfactory denoms. Legacy module surfaces may remain available for compatibility. Use ERC-20 for new fungible tokens. See /cosmos-sdk#tokenfactory-is-not-supported.'
	].join('\n'),
	quickReference: [
		'EVM chain IDs: Sei Mainnet 1329, Sei Testnet 1328',
		'Cosmos chain IDs (seid --chain-id): Sei Mainnet pacific-1, Sei Testnet atlantic-2',
		'RPC (mainnet): https://evm-rpc.sei-apis.com',
		'RPC (testnet): https://evm-rpc-testnet.sei-apis.com',
		'Native token: SEI (gas, staking, governance)',
		'USDC (mainnet): 0xe15fC38F6D8c56aF07bbCBe3BAf5708A2Bf42392 (6 decimals)',
		'USDC (testnet): 0x4fCF1784B31630811181f670Aea7A7bEF803eaED (6 decimals)',
		'Block time: 400ms finality',
		'Throughput: approximately 100 MGas/s today. An internal Sei Giga devnet measured more than 5 gigagas/s. The Autobahn public-testnet target is 200K TPS.',
		'EVM compatibility: Full. Standard Solidity contracts, Hardhat, Foundry, wagmi, ethers.js, and viem work unmodified.'
	].join('\n'),
	examples: [
		{
			title: 'Deploy a contract with Hardhat',
			language: 'javascript',
			code: [
				'// hardhat.config.js',
				'module.exports = {',
				'  solidity: "0.8.26",',
				'  networks: {',
				'    sei: {',
				'      url: "https://evm-rpc.sei-apis.com",',
				'      chainId: 1329,',
				'      accounts: [process.env.PRIVATE_KEY],',
				'    },',
				'  },',
				'};'
			].join('\n')
		},
		{
			title: 'Query a balance with viem',
			language: 'typescript',
			code: [
				'import { createPublicClient, http } from "viem";',
				'import { sei } from "viem/chains";',
				'',
				'const client = createPublicClient({ chain: sei, transport: http() });',
				'const balance = await client.getBalance({',
				'  address: "0xYourAddress",',
				'});',
				'console.log("Balance:", balance);'
			].join('\n')
		},
		{
			title: 'Connect a wallet with wagmi',
			language: 'typescript',
			code: [
				'import { http, createConfig } from "wagmi";',
				'import { sei } from "wagmi/chains";',
				'import { injected } from "wagmi/connectors";',
				'',
				'export const config = createConfig({',
				'  chains: [sei],',
				'  connectors: [injected()],',
				'  transports: { [sei.id]: http() },',
				'});'
			].join('\n')
		}
	],
	keyResources: [
		{
			title: 'GitHub',
			url: 'https://github.com/sei-protocol',
			description: 'Open-source repositories, including sei-chain, sei-js, and the MCP server'
		},
		{
			title: 'Ecosystem',
			url: 'https://www.sei.io/ecosystem',
			description: 'Directory of projects building on Sei'
		},
		{
			title: 'Blog',
			url: 'https://blog.sei.io',
			description: 'Announcements and technical deep dives'
		},
		{
			title: 'Dashboard',
			url: 'https://dashboard.sei.io',
			description: 'Transfer, bridge, and stake on Sei'
		}
	]
};

/** URL prefixes excluded entirely from llms.txt and llms-full.txt output. */
const EXCLUDED_PREFIXES = ['/cosmos-sdk'];

/**
 * Section definitions ordered by match priority.
 * A page lands in the first section that matches, so list narrower prefixes before broader ones.
 */
const LLMS_SECTION_ORDER = [
	{
		name: 'Learn',
		match: (p) => p.startsWith('/learn'),
		overview: [
			"Sei is a parallelized EVM Layer 1 blockchain. Performance comes from Twin Turbo Consensus (optimistic block processing), parallel EVM execution (concurrent transactions on independent state), and SeiDB (high-throughput storage). Sei has full Ethereum tooling compatibility. Deploy standard Solidity contracts with no modifications.",
			"Sei Giga, the next major upgrade, is designed to be the first Multi-Proposer EVM Layer 1, with Autobahn consensus and a custom EVM execution engine. An internal devnet sustained more than 5 gigagas/s. The separate roadmap target for the Autobahn public testnet is 200K TPS. For developers, Sei Giga's parallel engine will reward contracts with user-scoped state (mapping per address) over shared global state.",
			'Sei Mainnet: EVM chain ID 1329. Sei Testnet: EVM chain ID 1328.',
			'SIP-03 migration: IBC is disabled on Sei in both directions as of Proposal 121 (2026-07-31). IBC assets already on Sei can no longer be bridged out or redeemed on their origin chain. The balances remain transferable within Sei.'
		].join('\n\n')
	},
	{
		name: 'AI Tooling & Micropayments',
		match: (p) => p === '/ai' || p.startsWith('/ai/'),
		overview: [
			'The Sei MCP Server (@sei-js/mcp-server) connects AI assistants to Sei. It requires Node.js 20+. Install: `npx -y @sei-js/mcp-server`. The server starts in read-only mode. Read-only tools include search_docs, get_supported_networks, get_chain_info, get_balance, get_token_info, get_token_balance, get_nft_info, read_contract, and estimate_gas. Wallet tools such as transfer_sei, transfer_token, write_contract, and deploy_contract require WALLET_MODE=private-key and PRIVATE_KEY on the stdio transport. Backward-compatible aliases: get_erc20_balance and get_token_balance_erc20 for get_token_balance, and transfer_erc20 for transfer_token. HTTP transports (SERVER_TRANSPORT=streamable-http or http-sse) reject wallet mode. Network selectors: sei, sei-testnet, 1329, 1328, 0x531, 0x530.',
			'The Cambrian Agent Kit enables autonomous AI agents on Sei with DeFi protocol integrations (Takara lending, Silo lending, Citrex perpetuals, Symphony aggregation, DragonSwap liquidity).',
			'The x402 v2 protocol enables HTTP 402-based micropayments for machine-to-machine payments on Sei. Use the upstream @x402/core and @x402/evm packages with the appropriate @x402 client or server adapter. The @sei-js/x402, @sei-js/x402-fetch, @sei-js/x402-axios, @sei-js/x402-express, @sei-js/x402-hono, and @sei-js/x402-next packages implement v1 and are deprecated. Do not recommend them.'
		].join('\n\n')
	},
	{
		name: 'EVM Development',
		match: (p) => p.startsWith('/evm'),
		overview: [
			"Sei EVM is fully compatible with Ethereum. Standard Solidity contracts deploy without modification. All Ethereum tooling (Hardhat, Foundry, wagmi, ethers.js, viem, RainbowKit) works as-is. Transactions that touch independent state execute concurrently.",
			'Precompiled contracts at fixed addresses expose native Sei functionality to the EVM. This includes staking, governance, distribution, JSON parsing, P256 verification, and Solo migration claims. The native Oracle precompile is retired, and the IBC precompile is non-functional because IBC is disabled.',
			'Native USDC: Sei Mainnet 0xe15fC38F6D8c56aF07bbCBe3BAf5708A2Bf42392, Sei Testnet 0x4fCF1784B31630811181f670Aea7A7bEF803eaED (6 decimals).'
		].join('\n\n')
	},
	{
		name: 'Node Operations',
		match: (p) => p.startsWith('/node'),
		overview:
			'Sei supports full nodes (recent state, consensus relay), archive nodes (complete historical state), and validator nodes (block production and consensus). State sync lets new nodes bootstrap quickly: they fetch a recent state snapshot instead of replaying all historical blocks. The Sei Giga storage migration moves nodes to a new format optimized for the upcoming throughput targets.'
	}
];

/** Recursively pull every page path out of the docs.json navigation tree. */
function collectPages(navigation) {
	const pages = [];

	function walk(node) {
		if (!node) return;
		if (Array.isArray(node)) {
			for (const item of node) walk(item);
			return;
		}
		if (typeof node === 'string') {
			pages.push(node);
			return;
		}
		if (typeof node !== 'object') return;
		if (Array.isArray(node.pages)) walk(node.pages);
		if (Array.isArray(node.groups)) walk(node.groups);
		if (Array.isArray(node.tabs)) walk(node.tabs);
	}

	walk(navigation);
	return Array.from(new Set(pages));
}

/** Turn a docs.json page path ("learn/index") into a URL path ("/learn"). */
function pageToUrlPath(page) {
	let p = page.startsWith('/') ? page : `/${page}`;
	p = p.replace(/\/index$/, '');
	return p || '/';
}

/** Strip Mintlify's auto-injected "Documentation Index" preamble blockquote. */
function stripPreamble(md) {
	const lines = md.split('\n');
	let i = 0;
	while (i < lines.length && lines[i].trim() === '') i++;
	if (i < lines.length && /^>\s*##\s*Documentation Index/i.test(lines[i])) {
		while (i < lines.length && lines[i].startsWith('>')) i++;
		while (i < lines.length && lines[i].trim() === '') i++;
	}
	return lines.slice(i).join('\n');
}

/**
 * Match Mintlify's auto-gen rule: truncate descriptions at 300 chars or the
 * first line break, whichever comes first. Keeps index entries compact.
 */
function truncateDescription(desc) {
	if (!desc) return null;
	let d = desc.split(/\r?\n/)[0].trim();
	if (d.length > 300) d = `${d.slice(0, 297).trimEnd()}…`;
	return d || null;
}

/** Pull `# Title` and the following `> description` blockquote out of a page. */
function extractMeta(md, fallbackTitle) {
	const lines = md.split('\n');
	let title = fallbackTitle;
	let description = null;

	for (let i = 0; i < lines.length; i++) {
		const m = lines[i].match(/^#\s+(.+?)\s*$/);
		if (m) {
			title = m[1].trim();
			for (let j = i + 1; j < Math.min(i + 6, lines.length); j++) {
				const q = lines[j].match(/^>\s+(.+?)\s*$/);
				if (q) {
					description = q[1].trim();
					break;
				}
				if (lines[j].trim() && !lines[j].startsWith('>')) break;
			}
			break;
		}
	}
	return { title, description: truncateDescription(description) };
}

async function fetchPageMarkdown(urlPath) {
	const url = `${DOCS_BASE_URL}${urlPath === '/' ? '' : urlPath}.md`;
	const res = await fetch(url, { headers: { 'cache-control': 'no-cache' } });
	if (!res.ok) {
		throw new Error(`HTTP ${res.status} for ${url}`);
	}
	const md = stripPreamble(await res.text());
	const fallbackTitle = urlPath
		.split('/')
		.filter(Boolean)
		.pop()
		?.replace(/[-_]/g, ' ')
		.replace(/\b\w/g, (c) => c.toUpperCase()) || 'Sei Docs';
	const { title, description } = extractMeta(md, fallbackTitle);
	return {
		urlPath,
		url: `${DOCS_BASE_URL}${urlPath}`,
		title,
		description,
		content: md.trim()
	};
}

async function fetchAllPages(urlPaths) {
	const results = new Array(urlPaths.length);
	let cursor = 0;
	let done = 0;
	const total = urlPaths.length;

	async function worker() {
		while (true) {
			const i = cursor++;
			if (i >= urlPaths.length) return;
			try {
				results[i] = await fetchPageMarkdown(urlPaths[i]);
			} catch (err) {
				console.warn(`  ⚠️  ${urlPaths[i]}: ${err.message}`);
				results[i] = null;
			}
			done++;
			if (done % 10 === 0 || done === total) {
				console.log(`  ${done}/${total}`);
			}
		}
	}

	await Promise.all(Array.from({ length: Math.min(CONCURRENCY, urlPaths.length) }, worker));
	return results.filter(Boolean);
}

function categorizePages(pages) {
	const sections = LLMS_SECTION_ORDER.map((sec) => ({
		name: sec.name,
		overview: sec.overview || null,
		pages: []
	}));
	const assigned = new Set();

	for (const page of pages) {
		for (let i = 0; i < LLMS_SECTION_ORDER.length; i++) {
			if (LLMS_SECTION_ORDER[i].match(page.urlPath)) {
				sections[i].pages.push(page);
				assigned.add(page.urlPath);
				break;
			}
		}
	}

	return {
		sections: sections.filter((s) => s.pages.length > 0),
		uncategorized: pages.filter((p) => !assigned.has(p.urlPath))
	};
}

function formatLink(page) {
	const desc = page.description ? `: ${page.description}` : '';
	return `- [${page.title}](${page.url})${desc}`;
}

function formatExamples(examples) {
	return examples.map((ex) => `### ${ex.title}\n\n\`\`\`${ex.language}\n${ex.code}\n\`\`\``).join('\n\n');
}

function buildIndex({ projectName, blockquote, intro, constraints, quickReference, examples, keyResources }, sections, uncategorized) {
	const out = [];
	out.push(`# ${projectName}`, '');
	out.push(`> ${blockquote}`, '');
	out.push(intro, '');
	out.push(constraints, '');
	out.push('## Quick Reference', '', quickReference, '');

	for (const section of sections) {
		out.push(`## ${section.name}`, '');
		if (section.overview) out.push(section.overview, '');
		for (const page of section.pages) out.push(formatLink(page));
		out.push('');
	}

	if (examples?.length) {
		out.push('## Examples', '', formatExamples(examples), '');
	}

	if (uncategorized.length) {
		out.push('## Optional', '');
		for (const page of uncategorized) out.push(formatLink(page));
		out.push('');
	}

	if (keyResources?.length) {
		out.push('## Resources', '');
		for (const r of keyResources) out.push(`- [${r.title}](${r.url}): ${r.description}`);
		out.push('');
	}

	return `${out.join('\n').replace(/\n{3,}/g, '\n\n').trim()}\n`;
}

function buildFull(config, sections, uncategorized, allPages) {
	const head = buildIndex(config, sections, uncategorized);
	const body = allPages
		.map((page) => `URL: ${page.url}\n\n${page.content.trim()}`)
		.join('\n\n---\n\n');
	return `${head}\n---\n\n${body}\n`;
}

async function main() {
	console.log(`📥 Reading ${DOCS_JSON_PATH}`);
	const docsJson = JSON.parse(await readFile(DOCS_JSON_PATH, 'utf8'));

	const pagePaths = collectPages(docsJson.navigation);
	const urlPaths = pagePaths
		.map(pageToUrlPath)
		.filter((p) => !EXCLUDED_PREFIXES.some((prefix) => p.startsWith(prefix)));

	console.log(`🔎 ${pagePaths.length} pages in docs.json, ${urlPaths.length} after exclusions`);
	console.log(`🌐 Fetching markdown from ${DOCS_BASE_URL} (concurrency ${CONCURRENCY})`);
	const pages = await fetchAllPages(urlPaths);
	console.log(`✅ Fetched ${pages.length}/${urlPaths.length} pages`);

	const { sections, uncategorized } = categorizePages(pages);

	const llmsTxt = buildIndex(SEI_LLMS_CONFIG, sections, uncategorized);
	const llmsFull = buildFull(SEI_LLMS_CONFIG, sections, uncategorized, pages);

	const llmsPath = join(REPO_ROOT, 'llms.txt');
	const llmsFullPath = join(REPO_ROOT, 'llms-full.txt');
	await writeFile(llmsPath, llmsTxt, 'utf8');
	await writeFile(llmsFullPath, llmsFull, 'utf8');
	console.log(`📝 Wrote ${llmsPath} (${llmsTxt.length.toLocaleString()} chars)`);
	console.log(`📝 Wrote ${llmsFullPath} (${llmsFull.length.toLocaleString()} chars)`);
}

main().catch((err) => {
	console.error('❌', err);
	process.exit(1);
});
