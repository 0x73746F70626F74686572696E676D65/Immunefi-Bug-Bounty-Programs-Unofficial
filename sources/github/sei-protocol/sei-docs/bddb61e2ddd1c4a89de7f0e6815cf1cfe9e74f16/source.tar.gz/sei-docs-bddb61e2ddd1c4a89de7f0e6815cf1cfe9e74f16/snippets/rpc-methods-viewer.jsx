/*
 * Sei EVM JSON-RPC Explorer — interactive reference for Sei's EVM RPC methods.
 *
 * Mintlify note: snippets must use arrow-function syntax (no `function` keyword),
 * React hooks are provided in scope by the Mintlify runtime, and ALL declarations
 * (constants, helpers, data) must live INSIDE the component — Mintlify evaluates
 * only the component's own scope, so module-level consts are not visible at runtime.
 */

export const RPCMethodsViewer = () => {
const NETWORKS = {
  mainnet: {
    label: 'Sei Mainnet',
    chainId: '1329',
    http: 'https://evm-rpc.sei-apis.com',
    ws: 'wss://evm-ws.sei-apis.com',
  },
  testnet: {
    label: 'Sei Testnet',
    chainId: '1328',
    http: 'https://evm-rpc-testnet.sei-apis.com',
    ws: 'wss://evm-ws-testnet.sei-apis.com',
  },
};

const NAMESPACE_META = {
  eth: { label: 'eth', color: '#b05c6c', blurb: 'Standard Ethereum methods for accounts, balances, blocks, transactions, logs, calls, and filters.' },
  debug: { label: 'debug', color: '#966f22', blurb: 'Transaction and block tracing.' },
  txpool: { label: 'txpool', color: '#3b82f6', blurb: 'Transaction-pool inspection.' },
  net: { label: 'net', color: '#0d9488', blurb: 'Network metadata.' },
  web3: { label: 'web3', color: '#7c3aed', blurb: 'Client metadata.' },
  sei: { label: 'sei', color: '#600014', colorDark: '#b99ba1', blurb: 'Remaining legacy Sei extensions for address resolution, cross-VM lookup, and synthetic receipts.', deprecated: true },
  admin: { label: 'admin', color: '#6b7280', blurb: 'Node administration is not exposed on Sei.', unavailable: true },
  miner: { label: 'miner', color: '#6b7280', blurb: 'Mining control is not applicable (no proof-of-work).', unavailable: true },
  clique: { label: 'clique', color: '#6b7280', blurb: 'Clique proof-of-authority is not applicable (CometBFT consensus).', unavailable: true },
  engine: { label: 'engine', color: '#6b7280', blurb: 'The Consensus Engine API is not applicable (CometBFT consensus).', unavailable: true },
  les: { label: 'les', color: '#6b7280', blurb: 'The Light Ethereum Subprotocol is not exposed on Sei.', unavailable: true },
  personal: { label: 'personal', color: '#6b7280', blurb: 'Hosted-key account management is not exposed on Sei.', unavailable: true },
};

const NAMESPACE_ORDER = ['eth', 'debug', 'txpool', 'net', 'web3', 'sei', 'admin', 'miner', 'clique', 'engine', 'les', 'personal'];

const STATUS_META = {
  supported: { label: 'Supported', dark: '#22c55e', light: '#16a34a', tip: 'Implemented with standard Ethereum behavior.' },
  limited: { label: 'Limited', dark: '#f59e0b', light: '#b45309', tip: 'Works, but is deprecated, returns a static value, or has a Sei-specific caveat.' },
  unsupported: { label: 'Unavailable', dark: '#9ca3af', light: '#6b7280', tip: 'Not registered on Sei, explicitly errors, or not applicable to the Sei architecture.' },
};

const LANGUAGES = [
  { id: 'curl', name: 'cURL' },
  { id: 'cast', name: 'cast' },
  { id: 'javascript', name: 'JavaScript' },
  { id: 'typescript', name: 'TypeScript' },
  { id: 'python', name: 'Python' },
  { id: 'go', name: 'Go' },
  { id: 'rust', name: 'Rust' },
  { id: 'java', name: 'Java' },
  { id: 'kotlin', name: 'Kotlin' },
  { id: 'swift', name: 'Swift' },
  { id: 'csharp', name: 'C#' },
];

const SEI_RPC_METHODS = [
  {"namespace":"eth","name":"eth_blockNumber","status":"supported","description":"Returns the number of the most recent committed EVM block as a hex uint64.","seiNote":"Block height comes from the CometBFT latest height. The latest committed block is already final on Sei (instant finality, so latest == safe == finalized)."},
  {"namespace":"eth","name":"eth_chainId","status":"supported","description":"Returns the EVM chain ID as a hex big int.","seiNote":"The chain ID comes from the x/evm keeper. Sei Mainnet = 1329 (0x531). Sei Testnet = 1328 (0x530)."},
  {"namespace":"eth","name":"eth_coinbase","status":"limited","description":"Returns the block reward beneficiary (coinbase) address.","seiNote":"Sei has no miner. This method returns the Cosmos fee-collector module address (GetFeeCollectorAddress), not a validator or miner address. The COINBASE opcode returns the same value."},
  {"namespace":"eth","name":"eth_accounts","status":"limited","description":"Returns the list of addresses for which the node holds hosted keys.","seiNote":"The list comes only from the node's local test keyring. Production and public RPC nodes hold no hosted keys, so this method returns an empty list. Sign client-side and use eth_sendRawTransaction."},
  {"namespace":"eth","name":"eth_gasPrice","status":"limited","description":"Returns a suggested gas price in wei (hex).","seiNote":"The price comes from a Sei-specific congestion heuristic, not a raw mempool oracle. InfoAPI.GasPrice/GasPriceHelper (info.go) returns baseFee * 110/100 (base fee +10%) when the chain is uncongested. When the chain is congested, it returns medianRewardPrevBlock + baseFee (the 50th-percentile priority-fee reward from the previous block, added to the base fee). The base fee comes from the x/evm keeper (GetNextBaseFeePerGas), which is itself floored at the governance-set minimum base fee. The RPC handler applies no other explicit lower-bound clamp. The mainnet minimum gas price (approximately 50 gwei) is enforced for transaction acceptance at the mempool and ante-handler level, not inside eth_gasPrice."},
  {"namespace":"eth","name":"eth_maxPriorityFeePerGas","status":"limited","description":"Returns a suggested priority fee (tip) per gas in wei (hex).","seiNote":"Returns a hardcoded 1 gwei (defaultPriorityFeePerGas) when the chain is uncongested. It derives the tip from the previous block's 50th-percentile reward only when the chain is congested. Sei docs advise using a single gasPrice and omitting EIP-1559 fee fields."},
  {"namespace":"eth","name":"eth_feeHistory","status":"supported","description":"Returns base fees, gas-used ratios, and reward percentile data over a range of blocks.","seiNote":"Base fees and rewards reflect Sei's x/evm fee market (GetNextBaseFee), not an Ethereum EIP-1559 mempool. Sei does not burn the base fee. The method is watermark-aware, so pruned or historical blocks may not be available as far back as on Ethereum archive nodes.","params":[{"name":"blockCount","type":"QUANTITY","description":"Number of blocks in the requested range.","example":"0x5"},{"name":"newestBlock","type":"BLOCKNUMBER","description":"Highest block of the range (number or tag).","example":"latest"},{"name":"rewardPercentiles","type":"array of float","description":"Monotonically increasing percentiles to sample for priority-fee rewards.","example":"[25,50,75]"}]},
  {"namespace":"eth","name":"eth_blobBaseFee","status":"unsupported","description":"Returns the EIP-4844 blob base fee. Sei registers this method, but it always returns an unsupported error.","seiNote":"Always returns JSON-RPC error -32000 with the message 'blobs not supported on this chain'. Sei does not implement EIP-4844 blob transactions."},
  {"namespace":"eth","name":"eth_syncing","status":"unsupported","description":"Returns the sync status. Sei registers this method, but it always returns an unsupported error instead of false or a sync object.","seiNote":"InfoAPI.Syncing returns a JSON-RPC error with the exact message 'eth_syncing is not supported on Sei EVM RPC' (from ErrEVMNotSupported, code -32000, not -32601). Sei does not expose Ethereum sync semantics here. Query CometBFT status endpoints instead."},
  {"namespace":"eth","name":"eth_getBalance","status":"supported","description":"Returns the wei balance of an account at a given block.","seiNote":"The balance reflects the account's SEI bank balance (18-decimal wei representation). Both EVM and non-EVM (Cosmos bank send or wasm) transactions can change it. The watermark manager resolves the height with a state-version guard.","params":[{"name":"address","type":"DATA, 20 bytes","description":"Account address.","example":"0xDa52B9E673d1f48FcD9916b3F606A136a8eA5e55"},{"name":"blockNrOrHash","type":"BLOCKNUMBER or DATA","description":"Block number, tag (latest/earliest/pending/safe/finalized), or hash.","example":"latest"}]},
  {"namespace":"eth","name":"eth_getCode","status":"supported","description":"Returns the contract bytecode at an address for a given block.","params":[{"name":"address","type":"DATA, 20 bytes","description":"Contract address.","example":"0xE30feDd158A2e3b13e9badaeABaFc5516e95e8C7"},{"name":"blockNrOrHash","type":"BLOCKNUMBER or DATA","description":"Block number, tag, or hash.","example":"latest"}]},
  {"namespace":"eth","name":"eth_getStorageAt","status":"supported","description":"Returns the value stored at a storage slot of an address at a given block.","seiNote":"Reads the EVM keeper's slot value directly rather than from an MPT trie. The slot key must decode to at most 32 bytes.","params":[{"name":"address","type":"DATA, 20 bytes","description":"Contract address.","example":"0xE30feDd158A2e3b13e9badaeABaFc5516e95e8C7"},{"name":"key","type":"DATA, 32 bytes","description":"Storage slot key (hex, up to 32 bytes).","example":"0x0"},{"name":"blockNrOrHash","type":"BLOCKNUMBER or DATA","description":"Block number, tag, or hash.","example":"latest"}]},
  {"namespace":"eth","name":"eth_getProof","status":"limited","description":"Returns a Merkle proof for an account and the requested storage slots.","seiNote":"Sei stores state in an IAVL tree, not an Ethereum Merkle-Patricia trie. The result is a Sei-specific ProofResult{address, hexValues, storageProof}. Its storageProof entries are CometBFT/IAVL crypto.ProofOps, NOT eth-style MPT proof nodes. There is no accountProof, balance, codeHash, nonce, or storageHash field (Sei has no per-account state root). Standard eth_getProof verifiers do not work.","params":[{"name":"address","type":"DATA, 20 bytes","description":"Account address.","example":"0xE30feDd158A2e3b13e9badaeABaFc5516e95e8C7"},{"name":"storageKeys","type":"array of DATA, 32 bytes","description":"Storage slot keys to prove (bounded by MaxStorageKeysPerProof).","example":"[\"0x0\"]"},{"name":"blockNrOrHash","type":"BLOCKNUMBER or DATA","description":"Block number, tag, or hash.","example":"latest"}]},
  {"namespace":"eth","name":"eth_getNonce","status":"limited","description":"Sei-specific helper that returns the current EVM nonce for an address (latest state only).","seiNote":"This non-standard Sei extension is exposed as eth_getNonce and implemented as StateAPI.GetNonce in state.go (NOT on TransactionAPI). Unlike eth_getTransactionCount, it takes no block tag (latest only, through ctxProvider(LatestCtxHeight)) and returns a bare uint64. Prefer eth_getTransactionCount for standard nonce queries.","params":[{"name":"address","type":"DATA, 20 bytes","description":"Account address.","example":"0xDa52B9E673d1f48FcD9916b3F606A136a8eA5e55"}]},
  {"namespace":"eth","name":"eth_call","status":"supported","description":"Executes a read-only message call against state without creating a transaction. Supports state and block overrides.","seiNote":"RPCGasCap caps gas, and RPCEVMTimeout caps execution time. A fail-fast limiter may reject the call with 'eth_call rejected due to rate limit: server busy'. Canonical EVM<->Sei address resolution uses eth_call to the addr precompile at 0x0000000000000000000000000000000000001004.","params":[{"name":"args","type":"object","description":"Call object (to, from, data/input, gas, gasPrice/maxFeePerGas, value).","example":"{\"to\":\"0x0000000000000000000000000000000000001004\",\"data\":\"0x0c3c20ed000000000000000000000000Da52B9E673d1f48FcD9916b3F606A136a8eA5e55\"}"},{"name":"blockNrOrHash","type":"BLOCKNUMBER or DATA","description":"Block number, tag, or hash. Defaults to latest.","example":"latest"},{"name":"overrides","type":"object","description":"Optional per-account state overrides (balance, code, nonce, state).","example":"{}"},{"name":"blockOverrides","type":"object","description":"Optional block-context overrides (number, time, coinbase).","example":"{}"}]},
  {"namespace":"eth","name":"eth_estimateGas","status":"supported","description":"Estimates the gas needed to execute a transaction.","seiNote":"RPCGasCap bounds this method, and a fail-fast limiter protects it. The block gas limit on Sei is 12.5M. Parallel execution can cause estimates to vary slightly, so size gasLimit with a modest buffer.","params":[{"name":"args","type":"object","description":"Transaction call object.","example":"{\"to\":\"0xE30feDd158A2e3b13e9badaeABaFc5516e95e8C7\",\"data\":\"0x18160ddd\"}"},{"name":"blockNrOrHash","type":"BLOCKNUMBER or DATA","description":"Optional block number, tag, or hash. Defaults to latest.","example":"latest"},{"name":"overrides","type":"object","description":"Optional state overrides.","example":"{}"}]},
  {"namespace":"eth","name":"eth_estimateGasAfterCalls","status":"limited","description":"Estimates gas for a transaction after first applying a sequence of preceding calls against the same simulated state.","seiNote":"This is a non-standard Sei/geth extension (not part of the standard Ethereum JSON-RPC spec). It has the same gas-cap and fail-fast-limiter behavior as eth_estimateGas.","params":[{"name":"args","type":"object","description":"The final call to estimate gas for.","example":"{\"to\":\"0xE30feDd158A2e3b13e9badaeABaFc5516e95e8C7\",\"data\":\"0x\"}"},{"name":"calls","type":"array of object","description":"Ordered list of preceding calls applied before the estimate.","example":"[]"},{"name":"blockNrOrHash","type":"BLOCKNUMBER or DATA","description":"Optional block number, tag, or hash. Defaults to latest.","example":"latest"},{"name":"overrides","type":"object","description":"Optional state overrides.","example":"{}"}]},
  {"namespace":"eth","name":"eth_createAccessList","status":"supported","description":"Generates an EIP-2930 access list (and gas used) for a transaction.","seiNote":"Defaults to the pending block tag (matching geth). A VM error during simulation appears in the result's 'error' field instead of failing the RPC.","params":[{"name":"args","type":"object","description":"Transaction call object.","example":"{\"to\":\"0xE30feDd158A2e3b13e9badaeABaFc5516e95e8C7\",\"data\":\"0x\"}"},{"name":"blockNrOrHash","type":"BLOCKNUMBER or DATA","description":"Optional block number, tag, or hash. Defaults to pending.","example":"pending"}]},
  {"namespace":"eth","name":"eth_sendRawTransaction","status":"supported","description":"Submits a signed, RLP-encoded raw EVM transaction to the network and returns its hash.","seiNote":"Decodes the bytes to an ethtypes.Transaction, wraps it in a Cosmos MsgEVMTransaction, and broadcasts it through CometBFT. By default, it uses a CheckTx-level BroadcastTx (that is, broadcast_tx_sync), and slow mode uses BroadcastTxCommit. Non-zero CheckTx codes are returned as ABCI errors, not geth mempool errors. Legacy (non-1559) transactions must set gasPrice at or above the governance minimum (currently 50 gwei on Sei Mainnet). Blob (EIP-4844) transactions are not enabled. The method supports per-sender EvmProxy forwarding.","params":[{"name":"data","type":"DATA","description":"Signed, RLP-encoded transaction bytes (0x-prefixed).","example":"0x02f8b101808459682f00..."}]},
  {"namespace":"eth","name":"eth_sendTransaction","status":"limited","description":"Signs (with a node-hosted key) and submits a transaction in one call.","seiNote":"Requires the 'from' address's private key in the node's local test keyring. Production and public RPC nodes hold no hosted keys, so this method returns 'from address does not have hosted key'. Always signs as LegacyTxType. Sign client-side and use eth_sendRawTransaction instead.","params":[{"name":"args","type":"object","description":"Transaction object (from, to, value, data, gas, nonce, and other fields).","example":"{\"from\":\"0xDa52B9E673d1f48FcD9916b3F606A136a8eA5e55\",\"to\":\"0x7507454444fa193d39f1392076bc784b77a7a8ff\",\"value\":\"0x1\"}"}]},
  {"namespace":"eth","name":"eth_signTransaction","status":"limited","description":"Signs a transaction with a node-hosted key and returns the signed payload without broadcasting.","seiNote":"Requires a node-hosted key for the from address. It does not work on public RPC nodes that hold no keys. Returns both the raw RLP bytes and the decoded tx.","params":[{"name":"args","type":"object","description":"SendTxArgs transaction object to sign (from, to, gas, gasPrice, value, nonce, data).","example":"{\"from\":\"0xDa52B9E673d1f48FcD9916b3F606A136a8eA5e55\",\"to\":\"0x7507454444fa193d39f1392076bc784b77a7a8ff\",\"value\":\"0x1\",\"nonce\":\"0x0\",\"gas\":\"0x5208\",\"gasPrice\":\"0x3b9aca00\"}"}]},
  {"namespace":"eth","name":"eth_sign","status":"limited","description":"Signs an EIP-191 personal message with a node-hosted key for the given address.","seiNote":"Only works for addresses in the node's local test keyring. Production and public RPC nodes hold no hosted keys, so this method returns 'address does not have hosted key'. Applies the EIP-191 personal-message TextHash before signing.","params":[{"name":"address","type":"DATA, 20 bytes","description":"Address whose hosted key signs the data.","example":"0xDa52B9E673d1f48FcD9916b3F606A136a8eA5e55"},{"name":"data","type":"DATA","description":"Message bytes to sign.","example":"0xdeadbeef"}]},
  {"namespace":"eth","name":"eth_getBlockByNumber","status":"supported","description":"Returns block information by number or tag, with full transactions when fullTx is true.","seiNote":"Under the eth namespace, only EVM transactions are indexed (synthetic and bank-transfer txs are excluded). Block number 0 returns a synthetic genesis block (for The Graph compatibility). Future or non-existent numeric blocks return null. Uncle and PoW header fields (sha3Uncles, nonce, mixHash, difficulty) are placeholders, and the uncles array is always empty (CometBFT consensus). The safe, finalized, and latest tags are equivalent because of instant finality.","params":[{"name":"number","type":"BLOCKNUMBER","description":"Block number (hex) or tag (latest/safe/finalized/pending/earliest).","example":"latest"},{"name":"fullTx","type":"boolean","description":"If true, the block includes full transaction objects. If false, it includes only hashes.","example":"true"}]},
  {"namespace":"eth","name":"eth_getBlockByHash","status":"supported","description":"Returns block information by block hash, with full transactions when fullTx is true.","seiNote":"Block hashes are CometBFT block hashes (computed from the Tendermint header), so they differ from Ethereum block hashes and are not interchangeable across chains. Under the eth namespace, synthetic txs and bank transfers are excluded. The genesis hash returns a synthetic genesis block. An unknown or zero hash returns null. The uncles array is always empty.","params":[{"name":"blockHash","type":"DATA, 32 bytes","description":"Block hash.","example":"0x5620c15afd9a1d0ab19d7560043df6e038d731c6205974dca7a55900071e3864"},{"name":"fullTx","type":"boolean","description":"If true, the block includes full transaction objects. If false, it includes only hashes.","example":"false"}]},
  {"namespace":"eth","name":"eth_getBlockTransactionCountByNumber","status":"supported","description":"Returns the number of EVM transactions in a block by number, as a hex quantity.","seiNote":"Counts EVM transactions only (through getEvmTxCount). Synthetic and bank-transfer txs are excluded. Genesis returns 0x0. Non-existent or future blocks return null.","params":[{"name":"number","type":"BLOCKNUMBER","description":"Block number or tag.","example":"latest"}]},
  {"namespace":"eth","name":"eth_getBlockTransactionCountByHash","status":"supported","description":"Returns the number of EVM transactions in a block by hash, as a hex quantity.","seiNote":"Counts EVM transactions only. Synthetic and bank-transfer txs are excluded. The genesis hash returns 0x0. An unknown hash returns null.","params":[{"name":"blockHash","type":"DATA, 32 bytes","description":"Block hash.","example":"0x5620c15afd9a1d0ab19d7560043df6e038d731c6205974dca7a55900071e3864"}]},
  {"namespace":"eth","name":"eth_getBlockReceipts","status":"supported","description":"Returns all EVM transaction receipts for a given block.","seiNote":"Under the eth namespace, synthetic and shell receipts are excluded (includeShellReceipts=false). Genesis returns an empty array. A zero hash returns null. transactionIndex is recomputed sequentially over the compacted receipt list.","params":[{"name":"blockNrOrHash","type":"BLOCKNUMBER or DATA","description":"Block number, tag, or hash.","example":"latest"}]},
  {"namespace":"eth","name":"eth_getTransactionByHash","status":"supported","description":"Returns the EVM transaction matching the given hash, or null if not found.","seiNote":"Sees EVM transactions only. If the hash resolves to a non-EVM Cosmos tx, it returns an error. Pending lookups read from the CometBFT mempool, not a geth txpool.","params":[{"name":"hash","type":"DATA, 32 bytes","description":"Transaction hash.","example":"0x828c91592453fe7c5bf743204495a35bf02b67b579b8f59ee7eea8af031d7c14"}]},
  {"namespace":"eth","name":"eth_getTransactionReceipt","status":"supported","description":"Returns the receipt of a transaction by hash, or null if not found.","seiNote":"The receipt is reconstructed from keeper.GetReceipt and CometBFT block data, not from a native MPT receipt trie. Status and logs use the standard Ethereum format.","params":[{"name":"hash","type":"DATA, 32 bytes","description":"Transaction hash.","example":"0x828c91592453fe7c5bf743204495a35bf02b67b579b8f59ee7eea8af031d7c14"}]},
  {"namespace":"eth","name":"eth_getTransactionByBlockNumberAndIndex","status":"supported","description":"Returns the EVM transaction at the given index within the block at the specified number.","seiNote":"Index maps over EVM transactions only. An out-of-range index returns a null result, not an error.","params":[{"name":"blockNr","type":"BLOCKNUMBER","description":"Block number or tag.","example":"latest"},{"name":"index","type":"QUANTITY","description":"Transaction index within the block.","example":"0x0"}]},
  {"namespace":"eth","name":"eth_getTransactionByBlockHashAndIndex","status":"supported","description":"Returns the EVM transaction at the given index within the block identified by hash.","seiNote":"Index maps over EVM transactions only. It has the same null-on-overflow semantics as the block-number variant.","params":[{"name":"blockHash","type":"DATA, 32 bytes","description":"Block hash.","example":"0x5620c15afd9a1d0ab19d7560043df6e038d731c6205974dca7a55900071e3864"},{"name":"index","type":"QUANTITY","description":"Transaction index within the block.","example":"0x0"}]},
  {"namespace":"eth","name":"eth_getTransactionCount","status":"supported","description":"Returns the number of transactions sent from an address (nonce) at a given block.","seiNote":"For the 'pending' tag, Sei returns EvmNextPendingNonce from the CometBFT mempool (or redirects to an EvmProxy if the sender is sharded there). The safe, finalized, and latest tags are equivalent because of instant finality.","params":[{"name":"address","type":"DATA, 20 bytes","description":"Account address.","example":"0xDa52B9E673d1f48FcD9916b3F606A136a8eA5e55"},{"name":"blockNrOrHash","type":"BLOCKNUMBER or DATA","description":"Block number, tag, or hash. The 'pending' tag returns the next pending nonce.","example":"latest"}]},
  {"namespace":"eth","name":"eth_getVMError","status":"limited","description":"Sei extension that returns the EVM VM error string recorded in a transaction's receipt by hash.","seiNote":"This non-standard Sei extension is registered under the eth namespace. Returns the receipt's VmError field and propagates a not-found error (unlike eth_getTransactionErrorByHash, which returns an empty string on not-found).","params":[{"name":"hash","type":"DATA, 32 bytes","description":"Transaction hash.","example":"0x828c91592453fe7c5bf743204495a35bf02b67b579b8f59ee7eea8af031d7c14"}]},
  {"namespace":"eth","name":"eth_getTransactionErrorByHash","status":"limited","description":"Sei extension that returns the recorded VM error string for a transaction by hash (empty string if it succeeded or is not found).","seiNote":"This non-standard Sei extension is registered under the eth namespace. Unlike eth_getVMError, a not-found lookup returns an empty string and no error.","params":[{"name":"hash","type":"DATA, 32 bytes","description":"Transaction hash.","example":"0x828c91592453fe7c5bf743204495a35bf02b67b579b8f59ee7eea8af031d7c14"}]},
  {"namespace":"eth","name":"eth_newFilter","status":"supported","description":"Creates a log filter for the given criteria and returns a filter ID for later polling.","seiNote":"It has the same range and size caps as eth_getLogs. Open-ended ranges return up to 10,000 logs (DefaultMaxLogLimit). Close-ended ranges are limited to 2,000 blocks (DefaultMaxBlockRange), with large-query rate limiting.","params":[{"name":"crit","type":"object","description":"Filter criteria: fromBlock, toBlock (or blockHash), address(es), and topics.","example":"{\"fromBlock\":\"latest\",\"address\":\"0xE30feDd158A2e3b13e9badaeABaFc5516e95e8C7\",\"topics\":[]}"}]},
  {"namespace":"eth","name":"eth_newBlockFilter","status":"supported","description":"Creates a filter that tracks newly arrived block hashes and returns its ID."},
  {"namespace":"eth","name":"eth_newPendingTransactionFilter","status":"unsupported","description":"Creates a pending-transaction filter. Sei registers this method, but it always returns an unsupported error.","seiNote":"Always returns JSON-RPC -32000. Sei has no geth-style public pending mempool to filter. The corresponding newPendingTransactions subscription type is also unavailable."},
  {"namespace":"eth","name":"eth_getFilterChanges","status":"supported","description":"Polls a filter and returns new logs (log filters) or block hashes (block filters) since the last poll.","params":[{"name":"filterID","type":"QUANTITY/ID","description":"Filter ID from a New*Filter call.","example":"0x1"}]},
  {"namespace":"eth","name":"eth_getFilterLogs","status":"supported","description":"Returns all logs matching a previously created log filter, including historical logs.","seiNote":"Bounded by the same caps as eth_getLogs (2,000-block range, 10,000-log limit) with large-query rate limiting.","params":[{"name":"filterID","type":"QUANTITY/ID","description":"Filter ID from a NewFilter call.","example":"0x1"}]},
  {"namespace":"eth","name":"eth_getLogs","status":"supported","description":"Returns logs matching the given filter criteria.","seiNote":"Returns EVM logs only. Hard limits: a maximum of 2,000 blocks per close-ended query and up to 10,000 logs per response. A query that exceeds the range returns the error 'block range too large'. Large queries are globally rate-limited.","params":[{"name":"crit","type":"object","description":"Filter criteria: fromBlock, toBlock (or blockHash), address(es), topics.","example":"{\"fromBlock\":\"0x0\",\"toBlock\":\"latest\",\"address\":\"0xE30feDd158A2e3b13e9badaeABaFc5516e95e8C7\",\"topics\":[]}"}]},
  {"namespace":"eth","name":"eth_uninstallFilter","status":"supported","description":"Removes a previously installed filter by ID. Returns true if the filter existed and was removed.","seiNote":"Returns false instead of an error if the filter did not exist. Filters also expire automatically when they are not polled.","params":[{"name":"filterID","type":"QUANTITY/ID","description":"Filter ID to remove.","example":"0x1"}]},
  {"namespace":"eth","name":"eth_subscribe","status":"limited","description":"Opens a WebSocket-only push subscription for newHeads or logs notifications.","seiNote":"This method works over WebSocket only. SubscriptionAPI is not registered on the HTTP server, so calls over HTTP return rpc.ErrNotificationsUnsupported. Only 'newHeads' and 'logs' are implemented in source. There is no 'newPendingTransactions' subscription, although some client docs imply otherwise. MaxSubscriptionsNewHead caps newHeads subscriptions.","params":[{"name":"subscriptionType","type":"string","description":"Subscription name: 'newHeads' or 'logs'.","example":"newHeads"},{"name":"filter","type":"object","description":"Optional filter criteria (address and topics) for the 'logs' subscription.","example":"{\"address\":\"0xE30feDd158A2e3b13e9badaeABaFc5516e95e8C7\",\"topics\":[]}"}]},
  {"namespace":"eth","name":"eth_unsubscribe","status":"supported","description":"Cancels an existing WebSocket subscription by ID. Returns true on success.","seiNote":"This method works over WebSocket only. It has no effect over HTTP, where notifications are not supported.","params":[{"name":"subscriptionID","type":"string","description":"The subscription ID returned by a prior eth_subscribe call.","example":"0x9cef478923ff08bf67fde6c64013158d"}]},
  {"namespace":"eth","name":"eth_mining","status":"unsupported","description":"Returns whether the node is mining. Sei does not register this method.","seiNote":"Sei uses CometBFT proof-of-stake consensus with no PoW mining. The method is not registered and returns -32601 method not found."},
  {"namespace":"eth","name":"eth_hashrate","status":"unsupported","description":"Returns the node mining hashrate. Sei does not register this method.","seiNote":"Sei has no PoW mining (CometBFT consensus). The method is not registered and returns -32601 method not found."},
  {"namespace":"eth","name":"eth_getWork","status":"unsupported","description":"Returns the PoW work package (current header hash, seed, target). Sei does not register this method.","seiNote":"The proof-of-work concept does not exist under Sei's CometBFT consensus. The method is not registered."},
  {"namespace":"eth","name":"eth_submitWork","status":"unsupported","description":"Submits a PoW solution. Sei does not register this method.","seiNote":"PoW submission is meaningless on Sei (CometBFT PoS). The method is not registered.","params":[{"name":"nonce","type":"DATA, 8 bytes","description":"Found PoW nonce.","example":"0x0000000000000001"},{"name":"powHash","type":"DATA, 32 bytes","description":"Header pow-hash.","example":"0x0000000000000000000000000000000000000000000000000000000000000000"},{"name":"mixDigest","type":"DATA, 32 bytes","description":"Mix digest.","example":"0x0000000000000000000000000000000000000000000000000000000000000000"}]},
  {"namespace":"eth","name":"eth_submitHashrate","status":"unsupported","description":"Submits a node's mining hashrate. Sei does not register this method.","seiNote":"Sei has no PoW mining. The method is not registered.","params":[{"name":"hashrate","type":"QUANTITY","description":"Hashrate value (hex).","example":"0x500000"},{"name":"id","type":"DATA, 32 bytes","description":"Random hex ID that identifies the client.","example":"0x59daa26581d0acd1fce254fb7e85952f4c09d0915afd33d3886cd914bc7d283c"}]},
  {"namespace":"eth","name":"eth_protocolVersion","status":"unsupported","description":"Returns the Ethereum (devp2p) protocol version. Sei does not register this method.","seiNote":"Sei does not expose the Ethereum devp2p protocol version. The method is not registered and returns -32601 method not found."},
  {"namespace":"eth","name":"eth_getUncleCountByBlockNumber","status":"unsupported","description":"Returns the uncle count by block number. Sei has no uncles and does not register this method.","seiNote":"Sei uses CometBFT (single canonical chain, no uncles or ommers). The method is not registered and returns -32601.","params":[{"name":"number","type":"BLOCKNUMBER","description":"Block number or tag.","example":"latest"}]},
  {"namespace":"eth","name":"eth_getUncleCountByBlockHash","status":"unsupported","description":"Returns the uncle count by block hash. Sei has no uncles and does not register this method.","seiNote":"CometBFT consensus has no uncle blocks. The method is not registered and returns -32601.","params":[{"name":"blockHash","type":"DATA, 32 bytes","description":"Block hash.","example":"0x5620c15afd9a1d0ab19d7560043df6e038d731c6205974dca7a55900071e3864"}]},
  {"namespace":"eth","name":"eth_getUncleByBlockNumberAndIndex","status":"unsupported","description":"Returns an uncle block by number and index. Sei has no uncles and does not register this method.","seiNote":"CometBFT consensus has no uncle blocks. The method is not registered and returns -32601.","params":[{"name":"number","type":"BLOCKNUMBER","description":"Block number or tag.","example":"latest"},{"name":"index","type":"QUANTITY","description":"Uncle index.","example":"0x0"}]},
  {"namespace":"eth","name":"eth_getUncleByBlockHashAndIndex","status":"unsupported","description":"Returns an uncle block by hash and index. Sei has no uncles and does not register this method.","seiNote":"CometBFT consensus has no uncle blocks. The method is not registered and returns -32601.","params":[{"name":"blockHash","type":"DATA, 32 bytes","description":"Block hash.","example":"0x5620c15afd9a1d0ab19d7560043df6e038d731c6205974dca7a55900071e3864"},{"name":"index","type":"QUANTITY","description":"Uncle index.","example":"0x0"}]},
  {"namespace":"eth","name":"eth_pendingTransactions","status":"unsupported","description":"Lists the pending transactions in the node's transaction pool. Sei does not register this method.","seiNote":"Sei exposes no geth-style mempool through this method. Pending state is exposed only through the 'pending' tag on eth_getTransactionCount and through txpool_content. The method is not registered and returns -32601."},
  {"namespace":"net","name":"net_version","status":"supported","description":"Returns the network or chain ID as a decimal string.","seiNote":"Returns the EVM chain ID in decimal (alias of eth_chainId): '1329' on Sei Mainnet and '1328' on Sei Testnet."},
  {"namespace":"net","name":"net_listening","status":"unsupported","description":"Returns whether the node is listening for connections. Sei does not register this method.","seiNote":"The method is not registered on Sei's NetAPI and returns -32601 method not found. CometBFT handles P2P, not this RPC."},
  {"namespace":"net","name":"net_peerCount","status":"unsupported","description":"Returns the number of connected peers. Sei does not register this method.","seiNote":"The method is not registered on Sei's NetAPI and returns -32601. Query CometBFT net_info for peer data instead."},
  {"namespace":"web3","name":"web3_clientVersion","status":"supported","description":"Returns the client version string.","seiNote":"Reports a synthetic 'Geth/<os>-<arch>/<goVersion>' string (Sei's EVM is backed by go-ethereum). It does NOT embed the actual sei-chain/seid version, so it is not a reliable Sei version indicator."},
  {"namespace":"web3","name":"web3_sha3","status":"unsupported","description":"Returns the Keccak-256 hash of the input. Sei's Web3API does not implement this method.","seiNote":"Unlike go-ethereum, Sei's Web3API does not implement web3_sha3. It is not registered and returns -32601 method not found.","params":[{"name":"data","type":"DATA","description":"Bytes to hash.","example":"0x68656c6c6f20776f726c64"}]},
  {"namespace":"txpool","name":"txpool_content","status":"limited","description":"Returns the transactions currently in the pool, grouped by sender address and nonce into pending and queued buckets.","seiNote":"As a Sei-specific simplification, every unconfirmed EVM tx from the CometBFT mempool is reported under 'pending'. The 'queued' bucket is always empty (no geth-style nonce-gap distinction between pending and queued). The result set is truncated to the node's MaxTxPoolTxs config, so it may not reflect the entire mempool."},
  {"namespace":"txpool","name":"txpool_contentFrom","status":"unsupported","description":"Returns the pending and queued transactions for a single account. Sei does not implement this method.","seiNote":"The method is not registered and returns -32601 method not found. The only txpool method available on Sei is txpool_content.","params":[{"name":"address","type":"DATA, 20 bytes","description":"The account address to filter by.","example":"0xDa52B9E673d1f48FcD9916b3F606A136a8eA5e55"}]},
  {"namespace":"txpool","name":"txpool_status","status":"unsupported","description":"Returns the counts of pending and queued transactions. Sei does not implement this method.","seiNote":"The method is not registered and returns -32601 method not found."},
  {"namespace":"txpool","name":"txpool_inspect","status":"unsupported","description":"Returns a human-readable summary of pending and queued transactions. Sei does not implement this method.","seiNote":"The method is not registered and returns -32601 method not found."},
  {"namespace":"debug","name":"debug_traceTransaction","status":"supported","description":"Replays a transaction by hash and returns an execution trace using the configured tracer.","seiNote":"Works over HTTP only (the debug namespace is not registered on the WebSocket server). Supports geth tracers (callTracer, prestateTracer, flatCallTracer, struct or opcode logger). TraceBaker pre-bakes and caches callTracer, prestateTracer, and flatCallTracer results. Requires trace-enabled or archive state for the target height.","params":[{"name":"hash","type":"DATA, 32 bytes","description":"Transaction hash to trace.","example":"0x5c504ed432cb51138bcf09aa5e8a410dd4a1e204ef84bfed1be16dfba1b22060"},{"name":"config","type":"object","description":"Optional tracer config (tracer name, tracerConfig, timeout, reexec, disableStorage/Stack/Memory).","example":"{\"tracer\":\"callTracer\"}"}]},
  {"namespace":"debug","name":"debug_traceBlockByNumber","status":"supported","description":"Traces all transactions in a block by number and returns per-transaction execution traces.","seiNote":"Works over HTTP only. The safe, finalized, and latest tags are equivalent because of instant finality.","params":[{"name":"number","type":"BLOCKNUMBER","description":"Block number or tag.","example":"latest"},{"name":"config","type":"object","description":"Optional tracer config.","example":"{\"tracer\":\"callTracer\"}"}]},
  {"namespace":"debug","name":"debug_traceBlockByHash","status":"supported","description":"Traces all transactions in a block by hash and returns per-transaction execution traces.","seiNote":"Works over HTTP only.","params":[{"name":"hash","type":"DATA, 32 bytes","description":"Block hash.","example":"0x5620c15afd9a1d0ab19d7560043df6e038d731c6205974dca7a55900071e3864"},{"name":"config","type":"object","description":"Optional tracer config.","example":"{\"tracer\":\"callTracer\"}"}]},
  {"namespace":"debug","name":"debug_traceCall","status":"supported","description":"Executes and traces a call against a block's state without creating a transaction.","seiNote":"Works over HTTP only. Arbitrary geth tracer names pass through. Tracing on the pending block is not supported.","params":[{"name":"args","type":"object","description":"Transaction call object.","example":"{\"to\":\"0xE30feDd158A2e3b13e9badaeABaFc5516e95e8C7\",\"data\":\"0x70a08231\"}"},{"name":"blockNrOrHash","type":"BLOCKNUMBER or DATA","description":"Block number, tag, or hash.","example":"latest"},{"name":"config","type":"object","description":"Optional trace-call config (tracer name, state overrides, block overrides).","example":"{\"tracer\":\"callTracer\"}"}]},
  {"namespace":"debug","name":"debug_traceStateAccess","status":"limited","description":"Sei extension that replays a transaction and returns its app, tendermint, and receipt state-access traces.","seiNote":"This is a Sei-specific extension (not part of upstream go-ethereum's debug namespace). It works over HTTP only and is subject to historical-debug-trace availability guards.","params":[{"name":"hash","type":"DATA, 32 bytes","description":"Transaction hash whose state accesses are returned.","example":"0x5c504ed432cb51138bcf09aa5e8a410dd4a1e204ef84bfed1be16dfba1b22060"}]},
  {"namespace":"debug","name":"debug_traceTransactionProfile","status":"limited","description":"Sei extension that traces a transaction and returns the trace plus a phase-by-phase timing profile of the trace execution.","seiNote":"This is a Sei-specific extension (not part of upstream go-ethereum's debug namespace). Returns {trace, profile}, where profile carries totalNanos, historicalDbLookupNanos, otherNanos, and per-phase timings. It works over HTTP only and is subject to the max_trace_lookback_blocks historical guard.","params":[{"name":"hash","type":"DATA, 32 bytes","description":"Transaction hash to trace and profile.","example":"0x5c504ed432cb51138bcf09aa5e8a410dd4a1e204ef84bfed1be16dfba1b22060"},{"name":"config","type":"object","description":"Optional tracer config.","example":"{\"tracer\":\"callTracer\"}"}]},
  {"namespace":"debug","name":"debug_getRawHeader","status":"unsupported","description":"Returns the RLP-encoded block header. Sei registers this method, but it always returns an unsupported error.","seiNote":"Always returns JSON-RPC -32000. Sei block headers are CometBFT headers, not RLP-encoded Ethereum headers.","params":[{"name":"blockNrOrHash","type":"BLOCKNUMBER or DATA","description":"Block number, tag, or hash.","example":"latest"}]},
  {"namespace":"debug","name":"debug_getRawBlock","status":"unsupported","description":"Returns the RLP-encoded full block. Sei registers this method, but it always returns an unsupported error.","seiNote":"Always returns JSON-RPC -32000. No canonical RLP-encoded Ethereum block exists on Sei.","params":[{"name":"blockNrOrHash","type":"BLOCKNUMBER or DATA","description":"Block number, tag, or hash.","example":"latest"}]},
  {"namespace":"debug","name":"debug_getRawReceipts","status":"unsupported","description":"Returns the RLP-encoded receipts for a block. Sei registers this method, but it always returns an unsupported error.","seiNote":"Always returns JSON-RPC -32000.","params":[{"name":"blockNrOrHash","type":"BLOCKNUMBER or DATA","description":"Block number, tag, or hash.","example":"latest"}]},
  {"namespace":"debug","name":"debug_getRawTransaction","status":"unsupported","description":"Returns an RLP-encoded signed transaction by hash. Sei registers this method, but it always returns an unsupported error.","seiNote":"Always returns JSON-RPC -32000.","params":[{"name":"hash","type":"DATA, 32 bytes","description":"Transaction hash.","example":"0x5c504ed432cb51138bcf09aa5e8a410dd4a1e204ef84bfed1be16dfba1b22060"}]},
  {"namespace":"debug","name":"debug_storageRangeAt","status":"unsupported","description":"Returns a range of storage entries for a contract at a block or tx. Sei does not implement this method.","seiNote":"The method is not registered and returns -32601. Sei uses IAVL state, not an Ethereum MPT, so geth's MPT-based storage-range walk is not available.","params":[{"name":"blockHash","type":"DATA, 32 bytes","description":"Block hash.","example":"0x5620c15afd9a1d0ab19d7560043df6e038d731c6205974dca7a55900071e3864"},{"name":"txIndex","type":"QUANTITY","description":"Transaction index.","example":"0x0"},{"name":"address","type":"DATA, 20 bytes","description":"Contract address.","example":"0xE30feDd158A2e3b13e9badaeABaFc5516e95e8C7"},{"name":"startKey","type":"DATA","description":"Start storage key.","example":"0x00"},{"name":"maxResult","type":"QUANTITY","description":"Maximum number of entries.","example":"0x64"}]},
  {"namespace":"debug","name":"debug_traceBlock","status":"unsupported","description":"Traces a block supplied as raw RLP bytes. Sei does not implement this method.","seiNote":"The method is not registered and returns -32601. Sei does not accept RLP-encoded Ethereum blocks. Use debug_traceBlockByNumber or debug_traceBlockByHash instead.","params":[{"name":"blockRlp","type":"DATA","description":"RLP-encoded block bytes.","example":"0xf90211..."}]},
  {"namespace":"debug","name":"debug_intermediateRoots","status":"unsupported","description":"Returns the intermediate state roots while a block executes. Sei does not implement this method.","seiNote":"The method is not registered and returns -32601. Sei uses IAVL state, not an Ethereum MPT, so it does not produce per-transaction MPT intermediate roots.","params":[{"name":"blockHash","type":"DATA, 32 bytes","description":"Block hash.","example":"0x5620c15afd9a1d0ab19d7560043df6e038d731c6205974dca7a55900071e3864"},{"name":"config","type":"object","description":"Optional trace config.","example":"{}"}]},
  {"namespace":"debug","name":"debug_setHead","status":"unsupported","description":"Rewinds the chain head to a given block. Sei does not implement this method.","seiNote":"The method is not registered and returns -32601. CometBFT consensus controls the chain head, not the EVM RPC layer.","params":[{"name":"number","type":"QUANTITY","description":"Block number to set as head.","example":"0x1a2b3c"}]},
  {"namespace":"sei","name":"sei_getSeiAddress","status":"limited","description":"Returns the native Sei bech32 (sei1...) address associated with a given EVM (0x) address.","seiNote":"This legacy sei_* method is deprecated but ENABLED by default in the enabled_legacy_sei_apis allowlist on seid init. New integrations should call the addr precompile at 0x0000000000000000000000000000000000001004 (getSeiAddr) with eth_call. Returns an error if the address is not yet associated. Works over HTTP only.","params":[{"name":"ethAddress","type":"DATA, 20 bytes","description":"The EVM address to resolve.","example":"0xDa52B9E673d1f48FcD9916b3F606A136a8eA5e55"}]},
  {"namespace":"sei","name":"sei_getEVMAddress","status":"limited","description":"Returns the EVM (0x) address associated with a given native Sei bech32 (sei1...) address.","seiNote":"This legacy sei_* method is deprecated but ENABLED by default in enabled_legacy_sei_apis. Prefer the addr precompile at 0x0000000000000000000000000000000000001004 (getEvmAddr) with eth_call. Returns an error if the bech32 is malformed or the address is not yet associated. Works over HTTP only.","params":[{"name":"seiAddress","type":"string","description":"The Sei bech32 address to resolve.","example":"sei13ytysxs88z0fp9cssagg77ekpecrrlrwce9pwl"}]},
  {"namespace":"sei","name":"sei_getCosmosTx","status":"limited","description":"Returns the underlying CometBFT/Cosmos transaction hash corresponding to a given EVM transaction hash.","seiNote":"This legacy sei_* method is deprecated but ENABLED by default in enabled_legacy_sei_apis (it has no precompile equivalent yet). Returns the wrapping Cosmos transaction hash as uppercase hexadecimal without a 0x prefix. Works over HTTP only.","params":[{"name":"ethHash","type":"DATA, 32 bytes","description":"The EVM transaction hash to map to its underlying Cosmos tx hash.","example":"0x828c91592453fe7c5bf743204495a35bf02b67b579b8f59ee7eea8af031d7c14"}]},
  {"namespace":"sei","name":"sei_getTransactionReceipt","status":"limited","description":"Returns a transaction receipt by hash, including synthetic receipts for Cosmos transactions.","seiNote":"This legacy sei_* method is deprecated and DISABLED by default. It can get logs for a synthetic transaction when its hash is already known. Works over HTTP only.","params":[{"name":"hash","type":"DATA, 32 bytes","description":"Transaction hash.","example":"0x828c91592453fe7c5bf743204495a35bf02b67b579b8f59ee7eea8af031d7c14"}]},
  {"namespace":"admin","name":"admin_*","status":"unsupported","description":"Geth node administration namespace (admin_nodeInfo, admin_peers, admin_addPeer, admin_datadir, and others). Sei does not run this namespace.","seiNote":"Sei does not run go-ethereum's admin namespace. Node administration goes through the CometBFT/Cosmos stack. All admin_* methods return -32601 method not found."},
  {"namespace":"miner","name":"miner_*","status":"unsupported","description":"Geth miner-control namespace (miner_start, miner_stop, miner_setEtherbase, miner_setGasPrice, and others). Sei does not run this namespace.","seiNote":"Sei has no PoW or PoA miner (CometBFT PoS consensus) and does not serve the namespace. All miner_* methods return -32601."},
  {"namespace":"clique","name":"clique_*","status":"unsupported","description":"Clique proof-of-authority consensus namespace (clique_getSnapshot, clique_propose, and others). Sei does not run this namespace.","seiNote":"Sei uses CometBFT, not the Clique PoA engine, and does not serve the namespace. All clique_* methods return -32601."},
  {"namespace":"engine","name":"engine_*","status":"unsupported","description":"Ethereum Engine API namespace (engine_newPayloadV*, engine_forkchoiceUpdatedV*, engine_getPayloadV*) for payload exchange between the consensus and execution layers. Sei does not run this namespace.","seiNote":"Sei is not a post-merge Ethereum execution client. It has no CL/EL split or payload engine (consensus is CometBFT). All engine_* methods return -32601."},
  {"namespace":"les","name":"les_*","status":"unsupported","description":"Light Ethereum Subprotocol (LES) light-server namespace. Sei does not run this namespace.","seiNote":"Sei does not implement LES light-server endpoints and does not serve the namespace. All les_* methods return -32601."},
  {"namespace":"personal","name":"personal_*","status":"unsupported","description":"Geth account-management namespace (personal_newAccount, personal_unlockAccount, personal_sendTransaction, personal_sign, and others). Sei does not run this namespace.","seiNote":"Sei does not expose the deprecated personal namespace. Hosted RPC nodes hold no user keys. Key management and signing happen client-side, and eth_sendRawTransaction is the supported path. All personal_* methods return -32601."}
];

const parseValue = (raw) => {
  if (typeof raw !== 'string') return raw;
  const t = raw.trim();
  if (t === '') return '';
  const looksJson = t[0] === '{' || t[0] === '[' || t === 'true' || t === 'false' || t === 'null';
  if (looksJson) {
    try { return JSON.parse(t); } catch (e) { return raw; }
  }
  return raw;
};

const isEmptyValue = (v) => {
  if (v === '' || v === undefined || v === null) return true;
  if (Array.isArray(v)) return v.length === 0;
  if (typeof v === 'object') return Object.keys(v).length === 0;
  return false;
};

const buildParams = (method, values) => {
  const defs = method.params || [];
  // Untouched fields (undefined) use the catalog example.
  const raw = defs.map((p) => {
    const v = values ? values[p.name] : undefined;
    return v !== undefined ? v : (p.example || '');
  });
  // A field is "cleared" only when it's blank. Typing a valid empty collection
  // ([] or {}) is a deliberate value and must be preserved as-is.
  const isBlank = (v) => typeof v === 'string' && v.trim() === '';
  // Drop trailing empty values (optional trailing args left empty/default)...
  let end = raw.length;
  while (end > 0 && isEmptyValue(parseValue(raw[end - 1]))) end--;
  // ...but a cleared *middle* arg can't be sent as "" (invalid positional
  // JSON-RPC param), so fall back to its catalog example to keep the call valid.
  // A non-blank middle value (including [] or {}) is preserved verbatim.
  const params = raw.slice(0, end).map((v, i) => (isBlank(v) ? parseValue(defs[i].example || '') : parseValue(v)));
  // eth_subscribe: the optional filter only applies to the logs stream
  // (tolerate casing/whitespace on the subscription type).
  const sub = typeof params[0] === 'string' ? params[0].trim().toLowerCase() : params[0];
  if (method.name === 'eth_subscribe' && sub !== 'logs') params.length = 1;
  return params;
};

const deriveWsEndpoint = (httpUrl) => {
  if (!httpUrl) return 'wss://<your-ws-endpoint>';
  try {
    const u = new URL(httpUrl);
    u.protocol = u.protocol === 'http:' ? 'ws:' : 'wss:';
    return u.toString().replace(/\/$/, '');
  } catch (e) {
    return 'wss://<your-ws-endpoint>';
  }
};

const isWsOnly = (name) => name === 'eth_subscribe' || name === 'eth_unsubscribe';
const isMutation = (name) => name === 'eth_sendRawTransaction' || name === 'eth_sendTransaction' || name === 'eth_signTransaction' || name === 'eth_sign' || name.startsWith('personal_');

  // See scripts/check-snippet-theme-default.mjs for the shared SSR theme
  // invariant. Layout sync applies a saved preference before paint.
  const [theme, setTheme] = useState('dark');
  const [isMobile, setIsMobile] = useState(false);
  const [mobileView, setMobileView] = useState('list');
  const rootRef = useRef(null);
  const runIdRef = useRef(0);    // tags Run requests so a stale in-flight response can't overwrite a newer one
  const probeIdRef = useRef(0);  // tags reachability probes so a stale one can't set the wrong Live/Offline state

  const [network, setNetwork] = useState('mainnet');
  const [customEndpoint, setCustomEndpoint] = useState('');
  const endpoint = network === 'custom' ? customEndpoint : NETWORKS[network].http;
  const wsEndpoint = network === 'custom' ? deriveWsEndpoint(customEndpoint) : NETWORKS[network].ws;
  const [connection, setConnection] = useState('idle'); // idle | ok | fail
  const [consoleActive, setConsoleActive] = useState(false); // true once the user engages the console; gates the connectivity ping so a page view alone doesn't hit the RPC

  const [searchTerm, setSearchTerm] = useState('');
  const [selectedNamespace, setSelectedNamespace] = useState('all');
  const [showAll, setShowAll] = useState(false);
  const isHiddenByDefault = (m) => m.status === 'unsupported' || !!(NAMESPACE_META[m.namespace] && NAMESPACE_META[m.namespace].deprecated);

  const [selectedMethod, setSelectedMethod] = useState(null);
  const [selectedLanguage, setSelectedLanguage] = useState('curl');
  const [paramValues, setParamValues] = useState({});
  const [debouncedParams, setDebouncedParams] = useState({});
  const [requestResult, setRequestResult] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [copied, setCopied] = useState('');

  const isDark = theme === 'dark';

  useLayoutEffect(() => {
    const detect = () => setTheme(document.documentElement.classList.contains('dark') ? 'dark' : 'light');
    detect();
    const observer = new MutationObserver(detect);
    observer.observe(document.documentElement, { attributes: true, attributeFilter: ['class'] });
    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    const stackBelow = (w) => setIsMobile(w < 768);
    const el = rootRef.current;
    if (el && typeof ResizeObserver !== 'undefined') {
      const ro = new ResizeObserver((entries) => stackBelow(entries[0].contentRect.width));
      ro.observe(el);
      return () => ro.disconnect();
    }
    const check = () => stackBelow(window.innerWidth);
    check();
    window.addEventListener('resize', check);
    return () => window.removeEventListener('resize', check);
  }, []);

  useEffect(() => {
    const t = setTimeout(() => setDebouncedParams(paramValues), 250);
    return () => clearTimeout(t);
  }, [paramValues]);

  const validateEndpoint = useCallback(async () => {
    if (!endpoint) { setConnection('idle'); return; }
    const probeId = ++probeIdRef.current;
    try {
      const res = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ jsonrpc: '2.0', id: 1, method: 'web3_clientVersion', params: [] }),
      });
      // Ignore a late response from a previous endpoint so the indicator
      // always reflects the current URL.
      if (probeId === probeIdRef.current) setConnection(res.ok ? 'ok' : 'fail');
    } catch (e) {
      if (probeId === probeIdRef.current) setConnection('fail');
    }
  }, [endpoint]);

  useEffect(() => { if (consoleActive) validateEndpoint(); }, [validateEndpoint, consoleActive]);

  // Clear any prior run result when the target endpoint changes (network switch
  // or custom-URL edit) and invalidate any in-flight request, so a response from
  // one endpoint is never left showing under a different network's label.
  // Also clear isLoading: a superseded in-flight Run is guarded out of its own
  // finally{}, so without this its spinner would stay stuck on.
  useEffect(() => { runIdRef.current++; setRequestResult(null); setIsLoading(false); }, [endpoint]);

  const allMethods = useMemo(() => SEI_RPC_METHODS.map((m) => ({ ...m, meta: NAMESPACE_META[m.namespace] || { label: m.namespace, color: '#6b7280' } })), []);

  const filteredMethods = useMemo(() => {
    let list = allMethods;
    if (selectedNamespace !== 'all') list = list.filter((m) => m.namespace === selectedNamespace);
    if (!showAll) list = list.filter((m) => !isHiddenByDefault(m));
    if (searchTerm) {
      const q = searchTerm.toLowerCase();
      list = list.filter((m) => m.name.toLowerCase().includes(q) || (m.description || '').toLowerCase().includes(q));
    }
    const rank = (s) => (s === 'supported' ? 0 : s === 'limited' ? 1 : 2);
    return [...list].sort((a, b) => {
      const ns = NAMESPACE_ORDER.indexOf(a.namespace) - NAMESPACE_ORDER.indexOf(b.namespace);
      if (ns !== 0) return ns;
      return rank(a.status) - rank(b.status);
    });
  }, [allMethods, selectedNamespace, showAll, searchTerm]);

  const visibleNamespaces = useMemo(() => {
    const present = new Set();
    allMethods.forEach((m) => { if (showAll || !isHiddenByDefault(m)) present.add(m.namespace); });
    return NAMESPACE_ORDER.filter((ns) => present.has(ns));
  }, [allMethods, showAll]);

  const counts = useMemo(() => allMethods.reduce((a, m) => ((a[m.status] = (a[m.status] || 0) + 1), a), {}), [allMethods]);

  const selectMethod = (m) => {
    setConsoleActive(true);
    setSelectedMethod(m);
    setParamValues({});
    // Clear synchronously so examples don't reuse the previous method's values.
    setDebouncedParams({});
    runIdRef.current++; // a pending Run from the previous method must not land here
    setRequestResult(null);
    setIsLoading(false); // ...and its guarded finally{} won't reset the spinner, so do it here
    setSelectedLanguage('curl');
    if (isMobile) setMobileView('detail');
  };

  const copy = (text, key) => {
    navigator.clipboard.writeText(text);
    setCopied(key);
    setTimeout(() => setCopied(''), 1500);
  };

  const execute = async () => {
    if (!selectedMethod) return;
    const runId = ++runIdRef.current; // a newer run, method switch, or endpoint change supersedes this one
    setIsLoading(true);
    setRequestResult(null);
    const params = buildParams(selectedMethod, paramValues);
    try {
      const res = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ jsonrpc: '2.0', id: 1, method: selectedMethod.name, params }),
      });
      const json = await res.json();
      if (runId === runIdRef.current) setRequestResult(json);
    } catch (e) {
      if (runId === runIdRef.current) setRequestResult({ error: { code: -1, message: e.message + ' (the endpoint may not allow CORS requests from a browser)' } });
    } finally {
      if (runId === runIdRef.current) setIsLoading(false);
    }
  };

  // ---- Code generation ---------------------------------------------------
  const generateCode = useCallback((method, language) => {
    if (!method) return '';
    const params = buildParams(method, debouncedParams);
    const paramsJson = JSON.stringify(params);
    const bodyJson = JSON.stringify({ jsonrpc: '2.0', id: 1, method: method.name, params });
    const url = endpoint || 'https://evm-rpc.sei-apis.com';
    const ws = wsEndpoint;
    const BT = String.fromCharCode(96); // backtick, for raw string literals
    const csBody = bodyJson.replace(/\\/g, '\\\\').replace(/"/g, '\\"'); // valid C#/JSON string literal

    if (isWsOnly(method.name)) {
      if (language === 'javascript') {
        return [
          `// ${method.name} runs over WebSocket only.`,
          `const socket = new WebSocket('${ws}');`,
          'socket.onopen = () => socket.send(JSON.stringify({',
          `  jsonrpc: '2.0', id: 1, method: '${method.name}', params: ${paramsJson},`,
          '}));',
          'socket.onmessage = (e) => console.log(JSON.parse(e.data));',
          '',
          '// ethers v6',
          "import { WebSocketProvider } from 'ethers';",
          `const provider = new WebSocketProvider('${ws}');`,
          `console.log(await provider.send('${method.name}', ${paramsJson}));`,
        ].join('\n');
      }
      if (language === 'typescript') {
        return [
          `// ${method.name} runs over WebSocket only.`,
          `const socket = new WebSocket('${ws}');`,
          'socket.onopen = () => socket.send(JSON.stringify({',
          `  jsonrpc: '2.0', id: 1, method: '${method.name}', params: ${paramsJson},`,
          '}));',
          'socket.onmessage = (e: MessageEvent) => console.log(JSON.parse(e.data));',
        ].join('\n');
      }
      if (language === 'python') {
        return [
          '# pip install websocket-client',
          'from websocket import create_connection',
          `socket = create_connection("${ws}")`,
          `socket.send(r"""${bodyJson}""")`,
          'print(socket.recv())',
          'socket.close()',
        ].join('\n');
      }
      if (language === 'go') {
        return [
          '// go get github.com/gorilla/websocket',
          'package main',
          '',
          'import (',
          '\t"fmt"',
          '\t"github.com/gorilla/websocket"',
          ')',
          '',
          'func main() {',
          `\tc, _, err := websocket.DefaultDialer.Dial("${ws}", nil)`,
          '\tif err != nil {',
          '\t\tpanic(err)',
          '\t}',
          '\tdefer c.Close()',
          '\tc.WriteMessage(websocket.TextMessage, []byte(' + BT + bodyJson + BT + '))',
          '\t_, msg, _ := c.ReadMessage()',
          '\tfmt.Println(string(msg))',
          '}',
        ].join('\n');
      }
      if (language === 'rust') {
        return [
          '// tokio-tungstenite = "0.23"  futures-util = "0.3"  tokio = { version = "1", features = ["full"] }',
          'use futures_util::{SinkExt, StreamExt};',
          'use tokio_tungstenite::{connect_async, tungstenite::Message};',
          '',
          '#[tokio::main]',
          'async fn main() -> Result<(), Box<dyn std::error::Error>> {',
          `    let (mut socket, _) = connect_async("${ws}").await?;`,
          '    socket.send(Message::Text(r#"' + bodyJson + '"#.to_string())).await?;',
          '    if let Some(msg) = socket.next().await {',
          '        println!("{}", msg?);',
          '    }',
          '    Ok(())',
          '}',
        ].join('\n');
      }
      if (language === 'csharp') {
        return [
          'using System;',
          'using System.Net.WebSockets;',
          'using System.Text;',
          'using System.Threading;',
          '',
          'using var socket = new ClientWebSocket();',
          `await socket.ConnectAsync(new Uri("${ws}"), CancellationToken.None);`,
          `var body = Encoding.UTF8.GetBytes("${csBody}");`,
          'await socket.SendAsync(body, WebSocketMessageType.Text, true, CancellationToken.None);',
          'var buffer = new byte[8192];',
          'var res = await socket.ReceiveAsync(buffer, CancellationToken.None);',
          'Console.WriteLine(Encoding.UTF8.GetString(buffer, 0, res.Count));',
        ].join('\n');
      }
      if (language === 'cast') {
        return [
          `# ${method.name} is WebSocket-only. cast has no native WebSocket support.`,
          '# Use wscat (npm i -g wscat):',
          `wscat -c ${ws}`,
          `> ${bodyJson}`,
        ].join('\n');
      }
      if (language === 'java') {
        return [
          'import java.net.URI;',
          'import java.net.http.*;',
          'import java.util.concurrent.CompletableFuture;',
          'import java.util.concurrent.CompletionStage;',
          '',
          'var done = new CompletableFuture<Void>();',
          'HttpClient.newHttpClient().newWebSocketBuilder()',
          `    .buildAsync(URI.create("${ws}"), new WebSocket.Listener() {`,
          '        public void onOpen(WebSocket ws) {',
          `            ws.sendText("${csBody}", true); ws.request(1);`,
          '        }',
          '        public CompletionStage<?> onText(WebSocket ws, CharSequence data, boolean last) {',
          '            System.out.println(data); done.complete(null); return null;',
          '        }',
          '    }).join();',
          'done.join();',
        ].join('\n');
      }
      if (language === 'kotlin') {
        return [
          'import java.net.URI',
          'import java.net.http.*',
          'import java.util.concurrent.CompletableFuture',
          'import java.util.concurrent.CompletionStage',
          '',
          'val done = CompletableFuture<Void>()',
          'HttpClient.newHttpClient().newWebSocketBuilder()',
          `    .buildAsync(URI.create("${ws}"), object : WebSocket.Listener {`,
          '        override fun onOpen(ws: WebSocket) {',
          `            ws.sendText("${csBody}", true); ws.request(1)`,
          '        }',
          '        override fun onText(ws: WebSocket, data: CharSequence, last: Boolean): CompletionStage<*>? {',
          '            println(data); done.complete(null); ws.request(1); return null',
          '        }',
          '    }).join()',
          'done.join()',
        ].join('\n');
      }
      if (language === 'swift') {
        return [
          'import Foundation',
          '',
          `let task = URLSession.shared.webSocketTask(with: URL(string: "${ws}")!)`,
          'task.resume()',
          `try await task.send(.string(#"${bodyJson}"#))`,
          'let msg = try await task.receive()',
          'if case .string(let text) = msg { print(text) }',
          'task.cancel(with: .normalClosure, reason: nil)',
        ].join('\n');
      }
      // curl (default) — wscat
      return [
        `# ${method.name} is WebSocket-only. Use wscat (npm i -g wscat):`,
        `wscat -c ${ws}`,
        `> ${bodyJson}`,
      ].join('\n');
    }

    if (language === 'javascript') {
      return [
        '// fetch',
        `const res = await fetch('${url}', {`,
        "  method: 'POST',",
        "  headers: { 'Content-Type': 'application/json' },",
        '  body: JSON.stringify({',
        "    jsonrpc: '2.0', id: 1,",
        `    method: '${method.name}',`,
        `    params: ${paramsJson},`,
        '  }),',
        '});',
        'console.log((await res.json()).result);',
        '',
        '// ethers v6',
        "import { JsonRpcProvider } from 'ethers';",
        `const provider = new JsonRpcProvider('${url}');`,
        `console.log(await provider.send('${method.name}', ${paramsJson}));`,
        '',
        '// viem',
        "import { createPublicClient, http } from 'viem';",
        `const client = createPublicClient({ transport: http('${url}') });`,
        `console.log(await client.request({ method: '${method.name}', params: ${paramsJson} }));`,
      ].join('\n');
    }

    if (language === 'typescript') {
      return [
        'type RpcResponse<T> = {',
        '  jsonrpc: string; id: number;',
        '  result?: T; error?: { code: number; message: string };',
        '};',
        '',
        `const res = await fetch('${url}', {`,
        "  method: 'POST',",
        "  headers: { 'Content-Type': 'application/json' },",
        '  body: JSON.stringify({',
        "    jsonrpc: '2.0', id: 1,",
        `    method: '${method.name}',`,
        `    params: ${paramsJson},`,
        '  }),',
        '});',
        'const data: RpcResponse<unknown> = await res.json();',
        'console.log(data.result);',
        '',
        '// ethers v6',
        "import { JsonRpcProvider } from 'ethers';",
        `const provider = new JsonRpcProvider('${url}');`,
        `console.log(await provider.send('${method.name}', ${paramsJson}));`,
      ].join('\n');
    }

    if (language === 'python') {
      return [
        'import requests, json',
        '',
        `url = "${url}"`,
        `params = json.loads(r"""${paramsJson}""")`,
        'res = requests.post(url, json={',
        '    "jsonrpc": "2.0", "id": 1,',
        `    "method": "${method.name}", "params": params,`,
        '})',
        'print(res.json().get("result"))',
        '',
        '# web3.py',
        'from web3 import Web3',
        'w3 = Web3(Web3.HTTPProvider(url))',
        `print(w3.provider.make_request("${method.name}", params))`,
      ].join('\n');
    }

    if (language === 'go') {
      return [
        'package main',
        '',
        'import (',
        '\t"bytes"',
        '\t"fmt"',
        '\t"io"',
        '\t"net/http"',
        ')',
        '',
        'func main() {',
        '\tbody := []byte(' + BT + bodyJson + BT + ')',
        `\tresp, err := http.Post("${url}", "application/json", bytes.NewBuffer(body))`,
        '\tif err != nil {',
        '\t\tpanic(err)',
        '\t}',
        '\tdefer resp.Body.Close()',
        '\tout, _ := io.ReadAll(resp.Body)',
        '\tfmt.Println(string(out))',
        '}',
      ].join('\n');
    }

    if (language === 'rust') {
      return [
        '// reqwest = { version = "0.12", features = ["json"] }',
        '// serde_json = "1"   tokio = { version = "1", features = ["full"] }',
        'use serde_json::Value;',
        '',
        '#[tokio::main]',
        'async fn main() -> Result<(), Box<dyn std::error::Error>> {',
        '    let body: Value = serde_json::from_str(r#"' + bodyJson + '"#)?;',
        `    let res = reqwest::Client::new().post("${url}")`,
        '        .json(&body).send().await?',
        '        .json::<Value>().await?;',
        '    println!("{:#?}", res["result"]);',
        '    Ok(())',
        '}',
      ].join('\n');
    }

    if (language === 'csharp') {
      return [
        'using System;',
        'using System.Net.Http;',
        'using System.Text;',
        '',
        'using var http = new HttpClient();',
        `var json = "${csBody}";`,
        'var content = new StringContent(json, Encoding.UTF8, "application/json");',
        `var res = await http.PostAsync("${url}", content);`,
        'Console.WriteLine(await res.Content.ReadAsStringAsync());',
      ].join('\n');
    }

    if (language === 'cast') {
      const castArgs = params.map(p => `'${JSON.stringify(p)}'`).join(' ');
      return `cast rpc --rpc-url ${url} ${method.name}${params.length ? ' ' + castArgs : ''}`;
    }

    if (language === 'java') {
      return [
        'import java.net.URI;',
        'import java.net.http.*;',
        '',
        `var json = "${csBody}";`,
        `var req = HttpRequest.newBuilder(URI.create("${url}"))`,
        '    .header("Content-Type", "application/json")',
        '    .POST(HttpRequest.BodyPublishers.ofString(json))',
        '    .build();',
        'var res = HttpClient.newHttpClient().send(req, HttpResponse.BodyHandlers.ofString());',
        'System.out.println(res.body());',
      ].join('\n');
    }

    if (language === 'kotlin') {
      return [
        'import java.net.URI',
        'import java.net.http.HttpClient',
        'import java.net.http.HttpRequest',
        'import java.net.http.HttpResponse',
        '',
        `val json = "${csBody}"`,
        `val req = HttpRequest.newBuilder(URI.create("${url}"))`,
        '    .header("Content-Type", "application/json")',
        '    .POST(HttpRequest.BodyPublishers.ofString(json))',
        '    .build()',
        'val res = HttpClient.newHttpClient().send(req, HttpResponse.BodyHandlers.ofString())',
        'println(res.body())',
      ].join('\n');
    }

    if (language === 'swift') {
      return [
        'import Foundation',
        '',
        `let url = URL(string: "${url}")!`,
        'var request = URLRequest(url: url)',
        'request.httpMethod = "POST"',
        'request.setValue("application/json", forHTTPHeaderField: "Content-Type")',
        `request.httpBody = Data(#"${bodyJson}"#.utf8)`,
        '',
        'let (data, _) = try await URLSession.shared.data(for: request)',
        'print(String(decoding: data, as: UTF8.self))',
      ].join('\n');
    }

    // curl (default) — escape single quotes so apostrophes in param values
    // don't terminate the shell-quoted -d string ('\'' closes, escapes, reopens).
    const curlBody = bodyJson.replace(/'/g, "'\\''");
    return `curl -s -X POST ${url} \\\n  -H "Content-Type: application/json" \\\n  -d '${curlBody}'`;
  }, [endpoint, wsEndpoint, debouncedParams]);

  const codeExample = useMemo(() => generateCode(selectedMethod, selectedLanguage), [selectedMethod, selectedLanguage, generateCode]);

  // ---- Styling shorthands -------------------------------------------------
  const c = {
    bg: isDark ? '#000000' : '#f5f5f7',
    panel: isDark ? '#0a0a0a' : '#ffffff',
    panel2: isDark ? '#121212' : '#f5f5f7',
    border: isDark ? '#1f1f1f' : '#ececee',
    text: isDark ? '#ffffff' : '#131313',
    sub: isDark ? '#9ca3af' : '#666666',
    // #999 on the white panel is 2.85:1 and #6b7280 on #0a0a0a is 4.1:1 (method
    // descriptions are 11.5px). These pass 4.5:1 in both themes.
    faint: isDark ? '#8b919c' : '#707070',
    input: isDark ? '#161616' : '#ffffff',
    code: isDark ? '#0d0d0d' : '#1a1a1a',
    maroon: '#600014',
  };
  const mono = 'var(--sei-font-mono, ui-monospace, "SF Mono", Menlo, monospace)';
  const bd = '1px solid ' + c.border; // shared 1px border
  const fieldStyle = { width: '100%', fontSize: 12, fontFamily: mono, padding: '7px 10px', background: c.input, color: c.text, border: bd, borderRadius: 4, outline: 'none', boxSizing: 'border-box' };
  const statusColor = (s) => (isDark ? STATUS_META[s].dark : STATUS_META[s].light);

  const StatusDot = ({ status }) => (
    <span title={STATUS_META[status].label} style={{ display: 'inline-block', width: 7, height: 7, borderRadius: 9, background: statusColor(status), flexShrink: 0 }} />
  );

  const Badge = ({ status }) => (
    <span style={{ fontSize: 11, fontWeight: 600, padding: '2px 8px', borderRadius: 3, color: statusColor(status), background: statusColor(status) + '22', border: `1px solid ${statusColor(status)}55` }}>
      {STATUS_META[status].label}
    </span>
  );

  const CopyBtn = ({ text, k }) => (
    <button
      onClick={() => copy(text, k)}
      style={{ fontSize: 11, color: c.sub, background: 'transparent', border: bd, borderRadius: 3, padding: '3px 8px', cursor: 'pointer' }}
    >
      {copied === k ? 'Copied' : 'Copy'}
    </button>
  );

  const CodeBlock = ({ text, maxHeight }) => (
    <pre style={{ margin: 0, padding: 14, borderRadius: 4, background: c.code, border: bd, overflowX: 'auto', maxHeight }}>
      <code style={{ fontFamily: mono, fontSize: 12, color: '#d4d4d4', whiteSpace: 'pre', lineHeight: 1.6 }}>{text}</code>
    </pre>
  );

  const m = selectedMethod;
  const mMeta = m ? NAMESPACE_META[m.namespace] || {} : {};

  return (
    <div ref={rootRef} className="not-prose rpc-explorer-root" style={{ fontFamily: 'var(--sei-font-body, inherit)', color: c.text, background: c.bg, border: bd, borderRadius: 6, overflow: 'hidden', display: 'flex', flexDirection: 'column', height: '96vh', minHeight: 768 }}>
      <div style={{ borderBottom: bd, background: c.panel, padding: '14px 18px', display: 'flex', flexDirection: 'column', gap: 12, flexShrink: 0 }}>
        <div>
          <div style={{ fontSize: 16, fontWeight: 700, letterSpacing: '-0.01em' }}>Sei EVM JSON-RPC Explorer</div>
          <div style={{ fontSize: 12, color: c.sub, marginTop: 2 }}>
            {allMethods.length} methods · {counts.supported} supported · {counts.limited} limited · {counts.unsupported} unavailable
          </div>
        </div>
        <div style={{ display: 'flex', gap: 8, alignItems: 'center', flexWrap: 'wrap' }}>
          {/* Network segmented control */}
          <div style={{ display: 'flex', border: bd, borderRadius: 4, overflow: 'hidden' }}>
            {['mainnet', 'testnet', 'custom'].map((n) => (
              <button
                key={n}
                onClick={() => { setNetwork(n); setConnection('idle'); }}
                style={{
                  fontSize: 12, padding: '6px 12px', cursor: 'pointer', border: 'none', textTransform: 'capitalize',
                  background: network === n ? c.maroon : 'transparent',
                  color: network === n ? '#fff' : c.sub,
                  fontWeight: network === n ? 600 : 400,
                }}
              >
                {n}
              </button>
            ))}
          </div>
          {network === 'custom' ? (
            <input
              value={customEndpoint}
              onChange={(e) => { setCustomEndpoint(e.target.value); setConnection('idle'); }}
              onBlur={validateEndpoint}
              placeholder="https://your-rpc"
              style={{ fontSize: 12, fontFamily: mono, padding: '6px 10px', width: 220, background: c.input, color: c.text, border: bd, borderRadius: 4, outline: 'none' }}
            />
          ) : (
            <code style={{ fontSize: 12, fontFamily: mono, color: c.sub, padding: '5px 10px', background: c.panel2, borderRadius: 4, border: bd, maxWidth: '100%', overflowWrap: 'anywhere' }}>{endpoint}</code>
          )}
          <span title={connection === 'ok' ? 'Reachable' : connection === 'fail' ? 'Unreachable from this browser' : 'Not checked'} style={{ display: 'inline-flex', alignItems: 'center', gap: 5, fontSize: 11, color: connection === 'ok' ? '#22c55e' : connection === 'fail' ? '#ef4444' : c.faint }}>
            <span style={{ width: 8, height: 8, borderRadius: 9, background: connection === 'ok' ? '#22c55e' : connection === 'fail' ? '#ef4444' : c.faint }} />
            {connection === 'ok' ? 'Live' : connection === 'fail' ? 'Offline' : '—'}
          </span>
        </div>
      </div>

      {/* Body */}
      <div style={{ flex: 1, display: 'flex', overflow: 'hidden' }}>
        {/* Left: list */}
        <div style={{ width: isMobile ? '100%' : 320, flexShrink: 0, display: (isMobile && mobileView !== 'list') ? 'none' : 'flex', flexDirection: 'column', borderRight: isMobile ? 'none' : bd, background: c.panel, overflow: 'hidden' }}>
          <div style={{ padding: 14, borderBottom: bd }}>
            <input
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search methods…"
              style={{ width: '100%', fontSize: 13, padding: '8px 12px', background: c.input, color: c.text, border: bd, borderRadius: 4, outline: 'none', boxSizing: 'border-box' }}
            />
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: 5, marginTop: 10 }}>
              <button
                onClick={() => setSelectedNamespace('all')}
                style={{ fontSize: 11, padding: '3px 9px', borderRadius: 3, cursor: 'pointer', fontWeight: 600, border: `1px solid ${selectedNamespace === 'all' ? c.maroon : c.border}`, background: selectedNamespace === 'all' ? c.maroon : 'transparent', color: selectedNamespace === 'all' ? '#fff' : c.sub }}
              >
                All
              </button>
              {visibleNamespaces.map((ns) => {
                const active = selectedNamespace === ns;
                const col = NAMESPACE_META[ns].color;
                const colFg = isDark && NAMESPACE_META[ns].colorDark ? NAMESPACE_META[ns].colorDark : col;
                return (
                  <button
                    key={ns}
                    onClick={() => setSelectedNamespace(ns)}
                    style={{ fontSize: 11, padding: '3px 9px', borderRadius: 3, cursor: 'pointer', fontWeight: 600, border: `1px solid ${active ? col : colFg}`, background: active ? col : 'transparent', color: active ? '#fff' : colFg, opacity: active ? 1 : 0.85 }}
                  >
                    {NAMESPACE_META[ns].label}
                  </button>
                );
              })}
            </div>
            <label style={{ display: 'flex', alignItems: 'center', gap: 7, marginTop: 11, fontSize: 12, color: c.sub, cursor: 'pointer' }}>
              <input
                type="checkbox"
                checked={showAll}
                onChange={(e) => {
                  const next = e.target.checked;
                  setShowAll(next);
                  if (!next) {
                    if (selectedNamespace !== 'all') {
                      const meta = NAMESPACE_META[selectedNamespace];
                      if (meta && (meta.deprecated || meta.unavailable)) setSelectedNamespace('all');
                    }
                    // If the open method just disappeared from the list, close its
                    // detail pane so it can't linger behind a hidden filter.
                    if (selectedMethod && isHiddenByDefault(selectedMethod)) {
                      runIdRef.current++;
                      setSelectedMethod(null);
                      setRequestResult(null);
                      setIsLoading(false);
                    }
                  }
                }}
                style={{ accentColor: c.maroon }}
              />
              Show deprecated &amp; unavailable methods
            </label>
          </div>
          <div style={{ flex: 1, overflowY: 'auto' }}>
            {filteredMethods.length === 0 && (
              <div style={{ padding: 24, fontSize: 13, color: c.faint, textAlign: 'center' }}>No methods match.</div>
            )}
            {filteredMethods.map((mm) => {
              const active = m && m.name === mm.name;
              return (
                <button
                  key={mm.name}
                  onClick={() => selectMethod(mm)}
                  style={{ width: '100%', textAlign: 'left', padding: '9px 13px 9px 12px', cursor: 'pointer', border: 'none', borderLeft: `3px solid ${isDark && mm.meta.colorDark ? mm.meta.colorDark : mm.meta.color}`, borderBottom: bd, background: active ? (isDark ? '#161616' : '#f0eef0') : 'transparent', display: 'block', opacity: mm.status === 'unsupported' ? 0.6 : 1 }}
                >
                  <div style={{ display: 'flex', alignItems: 'center', gap: 7 }}>
                    <StatusDot status={mm.status} />
                    <code style={{ fontFamily: mono, fontSize: 12.5, color: active ? c.text : (isDark ? '#e5e5e5' : '#1a1a1a'), fontWeight: active ? 600 : 500, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{mm.name}</code>
                  </div>
                  <div style={{ fontSize: 11.5, color: c.faint, marginTop: 3, lineHeight: 1.35, display: '-webkit-box', WebkitLineClamp: 2, WebkitBoxOrient: 'vertical', overflow: 'hidden' }}>{mm.description}</div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Right: detail */}
        <div style={{ flex: 1, display: (isMobile && mobileView !== 'detail') ? 'none' : 'flex', flexDirection: 'column', overflowY: 'auto', background: c.bg }}>
          {!m ? (
            <div style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', color: c.faint, fontSize: 14, padding: 24, textAlign: 'center' }}>
              Select a method to see its reference, parameters, and runnable examples.
            </div>
          ) : (
            <div style={{ padding: isMobile ? 16 : 24, maxWidth: 860 }}>
              {isMobile && (
                <button onClick={() => setMobileView('list')} style={{ fontSize: 12, color: c.sub, background: 'transparent', border: 'none', cursor: 'pointer', padding: 0, marginBottom: 12 }}>← Methods</button>
              )}
              <div style={{ display: 'flex', alignItems: 'center', gap: 10, flexWrap: 'wrap' }}>
                <code style={{ fontFamily: mono, fontSize: 19, fontWeight: 700, color: c.text }}>{m.name}</code>
                <Badge status={m.status} />
                <span style={{ fontSize: 11, padding: '2px 8px', borderRadius: 3, color: '#fff', background: mMeta.color }}>{mMeta.label}</span>
              </div>
              <p style={{ fontSize: 14, color: c.sub, marginTop: 10, lineHeight: 1.55 }}>{m.description}</p>

              {mMeta.deprecated && (
                <div style={{ marginTop: 14, padding: '10px 14px', borderRadius: 4, background: '#f59e0b18', border: '1px solid #f59e0b55', fontSize: 12.5, color: isDark ? '#fbbf24' : '#92400e', lineHeight: 1.5 }}>
                  <strong>Deprecated.</strong> The <code style={{ fontFamily: mono }}>{m.namespace}_*</code> namespace is scheduled for removal. The <code style={{ fontFamily: mono }}>enabled_legacy_sei_apis</code> setting in <code style={{ fontFamily: mono }}>app.toml</code> controls access to it. Prefer standard <code style={{ fontFamily: mono }}>eth_*</code> and <code style={{ fontFamily: mono }}>debug_*</code> methods for new integrations.
                </div>
              )}
              {mMeta.unavailable && (
                <div style={{ marginTop: 14, padding: '10px 14px', borderRadius: 4, background: isDark ? '#ffffff0a' : '#0000000a', border: bd, fontSize: 12.5, color: c.sub, lineHeight: 1.5 }}>
                  The entire <code style={{ fontFamily: mono }}>{m.namespace}_*</code> namespace is not exposed on Sei. {mMeta.blurb}
                </div>
              )}
              {m.seiNote && (
                <div style={{ marginTop: 14, padding: '12px 14px', borderRadius: 4, background: c.maroon + (isDark ? '22' : '12'), border: `1px solid ${c.maroon}${isDark ? '66' : '44'}`, fontSize: 12.5, color: isDark ? '#e9b8c0' : '#600014', lineHeight: 1.55 }}>
                  <div style={{ fontWeight: 700, marginBottom: 4, fontSize: 11, letterSpacing: '0.04em', textTransform: 'uppercase' }}>Sei-specific behavior</div>
                  {m.seiNote}
                </div>
              )}

              {/* Parameters */}
              {m.params && m.params.length > 0 && (
                <div style={{ marginTop: 22 }}>
                  <div style={{ fontSize: 13, fontWeight: 700, marginBottom: 10 }}>Parameters</div>
                  <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                    {m.params.map((p) => (
                      <div key={p.name} style={{ padding: '10px 13px', borderRadius: 4, background: c.panel2, border: bd }}>
                        <div style={{ display: 'flex', alignItems: 'center', gap: 8, flexWrap: 'wrap' }}>
                          <code style={{ fontFamily: mono, fontSize: 12.5, color: isDark ? '#e9b8c0' : c.maroon, fontWeight: 600 }}>{p.name}</code>
                          <span style={{ fontSize: 10.5, padding: '1px 7px', borderRadius: 3, color: c.sub, background: isDark ? '#ffffff10' : '#00000008', border: bd, fontFamily: mono }}>{p.type}</span>
                        </div>
                        <div style={{ fontSize: 12.5, color: c.sub, marginTop: 5, lineHeight: 1.5 }}>{p.description}</div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Try it — request (inputs + code) first, then Run, then Result */}
              {m.status !== 'unsupported' && (
                <div style={{ marginTop: 22 }}>
                  <div style={{ fontSize: 13, fontWeight: 700, marginBottom: 10, display: 'flex', alignItems: 'center', gap: 8 }}>
                    Try it
                    <span style={{ fontSize: 11, fontWeight: 400, color: c.faint }}>· {network === 'custom' ? (endpoint || 'set a custom endpoint') : NETWORKS[network].label}</span>
                  </div>

                  {isWsOnly(m.name) && (
                    <div style={{ padding: '10px 14px', borderRadius: 4, background: c.panel2, border: bd, fontSize: 12.5, color: c.sub, lineHeight: 1.5, marginBottom: 10 }}>
                      This is a WebSocket subscription method. Connect to <code style={{ fontFamily: mono }}>{wsEndpoint}</code> and send the payload below. To customize the subscription, edit the parameters.
                      {network === 'custom' && ' This URL is a best guess, derived from your HTTP endpoint. Sei serves WebSocket on a separate host (evm-ws…) from HTTP (evm-rpc…). If this URL differs from the actual WebSocket endpoint of your node, replace it.'}
                    </div>
                  )}
                  {m.params && m.params.length > 0 && (
                    <div style={{ display: 'flex', flexDirection: 'column', gap: 8, marginBottom: 10 }}>
                      {m.params.map((p) => {
                        const ex = p.example || '';
                        const big = ex.trim().startsWith('{') || ex.trim().startsWith('[') || (p.type || '').toLowerCase().includes('object');
                        const fieldId = `rpc-param-${p.name}`;
                        const field = {
                          id: fieldId,
                          value: paramValues[p.name] !== undefined ? paramValues[p.name] : '',
                          onChange: (e) => setParamValues((prev) => ({ ...prev, [p.name]: e.target.value })),
                          placeholder: ex,
                        };
                        return (
                          <div key={p.name}>
                            <label htmlFor={fieldId} style={{ fontSize: 11, color: c.faint, fontFamily: mono, display: 'block', marginBottom: 3 }}>{p.name}</label>
                            {big
                              ? <textarea rows={2} {...field} style={{ ...fieldStyle, resize: 'vertical' }} />
                              : <input {...field} style={fieldStyle} />}
                          </div>
                        );
                      })}
                    </div>
                  )}
                  {isMutation(m.name) && (
                    <div style={{ fontSize: 11.5, color: c.faint, marginBottom: 8, lineHeight: 1.45 }}>
                      This is a state-changing or signing method. Public RPC nodes hold no keys, so it generally returns an error unless you supply a signed payload.
                    </div>
                  )}

                  {/* Request — code example */}
                  <div style={{ marginTop: 12 }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8, flexWrap: 'wrap', gap: 8 }}>
                      <div style={{ fontSize: 12, fontWeight: 700, color: c.sub }}>Request</div>
                      <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
                        <div style={{ display: 'flex', gap: 3, flexWrap: 'wrap' }}>
                          {LANGUAGES.map((l) => (
                            <button
                              key={l.id}
                              onClick={() => setSelectedLanguage(l.id)}
                              style={{ fontSize: 11, padding: '3px 9px', borderRadius: 3, cursor: 'pointer', border: 'none', background: selectedLanguage === l.id ? c.maroon : (isDark ? '#161616' : '#ececee'), color: selectedLanguage === l.id ? '#fff' : c.sub }}
                            >
                              {l.name}
                            </button>
                          ))}
                        </div>
                        <CopyBtn text={codeExample} k="code" />
                      </div>
                    </div>
                    <CodeBlock text={codeExample} />
                  </div>

                  {/* Run + Result (HTTP-callable methods) */}
                  {!isWsOnly(m.name) && (
                    <div style={{ marginTop: 14 }}>
                      <button
                        onClick={execute}
                        disabled={isLoading || !endpoint}
                        style={{ fontSize: 13, fontWeight: 600, padding: '8px 18px', borderRadius: 4, cursor: isLoading || !endpoint ? 'not-allowed' : 'pointer', border: 'none', background: c.maroon, color: '#fff', opacity: isLoading || !endpoint ? 0.55 : 1 }}
                      >
                        {isLoading ? 'Running…' : 'Run request'}
                      </button>
                      {requestResult && (
                        <div style={{ marginTop: 12 }}>
                          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 6 }}>
                            <span style={{ fontSize: 11, color: requestResult.error ? '#ef4444' : '#22c55e', fontWeight: 600 }}>{requestResult.error ? 'Error' : 'Result'}</span>
                            <CopyBtn text={JSON.stringify(requestResult, null, 2)} k="resp" />
                          </div>
                          <CodeBlock text={JSON.stringify(requestResult, null, 2)} maxHeight={280} />
                        </div>
                      )}
                    </div>
                  )}
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default RPCMethodsViewer;
