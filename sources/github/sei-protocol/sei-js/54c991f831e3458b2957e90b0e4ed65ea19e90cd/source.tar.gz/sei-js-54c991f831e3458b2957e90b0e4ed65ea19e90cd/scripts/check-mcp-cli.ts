import { createServer } from 'node:net';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = join(dirname(fileURLToPath(import.meta.url)), '..');
const packageDir = join(root, 'packages/mcp-server');
const packageJson = await Bun.file(join(packageDir, 'package.json')).json();

const checkVersion = async (entrypoint: string) => {
	const child = Bun.spawn(['node', entrypoint, '--version'], {
		cwd: root,
		stdout: 'pipe',
		stderr: 'pipe'
	});
	const [exitCode, stdout, stderr] = await Promise.all([child.exited, new Response(child.stdout).text(), new Response(child.stderr).text()]);

	if (exitCode !== 0 || stdout.trim() !== packageJson.version || stderr.trim()) {
		throw new Error(
			`MCP CLI check failed for ${entrypoint}: exit=${exitCode}, stdout=${JSON.stringify(stdout.trim())}, stderr=${JSON.stringify(stderr.trim())}`
		);
	}
};

const redactDiagnostics = (value: string, secrets: string[]): string =>
	secrets.reduce((sanitized, secret) => (secret ? sanitized.split(secret).join('[redacted]') : sanitized), value);

const checkPackagedBinFailure = async (
	name: string,
	environment: Record<string, string>,
	expectedError: string,
	secrets: string[],
	allowAdditionalLines = false,
	forbiddenText: string[] = []
): Promise<void> => {
	const entrypoint = join(packageDir, 'bin/mcp-server.js');
	const child = Bun.spawn(['node', entrypoint], {
		cwd: root,
		env: {
			...process.env,
			...environment
		},
		stdin: 'ignore',
		stdout: 'pipe',
		stderr: 'pipe'
	});
	const [exitCode, stdout, stderr] = await Promise.all([child.exited, new Response(child.stdout).text(), new Response(child.stderr).text()]);
	const output = `${stdout}\n${stderr}`;
	const unexpectedLines = stderr
		.split(/\r?\n/)
		.map((line) => line.trim())
		.filter((line) => line && line !== expectedError && !line.startsWith('Supported networks:'));
	const leakedSecret = secrets.some((secret) => secret && output.includes(secret));
	const containsForbiddenText = forbiddenText.some((value) => output.includes(value));
	const hasUncaughtStack = /(?:^|\n)\s*(?:at\s|file:\/\/|node:internal\/)|uncaught|unhandled(?:Promise)?rejection/i.test(output);

	if (
		exitCode !== 1 ||
		stdout.trim() ||
		!stderr.split(/\r?\n/).includes(expectedError) ||
		(!allowAdditionalLines && unexpectedLines.length > 0) ||
		leakedSecret ||
		containsForbiddenText ||
		hasUncaughtStack
	) {
		throw new Error(
			`MCP packaged-bin failure check failed for ${name}: exit=${exitCode}, stdout=${JSON.stringify(redactDiagnostics(stdout.trim(), secrets))}, stderr=${JSON.stringify(
				redactDiagnostics(stderr.trim(), secrets)
			)}`
		);
	}
};

const getAvailablePort = async (): Promise<number> =>
	new Promise((resolve, reject) => {
		const server = createServer();
		server.once('error', reject);
		server.listen(0, '127.0.0.1', () => {
			const address = server.address();
			if (!address || typeof address === 'string') {
				server.close();
				reject(new Error('Could not allocate a port for the MCP HTTP startup check'));
				return;
			}

			server.close((error) => {
				if (error) reject(error);
				else resolve(address.port);
			});
		});
	});

const waitForHealth = async (child: ReturnType<typeof Bun.spawn>, port: number): Promise<boolean> => {
	const deadline = Date.now() + 10_000;
	while (Date.now() < deadline && child.exitCode === null) {
		try {
			const response = await fetch(`http://127.0.0.1:${port}/health`, { signal: AbortSignal.timeout(500) });
			if (response.ok) return true;
		} catch {
			// The listener may not be ready yet.
		}
		await Bun.sleep(50);
	}
	return false;
};

const killProcessTree = (child: ReturnType<typeof Bun.spawn>, signal: 'SIGTERM' | 'SIGKILL') => {
	if (typeof child.pid === 'number') {
		try {
			process.kill(-child.pid, signal);
			return;
		} catch {
			// Process group kill is unsupported (Windows) or the group is already gone.
		}
	}

	child.kill(signal === 'SIGKILL' ? 9 : undefined);
};

const stopChild = async (child: ReturnType<typeof Bun.spawn>): Promise<void> => {
	if (child.exitCode !== null) return;

	killProcessTree(child, 'SIGTERM');
	const stopped = await Promise.race([child.exited.then(() => true), Bun.sleep(2_000).then(() => false)]);
	if (!stopped) {
		killProcessTree(child, 'SIGKILL');
		await Promise.race([child.exited.then(() => undefined), Bun.sleep(2_000)]);
	}
};

const collectProcessOutput = async (stdoutPromise: Promise<string>, stderrPromise: Promise<string>): Promise<[string, string]> => {
	const result = await Promise.race([Promise.all([stdoutPromise, stderrPromise]), Bun.sleep(2_000).then(() => null)]);
	if (!result) {
		return ['', 'timed out waiting for process output after shutdown'];
	}

	return result;
};

const checkHttpStart = async (script: 'start:http' | 'start:http-sse', transport: 'streamable-http' | 'http-sse') => {
	const port = await getAvailablePort();
	const child = Bun.spawn(['bun', 'run', '--cwd', packageDir, script], {
		cwd: root,
		detached: true,
		env: {
			...process.env,
			// Intentionally stdio: the package script must override this inherited value.
			SERVER_TRANSPORT: 'stdio',
			SERVER_HOST: '127.0.0.1',
			SERVER_PORT: String(port),
			SERVER_PATH: '/mcp',
			WALLET_MODE: 'disabled'
		},
		stdin: 'ignore',
		stdout: 'pipe',
		stderr: 'pipe'
	});
	const stdoutPromise = new Response(child.stdout).text();
	const stderrPromise = new Response(child.stderr).text();

	try {
		const healthy = await waitForHealth(child, port);
		await stopChild(child);
		const [stdout, stderr] = await collectProcessOutput(stdoutPromise, stderrPromise);
		if (!healthy || !stderr.includes(`MCP Server ready (${transport} transport`)) {
			throw new Error(
				`MCP HTTP startup check failed for ${script}: exit=${child.exitCode}, healthy=${healthy}, stdout=${JSON.stringify(stdout.trim())}, stderr=${JSON.stringify(
					stderr.trim()
				)}`
			);
		}
	} finally {
		await stopChild(child);
	}
};

await checkVersion(join(packageDir, 'bin/mcp-server.js'));
await checkVersion(join(packageDir, 'dist/index.js'));
const malformedPrivateKey = 'malformed-private-key-test-value';
await checkPackagedBinFailure(
	'malformed private key',
	{
		WALLET_MODE: 'private-key',
		PRIVATE_KEY: malformedPrivateKey,
		SERVER_TRANSPORT: 'stdio'
	},
	'Error starting MCP server: PRIVATE_KEY must be a valid 32-byte secp256k1 private key.',
	[malformedPrivateKey]
);
const httpWalletPrivateKey = '1'.repeat(64);
await checkPackagedBinFailure(
	'wallet over HTTP',
	{
		WALLET_MODE: 'private-key',
		PRIVATE_KEY: httpWalletPrivateKey,
		SERVER_TRANSPORT: 'http-sse',
		SERVER_HOST: '127.0.0.1',
		SERVER_PORT: String(await getAvailablePort())
	},
	'║ Wallet mode cannot be used with HTTP transports!               ║',
	[httpWalletPrivateKey],
	true,
	['Supported networks:']
);
await checkHttpStart('start:http', 'streamable-http');
await checkHttpStart('start:http-sse', 'http-sse');

console.log(`MCP CLI and HTTP startup OK: ${packageJson.version}`);
