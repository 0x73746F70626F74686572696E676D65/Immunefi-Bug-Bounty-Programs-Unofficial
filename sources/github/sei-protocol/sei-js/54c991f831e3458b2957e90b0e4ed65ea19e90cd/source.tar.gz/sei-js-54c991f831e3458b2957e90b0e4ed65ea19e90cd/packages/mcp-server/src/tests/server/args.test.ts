import { afterEach, beforeEach, describe, expect, it, jest, test } from 'bun:test';

// Mock dependencies
jest.mock('commander', () => ({
	Command: jest.fn()
}));

jest.mock('dotenv', () => ({
	config: jest.fn()
}));

jest.mock('../../server/package-info.js', () => ({
	getPackageInfo: jest.fn()
}));

describe('Args Module', () => {
	let parseArgs: any;
	let mockCommand: any;
	let mockDotenvConfig: jest.MockedFunction<any>;
	let mockGetPackageInfo: jest.MockedFunction<any>;
	let originalEnv: NodeJS.ProcessEnv;
	let consoleErrorSpy: jest.SpyInstance;
	let processExitSpy: jest.SpyInstance;

	beforeEach(async () => {
		jest.clearAllMocks();

		// Save original environment
		originalEnv = { ...process.env };

		// Clear environment variables
		delete process.env.SERVER_TRANSPORT;
		delete process.env.SERVER_PORT;
		delete process.env.SERVER_HOST;
		delete process.env.SERVER_PATH;
		delete process.env.SSE_MAX_SESSIONS;
		delete process.env.STREAMABLE_HTTP_MAX_REQUESTS;
		delete process.env.WALLET_MODE;
		delete process.env.PRIVATE_KEY;
		delete process.env.MAINNET_RPC_URL;
		delete process.env.TESTNET_RPC_URL;

		// Import mocked modules
		const { Command } = await import('commander');
		const { config: dotenvConfig } = await import('dotenv');
		const { getPackageInfo } = await import('../../server/package-info.js');

		mockDotenvConfig = dotenvConfig as jest.MockedFunction<any>;
		mockGetPackageInfo = getPackageInfo as jest.MockedFunction<any>;

		// Setup mock command
		mockCommand = {
			name: jest.fn().mockReturnThis(),
			description: jest.fn().mockReturnThis(),
			version: jest.fn().mockReturnThis(),
			addHelpText: jest.fn().mockReturnThis(),
			parse: jest.fn()
		};

		(Command as jest.MockedClass<any>).mockImplementation(() => mockCommand);

		// Setup mock package info
		mockGetPackageInfo.mockReturnValue({
			name: '@sei-js/mcp-server',
			description: 'MCP Server for Sei blockchain',
			version: '1.0.0'
		});

		// Spy on console.error and process.exit
		consoleErrorSpy = jest.spyOn(console, 'error').mockImplementation(() => {});
		processExitSpy = jest.spyOn(process, 'exit').mockImplementation(() => undefined as never);

		// Import the function after mocks are set up
		const argsModule = await import('../../server/args.js');
		parseArgs = argsModule.parseArgs;
	});

	afterEach(() => {
		// Restore original environment
		process.env = originalEnv;
		consoleErrorSpy.mockRestore();
		processExitSpy.mockRestore();
	});

	describe('getEnvValue (helper)', () => {
		it('should return environment variable value when set', () => {
			process.env.TEST_VAR = 'test-value';

			const result = parseArgs();

			// Indirectly test getEnvValue through parseArgs behavior
			expect(mockDotenvConfig).toHaveBeenCalled();
		});

		it('should return default value when environment variable not set', () => {
			// Test through loadConfig defaults
			const result = parseArgs();

			expect(result.mode).toBe('stdio'); // Default transport
			expect(result.port).toBe(8080); // Default port
			expect(result.host).toBe('localhost'); // Default host
			expect(result.path).toBe('/mcp'); // Default path
		});
	});

	describe('loadConfig', () => {
		it('should load default configuration when no environment variables set', () => {
			const result = parseArgs();

			expect(result).toEqual({
				mode: 'stdio',
				port: 8080,
				host: 'localhost',
				path: '/mcp',
				appConfig: {
					privateKey: undefined,
					walletMode: 'disabled',
					walletApiKey: undefined
				},
				maxSseSessions: 100,
				maxStreamableRequests: 100
			});
			expect(Object.isFrozen(result.appConfig)).toBe(true);
		});

		it('should load configuration from environment variables', () => {
			process.env.SERVER_TRANSPORT = 'http-sse';
			process.env.SERVER_PORT = '3001';
			process.env.SERVER_HOST = '0.0.0.0';
			process.env.SERVER_PATH = '/api/mcp';
			process.env.WALLET_MODE = 'private-key';
			process.env.PRIVATE_KEY = '1'.repeat(64);

			const result = parseArgs();

			expect(result).toEqual({
				mode: 'http-sse',
				port: 3001,
				host: '0.0.0.0',
				path: '/api/mcp',
				appConfig: {
					privateKey: `0x${'1'.repeat(64)}`,
					walletMode: 'private-key',
					walletApiKey: undefined
				},
				maxSseSessions: 100,
				maxStreamableRequests: 100
			});
		});

		it('should normalize path to start with forward slash', () => {
			process.env.SERVER_PATH = 'api/mcp';

			const result = parseArgs();

			expect(result.path).toBe('/api/mcp');
		});

		it('should keep path unchanged if it already starts with forward slash', () => {
			process.env.SERVER_PATH = '/already/normalized';

			const result = parseArgs();

			expect(result.path).toBe('/already/normalized');
		});

		it('should handle invalid port numbers by using default', () => {
			process.env.SERVER_PORT = 'invalid-port';

			const result = parseArgs();

			expect(result.port).toBe(8080); // Should fallback to default
		});

		it('should reject invalid nonblank ports for HTTP transports', () => {
			process.env.SERVER_TRANSPORT = 'streamable-http';
			process.env.SERVER_PORT = 'invalid-port';
			expect(() => parseArgs()).toThrow("Invalid port 'NaN'");

			process.env.SERVER_PORT = '-1';
			expect(() => parseArgs()).toThrow("Invalid port '-1'");
			process.env.SERVER_PORT = '3000.5';
			expect(() => parseArgs()).toThrow("Invalid port '3000.5'");
		});

		it('should call dotenv config to load .env file', () => {
			parseArgs();

			expect(mockDotenvConfig).toHaveBeenCalled();
		});

		it('loads and validates the legacy SSE session limit', () => {
			process.env.SERVER_TRANSPORT = 'http-sse';
			process.env.SSE_MAX_SESSIONS = '12';
			expect(parseArgs().maxSseSessions).toBe(12);

			process.env.SSE_MAX_SESSIONS = '0';
			expect(() => parseArgs()).toThrow("Invalid SSE_MAX_SESSIONS '0'");

			process.env.SSE_MAX_SESSIONS = '1.5';
			expect(() => parseArgs()).toThrow("Invalid SSE_MAX_SESSIONS '1.5'");

			process.env.SSE_MAX_SESSIONS = 'not-a-number';
			expect(() => parseArgs()).toThrow("Invalid SSE_MAX_SESSIONS 'NaN'");
		});

		it('loads and validates the Streamable HTTP request limit', () => {
			process.env.SERVER_TRANSPORT = 'streamable-http';
			process.env.STREAMABLE_HTTP_MAX_REQUESTS = '12';
			expect(parseArgs().maxStreamableRequests).toBe(12);

			process.env.STREAMABLE_HTTP_MAX_REQUESTS = '0';
			expect(() => parseArgs()).toThrow("Invalid STREAMABLE_HTTP_MAX_REQUESTS '0'");

			process.env.STREAMABLE_HTTP_MAX_REQUESTS = 'not-a-number';
			expect(() => parseArgs()).toThrow("Invalid STREAMABLE_HTTP_MAX_REQUESTS 'NaN'");
		});

		it('ignores invalid HTTP-only settings for stdio', () => {
			process.env.SERVER_TRANSPORT = 'stdio';
			process.env.SERVER_PORT = 'not-a-port';
			process.env.SSE_MAX_SESSIONS = 'not-a-limit';
			process.env.STREAMABLE_HTTP_MAX_REQUESTS = 'also-not-a-limit';

			expect(parseArgs()).toMatchObject({
				port: 8080,
				maxSseSessions: 100,
				maxStreamableRequests: 100
			});
		});

		it('should handle all RPC URL environment variables', () => {
			process.env.MAINNET_RPC_URL = 'https://mainnet.example.com';
			process.env.TESTNET_RPC_URL = 'https://testnet.example.com';

			// RPC URLs are loaded but not returned in the final config
			// This tests that they don't cause errors
			expect(() => parseArgs()).not.toThrow();
		});
	});

	describe('validateConfig', () => {
		it('should pass validation with valid configuration', () => {
			process.env.SERVER_TRANSPORT = 'stdio';
			process.env.WALLET_MODE = 'disabled';
			process.env.SERVER_PORT = '8080';

			expect(() => parseArgs()).not.toThrow();
			expect(processExitSpy).not.toHaveBeenCalled();
		});

		it('should throw for invalid wallet mode', () => {
			process.env.WALLET_MODE = 'invalid-mode';

			expect(() => parseArgs()).toThrow("Invalid wallet mode 'invalid-mode'. Valid modes are: private-key, disabled");
			expect(processExitSpy).not.toHaveBeenCalled();
		});

		it('should throw for invalid transport mode', () => {
			process.env.SERVER_TRANSPORT = 'invalid-transport';

			expect(() => parseArgs()).toThrow("Invalid transport mode 'invalid-transport'. Valid modes are: stdio, streamable-http, http-sse");
			expect(processExitSpy).not.toHaveBeenCalled();
		});

		it('should throw for port below valid range', () => {
			process.env.SERVER_TRANSPORT = 'http-sse';
			process.env.SERVER_PORT = '0';

			expect(() => parseArgs()).toThrow("Invalid port '0'. Port must be a number between 1 and 65535.");
			expect(processExitSpy).not.toHaveBeenCalled();
		});

		it('should throw for port above valid range', () => {
			process.env.SERVER_TRANSPORT = 'streamable-http';
			process.env.SERVER_PORT = '65536';

			expect(() => parseArgs()).toThrow("Invalid port '65536'. Port must be a number between 1 and 65535.");
			expect(processExitSpy).not.toHaveBeenCalled();
		});

		it('should accept minimum valid port', () => {
			process.env.SERVER_PORT = '1';

			expect(() => parseArgs()).not.toThrow();
			expect(processExitSpy).not.toHaveBeenCalled();
		});

		it('should accept maximum valid port', () => {
			process.env.SERVER_PORT = '65535';

			expect(() => parseArgs()).not.toThrow();
			expect(processExitSpy).not.toHaveBeenCalled();
		});

		it('should validate all transport modes', () => {
			const validModes = ['stdio', 'streamable-http', 'http-sse'];

			for (const mode of validModes) {
				jest.clearAllMocks();
				process.env.SERVER_TRANSPORT = mode;

				expect(() => parseArgs()).not.toThrow();
				expect(processExitSpy).not.toHaveBeenCalled();
			}
		});

		it('should validate all wallet modes', () => {
			const validModes = ['private-key', 'disabled'];

			for (const mode of validModes) {
				jest.clearAllMocks();
				process.env.WALLET_MODE = mode;
				process.env.PRIVATE_KEY = mode === 'private-key' ? '1'.repeat(64) : undefined;

				expect(() => parseArgs()).not.toThrow();
				expect(processExitSpy).not.toHaveBeenCalled();
			}
		});

		it('requires PRIVATE_KEY in private-key wallet mode', () => {
			process.env.WALLET_MODE = 'private-key';
			delete process.env.PRIVATE_KEY;
			expect(() => parseArgs()).toThrow('PRIVATE_KEY is required when WALLET_MODE=private-key');
		});

		it('rejects an invalid PRIVATE_KEY without including it in the error', () => {
			process.env.WALLET_MODE = 'private-key';
			process.env.PRIVATE_KEY = 'clearly-invalid-test-value';
			expect(() => parseArgs()).toThrow('PRIVATE_KEY must be a valid 32-byte secp256k1 private key');
			try {
				parseArgs();
			} catch (error) {
				expect(String(error)).not.toContain(process.env.PRIVATE_KEY);
			}
		});
	});

	describe('parseArgs', () => {
		it('should setup commander with package info', () => {
			parseArgs();

			expect(mockCommand.name).toHaveBeenCalledWith('@sei-js/mcp-server');
			expect(mockCommand.description).toHaveBeenCalledWith('MCP Server for Sei blockchain');
			expect(mockCommand.version).toHaveBeenCalledWith('1.0.0');
		});

		it('should add help text with examples and environment variables', () => {
			parseArgs();

			expect(mockCommand.addHelpText).toHaveBeenCalledWith('after', expect.stringContaining('Examples:'));
			expect(mockCommand.addHelpText).toHaveBeenCalledWith('after', expect.stringContaining('Environment Variables:'));
			expect(mockCommand.addHelpText).toHaveBeenCalledWith('after', expect.stringContaining('@sei-js/mcp-server'));
		});

		it('should call commander parse method', () => {
			parseArgs();

			expect(mockCommand.parse).toHaveBeenCalled();
		});

		it('should return TransportConfig interface', () => {
			const result = parseArgs();

			expect(result).toHaveProperty('mode');
			expect(result).toHaveProperty('port');
			expect(result).toHaveProperty('host');
			expect(result).toHaveProperty('path');
			expect(result).toHaveProperty('appConfig');

			// Verify types
			expect(typeof result.mode).toBe('string');
			expect(typeof result.port).toBe('number');
			expect(typeof result.host).toBe('string');
			expect(typeof result.path).toBe('string');
			expect(typeof result.appConfig.walletMode).toBe('string');
		});

		it('should handle getPackageInfo errors gracefully', () => {
			mockGetPackageInfo.mockImplementation(() => {
				throw new Error('Package info error');
			});

			expect(() => parseArgs()).toThrow('Package info error');
		});

		it('should integrate all functions in correct order', () => {
			process.env.SERVER_TRANSPORT = 'streamable-http';
			process.env.SERVER_PORT = '9000';
			process.env.WALLET_MODE = 'private-key';
			process.env.PRIVATE_KEY = '1'.repeat(64);

			const result = parseArgs();

			// Verify dotenv was called (loadConfig)
			expect(mockDotenvConfig).toHaveBeenCalled();

			// Verify commander was setup (parseArgs)
			expect(mockCommand.parse).toHaveBeenCalled();

			// Verify validation passed (validateConfig)
			expect(processExitSpy).not.toHaveBeenCalled();

			// Verify final result
			expect(result).toEqual({
				mode: 'streamable-http',
				port: 9000,
				host: 'localhost',
				path: '/mcp',
				appConfig: {
					privateKey: `0x${'1'.repeat(64)}`,
					walletMode: 'private-key',
					walletApiKey: undefined
				},
				maxSseSessions: 100,
				maxStreamableRequests: 100
			});
		});
	});

	describe('edge cases and error scenarios', () => {
		it('treats blank optional HTTP and stdio values as defaults', () => {
			process.env.SERVER_HOST = '';
			process.env.SERVER_PATH = '';
			process.env.SERVER_PORT = '';
			process.env.SSE_MAX_SESSIONS = '';
			process.env.STREAMABLE_HTTP_MAX_REQUESTS = '';

			expect(parseArgs()).toMatchObject({
				mode: 'stdio',
				host: 'localhost',
				path: '/mcp',
				port: 8080,
				maxSseSessions: 100,
				maxStreamableRequests: 100
			});

			process.env.SERVER_TRANSPORT = 'http-sse';
			expect(parseArgs()).toMatchObject({ host: 'localhost', port: 8080, maxSseSessions: 100 });
		});

		it('should handle whitespace in environment variables', () => {
			process.env.SERVER_HOST = '  localhost  ';
			process.env.SERVER_PATH = '  /api/mcp  ';

			const result = parseArgs();

			expect(result.host).toBe('  localhost  '); // Whitespace preserved
			expect(result.path).toBe('/  /api/mcp  '); // Path normalization adds / prefix
		});

		it('should handle special characters in paths', () => {
			process.env.SERVER_PATH = '/api/mcp-v1.0_test@special';

			const result = parseArgs();

			expect(result.path).toBe('/api/mcp-v1.0_test@special');
		});

		it('should report the first of multiple validation errors', () => {
			process.env.WALLET_MODE = 'invalid';
			process.env.SERVER_TRANSPORT = 'also-invalid';
			process.env.SERVER_PORT = '0';

			expect(() => parseArgs()).toThrow("Invalid wallet mode 'invalid'");
			expect(processExitSpy).not.toHaveBeenCalled();
		});

		it('should handle process.env being undefined for specific keys', () => {
			// Explicitly set to undefined
			process.env.SERVER_PORT = undefined;
			process.env.SERVER_HOST = undefined;

			const result = parseArgs();

			expect(result.port).toBe(8080); // Should use default
			expect(result.host).toBe('localhost'); // Should use default
		});
	});
});
