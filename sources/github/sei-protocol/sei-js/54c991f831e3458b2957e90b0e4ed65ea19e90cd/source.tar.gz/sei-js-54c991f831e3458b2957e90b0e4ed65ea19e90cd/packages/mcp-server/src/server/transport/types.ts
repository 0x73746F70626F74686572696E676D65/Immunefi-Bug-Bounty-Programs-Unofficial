import type { McpServer } from '@modelcontextprotocol/sdk/server/mcp.js';
import type { AppConfigSnapshot, WalletMode } from '../../core/config.js';

export type TransportMode = 'stdio' | 'streamable-http' | 'http-sse';

export interface McpTransport {
	start(server?: McpServer): Promise<void>;
	stop(): Promise<void>;
	readonly mode: TransportMode;
}

export interface TransportConfig {
	mode: TransportMode;
	appConfig: AppConfigSnapshot;
	port: number; // Required for HTTP-based transports
	host: string; // Required for HTTP-based transports
	path: string; // Required for HTTP-based transports
	maxSseSessions?: number; // Applied only to the legacy SSE transport
	maxStreamableRequests?: number; // Applied only to Streamable HTTP
}

// Re-export WalletMode for convenience
export type { WalletMode };
