import type { Abi } from 'viem';

/**
 * The address of the Staking precompile contract.
 * @category Address
 */
export const STAKING_PRECOMPILE_ADDRESS: `0x${string}` = '0x0000000000000000000000000000000000001005';

/**
 * The ABI for the Staking precompile contract.
 * Synced from the frozen Sei Chain v6.6.1 precompile snapshot.
 * @see https://github.com/sei-protocol/sei-chain/blob/v6.6.1/precompiles/staking/legacy/v66/abi.json
 * @category ABI
 */
export const STAKING_PRECOMPILE_ABI = [
	{
		anonymous: false,
		inputs: [
			{ indexed: true, internalType: 'address', name: 'delegator', type: 'address' },
			{ indexed: false, internalType: 'string', name: 'validator', type: 'string' },
			{ indexed: false, internalType: 'uint256', name: 'amount', type: 'uint256' }
		],
		name: 'Delegate',
		type: 'event'
	},
	{
		anonymous: false,
		inputs: [
			{ indexed: true, internalType: 'address', name: 'delegator', type: 'address' },
			{ indexed: false, internalType: 'string', name: 'validator', type: 'string' },
			{ indexed: false, internalType: 'uint256', name: 'amount', type: 'uint256' }
		],
		name: 'DelegationRewardsWithdrawn',
		type: 'event'
	},
	{
		anonymous: false,
		inputs: [
			{ indexed: true, internalType: 'address', name: 'delegator', type: 'address' },
			{ indexed: false, internalType: 'string', name: 'srcValidator', type: 'string' },
			{ indexed: false, internalType: 'string', name: 'dstValidator', type: 'string' },
			{ indexed: false, internalType: 'uint256', name: 'amount', type: 'uint256' }
		],
		name: 'Redelegate',
		type: 'event'
	},
	{
		anonymous: false,
		inputs: [
			{ indexed: true, internalType: 'address', name: 'delegator', type: 'address' },
			{ indexed: false, internalType: 'string', name: 'validator', type: 'string' },
			{ indexed: false, internalType: 'uint256', name: 'amount', type: 'uint256' }
		],
		name: 'Undelegate',
		type: 'event'
	},
	{
		anonymous: false,
		inputs: [
			{ indexed: true, internalType: 'address', name: 'creator', type: 'address' },
			{ indexed: false, internalType: 'string', name: 'validatorAddress', type: 'string' },
			{ indexed: false, internalType: 'string', name: 'moniker', type: 'string' }
		],
		name: 'ValidatorCreated',
		type: 'event'
	},
	{
		anonymous: false,
		inputs: [
			{ indexed: true, internalType: 'address', name: 'editor', type: 'address' },
			{ indexed: false, internalType: 'string', name: 'validatorAddress', type: 'string' },
			{ indexed: false, internalType: 'string', name: 'moniker', type: 'string' }
		],
		name: 'ValidatorEdited',
		type: 'event'
	},
	{
		inputs: [
			{ internalType: 'string', name: 'pubKeyHex', type: 'string' },
			{ internalType: 'string', name: 'moniker', type: 'string' },
			{ internalType: 'string', name: 'commissionRate', type: 'string' },
			{ internalType: 'string', name: 'commissionMaxRate', type: 'string' },
			{ internalType: 'string', name: 'commissionMaxChangeRate', type: 'string' },
			{ internalType: 'uint256', name: 'minSelfDelegation', type: 'uint256' }
		],
		name: 'createValidator',
		outputs: [{ internalType: 'bool', name: 'success', type: 'bool' }],
		stateMutability: 'payable',
		type: 'function'
	},
	{
		inputs: [{ internalType: 'string', name: 'valAddress', type: 'string' }],
		name: 'delegate',
		outputs: [{ internalType: 'bool', name: 'success', type: 'bool' }],
		stateMutability: 'payable',
		type: 'function'
	},
	{
		inputs: [
			{ internalType: 'address', name: 'delegator', type: 'address' },
			{ internalType: 'string', name: 'valAddress', type: 'string' }
		],
		name: 'delegation',
		outputs: [
			{
				components: [
					{
						components: [
							{ internalType: 'uint256', name: 'amount', type: 'uint256' },
							{ internalType: 'string', name: 'denom', type: 'string' }
						],
						internalType: 'struct IStaking.Balance',
						name: 'balance',
						type: 'tuple'
					},
					{
						components: [
							{ internalType: 'string', name: 'delegator_address', type: 'string' },
							{ internalType: 'uint256', name: 'shares', type: 'uint256' },
							{ internalType: 'uint256', name: 'decimals', type: 'uint256' },
							{ internalType: 'string', name: 'validator_address', type: 'string' }
						],
						internalType: 'struct IStaking.DelegationDetails',
						name: 'delegation',
						type: 'tuple'
					}
				],
				internalType: 'struct IStaking.Delegation',
				name: 'delegation',
				type: 'tuple'
			}
		],
		stateMutability: 'view',
		type: 'function'
	},
	{
		inputs: [
			{ internalType: 'address', name: 'delegator', type: 'address' },
			{ internalType: 'bytes', name: 'nextKey', type: 'bytes' }
		],
		name: 'delegatorDelegations',
		outputs: [
			{
				components: [
					{
						components: [
							{
								components: [
									{ internalType: 'uint256', name: 'amount', type: 'uint256' },
									{ internalType: 'string', name: 'denom', type: 'string' }
								],
								internalType: 'struct IStaking.Balance',
								name: 'balance',
								type: 'tuple'
							},
							{
								components: [
									{ internalType: 'string', name: 'delegator_address', type: 'string' },
									{ internalType: 'uint256', name: 'shares', type: 'uint256' },
									{ internalType: 'uint256', name: 'decimals', type: 'uint256' },
									{ internalType: 'string', name: 'validator_address', type: 'string' }
								],
								internalType: 'struct IStaking.DelegationDetails',
								name: 'delegation',
								type: 'tuple'
							}
						],
						internalType: 'struct IStaking.Delegation[]',
						name: 'delegations',
						type: 'tuple[]'
					},
					{ internalType: 'bytes', name: 'nextKey', type: 'bytes' }
				],
				internalType: 'struct IStaking.DelegationsResponse',
				name: 'response',
				type: 'tuple'
			}
		],
		stateMutability: 'view',
		type: 'function'
	},
	{
		inputs: [
			{ internalType: 'address', name: 'delegator', type: 'address' },
			{ internalType: 'bytes', name: 'nextKey', type: 'bytes' }
		],
		name: 'delegatorUnbondingDelegations',
		outputs: [
			{
				components: [
					{
						components: [
							{ internalType: 'string', name: 'delegatorAddress', type: 'string' },
							{ internalType: 'string', name: 'validatorAddress', type: 'string' },
							{
								components: [
									{ internalType: 'int64', name: 'creationHeight', type: 'int64' },
									{ internalType: 'int64', name: 'completionTime', type: 'int64' },
									{ internalType: 'string', name: 'initialBalance', type: 'string' },
									{ internalType: 'string', name: 'balance', type: 'string' }
								],
								internalType: 'struct IStaking.UnbondingDelegationEntry[]',
								name: 'entries',
								type: 'tuple[]'
							}
						],
						internalType: 'struct IStaking.UnbondingDelegation[]',
						name: 'unbondingDelegations',
						type: 'tuple[]'
					},
					{ internalType: 'bytes', name: 'nextKey', type: 'bytes' }
				],
				internalType: 'struct IStaking.UnbondingDelegationsResponse',
				name: 'response',
				type: 'tuple'
			}
		],
		stateMutability: 'view',
		type: 'function'
	},
	{
		inputs: [
			{ internalType: 'address', name: 'delegator', type: 'address' },
			{ internalType: 'string', name: 'validatorAddress', type: 'string' }
		],
		name: 'delegatorValidator',
		outputs: [
			{
				components: [
					{ internalType: 'string', name: 'operatorAddress', type: 'string' },
					{ internalType: 'bytes', name: 'consensusPubkey', type: 'bytes' },
					{ internalType: 'bool', name: 'jailed', type: 'bool' },
					{ internalType: 'int32', name: 'status', type: 'int32' },
					{ internalType: 'string', name: 'tokens', type: 'string' },
					{ internalType: 'string', name: 'delegatorShares', type: 'string' },
					{ internalType: 'string', name: 'description', type: 'string' },
					{ internalType: 'int64', name: 'unbondingHeight', type: 'int64' },
					{ internalType: 'int64', name: 'unbondingTime', type: 'int64' },
					{ internalType: 'string', name: 'commissionRate', type: 'string' },
					{ internalType: 'string', name: 'commissionMaxRate', type: 'string' },
					{ internalType: 'string', name: 'commissionMaxChangeRate', type: 'string' },
					{ internalType: 'int64', name: 'commissionUpdateTime', type: 'int64' },
					{ internalType: 'string', name: 'minSelfDelegation', type: 'string' }
				],
				internalType: 'struct IStaking.Validator',
				name: 'validator',
				type: 'tuple'
			}
		],
		stateMutability: 'view',
		type: 'function'
	},
	{
		inputs: [
			{ internalType: 'address', name: 'delegator', type: 'address' },
			{ internalType: 'bytes', name: 'nextKey', type: 'bytes' }
		],
		name: 'delegatorValidators',
		outputs: [
			{
				components: [
					{
						components: [
							{ internalType: 'string', name: 'operatorAddress', type: 'string' },
							{ internalType: 'bytes', name: 'consensusPubkey', type: 'bytes' },
							{ internalType: 'bool', name: 'jailed', type: 'bool' },
							{ internalType: 'int32', name: 'status', type: 'int32' },
							{ internalType: 'string', name: 'tokens', type: 'string' },
							{ internalType: 'string', name: 'delegatorShares', type: 'string' },
							{ internalType: 'string', name: 'description', type: 'string' },
							{ internalType: 'int64', name: 'unbondingHeight', type: 'int64' },
							{ internalType: 'int64', name: 'unbondingTime', type: 'int64' },
							{ internalType: 'string', name: 'commissionRate', type: 'string' },
							{ internalType: 'string', name: 'commissionMaxRate', type: 'string' },
							{ internalType: 'string', name: 'commissionMaxChangeRate', type: 'string' },
							{ internalType: 'int64', name: 'commissionUpdateTime', type: 'int64' },
							{ internalType: 'string', name: 'minSelfDelegation', type: 'string' }
						],
						internalType: 'struct IStaking.Validator[]',
						name: 'validators',
						type: 'tuple[]'
					},
					{ internalType: 'bytes', name: 'nextKey', type: 'bytes' }
				],
				internalType: 'struct IStaking.ValidatorsResponse',
				name: 'response',
				type: 'tuple'
			}
		],
		stateMutability: 'view',
		type: 'function'
	},
	{
		inputs: [
			{ internalType: 'string', name: 'moniker', type: 'string' },
			{ internalType: 'string', name: 'commissionRate', type: 'string' },
			{ internalType: 'uint256', name: 'minSelfDelegation', type: 'uint256' }
		],
		name: 'editValidator',
		outputs: [{ internalType: 'bool', name: 'success', type: 'bool' }],
		stateMutability: 'nonpayable',
		type: 'function'
	},
	{
		inputs: [{ internalType: 'int64', name: 'height', type: 'int64' }],
		name: 'historicalInfo',
		outputs: [
			{
				components: [
					{ internalType: 'int64', name: 'height', type: 'int64' },
					{
						components: [
							{ internalType: 'string', name: 'operatorAddress', type: 'string' },
							{ internalType: 'bytes', name: 'consensusPubkey', type: 'bytes' },
							{ internalType: 'bool', name: 'jailed', type: 'bool' },
							{ internalType: 'int32', name: 'status', type: 'int32' },
							{ internalType: 'string', name: 'tokens', type: 'string' },
							{ internalType: 'string', name: 'delegatorShares', type: 'string' },
							{ internalType: 'string', name: 'description', type: 'string' },
							{ internalType: 'int64', name: 'unbondingHeight', type: 'int64' },
							{ internalType: 'int64', name: 'unbondingTime', type: 'int64' },
							{ internalType: 'string', name: 'commissionRate', type: 'string' },
							{ internalType: 'string', name: 'commissionMaxRate', type: 'string' },
							{ internalType: 'string', name: 'commissionMaxChangeRate', type: 'string' },
							{ internalType: 'int64', name: 'commissionUpdateTime', type: 'int64' },
							{ internalType: 'string', name: 'minSelfDelegation', type: 'string' }
						],
						internalType: 'struct IStaking.Validator[]',
						name: 'validators',
						type: 'tuple[]'
					}
				],
				internalType: 'struct IStaking.HistoricalInfo',
				name: 'historicalInfo',
				type: 'tuple'
			}
		],
		stateMutability: 'view',
		type: 'function'
	},
	{
		inputs: [],
		name: 'params',
		outputs: [
			{
				components: [
					{ internalType: 'uint64', name: 'unbondingTime', type: 'uint64' },
					{ internalType: 'uint32', name: 'maxValidators', type: 'uint32' },
					{ internalType: 'uint32', name: 'maxEntries', type: 'uint32' },
					{ internalType: 'uint32', name: 'historicalEntries', type: 'uint32' },
					{ internalType: 'string', name: 'bondDenom', type: 'string' },
					{ internalType: 'string', name: 'minCommissionRate', type: 'string' },
					{ internalType: 'string', name: 'maxVotingPowerRatio', type: 'string' },
					{ internalType: 'string', name: 'maxVotingPowerEnforcementThreshold', type: 'string' }
				],
				internalType: 'struct IStaking.Params',
				name: 'params',
				type: 'tuple'
			}
		],
		stateMutability: 'view',
		type: 'function'
	},
	{
		inputs: [],
		name: 'pool',
		outputs: [
			{
				components: [
					{ internalType: 'string', name: 'notBondedTokens', type: 'string' },
					{ internalType: 'string', name: 'bondedTokens', type: 'string' }
				],
				internalType: 'struct IStaking.Pool',
				name: 'pool',
				type: 'tuple'
			}
		],
		stateMutability: 'view',
		type: 'function'
	},
	{
		inputs: [
			{ internalType: 'string', name: 'srcAddress', type: 'string' },
			{ internalType: 'string', name: 'dstAddress', type: 'string' },
			{ internalType: 'uint256', name: 'amount', type: 'uint256' }
		],
		name: 'redelegate',
		outputs: [{ internalType: 'bool', name: 'success', type: 'bool' }],
		stateMutability: 'nonpayable',
		type: 'function'
	},
	{
		inputs: [
			{ internalType: 'string', name: 'delegator', type: 'string' },
			{ internalType: 'string', name: 'srcValidator', type: 'string' },
			{ internalType: 'string', name: 'dstValidator', type: 'string' },
			{ internalType: 'bytes', name: 'nextKey', type: 'bytes' }
		],
		name: 'redelegations',
		outputs: [
			{
				components: [
					{
						components: [
							{ internalType: 'string', name: 'delegatorAddress', type: 'string' },
							{ internalType: 'string', name: 'validatorSrcAddress', type: 'string' },
							{ internalType: 'string', name: 'validatorDstAddress', type: 'string' },
							{
								components: [
									{ internalType: 'int64', name: 'creationHeight', type: 'int64' },
									{ internalType: 'int64', name: 'completionTime', type: 'int64' },
									{ internalType: 'string', name: 'initialBalance', type: 'string' },
									{ internalType: 'string', name: 'sharesDst', type: 'string' }
								],
								internalType: 'struct IStaking.RedelegationEntry[]',
								name: 'entries',
								type: 'tuple[]'
							}
						],
						internalType: 'struct IStaking.Redelegation[]',
						name: 'redelegations',
						type: 'tuple[]'
					},
					{ internalType: 'bytes', name: 'nextKey', type: 'bytes' }
				],
				internalType: 'struct IStaking.RedelegationsResponse',
				name: 'response',
				type: 'tuple'
			}
		],
		stateMutability: 'view',
		type: 'function'
	},
	{
		inputs: [
			{ internalType: 'address', name: 'delegator', type: 'address' },
			{ internalType: 'string', name: 'validatorAddress', type: 'string' }
		],
		name: 'unbondingDelegation',
		outputs: [
			{
				components: [
					{ internalType: 'string', name: 'delegatorAddress', type: 'string' },
					{ internalType: 'string', name: 'validatorAddress', type: 'string' },
					{
						components: [
							{ internalType: 'int64', name: 'creationHeight', type: 'int64' },
							{ internalType: 'int64', name: 'completionTime', type: 'int64' },
							{ internalType: 'string', name: 'initialBalance', type: 'string' },
							{ internalType: 'string', name: 'balance', type: 'string' }
						],
						internalType: 'struct IStaking.UnbondingDelegationEntry[]',
						name: 'entries',
						type: 'tuple[]'
					}
				],
				internalType: 'struct IStaking.UnbondingDelegation',
				name: 'unbondingDelegation',
				type: 'tuple'
			}
		],
		stateMutability: 'view',
		type: 'function'
	},
	{
		inputs: [
			{ internalType: 'string', name: 'valAddress', type: 'string' },
			{ internalType: 'uint256', name: 'amount', type: 'uint256' }
		],
		name: 'undelegate',
		outputs: [{ internalType: 'bool', name: 'success', type: 'bool' }],
		stateMutability: 'nonpayable',
		type: 'function'
	},
	{
		inputs: [{ internalType: 'string', name: 'validatorAddress', type: 'string' }],
		name: 'validator',
		outputs: [
			{
				components: [
					{ internalType: 'string', name: 'operatorAddress', type: 'string' },
					{ internalType: 'bytes', name: 'consensusPubkey', type: 'bytes' },
					{ internalType: 'bool', name: 'jailed', type: 'bool' },
					{ internalType: 'int32', name: 'status', type: 'int32' },
					{ internalType: 'string', name: 'tokens', type: 'string' },
					{ internalType: 'string', name: 'delegatorShares', type: 'string' },
					{ internalType: 'string', name: 'description', type: 'string' },
					{ internalType: 'int64', name: 'unbondingHeight', type: 'int64' },
					{ internalType: 'int64', name: 'unbondingTime', type: 'int64' },
					{ internalType: 'string', name: 'commissionRate', type: 'string' },
					{ internalType: 'string', name: 'commissionMaxRate', type: 'string' },
					{ internalType: 'string', name: 'commissionMaxChangeRate', type: 'string' },
					{ internalType: 'int64', name: 'commissionUpdateTime', type: 'int64' },
					{ internalType: 'string', name: 'minSelfDelegation', type: 'string' }
				],
				internalType: 'struct IStaking.Validator',
				name: 'validator',
				type: 'tuple'
			}
		],
		stateMutability: 'view',
		type: 'function'
	},
	{
		inputs: [
			{ internalType: 'string', name: 'validatorAddress', type: 'string' },
			{ internalType: 'bytes', name: 'nextKey', type: 'bytes' }
		],
		name: 'validatorDelegations',
		outputs: [
			{
				components: [
					{
						components: [
							{
								components: [
									{ internalType: 'uint256', name: 'amount', type: 'uint256' },
									{ internalType: 'string', name: 'denom', type: 'string' }
								],
								internalType: 'struct IStaking.Balance',
								name: 'balance',
								type: 'tuple'
							},
							{
								components: [
									{ internalType: 'string', name: 'delegator_address', type: 'string' },
									{ internalType: 'uint256', name: 'shares', type: 'uint256' },
									{ internalType: 'uint256', name: 'decimals', type: 'uint256' },
									{ internalType: 'string', name: 'validator_address', type: 'string' }
								],
								internalType: 'struct IStaking.DelegationDetails',
								name: 'delegation',
								type: 'tuple'
							}
						],
						internalType: 'struct IStaking.Delegation[]',
						name: 'delegations',
						type: 'tuple[]'
					},
					{ internalType: 'bytes', name: 'nextKey', type: 'bytes' }
				],
				internalType: 'struct IStaking.DelegationsResponse',
				name: 'response',
				type: 'tuple'
			}
		],
		stateMutability: 'view',
		type: 'function'
	},
	{
		inputs: [
			{ internalType: 'string', name: 'validatorAddress', type: 'string' },
			{ internalType: 'bytes', name: 'nextKey', type: 'bytes' }
		],
		name: 'validatorUnbondingDelegations',
		outputs: [
			{
				components: [
					{
						components: [
							{ internalType: 'string', name: 'delegatorAddress', type: 'string' },
							{ internalType: 'string', name: 'validatorAddress', type: 'string' },
							{
								components: [
									{ internalType: 'int64', name: 'creationHeight', type: 'int64' },
									{ internalType: 'int64', name: 'completionTime', type: 'int64' },
									{ internalType: 'string', name: 'initialBalance', type: 'string' },
									{ internalType: 'string', name: 'balance', type: 'string' }
								],
								internalType: 'struct IStaking.UnbondingDelegationEntry[]',
								name: 'entries',
								type: 'tuple[]'
							}
						],
						internalType: 'struct IStaking.UnbondingDelegation[]',
						name: 'unbondingDelegations',
						type: 'tuple[]'
					},
					{ internalType: 'bytes', name: 'nextKey', type: 'bytes' }
				],
				internalType: 'struct IStaking.UnbondingDelegationsResponse',
				name: 'response',
				type: 'tuple'
			}
		],
		stateMutability: 'view',
		type: 'function'
	},
	{
		inputs: [
			{ internalType: 'string', name: 'status', type: 'string' },
			{ internalType: 'bytes', name: 'nextKey', type: 'bytes' }
		],
		name: 'validators',
		outputs: [
			{
				components: [
					{
						components: [
							{ internalType: 'string', name: 'operatorAddress', type: 'string' },
							{ internalType: 'bytes', name: 'consensusPubkey', type: 'bytes' },
							{ internalType: 'bool', name: 'jailed', type: 'bool' },
							{ internalType: 'int32', name: 'status', type: 'int32' },
							{ internalType: 'string', name: 'tokens', type: 'string' },
							{ internalType: 'string', name: 'delegatorShares', type: 'string' },
							{ internalType: 'string', name: 'description', type: 'string' },
							{ internalType: 'int64', name: 'unbondingHeight', type: 'int64' },
							{ internalType: 'int64', name: 'unbondingTime', type: 'int64' },
							{ internalType: 'string', name: 'commissionRate', type: 'string' },
							{ internalType: 'string', name: 'commissionMaxRate', type: 'string' },
							{ internalType: 'string', name: 'commissionMaxChangeRate', type: 'string' },
							{ internalType: 'int64', name: 'commissionUpdateTime', type: 'int64' },
							{ internalType: 'string', name: 'minSelfDelegation', type: 'string' }
						],
						internalType: 'struct IStaking.Validator[]',
						name: 'validators',
						type: 'tuple[]'
					},
					{ internalType: 'bytes', name: 'nextKey', type: 'bytes' }
				],
				internalType: 'struct IStaking.ValidatorsResponse',
				name: 'response',
				type: 'tuple'
			}
		],
		stateMutability: 'view',
		type: 'function'
	}
] as const satisfies Abi;
