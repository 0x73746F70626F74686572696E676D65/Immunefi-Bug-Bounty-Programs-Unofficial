const fs = require('node:fs').promises;
const path = require('node:path');
const { JSDOM } = require('jsdom');

// Configuration for parallel processing
const CONCURRENCY_LIMIT = 20; // Number of files to process simultaneously

const SEI_LLMS_CONFIG = {
	projectName: 'Sei Documentation',
	blockquote:
		'Technical documentation for Sei, the fastest EVM blockchain. Covers smart contract development (Hardhat, Foundry), frontend integration (wagmi, ethers.js), AI tooling (MCP Server, Cambrian Agent Kit), x402 micropayments, node operations, and the Sei Giga upgrade roadmap.',
	intro:
		'Sei is a parallelized EVM Layer 1 blockchain with 400ms finality, 100 MGas/s throughput, and full Ethereum tooling compatibility. Deploy standard Solidity contracts with no modifications. Chain ID: mainnet 1329, testnet 1328.',
	constraints: [
		'Prerequisites: Node.js ≥ 18, a wallet (MetaMask or any EVM-compatible wallet), and SEI tokens for gas fees.',
		'Authentication: No API key is required for public RPC endpoints. Rate limits apply to free RPC endpoints — use a dedicated provider (Ankr, DRPC, Nirvana) for production workloads.',
		'Version compatibility: Solidity ≥ 0.8.x recommended. Sei EVM uses the Pectra EVM version (without blob transactions).',
		'Network requirements: Mainnet chain ID 1329, testnet chain ID 1328. Gas is paid in SEI (18 decimals).',
		'Important notes: Sei has 400ms block times — set lower polling intervals than on Ethereum. Transactions that touch independent state are parallelized automatically; shared-state writes are serialized.'
	].join('\n'),
	quickReference: [
		'Chain ID: mainnet 1329, testnet 1328',
		'RPC (mainnet): https://evm-rpc.sei-apis.com',
		'RPC (testnet): https://evm-rpc-testnet.sei-apis.com',
		'Native token: SEI (gas, staking, governance)',
		'USDC (mainnet): 0xe15fC38F6D8c56aF07bbCBe3BAf5708A2Bf42392 (6 decimals)',
		'USDC (testnet): 0x4fCF1784B31630811181f670Aea7A7bEF803eaED (6 decimals)',
		'Block time: 400ms finality',
		'Throughput: 100 MGas/s (~12,500 TPS)',
		'EVM compatibility: Full — standard Solidity, Hardhat, Foundry, wagmi, ethers.js work unmodified'
	].join('\n'),
	examples: [
		{
			title: 'Deploy a contract with Hardhat',
			language: 'javascript',
			code: [
				'// hardhat.config.js',
				'module.exports = {',
				'  solidity: "0.8.26",',
				'  networks: {',
				'    sei: {',
				'      url: "https://evm-rpc.sei-apis.com",',
				'      chainId: 1329,',
				'      accounts: [process.env.PRIVATE_KEY],',
				'    },',
				'  },',
				'};'
			].join('\n')
		},
		{
			title: 'Query a balance with viem',
			language: 'typescript',
			code: [
				'import { createPublicClient, http } from "viem";',
				'import { sei } from "viem/chains";',
				'',
				'const client = createPublicClient({ chain: sei, transport: http() });',
				'const balance = await client.getBalance({',
				'  address: "0xYourAddress",',
				'});',
				'console.log("Balance:", balance);'
			].join('\n')
		},
		{
			title: 'Connect a wallet with wagmi',
			language: 'typescript',
			code: [
				'import { http, createConfig } from "wagmi";',
				'import { sei } from "wagmi/chains";',
				'import { injected } from "wagmi/connectors";',
				'',
				'export const config = createConfig({',
				'  chains: [sei],',
				'  connectors: [injected()],',
				'  transports: { [sei.id]: http() },',
				'});'
			].join('\n')
		}
	],
	keyResources: [
		{
			title: 'GitHub',
			url: 'https://github.com/sei-protocol',
			description: 'Open source repositories including sei-chain, sei-js, and MCP server'
		},
		{
			title: 'Sei-JS Documentation',
			url: 'https://sei-js.docs.sei.io',
			description: 'JavaScript/TypeScript SDK documentation for Sei-js blockchain integration'
		},
		{
			title: 'Ecosystem',
			url: 'https://www.sei.io/ecosystem',
			description: 'Directory of projects building on Sei'
		},
		{
			title: 'Blog',
			url: 'https://blog.sei.io',
			description: 'Latest news, announcements, and technical deep dives'
		}
	]
};

/** URL prefixes to exclude entirely from llms.txt and llms-full.txt output. */
const EXCLUDED_PREFIXES = ['/cosmos-sdk'];

/**
 * Section definitions ordered by match priority.
 * More specific prefixes (e.g. /evm/ai-tooling) must come before broader ones (/evm).
 */
const LLMS_SECTION_ORDER = [
	{
		name: 'Learn',
		match: (urlPath) => urlPath.startsWith('/learn'),
		overview: [
			'Sei is a parallelized EVM Layer 1 blockchain. Its performance comes from Twin Turbo Consensus (optimistic block processing), parallel EVM execution (concurrent transaction processing for independent state), and SeiDB (high-throughput storage layer). Full Ethereum tooling compatibility — deploy standard Solidity contracts with no modifications.',
			"Sei Giga is the next major upgrade targeting 200K TPS and 5 gigagas/s throughput via Autobahn multi-proposer BFT consensus and a custom EVM execution engine. For developers: Sei Giga's parallel execution engine rewards contracts with user-scoped state (mapping per address) over shared global state.",
			'Mainnet (pacific-1): Chain ID 1329. Testnet (atlantic-2): Chain ID 1328.'
		].join('\n\n')
	},
	{
		name: 'AI Tooling',
		match: (urlPath) => urlPath.startsWith('/evm/ai-tooling') || urlPath.startsWith('/evm/x402'),
		overview: [
			'The Sei MCP Server (@sei-js/mcp-server) connects AI assistants to Sei with 29+ tools. Install: `npx -y @sei-js/mcp-server`. Read-only tools: get_chain_info, get_balance, get_erc20_balance, get_token_info, get_nft_info, and more. Wallet tools (require PRIVATE_KEY): transfer_sei, transfer_erc20, deploy_contract, write_contract, and more. Documentation search: search_docs, search_sei_js_docs.',
			'The Cambrian Agent Kit enables autonomous AI agents on Sei with DeFi protocol integrations (Takara lending, Silo lending, Citrex perpetuals, Symphony aggregation, DragonSwap liquidity).',
			'The x402 protocol enables HTTP 402-based micropayments for machine-to-machine payments — agents pay per-request for APIs, content, and services with instant settlement on Sei (~400ms finality). The sei-js library provides both server-side (payment verification) and client-side (payment signing) x402 packages.'
		].join('\n\n')
	},
	{
		name: 'EVM Development',
		match: (urlPath) => urlPath.startsWith('/evm'),
		overview: [
			"Sei's EVM is fully compatible with Ethereum. Standard Solidity contracts deploy without modification. All Ethereum tooling (Hardhat, Foundry, wagmi, ethers.js, viem, RainbowKit) works as-is. Transactions touching independent state execute concurrently.",
			'Precompiled contracts at fixed addresses expose native Sei functionality (staking, governance, IBC transfers, pointer contracts) to EVM.',
			'Native USDC: mainnet 0xe15fC38F6D8c56aF07bbCBe3BAf5708A2Bf42392, testnet 0x4fCF1784B31630811181f670Aea7A7bEF803eaED (6 decimals).'
		].join('\n\n')
	},
	{
		name: 'Node Operations',
		match: (urlPath) => urlPath.startsWith('/node'),
		overview:
			'Sei supports full nodes (recent state, consensus relay), archive nodes (complete historical state), and validator nodes (block production and consensus). StateSync enables fast bootstrap — new nodes fetch a recent state snapshot instead of replaying all historical blocks.'
	}
];

/**
 * Assign each scraped page to a section based on its URL path.
 * Returns { sections, assigned } where assigned is the Set of URLs that matched.
 */
function categorizePages(scrapedPages) {
	const sections = LLMS_SECTION_ORDER.map((sec) => ({
		name: sec.name,
		overview: sec.overview || null,
		pages: []
	}));

	const assigned = new Set();

	for (const page of scrapedPages) {
		try {
			const urlPath = new URL(page.url).pathname;
			for (let i = 0; i < LLMS_SECTION_ORDER.length; i++) {
				if (LLMS_SECTION_ORDER[i].match(urlPath)) {
					sections[i].pages.push(page);
					assigned.add(page.url);
					break;
				}
			}
		} catch {
			// malformed URL — skip categorization
		}
	}

	return { sections: sections.filter((s) => s.pages.length > 0), assigned };
}

function formatLink(page) {
	const desc = page.description ? `: ${page.description}` : '';
	return `- [${page.title}](${page.url})${desc}`;
}

/**
 * Generate llms.txt and llms-full.txt following https://llmstxt.org.
 *
 * llms.txt     – project header, intro, categorized links with descriptions
 * llms-full.txt – header, quick reference, section overviews, categorized links,
 *                 key resources, then full scraped page content
 */
async function createLlmsFiles(scrapedPages, outputPath) {
	try {
		console.log('📝 Generating llms.txt and llms-full.txt...');

		const { projectName, blockquote, intro, constraints, quickReference, examples, keyResources } = SEI_LLMS_CONFIG;

		const isExcluded = (url) => {
			try {
				const urlPath = new URL(url).pathname;
				return EXCLUDED_PREFIXES.some((prefix) => urlPath.startsWith(prefix));
			} catch {
				return false;
			}
		};
		const filteredPages = scrapedPages.filter((p) => !isExcluded(p.url));

		const { sections, assigned } = categorizePages(filteredPages);
		const uncategorized = filteredPages.filter((p) => !assigned.has(p.url));

		function formatExamples(examplesList) {
			let out = '';
			for (const ex of examplesList) {
				out += `### ${ex.title}\n\n`;
				out += `\`\`\`${ex.language}\n${ex.code}\n\`\`\`\n\n`;
			}
			return out;
		}

		// ---- llms.txt ----
		let llmsTxt = `# ${projectName}\n\n`;
		llmsTxt += `> ${blockquote}\n\n`;
		llmsTxt += `${intro}\n\n`;
		llmsTxt += `${constraints}\n`;
		llmsTxt += `\n## Quick Reference\n\n${quickReference}\n`;

		for (const section of sections) {
			llmsTxt += `\n## ${section.name}\n\n`;
			if (section.overview) {
				llmsTxt += `${section.overview}\n\n`;
			}
			for (const page of section.pages) {
				llmsTxt += `${formatLink(page)}\n`;
			}
		}

		if (examples && examples.length > 0) {
			llmsTxt += `\n## Examples\n\n`;
			llmsTxt += formatExamples(examples);
		}

		if (uncategorized.length > 0) {
			llmsTxt += `\n## Optional\n\n`;
			for (const page of uncategorized) {
				llmsTxt += `${formatLink(page)}\n`;
			}
		}

		if (keyResources.length > 0) {
			llmsTxt += `\n## Resources\n\n`;
			for (const res of keyResources) {
				llmsTxt += `- [${res.title}](${res.url}): ${res.description}\n`;
			}
		}

		// ---- llms-full.txt ----
		let llmsFull = `# ${projectName}\n\n`;
		llmsFull += `> ${blockquote}\n\n`;
		llmsFull += `${constraints}\n`;
		llmsFull += `\n## Quick Reference\n\n${quickReference}\n`;

		for (const section of sections) {
			llmsFull += `\n## ${section.name}\n\n`;
			if (section.overview) {
				llmsFull += `${section.overview}\n\n`;
			}
			for (const page of section.pages) {
				llmsFull += `${formatLink(page)}\n`;
			}
		}

		if (examples && examples.length > 0) {
			llmsFull += `\n## Examples\n\n`;
			llmsFull += formatExamples(examples);
		}

		if (uncategorized.length > 0) {
			llmsFull += `\n## Optional\n\n`;
			for (const page of uncategorized) {
				llmsFull += `${formatLink(page)}\n`;
			}
		}

		if (keyResources.length > 0) {
			llmsFull += `\n## Resources\n\n`;
			for (const res of keyResources) {
				llmsFull += `- [${res.title}](${res.url}): ${res.description}\n`;
			}
		}

		// Append full page content after a separator
		llmsFull += '\n---\n\n';
		for (const page of filteredPages) {
			llmsFull += `# ${page.title}\n\n`;
			llmsFull += `URL: ${page.url}\n`;
			if (page.description) {
				llmsFull += `Description: ${page.description}\n`;
			}
			if (page.keywords && page.keywords.length > 0) {
				llmsFull += `Keywords: ${page.keywords.join(', ')}\n`;
			}
			llmsFull += `\n${page.content}\n\n---\n\n`;
		}

		await Promise.all([fs.writeFile(path.join(outputPath, 'llms.txt'), llmsTxt, 'utf8'), fs.writeFile(path.join(outputPath, 'llms-full.txt'), llmsFull, 'utf8')]);

		console.log('📄 Created llms.txt and llms-full.txt');
	} catch (error) {
		console.error('❌ Error generating llms.txt files:', error.message);
	}
}

module.exports = { SEI_LLMS_CONFIG, LLMS_SECTION_ORDER, categorizePages, createLlmsFiles };

/**
 * Scrape documentation from the built HTML files in .next/server/app
 */
async function scrapeBuiltHtml() {
	const buildDir = './.next/server/app';
	const outputPath = './public/_scraped-docs';
	const scrapedPages = [];

	try {
		console.log('🚀 Starting built HTML documentation scraping...');
		await fs.mkdir(outputPath, { recursive: true });

		// Find all HTML files in the build directory
		const htmlFiles = await findHtmlFiles(buildDir);
		console.log(`📋 Found ${htmlFiles.length} HTML files`);

		// Process files in parallel with concurrency limit
		const processedPages = await processFilesInParallel(htmlFiles, buildDir);

		// Filter out null results (failed or skipped files)
		scrapedPages.push(...processedPages.filter((page) => page !== null));

		console.log(`✅ Successfully processed ${scrapedPages.length} pages out of ${htmlFiles.length} total files`);
		await saveScrapedContent(scrapedPages, outputPath);
		// Generate llms.txt and llms-full.txt at the public root (served as docs.sei.io/llms.txt)
		await createLlmsFiles(scrapedPages, './public');
		// Generate per-page .md files mirroring URL paths (e.g. /evm/evm-general.md)
		await createPerPageMarkdownFiles(scrapedPages, './public');
	} catch (err) {
		console.error('❌ Fatal error:', err);
		process.exit(1);
	}
}

/**
 * Process files in parallel with concurrency limiting
 */
async function processFilesInParallel(htmlFiles, buildDir) {
	const results = [];
	let completed = 0;
	let errors = 0;

	// Create chunks for parallel processing
	const chunks = [];
	for (let i = 0; i < htmlFiles.length; i += CONCURRENCY_LIMIT) {
		chunks.push(htmlFiles.slice(i, i + CONCURRENCY_LIMIT));
	}

	console.log(`🔄 Processing ${htmlFiles.length} files in ${chunks.length} chunks of max ${CONCURRENCY_LIMIT} files each`);

	// Process each chunk in parallel
	for (let chunkIndex = 0; chunkIndex < chunks.length; chunkIndex++) {
		const chunk = chunks[chunkIndex];
		const chunkStartTime = Date.now();

		console.log(`\n📦 Processing chunk ${chunkIndex + 1}/${chunks.length} (${chunk.length} files)`);

		// Process all files in the current chunk simultaneously
		const chunkPromises = chunk.map(async (filePath, fileIndex) => {
			const globalIndex = chunkIndex * CONCURRENCY_LIMIT + fileIndex + 1;

			try {
				console.log(`   ➡️ (${globalIndex}/${htmlFiles.length}) Starting: ${filePath}`);

				const pageData = await processHtmlFile(filePath, buildDir);

				if (pageData) {
					console.log(`   ✅ (${globalIndex}/${htmlFiles.length}) Done: ${path.basename(filePath)} (${pageData.content.length} chars)`);
					completed++;
					return pageData;
				} else {
					console.log(`   ⚠️ (${globalIndex}/${htmlFiles.length}) Skipped: ${path.basename(filePath)} (no content or too short)`);
					completed++;
					return null;
				}
			} catch (error) {
				console.warn(`   ❌ (${globalIndex}/${htmlFiles.length}) Error processing ${path.basename(filePath)}:`, error.message);
				errors++;
				return null;
			}
		});

		// Wait for all files in this chunk to complete
		const chunkResults = await Promise.all(chunkPromises);
		results.push(...chunkResults);

		const chunkDuration = ((Date.now() - chunkStartTime) / 1000).toFixed(2);
		const successCount = chunkResults.filter((r) => r !== null).length;

		console.log(`   📊 Chunk ${chunkIndex + 1} completed in ${chunkDuration}s - Success: ${successCount}/${chunk.length}`);
		console.log(
			`   📈 Overall progress: ${completed + errors}/${htmlFiles.length} files processed (${(((completed + errors) / htmlFiles.length) * 100).toFixed(1)}%)`
		);
	}

	console.log(`\n🏁 Parallel processing complete!`);
	console.log(`   ✅ Successfully processed: ${completed} files`);
	console.log(`   ❌ Errors: ${errors} files`);
	console.log(`   📄 Total valid pages: ${results.filter((r) => r !== null).length}`);

	return results;
}

/**
 * Recursively find all HTML files in the build directory
 */
async function findHtmlFiles(dir, htmlFiles = []) {
	const items = await fs.readdir(dir);

	for (const item of items) {
		const fullPath = path.join(dir, item);
		const stat = await fs.stat(fullPath);

		if (stat.isDirectory()) {
			await findHtmlFiles(fullPath, htmlFiles);
		} else if (item.endsWith('.html') && !item.startsWith('_')) {
			htmlFiles.push(fullPath);
		}
	}

	return htmlFiles;
}

/**
 * Process a single HTML file
 */
async function processHtmlFile(filePath, buildDir) {
	try {
		const htmlContent = await fs.readFile(filePath, 'utf8');

		// Create DOM from HTML
		const dom = new JSDOM(htmlContent);
		const document = dom.window.document;

		// Generate URL from file path
		const url = generateUrlFromPath(filePath, buildDir);

		// Extract metadata
		const title = extractTitle(document);
		const description = extractDescription(document);
		const keywords = extractKeywords(document);

		// Extract and clean content
		const content = extractAndCleanContent(document);

		if (!content || content.length < 100) {
			return null; // Skip pages with little content
		}

		return {
			url: `https://docs.sei.io${url}`,
			title,
			description,
			keywords,
			content,
			filePath
		};
	} catch (error) {
		console.warn(`Could not process ${filePath}:`, error.message);
		return null;
	}
}

/**
 * Generate URL from file path
 */
function generateUrlFromPath(filePath, buildDir) {
	// Normalize the buildDir to handle different path formats
	const normalizedBuildDir = buildDir.replace(/^\.\//, '');

	// Remove the build directory prefix and .html extension
	let url = filePath.replace(normalizedBuildDir, '').replace(/\.html$/, '');

	// Convert file system path to URL path
	url = url.replace(/\\/g, '/'); // Convert backslashes to forward slashes

	// Remove leading slash if present
	if (url.startsWith('/')) {
		url = url.substring(1);
	}

	// Handle index files and root
	if (url === 'index' || url === '') {
		return '/';
	}

	// Ensure it starts with /
	return `/${url}`;
}

/**
 * Extract title from document
 */
function extractTitle(document) {
	// Try different methods to get the title
	const titleElement = document.querySelector('h1');
	if (titleElement) {
		return titleElement.textContent.trim();
	}

	const metaTitle = document.querySelector('title');
	if (metaTitle) {
		return metaTitle.textContent.replace(' | Sei Docs', '').trim();
	}

	return 'Untitled';
}

/**
 * Extract description from document
 */
function extractDescription(document) {
	const metaDesc = document.querySelector('meta[name="description"]');
	if (metaDesc) {
		return metaDesc.getAttribute('content');
	}

	const ogDesc = document.querySelector('meta[property="og:description"]');
	if (ogDesc) {
		return ogDesc.getAttribute('content');
	}

	return null;
}

/**
 * Extract keywords from document
 */
function extractKeywords(document) {
	const metaKeywords = document.querySelector('meta[name="keywords"]');
	if (metaKeywords) {
		const keywords = metaKeywords.getAttribute('content');
		return keywords ? keywords.split(',').map((k) => k.trim()) : null;
	}
	return null;
}

/**
 * Extract and clean content from document
 */
function extractAndCleanContent(document) {
	// Remove navigation, headers, footers and other non-content elements
	const elementsToRemove = [
		'nav',
		'header',
		'footer',
		'[role="navigation"]',
		'[role="banner"]',
		'[role="contentinfo"]',
		'.sidebar',
		'.nav',
		'.navigation',
		'.header',
		'.footer',
		'.breadcrumb',
		'.pagination',
		'.toc',
		'.table-of-contents',
		'script',
		'style',
		'noscript',
		'link[rel="stylesheet"]',
		'button:not(.copy-button)', // Keep copy buttons as they indicate code
		'.search',
		'#search',
		'[data-search]',
		'.nx-sidebar',
		'.nx-toc',
		'.nx-nav-container',
		'[data-nextra-nav]',
		'[data-nextra-sidebar]',
		'.nextra-nav-container',
		'.nextra-sidebar'
	];

	elementsToRemove.forEach((selector) => {
		const elements = document.querySelectorAll(selector);
		elements.forEach((el) => {
			el.remove();
		});
	});

	// Try to find the main content area
	const contentElement =
		document.querySelector('main') ||
		document.querySelector('[role="main"]') ||
		document.querySelector('.content') ||
		document.querySelector('.main-content') ||
		document.querySelector('article') ||
		document.querySelector('.nx-content') ||
		document.querySelector('[data-nextra-content]') ||
		document.body;

	if (!contentElement) {
		return null;
	}

	// Unroll tabs - make all tab content visible
	unrollTabContent(contentElement);

	// Remove empty elements
	const emptyElements = contentElement.querySelectorAll('*:empty:not(img):not(input):not(textarea):not(br):not(hr)');
	emptyElements.forEach((el) => {
		el.remove();
	});

	// Convert HTML to markdown-like text
	const content = htmlToMarkdown(contentElement);

	// Clean up whitespace
	return content
		.replace(/\n\s*\n\s*\n/g, '\n\n')
		.replace(/[ \t]+/g, ' ')
		.replace(/^[ \t]+|[ \t]+$/gm, '')
		.trim();
}

/**
 * Unroll tab content to make all tabs visible in sequence
 */
function unrollTabContent(contentElement) {
	console.log('Unrolling tab content...');

	// 1. Handle Nextra-specific tab patterns first
	const nextraTabGroups = contentElement.querySelectorAll('.nextra-tabs, [data-tabs]');
	console.log(`Found ${nextraTabGroups.length} Nextra tab groups`);

	nextraTabGroups.forEach((tabGroup) => {
		// Find all tab panels within this group
		const tabPanels = tabGroup.querySelectorAll('[role="tabpanel"], .tab-panel, [data-tab-panel]');
		const tabButtons = tabGroup.querySelectorAll('[role="tab"], .tab-button, [data-tab]');

		console.log(`Processing tab group with ${tabPanels.length} panels and ${tabButtons.length} buttons`);

		tabPanels.forEach((panel, index) => {
			// Remove hidden attribute and any hiding styles
			panel.removeAttribute('hidden');
			panel.style.display = 'block';
			panel.style.visibility = 'visible';
			panel.style.opacity = '1';
			panel.setAttribute('data-state', 'active');

			// Remove any transform or position styles that might hide content
			panel.style.transform = '';
			panel.style.position = '';
			panel.style.left = '';
			panel.style.top = '';

			// Try to find the corresponding tab button for labeling
			let tabLabel = '';
			if (tabButtons[index]) {
				tabLabel = tabButtons[index].textContent.trim();
			} else {
				// Try to find by aria-labelledby
				const labelledBy = panel.getAttribute('aria-labelledby');
				if (labelledBy) {
					const labelElement = contentElement.querySelector(`#${labelledBy}`);
					if (labelElement) {
						tabLabel = labelElement.textContent.trim();
					}
				}
			}

			// Add a header to identify the tab section if we found a label
			if (tabLabel && !panel.querySelector('h4, h3, h2')) {
				const headerEl = contentElement.ownerDocument.createElement('h3');
				headerEl.textContent = tabLabel;
				headerEl.style.marginTop = '2rem';
				headerEl.style.marginBottom = '1rem';
				headerEl.style.fontWeight = 'bold';
				headerEl.style.fontSize = '1.25em';
				panel.insertBefore(headerEl, panel.firstChild);
				console.log(`Added header for Nextra tab: ${tabLabel}`);
			}
		});
	});

	// 2. Handle Radix UI tabs specifically
	const radixTabPanels = contentElement.querySelectorAll('[role="tabpanel"]');
	console.log(`Found ${radixTabPanels.length} Radix tab panels`);

	radixTabPanels.forEach((panel, _index) => {
		// Remove hidden attribute and any hiding styles
		panel.removeAttribute('hidden');
		panel.style.display = '';
		panel.style.visibility = 'visible';
		panel.style.opacity = '1';
		panel.setAttribute('data-state', 'active');

		// Find the corresponding tab trigger to get the label
		const triggerId = panel.getAttribute('aria-labelledby');
		if (triggerId) {
			// Escape CSS selector safely
			const escapedId = triggerId.replace(/"/g, '\\"').replace(/'/g, "\\'");
			const trigger = contentElement.querySelector(`#${escapedId}`);
			if (trigger) {
				const tabLabel = trigger.textContent.trim();
				if (tabLabel && !panel.querySelector('h4')) {
					// Add a header to identify the tab section
					const headerEl = contentElement.ownerDocument.createElement('h4');
					headerEl.textContent = tabLabel;
					headerEl.style.marginTop = '2rem';
					headerEl.style.marginBottom = '1rem';
					headerEl.style.fontWeight = 'bold';
					headerEl.style.fontSize = '1.25em';
					panel.insertBefore(headerEl, panel.firstChild);
					console.log(`Added header for tab: ${tabLabel}`);
				}
			}
		}
	});

	// 3. Handle any elements with data-state="inactive"
	const inactiveElements = contentElement.querySelectorAll('[data-state="inactive"]');
	console.log(`Found ${inactiveElements.length} inactive elements`);

	inactiveElements.forEach((el) => {
		el.setAttribute('data-state', 'active');
		el.removeAttribute('hidden');
		el.style.display = '';
		el.style.visibility = 'visible';
		el.style.opacity = '1';
	});

	// 4. Handle any elements with hidden attribute
	const hiddenElements = contentElement.querySelectorAll('[hidden]');
	console.log(`Found ${hiddenElements.length} hidden elements`);

	hiddenElements.forEach((el) => {
		// Only unhide if it looks like substantial content (not just UI elements)
		const textContent = el.textContent.trim();
		if (textContent.length > 50 || el.querySelector('pre, code, h1, h2, h3, h4, h5, h6')) {
			el.removeAttribute('hidden');
			el.style.display = '';
			el.style.visibility = 'visible';
			el.style.opacity = '1';
			console.log(`Unhid element with ${textContent.length} chars of content`);
		}
	});

	// 5. Look for any CSS-hidden content
	const hiddenByStyle = contentElement.querySelectorAll('[style*="display: none"], [style*="display:none"]');
	console.log(`Found ${hiddenByStyle.length} CSS-hidden elements`);

	hiddenByStyle.forEach((el) => {
		const textContent = el.textContent.trim();
		if (textContent.length > 50 || el.querySelector('pre, code, h1, h2, h3, h4, h5, h6')) {
			el.style.display = '';
			el.style.visibility = 'visible';
			el.style.opacity = '1';
			console.log(`Unhid CSS-hidden element with ${textContent.length} chars of content`);
		}
	});

	// 6. Handle any other tab-like patterns
	const genericTabPanels = contentElement.querySelectorAll('.tab-content, .tab-panel, [class*="tabcontent"], [class*="TabContent"]');

	genericTabPanels.forEach((panel) => {
		panel.style.display = '';
		panel.style.visibility = 'visible';
		panel.style.opacity = '1';
		panel.removeAttribute('hidden');
	});

	console.log('Tab unrolling complete');
}

/**
 * Convert HTML element to markdown-like text
 */
function htmlToMarkdown(element) {
	let result = '';

	// Process each child node
	for (const node of element.childNodes) {
		if (node.nodeType === 3) {
			// Text node - handle with context awareness
			const text = node.textContent;
			if (text.trim()) {
				// Preserve significant whitespace but normalize
				const normalizedText = text.replace(/\s+/g, ' ');
				result += normalizedText;
			}
		} else if (node.nodeType === 1) {
			// Element node
			const tagName = node.tagName.toLowerCase();

			switch (tagName) {
				case 'h1':
					result += `${ensureNewlines(result, 2)}# ${node.textContent.trim()}\n\n`;
					break;
				case 'h2':
					result += `${ensureNewlines(result, 2)}## ${node.textContent.trim()}\n\n`;
					break;
				case 'h3':
					result += `${ensureNewlines(result, 2)}### ${node.textContent.trim()}\n\n`;
					break;
				case 'h4':
					result += `${ensureNewlines(result, 2)}#### ${node.textContent.trim()}\n\n`;
					break;
				case 'h5':
					result += `${ensureNewlines(result, 2)}##### ${node.textContent.trim()}\n\n`;
					break;
				case 'h6':
					result += `${ensureNewlines(result, 2)}###### ${node.textContent.trim()}\n\n`;
					break;
				case 'p': {
					const pText = node.textContent.trim();
					if (pText) {
						result += `${ensureNewlines(result, 1) + pText}\n\n`;
					}
					break;
				}
				case 'ul':
				case 'ol':
					result += `${ensureNewlines(result, 1) + processListElement(node)}\n`;
					break;
				case 'li':
					// Handled by processListElement
					break;
				case 'a': {
					const href = node.getAttribute('href');
					const text = node.textContent.trim();
					if (href && text) {
						result += `[${text}](${href})`;
					} else if (text) {
						result += text;
					}
					break;
				}
				case 'strong':
				case 'b': {
					const strongText = node.textContent.trim();
					if (strongText) {
						result += `**${strongText}**`;
					}
					break;
				}
				case 'em':
				case 'i': {
					const emText = node.textContent.trim();
					if (emText) {
						result += `*${emText}*`;
					}
					break;
				}
				case 'code': {
					const codeText = node.textContent.trim();
					if (codeText) {
						result += `\`${codeText}\``;
					}
					break;
				}
				case 'pre': {
					const preText = node.textContent.trim();
					if (preText) {
						result += `${ensureNewlines(result, 1)}\`\`\`\n${preText}\n\`\`\`\n\n`;
					}
					break;
				}
				case 'blockquote': {
					const quoteText = node.textContent.trim();
					if (quoteText) {
						const lines = quoteText.split('\n');
						result += `${ensureNewlines(result, 1) + lines.map((line) => `> ${line.trim()}`).join('\n')}\n\n`;
					}
					break;
				}
				case 'table':
					result += `${ensureNewlines(result, 1) + processTableElement(node)}\n\n`;
					break;
				case 'br':
					result += '\n';
					break;
				case 'hr':
					result += `${ensureNewlines(result, 2)}---\n\n`;
					break;
				case 'div':
				case 'section':
				case 'article': {
					// Check if this is a block-level container that should add spacing
					const hasBlockContent = node.querySelector('h1, h2, h3, h4, h5, h6, p, ul, ol, pre, blockquote, table');
					if (hasBlockContent) {
						result += `${ensureNewlines(result, 1) + htmlToMarkdown(node)}\n`;
					} else {
						// Inline container
						result += htmlToMarkdown(node);
					}
					break;
				}
				case 'span':
					// Always inline
					result += htmlToMarkdown(node);
					break;
				case 'dt':
					result += `${ensureNewlines(result, 1)}**${node.textContent.trim()}**\n`;
					break;
				case 'dd':
					result += `${node.textContent.trim()}\n\n`;
					break;
				case 'dl':
					result += `${ensureNewlines(result, 1) + htmlToMarkdown(node)}\n`;
					break;
				default:
					// For other elements, check if they might be important containers
					if (node.children && node.children.length > 0) {
						// If it has children, process them
						const childContent = htmlToMarkdown(node);
						if (childContent.trim()) {
							result += childContent;
						}
					} else {
						// For leaf elements, get text content
						const textContent = node.textContent.trim();
						if (textContent) {
							result += textContent;
						}
					}
					break;
			}
		}
	}

	return result;
}

/**
 * Ensure the result has the specified number of newlines at the end
 */
function ensureNewlines(text, count) {
	const trailingNewlines = (text.match(/\n*$/)?.[0] || '').length;
	const needed = Math.max(0, count - trailingNewlines);
	return '\n'.repeat(needed);
}

/**
 * Process list elements
 */
function processListElement(listElement) {
	let result = '';
	const items = listElement.querySelectorAll('li');
	const isOrdered = listElement.tagName.toLowerCase() === 'ol';

	items.forEach((item, index) => {
		const prefix = isOrdered ? `${index + 1}. ` : '- ';
		const text = item.textContent.trim();
		if (text) {
			result += `${prefix + text}\n`;
		}
	});

	return result;
}

/**
 * Process table elements
 */
function processTableElement(tableElement) {
	let result = '';
	const rows = tableElement.querySelectorAll('tr');

	rows.forEach((row, rowIndex) => {
		const cells = row.querySelectorAll('th, td');
		const cellTexts = Array.from(cells).map((cell) => cell.textContent.trim());

		if (cellTexts.length > 0) {
			result += `| ${cellTexts.join(' | ')} |\n`;

			// Add separator row after header
			if (rowIndex === 0 && row.querySelector('th')) {
				result += `| ${cellTexts.map(() => '---').join(' | ')} |\n`;
			}
		}
	});

	return result;
}

/**
 * Save scraped content
 */
async function saveScrapedContent(scrapedPages, outputPath) {
	console.log('📝 Saving scraped content...');

	// Create consolidated content
	let consolidatedContent = '';

	for (const page of scrapedPages) {
		const fileName = generateFileName(page.url);

		// Build frontmatter
		let frontmatter = `---
title: "${page.title.replace(/"/g, '\\"')}"
url: "${page.url}"
file_path: "${page.filePath}"`;

		if (page.description) {
			frontmatter += `
description: "${page.description.replace(/"/g, '\\"')}"`;
		}

		if (page.keywords && Array.isArray(page.keywords) && page.keywords.length > 0) {
			frontmatter += `
keywords:`;
			page.keywords.forEach((keyword) => {
				frontmatter += `
  - "${keyword.replace(/"/g, '\\"')}"`;
			});
		}

		frontmatter += `
---`;

		const mdxContent = `${frontmatter}

# ${page.title}

${page.content}
`;

		// Save individual file
		await fs.writeFile(path.join(outputPath, `${fileName}.mdx`), mdxContent, 'utf8');

		// Add to consolidated content
		consolidatedContent += `# ${page.title}\n\nURL: ${page.url}\nFile: ${page.filePath}\n`;
		if (page.description) {
			consolidatedContent += `Description: ${page.description}\n`;
		}
		if (page.keywords && page.keywords.length > 0) {
			consolidatedContent += `Keywords: ${page.keywords.join(', ')}\n`;
		}
		consolidatedContent += `\n${page.content}\n\n---\n\n`;
	}

	// Save consolidated content
	await fs.writeFile(path.join(outputPath, 'sei-docs-consolidated.txt'), consolidatedContent, 'utf8');

	// Save structured JSON
	await fs.writeFile(path.join(outputPath, 'sei-docs-structured.json'), JSON.stringify(scrapedPages, null, 2), 'utf8');

	console.log(`📄 Created consolidated text file: ${outputPath}/sei-docs-consolidated.txt`);
	console.log(`📋 Created structured JSON file: ${outputPath}/sei-docs-structured.json`);
	console.log(`📁 Created ${scrapedPages.length} individual .mdx files`);
}

/**
 * Generate filename from URL
 */
function generateFileName(url) {
	try {
		const urlObj = new URL(url);
		let pathname = urlObj.pathname;

		// Remove leading/trailing slashes and replace special chars
		pathname = pathname.replace(/^\/+|\/+$/g, '');
		pathname = pathname.replace(/[/\\:*?"<>|]/g, '-');
		pathname = pathname.replace(/-+/g, '-');

		return pathname || 'index';
	} catch {
		return `page-${Date.now()}`;
	}
}

/**
 * Create per-page .md files that mirror the URL structure.
 * E.g. a page at https://docs.sei.io/evm/evm-general gets a file at public/evm/evm-general.md
 * so that docs.sei.io/evm/evm-general.md returns the LLM-friendly markdown.
 */
async function createPerPageMarkdownFiles(scrapedPages, publicDir) {
	try {
		console.log('📝 Generating per-page .md files...');
		let created = 0;

		for (const page of scrapedPages) {
			const urlObj = new URL(page.url);
			let pathname = urlObj.pathname;

			// Skip the root page (index)
			if (pathname === '/' || pathname === '') continue;

			// Remove leading slash
			pathname = pathname.replace(/^\//, '');

			const mdFilePath = path.join(publicDir, `${pathname}.md`);

			// Ensure the directory exists
			await fs.mkdir(path.dirname(mdFilePath), { recursive: true });

			// Build the markdown content with frontmatter
			let md = `---\ntitle: ${page.title}\n`;
			if (page.description) {
				md += `description: ${page.description}\n`;
			}
			md += `url: ${page.url}\n---\n\n`;
			md += `# ${page.title}\n\n`;
			md += page.content;

			await fs.writeFile(mdFilePath, md, 'utf8');
			created++;
		}

		console.log(`📄 Created ${created} per-page .md files (append .md to any docs URL)`);
	} catch (error) {
		console.error('❌ Error generating per-page .md files:', error.message);
	}
}

// Run the scraper
scrapeBuiltHtml();
