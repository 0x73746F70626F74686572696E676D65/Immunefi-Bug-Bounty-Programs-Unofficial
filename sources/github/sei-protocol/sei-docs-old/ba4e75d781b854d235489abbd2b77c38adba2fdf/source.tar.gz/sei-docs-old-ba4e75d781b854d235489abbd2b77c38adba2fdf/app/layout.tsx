import { GoogleTagManager } from '@next/third-parties/google';
import type { Metadata, Viewport } from 'next';
import { getPageMap } from 'nextra/page-map';
import { Toaster } from 'sonner';

import DocsProviders from '../src/providers/DocsProviders';

import 'nextra-theme-docs/style.css';
import './globals.css';
import 'katex/dist/katex.min.css';

const GTM_ID = 'GTM-KKN784SR';

export const metadata: Metadata = {
	metadataBase: new URL('https://docs.sei.io'),
	title: {
		default: 'Sei Documentation | Developer Guides & Resources',
		template: '%s | Sei Docs'
	},
	description:
		'Documentation for Sei. Providing comprehensive guides, tutorials, and resources for developers building on Sei. Learn about the EVM, smart contracts, tokenization standards (ERC20, ERC721, ERC1155), and advanced features of the Sei ecosystem to accelerate your blockchain development journey.',
	category: 'technology',
	openGraph: {
		url: 'https://docs.sei.io',
		siteName: 'Sei Docs',
		locale: 'en_US',
		images: [
			{
				url: 'https://docs.sei.io/assets/docs-banner.png',
				alt: 'Sei Docs'
			}
		],
		type: 'article'
	},
	twitter: {
		card: 'summary_large_image',
		creator: '@SeiNetwork',
		images: ['https://docs.sei.io/assets/docs-banner.png']
	},
	referrer: 'origin-when-cross-origin',
	keywords: ['Sei', 'Sei Network', 'Sei Blockchain', 'Sei Docs', 'Sei Documentation', 'EVM', 'ERC20', 'ERC721'],
	creator: 'Sei Network',
	publisher: 'Sei Network',
	formatDetection: {
		email: false,
		address: false,
		telephone: false
	},
	robots: {
		index: true,
		follow: true,
		nocache: false,
		googleBot: {
			index: true,
			follow: true,
			noimageindex: false,
			'max-video-preview': -1,
			'max-image-preview': 'large',
			'max-snippet': -1
		}
	},
	icons: {
		icon: '/icon.png',
		apple: '/apple-icon.png'
	}
};

export const viewport: Viewport = {
	width: 'device-width',
	initialScale: 1,
	viewportFit: 'cover'
};

export default async function RootLayout({ children }) {
	return (
		<html lang='en' dir='ltr' suppressHydrationWarning className='dark' style={{ width: '100%', height: '100%' }}>
			<head>
				<meta name='color-scheme' content='dark light' />
				{/* Google Fonts: Inter + JetBrains Mono to match Sei design system */}
				<link rel='preconnect' href='https://fonts.googleapis.com' />
				<link rel='preconnect' href='https://fonts.gstatic.com' crossOrigin='anonymous' />
				<link
					href='https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&family=JetBrains+Mono:wght@300;400;500;600;700&display=swap'
					rel='stylesheet'
				/>
				<script
					type='application/ld+json'
					dangerouslySetInnerHTML={{
						__html: JSON.stringify({
							'@context': 'https://schema.org',
							'@type': 'Organization',
							name: 'Sei Network',
							url: 'https://sei.io',
							logo: 'https://docs.sei.io/icon.png',
							sameAs: ['https://x.com/SeiNetwork', 'https://github.com/sei-protocol', 'https://www.linkedin.com/company/sei-network/']
						})
					}}
				/>
				<script
					type='application/ld+json'
					dangerouslySetInnerHTML={{
						__html: JSON.stringify({
							'@context': 'https://schema.org',
							'@type': 'WebSite',
							name: 'Sei Docs',
							url: 'https://docs.sei.io',
							potentialAction: {
								'@type': 'SearchAction',
								target: 'https://docs.sei.io/?q={search_term_string}',
								'query-input': 'required name=search_term_string'
							}
						})
					}}
				/>
			</head>
			<body style={{ width: '100%', height: '100%', fontFamily: "'Inter', system-ui, -apple-system, sans-serif" }}>
				{/* Google Tag Manager (noscript) fallback */}
				<noscript>
					<iframe
						src={`https://www.googletagmanager.com/ns.html?id=${GTM_ID}`}
						height='0'
						width='0'
						style={{ display: 'none', visibility: 'hidden' }}
						title='Google Tag Manager'
					/>
				</noscript>
				<Toaster position='bottom-left' />
				<DocsProviders pageMap={await getPageMap()}>{children}</DocsProviders>
			</body>
			<GoogleTagManager gtmId={GTM_ID} />
		</html>
	);
}
