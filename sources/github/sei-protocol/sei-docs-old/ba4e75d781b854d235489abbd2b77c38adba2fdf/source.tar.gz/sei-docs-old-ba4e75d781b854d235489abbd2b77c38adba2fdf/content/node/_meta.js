export default {
	index: {
		title: 'Home'
	},
	'-- Node Operations': {
		type: 'separator',
		title: 'Node Operations'
	},
	'node-operators': 'Overview',
	seictl: 'Seictl Setup Helper',
	statesync: 'Statesync',
	snapshot: 'Snapshot Sync',
	'node-types': 'Node Types',
	troubleshooting: 'Troubleshooting',
	swagger: 'API configuration',
	validators: 'Validator Operations Guide',

	'-- Advanced Operations': {
		type: 'separator',
		title: 'Advanced Operations'
	},
	'advanced-config-monitoring': 'Advanced Configuration & Monitoring',
	'rocksdb-backend': 'RocksDB Backend',
	'giga-storage-migration': 'Giga SS Store Migration',
	'technical-reference': 'Technical Reference'
};
