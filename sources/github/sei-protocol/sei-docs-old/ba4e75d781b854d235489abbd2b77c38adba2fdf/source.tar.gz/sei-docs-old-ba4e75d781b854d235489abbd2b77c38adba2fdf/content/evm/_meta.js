export default {
	index: {
		title: 'Home'
	},
	'-- Essentials': {
		type: 'separator',
		title: 'Essentials'
	},
	networks: 'Network Information',
	'differences-with-ethereum': 'Divergence from Ethereum',
	'migrate-from-other-evms': 'Migrate from Other EVMs',
	'migrate-from-solana': 'Migrate from Solana',

	'-- seid CLI': {
		type: 'separator',
		title: 'seid CLI'
	},
	'installing-seid-cli': 'Installing seid CLI',
	'querying-the-evm': 'Querying the EVM',
	'transactions-with-seid': 'Transactions with seid',
	changelog: 'Changelog',

	'-- Frontend Development': {
		type: 'separator',
		title: 'Frontend Development'
	},
	'sei-global-wallet': {
		title: 'Sei Global Wallet'
	},
	'building-a-frontend': 'Building a Frontend',
	'in-app-swaps': 'In-App Swaps',

	'-- Smart Contracts': {
		type: 'separator',
		title: 'Smart Contracts'
	},
	'evm-general': 'EVM (General)',
	'evm-hardhat': 'EVM with Hardhat',
	'evm-foundry': 'EVM with Foundry',
	'evm-wizard': {
		title: 'EVM Contract Wizard',
		theme: {
			sidebar: true,
			toc: false,
			layout: 'full'
		}
	},
	'solidity-resources': 'Solidity Resources',
	'best-practices': 'Best Practices',
	'debugging-contracts': 'Debugging for EVM',
	tracing: 'Debug Tracing',
	'evm-verify-contracts': 'Verify Contracts',
	precompiles: 'Precompiles',

	'-- Sei-js': {
		type: 'separator',
		title: 'sei-js Library'
	},
	'sei-js': {
		display: 'children'
	},

	'-- Videos': {
		type: 'separator',
		title: 'Videos'
	},
	videos: 'Video Tutorials',

	'-- Ecosystem Tutorials': {
		type: 'separator',
		title: 'Ecosystem Tutorials'
	},
	'indexer-providers': 'Indexers',
	'wallet-integrations': 'Wallet Integrations',
	bridging: 'Bridging',
	'ai-tooling': 'AI Tooling',
	'usdc-on-sei': 'USDC on Sei',
	x402: 'x402 Protocol',
	dune: 'Dune Analytics',
	oracles: 'Oracles',
	vrf: 'VRF',

	'-- Reference': {
		type: 'separator',
		title: 'Reference'
	},
	transactions: 'Transaction Overview',
	reference: 'RPC Reference',
	tokens: 'View Tokens',
	'analytics-setup': 'Analytics Setup',
	'ecosystem-contracts': 'Ecosystem Contracts',

	'-- Hardware Wallets': {
		type: 'separator',
		title: 'Hardware Wallets'
	},
	'ledger-ethers': 'Ledger Setup (EVM)'
};
