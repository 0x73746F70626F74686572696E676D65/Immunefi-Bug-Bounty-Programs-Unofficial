import { network } from "hardhat";

const { viem } = await network.connect({
  network: "seiTestnet",
  chainType: "l1",
});

console.log("Sending transaction using the SEI testnet chain type");

const publicClient = await viem.getPublicClient();
const [senderClient] = await viem.getWalletClients();

console.log("Sending 1 wei from", senderClient.account.address, "to itself");

console.log("Sending transaction");
const tx = await senderClient.sendTransaction({
  to: senderClient.account.address,
  value: 1n,
});

await publicClient.waitForTransactionReceipt({ hash: tx });

console.log("Transaction sent successfully");
