# TypeScript idiom pack

Written against `_TEMPLATE.md`. Cite §2 authorities in findings. Like the Go and Rust packs, the value is less "teach TS" than to give findings a **citation**. It also encodes the **divergences** (§3) where general/other-language habits are *wrong* for TypeScript. Findings cite an authority plus, where one exists, a checkable **lint anchor** from §7.

Sections: §1 dimensions · §2 authorities · §3 divergences · §4 anti-patterns · §5 framework overlays · §6 severity model · §7 lint anchors. Grounded in the TypeScript Handbook, Google's style guide for TypeScript, typescript-eslint, and the `tsc` strict family.

> **Citing a lint anchor:** cite an `eslint`/`@typescript-eslint`/`tsc` anchor **only** from §7, and carry §7's two-part caveat. (a) Which **preset** the rule lives in: `recommended` / `recommended-type-checked` / `strict` / `stylistic` / off. (b) Whether it **requires type information** (`parserOptions.project`/`projectService`).
>
> **A type-checked rule silently does not run if the project has not wired typed linting.** It fails a build only when the project enables both the preset *and* type info. Never assert a rule name or its preset from memory. If §7 marks a dimension *judgment-only*, say so and cite the prose authority; do **not** fabricate a rule.
>
> Worked before/after pairs (loaded **on demand**): `examples-typescript.md`. Running `eslint`/`tsc` verified each lint-anchored pair, so the pairs show the §7 anchors, presets, and type-info status rather than assert them.

## 1. dimensions[]

| id | dimension | idiomatic rule | cue | authority |
|----|-----------|----------------|-----|-----------|
| T1 | Types & assertions | Prefer inference; annotate where it documents or localizes errors. `unknown` over `any` (`any` switches off checking and propagates). Avoid the non-null assertion `!` and `as` casts — narrow with a real guard; route a forced cast through `unknown`. Use lowercase primitives (`string`/`number`/`boolean`), never wrapper types (`String`/`Number`/`Object`/`{}`). `as const` to keep literal types. A `@ts-ignore`/`@ts-nocheck` suppression states its reason — prefer `@ts-expect-error` with a description. | `: any` / `as any`; `x!`; `as Foo` on an unvalidated value; `: String`/`: Object`/`: {}`; a widened literal that needed `as const`; a bare `@ts-ignore`. | TS Handbook: Everyday Types; Do's & Don'ts; Google TS: Type system; lint: `no-explicit-any`, `no-non-null-assertion`, `no-unnecessary-type-assertion`, `prefer-as-const`, `ban-ts-comment` (§7) |
| T2 | Null / undefined safety | Run with `strictNullChecks` (the `strict` family) so the caller must narrow `null`/`undefined` before use. Pick one of `null`/`undefined` per context; prefer an optional field `?` over a `\| undefined` union; keep `\| null`/`\| undefined` out of type aliases. Use `?.` / `??` over hand-rolled guards. | a possibly-nullish value used without narrowing; `x \|\| default` where the author means `??`; `null` and `undefined` both modeled for one concept. | TS Handbook: `strictNullChecks`, Narrowing; Google TS: Nullability; lint: `no-unnecessary-condition`, `prefer-nullish-coalescing`, `prefer-optional-chain`; tsc `strictNullChecks` (§7) |
| T3 | Discriminated unions & exhaustiveness | Model variants as a discriminated (tagged) union — a shared literal `kind` field lets the compiler narrow each branch. Prove exhaustiveness by assigning the residual to `never` (`const _: never = x`) so a new variant fails to compile. Prefer unions / `as const` objects over `enum`. | a struct-of-`Option`-flags with implicit rules; a `switch` over a union with no `never` default; an `enum` where a string-literal union fits. | TS Handbook: Discriminated unions, The `never` type, Exhaustiveness checking; lint: `switch-exhaustiveness-check`; tsc `noImplicitReturns`, `noFallthroughCasesInSwitch` (§7) |
| T4 | Async / Promises | Never leave a promise floating — `await`, `return`, `.catch()`, or explicit `void` every promise-valued statement. Do not pass a promise where the API expects a void/boolean (an `async` callback to `forEach`, a promise in an `if`). | `arr.forEach(async …)`; `doAsync();` as a bare statement; `if (promise)`; an unhandled `.then()`. | TS Handbook; typescript-eslint async docs; lint: `no-floating-promises`, `no-misused-promises`, `await-thenable`, `return-await` (all **type-info** — §7) |
| T5 | Functions & API surface | Do not annotate inferable internals; **do** type the *exported* boundary (args + return). No `any` in public signatures — `unknown` + narrow. Order overloads most-specific first; collapse trailing-optional and single-arg-type-difference overloads. Callback params required, not optional, just because callers may ignore them; a callback whose result is unused returns `void`. | `any` in an exported signature; an untyped public function; general overload before specific; `any` callback return type. | Do's & Don'ts: Function Overloads, Callbacks; Google TS; lint: `no-unsafe-*` family, `explicit-module-boundary-types` (off) (§7) |
| T6 | Immutability & data | `const` by default; `let` only when reassigned; never `var`. Mark fields never reassigned `readonly`; prefer `readonly T[]` for arrays a function does not mutate. Preserve literals with `as const`. | `let` never reassigned; a class field set once but mutable; a param array mutated in place. | Google TS: `readonly`, `const`/`let`; TS Handbook: Literal Inference; lint: `prefer-readonly` (type-info), `prefer-const` (off) (§7) |
| T7 | Modules & exports | ES modules (`import`/`export`); never `namespace`. **Named exports only** — no default exports (keeps import names uniform and refactor-safe). `import type` for type-only imports. | a `default export`; a `namespace`; a value-import used only as a type. | Google TS: Imports/Exports, Namespaces vs Modules; lint: `consistent-type-imports` (off) (§7) |
| T8 | Naming | `UpperCamelCase` types/classes/interfaces/enums; `lowerCamelCase` values/functions/properties; `CONSTANT_CASE` module-level consts & enum members. No Hungarian/decorative affixes — no `IFoo` interface prefix, no leading/trailing `_`, no `opt_`. | `IFoo`; `_private`; `opt_x`; a `snake_case` value. | Google TS: Identifiers, Naming style; lint: `naming-convention` (off, type-info, policy-configurable) (§7) |
| T10 | Error handling | Only `throw` `Error` instances (or subclasses) — never strings/objects. Treat a caught value as `unknown` (`useUnknownInCatchVariables`, in `strict`) and narrow before use. Model a meaningful error type, not a bare `string`. | `throw 'msg'` / `throw {code}`; `catch (e)` using `e` as `any`; control flow on string error messages. | Google TS: throw Error not strings, Catching errors; lint: `only-throw-error` (type-info); tsc `useUnknownInCatchVariables` (§7) |
| T11 | Testing | Black-box tests against the public module surface; no unused test scaffolding. Framework discipline (no focused/disabled tests, valid assertions) lives in the test plugin (`eslint-plugin-jest`/`vitest`), an opt-in dependency. | a test reaching into non-exported internals; a committed `it.only`/`describe.skip`; unused setup. | typescript-eslint; (framework rules: separate plugins); lint: `no-unused-vars` (§7) |

## 2. authorities[]

- **TS Handbook** — typescriptlang.org/docs/handbook — the canonical language reference (Everyday Types, Narrowing, Discriminated unions, Exhaustiveness). **Apache-2.0** (adapt w/ attribution; we paraphrase).
- **TS Handbook — Declaration "Do's and Don'ts"** — typescriptlang.org/docs/handbook/declaration-files/do-s-and-don-ts.html. Covers the wrapper-type ban, `any`→`unknown`, callback rules, overload ordering. **Apache-2.0**.
- **Google's style guide for TypeScript** — google.github.io/styleguide/tsguide.html — house idioms (assertions, `!`, nullability, named-exports-only, no-namespaces, naming, JSDoc, throw Error). **CC-BY-3.0** (adapt w/ attribution).
- **typescript-eslint** — typescript-eslint.io — the lint corpus + the `recommended` / `recommended-type-checked` / `strict` / `stylistic` config taxonomy; cite a rule **only from §7**. **MIT**.
- **`tsc` strict family** — typescriptlang.org/tsconfig — `strict`, `strictNullChecks`, `noImplicitAny`, `useUnknownInCatchVariables`, `noImplicitReturns`, `noUncheckedIndexedAccess`, `exactOptionalPropertyTypes`. Note which are/are not implied by `strict` (§7).
- **Effective TypeScript (Vanderkam)** — O'Reilly — **copyrighted, cite-only**: name an item's idiom in our own words, never reproduce its text. Every idiom it shares with this pack is independently grounded in the open sources above, so cite those.

## 3. divergences[] — where TS rejects general / other-language wisdom

Do **not** flag these.

- **Structural, not nominal, typing.** Compatibility is by shape, not declared name — do not expect a class/brand to gate assignability without an explicit brand. Do not recommend nominal-style wrappers as if the name enforced anything.
- **Do not reach for classes / inheritance by default.** Plain object types, unions, and functions are the default unit; classes are for genuine identity/encapsulation. Do not recommend an OOP hierarchy.
- **`enum` is not the default for a fixed set.** String-literal unions or `as const` objects are erasable and structurally checkable; Google TS disallows `const enum`. Do not recommend an `enum` reflexively, and do not flag a union-of-literals as "should be an enum."
- **Do not annotate what's inferable.** Redundant annotations on locals/returns are noise that drifts. Do not recommend adding a type the compiler already infers (except to document an exported boundary).
- **`namespace` is legacy for module code.** Use ES modules. Do not recommend `namespace` for organization.
- **`unknown`, not `any`, is the escape hatch.** Do not bless `any` as "I will type it later"; do not *suggest* `any` to silence an error.
- **Named exports over default exports.** Do not recommend a default export for "the main thing"; uniform named imports are the idiom (Google TS).
- **`===`/`!==`, with one sanctioned `== null`.** The lone idiomatic loose-equality is `== null` (catches both `null` and `undefined`). Do not flag `== null`; do prefer `===` elsewhere.

## 4. anti_patterns[]

- **`any` as a boundary type** — cue: `path: any`, `JSON.parse(x) as Config`. Rewrite: `unknown` + a validating narrow (schema or type guard). lint: `no-explicit-any` (§7).
- **Non-null assertion to dodge a check** — cue: `x!.foo`. Rewrite: narrow with a guard that proves non-null. lint: `no-non-null-assertion` (§7).
- **Unsound `as` cast** — cue: `as Config` on an unvalidated value (the assertion lies; no lint catches unsoundness). Rewrite: validate then narrow. Anchor: judgment (only `no-unnecessary-type-assertion` catches *redundant* casts) (§7).
- **Floating promise** — cue: a promise-valued statement not awaited/returned/handled/`void`-ed. Rewrite: `await`/`return`/`.catch()`/`void`. lint: `no-floating-promises` (type-info) (§7).
- **`async` callback to a void-callback API** — cue: `arr.forEach(async …)`. Rewrite: `for…of` with `await`, or `await Promise.all(arr.map(async …))`. lint: `no-misused-promises` (type-info) (§7).
- **Non-exhaustive switch over a union** — cue: a `switch` on a tagged union missing cases, no `never` default. Rewrite: handle every variant + `default: { const _: never = x; … }`. lint: `switch-exhaustiveness-check` (type-info); tsc `noImplicitReturns` (§7).
- **`throw` a non-Error** — cue: `throw 'msg'` / `throw {code}`. Rewrite: `throw new Error(...)` / a subclass. lint: `only-throw-error` (type-info) (§7).
- **`enum` where a union fits** — cue: a small fixed set as an `enum`. Rewrite: a string-literal union or `as const` object. Anchor: judgment (§3 divergence).
- **Default export** — cue: `export default`. Rewrite: a named export. lint: `consistent-type-imports` is unrelated; default-export is judgment / `eslint-plugin-import` (§7).
- **`namespace` for organization** — cue: `namespace Foo {}`. Rewrite: ES modules. Anchor: judgment.

## 5. framework_overlays[]

### Typed-linting precondition (applies to all type-info rules)

Not a framework so much as a config gate. It ranks above style because it determines whether half this pack's anchors run at all.

| id | rule | cue | consequence |
|----|------|-----|-------------|
| TC1 | The type-checked rules (all of T4, plus `no-unnecessary-condition`, `only-throw-error`, the `no-unsafe-*` family, `switch-exhaustiveness-check`, `prefer-readonly`, `naming-convention`) need `parserOptions.project`/`projectService`. | an eslint config using `recommended`/`strict` but **not** the `-type-checked` variant, or no `project` wired. | those rules **silently do not run** — a real defect (a floating promise, a non-Error throw) ships unflagged. If typed linting is absent, those dimensions fall back to **judgment-only**; say so. |

## 6. severity_model

- **correctness** — T4 floating/misused promise (unhandled rejection, lost ordering); T3 non-exhaustive switch that returns `undefined` (tsc `TS2366`). Also T10 `throw` non-Error (breaks `instanceof` handling) and untyped `catch` use; T1 `any` at a boundary / unsound `as` (defeats checking downstream).
- **idiom-divergence-with-consequence** — T1 non-null `!` (suppresses an unproven invariant); T2 missing nullish narrowing; T5 `any` in a public signature. Also T6 mutable-where-readonly; the type-checked-linting-absent gap (TC1).
- **style** — T7 default-export / import-type, T8 naming, T11, `prefer-const`/`as const`/`??`-vs-`||` presentation. Bundle these; never lead with them.

Profile note: this pack is **subordinate to the repo profile** (`package-profile.md`). A repo's documented convention (e.g. "we allow default exports for pages") or its eslint/tsconfig (which rules it enables) overrides any dimension here. Reconcile against the profile and the real config first.

## 7. lint_anchors[]

The machine-checkable rules behind the dimensions. **Cite a rule only from this table** — never assert a name or preset from memory. Two facts decide whether a finding fails a build: the **preset** the rule is in, and whether it **requires type information** (`parserOptions.project`).

**A type-checked rule silently does not run without typed linting** (TC1). Running the tools confirmed this: under plain `recommended` (no `project`), `no-floating-promises`/`no-misused-promises` do not fire; only `no-explicit-any` does. Where a dimension is **judgment-only**, there is no checkable rule — say so and cite the prose authority. Verified against **eslint 10.5 / typescript-eslint 8.x / tsc 6.0.3** (see `examples-typescript.md`).

| dimension | anchor(s) | source · preset | type info? | flags | caveat |
|---|---|---|---|---|---|
| T1 Types & assertions | `no-explicit-any`; `no-non-null-assertion`; `no-unnecessary-type-assertion`; `prefer-as-const`; `ban-ts-comment` | ts-eslint · `recommended` / `strict` / `recommended-type-checked` / `recommended` / `recommended` | no / no / **yes** / no / no | explicit `any`; the `!` operator; a redundant `as`/`!`; a literal cast that needs `as const`; `@ts-ignore`/`@ts-nocheck` with no description | `type` vs `interface` *choice* is **judgment-only**; `no-unnecessary-type-assertion` catches only *redundant* casts, never an *unsound* one |
| T2 Null safety | `no-unnecessary-condition`; `prefer-nullish-coalescing`; `prefer-optional-chain`; tsc `strictNullChecks` | ts-eslint · `strict-type-checked` / `stylistic-type-checked` / `stylistic` ; tsc strict | **yes** / **yes** / no / — | always-truthy/falsy condition; `\|\|` where `??` fits; `a && a.b` that should be `a?.b` | `prefer-optional-chain` is the one here needing no type info; the rest need `project` |
| T3 Exhaustiveness | `switch-exhaustiveness-check`; tsc `noImplicitReturns`; tsc `noFallthroughCasesInSwitch` | ts-eslint · **off (no preset)** ; tsc (both separate opt-ins, **not** in `strict`) | **yes** / — / — | a `switch` over a union missing cases; a code path that does not return; case fallthrough | union *design* is **judgment-only**; `switch-exhaustiveness-check` is in no preset — enable it yourself; the `never`-default pattern fails `tsc` with zero lint config |
| T4 Async / Promises | `no-floating-promises`; `no-misused-promises`; `await-thenable`; `return-await` | ts-eslint · `recommended-type-checked` / `recommended-type-checked` / `recommended-type-checked` / `strict-type-checked` | **yes** (all) | unhandled promise statement; promise passed to a void/boolean slot (`forEach(async …)`); `await` on a non-thenable; wrong `return await` | **all need type info** — if typed linting is off (TC1) none fire. `forEach(async)` is `no-misused-promises`, a bare unhandled promise is `no-floating-promises` |
| T5 Functions & API surface | `no-unsafe-argument`/`-assignment`/`-call`/`-member-access`/`-return`; `explicit-module-boundary-types` | ts-eslint · `recommended-type-checked` / **off** | **yes** / **yes** | `any`-typed values flowing through code; missing types on exported boundaries | `explicit-module-boundary-types` is off by default — cite only if the repo opted in; "type the public API" is otherwise judgment |
| T6 Immutability | `prefer-readonly`; `prefer-const`; `no-param-reassign` | ts-eslint · `strict-type-checked` ; eslint core · **off** / **off** | **yes** / no / no | a private field never reassigned, a `readonly` candidate; `let` never reassigned; a reassigned param | `prefer-readonly` covers class-private fields only; `prefer-const`/`no-param-reassign` are off-by-default in modern `eslint:recommended` — must opt in; readonly-array *preference* is judgment |
| T7 Modules & exports | `consistent-type-imports` | ts-eslint · **off (no preset)** | no | a type imported without `import type` | no type info needed but off by default; **default-export and module-surface taste are judgment-only** (`import/*` rules live in the separate `eslint-plugin-import`) |
| T8 Naming | `naming-convention` | ts-eslint · **off (no preset)** | **yes** | identifier casing/affix policy | enforces *your configured policy*, not a default; off by default; heavy. Naming *taste* beyond casing is judgment |
| T10 Error handling | `only-throw-error`; tsc `useUnknownInCatchVariables` | ts-eslint · `recommended-type-checked` ; tsc strict family | **yes** / — | `throw` of a non-Error; `catch` binding typed `any` | `only-throw-error` is the rename of the old `no-throw-literal`; needs type info. Error *taxonomy design* is judgment |
| T11 Testing | `no-unused-vars` (ts-eslint version) | ts-eslint · `recommended` | no | unused vars/imports/setup | use `@typescript-eslint/no-unused-vars`, disable the core one; test-framework rules live in separate opt-in plugins |

**Genuinely judgment-only — never fabricate a rule:** the `type`-vs-`interface` choice (T1), discriminated-union *design* (T3), `explicit` API-boundary typing when the rule's off (T5). Also readonly-array preference (T6), default-export dogma & module-surface taste (T7), naming taste beyond casing (T8), and Error-taxonomy design (T10). Cite the prose authority and say plainly no checkable rule exists.

**Provenance caveats (carry these when citing; running the tools verified each one):**

- The modern `eslint:recommended` (`@eslint/js`) is a *small* bug-catching set. Most suggestion/stylistic rules (`prefer-const`, `eqeqeq`, `require-await`) default to **off**.
- The entire type-checked rule family **needs `parserOptions.project` and silently does not run without it** (TC1). That family is T4, `no-unnecessary-condition`, `only-throw-error`, `no-unsafe-*`, `switch-exhaustiveness-check`, `prefer-readonly`, `naming-convention`.
- `only-throw-error` is the current name (was `no-throw-literal`). eslint deprecated core `no-return-await` in favor of `@typescript-eslint/return-await`.
- tsc `noImplicitReturns`/`noFallthroughCasesInSwitch` are **separate flags not implied by `strict`**.
- `switch-exhaustiveness-check`, `explicit-module-boundary-types`, `consistent-type-imports`, `naming-convention` are in **no preset** (opt-in).
- Default-on and safe to cite as build-failing *only if* the project enables the matching preset. The type-checked ones also need type info present.

## Language → specialist agent

The roster has no `typescript-specialist` agent today. For deep TS judgment calls beyond this pack, review on the pack + first principles and flag the gap. If TS work becomes common, a `typescript-specialist` is the un-defer.
