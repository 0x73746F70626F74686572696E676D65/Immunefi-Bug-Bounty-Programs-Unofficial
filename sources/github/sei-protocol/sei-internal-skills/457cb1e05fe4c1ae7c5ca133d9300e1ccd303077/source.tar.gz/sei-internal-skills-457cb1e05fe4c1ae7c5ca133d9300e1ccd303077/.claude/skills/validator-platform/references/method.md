# The method — operating & reviewing K8s-managed Sei validators for governance

Two modes, one spine. **Author** is the operator writing per-node SeiNodeTask manifests for a gov submit/vote. **Review** is a lens over existing gov manifests + the on-chain result. Both load the profile + kit first and judge against the platform's actual behavior before generic CRD/gov intuition. Both rank idempotency/double-submit + mainnet-adjacency hazards above style. The gates, fan-out template, fee-floor numbers, and mainnet allowlist belong to `/gov-ops` — this method **cites** them.

## The four stages

1. **Load the profile + the kit(s).** `sei-validator-profile.md` (always first — its behavior overrides generic CRD/gov habit) + the kit for the concern. The kits: `kit-platform-machinery` (the controller-behavior invariants), `kit-seinodetask-gov-manifests` (authoring the 3 gov kinds), or `kit-shadow-comparison` (driving a shadow `result-export` comparison against a shadow-ready node). If working *in* the controller / seictl repo, read its code at HEAD — the live repo wins over this snapshot; flag drift. The seinode-task LLD is loadable for the kind/lifecycle/idempotency contract **only** (STALE on topology + signing-topology — take those from §controller).
2. **Read the whole target.** Never reason about a sidecar task from a generic CRD mental model. Only gov kinds carry their result on `status.outputs`. The two submit kinds are submit-once. The CRD has no selector.
   - For review: the SeiNodeTask manifest(s), `spec.target.nodeRef.name`, the typed payload, and the `keyName` / operatorKeyring config. Also the per-node fan-out set and the **on-chain** state (proposalId / txHash via the `taskID=` memo).
   - For author: the SeiNode set to fan out across (no selector — one manifest per node). Also the kind's idempotency class and the signing key the ladder resolves.
   - For a **shadow `result-export`**: the comparison params (the `canonicalRpc` discriminator + the EVM/migration params, passed via the raw params map). Also the **S3 + Prometheus** result sink — not on-chain state.
3. **Apply the five dimensions** (below), profile-first. Each finding cites a `sources.md` anchor and/or a profile rule. Flag a genuinely-uncertain call rather than forcing it. Where a fact is `/gov-ops`'s (a gate, the fan-out template, the fee floor, the allowlist), cite `/gov-ops` — do not restate it.
4. **Rank + surface.** Idempotency/double-submit hazards (delete-recreate on a non-idempotent submit kind) and mainnet-adjacency lead; encoding traps and on-chain verification next. Structure/style go in one bundle. Refuse a delete-recreate retry on a submit kind; defer the mainnet refuse to `/gov-ops`.

## The five dimensions (the scorecard)

Grounded in the corpus (`sources.md`) and specialized by the profile. Kits map their review cues to these — always written as `Dimension N (name)`.

**Dimension 1 (Manifest correctness & encoding).** The discriminator `spec.kind` matches the payload sub-key (`govVote`/`govSoftwareUpgrade`/`govParamChange`). `keyName` lives inside the payload; `apiVersion` group is `sei.io`; fields are **camelCase**; typed numerics are JSON **numbers** — `proposalId` (`uint64`) and `upgradeHeight` (`int64`) carry no quotes; `option` is the lowercase enum.

The integer-as-JSON-string and double-encode rules apply to a **`GovParamChangeEntry.value`** only. A large-integer-valued **param** the chain expects as a JSON **string** is `"86400000000000"` not a bare number (its decode path loses precision above 2^53). A struct-valued param is a **JSON object**, not a double-encoded escaped string. The fee clears the floor. *Basis:* `sources.md` §controller (CRD payload shapes + the `GovParamChangeEntry.value` doc), §seictl (the `gov_*` handlers, `paramChange.Value`); the **fee floor is `/gov-ops`'s** — cite it, do not restate.

**Dimension 2 (Idempotency & recovery).** Reason per-kind: `GovVote` is chain-idempotent (last-write-wins on proposalId/voter) → re-apply safe. `GovSoftwareUpgrade` and `GovParamChange` are **submit-once**; `GovParamChange` higher-blast-radius. The pre-broadcast marker (seictl#219) makes a crash-window re-run of the **same** task adopt the prior tx. It does nothing for a new task.

**Re-apply re-joins** the run via the task-ID (UUIDv5). **Delete-recreate mints a new run → a duplicate submit + deposit** — refuse it on a submit kind. `requirePhaseTimeout` is **terminal** (a timed-out task does not retry). *Basis:* §controller (CRD idempotency comments, task-ID), §seictl (the pre-broadcast marker, seictl#219); profile.

**Dimension 3 (Context & mainnet-adjacency safety).** The kube-context targets the intended `(context, network, namespace)` triple; an arctic-1 task is not aimed at a context co-hosting pacific-1 mainnet. The **enforcement allowlist + co-host refuse is `/gov-ops`'s** — point at it, never restate a weaker prod-pattern rule. *Basis:* profile §8 (Safety — mainnet-adjacency); `/gov-ops` (the allowlist).

**Dimension 4 (Result verification).** **Gov** kinds read from `status.outputs.gov*` — the controller decodes `wire.GovTxResult` (`txHash`/`height`; `proposalId` on the submit kinds once committed, zero while pending; know `includedAt` semantics). The `taskID=` memo + chain query is the pending-case fallback. The **other sidecar kinds do not populate `status.outputs`** — **shadow `result-export`** reads the S3 comparison artifacts (`.compare.ndjson.gz` / divergence reports) + Prometheus metrics. *Basis:* §controller (`govoutputs.go`); profile §6; `kit-shadow-comparison` (the S3/Prom sink).

**Dimension 5 (Citation discipline).** Cite `/gov-ops` / the LLD / controller / seictl / sei-skill at their pins. Never restate a fact another skill owns — above all `/gov-ops`'s gates, fan-out template, fee floor, and mainnet allowlist. *Basis:* `sources.md`; SKILL.md Guardrail 2.

## Author discipline (when writing manifests, not just reviewing)

- Argue the **maximum scope you'd defend** (fan the submit/vote across exactly the intended SeiNode set, with the right kind/payload/key). Then name what you'd **cut first** and the condition that un-defers it — the orchestrator/human picks the minimum.
- A **submit kind** (`GovSoftwareUpgrade` / `GovParamChange`) is a one-way door: it broadcasts a real tx + deposit. Author it as submit-once; never delete-recreate to retry. Route the gates + fee floor through `/gov-ops`.
- Reach for the platform's *actual* behavior over a generic one. The CRD has **no selector** (one manifest per node — fan-out is yours). Gov results land on **`status.outputs.gov*`** (shadow reads S3/Prom — its `status.outputs` stays empty). The sidecar is reachable at **`:8443`** (the RBACProxyPort), not `7777`.
