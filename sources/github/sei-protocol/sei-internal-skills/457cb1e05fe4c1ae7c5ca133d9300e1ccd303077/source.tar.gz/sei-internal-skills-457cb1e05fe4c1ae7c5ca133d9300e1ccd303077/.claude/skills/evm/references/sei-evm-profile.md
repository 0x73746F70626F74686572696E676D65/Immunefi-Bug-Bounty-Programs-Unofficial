# Sei-EVM profile (always-first overlay)

Loaded before any contract design or review. It encodes **Sei's EVM execution environment** and **overrides generic Ethereum/EVM habit** — the way `/idiomatic`'s repo profile outranks generic idiom. Distilled (and cited) from `sei-protocol/sei-chain` (`/tmp/sei-arch/sei-chain`, repo `v6.1.12`) + the Sei docs (`/tmp/sei-arch/sei-docs`) at research time.

**Snapshot caveat:** a portable distillation for design + review. Sei is governance-tunable and fast-moving — gas params, min gas price, and supported features change by proposal/release. The live `x/evm/AGENTS.md` + the published Sei docs + a runtime query (`eth_estimateGas`, `eth_gasPrice`, `eth_chainId`) are authoritative; flag drift, do not follow a stale number.

**Direction (read first):** Sei is moving to **EVM-only** — Sei is deprecating the Cosmos-SDK / CosmWasm side. **Prop 115 already froze new CosmWasm uploads/instantiation** (the `wasmd` precompile's `instantiate` reverts at runtime). Anchor designs on the **EVM**: deploy new tokens directly as ERC-20/721/1155, treat CW↔ERC interop as legacy. Native-bank/IBC-denom→ERC20 representation still matters; CW20/CW721 pointers apply only to already-deployed CW tokens.

## The chain in one paragraph

Sei runs a **patched go-ethereum fork** (`github.com/sei-protocol/go-ethereum v1.15.7-sei-16`, *not* stock geth — `go.mod`) inside a Cosmos-SDK/Tendermint chain, at fork level **Cancun + Prague (Pectra), blobs excluded** (`x/evm/types/config.go:11-12`, `CancunTime=0`/`PragueTime=0`). Blocks are **~400 ms with instant finality** and **no pending state**. Native gas token is **SEI**, denominated **6-decimal `usei` natively but 18-decimal `wei` to the EVM** (a conversion bridge with sub-`usei` dust — `x/evm/AGENTS.md`). 13 **precompiles** (`0x…1001`–`0x…100C`, `0x…1011`) expose Cosmos modules to Solidity. Every account has a **dual 0x↔`sei1…` address** that needs an **association**; mainnet is `pacific-1` (EVM chain id **1329**), testnet `atlantic-2` (**1328**). The current `solidity-developer` agent's expertise is **generic EVM with no Sei specifics** — see the corrections below.

## Hard conventions (these override generic EVM habit)

1. **Instant finality, no pending state, no reorgs.** ~400 ms blocks; `latest`/`safe`/`finalized` all resolve to the same block; **`tx.wait(1)` is final** — confirmation-depth / reorg-handling logic is dead code here. Sei has **no pending state** (the proposer broadcasts before executing). Hence `eth_getBlockByNumber("pending")` → latest/null, pending nonce == confirmed nonce, and **pending-tx filters/subscriptions are unreliable** — never gate logic on them. *Cited:* sei-docs `evm/evm-parity/finality.mdx`, `evm-compatibility.mdx`; `x/evm/AGENTS.md`.

2. **Gas is governance-tunable — estimate at runtime, never hard-code.** No base-fee burn (all fees → validators). Always `eth_gasPrice` / `eth_estimateGas`.
   - EIP-1559 works but with Sei-specific min/max bounds recomputed each block. Legacy txns must clear a **governance-set minimum gas price** (docs cite ~50 gwei mainnet at research time). *Verify-before-print: query `eth_gasPrice` at runtime, never print as a constant*.
   - **SSTORE set-gas is a Sei chain param** (`SeiSstoreSetGasEIP2200`, default `20000` in code — `x/evm/types/params.go:43`), **not** the fixed-20k Ethereum constant. Governance set it higher on mainnet (~72k per docs).
   - **The EVM module has no block-level gas limit** — limits are per-transaction only (`x/evm/AGENTS.md`). *(Verify-before-print: the docs cite a 12.5M "block gas limit"; the EVM module enforces none — reconcile against the live chain, treat per-tx as the model.)* *Cited:* `x/evm/types/params.go:43`, `x/evm/config/config.go:26`, `x/evm/AGENTS.md`, sei-docs `evm/evm-parity/gas-and-fees.mdx`, `differences-with-ethereum.mdx`.

3. **These opcodes diverge — generic assumptions are wrong here.** `block.prevrandao`/`PREVRANDAO` **derives from block time, NOT randomness** — never use it for entropy (use a VRF — Pyth Entropy). `COINBASE` is the **global fee-collector**, not the proposer. `BLOCKHASH` is the **hash of the Tendermint header** (different encoding, recent-blocks-only). `BASEFEE` carries no burn; **refactor `SELFDESTRUCT` out** (soft-close pattern). *Cited:* sei-docs `evm/differences-with-ethereum.mdx`.

4. **Proofs are IAVL, not MPT.** State is a single global AVL tree with no per-account state root; **`eth_getProof` returns IAVL proofs** — **incompatible with standard Ethereum MPT verifiers**. Any design relying on Merkle-Patricia state proofs (cross-chain light clients, storage-proof verifiers) does not work unmodified. *Cited:* sei-docs `evm/differences-with-ethereum.mdx`, `evm-compatibility.mdx`.

5. **Dual 0x↔bech32 address + mandatory association.** One secp256k1 key → an EVM `0x…` (keccak) and a Cosmos `sei1…` (bech32) address. **Before association they are separate accounts with separate balances**; the chain blocks transfers across the VM boundary to an unassociated counterpart. Association is **permanent and one-to-one** (via the `addr` precompile `0x…1004` or implicitly by signing any tx).
   - The **`CanAddressReceive` trap.** A direct-cast Sei address **may not receive bank funds once its cast EVM origin holds an association** with a true pubkey-derived address (`x/evm/keeper/address.go:78-86`). A native send to a stale cast address can revert.
   - **HD-path trap:** EVM uses BIP-44 coin type **60**, Cosmos uses **118** — the same mnemonic yields different accounts.
   - `getSeiAddr` **reverts** if unassociated (surface as "not linked"). *Cited:* `x/evm/keeper/address.go:10-100`, `x/evm/AGENTS.md`, sei-docs `learn/accounts.mdx`.

6. **`usei`(6) ↔ `wei`(18) boundary has dust.** EVM-facing balances are 18-decimal; native is 6-decimal; the StateDB bridge tracks a sub-`usei` `wei` remainder. **Precompile value args mix decimals** — for example, `staking.delegate()` takes `msg.value` in 18-dec wei but **truncates to 6-dec `uSEI`** (must be a multiple of `1e12` wei). `undelegate`/`redelegate` take 6-dec `uSEI`; read the precompile interface for each method's decimal contract. Payable precompiles **suppress transfer events** to avoid double-counting. *Cited:* `x/evm/AGENTS.md`, sei-docs `evm/precompiles/staking.mdx`.

7. **Failure-receipt semantics differ.** A tx can fail **before** the EVM (during ante). A **nonce-mismatch produces NO receipt**; other ante failures produce a **status-0 receipt** (nonce already incremented). Indexers/agents must handle both — "no receipt" ≠ "tx never happened." *Cited:* `x/evm/AGENTS.md`.

8. **Dual execution env — non-EVM txns mutate EVM-visible state, and a bloom filter drops cross-VM logs.** Native/bank txns change EVM-visible balances **with no EVM tx or log**. Cross-VM activity emits **synthetic receipts/logs**, but a **separate EVM-only bloom filter EXCLUDES CW-originated logs**. A naive `eth_getLogs`/topic-filter consumer can therefore **silently miss** cross-VM events. This is the dominant on-chain-event-receipt trap (see `kit-evm-indexing-events`). *Cited:* `x/evm/AGENTS.md`.

9. **Precompiles expose Cosmos modules to Solidity (fixed addresses).** `0x…1001` bank · `1002` wasmd *(instantiate reverts — Prop 115)* · `1003` json · `1004` addr · `1005` staking · `1006` gov · `1007` distribution · `1008` oracle *(deprecated — use Pyth/Chainlink)* · `1009` ibc · `100A` pointerview · `100b` pointer · `100C` solo · `1011` p256 (RIP-7212). Each ships a published Solidity interface `.sol` in `precompiles/<name>/`. Note the **non-contiguous gap** (…1009, 100A, 100b, 100C, then 1011). *Cited:* `precompiles/setup.go:48-60`, the per-precompile `*.go`/`.sol`.

10. **Parallel execution (OCC) is internal — no Solidity-facing knob, one design implication.** Txns run optimistically against a multi-version store, then validate; conflicts re-run, sustained conflict falls back to sequential (`sei-cosmos/tasks/scheduler.go`). Contract authors get **no API** to control it. The only actionable implication: **contracts that contend on the same hot state (same recipient, same storage slot, a global counter) conflict and serialize, losing parallelism**. Spread writes across independent state; do not overstate beyond this. *Cited:* `sei-cosmos/tasks/scheduler.go:27-44`, `occ_tests/messages/test_msgs.go:62-78`.

## The agent boundary

- **solidity-developer** (this skill): EVM contract design/review + Sei-EVM specifics + Foundry tooling + on-chain-event indexing for agentic consumers.
- **idiomatic-reviewer** (`/idiomatic` Solidity pack): Solidity **idiom** — CEI *form*, explicit visibility, custom-error style, lint anchors. This skill does **not** re-litigate idiom; it owns the Sei-domain + secure-design *method*.
- **security-specialist**: deep **adversarial exploit audit** + severity/exploitability verdicts. This skill flags secure-design-time patterns and hands the exploit-depth call to security-specialist (same deferral the idiom pack uses).
- **sei-network-specialist**: Sei node P2P/RPC/ports. This skill is contract-layer.

## Stale-agent corrections (modernize / Sei-correct the old persona)

The old `solidity-developer` bullets are generic and partly stale — correct them:

- **Security taxonomy:** the **SWC Registry is unmaintained (frozen 2020)** — use it only as historical IDs. The current authority is **EEA EthTrust Security Levels v3** (Mar 2025) + Trail of Bits `building-secure-contracts`/Slither. (`sources.md` §ethtrust, §swc.)
- **OZ:** target **OpenZeppelin v5** (custom errors, `Ownable(initialOwner)`, `Counters`/`SafeMath` removed, `AccessManager`, **ERC-7201 namespaced storage**). A **v4→v5 proxy upgrade is storage-incompatible and can brick a live proxy** (`sources.md` §oz, §erc7201).
- **Solidity:** target `^0.8.20` min (OZ v5 floor); `0.8.27+` for `require(cond, CustomError())` and transient storage (EIP-1153). The `erc7201` builtin landed later (0.8.35 per release notes — `soliditylang.org` unverified, see `sources.md` §solidity) (`sources.md` §solidity).
- **Sei-specific (none of which the old persona knows):** PREVRANDAO is not random (use VRF); gas/SSTORE/min-gas are governance-mutable (estimate at runtime). Proofs are IAVL not MPT; no pending state; a bloom filter drops cross-VM logs. Addresses are dual + must associate; precompiles mix `usei`/`wei` decimals; `SELFDESTRUCT` is out. All cited in the hard conventions above.
