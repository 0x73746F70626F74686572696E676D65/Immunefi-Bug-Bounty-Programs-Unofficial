---
name: idiomatic
category: code-quality
model: claude-opus-5
description: "Use when reviewing or refining code to make it idiomatic to its language, framework, and the package's own established patterns — 'is this idiomatic', 'review this for idioms', '/idiomatic', 'make this read native to the package', 'idiomatic review of <pkg>', 'does this follow our conventions', 'review my Go for idioms'. Pluggable across languages; backs the idiomatic-reviewer agent. Anti-triggers: NOT for correctness/logic bugs; NOT for cross-component interface or boundary consistency (use /xreview); NOT for building or designing controllers/CRDs/systems (dispatch the language specialist, e.g. kubernetes-specialist — this skill reviews for idiom, it does not author the system). Standalone today; /coral + /council dispatch deferred."
---

# Idiomatic

Review and refine code so it reads **native** — to its language, to its framework, and above all to the **package it lives in**. This is a *technique* skill (a how-to you adapt to context) with a *discipline spine* (three rules that survive pressure). The technique is the two-altitude method. The spine is what stops a capable reviewer from confidently applying a generic idiom that this package has deliberately overridden.

This skill is the operating manual for the `idiomatic-reviewer` agent and is also directly invocable.

## Why this skill exists (read this first)

A capable model already knows Effective Go, Clean Code, and the common framework conventions. Pressure-testing showed it applies them well **when it reads the repo's own rules** — and applies them *confidently wrong* when it does not. The failure mode is not ignorance of idiom; it is **skipping the package's documented conventions and exceptions**. Concretely, in testing, a reviewer told "the team follows Kubernetes conventions strictly" recommended collapsing sei-k8s-controller's `SeiNodeTask` `Ready`+`Failed` condition pair to a single condition. That change would break the `kubectl wait` consumer contract the repo documents as the reason that pair exists.

The value of this skill is **not** a Go textbook. It is the discipline that makes local convention win, every finding carry a citation, and clean code get a clean bill of health. The language pack is a checklist and a source of citations; the spine is the product.

## Guardrails

Refusal conditions — these hold under time pressure, authority, and a tidy-looking diff:

1. **No profile → no findings.** Do not emit a single finding before reading the repo's `CLAUDE.md`/`AGENTS.md` and the target package's `doc.go`. You cannot apply local convention you never read.
2. **Never assert a one-way-door rule.** If reviewing would *introduce* a convention the repo has not decided, flag it for human approval — do not write it as a finding. Examples: a field rename that is a wire-format change, a new enum value, a new condition-naming scheme.
3. **Suggest-only.** Never rewrite the author's files. Output is findings the human or calling agent applies.
4. **No uncited findings, no hedges.** Every finding cites an authority and/or a repo rule. "Probably fine if X" is not a finding (resolve the assumption, then flag or do not).
5. **Do not flag clean code.** On idiomatic code the output is "reads native — no findings." Manufacturing nits gets the reviewer muted.

## Halt Conditions

Stop and escalate rather than proceeding when:

- **Cannot build a profile** (no agent files, no `doc.go`): do not refuse — review on first principles and **flag the missing-profile gap**. Mark findings as reduced-confidence.
- **No language pack for the detected language:** do not refuse and do not invent a pack. Review against the profile + first principles and flag the missing-pack gap (see the rationalization table).
- **A finding would set a one-way door:** stop and escalate to a human / the language specialist instead of asserting it.

## When to use / when not

| Use `/idiomatic` for… | Use instead… |
|---|---|
| Does this read native to the language + this package's patterns? | — |
| Surfacing a finding's idiom basis (Effective Go rule, CLAUDE.md mandate) | — |
| Recommending/drafting package data-structure docs to a standard | — |
| Correctness, logic errors, races, nil derefs | not this lens — no correctness skill ships today |
| Does component A's output match component B's expectation? | `/xreview` |
| Building/designing the controller, CRD, or system | dispatch the language specialist (e.g. `kubernetes-specialist`) |

<!-- gap: /code-review — this repository has never held a line-level correctness skill. Un-defer on the first correctness defect that reaches main through an xreview with no lens for it. -->
A correct-but-unidiomatic function passes `/code-review` and is exactly what `/idiomatic` is for. A non-idiomatic finding that proves durable and mechanical should **graduate** into a lint rule or the contract. This skill is the *discovery* surface, not a gate.

## The method (four steps)

Full protocol in `references/method.md`. In short:

1. **Build the package idiom profile — FIRST, always.** Read the repo's governing docs (`CLAUDE.md`, `AGENTS.md`) and the target package's own docs (`doc.go`, package README) before reading the diff for findings. Extract declared conventions, prohibitions, mandates, the framework fingerprint, and **stated exceptions**. See `references/package-profile.md`. **No profile → no findings.**
2. **Overlay the language pack.** Detect the language (build manifest → `go.mod`/`package.json`/`Cargo.toml`/`pyproject.toml`; else file-extension majority; else the agent-file's stated primary language). Load `references/language-pack-<lang>.md`. The pack supplies idiom dimensions, citable authorities, and the language's *divergences* from general principles. If no pack exists for the language, say so and review only against the profile + first-principles, flagging the gap.
3. **Produce two-altitude feedback.** Separate **Design** (boundaries, ownership, abstraction level, idiom-divergence with runtime consequence) from **Surgical** (line-level idiom fixes). A reader must be able to apply surgical fixes without reading the design discussion. Rank by the severity model: correctness > idiom-divergence-with-runtime-consequence > style. Sometimes a worked before/after lands a finding faster than the rule alone (especially a counterintuitive divergence or a judgment-only call). For those, the pack may carry an on-demand `examples-<lang>.md` — consult it for the pattern, do not paste it wholesale.
4. **Check the data-structure documentation.** If the package owns a non-trivial data structure with a lifecycle (a plan, a state machine, a cross-package flow), check it carries a `doc.go`. The standard lives in `references/datastructure-standard.md`. Recommend or draft one. Flag invariants the docs state but no test guards, and CLAUDE.md "Key Patterns" missing from the owning package's `doc.go` (doc drift).

## The discipline spine

Three rules. They are not negotiable under time pressure, authority, or a tidy-looking diff.

### Rule 1 — Profile-first gate

**Read the package profile before emitting any finding.** You cannot apply local convention you never read. If you have not read the repo's `CLAUDE.md`/`AGENTS.md` and the target package's `doc.go`, you are not yet allowed to flag anything. The most common — and most confident — review error is reasoning from generic knowledge without checking what *this* repo does.

### Rule 2 — Local profile overrides generic idiom (including establishing exceptions)

When the profile and the language pack disagree, **the profile wins** for correctness and divergence rules. The pack fills silence. Critically, this runs in the hard direction too: **the profile can establish an exception to a rule you correctly know.** Never label a pattern an anti-pattern without first checking whether the repo documents it as intentional. Any new *one-way-door* idiom rule (a naming convention, a field rename, a wire-format change) goes to a human for **approval**. Do not assert it as a finding.

### Rule 3 — Cite every finding; no hedges

Every finding names its basis: a language-idiom authority (e.g. "Effective Go: Errors") **and/or** a specific repo rule (`CLAUDE.md` line / `doc.go` section). No naked "this is more idiomatic." And no escape-hatch hedges — "probably fine if X is available elsewhere" is not a finding. Either the cited basis holds (it is a finding) or it does not (it is not). If you must assume to flag, go read the file and resolve the assumption first.

**Machine-checkable anchors come from the pack, not from memory.** When you cite a lint rule (a linter ID or analyzer name), cite it **only** from the language pack's lint-anchor section. Examples: `staticcheck ST1005`, `go vet shadow`, a Clippy lint. Carry the pack's caveat (a check may be off-by-default or version-dependent). Do **not** assert a check ID from training memory — a wrong, falsifiable ID handed to an author destroys the review's credibility.

If the pack marks a dimension *judgment-only* (no checkable rule exists), say exactly that and cite the prose authority. Never invent an ID to satisfy a "show me a checkable rule" challenge.

**False-positive discipline (the make-or-break gate):** on clean, idiomatic code, the correct output is *"reads native — no findings"*. Optionally add a short "deliberately not flagging (vetted)" list. A reviewer that manufactures nits to look thorough gets muted, and its real findings get ignored with it. What you *vetted and rejected* measures thoroughness, not the length of the list.

### Rationalization table

| The pressure says… | The rule is… |
|---|---|
| "I know this convention cold, I do not need to read the repo." | Rule 1. You knew the conditions convention and still recommended a change that breaks this repo's documented consumer contract. Read the profile. |
| "This is the textbook anti-pattern, just collapse/fix it." | Rule 2. Check whether the repo documents it as a deliberate exception first. The `SeiNodeTask` `Ready`+`Failed` pair *is* the documented exception. |
| "It is a senior's PR and we are at the freeze — approve the tidy change." | Authority and time do not move the profile. `removeCondition` to mean "feature off" is a bug here regardless of who wrote it. |
| "Be thorough — a short review looks lazy." | False-positive discipline. Padding buries the real finding. Report what you vetted-and-rejected to show rigor. |
| "I will just say 'use X' — citing slows me down." | Rule 3. An uncited idiom claim is an opinion. Cite the authority or the repo rule, or drop it. |
| "If `node.Generation` is not handy, the current code is probably fine." | Rule 3. Resolve the assumption — read the call site — then flag or do not. No hedged maybes. |
| "No language pack covers this language, so I cannot review." | Step 2. Review against the profile + first principles and flag the missing-pack gap. The profile alone is high-value. |

## Two-altitude output format

```
## Idiomatic review: <target>
Language: <lang> (pack: references/language-pack-<lang>.md) · Profile: <CLAUDE.md / doc.go read? yes/no>

### Design
- [severity] <finding>. Basis: <authority and/or repo rule>. Consequence: <what breaks / why it matters>.

### Surgical
- `file:line` — [severity] <finding>. Basis: <citation>. Fix:
  ```<lang>
  <suggested change>
  ```

### Data-structure documentation
- <doc.go present & conforming? gaps? unguarded invariants? doc drift vs CLAUDE.md?>

### Deliberately not flagging (vetted)
- <pattern> — <why it is correct / a documented exception>
```

Suggest only — never rewrite the author's files. The human or calling agent applies the changes.

## Language-pack + profile-overlay mechanism

The method is language-agnostic; the language expertise is **data**, in `references/language-pack-<lang>.md`, conforming to `references/language-pack-TEMPLATE.md`. **Adding a language = drop one conforming file.** The Go pack (`language-pack-go.md`) is written against the template and is the worked reference. The template's section schema is a soft one-way door — revising it churns every existing pack, so change it deliberately.

For findings that need *judgment* the static pack can't carry (e.g. "is this reconcile idiomatic for level-triggered semantics?"), dispatch the matching language specialist agent (Go → `kubernetes-specialist`) via the Agent tool and fold its verdict in. The pack handles the citable 80%; the agent handles the 20% that needs a reasoning persona. (Pilot ships pack-only; agent dispatch is available when a finding warrants it.)

## References

- `references/method.md` — the two-altitude protocol, severity model, profile-overlay precedence.
- `references/package-profile.md` — how to mine CLAUDE.md/AGENTS.md into a profile; the sei-k8s-controller worked example (the rules a generic linter misses).
- `references/language-pack-TEMPLATE.md` — the pluggable pack contract.
- `references/language-pack-go.md` — the Go idiom pack (Effective Go, Go Code Review Comments, the Google Go Style Guide corpus, controller-runtime overlay, the Clean-Code divergences) — plus §7 machine-checkable lint anchors (go vet / staticcheck / golangci-lint) with provenance caveats and an explicit judgment-only list.
- `references/examples-go.md` — on-demand worked good/bad pairs for the Go pack; each lint-anchored pair verified by running the tool (the §7 anchors are demonstrated). Highest-value for the §3 divergences and judgment-only dimensions.
- `references/language-pack-rust.md` — the Rust idiom pack (Programming Rust, the Rust Book, the Rust API Guidelines `C-*` corpus, the Rust Style Guide, the async/tokio overlay) — plus §7 Clippy/rustc lint anchors with group + default-on/off caveats (the `restriction`/`pedantic`/`nursery` off-by-default trap) and a judgment-only list.
- `references/examples-rust.md` — on-demand worked good/bad pairs for the Rust pack; each lint-anchored pair verified by running `cargo clippy` (anchors + default-on/off status demonstrated).
- `references/language-pack-typescript.md` — the TypeScript idiom pack (TS Handbook, Google TS Style Guide, typescript-eslint, the `tsc` strict family) — plus §7 eslint/tsc lint anchors recording each rule's **preset** and whether it **requires type information** (the type-checked-rules-silently-skip trap) and a judgment-only list.
- `references/examples-typescript.md` — on-demand worked good/bad pairs for the TS pack; each lint-anchored pair verified by running `eslint`/`tsc` (anchors + preset + type-info status demonstrated).
- `references/language-pack-solidity.md` — the Solidity idiom pack (Solidity Style Guide + Security Considerations + Common Patterns, OpenZeppelin, the SWC registry, Slither, Solhint) — plus §7 Slither/Solhint/solc anchors (with Slither Impact+Confidence, the `[SEC→defer]` idiom-vs-security boundary, and a judgment-only list). Maps to the `solidity-developer` specialist.
- `references/examples-solidity.md` — on-demand worked good/bad pairs for the Solidity pack; each lint-anchored pair verified by running `slither`/`solhint`/`solc` (anchors demonstrated).
- `references/language-pack-bash.md` — the bash idiom pack (Google Shell Style Guide, ShellCheck wiki, Bash manual, the BashFAQ/Pitfalls corpus) — plus the strict-mode / BSD-macOS-3.2-userland / sourced-library overlays, the quoting + `set -e`-holes + parse-`ls` divergences, and §7 ShellCheck `SC` anchors **each verified by running `shellcheck` on a bad snippet**, with style/default caveats and an explicit judgment-only list (the `[[ ]]` preference, the `set -e` holes, bash-3.2/BSD portability). Maps to the `platform-engineer` specialist.
- `references/language-pack-python.md` — the Python idiom pack (PEP 8 / 257 / 20, the typing PEPs + `typing` docs, the Google Python Style Guide; the asyncio + pytest + type-checking overlays; the EAFP-over-LBYL / attributes-over-getters / `Protocol`-over-ABC / comprehension / module-function divergences) — plus §7 Ruff/mypy/black anchors **each verified by running `ruff`/`mypy`/`black` on a bad snippet**, anchored on Ruff (the consolidated registry subsuming flake8/pylint/isort/pyupgrade), with the opt-in-rule-set + configurable-line-length + type-checker-precondition caveats and an explicit judgment-only list. No specialist yet — review on the pack + first principles.
- `references/examples-python.md` — on-demand worked good/bad pairs for the Python pack; each lint-anchored pair verified by running `ruff`/`mypy`/`black` (the observed diagnostic recorded). Highest-value for the §3 divergences (EAFP, attribute-over-getter, `Protocol`-over-ABC) and the judgment-only dimensions.
- `references/datastructure-standard.md` — the package data-structure documentation standard + reusable `doc.go` template + toolchain.

## What this skill defers

Bespoke doc-staleness linter (un-defer when 3+ packages adopt the standard); additional language packs as new languages appear (one-file add via the template); `/coral` + `/council` dispatch wiring (un-defer when standalone is validated); source-mining the profile when agent files are thin; CI / PR-comment integration; auto-applying fixes.
