# Code safety & quality

Checklist for defensive, resource-bounded construction in code that must stay correct over its lifetime. Our-own-words items (they *summarize* TIGER STYLE and Power-of-Ten ideas, never restate them); cite the authority (see `sources.md`).

**Scope note — this is the *systems-safety* slice only.** General code-craft that belongs to other lenses is deliberately out. Idiom/naming/control-flow → `/idiomatic`; small-functions / check-every-return / test-size discipline → `/idiomatic` (the language pack's testing + error dimensions). Code-review norms (small CLs, approve-to-unblock, review latency) → the cited Google Engineering Practices. Comment and documentation discipline → the AGENTS.md contract (Output discipline). This file keeps only the rows that are distinctly about *systems safety under failure and load*.

Sections: `## checklist` · `## severity model`. Anchors: TigerBeetle TIGER STYLE, NASA/JPL Power of Ten. Companion: `performance.md` (bounded concurrency), `api-design.md` (validate at the boundary).

## checklist

| id | principle | rule | cue | authority |
|----|-----------|------|-----|-----------|
| SAFE1 | Assert invariants, in pairs | State what must be true and check it. Where it matters, confirm the same invariant from two independent paths so a single wrong assumption cannot pass silently. Assertions catch the impossible before it corrupts state. | A critical invariant trusted but never checked; a computed result used with no sanity check. | TigerBeetle: TIGER STYLE |
| SAFE2 | Bound every loop and buffer | Give every loop, queue, and buffer an explicit upper limit. A bad input or runaway condition then fails fast instead of spinning or growing without end. | A loop with no provable termination bound; an unbounded slice/queue that grows with input. | NASA/JPL: Power of Ten |
| SAFE3 | Fixed memory on the hot path | On hot or long-running paths prefer statically sized / pre-allocated memory over per-operation dynamic allocation. Predictable footprint, no fragmentation or alloc-time surprise under load. | Repeated allocate/free in a steady-state loop; growth that depends on untrusted size. | TigerBeetle: TIGER STYLE |
| SAFE4 | Minimize dependencies | Each dependency is attack surface, supply-chain risk, and a version to track. Pull one in only when it out-earns the code you'd otherwise write by a wide margin. | A new third-party import to save a few lines; a heavy lib used for one trivial call. | TigerBeetle: TIGER STYLE |
| SAFE5 | Validate input at the trust boundary | Validate data crossing any trust boundary (args, network, files, config) at the point of entry, before use — assume nothing about shape, size, or range. | A request/file/env value used without range/shape checks; a size taken on faith. | TigerBeetle: TIGER STYLE |
| SAFE6 | No unbounded recursion in critical paths | In safety- or availability-critical code, avoid recursion (and indirection) with no depth bound. The call graph then stays statically traceable and adversarial input cannot blow the stack. *(Advisory outside genuinely critical/hostile-input code — bounded recursion is fine in ordinary services.)* | Recursion with input-dependent depth on a path exposed to untrusted data. | NASA/JPL: Power of Ten |

## severity model

- **correctness/safety** — SAFE1 (unchecked invariant corrupts state), SAFE2 (unbounded loop/buffer → hang or OOM), SAFE5 (unvalidated input → corruption or injection). Defects, not preferences; lead with them.
- **consequence-under-load** — SAFE3 (alloc on the steady-state path), SAFE6 (unbounded recursion can blow the stack on adversarial input). Bite under volume or hostile input.
- **advisory** — SAFE4 (dependency hygiene). Real and worth enforcing; bundle, do not lead with it over a correctness finding.
