# Solidity idiom pack

Written against `_TEMPLATE.md`. Cite §2 authorities in findings. Like the Go/Rust/TS packs, the value is to give findings a **citation**. It also encodes the **divergences** (§3) where older Solidity habits are *wrong* for modern (≥0.8) Solidity. Findings cite an authority plus, where one exists, a checkable **lint anchor** from §7.

**Idiom vs. security — read this first.** This is an *idiom* lens. Some Solidity idioms are also security-critical (reentrancy ordering, access control, checked external calls). This pack flags the **idiomatic form** of those (CEI ordering present, visibility explicit, `msg.sender` for auth, return value checked) and cites the detector. But it **defers the exploit-depth verdict to `security-specialist`**.

A §7 row marked **[SEC→defer]** means: surface the idiomatic finding and the detector, then hand the severity/exploitability call to a security review. Do not present this pack as a security audit.

Sections: §1 dimensions · §2 authorities · §3 divergences · §4 anti-patterns · §5 idiom-vs-security overlay · §6 severity model · §7 lint anchors. Grounded in the Solidity Style Guide + Security Considerations + Common Patterns, OpenZeppelin Contracts, the SWC registry, Slither, and Solhint.

> **Citing a lint anchor:** cite a Slither detector / Solhint rule / solc warning **only** from §7. For Slither, **all detectors run by default** — weight a finding by its **Impact + Confidence** (in §7), do not treat every detector as equally blocking. For Solhint, cite whether the rule is in **`solhint:recommended`** (most idiom rules are `warn`; only `compiler-version`/`no-console`/`quotes` are error-level). Never assert a detector/rule name from memory. If §7 marks a dimension *judgment-only*, say so and cite the prose authority; do **not** fabricate a detector.
>
> Worked before/after pairs (loaded **on demand**): `examples-solidity.md`. Running `slither`/`solhint`/`solc` verified each lint-anchored pair, so the §7 anchors rest on demonstration, not assertion.

## 1. dimensions[]

| id | dimension | idiomatic rule | cue | authority |
|----|-----------|----------------|-----|-----------|
| S1 | Checks-Effects-Interactions & reentrancy | Update state **before** any external call; treat every external call as able to re-enter. CEI is the primary idiom; a `nonReentrant` guard is defense-in-depth, not a substitute for ordering. | a state write *after* a `.call`/transfer; reaching for `ReentrancyGuard` while leaving the state update last. | Solidity Security Considerations (CEI / Reentrancy); SWC-107; lint: `reentrancy-eth`, `reentrancy-no-eth` **[SEC→defer]** (§7) |
| S2 | External calls | Check the return of every low-level `call`/`send`/`delegatecall` (they return `false`, do not revert). Prefer a typed interface call or a library over raw `.call`; **pull over push** for payouts. Never `delegatecall` an untrusted callee. | `(bool ok,) = …call(…)` with `ok` unchecked; raw `.call`/`.send`; pushing ether in a loop. | Security Considerations; Common Patterns (withdrawal); SWC-104/112/113; lint: `unchecked-lowlevel`, `unchecked-send`, `low-level-calls`, Solhint `avoid-low-level-calls`, `check-send-result`, `no-unused-vars` (§7) |
| S3 | Visibility & access control | Declare visibility explicitly on every function and state variable. Gate privileged operations behind an access modifier (`onlyOwner`/role). Authenticate with `msg.sender`, never `tx.origin`. Validate address inputs against zero. | implicit visibility; an ungated setter/withdraw/`selfdestruct`; `tx.origin ==`; an `address` arg set with no zero-check. | SWC-100/105/106/115; Common Patterns (restricting access); OpenZeppelin Ownable/AccessControl; lint: `suicidal`, `unprotected-upgrade`, `missing-zero-check`, `tx-origin` **[SEC→defer]**, Solhint `state-visibility`, `func-visibility`, `avoid-tx-origin` (§7) |
| S4 | Custom errors over `require`-strings | Since 0.8.4 prefer a named `error` + `revert MyError()` over a long `require("…")` string — cheaper and machine-decodable. | `require(cond, "long string")` / `revert("string")` in ≥0.8.4 code. | OpenZeppelin v5 (library-wide custom-error migration); Solidity 0.8.4 release; lint: Solhint `gas-custom-errors`, `reason-string` (§7) |
| S5 | Arithmetic | On ≥0.8.0 arithmetic reverts on overflow by default — **no SafeMath**. Use an explicit `unchecked { }` block only where you intend wrap-around and prove it safe. Avoid divide-before-multiply precision loss. | `using SafeMath` on ≥0.8; an `unchecked` block whose safety is not argued; `a / b * c`. | Security Considerations (overflow); SWC-101; lint: `divide-before-multiply` (§7) |
| S6 | Token interactions | Wrap ERC-20 `transfer`/`transferFrom`/`approve` in `SafeERC20` — non-standard tokens return `false` or nothing instead of reverting. Check the return either way. | a bare `token.transfer(...)` with its return unchecked; raw `approve` race. | OpenZeppelin SafeERC20; SWC-104; lint: `unchecked-transfer`, `arbitrary-send-erc20` **[SEC→defer]** (§7) |
| S7 | State & storage | Mark never-reassigned values `constant`, set-once-in-constructor values `immutable` (clearer + cheaper than storage reads). Use `calldata` (not `memory`) for external read-only reference args. | a state var never written (→`constant`); one set only in the ctor (→`immutable`); `memory` external arg only read. | Solidity language; OpenZeppelin usage; lint: `constable-states`, `immutable-states`, Solhint `gas-calldata-parameters` (§7) |
| S8 | Events | Emit an event on every state-changing/privileged action; `index` the params consumers filter on; events are `CapWords`. | an owner/parameter change with no event; an un-indexed event param consumers filter by. | Style Guide (event names); lint: `events-access`, `events-maths` (narrow), Solhint `gas-indexed-events` (§7) |
| S9 | Pragma & SPDX | Lead each file with an SPDX identifier and a **pinned** pragma. Avoid floating `^`/`>=` in deployable contracts (deterministic compiler). | `// SPDX-License-Identifier` missing; `pragma solidity ^0.8.0;` in a deployable. | SWC-102/103; lint: `solc-version`, `pragma`, Solhint `compiler-version` (error), solc SPDX warning (§7) |
| S10 | NatSpec | Document public/external functions, events, and the contract with NatSpec (`@notice`/`@param`/`@return`/`@dev`). | a public/external function or the contract with no NatSpec. | Style Guide (NatSpec); lint: Solhint `use-natspec` (presence only) (§7) |
| S12 | Inheritance & overrides | Annotate overrides with `override`; order base contracts consistently (C3 linearization); do not shadow inherited state/locals; call `super` where the pattern requires. | a shadowed inherited state var; a missing `override` (solc-enforced); an interface the contract should inherit but does not. | Style Guide (function order); lint: `shadowing-state` **[SEC-adjacent]**, `shadowing-local`, `missing-inheritance`, `unimplemented-functions` (§7) |

## 2. authorities[]

- **Solidity Style Guide** — docs.soliditylang.org/en/latest/style-guide.html — naming (`CapWords` contracts/events/structs, `mixedCase` functions/vars, `UPPER_CASE` constants, `_` prefix for non-external), layout/ordering, NatSpec. Open docs (paraphrase + cite).
- **Solidity Security Considerations** — docs.soliditylang.org/en/latest/security-considerations.html — CEI, reentrancy, sending ether, `tx.origin`, overflow.
- **Solidity Common Patterns** — docs.soliditylang.org/en/latest/common-patterns.html — the withdrawal (pull-over-push) and restricting-access patterns.
- **OpenZeppelin Contracts (v5.x)** — docs.openzeppelin.com/contracts — reference implementations: Ownable/AccessControl, ReentrancyGuard, SafeERC20, the library-wide custom-error idiom. **MIT** (paraphrase patterns).
- **SWC Registry** — swcregistry.io — the weakness taxonomy; cite stable `SWC-NNN` IDs (maintenance-frozen but the canonical ID namespace).
- **Slither + Solhint + solc** — the checkable anchors (§7). Slither (github.com/crytic/slither) runs **all** detectors by default — cite by detector name + its Impact/Confidence. Solhint (github.com/protofire/solhint) — cite the rule ID + whether it is in `solhint:recommended`. solc emits its own warnings (SPDX, unused var, shadowing, unchecked return).
<!-- 'Consensys Smart Contract Best Practices' is a citation title; the tagger reads it as a noun cluster. -->
<!-- vale AgenticWriting.STE-NounCluster = NO -->
- **Consensys Smart Contract Best Practices** — consensys.github.io/smart-contract-best-practices — background corroboration (pull-payments, CEI, external-call caution).
<!-- vale AgenticWriting.STE-NounCluster = YES -->

## 3. divergences[] — where modern (≥0.8) Solidity rejects older habits

Do **not** flag these as problems (and do not recommend the old form).

- **Custom errors over `require`-strings** (since 0.8.4) — `revert MyError()` is cheaper and decodable. Do not recommend long `require` strings.
- **No SafeMath on ≥0.8.0** — checked arithmetic reverts by default; `using SafeMath` is redundant noise. Do not recommend SafeMath; do flag a deliberate `unchecked` block whose safety is not argued.
- **`error`/`revert`/`require`, not `throw`** — 0.5.0 removed `throw`; `sha3`→`keccak256`, `var` removed. Do not bless deprecated forms (SWC-111).
- **No constructor visibility** — since 0.7.0 constructors take no visibility; `constructor() public` is a legacy smell, not something to add.
- **`calldata` over `memory`** for external read-only reference args — avoids a copy; the idiomatic default. Do not recommend `memory` there.
- **`immutable`/`constant` over plain storage** for set-once/never-changed values — do not leave them as mutable storage "for flexibility."
- **CEI over a reentrancy guard where structurally possible** — correct ordering is the design; `nonReentrant` is defense-in-depth. Do not accept "it has a guard" as a substitute for ordering, and do not recommend adding a guard *instead of* fixing the ordering.
- **`msg.sender`, never `tx.origin`, for auth** — `tx.origin` auth is a phishing vector, never idiomatic (SWC-115).
- **Pinned pragma over floating `^`** in deployables — deterministic compilation (SWC-103).

## 4. anti_patterns[]

- **State update after external call** — cue: `balances[x] -= n` *after* `x.call{value:n}("")`. Rewrite: checks-effects-interactions — update state, then call. lint: `reentrancy-eth` **[SEC→defer]** (§7).
- **Unchecked low-level call** — cue: `(bool ok,) = a.call(…)` with `ok` never checked, or a bare `a.call(…)`. Rewrite: check `ok` and revert, or use a typed interface call. lint: `unchecked-lowlevel`, Solhint `avoid-low-level-calls`/`no-unused-vars` (§7).
- **Unchecked ERC-20 transfer** — cue: `token.transfer(to, amt);` return ignored. Rewrite: `SafeERC20.safeTransfer(token, to, amt)`. lint: `unchecked-transfer` (§7).
- **`tx.origin` auth** — cue: `require(tx.origin == owner)`. Rewrite: `msg.sender`. lint: `tx-origin` **[SEC→defer]**, Solhint `avoid-tx-origin` (§7).
- **Ungated privileged function** — cue: a setter/withdraw/`selfdestruct` with no access modifier. Rewrite: an `onlyOwner`/role modifier. lint: `suicidal`/`unprotected-upgrade` **[SEC→defer]** (the right role gating the right function is **judgment-only**) (§7).
- **Missing zero-address check** — cue: an `address` stored from input with no `!= address(0)`. Rewrite: validate. lint: `missing-zero-check` (§7).
- **Implicit visibility** — cue: a function/state var with no visibility keyword. Rewrite: state it. lint: Solhint `state-visibility`/`func-visibility` (§7).
- **`require`-string where a custom error fits** — cue: `require(c, "msg")` in ≥0.8.4. Rewrite: `error Foo(); … if (!c) revert Foo();`. lint: Solhint `gas-custom-errors` (§7).
- **SafeMath on ≥0.8** — cue: `using SafeMath for uint256;`. Rewrite: delete it; arithmetic reverts by default; `unchecked {}` only where proven safe. Anchor: judgment / §3.
- **Const-able / immutable-able storage** — cue: a state var never written (→`constant`) or set only in the ctor (→`immutable`). Rewrite: mark it. lint: `constable-states`/`immutable-states` (§7).
- **Floating pragma in a deployable** — cue: `pragma solidity ^0.8.0;`. Rewrite: pin it. lint: `solc-version`, Solhint `compiler-version` (§7).
- **Leftover debug statement** — cue: a `console.log`/`hardhat/console` import or call in a contract. Rewrite: delete it before deploy. lint: Solhint `no-console` (**error**) (§7).

## 5. framework_overlays[]

### Idiom-vs-security boundary (the load-bearing overlay)

Not a framework — the boundary that determines where a finding goes. It ranks above style because mis-routing a security-critical finding is the failure mode. Mis-routing means treating it as a mere idiom nit, or conversely claiming a full exploit verdict this lens cannot back.

| id | rule | cue | consequence |
|----|------|-----|-------------|
| SEC1 | For a **[SEC→defer]** detector (the ones marked `[SEC→defer]` in §7: reentrancy `-eth`/`-no-eth`, `tx-origin`, `arbitrary-send-*`, `suicidal`, `unprotected-upgrade`, `unchecked-transfer`, `shadowing-state`): surface the **idiomatic finding** (CEI ordering, `msg.sender`, explicit gating, checked return) and **cite the detector**. Then hand the exploitability/severity verdict to `security-specialist`. | a reentrancy/access/arbitrary-send detector fires. | claiming a full security verdict overstates this lens; *ignoring* it because "security is the audit's job" lets the idiomatic defect ship. Do both: flag the idiom, defer the exploit depth. |

## 6. severity_model

- **correctness / [SEC→defer]** — exactly the §7 `[SEC→defer]` set: S1 reentrancy (state-after-call), S3 ungated privileged function / `tx-origin` auth. Also S6 unchecked ERC-20 transfer and S12 `shadowing-state` (inherited state shadowed). These are exploitable classes: flag the idiomatic form, cite the detector (with its Slither Impact+Confidence), defer exploit depth to `security-specialist` (SEC1).
- **correctness (flag directly, not deferred)** — S2 unchecked low-level call (a swallowed failed `.call`): check the return / use a typed call, cite `unchecked-lowlevel` — *not* a `[SEC→defer]` class.
- **idiom-divergence-with-consequence** — S4 `require`-string-where-custom-error-fits (gas), S5 SafeMath-on-0.8 / unargued `unchecked` (gas/safety). S7 const-able/immutable-able storage & `memory`-vs-`calldata` (gas), S9 floating pragma (non-determinism). S3 missing-zero-check, S12 `shadowing-local`/`shadowing-builtin` (the non-state shadowing).
- **style** — S8 event/indexing nits, S10 NatSpec presence, naming/layout, `explicit-types`. Bundle these; never lead with them.

Profile note: this pack is **subordinate to the repo profile** (`package-profile.md`). A repo's documented convention (e.g. a fixed compiler via Foundry config, a house error library) overrides any dimension here. Its slither/solhint config (which detectors/rules it actually enables) overrides too. Reconcile against the profile and the real config first.

## 7. lint_anchors[]

The machine-checkable rules behind the dimensions. **Cite an anchor only from this table.** For **Slither**, all detectors run by default — the table gives each detector's **Impact + Confidence**. Weight the finding by it (a `High+High` is blocking; an `Informational` is a signal, not a defect). For **Solhint**, the table notes `recommended` membership (almost all idiom rules carry `warn`).

**[SEC→defer]** marks a detector whose exploit verdict goes to `security-specialist` (SEC1). Where a dimension is **judgment-only**, there is no anchor — say so and cite the prose authority; never fabricate a detector.

Verified by running **slither 0.11.5 / solhint 6.2.1 / solc 0.8.35** (see `examples-solidity.md`). Rows marked *(observed)* fired locally; the Slither detector wiki verifies the rest by catalog (and they run by default).

Each Slither detector carries its **(Impact+Confidence)** inline next to the detector name (so the pairing is unambiguous and reorder-safe). Solhint rules carry **(recommended/warn|error)**. `[SEC→defer]` sits inline on the detector it applies to.

| dimension | anchor(s) — each with its weight inline | source | flags | caveat |
|---|---|---|---|---|
| S1 reentrancy | `reentrancy-eth` (High+Medium, **[SEC→defer]**) *(observed)*; `reentrancy-no-eth` (Medium+Medium, **[SEC→defer]**); `reentrancy-benign` (Low+Medium); `reentrancy-events` (Low+Medium) | slither (all default-on) | state write after an external call | `-benign`/`-events` are ordering/idiom nits. Solhint `reentrancy` is a shallow heuristic — prefer Slither |
| S2 external calls | `unchecked-lowlevel` (Medium+Medium) *(observed)*; `unchecked-send` (Medium+Medium); `low-level-calls` (Informational+High) *(observed)*; Solhint `avoid-low-level-calls` (warn) *(obs)*, `no-unused-vars` (warn) *(obs)*, `check-send-result` (warn) | slither + solhint | ignored low-level return; raw `.call`/`.send` | `low-level-calls` is Informational (presence, not a bug). **Pull-over-push design is judgment-only.** `check-send-result` is in recommended but did not fire on a value-captured `.call` — `no-unused-vars` caught the unused `ok` instead |
| S3 visibility & access | `suicidal` (High+High, **[SEC→defer]**); `unprotected-upgrade` (High+High, **[SEC→defer]**); `tx-origin` (Medium+Medium, **[SEC→defer]**); `missing-zero-check` (Low+Medium) *(observed)*; Solhint `state-visibility` (warn) *(obs)*, `func-visibility` (warn) *(obs)*, `avoid-tx-origin` (warn) *(obs)* | slither + solhint | ungated selfdestruct/upgrade; `tx.origin`; address w/o zero-check; implicit visibility | **Whether the right role gates the right function is judgment-only** — no detector knows your authz model |
| S4 custom errors | Solhint `gas-custom-errors` (warn) *(observed)*; `reason-string` (warn) | solhint | `require("string")`/`revert("string")` in ≥0.8.4; over-long/missing reason | the two partly conflict by design (`gas-custom-errors` pushes off strings; `reason-string` governs strings you keep). No Slither anchor; no security weight |
| S5 arithmetic | `divide-before-multiply` (Medium+Medium); `incorrect-exp` (High+Medium) | slither | `a/b*c` precision loss; `**`/`^` misuse | **SafeMath-on-0.8 and unsafe-`unchecked`-block are judgment-only** — no detector flags redundant SafeMath or an unsafe `unchecked` |
| S6 token interactions | `unchecked-transfer` (High+Medium, **[SEC→defer]**) *(observed)*; `arbitrary-send-erc20` (High+High, **[SEC→defer]**) | slither | ignored ERC-20 transfer return; attacker-controlled `transferFrom(from)` | **"Use OZ SafeERC20 specifically" is judgment-only** — Slither flags the unchecked return, not the library choice |
| S7 state & storage | `constable-states` (Optimization+High) *(observed)*; `immutable-states` (Optimization+High) *(observed)*; Solhint `gas-calldata-parameters` (warn) | slither + solhint | never-written var (→`constant`); ctor-only var (→`immutable`); `memory` arg that could be `calldata` | precise & checkable; Optimization-impact (a gas signal, not a defect). **Storage-packing *layout* is judgment-only** (`gas-struct-packing` is a noisy heuristic) |
| S8 events | `events-access` (Low+Medium); `events-maths` (Low+Medium); Solhint `gas-indexed-events` (warn) | slither + solhint | access/arith change with no event; un-indexed event param | the Slither detectors are **narrow** (specific mutation shapes). **General event *completeness* is judgment-only** |
| S9 pragma & SPDX | `solc-version` (Informational+High) *(observed)*; `pragma` (Informational+High); Solhint `compiler-version` (**error**); solc SPDX warning *(observed)* | slither + solhint + solc | floating/old pragma; conflicting pragmas; missing SPDX | `compiler-version` is one of the few **error-level** Solhint rules. SPDX-missing is a **solc** warning, not a linter. Informational-impact — idiom/reproducibility, not a blocking bug |
| S10 NatSpec | Solhint `use-natspec` (warn) *(observed)* | solhint | public/external item or contract missing NatSpec | **presence only** — NatSpec *quality/accuracy* is judgment-only |
| S12 inheritance & overrides | `shadowing-state` (High+High, **[SEC→defer]**); `shadowing-local` (Low+High); `shadowing-builtin` (Low+High); `missing-inheritance` (Informational+High); `unimplemented-functions` (Informational+High) | slither | shadowed inherited state/local/builtin; un-inherited interface; unimplemented abstract fn | the `override` keyword is **solc-enforced** at compile time (a solc error, not a lint); intended `super` chains are judgment-only |
| AP leftover debug statement | Solhint `no-console` (**error**) | solhint | leftover `console.log`/`hardhat/console` | one of the three **error**-level Solhint rules — safe to cite as build-failing |

**Genuinely judgment-only — never fabricate a detector:** pull-over-push withdrawal design (S2), authorization-model correctness (S3), SafeMath-removal & unsafe-`unchecked` blocks (S5). Also the OZ-SafeERC20 library choice (S6), storage-packing layout (S7), event *completeness* (S8), NatSpec *quality* (S10), and intended `super`/override chains (S12). Cite the prose authority + SWC-ID and say plainly no checkable rule exists.

**Provenance caveats (carry these when citing — running the tools verified all of them):**

- Slither runs **all** detectors by default, so cite the detector + its **Impact+Confidence**. Do not treat an `Informational`/`Optimization` detector (`low-level-calls`, `constable-states`, `immutable-states`, `pragma`, `solc-version`) as a blocking defect. The high-impact security detectors are **[SEC→defer]** (flag the idiom, hand exploit depth to `security-specialist`).
- Solhint: only `compiler-version`/`no-console`/`quotes` are **error**-level in `recommended` — everything else carries `warn`. `not-rely-on-time`, `ordering`, `private-vars-leading-underscore`, `payable-fallback` are **off** by default (do not claim they fire).
- Use the Slither `--detect` names (`unchecked-lowlevel`, `missing-zero-check`, `constable-states`) — the wiki anchors sometimes differ (`unchecked-low-level-calls`, `missing-zero-address-validation`).
- Solhint folded `compiler-fixed` into `compiler-version`; `use-natspec` superseded the older comment rules — do not cite the retired names.

**Tool conflicts / idiom-divergent defaults (observed — do not mis-cite):** Solhint `func-visibility` flags an **idiomatic no-visibility constructor** (correct since 0.7 — a §3 divergence). Only `ignoreConstructors: true` in the config silences it. If a repo's solhint flags its constructor, that is the rule's default, not a real finding.

Solhint `immutable-vars-naming` wants an immutable in `SNAKE_CASE` (`ADMIN`) while Slither `naming-convention` (Informational) wants `mixedCase` (`admin`) — the two **conflict** on immutable casing. Pick the repo's convention and do not cite both against the same name. Solhint `gas-indexed-events` suggests indexing event value-params (e.g. a payment `amount`) — a gas hint, not an idiom requirement (you typically index filter keys, not values).

## Language → specialist agent

Solidity maps to **`solidity-developer`** (see the TEMPLATE specialist map). For deep Solidity judgment calls beyond this pack — and for the exploit-depth verdict on any **[SEC→defer]** finding — dispatch `solidity-developer` (it can run `forge`/`slither`). For adversarial threat analysis, dispatch `security-specialist`.
