# Python idiom pack

> §2 lists the authorities this pack loads; cite them in findings. The §7 anchors match the official Ruff rule registry + mypy error-code list. **Running `ruff` 0.15.17 / `mypy` 2.1.0 / `black` 26.5.1 on snippets confirmed them** — none come from memory.
>
> <!-- 'Google Python Style Guide' is a citation title; the tagger reads it as a noun cluster. -->
> <!-- vale AgenticWriting.STE-NounCluster = NO -->
> Strategic stance: this pack enshrines the **language's own published standards** (PEPs, the official docs, the Google Python Style Guide). It adds the community-consolidated lint registry (Ruff); hand-rolled house rules stay out. Where a rule is the team's, it says so.
> <!-- vale AgenticWriting.STE-NounCluster = YES -->
>
> **Citing a §7 anchor:** cite a lint code only from §7, and carry its two-part caveat. (a) Is it in Ruff's defaults or **opt-in** (most of `N`/`D`/`ANN`/`B`/`C4`/`PTH`/`I` are opt-in)? (b) Does it need a configured **type checker** (the P2/`ANN` rules — TC1)? If §7 marks a dimension **judgment-only**, say so and cite the PEP/doc authority — never fabricate a code.

Sections: §1 dimensions · §2 authorities · §3 divergences (do **not** flag these) · §4 anti_patterns · §5 framework_overlays · §6 severity_model · §7 lint_anchors · language→specialist.

## 1. dimensions[]

| id | dimension | idiomatic rule | cue | authority |
|----|-----------|----------------|-----|-----------|
| P1 | Naming | `snake_case` functions/variables/modules; `CapWords` (PascalCase) classes; `UPPER_CASE` module-level constants; `_leading` for non-public, `__dunder__` only for the data model. | `getItem`/`MyVar` functions; `my_class` class; a module-level `Config` that is a constant. | PEP 8 *Naming Conventions*; lint `N801`/`N802`/`N803`/`N806` (§7) |
| P2 | Typing & annotations | Annotate the **public boundary** (args + return); let locals infer. Modern forms (per target Python): `list[int]`/`dict[str,int]` (PEP 585, 3.9+) **not** `typing.List`; `X \| None` (PEP 604, 3.10+) **not** `Optional[X]`; PEP 695 generics (`class C[T]`, `type Alias = …`, 3.12+); `@override` (PEP 698, 3.12+). Structural typing via `Protocol` (PEP 544), not forced ABC inheritance. Run a type checker (mypy/pyright). | `Optional[X]`/`Union`/`typing.List` on 3.10+; an untyped public function; `Any` in a public signature where a `Protocol` fits. | PEP 484/526/585/604/695/698; `typing` docs; PEP 544; lint `UP006`/`UP035`/`UP045`, `ANN201`; mypy `[arg-type]`/`[return-value]`/`[no-untyped-def]` (§7) |
| P3 | Docstrings | PEP 257 triple-double-quote docstrings on public modules/classes/functions/methods (incl. `__init__`); imperative mood ("Return …", not "Returns …"); one-line closes on the same line, multi-line summary + blank + body + closing quotes on their own line. The **section format** (Google `Args:`/`Returns:`/`Raises:`, NumPy, or reST) is a **project convention** layered on PEP 257 — pick one, do not mix. | a public function with no docstring; a docstring describing in past/indicative tense; mixed Google+NumPy formats. | PEP 257; Google Style Guide §3.8 (format); lint `D101`/`D103` (pydocstyle) (§7) |
| P4 | EAFP control flow | "Easier to ask forgiveness than permission": assume validity and catch the specific exception, rather than pre-checking (LBYL). Pre-checks are verbose and risk a TOCTOU race. Keep the `try` body and the `except` clause narrow. | a chain of `if key in d and d[key] is not None …` guarding a lookup; a broad pre-validation block mirroring the operation. | docs glossary (EAFP / LBYL); PEP 20 "Errors should never pass silently"; lint judgment-only apart from the adjacent `SIM105` `contextlib.suppress` (§7) |
| P5 | Comprehensions, builtins & stdlib | A comprehension (or generator) for a simple transform/filter, over a manual `for`-append loop or `map`/`filter`+`lambda`; but cap complexity (no multiple `for`/filter clauses — extract a loop). Reach for builtins/stdlib: `enumerate`, `zip`, `any`/`all`, `pathlib.Path` over `os.path` string-munging. | `result=[]; for…: result.append(…)`; `list(map(lambda…))`; a 3-clause comprehension; `os.path.join`. | tutorial *Data Structures* §5.1.3; Google §2.7; lint `C4xx` (e.g. `C416`), `PTH118`, `SIM` (§7) |
| P6 | Data model, properties & protocols | Expose attributes directly; add `@property`/descriptors **only** when access needs behavior — no Java-style `get_x()`/`set_x()`. Implement protocols via dunders (`__len__`, `__iter__`, `__enter__`/`__exit__`); use `@dataclass` for data aggregates; `Protocol` for "looks-like-a-duck" interfaces. | `get_name()`/`set_name()` pairs over a plain attribute; a hand-rolled iterator without `__iter__`; a boilerplate `__init__`-only class that a `@dataclass` replaces. | data model §3.3; `property` / `dataclasses` docs; PEP 544; lint judgment-only (§7) |
| P7 | Mutable defaults & shared state | Never a **mutable default argument** (`def f(x=[])`/`={}`) — Python evaluates the default once and shares it across calls; default to `None` and construct inside. Same for mutable **class attributes** — annotate `ClassVar` or set in `__init__`. | `def f(x=[])` / `def f(x={})`; a `cache = {}` class attribute mutated per-instance. | flake8-bugbear + Ruff convention; PEP 20; lint `B006`/`B008`/`RUF012` (§7) |
| P8 | Imports | One import per line; grouped **stdlib → third-party → local** with a blank line between groups; absolute imports; **no wildcard `from x import *`**. (Google §2.2 additionally imports modules, not symbols — exempting `typing`/`collections.abc`; treat as a project overlay.) | `import os, sys`; a third-party import among stdlib; `from x import *`; an unused import. | PEP 8 *Imports*; Google §2.2; lint `I001` (isort), `F401` (unused), `F403`/`F405` (wildcard) (§7) |
| P9 | Errors & exceptions | Raise/catch **specific** `Exception` subclasses — never a bare `except:`. Do not silence silently (PEP 20): an intentional swallow says why. Preserve the cause with `raise New(...) from err` inside an `except`. Do not use exceptions for ordinary control flow beyond EAFP. | `except:` / `except Exception: pass`; `raise X()` inside `except` losing the cause; control flow on caught error messages. | PEP 8 (bare except); PEP 20; tutorial *Errors and Exceptions*; lint `E722` (bare except), `B904` (raise-without-from) (§7) |
| P11 | Formatting | Defer mechanical formatting to **`black`** (or `ruff format`) — deterministic, "uncompromising"; double-quote normalization, trailing-comma handling. **Line length is project-configurable**: black/Ruff default **88** (PEP 8 says 79 but sanctions up to 99 and warns against "a foolish consistency"). Do not hand-litigate whitespace a formatter owns — hand-formatting drifts from the formatter and produces review noise the formatter would erase. | hand-aligned dict/whitespace; arguing 79 vs 88 in review; single vs double quotes by hand. | black *code style*; PEP 8 (with its 99/"foolish consistency" carve-outs); lint `E501` (configurable) (§7) |

## 2. authorities[]

- **PEP 8** — *Style Guide for Python Code* — https://peps.python.org/pep-0008/ — naming, layout, imports, line length, comparisons. The baseline.
- **PEP 257** — *Docstring Conventions* — https://peps.python.org/pep-0257/ — docstring placement, quoting, mood, one-line vs multi-line.
- **PEP 20** — *The Zen of Python* — https://peps.python.org/pep-0020/ — "explicit is better than implicit"; "errors should never pass silently"; "one obvious way."
- **The typing PEPs** — 484 (hints), 526 (variable annotations), 585 (builtin generics), 604 (`X|Y` unions). Also 612 (ParamSpec), 646 (variadic), 695 (type-param syntax, 3.12), 698 (`@override`, 3.12) — https://peps.python.org/. Plus the **`typing` module docs** https://docs.python.org/3/library/typing.html and **PEP 544** (`Protocol`, structural typing).
- **Official Python documentation** — the tutorial (https://docs.python.org/3/tutorial/), the data model (https://docs.python.org/3/reference/datamodel.html), and the glossary (https://docs.python.org/3/glossary.html — EAFP/LBYL).
<!-- 'Google Python Style Guide' is a citation title; the tagger reads it as a noun cluster. -->
<!-- vale AgenticWriting.STE-NounCluster = NO -->
- **Google Python Style Guide** — https://google.github.io/styleguide/pyguide.html — a widely-adopted **community** standard (not a PEP): Google-format docstrings, import-modules-not-symbols, complexity caps. Cite as community, layered on PEP 8.
<!-- vale AgenticWriting.STE-NounCluster = YES -->
- **Tooling (the lint ecosystem):**
  - **Ruff** (https://docs.astral.sh/ruff/) — the consolidated linter. Re-implements 900+ rules from pycodestyle/Pyflakes/isort/pep8-naming/pydocstyle/pyupgrade/flake8-bugbear/-comprehensions/-simplify/-use-pathlib/-annotations + Ruff-specific. The 2026 de-facto standard, used by FastAPI/Pydantic/Pandas.
  - **mypy** (https://mypy.readthedocs.io/) / **pyright** (https://github.com/microsoft/pyright — repo, no docs.* site) for type checking.
  - **black** (https://black.readthedocs.io/) / `ruff format` for formatting.

## 3. divergences[] — where Python rejects general / other-language wisdom

Do **not** flag these — they are correct Python, not smells (the false-positive guard):

- **EAFP over LBYL.** General defensive style says validate-everything-before-acting; Python prefers `try`/`except` (cleaner, and avoids the TOCTOU race a pre-check introduces). → Reviewer must NOT flag a well-scoped `try`/`except` as "missing pre-checks."
- **Attributes over getters/setters.** Classic OOP encapsulation says private fields + accessors; Python exposes attributes and adds `@property` only when access needs behavior. → Must NOT flag a public attribute as "needs a getter/setter."
- **Structural (duck) typing over interface inheritance.** Nominal-typing dogma says "implement the interface"; Python uses duck typing at runtime and `Protocol` (PEP 544) for static structural typing. → Must NOT flag "does not subclass the ABC" when a `Protocol` / duck match holds.
- **Comprehensions over loops/`map`/`filter`.** → Must NOT flag a clear single-clause comprehension as "too clever."
- **Module-level functions over class-wrapping.** Java's "everything in a class" is not Python; a module of functions is idiomatic. → Must NOT flag a stateless function for "not being in a class."
- **Explicit + one obvious way (Zen).** Cuts against clever metaprogramming and DRY-at-all-costs magic. → Must NOT flag the explicit, obvious form as "verbose" or "not DRY" when a terser implicit/metaprogrammed one exists.
- **Line length is project-configurable.** → Must NOT flag 88-column lines against a literal 79; PEP 8 itself sanctions 99 and the "foolish consistency" carve-out.

## 4. anti_patterns[]

Each is example-paired in `examples-python.md` (the bad snippet run through the tool, the observed diagnostic recorded).

- **Mutable default argument** — cue: `def f(x=[])` / `={}`. Rewrite: `def f(x=None): x = [] if x is None else x`. (`B006`; a function *call* in a default is `B008` — but see §5 FastAPI FA2 for the documented framework exception; mutable class attr → `RUF012`)
- **Bare / swallowing except** — cue: `except:` or `except Exception: pass`. Rewrite: catch the specific type; intentional suppress → `contextlib.suppress(...)` + a one-line why. (`E722`; `SIM105`)
- **Legacy typing** — cue: `Optional[int]` / `List[str]` / `Union[...]`. Rewrite: `int | None` / `list[str]` / `X | Y`. (`UP045`/`UP006`/`UP035`)
- **Wildcard import** — cue: `from x import *`. Rewrite: explicit names. (`F403`/`F405`)
- **Singleton / type comparison** — cue: `x == None` / `x == True` / `type(x) == int`. Rewrite: `x is None` / truthiness / `isinstance(x, int)`. (`E711`/`E712`/`E721`)
- **`os.path` string-munging** — cue: `os.path.join(...)`. Rewrite: `Path(...) / ...`. (`PTH118`)
- **Manual loop that is a comprehension** — cue: `r=[]; for…: r.append(…)`. Rewrite: `[… for … in …]`. (judgment; adjacent `C416` fires only on a *redundant* comprehension that is a plain copy, not on the loop→comprehension rewrite)
- **f-string in a logging call** — cue: `logging.info(f"…{x}")` (formats eagerly even at a disabled level). Rewrite: `logging.info("…%s", x)`. (`G004`; `flake8-logging-format`, opt-in)

## 5. framework_overlays[]

### Type-checking precondition (applies to all P2 annotation/type rules)
| id | rule | cue | consequence |
|----|------|-----|-------------|
| TC1 | The type-quality dimension (P2 mypy/pyright codes + `ANN*`) requires a **configured type checker** (mypy/pyright) and, for `ANN*`, `flake8-annotations` selected in Ruff. | `ruff` defaults with no type checker / `ANN` not selected. | type-mismatch + missing-annotation defects **ship unflagged**; those dimensions fall back to **judgment-only** — say so. |

### asyncio (overlay — runtime consequences rank above style)
| id | rule | cue | consequence |
|----|------|-----|-------------|
| A1 | Never block the event loop inside an `async def` — no sync I/O, `time.sleep`, or blocking opens; use the async equivalent (`asyncio.sleep`, async file/HTTP/DB). | `time.sleep(...)`, `open(...)`, a sync DB/HTTP call inside `async def`. | the **whole event loop stalls** — every coroutine starves, not just this one. (`ASYNC251` sleep, `ASYNC230` blocking-open, `ASYNC110` busy-wait) |
| A2 | Keep a reference to every `asyncio.create_task(...)`. | `asyncio.create_task(coro())` with the result discarded. | the task may be **garbage-collected before it finishes** and silently never complete. (`RUF006`) |

### pytest (overlay)
| id | rule | cue | consequence |
|----|------|-----|-------------|
| PT1 | Bare `assert` (pytest rewrites it for rich diffs), not `unittest` `self.assertEqual`; scope `pytest.raises(...)` to the specific exception; one logical check per assert. | `self.assertEqual(...)` in a pytest test; `pytest.raises(Exception)`; a composite `assert a and b`. | weaker failure diagnostics; an over-broad `raises` **passes on the wrong error**. (`PT009`, `PT011`, `PT018` — `flake8-pytest-style` `PT` set, opt-in) |

### FastAPI (overlay — framework runtime + the official "prefer `Annotated`" idiom)
FastAPI's docs repeat one through-line across `Depends`/`Query`/`Path`/`Body`: **"Prefer to use the `Annotated` version if possible"** (added + recommended since 0.95.0). The overlay encodes that idiom plus the framework's runtime hazards. Enable Ruff's `FAST` set (opt-in) to anchor FA1 (`FAST002`), FA3 (`FAST001`), and FA4 (`FAST003`); FA5 composes the `ASYNC` set (`ASYNC251`/`ASYNC210`); FA2 is the `B008` exemption; FA6 is judgment-only. All anchors are in §7.

| id | rule | cue | consequence |
|----|------|-----|-------------|
| FA1 | **Annotated dependency/parameter style** — `param: Annotated[X, Depends(get_x)]` / `Annotated[str, Query(max_length=50)] = None`, **not** the `= Depends(...)` / `= Query(default=...)` default-value form. The docs prefer it for editor/`mypy` type preservation, reuse (hoist `CommonsDep = Annotated[...]`), keeping the function callable outside FastAPI, and non-ambiguous required-vs-optional. | `commons: dict = Depends(common)`; `q: str = Query(default=None)`. | the default-value form loses static type info + reusability, and (for `Depends`) trips generic `B008` — see FA2. (`FAST002` — `fast-api-non-annotated-dependency`) |
| FA2 | **`Depends`/`Query`/`Path`/`Body` in a default INVERTS `B008`** — a function call in an arg default is idiomatic FastAPI, not the flake8-bugbear mutable-call bug. Do not flag `B008` on them; the documented fix is Ruff `lint.flake8-bugbear.extend-immutable-calls = ["fastapi.Depends","fastapi.params.Depends","fastapi.Query","fastapi.params.Query", …]` — list **both** the `fastapi.X` and the `fastapi.params.X` qualified name. (FA1's `Annotated` form sidesteps `B008` for deps entirely — no default-arg call — so the exemption mainly covers `Query`/`Path`/`Body` value declarations + legacy code.) | `B008` firing on a FastAPI route signature. | a naïve `B008` lint floods idiomatic FastAPI with false positives. The documented exception to the pack's `B006`/`B008` rule (FastAPI discussion #7463; Ruff `extend-immutable-calls` settings example). |
| FA3 | **`response_model` only when the output differs from the return type** — prefer the return annotation `-> Item`. Use `response_model=` **only** when the returned object differs from the declared output (filtering/security). Example: return `UserIn` under `response_model=UserOut` to strip `password` — "limit and filter the output data … particularly important for security". Prefer multiple classes over `response_model_exclude*` (the OpenAPI schema still shows the full model). | `@app.post(..., response_model=Item)` paired with `-> Item`; **or** a route returning a richer object with NO output model. | redundant `response_model` (`FAST001` — `fast-api-redundant-response-model`); or, worse, undeclared output → unfiltered fields **leak to the client**. |
| FA4 | **Every `{param}` in the route path has a same-named function arg**; declare `/users/me` **before** `/users/{user_id}` (routes match in order). | a `{thing_id}` in the path string absent from the signature; a `/{id}` route shadowing a literal `/me` route. | a missing arg → the path param is silently unhandled (`FAST003` — `fast-api-unused-path-parameter`). A `/{id}` declared before a literal `/me` → the `/{id}` route captures the literal route as an id (judgment-only ordering footgun — FastAPI tutorial/path-params). |
| FA5 | **Do not block the event loop in an `async def` route** — a sync DB driver, `requests`, or `time.sleep` inside an `async def` route/dependency stalls every concurrent request. Use a plain `def` route (FastAPI runs it in a threadpool) **or** an async client + `await`. The docs' rule: *"If you just don't know, use normal `def`."* | blocking/sync I/O inside an `async def` route or dependency. | the **whole event loop stalls** — all in-flight requests starve, not just this one. (composes the pack's asyncio overlay — `ASYNC251` for `time.sleep`, `ASYNC210` for a blocking HTTP call like `requests`; FastAPI `/async/` guidance.) |
| FA6 | **Framework idioms** — `raise HTTPException` (never `return` it — it is an exception); `status_code=` on the **decorator** (+ `from fastapi import status` constants over magic ints). `BackgroundTasks` for after-response work; `APIRouter` + `include_router` for structure; a `lifespan=` async-context-manager, **not** the deprecated `@app.on_event`. | `return HTTPException(...)`; a magic `status_code=201`; after-response work done inline; one flat module of routes; `@app.on_event("startup")`. | a *returned* `HTTPException` is **not** an error response (the client gets a 200 with a serialized exception). After-response work run inline blocks the response until it finishes (use `BackgroundTasks`). A flat single-module app gets unmaintainable as it grows (use `APIRouter` + `include_router`); FastAPI deprecates `@app.on_event` and silently skips it if you also set a `lifespan`. (judgment/no-lint — FastAPI handling-errors, response-status-code, background-tasks, bigger-applications, advanced/events docs.) |

Further sub-packs, deferred until the work is common: **pydantic** (v2 model/validator patterns; frozen-model immutability), **Django** (ORM N+1 → `select_related`/`prefetch_related`; fat-model/thin-view). Add each as a conforming overlay table when a repo needs it.

## 6. severity_model

- **correctness:** the mutable-default bug (`B006`/`RUF012`), a bare/swallowing `except` that hides failures (`E722`), a real type mismatch a checker flags (mypy `[arg-type]`/`[return-value]`), a `==`-on-singleton identity bug (`E711`). Always wins.
- **idiom-divergence-with-consequence:** legacy typing that misleads tooling / breaks on `from __future__`-free runtime introspection (`UP006`/`UP045`); `os.path` vs `pathlib` portability. Also a wildcard import shadowing names (`F403`/`F405`) and a missing public-boundary annotation (`ANN201`).
- **style:** naming (`N8xx`), import ordering (`I001`), line length (`E501`), docstring presence (`D1xx`), formatting black owns. Bundle these; never lead with them.

*Framework overlays map onto the same tiers.* FastAPI FA3 (unfiltered fields leak to the client) and FA5 (a blocked event loop starves all requests) are **correctness**. FA1/FA2/FA4 are **idiom-divergence-with-consequence** (lost typing/reuse, a `B008` false-positive flood, a silently-unhandled path param). FA6 is mixed (returned-`HTTPException` is correctness; magic `status_code` is style). The asyncio overlay's event-loop block (A1) is likewise correctness.

**Subordinate to the repo profile.** This pack is subordinate to `package-profile.md`, and Python is *more* profile-dependent than its peers. The repo's call: which `ruff` rule-sets it selects (`N`/`D`/`ANN`/`B`/`C4`/`PTH`/`I` are **opt-in**, not Ruff defaults) and which docstring convention (`google`/`numpy`/`pep257`). Also the configured line length and whether a type checker runs (TC1). Reconcile against the repo's `ruff`/`mypy`/`black` config + `CLAUDE.md` first — never cite `N802`/`ANN201`/`D103` as build-failing against a repo that never selected those sets.

## 7. lint_anchors[]

Anchors verified against the Ruff rule registry + the mypy error-code list, **and by running `ruff`/`mypy`/`black` on snippets**. Registry: https://docs.astral.sh/ruff/rules/. Cite a lint code only from this table.

| dimension | anchor(s) | tool · rule-set | autofix? | flags | caveat |
|---|---|---|---|---|---|
| P1 Naming | `N801` (class not CapWords); `N802` (function not snake_case); `N803` (argument not lowercase); `N806` (variable in function not lowercase) | Ruff · `pep8-naming` (`N`) | no | `class my_class`; `def getItem`; `def f(D=…)`; `X = …` local | the `N` set is **not** in Ruff defaults — select it explicitly; encodes PEP 8 naming |
| P2 Typing | `UP006`/`UP035` (`typing.List`→`list`); `UP045` (`Optional[X]`→`X\|None`); `ANN201` (missing public return type); mypy `[arg-type]`/`[return-value]`/`[no-untyped-def]` | Ruff · `pyupgrade`(`UP`)/`flake8-annotations`(`ANN`) ; mypy | UP\* yes / ANN no | `Optional`/`List` on 3.10+; untyped public def; type mismatch | `ANN` + mypy need opt-in (TC1); `[no-untyped-def]` is on mypy's **optional** list (fires under `--strict`/`--disallow-untyped-defs`) |
| P3 Docstrings | `D101` (undocumented public class); `D103` (undocumented public function) | Ruff · `pydocstyle` (`D`) | no | a public class/function with no docstring | `D` set is opt-in + has a convention (`google`/`numpy`/`pep257`) you must pick; conflicting `D203/D211`, `D212/D213` pairs — choose per convention; docstring *format* is judgment |
| P4 EAFP | `SIM105` (`try/except/pass`→`contextlib.suppress`) — *adjacent* | Ruff · `flake8-simplify` (`SIM`) | yes | a `try: … except X: pass` block | EAFP-vs-LBYL *choice* is **judgment-only** — no linter says "this should have been try/except"; `SIM105` only tidies an existing suppress |
| P5 Comprehensions/stdlib | `C416` (unnecessary comprehension); `C401`/`C417` (comprehension/`map` rewrites); `PTH118` (`os.path.join`→`pathlib`); `SIM` family | Ruff · `flake8-comprehensions`(`C4`)/`-use-pathlib`(`PTH`)/`-simplify`(`SIM`) | yes (most) | `[i for i in xs]`; `os.path.join`; nested `if` | `PTH` is opt-in; "comprehension vs loop *readability*" beyond the mechanical rewrites is judgment |
| P6 Data model | — (no anchor) | — | — | getters/setters; hand-rolled iterator; boilerplate class | **judgment-only** — no linter flags a getter-pair or "should be a `@dataclass`/`Protocol`"; cite the data-model docs |
| P7 Mutable defaults | `B006` (mutable arg default); `B008` (call in arg default); `RUF012` (mutable class attr needs `ClassVar`) | Ruff · `flake8-bugbear`(`B`)/Ruff-specific(`RUF`) | no | `def f(x=[])`; `def f(x=set())`; `cache = {}` class attr | `B`/`RUF` opt-in; `B006` exempts immutable-annotated params; **verified firing on a live snippet** |
| P8 Imports | `I001` (unsorted/ungrouped); `F401` (unused); `F403`/`F405` (wildcard / name-via-wildcard) | Ruff · `isort`(`I`)/`Pyflakes`(`F`) | I/F401 yes | a third-party import among stdlib; unused import; `from x import *` | `F` is in Ruff defaults; `I` is opt-in; the Google import-modules-not-symbols rule is a **project overlay**, not lint-default |
| P9 Errors | `E722` (bare `except`); `B904` (`raise` in `except` without `from`) | Ruff · `pycodestyle`(`E`)/`flake8-bugbear`(`B`) | no | `except:`; `raise X()` inside `except` | `E722` is in defaults; `B904` opt-in; "swallowed-but-should-reraise" beyond the bare case is judgment |
| P11 Formatting | `E501` (line too long); `black`/`ruff format` own the rest | Ruff · `pycodestyle`(`E`) ; black | format: yes | a >limit line; hand-formatted whitespace | `E501`'s limit is **project-configurable** (default 88 with the Ruff formatter; PEP 8 = 79; 99 sanctioned) — never assert a fixed 79 |
| FA1/FA3/FA4 (FastAPI overlay) | `FAST002` (non-annotated dep); `FAST001` (redundant `response_model`); `FAST003` (unused path param) | Ruff · FastAPI linter (`FAST`) | all 3: hidden | default-value `Depends`; `response_model=` duplicating the return type; `{param}` not in the signature | the `FAST` set is **opt-in** + recent (version-gated to the ruff that shipped it). FAST001/002/003 carry a *hidden, unsafe* fix (enable with `--unsafe-fixes`). **Verified firing on live snippets** (0.15.17) |
| FA2 (FastAPI `B008` inversion) | `B008` (function call in default — see P7) | Ruff · `flake8-bugbear` (`B`) | no | `B008` firing on `Depends`/`Query`/`Path`/`Body` in an arg default | **inverted for FastAPI** — exempt via `lint.flake8-bugbear.extend-immutable-calls` (list both the `fastapi.X` and `fastapi.params.X` names); the `Annotated` form needs no exemption; see §5 FA2 |
| FA5 (FastAPI async route) | `ASYNC251` (`time.sleep`); `ASYNC210` (blocking HTTP, e.g. `requests`) in an `async def` | Ruff · `flake8-async` (`ASYNC`) | no | a sync sleep / blocking HTTP call inside an `async def` route | `ASYNC` set opt-in; composes the pack's asyncio overlay; **verified firing on live snippets** (0.15.17) |

**Anti-fabrication note:** `ruff rule <code>` (Ruff 0.15.17) confirmed every code above exists with the stated name, and each fired on a bad snippet. `mypy --strict` (2.1.0) confirmed the mypy codes. When §7 marks a dimension **judgment-only**, cite the PEP/doc authority — do not invent a code. **Genuinely judgment-only — never fabricate a code:** P4 (EAFP-vs-LBYL *choice*), P6 (data-model / `@property` / `@dataclass` / `Protocol` *design*), and `@override`/PEP-695 *adoption* under P2. The FastAPI overlay's judgment-only items are FA6 (the framework idioms: raise-not-return, `BackgroundTasks`, `APIRouter`, lifespan-vs-`on_event`) and FA4's route-ordering footgun. For those, cite the FastAPI docs, not a code — no checker enforces these.

## Language → specialist agent

| language | specialist agent |
|----------|------------------|
| Python | *(none yet — review on the pack + first principles. Add a `python-specialist` when Python work is common, e.g. for "is this async/reconcile pattern idiomatic" judgment the static pack cannot carry.)* |
