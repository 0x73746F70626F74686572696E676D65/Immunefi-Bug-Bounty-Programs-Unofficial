# Sources — the validator-platform corpus

The pinned, primary sources this skill cites. **Cite-and-pin**; never restate a fact another skill owns. Verified against the source during authoring. Unlike `/platform`'s external-standards corpus, this corpus holds **internal pins** (the controller + seictl at a sha) plus the shipped `/gov-ops` skill and the public `sei-skill`. The **profile** (`sei-validator-profile.md`) is what actually applies here and points back at these pins.

- **§controller — `sei-k8s-controller@5730aa4` (the topology + CRD contract pin).** The live source of truth for topology and the CRD behavior.
  - SeiNetwork **owns** SeiNode (`internal/controller/seinetwork/nodes.go:124`); SeiNodeTask is a soft name-ref (`spec.target.nodeRef.name`); `SeiNodeDeployment` removed (#417).
  - The cross-pod-reachable sidecar address `:8443` is the controller's `RBACProxyPort` (`internal/noderesource/noderesource.go:65`).
  - The keyName ladder lives here (`internal/task/seinodetask_params.go:231` `resolveSigningUID`; CRD comments `api/v1alpha1/seinodetask_types.go:227-231,286-292,355-362`; `DefaultOperatorKeyName="node_admin"` in `api/v1alpha1/validator_types.go:7`).
  - Gov kinds populate `status.outputs` — `internal/controller/nodetask/govoutputs.go` `populateGovOutputs` decodes `wire.GovTxResult` into `status.outputs.gov*` (`txHash`/`height`; `proposalId` on committed submits), verified at controller@8bf3ade (sei-k8s-controller#453); the other sidecar kinds do not.
  - **Cite topology + signing HERE, never the stale LLD.**

- **§seictl — `seictl@79f74a5` (the sidecar execution pin).** The sidecar builds, signs, and broadcasts the gov `Msg`.
  - Reachable cross-pod at `:8443` (the controller's `RBACProxyPort` — see §controller `internal/noderesource/noderesource.go:65`, NOT a seictl path). `7777` is the in-pod bind behind the proxy.
  - The sidecar builds gov `Msg`s in-process (`sidecar/tasks/{gov_vote,gov_software_upgrade,gov_param_change}.go` — no `seid` shell-out).
  - seictl declares `BroadcastSync(...)` at `sign_and_broadcast.go:120` and calls it at `:206`. `includedAt` (separate inclusion poll, nil on poll-deadline) sits at `:83`.
  - The chain-ID guard `guardChainID` sits at `sign_and_broadcast.go:316` (`chainId` == `SEI_CHAIN_ID` env AND node `/status` `node_info.network`).
  - The per-kind request structs `GovVoteRequest` / `GovSoftwareUpgradeRequest` / `GovParamChangeRequest` (+ `paramChange.Value` raw-JSON, stringified once).
  - The cross-handler **pre-broadcast txHash marker shipped** (seictl#219, closing `seictl#174`) and covers BOTH submit kinds. The handler fsyncs a durable `{taskID,txHash,txBytes}` record before broadcast. A crash-window re-run of the same task therefore adopts the prior tx. Already-on-chain → build from it; else re-broadcast identical bytes — never re-sign.
  - Task identity keys the marker: a fresh task/run is a fresh broadcast, so the submit-once rule stands. (The `REHYDRATION WARNING` headers in `gov_software_upgrade.go` + `gov_param_change.go` document the crash window and its shipped marker fix; retained post-pin.)

- **§seictl-shadow — `seictl@origin/main` (the shadow result-export pin).** The supported shadow comparison surface, pinned to **`origin/main`** (newer than the `79f74a5` gov pin — the shadow code post-dates it).
  - The `result-export` task + its 9-param request (`sidecar/tasks/result_export.go:36-107`; type `sidecar/engine/types.go:28`). `canonicalRpc` is the comparison-mode discriminator.
  - `sidecar/tasks/result_compare.go` holds the comparison loop, the watermark (`.sei-sidecar-last-export.json`), 100-block paging, `migrationMode` wiring, and the S3 output keys (`*.compare.ndjson.gz`, `divergence-{h}.report.json.gz`).
  - `sidecar/shadow/{types,comparator,layer0,layer1,layer2,keysource,metrics,report,render}.go` holds the L0/L1/L2 layer model, the migration verdict, and the touched-key trace source. It also holds the metrics (`seictl_shadow_blocks_compared_total`, `seictl_shadow_divergences_total{divergence_layer}`), the report, and the Markdown render.
  - The **typed-client gap**: `ResultExportTask` (`sidecar/client/tasks.go:305-336`) carries only `{bucket,prefix,region,canonicalRpc}`. The EVM/migration params need the **raw** `SubmitTask` (`sidecar/client/client.go:96`) / `POST /v0/tasks` (`sidecar/server/server.go:38-46,67`).
  - The `evm-logical-digest` task (`sidecar/tasks/evm_logical_digest.go`, type `engine/types.go:38`) is the adjacent at-tip full-keyspace task (seidb shell-out).
  - The migrate-EVM / mode-mismatch enum that moves a node into the shadow state is **external `sei-config`/seid-build-owned**. Cite it only as a *precondition concept*, never restate it. `config-patch`/`restart-seid` are a situational break-glass workaround, out of this kit's scope.

- **§seinode-task-lld — the seinode-task LLD / reference (CONTRACT ONLY; STALE on topology).** Cite for the **kind / lifecycle / idempotency contract** only. **Flagged STALE on topology** — it predates #417/#442 (still describes `SeiNodeDeployment` + Chaos-Mesh-Workflow fan-out). **Never cite it for topology / fan-out / signing-topology** — take those from §controller. (A separate follow-up carries the refresh of these docs, out of scope for this kit.)

- **§gov-ops — the `/gov-ops` skill (CITED, never restated — owner of the gates).** The shipped, anchor-coupled orchestration skill. **Owns:** the fail-closed gates (value-shape, deposit ≥ min_deposit, fees ≥ gas × min-gas-price, fanned proposalId == resolved submit id, code-13 / tally-stall HALT). It also owns the **GovVote fan-out template** (`fan-out.md`), the **fee-floor numbers**, and the **mainnet-adjacency allowlist + co-host refuse**. This skill **cites** these at the seam; it never restates a weaker version. `/gov-ops` keeps its existing seinode-task anchor citations **as-is** — do not re-point it through this skill.

- **§sei-skill — the public `sei-skill` inventory.** Dev-facing `seid` / gov / validator primitives (proposal types, vote options, `seid query gov`, validator key concepts). Cite for the on-chain / `seid`-CLI vocabulary an operator uses to verify a result on the chain.

- **§kubernetes — the `/kubernetes` skill (the controller-AUTHOR view).** Cite its profile + `kit-sidecar-task-integration` for the controller-author's reconcile/CRD-durability view of the same machinery. This skill is the **consumer** (operator driving manifests through the contract); `/kubernetes` is the author (reconcile-correctness, CRD durability, RBAC). Do not duplicate it — cite it.

**Anchor discipline:** every kit entry cites at least one of the pins above (a controller/seictl path-at-sha, the LLD contract, `/gov-ops`, `sei-skill`). A claim with no pin is not a corpus entry. **Cite** a fact `/gov-ops` owns (a gate, the fan-out template, the fee floor, the allowlist) **to §gov-ops**; never restate it.
