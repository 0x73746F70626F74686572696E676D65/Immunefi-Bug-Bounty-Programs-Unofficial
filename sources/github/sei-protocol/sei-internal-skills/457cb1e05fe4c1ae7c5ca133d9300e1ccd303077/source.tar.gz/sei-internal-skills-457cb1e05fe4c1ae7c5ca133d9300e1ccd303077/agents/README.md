# Agent bundles

Omni agent bundles — each a `config.yaml` (the omni agent spec) plus a `skills/`
directory carrying the discipline the bundle runs. These get baked into the
omnigent server's Docker image (`OMNIGENT_BUILTIN_AGENT_DIRS` points at them at
the in-image path). The server registers them as built-in agents on boot.

- `root-cause/` — the headless root-cause investigator.
- `sei-spec/` — spec-driven development, running GitHub Spec Kit for a human who
  selects it from the agent dropdown.
- `xreview-scout-codex/` — one independent reading of a pull request, on the
  codex harness, gathered before the review that merges it.
- `xreview-scout-cursor/` — the same contract on the cursor harness. Baked, not
  registered: its README lists the four prerequisites that stand between it and a
  live session.

`root-cause` is headless: a route resolves it by name and consumes
a returned verdict, so their bundle name is a machine contract. `sei-spec` is
interactive and co-driven. It vendors upstream Spec Kit skills rather than a copy
of a sei-internal-skills skill. Its update path is a re-vendor from a newer
spec-kit release.

Formerly `sei_omnigent/agents/`, alongside the custom overlay package for
omnigent. The platform retired that overlay and now runs vanilla omnigent
directly. These bundles are the only part of `sei_omnigent/` that is still live,
relocated here as a standalone concern.
