package review

import (
	"strings"
	"testing"
)

// TestDecisionIsDerivedWithTheConclusion is the contract behind the recorded decision:
// what the caller submits and what the check concludes come from one reading, and the
// word the reply wrote does not get to record an approval its own findings withhold.
func TestDecisionIsDerivedWithTheConclusion(t *testing.T) {
	t.Parallel()

	for _, tc := range []struct {
		name       string
		block      string
		said       string
		decision   string
		conclusion string
		notice     []string // in both the check summary and the comment footer
	}{
		{"clean approve",
			`{"read":40,"decision":"approve","summary":"s"}`,
			"approve", "approve", "success", nil},
		{"approve over suggestions",
			`{"read":40,"decision":"approve","summary":"s",
			  "non_blockers":["consider a table"]}`,
			"approve", "approve", "success", nil},
		{"request_changes with a blocker",
			`{"read":40,"decision":"request_changes","summary":"s",
			  "blockers":["nil deref in a.go"]}`,
			"request_changes", "request_changes", "failure", nil},
		{"approve beside a blocker",
			`{"read":40,"decision":"approve","summary":"s",
			  "blockers":["nil deref in a.go"]}`,
			"approve", "request_changes", "failure",
			[]string{"**Changes requested.**", "wrote `approve`", "nil deref in a.go"}},
		{"approve beside a line-tied blocker",
			`{"read":40,"decision":"approve","summary":"s",
			  "inline_comments":[{"path":"a.go","line":2,"side":"RIGHT",
			    "severity":"blocker","body":"unchecked error"}]}`,
			"approve", "request_changes", "failure",
			[]string{"**Changes requested.**", "unchecked error"}},
		{"approve beside an unaccepted pre-existing blocker",
			`{"read":40,"decision":"approve","summary":"Approving.",
			  "pre_existing_issues":[{"severity":"blocker","body":"b.go:4 leaks a handle"}]}`,
			"approve", "comment", "neutral",
			[]string{"**Approval withheld.**", "pre-existing blocker", "b.go:4 leaks a handle"}},
		{"approve that did not read the diff",
			`{"decision":"approve","summary":"s"}`,
			"approve", "comment", "neutral",
			[]string{"**Approval withheld.**", "did not show it read the diff"}},
		{"comment and nothing else",
			`{"read":40,"decision":"comment","summary":"s"}`,
			"comment", "comment", "neutral",
			[]string{"**No position recorded.**"}},
	} {
		t.Run(tc.name, func(t *testing.T) {
			t.Parallel()
			v := verdictFrom(t, tc.block)
			if got := v.Said(); got != tc.said {
				t.Errorf("Said() = %q, want %q", got, tc.said)
			}
			if got := v.Decision(); got != tc.decision {
				t.Errorf("Decision() = %q, want %q", got, tc.decision)
			}
			if got := v.CheckConclusion(); got != tc.conclusion {
				t.Errorf("CheckConclusion() = %q, want %q", got, tc.conclusion)
			}
			check, ok := BuildCheckRun(v, false)
			if !ok {
				t.Fatal("BuildCheckRun() = !ok on a verdict")
			}
			if check.Decision != tc.decision {
				t.Errorf("check.Decision = %q, want %q", check.Decision, tc.decision)
			}
			comment := RenderComment(v, false, "conv_1")
			if !strings.Contains(comment, "decision `"+tc.decision+"`") {
				t.Errorf("the footer does not carry the recorded decision %q:\n%s",
					tc.decision, comment)
			}
			for _, want := range tc.notice {
				if !strings.Contains(check.Summary, want) {
					t.Errorf("check summary lacks %q:\n%s", want, check.Summary)
				}
				if !strings.Contains(comment, want) {
					t.Errorf("comment lacks %q:\n%s", want, comment)
				}
			}
			if tc.notice == nil {
				for _, stray := range []string{"withheld", "No position", "Changes requested."} {
					if strings.Contains(check.Summary, stray) {
						t.Errorf("check summary carries an unwarranted notice %q:\n%s",
							stray, check.Summary)
					}
				}
			}
		})
	}
}

// TestTheNoticeIsAheadOfTheSections: the withheld notice follows the summary and comes
// before every section, so a long list of findings cannot push it down the page, and the
// reply's own prose -- however long -- is not what the comment publishes.
func TestTheNoticeIsAheadOfTheSections(t *testing.T) {
	t.Parallel()

	pad := strings.Repeat("Approving, this all looks fine.\n", 4000)
	v := ParseVerdict(pad + "\n```json\n" + `{"read":40,"decision":"approve","summary":"s",
	  "non_blockers":["a design note"],
	  "pre_existing_issues":[{"severity":"blocker","body":"b.go:4 leaks a handle"}]}` + "\n```")
	body := RenderComment(v, false, "conv_1")
	if strings.Contains(body, "Approving, this all looks fine.") {
		t.Fatalf("the reply's prose reached the comment:\n%s", body[:300])
	}
	notice := strings.Index(body, "**Approval withheld.**")
	section := strings.Index(body, "### Non-blocking")
	if notice < 0 || section < 0 || notice > section {
		t.Errorf("the notice (at %d) is not ahead of the first section (at %d):\n%s",
			notice, section, body)
	}
	for _, want := range []string{"b.go:4 leaks a handle", "decision `comment`"} {
		if !strings.Contains(body, want) {
			t.Errorf("%q is missing from the comment", want)
		}
	}
}

// TestScoutSettlementRecordsApproveWithoutANotice: a verdict the scouts settled is an
// approve on its own terms and the position has nothing to add.
func TestScoutSettlementRecordsApproveWithoutANotice(t *testing.T) {
	t.Parallel()

	v, ok := SettleByScouts(Request{Scouts: []ScoutResult{
		{Name: "codex", Lines: 3, Inert: true},
	}})
	if !ok {
		t.Fatal("SettleByScouts() = !ok on an inert, clean reading")
	}
	if got := v.Decision(); got != "approve" {
		t.Errorf("Decision() = %q, want approve", got)
	}
	if got := v.CheckConclusion(); got != "success" {
		t.Errorf("CheckConclusion() = %q, want success", got)
	}
	if p := v.position(); p != "" {
		t.Errorf("position() = %q, want empty on a settled verdict", p)
	}
}

// TestAcceptedPreExistingBlockerDoesNotWithhold is the acknowledgement path, enforced
// in Go: the same finding vetoes without the base branch's acceptance and clears with
// it, and in both cases it stays on the page.
func TestAcceptedPreExistingBlockerDoesNotWithhold(t *testing.T) {
	t.Parallel()

	const block = `{"read":40,"decision":"approve","summary":"s",
	  "pre_existing_issues":[
	    {"severity":"blocker","body":"go.mod pins uci to the feature branch, not a tag"},
	    {"severity":"suggestion","body":"README drifts from the flags"}]}`
	accepted := ParseAccepted("# Review\n\n## Accepted pre-existing conditions\n\n" +
		"- pins `uci` to the feature branch — deliberate until PLT-1300 lands\n")
	if len(accepted) != 1 {
		t.Fatalf("ParseAccepted() = %q, want one entry", accepted)
	}

	unaccepted := verdictFrom(t, block)
	if got := unaccepted.Decision(); got != "comment" {
		t.Errorf("without an acceptance Decision() = %q, want comment", got)
	}

	v := verdictFrom(t, block)
	v.Accepted = accepted
	if got := v.Decision(); got != "approve" {
		t.Errorf("with the acceptance Decision() = %q, want approve", got)
	}
	if got := v.CheckConclusion(); got != "success" {
		t.Errorf("with the acceptance CheckConclusion() = %q, want success", got)
	}
	issues := PreExisting(v)
	if len(issues) != 2 {
		t.Fatalf("PreExisting() = %d issues, want both kept", len(issues))
	}
	if issues[0].Accepted != accepted[0] {
		t.Errorf("issues[0].Accepted = %q, want the acceptance verbatim", issues[0].Accepted)
	}
	if issues[1].Accepted != "" {
		t.Errorf("issues[1].Accepted = %q, want none: the suggestion matched nothing",
			issues[1].Accepted)
	}
	check, _ := BuildCheckRun(v, false)
	for _, want := range []string{
		"**blocker, accepted**", "pins uci to the feature branch", "PLT-1300",
		"**Accepted pre-existing blocker**",
	} {
		if !strings.Contains(check.Summary, want) {
			t.Errorf("check summary lacks %q:\n%s", want, check.Summary)
		}
	}
	if strings.Contains(check.Summary, "Approval withheld") {
		t.Errorf("check summary still withholds:\n%s", check.Summary)
	}
	if comment := RenderComment(v, false, "conv_1"); !strings.Contains(comment, "**Accepted pre-existing blocker**") {
		t.Errorf("comment does not name the acceptance:\n%s", comment)
	}
}

// TestAcceptanceIsNarrow: an entry accepts one condition, not a category, and a
// second blocker beside an accepted one still withholds.
func TestAcceptanceIsNarrow(t *testing.T) {
	t.Parallel()

	accepted := ParseAccepted("## Accepted\n- pins uci to the feature branch\n")
	v := verdictFrom(t, `{"read":40,"decision":"approve","summary":"s",
	  "pre_existing_issues":[
	    {"severity":"blocker","body":"go.mod pins uci to the feature branch"},
	    {"severity":"blocker","body":"c.go:9 writes the token to the log"}]}`)
	v.Accepted = accepted
	if got := v.Decision(); got != "comment" {
		t.Errorf("Decision() = %q, want comment: the second blocker is not accepted", got)
	}
	check, _ := BuildCheckRun(v, false)
	if !strings.Contains(check.Summary, "writes the token to the log") {
		t.Errorf("the notice does not name the blocker that withheld:\n%s", check.Summary)
	}
}

func TestParseAccepted(t *testing.T) {
	t.Parallel()

	for _, tc := range []struct {
		name string
		text string
		want []string
	}{
		{"no section", "# Review\n\n- pins uci to the feature branch\n", nil},
		{"the section, then another heading ends it",
			"## Accepted pre-existing conditions\n- pins uci to the feature branch\n" +
				"## Style\n- prefer short names here\n",
			[]string{"pins uci to the feature branch"}},
		{"star bullets and a rationale",
			"### Accepted\n* pins uci to the feature branch -- until PLT-1300\n",
			[]string{"pins uci to the feature branch -- until PLT-1300"}},
		{"too short to name one condition",
			"## Accepted\n- pin\n- the pin\n- blocker — anything\n",
			nil},
		{"a heading that merely contains the word",
			"## Not accepted\n- pins uci to the feature branch\n", nil},
		{"crlf", "## Accepted\r\n- pins uci to the feature branch\r\n",
			[]string{"pins uci to the feature branch"}},
		{"a heading that only begins with the word",
			"## Acceptedness of pins\n- pins uci to the feature branch\n", nil},
		{"a heading with the word later",
			"## Conditions accepted on main\n- pins uci to the feature branch\n", nil},
		{"an example in a fence is not an entry",
			"## Accepted\n```markdown\n- pins uci to the feature branch\n```\n" +
				"- reads the token from the env\n",
			[]string{"reads the token from the env"}},
	} {
		t.Run(tc.name, func(t *testing.T) {
			t.Parallel()
			got := ParseAccepted(tc.text)
			if strings.Join(got, "|") != strings.Join(tc.want, "|") {
				t.Errorf("ParseAccepted() = %q, want %q", got, tc.want)
			}
		})
	}
}

func TestAcceptanceMatchingFoldsForm(t *testing.T) {
	t.Parallel()

	accepted := []string{"pins `uci` to the feature branch — deliberate"}
	for body, want := range map[string]bool{
		"go.mod PINS uci   to the feature branch instead of a tag": true,
		"pins 'uci' to the feature branch":                         true,
		"pins uci to a tag":                                        false,
		"":                                                         false,
		"go.mod no longer pins uci to the feature branch":                  false,
		"the module is untagged, so go.mod pins uci to the feature branch": true,
		"pins uci to the feature branch and leaks the token":               false,
		"pins uci to the feature branch; the token is logged":              false,
		"pins uci to the feature branch, which has no tag":                 true,
	} {
		if got := acceptanceFor(body, accepted) != ""; got != want {
			t.Errorf("acceptanceFor(%q) matched = %v, want %v", body, got, want)
		}
	}
}

func TestTheAcceptedSourceIsRecorded(t *testing.T) {
	t.Parallel()

	v := verdictFrom(t, `{"read":40,"decision":"approve","summary":"s",
	  "pre_existing_issues":[
	    {"severity":"blocker","body":"go.mod pins uci to the feature branch"}]}`)
	v.Accepted = []string{"pins uci to the feature branch"}
	check, _ := BuildCheckRun(v, false)
	if check.AcceptedFrom != "" || !strings.Contains(check.Summary, "accepted on the base branch:") {
		t.Errorf("with no ref reported, want the base branch named:\n%s", check.Summary)
	}
	v.AcceptedFrom = "main"
	check, _ = BuildCheckRun(v, false)
	if check.AcceptedFrom != "main" || !strings.Contains(check.Summary, "accepted on `main`:") {
		t.Errorf("AcceptedFrom = %q; want main in the check and the section:\n%s",
			check.AcceptedFrom, check.Summary)
	}
	if notice := v.position(); !strings.Contains(notice, "listed under Accepted in `main`'s") {
		t.Errorf("the notice does not name the ref:\n%s", notice)
	}
}

func TestOnlyAWithholdingFindingIsMarkedAccepted(t *testing.T) {
	t.Parallel()

	v := verdictFrom(t, `{"read":40,"decision":"approve","summary":"s",
	  "pre_existing_issues":[
	    {"severity":"suggestion","body":"go.mod pins uci to the feature branch"}]}`)
	v.Accepted = []string{"pins uci to the feature branch"}
	if issues := PreExisting(v); len(issues) != 1 || issues[0].Accepted != "" {
		t.Errorf("PreExisting() = %+v; a suggestion lifts no veto and is not marked accepted", issues)
	}
	check, _ := BuildCheckRun(v, false)
	if strings.Contains(check.Summary, "accepted") {
		t.Errorf("the check says accepted where nothing was withheld:\n%s", check.Summary)
	}
}

func TestTheNoticeCountsAndClipsWhatItNames(t *testing.T) {
	t.Parallel()

	long := strings.Repeat("x", maxPositionText+50)
	v := verdictFrom(t, `{"read":40,"decision":"approve","summary":"s",
	  "pre_existing_issues":[
	    {"severity":"blocker","body":"one is the first blocker"},
	    {"severity":"blocker","body":"two is the second blocker"},
	    {"severity":"blocker","body":"three is the third blocker"},
	    {"severity":"blocker","body":"four is the fourth blocker"},
	    {"severity":"blocker","body":"`+long+`"}]}`)
	notice := v.position()
	if !strings.Contains(notice, "; and 2 more.") {
		t.Errorf("the notice does not count the findings past %d:\n%s", maxPositionNamed, notice)
	}
	if strings.Contains(notice, "four is the fourth") || strings.Contains(notice, long) {
		t.Errorf("the notice names past its bound:\n%s", notice)
	}
	v.Structured["pre_existing_issues"] = []any{map[string]any{"severity": "blocker", "body": long}}
	if notice := v.position(); strings.Contains(notice, long) || !strings.Contains(notice, strings.Repeat("x", 50)) {
		t.Errorf("a long finding is not clipped to %d:\n%s", maxPositionText, notice)
	}
}
