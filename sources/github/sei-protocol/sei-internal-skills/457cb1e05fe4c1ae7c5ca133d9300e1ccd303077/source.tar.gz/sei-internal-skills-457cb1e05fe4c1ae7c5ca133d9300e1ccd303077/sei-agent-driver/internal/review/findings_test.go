package review

import (
	"encoding/json"
	"strings"
	"testing"
)

// TestPlaceableFindingsDropsWhatCannotBePlaced pins the rule that decides which
// observations become inline comments.
//
// A review comment needs a path and a line. An entry missing either has nowhere
// to go, and posting it somewhere arbitrary attributes a finding to code it is
// not about. Everything dropped here still travels in the summary comment's
// prose, so the review is not lost — only its placement.
func TestPlaceableFindingsDropsWhatCannotBePlaced(t *testing.T) {
	t.Parallel()

	v := ParseVerdict("prose\n\n```json\n" + `{"read": 120, "decision": "comment","summary":"s","findings":[
		{"file":"a.go","line":12,"severity":"high","detail":"placeable"},
		{"file":"","line":9,"severity":"low","detail":"no file"},
		{"file":"b.go","line":0,"severity":"low","detail":"no line"},
		{"file":"c.go","line":"34","severity":"low","detail":"line as a string"},
		{"file":"d.go","line":7,"severity":"low","detail":""},
		"not an object"
	]}` + "\n```")

	got := PlaceableFindings(v, true, nil)
	if len(got) != 2 {
		t.Fatalf("placeable findings = %d, want 2: %+v", len(got), got)
	}
	if got[0].File != "a.go" || got[0].Line != 12 {
		t.Errorf("first = %+v, want a.go:12", got[0])
	}
	// A quoted number is still a number; an agent hand-writing JSON quotes them
	// often enough that refusing would drop real findings.
	if got[1].File != "c.go" || got[1].Line != 34 {
		t.Errorf("second = %+v, want c.go:34 from a quoted line", got[1])
	}
}

// TestPlaceableFindingsOnNoVerdict keeps a reply with no structured block from
// producing inline comments.
func TestPlaceableFindingsOnNoVerdict(t *testing.T) {
	t.Parallel()

	if got := PlaceableFindings(ParseVerdict("just prose, no block"), true, nil); len(got) != 0 {
		t.Errorf("placeable findings = %d, want 0 when there is no verdict", len(got))
	}
}

// TestPlaceableFindingsReadsTheCurrentContract covers the buckets a review sorts
// its observations into, including side, which is what makes a finding about a
// removed line placeable at all.
func TestPlaceableFindingsReadsTheCurrentContract(t *testing.T) {
	t.Parallel()

	v := verdictFrom(t, `{"read": 120, "decision": "request_changes","summary":"s",
	  "inline_comments":[
	    {"path":"a.go","line":10,"side":"RIGHT","severity":"blocker","body":"boom"},
	    {"path":"b.go","line":4,"side":"LEFT","severity":"nit","body":"gone"},
	    {"path":"c.go","line":0,"severity":"nit","body":"unplaceable"}],
	  "blockers":["needs a test"],
	  "non_blockers":["naming could be clearer"],
	  "pre_existing_issues":[{"severity":"nit","body":"old thing"}]}`)

	got := PlaceableFindings(v, true, nil)
	if len(got) != 2 {
		t.Fatalf("placed %d findings, want 2 (the line-less one is dropped): %+v", len(got), got)
	}
	if got[0].Side != "RIGHT" || got[1].Side != "LEFT" {
		t.Errorf("sides = %q, %q; want RIGHT, LEFT", got[0].Side, got[1].Side)
	}
	if got[0].Severity != "blocker" || got[0].Detail != "boom" || got[0].File != "a.go" {
		t.Errorf("first finding = %+v", got[0])
	}
	if b := Blockers(v); len(b) != 1 || b[0] != "needs a test" {
		t.Errorf("Blockers = %v", b)
	}
	if n := NonBlockers(v); len(n) != 1 {
		t.Errorf("NonBlockers = %v", n)
	}
	pre := PreExisting(v)
	if len(pre) != 1 || pre[0].Body != "old thing" {
		t.Fatalf("PreExisting = %+v", pre)
	}
	if pre[0].Severity != "suggestion" {
		t.Errorf("pre-existing severity = %q, want suggestion: the bucket takes "+
			"blocker or suggestion, and a nit about untouched code is noise",
			pre[0].Severity)
	}
}

// TestPlaceableFindingsStillReadsTheOlderContract is the one that stops a schema change
// from going silent. A session that reviewed before this contract carries its first
// prompt in context and cannot be told otherwise, so it keeps answering in the vocabulary
// it learned. Reading only the new keys would place nothing on every pull request already
// reviewed, and report success while doing it.
func TestPlaceableFindingsStillReadsTheOlderContract(t *testing.T) {
	t.Parallel()

	v := verdictFrom(t, `{"read": 120, "decision": "comment","summary":"s",
	  "findings":[{"file":"a.go","line":10,"severity":"high","detail":"boom"},
	              {"file":"b.go","line":2,"severity":"low","detail":"minor"}]}`)

	got := PlaceableFindings(v, true, nil)
	if len(got) != 2 {
		t.Fatalf("placed %d, want 2: %+v", len(got), got)
	}
	if got[0].Severity != "blocker" || got[1].Severity != "nit" {
		t.Errorf("severities = %q, %q; want blocker, nit (high/low map on)",
			got[0].Severity, got[1].Severity)
	}
	if got[0].Side != "RIGHT" {
		t.Errorf("side = %q, want RIGHT: a finding written before side existed "+
			"meant the new file", got[0].Side)
	}
}

// TestCheckConclusion pins the mapping the check run is published under.
func TestCheckConclusion(t *testing.T) {
	t.Parallel()

	for decision, want := range map[string]string{
		"request_changes": "failure",
		// comment over EMPTY buckets, which is what this block carries. The prompt tells
		// the reply to say comment when it could not read the diff or the tree, and the
		// tree read has no count of its own -- so nothing written down beside that word
		// is a review that did not happen. comment WITH notes reaches success; that case
		// is in TestCheckConclusionFollowsTheFindings.
		"comment": "neutral",
		"approve": "success",
	} {
		v := verdictFrom(t, `{"read": 120, "decision": "`+decision+`","summary":"s"}`)
		if got := v.CheckConclusion(); got != want {
			t.Errorf("decision %q -> %q, want %q", decision, got, want)
		}
	}
	if got := (Verdict{}).CheckConclusion(); got != "" {
		t.Errorf("no verdict -> %q, want empty", got)
	}
}

// verdictFrom parses a closing block the way a real reply carries one.
func verdictFrom(t *testing.T, block string) Verdict {
	t.Helper()
	v := ParseVerdict("Review prose.\n\n```json\n" + block + "\n```\n")
	if !v.HasVerdict() {
		t.Fatalf("no verdict parsed from %s", block)
	}
	return v
}

// TestPlaceableFindingsReadsBothKeysWhenTheNewOneIsEmpty is the case a fallback misses. A
// session shown the current schema on re-review knows the new key exists and writes it
// empty, while still reporting under the vocabulary its first prompt taught. Reading the
// old key only when the new one is ABSENT places nothing here, and reports success doing
// it.
func TestPlaceableFindingsReadsBothKeysWhenTheNewOneIsEmpty(t *testing.T) {
	t.Parallel()

	v := verdictFrom(t, `{"read": 120, "decision": "comment","summary":"s",
	  "inline_comments":[],
	  "findings":[{"file":"a.go","line":9,"severity":"high","detail":"boom"}]}`)

	got := PlaceableFindings(v, true, nil)
	if len(got) != 1 {
		t.Fatalf("placed %d, want 1: an empty inline_comments must not hide a "+
			"filled findings", len(got))
	}
	if got[0].Severity != "blocker" || got[0].File != "a.go" {
		t.Errorf("finding = %+v", got[0])
	}
}

// TestPlaceableFindingsDedupesAcrossKeys covers the other half of reading both:
// a reply that wrote one finding under each key means it once.
func TestPlaceableFindingsDedupesAcrossKeys(t *testing.T) {
	t.Parallel()

	v := verdictFrom(t, `{"read": 120, "decision": "comment","summary":"s",
	  "inline_comments":[{"path":"a.go","line":9,"side":"RIGHT","severity":"blocker","body":"boom"}],
	  "findings":[{"file":"a.go","line":9,"severity":"high","detail":"boom"}]}`)

	if got := PlaceableFindings(v, true, nil); len(got) != 1 {
		t.Fatalf("placed %d, want 1: the same finding under both keys is one "+
			"finding, and posting it twice is noise on the author's diff", len(got))
	}
}

// TestTheVerdictShapeIsOnBothPathsAndTheProseIsNot pins the one asymmetry in what a
// re-review is re-sent.
//
// Both prompts carry the closing block's schema. Only the first carries the prose that
// explains how to sort observations into it, because the adopted prompt reaches a session
// that already holds it and re-sending it is what that prompt exists not to do.
//
// The schema is the exception because its decay is the only silent one: a turn that stops
// emitting the block produces a review nobody sees, since the driver refuses it and exits
// ExitNoVerdict. A forgotten sorting rule produces a worse review, which a reader sees.
func TestTheVerdictShapeIsOnBothPathsAndTheProseIsNot(t *testing.T) {
	t.Parallel()

	req := Request{Repo: "sei-protocol/sandbox", PR: 42}
	first, adopted := BuildPrompt(req), AdoptedPrompt(req)

	// The schema, on both -- and the one field rule that rides with it. read is the second
	// silent decay: a turn that copies the shape it was handed reports read: 0, which reads
	// as a review of nothing and degrades a clean re-review from success to neutral with no
	// error anywhere.
	for name, prompt := range map[string]string{"BuildPrompt": first, "AdoptedPrompt": adopted} {
		for _, want := range []string{
			"```json", "inline_comments", "blockers", "non_blockers", "pre_existing_issues",
			"read is the line count the diff command printed",
		} {
			if !strings.Contains(prompt, want) {
				t.Errorf("%s does not carry %q; a turn that cannot see the block's shape "+
					"produces a review nobody sees", name, want)
			}
		}
	}

	// And the placeholder is not copyable into the sentinel.
	for name, prompt := range map[string]string{"BuildPrompt": first, "AdoptedPrompt": adopted} {
		if strings.Contains(prompt, `"read": 0`) {
			t.Errorf("%s hands the agent `\"read\": 0` as the shape. Filling that in "+
				"verbatim reports a review of nothing and silently downgrades the check",
				name)
		}
	}

	// The sorting prose, on the first only.
	for _, prose := range []string{
		"side is RIGHT for an added or changed line",
		"blocker, suggestion or nit",
		"Sort each one:",
	} {
		if !strings.Contains(first, prose) {
			t.Errorf("BuildPrompt does not carry %q", prose)
		}
		if strings.Contains(adopted, prose) {
			t.Errorf("AdoptedPrompt carries %q. The session already holds it, and "+
				"re-sending it is the cost that prompt exists to avoid", prose)
		}
	}
}

// TestBothPromptsCarryTheRepoContext pins the standards and intent a review
// Adding a step to one prompt and not the other is how a rule reaches the first dispatch
// on a pull request and no dispatch after it. The adopted path is the one almost every
// review takes.
func TestBothPromptsCarryTheRepoContext(t *testing.T) {
	t.Parallel()

	req := Request{Repo: "sei-protocol/sandbox", PR: 42}
	for name, prompt := range map[string]string{
		"BuildPrompt":   BuildPrompt(req),
		"AdoptedPrompt": AdoptedPrompt(req),
	} {
		for _, want := range []string{
			// From the BASE branch. Read from the working tree, a change that edits the standards
			// would be handing itself the ones it is judged against. They outrank this prompt's
			// checklist, which makes that a way to approve anything.
			"--json baseRefName",
			"REVIEW.md?ref=$base",
			"never from pr-42-tree",
			"outrank the review checklist",
			// Each command on its own indented line. Run together with the prose, an
			// agent copying it literally asked gh for a field called "body." and got
			// no intent at all.
			"\n    gh pr view 42 --repo sei-protocol/sandbox --json title,body\n",
			"never justify one",
		} {
			if !strings.Contains(prompt, want) {
				t.Errorf("%s does not carry %q", name, want)
			}
		}
	}
}

// TestPlaceablePathsAreJudgedAsRepoPaths pins the rule an inline comment's path is held
// to, and which sink that rule belongs to.
//
// The path travels in a JSON request body to the GitHub review-comment API, not through a
// shell. So the question is whether it is a repository-relative file path, not whether it
// would survive interpolation: c++/, @types/, a route group in parentheses and a path with
// a space are files a review has to be able to comment on, and a character allowlist drops
// every one of them onto the floor.
//
// The refusals are the other half. A path that is absolute, that reaches for home, that
// traverses, that carries an empty or dot segment, that holds a control character, that
// argv would read as an option, or that no checkout could hold, is not naming a file in
// this pull request. Both halves run through the same harness, so a harness that accepted
// or refused everything fails here rather than passing quietly.
func TestPlaceablePathsAreJudgedAsRepoPaths(t *testing.T) {
	t.Parallel()

	for _, tc := range []struct {
		path  string
		want  bool
		about string
	}{
		{"src/main.go", true, "an ordinary path"},
		{"c++/parser.cc", true, "a directory named for the language"},
		{"@types/node/index.d.ts", true, "a scoped package"},
		{"app/(marketing)/page.tsx", true, "a route group"},
		{"app/[slug]/page.tsx", true, "a dynamic route"},
		{"docs/design notes.md", true, "a path with a space"},
		{"docs/Q&A.md", true, "a path with an ampersand"},
		{"pkg/v2..1/x.go", true, "dots inside a segment, which traverse nothing"},

		{"", false, "no path at all"},
		{"/etc/passwd", false, "absolute"},
		{"~/.aws/credentials", false, "a home reference"},
		{"../../../etc/shadow", false, "a traversal"},
		{"a/../../etc/shadow", false, "a traversal partway along"},
		{"./a.go", false, "a dot segment"},
		{"a//b.go", false, "an empty segment"},
		{"src/", false, "a directory, which is not a file to comment on"},
		{"a\nb.go", false, "a newline"},
		{"a\x00b.go", false, "a NUL"},
		{"-rf", false, "a leading dash argv would read as an option"},
		{strings.Repeat("a", 256) + "/x.go", false, "a segment no checkout could hold"},
	} {
		got := placedPaths(t, tc.path)
		if tc.want && len(got) != 1 {
			t.Errorf("%q (%s) placed %d comments, want 1", tc.path, tc.about, len(got))
			continue
		}
		if !tc.want && len(got) != 0 {
			t.Errorf("%q (%s) placed %d comments, want 0", tc.path, tc.about, len(got))
			continue
		}
		if tc.want && got[0].File != tc.path {
			t.Errorf("%q placed as %q; the path is posted verbatim", tc.path, got[0].File)
		}
	}
}

// placedPaths runs one inline comment on path through the whole reply-reading path, so
// what is asserted is what a caller would post. The block is marshalled rather than
// written out, which keeps a path carrying a control character exact.
func placedPaths(t *testing.T, path string) []Finding {
	t.Helper()
	block, err := json.Marshal(map[string]any{
		"read": 120, "decision": "comment", "summary": "s",
		"inline_comments": []any{map[string]any{
			"path": path, "line": 12, "side": "RIGHT",
			"severity": "blocker", "body": "boom",
		}},
	})
	if err != nil {
		t.Fatalf("building the reply block: %v", err)
	}
	return PlaceableFindings(verdictFrom(t, string(block)), true, nil)
}

// TestPlaceableFindingsGatesNits pins the rule that a nit is placed only when the
// pull request asked for one.
//
// Both directions on one fixture, because the interesting failure is a gate wired to
// a constant: a filter that always drops passes a drop-only test, and one that never
// drops passes a keep-only test.
func TestPlaceableFindingsGatesNits(t *testing.T) {
	v := verdictFrom(t, `{"read":40,"decision":"comment","summary":"s",
	  "inline_comments":[
	    {"path":"a.go","line":1,"side":"RIGHT","severity":"blocker","body":"real"},
	    {"path":"b.go","line":2,"side":"RIGHT","severity":"nit","body":"polish"}]}`)

	off := PlaceableFindings(v, false, nil)
	if len(off) != 1 || off[0].Severity != "blocker" {
		t.Fatalf("with nits off = %+v; want the blocker alone", off)
	}

	on := PlaceableFindings(v, true, nil)
	if len(on) != 2 {
		t.Fatalf("with nits on = %+v; want both", on)
	}
	if on[1].Severity != "nit" {
		t.Errorf("second severity = %q; want nit", on[1].Severity)
	}
}

// TestDroppedNitDoesNotClaimTheDedupeKey covers the ordering inside the loop.
//
// [Finding.dedupeKey] carries no severity, so a nit and a blocker reported about the
// same line in the same words share one key. Checking the severity after the key is
// recorded would let the dropped nit suppress the blocker — a review that silently
// loses its only real finding, which is the worst outcome this file can produce.
func TestDroppedNitDoesNotClaimTheDedupeKey(t *testing.T) {
	v := verdictFrom(t, `{"read":40,"decision":"request_changes","summary":"s",
	  "inline_comments":[
	    {"path":"a.go","line":7,"side":"RIGHT","severity":"nit","body":"same words"},
	    {"path":"a.go","line":7,"side":"RIGHT","severity":"blocker","body":"same words"}]}`)

	got := PlaceableFindings(v, false, nil)
	if len(got) != 1 {
		t.Fatalf("got %d findings %+v; want the blocker alone", len(got), got)
	}
	if got[0].Severity != "blocker" {
		t.Errorf("severity = %q; want blocker — the dropped nit claimed the key", got[0].Severity)
	}
}
