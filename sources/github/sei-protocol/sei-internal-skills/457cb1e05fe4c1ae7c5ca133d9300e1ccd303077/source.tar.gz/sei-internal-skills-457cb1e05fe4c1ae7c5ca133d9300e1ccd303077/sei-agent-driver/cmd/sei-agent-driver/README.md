# review

`review` drives one seidroid review of a pull request inside an Omnigent
managed sandbox: it resolves the `seidroid` agent, creates or adopts **the
session for that pull request**, sends the review prompt,
answers whatever permission prompts the turn parks on (allowing only what an
operator listed — see [Permission policy](#permission-policy)), and reads a
verdict out of the
agent's final message. It is the Go successor to this repository's Python
driver and keeps that driver's contract: the same environment variables and the
same exit codes.

**One session per pull request, not per invocation.** The session is the agent's
memory of having reviewed this pull request, so a review ends by *stopping* the
turn rather than deleting it, and the next dispatch on the same pull
request picks up the same conversation — it can say what changed since, and
whether what it raised last time was addressed. An earlier version keyed the
session on the trigger and deleted it on the way out, which meant every
invocation met the diff with no memory of the previous one.

The session is destroyed when the pull request closes or merges (`--close`). That
is also the only thing that reclaims the sandbox: the Kubernetes launcher reports
`resume_stopped=false`, so a stopped host cannot be woken in place and the host
stays up while the session exists. Nothing else reclaims it: the Kubernetes
launcher sets no lifetime cap and the server runs no sweep, so a close event that
never arrives leaves a pod holding its cpu and memory indefinitely.

It is normally invoked by a workflow rather than run by hand. The caller lives in the
repository being reviewed: a thin workflow there dispatches `seidroid-review.yml` on a
`seidroid review` comment, and on a pull request closing. This file names no caller, because that file belongs to
the other repository and this one cannot keep the reference true. Every input below is a plain environment variable or CLI flag, so it also runs
the same way in a terminal.

## Usage

```
sei-agent-driver review <owner/name> <pr-number> [--out FILE] [--trigger-id ID] [...]
```

- `<owner/name> <pr-number>` — the pull request to review. Both are
  required; anything else is a configuration error (`ExitConfig`), not a
  request sent to the server.
- `--out FILE` — write the verdict text here for a caller to post. **The file
  is written only when the turn produced a real verdict.** Its absence is
  how a caller distinguishes "nothing to post" from "posted"; a failed or
  no-verdict run must never see a stale or placeholder file where a previous
  good review's output used to be. (This CLI never writes it as a
  placeholder — the caller-side rule is simply: don't create one and don't
  upsert on absence.)
- `--close` — delete this pull request's session instead of reviewing, and the
  scouts' sessions with it. The only thing that reclaims a sandbox. Wired in the
  reviewed repository's caller, on `pull_request: [closed]`; nothing in this
  repository invokes it.
- `--trigger-id ID` — identifies this dispatch in the logs, e.g. the GitHub
  comment id that fired the run. **Not** part of the session key any more — the
  session is keyed on the pull request. Defaults to
  `run:$GITHUB_RUN_ID/$GITHUB_RUN_ATTEMPT` (from the environment) and, failing
  that, a deterministic `manual:owner/name#pr` key. Every dispatch for a pull
  request adopts that pull request's one session and drives a fresh review turn
  on the current tree, whatever the trigger id is — nothing is skipped as a
  duplicate. Pass an explicit id so an automated dispatch is identifiable when
  reading back a reused session's history.

Machine-readable output (session id, exit code, teardown flag, and the
decision when there is one) is printed to stdout as JSON on every run;
logs go to stderr as structured (`slog`) JSON.

The remaining flags are optional and default to off. Each output flag writes only
when there is something to write, on the same rule as `--out`: absence is the
signal, so a caller never posts a stale file from a previous run.

- `--findings-out FILE` — write the observations that name a line, as json, for a
  caller to post as inline comments. Empty when the review placed none, which is
  ordinary rather than a failure.
- `--check-out FILE` — write the check run as json: conclusion, title and summary.
  The conclusion is derived from the findings, not from the word the agent used for
  itself, so a review that says `approve` while listing blockers still fails. A
  no-verdict run writes this file too: it concludes `failure` under the title `no
  verdict`, it carries the reason there is none, and it carries no `counts` key. So a
  caller publishes whatever it finds at this path, and reads the **title** to tell the
  two apart — `failure` is also what a decided review carrying blockers concludes, so
  the conclusion alone does not separate them. An absent `counts` says the same thing.
  Read that absence as absent, never as zero — "nothing blocking" over a review nobody
  could read is the one wrong answer here. The `failure` holds a merge wherever the
  check is required, and it reports a change this tool could not read rather than a
  bad one.

  The file also carries `decision`: the position this tool records, `approve`,
  `comment` or `request_changes`, derived in the same reading as the conclusion. A
  caller submits it as the review event verbatim and recomputes nothing from the
  conclusion. It is `approve` only where nothing withholds — the reply affirmed it read
  the diff, nothing blocks, and no pre-existing blocker stands unaccepted. An `approve`
  the reply wrote beside a blocker records `request_changes`; beside an unaccepted
  pre-existing blocker, or without a read count, it records `comment`. Wherever the
  recorded decision parts from the word the reply wrote, the check summary opens with a
  notice saying what was recorded and which finding decided it, and the same notice
  rides in the published comment's footer, ahead of anything truncation removes. A
  no-verdict run carries no `decision`.

  The file also carries a `threads` object, on the same reasoning as `counts`: it is
  no part of the check run GitHub publishes, and it rides here because this is the
  file a caller already reads.

  ```json
  "threads": { "addressed": [], "superseded": [], "refused": [], "refused_total": 0 }
  ```

  `addressed` are the threads whose finding the change fixed — resolve them whenever
  the review publishes. `superseded` are the threads a new inline comment restates —
  resolve them only once those comments are on the code, because a thread closed
  behind a comment that never posted takes a live finding off the pull request.

  An id that any inline comment claims never appears under `addressed`, whether or not
  the reply also named it there. It appears under `superseded` when that comment is one
  this run can place, and under neither key when it is not — a nit dropped by the
  `--include-nits` setting, or a finding naming no line, replaces nothing and so closes
  nothing. Either way a reply that contradicts itself costs a thread left open rather
  than a finding taken off the diff.

  `refused` are the ids the reply named that match no thread supplied through
  `--conversation-context`; report them and resolve nothing. It carries at most 20,
  and `refused_total` is how many there were — read that rather than the list's
  length, because a review inventing thousands of ids and one that slipped once are
  different problems. An older binary writes no `threads` key, and a caller reading
  its absence resolves nothing.
- `--guidelines-file PATH` — a path *inside the reviewed repository* holding the
  guidance that repository adds to every review. Defaults to `REVIEW.md`, which is
  read whether or not this is passed; a repository without that file is reviewed
  against the checklist alone, silently and by design. The value must be a plain
  repository-relative path — a space, an `@`, a leading `/` or a `..` falls back to
  the default rather than failing, so check the logged path if standards seem not to
  be applying. Read by the agent in its sandbox, not by this process.
- `--base-standards-file PATH` — a local copy of the same standards file as it stands
  on the pull request's **base** branch, for this process to read. `--guidelines-file`
  names what the agent reads for guidance in its sandbox; this is what the driver
  enforces, and the driver cannot fetch it itself. Its `Accepted` section lists the
  pre-existing blockers that do not withhold approval: a heading opening with the word `Accepted`, then one
  bullet per condition, until the next heading. The text before an em dash or ` -- ` is
  the phrase a finding must contain to match; what follows is the rationale, carried
  into the check and the comment as the authority. A bullet under three words is
  dropped, because two words name a category, not a condition. A phrase matches only
  where it carries the finding: not where the finding negates it (`no longer pins uci
  to the feature branch`) and not where the finding goes on to a second claim (`pins
  uci to the feature branch and leaks the token`). Both fail closed — the blocker
  withholds and the notice names it — so reword the entry or the finding rather than
  expecting a wider match.

  ```markdown
  ## Accepted pre-existing conditions
  - pins `uci` to the feature branch — deliberate until PLT-1300 lands
  ```

  The caller fetches the file from the base ref, never the head. A pull request that
  wrote its own acceptance would be handing itself the approval its blocker withholds,
  and this process cannot see the repository to check. An accepted finding stays on the
  page, marked accepted with its rationale; only the veto is lifted. An absent file
  accepts nothing, and so does an unreadable one, with a warning.
- `--base-standards-ref REF` — the ref the caller read `--base-standards-file` from,
  e.g. `main`. Recorded as `accepted_from` in the check file and named beside every
  accepted finding in the check summary and the comment's notice, so a workflow that
  handed over the head's copy shows it on the pull request. Unverified: this process
  records what the caller says. Empty renders as "the base branch".
- `--extra-instructions TEXT` — additional guidance for this dispatch only. Carried
  into both the first prompt and the adopted one.
- `--include-nits` — place nit-severity findings inline as well. Off by default. Off
  means redirected, not suppressed. The prompt sends a nit to `non_blockers` instead of
  `inline_comments`. The check run then lists it under Non-blocking, and no thread opens
  on the line. A wall of advice around two real findings teaches the author to skim all
  of it.

  The redirect widens that bucket, and says so. The sorting rules call `non_blockers`
  line-less, but a nit names a line. A bare redirect would swap one contradiction for
  another, so the rule states the wider contract.

  The check run's finding count applies the same gate as the placement. Its body omits
  every line-tied finding by design, so counting a suppressed nit would name a finding
  the check cannot show. The published summary comment drops the reply's closing block,
  so no suppressed nit reaches the reader from there. That comment carries the reply's
  prose whole, so a nit the reply also wrote into its prose still appears.

  Naming the destination is load-bearing. The sorting rules say every observation belongs
  in the block. They also say a note missing from the block is one the author never sees.
  A nit banned from the block with nowhere to go therefore leaves one cheap way to obey
  both rules: drop the observation. The flag gates placement, not noticing.

  Every dispatch states the setting it runs under, in both directions. Each also states
  that it replaces any earlier one. The session outlives the run, so a first turn told to
  leave nits out still holds that instruction. Silence on a later opt-in would leave the
  ban standing and the flag inert.

  When it is off, the prompt also forbids relabelling a nit as a suggestion to place it
  inline. The placement then drops anything still called a nit. The driver does both on
  purpose. Telling the model alone leaves the rule to its compliance. Filtering alone
  leaves the review no reason not to promote.

  The severity vocabulary does not move with the flag. The filter enforces on the label,
  so withholding the word would turn a suppressed thread into an unrecognisable one.
- `--conversation-context FILE` — this tool's earlier findings and their replies, as
  json, so a re-review can say what changed instead of repeating itself. A file that
  cannot be read is a warning rather than a refusal: the review is still correct
  without it.

  Each entry takes `thread_id`, `file`, `line`, `body`, `replies` and `resolved`. The
  `thread_id` is the GraphQL node id of the review thread, and this file is the
  allowlist that decides which threads a review may close: an id the reply names is
  admitted only when it matches one here, and every other lands in `refused`. So a
  caller supplies the threads it has already established are this tool's own — on this
  pull request, written by this identity — and nothing else. Omitting `thread_id`
  leaves the history working and closes nothing.

## Environment variables

### Connection and identity

| Variable | Default | Meaning |
|---|---|---|
| `OMNIGENT_BASE_URL` | `http://127.0.0.1:6767` | The Omnigent server. The default is loopback so a bare local run fails locally rather than reaching for someone's deployment; the review workflow always passes the real one (`https://seigent.dev.platform.sei.io`). It must be https or loopback: anything else is refused twice over, once when the client is built and once when the token mint declines to put the client secret on the wire. The in-cluster ClusterIP Service is not usable for this reason — it is plain http on port 80. |
| `OMNIGENT_ORIGIN` | `omnigent://internal` | Sent as the `Origin` header on every request to satisfy the server's trusted-origin CSRF guard on state-changing POSTs. This process is not a browser and sends no Origin of its own, so it announces this sentinel instead. |
| `SEIDROID_AGENT_ID` | `seidroid` | The agent **name** to resolve to an id. There is no lookup-by-name route server-side, so the driver pages the agent listing until this name matches. |
| `SEIDROID_MODEL` | *(empty)* | Substitutes for the model the agent spec names. Empty leaves the spec's own. It applies to the review's own agent only. A scout runs on another agent, so another harness and another provider. A scout therefore keeps its spec's model, and the driver leaves any override of its own alone. Forwarding a name one provider does not answer to costs the whole reading, not just the model. The driver applies the override at both ends of a session's life, because it lives on the session row rather than on the turn. A session this run opens carries it from create, so the first turn — the one that writes the review — already runs on it. For a session an earlier dispatch opened, the driver moves it on adopt. One limit applies there. The harness reads the row when it launches. A session whose harness is already up therefore answers this run on the model it launched with. The new value takes effect at the next launch. The log says which of the two happened instead of reporting a bare success. The reconcile compares before it writes, so the common case costs no request: nothing asked for, no override present. A failure logs a warning rather than failing the run, because the review still runs on the model the session already carries. That is the override it had, not the spec's model, so a failed clear leaves the stale one in place. The server forwards the value as-is and enumerates nothing, so it does not reject an unrecognised name here — that fails at turn start. |
| `SEIDROID_EFFORT` | *(empty)* | Substitutes for the reasoning effort the agent spec names, for example `high`. Empty leaves the spec's own. It applies to the review's own agent only, because a scout takes its effort from its own bundle. The driver sets it at create and moves it on adopt. On adopt, a session whose harness is already up answers this run at the effort it launched with. The server rejects a value outside its accepted set at create, and the run exits `2` (`ExitConfig`). |

The driver also reads `GITHUB_RUN_ID` and `GITHUB_RUN_ATTEMPT` when
`--trigger-id` is not given. These now only label a dispatch in the logs — they
do not affect which session is used, so a re-run reuses the pull request's
session like any other invocation.

### Credential — pick one path

The driver needs exactly one of these two credential shapes. Supplying
neither is a configuration error; supplying half of the machine-client pair
is also a configuration error (a distinct, more specific one), because the
two mistakes have different fixes.

Nothing here has a default, and the machine-client pair is all-or-nothing: setting
one half is refused with `machine client is half-configured` and exit 2 rather
than falling through to an anonymous request.

| Variable | Required | Meaning |
|---|---|---|
| `OMNIGENT_API_TOKEN` | one of the three routes | A bearer token minted elsewhere. Never logged. |
| `OMNIGENT_API_TOKEN_FILE` | one of the three routes | Path to a file holding that token, re-read on every invocation so a rotated credential is picked up without a redeploy. Takes precedence over `OMNIGENT_API_TOKEN` when both are set — and an unreadable file yields an empty token with **no** fallback to it, which presents as "no API credential". |
| `OMNIGENT_MACHINE_CLIENT_ID` | **yes, with the secret** | The confidential client's identifier. Mirrors the server's own `OMNIGENT_MACHINE_CLIENT_ID` — an operator configures one value, not two vocabularies for the two ends of the same client-credentials pair. |
| `OMNIGENT_MACHINE_CLIENT_SECRET` | **yes, with the id** | That client's secret, in plaintext, on this side only. **The server stores just a digest of it**, under `OMNIGENT_MACHINE_CLIENT_SECRET_HASH` — note the `_HASH` that only the server-side name carries; do not cross-wire the two. Never logged, and never written to a workflow step output. |

Setting `OMNIGENT_MACHINE_CLIENT_ID` and `OMNIGENT_MACHINE_CLIENT_SECRET` is
the preferred path for an automated caller: the driver exchanges them for a
short-lived bearer **in-process**, at `POST /oauth/token` with
`grant_type=client_credentials`, so the token itself never has to transit a
workflow step output or a log line to reach the process that uses it. An
explicit `OMNIGENT_API_TOKEN` (or `_FILE`) overrides the exchange if both
forms are present.

**`OMNIGENT_MACHINE_CLIENT_SECRET` is the one *secret* an operator has to
configure** to run this tool from CI. It is not the only variable: the machine
client is a pair, so `OMNIGENT_MACHINE_CLIENT_ID` has to be set beside it and
has no default. Configuring one half of the pair is refused with
`machine client is half-configured` and exit 2, deliberately, rather than
falling through to an anonymous request. Everything else above has a workable
default.

### Permission allowlists

| Variable | Default | Meaning |
|---|---|---|
| `SEIDROID_ALLOW_POLICIES` | *(empty)* | Comma-separated exact `policy_name` values to accept automatically. |
| `SEIDROID_ALLOW_TOOLS` | *(empty)* | Comma-separated exact `tool_name` values to accept automatically, e.g. `Bash`. This deployment does send `tool_name`, measured, so this is the narrower of the two allowlists: `policy_name` is `claude_native_permission` for every native permission request, which makes allowing it equivalent to accepting every tool call. The review workflow passes `Bash,Read` — the binary's own default stays closed, so a bare local run allows nothing. |

See [Permission policy](#permission-policy) below — **read this before
assuming a blank allowlist is merely "cautious."**

### Independent readings

| Variable | Default | Meaning |
|---|---|---|
| `SEIDROID_SCOUTS` | *(empty)* | Scouts to gather a reading from before the review, as `name=agent,name=agent` — e.g. `codex=xreview-scout-codex`, naming the bundle in `agents/`. Empty runs the review alone, which is the behaviour without this set. Each scout reads the same pull request in its **own session on its own agent**, seeing neither the review nor another scout; the review then verifies their claims against the diff and merges what holds. The agent is what fixes the harness, so a scout naming the review's own agent is refused — a reading from the same harness is not independent of the one it is checking — as are two scouts on one agent, which would count one opinion twice. A scout that fails contributes a note the review is shown rather than nothing, because a reading that failed must not look like a reading that found nothing. Scouts share `SEIDROID_RUN_DEADLINE_S`: they run in parallel with two fifths of it between them, and the review keeps its own full deadline, so a run costs at worst `deadline x 1.4` end to end. When every scout read the diff, found nothing and reported it **inert** — comments, documentation or whitespace only, no executable surface — the review is settled on their readings and no review turn runs: the published verdict approves and says the scouts decided it. Anything less than that unanimity — one finding, one failed scout, one scout that did not call the diff inert, or no scouts at all — runs the review turn as before. |

### Timeouts (seconds)

| Variable | Default | Meaning |
|---|---|---|
| `SEIDROID_RUN_DEADLINE_S` | `1800` | Bounds the whole run: resolve, create or adopt, and drive. On expiry the run ends and the session is left as it is — the turn keeps running server-side, and the next invocation's prompt queues behind it. |
| `SEIDROID_REQUEST_TIMEOUT_S` | `30` | Bounds every request this driver times itself rather than leaving to the SDK, which is wider than it sounds: the token mint, the **liveness probe**, the post-turn reply read, the salvage read after a lost stream, at **twice** this value each paginated listing walk, and at **four times** it the whole of teardown. So it is not a per-request knob. Lowering it to fail a slow mint faster also shortens the liveness probe — and a probe that times out reads as not-live, which is what decides whether the prompt goes in at all — and shortens the walk that finds the session to reclaim, which is the only thing that frees a sandbox (see exit `8`). It is deliberately not handed to the SDK as a unary timeout, so tightening it does not tighten the client's own create/send/resolve calls; those take `SEIDROID_UNARY_TIMEOUT_S`. The event stream takes `SEIDROID_STREAM_IDLE_TIMEOUT_S`. |
| `SEIDROID_STREAM_IDLE_TIMEOUT_S` | `300` | How long the event stream may sit silent before it's treated as dead. The server heartbeats an idle stream every 15s, so this must stay comfortably above that or a healthy idle stream gets torn down between turns. Minutes rather than seconds because a *newly created* session is quiet while its sandbox provisions, clones the repository and connects a runner: a measured launch produced two heartbeats in 90 seconds while cloning a large repo, and the old 90s default killed the review before the agent existed. The run deadline is the real backstop. |
| `SEIDROID_UNARY_TIMEOUT_S` | `150` | Bounds one non-streaming SDK call — listing, create, send, resolve. Longer than `SEIDROID_REQUEST_TIMEOUT_S` because a session create is slower than a read. Zero does not mean "let the SDK decide": a non-positive value is a configuration error and exits 2, and a `Config` built in code with this unset gets 150s substituted before the client is built. |

| `SEIDROID_SERVER_RESTART_BUDGET_S` | `180` | How long the driver keeps reading the session, on each stream re-subscribe, while a gateway reports the server gone. A gateway answer (a 502, 503 or 504 with no error envelope) means that a rollout is replacing the server. A single-replica server with a Recreate rollout is down for about two minutes. The sandbox and the turn survive that window, so waiting collects an answer that the run would otherwise discard. The driver does not retry a 503 that the server writes itself, such as `runner_unavailable`. Past the budget, the run exits `6`. |

The five values above must each parse as a positive number; zero, negative, or
non-numeric values are rejected as configuration errors rather than silently
producing an unbounded run.

### Logging

| Variable | Default | Meaning |
|---|---|---|
| `LOG_LEVEL` | `info` | Log verbosity. `debug` adds a record per request, which is what joins a run to gateway access logs; successful traces are not logged below it. Unlike the timeouts this is **not** validated: an unrecognised value falls back to `info` silently, so a typo presents as missing debug records rather than as a configuration error. |

## Exit codes

The calling workflow branches on these, so the numbers are a contract with
it — carried over from the Python driver this repository replaces, and any
workflow pinned to an older ref must keep reading them the same way. A number
may be added, and a number's meaning may widen to cover more states; none moves
to a different meaning. So branch on the code and read the log for the detail.

| Code | Constant | Meaning |
|---|---|---|
| `0` | `ExitOK` | A completed turn that produced a verdict. A duplicate trigger is not a separate outcome: it adopts the existing session and drives it to a verdict like any other run. |
| `2` | `ExitConfig` | The run was rejected before it reached the review API: bad arguments, a missing or rejected credential, a base URL the client refuses, or a failed token exchange. Two things also land here. A token exchange failing on the *network* does, so a flapping `2` can mean "retry" rather than "fix the secret". And the Go runtime exits `2` itself on an unparseable flag, and on a panic raised on a goroutine the driver cannot recover — `9` takes the ones it can. The logged error distinguishes all of them: a configuration failure names the variable, and a crash carries a stack. |
| `3` | `ExitTimeout` | The run deadline (`SEIDROID_RUN_DEADLINE_S`) expired. The turn is abandoned rather than stopped — it keeps running server-side, and the next invocation's prompt queues behind it. The conversation is kept. |
| `4` | `ExitTurnFailed` | The session reported failure — the agent's outcome, not the driver's. |
| `5` | `ExitNoVerdict` | The turn ended without a verdict this driver could attribute and parse. The turn may have succeeded and simply not produced the closing block the caller needs. Also reported when more than one turn replied into the session while ours ran, when no reply carries this turn's response id, and when a reply looks like it carries a credential — the log's `reason` distinguishes them, and every one of those refuses rather than posting text it cannot attribute. |
| `6` | `ExitTransport` | The stream or a request failed in a way retrying inside one run can't fix. |
| `7` | `ExitCancelled` | A terminate signal (SIGINT/SIGTERM) unwound the run. Teardown is attempted on the way out. |
| `8` | `ExitTeardownLeak` | A `--close` that did not establish the session was gone: one found and refused to delete, or one whose budget ran out before it could look. Only the first carries a session id, so the log is what separates them and the run key is what to search on. A review never reports it: it deletes nothing, because the session is meant to outlive the run. The delete is the only thing that reclaims the sandbox — the Kubernetes launcher sets no lifetime cap and the server runs no sweep — so this means a pod may be holding its reserved cpu and memory with nothing left to use it. |
| `9` | `ExitInternal` | A defect in the driver: a panic it recovered rather than let the runtime report as a `2` nobody can tell from a bad configuration. Not from the Python driver's set, so a workflow pinned to an older ref reads it as an unknown failure, which is the right reading of one. The log carries the panic and its stack. |

`1` is not used by this program; nothing here relies on it meaning anything
in particular.

## Permission policy

A review turn runs with the session owner's execution identity, and some of
what it might do — a shell command, a write, anything else the server's
policy engine has a phase for — parks the turn on a permission prompt
(an *elicitation*) instead of running it. `review` answers every one of
those prompts itself; there is no human in the loop during a run.

**The policy denies by default and accepts only on an exact match** against
`SEIDROID_ALLOW_POLICIES` (matched on the server-attested `policy_name`) or
 `SEIDROID_ALLOW_TOOLS` (matched on `tool_name`, which this deployment does
stamp). There is no substring,
prefix, or pattern matching anywhere in this. That's deliberate: a prompt
raised while the agent reads a pull request is raised over content the
agent was asked to review, i.e. attacker-influenced input in the general
case. Any matcher whose behavior a PR's diff, description or comments could
influence is a matcher that untrusted content could steer into approving
its own escalation — so the only fields this policy will ever classify on
are ones the server's policy engine stamps, never the model-influenced
`message` or `content_preview` that ride along with a prompt for logging.

**With both allowlists empty — the default — every prompt is declined, with no
exceptions.** This is not a "reasonably conservative" default that still lets
ordinary reads through: a review turn that needs a gated operation simply cannot
run it. The two allowlists are checked independently and either one can accept,
so unblocking a turn means adding to one of them — and they are not
interchangeable. **Add the exact `tool_name` values to `SEIDROID_ALLOW_TOOLS`.**
Do not reach for `SEIDROID_ALLOW_POLICIES`: this deployment stamps
`claude_native_permission` as the `policy_name` on every native permission
request, so allowlisting it accepts every tool call the agent makes, which is
the opposite of a gate. Concretely: on a deployment
where every one of the turn's read operations happens to be gated, a blank
allowlist means the turn parks on every one of them, gets `decline`d, and
the review effectively can't read anything the gate covers. This is the
same fail-closed posture the Python driver had in practice (it classified
on a `tool_name` the server never actually sent, so its allowlist could
never match anything either) — the difference here is that this is the
documented, intended behavior rather than an accidental one, and it is
configurable rather than permanently closed.

**The review prompt's first step is a shell command**, so this is not a knob
that trades review depth for caution. `gh pr diff` needs `Bash`; decline it and the turn reports that it could not
read the diff, which is what the prompt tells it to do rather than review from
the title. A read *inside* the agent's working directory raises no prompt, which
is why the diff stages there — a recorded run staged it in `/tmp`, had the read
refused, and spent three tool calls copying the file somewhere it could read.
`seidroid-review.yml` therefore passes `Bash,Read`. The access control on a review
is its trigger gate: the comment must come from a non-bot account whose association
is `OWNER`, `MEMBER` or `COLLABORATOR`, and where `allowed-team` is set, from an
active member of that team.

To find out what else to allow: run once, watch the structured logs for
`"deciding a permission prompt"` records, and read off the **`tool_name`**
each declined prompt carried. Add the ones this deployment's review turns
legitimately need to  `SEIDROID_ALLOW_TOOLS` (comma-separated, exact values,
no wildcards). Every accepted prompt is logged the same way, so an allow
decision is exactly as visible after the fact as a decline is.

Read off `tool_name` and not `policy_name`, and the reason is the whole
point of the table above: on this deployment every native permission prompt
carries the same `policy_name`, `claude_native_permission`, because the
field names the policy that fired rather than the action it gated. Putting
that one value in `SEIDROID_ALLOW_POLICIES` accepts every tool call the agent
makes. `tool_name` is per-tool, so it is the narrowest thing here that can
be allowed deliberately.

Neither knob buys a read-only guarantee. `Bash` is arbitrary shell, so
allowing it allows a push as readily as a diff read; the read-only posture
rests on the prompt's instruction and the server-side gate.
