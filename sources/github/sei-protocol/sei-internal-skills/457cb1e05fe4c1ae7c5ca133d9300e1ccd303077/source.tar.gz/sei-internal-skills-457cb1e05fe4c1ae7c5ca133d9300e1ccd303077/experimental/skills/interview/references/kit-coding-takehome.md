# Coding take-home kit — the mempool challenge

The first kit. Specializes the eight method dimensions for the take-home where the candidate designs and implements a transaction pool (mempool). The pool collects transactions, orders them by fee/timestamp, and periodically produces a block candidate.

## 1. What this format tests

A take-home is a **work sample** — among the strongest predictors of on-the-job performance (`sources.md` F3). It shows real code: structure, testing, documentation, and the candidate's own design choices, built without an interviewer hovering. It stays **blind** to how they think under live pressure. It cannot see whether they actually understand code they may have generated with AI. And it cannot see how they reason about productionizing beyond what they had time to build. The **scorecard reads the artifact; the verticals + live discussion cover the blind spots** — productionizing the system is the north star there.

## 2. The prompt under evaluation

The prompt asked the candidate to **design and implement a transaction pool (mempool)**:
- `add`, `remove`, `update` transactions; each tx has at least an ID, fee/priority, sender, recipient, payload.
- Efficient retrieval in priority (or timestamp) order.
- A mechanism that selects transactions to form a block (timer or tx-count trigger).
- Basic checks — gas or tx-count per block.
- A block **header** with the previous block's hash, a timestamp, and minimal metadata.
- An interface or simple CLI to simulate incoming transactions and block production.
- Tests or a demo that inserts mixed-fee transactions, triggers block production, and shows that block production selects and removes the highest-priority transactions.

Optional bonuses — do **not** dock a submission for skipping these; they are senior-signal and live-discussion fuel. The bonuses: a pre-add validation check; making the mempool faster via parallelization (and how to multithread it). Also disaster recovery on restart, and a dynamic fee market that adjusts to mempool size.

Score the artifact against the deliverables above. The absence of a *bonus* (or any un-asked scope) is a **discussion vertical**, not a low score.

## 3. Dimensions in play

All eight apply. Per `sei-hiring-profile.md`, weight: **maintainability (2), testing (4), documentation (5) are table stakes**. **Design/trade-offs (3) and production thinking (7) carry the senior signal**. **AI-collaboration (8) defaults to cannot-assess from code alone → a live probe.**

## 4. Behavioral anchors (1–4)

Match the artifact to the observable behavior, not a number. 3 = hire bar, 4 = bar-raising.

| Dimension | 1 — poor | 2 — borderline | 3 — solid (bar) | 4 — bar-raising |
|---|---|---|---|---|
| **1 Correctness & verification** | core deliverables missing/broken (no working add-remove-update, or block selection ignores priority) | core works but edge cases break — empty pool, fee ties, duplicate IDs, remove-missing | all deliverables work incl. gas/tx-count caps; ties + empty + dup handled; highest-priority correctly selected **and removed** | also handles subtle cases (deterministic tie-break, `update` re-prioritizes, block respects gas **and** count) and self-found/fixed bugs visible in commits/tests |
| **2 Code quality & maintainability** | monolithic; tx/pool/block tangled; unclear names; dead code | works but flat structure; naming/abstraction rough; concerns partly mixed | clean separation (tx · pool · block), clear names, right-sized types; reads logically; idiomatic for the language | extensible without over-engineering (priority strategy / block-trigger swappable); reads like production, not a script |
| **3 Design & trade-off articulation** | structure chosen with no rationale; cannot say why fee vs timestamp | choices (ordering, eviction, structure) unexplained; no alternatives weighed | justifies the priority structure (heap vs sorted slice vs map) for **this** workload; states gas/tx-count trade-offs; notes add/pop complexity | weighs alternatives against compounding costs (eviction under load, fee dynamics, O(log n) vs O(n)); names what they'd change at scale unprompted |
| **4 Testing discipline** | no tests, or one happy-path assertion | happy path only; corner cases missed; demo "shows it works" but does not verify ordering/removal | common + corner cases (empty, ties, caps, remove-missing); demo proves highest-priority **selected and removed** | property/stress coverage (ordering invariant over many txs), tests the gas/count boundary exactly; tests read as specifications |
| **5 Communication & documentation** | no README; assumptions implicit; commits uninformative | minimal README; thin commits; most assumptions implicit | README explains design + how to run + stated assumptions; commits narrate; "if I had more time" noted | docs make the trade-offs and productionization gaps explicit — the candidate pre-empts the discussion |
| **6 Handling ambiguity & scope judgment** | misreads prompt / builds the wrong thing; no assumptions | builds literally to the prompt; scope neither cut nor justified | states sensible assumptions (fee-vs-timestamp, what a "block candidate" is); cuts scope deliberately and says so | reframes under-specified parts as design decisions; surfaces the questions a real mempool raises (eviction, replace-by-fee, DoS) and scopes with rationale |
| **7 Production / operational thinking** | no awareness beyond happy path; breaks under any real load/failure | the asked gas/tx caps only; no thought to failure, restart, or scale | enforces the **required** gas/tx-count bounds and degrades gracefully on bad input (a malformed tx does not corrupt or crash the pool). Code/README shows awareness of scale/restart limits even if unimplemented | builds or articulates real operability — bounded memory, backpressure/eviction, restart/DR, observability — and frames the in-memory pool as a step toward a production node |
| **8 AI-collaboration quality** | code looks generated with no sign of understanding (inconsistent style, unused scaffolding) | used AI but accepted it uncritically; some generated code does not fit / is unused | AI used for well-scoped parts; candidate owns the design; code is coherent (process often noted in README/commits) | evidence of strategic use — decomposition, verification of generated code, overriding the model where wrong; scales themselves with AI |

**Note on Dimension 8:** the artifact rarely proves AI-collaboration quality on its own. Default to **cannot-assess** unless the commits/README show the process, and convert it to a live probe (see §5 vertical). Ask: "walk me through where you used AI and how you decided the output was good enough."

## 5. Vertical seeds (productionization north-star)

The menu. Fire only the seeds that trace to **their** code or a deliberate omission; sharpen each against what they built. Lead with the one that best separates levels for this submission.

- **Ordering at scale** — *Hook:* their priority structure (sort-on-each-call / heap / map). *Ask:* keep it ordered and pop-highest at 100k–1M pending txs — what structure, what add/pop cost? *Strong:* an **indexed** priority queue (heap + a position map) or skip list — O(log n) add/pop **and** O(log n) re-prioritize on `update`. A bare heap needs O(n) to *find* the element before it can sift, so "a heap" alone is the mid answer for the update path. The index is the senior tell. *Weak:* "re-sort the slice each time."
- **Consistent hashing & IDs** — *Hook:* how they hash/ID a tx and compute the block's prev-hash. *Ask:* collision handling, and do all nodes compute the same tx ID and block hash? if you shard the mempool across nodes, how route a tx? *Strong:* a collision-resistant hash over a **canonical** tx serialization (so every node derives the same ID). Also a *separate* ordered/Merkle commitment for the block hash, and consistent hashing for sharding/routing. *Weak:* hand-rolled ID; non-deterministic serialization (map-iteration order / unsorted fields → divergent hashes across nodes → consensus break).
- **Concurrency & parallelism** (bonus) — *Hook:* single-threaded add/select; "CPU underutilized." *Ask:* how parallelize, and where's the contention? *Strong:* striped/sharded locks or lock-free structures. **Do not hold the lock across the block-build scan** (snapshot, or use a concurrent structure — else selection stalls all admission). Knows that sharding *by sender* makes per-sender nonce ordering local but turns global fee ordering into a merge across shard heads. *Weak:* "wrap it in one global mutex" (serializes — the trap; probe whether they see it).
- **Per-sender nonce ordering** ⭐ — *Hook:* a global fee-only ordering + the `sender` field. *Ask:* on an account-model chain (Sei/Cosmos/Ethereum) a sender's txs must execute in nonce order. Can your priority structure propose a sender's nonce-5 before nonce-4? *Strong:* orders by executability — `(sender, nonce)` consecutively, fee *across* senders; splits **executable "pending"** (consecutive-nonce) from **non-executable "queued"** (gapped), as go-ethereum does. Sees that a pure global-fee heap would propose an **invalid** block. *Weak:* pure global fee heap, unaware that the chain demands nonce ordering.

  (**Highest-signal mempool vertical** — the most common place a naive global-fee mempool is actually *wrong*; ties into shard-by-sender and replacement below.)
- **Transaction replacement (replace-by-fee)** ⭐ — *Hook:* their `update` re-prioritizes a tx. *Ask:* two txs, same sender, same nonce — which wins, and how do you stop replacement-spam? *Strong:* requires a **minimum fee bump** (e.g. ~10%, geth's default) to accept a replacement; connects it to their `update` path. *Weak:* silent overwrite / no bump rule (free replacement-spam DoS).
- **Disaster recovery** (bonus) — *Hook:* in-memory pool. *Ask:* the node restarts and the mempool vanishes — what do you do? *Strong:* recognizes the mempool is **soft state** — re-gossip from peers is the real recovery. A WAL/journal is at most a warm-start optimization; accept bounded transient loss. *Weak:* "save to disk" with fsync-per-tx (tanks throughput) and no consistency thought.
- **Dynamic fee market** (bonus) — *Hook:* static fee ordering; the bonus's "adjust to mempool size." *Ask:* make fees adjust to pressure? *Strong:* distinguishes the **protocol base fee** from a **local dynamic min-fee admission floor**. The base fee (EIP-1559) tracks *block* gas-used / utilization, ±12.5% per block toward a target; the floor tracks *mempool* pressure. The two signals relate but differ; plus replace-by-fee + anti-spam. *Weak:* hand-wave, or conflates the protocol base fee with mempool size. (Score *up* a candidate who separates the two.)
- **Block-building / gas packing** — *Hook:* their gas + tx-count caps. *Ask:* greedy highest-fee-first under a gas budget — is that optimal? *Strong:* orders by **fee-per-gas**, not raw fee. Recognizes packing under a gas limit is a bounded-knapsack (a big high-fee tx can be worse value than multiple small ones). Greedy fee-per-gas is an acceptable production answer. *Weak:* raw-fee ordering that ignores each tx's gas size.
- **Admission, validation & DoS** (bonus) — *Hook:* their validation check (or its absence). *Ask:* an adversary floods invalid / low-fee / duplicate txs — defenses? *Strong:* stateless (signature, format, intrinsic gas) **+** stateful (nonce, balance, account) validation, per-sender limits, min-fee floor, dedupe, bounded pool with eviction. *Weak:* "validate the fields."
- **Observability & availability** — *Hook:* no metrics/limits (mirrors the prompt's throttling/observability bonus). *Ask:* how do you know the pool is healthy, and protect node availability under a flood? *Strong:* pool-size / age / reject-rate metrics, admission throttling, eviction-by-age, backpressure to the gossip layer. *Weak:* "add some logs."
- **MEV / ordering fairness** (optional — advanced L6 reach) — *Hook:* pure fee-priority ordering. *Ask:* what does fee-priority ordering invite, and who exploits it? *Strong:* front-running / sandwiching, priority-gas-auctions, private orderflow or fair-ordering as productionization concerns. *Weak:* unaware. *(Optional and advanced — do **not** over-weight a MEV name-drop over a candidate who nails nonce ordering. Flag it as reach, not a core expectation.)*

## 6. Level notes (L4/5 vs L6 on this task)

- **L4 / L5:** delivers a correct, clean, well-tested mempool to spec; when prompted, can reason through one or two verticals sensibly.
- **L6:** treats "build a mempool" as "build the admission + ordering + availability layer of a node". **Unprompted**, reasons about **executability** (per-sender nonce ordering, replace-by-fee), eviction policy, and the fee market as an anti-spam mechanism. Also sharding/concurrency, DR, and the fact that a public mempool is a DoS surface. The single sharpest senior tell on this task: recognizing that a pure global-fee heap proposes invalid blocks because it ignores nonce order. The take-home is a starting point they naturally extend toward production.
