# Structure

Two fields. They do different jobs, and you write them differently.

## `summary` — one line

One sentence. What this project is, in terms someone outside the team understands.
No status, no dates, no jargon that needs a second sentence to unpack.

> *Illustration only — invented domain, invented facts:*
> Nightly job that reconciles warehouse inventory counts against the ledger and
> files a discrepancy report.

This is the line that appears in list views and portfolio sweeps. It is often the
only thing a reader sees. Write it last, after the description has forced you to be
clear about what the thing actually is.

**A warning about examples, including that one.** Every example in this file is an
invention. All of them deliberately use one unrelated domain, warehouse inventory, so
that nobody mistakes one for a fact about the project you are actually writing. None
of them is a fact about any project. A polished, on-topic example is the easiest
thing in the world to paste. Pasting one is fabrication with a style guide as its
only source — the exact failure guardrail 6 exists to stop.

In testing, an agent received a scenario that matched an example in an earlier draft
of this file. It reported the pull directly: *"That line was sitting right there,
on-topic, and polished. I could have pasted it and built a plausible page around
it."* It resisted by asking where the sentence came from. Ask the same question.

## `description` — about one page

### Why this ordering

Linear's Head of Product publishes the rule their own PRDs follow:

> "Start with the highest level and get more granular. Start with the widest
> audience, and get narrower. **Start with the stuff that is least likely to change,
> end with the stuff that is most likely to change** as you discover and build."

The third clause is what keeps a description alive. Put the durable material first
and the description ages from the bottom, where damage is cheap and visible.

Independently, the durability split is well documented. **Durable:** motivation
behind decisions, invariants, boundaries, deliberate trade-offs, rejected
alternatives, non-goals. **Rots:** status, percent-done, task inventories, child
lists, dates, current owners, implementation detail that mirrors code.

### The sections

Use these names. Keep them stable across the project's life — return readers
navigate by heading, and renaming one breaks every link into it. Skip a section
rather than write a placeholder under it.

**1. The lead — two or three sentences, no heading**

What this is and why it exists, before any heading. A reader who stops here should
be able to say what the project is for. Conclusion first: readers "stop reading at
any point on the page and still come away with the main point."

Shape Up's test for how much context to supply is the best one published. How far
you spell out the problem depends on how much context you share with the people
reading the write-up. Then:

> "The best problem definition consists of **a single specific story** that shows why
> the status quo does not work."

A specific story beats an abstract problem statement. *Illustration:* "One service
generates every returns label, and in March it stopped for six hours during peak."
That lands where "improve reliability of the returns pipeline" does not.

**2. Why now**

The forcing function. What changed that makes this a this-quarter bet rather than a
someday item. This is the section that most often does not exist in the author's head
until asked for — ask for it.

**3. What we are doing**

The approach at the altitude that survives. Name the meaning of the work, not its
issues. If the work has a natural shape — build, prove, cut over — name the shape and
what each part buys you. Stop before implementation detail; that belongs to the spec
and to the issues.

**4. What we are not doing**

Non-goals, in the strict sense. Not negated goals like "The system should not crash",
but rather:

> "things that could reasonably be goals, but are explicitly chosen not to be goals."

This is the highest-value-per-word section in the whole description and the one most
often missing. Scope questions are what derail reviews. It is also durable — a
deliberate exclusion stays true.

**5. What done means**

Observable outcomes. Something a person could check and agree on. If nobody can
check a criterion without asking the author, it is not a criterion yet.

Not a status. *Illustration:* "Every warehouse reconciles nightly and the discrepancy
rate holds under 0.1% for four consecutive weeks" is a criterion. "Reconciliation
complete" is a restatement of the title.

**6. What is hard about it** *(only when true)*

Constraints, one-way doors, rabbit holes, real dependencies. Shape Up's "rabbit holes"
— the details worth calling out to avoid problems. If a decision is irreversible, say
so in words next to the number. *Illustration:*

- A bare "6-hour window" reads as a schedule detail.
- "After 6 hours the old ledger goes to archive and reversing means a manual re-key
  — a one-way door" reads as a warning.

Warnings survive summarization.

Write the consequence, not just the constraint. A number alone tells the reader there
is a deadline; it does not tell them what it costs to miss it. If you do not know the
consequence, that is the question to ask — not a sentence to compose.

Skip this section entirely if the project is not hard. Writing it anyway to look
thorough is padding.

**7. Depth** *(only when it exists)*

Links out to the spec, the design doc, the incident. As depth for the reader who has
already decided to engage — never as a substitute for orientation.

Link form matters. Inline the conclusion, link the receipt:

> Good: `The March outage stopped label generation for six hours ([report](…)).`
> Bad: `See the incident report for background.`

The test: **the description's point must survive the reader never clicking.** If they
have to click to follow you, you have offloaded your job onto them.

## Length

Convergence across published practice for a tracker-level description is about one
page. Linear's engineers target 1–2 pages for a spec. Linear Method says "write only
as much as you need". Shortcut keeps "in-depth details to specific Stories."

Anything that wants six pages is a different artifact. Write that separately and link
it from section 7.

If it is too long, restructure before you cut. Gopen & Swan, on revising professional
prose: "Sheer length was neither the problem nor the solution." Their revised version
was not noticeably shorter than the original, yet it was far easier to interpret.

## Sentence-level

BLUF governs the *document*: main point first. It does **not** govern the *sentence* —
inside a sentence the order inverts. Put context in the topic position (the start) and
the payload in the stress position (the end). The reason: "readers naturally emphasize
the material that arrives at the end of a sentence."

Practical consequences:
- Provide context before asking the reader to consider anything new.
- Put the new information you want emphasized at the end of the sentence.
- Articulate the action of a sentence in its verb, not in a nominalization.

*(Gopen & Swan call these reader expectations, not rules, and say so explicitly. Treat
them as a diagnostic for a sentence that reads badly, not a checklist to apply.)*
