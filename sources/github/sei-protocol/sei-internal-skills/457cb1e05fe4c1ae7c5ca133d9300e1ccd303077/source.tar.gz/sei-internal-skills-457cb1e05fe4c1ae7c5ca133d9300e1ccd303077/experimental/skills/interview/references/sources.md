# Sources — the method's evidence base

Structured-interview research grounds the evaluation method. Citations are **cite-and-link**; reserved/paid sources are never reproduced. Verified online against the primary or an authoritative secondary source (2026-06).

## Method backbone

- **F1 — Structured interviewing + shared rubric.** Vetted consistent questions + a rubric that pre-defines poor/borderline/solid/outstanding answers make scoring consistent across raters, raising predictive validity and shrinking demographic gaps. *Google re:Work, "A guide to structured interviewing"* — https://rework.withgoogle.com/intl/en/guides/a-guide-to-structured-interviewing-for-better-hiring-practices ("Structured interviews result in increased predictive validity and decreased differences between demographic groups."). Google content — cite, do not reproduce. The **poor / borderline / solid / outstanding** anchor labels come from here.
- **F2 — *Behaviorally Anchored Rating Scales* (BARS).** Anchoring each score with an observable-behavior description (vs a bare 1–5) makes two raters converge and mitigates halo/horns.

  Origin: *Smith & Kendall (1963), "Retranslation of expectations…", J. Applied Psychology 47(2), 149–155.* Overview: https://en.wikipedia.org/wiki/Behaviorally_anchored_rating_scales . **Caveat (honest):** BARS "may still suffer from unreliability, leniency bias and lack of discriminant validity". Anchors reduce subjectivity, they do not erase it; calibration still matters.
- **F3 — Work samples are top-tier predictors.** A take-home IS a work sample — empirically among the strongest single predictors of job performance, on par with structured interviews. Combining them is near-best. *Schmidt & Hunter (1998), Psychological Bulletin 124, 262–274* (work sample r ≈ .54, structured interview r ≈ .51).

  **Caveat:** the original PDF resisted a direct fetch; coefficients verified via a secondary summary. Later re-analyses (Sackett/Roth et al., 2005) argue work-sample validity is lower (~.33). The conclusion "work samples are a strong predictor" holds; do not over-claim the exact figure.

## Dimensions & leveling

<!-- vale AgenticWriting.STE-Passive = NO -->
- **F4 — Coding-eval dimensions converge.** Industry coding evaluation splits into Communication, Problem Solving (incl. trade-off analysis), Technical Competency (correct/clean implementation), and Testing/Verification. *Tech Interview Handbook, "How candidates are evaluated"* — https://www.techinterviewhandbook.org/coding-interview-rubrics/ .
<!-- vale AgenticWriting.STE-Passive = YES -->
- **F5 — A concrete coding-eval BARS template exists.** Four tiers (`Excellent` / `Good` / `Fair` / `Poor`) anchored by observable behaviors. *Holloway, "The Holloway Guide to Technical Recruiting and Hiring — Building Rubrics"* — https://www.holloway.com/g/technical-recruiting-hiring/sections/building-rubrics . Paid/licensed — cite the URL, do not copy the rubric body.
- **F6 — Leveling axes.** Scope / autonomy / ambiguity / influence separate IC (L4 autonomous on moderate components) from senior/staff (L6 owns vision, "pivots more towards design than implementation"). *levels.fyi Standard SWE Level Framework* — https://www.levels.fyi/blog/swe-level-framework.html .

## AI-collaboration

- **F7 — Permit AI, score the judgment over it.** "Good" = strategic, decomposed use with the human owning decisions, critically reviewing and verifying AI output, overriding when wrong. "Bad" = blind prompt-and-accept / using AI as a crutch with no understanding of the generated code. *Canva Engineering, "Yes, You Can Use AI in Our Interviews"* — https://www.canva.dev/blog/engineering/yes-you-can-use-ai-in-our-interviews/ ("Can they identify and fix issues in AI-generated code?"). *Hello Interview, "Meta's AI-Enabled Coding Interview"* — https://www.hellointerview.com/blog/meta-ai-enabled-coding (Verification: "Do you check the AI's output before moving on?").

  **Status:** the sources cite the *direction* (judgment, decomposition, verification, override). The rubric's specific **weighting and anchors are the team's own judgment** — no settled industry-standard AI-collaboration scale exists yet.
