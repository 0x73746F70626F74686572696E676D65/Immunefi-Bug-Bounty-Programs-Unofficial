# Coral → Council Handoff Criteria

Coral is for lightweight iteration. Council is for full-ceremony work. When any of these match, stop and ask whether to hand off.

## Component / Interface Count

- ≥3 components affected → council (System tier likely)
- ≥2 interface boundaries touched → council
- Any new interface the work *defines* (as opposed to consumes) → council

## One-Way Doors

Immediate handoff, regardless of size:

- Persisted schema / field names (after data lands or consumers depend on them)
- Public API contracts (request/response shapes, status codes, error formats)
- On-disk or wire data formats
- Signed or indexed identifiers (stable IDs, content hashes, signed tokens)
- Anything the repo's CLAUDE.md flags as irreversible

Script: "This touches a one-way door: [what]. Warrants full council process — I will hand off unless you want to stay in coral with you gating it manually."

## Duration Signals

- User says "this is bigger than I thought" / "let us do this properly" / "we should design this"
- Work will not complete in one session
- Experts start asking for design documents that do not exist

## Interface Changes

Anything requiring an interface-registry update (where a registry exists) → council. Coral does not edit the registry.

## What Coral Keeps Handling

- Single-component iteration with defined interfaces
- Debugging, troubleshooting, one-off questions
- Writing code against an existing LLD
- Second opinions from a single specialist
- Explaining existing design decisions
- Quick reviews of small changes

## Handoff Script Examples

- "Now touching 3 components (A, B, C) with interface changes between A→B. That is System tier — hand off to /council?"
- "You just mentioned renaming a persisted field other systems depend on. One-way door. Hand off to /council for the gate, or handle it here with you gating manually?"
- "You said 'let us design this properly' — that is a council cue. Hand off?"
