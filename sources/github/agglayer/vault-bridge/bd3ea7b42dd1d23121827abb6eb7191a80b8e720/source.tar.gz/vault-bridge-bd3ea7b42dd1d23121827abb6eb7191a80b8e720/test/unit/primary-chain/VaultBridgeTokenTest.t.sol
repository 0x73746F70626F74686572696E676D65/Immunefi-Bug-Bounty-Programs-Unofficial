// SPDX-License-Identifier: LicenseRef-PolygonLabs-Source-Available
pragma solidity ^0.8.29;

// Test base
import "test/base/primary-chain/VaultBridgeTokenTestBase.sol";

// OpenZeppelin
import {IERC20Permit} from "@openzeppelin/contracts/token/ERC20/extensions/IERC20Permit.sol";
import {IERC4626} from "@openzeppelin/contracts/interfaces/IERC4626.sol";
import {Initializable} from "@openzeppelin-contracts-upgradeable/proxy/utils/Initializable.sol";
import {Math} from "@openzeppelin/contracts/utils/math/Math.sol";
import {PausableUpgradeable} from "@openzeppelin-contracts-upgradeable/utils/PausableUpgradeable.sol";
import {SafeERC20} from "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";

// Mocks
import {IAgglayerBridge as _IAgglayerBridge} from "test/interfaces/IAgglayerBridge.sol";
import {MockAgglayerBridge} from "test/utils/mocks/MockAgglayerBridge.sol";
import {MockVault} from "test/utils/mocks/MockVault.sol";

/// @dev Tests for VaultBridgeToken and VaultBridgeTokenPart2
contract VaultBridgeTokenTest is VaultBridgeTokenTestBase {
    using SafeERC20 for IERC20;
    using SafeERC20 for TestHarnessVaultBridgeToken;

    function setUp() public virtual {
        deployVaultBridgeTokenInfrastructure();
    }

    function test_initialize_twice() public {
        vm.expectRevert(Initializable.InvalidInitialization.selector);
        VaultBridgeToken.InitializationParameters memory initParams = VaultBridgeToken.InitializationParameters({
            owner: owner,
            name: tokenName,
            symbol: tokenSymbol,
            underlyingToken: underlyingToken,
            minimumReservePercentage: minimumReservePercentage,
            yieldVault: address(yieldVault),
            yieldRecipient: yieldRecipient,
            agglayerBridge: agglayerBridge,
            minimumYieldVaultDeposit: MINIMUM_YIELD_VAULT_DEPOSIT,
            migrationManager: migrationManagerAddr,
            yieldVaultMaximumSlippagePercentage: YIELD_VAULT_ALLOWED_SLIPPAGE,
            vaultBridgeTokenPart2: address(vbTokenPart2)
        });
        vbToken.reinitialize1(address(initializer), initParams);
    }

    function test_initialize() public virtual {
        vm.revertToState(stateBeforeInitialize);

        bytes memory initData;
        VaultBridgeToken.InitializationParameters memory initParams = VaultBridgeToken.InitializationParameters({
            owner: address(0),
            name: tokenName,
            symbol: tokenSymbol,
            underlyingToken: underlyingToken,
            minimumReservePercentage: minimumReservePercentage,
            yieldVault: address(yieldVault),
            yieldRecipient: yieldRecipient,
            agglayerBridge: agglayerBridge,
            minimumYieldVaultDeposit: MINIMUM_YIELD_VAULT_DEPOSIT,
            migrationManager: migrationManagerAddr,
            yieldVaultMaximumSlippagePercentage: YIELD_VAULT_ALLOWED_SLIPPAGE,
            vaultBridgeTokenPart2: address(vbTokenPart2)
        });

        initData = abi.encodeCall(vbToken.reinitialize1, (address(0), initParams));
        vm.expectRevert(VaultBridgeToken.InvalidInitializer.selector);
        vbToken = TestHarnessVaultBridgeToken(payable(_proxify(vbTokenImplementation, address(this), initData)));

        initData = abi.encodeCall(vbToken.reinitialize1, (address(initializer), initParams));
        vm.expectRevert(VaultBridgeToken.InvalidOwner.selector);
        vbToken = TestHarnessVaultBridgeToken(payable(_proxify(vbTokenImplementation, address(this), initData)));
        vm.revertToState(stateBeforeInitialize);

        initParams.owner = owner;
        initParams.name = "";
        initData = abi.encodeCall(vbToken.reinitialize1, (address(initializer), initParams));
        vm.expectRevert(VaultBridgeToken.InvalidName.selector);
        vbToken = TestHarnessVaultBridgeToken(payable(_proxify(vbTokenImplementation, address(this), initData)));

        initParams.name = tokenName;
        initParams.symbol = "";
        initData = abi.encodeCall(vbToken.reinitialize1, (address(initializer), initParams));
        vm.expectRevert(VaultBridgeToken.InvalidSymbol.selector);
        vbToken = TestHarnessVaultBridgeToken(payable(_proxify(vbTokenImplementation, address(this), initData)));

        initParams.symbol = tokenSymbol;
        initParams.underlyingToken = address(0);
        initData = abi.encodeCall(vbToken.reinitialize1, (address(initializer), initParams));
        /// forge-config: default.allow_internal_expect_revert = true
        vm.expectRevert(VaultBridgeToken.InvalidUnderlyingToken.selector);
        vbToken = TestHarnessVaultBridgeToken(payable(_proxify(vbTokenImplementation, address(this), initData)));

        initParams.underlyingToken = underlyingToken;
        initParams.minimumReservePercentage = 1e19;
        initData = abi.encodeCall(vbToken.reinitialize1, (address(initializer), initParams));
        vm.expectRevert(VaultBridgeToken.InvalidMinimumReservePercentage.selector);
        vbToken = TestHarnessVaultBridgeToken(payable(_proxify(vbTokenImplementation, address(this), initData)));

        initParams.minimumReservePercentage = minimumReservePercentage;
        initParams.yieldVault = address(0);
        initData = abi.encodeCall(vbToken.reinitialize1, (address(initializer), initParams));
        vm.expectRevert(VaultBridgeToken.InvalidYieldVault.selector);
        vbToken = TestHarnessVaultBridgeToken(payable(_proxify(vbTokenImplementation, address(this), initData)));

        initParams.yieldVault = address(yieldVault);
        initParams.yieldRecipient = address(0);
        initData = abi.encodeCall(vbToken.reinitialize1, (address(initializer), initParams));
        vm.expectRevert(VaultBridgeToken.InvalidYieldRecipient.selector);
        vbToken = TestHarnessVaultBridgeToken(payable(_proxify(vbTokenImplementation, address(this), initData)));

        initParams.yieldRecipient = yieldRecipient;
        initParams.agglayerBridge = address(0);
        initData = abi.encodeCall(vbToken.reinitialize1, (address(initializer), initParams));
        vm.expectRevert(VaultBridgeToken.InvalidAgglayerBridge.selector);
        vbToken = TestHarnessVaultBridgeToken(payable(_proxify(vbTokenImplementation, address(this), initData)));

        initParams.agglayerBridge = agglayerBridge;
        initParams.migrationManager = address(0);
        initData = abi.encodeCall(vbToken.reinitialize1, (address(initializer), initParams));
        vm.expectRevert(VaultBridgeToken.InvalidMigrationManager.selector);
        vbToken = TestHarnessVaultBridgeToken(payable(_proxify(vbTokenImplementation, address(this), initData)));

        initParams.migrationManager = migrationManagerAddr;
        initParams.yieldVaultMaximumSlippagePercentage = 1e19;
        initData = abi.encodeCall(vbToken.reinitialize1, (address(initializer), initParams));
        vm.expectRevert(VaultBridgeToken.InvalidYieldVaultMaximumSlippagePercentage.selector);
        vbToken = TestHarnessVaultBridgeToken(payable(_proxify(vbTokenImplementation, address(this), initData)));

        initParams.yieldVaultMaximumSlippagePercentage = YIELD_VAULT_ALLOWED_SLIPPAGE;
        initParams.vaultBridgeTokenPart2 = address(0);
        initData = abi.encodeCall(vbToken.reinitialize1, (address(initializer), initParams));
        vm.expectRevert(VaultBridgeToken.InvalidVaultBridgeTokenPart2.selector);
        vbToken = TestHarnessVaultBridgeToken(payable(_proxify(vbTokenImplementation, address(this), initData)));
    }

    function test_deposit_revert() public {
        uint256 amount = 1 ether;

        bytes memory callData = abi.encodeCall(vbToken.deposit, (amount, recipient));
        _testPauseUnpause(owner, address(vbToken), callData);

        deal(underlyingToken, sender, amount);

        vm.startPrank(sender);

        vm.expectRevert(VaultBridgeToken.InvalidAssets.selector);
        vbToken.deposit(0, recipient);

        vm.expectRevert(VaultBridgeToken.InvalidReceiver.selector);
        vbToken.deposit(amount, address(0));

        vm.expectRevert(VaultBridgeToken.InvalidReceiver.selector);
        vbToken.deposit(amount, address(vbToken));

        vm.stopPrank();
    }

    function test_deposit_amount_gt_max_deposit() public {
        uint256 vaultMaxDeposit = yieldVault.maxDeposit(address(vbToken));
        uint256 amount = (vaultMaxDeposit * 10) / 9 + 1; // account for the minimum reserve percentage and add to make the amount greater than the max deposit limit
        assertGt(amount, MINIMUM_YIELD_VAULT_DEPOSIT, "Amount should be greater than the minimum deposit.");

        _dealAndApprove(underlyingToken, sender, amount, address(vbToken));

        vm.startPrank(sender);

        uint256 sharesToBeMinted = vbToken.previewDeposit(amount);
        vm.expectEmit();
        emit IERC4626.Deposit(sender, recipient, amount, sharesToBeMinted);
        vbToken.deposit(amount, recipient);

        vm.stopPrank();

        // since max deposit is reached, the reserve amount should be calculated based on the max deposit limit
        uint256 reserveAssetsAfterDeposit = calculateReserveAssets(amount, vaultMaxDeposit);

        assertEq(IERC20(underlyingToken).balanceOf(address(vbToken)), reserveAssetsAfterDeposit); // reserve assets increased
        assertGt(yieldVault.balanceOf(address(vbToken)), 0); // shares locked in the vault
        assertEq(vbToken.balanceOf(recipient), sharesToBeMinted); // shares minted to the recipient
    }

    function test_deposit_exceeds_max_and_reserve_above_threshold() public {
        uint256 amount = 100 ether; // use a large amount to ensure reserve exceeds the threshold
        assertGt(amount, MAX_DEPOSIT, "Amount should be greater than the max deposit.");

        uint256 reserveAssetsAfterDeposit = calculateReserveAssets(amount, MAX_DEPOSIT);
        uint256 reserveThreshold = 3 * minimumReservePercentage; // the threshold is set to 3x the minimum reserve percentage according to the spec
        uint256 maxDepositPercentage = Math.mulDiv(reserveAssetsAfterDeposit, 1e18, amount);

        assertGt(
            maxDepositPercentage,
            reserveThreshold,
            "Max deposit percentage should be greater than the reserve threshold."
        );

        _dealAndApprove(underlyingToken, sender, amount, address(vbToken));

        vm.startPrank(sender);

        uint256 sharesToBeMinted = vbToken.previewDeposit(amount);
        vm.expectEmit();
        emit IERC4626.Deposit(sender, recipient, amount, sharesToBeMinted);
        vbToken.deposit(amount, recipient);

        vm.stopPrank();

        // since the reserve percentage is above the threshold, the reserve amount should be calculated based on the rebalanced amount
        uint256 newAmount = reserveAssetsAfterDeposit;
        uint256 finalReserveAssets = calculateReserveAssets(newAmount, MAX_DEPOSIT);

        assertEq(IERC20(underlyingToken).balanceOf(address(vbToken)), finalReserveAssets); // reserve assets increased
        assertGt(yieldVault.balanceOf(address(vbToken)), 0); // shares locked in the vault
        assertEq(vbToken.balanceOf(recipient), sharesToBeMinted); // shares minted to the recipient
    }

    function test_deposit_amount_lt_max_deposit() public {
        uint256 vaultMaxDeposit = yieldVault.maxDeposit(address(vbToken));
        uint256 amount = (vaultMaxDeposit * 10) / 9 - 1; // account for the minimum reserve percentage and subtract to make the amount less than the max deposit limit
        assertGt(amount, MINIMUM_YIELD_VAULT_DEPOSIT, "Amount should be greater than the minimum deposit.");

        _dealAndApprove(underlyingToken, sender, amount, address(vbToken));

        vm.startPrank(sender);

        uint256 sharesToBeMinted = vbToken.previewDeposit(amount);
        vm.expectEmit();
        emit IERC4626.Deposit(sender, recipient, amount, sharesToBeMinted);
        vbToken.deposit(amount, recipient);

        vm.stopPrank();

        // since max deposit is not reached, the reserve amount should be calculated based on the deposit amount
        uint256 reserveAssets = (amount * minimumReservePercentage) / MAX_RESERVE_PERCENTAGE;

        assertEq(IERC20(underlyingToken).balanceOf(address(vbToken)), reserveAssets); // reserve assets increased
        assertGt(yieldVault.balanceOf(address(vbToken)), 0); // shares locked in the vault
        assertEq(vbToken.balanceOf(recipient), sharesToBeMinted); // shares minted to the recipient
    }

    function test_deposit_amount_lt_minimum_deposit() public {
        uint256 amount = MINIMUM_YIELD_VAULT_DEPOSIT - 1;

        _dealAndApprove(underlyingToken, sender, amount, address(vbToken));

        vm.startPrank(sender);

        uint256 sharesToBeMinted = vbToken.previewDeposit(amount);
        vm.expectEmit();
        emit IERC4626.Deposit(sender, recipient, amount, sharesToBeMinted);
        vbToken.deposit(amount, recipient);

        vm.stopPrank();

        assertEq(IERC20(underlyingToken).balanceOf(address(vbToken)), amount); // All assets are reserved and non are deposited in the vault
        assertEq(yieldVault.balanceOf(address(vbToken)), 0); // No assets deposited in the vault
        assertEq(vbToken.balanceOf(recipient), sharesToBeMinted); // shares minted to the recipient
    }

    function test_depositWithPermit_revert() public {
        uint256 amount = 100 ether;

        deal(underlyingToken, sender, amount);
        vm.startPrank(sender);

        vm.expectRevert(VaultBridgeToken.InvalidPermitData.selector);
        vbToken.depositWithPermit(amount, recipient, bytes(""));

        vm.stopPrank();
    }

    function test_depositWithPermit() public virtual {
        uint256 amount = 1 ether;
        uint256 vaultMaxDeposit = yieldVault.maxDeposit(address(vbToken));

        deal(underlyingToken, sender, amount);

        bytes32 domainSeparator = IERC20Permit(underlyingToken).DOMAIN_SEPARATOR();

        (uint8 v, bytes32 r, bytes32 s) = vm.sign(
            senderPrivateKey,
            keccak256(
                abi.encodePacked(
                    "\x19\x01",
                    domainSeparator, // remember to use the domain separator of the underlying token
                    keccak256(
                        abi.encode(
                            PERMIT_TYPEHASH, sender, address(vbToken), amount, vm.getNonce(sender), block.timestamp
                        )
                    )
                )
            )
        );
        bytes memory permitData =
            abi.encodeWithSelector(PERMIT_SIGNATURE, sender, address(vbToken), amount, block.timestamp, v, r, s);

        uint256 sharesToBeMinted = vbToken.previewDeposit(amount);

        vm.startPrank(sender);
        vm.expectEmit();
        emit IERC4626.Deposit(sender, recipient, amount, sharesToBeMinted);
        vbToken.depositWithPermit(amount, recipient, permitData);
        vm.stopPrank();

        uint256 reserveAssetsAfterDeposit = calculateReserveAssets(amount, vaultMaxDeposit);

        assertEq(IERC20(underlyingToken).balanceOf(address(vbToken)), reserveAssetsAfterDeposit); // reserve assets increased
        assertEq(vbToken.balanceOf(recipient), sharesToBeMinted); // shares minted to the recipient
    }

    function test_depositAndBridge_revert() public {
        uint256 amount = 100 ether;

        vm.expectRevert(VaultBridgeToken.InvalidDestinationNetworkId.selector);
        vbToken.depositAndBridge(amount, recipient, 0, true);
    }

    function test_depositAndBridge() public {
        uint256 amount = 1 ether;
        uint256 vaultMaxDeposit = yieldVault.maxDeposit(address(vbToken));

        bytes memory callData = abi.encodeCall(vbToken.depositAndBridge, (amount, recipient, NETWORK_ID_L2, true));
        _testPauseUnpause(owner, address(vbToken), callData);

        _dealAndApprove(underlyingToken, sender, amount, address(vbToken));

        vm.startPrank(sender);
        vm.expectEmit();
        emit MockAgglayerBridge.BridgeEvent(
            LEAF_TYPE_ASSET,
            NETWORK_ID_L1,
            address(vbToken),
            NETWORK_ID_L2,
            recipient,
            amount,
            tokenMetadata,
            _IAgglayerBridge(agglayerBridge).depositCount()
        );
        vbToken.depositAndBridge(amount, recipient, NETWORK_ID_L2, true);
        vm.stopPrank();

        uint256 reserveAssetsAfterDeposit = calculateReserveAssets(amount, vaultMaxDeposit);

        assertEq(IERC20(underlyingToken).balanceOf(address(vbToken)), reserveAssetsAfterDeposit); // reserve assets increased
        assertEq(vbToken.balanceOf(agglayerBridge), amount); // shares locked on bridge
    }

    function test_depositAndBridgePermit() public virtual {
        uint256 amount = 1 ether;
        uint256 vaultMaxDeposit = yieldVault.maxDeposit(address(vbToken));

        deal(underlyingToken, sender, amount);

        bytes32 domainSeparator = IERC20Permit(underlyingToken).DOMAIN_SEPARATOR();

        (uint8 v, bytes32 r, bytes32 s) = vm.sign(
            senderPrivateKey,
            keccak256(
                abi.encodePacked(
                    "\x19\x01",
                    domainSeparator, // remember to use the domain separator of the underlying token
                    keccak256(
                        abi.encode(
                            PERMIT_TYPEHASH, sender, address(vbToken), amount, vm.getNonce(sender), block.timestamp
                        )
                    )
                )
            )
        );
        bytes memory permitData =
            abi.encodeWithSelector(PERMIT_SIGNATURE, sender, address(vbToken), amount, block.timestamp, v, r, s);

        vm.startPrank(sender);
        vm.expectEmit();
        emit MockAgglayerBridge.BridgeEvent(
            LEAF_TYPE_ASSET,
            NETWORK_ID_L1,
            address(vbToken),
            NETWORK_ID_L2,
            recipient,
            amount,
            tokenMetadata,
            _IAgglayerBridge(agglayerBridge).depositCount()
        );
        vbToken.depositWithPermitAndBridge(amount, recipient, NETWORK_ID_L2, true, permitData);
        vm.stopPrank();

        uint256 reserveAssetsAfterDeposit = calculateReserveAssets(amount, vaultMaxDeposit);

        assertEq(IERC20(underlyingToken).balanceOf(address(vbToken)), reserveAssetsAfterDeposit);
        assertEq(vbToken.balanceOf(agglayerBridge), amount); // shares locked on bridge
    }

    function test_mint() public virtual {
        uint256 amount = 1 ether;
        uint256 vaultMaxDeposit = yieldVault.maxDeposit(address(vbToken));

        bytes memory callData = abi.encodeCall(vbToken.mint, (amount, recipient));
        _testPauseUnpause(owner, address(vbToken), callData);

        _dealAndApprove(underlyingToken, sender, amount, address(vbToken));
        uint256 sharesToBeMinted = vbToken.previewMint(amount);

        vm.startPrank(sender);
        vbToken.mint(amount, sender);
        vm.stopPrank();

        uint256 reserveAssetsAfterDeposit = calculateReserveAssets(amount, vaultMaxDeposit);

        assertEq(IERC20(underlyingToken).balanceOf(address(vbToken)), reserveAssetsAfterDeposit);
        assertEq(vbToken.balanceOf(sender), sharesToBeMinted); // shares minted to the recipient
    }

    function test_withdraw_revert() public {
        uint256 amountGtMaxWithdraw = 100 ether;

        bytes memory callData = abi.encodeCall(vbToken.withdraw, (amountGtMaxWithdraw, recipient, sender));
        _testPauseUnpause(owner, address(vbToken), callData);

        vm.expectRevert(VaultBridgeToken.InvalidAssets.selector);
        vbToken.withdraw(0, recipient, sender);

        vm.expectRevert(VaultBridgeToken.InvalidReceiver.selector);
        vbToken.withdraw(amountGtMaxWithdraw, address(0), sender);

        vm.expectRevert(VaultBridgeToken.InvalidOwner.selector);
        vbToken.withdraw(amountGtMaxWithdraw, recipient, address(0));

        uint256 stateBeforeDeposit = vm.snapshotState();

        deal(underlyingToken, sender, amountGtMaxWithdraw);

        vm.startPrank(sender);

        IERC20(underlyingToken).forceApprove(address(vbToken), amountGtMaxWithdraw);
        vbToken.deposit(amountGtMaxWithdraw, sender);
        assertEq(IERC20(underlyingToken).balanceOf(sender), 0); // make sure sender has deposited all assets
        assertEq(vbToken.balanceOf(sender), amountGtMaxWithdraw);

        uint256 withdrawableAmount = _calculateWithdrawableAmount(amountGtMaxWithdraw);
        uint256 availableAmount = vbToken.reservedAssets() + withdrawableAmount;
        vm.expectRevert(
            abi.encodeWithSelector(VaultBridgeToken.AssetsTooLarge.selector, availableAmount, amountGtMaxWithdraw + 1)
        );
        vbToken.withdraw(amountGtMaxWithdraw + 1, sender, sender);

        vm.revertToState(stateBeforeDeposit);

        uint256 amountLtMaxWithdraw = MAX_WITHDRAW - 1;

        deal(underlyingToken, sender, amountLtMaxWithdraw);

        IERC20(underlyingToken).forceApprove(address(vbToken), amountLtMaxWithdraw);
        vbToken.deposit(amountLtMaxWithdraw, sender);
        assertEq(IERC20(underlyingToken).balanceOf(sender), 0); // make sure sender has deposited all assets
        assertEq(vbToken.balanceOf(sender), amountLtMaxWithdraw);

        vm.expectRevert("MockVault: Insufficient balance");
        vbToken.withdraw(amountLtMaxWithdraw + 1, sender, sender);

        vm.revertToState(stateBeforeDeposit);

        uint256 amount = 1 ether;

        deal(underlyingToken, sender, amount);

        IERC20(underlyingToken).forceApprove(address(vbToken), amount);
        vbToken.deposit(amount, sender);
        assertEq(IERC20(underlyingToken).balanceOf(sender), 0); // make sure sender has deposited all assets
        assertEq(vbToken.balanceOf(sender), amount);

        uint256 withdrawAmount = vbToken.stakedAssets();
        uint256 slippageAmount = Math.mulDiv(
            withdrawAmount, YIELD_VAULT_ALLOWED_SLIPPAGE + Math.mulDiv(YIELD_VAULT_ALLOWED_SLIPPAGE, 1, 100), 1e18
        );
        yieldVault.setSlippage(true, slippageAmount);

        vm.expectRevert(
            abi.encodeWithSelector(
                VaultBridgeToken.ExcessiveYieldVaultSharesBurned.selector,
                withdrawAmount + slippageAmount,
                withdrawAmount
            )
        );
        vbToken.withdraw(amount, sender, sender);

        vm.stopPrank();
    }

    function test_withdraw_from_reserve() public virtual {
        uint256 amount = 1 ether;
        uint256 vaultMaxDeposit = yieldVault.maxDeposit(address(vbToken));

        _dealAndApprove(underlyingToken, sender, amount, address(vbToken));

        vm.startPrank(sender);
        vbToken.deposit(amount, sender);
        assertEq(IERC20(underlyingToken).balanceOf(sender), 0); // make sure sender has deposited all assets
        assertEq(vbToken.balanceOf(sender), amount);

        uint256 reserveAssetsAfterDeposit = calculateReserveAssets(amount, vaultMaxDeposit);
        uint256 reserveWithdrawAmount = (reserveAssetsAfterDeposit * 90) / 100; // withdraw 90% of reserve assets
        uint256 reserveAfterWithdraw = reserveAssetsAfterDeposit - reserveWithdrawAmount;

        vm.expectEmit();
        emit IERC4626.Withdraw(sender, sender, sender, reserveWithdrawAmount, reserveWithdrawAmount);
        vbToken.withdraw(reserveWithdrawAmount, sender, sender);
        assertEq(IERC20(underlyingToken).balanceOf(address(vbToken)), reserveAfterWithdraw); // reserve assets reduced
        assertEq(IERC20(underlyingToken).balanceOf(sender), reserveWithdrawAmount); // assets returned to sender
        assertEq(vbToken.balanceOf(sender), amount - reserveWithdrawAmount); // shares reduced

        vm.stopPrank();
    }

    function test_withdraw_from_stake() public virtual {
        uint256 amount = 1 ether;

        _dealAndApprove(underlyingToken, sender, amount, address(vbToken));
        vm.startPrank(sender);
        vbToken.deposit(amount, sender);
        assertEq(IERC20(underlyingToken).balanceOf(sender), 0); // make sure sender has deposited all assets
        assertEq(vbToken.balanceOf(sender), amount);

        uint256 amountToWithdraw = amount;

        vm.expectEmit();
        emit IERC4626.Withdraw(sender, sender, sender, amountToWithdraw, amountToWithdraw);
        vbToken.withdraw(amountToWithdraw, sender, sender);
        assertEq(IERC20(underlyingToken).balanceOf(sender), amountToWithdraw);
        assertEq(IERC20(underlyingToken).balanceOf(address(vbToken)), 0); // reserve assets reduced
        assertEq(IERC20(underlyingToken).balanceOf(sender), amountToWithdraw); // assets returned to sender
        assertEq(vbToken.balanceOf(sender), amount - amountToWithdraw); // shares reduced
        vm.stopPrank();
    }

    function test_rebalanceReserve_revert() public {
        vm.expectRevert(); // only owner can rebalance reserve
        (address(vbToken).call(abi.encodeCall(vbTokenPart2.rebalanceReserve, ())));

        bytes memory callData = abi.encodeCall(vbTokenPart2.rebalanceReserve, ());
        _testPauseUnpause(owner, address(vbToken), callData);
    }

    function test_rebalanceReserve_below() public virtual {
        uint256 vaultMaxDeposit = yieldVault.maxDeposit(address(vbToken));
        uint256 amount = (vaultMaxDeposit * 10) / 9 + 1; // account for the minimum reserve percentage and add to make the amount greater than the max deposit limit
        assertGt(amount, MINIMUM_YIELD_VAULT_DEPOSIT, "Amount should be greater than the minimum deposit.");

        uint256 totalSupply;
        _dealAndApprove(underlyingToken, sender, amount, address(vbToken)); // fund the sender

        uint256 reserveAmount = calculateReserveAssets(amount, vaultMaxDeposit);

        // create reserve
        vm.startPrank(sender);
        vbToken.deposit(amount, recipient);
        totalSupply += amount;
        assertEq(vbToken.reservedAssets(), reserveAmount);

        uint256 stakedAssetsBefore = vbToken.stakedAssets();

        // offset the reserve by reducing the reserve assets
        vm.store(address(vbToken), RESERVE_ASSET_STORAGE, bytes32(uint256(reserveAmount - 100)));

        vm.stopPrank();

        uint256 finalReserveAmount =
            Math.mulDiv(totalSupply, minimumReservePercentage, MAX_RESERVE_PERCENTAGE, Math.Rounding.Ceil);
        uint256 finalPercentage = finalReserveAmount * 1e18 / totalSupply;
        vm.expectEmit();
        emit VaultBridgeToken.ReserveRebalanced(reserveAmount - 100, finalReserveAmount, finalPercentage);
        vm.prank(owner);
        (address(vbToken).call(abi.encodeCall(vbTokenPart2.rebalanceReserve, ())));

        assertEq(vbToken.reservedAssets(), finalReserveAmount);
        assertGt(stakedAssetsBefore, vbToken.stakedAssets()); // staked assets would be reduced as reserve is replinished from the vault
    }

    function test_rebalanceReserve_above() public virtual {
        uint256 vaultMaxDeposit = yieldVault.maxDeposit(address(vbToken));
        uint256 amount = vaultMaxDeposit / 2;
        assertGt(amount, MINIMUM_YIELD_VAULT_DEPOSIT, "Amount should be greater than the minimum deposit.");

        uint256 totalSupply;
        _dealAndApprove(underlyingToken, sender, amount, address(vbToken)); // fund the sender

        uint256 reserveAmount = calculateReserveAssets(amount, vaultMaxDeposit);

        vm.startPrank(sender);
        vbToken.deposit(amount, recipient);
        totalSupply += amount;
        assertEq(vbToken.reservedAssets(), reserveAmount);

        uint256 stakedAssetsBefore = vbToken.stakedAssets();

        // offset the reserve by increasing the reserve assets
        vm.store(address(vbToken), RESERVE_ASSET_STORAGE, bytes32(uint256(reserveAmount + MINIMUM_YIELD_VAULT_DEPOSIT)));

        vm.stopPrank();

        uint256 finalReserveAmount = totalSupply * minimumReservePercentage / MAX_RESERVE_PERCENTAGE;
        uint256 finalPercentage = finalReserveAmount * 1e18 / totalSupply;
        vm.expectEmit();
        emit VaultBridgeToken.ReserveRebalanced(
            reserveAmount + MINIMUM_YIELD_VAULT_DEPOSIT, finalReserveAmount, finalPercentage
        );
        vm.prank(owner);
        vbTokenPart2.rebalanceReserve();

        assertEq(vbToken.reservedAssets(), finalReserveAmount);
        assertGt(vbToken.stakedAssets(), stakedAssetsBefore); //  staked assets would be increased as execess reserve is deposited in the vault
    }

    function test_collectYield() public {
        vm.expectRevert(); // only owner can claim yield
        vbTokenPart2.collectYield();

        vm.expectRevert(VaultBridgeToken.NoYield.selector); // no reserved and staked assets
        vm.prank(owner);
        vbTokenPart2.collectYield();

        uint256 amount = 100 ether;
        uint256 yieldInAssets = 500 ether;

        _dealAndApprove(underlyingToken, sender, amount, address(vbToken));
        vm.startPrank(sender);
        vbToken.mint(amount, sender);
        vm.stopPrank();

        uint256 sharesBalanceBefore = yieldVault.balanceOf(address(vbToken));
        uint256 yieldShares = yieldVault.convertToShares(yieldInAssets);

        deal(address(yieldVault), address(vbToken), sharesBalanceBefore + yieldShares); // add yield to the vault

        uint256 expectedYieldAssets = vbToken.yield();

        vm.expectEmit();
        emit VaultBridgeToken.YieldCollected(yieldRecipient, expectedYieldAssets);
        vm.prank(owner);
        vbTokenPart2.collectYield();

        vm.assertEq(vbToken.balanceOf(yieldRecipient), expectedYieldAssets);
    }

    function test_setYieldRecipient_no_yield() public {
        address newRecipient = makeAddr("newRecipient");
        vm.expectRevert(); // only owner can claim yield
        vbTokenPart2.setYieldRecipient(newRecipient);

        vm.expectRevert(VaultBridgeToken.InvalidYieldRecipient.selector);
        vm.prank(owner);
        vbTokenPart2.setYieldRecipient(address(0));

        assertEq(vbToken.yieldRecipient(), yieldRecipient);

        vm.expectEmit();
        emit VaultBridgeToken.YieldRecipientSet(newRecipient);
        vm.prank(owner);
        vbTokenPart2.setYieldRecipient(newRecipient);
        assertEq(vbToken.yieldRecipient(), newRecipient);
    }

    function test_setYieldRecipient_with_yield() public {
        uint256 amount = 100 ether;
        uint256 yieldInAssets = 500 ether;
        address newRecipient = makeAddr("newRecipient");

        // generate yield
        _dealAndApprove(underlyingToken, sender, amount, address(vbToken));
        vm.startPrank(sender);
        vbToken.mint(amount, sender);
        vm.stopPrank();

        uint256 sharesBalanceBefore = yieldVault.balanceOf(address(vbToken));
        uint256 yieldShares = yieldVault.convertToShares(yieldInAssets);

        deal(address(yieldVault), address(vbToken), sharesBalanceBefore + yieldShares); // add yield to the vault

        uint256 expectedYieldAssets = vbToken.yield();

        assertEq(vbToken.yieldRecipient(), yieldRecipient);

        vm.expectEmit();
        emit VaultBridgeToken.YieldCollected(yieldRecipient, expectedYieldAssets);
        vm.prank(owner);
        vbTokenPart2.setYieldRecipient(newRecipient);
        assertEq(vbToken.balanceOf(yieldRecipient), expectedYieldAssets); // yield collected to the old recipient
        assertEq(vbToken.yieldRecipient(), newRecipient);
    }

    function test_setMinimumReservePercentage_no_rebalance() public {
        uint256 newPercentage = 2e17;
        vm.expectRevert(); // only owner can set minimum reserve percentage
        vbTokenPart2.setMinimumReservePercentage(newPercentage);

        vm.expectRevert(VaultBridgeToken.InvalidMinimumReservePercentage.selector);
        vm.prank(owner);
        vbTokenPart2.setMinimumReservePercentage(MAX_RESERVE_PERCENTAGE + 1);

        assertEq(vbToken.minimumReservePercentage(), minimumReservePercentage); // sanity check

        vm.expectEmit();
        emit VaultBridgeToken.MinimumReservePercentageSet(newPercentage);
        vm.prank(owner);
        vbTokenPart2.setMinimumReservePercentage(newPercentage);
        assertEq(vbToken.minimumReservePercentage(), newPercentage);
    }

    function test_redeem_revert() public {
        bytes memory callData = abi.encodeCall(vbToken.redeem, (100 ether, sender, sender));
        _testPauseUnpause(owner, address(vbToken), callData);

        vm.expectRevert(VaultBridgeToken.InvalidShares.selector);
        vbToken.redeem(0, sender, sender);

        vm.stopPrank();
    }

    function test_redeem() public virtual {
        uint256 amount = 1 ether;

        _dealAndApprove(underlyingToken, sender, amount, address(vbToken));

        vm.startPrank(sender);
        vbToken.deposit(amount, sender);
        assertEq(IERC20(underlyingToken).balanceOf(sender), 0);
        assertEq(vbToken.balanceOf(sender), amount);

        uint256 redeemAmount = vbToken.totalAssets();

        vbToken.redeem(redeemAmount, sender, sender); // redeem from both staked and reserved assets
        assertEq(IERC20(underlyingToken).balanceOf(sender), redeemAmount);
        vm.stopPrank();
    }

    function test_completeMigration_revert() public {
        bytes memory callData = abi.encodeCall(vbTokenPart2.completeMigration, (NETWORK_ID_L1, 0, 0));
        _testPauseUnpause(owner, address(vbToken), callData);

        // Not Migration manager
        vm.expectRevert(VaultBridgeToken.Unauthorized.selector);
        vbTokenPart2.completeMigration(NETWORK_ID_L2, 100, 100);

        vm.startPrank(migrationManagerAddr);

        // Wrong network id
        vm.expectRevert(VaultBridgeToken.InvalidOriginNetwork.selector);
        vbTokenPart2.completeMigration(NETWORK_ID_L1, 100, 100);

        vm.expectRevert(VaultBridgeToken.InvalidShares.selector);
        vbTokenPart2.completeMigration(NETWORK_ID_L2, 0, 100);

        vm.stopPrank();
    }

    function test_completeMigration_no_discrepancy_shares_lt_max_deposit() public {
        uint256 vaultMaxDeposit = yieldVault.maxDeposit(address(vbToken));
        uint256 amount = (vaultMaxDeposit * 10) / 9 - 1;
        uint256 shares = vbToken.convertToShares(amount);

        deal(underlyingToken, address(vbToken), amount);

        uint256 stakedAssetsBefore = vbToken.stakedAssets();

        vm.expectEmit();
        emit MockAgglayerBridge.BridgeEvent(
            LEAF_TYPE_ASSET,
            NETWORK_ID_L1,
            address(vbToken),
            NETWORK_ID_L2,
            address(0),
            shares,
            tokenMetadata,
            _IAgglayerBridge(agglayerBridge).depositCount()
        );
        vm.expectEmit();
        emit IERC4626.Deposit(migrationManagerAddr, address(vbToken), amount, shares);
        vm.expectEmit();
        emit VaultBridgeToken.MigrationCompleted(NETWORK_ID_L2, shares, amount, 0);
        vm.prank(migrationManagerAddr);
        vbTokenPart2.completeMigration(NETWORK_ID_L2, shares, amount);

        uint256 reserveAssetsAfterDeposit =
            vbToken.convertToAssets(shares) * minimumReservePercentage / MAX_RESERVE_PERCENTAGE;

        assertEq(vbToken.reservedAssets(), reserveAssetsAfterDeposit);
        assertGt(vbToken.stakedAssets(), stakedAssetsBefore);
    }

    function test_completeMigration_no_discrepancy_shares_gt_max_deposit() public {
        uint256 vaultMaxDeposit = yieldVault.maxDeposit(address(vbToken));
        uint256 amount = (vaultMaxDeposit * 10) / 9 + 1;
        uint256 shares = vbToken.convertToShares(amount);

        deal(underlyingToken, address(vbToken), amount);

        uint256 stakedAssetsBefore = vbToken.stakedAssets();

        vm.expectEmit();
        emit MockAgglayerBridge.BridgeEvent(
            LEAF_TYPE_ASSET,
            NETWORK_ID_L1,
            address(vbToken),
            NETWORK_ID_L2,
            address(0),
            shares,
            tokenMetadata,
            _IAgglayerBridge(agglayerBridge).depositCount()
        );
        vm.expectEmit();
        emit IERC4626.Deposit(migrationManagerAddr, address(vbToken), amount, shares);
        vm.expectEmit();
        emit VaultBridgeToken.MigrationCompleted(NETWORK_ID_L2, shares, amount, 0);
        vm.prank(migrationManagerAddr);
        vbTokenPart2.completeMigration(NETWORK_ID_L2, shares, amount);

        // since max deposit is reached, the reserve amount should be calculated based on the max deposit limit
        uint256 reserveAssetsAfterDeposit = calculateReserveAssets(amount, vaultMaxDeposit);

        assertEq(vbToken.reservedAssets(), reserveAssetsAfterDeposit);
        assertGt(vbToken.stakedAssets(), stakedAssetsBefore);
    }

    function test_completeMigration_with_discrepancy() public {
        uint256 vaultMaxDeposit = yieldVault.maxDeposit(address(vbToken));
        uint256 amount = (vaultMaxDeposit * 10) / 9 - 1;
        uint256 shares = vbToken.convertToShares(amount) + vbToken.convertToShares(1);

        // no migration fees funds
        vm.expectRevert(abi.encodeWithSelector(VaultBridgeToken.CannotCompleteMigration.selector, shares, amount, 0));
        vm.prank(migrationManagerAddr);
        vbTokenPart2.completeMigration(NETWORK_ID_L2, shares, amount);

        // fund the migration fees
        deal(underlyingToken, address(this), amount);
        IERC20(underlyingToken).forceApprove(address(vbToken), amount);
        vm.expectEmit();
        emit VaultBridgeToken.DonatedForCompletingMigration(address(this), amount);
        vbTokenPart2.donateForCompletingMigration(amount);
        assertEq(vbToken.migrationFeesFund(), amount);

        uint256 stakedAssetsBefore = vbToken.stakedAssets();

        vm.expectEmit();
        emit MockAgglayerBridge.BridgeEvent(
            LEAF_TYPE_ASSET,
            NETWORK_ID_L1,
            address(vbToken),
            NETWORK_ID_L2,
            address(0),
            shares,
            tokenMetadata,
            _IAgglayerBridge(agglayerBridge).depositCount()
        );
        vm.expectEmit();
        emit IERC4626.Deposit(migrationManagerAddr, address(vbToken), amount, shares);
        vm.expectEmit();
        emit VaultBridgeToken.MigrationCompleted(NETWORK_ID_L2, shares, amount, shares - amount);
        vm.prank(migrationManagerAddr);
        vbTokenPart2.completeMigration(NETWORK_ID_L2, shares, amount);

        uint256 reserveAssetsAfterDeposit = Math.mulDiv(
            vbToken.convertToAssets(shares), minimumReservePercentage, MAX_RESERVE_PERCENTAGE, Math.Rounding.Ceil
        );

        assertEq(vbToken.reservedAssets(), reserveAssetsAfterDeposit);
        assertGt(vbToken.stakedAssets(), stakedAssetsBefore);
    }

    function test_maxDeposit() public {
        assertEq(vbToken.maxDeposit(address(0)), type(uint256).max);

        vm.prank(owner);
        vbTokenPart2.pause();
        assertEq(vbToken.maxDeposit(address(0)), 0);
    }

    function test_previewDeposit() public {
        uint256 amount = 100 ether;

        bytes memory callData = abi.encodeCall(vbToken.previewDeposit, (amount));
        _testPauseUnpause(owner, address(vbToken), callData);

        vm.expectRevert(VaultBridgeToken.InvalidAssets.selector);
        vbToken.previewDeposit(0);

        vm.assertEq(vbToken.previewDeposit(amount), amount);
    }

    function test_maxMint() public virtual {
        assertEq(vbToken.maxMint(address(0)), type(uint256).max);

        vm.prank(owner);
        vbTokenPart2.pause();
        assertEq(vbToken.maxMint(address(0)), 0);
    }

    function test_previewMint() public virtual {
        uint256 amount = 100 ether;

        bytes memory callData = abi.encodeCall(vbToken.previewMint, (amount));
        _testPauseUnpause(owner, address(vbToken), callData);

        vm.expectRevert(VaultBridgeToken.InvalidShares.selector);
        vbToken.previewMint(0);

        vm.assertEq(vbToken.previewMint(amount), amount);
    }

    function test_maxWithdraw() public virtual {
        uint256 amount = 1 ether;

        vm.startPrank(owner);
        vbTokenPart2.pause();
        vm.assertEq(vbToken.maxWithdraw(address(0)), 0);
        vbTokenPart2.unpause();
        vm.stopPrank();

        assertEq(vbToken.maxWithdraw(address(0)), 0); // 0 if no shares

        _dealAndApprove(underlyingToken, sender, amount, address(vbToken));
        vm.startPrank(sender);
        vbToken.deposit(amount, sender);
        vm.stopPrank();

        assertEq(vbToken.maxWithdraw(sender), vbToken.totalAssets());
    }

    function test_previewWithdraw() public virtual {
        uint256 amount = 11 ether;
        uint256 vaultMaxDeposit = yieldVault.maxDeposit(address(vbToken));

        bytes memory callData = abi.encodeCall(vbToken.previewWithdraw, (amount));
        _testPauseUnpause(owner, address(vbToken), callData);

        vm.expectRevert(VaultBridgeToken.InvalidAssets.selector);
        vbToken.previewWithdraw(0);

        _dealAndApprove(underlyingToken, sender, amount, address(vbToken));
        vm.startPrank(sender);
        vbToken.deposit(amount, sender);
        vm.stopPrank();

        uint256 withdrawableAmount = _calculateWithdrawableAmount(amount + 1 ether);
        uint256 availableAmount = vbToken.reservedAssets() + withdrawableAmount;
        vm.expectRevert(
            abi.encodeWithSelector(VaultBridgeToken.AssetsTooLarge.selector, availableAmount, amount + 1 ether)
        );
        vbToken.previewWithdraw(amount + 1 ether);

        uint256 stakedAmount = yieldVault.convertToAssets(yieldVault.balanceOf(address(vbToken)));
        uint256 reserveAssetsAfterDeposit = calculateReserveAssets(amount, vaultMaxDeposit);

        vm.assertEq(vbToken.previewWithdraw(reserveAssetsAfterDeposit), vbToken.reservedAssets()); // reserve assets
        vm.assertEq(vbToken.previewWithdraw(reserveAssetsAfterDeposit + stakedAmount), vbToken.totalAssets()); // reserve + staked assets
    }

    function test_maxRedeem() public virtual {
        uint256 amount = 1 ether;

        vm.startPrank(owner);
        vbTokenPart2.pause();
        vm.assertEq(vbToken.maxRedeem(sender), 0);
        vbTokenPart2.unpause();
        vm.stopPrank();

        assertEq(vbToken.maxRedeem(sender), 0); // 0 if no shares

        _dealAndApprove(underlyingToken, sender, amount, address(vbToken));
        vm.startPrank(sender);
        vbToken.deposit(amount, sender);
        vm.stopPrank();

        assertEq(vbToken.maxRedeem(sender), vbToken.totalAssets());
    }

    function test_previewRedeem() public virtual {
        uint256 amount = 1 ether;
        uint256 vaultMaxDeposit = yieldVault.maxDeposit(address(vbToken));
        uint256 reserveAmount = (amount * minimumReservePercentage) / MAX_RESERVE_PERCENTAGE;

        bytes memory callData = abi.encodeCall(vbToken.previewRedeem, (amount));
        _testPauseUnpause(owner, address(vbToken), callData);

        vm.expectRevert(VaultBridgeToken.InvalidShares.selector);
        vbToken.previewRedeem(0);

        _dealAndApprove(underlyingToken, sender, amount, address(vbToken));
        vm.startPrank(sender);
        vbToken.deposit(amount, sender);
        vm.stopPrank();

        uint256 stakedAmount = yieldVault.convertToAssets(yieldVault.balanceOf(address(vbToken)));
        uint256 assetsToDeposit = amount - reserveAmount;
        uint256 assetsToDepositMax = (assetsToDeposit > vaultMaxDeposit) ? vaultMaxDeposit : assetsToDeposit;
        uint256 reserveAssetsAfterDeposit = amount - assetsToDepositMax;

        vm.assertEq(vbToken.previewRedeem(reserveAssetsAfterDeposit), vbToken.reservedAssets()); // reserve assets
        vm.assertEq(vbToken.previewRedeem(reserveAssetsAfterDeposit + stakedAmount), vbToken.totalAssets()); // reserve + staked assets
    }

    function test_reservePercentage() public {
        uint256 amount = 1 ether;
        uint256 vaultMaxDeposit = yieldVault.maxDeposit(address(vbToken));

        _dealAndApprove(underlyingToken, sender, amount, address(vbToken));
        vm.startPrank(sender);
        vbToken.deposit(amount, sender);
        vm.stopPrank();

        uint256 reserveAssetsAfterDeposit = calculateReserveAssets(amount, vaultMaxDeposit);

        uint256 expectedPercentage = (reserveAssetsAfterDeposit * MAX_RESERVE_PERCENTAGE) / vbToken.totalSupply();

        assertEq(vbToken.reservePercentage(), expectedPercentage);
    }

    function test_burn_revert() public virtual {
        uint256 amount = 1 ether;

        // Only yield recipient can burn
        vm.expectRevert(VaultBridgeToken.Unauthorized.selector);
        vbTokenPart2.burn(amount);

        // Cannot burn 0 shares
        vm.expectRevert(VaultBridgeToken.InvalidShares.selector);
        vm.prank(yieldRecipient);
        vbTokenPart2.burn(0);
    }

    function test_burn() public virtual {
        uint256 amount = 1 ether;

        // First, set up yield to burn - need to deposit, collect yield, then burn
        _dealAndApprove(underlyingToken, sender, amount, address(vbToken));
        vm.startPrank(sender);
        vbToken.deposit(amount, sender);
        vm.stopPrank();

        // Generate some yield by adding shares to the vault
        uint256 yieldShares = 0.1 ether;
        uint256 sharesBalanceBefore = yieldVault.balanceOf(address(vbToken));
        deal(address(yieldVault), address(vbToken), sharesBalanceBefore + yieldShares);

        // Collect yield to mint vbTokens to yield recipient
        vm.prank(owner);
        vbTokenPart2.collectYield();

        uint256 yieldRecipientBalance = vbToken.balanceOf(yieldRecipient);
        assertGt(yieldRecipientBalance, 0);

        // Burn half of the yield recipient's balance
        uint256 burnAmount = yieldRecipientBalance / 2;

        vm.expectEmit();
        emit VaultBridgeToken.Burned(burnAmount);
        vm.prank(yieldRecipient);
        vbTokenPart2.burn(burnAmount);

        assertEq(vbToken.balanceOf(yieldRecipient), yieldRecipientBalance - burnAmount);
    }

    function test_donateAsYield_revert() public {
        // Cannot donate 0 assets
        vm.expectRevert(VaultBridgeToken.InvalidAssets.selector);
        vbTokenPart2.donateAsYield(0);
    }

    function test_donateAsYield() public {
        uint256 amount = 1 ether;

        // Get initial reserved assets
        uint256 initialReservedAssets = vbToken.reservedAssets();

        deal(underlyingToken, address(this), amount);
        IERC20(underlyingToken).forceApprove(address(vbToken), amount);

        vm.expectEmit();
        emit VaultBridgeToken.DonatedAsYield(address(this), amount);
        vbTokenPart2.donateAsYield(amount);

        assertEq(vbToken.reservedAssets(), initialReservedAssets + amount);
        assertEq(IERC20(underlyingToken).balanceOf(address(this)), 0);
    }

    function test_drainYieldVault_revert() public {
        uint256 shares = 1 ether;

        // Only admin can drain yield vault
        vm.expectRevert();
        vbTokenPart2.drainYieldVault(shares, false);

        vm.startPrank(owner);

        // Cannot drain 0 shares
        vm.expectRevert(VaultBridgeToken.InvalidShares.selector);
        vbTokenPart2.drainYieldVault(0, false);

        vm.stopPrank();
    }

    function test_drainYieldVault() public {
        uint256 depositAmount = 10 ether;

        // First, deposit some assets to generate yield vault shares
        _dealAndApprove(underlyingToken, sender, depositAmount, address(vbToken));
        vm.startPrank(sender);
        vbToken.deposit(depositAmount, sender);
        vm.stopPrank();

        uint256 initialReservedAssets = vbToken.reservedAssets();
        uint256 vaultSharesBalance = yieldVault.balanceOf(address(vbToken));

        // Only proceed if there are vault shares to drain
        vm.assume(vaultSharesBalance > 0);

        // Calculate shares to drain (half of the balance)
        uint256 sharesToDrain = vaultSharesBalance / 2;

        // Preview how many assets we expect to receive
        uint256 expectedAssets = yieldVault.previewRedeem(sharesToDrain);

        vm.expectEmit();
        emit VaultBridgeToken.YieldVaultDrained(sharesToDrain, expectedAssets);
        vm.prank(owner);
        vbTokenPart2.drainYieldVault(sharesToDrain, false);

        // Verify that reserved assets increased by the drained amount
        assertEq(vbToken.reservedAssets(), initialReservedAssets + expectedAssets);
        // Verify that yield vault shares decreased
        assertEq(yieldVault.balanceOf(address(vbToken)), vaultSharesBalance - sharesToDrain);
    }

    function test_setYieldVault_revert() public {
        address newVault = makeAddr("newVault");

        // Only admin can set yield vault
        vm.expectRevert();
        vbTokenPart2.setYieldVault(newVault);

        vm.startPrank(owner);

        // Cannot set yield vault to zero address
        vm.expectRevert(VaultBridgeToken.InvalidYieldVault.selector);
        vbTokenPart2.setYieldVault(address(0));

        vm.stopPrank();
    }

    function test_setYieldVault() public {
        // Create a new test vault
        MockVault newVault = new MockVault(underlyingToken);
        newVault.setMaxDeposit(MAX_DEPOSIT);
        newVault.setMaxWithdraw(MAX_WITHDRAW);

        // Get the current yield vault for comparison
        address oldVault = address(vbToken.yieldVault());
        assertEq(oldVault, address(yieldVault));

        // Expect the event to be emitted
        vm.expectEmit();
        emit VaultBridgeToken.YieldVaultSet(address(newVault));

        // Set the new yield vault as owner
        vm.prank(owner);
        vbTokenPart2.setYieldVault(address(newVault));

        assertEq(address(vbToken.yieldVault()), address(newVault));
        assertNotEq(address(vbToken.yieldVault()), oldVault);
        assertEq(IERC20(underlyingToken).allowance(address(vbToken), address(newVault)), type(uint256).max);
        assertEq(IERC20(underlyingToken).allowance(address(vbToken), oldVault), 0);
    }

    function test_setMinimumYieldVaultDeposit_revert() public {
        uint256 newDeposit = 5e12;

        // Only admin can set minimum yield vault deposit
        vm.expectRevert();
        vbTokenPart2.setMinimumYieldVaultDeposit(newDeposit);
    }

    function test_setMinimumYieldVaultDeposit() public {
        uint256 newDeposit = 5e12;

        // Get the current minimum yield vault deposit for comparison
        uint256 oldDeposit = vbToken.minimumYieldVaultDeposit();
        assertEq(oldDeposit, MINIMUM_YIELD_VAULT_DEPOSIT);

        vm.prank(owner);
        vbTokenPart2.setMinimumYieldVaultDeposit(newDeposit);

        assertEq(vbToken.minimumYieldVaultDeposit(), newDeposit);
        assertNotEq(vbToken.minimumYieldVaultDeposit(), oldDeposit);

        // Test setting to 0 (disabled)
        vm.prank(owner);
        vbTokenPart2.setMinimumYieldVaultDeposit(0);
        assertEq(vbToken.minimumYieldVaultDeposit(), 0);
    }

    function test_setYieldVaultMaximumSlippagePercentage_revert() public {
        // Test non-admin caller reverts
        vm.expectRevert();
        vbTokenPart2.setYieldVaultMaximumSlippagePercentage(5e17);

        // Test invalid percentage (> 1e18) reverts
        vm.startPrank(owner);
        vm.expectRevert(VaultBridgeToken.InvalidYieldVaultMaximumSlippagePercentage.selector);
        vbTokenPart2.setYieldVaultMaximumSlippagePercentage(1e18 + 1);
        vm.stopPrank();
    }

    function test_setYieldVaultMaximumSlippagePercentage() public {
        vm.startPrank(owner);

        // Test setting a valid percentage
        uint256 newSlippagePercentage = 5e17;

        vm.expectEmit();
        emit VaultBridgeToken.YieldVaultMaximumSlippagePercentageSet(newSlippagePercentage);
        vbTokenPart2.setYieldVaultMaximumSlippagePercentage(newSlippagePercentage);

        assertEq(vbToken.yieldVaultMaximumSlippagePercentage(), newSlippagePercentage);

        // Test setting to zero (disable slippage protection)
        vm.expectEmit();
        emit VaultBridgeToken.YieldVaultMaximumSlippagePercentageSet(0);
        vbTokenPart2.setYieldVaultMaximumSlippagePercentage(0);

        assertEq(vbToken.yieldVaultMaximumSlippagePercentage(), 0);

        // Test setting to maximum allowed (100%)
        vm.expectEmit();
        emit VaultBridgeToken.YieldVaultMaximumSlippagePercentageSet(1e18);
        vbTokenPart2.setYieldVaultMaximumSlippagePercentage(1e18);

        assertEq(vbToken.yieldVaultMaximumSlippagePercentage(), 1e18);

        vm.stopPrank();
    }

    function test_fallback_revert() public {
        // Test that fallback function reverts with UnknownFunction error
        bytes4 invalidSelector = bytes4(keccak256("nonExistentFunction()"));

        vm.expectRevert(abi.encodeWithSelector(VaultBridgeToken.UnknownFunction.selector, invalidSelector));
        (address(vbTokenPart2).call(abi.encodePacked(invalidSelector)));

        // Test the fallback by directly calling the implementation contract
        vm.expectRevert(abi.encodeWithSelector(VaultBridgeToken.UnknownFunction.selector, invalidSelector));
        (address(vbTokenPart2Implementation).call(abi.encodePacked(invalidSelector)));
    }

    function test_pause_unpause() public {
        vm.expectRevert();
        vbTokenPart2.pause();

        vm.expectRevert();
        vbTokenPart2.unpause();

        vm.startPrank(owner);
        vm.expectEmit();
        emit PausableUpgradeable.Paused(owner);
        vbTokenPart2.pause();

        vm.expectEmit();
        emit PausableUpgradeable.Unpaused(owner);
        vbTokenPart2.unpause();
        vm.stopPrank();
    }

    function test_approve() public {
        assertTrue(vbToken.approve(address(0xBEEF), 1e18));

        assertEq(vbToken.allowance(address(this), address(0xBEEF)), 1e18);
    }

    // ERC20 tests
    function test_transfer() public virtual {
        deal(address(vbToken), address(this), 1e18);

        assertTrue(vbToken.transfer(address(0xBEEF), 1e18));

        assertEq(vbToken.balanceOf(address(this)), 0);
        assertEq(vbToken.balanceOf(address(0xBEEF)), 1e18);
    }

    function test_transferFrom() public virtual {
        address from = address(0xABCD);
        deal(address(vbToken), from, 1e18);

        vm.prank(from);
        vbToken.forceApprove(address(this), 1e18);

        assertTrue(vbToken.transferFrom(from, address(0xBEEF), 1e18));

        assertEq(vbToken.allowance(from, address(this)), 0);

        assertEq(vbToken.balanceOf(from), 0);
        assertEq(vbToken.balanceOf(address(0xBEEF)), 1e18);
    }

    function test_infiniteApproveTransferFrom() public virtual {
        address from = address(0xABCD);
        deal(address(vbToken), from, 1e18);

        vm.prank(from);
        vbToken.forceApprove(address(this), type(uint256).max);

        assertTrue(vbToken.transferFrom(from, address(0xBEEF), 1e18));

        assertEq(vbToken.allowance(from, address(this)), type(uint256).max);

        assertEq(vbToken.balanceOf(from), 0);
        assertEq(vbToken.balanceOf(address(0xBEEF)), 1e18);
    }

    function test_failTransferInsufficientBalance() public {
        deal(address(vbToken), address(this), 0.9e18);
        vm.expectRevert();
        vbToken.transfer(address(0xBEEF), 1e18);
    }

    function test_failTransferFromInsufficientAllowance() public virtual {
        address from = address(0xABCD);

        deal(address(vbToken), address(this), 1e18);

        vm.prank(from);
        vbToken.forceApprove(address(this), 0.9e18);

        vm.expectRevert();
        vbToken.transferFrom(from, address(0xBEEF), 1e18);
    }

    function test_failTransferFromInsufficientBalance() public virtual {
        address from = address(0xABCD);

        deal(address(vbToken), address(this), 0.9e18);

        vm.prank(from);
        vbToken.forceApprove(address(this), 1e18);

        vm.expectRevert();
        vbToken.transferFrom(from, address(0xBEEF), 1e18);
    }

    function test_permit() public virtual {
        (uint8 v, bytes32 r, bytes32 s) = vm.sign(
            senderPrivateKey,
            keccak256(
                abi.encodePacked(
                    "\x19\x01",
                    vbToken.DOMAIN_SEPARATOR(),
                    keccak256(
                        abi.encode(PERMIT_TYPEHASH, sender, address(0xCAFE), 1e18, vm.getNonce(sender), block.timestamp)
                    )
                )
            )
        );

        vm.prank(sender);
        vbToken.permit(sender, address(0xCAFE), 1e18, block.timestamp, v, r, s);

        assertEq(vbToken.allowance(sender, address(0xCAFE)), 1e18);
        assertEq(vbToken.nonces(sender), 1);
    }
}
