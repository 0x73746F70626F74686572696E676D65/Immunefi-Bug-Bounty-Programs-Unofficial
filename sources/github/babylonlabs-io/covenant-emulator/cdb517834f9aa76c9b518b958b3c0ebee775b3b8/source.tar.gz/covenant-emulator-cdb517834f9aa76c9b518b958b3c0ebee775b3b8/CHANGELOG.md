<!--
Guiding Principles:

Changelogs are for humans, not machines.
There should be an entry for every single version.
The same types of changes should be grouped.
Versions and sections should be linkable.
The latest version comes first.
The release date of each version is displayed.
Mention whether you follow Semantic Versioning.

Usage:

Change log entries are to be added to the Unreleased section under the
appropriate stanza (see below). Each entry should have following format:

* [#PullRequestNumber](PullRequestLink) message

Types of changes (Stanzas):

"Features" for new features.
"Improvements" for changes in existing functionality.
"Deprecated" for soon-to-be removed features.
"Bug Fixes" for any bug fixes.
"Client Breaking" for breaking CLI commands and REST routes used by end-users.
"API Breaking" for breaking exported APIs used by developers building on SDK.
"State Machine Breaking" for any changes that result in a different AppState
given same genesisState and txList.
Ref: https://keepachangelog.com/en/1.0.0/
-->

# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/)

## Unreleased

### Improvements

* [#203](https://github.com/babylonlabs-io/covenant-emulator/pull/203) chore(deps): bump github.com/opencontainers/runc to v1.3.6 (go_modules group)
* [#202](https://github.com/babylonlabs-io/covenant-emulator/pull/202) chore(deps): bump go-chi/chi/v5 to v5.2.4 and shamaton/msgpack/v2 to v2.4.1 (go_modules group across / and /tools)
* [#196](https://github.com/babylonlabs-io/covenant-emulator/pull/196) chore(deps): bump go-getter to v1.8.6 (aws-sdk-go v1 to v2 migration)
* [#195](https://github.com/babylonlabs-io/covenant-emulator/pull/195) chore(deps): bump edwards25519 to v1.1.1, cometbft to v0.38.21, and go-ethereum to v1.17.0
* [#194](https://github.com/babylonlabs-io/covenant-emulator/pull/194) chore(deps): bump docker/cli to v29.2.0, go-jose/v4 to v4.1.4 (security fix), and otel/sdk to v1.40.0
* [#190](https://github.com/babylonlabs-io/covenant-emulator/pull/190) chore: enable Trivy scanning, bump grpc to v1.79.3, fix Dockerfile hadolint warnings
* [#186](https://github.com/babylonlabs-io/covenant-emulator/pull/186) chore(deps): bump go_modules group
  (edwards25519, cometbft, go-ethereum) with Docker SDK pinned below v29 for dockertest compatibility
* [#171](https://github.com/babylonlabs-io/covenant-emulator/pull/171) chore: bump dependencies babylon v4.2.0

## v0.16.1

### Improvements

* [#184](https://github.com/babylonlabs-io/covenant-emulator/pull/184) chore: bump reusable workflow to v0.16.1
* [#165](https://github.com/babylonlabs-io/covenant-emulator/pull/165) chore: add missing log detail of stk tx hex

### Bug Fixes

* [#180](https://github.com/babylonlabs-io/covenant-emulator/pull/180) fix: avoid err wrap in `ValidateStakeExpansion`
to not drop entire query if covenant is not in the committee of stake extension

## v0.16.0

### Improvements

* [#160](https://github.com/babylonlabs-io/covenant-emulator/pull/160) chore: bump babylon to `v4.0.0-rc.3`
* [#161](https://github.com/babylonlabs-io/covenant-emulator/pull/161) chore: bump babylon to `v4.0.0`

### Bug Fixes

* [#156](https://github.com/babylonlabs-io/covenant-emulator/pull/156) fix: overflow in parse hardened

## v0.16.0-rc.2

### Improvements

* [#134](https://github.com/babylonlabs-io/covenant-emulator/pull/134) chore: add golangci lint rules
* [#141](https://github.com/babylonlabs-io/covenant-emulator/pull/141) chore: bumps go1.25
* [#112](https://github.com/babylonlabs-io/covenant-emulator/pull/112) feat: resend batch msgs if some failed
* [#151](https://github.com/babylonlabs-io/covenant-emulator/pull/151) chore: bump to v4, rm phase 3 signingcontext

## v0.16.0-rc.1

### Improvements

* [#125](https://github.com/babylonlabs-io/covenant-emulator/pull/125) Update config defaults for gas adjustment and cov batch sigs.
* [#127](https://github.com/babylonlabs-io/covenant-emulator/pull/127) Add Stake Expansion support
* [#128](https://github.com/babylonlabs-io/covenant-emulator/pull/128) Removed check where the covenant needs to have signed the
previous staking transaction to sign the stake expansion tx.
* [#129](https://github.com/babylonlabs-io/covenant-emulator/pull/129) bump Babylon to
v3.0.0-rc.0

## v0.15.1

### Improvements

* [#122](https://github.com/babylonlabs-io/covenant-emulator/pull/122) Bump babylon node to v1.0.0

## v0.15.0

### Improvements

* [#120](https://github.com/babylonlabs-io/covenant-emulator/pull/120) Bump babylon to rc-9.
* [#119](https://github.com/babylonlabs-io/covenant-emulator/pull/119) Make passphrase for Unlock optional.
* [#116](https://github.com/babylonlabs-io/covenant-emulator/pull/116) Add health check to prometheus server.
* [#117](https://github.com/babylonlabs-io/covenant-emulator/pull/117) Add health check on startup, increase gas adjustment and update docs.

## v0.14.0

* [#114](https://github.com/babylonlabs-io/covenant-emulator/pull/114) bump babylon to v1.0.0-rc.8
* [#109](https://github.com/babylonlabs-io/covenant-emulator/pull/109) HMAC authentication between signer and emulator.

## v0.13.0

### Improvements

* [#110](https://github.com/babylonlabs-io/covenant-emulator/pull/110) bump babylon to v1.0.0-rc.7
* [#113](https://github.com/babylonlabs-io/covenant-emulator/pull/113) chore: enforcing keyring-backend test

### Bug Fixes

* [#107](https://github.com/babylonlabs-io/covenant-emulator/pull/107) crypto: replace dcrd fork with btcd fork
with crypto fix
* [#106](https://github.com/babylonlabs-io/covenant-emulator/pull/106) crypto: use dcrd fork with crypto fix
* [#108](https://github.com/babylonlabs-io/covenant-emulator/pull/108) chore: increase max content length

## v0.12.0

### Improvements

* [#83](https://github.com/babylonlabs-io/covenant-emulator/pull/83) covenant-signer: remove go.mod
* [#95](https://github.com/babylonlabs-io/covenant-emulator/pull/95) removed local signer option
as the covenant emulator should only connect to a remote signer
* [#96](https://github.com/babylonlabs-io/covenant-emulator/pull/96) add pagination to `queryDelegationsWithStatus`
* [#99](https://github.com/babylonlabs-io/covenant-emulator/pull/99) add more metrics
covenant-signer
* [#100](https://github.com/babylonlabs-io/covenant-emulator/pull/100) bump babylon to v1.0.0-rc.4

## v0.11.3

### Bug fixes

* [#91](https://github.com/babylonlabs-io/covenant-emulator/pull/91) Add verification
if the covenant public key was present in the params of the versioned BTC delegation

## v0.11.2

### Bug fixes

* [#84](https://github.com/babylonlabs-io/covenant-emulator/pull/84) Fix bug with
deduplication of already signed delegations

## v0.11.1

### Bug fixes

* [#71](https://github.com/babylonlabs-io/covenant-emulator/pull/71) Fix delegation
response to delegation conversion

## v0.11.0

### Improvements

* [#68](https://github.com/babylonlabs-io/covenant-emulator/pull/68) Bump babylon to v1.0.0-rc.1
* [#63](https://github.com/babylonlabs-io/covenant-emulator/pull/63) Add babylon
address to keys command output and fix casing in dockerfile
* [#67](https://github.com/babylonlabs-io/covenant-emulator/pull/67) Add keys cmd to covenant-signer

## v0.10.0

### Improvements

* [#43](https://github.com/babylonlabs-io/covenant-emulator/pull/43) Test importing
private key to the cosmos keyring
* [#44](https://github.com/babylonlabs-io/covenant-emulator/pull/44) Command
to derive child private keys from the master key
* [#45](https://github.com/babylonlabs-io/covenant-emulator/pull/45) Add e2e test
with encrypted file keyring usage
* [#47](https://github.com/babylonlabs-io/covenant-emulator/pull/47) Add unlocking keyring
through API
* [#48](https://github.com/babylonlabs-io/covenant-emulator/pull/48) Add covenant
signer version that requires unlocking
* [#49](https://github.com/babylonlabs-io/covenant-emulator/pull/49) Add show-key command
* [#52](https://github.com/babylonlabs-io/covenant-emulator/pull/52) Fix CosmosKeyStoreConfig
* [#57](https://github.com/babylonlabs-io/covenant-emulator/pull/57) Bump babylon to v0.18.0

## v0.9.0

* [#33](https://github.com/babylonlabs-io/covenant-emulator/pull/33) Add remote
signer sub module
* [#31](https://github.com/babylonlabs-io/covenant-emulator/pull/31/) Bump docker workflow
version, fix some Dockerfile issue
* [#36](https://github.com/babylonlabs-io/covenant-emulator/pull/36) Add public key
endpoint to the remote signer
* [#38](https://github.com/babylonlabs-io/covenant-emulator/pull/38) Bump Babylon version
to v0.17.1
* [#37](https://github.com/babylonlabs-io/covenant-emulator/pull/37) Add remote signer
to the covenant emulator
* [#40](https://github.com/babylonlabs-io/covenant-emulator/pull/40) Fix min unbonding time
validation

## v0.8.0

### Bug fixes

* [#30](https://github.com/babylonlabs-io/covenant-emulator/pull/30) Ignore duplicated sig error

### Improvements

* [#22](https://github.com/babylonlabs-io/covenant-emulator/pull/22) Go releaser setup
  and move changelog reminder out
* [#32](https://github.com/babylonlabs-io/covenant-emulator/pull/32) Upgrade Babylon
  to v0.16.0

## v0.7.0

### Improvements

* [#25](https://github.com/babylonlabs-io/covenant-emulator/pull/25) Bump Babylon to v0.15.0

## v0.6.0

### Improvements

* [#24](https://github.com/babylonlabs-io/covenant-emulator/pull/24) Bump Babylon to v0.14.0

## v0.5.0

### Bug fixes

* [#23](https://github.com/babylonlabs-io/covenant-emulator/pull/23) Fix pre-approval flow

### Improvements

* [#20](https://github.com/babylonlabs-io/covenant-emulator/pull/20) Add signing behind
interface.
