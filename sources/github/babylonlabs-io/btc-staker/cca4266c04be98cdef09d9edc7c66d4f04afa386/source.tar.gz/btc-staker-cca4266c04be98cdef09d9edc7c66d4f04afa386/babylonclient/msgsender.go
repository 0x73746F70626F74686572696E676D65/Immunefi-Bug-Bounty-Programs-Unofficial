package babylonclient

import (
	"context"
	"errors"
	"fmt"
	"sync"

	bct "github.com/babylonlabs-io/babylon/v4/client/babylonclient"
	"golang.org/x/sync/semaphore"

	"github.com/babylonlabs-io/btc-staker/utils"
	"github.com/btcsuite/btcd/chaincfg/chainhash"
	"github.com/sirupsen/logrus"
)

var (
	// ErrBabylonBtcLightClientNotReady indicates the BTC LC has not yet processed the inclusion block.
	ErrBabylonBtcLightClientNotReady = errors.New("babylon btc light client is not ready to receive delegation")
)

type sendDelegationRequest struct {
	utils.Request[*bct.RelayerTxResponse]
	dg                          *DelegationData
	requiredInclusionBlockDepth uint32
}

func newSendDelegationRequest(
	dg *DelegationData,
	requiredInclusionBlockDepth uint32,
) sendDelegationRequest {
	return sendDelegationRequest{
		Request:                     utils.NewRequest[*bct.RelayerTxResponse](),
		dg:                          dg,
		requiredInclusionBlockDepth: requiredInclusionBlockDepth,
	}
}

// BabylonMsgSender serializes delegation requests heading to Babylon and enforces readiness checks.
// It makes sure:
// - that babylon is ready for either delgetion or undelegation
// - only one messegae is sent to babylon at a time
type BabylonMsgSender struct {
	startOnce sync.Once
	stopOnce  sync.Once
	wg        sync.WaitGroup
	quit      chan struct{}

	cl                        BabylonClient
	logger                    *logrus.Logger
	sendDelegationRequestChan chan *sendDelegationRequest
	s                         *semaphore.Weighted
}

// NewBabylonMsgSender creates a sender with the given concurrency bounds.
func NewBabylonMsgSender(
	cl BabylonClient,
	logger *logrus.Logger,
	maxConcurrentTransactions uint32,
) *BabylonMsgSender {
	s := semaphore.NewWeighted(int64(maxConcurrentTransactions))
	return &BabylonMsgSender{
		quit:                      make(chan struct{}),
		cl:                        cl,
		logger:                    logger,
		sendDelegationRequestChan: make(chan *sendDelegationRequest),
		s:                         s,
	}
}

// Start launches the background goroutine that drains delegation requests.
func (m *BabylonMsgSender) Start() {
	m.startOnce.Do(func() {
		m.wg.Add(1)
		go m.handleSentToBabylon()
	})
}

// Stop terminates the background goroutine and waits for it to finish.
func (m *BabylonMsgSender) Stop() {
	m.stopOnce.Do(func() {
		close(m.quit)
		m.wg.Wait()
	})
}

// isBabylonBtcLcReady checks if Babylon BTC light client is ready to receive delegation
func (m *BabylonMsgSender) isBabylonBtcLcReady(
	requiredInclusionBlockDepth uint32,
	req *DelegationData,
) error {
	// no need to consult Babylon if we send delegation without inclusion proof
	if req.StakingTransactionInclusionInfo == nil {
		return nil
	}

	depth, err := m.cl.QueryHeaderDepth(req.StakingTransactionInclusionInfo.StakingTransactionInclusionBlockHash)

	if err != nil {
		// If header is not known to babylon, or it is on LCFork, then most probably
		// lc is not up to date. We should retry sending delegation after some time.
		if errors.Is(err, ErrHeaderNotKnownToBabylon) || errors.Is(err, ErrHeaderOnBabylonLCFork) {
			return fmt.Errorf("btc light client error %s: %w", err.Error(), ErrBabylonBtcLightClientNotReady)
		}

		// got some unknown error, return it to the caller
		return fmt.Errorf("error while getting delegation data: %w", err)
	}

	if depth < requiredInclusionBlockDepth {
		return fmt.Errorf("btc lc not ready, required depth: %d, current depth: %d: %w", requiredInclusionBlockDepth, depth, ErrBabylonBtcLightClientNotReady)
	}

	return nil
}

func (m *BabylonMsgSender) sendDelegationAsync(stakingTxHash *chainhash.Hash, req *sendDelegationRequest) {
	// do not check the error, as only way for it to return err is if provided context would be cancelled
	// which can't happen here
	_ = m.s.Acquire(context.Background(), 1)
	m.wg.Add(1)
	go func() {
		defer m.s.Release(1)
		defer m.wg.Done()
		// TODO pass context to delegate
		var (
			txResp  *bct.RelayerTxResponse
			err     error
			useCase = "regular delegation"
		)
		// Route to appropriate bbn client method based on whether this is a stake expansion
		// or a regular delegation.
		if req.dg.StakeExpansion != nil {
			txResp, err = m.cl.ExpandDelegation(req.dg)
			useCase = "stake expansion delegation"
		} else {
			txResp, err = m.cl.Delegate(req.dg)
		}

		if err != nil {
			if errors.Is(err, ErrInvalidBabylonExecution) {
				m.logger.WithFields(logrus.Fields{
					"btcTxHash":          stakingTxHash,
					"babylonTxHash":      txResp.TxHash,
					"babylonBlockHeight": txResp.Height,
					"babylonErrorCode":   txResp.Code,
				}).Errorf("Invalid delegation data sent to babylon. Case: %s", useCase)
			}

			m.logger.WithFields(logrus.Fields{
				"btcTxHash": stakingTxHash,
				"err":       err,
			}).Errorf("Error while sending delegation data to babylon. Case: %s", useCase)

			req.ErrorChan() <- fmt.Errorf("failed to send delegation for tx with hash: %s; Case: %s; Error: %w", stakingTxHash.String(), useCase, err)
		}
		req.ResultChan() <- txResp
	}()
}

func (m *BabylonMsgSender) handleSentToBabylon() {
	defer m.wg.Done()
	for {
		select {
		case req := <-m.sendDelegationRequestChan:
			stakingTxHash := req.dg.StakingTransaction.TxHash()

			err := m.isBabylonBtcLcReady(
				req.requiredInclusionBlockDepth,
				req.dg,
			)

			if err != nil {
				m.logger.WithFields(logrus.Fields{
					"btcTxHash": stakingTxHash,
					"err":       err,
				}).Error("Cannot send delegation request to babylon")

				req.ErrorChan() <- err
				continue
			}

			m.sendDelegationAsync(&stakingTxHash, req)

		case <-m.quit:
			return
		}
	}
}

// SendDelegation enqueues a delegation request and waits for Babylon to respond.
func (m *BabylonMsgSender) SendDelegation(
	dg *DelegationData,
	requiredInclusionBlockDepth uint32,
) (*bct.RelayerTxResponse, error) {
	req := newSendDelegationRequest(dg, requiredInclusionBlockDepth)

	return utils.SendRequestAndWaitForResponseOrQuit[*bct.RelayerTxResponse, *sendDelegationRequest](
		&req,
		m.sendDelegationRequestChan,
		m.quit,
	)
}
