package keeper

import (
	"context"
	"testing"
	"time"

	"cosmossdk.io/collections"
	"cosmossdk.io/core/header"
	corestore "cosmossdk.io/core/store"
	"cosmossdk.io/log"
	"cosmossdk.io/store"
	storemetrics "cosmossdk.io/store/metrics"
	storetypes "cosmossdk.io/store/types"
	tstore "github.com/babylonlabs-io/babylon/v4/testutil/store"
	costakingkeeper "github.com/babylonlabs-io/babylon/v4/x/costaking/keeper"
	costktypes "github.com/babylonlabs-io/babylon/v4/x/costaking/types"
	cmtproto "github.com/cometbft/cometbft/proto/tendermint/types"
	dbm "github.com/cosmos/cosmos-db"
	"github.com/cosmos/cosmos-sdk/codec"
	codectypes "github.com/cosmos/cosmos-sdk/codec/types"
	"github.com/cosmos/cosmos-sdk/runtime"
	sdk "github.com/cosmos/cosmos-sdk/types"
	authtypes "github.com/cosmos/cosmos-sdk/x/auth/types"
	"github.com/golang/mock/gomock"
	"github.com/stretchr/testify/require"

	appparams "github.com/babylonlabs-io/babylon/v4/app/params"
	"github.com/babylonlabs-io/babylon/v4/x/costaking/keeper"
	"github.com/babylonlabs-io/babylon/v4/x/costaking/types"
)

func CostakingKeeperWithStore(
	t testing.TB,
	db dbm.DB,
	stateStore store.CommitMultiStore,
	storeKey *storetypes.KVStoreKey,
	bankK types.BankKeeper,
	accK types.AccountKeeper,
	ictvK types.IncentiveKeeper,
	stkK types.StakingKeeper,
	distK types.DistributionKeeper,
) (*keeper.Keeper, sdk.Context) {
	if storeKey == nil {
		storeKey = storetypes.NewKVStoreKey(types.StoreKey)
	}

	stateStore.MountStoreWithDB(storeKey, storetypes.StoreTypeIAVL, db)
	require.NoError(t, stateStore.LoadLatestVersion())

	registry := codectypes.NewInterfaceRegistry()
	cdc := codec.NewProtoCodec(registry)

	k := keeper.NewKeeper(
		cdc,
		runtime.NewKVStoreService(storeKey),
		bankK,
		accK,
		ictvK,
		stkK,
		distK,
		appparams.AccGov.String(),
		authtypes.FeeCollectorName,
	)

	ctx := sdk.NewContext(
		stateStore,
		cmtproto.Header{
			Time: time.Now().UTC(),
		},
		false,
		log.NewNopLogger(),
	)
	ctx = ctx.WithHeaderInfo(header.Info{})

	return &k, ctx
}

func CostakingKeeperWithMocks(t testing.TB, ctrl *gomock.Controller) (*keeper.Keeper, *gomock.Controller, sdk.Context) {
	if ctrl == nil {
		ctrl = gomock.NewController(t)
	}

	accK := types.NewMockAccountKeeper(ctrl)
	accK.EXPECT().GetModuleAddress(gomock.Any()).Return(authtypes.NewModuleAddress(types.ModuleName)).AnyTimes()

	k, ctx := CostakingKeeperWithStoreKey(t, nil, types.NewMockBankKeeper(ctrl), accK, types.NewMockIncentiveKeeper(ctrl), types.NewMockStakingKeeper(ctrl), types.NewMockDistributionKeeper(ctrl))
	return k, ctrl, ctx
}

func CostakingKeeperWithStoreKey(
	t testing.TB,
	storeKey *storetypes.KVStoreKey,
	bankK types.BankKeeper,
	accK types.AccountKeeper,
	ictvK types.IncentiveKeeper,
	stkK types.StakingKeeper,
	distK types.DistributionKeeper,
) (*keeper.Keeper, sdk.Context) {
	db := dbm.NewMemDB()
	stateStore := store.NewCommitMultiStore(db, log.NewTestLogger(t), storemetrics.NewNoOpMetrics())

	k, ctx := CostakingKeeperWithStore(t, db, stateStore, storeKey, bankK, accK, ictvK, stkK, distK)

	// Initialize params
	if err := k.SetParams(ctx, types.DefaultParams()); err != nil {
		panic(err)
	}

	return k, ctx
}

func NewKeeperWithMockIncentiveKeeper(t *testing.T, mockIctvK types.IncentiveKeeper) (*costakingkeeper.Keeper, sdk.Context) {
	encConf := appparams.DefaultEncodingConfig()
	ctx, kvStore := tstore.NewStoreWithCtx(t, types.ModuleName)

	ctrl := gomock.NewController(t)
	t.Cleanup(ctrl.Finish)

	mockBankK := types.NewMockBankKeeper(ctrl)
	mockAccK := types.NewMockAccountKeeper(ctrl)
	stkK := types.NewMockStakingKeeper(ctrl)
	dstrK := types.NewMockDistributionKeeper(ctrl)

	mockAccK.EXPECT().GetModuleAddress(gomock.Any()).Return(authtypes.NewModuleAddress(types.ModuleName)).AnyTimes()

	k := costakingkeeper.NewKeeper(
		encConf.Codec,
		kvStore,
		mockBankK,
		mockAccK,
		mockIctvK,
		stkK,
		dstrK,
		appparams.AccGov.String(),
		appparams.AccFeeCollector.String(),
	)

	err := k.SetParams(ctx, types.DefaultParams())
	require.NoError(t, err)
	return &k, ctx
}

func RwdTrackerCollection(storeService corestore.KVStoreService, cdc codec.BinaryCodec) collections.Map[[]byte, costktypes.CostakerRewardsTracker] {
	sb := collections.NewSchemaBuilder(storeService)
	rwdTrackers := collections.NewMap(
		sb,
		costktypes.CostakerRewardsTrackerKeyPrefix,
		"costaker_rewards_tracker",
		collections.BytesKey,
		codec.CollValue[costktypes.CostakerRewardsTracker](cdc),
	)
	return rwdTrackers
}

func CreateCostakerRewardsTracker(t *testing.T, ctx context.Context, cdc codec.BinaryCodec, storeService corestore.KVStoreService, stakerAddr sdk.AccAddress, tracker costktypes.CostakerRewardsTracker) {
	rwdTrackers := RwdTrackerCollection(storeService, cdc)
	err := rwdTrackers.Set(ctx, []byte(stakerAddr), tracker)
	require.NoError(t, err)
}
