package testnet

// The BTC staking parameters should be compatible with the global-parameters
// used in the BTC staking caps on bbn-test-4
// ref: https://github.com/babylonchain/networks/blob/main/bbn-test-4/parameters/global-params.json
// allow_list_expiration_height set to close to 72 hours of blocks 25920 + ~200 blocks of TGE
// producing each babylon block in 10 seconds = 26120.
// In global params version 2,3,4 we inserted the cap_height: 201385, at the moment we don't
// have a good way of specifyng the cap to avoid overflow to join as valid BTC staking,
// so this will be filtered out by the allow list of transactions
// ./allowed_staking_tx_hashes.go
const BtcStakingParamsStr = `[
  {
    "covenant_pks": [
      "49766ccd9e3cd94343e2040474a77fb37cdfd30530d05f9f1e96ae1e2102c86e",
      "76d1ae01f8fb6bf30108731c884cddcf57ef6eef2d9d9559e130894e0e40c62c",
      "17921cf156ccb4e73d428f996ed11b245313e37e27c978ac4d2cc21eca4672e4",
      "113c3a32a9d320b72190a04a020a0db3976ef36972673258e9a38a364f3dc3b0",
      "79a71ffd71c503ef2e2f91bccfc8fcda7946f4653cef0d9f3dde20795ef3b9f0",
      "3bb93dfc8b61887d771f3630e9a63e97cbafcfcc78556a474df83a31a0ef899c",
      "d21faf78c6751a0d38e6bd8028b907ff07e9a869a43fc837d6b3f8dff6119a36",
      "40afaf47c4ffa56de86410d8e47baa2bb6f04b604f4ea24323737ddc3fe092df",
      "f5199efae3f28bb82476163a7e458c7ad445d9bffb0682d10d3bdb2cb41f8e8e"
    ],
    "covenant_quorum": 6,
    "min_staking_value_sat": 50000,
    "max_staking_value_sat": 5000000,
    "min_staking_time_blocks": 64000,
    "max_staking_time_blocks": 64000,
    "slashing_pk_script": "dqkUAQEBAQEBAQEBAQEBAQEBAQEBAQGIrA==",
    "min_slashing_tx_fee_sat": 1000,
    "slashing_rate": "0.100000000000000000",
    "unbonding_time_blocks": 1008,
    "unbonding_fee_sat": 2000,
    "min_commission_rate": "0.03",
    "delegation_creation_base_gas_fee": 1000,
    "allow_list_expiration_height": 26120,
    "btc_activation_height": 197535
  },
  {
    "covenant_pks": [
      "09585ab55a971a231c945790a0a81df754e5a07263a5c20829931cc24683bbb7",
      "76d1ae01f8fb6bf30108731c884cddcf57ef6eef2d9d9559e130894e0e40c62c",
      "17921cf156ccb4e73d428f996ed11b245313e37e27c978ac4d2cc21eca4672e4",
      "113c3a32a9d320b72190a04a020a0db3976ef36972673258e9a38a364f3dc3b0",
      "79a71ffd71c503ef2e2f91bccfc8fcda7946f4653cef0d9f3dde20795ef3b9f0",
      "3bb93dfc8b61887d771f3630e9a63e97cbafcfcc78556a474df83a31a0ef899c",
      "d21faf78c6751a0d38e6bd8028b907ff07e9a869a43fc837d6b3f8dff6119a36",
      "40afaf47c4ffa56de86410d8e47baa2bb6f04b604f4ea24323737ddc3fe092df",
      "f5199efae3f28bb82476163a7e458c7ad445d9bffb0682d10d3bdb2cb41f8e8e"
    ],
    "covenant_quorum": 6,
    "min_staking_value_sat": 50000,
    "max_staking_value_sat": 5000000,
    "min_staking_time_blocks": 64000,
    "max_staking_time_blocks": 64000,
    "slashing_pk_script": "dqkUAQEBAQEBAQEBAQEBAQEBAQEBAQGIrA==",
    "min_slashing_tx_fee_sat": 1000,
    "slashing_rate": "0.100000000000000000",
    "unbonding_time_blocks": 1008,
    "unbonding_fee_sat": 10000,
    "min_commission_rate": "0.03",
    "delegation_creation_base_gas_fee": 1000,
    "allow_list_expiration_height": 26120,
    "btc_activation_height": 198665
  },
  {
    "covenant_pks": [
      "fa9d882d45f4060bdb8042183828cd87544f1ea997380e586cab77d5fd698737",
      "0aee0509b16db71c999238a4827db945526859b13c95487ab46725357c9a9f25",
      "17921cf156ccb4e73d428f996ed11b245313e37e27c978ac4d2cc21eca4672e4",
      "113c3a32a9d320b72190a04a020a0db3976ef36972673258e9a38a364f3dc3b0",
      "79a71ffd71c503ef2e2f91bccfc8fcda7946f4653cef0d9f3dde20795ef3b9f0",
      "3bb93dfc8b61887d771f3630e9a63e97cbafcfcc78556a474df83a31a0ef899c",
      "d21faf78c6751a0d38e6bd8028b907ff07e9a869a43fc837d6b3f8dff6119a36",
      "40afaf47c4ffa56de86410d8e47baa2bb6f04b604f4ea24323737ddc3fe092df",
      "f5199efae3f28bb82476163a7e458c7ad445d9bffb0682d10d3bdb2cb41f8e8e"
    ],
    "covenant_quorum": 6,
    "min_staking_value_sat": 50000,
    "max_staking_value_sat": 5000000,
    "min_staking_time_blocks": 64000,
    "max_staking_time_blocks": 64000,
    "slashing_pk_script": "dqkUAQEBAQEBAQEBAQEBAQEBAQEBAQGIrA==",
    "min_slashing_tx_fee_sat": 1000,
    "slashing_rate": "0.100000000000000000",
    "unbonding_time_blocks": 1008,
    "unbonding_fee_sat": 10000,
    "min_commission_rate": "0.03",
    "delegation_creation_base_gas_fee": 1000,
    "allow_list_expiration_height": 26120,
    "btc_activation_height": 200665
  },
  {
    "covenant_pks": [
      "fa9d882d45f4060bdb8042183828cd87544f1ea997380e586cab77d5fd698737",
      "0aee0509b16db71c999238a4827db945526859b13c95487ab46725357c9a9f25",
      "17921cf156ccb4e73d428f996ed11b245313e37e27c978ac4d2cc21eca4672e4",
      "113c3a32a9d320b72190a04a020a0db3976ef36972673258e9a38a364f3dc3b0",
      "79a71ffd71c503ef2e2f91bccfc8fcda7946f4653cef0d9f3dde20795ef3b9f0",
      "3bb93dfc8b61887d771f3630e9a63e97cbafcfcc78556a474df83a31a0ef899c",
      "d21faf78c6751a0d38e6bd8028b907ff07e9a869a43fc837d6b3f8dff6119a36",
      "40afaf47c4ffa56de86410d8e47baa2bb6f04b604f4ea24323737ddc3fe092df",
      "f5199efae3f28bb82476163a7e458c7ad445d9bffb0682d10d3bdb2cb41f8e8e"
    ],
    "covenant_quorum": 6,
    "min_staking_value_sat": 50000,
    "max_staking_value_sat": 50000000,
    "min_staking_time_blocks": 64000,
    "max_staking_time_blocks": 64000,
    "slashing_pk_script": "dqkUAQEBAQEBAQEBAQEBAQEBAQEBAQGIrA==",
    "min_slashing_tx_fee_sat": 1000,
    "slashing_rate": "0.100000000000000000",
    "unbonding_time_blocks": 1008,
    "unbonding_fee_sat": 5000,
    "min_commission_rate": "0.03",
    "delegation_creation_base_gas_fee": 1000,
    "allow_list_expiration_height": 26120,
    "btc_activation_height": 215968
  },
  {
    "covenant_pks": [
      "fa9d882d45f4060bdb8042183828cd87544f1ea997380e586cab77d5fd698737",
      "0aee0509b16db71c999238a4827db945526859b13c95487ab46725357c9a9f25",
      "17921cf156ccb4e73d428f996ed11b245313e37e27c978ac4d2cc21eca4672e4",
      "113c3a32a9d320b72190a04a020a0db3976ef36972673258e9a38a364f3dc3b0",
      "79a71ffd71c503ef2e2f91bccfc8fcda7946f4653cef0d9f3dde20795ef3b9f0",
      "3bb93dfc8b61887d771f3630e9a63e97cbafcfcc78556a474df83a31a0ef899c",
      "d21faf78c6751a0d38e6bd8028b907ff07e9a869a43fc837d6b3f8dff6119a36",
      "40afaf47c4ffa56de86410d8e47baa2bb6f04b604f4ea24323737ddc3fe092df",
      "f5199efae3f28bb82476163a7e458c7ad445d9bffb0682d10d3bdb2cb41f8e8e"
    ],
    "covenant_quorum": 6,
    "min_staking_value_sat": 50000,
    "max_staking_value_sat": 50000000,
    "min_staking_time_blocks": 64000,
    "max_staking_time_blocks": 64000,
    "slashing_pk_script": "dqkUAQEBAQEBAQEBAQEBAQEBAQEBAQGIrA==",
    "min_slashing_tx_fee_sat": 1000,
    "slashing_rate": "0.100000000000000000",
    "unbonding_time_blocks": 1008,
    "unbonding_fee_sat": 5000,
    "min_commission_rate": "0.03",
    "delegation_creation_base_gas_fee": 1000,
    "allow_list_expiration_height": 26120,
    "btc_activation_height": 220637
  },
  {
    "covenant_pks": [
      "fa9d882d45f4060bdb8042183828cd87544f1ea997380e586cab77d5fd698737",
      "0aee0509b16db71c999238a4827db945526859b13c95487ab46725357c9a9f25",
      "17921cf156ccb4e73d428f996ed11b245313e37e27c978ac4d2cc21eca4672e4",
      "113c3a32a9d320b72190a04a020a0db3976ef36972673258e9a38a364f3dc3b0",
      "79a71ffd71c503ef2e2f91bccfc8fcda7946f4653cef0d9f3dde20795ef3b9f0",
      "3bb93dfc8b61887d771f3630e9a63e97cbafcfcc78556a474df83a31a0ef899c",
      "d21faf78c6751a0d38e6bd8028b907ff07e9a869a43fc837d6b3f8dff6119a36",
      "40afaf47c4ffa56de86410d8e47baa2bb6f04b604f4ea24323737ddc3fe092df",
      "f5199efae3f28bb82476163a7e458c7ad445d9bffb0682d10d3bdb2cb41f8e8e"
    ],
    "covenant_quorum": 6,
    "min_staking_value_sat": 50000,
    "max_staking_value_sat": 35000000000,
    "min_staking_time_blocks": 10000,
    "max_staking_time_blocks": 64000,
    "slashing_pk_script": "ABRb4SYk0IorQkCV18ByIcM0UNFL8Q==",
    "min_slashing_tx_fee_sat": 5000,
    "slashing_rate": "0.05",
    "unbonding_time_blocks": 1008,
    "unbonding_fee_sat": 2000,
    "min_commission_rate": "0.03",
    "delegation_creation_base_gas_fee": 1095000,
    "allow_list_expiration_height": 26124,
    "btc_activation_height": 227174
  }
]`
