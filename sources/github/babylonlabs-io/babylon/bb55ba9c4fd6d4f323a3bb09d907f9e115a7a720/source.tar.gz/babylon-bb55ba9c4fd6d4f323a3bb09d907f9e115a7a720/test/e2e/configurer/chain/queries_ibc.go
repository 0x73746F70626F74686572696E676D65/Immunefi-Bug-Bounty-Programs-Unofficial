package chain

import (
	"fmt"
	"net/url"

	"github.com/babylonlabs-io/babylon/v3/test/e2e/util"
	clienttypes "github.com/cosmos/ibc-go/v10/modules/core/02-client/types"
	connectiontypes "github.com/cosmos/ibc-go/v10/modules/core/03-connection/types"
	channeltypes "github.com/cosmos/ibc-go/v10/modules/core/04-channel/types"
)

func (n *NodeConfig) QueryIBCChannels() (*channeltypes.QueryChannelsResponse, error) {
	path := "/ibc/core/channel/v1/channels"
	bz, err := n.QueryGRPCGateway(path, url.Values{})
	if err != nil {
		return nil, err
	}

	var resp channeltypes.QueryChannelsResponse
	if err := util.Cdc.UnmarshalJSON(bz, &resp); err != nil {
		return nil, err
	}

	return &resp, nil
}

func (n *NodeConfig) QueryNextSequenceReceive(channelID, portID string) (*channeltypes.QueryNextSequenceReceiveResponse, error) {
	path := fmt.Sprintf("/ibc/core/channel/v1/channels/%s/ports/%s/next_sequence", channelID, portID)
	bz, err := n.QueryGRPCGateway(path, url.Values{})
	if err != nil {
		return nil, err
	}

	var resp channeltypes.QueryNextSequenceReceiveResponse
	if err := util.Cdc.UnmarshalJSON(bz, &resp); err != nil {
		return nil, err
	}

	return &resp, nil
}

func (n *NodeConfig) QueryNextSequenceSend(channelID, portID string) (*channeltypes.QueryNextSequenceSendResponse, error) {
	path := fmt.Sprintf("/ibc/core/channel/v1/channels/%s/ports/%s/next_sequence_send", channelID, portID)
	bz, err := n.QueryGRPCGateway(path, url.Values{})
	if err != nil {
		return nil, err
	}

	var resp channeltypes.QueryNextSequenceSendResponse
	if err := util.Cdc.UnmarshalJSON(bz, &resp); err != nil {
		return nil, err
	}

	return &resp, nil
}

func (n *NodeConfig) QueryPacketAcknowledgement(channelID string, portID string, sequence uint64) (*channeltypes.QueryPacketAcknowledgementResponse, error) {
	path := fmt.Sprintf("/ibc/core/channel/v1/channels/%s/ports/%s/packet_acks/%d", channelID, portID, sequence)
	bz, err := n.QueryGRPCGateway(path, url.Values{})
	if err != nil {
		return nil, err
	}

	var resp channeltypes.QueryPacketAcknowledgementResponse
	if err := util.Cdc.UnmarshalJSON(bz, &resp); err != nil {
		return nil, err
	}

	return &resp, nil
}

func (n *NodeConfig) QueryChannelClientState(channelID, portID string) (*channeltypes.QueryChannelClientStateResponse, error) {
	path := fmt.Sprintf("/ibc/core/channel/v1/channels/%s/ports/%s/client_state", channelID, portID)
	bz, err := n.QueryGRPCGateway(path, url.Values{})
	if err != nil {
		return nil, err
	}

	var resp channeltypes.QueryChannelClientStateResponse
	if err := util.Cdc.UnmarshalJSON(bz, &resp); err != nil {
		return nil, err
	}

	return &resp, nil
}

func (n *NodeConfig) QueryClientStates() (*clienttypes.QueryClientStatesResponse, error) {
	bz, err := n.QueryGRPCGateway("/ibc/core/client/v1/client_states", url.Values{})
	if err != nil {
		return nil, err
	}

	var resp clienttypes.QueryClientStatesResponse
	if err := util.Cdc.UnmarshalJSON(bz, &resp); err != nil {
		return nil, err
	}

	return &resp, nil
}

func (n *NodeConfig) QueryConnections() (*connectiontypes.QueryConnectionsResponse, error) {
	bz, err := n.QueryGRPCGateway("/ibc/core/connection/v1/connections", url.Values{})
	if err != nil {
		return nil, err
	}

	var resp connectiontypes.QueryConnectionsResponse
	if err := util.Cdc.UnmarshalJSON(bz, &resp); err != nil {
		return nil, err
	}

	return &resp, nil
}
