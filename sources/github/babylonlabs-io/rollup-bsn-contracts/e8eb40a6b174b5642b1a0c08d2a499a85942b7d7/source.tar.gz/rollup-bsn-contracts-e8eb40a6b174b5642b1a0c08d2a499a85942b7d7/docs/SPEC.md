# Finality contract specification for the rollup integration

- [1. Abstract](#1-abstract)
- [2. Background](#2-background)
  - [2.1. BTC staking integration](#21-btc-staking-integration)
  - [2.2. The role of the finality contract](#22-the-role-of-the-finality-contract)
- [3. Keywords](#3-keywords)
- [4. Specification](#4-specification)
  - [4.1. Babylon Genesis chain message interfaces](#41-babylon-genesis-chain-message-interfaces)
    - [4.1.1. Message: EquivocationEvidence (MUST)](#411-message-equivocationevidence-must)
  - [4.2. Babylon Genesis chain gRPC queries](#42-babylon-genesis-chain-grpc-queries)
    - [4.2.1. QueryFinalityProvider (MUST)](#421-queryfinalityprovider-must)
  - [4.3. Babylon Genesis chain Custom Queries](#43-babylon-genesis-chain-custom-queries)
    - [4.3.1. CurrentEpoch (MUST)](#431-currentepoch-must)
    - [4.3.2. LastFinalizedEpoch (MUST)](#432-lastfinalizedepoch-must)
  - [4.4. Contract Instantiation](#44-contract-instantiation)
  - [4.5. Contract Migration (MUST)](#45-contract-migration-must)
  - [4.6. Signing Context](#46-signing-context)
  - [4.7. Rate Limiting (MUST)](#47-rate-limiting-must)
  - [4.8. Finality Contract message handlers](#48-finality-contract-message-handlers)
    - [4.8.1. CommitPublicRandomness (MUST)](#481-commitpublicrandomness-must)
    - [4.8.2. SubmitFinalitySignature (MUST)](#482-submitfinalitysignature-must)
    - [4.8.3. UpdateAdmin (SHOULD)](#483-updateadmin-should)
    - [4.8.4. UpdateConfig (MUST)](#484-updateconfig-must)
    - [4.8.5. AddToAllowlist (SHOULD)](#485-addtoallowlist-should)
    - [4.8.6. RemoveFromAllowlist (SHOULD)](#486-removefromallowlist-should)
    - [4.8.7. PruneData (SHOULD)](#487-prunedata-should)
  - [4.9. Contract State Storage](#49-contract-state-storage)
    - [4.9.1. Core Configuration](#491-core-configuration)
    - [4.9.2. Rate Limiting Storage](#492-rate-limiting-storage)
    - [4.9.3. Finality State Storage](#493-finality-state-storage)
    - [4.9.4. Public Randomness Storage](#494-public-randomness-storage)
  - [4.10. Finality contract queries](#410-finality-contract-queries)
    - [4.10.1. BlockVoters (MUST)](#4101-blockvoters-must)
    - [4.10.2. FirstPubRandCommit (MUST)](#4102-firstpubrandcommit-must)
    - [4.10.3. LastPubRandCommit (MUST)](#4103-lastpubrandcommit-must)
    - [4.10.4. ListPubRandCommit (MUST)](#4104-listpubrandcommit-must)
    - [4.10.5. Admin (SHOULD)](#4105-admin-should)
    - [4.10.6. Config (SHOULD)](#4106-config-should)
    - [4.10.7. AllowedFinalityProviders (SHOULD)](#4107-allowedfinalityproviders-should)
    - [4.10.8. AllowedFinalityProvidersAtHeight (SHOULD)](#4108-allowedfinalityprovidersatheight-should)
    - [4.10.9. HighestVotedHeight (SHOULD)](#4109-highestvotedheight-should)
- [5. Implementation status](#5-implementation-status)
  - [5.1. Babylon implementation status](#51-babylon-implementation-status)
  - [5.2. Finality contract implementation status](#52-finality-contract-implementation-status)

## 1. Abstract

This document specifies the design and requirements of the finality contract
used in integrating rollups with Babylon's Bitcoin staking protocol. The
finality contract enables BSNs to inherit Bitcoin-backed economic security by
recording finality signatures from BSN finality providers, enforcing slashing
for equivocation, and exposing finality signatures to the integrated BSN. The
document details the contract's interfaces, message handlers, and queries, and
provides guidance for implementers seeking to leverage Babylon's Bitcoin
security for rollup finality.

## 2. Background

### 2.1. BTC staking integration

Babylon's phase-3 network introduces Bitcoin staking integration to provide
Bitcoin security to other decentralized systems, known as Bitcoin Supercharged
Networks (BSNs), such as L1 blockchains and rollups. This integration enables
BTC stakers to delegate their native BTC to finality providers on BSNs, and each
BSN will leverage this BTC stake for economic security. For more details, see
the [Cosmos integration
1-pager](https://www.notion.so/BTC-staking-integration-for-Cosmos-chains-1-pager-f0574cd4e624475eb00d64912698a38c?pvs=4)
and [OP Stack integration
1-pager](https://www.notion.so/BTC-staking-integration-for-OP-stack-chains-1-pager-16f28a013c55805fbebdec6102b43c92?pvs=4).

### 2.2. The role of the finality contract

The finality contract is a necessary component in the integration architecture
between rollups and Babylon's Bitcoin staking protocol. This contract is
responsible for two primary functions:

1. Maintaining finality signatures submitted by rollup BSN finality providers,
   and
2. Enforcing slashing upon detection of equivocation by BSN finality providers.

To determine Bitcoin staking finalization status, each rollup full node
maintains a connection to a Babylon Genesis full node to retrieve finality
signatures. Please refer to the [OP stack integration
1-pager](https://www.notion.so/BTC-staking-integration-for-OP-stack-chains-1-pager-16f28a013c55805fbebdec6102b43c92?pvs=4)
as an example in the context of integrating an OP stack rollup.

## 3. Keywords

The key words "MUST", "MUST NOT", "REQUIRED", "SHALL", "SHALL NOT", "SHOULD",
"SHOULD NOT", "RECOMMENDED", "NOT RECOMMENDED", "MAY", and "OPTIONAL" in this
document are to be interpreted as described in [RFC
2119](https://www.ietf.org/rfc/rfc2119.html) and [RFC
8174](https://www.ietf.org/rfc/rfc8174.html).

## 4. Specification

This section outlines the detailed requirements for implementing a finality
contract that integrates with Babylon's Bitcoin staking protocol. It covers the
interfaces with Babylon Genesis chain, message handlers, and queries that all
finality contract implementations must or should support. The specification
distinguishes between required ("MUST") and recommended ("SHOULD") components.

### 4.1. Babylon Genesis chain message interfaces

This section outlines the interfaces that Babylon Genesis chain has to implement
and the finality contract needs to interact with.

#### 4.1.1. Message: EquivocationEvidence (MUST)

The Babylon Genesis chain MUST provide a message interface for finality
contracts to report equivocation evidence when finality providers double-sign:

```rust
// Interface provided by Babylon Genesis chain
BabylonMsg::MsgEquivocationEvidence {
    /// Address of the entity reporting the equivocation
    signer: String,
    /// BTC public key of the equivocating finality provider (hex-encoded)
    fp_btc_pk_hex: String,
    /// Block height at which an equivocation occurred
    block_height: u64,
    /// Public randomness value used in both signatures (hex-encoded)
    pub_rand_hex: String,
    /// Application hash of the canonical block (hex-encoded)
    canonical_app_hash_hex: String,
    /// Application hash of the fork block (hex-encoded)
    fork_app_hash_hex: String,
    /// EOTS signature on the canonical block (hex-encoded)
    canonical_finality_sig_hex: String,
    /// EOTS signature on the fork block (hex-encoded)
    fork_finality_sig_hex: String,
    /// Signing context used for the signatures
    signing_context: String,
}
```

**Expected behaviour of Babylon Genesis chain:** Upon receiving the message, the
Babylon chain MUST validate the evidence cryptographically, extract the finality
provider's secret key using EOTS, remove them from the active set, set their
voting power to zero, and record the evidence.

**Usage Context:** Finality contracts MUST send this when detecting
double-signing by a finality provider at the same height.

### 4.2. Babylon Genesis chain gRPC queries

The Babylon Genesis chain MUST provide the contracts with access to the
following gRPC endpoints through the whitelist configuration in the [Babylon
chain](https://github.com/babylonlabs-io/babylon/blob/b9774782f38e9758c4f5aafab1e1e45dde0f3838/wasmbinding/grpc_whitelist.go).
<!-- TODO: use a release rather than a commit for the pointer -->

```go
func WhitelistedGrpcQuery() wasmkeeper.AcceptedQueries {
    return wasmkeeper.AcceptedQueries{
        // btcstkconsumer
        "/babylon.btcstaking.v1.Query/FinalityProvider": func() proto.Message {
            return &btcstakingtypes.QueryFinalityProviderResponse{}
        },
        // btcstaking
        "/babylon.btcstaking.v1.Query/FinalityProviderCurrentPower": func() proto.Message {
            return &ftypes.QueryFinalityProviderCurrentPowerResponse{}
        },
        // for testing
        "/babylon.epoching.v1.Query/CurrentEpoch": func() proto.Message {
            return &epochtypes.QueryCurrentEpochResponse{}
        },
    }
}
```

#### 4.2.1. QueryFinalityProvider (MUST)

Query `/babylon.btcstaking.v1.Query/FinalityProvider` returns the finality
provider information for the finality provider BTC PK. This query is used for
verifying that the finality provider exists, is not slashed, and is associated
with the correct BSN.

```protobuf
// QueryFinalityProviderRequest requests information about a finality provider
message QueryFinalityProviderRequest {
  // fp_btc_pk_hex is the hex str of Bitcoin secp256k1 PK of the finality
  // provider
  string fp_btc_pk_hex = 1;
}

// QueryFinalityProviderResponse contains information about a finality provider
message QueryFinalityProviderResponse {
  // finality_provider contains the FinalityProvider
  FinalityProviderResponse finality_provider = 1;
}

// FinalityProviderResponse defines a finality provider with voting power
// information.
message FinalityProviderResponse {
  // description defines the description terms for the finality provider.
  cosmos.staking.v1beta1.Description description = 1;
  // commission defines the commission rate of the finality provider.
  string commission = 2 [
    (cosmos_proto.scalar) = "cosmos.Dec",
    (gogoproto.customtype) = "cosmossdk.io/math.LegacyDec"
  ];
  // addr is the address to receive commission from delegations.
  string addr = 3 [ (cosmos_proto.scalar) = "cosmos.AddressString" ];
  // btc_pk is the Bitcoin secp256k1 PK of this finality provider
  // the PK follows encoding in BIP-340 spec
  bytes btc_pk = 4
      [ (gogoproto.customtype) =
            "github.com/babylonlabs-io/babylon/v3/types.BIP340PubKey" ];
  // pop is the proof of possession of the BTC_PK by the fp addr.
  // Essentially is the signature where the BTC SK sigs the fp addr.
  ProofOfPossessionBTC pop = 5;
  // slashed_babylon_height indicates the Babylon height when
  // the finality provider is slashed.
  // if it's 0 then the finality provider is not slashed
  uint64 slashed_babylon_height = 6;
  // slashed_btc_height indicates the BTC height when
  // the finality provider is slashed.
  // if it's 0 then the finality provider is not slashed
  uint32 slashed_btc_height = 7;
  // height is the queried Babylon height
  uint64 height = 8;
  // jailed defines whether the finality provider is jailed
  bool jailed = 9;
  // highest_voted_height is the highest height for which the
  // finality provider has voted
  uint32 highest_voted_height = 10;
  // commission_info contains information details of the finality provider
  // commission.
  CommissionInfo commission_info = 11;
  // bsn_id is the ID of the BSN the finality provider is securing
  string bsn_id = 12;
}

// Description defines a validator description.
message Description {
  // moniker defines a human-readable name for the validator.
  string moniker = 1;
  // identity defines an optional identity signature (ex. UPort or Keybase).
  string identity = 2;
  // website defines an optional website link.
  string website = 3;
  // security_contact defines an optional email for security contact.
  string security_contact = 4;
  // details define other optional details.
  string details = 5;
}

// ProofOfPossessionBTC is the proof of possession that a Babylon
// address and a Bitcoin secp256k1 secret key are held by the same
// person
message ProofOfPossessionBTC {
    // btc_sig_type indicates the type of btc_sig in the pop
    BTCSigType btc_sig_type = 1;
    // btc_sig is the signature generated via sign(sk_btc, babylon_staker_address)
    // the signature follows encoding in either BIP-340 spec or BIP-322 spec
    bytes btc_sig = 2;
}

// BTCSigType indicates the type of btc_sig in a pop
enum BTCSigType {
    // BIP340 means the btc_sig will follow the BIP-340 encoding
    BIP340 = 0;
    // BIP322 means the btc_sig will follow the BIP-322 encoding
    BIP322 = 1;
    // ECDSA means the btc_sig will follow the ECDSA encoding
    // ref: https://github.com/okx/js-wallet-sdk/blob/a57c2acbe6ce917c0aa4e951d96c4e562ad58444/packages/coin-bitcoin/src/BtcWallet.ts#L331
    ECDSA = 2;
}
```

### 4.3. Babylon Genesis chain Custom Queries

Finality contracts MUST utilize custom queries provided by the
[babylon-bindings](https://github.com/babylonlabs-io/bindings/) crate to
interact with Babylon-specific functionality. These custom queries provide
access to Babylon chain state that is not available through standard CosmWasm
queries.

**Required Dependencies:** The contract must include the `babylon_bindings`
crate which provides CosmWasm bindings to custom
[Babylon](https://github.com/babylonlabs-io/babylon) features.

#### 4.3.1. CurrentEpoch (MUST)

**Query Purpose:** Retrieves the current Babylon epoch number, which is
essential for timestamping public randomness commitments.

**Query Interface:**
```rust
// Request - no parameters required
pub struct CurrentEpochRequest {}

// Response
pub struct CurrentEpochResponse {
    pub epoch: u64,
}
```

**Expected Behaviour:**
- Query the current epoch from the Babylon chain
- Return the current epoch number as a `u64`

**Usage Context:** This query is used when storing public randomness commitments
to record the Babylon epoch at which the commitment was made, enabling BTC
timestamping validation.

#### 4.3.2. LastFinalizedEpoch (MUST)

**Query Purpose:** Retrieves the last finalized Babylon epoch, which is used to
verify that public randomness commitments have been timestamped by Bitcoin.

**Query Interface:**
```rust
// Request - no parameters required  
pub struct LastFinalizedEpochRequest {}

// Response
pub struct LastFinalizedEpochResponse {
    pub epoch_number: u64,
    pub epoch_info: Option<EpochInfo>,
}

pub struct EpochInfo {
    pub epoch_number: u64,
    pub epoch_boundary: u64,
    pub sealed_epoch: u64,
}
```

**Expected Behaviour:**
- Query the latest finalized epoch information from the Babylon chain
- Return the epoch number and optional epoch metadata

**Usage Context:** This query is used during finality signature verification to
ensure that the public randomness commitment has been timestamped by Bitcoin
before accepting finality signatures that reference it.

**BTC Timestamping Validation:** A public randomness commitment is considered
BTC-timestamped if its commitment epoch is less than or equal to the last
finalized epoch. This ensures that the commitment has been anchored to the
Bitcoin blockchain before being used for finality signatures.

### 4.4. Contract Instantiation

Finality contracts MUST support instantiation with configuration parameters for
operational settings. The contract MUST utilize custom queries provided by the
[babylon-bindings](https://github.com/babylonlabs-io/bindings/) crate to
interact with Babylon-specific functionality.

```rust
pub struct InstantiateMsg {
    pub admin: String,
    pub bsn_id: String,
    pub min_pub_rand: u64,
    pub rate_limiting_interval: u64,
    pub max_msgs_per_interval: u32,
    pub bsn_activation_height: u64,
    pub finality_signature_interval: u64,
    pub allowed_finality_providers: Option<Vec<String>>,
}
```

**New Optional Parameter:**
- `allowed_finality_providers`: `Option<Vec<String>>` — An optional list of BTC
  public keys (hex-encoded) to pre-populate the allowlist at contract
  instantiation. If provided, each key must be non-empty. Any empty key will
  cause instantiation to fail. If omitted or empty, the allowlist will start
  empty.

**Example:**
```json
{
  "admin": "babylon1...",
  "bsn_id": "op-stack-l2-11155420",
  "min_pub_rand": 100,
  "rate_limiting_interval": 500,
  "max_msgs_per_interval": 10,
  "bsn_activation_height": 0,
  "finality_signature_interval": 5,
  "allowed_finality_providers": [
    "02a0434d9e47f3c86235477c7b1ae6ae5d3442d49b1943c2b752a68e2a47e247c7",
    "03a0434d9e47f3c86235477c7b1ae6ae5d3442d49b1943c2b752a68e2a47e247c7"
  ]
}
```

**Expected Behaviour:** When deploying the finality contract, the following
parameters must be provided.

**Required Parameters:**
- `admin`: String - The initial admin address for the contract who can update
  settings
- `bsn_id`: String - The unique identifier for this BSN (e.g.,
  `op-stack-l2-11155420`)
- `min_pub_rand`: u64 - Minimum number of public randomness values required in
  commitments (must be ≥ 1)
- `rate_limiting_interval`: u64 - Number of blocks in each rate limiting
  interval (must be ≥ 1)
- `max_msgs_per_interval`: u32 - Maximum messages allowed per finality provider
  per interval (must be ≥ 1)
- `bsn_activation_height`: u64 - The block height at which the BSN system is
  activated and begins accepting finality signatures. Setting this to 0 means
  "activate immediately from genesis". **Note**: This parameter only affects
  `SubmitFinalitySignature` messages; `CommitPublicRandomness` messages are
  unaffected by BSN activation height
- `finality_signature_interval`: u64 - The interval between allowed finality
  signature submissions to prevent spam (must be ≥ 1). This parameter also
  determines the interval for sparse public randomness generation, where public
  randomness values are generated at heights: `start_height`, `start_height +
  interval`, `start_height + 2 * interval`, etc.

**Validation Requirements:**
1. **Admin Address Validation**: The `admin` parameter MUST be a valid Babylon
   address
2. **BSN ID Validation**: The `bsn_id` parameter MUST:
   - Not be empty
   - Contain only alphanumeric characters, hyphens, and underscores
   - Not exceed 100 characters in length
3. **Min Pub Rand Validation**: The `min_pub_rand` parameter MUST be ≥ 1
4. **Rate Limiting Validation**: Both `rate_limiting_interval` and
   `max_msgs_per_interval` MUST be ≥ 1
5. **Allowlist Validation**: If `allowed_finality_providers` is provided, all
   keys MUST be non-empty strings. If any are empty, instantiation MUST fail.
6. **Finality Signature Interval Validation**: The `finality_signature_interval`
   parameter MUST be ≥ 1

**Instantiation Process:**
1. **Parameter Validation**: Validate all input parameters according to the
   requirements above
2. **Admin Setup**: Set the provided admin address as the contract administrator
3. **Configuration Storage**: Save the bsn_id, min_pub_rand, rate limiting
   configuration, bsn_activation_height, and finality_signature_interval in the
   contract configuration
4. **Allowlist Setup**: If provided, add all valid keys to the allowlist
   configuration in the contract configuration
5. **Response**: Return a success response with instantiation attributes

**Important Design Consideration - Height Alignment**: For optimal integration,
the `start_height` of public randomness commitments SHOULD align with the
`bsn_activation_height` to ensure that public randomness is available exactly
when finality signatures are allowed. This alignment prevents validation errors
and ensures efficient sparse generation. For example, if `bsn_activation_height
= 0` and `finality_signature_interval = 5`, then public randomness commitments
should start at height 0 to provide randomness at heights 0, 5, 10, 15, etc.

### 4.5. Contract Migration (MUST)

Finality contracts MUST support contract migration to enable upgrades while
preserving contract state and address. This is essential for production
deployments where contract logic needs to be updated without disrupting existing
functionality.

**Migration Requirements:**
- **Entry Point**: Contracts MUST export a `migrate` entry point using the
  CosmWasm `#[cfg_attr(not(feature = "library"), entry_point)]` attribute
- **Admin Control**: Only the contract admin can execute migrations (enforced by
  CosmWasm runtime)
- **State Preservation**: Migration MUST preserve all existing contract state
  and storage
- **Backward Compatibility**: New contract versions MUST be compatible with
  existing state structures for non-state-breaking migrations
- **Contract Validation**: Migration MUST validate the contract name matches
  expectations

**Migration Message Format:**
```rust
#[cw_serde]
pub struct MigrateMsg {}  // Empty for non-state-breaking migrations
```

**Note**: Version tracking is handled automatically by the `cw2` library during
migration. The `MigrateMsg` is empty because all version information is stored
in the contract's state and managed by the migration function.

**Migration Function:**
```rust
/// Handle contract migration.
/// This function is called when the contract is migrated to a new version.
/// It supports both:
/// - Migrating from contracts with existing cw2 version info
/// - Migrating from legacy contracts deployed without cw2 version tracking
/// For non-state-breaking migrations, this updates the contract version and logs the migration.
pub fn migrate(
    deps: DepsMut<BabylonQuery>,
    _env: Env,
    _msg: MigrateMsg,
) -> Result<Response<BabylonMsg>, ContractError> {
    // Attempt to get the current version stored in the contract
    let prev_version = match cw2::get_contract_version(deps.storage) {
        Ok(version) => {
            // Contract has version info - validate it's the expected contract
            if version.contract != CONTRACT_NAME {
                return Err(ContractError::InvalidContractName {
                    expected: CONTRACT_NAME.to_string(),
                    actual: version.contract,
                });
            }
            version
        }
        Err(_) => {
            // No version info exists - this is a legacy contract
            // Create a placeholder version for logging purposes
            cw2::ContractVersion {
                contract: CONTRACT_NAME.to_string(),
                version: LEGACY_VERSION.to_string(),
            }
        }
    };

    // Update to the new version (this creates version info if it didn't exist)
    cw2::set_contract_version(deps.storage, CONTRACT_NAME, CONTRACT_VERSION)?;

    Ok(Response::new()
        .add_attribute("action", "migrate")
        .add_attribute("from_version", prev_version.version)
        .add_attribute("to_version", CONTRACT_VERSION))
}
```

**Migration Features:**
- **Automatic Version Tracking**: Uses the `cw2` library for contract version
  management
- **Legacy Contract Support**: Gracefully handles contracts deployed before
  `cw2` version tracking was implemented
- **Contract Validation**: Ensures the contract name matches before migration
- **Version Updates**: Automatically updates stored version information
- **Detailed Logging**: Returns attributes showing the version transition

**Migration Types:**
1. **Non-State-Breaking Migrations**: Updates to contract logic that don't
   change storage structures (currently supported)
2. **State-Breaking Migrations**: Updates that require data transformation
   (future enhancement - would require extending MigrateMsg)

**Migration Process:**
1. Store new contract code on the blockchain
2. Execute migration transaction with contract address and new code ID
3. New contract's `migrate` function executes against existing state
4. Contract address remains the same, only the code changes

**Error Handling:** The migration function includes validation that returns
`ContractError::InvalidContractName` if the stored contract name doesn't match
the expected name (`"rollup-bsn/finality"`).

**Version Management:**
- **Contract Name**: `"rollup-bsn/finality"` (constant)
- **Contract Version**: Uses `CARGO_PKG_VERSION` from the package manifest
- **Legacy Version**: `"pre-cw2"` (constant used for contracts deployed before
  version tracking)
- **Storage**: Version information is stored using the `cw2` library

**Security Considerations:**
- Migration is admin-only and enforced by the CosmWasm runtime
- Contract must have been instantiated with an admin address
- Contract name validation prevents migration to incompatible contracts
- Migration cannot be used to bypass access controls or modify critical state

### 4.6. Signing Context

Finality contracts MUST implement signing context to ensure message signatures
are bound to the specific contract and chain. The signing context prevents
signature replay attacks across different contracts or chains.
[Babylon](https://github.com/babylonlabs-io/babylon/tree/main/app/signingcontext)
provides a library for signing context.

**Signing Context Format:** The signing context is a hex-encoded SHA256 hash of
a structured string that includes:
- Protocol name: `btcstaking`
- Version: `0`
- Operation type: `fp_rand_commit` or `fp_fin_vote`
- Chain ID: The chain ID of the blockchain where the contract is deployed
- Contract address: The address of the finality contract

**Context Generation:**
1. **Public Randomness Commitment Context**:
   ```
   hex(sha256("btcstaking/0/fp_rand_commit/{chain_id}/{contract_address}"))
   ```
   Used for verifying signatures on public randomness commitments.

2. **Finality Vote Context**:
   ```
   hex(sha256("btcstaking/0/fp_fin_vote/{chain_id}/{contract_address}"))
   ```
   Used for verifying EOTS signatures on finality votes.

**Usage in Message Construction:** The signing context is prepended to the
message being signed as raw bytes from the hex string. This ensures that
signatures are cryptographically bound to the specific contract instance and
cannot be replayed across different contracts or chains.

### 4.7. Rate Limiting (MUST)

Finality contracts MUST implement rate limiting to prevent spam and ensure fair
usage of the contract by finality providers. The rate limiting system operates
on a per-finality provider basis using block intervals.

**Rate Limiting Design:**
- **Interval-Based**: Rate limits are calculated based on block intervals, where
  each interval consists of a configurable number of Babylon blocks
- **Per-Finality Provider**: Each finality provider has an independent rate
  limit counter
- **Automatic Reset**: Counters automatically reset when a new interval begins
- **Configurable Limits**: Both the interval duration and maximum messages per
  interval are configurable at contract instantiation

**Rate Limiting Configuration:**
```rust
pub struct RateLimitingConfig {
    pub max_msgs_per_interval: u32,  // Maximum messages per FP per interval
    pub block_interval: u64,         // Number of Babylon blocks per interval
}
```

**Rate Limiting Storage:**
- **Storage Key**: `Map<&[u8], (u64, u32)>` where the key is the finality
  provider's BTC public key
- **Storage Value**: Tuple of `(interval_number, message_count)` where:
  - `interval_number`: The current interval number (calculated as `block_height
    / block_interval`)
  - `message_count`: Number of messages processed in the current interval

**Rate Limiting Logic:**
1. **Interval Calculation**: `current_interval = block_height / block_interval`
2. **Counter Retrieval**: Load existing counter for the finality provider or
   initialize with `(current_interval, 0)`
3. **Interval Reset Check**: If stored interval differs from current interval,
   reset count to 0 and update interval
4. **Rate Limit Check**: Verify that `message_count + 1 ≤ max_msgs_per_interval`
5. **Counter Update**: Increment the message count and save to storage
6. **Error Handling**: Return `ContractError::RateLimitExceeded` if the limit
   would be exceeded

**Integration Points:**
- MUST be enforced in `CommitPublicRandomness` handler before signature
  verification
- MUST be enforced in `SubmitFinalitySignature` handler before finality
  signature processing
- Rate limiting checks MUST occur early in message processing to prevent
  resource consumption

**Rate Limiting Errors:**
```rust
ContractError::RateLimitExceeded {
    fp_btc_pk: String,     // Hex-encoded finality provider BTC public key
    limit: u32,            // The rate limit that was exceeded
}
```

### 4.8. Finality Contract message handlers

The finality contract message requirements are divided into core finality
functionality (MUST) and administrative functionality (SHOULD):

```rust
use cosmwasm_schema::cw_serde;
use cosmwasm_std::{Addr, Binary};
use babylon_merkle::Proof;

#[cw_serde]
pub enum ExecuteMsg {
    // MUST: Core messages

    /// This message allows a finality provider to commit to a sequence of public randomness values
    /// that will be revealed later during finality signature submissions.
    /// 
    /// The commitment is a Merkle root containing the public randomness values. When submitting 
    /// finality signatures later, the provider must include Merkle proofs that verify against this
    /// commitment.
    ///
    /// This commitment mechanism ensures that finality providers cannot adaptively choose their
    /// public randomness values after seeing block contents, which is important for security.
    CommitPublicRandomness {
        /// `fp_pubkey_hex` is the BTC PK of the finality provider that commits the public randomness
        fp_pubkey_hex: String,
        /// `start_height` is the start block height of the list of public randomness
        start_height: u64,
        /// `num_pub_rand` is the amount of public randomness committed
        num_pub_rand: u64,
        /// `commitment` is the commitment of these public randomness values.
        /// Currently, it's the root of the Merkle tree that includes the public randomness
        commitment: Binary,
        /// `signature` is the signature on (start_height || num_pub_rand || commitment) signed by
        /// the SK corresponding to `fp_pubkey_hex`.
        /// This prevents others committing public randomness on behalf of `fp_pubkey_hex`
        signature: Binary,
    },
    /// Submit Finality Signature.
    ///
    /// This is a message that can be called by a finality provider to submit their finality
    /// signature to the BSN.
    /// The signature is verified by the BSN using the finality provider's public key.
    /// If an equivocation is detected (signing two different blocks at the same height),
    /// the contract will automatically extract the secret key using EOTS and submit evidence
    /// to Babylon Genesis for slashing.
    ///
    /// This message is equivalent to the `MsgAddFinalitySig` message in the Babylon finality protobuf
    /// defs.
    SubmitFinalitySignature {
        /// The BTC public key of the finality provider submitting the signature
        fp_pubkey_hex: String,
        /// Optional L1 block number (rollup-specific metadata)
        l1_block_number: Option<u64>,
        /// Optional L1 block hash hex (rollup-specific metadata)
        l1_block_hash_hex: Option<String>,
        /// The block height this finality signature is for
        height: u64,
        /// The public randomness used for signing this block
        pub_rand: Binary,
        /// Merkle proof verifying that pub_rand was included in the earlier commitment
        proof: Proof,
        /// Hash of the block being finalized
        block_hash: Binary,
        /// Finality signature on (height || block_hash) signed by finality provider
        signature: Binary,
    },

    // SHOULD: Administrative messages

    /// Update the admin address.
    ///
    /// This message can be called by the admin only.
    /// The new admin address must be a valid Babylon address.
    UpdateAdmin {
        admin: String,
    },
    /// Add a finality provider to the allowlist.
    ///
    /// This message can be called by the admin only.
    /// Only finality providers in the allowlist can submit finality signatures and public randomness commitments.
    AddToAllowlist {
        /// The BTC public keys of the finality providers to add to the allowlist (in hex format)
        fp_pubkey_hex_list: Vec<String>,
    },
    /// Remove a finality provider from the allowlist.
    ///
    /// This message can be called by the admin only.
    /// Removing a finality provider from the allowlist will prevent them from submitting
    /// new finality signatures and public randomness commitments.
    RemoveFromAllowlist {
        /// The BTC public keys of the finality providers to remove from the allowlist (in hex format)
        fp_pubkey_hex_list: Vec<String>,
    },
    /// Update contract configuration.
    ///
    /// This message can be called by the admin only.
    /// All fields are optional - only provided fields will be updated.
    /// Updated values must pass the same validation as during instantiation.
    UpdateConfig {
        /// New minimum number of public randomness values required (if provided)
        min_pub_rand: Option<u64>,
        /// New maximum messages per finality provider per interval (if provided)
        max_msgs_per_interval: Option<u32>,
        /// New rate limiting interval in blocks (if provided)
        rate_limiting_interval: Option<u64>,
        /// New BSN activation height (if provided)
        bsn_activation_height: Option<u64>,
        /// New finality signature interval (if provided)
        finality_signature_interval: Option<u64>,
    },
}
```

#### 4.8.1. CommitPublicRandomness (MUST)

**Message Structure:**
```rust
CommitPublicRandomness {
    fp_pubkey_hex: String,
    start_height: u64,
    num_pub_rand: u64,
    commitment: Binary,
    signature: Binary,
}
```

**Expected Behaviour:** Finality contracts MUST implement this handler with the
following verification logic:

0. **Public Key Decoding**: Decode the finality provider's BTC public key:
   - Decode the `fp_pubkey_hex` parameter from hex string to bytes
   - This decoded byte array is used for all subsequent validation steps

1. **Allowlist Check**: Verify that the finality provider is in the allowlist:
   - Query the allowlist storage using the decoded BTC public key bytes
   - If the finality provider is not in the allowlist, return
     `FinalityProviderNotAllowed` error

2. **Finality Provider Existence Check**: Verify that the finality provider
   exists and is not slashed by querying the Babylon Genesis chain through gRPC:
   - Use `query_grpc` to call `/babylon.btcstaking.v1.Query/FinalityProvider`
     with the `fp_pubkey_hex` parameters
   - Verify the response contains a valid finality provider
   - Ensure the finality provider is associated with this BSN
   - Ensure the finality provider has not been slashed (`slashed_babylon_height`
     and `slashed_btc_height` are both 0)

3. **Rate Limiting Check**: Enforce rate limiting for the finality provider:
   - Call the rate limiting function with the decoded BTC public key bytes and
     current block environment
   - Return `ContractError::RateLimitExceeded` if the rate limit is exceeded

4. **Signature Verification**: Verify the commitment signature using Schnorr
   signature verification:
   - Use the previously decoded finality provider's BTC public key bytes
   - Generate signing context:
     `hex(sha256("btcstaking/0/fp_rand_commit/{chain_id}/{contract_address}"))`
   - Construct message: `signing_context || start_height || num_pub_rand ||
     commitment` (where signing_context is the hex string as bytes, start_height
     and num_pub_rand are in big-endian bytes)
   - Verify signature against the constructed message using the BTC public key

4. **Height Overlap Check**: Ensure no overlap with existing public randomness
   commitments:
   - Query the last public randomness commitment for this finality provider from
     public randomness commitment state
   - Use key `(fp_pubkey_hex, _)` to find the highest height commitment
   - For sparse generation, ensure `start_height > last_commit.start_height +
     (last_commit.num_pub_rand - 1) * last_commit.interval` to prevent overlapping
     height ranges in the sparse pattern

5. **Storage Operations**: Save the public randomness commitment data:
   - Create a new `PubRandCommit` struct with provided parameters, current
     Babylon epoch, and the contract's `finality_signature_interval` as the interval
   - The `interval` field is automatically set to the contract's `finality_signature_interval`
     to enable sparse public randomness generation aligned with finality signature scheduling
   - Save to the public randomness commitment state using key `(fp_pubkey_hex,
     start_height)`
   - Record the current Babylon epoch as the commitment epoch for BTC
     timestamping validation

**Sparse Generation Pattern**: The public randomness values in the commitment are available
at heights: `start_height`, `start_height + interval`, `start_height + 2 * interval`, etc.
This pattern aligns with the finality signature interval to ensure that public randomness
is available exactly when finality signatures are allowed to be submitted.

#### 4.8.2. SubmitFinalitySignature (MUST)

**Message Structure:**
```rust
SubmitFinalitySignature {
    fp_pubkey_hex: String,
    l1_block_number: Option<u64>,
    l1_block_hash_hex: Option<String>,
    height: u64,
    pub_rand: Binary,
    proof: Proof,
    block_hash: Binary,
    signature: Binary,
}
```

**Finality Signature Message Format:** The finality signature is computed over a
message constructed as follows:
1. Generate signing context:
   `hex(sha256("btcstaking/0/fp_fin_vote/{chain_id}/{contract_address}"))`
2. Construct the message: `signing_context || height || block_hash` (where
signing_context is the hex string as bytes, height is encoded as 8 bytes in
big-endian format) 3. Apply SHA256 hash to the message: `message_hash =
SHA256(signing_context || height || block_hash)`
3. Sign the message hash using EOTS with the public randomness

**Expected Behaviour:** Finality contracts MUST implement this handler with the
following verification logic:

0. **Public Key Decoding**: Decode the finality provider's BTC public key:
   - Decode the `fp_pubkey_hex` parameter from hex string to bytes
   - This decoded byte array is used for all subsequent validation steps

1. **Allowlist Check**: Verify that the finality provider is in the allowlist:
   - Query the allowlist storage using the decoded BTC public key bytes
   - If the finality provider is not in the allowlist, return
     `FinalityProviderNotAllowed` error

2. **BSN Activation and Interval Check**: Ensure finality signatures are allowed
   by validating both BSN activation status and scheduled intervals:
   - Load the contract configuration to get `bsn_activation_height` and
     `finality_signature_interval`
   - Verify that `height >= bsn_activation_height`
   - Verify that `(height - bsn_activation_height) % finality_signature_interval
     == 0`
   - Return `ContractError::BeforeBSNActivation` if the height is before BSN
     activation
   - Return `ContractError::FinalitySignatureNotAtScheduledHeight` if the
     signature is not at a scheduled height
   - **Note**: This validation is typically implemented as a single function
     that performs both checks together

3. **Finality Provider Existence Check**: Verify that the finality provider
   exists and is not slashed by querying the Babylon Genesis chain through gRPC:
   - Use `query_grpc` to call `/babylon.btcstaking.v1.Query/FinalityProvider`
     with the `fp_pubkey_hex` parameters
   - Verify the response contains a valid finality provider
   - Ensure the finality provider is associated with this BSN
   - Ensure the finality provider has not been slashed (`slashed_babylon_height`
     and `slashed_btc_height` are both 0)

4. **Rate Limiting Check**: Enforce rate limiting for the finality provider:
   - Call the rate limiting function with the decoded BTC public key bytes and
     current block environment
   - Return `ContractError::RateLimitExceeded` if the rate limit is exceeded

5. **Duplicate Vote Check**: Check if an identical vote already exists:
   - Query finality signature state using key `(height, fp_pubkey_bytes)`
   - If the same signature exists for the same block hash, return success
     (duplicate vote)
   - If a different signature exists for the same height, proceed to
     equivocation handling

6. **Public Randomness Commitment Retrieval**: Find the public randomness
   commitment that covers the target height:
   - Query public randomness commitment state to find commitment where the height
     is within the sparse generation pattern
   - Use the `contains_height` method to verify: `height` must be in the form
     `start_height + i * interval` for some `i < num_pub_rand`
   - **BTC Timestamping Validation**: Ensure the commitment is timestamped by
     BTC by verifying that the commitment's epoch is less than or equal to the
     last finalized epoch
   - Use the commitment for subsequent verification steps

7. **Finality Signature Verification**:
   - **Sparse Generation Height Check**: Verify that the block height corresponds to the correct public randomness index:
     - Calculate expected height: `proof_height = pr_commit.start_height + proof.index * pr_commit.interval`
     - Verify `height == proof_height` to ensure the height aligns with the sparse generation pattern
   - Verify `proof.total == pr_commit.num_pub_rand`
   - Verify the inclusion proof for the public randomness value against
     `pr_commit.commitment`
   - Verify the EOTS signature using:
     - Generate signing context:
       `hex(sha256("btcstaking/0/fp_fin_vote/{chain_id}/{contract_address}"))`
     - Message: `SHA256(signing_context || height || block_hash)` (where
       signing_context is the hex string as bytes, height is in big-endian
       format)
     - Public randomness value and EOTS signature

8. **Equivocation Detection and Handling**: Check if the finality provider has
   already voted for a different block at this height:
   - If existing signature differs from current block hash:
     - Extract the secret key using EOTS from the two different signatures
     - Send `BabylonMsg::MsgEquivocationEvidence` to trigger slashing on Babylon
       Genesis
     - Emit `slashed_finality_provider` event with extracted secret key

9. **Storage Operations**: Store the finality signature and related data
   atomically:
   - Use the `insert_finality_sig_and_signatory` helper function to perform all
     storage operations atomically
   - This function performs the following operations in sequence:
     - Save finality signature using key `(height, fp_pubkey_hex)` (will
       override existing signature)
     - Add signatory to the set of signatories for the block using key `(height,
       block_hash)`
     - Save public randomness value using key `(height, fp_pubkey_hex)` if this
       is the first vote for this height

#### 4.8.3. UpdateAdmin (SHOULD)

**Message Structure:**
```rust
UpdateAdmin {
    admin: String,
}
```

**Expected Behaviour:** Finality contracts SHOULD implement this administrative
handler with the following verification logic:

1. **Admin Authorization**: Verify that the caller is the current contract
   admin:
   - Query the current admin address
   - Verify that the message sender matches the current admin address

2. **Admin Validation**: Validate the new admin address:
   - Ensure the `admin` parameter is a valid Babylon address
   - Optionally ensure the new admin differs from the current admin

3. **Storage Operations**: Update the admin address:
   - Update the admin address using the cw-controllers Admin functionality
     - The new admin address from `admin` parameter replaces the current admin
  - Return success response

#### 4.8.4. UpdateConfig (MUST)

**Message Structure:**
```rust
UpdateConfig {
    min_pub_rand: Option<u64>,
    max_msgs_per_interval: Option<u32>,
    rate_limiting_interval: Option<u64>,
}
```

**Expected Behaviour:** Finality contracts SHOULD implement this administrative
handler with the following verification logic:

1. **Admin Authorization**: Verify that the caller is the current contract
   admin:
   - Query the current admin address
   - Verify that the message sender matches the current admin address

2. **Parameter Validation**: Validate any provided configuration parameters:
   - If `min_pub_rand` is provided, ensure it is ≥ 1
   - If `max_msgs_per_interval` is provided, ensure it is ≥ 1
   - If `rate_limiting_interval` is provided, ensure it is ≥ 1
   - Use the same validation functions as during contract instantiation

3. **Storage Operations**: Update the contract configuration:
   - Load the current configuration from storage
   - Update only the fields that are provided (Some values)
   - Leave unchanged any fields that are None
   - Save the updated configuration to storage
   - Return success response

> **Note**: The `bsn_activation_height` and `finality_signature_interval` parameters are 
> immutable and cannot be updated after contract instantiation

**Usage Context:** This message allows the admin to modify operational
parameters without requiring contract migration, enabling fine-tuning of rate
limits, finality intervals, and other settings based on network conditions.

#### 4.8.5. AddToAllowlist (SHOULD)

**Message Structure:**
```rust
AddToAllowlist {
    fp_pubkey_hex_list: Vec<String>,
}
```

**Expected Behaviour:** Finality contracts SHOULD implement this administrative
handler with the following verification logic:

1. **Admin Authorization**: Verify that the caller is the current contract
   admin:
   - Query the current admin address
   - Verify that the message sender matches the current admin address

2. **Parameter Validation**: Validate the finality provider public keys:
   - Ensure the `fp_pubkey_hex_list` is not empty
   - For each key in the list, ensure it is not empty
   - If any key is empty, return `EmptyFpBtcPubKey` error

3. **Storage Operations**: Add the finality providers to the allowlist:
   - For each `fp_pubkey_hex` in the list:
     - Decode the parameter from hex string to bytes
     - Add the finality provider's BTC public key bytes to the allowlist storage
   - Return success response with action attributes indicating the number of
     providers added

#### 4.8.6. RemoveFromAllowlist (SHOULD)

**Message Structure:**
```rust
RemoveFromAllowlist {
    fp_pubkey_hex_list: Vec<String>,
}
```

**Expected Behaviour:** Finality contracts SHOULD implement this administrative
handler with the following verification logic:

1. **Admin Authorization**: Verify that the caller is the current contract
   admin:
   - Query the current admin address
   - Verify that the message sender matches the current admin address

2. **Parameter Validation**: Validate the finality provider public keys:
   - Ensure the `fp_pubkey_hex_list` is not empty
   - For each key in the list, ensure it is not empty
   - If any key is empty, return `EmptyFpBtcPubKey` error

3. **Storage Operations**: Remove the finality providers from the allowlist:
   - For each `fp_pubkey_hex` in the list:
     - Decode the parameter from hex string to bytes
     - Remove the finality provider's BTC public key bytes from the allowlist
       storage
   - Return success response with action attributes indicating the number of
     providers removed

#### 4.8.7. PruneData (SHOULD)

**Message Structure:**
```rust
PruneData {
    rollup_height: u64,
    max_signatures_to_prune: Option<u32>,
    max_pub_rand_values_to_prune: Option<u32>,
}
```

**Parameter Semantics:**
- `rollup_height`: Remove all data for rollup blocks with height ≤ this value.
- `max_signatures_to_prune`: Maximum number of finality signatures and
  signatories to prune in a single operation.
  - Since every signature has a corresponding signatory record, this limit
    applies to both.
  - If `None`, the default value is 50.
  - If `Some(0)`, disables pruning of finality signatures and signatories for
    this call.
- `max_pub_rand_values_to_prune`: Maximum number of public randomness values to
  prune in a single operation.
  - If `None`, the default value is 50.
  - If `Some(0)`, disables pruning of public randomness values for this call.

**Expected Behaviour:** Finality contracts SHOULD implement this administrative
handler with the following logic:

1. **Admin Authorization**: Verify that the caller is the current contract
   admin:
   - Query the current admin address
   - Verify that the message sender matches the current admin address

2. **Parameter Validation**: Validate pruning parameters:
   - Ensure `rollup_height` is reasonable (not excessively high)
   - Apply default limits if `None` provided (50 for both types)
   - Apply maximum limits to prevent gas exhaustion (100 for both types)

3. **Pruning Operations**: Remove old data for blocks with height ≤
   `rollup_height`:
   - **Finality Signatures**: Remove entries from `FINALITY_SIGNATURES` storage
     up to `max_signatures_to_prune` limit
   - **Signatories**: Remove entries from `SIGNATORIES_BY_BLOCK_HASH` storage up
     to the same limit (one-to-one correspondence with signatures)
   - **Public Randomness Values**: Remove entries from `PUB_RAND_VALUES` storage
     up to `max_pub_rand_values_to_prune` limit

4. **Response Attributes**: Return response with pruning statistics:
   - `pruned_signatures`: Number of finality signatures removed
   - `pruned_signatories`: Number of signatory entries removed
   - `pruned_pub_rand_values`: Number of public randomness values removed

**WARNING**: This operation is irreversible. The admin is responsible for
ensuring that the pruning height is safe and that no data is still being used
for the affected height range.

**Example Usage:**
```json
{
  "prune_data": {
    "rollup_height": 1000,
    "max_signatures_to_prune": 50,
    "max_pub_rand_values_to_prune": 20
  }
}
```

### 4.9. Contract State Storage

This section documents the actual state storage structure used by the finality
contract implementation.

#### 4.9.1. Core Configuration

**ADMIN**: Admin controller for contract administration
- Type: `Admin` (from cw-controllers)
- Storage key: `"admin"`
- Purpose: Manages contract administrative functions

**CONFIG**: Contract configuration settings
- Type: `Item<Config>`
- Storage key: `"config"`
- Structure:
  ```rust
  pub struct Config {
      pub bsn_id: String,
      pub min_pub_rand: u64,
      pub rate_limiting: RateLimitingConfig,
      pub bsn_activation_height: u64,
      pub finality_signature_interval: u64,
  }

  pub struct RateLimitingConfig {
      pub max_msgs_per_interval: u32,
      pub block_interval: u64,
  }
  ```

**ALLOWED_FINALITY_PROVIDERS**: Allowlist of finality providers
- Type: `SnapshotItem<HashSet<Vec<u8>>>`
- Storage key: `"allowed_finality_providers"`
- Checkpoints key: `"allowed_finality_providers__checkpoints"`
- Changelog key: `"allowed_finality_providers__changelog"`
- Strategy: `EveryBlock`
- Purpose: Stores the set of finality providers that are allowed to submit
  finality signatures and public randomness commitments
- Value: `HashSet<Vec<u8>>` containing BTC public key bytes
- Note: While the API accepts hex strings, the storage layer uses the decoded
  byte representation for efficiency.

#### 4.9.2. Rate Limiting Storage

**NUM_MSGS_LAST_INTERVAL**: Rate limiting counters per finality provider
- Type: `Map<&[u8], (u64, u32)>`
- Storage key: `"num_msgs_last_interval"`
- Key format: `fp_pubkey_bytes`
- Value format: `(interval_number, message_count)`
- Purpose: Tracks message count per finality provider within block intervals
- Automatic reset when interval changes

#### 4.9.3. Finality State Storage

**FINALITY_SIGNATURES**: Finality signatures by height and provider
- Type: `Map<(u64, &[u8]), FinalitySigInfo>`
- Storage key: `"finality_signatures"`
- Key format: `(block_height, fp_pubkey_bytes)`
- Purpose: Stores finality signature information including signature and block
  hash
- Structure:
  ```rust
  pub struct FinalitySigInfo {
      pub finality_sig: Vec<u8>,  // The EOTS finality signature
      pub block_hash: Vec<u8>,    // The block hash that the signature is for
  }
  ```

**SIGNATORIES_BY_BLOCK_HASH**: Voting aggregation by height and block hash
- Type: `Map<(u64, &[u8]), HashSet<String>>`
- Storage key: `"signatories_by_block_hash"`
- Key format: `(block_height, block_hash_bytes)`
- Purpose: Maps each (height, block_hash) combination to the set of finality
  provider public keys (hex-encoded) that voted for it

**HIGHEST_VOTED_HEIGHT**: Highest voted height tracking per finality provider
- Type: `Map<&[u8], u64>`
- Storage key: `"highest_voted_height"`
- Key format: `fp_pubkey_bytes`
- Purpose: Stores the highest rollup block height that each finality provider
  has voted on, enabling O(1) lookup for the `HighestVotedHeight` query
- **Automatic Maintenance**: This map is automatically updated whenever a
  finality signature is submitted

#### 4.9.4. Public Randomness Storage

**PUB_RAND_VALUES**: Individual public randomness values
- Type: `Map<(u64, &[u8]), Vec<u8>>`
- Storage key: `"pub_rand_values"`
- Key format: `(block_height, fp_pubkey_bytes)`
- Purpose: Stores individual public randomness values revealed during finality
  signature submission
- **Note**: Key format changed from `(&[u8], u64)` to `(u64, &[u8])` for
  efficient range queries in pruning operations

**PUB_RAND_COMMITS**: Public randomness commitments by finality provider
- Type: `Map<(&[u8], u64), PubRandCommit>`
- Storage key: `"pub_rand_commits"`
- Key format: `(fp_pubkey_bytes, start_height)`
- Purpose: Stores public randomness commitments made by finality providers
- Structure:
  ```rust
  pub struct PubRandCommit {
      pub start_height: u64,
      pub num_pub_rand: u64,
      pub interval: u64,
      pub babylon_epoch: u64,
      pub commitment: Vec<u8>,
  }
  ```
- **Sparse Generation Support**: The `interval` field enables sparse public randomness generation where public randomness values are available at heights: `start_height`, `start_height + interval`, `start_height + 2 * interval`, etc. This aligns with the `finality_signature_interval` to optimize storage and computation.

### 4.10. Finality contract queries

The finality contract query requirements are divided into core finality
functionality (MUST) and administrative functionality (SHOULD):

```rust
use cosmwasm_schema::{cw_serde, QueryResponses};
use cw_controllers::AdminResponse;
use std::collections::HashSet;

#[cw_serde]
pub struct BlockVoterInfo {
    pub fp_btc_pk_hex: String,
    pub pub_rand: Vec<u8>,
    pub finality_signature: FinalitySigInfo,
}

#[cw_serde]
#[derive(QueryResponses)]
pub enum QueryMsg {    
    // MUST: Core finality queries
    #[returns(Option<Vec<BlockVoterInfo>>)]
    /// `BlockVoters` the list of finality providers and their signatures for the
    /// specified block, if any.
    ///
    /// `height` is the block height to query voters for
    /// `hash_hex` is the block hash in hex format
    BlockVoters { height: u64, hash_hex: String },
    /// `FirstPubRandCommit` returns the first public random commitment (if any) for a given FP.
    ///
    /// `btc_pk_hex` is the BTC public key of the finality provider, in hex format.
    #[returns(Option<PubRandCommit>)]
    FirstPubRandCommit { btc_pk_hex: String },
    /// `LastPubRandCommit` returns the last public random commitment (if any) for a given FP.
    ///
    /// `btc_pk_hex` is the BTC public key of the finality provider, in hex format.
    #[returns(Option<PubRandCommit>)]
    LastPubRandCommit { btc_pk_hex: String },
    /// `ListPubRandCommit` returns a paginated list of public randomness 
    /// commitments for a given FP.
    ///
    /// `btc_pk_hex` is the BTC public key of the finality provider, in hex format.
    /// `start_after` is optional pagination parameter - only return commitments 
    /// with start_height > start_after.
    /// `limit` is optional limit on number of results (default 10, max 30).
    /// `reverse` is optional flag to reverse the order (default false = 
    /// ascending by start_height).
    #[returns(Vec<PubRandCommit>)]
    ListPubRandCommit { 
        btc_pk_hex: String, 
        start_after: Option<u64>, 
        limit: Option<u32>, 
        reverse: Option<bool> 
    },

    // SHOULD: Administrative queries
    #[returns(AdminResponse)]
    Admin {},
    #[returns(Config)]
    Config {},
    /// Get the list of all allowed finality providers.
    ///
    /// Returns a list of BTC public keys (in hex format) of finality providers
    /// that are allowed to submit finality signatures and public randomness commitments.
    #[returns(Vec<String>)]
    AllowedFinalityProviders {},
    /// Get the list of allowed finality providers at a specific Babylon height.
    ///
    /// Returns a list of BTC public keys (in hex format) that were allowed
    /// at the specified Babylon height or the most recent height before it.
    #[returns(Vec<String>)]
    AllowedFinalityProvidersAtHeight { babylon_height: u64 },
    /// `HighestVotedHeight` returns the highest rollup block height that the given finality provider has voted on.
    ///
    /// `btc_pk_hex` is the BTC public key of the finality provider, in hex format.
    /// Returns None if the finality provider has never submitted a finality signature.
    #[returns(Option<u64>)]
    HighestVotedHeight { btc_pk_hex: String },

}
```

#### 4.10.1. BlockVoters (MUST)

**Query Structure:**
```rust
BlockVoters {
    height: u64,         // Block height to query voters for
    hash_hex: String     // Block hash in hex format
}
```

**Return Type:** `Option<Vec<BlockVoterInfo>>` - List of finality providers and
their signatures for the specified block, or `None` if no votes found.

**Expected Behaviour:** Finality contracts MUST implement this query to return
the finality providers that voted for a specific block along with their complete
signature information:

1. Decode hash_hex from hex string to bytes
   - IF decode fails: RETURN error with `QueryBlockVoterError`

2. Query signatories storage using key `(height, hash_bytes)`
   - Access the stored set of finality provider public keys from
     `SIGNATORIES_BY_BLOCK_HASH`

3. For each finality provider in the set:
   - Query the `FINALITY_SIGNATURES` storage using key `(height,
     fp_pubkey_bytes)`
   - IF signature not found: RETURN error with `QueryBlockVoterError`
   - Query the `PUB_RAND_VALUES` storage using key `(fp_pubkey_bytes, height)`
   - IF public randomness not found: RETURN error with `QueryBlockVoterError`
   - Create `BlockVoterInfo` with `fp_btc_pk_hex`, `pub_rand`, and
     `FinalitySigInfo`

4. Return the list of BlockVoterInfo
   - IF no votes found: RETURN `None`
   - IF votes exist: RETURN `Some(Vec<BlockVoterInfo>)` with all voter
     information

WHERE `BlockVoterInfo` contains:
- `fp_btc_pk_hex`: `String` - The finality provider's BTC public key in hex
  format
- `pub_rand`: `Vec<u8>` - The public randomness value for the block
- `finality_signature`: `FinalitySigInfo` - Complete signature information
  including signature and block hash

#### 4.10.2. FirstPubRandCommit (MUST)

**Query Structure:**
```rust
FirstPubRandCommit {
    btc_pk_hex: String    // BTC public key of the finality provider in hex format
}
```

**Return Type:** `Option<PubRandCommit>` - The first public randomness
commitment or None if not found

**Expected Behaviour:** Finality contracts MUST implement this query to return
the first public randomness commitment for a given finality provider:

1. Query public randomness commitments storage with prefix `btc_pk_hex`
   - Search for all commitments belonging to this finality provider

2. Sort commitments by `start_height` in ascending order
   - Find the commitment with the lowest `start_height`

3. Return the first commitment
   - IF no commitments found: RETURN `None`
   - IF commitments exist: RETURN `Some(first_commitment)`

WHERE `PubRandCommit` contains:
- `start_height`: `u64` - The height of the first commitment
- `num_pub_rand`: `u64` - The amount of committed public randomness
- `interval`: `u64` - The interval between consecutive pub rand values (enables sparse generation)
- `babylon_epoch`: `u64` - The epoch number when the commitment was submitted
- `commitment`: `Vec<u8>` - The commitment value (Merkle root)

#### 4.10.3. LastPubRandCommit (MUST)

**Query Structure:**
```rust
LastPubRandCommit {
    btc_pk_hex: String    // BTC public key of the finality provider in hex format
}
```

**Return Type:** `Option<PubRandCommit>` - The last public randomness commitment
or `None` if not found

**Expected Behaviour:** Finality contracts MUST implement this query to return
the last public randomness commitment for a given finality provider:

1. Query public randomness commitments storage with prefix `btc_pk_hex`
   - Search for all commitments belonging to this finality provider

2. Sort commitments by `start_height` in descending order
   - Find the commitment with the highest `start_height`

3. Return the last commitment
   - IF no commitments found: RETURN `None`
   - IF commitments exist: RETURN `Some(last_commitment)`

WHERE `PubRandCommit` contains:
- `start_height`: `u64` - The height of the first commitment
- `num_pub_rand`: `u64` - The amount of committed public randomness
- `interval`: `u64` - The interval between consecutive pub rand values (enables sparse generation)
- `babylon_epoch`: `u64` - The epoch number when the commitment was submitted
- `commitment`: `Vec<u8>` - The commitment value (Merkle root)

#### 4.10.4. ListPubRandCommit (MUST)

**Query Structure:**
```rust
ListPubRandCommit {
    btc_pk_hex: String,         // BTC public key of the finality provider
    start_after: Option<u64>,   // Pagination: start_height > start_after
    limit: Option<u32>,         // Limit results (default 10, max 30)
    reverse: Option<bool>,      // Reverse order (default false)
}
```

**Return Type:** `Vec<PubRandCommit>` - A paginated list of public randomness
commitments, or empty vector if none found

**Expected Behaviour:** Finality contracts MUST implement this query to return a
paginated list of public randomness commitments for a given finality provider:

1. Query public randomness commitments storage with prefix `btc_pk_hex`
   - Search for all commitments belonging to this finality provider
   - Apply pagination using `start_after` as exclusive boundary if provided

2. Apply sorting and limiting
   - Sort commitments by `start_height` in ascending order (or descending if
     `reverse=true`)
   - Limit results to the specified limit (default 10, max 30)

3. Return the paginated results
   - IF no commitments found: RETURN empty vector
   - IF commitments exist: RETURN `Vec<PubRandCommit>` with matching commitments

WHERE `PubRandCommit` contains:
- `start_height`: `u64` - The height of the first commitment
- `num_pub_rand`: `u64` - The amount of committed public randomness
- `interval`: `u64` - The interval between consecutive pub rand values (enables sparse generation)
- `babylon_epoch`: `u64` - The epoch number when the commitment was submitted
- `commitment`: `Vec<u8>` - The commitment value (Merkle root)

#### 4.10.5. Admin (SHOULD)

**Query Structure:**
```rust
Admin {}    // No parameters required
```

**Return Type:** `AdminResponse` - Contains the current admin address

**Expected Behaviour:** Finality contracts SHOULD implement this administrative
query to return the current admin address:

1. Query admin storage to retrieve current admin address
   - Access the stored admin address value

2. Return admin information
   - Return AdminResponse containing the admin address
   - IF no admin set: RETURN `None`

WHERE AdminResponse contains:
- `admin`: `Option<String>`

#### 4.10.6. Config (SHOULD)

**Query Structure:**
```rust
Config {}    // No parameters required
```

**Return Type:** `Config` - Contract configuration settings

**Expected Behaviour:** Finality contracts SHOULD implement this administrative
query to return the contract configuration:

1. Query configuration storage to retrieve current settings
   - Access all stored configuration parameters

2. Return configuration information
   - Return `Config` struct with all configuration values
   - All configuration fields should be populated

WHERE Config contains:
- `bsn_id`: `String` - The BSN identifier for this finality contract
- `min_pub_rand`: `u64` - Minimum public randomness requirement for commitments
- `rate_limiting`: `RateLimitingConfig` - Rate limiting configuration including
  `max_msgs_per_interval` and `block_interval`

#### 4.10.7. AllowedFinalityProviders (SHOULD)

**Query Structure:**
```rust
AllowedFinalityProviders {}    // No parameters required
```

**Return Type:** `Vec<String>` - List of BTC public keys (in hex format) of
allowed finality providers

**Expected Behaviour:** Finality contracts SHOULD implement this administrative
query to return the list of all allowed finality providers:

1. Query allowlist storage to retrieve all allowed finality providers
   - Access all entries in the `ALLOWED_FINALITY_PROVIDERS` storage

2. Return allowlist information
   - Return a vector of BTC public keys (in hex format) for all allowed finality
     providers
   - If no finality providers are in the allowlist, return an empty vector

WHERE the return value contains:
- `Vec<String>` - List of BTC public keys in hex format for all allowed finality
  providers

#### 4.10.8. AllowedFinalityProvidersAtHeight (SHOULD)

**Query Structure:**
```rust
AllowedFinalityProvidersAtHeight {
    babylon_height: u64    // Babylon height to query allowlist at
}
```

**Return Type:** `Vec<String>` - List of BTC public keys (in hex format) of
allowed finality providers at the specified Babylon height

**Expected Behaviour:** Finality contracts SHOULD implement this administrative
query to return the list of allowed finality providers at a specific Babylon
height:

1. Query allowlist storage at the specified Babylon height
   - Retrieve the allowlist state at `babylon_height`

2. Return allowlist information
   - Return a vector of BTC public keys (in hex format) for all allowed finality
     providers at the specified height
   - If no finality providers were in the allowlist at that height, return an
     empty vector

WHERE the return value contains:
- `Vec<String>` - List of BTC public keys in hex format for all allowed finality
  providers at the specified Babylon height

#### 4.10.9. HighestVotedHeight (SHOULD)

**Query Structure:**
```rust
HighestVotedHeight {
    btc_pk_hex: String    // BTC public key of the finality provider in hex format
}
```

**Return Type:** `Option<u64>` - The highest rollup block height that the given
finality provider has voted on, or `None` if the finality provider has never
submitted a finality signature.

**Expected Behaviour:** Finality contracts SHOULD implement this query to return
the highest rollup block height that a given finality provider has voted on:

1. Decode the `btc_pk_hex` parameter from hex string to bytes
   - This provides the finality provider's BTC public key bytes for storage lookup

2. Query the `HIGHEST_VOTED_HEIGHT` storage using the decoded BTC public key bytes
   - This dedicated map is automatically maintained when finality signatures are submitted
   - Provides efficient lookup without iterating through all finality signatures

3. Return the highest voted height
   - IF no entry found: RETURN `None` (the finality provider has never voted)
   - IF entry exists: RETURN `Some(height)` with the stored highest voted height

## 5. Implementation status

### 5.1. Babylon implementation status

The interfaces in this specification have been fully implemented in the [Babylon
codebase](https://github.com/babylonlabs-io/babylon) (`main` branch). This
includes all required message types, queries, and expected behaviors for
finality contract integration.

### 5.2. Finality contract implementation status

As of this writing, there are two known implementations of finality contracts
that integrate with Babylon's Bitcoin staking protocol:

1. **Rollup BSN Contracts** - Available at
   [babylonlabs-io/rollup-bsn-contracts](https://github.com/babylonlabs-io/rollup-bsn-contracts).
   This implementation is a CosmWasm smart contract designed to integrate OP
   Stack rollups with Babylon's Bitcoin staking protocol. The contract is
   actively developed and maintained by Babylon Labs. This implementation
   follows the specification outlined in this document and includes support for
   contract migration to enable production upgrades.

2. **BLITZ** - Available at
   [alt-research/blitz](https://github.com/alt-research/blitz). This
   implementation provides fast finality for Arbitrum Orbit chains using
   Babylon's Bitcoin staking protocol. BLITZ includes both the finality contract
   (`nitro-finality-gadget`) and support infrastructure for Arbitrum Orbit
   integration. The project is developed and maintained by AltLayer.

**Comparison**: While both implementations follow the general principles
outlined in this specification, they target different rollup architectures. The
OP Finality Gadget is specifically designed for OP Stack chains and leverages
CosmWasm for deployment on Babylon, whereas BLITZ focuses on Arbitrum Orbit
chains and includes additional infrastructure components for the Nitro-based
architecture.
<!-- TODO: add Manta contract after open-source -->
