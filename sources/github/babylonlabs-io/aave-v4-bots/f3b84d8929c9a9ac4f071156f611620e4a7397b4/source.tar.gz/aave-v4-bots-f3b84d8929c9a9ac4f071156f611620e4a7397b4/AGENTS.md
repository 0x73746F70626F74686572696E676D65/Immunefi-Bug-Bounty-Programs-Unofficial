# AGENTS.md

This file provides guidance any agent when working with code in this repository.

## Commands

pnpm workspace (pnpm 9.13.2). `packages/*` + `services/*`.

```bash
pnpm install

pnpm check                  # biome: lint + format + import sort — THIS is the gate CI runs
pnpm check:fix              # autofix
pnpm typecheck              # tsc across all packages + services

pnpm test                   # vitest, all workspaces
pnpm --filter @repo/engine test                              # one package
pnpm --filter @repo/engine test src/arbitrage/engine.test.ts # one file
pnpm --filter @repo/engine test -- -t "substring of name"    # one test (note the `--`)
```

The `--` matters: without it pnpm swallows `-t` and the whole suite runs while appearing to have
filtered. A working filter reports the non-matching tests as *skipped*.

`pnpm lint` exists but only runs the linter — CI runs `pnpm check`, which also enforces
formatting and import order. Use `check`.

Solidity lives here too (`contracts/`, `test/`), so the Foundry gates are part of CI as well:

```bash
forge build
forge fmt --check                                    # CI gate; `forge fmt` to fix
SEPOLIA_RPC=<url> forge test --match-path 'test/fork/**'   # fork tests, pinned blocks
```

The fork tests pin their blocks (`test/fork/base/TestSuites.sol`), so after the first run foundry
serves them from `~/.foundry/cache/rpc` and the RPC is not called again — which is what makes them
cheap enough to gate on.

Running a bot locally needs its database and indexer first:

```bash
pnpm arbitrageur:db:up && pnpm arbitrageur:indexer   # ports 5433 / 42070
pnpm arbitrageur:run
pnpm liquidator:db:up && pnpm liquidator:indexer     # ports 5432 / 42069
pnpm liquidator:run
```

### E2E

`scripts/e2e-local.sh` boots docker (postgres, bitcoin regtest), anvil, deploys the protocol from
the `lib/tbv-contracts/` submodule, starts the real bot processes, and tears everything down on exit. It
needs `foundry` and docker. Suites are selected with `SUITE` (default `liquidator`):

```bash
E2E_FORK_URL=https://sepolia.gateway.tenderly.co ./scripts/e2e-local.sh  # liquidator (default) — needs a fork
SUITE=arbitrageur ./scripts/e2e-local.sh              # one bot, both engines
SUITE=manual-arbitrageur ./scripts/e2e-local.sh       # keyless MANUAL mode + operator-cli
SUITE=stress-arbitrageur ./scripts/e2e-local.sh       # mass-liquidation + nonce chaos
KEEP_DEPS=1 ./scripts/e2e-local.sh                    # reuse running postgres/btc/anvil
```

The **liquidator** suite is the only one that needs `E2E_FORK_URL`, and the script refuses to start
without it. It runs flash-funded against the *real* UniswapV4 and Morpho deployments rather than
mocks, which exist only on a fork; the protocol itself is still deployed fresh, so the suite keeps
admin over the price feed and tokens. The fork block is pinned, so foundry serves it from
`~/.foundry/cache/rpc` after the first run. Every other suite is inventory-funded on a bare chain —
between them the two funding modes are both covered.

Forge scripts here need `FOUNDRY_PROFILE=e2e` (it enables `ffi`, which the suite uses to manage
bot processes). The stress suite's knobs and assertions are documented in the README.

## Architecture

**Package-per-concern monorepo.** Each `@repo/*` package owns one concern; `services/*` are thin
composition roots that wire packages together, own their env parsing and metrics, and run a poll
loop. Pipeline logic lives in `@repo/engine`, whose decision math is pure and unit-tested in
isolation; every IO concern (signing, secrets, nonces, RPC, persistence) sits behind its own
package and seam, so swapping a local key for AWS KMS is a config change with no engine edit.

**Two bots, one shared pipeline.** `@services/liquidator` runs only `LiquidationEngine`.
`@services/arbitrageur` always runs `ArbitrageEngine` and *additionally* runs the same
`LiquidationEngine` when `ADAPTER_ADDRESS` + `LENS_ADDRESS` are set. They cooperate through
BTCVaultSwap (the LLP): a liquidator calls `liquidateWithLLP`, which escrows the seized vault and
pays the liquidator WBTC at a discount; an arbitrageur later buys that escrowed vault. So the
liquidator produces exactly what the arbitrageur consumes.

**One of each, per process — this is the source of most subtlety.** `@repo/runtime`'s
`startRuntime` builds exactly one `Executor`, one `RiskGate`, and one nonce allocator, injected
into *every* engine the process runs. In the dual-engine arbitrageur that means both engines share
a signer, a nonce sequence, a token balance, and a kill switch: a breaker trip halts both, a failed
send in one engine burns a nonce the other is queued behind, and both spend the same WBTC. When
changing either engine, consider what it does to the other.

**The Executor seam** (`packages/engine/src/shared/executor.ts`) is how AUTO and MANUAL share one
pipeline. `commit()` either signs+broadcasts under the shared nonce lock (AUTO) or writes a
content-hashed proposal for `operator-cli` to sign (MANUAL). Engines hold an `Executor`, never a
raw signer. `commit()` deliberately does **not** settle the risk slot — the engine owns that on
every exit path.

**Engine cycle shape.** Both engines: reconcile in-flight intents against the chain → resync
nonces → publish token balances to the gate → fetch candidates → *send all* → batch-wait every
receipt with `Promise.allSettled` → classify and settle. Sending and receipt-waiting are separate
phases on purpose; awaiting each receipt inline serialises the batch.

### Risk gate outcomes

`packages/risk` is a synchronous admission control: `openSlot(action)` reserves exposure plus the
action's declared token `spend`, and returns a `RiskSlot` the caller owes exactly one `settle()`
(idempotent, with `settleUnfinished` as a `finally` backstop). The outcome taxonomy carries real
weight and is easy to get wrong — the breaker exists to stop the bot when **the chain is rejecting
us**, so anything that isn't that evidence must stay off it:

| outcome | meaning | breaker | token ledger |
|---|---|---|---|
| `ok: true` | confirmed | resets streak | spent |
| `abandoned` | nothing was broadcast (duplicate, gas-estimate revert, MANUAL proposal) | exempt | released |
| `contended` | broadcast, reverted, but a competitor already took the subject | exempt | released (a revert transfers nothing) |
| `unresolved` | broadcast, receipt never arrived — fate unknown | exempt | counted as spent |
| `ok: false` | genuine failure | **feeds breaker** | released |

`contended` and `unresolved` are breaker-exempt but deliberately do **not** reset the failure
streak. Misclassifying a real failure as one of these hides it from the breaker, which is the
dangerous direction; the reverse is merely noisy.

The gate also reserves token spend so concurrent engines can't both judge the same balance
sufficient and together overdraw the signer. It fails closed on a token it has no balance for, so
an engine declaring `spend` must publish balances via `setAvailable` each cycle.

## Conventions

- Comments explain **why**, not what. The codebase is deliberately heavy on rationale where
  behaviour is non-obvious or was chosen over a plausible alternative. Match that register; don't
  narrate the code.
- Comments describe the code as it is — never what changed, was removed, or used to be there.
- `docs/` holds design docs, RFCs, and test plans, some of which are uncommitted work in progress.
  Do not cite `docs/*.md` filenames or section numbers from code, tests, or scripts.
- Two contract trees, and they are not the same thing. `contracts/` is **ours** — `LiquidationRouter`
  and its swap venues, which back flash funding; edit and build it here. `lib/tbv-contracts/` is the
  protocol submodule (Babylon's `vault-contracts-aave-v4`), excluded from biome and not ours to
  edit; the e2e compiles and deploys it. ABIs for both are hand-maintained in `@repo/abis`, and
  `packages/abis/src/artifacts.test.ts` pins every one of them to `forge build` output, so a
  submodule bump that changes a signature fails that test rather than a bot at runtime. Deployment
  addresses come from env.
- `foundry.lock` pins a `rev` for each `lib/` submodule. A submodule bump moves only the gitlink,
  so set the matching `rev` in the same commit. Take it from `git ls-tree HEAD lib/<dep>`, not from
  the checked-out submodule, which can be left over from another branch. The Docker images never
  read the lock, but `forge install` and `forge update` do, so a stale lock builds the contracts at
  the wrong commit on a fresh clone.
- Everything risky is opt-in and off by default (KMS, Postgres persistence, code-hash guard, kill
  switch, every `RISK_*` guard), so a minimal deployment behaves like a plain keeper. Preserve
  that: a new guard should be inert until its env var is set.
- The e2e bash suites run under `set -euo pipefail`. Two failure modes have bitten repeatedly:
  unguarded command substitutions (`grep -c` exits 1 on no match), and assertions that pass
  vacuously — a drain that reads zero both before work is indexed and after it completes proves
  nothing. Assert against counts that only move one way.
