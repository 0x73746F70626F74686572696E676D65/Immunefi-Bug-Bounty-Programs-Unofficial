import { adapterAbi, spokeAbi } from "@repo/abis";
import type { Logger } from "@repo/logger";
import type { Address, PublicClient } from "viem";
import { isBorrowableReserve } from "./domain";

/**
 * One Spoke reserve, at the id the protocol knows it by.
 *
 * The id is the whole point of this type. `AaveAdapterLiquidationPreview.estimateLiquidation`
 * returns repay amounts paired with the reserve ids they belong to, and the adapter pulls each in
 * that reserve's underlying. A list of *tokens* cannot express that mapping, which is why nothing
 * that has to name the token behind an amount may work from a filtered list.
 */
export interface SpokeReserve {
  /** Reserve id — what `estimateLiquidation` pairs each of its amounts with. */
  id: number;
  /** The ERC-20 the adapter pulls for this reserve. */
  token: Address;
  /**
   * Whether a borrower may take new debt here, as of the read this came from.
   *
   * `updateReserveConfig` can flip it without the reserve count moving, which is why the list is
   * read afresh each cycle rather than cached: a reserve that became borrowable is one whose token
   * the signer must now hold and approve, and a stale `false` costs every liquidation that owes it.
   *
   * The flag restricts borrowing only. The adapter repays existing debt with a plain `transferFrom`
   * and takes vaultBTC collateral, so debt on a reserve that is no longer borrowable is still
   * liquidatable by anyone holding the token. That is why inventory follows `repayable`.
   */
  borrowable: boolean;
  /**
   * Whether a borrower can owe this reserve: it is borrowable, or it still carries debt
   * (`getReserveTotalDebt > 0`). It decides *inventory* — what to hold and approve. A collateral
   * reserve carries no debt, so it stays out.
   */
  repayable: boolean;
}

/**
 * Every reserve the Spoke lists, in id order — the id space `estimateLiquidation` speaks in.
 *
 * Dense and complete by construction: `Spoke.addReserve` assigns `reserveId = _reserveCount++` and
 * writes the reserve once, so ids run `0..count-1`, are never reused, and a reserve's underlying
 * never changes after creation. `id → token` is therefore stable for the life of a deployment;
 * `borrowable` is not, and neither is the length.
 */
export interface SpokeReserves {
  /** The Spoke the adapter is wired to, read from the adapter rather than configured. */
  spoke: Address;
  /** Index i is reserve id i. */
  reserves: readonly SpokeReserve[];
}

/**
 * Ceiling on how many reserves this will enumerate.
 *
 * `getReserveCount` is a number read from an address the operator configured, and everything after
 * it is a loop. Point `ADAPTER_ADDRESS` at the wrong contract and the answer can be any 256-bit
 * value — which is not a slow boot, it is a process that allocates until it dies, before it has
 * logged anything an operator could act on. A Spoke listing more than this is not a deployment
 * anyone runs; refusing it names the misconfiguration instead.
 */
export const MAX_SPOKE_RESERVES = 256n;

/** The distinct tokens a borrower can owe — what an inventory-funded bot must hold and approve. */
export function repayableTokens(topology: SpokeReserves): Address[] {
  const seen = new Set<string>();
  const tokens: Address[] = [];
  for (const reserve of topology.reserves) {
    if (!reserve.repayable) continue;
    const k = reserve.token.toLowerCase();
    // Two reserves can share an underlying (same token on a different hub), and the balance and
    // allowance behind them are one and the same.
    if (seen.has(k)) continue;
    seen.add(k);
    tokens.push(reserve.token);
  }
  return tokens;
}

/** Every distinct reserve token, borrowable or not. */
export function reserveTokens(topology: SpokeReserves): Address[] {
  const seen = new Set<string>();
  const tokens: Address[] = [];
  for (const reserve of topology.reserves) {
    const k = reserve.token.toLowerCase();
    if (seen.has(k)) continue;
    seen.add(k);
    tokens.push(reserve.token);
  }
  return tokens;
}

/**
 * Enumerate the Spoke's reserves — boot-time chain discovery, not engine policy, so it reads as a
 * function rather than a method.
 *
 * Returns **every** reserve rather than the borrowable subset it used to, because two different
 * questions are asked of this: *"what can I be asked to pay?"* (the repayable tokens — approvals,
 * balances) and *"which token is this amount denominated in?"* (the reserve at that id). The second
 * cannot be answered from the first, and answering it from a filtered list is wrong the moment a
 * non-borrowable reserve sorts before a borrowable one — silently, in the direction of declaring
 * one token's outflow against another's balance.
 */
export async function discoverSpokeReserves(deps: {
  publicClient: PublicClient;
  adapterAddress: Address;
  logger: Logger;
  /** Resolved per reserve purely so the log names the token rather than an address. */
  tokenSymbol: (token: Address) => Promise<string>;
  /** The list this replaces, if any. Logging is silent unless it differs — this runs every cycle. */
  previous?: SpokeReserves;
}): Promise<SpokeReserves> {
  const { publicClient, adapterAddress, logger, tokenSymbol, previous } = deps;

  const spoke = await publicClient.readContract({
    address: adapterAddress,
    abi: adapterAbi,
    functionName: "BTC_VAULT_CORE_SPOKE",
  });

  const reserveCount = await publicClient.readContract({
    address: spoke,
    abi: spokeAbi,
    functionName: "getReserveCount",
  });
  if (reserveCount > MAX_SPOKE_RESERVES) {
    throw new Error(
      `Spoke ${spoke} reports ${reserveCount} reserves, past the ${MAX_SPOKE_RESERVES} this bot will enumerate — check that ADAPTER_ADDRESS points at the AaveAdapter for this deployment`
    );
  }
  const reserves: SpokeReserve[] = [];
  for (let i = 0n; i < reserveCount; i++) {
    const reserve = await publicClient.readContract({
      address: spoke,
      abi: spokeAbi,
      functionName: "getReserve",
      args: [i],
    });
    const borrowable = isBorrowableReserve(reserve.flags);
    // Debt is read only when the flag is clear: a borrowable reserve is repayable either way.
    const repayable =
      borrowable ||
      (await publicClient.readContract({
        address: spoke,
        abi: spokeAbi,
        functionName: "getReserveTotalDebt",
        args: [i],
      })) > 0n;
    reserves.push({ id: Number(i), token: reserve.underlying, borrowable, repayable });
  }

  const topology = { spoke, reserves };
  if (!sameReserves(previous, topology)) {
    logger.info(`Spoke ${spoke} lists ${reserveCount} reserve(s):`);
    for (const reserve of reserves) {
      logger.info(
        `  Reserve ${reserve.id}: ${await tokenSymbol(reserve.token)} (${reserve.token})${
          reserve.borrowable
            ? " - borrowable"
            : reserve.repayable
              ? " - not borrowable, still owed"
              : ""
        }`
      );
    }
    if (reserves.every((reserve) => !reserve.borrowable)) {
      logger.warn("No borrowable reserves found on Spoke");
    }
  }
  return topology;
}

/** Whether two reads describe the same Spoke in the same state — ids, tokens, flags and debt alike. */
function sameReserves(a: SpokeReserves | undefined, b: SpokeReserves): boolean {
  if (!a || a.spoke !== b.spoke || a.reserves.length !== b.reserves.length) return false;
  return a.reserves.every((reserve, i) => {
    const other = b.reserves[i];
    return (
      reserve.token === other.token &&
      reserve.borrowable === other.borrowable &&
      reserve.repayable === other.repayable
    );
  });
}
