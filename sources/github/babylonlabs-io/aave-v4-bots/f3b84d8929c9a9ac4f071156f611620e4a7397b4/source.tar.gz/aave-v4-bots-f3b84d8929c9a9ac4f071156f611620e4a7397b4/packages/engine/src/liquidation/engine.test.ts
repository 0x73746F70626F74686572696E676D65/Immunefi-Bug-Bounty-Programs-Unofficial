import {
  type NonceAllocator,
  PreBroadcastError,
  createNonceAllocator,
  createNonceLease,
} from "@repo/execution";
import type { Logger } from "@repo/logger";
import type { NotificationEvent, Notifier } from "@repo/notifications";
import { type MemoryStateStore, type StateStore, createMemoryStateStore } from "@repo/persistence";
import { createRiskGate } from "@repo/risk";
import { type PublicClient, TransactionReceiptNotFoundError, maxUint256 } from "viem";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { createManualExecutor } from "../shared/executor";
import { createAutoExecutorWithSender } from "../shared/executorTestKit";
import { createIndexerClient } from "../shared/indexerClient";
import { LENS_ESTIMATE_CHUNK, MAX_LIQUIDATION_CANDIDATES } from "./domain";
import { LiquidationEngine, type LiquidationEngineConfig } from "./engine";
import type { LiquidatablePosition } from "./types";

/**
 * The indexer as these tests drive it: a real client bound to a dummy base, so the existing
 * `global.fetch` mocks (and the failure cases that reject) still exercise the same path.
 */
const INDEXER_STUB = {
  ...createIndexerClient({ baseUrl: "http://indexer", retry: { maxAttempts: 1 } }),
  // The guard is unconfigured in these tests, which is the state it reports as "go ahead".
  ok: async () => true,
};

// Stub metrics port — the engine reports through it; tests assert on it directly.
// Recreated per test so call counts don't leak between cases.
function createMetrics() {
  return {
    recordPositionsChecked: vi.fn(),
    recordPositionsLiquidatable: vi.fn(),
    recordLiquidationSuccess: vi.fn(),
    recordLiquidationFailed: vi.fn(),
    recordSimulationFailed: vi.fn(),
    recordError: vi.fn(),
    recordPollDuration: vi.fn(),
    recordTokenBalance: vi.fn(),
  };
}
const silentLogger: Logger = { debug: vi.fn(), info: vi.fn(), warn: vi.fn(), error: vi.fn() };

let metrics: ReturnType<typeof createMetrics>;

const ZERO_BYTES32 =
  "0x0000000000000000000000000000000000000000000000000000000000000000" as `0x${string}`;

const mockReserveIds = [0n] as const;
const mockAmounts = [1000000n] as const;
/** The fairness payment the preview quotes; buffered like the debt before it becomes the cap. */
const mockWbtcPayment = 5000n;

const mockPosition: LiquidatablePosition = {
  proxyAddress: "0x1234567890123456789012345678901234567890",
  borrower: "0x000000000000000000000000000000000000b0b1",
  debtReserveIds: ["0"],
  debtToCoverAmounts: ["1000000"],
  vaultId: "0xvault1",
  suppliedShares: "1000000000",
};

/** The adapter's borrower → proxy mapping for the positions these tests feed. */
const PROXY_OF: Record<string, string> = {
  [mockPosition.borrower.toLowerCase()]: mockPosition.proxyAddress,
  "0x000000000000000000000000000000000000b0b2": "0xabcdefabcdefabcdefabcdefabcdefabcdefabcd",
  "0x000000000000000000000000000000000000b0b3": "0xfeedfeedfeedfeedfeedfeedfeedfeedfeedfeed",
};

/**
 * A `TxSender` that skips real signing but honors the contract that matters: `onSigned` (the
 * durable nonce + hash record) runs BEFORE the broadcast resolves, so crash-safety tests
 * exercise the same ordering as the real sender. Carries an `identity` like a real sender — the
 * engine reads `sender.identity` for the intent's chain id and the simulation `from`.
 */
function mockSender(identity = { from: "0xliquidator" as `0x${string}`, chainId: 31337 }) {
  return {
    identity,
    send: vi.fn(
      async (
        call: { nonce?: number },
        onSigned?: (tx: {
          hash: `0x${string}`;
          nonce: number;
          serialized: `0x${string}`;
        }) => Promise<void>
      ) => {
        await onSigned?.({ hash: "0xtxhash", nonce: call.nonce ?? 0, serialized: "0xraw" });
        return "0xtxhash" as `0x${string}`;
      }
    ),
  };
}

/**
 * Replace the answer for ONE `readContract` function, leaving every other read at its default.
 *
 * Overriding the whole implementation is how these tests go wrong quietly: an override that omits
 * `adapter`, `spoke` or `getReserveCount` makes boot throw, so the cycle sends nothing at all — and
 * a test asserting the breaker did NOT trip then passes without ever having liquidated anything.
 */
function overrideRead(
  clients: ReturnType<typeof createMockClients>,
  functionName: string,
  value: unknown
): void {
  const base = clients.publicClient.readContract.getMockImplementation();
  if (!base) throw new Error("readContract has no default implementation to fall back to");
  clients.publicClient.readContract.mockImplementation((args: { functionName: string }) =>
    args.functionName === functionName ? Promise.resolve(value) : base(args)
  );
}

function createMockClients() {
  return {
    sender: mockSender(),
    walletClient: {
      account: { address: "0xliquidator" as `0x${string}` },
      // A real `WalletClient<Transport, Chain, Account>` always has a chain; the engine reads
      // `chain.id` for the intent's idempotency key.
      chain: { id: 31337 },
      writeContract: vi.fn().mockResolvedValue("0xtxhash"), // approvals only
    },
    publicClient: {
      simulateContract: vi.fn().mockResolvedValue({ result: true }),
      readContract: vi
        .fn()
        .mockImplementation(
          ({ functionName, args }: { functionName: string; args?: unknown[] }) => {
            // One borrowable reserve, matching `mockAmounts` — the engine refuses to attribute a spend
            // when the Lens vector and the Spoke's reserve list disagree in length. The Lens reports
            // the adapter and Spoke it was built for; `prepare()` refuses a pair that disagrees.
            if (functionName === "adapter") return Promise.resolve("0xadapter");
            if (functionName === "spoke") return Promise.resolve("0xspoke");
            if (functionName === "BTC_VAULT_CORE_SPOKE") return Promise.resolve("0xspoke");
            if (functionName === "getReserveCount")
              return Promise.resolve(BigInt(mockAmounts.length));
            if (functionName === "getReserve") {
              return Promise.resolve({ flags: 0x04, underlying: "0xdebt" });
            }
            if (functionName === "estimateLiquidation") {
              // [debtReserveIds, debtToCoverAmounts, wbtcPayment, vaultId, amountCollateralToSeize] —
              // wbtcPayment is the WBTC the adapter pulls from msg.sender for fairness + redemption
              // fee, and doubles as the `maxWbtcPayment` cap on the call.
              return Promise.resolve([
                mockReserveIds,
                mockAmounts,
                mockWbtcPayment,
                "0xvault1",
                0n,
              ]);
            }
            // Default: the position still holds collateral, so a reverted liquidation reads as a genuine
            // failure (a lost-race test overrides this with totalCollateralBTC 0n).
            if (functionName === "getPosition") {
              return Promise.resolve({
                vaultIds: ["0xvault1"],
                totalCollateralBTC: 1000n,
                proxyContract:
                  PROXY_OF[String(args?.[0]).toLowerCase()] ?? mockPosition.proxyAddress,
              });
            }
            // Already approved, so the cycle's `refreshInventory` sends nothing and each test measures
            // the liquidation it is about. Genuinely unlimited: inventory funding asks for
            // `maxUint256 / 2`, so a merely large number would still trigger an approval. The tests
            // that DO cover approvals override this with a zero allowance.
            if (functionName === "allowance") return Promise.resolve(2n ** 256n - 1n);
            return Promise.resolve(BigInt("1000000000000000000"));
          }
        ),
      getTransactionCount: vi.fn().mockResolvedValue(0),
      getBlockNumber: vi.fn().mockResolvedValue(1n),
      // Reconcile asks for receipts. The default answer is viem's "not mined yet" signal — a
      // *typed* error, not a bare throw: `getReceiptStatus` only reads this one as "no receipt",
      // and propagates anything else (an RPC outage must never look like "not mined").
      getTransactionReceipt: vi
        .fn()
        .mockRejectedValue(new TransactionReceiptNotFoundError({ hash: "0xtxhash" })),
      // Reconcile also asks whether the node knows the tx at all: here it was broadcast, so
      // it does (in flight). Returning "unknown" would read as a rejected broadcast.
      getTransaction: vi.fn().mockResolvedValue({ hash: "0xtxhash" }),
      waitForTransactionReceipt: vi
        .fn()
        .mockResolvedValue({ status: "success", blockNumber: 123n, logs: [] }),
    },
  };
}

/**
 * A pre-seeded pass-through allocator: hands out nonce 0 and treats `resync` as a no-op. For tests
 * that drive a send path directly (e.g. `prepare`) without a `run()` to seed the lease from
 * the chain; `run()`-based tests keep the default real allocator, seeded from `getTransactionCount`.
 */
const passthroughNonces = (): NonceAllocator => ({
  withNonce: (send) => send(0),
  resync: async () => {},
});

type AutoDeps = Parameters<typeof createAutoExecutorWithSender>[0];

/**
 * Build the engine with a default AUTO executor over the mock wallet + sender (the composition the
 * `@repo/runtime` root does in production), unless a test injects its own `executor` (e.g. a keyless
 * `ManualExecutor`). `store`/`nonces` steer the executor's crash-safety + nonce plumbing.
 */
function createBot(
  clients: ReturnType<typeof createMockClients>,
  overrides: Partial<LiquidationEngineConfig> & {
    store?: StateStore;
    nonces?: NonceAllocator;
  } = {}
): LiquidationEngine {
  const { store, nonces, executor, ...engineOverrides } = overrides;
  return new LiquidationEngine({
    publicClient: clients.publicClient as unknown as LiquidationEngineConfig["publicClient"],
    adapterAddress: "0xadapter" as `0x${string}`,
    lensAddress: "0xlens" as `0x${string}`,
    wbtcAddress: "0xwbtc" as `0x${string}`,
    btcRedeemKey: ZERO_BYTES32,
    isDirectRedemption: false,
    llpAddress: "0xllpaddress000000000000000000000000000000" as `0x${string}`,
    indexer: INDEXER_STUB,
    txReceiptTimeoutMs: 60000,
    metrics,
    logger: silentLogger,
    risk: createRiskGate(), // permissive by default
    executor:
      executor ??
      createAutoExecutorWithSender({
        store,
        nonces,
        sender: clients.sender as unknown as AutoDeps["sender"],
        publicClient: clients.publicClient as unknown as AutoDeps["publicClient"],
        walletClient: clients.walletClient as unknown as AutoDeps["walletClient"],
        txReceiptTimeoutMs: 60000,
        logger: silentLogger,
      }),
    ...engineOverrides,
  });
}

describe("LiquidationEngine", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    metrics = createMetrics();
  });

  afterEach(() => {
    vi.restoreAllMocks();
  });

  describe("run() - ponder API handling", () => {
    it("processes positions when API returns liquidatable positions", async () => {
      const clients = createMockClients();
      const bot = createBot(clients);

      global.fetch = vi.fn().mockResolvedValue({
        ok: true,
        json: () =>
          Promise.resolve({
            liquidatable: [mockPosition],
            total: 10,
            checked: 10,
          }),
      });

      await bot.run();

      // Should call Lens estimate + simulate + send liquidation tx
      expect(clients.publicClient.readContract).toHaveBeenCalled();
      expect(clients.publicClient.simulateContract).toHaveBeenCalledOnce();
      expect(clients.sender.send).toHaveBeenCalledOnce();
    });

    it("does nothing when no liquidatable positions found", async () => {
      const clients = createMockClients();
      const bot = createBot(clients);

      global.fetch = vi.fn().mockResolvedValue({
        ok: true,
        json: () =>
          Promise.resolve({
            liquidatable: [],
            total: 10,
            checked: 10,
          }),
      });

      await bot.run();

      expect(clients.publicClient.simulateContract).not.toHaveBeenCalled();
      expect(clients.sender.send).not.toHaveBeenCalled();
    });

    it("continues when ponder API fails (no crash)", async () => {
      const clients = createMockClients();
      const bot = createBot(clients);

      global.fetch = vi.fn().mockRejectedValue(new Error("Network error"));

      await expect(bot.run()).resolves.not.toThrow();
      expect(clients.publicClient.simulateContract).not.toHaveBeenCalled();
    });

    it("handles ponder API returning non-ok status", async () => {
      const clients = createMockClients();
      const bot = createBot(clients);

      global.fetch = vi.fn().mockResolvedValue({
        ok: false,
        status: 500,
      });

      await expect(bot.run()).resolves.not.toThrow();
      expect(clients.publicClient.simulateContract).not.toHaveBeenCalled();
    });

    // A failed read must not write a zero to the candidate gauge.
    it("does not record an empty market when the candidate list cannot be read", async () => {
      const clients = createMockClients();
      const bot = createBot(clients);
      global.fetch = vi.fn().mockRejectedValue(new Error("Network error"));

      await bot.run();

      expect(metrics.recordError).toHaveBeenCalledWith("ponder_fetch_error");
      expect(metrics.recordPositionsLiquidatable).not.toHaveBeenCalled();
    });

    it("records the empty market when the indexer actually reports one", async () => {
      const clients = createMockClients();
      const bot = createBot(clients);
      global.fetch = vi.fn().mockResolvedValue({
        ok: true,
        json: () => Promise.resolve({ liquidatable: [], total: 0, checked: 0 }),
      });

      await bot.run();

      expect(metrics.recordPositionsLiquidatable).toHaveBeenCalledWith(0);
      expect(metrics.recordError).not.toHaveBeenCalledWith("ponder_fetch_error");
    });

    // The response is cast to its type, never parsed, so what the cycle is built on is checked where
    // it is read — the same reason the risk gate re-establishes the freshness stamp itself. The
    // arbitrage engine has always done this for its vault list; this side had not.
    describe("a response that is not the shape it claims", () => {
      const answering = (body: unknown) =>
        vi.fn().mockResolvedValue({ ok: true, json: () => Promise.resolve(body) });

      it.each([
        ["no list at all", { total: 0, checked: 0 }],
        ["a list that is not an array", { liquidatable: "none", total: 0, checked: 0 }],
        ["a null list", { liquidatable: null, total: 0, checked: 0 }],
      ])("is refused as a fetch failure when it carries %s", async (_label, body) => {
        const clients = createMockClients();
        const bot = createBot(clients);
        global.fetch = answering(body);

        await bot.run();

        // Named as what it is — an unusable indexer answer — not as a `poll_error` from a `TypeError`
        // two frames later with nothing pointing at the indexer.
        expect(metrics.recordError).toHaveBeenCalledWith("ponder_fetch_error");
        expect(metrics.recordError).not.toHaveBeenCalledWith("poll_error");
        expect(clients.sender.send).not.toHaveBeenCalled();
      });

      // Counts are reported, not acted on. A missing one costs a gauge, not the cycle — but it must
      // not reach `prom-client`, which throws on a value that is not a number.
      it("acts on a well-formed list whose counts are missing", async () => {
        const clients = createMockClients();
        const bot = createBot(clients);
        global.fetch = answering({ liquidatable: [mockPosition] });

        await bot.run();

        expect(metrics.recordPositionsChecked).not.toHaveBeenCalled();
        expect(clients.sender.send).toHaveBeenCalled();
      });
    });

    // A failed cycle is still a cycle: the stamp answers "is this bot alive", not "is it winning".
    // If only successful cycles stamped it, a bot whose indexer is down would look wedged.
    it("fires onPollComplete on both the happy and the failing path", async () => {
      const clients = createMockClients();
      const onPollComplete = vi.fn();
      const bot = createBot(clients, { onPollComplete });

      global.fetch = vi.fn().mockResolvedValue({
        ok: true,
        json: () => Promise.resolve({ liquidatable: [], total: 0, checked: 0 }),
      });
      await bot.run();
      expect(onPollComplete).toHaveBeenCalledOnce();

      global.fetch = vi.fn().mockRejectedValue(new Error("Network error"));
      await bot.run();
      expect(onPollComplete).toHaveBeenCalledTimes(2);
    });
  });

  describe("run() - risk gate", () => {
    const liquidatable = () => ({
      ok: true,
      json: () => Promise.resolve({ liquidatable: [mockPosition], total: 1, checked: 1 }),
    });

    it("skips the whole cycle when the gate is HALTED (kill-switch)", async () => {
      const clients = createMockClients();
      const risk = createRiskGate();
      risk.halt("manual");
      const bot = createBot(clients, { risk });
      global.fetch = vi.fn().mockResolvedValue(liquidatable());

      await bot.run();

      expect(clients.publicClient.simulateContract).not.toHaveBeenCalled();
      expect(clients.sender.send).not.toHaveBeenCalled();
    });

    it("trips the breaker on a reverted liquidation, halting subsequent runs", async () => {
      const clients = createMockClients();
      clients.publicClient.waitForTransactionReceipt.mockResolvedValue({
        status: "reverted",
        blockNumber: 1n,
        logs: [],
      });
      const risk = createRiskGate({ maxConsecutiveFailures: 1 });
      const bot = createBot(clients, { risk });
      global.fetch = vi.fn().mockResolvedValue(liquidatable());

      await bot.run(); // sends 1 tx → reverts → slot settles !ok → breaker trips
      expect(risk.state()).toBe("HALTED");

      clients.publicClient.simulateContract.mockClear();
      await bot.run(); // now HALTED → short-circuits before simulate
      expect(clients.publicClient.simulateContract).not.toHaveBeenCalled();
    });

    it("does NOT trip the breaker when the revert is a lost race (position already cleared)", async () => {
      const clients = createMockClients();
      clients.publicClient.waitForTransactionReceipt.mockResolvedValue({
        status: "reverted",
        blockNumber: 1n,
        logs: [],
      });
      // The liquidation reverted because another liquidator already cleared the position: no
      // collateral left, no vaults. The engine reads getPosition and sees both → lost race.
      overrideRead(clients, "getPosition", {
        vaultIds: [],
        totalCollateralBTC: 0n,
        proxyContract: mockPosition.proxyAddress,
      });
      const risk = createRiskGate({ maxConsecutiveFailures: 1 });
      const bot = createBot(clients, { risk });
      global.fetch = vi.fn().mockResolvedValue(liquidatable());

      await bot.run(); // reverts, but lost race → contended → breaker untouched
      // Asserted alongside the state: "RUNNING" is also what a cycle that never got as far as
      // sending would leave behind, so without this the test cannot tell the two apart.
      expect(clients.sender.send).toHaveBeenCalledTimes(1);
      expect(risk.state()).toBe("RUNNING");
    });

    it("does NOT trip the breaker when a competitor took our vault but left collateral", async () => {
      const clients = createMockClients();
      clients.publicClient.waitForTransactionReceipt.mockResolvedValue({
        status: "reverted",
        blockNumber: 1n,
        logs: [],
      });
      // The case single-vault seizure makes ordinary. The adapter takes exactly the head vault, so
      // a competitor liquidating a borrower who holds two leaves the second one behind. Judged on
      // collateral alone this reads as "still there to take", and every lost race against a
      // multi-vault borrower would be charged to the breaker. The mirror case — our vault still in
      // the list, so nobody outran us — is the default mock, asserted as HALTED above.
      overrideRead(clients, "getPosition", {
        vaultIds: ["0xvault2"], // ours is gone; the borrower's other vault is not
        totalCollateralBTC: 500n,
        proxyContract: mockPosition.proxyAddress,
      });
      const risk = createRiskGate({ maxConsecutiveFailures: 1 });
      const bot = createBot(clients, { risk });
      global.fetch = vi.fn().mockResolvedValue(liquidatable());

      await bot.run();
      expect(clients.sender.send).toHaveBeenCalledTimes(1);
      expect(risk.state()).toBe("RUNNING");
    });

    it("does NOT trip the breaker when the receipt never arrives (outcome unknown)", async () => {
      const clients = createMockClients();
      // Timing out or failing to fetch tells us nothing about what the chain did — the tx may
      // still be in the mempool, and behind a nonce gap it certainly is. Receipts are awaited as a
      // batch, so one shared cause fails them all at once; counting those would halt a healthy bot.
      clients.publicClient.waitForTransactionReceipt.mockRejectedValue(new Error("timeout"));
      const risk = createRiskGate({ maxConsecutiveFailures: 1 });
      const bot = createBot(clients, { risk });
      global.fetch = vi.fn().mockResolvedValue(liquidatable());

      await bot.run();

      expect(risk.state()).toBe("RUNNING");
    });

    // The breaker exists to stop us when THE CHAIN is rejecting our txs. A failure to prepare,
    // sign, or durably record never reaches the chain, so it must settle as `abandoned` and
    // leave the breaker alone — otherwise a database or RPC blip halts a healthy bot.
    it("does NOT trip the breaker when the send fails before broadcasting", async () => {
      const clients = createMockClients();
      clients.sender.send = vi
        .fn()
        .mockRejectedValue(new PreBroadcastError(new Error("store unavailable")));
      const risk = createRiskGate({ maxConsecutiveFailures: 1 });
      const bot = createBot(clients, { risk });
      global.fetch = vi.fn().mockResolvedValue(liquidatable());

      await bot.run();

      expect(clients.sender.send).toHaveBeenCalled(); // we really did attempt the send
      expect(risk.state()).not.toBe("HALTED");
      expect(risk.inFlight()).toBe(0); // and the exposure slot was still released
    });

    // The counterpart: an ambiguous *broadcast* may be on chain, so its spend stays held under the
    // signed hash. Its fate is unknown, which is not evidence the chain rejected us, so the breaker
    // does not count it.
    it("holds the spend of an ambiguous broadcast failure without tripping the breaker", async () => {
      const clients = createMockClients();
      clients.sender.send = vi.fn(
        async (
          call: { nonce?: number },
          onSigned?: (tx: {
            hash: `0x${string}`;
            nonce: number;
            serialized: `0x${string}`;
          }) => Promise<void>
        ) => {
          await onSigned?.({ hash: "0xambiguous", nonce: call.nonce ?? 0, serialized: "0xraw" });
          throw new Error("rpc timeout");
        }
      );
      const risk = createRiskGate({ maxConsecutiveFailures: 1 });
      const bot = createBot(clients, { risk });
      global.fetch = vi.fn().mockResolvedValue(liquidatable());

      await bot.run();

      expect(clients.sender.send).toHaveBeenCalled();
      expect(risk.state()).not.toBe("HALTED");
      expect(risk.outflows().map((o) => o.txHash)).toContain("0xambiguous");
    });

    const NOW = 1_000_000_000;
    const feedAt = (dataTimestampMs?: number) =>
      vi.fn().mockResolvedValue({
        ok: true,
        json: () =>
          Promise.resolve({ liquidatable: [mockPosition], total: 1, checked: 1, dataTimestampMs }),
      });

    it("blocks a stale candidate (maxDataStalenessMs) — no tx", async () => {
      const clients = createMockClients();
      const risk = createRiskGate({ maxDataStalenessMs: 60_000, now: () => NOW });
      const bot = createBot(clients, { risk });
      global.fetch = feedAt(NOW - 120_000); // indexer's reads are 2 min old

      await bot.run();

      expect(clients.sender.send).not.toHaveBeenCalled();
      expect(metrics.recordError).toHaveBeenCalledWith("risk_blocked");
    });

    it("allows a fresh candidate (positive control)", async () => {
      const clients = createMockClients();
      const risk = createRiskGate({ maxDataStalenessMs: 60_000, now: () => NOW });
      const bot = createBot(clients, { risk });
      global.fetch = feedAt(NOW - 5_000);

      await bot.run();

      expect(clients.sender.send).toHaveBeenCalledOnce();
    });

    // Fail-closed: an operator who opts into a staleness bound must not silently trade on data
    // of unknown age (old indexer, or its block-timestamp probe failed).
    it("blocks when the freshness guard is configured but the indexer reports no timestamp", async () => {
      const clients = createMockClients();
      const risk = createRiskGate({ maxDataStalenessMs: 60_000, now: () => NOW });
      const bot = createBot(clients, { risk });
      global.fetch = feedAt(undefined); // older indexer / failed probe

      await bot.run();

      expect(clients.sender.send).not.toHaveBeenCalled();
      expect(metrics.recordError).toHaveBeenCalledWith("risk_blocked");
    });

    it("ignores a missing timestamp when the freshness guard is not configured (default)", async () => {
      const clients = createMockClients();
      const bot = createBot(clients, { risk: createRiskGate() }); // permissive default
      global.fetch = feedAt(undefined);

      await bot.run();

      expect(clients.sender.send).toHaveBeenCalledOnce();
    });

    // Documents a known gap: liquidation profit is not derivable off-chain today (the Lens
    // estimate and the tx return value carry no WBTC-denominated profit), so the engine passes
    // no `expectedProfit` and the floor cannot bite here. If someone later wires a profit value,
    // this test fails loudly — which is the point.
    it("does NOT apply the profit floor to liquidations (expectedProfit not derivable)", async () => {
      const clients = createMockClients();
      const risk = createRiskGate({ minProfit: 10n ** 30n }); // absurd floor
      const bot = createBot(clients, { risk });
      global.fetch = feedAt(NOW);

      await bot.run();

      expect(clients.sender.send).toHaveBeenCalledOnce();
    });
  });

  describe("run() - Lens estimation", () => {
    it("skips positions where Lens estimate fails", async () => {
      const clients = createMockClients();
      clients.publicClient.readContract.mockRejectedValue(
        new Error("Position is not undercollateralized")
      );
      const bot = createBot(clients);

      global.fetch = vi.fn().mockResolvedValue({
        ok: true,
        json: () =>
          Promise.resolve({
            liquidatable: [mockPosition],
            total: 1,
            checked: 1,
          }),
      });

      await bot.run();

      // Should not simulate or send tx since Lens failed
      expect(clients.publicClient.simulateContract).not.toHaveBeenCalled();
      expect(clients.sender.send).not.toHaveBeenCalled();
    });
  });

  describe("run() - simulation filtering", () => {
    it("skips positions that fail simulation", async () => {
      const clients = createMockClients();
      clients.publicClient.simulateContract.mockRejectedValue(new Error("execution reverted"));
      const bot = createBot(clients);

      global.fetch = vi.fn().mockResolvedValue({
        ok: true,
        json: () =>
          Promise.resolve({
            liquidatable: [mockPosition],
            total: 1,
            checked: 1,
          }),
      });

      await bot.run();

      expect(clients.publicClient.simulateContract).toHaveBeenCalledOnce();
      // No tx sent since simulation failed
      expect(clients.sender.send).not.toHaveBeenCalled();
    });

    it("sends tx only for positions that pass simulation", async () => {
      const clients = createMockClients();

      const position2: LiquidatablePosition = {
        ...mockPosition,
        proxyAddress: "0xabcdefabcdefabcdefabcdefabcdefabcdefabcd",
        borrower: "0x000000000000000000000000000000000000b0b2",
      };

      // First simulation succeeds, second fails
      clients.publicClient.simulateContract
        .mockResolvedValueOnce({ result: true })
        .mockRejectedValueOnce(new Error("reverted"));

      const bot = createBot(clients);

      global.fetch = vi.fn().mockResolvedValue({
        ok: true,
        json: () =>
          Promise.resolve({
            liquidatable: [mockPosition, position2],
            total: 2,
            checked: 2,
          }),
      });

      await bot.run();

      expect(clients.publicClient.simulateContract).toHaveBeenCalledTimes(2);
      // Only 1 tx sent (first position)
      expect(clients.sender.send).toHaveBeenCalledTimes(1);
    });
  });

  describe("run() - transaction handling", () => {
    it("sends liquidation with borrower address and inputs from Lens", async () => {
      const clients = createMockClients();
      clients.publicClient.getTransactionCount.mockResolvedValue(42);
      const bot = createBot(clients);

      global.fetch = vi.fn().mockResolvedValue({
        ok: true,
        json: () =>
          Promise.resolve({
            liquidatable: [mockPosition],
            total: 1,
            checked: 1,
          }),
      });

      await bot.run();

      expect(clients.sender.send).toHaveBeenCalledWith(
        expect.objectContaining({
          nonce: 42,
          functionName: "liquidateWithLLP",
        }),
        expect.any(Function),
        expect.any(Function)
      );
    });

    it("sends liquidation with non-zero BTC redeem key when configured", async () => {
      const clients = createMockClients();
      clients.publicClient.getTransactionCount.mockResolvedValue(7);
      const nonZeroRedeemKey =
        "0x1234567890abcdef1234567890abcdef1234567890abcdef1234567890abcdef" as const;
      const bot = createBot(clients, { btcRedeemKey: nonZeroRedeemKey, isDirectRedemption: true });

      global.fetch = vi.fn().mockResolvedValue({
        ok: true,
        json: () =>
          Promise.resolve({
            liquidatable: [mockPosition],
            total: 1,
            checked: 1,
          }),
      });

      await bot.run();

      // Bot adds 1% buffer to the preview's figures to cover interest accrual — to the debt so it
      // does not leave dust, and to the payment because that figure is also the cap the adapter
      // checks its own recomputed payment against.
      const buffer = (amt: bigint) => (amt * 10100n) / 10000n;
      expect(clients.sender.send).toHaveBeenCalledWith(
        expect.objectContaining({
          nonce: 7,
          functionName: "liquidate",
          // minVaultBtcOut=0n disables BTC-out slippage protection; the reserve ids are passed
          // through unbuffered, since they name reserves rather than amounts.
          args: [
            mockPosition.borrower,
            [...mockReserveIds],
            mockAmounts.map(buffer),
            0n,
            buffer(mockWbtcPayment),
            nonZeroRedeemKey,
          ],
        }),
        expect.any(Function),
        expect.any(Function)
      );
    });

    it("increments nonce for multiple positions", async () => {
      const clients = createMockClients();
      clients.publicClient.getTransactionCount.mockResolvedValue(10);

      const position2: LiquidatablePosition = {
        ...mockPosition,
        proxyAddress: "0xabcdefabcdefabcdefabcdefabcdefabcdefabcd",
        borrower: "0x000000000000000000000000000000000000b0b2",
      };

      const bot = createBot(clients);

      global.fetch = vi.fn().mockResolvedValue({
        ok: true,
        json: () =>
          Promise.resolve({
            liquidatable: [mockPosition, position2],
            total: 2,
            checked: 2,
          }),
      });

      await bot.run();

      expect(clients.sender.send).toHaveBeenCalledTimes(2);
      expect(clients.sender.send).toHaveBeenNthCalledWith(
        1,
        expect.objectContaining({ nonce: 10 }),
        expect.any(Function),
        expect.any(Function)
      );
      expect(clients.sender.send).toHaveBeenNthCalledWith(
        2,
        expect.objectContaining({ nonce: 11 }),
        expect.any(Function),
        expect.any(Function)
      );
    });

    it("stops the cycle after a send error (does not process later positions)", async () => {
      const clients = createMockClients();

      const position2: LiquidatablePosition = {
        ...mockPosition,
        proxyAddress: "0xabcdefabcdefabcdefabcdefabcdefabcdefabcd",
        borrower: "0x000000000000000000000000000000000000b0b2",
      };

      // The first send throws — an AMBIGUOUS broadcast (the tx may be on the wire). The loop must
      // break rather than reserve the next nonce for position 2: continuing could leave a gap that
      // wedges every later tx, or double-act if position 1 actually landed. The next cycle's
      // reconcile + resync resolves the in-flight intent by nonce vs. chain.
      clients.sender.send.mockRejectedValueOnce(new Error("nonce too low"));

      const bot = createBot(clients);

      global.fetch = vi.fn().mockResolvedValue({
        ok: true,
        json: () =>
          Promise.resolve({
            liquidatable: [mockPosition, position2],
            total: 2,
            checked: 2,
          }),
      });

      await bot.run();

      // Only the first position was attempted; the cycle stopped before position 2.
      expect(clients.sender.send).toHaveBeenCalledTimes(1);
      // Nothing was successfully sent, so no receipt is awaited.
      expect(clients.publicClient.waitForTransactionReceipt).not.toHaveBeenCalled();
    });

    it("records failed liquidation when receipt shows reverted", async () => {
      const clients = createMockClients();

      clients.publicClient.waitForTransactionReceipt.mockResolvedValue({
        status: "reverted",
        blockNumber: 123n,
        logs: [],
      });

      const bot = createBot(clients);

      global.fetch = vi.fn().mockResolvedValue({
        ok: true,
        json: () =>
          Promise.resolve({
            liquidatable: [mockPosition],
            total: 1,
            checked: 1,
          }),
      });

      await bot.run();

      expect(metrics.recordLiquidationFailed).toHaveBeenCalled();
    });

    it("records successful liquidation when receipt confirms", async () => {
      const clients = createMockClients();

      const bot = createBot(clients);

      global.fetch = vi.fn().mockResolvedValue({
        ok: true,
        json: () =>
          Promise.resolve({
            liquidatable: [mockPosition],
            total: 1,
            checked: 1,
          }),
      });

      await bot.run();

      expect(metrics.recordLiquidationSuccess).toHaveBeenCalled();
    });
  });

  // Approving the adapter is inventory-funding behaviour: it exists because the signer's own tokens
  // pay. It happens inside the poll cycle (`refreshInventory`), NOT at boot — `prepare()` runs
  // before the risk gate's state is ever read, so an approval sent from there escapes it.
  // The one topology error nothing downstream can catch: a Lens wired to another deployment answers
  // in *its* reserve index space, and if both Spokes list the same number of reserves the amounts
  // line up perfectly against the wrong tokens. Two reads at boot, before anything is traded.
  // The Spoke is read every cycle, not cached: `updateReserveConfig` can make a reserve borrowable
  // without the reserve count moving, and a bot that only re-read on a count change would never
  // hold or approve that token — blocking every position that owes it until someone restarts it.
  describe("a Spoke that changes under a running bot", () => {
    it("holds and approves a token whose reserve became borrowable mid-run", async () => {
      const clients = createMockClients();
      const reserves = [
        { flags: 0x04, underlying: "0xtoken1" },
        { flags: 0x00, underlying: "0xtoken2" },
      ];
      clients.publicClient.readContract.mockImplementation(
        ({ functionName, args }: { functionName: string; args?: readonly unknown[] }) => {
          if (functionName === "adapter") return Promise.resolve("0xadapter");
          if (functionName === "spoke") return Promise.resolve("0xspoke");
          if (functionName === "BTC_VAULT_CORE_SPOKE") return Promise.resolve("0xspoke");
          if (functionName === "getReserveCount") return Promise.resolve(BigInt(reserves.length));
          if (functionName === "getReserve")
            return Promise.resolve(reserves[Number(args?.[0] ?? 0n)]);
          // Nothing approved, so each cycle approves whatever it is told to hold.
          if (functionName === "allowance") return Promise.resolve(0n);
          return Promise.resolve(0n);
        }
      );
      const bot = createBot(clients, { nonces: passthroughNonces() });
      await bot.prepare();

      const approvedIn = async () => {
        clients.sender.send.mockClear();
        await bot.run();
        return clients.sender.send.mock.calls
          .map(([call]) => (call as { address: string }).address)
          .filter((address) => address === "0xtoken2");
      };

      expect(await approvedIn()).toEqual([]);
      reserves[1].flags = 0x04; // the operator makes it borrowable, count unchanged
      expect(await approvedIn()).toEqual(["0xtoken2"]);
    });
  });

  describe("Lens wiring", () => {
    const wiredTo = (clients: ReturnType<typeof createMockClients>, over: Record<string, string>) =>
      clients.publicClient.readContract.mockImplementation(
        ({ functionName }: { functionName: string }) => {
          if (functionName in over) return Promise.resolve(over[functionName]);
          if (functionName === "getReserveCount") return Promise.resolve(1n);
          if (functionName === "getReserve")
            return Promise.resolve({ flags: 0x04, underlying: "0xtoken1" });
          return Promise.resolve(0n);
        }
      );

    it("refuses a Lens built for another adapter", async () => {
      const clients = createMockClients();
      wiredTo(clients, {
        adapter: "0xotheradapter",
        spoke: "0xspoke",
        BTC_VAULT_CORE_SPOKE: "0xspoke",
      });

      await expect(createBot(clients).prepare()).rejects.toThrow(/estimates for adapter/);
    });

    it("refuses a Lens reading another Spoke", async () => {
      const clients = createMockClients();
      wiredTo(clients, {
        adapter: "0xadapter",
        spoke: "0xotherspoke",
        BTC_VAULT_CORE_SPOKE: "0xspoke",
      });

      await expect(createBot(clients).prepare()).rejects.toThrow(/reads Spoke/);
    });

    it("accepts the matching pair, whatever the address casing", async () => {
      const clients = createMockClients();
      wiredTo(clients, {
        adapter: "0xADAPTER",
        spoke: "0xSPOKE",
        BTC_VAULT_CORE_SPOKE: "0xspoke",
      });

      await expect(createBot(clients).prepare()).resolves.not.toThrow();
    });
  });

  describe("adapter approvals", () => {
    /** A Spoke listing one borrowable reserve in `0xtoken1`, with `allowance` as given. */
    const oneReserve = (clients: ReturnType<typeof createMockClients>, allowance: bigint) =>
      clients.publicClient.readContract.mockImplementation(
        ({ functionName }: { functionName: string }) => {
          if (functionName === "adapter") return Promise.resolve("0xadapter");
          if (functionName === "spoke") return Promise.resolve("0xspoke");
          if (functionName === "BTC_VAULT_CORE_SPOKE") return Promise.resolve("0xspoke");
          if (functionName === "getReserveCount") return Promise.resolve(1n);
          if (functionName === "getReserve")
            return Promise.resolve({ flags: 0x04, underlying: "0xtoken1" });
          if (functionName === "allowance") return Promise.resolve(allowance);
          return Promise.resolve(0n);
        }
      );

    it("approves when allowance is below threshold", async () => {
      const clients = createMockClients();
      oneReserve(clients, 0n);

      const bot = createBot(clients, { nonces: passthroughNonces() });

      await bot.prepare();
      await bot.run();

      expect(clients.publicClient.readContract).toHaveBeenCalled();
      expect(clients.sender.send).toHaveBeenCalledWith(
        expect.objectContaining({
          functionName: "approve",
        }),
        expect.any(Function),
        expect.any(Function)
      );
    });

    it("skips approval when allowance is sufficient", async () => {
      const clients = createMockClients();
      oneReserve(
        clients,
        BigInt("0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff")
      );

      const bot = createBot(clients);

      await bot.prepare();
      await bot.run();

      expect(clients.sender.send).not.toHaveBeenCalled();
    });

    it("still approves WBTC when no debt tokens configured", async () => {
      const clients = createMockClients();
      // 0n allowance forces approval path; symbol/decimals reads happen during
      // logging via tokenMeta. The single readContract spy covers all three.
      clients.publicClient.readContract.mockImplementation(
        ({ functionName }: { functionName: string }) => {
          // The Lens reports the adapter and Spoke it was built for; `prepare()` checks the pair.
          if (functionName === "adapter") return Promise.resolve("0xadapter");
          if (functionName === "spoke")
            return Promise.resolve("0x0000000000000000000000000000000000000000");
          if (functionName === "BTC_VAULT_CORE_SPOKE")
            return Promise.resolve("0x0000000000000000000000000000000000000000");
          if (functionName === "allowance") return Promise.resolve(0n);
          if (functionName === "symbol") return Promise.resolve("WBTC");
          if (functionName === "decimals") return Promise.resolve(8);
          return Promise.resolve(0n);
        }
      );
      const bot = createBot(clients, { nonces: passthroughNonces() });

      // WBTC approval is unconditional — the adapter pulls WBTC from msg.sender
      // for fairness + direct-redemption fee, independent of whether WBTC is a
      // borrowable debt token on the Spoke.
      await bot.prepare();
      await bot.run();

      expect(clients.sender.send).toHaveBeenCalledTimes(1);
      expect(clients.sender.send).toHaveBeenCalledWith(
        expect.objectContaining({
          address: "0xwbtc",
          functionName: "approve",
        }),
        expect.any(Function),
        expect.any(Function)
      );
    });
  });

  // The guard this whole placement exists for. `prepare()` runs BEFORE the poll loop, and the poll
  // loop is the only place the gate's state is read — so an approval sent from `prepare()` escapes
  // it. That matters most in exactly the case the code-hash guard fires: it halts the gate at boot
  // because a pinned target's bytecode changed, and the old placement then granted that same
  // contract an unlimited allowance moments later.
  describe("approvals and the risk gate", () => {
    const approvalArgs = {};

    const zeroAllowance = (clients: ReturnType<typeof createMockClients>) =>
      clients.publicClient.readContract.mockImplementation(
        ({ functionName }: { functionName: string }) => {
          // The Lens reports the adapter and Spoke it was built for; `prepare()` checks the pair.
          if (functionName === "adapter") return Promise.resolve("0xadapter");
          if (functionName === "spoke")
            return Promise.resolve("0x0000000000000000000000000000000000000000");
          if (functionName === "BTC_VAULT_CORE_SPOKE")
            return Promise.resolve("0x0000000000000000000000000000000000000000");
          if (functionName === "allowance") return Promise.resolve(0n);
          if (functionName === "symbol") return Promise.resolve("WBTC");
          if (functionName === "decimals") return Promise.resolve(8);
          return Promise.resolve(0n);
        }
      );

    it("sends nothing at boot, even with an allowance of zero", async () => {
      const clients = createMockClients();
      zeroAllowance(clients);
      const bot = createBot(clients, { ...approvalArgs, nonces: passthroughNonces() });

      await bot.prepare();

      expect(clients.sender.send).not.toHaveBeenCalled();
    });

    it("does not approve while the gate is HALTED", async () => {
      const clients = createMockClients();
      zeroAllowance(clients);
      const risk = createRiskGate({ startHalted: true });
      const bot = createBot(clients, { ...approvalArgs, risk, nonces: passthroughNonces() });

      await bot.prepare();
      await bot.run();

      expect(clients.sender.send).not.toHaveBeenCalled();
    });

    // ...and repairs itself on resume, without a restart. The old placement could not: it approved
    // once at boot and had no later path, so a halted boot left the bot unable to fund anything.
    it("approves on the first cycle after a resume", async () => {
      const clients = createMockClients();
      zeroAllowance(clients);
      const risk = createRiskGate({ startHalted: true });
      const bot = createBot(clients, { ...approvalArgs, risk, nonces: passthroughNonces() });

      await bot.prepare();
      await bot.run();
      expect(clients.sender.send).not.toHaveBeenCalled();

      risk.resume();
      await bot.run();

      expect(clients.sender.send).toHaveBeenCalledWith(
        expect.objectContaining({ functionName: "approve" }),
        expect.any(Function),
        expect.any(Function)
      );
    });
  });

  // A batch of position probes can fail as a whole (the aggregate exceeding a node's eth_call gas
  // cap is the ordinary way), leaving the candidate list short. Acting on what we saw is right —
  // refusing the cycle turns a partial view into no view — but it must not pass as a quiet market.
  describe("a partially scanned position table", () => {
    const feedWith = (extra: Record<string, unknown>) => {
      global.fetch = vi.fn().mockResolvedValue({
        ok: true,
        status: 200,
        json: async () => ({
          liquidatable: [],
          total: 0,
          checked: 5,
          dataTimestampMs: Date.now(),
          ...extra,
        }),
      }) as unknown as typeof global.fetch;
    };

    it("reports the gap rather than reading it as nothing to do", async () => {
      const clients = createMockClients();
      const bot = createBot(clients);
      feedWith({ unscanned: 7 });

      await bot.run();

      expect(metrics.recordError).toHaveBeenCalledWith("positions_unscanned");
    });

    it("says nothing when the whole table was scanned", async () => {
      const clients = createMockClients();
      const bot = createBot(clients);
      feedWith({ unscanned: 0 });

      await bot.run();

      expect(metrics.recordError).not.toHaveBeenCalledWith("positions_unscanned");
    });

    // An indexer too old to report the field scanned everything, which is what it did before
    // batching existed — so its silence must not read as a permanent partial scan.
    it("treats an absent field as a full scan", async () => {
      const clients = createMockClients();
      const bot = createBot(clients);
      feedWith({});

      await bot.run();

      expect(metrics.recordError).not.toHaveBeenCalledWith("positions_unscanned");
    });
  });

  describe("discoverDebtTokens()", () => {
    it("discovers borrowable reserves from Spoke", async () => {
      const clients = createMockClients();

      clients.publicClient.readContract.mockImplementation(
        ({ functionName, args }: { functionName: string; args?: readonly unknown[] }) => {
          if (functionName === "BTC_VAULT_CORE_SPOKE") return Promise.resolve("0xspoke");
          if (functionName === "getReserveCount") return Promise.resolve(2n);
          if (functionName === "getReserve") {
            const idx = (args?.[0] as bigint) ?? 0n;
            if (idx === 0n) return Promise.resolve({ flags: 0x04, underlying: "0xtoken1" });
            return Promise.resolve({ flags: 0x00, underlying: "0xtoken2" });
          }
          if (functionName === "symbol") return Promise.resolve("USDC");
          if (functionName === "decimals") return Promise.resolve(6);
          return Promise.resolve(0n);
        }
      );

      const bot = createBot(clients);

      await bot.discoverReserves();

      // BTC_VAULT_CORE_SPOKE + getReserveCount + 2× getReserve + getReserveTotalDebt for the
      // non-borrowable reserve + symbol/decimals per reserve (decimals is read alongside symbol via
      // the tokenMeta cache). Both reserves are read and named, not just the borrowable one: the
      // non-borrowable one still occupies a reserve id, and the id is what the Lens amounts are
      // keyed by.
      expect(clients.publicClient.readContract).toHaveBeenCalledTimes(9);
    });

    it("handles zero reserves gracefully", async () => {
      const clients = createMockClients();

      clients.publicClient.readContract
        .mockResolvedValueOnce("0xspoke") // BTC_VAULT_CORE_SPOKE
        .mockResolvedValueOnce(0n); // getReserveCount = 0

      const bot = createBot(clients);

      await bot.discoverReserves();

      expect(clients.publicClient.readContract).toHaveBeenCalledTimes(2);
    });
  });

  describe("logBalances()", () => {
    it("logs debt token and WBTC balances", async () => {
      const clients = createMockClients();

      clients.publicClient.readContract.mockImplementation(
        ({ functionName, address }: { functionName: string; address: string }) => {
          if (functionName === "BTC_VAULT_CORE_SPOKE") return Promise.resolve("0xspoke");
          if (functionName === "getReserveCount") return Promise.resolve(1n);
          if (functionName === "getReserve")
            return Promise.resolve({ flags: 0x04, underlying: "0xtoken1" });
          if (functionName === "symbol")
            return Promise.resolve(address === "0xwbtc" ? "WBTC" : "USDC");
          if (functionName === "decimals") return Promise.resolve(address === "0xwbtc" ? 8 : 6);
          if (functionName === "balanceOf")
            return Promise.resolve(address === "0xwbtc" ? 50000000n : 1000000n);
          return Promise.resolve(0n);
        }
      );

      const bot = createBot(clients);
      // The tokens logged are the Spoke's borrowable reserves, so they exist only once it has been
      // read — the declared list is checked against that, never used in its place.
      await bot.discoverReserves();

      await expect(bot.logBalances()).resolves.not.toThrow();
      expect(metrics.recordTokenBalance).toHaveBeenCalled();
    });

    it("swallows a balance-read failure so the poll loop keeps running", async () => {
      const clients = createMockClients();
      clients.publicClient.readContract.mockRejectedValue(new Error("RPC blip"));
      const bot = createBot(clients);

      // Must not throw — a transient RPC error during balance logging must not
      // escape to the poll loop and crash the process.
      await expect(bot.logBalances()).resolves.not.toThrow();
    });

    it("caches symbol and decimals across calls (steady-state RPC reduction)", async () => {
      const clients = createMockClients();

      clients.publicClient.readContract.mockImplementation(
        ({ functionName, address }: { functionName: string; address: string }) => {
          if (functionName === "BTC_VAULT_CORE_SPOKE") return Promise.resolve("0xspoke");
          if (functionName === "getReserveCount") return Promise.resolve(1n);
          if (functionName === "getReserve")
            return Promise.resolve({ flags: 0x04, underlying: "0xtoken1" });
          if (functionName === "symbol")
            return Promise.resolve(address === "0xwbtc" ? "WBTC" : "USDC");
          if (functionName === "decimals") return Promise.resolve(address === "0xwbtc" ? 8 : 6);
          if (functionName === "balanceOf")
            return Promise.resolve(address === "0xwbtc" ? 50000000n : 1000000n);
          return Promise.resolve(0n);
        }
      );

      const bot = createBot(clients);
      await bot.discoverReserves();

      await bot.logBalances();
      const callsAfterFirst = clients.publicClient.readContract.mock.calls.length;

      await bot.logBalances();
      const callsAfterSecond = clients.publicClient.readContract.mock.calls.length;

      // Second cycle should only re-read balanceOf for each token (1 debt + 1 WBTC = 2),
      // not symbol/decimals (cached).
      expect(callsAfterSecond - callsAfterFirst).toBe(2);
    });
  });

  describe("crash-safety (StateStore)", () => {
    const feed = (positions: LiquidatablePosition[]) =>
      vi.fn().mockResolvedValue({
        ok: true,
        json: () => Promise.resolve({ liquidatable: positions, total: 1, checked: 1 }),
      });

    // A bot wired with the store + a fresh in-memory nonce allocator (as the composition root
    // does). A new allocator per bot models a restart (in-memory lease resets; the store
    // persists). The allocator is seeded from the chain by run()'s cycle-start resync.
    function storeBot(store: MemoryStateStore) {
      const clients = createMockClients();
      // The store path reads chainId off the wallet's chain.
      (clients.walletClient as { chain?: { id: number } }).chain = { id: 31337 };
      const nonces = createNonceAllocator(createNonceLease(), clients.walletClient.account.address);
      const bot = createBot(clients, { store, nonces });
      return { bot, clients };
    }

    it("re-drives after a crash mid-submit without double-sending", async () => {
      const store = createMemoryStateStore();

      // Run 1: the tx is broadcast, but the receipt never lands (simulated crash before
      // confirmation), so the intent is left 'submitted' (in-flight).
      const first = storeBot(store);
      first.clients.publicClient.waitForTransactionReceipt = vi
        .fn()
        .mockRejectedValue(new Error("process killed"));
      global.fetch = feed([mockPosition]);
      await first.bot.run();

      expect(first.clients.sender.send).toHaveBeenCalledOnce();
      const inflight = await store.reconcile();
      expect(inflight).toHaveLength(1);
      expect(inflight[0].status).toBe("submitted");

      // Restart: a fresh engine over the same store reconciles (receipt still not found →
      // left in-flight), then re-drives the same position — which is refused as a duplicate.
      const second = storeBot(store);
      await second.bot.reconcile();
      global.fetch = feed([mockPosition]);
      await second.bot.run();

      expect(second.clients.sender.send).not.toHaveBeenCalled();
      expect(metrics.recordError).toHaveBeenCalledWith("intent_in_flight");
    });

    it("keeps a failed send live, then re-drives it once the chain shows the nonce free", async () => {
      const store = createMemoryStateStore();
      const { bot, clients } = storeBot(store);
      // Chain nonce stays 0 (the failed tx never broadcast), so next-cycle reconcile can prove
      // the reserved nonce is free and re-drive. First send throws, second succeeds.
      clients.publicClient.getTransactionCount = vi.fn().mockResolvedValue(0);
      clients.sender.send = vi
        .fn()
        .mockRejectedValueOnce(new Error("boom"))
        .mockResolvedValue("0xtxhash");

      global.fetch = feed([mockPosition]);
      await bot.run(); // send fails → intent kept LIVE (not terminal), never re-driven this cycle
      const id = store.all()[0].id;
      expect(store.get(id)?.status).toBe("submitted");

      global.fetch = feed([mockPosition]);
      await bot.run(); // cycle-start reconcile: nonce free ⇒ terminal ⇒ re-drive
      expect(clients.sender.send).toHaveBeenCalledTimes(2);
      expect(store.get(id)?.status).toBe("confirmed");
    });

    it("holds (does not re-drive) a live intent whose reserved nonce is still in the mempool", async () => {
      const store = createMemoryStateStore();
      const { bot, clients } = storeBot(store);
      // Run 1: chain nonce 6 → the send reserves 6 then throws AFTER (mocked) broadcast.
      clients.publicClient.getTransactionCount = vi.fn().mockResolvedValue(6);
      clients.sender.send = vi.fn(
        async (
          call: { nonce?: number },
          onSigned?: (tx: {
            hash: `0x${string}`;
            nonce: number;
            serialized: `0x${string}`;
          }) => Promise<void>
        ) => {
          // Ambiguous send: signed + durably recorded, then the broadcast blows up.
          await onSigned?.({ hash: "0xtxhash", nonce: call.nonce ?? 0, serialized: "0xraw" });
          throw new Error("rpc timeout");
        }
      );

      global.fetch = feed([mockPosition]);
      await bot.run(); // send throws → intent kept live at nonce 6
      const id = store.all()[0].id;
      expect(store.get(id)?.status).toBe("submitted");
      expect(store.get(id)?.nonce).toBe(6);

      // Run 2: the ambiguous tx is now visible in the mempool — pending advanced past nonce 6.
      clients.publicClient.getTransactionCount = vi
        .fn()
        .mockImplementation(({ blockTag }: { blockTag: string }) =>
          Promise.resolve(blockTag === "pending" ? 7 : 6)
        );
      global.fetch = feed([mockPosition]);
      await bot.run(); // reconcile: pending(7) > nonce(6), latest(6) ⇒ hold, no re-drive
      expect(clients.sender.send).toHaveBeenCalledTimes(1);
    });

    it("allocates nonces from the persisted lease, seeded from the chain", async () => {
      const store = createMemoryStateStore();
      const { bot, clients } = storeBot(store);
      // Chain's next nonce is 7; the lease should seed there and the tx use it.
      clients.publicClient.getTransactionCount = vi.fn().mockResolvedValue(7);
      global.fetch = feed([mockPosition]);

      await bot.run();

      expect(clients.sender.send).toHaveBeenCalledWith(
        expect.objectContaining({ nonce: 7 }),
        expect.any(Function),
        expect.any(Function)
      );
    });

    it("does not mark an intent failed when post-broadcast bookkeeping fails", async () => {
      const store = createMemoryStateStore();
      // The 'submitted' write fails *after* writeContract has broadcast the tx. This must not
      // flip the intent to terminal 'failed' (which would let the next run double-submit).
      const realTransition = store.transition;
      store.transition = (async (id, to, meta) => {
        if (to === "submitted") throw new Error("db blip after broadcast");
        return realTransition(id, to, meta);
      }) as typeof store.transition;

      const { bot, clients } = storeBot(store);
      global.fetch = feed([mockPosition]);
      await bot.run();

      expect(clients.sender.send).toHaveBeenCalledOnce();
      expect(store.all()[0]?.status).not.toBe("failed");
    });

    it("stops the cycle on a send error (does not send later candidates at a gapped nonce)", async () => {
      const store = createMemoryStateStore();
      const { bot, clients } = storeBot(store);
      clients.publicClient.getTransactionCount = vi.fn().mockResolvedValue(10);
      const p2: LiquidatablePosition = {
        ...mockPosition,
        proxyAddress: "0xabcdefabcdefabcdefabcdefabcdefabcdefabcd",
        borrower: "0x000000000000000000000000000000000000b0b2",
      };
      const p3: LiquidatablePosition = {
        ...mockPosition,
        proxyAddress: "0xfeedfeedfeedfeedfeedfeedfeedfeedfeedfeed",
        borrower: "0x000000000000000000000000000000000000b0b3",
      };
      clients.sender.send = vi
        .fn()
        .mockResolvedValueOnce("0xA") // p1 @ nonce 10 — ok
        .mockRejectedValueOnce(new Error("send failed")); // p2 @ nonce 11 — fails → break
      global.fetch = feed([mockPosition, p2, p3]);

      await bot.run();

      // p1 sent (10), p2 attempted (11) and failed → cycle stops → p3 NOT attempted.
      expect(clients.sender.send).toHaveBeenCalledTimes(2);
      expect(clients.sender.send).toHaveBeenNthCalledWith(
        1,
        expect.objectContaining({ nonce: 10 }),
        expect.any(Function),
        expect.any(Function)
      );
      expect(clients.sender.send).toHaveBeenNthCalledWith(
        2,
        expect.objectContaining({ nonce: 11 }),
        expect.any(Function),
        expect.any(Function)
      );
    });
  });

  describe("execution identity", () => {
    const feed = () =>
      vi.fn().mockResolvedValue({
        ok: true,
        json: () => Promise.resolve({ liquidatable: [mockPosition], total: 1, checked: 1 }),
      });

    it("reads identity off the sender (intent chain id + simulation `from`)", async () => {
      const store = createMemoryStateStore();
      const clients = createMockClients(); // sender identity: { from: 0xliquidator, chainId: 31337 }
      const bot = createBot(clients, { store });
      global.fetch = feed();

      await bot.run();

      expect(store.all()[0]?.chainId).toBe(31337);
      expect(clients.publicClient.simulateContract).toHaveBeenCalledWith(
        expect.objectContaining({ account: "0xliquidator" })
      );
    });

    it("follows the sender's identity, not the wallet (the keyless-MANUAL substitution)", async () => {
      const store = createMemoryStateStore();
      const clients = createMockClients();
      // A sender carrying the OPERATOR's identity — as a keyless MANUAL bot would inject. The
      // wallet still says chain 31337 / 0xliquidator, but the sender is the source of truth.
      clients.sender = mockSender({ from: "0xoperator" as `0x${string}`, chainId: 424242 });
      const bot = createBot(clients, { store });
      global.fetch = feed();

      await bot.run();

      expect(store.all()[0]?.chainId).toBe(424242);
      expect(clients.publicClient.simulateContract).toHaveBeenCalledWith(
        expect.objectContaining({ account: "0xoperator" })
      );
    });
  });

  // End-to-end at the engine level: a MANUAL bot finds opportunities the same way (risk gate,
  // simulation, all keyless reads) and, at the commit, writes a proposal + notifies instead of
  // broadcasting. The `Executor` seam is unit-tested in `executor.test.ts`; this proves the engine
  // loop drives it correctly — including the keyless promise (no signer nonce reads).
  describe("MANUAL mode (keyless)", () => {
    const OPERATOR = "0xoperator00000000000000000000000000000000" as `0x${string}`;
    // Unlike AUTO's mocked sender, MANUAL's `propose` ABI-encodes the call for real, so the
    // position's addresses must be valid hex.
    const manualPosition: LiquidatablePosition = {
      ...mockPosition,
      borrower: "0x00000000000000000000000000000000000b0b01",
    };
    const feed = () =>
      vi.fn().mockResolvedValue({
        ok: true,
        json: () => Promise.resolve({ liquidatable: [manualPosition], total: 1, checked: 1 }),
      });

    function manualBot(store: MemoryStateStore) {
      const clients = createMockClients();
      const events: NotificationEvent[] = [];
      const notifier: Notifier = { notify: async (e) => void events.push(e) };
      // A keyless publicClient for the executor (reconcile's reader + allowance reads). Its
      // `getTransactionCount` is spied so the test can prove a MANUAL cycle issues NO nonce reads.
      const getTransactionCount = vi.fn(async () => 0);
      const executorPublicClient = {
        getTransaction: vi.fn(async () => ({ hash: "0xhash" })),
        getTransactionReceipt: vi.fn(),
        // Already approved, so a cycle proposes only the liquidation. Approvals now happen inside
        // the cycle rather than at boot, and MANUAL proposes them for an operator to sign — which
        // has its own test below.
        readContract: vi.fn(async () => 2n ** 256n - 1n),
        getTransactionCount,
      } as unknown as PublicClient;
      const executor = createManualExecutor({
        store,
        publicClient: executorPublicClient,
        notifier,
        identity: { from: OPERATOR, chainId: 31337 },
        logger: silentLogger,
        intentTtlMs: 0, // expiry not under test here
        intentStuckMs: 0, // stuck-check not under test here
      });
      // Injecting an executor makes the engine keyless: no `walletClient`, `sender`, or `nonces`.
      // The adapter/LLP addresses must be real hex too — MANUAL encodes the call + hashes the
      // payload (`getAddress`) for real, where AUTO's mocked sender skips both.
      const bot = createBot(clients, {
        store,
        executor,
        adapterAddress: "0x00000000000000000000000000000000000ada01",
        llpAddress: "0x0000000000000000000000000000000000011b01",
      });
      return { bot, clients, events, getTransactionCount };
    }

    it("proposes + notifies for a liquidatable position, broadcasting nothing", async () => {
      const store = createMemoryStateStore();
      const { bot, clients, events } = manualBot(store);
      global.fetch = feed();

      await bot.run();

      // A proposal was persisted (keyless: `proposed`, no nonce) — not a broadcast.
      const row = store.all()[0];
      expect(row).toMatchObject({
        action: "liquidation",
        subject: mockPosition.proxyAddress,
        status: "proposed",
        nonce: null,
      });
      // The operator was notified once, with the payload hash out-of-band (their tamper check).
      expect(events).toHaveLength(1);
      expect(events[0]).toMatchObject({
        kind: "manual-intent",
        action: "liquidation",
        subject: mockPosition.proxyAddress,
        payloadHash: row?.payloadHash,
      });
      // Nothing was signed or broadcast — the (unused) AUTO sender is never touched.
      expect(clients.sender.send).not.toHaveBeenCalled();
    });

    it("issues no signer nonce reads across the cycle (the keyless bar)", async () => {
      const store = createMemoryStateStore();
      const { bot, clients, getTransactionCount } = manualBot(store);
      global.fetch = feed();

      await bot.run();

      expect(getTransactionCount).not.toHaveBeenCalled();
      expect(clients.publicClient.getTransactionCount).not.toHaveBeenCalled();
    });

    it("dedups across cycles — one proposal, one notification for a stable position", async () => {
      const store = createMemoryStateStore();
      const { bot, events } = manualBot(store);
      global.fetch = feed();

      await bot.run();
      await bot.run();

      expect(store.all()).toHaveLength(1);
      expect(events).toHaveLength(1);
    });
  });

  // The indexer is untrusted, so its candidate list is trimmed before any RPC and estimated in chunks.
  describe("candidate intake", () => {
    /**
     * `MAX_LIQUIDATION_CANDIDATES + 100` distinct positions, each with its own borrower, on clients
     * whose adapter maps each borrower back to its proxy. `onEstimate` sees each Lens call; no
     * candidate proceeds past the Lens, because these tests are about which ones reach it.
     */
    function longFeed(onEstimate: (proxy: string) => Promise<void> | void) {
      const clients = createMockClients();
      const base = clients.publicClient.readContract;
      const proxyOf = new Map<string, string>();
      const distinct = Array.from({ length: MAX_LIQUIDATION_CANDIDATES + 100 }, (_, i) => {
        const proxyAddress = `0x${(i + 1).toString(16).padStart(40, "0")}`;
        const borrower = `0xb${(i + 1).toString(16).padStart(39, "0")}`;
        proxyOf.set(borrower, proxyAddress);
        return { ...mockPosition, proxyAddress, borrower };
      });
      clients.publicClient.readContract = vi.fn(
        async (args: { functionName: string; args?: unknown[] }) => {
          if (args.functionName === "getPosition") {
            return {
              vaultIds: [],
              totalCollateralBTC: 1n,
              proxyContract: proxyOf.get(String(args.args?.[0])),
            };
          }
          if (args.functionName !== "estimateLiquidation") return base(args);
          await onEstimate(String(args.args?.[0]));
          throw new Error("healthy position");
        }
      );
      return { clients, distinct };
    }

    const feedOf = (liquidatable: unknown[]) =>
      vi.fn().mockResolvedValue({
        ok: true,
        json: () => Promise.resolve({ liquidatable, total: 0, checked: 0 }),
      });

    it("estimates at most the capped number of distinct positions, a chunk at a time", async () => {
      let calls = 0;
      let active = 0;
      let peak = 0;
      const { clients, distinct } = longFeed(async () => {
        calls++;
        active++;
        peak = Math.max(peak, active);
        await new Promise((resolve) => setTimeout(resolve, 0));
        active--;
      });
      global.fetch = feedOf([...distinct, ...distinct]);

      await createBot(clients).run();

      expect(calls).toBe(MAX_LIQUIDATION_CANDIDATES);
      expect(peak).toBeLessThanOrEqual(LENS_ESTIMATE_CHUNK);
    });

    // Candidates the bot cannot clear stay liquidatable. A window fixed at the start of the list
    // would hold them every cycle, and the positions after them would never be estimated.
    it("moves the window on each cycle, so a long list is covered", async () => {
      let cycle: string[] = [];
      const { clients, distinct } = longFeed((proxy) => {
        cycle.push(proxy);
      });
      global.fetch = feedOf(distinct);
      const bot = createBot(clients);
      const proxies = (from: number, to: number) =>
        distinct.slice(from, to).map((p) => p.proxyAddress);

      await bot.run();
      const first = cycle;
      cycle = [];
      await bot.run();

      expect(first).toEqual(proxies(0, MAX_LIQUIDATION_CANDIDATES));
      expect(cycle).toEqual([
        ...proxies(MAX_LIQUIDATION_CANDIDATES, distinct.length),
        ...proxies(0, 400),
      ]);
    });
  });

  // The Lens estimates the proxy, but the liquidation charges the borrower, and the indexer supplies
  // both. A candidate whose pair the adapter does not confirm never reaches the Lens.
  describe("borrower check", () => {
    const OTHER_PROXY = "0x00000000000000000000000000000000000000c1";

    /** Clients that record every proxy sent to the Lens, with an optional `getPosition` override. */
    function countingClients(getPosition?: () => Promise<unknown>) {
      const clients = createMockClients();
      const base = clients.publicClient.readContract;
      const estimated: string[] = [];
      clients.publicClient.readContract = vi.fn(
        async (args: { functionName: string; args?: unknown[] }) => {
          if (args.functionName === "estimateLiquidation") estimated.push(String(args.args?.[0]));
          if (args.functionName === "getPosition" && getPosition) return getPosition();
          return base(args);
        }
      );
      return { clients, estimated };
    }

    const feed = (liquidatable: unknown[]) =>
      vi.fn().mockResolvedValue({
        ok: true,
        json: () =>
          Promise.resolve({
            liquidatable,
            total: liquidatable.length,
            checked: liquidatable.length,
          }),
      });

    it("drops a second proxy paired with the same borrower", async () => {
      const { clients, estimated } = countingClients();
      global.fetch = feed([mockPosition, { ...mockPosition, proxyAddress: OTHER_PROXY }]);

      await createBot(clients).run();

      expect(estimated).toEqual([mockPosition.proxyAddress]);
    });

    // The adapter reverts for a borrower it has no position for, so a failed read drops the candidate.
    it("drops a candidate whose borrower the adapter cannot resolve", async () => {
      const { clients, estimated } = countingClients(async () => {
        throw new Error("InvalidProxyContract");
      });
      global.fetch = feed([mockPosition]);

      await createBot(clients).run();

      expect(estimated).toEqual([]);
    });
  });
});
