import type { NonceAllocator } from "@repo/execution";
import type { Logger } from "@repo/logger";
import { type StateStore, createPostgresStateStore, idempotencyKey } from "@repo/persistence";
import pg from "pg";
import type { Address, Hex, PublicClient } from "viem";
import { afterAll, beforeAll, beforeEach, describe, expect, it, vi } from "vitest";

import { createCrashSafety } from "./crashSafety";
import { type ChainReader, createChainReader } from "./liveness";
import { reconcilePending } from "./reconcile";

// Crash-safety against a **real Postgres**, the store production actually runs on. The unit tests
// use the in-memory model, which cannot catch a schema, transaction, or upsert bug — and
// no-double-submit is exactly the property those bugs would break.
//
// Runs only when a connection string is configured; otherwise the block skips, so `pnpm test`
// stays offline by default. CI supplies it (see .github/workflows/ci.yml).
//
//   pnpm liquidator:db:up
//   export PERSISTENCE_E2E_DATABASE_URL=postgresql://ponder:ponder@localhost:5432/ponder
//   pnpm --filter @repo/engine test crashSafety.integration

const DATABASE_URL = process.env.PERSISTENCE_E2E_DATABASE_URL;
const SCHEMA = `bot_e2e_engine_${Date.now()}`;
const TIMEOUT = 20_000;

const SIGNER = "0x1111111111111111111111111111111111111111" as Address;
const TARGET = "0x2222222222222222222222222222222222222222" as Address;
const TX = "0xhash" as Hex;

const silentLogger: Logger = { debug: vi.fn(), info: vi.fn(), warn: vi.fn(), error: vi.fn() };

const intent = (subject: string) => ({
  chainId: 31337,
  target: TARGET,
  action: "liquidation",
  subject,
});

/**
 * A `ChainReader` with scripted receipts and nonce counts. `known` defaults to `true` — a
 * recorded hash the node still knows about, i.e. a tx that really was broadcast.
 */
const reader = (over: {
  receipts?: Record<string, "success" | "reverted" | null>;
  latest?: number;
  pending?: number;
  known?: boolean;
}): ChainReader => ({
  async getReceiptStatus(hash) {
    return over.receipts?.[hash] ?? null;
  },
  async getNonce(_address, tag) {
    return (tag === "latest" ? over.latest : over.pending) ?? 0;
  },
  async getBlockNumber() {
    return 0;
  },
  async findSafeExecution() {
    return null;
  },
  async getSafeExecution() {
    return null;
  },
  async isKnown() {
    return over.known ?? true;
  },
});

const publicClient = { getTransactionCount: vi.fn(async () => 0) } as unknown as PublicClient;

/** A pass-through allocator (identity nonce sequencing) — these tests exercise the store, not the lease. */
const allocator = (): NonceAllocator => ({ withNonce: (send) => send(0), resync: async () => {} });

const crashSafety = (store: StateStore) =>
  createCrashSafety({
    store,
    nonces: allocator(),
    reader: createChainReader(publicClient),
    signer: SIGNER,
    logger: silentLogger,
  });

describe.skipIf(!DATABASE_URL)("crash-safety over a real Postgres StateStore", () => {
  let store: StateStore;

  beforeAll(async () => {
    store = createPostgresStateStore({ connectionString: DATABASE_URL as string, schema: SCHEMA });
    // Force the lazy DDL so `beforeEach` can truncate.
    await store.reconcile();
  }, TIMEOUT);

  afterAll(async () => {
    await store.close();
    const admin = new pg.Client({ connectionString: DATABASE_URL });
    await admin.connect();
    await admin.query(`DROP SCHEMA IF EXISTS ${SCHEMA} CASCADE`);
    await admin.end();
  }, TIMEOUT);

  beforeEach(async () => {
    const admin = new pg.Client({ connectionString: DATABASE_URL });
    await admin.connect();
    await admin.query(`TRUNCATE ${SCHEMA}.tx_intents`);
    await admin.end();
  }, TIMEOUT);

  // The headline guarantee. A second process (or a re-drive after a crash) must not re-broadcast
  // an action whose intent is still live on chain.
  it(
    "refuses a duplicate live intent across two CrashSafety instances",
    async () => {
      const first = await crashSafety(store).claim(intent("pos-1"));
      expect(first).toEqual({
        claimed: true,
        intentId: idempotencyKey(intent("pos-1")),
        attemptAt: expect.any(Number),
      });

      // A fresh process over the same durable store — the restart case.
      const second = await crashSafety(store).claim(intent("pos-1"));

      expect(second.claimed).toBe(false);
      expect(second.existing).toMatchObject({ subject: "pos-1" });
    },
    TIMEOUT
  );

  it(
    "allows a re-drive once the intent reaches a terminal state",
    async () => {
      const cs = crashSafety(store);
      const { intentId } = await cs.claim(intent("pos-1"));
      if (!intentId) throw new Error("expected an intent id");

      await cs.transition(intentId, "failed", { error: "reverted" });

      expect(await cs.claim(intent("pos-1"))).toMatchObject({ claimed: true });
    },
    TIMEOUT
  );

  // markPending is the durability barrier: if the nonce cannot be persisted we must not broadcast.
  it(
    "markPending durably records the reserved nonce before broadcast",
    async () => {
      const cs = crashSafety(store);
      const { intentId, attemptAt } = await cs.claim(intent("pos-1"));
      if (!intentId || attemptAt === undefined) throw new Error("expected an intent id");

      await cs.markPending(intentId, 7, attemptAt);

      const [live] = await store.reconcile();
      expect(live).toMatchObject({ subject: "pos-1", nonce: 7, status: "pending" });
    },
    TIMEOUT
  );

  describe("reconcilePending resolves a crashed run against the chain", () => {
    it(
      "confirms an intent whose tx mined successfully",
      async () => {
        const cs = crashSafety(store);
        const { intentId, attemptAt } = await cs.claim(intent("pos-1"));
        if (!intentId || attemptAt === undefined) throw new Error("expected an intent id");
        await cs.markPending(intentId, 5, attemptAt);
        await cs.transition(intentId, "submitted", { txHash: TX });
        // …process dies here…

        const summary = await reconcilePending({
          store,
          signer: SIGNER,
          reader: reader({ receipts: { [TX]: "success" }, latest: 5, pending: 6 }),
        });

        expect(summary).toMatchObject({ examined: 1, confirmed: 1, failed: 0 });
        expect(await store.reconcile()).toHaveLength(0); // nothing left in flight
      },
      TIMEOUT
    );

    // The dangerous direction: an intent that was never broadcast must become re-drivable, and one
    // still in the mempool must NOT — re-driving it would double-submit.
    it(
      "frees a never-broadcast intent but holds one still in the mempool",
      async () => {
        const cs = crashSafety(store);
        const a = await cs.claim(intent("never-sent"));
        const b = await cs.claim(intent("in-mempool"));
        if (!a.intentId || !b.intentId) throw new Error("expected intent ids");
        await cs.markPending(a.intentId, 9, a.attemptAt as number); // nonce 9, chain never saw it
        await cs.markPending(b.intentId, 7, b.attemptAt as number); // nonce 7, in the mempool

        const summary = await reconcilePending({
          store,
          signer: SIGNER,
          reader: reader({ latest: 7, pending: 8 }), // nonce 7 pending; 9 untouched
        });

        expect(summary).toMatchObject({ examined: 2, failed: 1, stillInFlight: 1 });

        // never-sent is terminal ⇒ re-drivable; in-mempool is still live ⇒ refused.
        expect(await cs.claim(intent("never-sent"))).toMatchObject({ claimed: true });
        expect(await cs.claim(intent("in-mempool"))).toMatchObject({ claimed: false });
      },
      TIMEOUT
    );

    it(
      "leaves everything untouched when the chain is unreachable (fail closed)",
      async () => {
        const cs = crashSafety(store);
        const { intentId, attemptAt } = await cs.claim(intent("pos-1"));
        if (!intentId || attemptAt === undefined) throw new Error("expected an intent id");
        await cs.markPending(intentId, 5, attemptAt);
        await cs.transition(intentId, "submitted", { txHash: TX });

        const outage: ChainReader = {
          getReceiptStatus: async () => {
            throw new Error("ECONNREFUSED");
          },
          getNonce: async () => 9, // chain has moved past nonce 5
          getBlockNumber: async () => 0,
          getSafeExecution: async () => null,
          findSafeExecution: async () => null,
          isKnown: async () => {
            throw new Error("ECONNREFUSED");
          },
        };

        await expect(reconcilePending({ store, signer: SIGNER, reader: outage })).rejects.toThrow(
          "ECONNREFUSED"
        );

        // Still 'submitted' — NOT marked failed, so the next cycle cannot re-drive a mined tx.
        const [live] = await store.reconcile();
        expect(live).toMatchObject({ subject: "pos-1", status: "submitted" });
      },
      TIMEOUT
    );
  });
});
