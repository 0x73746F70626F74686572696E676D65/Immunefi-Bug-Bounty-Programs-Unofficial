import { type Hex, RpcRequestError, TransactionRejectedRpcError, keccak256, parseAbi } from "viem";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import {
  type ContractCall,
  PreBroadcastError,
  type ProposedTx,
  type SignedTx,
  SubmitRejectedError,
  createNonceAllocator,
  createNonceLease,
  createTxSender,
  encodeCall,
  hashPayload,
  nextNonce,
  waitForReceipt,
  waitForReceiptWithTimeout,
} from "./index";

const HASH = "0xhash" as `0x${string}`;
const ADDR = "0xaddr" as `0x${string}`;
const SIGNER = "0x1111111111111111111111111111111111111111" as `0x${string}`;

type PublicClientArg = Parameters<typeof waitForReceipt>[0];
type WalletClientArg = Parameters<typeof createTxSender>[1];

const SERIALIZED = "0xdeadbeef" as `0x${string}`;
/** The hash the node would report for `SERIALIZED` — derivable locally, before broadcast. */
const SIGNED_HASH = keccak256(SERIALIZED);

const CALL: ContractCall = {
  address: "0xcontract",
  abi: [
    {
      type: "function",
      name: "ping",
      inputs: [],
      outputs: [],
      stateMutability: "nonpayable",
    },
  ],
  functionName: "ping",
  args: [],
  nonce: 7,
};

/** Wallet/public client stubs recording the assemble → sign → broadcast sequence. */
function txClients(
  over: {
    sendRawTransaction?: () => Promise<`0x${string}`>;
    /** What the node prices the transaction at. Omitted ⇒ an EIP-1559 pair with a 1 wei tip. */
    fees?: Record<string, bigint>;
  } = {}
) {
  const walletClient = {
    account: { address: SIGNER },
    chain: { id: 31337 },
    prepareTransactionRequest: vi.fn(async (req: { nonce?: number }) => ({
      ...req,
      nonce: req.nonce ?? 42, // viem fills it from the chain when the caller left it out
      ...(over.fees ?? { maxFeePerGas: 101n, maxPriorityFeePerGas: 1n }),
    })),
    signTransaction: vi.fn().mockResolvedValue(SERIALIZED),
  };
  const publicClient = {
    sendRawTransaction:
      over.sendRawTransaction === undefined
        ? vi.fn().mockResolvedValue(SIGNED_HASH)
        : vi.fn(over.sendRawTransaction),
  };
  return { walletClient, publicClient };
}

describe("@repo/execution", () => {
  describe("nextNonce", () => {
    it("reads the pending transaction count", async () => {
      const client = { getTransactionCount: vi.fn().mockResolvedValue(7) };
      const nonce = await nextNonce(client as unknown as PublicClientArg, ADDR);

      expect(nonce).toBe(7);
      expect(client.getTransactionCount).toHaveBeenCalledWith({
        address: ADDR,
        blockTag: "pending",
      });
    });
  });

  describe("waitForReceipt", () => {
    beforeEach(() => vi.useFakeTimers());
    afterEach(() => vi.useRealTimers());

    it("returns the receipt when it resolves before the timeout", async () => {
      const receipt = { status: "success", blockNumber: 1n };
      const client = { waitForTransactionReceipt: vi.fn().mockResolvedValue(receipt) };

      // Do not advance timers: the timeout rejecter never fires.
      await expect(waitForReceipt(client as unknown as PublicClientArg, HASH, 5000)).resolves.toBe(
        receipt
      );
    });

    it("returns null when the timeout elapses first", async () => {
      const client = { waitForTransactionReceipt: () => new Promise(() => {}) }; // never resolves
      const promise = waitForReceipt(client as unknown as PublicClientArg, HASH, 5000);

      await vi.advanceTimersByTimeAsync(5000);
      await expect(promise).resolves.toBeNull();
    });

    it("re-throws non-timeout errors", async () => {
      const client = {
        waitForTransactionReceipt: vi.fn().mockRejectedValue(new Error("rpc down")),
      };
      await expect(
        waitForReceipt(client as unknown as PublicClientArg, HASH, 5000)
      ).rejects.toThrow("rpc down");
    });
  });

  describe("waitForReceiptWithTimeout", () => {
    beforeEach(() => {
      vi.useFakeTimers();
      vi.spyOn(console, "warn").mockImplementation(() => {});
    });
    afterEach(() => {
      vi.useRealTimers();
      vi.restoreAllMocks();
    });

    it("warns with the context prefix on timeout and returns null", async () => {
      const client = { waitForTransactionReceipt: () => new Promise(() => {}) };
      const promise = waitForReceiptWithTimeout(
        client as unknown as PublicClientArg,
        HASH,
        5000,
        "swap"
      );

      await vi.advanceTimersByTimeAsync(5000);
      await expect(promise).resolves.toBeNull();
      expect(console.warn).toHaveBeenCalledWith(expect.stringContaining("swap "));
      expect(console.warn).toHaveBeenCalledWith(expect.stringContaining(HASH));
    });

    it("does not warn when the receipt arrives in time", async () => {
      const receipt = { status: "success" };
      const client = { waitForTransactionReceipt: vi.fn().mockResolvedValue(receipt) };

      await expect(
        waitForReceiptWithTimeout(client as unknown as PublicClientArg, HASH, 5000)
      ).resolves.toBe(receipt);
      expect(console.warn).not.toHaveBeenCalled();
    });
  });

  describe("NonceAllocator", () => {
    const setup = () => {
      const lease = createNonceLease();
      return { alloc: createNonceAllocator(lease, SIGNER) };
    };

    it("reserve throws until seeded, then allocates from the chain seed", async () => {
      const { alloc } = setup();
      await expect(alloc.withNonce(async (n) => n)).rejects.toThrow(/not seeded/);

      await alloc.resync(() => Promise.resolve(10));
      expect(await alloc.withNonce(async (n) => n)).toBe(10);
      expect(await alloc.withNonce(async (n) => n)).toBe(11);
    });

    it("hands concurrent callers a gapless, duplicate-free sequence", async () => {
      const { alloc } = setup();
      await alloc.resync(() => Promise.resolve(0));

      const nonces = await Promise.all(
        Array.from({ length: 20 }, () => alloc.withNonce(async (n) => n))
      );

      expect(nonces).toEqual([...Array(20).keys()]); // 0..19, in call order
      expect(new Set(nonces).size).toBe(20); // no duplicates
    });

    it("does NOT reuse the nonce after a thrown send (no rollback)", async () => {
      const { alloc } = setup();
      await alloc.resync(() => Promise.resolve(5));

      await expect(
        alloc.withNonce(async () => {
          throw new Error("ambiguous send");
        })
      ).rejects.toThrow("ambiguous send");

      // 5 is burned; the next send gets 6 (reclaim is the chain's job, not a rollback).
      expect(await alloc.withNonce(async (n) => n)).toBe(6);
    });

    it("a rejected section does not poison the lock chain", async () => {
      const { alloc } = setup();
      await alloc.resync(() => Promise.resolve(0));

      await expect(
        alloc.withNonce(async () => {
          throw new Error("x");
        })
      ).rejects.toThrow("x");
      expect(await alloc.withNonce(async (n) => n)).toBe(1);
    });

    it("serializes resync against an in-flight withNonce (no mid-flight rewind)", async () => {
      const { alloc } = setup();
      await alloc.resync(() => Promise.resolve(5));

      let release!: () => void;
      const gate = new Promise<void>((r) => {
        release = r;
      });

      const p1 = alloc.withNonce(async (n) => {
        await gate; // hold the lock at nonce 5
        return n;
      });
      const p2 = alloc.resync(() => Promise.resolve(100)); // queued behind p1
      const p3 = alloc.withNonce(async (n) => n); // queued behind resync

      release();
      expect(await p1).toBe(5);
      await p2;
      expect(await p3).toBe(100); // saw the resync, not a stale 6
    });

    it("reads the chain INSIDE the lock (no lost update vs an in-flight withNonce)", async () => {
      const { alloc } = setup();
      await alloc.resync(() => Promise.resolve(5));

      let chain = 5;
      let release!: () => void;
      const gate = new Promise<void>((r) => {
        release = r;
      });

      // In-flight send reserves 5 and, while the lock is held, "broadcasts" — advancing the
      // chain to 6. A resync whose read happened OUTSIDE the lock would capture the stale 5
      // and rewind; reading inside the lock sees 6.
      const p1 = alloc.withNonce(async (n) => {
        await gate;
        chain = 6;
        return n;
      });
      const p2 = alloc.resync(async () => chain);

      release();
      expect(await p1).toBe(5);
      await p2;
      expect(await alloc.withNonce(async (n) => n)).toBe(6); // not rewound to a stale 5
    });

    it("resync SET pulls the lease down to reclaim (Case C)", async () => {
      const { alloc } = setup();
      await alloc.resync(() => Promise.resolve(20));
      expect(await alloc.withNonce(async (n) => n)).toBe(20);

      await alloc.resync(() => Promise.resolve(10)); // chain shows 10 free (e.g. a dropped tx)
      expect(await alloc.withNonce(async (n) => n)).toBe(10);
    });
  });

  // The node prices a transaction for the public mempool. A privately-submitted one is not in that
  // market at all: it is offered to builders, never pooled, and never re-priced — so an under-tipped
  // one is not slow, it never lands, and the fence re-drives it at the same price. The floor is the
  // operator's only lever on that, and it has to bite before signing, because the relay is handed
  // bytes that are already signed.
  describe("priority-fee floor", () => {
    const signed = (walletClient: { signTransaction: { mock: { calls: unknown[][] } } }) =>
      walletClient.signTransaction.mock.calls[0][0] as {
        maxFeePerGas: bigint;
        maxPriorityFeePerGas: bigint;
      };

    it("raises a tip the node priced below the floor, and the fee cap with it", async () => {
      const { walletClient, publicClient } = txClients();
      const sender = createTxSender(
        publicClient as unknown as PublicClientArg,
        walletClient as unknown as WalletClientArg,
        undefined,
        { minPriorityFeeWei: 5n }
      );

      await sender.send(CALL);

      // Both move by the same delta, so the 100 wei of base-fee headroom the node left survives the
      // bump. Raising the tip alone would eat it — and at a high base fee, exceed the cap outright.
      expect(signed(walletClient)).toMatchObject({ maxPriorityFeePerGas: 5n, maxFeePerGas: 105n });
    });

    it("leaves a tip that already clears the floor alone", async () => {
      const { walletClient, publicClient } = txClients({
        fees: { maxFeePerGas: 200n, maxPriorityFeePerGas: 9n },
      });
      const sender = createTxSender(
        publicClient as unknown as PublicClientArg,
        walletClient as unknown as WalletClientArg,
        undefined,
        { minPriorityFeeWei: 5n }
      );

      await sender.send(CALL);

      expect(signed(walletClient)).toMatchObject({ maxPriorityFeePerGas: 9n, maxFeePerGas: 200n });
    });

    it("does not touch the node's price when no floor is configured", async () => {
      const { walletClient, publicClient } = txClients();
      const sender = createTxSender(
        publicClient as unknown as PublicClientArg,
        walletClient as unknown as WalletClientArg
      );

      await sender.send(CALL);

      expect(signed(walletClient)).toMatchObject({ maxPriorityFeePerGas: 1n, maxFeePerGas: 101n });
    });

    // Refused rather than sent at whatever the node said: a floor was configured because the
    // operator judged an un-floored private submission would not land, and honouring it silently
    // in name only reproduces exactly the failure it was set to prevent.
    it("refuses to sign a legacy-priced transaction under a floor, without broadcasting", async () => {
      const { walletClient, publicClient } = txClients({ fees: { gasPrice: 100n } });
      const sender = createTxSender(
        publicClient as unknown as PublicClientArg,
        walletClient as unknown as WalletClientArg,
        undefined,
        { minPriorityFeeWei: 5n }
      );

      await expect(sender.send(CALL)).rejects.toThrow(PreBroadcastError);
      expect(walletClient.signTransaction).not.toHaveBeenCalled();
      expect(publicClient.sendRawTransaction).not.toHaveBeenCalled();
    });
  });

  describe("createTxSender", () => {
    it("exposes its identity, derived from the wallet (from + chainId)", () => {
      const { walletClient, publicClient } = txClients();
      const sender = createTxSender(
        publicClient as unknown as PublicClientArg,
        walletClient as unknown as WalletClientArg
      );
      // Identity rides with the sender — a caller never wires it separately.
      expect(sender.identity).toEqual({ from: SIGNER, chainId: 31337 });
    });

    it("hands the signed hash to onSigned BEFORE broadcasting", async () => {
      const { walletClient, publicClient } = txClients();
      const order: string[] = [];
      publicClient.sendRawTransaction.mockImplementation(async () => {
        order.push("broadcast");
        return SIGNED_HASH;
      });
      const sender = createTxSender(
        publicClient as unknown as PublicClientArg,
        walletClient as unknown as WalletClientArg
      );

      let recorded: SignedTx | undefined;
      const hash = await sender.send(CALL, async (tx) => {
        order.push("onSigned");
        recorded = tx;
      });

      // The whole point: the hash is durable while the tx is still purely local.
      expect(order).toEqual(["onSigned", "broadcast"]);
      expect(recorded).toEqual({ hash: SIGNED_HASH, nonce: 7, serialized: SERIALIZED });
      expect(hash).toBe(SIGNED_HASH);
      expect(publicClient.sendRawTransaction).toHaveBeenCalledWith({
        serializedTransaction: SERIALIZED,
      });
    });

    it("does NOT broadcast when the durable record fails", async () => {
      const { walletClient, publicClient } = txClients();
      const sender = createTxSender(
        publicClient as unknown as PublicClientArg,
        walletClient as unknown as WalletClientArg
      );

      await expect(
        sender.send(CALL, async () => {
          throw new Error("store unavailable");
        })
      ).rejects.toThrow("store unavailable");

      // Nothing reached the chain, so the reserved nonce is still free — the caller may treat
      // this exactly like any other send failure.
      expect(publicClient.sendRawTransaction).not.toHaveBeenCalled();
    });

    // The guard runs after all awaited work, so a halt that lands during it is still caught.
    it("asks beforeBroadcast last, after the durable record and before the wire", async () => {
      const { walletClient, publicClient } = txClients();
      const order: string[] = [];
      publicClient.sendRawTransaction.mockImplementation(async () => {
        order.push("broadcast");
        return SIGNED_HASH;
      });
      const sender = createTxSender(
        publicClient as unknown as PublicClientArg,
        walletClient as unknown as WalletClientArg
      );

      await sender.send(
        CALL,
        async () => {
          order.push("onSigned");
        },
        () => {
          order.push("beforeBroadcast");
        }
      );

      expect(order).toEqual(["onSigned", "beforeBroadcast", "broadcast"]);
    });

    it("does NOT broadcast when beforeBroadcast refuses, and says nothing was sent", async () => {
      const { walletClient, publicClient } = txClients();
      const sender = createTxSender(
        publicClient as unknown as PublicClientArg,
        walletClient as unknown as WalletClientArg
      );

      await expect(
        sender.send(CALL, undefined, () => {
          throw new Error("halted");
        })
      ).rejects.toThrow(PreBroadcastError);

      expect(publicClient.sendRawTransaction).not.toHaveBeenCalled();
    });

    // A caller cannot settle its risk slot correctly without knowing WHICH side of the
    // broadcast it failed on: everything before the wire is `abandoned` (nothing is on chain,
    // so it says nothing about whether the chain is rejecting us), and only a failed broadcast
    // is a genuine failure signal. Conflating them lets a database or RPC blip trip the
    // consecutive-failure breaker and halt the bot.
    describe("pre-broadcast failures are distinguishable from broadcast failures", () => {
      it("types a failed durable record as PreBroadcastError", async () => {
        const { walletClient, publicClient } = txClients();
        const sender = createTxSender(
          publicClient as unknown as PublicClientArg,
          walletClient as unknown as WalletClientArg
        );

        const error = await sender
          .send(CALL, async () => {
            throw new Error("store unavailable");
          })
          .catch((e) => e);

        expect(error).toBeInstanceOf(PreBroadcastError);
        expect(error.cause).toBeInstanceOf(Error); // the original is preserved, not swallowed
        expect(error.message).toBe("store unavailable");
      });

      it("types a failed signing as PreBroadcastError", async () => {
        const { walletClient, publicClient } = txClients();
        walletClient.signTransaction.mockRejectedValue(new Error("signer offline"));
        const sender = createTxSender(
          publicClient as unknown as PublicClientArg,
          walletClient as unknown as WalletClientArg
        );

        await expect(sender.send(CALL)).rejects.toBeInstanceOf(PreBroadcastError);
        expect(publicClient.sendRawTransaction).not.toHaveBeenCalled();
      });

      it("does NOT type an ambiguous broadcast failure as PreBroadcastError", async () => {
        const { walletClient, publicClient } = txClients({
          sendRawTransaction: () => Promise.reject(new Error("rpc timeout")),
        });
        const sender = createTxSender(
          publicClient as unknown as PublicClientArg,
          walletClient as unknown as WalletClientArg
        );

        // The tx may be in flight — the caller MUST treat this as a real failure, not abandon it.
        const error = await sender.send(CALL, async () => {}).catch((e) => e);
        expect(error).not.toBeInstanceOf(PreBroadcastError);
        expect(error.message).toBe("rpc timeout");
      });

      // A submitter that says outright "I never broadcast this" is believed, without any inspection
      // of the error's text. That is what lets a second backend (the private relay) classify its own
      // rejections instead of having `isInsufficientFunds` — which only understands viem-against-a-
      // node — silently call every relay error ambiguous and march the breaker toward a halt.
      it("types a submitter's own declared rejection as PreBroadcastError", async () => {
        const { walletClient, publicClient } = txClients({});
        const sender = createTxSender(
          publicClient as unknown as PublicClientArg,
          walletClient as unknown as WalletClientArg,
          () => Promise.reject(new SubmitRejectedError("invalid transaction"))
        );

        await expect(sender.send(CALL, async () => {})).rejects.toBeInstanceOf(PreBroadcastError);
      });

      // The other half of the same contract: a submitter that does NOT declare it stays ambiguous,
      // so an unrecognised relay failure can never free a nonce under a live transaction.
      it("leaves an undeclared submitter failure ambiguous", async () => {
        const { walletClient, publicClient } = txClients({});
        const sender = createTxSender(
          publicClient as unknown as PublicClientArg,
          walletClient as unknown as WalletClientArg,
          () => Promise.reject(new Error("flashbots submit failed: HTTP 502"))
        );

        const error = await sender.send(CALL, async () => {}).catch((e) => e);
        expect(error).not.toBeInstanceOf(PreBroadcastError);
        expect(error.message).toMatch(/HTTP 502/);
      });

      // A node that refuses the broadcast for insufficient funds queued nothing, so unlike the
      // ambiguous case above this IS a clean abort. It has to be: an empty gas tank is an ops
      // problem, and settling it as a real failure would march the consecutive-failure breaker
      // toward halting a bot whose trades the chain never objected to. Only strict nodes catch
      // this while preparing; on a lenient one it arrives here, so both paths must agree.
      it.each([
        ["Insufficient funds for gas * price + value", "anvil, capitalised"],
        ["insufficient funds for transfer", "geth, lower case"],
        ["exceeds transaction sender account balance", "the other upstream wording"],
      ])("types a broadcast refused with %j as PreBroadcastError (%s)", async (details) => {
        const { walletClient, publicClient } = txClients({
          sendRawTransaction: () =>
            Promise.reject(
              new TransactionRejectedRpcError(
                new RpcRequestError({
                  body: {},
                  error: { code: -32003, message: details },
                  url: "http://node",
                })
              )
            ),
        });
        const sender = createTxSender(
          publicClient as unknown as PublicClientArg,
          walletClient as unknown as WalletClientArg
        );

        await expect(sender.send(CALL, async () => {})).rejects.toBeInstanceOf(PreBroadcastError);
      });

      it("still does NOT abandon a nonce-too-low rejection", async () => {
        // Same error class, opposite meaning: a tx with that nonce is already on chain, so this is
        // emphatically not a clean abort and must stay ambiguous.
        const { walletClient, publicClient } = txClients({
          sendRawTransaction: () =>
            Promise.reject(
              new TransactionRejectedRpcError(
                new RpcRequestError({
                  body: {},
                  error: { code: -32003, message: "nonce too low" },
                  url: "http://node",
                })
              )
            ),
        });
        const sender = createTxSender(
          publicClient as unknown as PublicClientArg,
          walletClient as unknown as WalletClientArg
        );

        await expect(sender.send(CALL, async () => {})).rejects.not.toBeInstanceOf(
          PreBroadcastError
        );
      });
    });

    it("reports the signed nonce when the caller does not reserve one", async () => {
      const { walletClient, publicClient } = txClients();
      const sender = createTxSender(
        publicClient as unknown as PublicClientArg,
        walletClient as unknown as WalletClientArg
      );

      let recorded: SignedTx | undefined;
      await sender.send({ ...CALL, nonce: undefined }, async (tx) => {
        recorded = tx;
      });

      // viem filled the nonce from the chain — the record must carry THAT, not `undefined`,
      // or reconcile cannot tell a broadcast tx from one that never went out.
      expect(recorded?.nonce).toBe(42);
    });

    it("surfaces an ambiguous broadcast failure after the hash is already durable", async () => {
      const { walletClient, publicClient } = txClients({
        sendRawTransaction: () => Promise.reject(new Error("rpc timeout")),
      });
      const sender = createTxSender(
        publicClient as unknown as PublicClientArg,
        walletClient as unknown as WalletClientArg
      );

      let recorded: SignedTx | undefined;
      await expect(
        sender.send(CALL, async (tx) => {
          recorded = tx;
        })
      ).rejects.toThrow("rpc timeout");

      // The tx may or may not have propagated — but its hash is recorded either way, so
      // reconcile resolves it by receipt lookup rather than inferring from the nonce.
      expect(recorded?.hash).toBe(SIGNED_HASH);
    });

    it("broadcasts through a custom submit (e.g. a private relay)", async () => {
      const { walletClient, publicClient } = txClients();
      const submit = vi.fn().mockResolvedValue(SIGNED_HASH);
      const sender = createTxSender(
        publicClient as unknown as PublicClientArg,
        walletClient as unknown as WalletClientArg,
        submit
      );

      await sender.send(CALL);

      expect(submit).toHaveBeenCalledWith(SERIALIZED);
      expect(publicClient.sendRawTransaction).not.toHaveBeenCalled();
    });
  });

  describe("encodeCall", () => {
    it("encodes a call to its { to, data }", () => {
      const call: ContractCall = {
        address: "0x000000000000000000000000000000000000dEaD",
        abi: parseAbi(["function ping(uint256 value)"]),
        functionName: "ping",
        args: [1n],
      };
      const { to, data } = encodeCall(call);
      expect(to).toBe("0x000000000000000000000000000000000000dEaD");
      expect(data).toMatch(/^0x[0-9a-f]+$/); // encoded selector + arg
      expect(data.length).toBe(2 + 8 + 64); // selector (4 bytes) + one uint256
    });
  });

  describe("hashPayload", () => {
    const base = (): ProposedTx => ({
      chainId: 31337,
      to: "0x000000000000000000000000000000000000dEaD",
      data: "0xdeadbeef",
      value: "0",
    });

    it("is deterministic for identical payloads", () => {
      expect(hashPayload(base())).toBe(hashPayload(base()));
      expect(hashPayload(base())).toMatch(/^0x[0-9a-f]{64}$/);
    });

    // The load-bearing property: a jsonb round-trip reorders keys, may re-case the address, and
    // drops an absent `gasLimit`. The hash is over structured fields, so none of that moves it —
    // `operator-cli` reading the payload back must reproduce the hash the notification showed.
    it("survives a jsonb-style round trip (key reorder, casing, absent gasLimit)", () => {
      const original = base();
      const target = hashPayload(original);

      // Same semantic payload, keys in a different order and the address lower-cased (as a lenient
      // JSON store might return it), gasLimit still absent.
      const roundTripped: ProposedTx = {
        value: "0",
        data: "0xdeadbeef",
        to: "0x000000000000000000000000000000000000dead",
        chainId: 31337,
      };
      expect(hashPayload(roundTripped)).toBe(target);
    });

    it("treats an absent gasLimit and an explicit '0' as identical (the sentinel)", () => {
      expect(hashPayload({ ...base(), gasLimit: "0" })).toBe(hashPayload(base()));
    });

    it("changes when any semantic field changes", () => {
      const h = hashPayload(base());
      expect(hashPayload({ ...base(), chainId: 1 })).not.toBe(h);
      expect(hashPayload({ ...base(), value: "1" })).not.toBe(h);
      expect(hashPayload({ ...base(), data: "0xcafebabe" })).not.toBe(h);
      expect(hashPayload({ ...base(), gasLimit: "500000" })).not.toBe(h);
      expect(hashPayload({ ...base(), to: "0x1111111111111111111111111111111111111111" })).not.toBe(
        h
      );
    });

    it("rejects a malformed address rather than hashing it (getAddress guards)", () => {
      expect(() => hashPayload({ ...base(), to: "0xnope" as Hex })).toThrow();
    });
  });
});
