import { type Address, type Hex, formatUnits } from "viem";

import { adapterAbi, lensAbi } from "@repo/abis";
import { type RiskSlot, settleUnfinished } from "@repo/risk";
import { BaseEngine, type BaseEngineConfig } from "../shared/engine";
import {
  LENS_ESTIMATE_CHUNK,
  MAX_LIQUIDATION_CANDIDATES,
  bufferAmount,
  bufferAmounts,
  selectPositions,
} from "./domain";
import {
  type FundedCandidate,
  type FundingParams,
  type LiquidationCandidate,
  type LiquidationFunding,
  createLiquidationFunding,
} from "./funding";
import { type SpokeReserves, discoverSpokeReserves, repayableTokens } from "./reserves";
import type { LiquidatablePosition, PonderResponse } from "./types";

/** Observability port — the engine reports through it; the service supplies metrics. */
export interface LiquidationMetrics {
  recordError(type: string): void;
  recordLiquidationSuccess(): void;
  recordLiquidationFailed(): void;
  recordSimulationFailed(): void;
  recordPollDuration(durationMs: number): void;
  recordPositionsChecked(count: number): void;
  recordPositionsLiquidatable(count: number): void;
  recordTokenBalance(symbol: string, address: Address, balance: bigint, decimals: number): void;
}

/**
 * Domain parameters the liquidation pipeline operates on — the env-derivable
 * subset shared by the engine config and the service's own config (no runtime
 * deps like clients or metrics). Services extend this so the fields are declared
 * once, here, next to the engine that consumes them.
 */
export interface LiquidationEngineParams {
  adapterAddress: Address;
  lensAddress: Address;
  wbtcAddress: Address;
  /** BTC redeem key; bytes32(0) means WBTC payout via VaultSwap. */
  btcRedeemKey: Hex;
  /** Direct BTC redemption vs WBTC payout via VaultSwap. */
  isDirectRedemption: boolean;
  /** VaultSwap (LLP) address, used for non-direct redemption. */
  llpAddress: Address;
  txReceiptTimeoutMs: number;
  /**
   * How repayment is funded.
   *
   * `inventory` (default) pays out of the signer's own inventory, which is why every candidate
   * declares a `spend` vector to the risk gate. `flash` routes through `LiquidationRouter`, which
   * borrows each debt token from a venue and repays itself out of the seized collateral — the
   * signer spends only gas, and needs no debt-token inventory at all.
   */
  funding?: FundingParams;
}

export interface LiquidationEngineConfig
  extends LiquidationEngineParams,
    BaseEngineConfig<LiquidationMetrics> {}

export class LiquidationEngine extends BaseEngine<LiquidationMetrics> {
  private adapterAddress: Address;
  private lensAddress: Address;
  /** The Spoke's reserves in id order. Undefined until `prepare()` reads them. */
  private reserveTopology?: SpokeReserves;
  private wbtcAddress: Address;
  private isDirectRedemption: boolean;
  private txReceiptTimeoutMs: number;
  /** How repayment is funded — the seam that decides the call, the risk declaration and the setup. */
  private funding: LiquidationFunding;
  /** Where the next truncated candidate window starts. See `selectPositions`. */
  private candidateOffset = 0;

  constructor(config: LiquidationEngineConfig) {
    super(config, { engine: "liquidation", intentAction: "liquidation" });
    this.adapterAddress = config.adapterAddress;
    this.lensAddress = config.lensAddress;
    this.wbtcAddress = config.wbtcAddress;
    this.isDirectRedemption = config.isDirectRedemption;
    this.txReceiptTimeoutMs = config.txReceiptTimeoutMs;
    // The config already carries every collaborator a strategy needs, so it is spread in rather
    // than re-listed field by field. Only these two cannot come from it: the debt-token list is
    // discovered later (during `prepare()`), and the token cache is shared with this engine so a
    // symbol is read once per process.
    this.funding = createLiquidationFunding({
      ...config,
      reserves: () => this.discoverReserves(),
      tokenMeta: this.tokenMetaCache,
    });
  }

  /**
   * Boot-time setup: discover the debt tokens, then let the funding mode prepare itself.
   *
   * One call so a service never has to know which setup its funding mode needs. Neither mode sends
   * a transaction from here — see `LiquidationFunding.prepare`.
   */
  async prepare(): Promise<void> {
    const topology = await this.discoverReserves();
    await this.assertLensWiring(topology);
    await this.funding.prepare();
  }

  /** The funding mode owns the allowances, so it owns taking them back. */
  protected async revokeApprovals(): Promise<void> {
    await this.funding.revokeApprovals();
  }

  /**
   * Check the configured Lens is the one that speaks this adapter's reserve index space.
   *
   * The one topology error nothing downstream can catch. Every other mismatch shows up as a length
   * that disagrees, but a Lens wired to a *different* Spoke with the same number of reserves
   * answers in its own index space, and the amounts line up perfectly against the wrong tokens.
   * Two reads at boot close it, and the Lens carries both as immutables.
   */
  private async assertLensWiring(topology: SpokeReserves): Promise<void> {
    const [adapter, spoke] = await Promise.all([
      this.publicClient.readContract({
        address: this.lensAddress,
        abi: lensAbi,
        functionName: "adapter",
      }),
      this.publicClient.readContract({
        address: this.lensAddress,
        abi: lensAbi,
        functionName: "spoke",
      }),
    ]);
    const eq = (a: Address, b: Address) => a.toLowerCase() === b.toLowerCase();
    if (!eq(adapter, this.adapterAddress)) {
      throw new Error(
        `Lens ${this.lensAddress} estimates for adapter ${adapter}, but ADAPTER_ADDRESS is ${this.adapterAddress} — its repay amounts would be indexed by another deployment's reserves`
      );
    }
    if (!eq(spoke, topology.spoke)) {
      throw new Error(
        `Lens ${this.lensAddress} reads Spoke ${spoke}, but the adapter's is ${topology.spoke} — its repay amounts would be indexed by another Spoke's reserves`
      );
    }
  }

  /**
   * Whether another liquidator took the vault we were going for. Used only to classify a reverted
   * liquidation, so that losing a race does not feed the breaker as a malfunction.
   *
   * Matched on the *vault*, not on the collateral reaching zero. The adapter seizes exactly one
   * vault — the head of the borrower's ordered list — so a competitor liquidating a borrower who
   * holds several leaves the rest of the collateral behind. Against a collateral-zero test that
   * reads as "still there to take", and every such race would be charged to the breaker; on a
   * multi-vault borrower that is the normal outcome of competition, not an edge case. Our target
   * leaving the borrower's list is the thing that actually happened, at any collateral level.
   *
   * Collateral zero is still accepted, and is not redundant: the borrower's list is emptied on a
   * full clear, and reading it as taken costs nothing when there is no vault left to seize.
   *
   * `getPosition` returns a value, so a genuine RPC failure throws and is caught as `false`
   * (treat the revert as a real failure). Failing toward "not a lost race" is deliberate: a blip
   * must never exempt a real failure from the breaker.
   *
   * @param borrower The account the reverted liquidation targeted.
   * @param vaultId The head vault that liquidation would have seized, from our own estimate.
   */
  private async wasPositionTaken(borrower: Address, vaultId: Hex): Promise<boolean> {
    try {
      const position = await this.publicClient.readContract({
        address: this.adapterAddress,
        abi: adapterAbi,
        functionName: "getPosition",
        args: [borrower],
      });
      if (position.totalCollateralBTC === 0n) return true;
      return !position.vaultIds.some((id) => id.toLowerCase() === vaultId.toLowerCase());
    } catch {
      return false;
    }
  }

  /**
   * Read the Spoke's reserves — every one, in id order — and keep the answer for this cycle.
   *
   * The only source for this. A repay amount is charged to the token of the reserve *id* it is
   * indexed by, so the mapping has to come from the chain: no configured list of addresses can
   * express it, and one that tried would decide which balance an outflow is charged against.
   *
   * Read afresh every cycle rather than cached, which is both simpler and more correct than
   * checking for staleness. `id → token` is immutable, but the two things layered on it are not:
   * a reserve can be appended, and `updateReserveConfig` can flip `borrowable` without the count
   * moving at all. Nothing short of re-reading sees the second, and a stale `false` there is
   * silent — the token is never approved or published, so every position owing it is blocked until
   * somebody restarts the bot. Against a cycle that already reads a balance per token and an
   * estimate per position, one read per reserve is not the expensive part.
   */
  async discoverReserves(): Promise<SpokeReserves> {
    this.reserveTopology = await discoverSpokeReserves({
      publicClient: this.publicClient,
      adapterAddress: this.adapterAddress,
      logger: this.logger,
      tokenSymbol: async (token) => (await this.tokenMeta(token)).symbol,
      previous: this.reserveTopology,
    });
    return this.reserveTopology;
  }

  /**
   * Run one iteration of the liquidation bot.
   * For each position: estimate via Lens, simulate, then execute.
   */
  protected async poll(slots: RiskSlot[]): Promise<void> {
    // Publish spendable balances to the gate before judging any candidate. The gate reserves each
    // action's declared spend against these, which is what stops this engine and the arbitrage
    // engine — same signer, same WBTC — from both committing the same balance. A read failure
    // propagates to the cycle's catch: unable to price our own inventory, we do not trade.
    await this.funding.refreshInventory();

    // Fetch liquidatable positions from Ponder (with the freshness stamp of its reads)
    const feed = await this.fetchLiquidatablePositions();

    // A failed read is not an empty market. Skip the cycle without writing the candidate gauge,
    // which would report a quiet market.
    if (feed.kind === "unavailable") {
      this.logger.warn(
        "Skipping cycle: the candidate list could not be read (not an empty market)"
      );
      return;
    }
    const { dataTimestampMs } = feed;
    // The feed is untrusted: drop unusable and repeated entries, and cap the rest, before any RPC.
    const offset = this.candidateOffset;
    const {
      positions: selected,
      malformed,
      duplicates,
      truncated,
    } = selectPositions(feed.positions, MAX_LIQUIDATION_CANDIDATES, offset);
    // Move past this window, so a long list is covered across cycles.
    const listed = selected.length + truncated;
    this.candidateOffset = truncated > 0 ? (offset + selected.length) % listed : 0;
    if (malformed + duplicates > 0) {
      this.metrics.recordError("positions_malformed");
      this.logger.warn(
        `Indexer candidate list had ${malformed} unusable and ${duplicates} repeated entries — dropped`
      );
    }
    if (truncated > 0) {
      this.metrics.recordError("positions_truncated");
      this.logger.warn(
        `Indexer returned ${listed} liquidatable positions — acting on ${selected.length} from offset ${offset % listed}; later cycles cover the rest`
      );
    }

    this.metrics.recordPositionsLiquidatable(selected.length + truncated);

    if (selected.length === 0) {
      this.logger.info("No liquidatable positions found");
      return;
    }

    this.logger.info(`Found ${selected.length} liquidatable position(s)`);

    // The Lens estimates the proxy, but the liquidation charges the borrower, and the indexer
    // supplies both. Keep a candidate only if the adapter maps its borrower to its proxy. A failed
    // read drops it too: the adapter reverts for a borrower it has no position for.
    const positionOf = (p: LiquidatablePosition) =>
      this.publicClient.readContract({
        address: this.adapterAddress,
        abi: adapterAbi,
        functionName: "getPosition",
        args: [p.borrower],
      });
    const positions: LiquidatablePosition[] = [];
    for (let i = 0; i < selected.length; i += LENS_ESTIMATE_CHUNK) {
      const chunk = selected.slice(i, i + LENS_ESTIMATE_CHUNK);
      const reads = await Promise.allSettled(chunk.map(positionOf));
      reads.forEach((read, j) => {
        const mapped =
          read.status === "fulfilled"
            ? (read.value as { proxyContract?: unknown } | undefined)?.proxyContract
            : undefined;
        if (
          typeof mapped === "string" &&
          mapped.toLowerCase() === chunk[j].proxyAddress.toLowerCase()
        ) {
          positions.push(chunk[j]);
        }
      });
    }
    const mismatched = selected.length - positions.length;
    if (mismatched > 0) {
      this.metrics.recordError("positions_mismatched");
      this.logger.warn(
        `${mismatched} candidate(s) name a borrower the adapter does not map to their proxy — dropped`
      );
    }
    if (positions.length === 0) {
      this.logger.info("No candidates passed the borrower check");
      return;
    }

    // Estimate liquidation inputs via Lens, `LENS_ESTIMATE_CHUNK` at a time.
    const estimate = (p: LiquidatablePosition) =>
      this.publicClient.readContract({
        address: this.lensAddress,
        abi: lensAbi,
        functionName: "estimateLiquidation",
        args: [p.proxyAddress, this.isDirectRedemption],
      });
    const estimateResults: PromiseSettledResult<Awaited<ReturnType<typeof estimate>>>[] = [];
    for (let i = 0; i < positions.length; i += LENS_ESTIMATE_CHUNK) {
      const chunk = positions.slice(i, i + LENS_ESTIMATE_CHUNK);
      estimateResults.push(...(await Promise.allSettled(chunk.map(estimate))));
    }

    // Build position + amounts pairs, filter failed estimates
    const candidates: LiquidationCandidate[] = [];

    for (let i = 0; i < estimateResults.length; i++) {
      const result = estimateResults[i];
      const pos = positions[i];

      if (result.status === "fulfilled") {
        const [debtReserveIds, debtToCoverAmounts, wbtcPayment, vaultId] = result.value;
        // Buffer every figure (default 1%) to cover interest accrual between the Lens read and
        // execution. `wbtcPayment` (fairness top-up +, in direct-redemption mode, the redemption
        // fee) is pulled from msg.sender by the adapter on top of the debt, and it is also the
        // `maxWbtcPayment` cap the call carries — so it is buffered on the same grounds as the debt
        // rather than left bare, and declared at the buffered figure to the risk gate, which
        // reserves it against the WBTC the arbitrage engine is spending from the same signer.
        // Already mode-correct: the Lens was asked with `isDirectRedemption`.
        candidates.push({
          position: pos,
          debtReserveIds,
          debtToCoverAmounts: bufferAmounts(debtToCoverAmounts),
          wbtcPayment: bufferAmount(wbtcPayment),
          vaultId,
        });
      } else {
        this.metrics.recordError("lens_estimate_error");
        const reason = result.reason;
        const errorMsg = reason instanceof Error ? reason.message : "Unknown error";
        this.logger.warn(`Lens estimate failed for ${pos.proxyAddress}: ${errorMsg}`);
      }
    }

    if (candidates.length === 0) {
      this.logger.info("No positions passed Lens estimation");
      return;
    }

    // Vet + price. Each mode decides viability its own way and hands back the call to send.
    const validCandidates = await this.funding.vet(candidates);

    if (validCandidates.length === 0) {
      this.logger.info("No positions passed simulation");
      return;
    }

    this.logger.info(`${validCandidates.length}/${positions.length} positions passed simulation`);
    await this.sendAll(validCandidates, dataTimestampMs, slots);
  }

  /**
   * Commit every vetted candidate, then await the receipts.
   *
   * `flash` candidates arrive carrying the plan their probe produced; `inventory` ones are priced from
   * the signer's own balances here. The difference is confined to `slot`/`call` below — everything
   * about nonce ownership, intent lifecycle and receipt settlement is shared.
   */
  private async sendAll(
    validCandidates: readonly FundedCandidate[],
    dataTimestampMs: number | undefined,
    slots: RiskSlot[]
  ): Promise<void> {
    try {
      // Send. Every tx routes through the shared nonce allocator (`withNonce`), the single nonce
      // owner across both engines. A send error is treated as AMBIGUOUS (the tx may have
      // propagated): the intent is kept LIVE (never terminal) and the cycle stops — the next
      // cycle's reconcile resolves it by nonce vs. chain.
      // Each sent tx is paired with its intent id (so the receipt phase records its outcome) and its
      // risk slot (so the receipt phase settles the exposure it reserved).
      const sent: Array<{
        hash: Hex;
        intentId?: string;
        slot: RiskSlot;
        position: LiquidatablePosition;
        /** The vault this tx meant to seize — what tells a lost race from a real revert. */
        vaultId: Hex;
      }> = [];
      sendLoop: for (let i = 0; i < validCandidates.length; i++) {
        const { position, call, risk, vaultId } = validCandidates[i];

        // Risk gate — per-candidate check just before submit. An allowed check reserves an
        // exposure slot that MUST be settled on every path below (see `RiskSlot`).
        //
        // What gets declared comes from the funding mode, the only thing that can know it: `inventory`
        // names the tokens the tx will pull from the signer and cannot price itself, `flash` prices
        // the action from its probe and moves none of the signer's tokens. The engine stays out of
        // that judgement and owns only the slot's lifecycle.
        const slot = this.risk.openSlot({
          kind: this.intentAction,
          subject: position.proxyAddress,
          dataTimestampMs,
          ...risk,
        });
        if (!slot.allowed) {
          this.metrics.recordError("risk_blocked");
          this.logger.warn(`Risk gate blocked ${position.proxyAddress}: ${slot.reason}`);
          continue;
        }
        slots.push(slot);

        // Commit the action through the mode seam. AUTO signs + broadcasts under the shared nonce
        // lock (claim → send → markPending → submitted, all inside `commit`); MANUAL proposes +
        // notifies.
        const out = await this.executor.commit(call, {
          target: call.address,
          action: this.intentAction,
          subject: position.proxyAddress,
        });

        switch (out.kind) {
          case "duplicate":
            // A live intent for this subject already exists — nothing broadcast; free the slot.
            slot.settle({ ok: false, abandoned: true });
            this.metrics.recordError("intent_in_flight");
            continue;

          case "proposed":
            // MANUAL — written down for an operator; nothing on chain, no receipt to await.
            slot.settle({ ok: false, abandoned: true });
            continue;

          case "aborted":
            this.metrics.recordError("tx_send_error");
            this.logger.error(`Failed to send liquidation for ${position.borrower}: ${out.error}`);
            // A failed broadcast may still land. Its fate is unknown, so the spend stays held under
            // its hash and the breaker does not count it. A pre-broadcast failure moved nothing.
            slot.settle(
              out.broadcastAttempted
                ? { ok: false, unresolved: true, txHash: out.txHash }
                : { ok: false, abandoned: true }
            );
            // The send left a possible nonce gap — stop the cycle; the next resync reclaims it.
            break sendLoop;

          case "broadcast":
            // The intent is already `submitted` (recorded inside `commit`).
            this.logger.info(`Sent liquidation for ${position.borrower}: ${out.hash}`);
            sent.push({ hash: out.hash, intentId: out.intentId, slot, position, vaultId });
            continue;

          default:
            out satisfies never; // exhaustiveness — a new `CommitResult` kind must be handled here
        }
      }

      if (sent.length === 0) {
        this.logger.info("No liquidation txs were sent");
        return;
      }

      // Batch-wait for all receipts
      this.logger.info(`Waiting for ${sent.length} liquidation receipt(s)...`);
      const receipts = await Promise.allSettled(
        sent.map(({ hash }) =>
          this.publicClient.waitForTransactionReceipt({ hash, timeout: this.txReceiptTimeoutMs })
        )
      );

      for (let i = 0; i < receipts.length; i++) {
        const result = receipts[i];
        const { hash, intentId, slot, position, vaultId } = sent[i];
        if (result.status === "fulfilled") {
          const receipt = result.value;
          if (receipt.status === "success") {
            // The hash and the height it mined at travel with the outcome: the gate holds this
            // outflow until a balance read at or past that height can report it, rather than
            // assuming the next read comes from a node that already has the block.
            slot.settle({ ok: true, txHash: hash, minedAtBlock: receipt.blockNumber });
            this.metrics.recordLiquidationSuccess();
            this.logger.info(`Liquidation confirmed in block ${receipt.blockNumber}: ${hash}`);
            if (intentId)
              await this.executor.recordOutcome(intentId, { kind: "confirmed", txHash: hash });
          } else {
            // A reverted liquidation is only *our* failure if the vault we were going for is still
            // there to take. If it is gone, another liquidator got there first — a lost race,
            // normal competition, which must not feed the breaker (settle `contended`).
            const lostRace = await this.wasPositionTaken(position.borrower, vaultId);
            if (lostRace) {
              slot.settle({ ok: false, contended: true });
              this.metrics.recordError("race_lost");
              this.logger.info(
                `Vault ${vaultId} of ${position.borrower} already seized by another bot — not a failure`
              );
            } else {
              slot.settle({ ok: false });
              this.metrics.recordLiquidationFailed();
              this.metrics.recordError("tx_reverted");
              this.logger.error(`Liquidation reverted: ${hash}`);
            }
            if (intentId)
              await this.executor.recordOutcome(intentId, {
                kind: "failed",
                txHash: hash,
                error: lostRace ? "lost race" : "reverted",
              });
          }
        } else {
          // The receipt never arrived (timeout) or could not be fetched. Either way the tx's fate
          // is UNKNOWN, not failed — it may still be in the mempool, and behind a nonce gap it
          // certainly is. `unresolved` keeps it off the breaker (these arrive in batches, so one
          // shared cause would otherwise land N failures at once and halt a healthy bot) while
          // still counting its declared spend, since the tx may yet land.
          // The intent stays 'submitted' — boot reconcile resolves it against the chain.
          // With the hash, so the gate can hold this outflow by the transaction that owes it and
          // release it only when the chain says what became of it — not on the next refresh, which
          // is a read this transaction may still be un-mined behind.
          slot.settle({ ok: false, unresolved: true, txHash: hash });
          this.metrics.recordError("receipt_fetch_error");
          this.logger.error(`Failed to get receipt for ${hash}: ${result.reason}`);
        }
      }
    } catch (error) {
      this.metrics.recordError("batch_error");
      this.logger.error("Error in bot run:", error);
    } finally {
      settleUnfinished(slots);
    }
  }

  /**
   * Fetch liquidatable positions from Ponder indexer, along with the chain-block timestamp its
   * live reads were evaluated at (the risk gate's freshness input; `undefined` if the indexer
   * doesn't report it).
   */
  /**
   * The candidate list, or `unavailable` when the read failed. An empty list means a quiet market.
   */
  private async fetchLiquidatablePositions(): Promise<
    | { kind: "ok"; positions: LiquidatablePosition[]; dataTimestampMs?: number }
    | { kind: "unavailable" }
  > {
    try {
      const data = await this.indexer.read<PonderResponse>("/liquidatable-positions");
      // The response crosses an unauthenticated wire and is cast to its type, never parsed — the
      // same reason the risk gate re-establishes the freshness stamp rather than trusting it. This
      // is the field the cycle is built on, so a body that does not carry it (a version-skewed
      // indexer, a proxy error page) fails here, named, instead of as a `TypeError` on `.length`
      // two frames later with nothing pointing at the indexer.
      if (!Array.isArray(data.liquidatable)) {
        throw new Error("Invalid Ponder response: liquidatable must be an array");
      }
      // Counts are reported, not acted on, so a missing one costs a gauge rather than the cycle —
      // but it must not reach `prom-client`, which throws on a value that is not a number.
      if (Number.isFinite(data.checked)) this.metrics.recordPositionsChecked(data.checked);
      // A short scan is not a quiet market. Surfaced rather than acted on: the positions we DID see
      // are still worth acting on, and refusing the cycle would turn a partial view into no view.
      // What must not happen is reading an incomplete list as "nothing to liquidate" in silence.
      if (Number.isFinite(data.unscanned) && data.unscanned) {
        this.metrics.recordError("positions_unscanned");
        this.logger.warn(
          `Indexer could not probe ${data.unscanned} position(s) this cycle — the candidate list is incomplete`
        );
      }
      return {
        kind: "ok",
        positions: data.liquidatable,
        dataTimestampMs: data.dataTimestampMs,
      };
    } catch (error) {
      this.metrics.recordError("ponder_fetch_error");
      this.logger.error("Failed to fetch liquidatable positions:", error);
      return { kind: "unavailable" };
    }
  }

  /**
   * Log and record liquidator's token balances (debt tokens + WBTC)
   */
  async logBalances(): Promise<void> {
    // Best-effort: a balance read failing on an RPC blip must not crash the poll loop. The cycle
    // has its own catch, but reaching it would abandon the whole cycle over a log line.
    try {
      this.logger.info("Token balances:");

      // Debt tokens — symbol/decimals are immutable, fetched once and cached.
      // Kick metadata + balanceOf in parallel so cold-start matches the original
      // 3-RPC concurrency; subsequent cycles only fire balanceOf (cache hit).
      for (const tokenAddress of this.reserveTopology
        ? repayableTokens(this.reserveTopology)
        : []) {
        const [{ symbol, decimals }, balance] = await Promise.all([
          this.tokenMeta(tokenAddress),
          this.readOwnBalance(tokenAddress),
        ]);

        this.metrics.recordTokenBalance(symbol, tokenAddress, balance, decimals);
        this.logger.info(`   ${symbol}: ${formatUnits(balance, decimals)}`);
      }

      // WBTC balance
      const [{ symbol: wbtcSymbol, decimals: wbtcDecimals }, wbtcBalance] = await Promise.all([
        this.tokenMeta(this.wbtcAddress),
        this.readOwnBalance(this.wbtcAddress),
      ]);

      this.metrics.recordTokenBalance(wbtcSymbol, this.wbtcAddress, wbtcBalance, wbtcDecimals);
      this.logger.info(`   ${wbtcSymbol}: ${formatUnits(wbtcBalance, wbtcDecimals)}`);
    } catch (error) {
      this.logger.error("Failed to fetch balances:", error);
    }
  }
}
