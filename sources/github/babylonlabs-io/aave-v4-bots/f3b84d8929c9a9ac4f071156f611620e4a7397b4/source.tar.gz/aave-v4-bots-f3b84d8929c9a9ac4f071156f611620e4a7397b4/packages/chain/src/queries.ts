import { safeExecutionEvents } from "@repo/abis";
import {
  type Address,
  type Hex,
  type PublicClient,
  TransactionNotFoundError,
  TransactionReceiptNotFoundError,
  keccak256,
} from "viem";

// Chain queries: plain functions over a viem `PublicClient`, offered to whoever needs them.
// `chain` sits near the bottom of the graph — its only sibling import is `@repo/abis` (a pure leaf:
// contract ABIs, no logic), so contract shapes stay single-sourced there rather than duplicated here;
// it declares no interface on any consumer's behalf.

/**
 * keccak256 of the deployed bytecode at `address`, or `undefined` when the account has no code.
 * Consumed by the risk gate's code-hash guard.
 *
 * One address per call, deliberately: the caller must be able to judge the addresses it *could*
 * read even when another is unreadable. Batching here (`Promise.all`) would let one bad RPC
 * response mask a real bytecode mismatch on a different address.
 *
 * Errors are **not** swallowed: to the gate, a failed probe (RPC blip) must be distinguishable
 * from "no code here", which it treats as compromise and halts on.
 */
export async function readCodeHash(
  publicClient: PublicClient,
  address: string
): Promise<string | undefined> {
  const code = await publicClient.getCode({ address: address as Address });
  // viem returns `undefined` for an EOA/empty account; some nodes return "0x".
  if (code === undefined || code === "0x") return undefined;
  return keccak256(code);
}

/**
 * Receipt status for `hash`, or `null` when the chain says there is no receipt yet — which is what
 * distinguishes "still in the mempool" from "mined". viem signals that by throwing
 * `TransactionReceiptNotFoundError`; that is not an error here, it is the answer.
 *
 * Every **other** error propagates. Collapsing an RPC outage into `null` would let a caller read
 * it as "not mined": `reconcilePending` would then see a nonce the chain has moved past, mark a
 * live intent `failed (dropped/replaced)`, and re-drive a transaction that may already be mined.
 * An unreachable node must fail the reconcile, not silently invent an answer for it.
 */
export async function getReceiptStatus(
  publicClient: PublicClient,
  hash: Hex
): Promise<"success" | "reverted" | null> {
  try {
    const receipt = await publicClient.getTransactionReceipt({ hash });
    return receipt.status === "success" ? "success" : "reverted";
  } catch (error) {
    if (error instanceof TransactionReceiptNotFoundError) return null; // not mined yet
    throw error; // transport / RPC failure — the caller must not treat this as "not mined"
  }
}

/**
 * Does the node know this tx at all — mempool **or** mined? Senders sign locally and record the
 * hash *before* broadcasting, so a recorded hash no longer proves the tx was accepted; this is
 * what separates "in flight" from "signed, but the node rejected the broadcast".
 *
 * Same discipline as `getReceiptStatus`: only a genuine `TransactionNotFoundError` is `false`.
 * Reporting an RPC failure as `false` would let `reconcilePending` conclude the broadcast was
 * rejected and re-drive a subject whose tx is in fact in flight.
 */
export async function isTxKnown(publicClient: PublicClient, hash: Hex): Promise<boolean> {
  try {
    await publicClient.getTransaction({ hash });
    return true;
  } catch (error) {
    if (error instanceof TransactionNotFoundError) return false;
    throw error; // transport / RPC failure — the caller must not treat this as "unknown tx"
  }
}

/** Transaction count for `address` at `latest` (mined) or `pending` (mined + mempool). */
export function getNonce(
  publicClient: PublicClient,
  address: Address,
  blockTag: "latest" | "pending"
): Promise<number> {
  return publicClient.getTransactionCount({ address, blockTag });
}

/**
 * How far below the recorded anchor the scan starts.
 *
 * The anchor is a height read from one endpoint at claim time, and two ordinary things put the
 * execution *below* it: a reorg can move the block it landed in, and behind a load-balanced RPC pool
 * the endpoint answering `getLogs` may sit behind the one that answered then. Starting exactly at
 * the anchor misses those, and a miss here is the dangerous direction — the caller reads "not
 * executed" for a SafeTx that did execute, releases the claim, and the same fund-moving action can
 * be signed a second time under a fresh nonce.
 *
 * The same reasoning, and the same figure, as the arbitrage router's execution scan.
 */
export const SAFE_SCAN_REORG_MARGIN_BLOCKS = 12n;

/**
 * Scan `safe`'s `Execution{Success,Failure}` events for one whose `txHash` equals `safeTxHash`,
 * returning the tx that emitted it (and whether the inner call succeeded) or `null` — i.e. "has the
 * SafeTx with this exact hash executed since it was reserved?".
 *
 * Precise by hash, so — unlike the Safe nonce, which ANY SafeTx advances — an unrelated execution on
 * a shared Safe never trips it. `operator-cli release` uses it to refuse releasing a claim whose
 * SafeTx already landed (that case is a `confirm`).
 *
 * `anchor` is the claim-time height the envelope recorded. It is treated as an approximate starting
 * point, not a floor: the scan begins `SAFE_SCAN_REORG_MARGIN_BLOCKS` below it, and an anchor above
 * the current head is clamped to the head — asking for an inverted range is provider-dependent, and
 * "no logs" from one would read as "never executed". `toBlock` stays `latest` rather than the head
 * just read, so an execution landing in between widens the answer instead of escaping it.
 */
export async function findSafeExecutionByHash(
  publicClient: PublicClient,
  safe: Address,
  safeTxHash: Hex,
  anchor: bigint
): Promise<{ txHash: Hex; success: boolean } | null> {
  const head = await publicClient.getBlockNumber();
  const bounded = anchor > head ? head : anchor;
  const fromBlock =
    bounded > SAFE_SCAN_REORG_MARGIN_BLOCKS ? bounded - SAFE_SCAN_REORG_MARGIN_BLOCKS : 0n;
  const logs = await publicClient.getLogs({
    address: safe,
    events: safeExecutionEvents,
    fromBlock,
    toBlock: "latest",
  });
  for (const log of logs) {
    const emitted = (log.args as { txHash?: Hex }).txHash;
    if (emitted && emitted.toLowerCase() === safeTxHash.toLowerCase() && log.transactionHash) {
      return { txHash: log.transactionHash, success: log.eventName === "ExecutionSuccess" };
    }
  }
  return null;
}
