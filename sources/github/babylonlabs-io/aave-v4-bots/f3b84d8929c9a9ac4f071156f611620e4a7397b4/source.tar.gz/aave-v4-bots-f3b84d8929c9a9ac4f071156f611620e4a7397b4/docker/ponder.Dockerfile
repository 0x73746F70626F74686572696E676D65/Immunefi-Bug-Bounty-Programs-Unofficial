# ============================================
# Ponder Indexer (unified) - Multi-stage Dockerfile
# ============================================
# One image for both services. The index mode (liquidation / arbitrage / both) is
# derived at runtime from which addresses the env provides; PONDER_PORT selects the
# port. See services/ponder/README.md.

# Stage 1: Build dependencies
FROM node:22-alpine AS builder

# Install pnpm
RUN corepack enable && corepack prepare pnpm@9.13.2 --activate

WORKDIR /app

# Copy workspace configuration
COPY pnpm-workspace.yaml package.json pnpm-lock.yaml tsconfig.json ./

# Copy package.json files for the ponder and its workspace deps
COPY packages/abis/package.json ./packages/abis/
COPY packages/logger/package.json ./packages/logger/
COPY packages/secrets/package.json ./packages/secrets/
COPY services/ponder/package.json ./services/ponder/

# Install runtime dependencies for ponder and every workspace package it
# imports. The trailing ellipsis is load-bearing: without it pnpm links the
# @repo/* packages but omits their external dependencies, so @repo/abis loses
# its viem and ponder's vite-node dies at boot resolving viem's `abitype`
# import ("Failed to load url abitype", devnet 2026-08-18). Same form as
# arbitrageur.Dockerfile/liquidator.Dockerfile, which never lost it.
RUN pnpm install --frozen-lockfile --prod --filter @services/ponder...

# Copy ponder source code + config and its workspace deps
COPY packages/abis/ ./packages/abis/
COPY packages/logger/ ./packages/logger/
COPY packages/secrets/ ./packages/secrets/
COPY services/ponder/ ./services/ponder/

# ============================================
# Stage 2: Production runtime
# ============================================
FROM node:22-alpine AS runner

# wget for the healthcheck. Remove the npm bundled in the base image: it is
# unused at runtime and ships known-vulnerable transitive deps (tar, etc.) that
# the image scanner flags. pnpm/corepack are intentionally NOT installed here —
# ponder is started directly (see CMD), so no package manager ships in the
# runtime image.
RUN apk add --no-cache wget=~1.25 && \
    rm -rf /usr/local/lib/node_modules/npm /usr/local/bin/npm /usr/local/bin/npx

# Create non-root user for security
RUN addgroup --system --gid 1001 nodejs && \
    adduser --system --uid 1001 ponder

WORKDIR /app

# Copy built application from builder
COPY --from=builder /app/pnpm-workspace.yaml ./
COPY --from=builder /app/tsconfig.json ./
COPY --from=builder /app/package.json ./
COPY --from=builder /app/pnpm-lock.yaml ./
COPY --from=builder /app/node_modules ./node_modules
COPY --from=builder /app/packages ./packages
COPY --from=builder /app/services/ponder ./services/ponder

# Set ownership
RUN chown -R ponder:nodejs /app

USER ponder

WORKDIR /app/services/ponder

# Expose Ponder API port (default; the actual port is set via PONDER_PORT)
EXPOSE 42069

# Mode-agnostic health check (the GraphQL root is served in every mode).
# docker-compose overrides this per instance with a mode-specific endpoint.
HEALTHCHECK --interval=10s --timeout=5s --start-period=30s --retries=3 \
    CMD wget --no-verbose --tries=1 --spider "http://localhost:${PONDER_PORT:-42069}/" || exit 1

# Default command: start production mode through start.sh (no pnpm at runtime). The script
# derives DATABASE_SCHEMA when it is unset, and exec keeps ponder as PID 1.
CMD ["/bin/sh", "start.sh"]
