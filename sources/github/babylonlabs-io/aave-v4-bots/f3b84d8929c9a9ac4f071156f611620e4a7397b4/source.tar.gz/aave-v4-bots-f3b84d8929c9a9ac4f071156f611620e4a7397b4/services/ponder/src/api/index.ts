import { db, publicClients } from "ponder:api";
import schema from "ponder:schema";
import { lensAbi, vaultSwapAbi } from "@repo/abis";
import { createLogger } from "@repo/logger";
import { Hono } from "hono";
import { client, graphql, replaceBigInts as replaceBigIntsBase } from "ponder";
import type { Address, Hex, PublicClient } from "viem";
import { previewInChunks } from "../previewVaults";
import {
  MULTICALL_BATCH_BYTES,
  type Probe,
  probeInChunks,
  resolveChunkSize,
  selectProbeCandidates,
  summarizeProbes,
} from "../probePositions";

const logger = createLogger();

function replaceBigInts<T>(value: T) {
  return replaceBigIntsBase(value, (x) => String(x));
}

// Multicall3 is canonically deployed at this address on most public chains, but
// not on bare Anvil instances or freshly-bootstrapped private chains. Probe once
// per process and cache the result; if it's missing, fall back to per-position
// readContract so the bot still works (just without the savings).
const MULTICALL3_ADDRESS = (process.env.MULTICALL3_ADDRESS ||
  "0xcA11bde05977b3631167028862bE2a173976CA11") as Address;

const { chunkSize: probeChunkSize, invalid: probeChunkSizeInvalid } = resolveChunkSize(
  process.env.POSITION_PROBE_CHUNK_SIZE
);
if (probeChunkSizeInvalid) {
  logger.warn(
    `POSITION_PROBE_CHUNK_SIZE=${process.env.POSITION_PROBE_CHUNK_SIZE} is not a positive integer; probing in batches of ${probeChunkSize}`
  );
}

let multicallSupported: boolean | undefined;

async function isMulticallSupported(publicClient: PublicClient): Promise<boolean> {
  if (multicallSupported !== undefined) return multicallSupported;
  try {
    const code = await publicClient.getCode({ address: MULTICALL3_ADDRESS });
    multicallSupported = !!code && code !== "0x";
    if (!multicallSupported) {
      logger.warn(
        `Multicall3 not deployed at ${MULTICALL3_ADDRESS}; falling back to per-position readContract. Set MULTICALL3_ADDRESS or deploy Multicall3 to recover the batched-RPC savings.`
      );
    }
    return multicallSupported;
  } catch (error) {
    logger.warn("Multicall3 probe failed; falling back to per-position readContract:", error);
    multicallSupported = false;
    return false;
  }
}

/**
 * The block this endpoint's **live** contract reads are pinned to, and its timestamp.
 *
 * Read the block *and* pin every subsequent `eth_call` to it, so `dataTimestampMs` describes the
 * exact state the caller is being handed. Timestamping one block and then reading at "latest"
 * would decouple the two: a load-balanced RPC URL can serve the reads from a lagging replica, and
 * a reorg can replace the head between the calls — either way the reported age would not be the
 * age of the data, which is precisely what the risk gate's freshness guard relies on.
 *
 * Clients pass the timestamp to the risk gate as `dataTimestampMs`: if the RPC behind this indexer
 * is lagging, `now - dataTimestampMs` exceeds the freshness threshold and the action is blocked.
 * Note it measures *RPC* staleness, not indexer **head** lag — that is a separate guard the
 * indexer-liveness work owns.
 *
 * A failed probe returns `undefined`, and the reads fall back to unpinned "latest". Be clear about
 * what that means downstream: the risk gate is **fail-closed** on freshness. A client with
 * `RISK_MAX_DATA_STALENESS_MS` set will block *every* action when the timestamp is missing — it
 * will not "skip the guard". That is the safe direction (never trade on data of unknown age), but
 * it means a sustained failure of this probe stops the bot trading while this endpoint still
 * returns 200 with candidates. Alert on the warning below, not just on HTTP status.
 */
interface BlockRef {
  /** Pin live reads here, so the data and the timestamp describe the same state. */
  blockNumber: bigint;
  dataTimestampMs: number;
}

async function readBlockRef(publicClient: PublicClient): Promise<BlockRef | undefined> {
  try {
    const block = await publicClient.getBlock();
    // `getBlock()` defaults to the latest *mined* block, so `number` is never null here.
    if (block.number === null) return undefined;
    return { blockNumber: block.number, dataTimestampMs: Number(block.timestamp) * 1000 };
  } catch (error) {
    // The severity is the point: a client with RISK_MAX_DATA_STALENESS_MS set fail-closes on the
    // missing field and stops submitting entirely, while this endpoint keeps returning 200 with
    // candidates. This line is the only signal of that, so it must not read as benign.
    logger.warn(
      "Could not read block timestamp; omitting dataTimestampMs — clients with " +
        "RISK_MAX_DATA_STALENESS_MS set will BLOCK every action until this recovers:",
      error
    );
    return undefined;
  }
}

const app = new Hono();

// GraphQL endpoint
app.use("/", graphql({ db, schema }));
app.use("/graphql", graphql({ db, schema }));

// SQL client endpoint
app.use("/sql/*", client({ db, schema }));

// ── liquidation endpoints ────────────────────────────────────────────────────

/**
 * GET /liquidatable-positions
 *
 * Returns all positions that are liquidatable by calling estimateLiquidation
 * on the AaveAdapterLiquidationPreview contract. The call reverts for healthy
 * positions and succeeds for liquidatable ones, returning the required inputs
 * and the vault that will be seized.
 */
app.get("/liquidatable-positions", async (c) => {
  const publicClient = Object.values(publicClients)[0] as PublicClient | undefined;

  if (!publicClient) {
    return c.json({ error: "No public client configured" }, 500);
  }

  const lensAddress = process.env.LENS_ADDRESS as Address;
  if (!lensAddress) {
    return c.json({ error: "LENS_ADDRESS not configured" }, 500);
  }

  // Query all positions and proxy mappings from database
  const [positions, proxyMappings] = await Promise.all([
    db.query.position.findMany(),
    db.query.proxyMapping.findMany(),
  ]);

  if (positions.length === 0) {
    return c.json({ liquidatable: [], total: 0, checked: 0 });
  }

  // Pin the live `estimateLiquidation` reads below to one block, and report its timestamp as the
  // risk-gate `dataTimestampMs`. `blockNumber: undefined` (failed probe) means unpinned "latest".
  const blockRef = await readBlockRef(publicClient);
  const dataTimestampMs = blockRef?.dataTimestampMs;

  // Probe only rows with a borrower. See `selectProbeCandidates`.
  const { candidates, unmapped } = selectProbeCandidates(positions, proxyMappings);

  // One line per cycle. A rising count on an adapter-only deployment means proxy mappings are
  // missing.
  if (unmapped > 0) {
    logger.warn(
      `${unmapped} position row(s) have no proxy mapping and were not probed — no borrower means no liquidation call can be built for them`
    );
  }

  // estimateLiquidation reverts for healthy positions and returns
  // [debtReserveIds, debtToCoverAmounts, wbtcPayment, vaultId,
  // amountCollateralToSeize] for liquidatable ones. The wbtcPayment is pulled
  // directly from msg.sender by the adapter at liquidation time, so the API
  // response doesn't need to expose it — the client just needs enough WBTC
  // approved + balance. We unify both paths to a
  // { status: "success" | "failure", value/error } shape so the loop below
  // doesn't care which one ran.
  type Estimate = readonly [readonly bigint[], readonly bigint[], bigint, `0x${string}`, bigint];

  // A batch that fails as a whole costs its own positions and nothing more, and `unscanned` says
  // how many that was — see `probeInChunks`.
  const onChunkFailure = (offset: number, size: number, error: unknown) =>
    logger.warn(
      `estimateLiquidation batch ${offset}-${offset + size} failed as a whole; ${size} position(s) unscanned this cycle:`,
      error instanceof Error ? error.message : error
    );

  const scanStartedAt = Date.now();
  const probes = (await isMulticallSupported(publicClient))
    ? // One aggregate over every position would be one `eth_call`: past the node's gas cap the
      // whole thing reverts, viem throws, and this endpoint 500s while real unhealthy positions
      // exist. `PROBES_PER_CALL` is what bounds a call; the chunk is how many of them run at once.
      await probeInChunks(
        candidates,
        async (chunk): Promise<Probe<Estimate>[]> => {
          const results = await publicClient.multicall({
            contracts: chunk.map(({ position }) => ({
              address: lensAddress,
              abi: lensAbi,
              functionName: "estimateLiquidation" as const,
              args: [position.proxyAddress as Address, false] as const,
            })),
            allowFailure: true,
            multicallAddress: MULTICALL3_ADDRESS,
            // Explicit, not viem's 1024-byte default. See `PROBES_PER_CALL`.
            batchSize: MULTICALL_BATCH_BYTES,
            blockNumber: blockRef?.blockNumber,
          });
          return results.map((r) =>
            r.status === "success"
              ? { status: "success", value: r.result }
              : { status: "failure", error: r.error }
          );
        },
        onChunkFailure,
        probeChunkSize
      )
    : // Fallback: per-position `readContract`, in the same batches. Firing all of them at once is a
      // different flavour of the same exhaustion — thousands of concurrent requests against one
      // endpoint — so the batching is not just a multicall concern. `allSettled` keeps a single
      // failed read from costing its batch, which is why this path rarely reports `unscanned`.
      await probeInChunks(
        candidates,
        async (chunk): Promise<Probe<Estimate>[]> => {
          const settled = await Promise.allSettled(
            chunk.map(({ position }) =>
              publicClient.readContract({
                address: lensAddress,
                abi: lensAbi,
                functionName: "estimateLiquidation",
                args: [position.proxyAddress as Address, false],
                blockNumber: blockRef?.blockNumber,
              })
            )
          );
          return settled.map((s) =>
            s.status === "fulfilled"
              ? { status: "success", value: s.value }
              : { status: "failure", error: s.reason }
          );
        },
        onChunkFailure,
        probeChunkSize
      );

  // Probe time only.
  const scanMs = Date.now() - scanStartedAt;

  // Each candidate counts once: a success or a healthy revert is checked, anything else is
  // unscanned. See `summarizeProbes`.
  const { succeeded, checked, unscanned, faults } = summarizeProbes(candidates, probes);
  const liquidatable = succeeded.map(({ candidate: { position, borrower }, value }) => {
    const [debtReserveIds, debtToCoverAmounts, , vaultId] = value;
    return {
      proxyAddress: position.proxyAddress,
      borrower,
      debtReserveIds: debtReserveIds.map((id) => id.toString()),
      debtToCoverAmounts: debtToCoverAmounts.map((amt) => amt.toString()),
      vaultId,
      suppliedShares: position.suppliedShares.toString(),
    };
  });

  // Scan time grows with the candidate count, and the bot reads this route under a fixed timeout.
  // This line shows how close the scan is to that limit.
  logger.info(
    `Probed ${candidates.length} candidate(s) in ${scanMs}ms: ${liquidatable.length} liquidatable, ${unscanned} unscanned, ${unmapped} unmapped`
  );

  if (faults.count > 0) {
    logger.warn(
      `estimateLiquidation failed for ${faults.count} position(s) for a reason other than the position being healthy; reporting them as unscanned: ${faults.summary()}`
    );
  }

  return c.json(
    replaceBigInts({
      liquidatable,
      total: liquidatable.length,
      // `checked` counts the positions this cycle actually has an answer for. `unscanned` is
      // everything else — a batch that failed as a whole, or a probe that reverted for a reason
      // that is not "healthy". Without it a partial scan is indistinguishable from a quiet market,
      // and "no candidates" is exactly the answer a liquidator must not infer from a failure.
      checked,
      unscanned,
      // Rows with no borrower. Unlike `unscanned`, a later cycle does not change them.
      unmapped,
      // Probe time. Read it against `checked`: the scan is linear in it.
      scanMs,
      dataTimestampMs,
    })
  );
});

/**
 * GET /positions
 *
 * Returns all tracked positions (for debugging)
 */
app.get("/positions", async (c) => {
  const positions = await db.query.position.findMany();

  return c.json(
    replaceBigInts({
      positions: positions.map((p) => ({
        proxyAddress: p.proxyAddress,
        suppliedShares: p.suppliedShares,
        createdAt: p.createdAt,
        updatedAt: p.updatedAt,
      })),
      total: positions.length,
    })
  );
});

// ── arbitrage endpoints ──────────────────────────────────────────────────────

/**
 * GET /escrowed-vaults
 *
 * Returns all escrowed vaults with live debt data from VaultSwap contract.
 * Reads previewEscrowedVaults in chunks, so the RPC work per call and in flight stays bounded.
 * This is the main endpoint the arbitrageur client will poll.
 */
app.get("/escrowed-vaults", async (c) => {
  const publicClient = Object.values(publicClients)[0] as PublicClient | undefined;

  if (!publicClient) {
    return c.json({ error: "No public client configured" }, 500);
  }

  const vaultSwapAddress = process.env.VAULT_SWAP_ADDRESS as Address;
  if (!vaultSwapAddress) {
    return c.json({ error: "VAULT_SWAP_ADDRESS not configured" }, 500);
  }

  // Query all escrowed vaults from database
  const vaults = await db.query.escrowedVault.findMany();

  if (vaults.length === 0) {
    return c.json({ vaults: [], total: 0, failedVaultsCount: 0 });
  }

  // Pin the live `previewEscrowedVaults` reads below to one block, and report its timestamp as the
  // risk-gate `dataTimestampMs`. `blockNumber: undefined` (failed probe) means unpinned "latest".
  const blockRef = await readBlockRef(publicClient);
  const dataTimestampMs = blockRef?.dataTimestampMs;

  // Build vault ID array and createdAt lookup
  const vaultIds = vaults.map((v) => v.vaultId);
  const createdAtMap = new Map(vaults.map((v) => [v.vaultId, v.createdAt]));
  const toApiVault = (info: {
    vaultId: `0x${string}`;
    amountVault: bigint;
    amountDebt: bigint;
    amountInterest: bigint;
    amountFee: bigint;
    amountWbtcEquivalent: bigint;
    amountWbtcToAcquire: bigint;
    amountProfitEst: bigint;
  }) => ({
    vaultId: info.vaultId,
    btcAmount: info.amountVault.toString(),
    currentDebt: info.amountWbtcToAcquire.toString(),
    isProfitable: info.amountProfitEst > 0n,
    createdAt: createdAtMap.get(info.vaultId)?.toString() ?? "0",
  });

  // A vault acquired after the index read reverts its chunk, which is then read one vault at a time.
  const { previews, gone, failures, batchError } = await previewInChunks(
    vaultIds,
    (ids: readonly Hex[]) =>
      publicClient.readContract({
        address: vaultSwapAddress,
        abi: vaultSwapAbi,
        functionName: "previewEscrowedVaults",
        args: [ids],
        blockNumber: blockRef?.blockNumber,
      })
  );

  // Gone vaults are the steady state while the escrow drains, so they are an info line. Only a
  // vault that failed for another reason makes the batch failure an error.
  for (const { vaultId, error } of failures) {
    logger.error(`Failed to fetch vault info for ${vaultId}:`, error);
  }
  if (failures.length > 0) {
    logger.error("Batch previewEscrowedVaults failed, fell back to per-vault fetch:", batchError);
  } else if (gone > 0) {
    logger.info(
      `Batch previewEscrowedVaults skipped: ${gone} vault(s) acquired since the last index update`
    );
  }

  // 500 only when something broke. An empty list because every vault was acquired is a complete
  // answer.
  const enrichedVaults = previews.map(toApiVault);
  return c.json(
    replaceBigInts({
      vaults: enrichedVaults,
      total: enrichedVaults.length,
      failedVaultsCount: failures.length,
      dataTimestampMs,
    }),
    enrichedVaults.length > 0 || failures.length === 0 ? 200 : 500
  );
});

/**
 * GET /escrowed-vaults-raw
 *
 * Returns all indexed escrowed vaults without live enrichment (for debugging)
 */
app.get("/escrowed-vaults-raw", async (c) => {
  const vaults = await db.query.escrowedVault.findMany();

  return c.json(
    replaceBigInts({
      vaults: vaults.map((v) => ({
        vaultId: v.vaultId,
        createdAt: v.createdAt,
      })),
      total: vaults.length,
    })
  );
});

export default app;
