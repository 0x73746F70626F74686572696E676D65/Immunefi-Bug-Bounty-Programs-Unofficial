# Trivy Test Repository

Test repository for validating Trivy container scanning workflows before rolling out changes to shared CI/CD pipelines.

## Purpose

This repository tests:
- **Local image scanning** - Trivy scans Docker images without pushing to a registry
- **Table output** - Vulnerability results visible in GitHub Actions logs
- **SARIF integration** - Results uploaded to GitHub Security tab (public repos)
- **Exit code behavior** - Non-blocking vs blocking modes
- **CVE suppression** - `.trivyignore` functionality

## Quick Start

```bash
# Build locally
docker build -t trivy-test:local .

# Run container
docker run -p 3000:3000 trivy-test:local

# Test endpoint
curl http://localhost:3000/health
```

## Workflow Jobs

| Job | Purpose |
|-----|---------|
| `hadolint` | Lint Dockerfile, upload SARIF |
| `build-and-scan` | Build image, run Trivy (non-blocking), upload SARIF |
| `test-blocking-mode` | Test exit-code=1 behavior (fails on CRITICAL) |

## Testing Scenarios

### 1. Table Output in Logs
Check the `build-and-scan` job logs for vulnerability table.

### 2. SARIF in Security Tab
For public repos, check **Security** → **Code scanning alerts** for Trivy and Hadolint results.

### 3. Exit Code Behavior
- `exit-code: 0` - Workflow passes regardless of findings
- `exit-code: 1` - Workflow fails if vulnerabilities match severity filter

### 4. CVE Suppression
Add a CVE ID to `.trivyignore` to verify it's excluded from results:
```
# .trivyignore
CVE-2023-XXXXX
```

## Key Findings

- **No registry push required** - Trivy scans local images directly
- **Faster feedback** - Vulnerabilities caught before push
- **SARIF condition** - Only uploads on public repos (`github.event.repository.visibility == 'public'`)

## Files

| File | Description |
|------|-------------|
| `src/index.ts` | Express HTTP server |
| `Dockerfile` | Multi-stage build (node:20-alpine) |
| `.trivyignore` | CVE suppression list |
| `.github/workflows/test-trivy.yml` | Test workflow |
