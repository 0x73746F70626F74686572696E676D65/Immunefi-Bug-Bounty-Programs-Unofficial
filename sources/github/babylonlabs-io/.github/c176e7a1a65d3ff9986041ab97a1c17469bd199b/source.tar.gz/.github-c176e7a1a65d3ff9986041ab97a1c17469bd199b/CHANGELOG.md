# CHANGELOG

## Unreleased
- ci: remove `reusable_ci_doctor`. Its blocking rules (`timeout-minutes` on every job, a `concurrency` block on push and pull_request workflows) are CI hygiene, not security. Its only other blocking rule, YAML parse errors, stays covered: `reusable_zizmor` fails on a workflow it cannot parse (`--strict-collection`). It also ran a young, single-maintainer npm package on every pull request. Its org ruleset (Evaluate mode) was removed first, and no repository calls the workflow directly. This repository keeps its timeout and concurrency conventions (AGENTS.md), now enforced by review.
- reusable_docker_pipeline, reusable_go_lint_test: declare the secrets they read under `on.workflow_call.secrets` (`DOCKERHUB_USERNAME`, `DOCKERHUB_TOKEN`, `TBV_DEPS_APP_PRIVATE_KEY` for the docker pipeline; `TBV_DEPS_APP_PRIVATE_KEY` for go lint/test), all `required: false`. Callers can now pass them by name instead of `secrets: inherit`, which the org-required `reusable_zizmor` check rejects (`secrets-inherit`). Not breaking: callers that still inherit keep working. Migration: replace `secrets: inherit` with a `secrets:` map naming only what the job uses, e.g. `DOCKERHUB_USERNAME: ${{ secrets.DOCKERHUB_USERNAME }}`. Callers of `reusable_changelog_reminder`, `reusable_sync_branch` and `reusable_authenticate_commits` drop `secrets: inherit` without replacement: those read only `GITHUB_TOKEN` (or nothing), which a called workflow always receives.
- ci: `reusable_check_pinned_actions` and `reusable_authenticate_commits` run on `merge_group`. Both are org-required checks, but they ran only on `pull_request`, so they never reported on a merge-group commit: the queue waited until its timeout and removed the PR (seen on babylonlabs-io/btc-vault#2854). `reusable_check_pinned_actions` checks the merge-group tree. `reusable_authenticate_commits` passes without verifying in the queue: a PR enters the queue only after the check passed on its head, and the queue's commits are made by GitHub and are not signed with an allowed key.
- **Rollout required:** After merge, update the workflow SHAs in the organization rulesets `enforce-committers-whitelist` (12402330) and `enforce-pinned-actions-hashes` (14416028) to the new `babylonlabs-io/.github` main commit containing this fix. Merging alone does not activate this fix. Re-enqueue `btc-vault#2854` and verify that `validate` and `check-pinned-actions` both report success on the new merge-group commit.
- reusable_backport: **security** — the merged-only guard never applied. The job's `if:` mixed `${{ inputs.run-backport }}` with bare text, which made the whole condition a non-empty string, always true: the job ran on every event the caller subscribes to, merged or not, and `run-backport: false` did not switch it off. It is now one expression, so the job runs only when `run-backport` is true and the PR is merged (closed, or labelled `backport…`). Found by zizmor (`unsound-condition`).
- reusable_go_lint_test: the Docker Hub login before integration tests is removed. It never ran: its `if:` compared the boolean `integration-tests-docker-auth` with the string `'true'`, which is never equal. Turning it on would have put the inherited `DOCKERHUB_USERNAME`/`DOCKERHUB_TOKEN` (the pair `reusable_docker_pipeline` pushes with) on disk while the caller's install and test commands run, and failed on fork and Dependabot PRs, where those secrets are withheld. `integration-tests-docker-auth` stays as an input with no effect, so callers that set it keep working. If integration tests need authenticated pulls, add them back with a pull-only token passed as a named secret.
- ci: every job in this repository's workflows sets `timeout-minutes`, and the two `pull_request`-triggered checks (`reusable_authenticate_commits`, `reusable_check_pinned_actions`) declare a concurrency group with a per-workflow literal, so a called copy never shares its caller's group. `reusable_go_lint_test` and `reusable_go_releaser` take a `timeout_minutes` input (default 60, like `reusable_docker_pipeline`); in the Go callers' recent successful runs (24 caller workflows) the slowest go lint/test job took 13 minutes and goreleaser about 7. The 60-minute default also caps go_lint_test's integration (e2e) job: callers whose end-to-end suites run longer must pass `timeout_minutes` when they bump. `reusable_backport` takes a `timeout_minutes` input too (default 10), since a backport to many branches can run longer; the other small checks use fixed timeouts (5–15 minutes). Prerequisite for the `reusable_ci_doctor` gate (#94), which fails on missing timeouts and concurrency.
- reusable_docker_pipeline: **breaking** — per-platform images are published as `<tag>-r<run id>.<run attempt>-linux-<arch>` instead of `<tag>-linux-<arch>` (baby-auditor-infra-findings#120). The platform tags shared a namespace with the advertised tags, so one publication's staging image could take another's release name. The prefix is derived in `prepare-metadata` and passed on as the `platform-tag-prefix` output; the push and merge jobs never build a platform reference from the final tag. Migration: pull the multi-platform tag, not a `-linux-amd64` / `-linux-arm64` name; `imageTag` must now also leave room for the run-scoped suffix within the 128-character registry limit (about 100 characters).
- reusable_docker_pipeline: **breaking** — `repoName` must be a single lowercase registry repository name, `^[a-z0-9]+([._-][a-z0-9]+)*$`, 2-128 characters (no `/`, `:`, `@`, uppercase, or doubled/leading/trailing separators); the fallback repository name is validated the same way. This is the intersection of the Docker Hub and ECR naming rules, so an invalid name now fails in `prepare-metadata` instead of after credentials are bound. All 13 `repoName` values passed by the 41 calling repositories already match.
- reusable_docker_pipeline: **security** — the merge jobs build the multi-platform manifest from the digests each platform leg recorded after its own push, never from the staging tag names (baby-auditor-infra-findings#47), so a cancelled or foreign build cannot substitute bytes under a tag. Each leg reads its digest back with `docker image inspect` and uploads it as `digests-<registry>--<buildArtifactPrefix>--<image>--<platform>`; the merge downloads that exact prefix+image pattern. The prefix is part of the name because one caller run may publish the same image several times (btc-vault `default`/`test-utils`, vaults-load-test-framework matrices), and `prepare-metadata` now rejects a `buildArtifactPrefix` that is not tag-safe or contains the `--` delimiter. The Docker Hub merge refuses an existing tag (only a 404 allows publication; ECR relies on tag immutability), publishes one image:tag at a time within the repository (job `concurrency`, never cancelled), and after `imagetools create` reads the tag back and fails unless it resolves to exactly the recorded digests — a concurrent publisher that won the race fails the job instead of being reported as a release. `tests/test_docker_pipeline_tag_context.py` covers the digest sourcing, the artifact naming across matrix legs, the prefix validation and the read-back mismatches.
- ci: add `reusable_zizmor` workflow: runs zizmor 1.30.1 (upstream image pinned by digest, no third-party action) over the calling repository's workflows, composite actions and Dependabot config and fails on findings at or above medium severity and medium confidence. It also audits files `.gitignore` lists (`--collect=all`; GitHub runs them regardless) and fails on inputs it cannot parse (`--strict-collection`). Intended as an org-wide required workflow (ruleset "Require workflows to pass", like `reusable_check_pinned_actions`). No workflow changes are needed in the calling repositories, but each must clear its existing findings first: start the ruleset in Evaluate mode (this repository's own findings are fixed in a preceding PR). Repositories with nothing to audit pass. Accepted findings are ignored per repository in `.github/zizmor.yml` (or the other names zizmor reads: `.github/zizmor.yaml`, `zizmor.yml`, `zizmor.yaml`). A PR that changes only that config is audited with it, which is how a waiver is added or repaired, also for a finding already on main; any other PR is audited with its base commit's config, and also with its own when it edits the config, so it can neither waive its own findings nor drop or break a waiver. A PR that adds inline `zizmor: ignore` comments fails (the diff is scanned byte-wise, so NUL bytes, invalid UTF-8 or a file moved into place cannot hide one). The check runs again when a PR moves to another base branch (`edited`), runs in merge queues (`merge_group`), and fails on events other than pull_request, merge_group, push, workflow_dispatch and schedule.
- ci: add `reusable_ci_doctor` workflow: runs ci-doctor 0.5.1 (npm tarball and its `yaml` dependency pinned by version and SHA-256, unpacked without install scripts) over the calling repository's `.github/workflows`. Blocks on jobs without `timeout-minutes`, push/pull_request workflows without a `concurrency` block, and YAML parse errors; the other cost and hygiene rules only annotate, and the advisory run never fails the check. `docker-no-pin` is one of the annotating rules, since nothing else checks image pinning (`reusable_check_pinned_actions` reads only `uses:` refs, and zizmor at the regular persona does not flag tag-pinned images). `pinned-action-sha` and `missing-permissions` (enforced by `reusable_check_pinned_actions` and zizmor) and `deprecated-action` (stale version table) are disabled. A self-test runs the gate rules over a fixed fixture first and fails the check unless each rule fires exactly once and a YAML parse error is still reported, so an unknown or renamed rule ID (for example after a version bump) cannot pass as a clean run. Runs on `edited` and `merge_group` as well. Intended as an org-wide required workflow; as with zizmor, each repository must clear its existing findings first (start in Evaluate mode).

## 0.22.0
- release: v0.22.0 ships the image-identity and credential-isolation work below (baby-auditor-infra-findings #55, #61, #65, #119, #121 closed; **#14 partially addressed and still open** — #86 makes publication fail closed on an existing ECR tag, but caller-selected repositories and the shared role's account-wide ECR write remain, so cross-service tag squatting is unresolved). Verified before tagging with a `publish: false` run of the `devops-test` caller pinned to `d34926c` (https://github.com/babylonlabs-io/devops-test/actions/runs/35542512042): `prepare-metadata` validation, the job-scoped Docker config, the context/Dockerfile confinement step and the always-on credential cleanup all ran. The `merge_ecr` / `merge_dockerhub` jobs were not exercised, since that run does not publish.
- reusable_docker_pipeline: **breaking** — the image tag is validated in `prepare-metadata` and used exactly as given; it is no longer rewritten (baby-auditor-infra-findings#121). The previous sanitizer (`/` and other characters → `-`, leading `.`/`-` stripped) mapped different names to one registry tag (`.release-a` and `release-a`, `feat/a-b` and `feat-a/b`), so one publication could take over another's tag. `imageTag`, or the git tag name on tag events when `imageTag` is empty, must match `^[A-Za-z0-9_][A-Za-z0-9_.-]{0,115}$` (116 = the 128-character registry limit minus the `-linux-amd64` / `-linux-arm64` platform suffix) and must not end in one of those two suffixes. Branch names were never part of the tag (non-tag builds publish the commit SHA) and still are not. The merge jobs publish the validated tag (`type=raw`) instead of re-reading `inputs.imageTag` through `docker/metadata-action`, and refuse to publish if the final tag differs from it.
- Migration: git tags containing `/` (e.g. `covenant-signer/v0.3.0`, `circuits/v1.3`) now fail in `prepare-metadata` instead of being published as `covenant-signer-v0.3.0`. No current caller is affected: every caller filters tags with `*` or `v*`, which do not match `/`. To publish from such a tag, pass an explicit canonical `imageTag`.
- reusable_docker_pipeline: **breaking** — `dockerContext` and `dockerfile` must be relative paths inside the checked-out repository (`[A-Za-z0-9_./-]`, no `..`, no leading `-` or `/`, no `github.com/...`); URLs, git refs and other remote contexts are rejected (baby-auditor-infra-findings#119). A remote context was fetched separately by the amd64 and arm64 jobs, so one tag could combine two revisions that are not the reviewed commit. Both values are validated in `prepare-metadata`, passed on as normalized `./path` outputs, and `docker_build` checks them after the checkout: a context or Dockerfile that is a symlink, or is reached through a symlinked directory, is refused (also when the target is inside the repository), and the resolved directories must be inside the workspace. No current caller passes a remote context; an explicitly empty `dockerContext: ''` (previously the action's git context) is rejected too.
- ci: `tests/test_docker_pipeline_tag_context.py` runs the real tag and path validation shell blocks (the #121 collision pairs, remote and escaping contexts, every value callers pass today) in the existing PR regression workflow.
- reusable_docker_pipeline: **breaking** — `runs_on_amd64` / `runs_on_arm64` are checked against an approved list of GitHub-hosted labels before any job that holds credentials starts (baby-auditor-infra-findings#55, #65). Approved: `ubuntu-24.04`, `ubuntu-24.04-8core` (amd64) and `ubuntu-24.04-arm64` (arm64). Self-hosted pools (`arc-runner-set`, `arc-runner-set-dind`, `gpu`, `localnet`), JSON-array labels and any other value now fail the `prepare-metadata` job. Both inputs are checked even when `disable_arm64` is true. Every current caller passes an approved label or the default. Migration: to use another runner, add the label to the approved list in `prepare-metadata` through a DevOps-reviewed PR.
- reusable_docker_pipeline: the build matrix is encoded with `jq --arg` instead of string concatenation, and `PLATFORM_PAIR` is derived from fixed strings in a step output instead of writing `matrix.platform` to `$GITHUB_ENV` (#65). `repoName` values containing control characters are rejected. Matrix job names are unchanged.
- reusable_docker_pipeline: `prepare-metadata` always runs on `ubuntu-24.04` with `permissions: {}`; `dockerfile_lint`, `merge_dockerhub` and `merge_ecr` take their runner from its validated output, so `dockerfile_lint` now waits for `prepare-metadata`.
- reusable_docker_pipeline: every job that logs in to a registry uses a per-job `DOCKER_CONFIG` (and `BUILDX_CONFIG`) under `runner.temp`, and an `if: always()` final step logs out of ECR and Docker Hub and deletes the directory (baby-auditor-infra-findings#61).
- ci: `tests/test_docker_pipeline_runner_inputs.py` runs the real validation, matrix and cleanup shell blocks (including the #65 payload) in the existing PR regression workflow.
- reusable_go_lint_test: `go-private-repos-authentication` now mints a per-job GitHub App installation token (`tbv-protocol-deps-ro`, Contents: read, scoped by the new `private_repos` input, revoked when the job ends) instead of reading the org `GO_PRIVATE_TOKEN` PAT; the git URL rewrite is limited to `https://github.com/babylonlabs-io/` and uses the `x-access-token` form. Same caller requirements as the docker pipeline (org variable `TBV_DEPS_APP_ID` + secret `TBV_DEPS_APP_PRIVATE_KEY` visible to the caller, `secrets: inherit`). No caller currently enables the input.
- ci: run ECR publication regression scenarios on PRs changing the Docker workflow or its tests, using a read-only hosted job with mocked AWS/Docker commands.
- reusable_docker_pipeline: fail ECR publication when a platform or release tag already exists instead of silently accepting unverified registry content (baby-auditor-infra-findings#14). Lookup/API errors also fail; only an explicit `ImageNotFound` permits a push.
- Migration: rerunning publication with an existing immutable tag now fails, including identical rebuilds and partially completed earlier runs. Use a fresh `imageTag`; do not delete or make existing tags mutable to retry. This replaces the unverified ECR rerun skipping introduced in 0.20.1.
- Scope: this is a partial mitigation for #14. Caller-selected repository names and the existing shared ECR role remain supported, so an authorized caller can still reserve another service's unused tag. Builds now surface those collisions instead of reporting a successful publication; this does not establish deployment provenance.

## 0.21.0
- reusable_docker_pipeline: **breaking** — private build-time dependencies are fetched with a per-job GitHub App installation token (`tbv-protocol-deps-ro`, Contents: read, revoked when the job ends) instead of the org `PRIVATE_REPO_TOKEN` / `GO_PRIVATE_TOKEN` PATs; there is no PAT fallback. Callers that enable `private-repos-authentication` or `go-private-repos-authentication` must be able to read the org variable `TBV_DEPS_APP_ID` and secret `TBV_DEPS_APP_PRIVATE_KEY` (`secrets: inherit`) and should pass the new `private_repos` input (comma-separated repositories the token may read; empty = every repository the App is installed on). The BuildKit secret ids (`PRIVATE_REPO_TOKEN`, `GO_PRIVATE_TOKEN`) are unchanged, so Dockerfiles need no change.
- release: v0.21.0 is the first tag after v0.19.1 and also ships the 0.19.2, 0.20.0 and 0.20.1 entries below.

## 0.20.1
- reusable_docker_pipeline: resolve `IMAGE_TAG` to the ref name on tag events so a tag push no longer collides with the `<sha>`-named intermediate tags left by an earlier branch build of the same commit
- reusable_docker_pipeline: skip ECR pushes when the target tag already exists, making re-runs idempotent against ECR tag immutability

## 0.20.0
- security: **breaking** — remove `reusable_node_lint_test.yml` (BPT-056; instance of BPT-049). The workflow ran unpinned `npm install` and `npx semantic-release` in a job with `id-token: write`, `contents: write`, and `pull-requests: write`. It is no longer consumed: all former callers are archived or migrated to `babylon-toolkit`'s own release pipeline, and the last non-archived caller (`btc-staking-ts`) is scheduled for archival. Migration: repos still pinning historical tags for Node CI should move to the `babylon-toolkit` pipeline; the removed workflow remains reachable via tags ≤ v0.19.x and must not be adopted by new repos.

## 0.19.2
- ci: `reusable_check_pinned_actions` accepts `# unversioned` sentinel comment to allow SHA-only pinning for actions whose maintainers don't publish release tags (e.g. `dtolnay/rust-toolchain`). The SHA must still be a 40-char hex string; remote tag resolution is skipped.

## 0.19.0
- security: pin all GitHub Actions to full commit SHAs across all reusable workflows
- ci: add `reusable_check_pinned_actions` workflow — verifies all `uses:` entries are pinned to commit SHAs and match the remote tag via the GitHub API; supports a skip list for orgs with IP allowlists (e.g. `aquasecurity`)
- ci: upgrade `actions/checkout` from v4 to v6.0.2 across all workflows to resolve Node.js 20 deprecation warning

## 0.18.2
- security: add explicit `permissions: {}` top-level blocks and least-privilege job-level permissions to `reusable_changelog_reminder`, `reusable_go_lint_test`, `reusable_github_release`, and `reusable_sync_branch`

## 0.18.1
- reusable_docker_pipeline: bump trivy-action to v0.35.0
- reusable_docker_pipeline: fix `buildArtifactPrefix` not applied to intermediate registry tags

## 0.18.0
- reusable_docker_pipeline: push the scanned image to registry instead of rebuilding a new one
- reusable_docker_pipeline: use image tag instead of digest when pushing images
- reusable_docker_pipeline: remove ECR repository auto-creation

## 0.17.1
- Bump trivy-action version

## 0.17.0
- Allow disabling arm64 Docker build

## 0.16.1
- Re-add dockerfile_lint as a dependency of docker_build to block image publishing on lint failures

## 0.16.0
- Restructure reusable Docker pipeline to scan images with Trivy (filesystem and image scans) before pushing to registries, with results published to GitHub Security tab via SARIF upload

## 0.15.0
- Promote all changes from the 0.14.0–0.14.7 series to the 0.15.0 stable release (no additional code changes).

## 0.14.7
- Add permissions for NPM semantic release workflow to work with OIDC.

## 0.14.6
- Enable security-events permission to upload scan report

## 0.14.5
- Remove classic AWS token from docker workflow and add id-token perms to use OIDC

## 0.14.4
- Remove classic NPM token from node workflow and add id-token perms to use OIDC

## 0.14.3
- Enable creating ECR repo if it does not exist

## 0.14.2
- Enable private repos access through token env variable on docker pipeline

## 0.14.1
- Add inputs to reusable Docker pipeline to change the runner and timeout

## 0.14.0
- Add flags to reusable Docker pipeline for skipping ECR or Dockerhub pushes

## 0.13.5

- Add support for downloading/caching test file for unit tests
- Add codeowners
- Remove dockerfile_lint dependency from docker_build

## 0.13.4

- reusable_docker_pipeline: Publish only the tag with highest priority

## 0.13.2

- reusable_docker_pipeline: Disable latest tag

## 0.13.1

- Support semantic release in the node reusable pipeline

## 0.13.0

- Add reusable_github_release workflow

## 0.12.1

- reusable_docker_pipeline: Add buildArtifactPrefix to prevent uploading to the same artifact
- reusable_docker_pipeline: Ignore other tag patterns when inputs.imageTag is available

## 0.12.0

- reusable_docker_pipeline: Support custom image tag
- reusable_docker_pipeline: Support build-args

## 0.11.2

- reusable_docker_pipeline: Fix bug where a repo has both docker build workflow runs at the same time

## 0.11.1

- Bugfix: reusable_node_lint_test: Use changesets action to create pull request for release
- Bugfix: reusable_node_lint_test: Fix bug where both publish and run-changesets cannot be true

## 0.11.0

- reusable_node_lint_test: Support changesets release action

## 0.10.2

- Add inputs to allow Trivy failing: trivy_failable
- Add inputs to allow Hadolint failing: hadolint_failable

## 0.10.1

- Enable .trivyignore usage

## 0.10.0

- reusable_docker_pipeline: Add Trivy and Hadolint scanning

## 0.9.0

- reusable_node_lint_test: Support publishing a package

## 0.8.0

- reusable_docker_pipeline: Set default values for AWS_ECR_REGISTRY_ID and DOCKERHUB_REGISTRY_ID
- add backport release pipeline

## 0.7.0

- reusable_changelog_reminder: Add changelog reminder to remind PR submitters to update changelog
- reusable_go_releaser: Add go releaser to create a release upon a tagged version

## 0.6.0

- reusable_go_lint_test: Add Gosec job to inspects source code for security problems

## 0.5.0

- reusable_docker_pipeline: Add `platforms` input to support Multi-platform image
- reusable_docker_pipeline: Refactor docker_build job

## 0.4.0

- reusable_go_lint_test: Add go-private-repos input, allowing access to private repositories

## 0.3.2

- reusable_go_lint_test: Allow build job to be optional

## 0.3.1

- reusable_go_lint_test: Install dependencies on all steps
- reusable_go_lint_test: Templatize auth and make it optional

## 0.3.0

- Add reusable_node_lint_test workflow

## 0.2.0

- Add reusable_sync_branch workflow

## 0.1.0

- Add reusable_go_lint_test workflow
- Add resuable_docker_pipeline workflow
