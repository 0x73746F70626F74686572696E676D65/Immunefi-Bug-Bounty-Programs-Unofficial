defmodule BlockScoutWeb.AddressCoinBalanceController do
  @moduledoc """
  Manages the displaying of information about the coin balance history of an address
  """

  use BlockScoutWeb, :controller

  import BlockScoutWeb.Account.AuthController, only: [current_user: 1]
  import BlockScoutWeb.Chain, only: [paging_options: 1, next_page_params: 3, split_list_by_page: 1]
  import BlockScoutWeb.Models.GetAddressTags, only: [get_address_tags: 2]

  alias BlockScoutWeb.{AccessHelper, AddressCoinBalanceView, Controller}
  alias Explorer.{Chain, Market}
  alias Explorer.Chain.{Address, Address.CoinBalance, Wei}
  alias Indexer.Fetcher.OnDemand.CoinBalance, as: CoinBalanceOnDemand
  alias Phoenix.View

  def index(conn, %{"address_id" => address_hash_string, "type" => "JSON"} = params) do
    with {:ok, address_hash} <- Chain.string_to_address_hash(address_hash_string),
         {:ok, address} <- Chain.hash_to_address(address_hash, []),
         {:ok, false} <- AccessHelper.restricted_access?(address_hash_string, params) do
      full_options = paging_options(params)

      coin_balances_plus_one = CoinBalance.address_to_coin_balances(address, full_options)

      {coin_balances, next_page} = split_list_by_page(coin_balances_plus_one)

      next_page_url =
        case next_page_params(next_page, coin_balances, params) do
          nil ->
            nil

          next_page_params ->
            address_coin_balance_path(
              conn,
              :index,
              address_hash,
              Map.delete(next_page_params, "type")
            )
        end

      coin_balances_json =
        Enum.map(coin_balances, fn coin_balance ->
          View.render_to_string(
            AddressCoinBalanceView,
            "_coin_balances.html",
            conn: conn,
            coin_balance: coin_balance
          )
        end)

      json(conn, %{items: coin_balances_json, next_page_path: next_page_url})
    else
      {:restricted_access, _} ->
        not_found(conn)

      {:error, :not_found} ->
        case Chain.Hash.Address.validate(address_hash_string) do
          {:ok, _} ->
            json(conn, %{items: [], next_page_path: ""})

          _ ->
            not_found(conn)
        end

      :error ->
        unprocessable_entity(conn)
    end
  end

  def index(conn, %{"address_id" => address_hash_string} = params) do
    ip = AccessHelper.conn_to_ip_string(conn)

    with {:ok, address_hash} <- Chain.string_to_address_hash(address_hash_string),
         {:ok, address} <- Chain.hash_to_address(address_hash),
         {:ok, false} <- AccessHelper.restricted_access?(address_hash_string, params) do
      render(conn, "index.html",
        address: address,
        coin_balance_status: CoinBalanceOnDemand.trigger_fetch(ip, address),
        exchange_rate: Market.get_coin_exchange_rate(),
        current_path: Controller.current_full_path(conn),
        counters_path: address_path(conn, :address_counters, %{"id" => Address.checksum(address_hash)}),
        tags: get_address_tags(address_hash, current_user(conn))
      )
    else
      {:restricted_access, _} ->
        not_found(conn)

      {:error, :not_found} ->
        {:ok, address_hash} = Chain.string_to_address_hash(address_hash_string)

        address = %Chain.Address{
          hash: address_hash,
          smart_contract: nil,
          token: nil,
          fetched_coin_balance: %Wei{value: Decimal.new(0)}
        }

        case Chain.Hash.Address.validate(address_hash_string) do
          {:ok, _} ->
            render(
              conn,
              "index.html",
              address: address,
              coin_balance_status: CoinBalanceOnDemand.trigger_fetch(ip, address),
              exchange_rate: Market.get_coin_exchange_rate(),
              counters_path: address_path(conn, :address_counters, %{"id" => Address.checksum(address_hash)}),
              current_path: Controller.current_full_path(conn),
              tags: get_address_tags(address_hash, current_user(conn))
            )

          _ ->
            not_found(conn)
        end

      :error ->
        unprocessable_entity(conn)
    end
  end
end
