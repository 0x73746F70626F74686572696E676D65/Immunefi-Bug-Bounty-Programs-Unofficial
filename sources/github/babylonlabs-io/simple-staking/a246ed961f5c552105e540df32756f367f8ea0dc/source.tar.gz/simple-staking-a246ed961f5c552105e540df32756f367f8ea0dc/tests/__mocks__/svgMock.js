module.exports = "SVG-mock";
