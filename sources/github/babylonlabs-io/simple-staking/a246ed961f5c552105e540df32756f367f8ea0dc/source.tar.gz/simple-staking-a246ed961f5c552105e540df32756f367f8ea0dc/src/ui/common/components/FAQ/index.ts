export { FAQ } from "./FAQ";
