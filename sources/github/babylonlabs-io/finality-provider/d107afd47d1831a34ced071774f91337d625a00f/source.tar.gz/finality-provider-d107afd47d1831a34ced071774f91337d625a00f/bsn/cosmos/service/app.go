package service

import (
	"fmt"
	"github.com/babylonlabs-io/finality-provider/bsn/cosmos/clientcontroller"
	"github.com/babylonlabs-io/finality-provider/bsn/cosmos/config"
	cosmwasmcfg "github.com/babylonlabs-io/finality-provider/bsn/cosmos/cosmwasmclient/config"
	fpcc "github.com/babylonlabs-io/finality-provider/clientcontroller"
	"github.com/babylonlabs-io/finality-provider/finality-provider/service"
	"github.com/babylonlabs-io/finality-provider/finality-provider/store"
	"github.com/babylonlabs-io/finality-provider/metrics"
	"github.com/lightningnetwork/lnd/kvdb"
	"go.uber.org/zap"
)

// NewCosmosBSNFinalityProviderAppFromConfig creates a new FinalityProviderApp instance from the given configuration for cosmos BSN.
func NewCosmosBSNFinalityProviderAppFromConfig(
	cfg *config.CosmosFPConfig,
	db kvdb.Backend,
	logger *zap.Logger,
) (*service.FinalityProviderApp, error) {
	cc, err := fpcc.NewBabylonController(cfg.Common.BabylonConfig, logger)
	if err != nil {
		return nil, fmt.Errorf("failed to create rpc client for the Babylon chain: %w", err)
	}
	if err := cc.Start(); err != nil {
		return nil, fmt.Errorf("failed to start rpc client for the Babylon chain: %w", err)
	}

	wasmEncodingCfg := cosmwasmcfg.GetWasmdEncodingConfig()
	consumerCon, err := clientcontroller.NewCosmwasmConsumerController(cfg.Cosmwasm, wasmEncodingCfg, logger)
	if err != nil {
		return nil, fmt.Errorf("failed to create rpc client for the consumer chain cosmos: %w", err)
	}

	// if the EOTSManagerAddress is empty, run a local EOTS manager;
	// otherwise connect a remote one with a gRPC client
	em, err := service.InitEOTSManagerClient(cfg.Common.EOTSManagerAddress, cfg.Common.HMACKey)
	if err != nil {
		return nil, fmt.Errorf("failed to create EOTS manager client: %w", err)
	}

	logger.Info("successfully connected to a remote EOTS manager", zap.String("address", cfg.Common.EOTSManagerAddress))

	fpMetrics := metrics.NewFpMetrics()

	poller := service.NewChainPoller(logger, cfg.Common.PollerConfig, consumerCon, fpMetrics)

	pubRandStore, err := store.NewPubRandProofStore(db)
	if err != nil {
		return nil, fmt.Errorf("failed to initiate public randomness store: %w", err)
	}

	rndCommitter := service.NewDefaultRandomnessCommitter(
		service.NewRandomnessCommitterConfig(cfg.Common.NumPubRand, int64(cfg.Common.TimestampingDelayBlocks), cfg.Common.ContextSigningHeight),
		service.NewPubRandState(pubRandStore),
		consumerCon,
		em,
		logger,
		fpMetrics,
	)

	heightDeterminer := service.NewStartHeightDeterminer(consumerCon, cfg.Common.PollerConfig, logger)
	finalitySubmitter := service.NewDefaultFinalitySubmitter(consumerCon,
		em,
		rndCommitter.GetPubRandProofList,
		service.NewDefaultFinalitySubmitterConfig(cfg.Common.MaxSubmissionRetries,
			cfg.Common.ContextSigningHeight,
			cfg.Common.SubmissionRetryInterval),
		logger,
		fpMetrics,
	)

	fpApp, err := service.NewFinalityProviderApp(cfg.Common, cc, consumerCon, em, poller, rndCommitter, heightDeterminer, finalitySubmitter, fpMetrics, db, logger)
	if err != nil {
		return nil, fmt.Errorf("failed to create finality provider app: %w", err)
	}

	return fpApp, nil
}
