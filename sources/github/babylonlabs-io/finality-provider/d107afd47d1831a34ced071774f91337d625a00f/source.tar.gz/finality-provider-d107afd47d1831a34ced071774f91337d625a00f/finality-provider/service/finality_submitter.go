package service

import (
	"context"
	"encoding/hex"
	"errors"
	"fmt"
	"math"
	"strings"
	"time"

	"github.com/avast/retry-go/v4"
	bbntypes "github.com/babylonlabs-io/babylon/v3/types"
	fpcc "github.com/babylonlabs-io/finality-provider/clientcontroller"
	"github.com/babylonlabs-io/finality-provider/clientcontroller/api"
	"github.com/babylonlabs-io/finality-provider/eotsmanager"
	"github.com/babylonlabs-io/finality-provider/finality-provider/proto"
	"github.com/babylonlabs-io/finality-provider/metrics"
	"github.com/babylonlabs-io/finality-provider/types"
	"github.com/btcsuite/btcd/btcec/v2"
	"go.uber.org/zap"
)

var _ types.FinalitySignatureSubmitter = (*DefaultFinalitySubmitter)(nil)

type PubRandProofListGetterFunc func(startHeight uint64, numPubRand uint64) ([][]byte, error)

type DefaultFinalitySubmitter struct {
	State               types.FinalityProviderState
	Em                  eotsmanager.EOTSManager
	ConsumerCtrl        api.ConsumerController
	ProofListGetterFunc PubRandProofListGetterFunc
	Cfg                 *FinalitySubmitterConfig
	Logger              *zap.Logger
	Metrics             *metrics.FpMetrics
}

type FinalitySubmitterConfig struct {
	MaxSubmissionRetries    uint32
	ContextSigningHeight    uint64
	SubmissionRetryInterval time.Duration
}

func NewDefaultFinalitySubmitterConfig(
	maxSubmissionRetries uint32,
	contextSigningHeight uint64,
	submissionRetryInterval time.Duration,
) *FinalitySubmitterConfig {
	return &FinalitySubmitterConfig{
		MaxSubmissionRetries:    maxSubmissionRetries,
		SubmissionRetryInterval: submissionRetryInterval,
		ContextSigningHeight:    contextSigningHeight,
	}
}

func NewDefaultFinalitySubmitter(
	consumerCtrl api.ConsumerController,
	em eotsmanager.EOTSManager,
	proofListGetterFunc PubRandProofListGetterFunc,
	cfg *FinalitySubmitterConfig,
	logger *zap.Logger,
	metrics *metrics.FpMetrics) *DefaultFinalitySubmitter {
	return &DefaultFinalitySubmitter{
		Em:                  em,
		ConsumerCtrl:        consumerCtrl,
		ProofListGetterFunc: proofListGetterFunc,
		Cfg:                 cfg,
		Logger:              logger.With(zap.String("module", "finality_submitter")),
		Metrics:             metrics,
	}
}

func (ds *DefaultFinalitySubmitter) GetBtcPkHex() string {
	return ds.GetBtcPkBIP340().MarshalHex()
}

func (ds *DefaultFinalitySubmitter) GetBtcPk() *btcec.PublicKey {
	return ds.State.GetBtcPk()
}

func (ds *DefaultFinalitySubmitter) GetBtcPkBIP340() *bbntypes.BIP340PubKey {
	return ds.State.GetBtcPkBIP340()
}

func (ds *DefaultFinalitySubmitter) MustSetLastVotedHeight(height uint64) {
	if err := ds.State.SetLastVotedHeight(height); err != nil {
		ds.Logger.Fatal("failed to update state after finality signature submitted",
			zap.String("pk", ds.GetBtcPkHex()), zap.Uint64("height", height), zap.Error(err))
	}
}

func (ds *DefaultFinalitySubmitter) mustSetStatus(s proto.FinalityProviderStatus) {
	if err := ds.State.SetStatus(s); err != nil {
		ds.Logger.Fatal("failed to set finality-provider status",
			zap.String("pk", ds.GetBtcPkHex()), zap.String("status", s.String()))
	}
}

// InitState sets the finality provider state store.
func (ds *DefaultFinalitySubmitter) InitState(state types.FinalityProviderState) error {
	if ds.State != nil {
		return fmt.Errorf("finality provider state is already set")
	}

	ds.State = state

	return nil
}

// FilterBlocksForVoting filters blocks based on the finality provider's voting power and height criteria for submission, returning a slice of blocks eligible for voting and an error if any issues are encountered during processing. It also updates the finality provider instance status according to the block's voting power.
func (ds *DefaultFinalitySubmitter) FilterBlocksForVoting(ctx context.Context, blocks []types.BlockDescription) ([]types.BlockDescription, error) {
	processedBlocks := make([]types.BlockDescription, 0, len(blocks))

	var hasPower bool
	var err error
	for _, b := range blocks {
		blk := b
		if blk.GetHeight() <= ds.State.GetLastVotedHeight() {
			ds.Logger.Debug(
				"the block height is lower than last processed height",
				zap.String("pk", ds.GetBtcPkHex()),
				zap.Uint64("block_height", blk.GetHeight()),
				zap.Uint64("last_voted_height", ds.State.GetLastVotedHeight()),
			)

			continue
		}

		// check whether the finality provider has voting power
		blkHeight := blk.GetHeight()
		hasPower, err = ds.getVotingPowerWithRetry(ctx, blkHeight)
		if err != nil {
			return nil, fmt.Errorf("failed to get voting power for height %d: %w", blkHeight, err)
		}
		if !hasPower {
			ds.Logger.Debug(
				"the finality-provider does not have voting power",
				zap.String("pk", ds.GetBtcPkHex()),
				zap.Uint64("block_height", blkHeight),
			)

			// the finality provider does not have voting power
			// and it will never will at this block, so continue
			ds.Metrics.IncrementFpTotalBlocksWithoutVotingPower(ds.GetBtcPkHex())

			continue
		}
		ds.Logger.Debug(
			"the finality-provider has voting power",
			zap.String("pk", ds.GetBtcPkHex()),
			zap.Uint64("block_height", blkHeight),
		)

		processedBlocks = append(processedBlocks, blk)
	}

	// update fp status according to the power for the last block
	if hasPower && ds.State.GetStatus() != proto.FinalityProviderStatus_ACTIVE {
		ds.mustSetStatus(proto.FinalityProviderStatus_ACTIVE)
	}

	if !hasPower && ds.State.GetStatus() == proto.FinalityProviderStatus_ACTIVE {
		ds.mustSetStatus(proto.FinalityProviderStatus_INACTIVE)
	}

	return processedBlocks, nil
}

// SubmitBatchFinalitySignatures builds and sends a finality signature over the given block to the consumer chain
// Contract:
//  1. the input blocks should be in the ascending order of height
//  2. the returned response could be nil due to no transactions might be made in the end
func (ds *DefaultFinalitySubmitter) SubmitBatchFinalitySignatures(ctx context.Context, blocks []types.BlockDescription) (*types.TxResponse, error) {
	if len(blocks) == 0 {
		return nil, fmt.Errorf("cannot send signatures for empty blocks")
	}

	blocks, err := ds.FilterBlocksForVoting(ctx, blocks)
	if err != nil {
		return nil, fmt.Errorf("failed to filter blocks for voting: %w", err)
	}

	if len(blocks) == 0 {
		ds.Logger.Debug(
			"no blocks to vote for after filtering",
			zap.String("pk", ds.GetBtcPkHex()),
			zap.Uint64("last_voted_height", ds.State.GetLastVotedHeight()),
		)

		return nil, nil // No blocks to vote for
	}

	var failedCycles uint32
	targetHeight := blocks[len(blocks)-1].GetHeight()

	// Retry loop with internal retry logic
	for {
		res, err := ds.submitBatchFinalitySignaturesOnce(ctx, blocks)
		if err != nil {
			ds.Logger.Debug(
				"failed to submit finality signature to the consumer chain",
				zap.String("pk", ds.GetBtcPkHex()),
				zap.Uint32("current_failures", failedCycles),
				zap.Uint64("target_start_height", blocks[0].GetHeight()),
				zap.Uint64("target_end_height", targetHeight),
				zap.Error(err),
			)

			// Handle different error types
			if fpcc.IsUnrecoverable(err) {
				return nil, err
			}

			if fpcc.IsExpected(err) {
				return nil, nil
			}

			failedCycles++
			if failedCycles > ds.Cfg.MaxSubmissionRetries {
				return nil, fmt.Errorf("reached max failed cycles with err: %w", err)
			}
		} else {
			// The signature has been successfully submitted
			return res, nil
		}

		// Check if the block is already finalized
		finalized, err := ds.CheckBlockFinalization(ctx, targetHeight)
		if err != nil {
			return nil, fmt.Errorf("failed to query block finalization at height %v: %w", targetHeight, err)
		}
		if finalized {
			ds.Logger.Debug(
				"the block is already finalized, skip submission",
				zap.String("pk", ds.GetBtcPkHex()),
				zap.Uint64("target_height", targetHeight),
			)

			ds.Metrics.IncrementFpTotalFailedVotes(ds.GetBtcPkHex())

			return nil, nil
		}

		// Wait for the retry interval
		select {
		case <-time.After(ds.Cfg.SubmissionRetryInterval):
			// Continue to next retry iteration
			continue
		case <-ctx.Done():
			ds.Logger.Debug("the finality-provider instance is closing", zap.String("pk", ds.GetBtcPkHex()))

			return nil, ErrFinalityProviderShutDown
		}
	}
}

// submitBatchFinalitySignaturesOnce performs a single submission attempt (original SubmitBatchFinalitySignatures logic)
func (ds *DefaultFinalitySubmitter) submitBatchFinalitySignaturesOnce(ctx context.Context, blocks []types.BlockDescription) (*types.TxResponse, error) {
	if len(blocks) == 0 {
		return nil, fmt.Errorf("should not submit batch finality signature with zero block")
	}

	if len(blocks) > math.MaxUint32 {
		return nil, fmt.Errorf("should not submit batch finality signature with too many blocks")
	}

	// Get proofs and public randomness for each block
	var proofBytesList [][]byte
	var prList []*btcec.FieldVal

	// TODO: https://github.com/babylonlabs-io/finality-provider/issues/560
	for _, block := range blocks {
		// Get public randomness for this specific height
		pr, err := ds.GetPubRandList(block.GetHeight(), 1)
		if err != nil {
			return nil, fmt.Errorf("failed to get public randomness for height %d: %w", block.GetHeight(), err)
		}
		prList = append(prList, pr[0])

		// Get proof for this specific height
		proofs, err := ds.ProofListGetterFunc(block.GetHeight(), 1)
		if err != nil {
			return nil, fmt.Errorf("failed to get public randomness inclusion proof for height %d: %w\nplease recover the randomness proof from db", block.GetHeight(), err)
		}
		if len(proofs) != 1 {
			return nil, fmt.Errorf("expected exactly one proof for height %d, got %d", block.GetHeight(), len(proofs))
		}
		proofBytesList = append(proofBytesList, proofs[0])
	}

	// Create slices to store only the valid items
	validBlocks := make([]types.BlockDescription, 0, len(blocks))
	validPrList := make([]*btcec.FieldVal, 0, len(blocks))
	validProofList := make([][]byte, 0, len(blocks))
	validSigList := make([]*btcec.ModNScalar, 0, len(blocks))

	// Process each block and collect only valid items
	for i, b := range blocks {
		eotsSig, err := ds.SignFinalitySig(b)
		if err != nil {
			if !errors.Is(err, ErrFailedPrecondition) {
				return nil, err
			}
			// Skip this block if we encounter FailedPrecondition
			ds.Logger.Warn("encountered FailedPrecondition error, skipping block",
				zap.Uint64("height", b.GetHeight()),
				zap.String("hash", hex.EncodeToString(b.GetHash())),
				zap.Error(err))

			continue
		}

		// If signature is valid, append all corresponding items
		validBlocks = append(validBlocks, b)
		validPrList = append(validPrList, prList[i])
		validProofList = append(validProofList, proofBytesList[i])
		validSigList = append(validSigList, eotsSig.ToModNScalar())
	}

	// If all blocks were skipped, return early
	if len(validBlocks) == 0 {
		ds.Logger.Info("all blocks were skipped due to double sign errors")

		return nil, nil
	}

	// send finality signature to the consumer chain
	res, err := ds.ConsumerCtrl.SubmitBatchFinalitySigs(ctx, api.NewSubmitBatchFinalitySigsRequest(
		ds.GetBtcPk(),
		validBlocks,
		validPrList,
		validProofList,
		validSigList,
	))

	if err != nil {
		if strings.Contains(err.Error(), "jailed") {
			return nil, ErrFinalityProviderJailed
		}
		if strings.Contains(err.Error(), "slashed") {
			return nil, ErrFinalityProviderSlashed
		}

		return nil, fmt.Errorf("failed to submit finality signature to the consumer chain: %w", err)
	}

	// update the metrics with voted blocks
	for _, b := range validBlocks {
		ds.Metrics.RecordFpVotedHeight(ds.GetBtcPkHex(), b.GetHeight())
	}

	// update state with the highest height of this batch
	highBlock := blocks[len(blocks)-1]
	ds.MustSetLastVotedHeight(highBlock.GetHeight())

	return res, nil
}

// CheckBlockFinalization checks if a block at given height is finalized.
func (ds *DefaultFinalitySubmitter) CheckBlockFinalization(ctx context.Context, height uint64) (bool, error) {
	b, err := ds.ConsumerCtrl.QueryBlock(ctx, height)
	if err != nil {
		return false, fmt.Errorf("failed to query block at height %d: %w", height, err)
	}

	return b.IsFinalized(), nil
}

func (ds *DefaultFinalitySubmitter) SignFinalitySig(b types.BlockDescription) (*bbntypes.SchnorrEOTSSig, error) {
	// build proper finality signature request
	var msgToSign []byte
	if b.GetHeight() >= ds.Cfg.ContextSigningHeight {
		signCtx := ds.ConsumerCtrl.GetFpFinVoteContext()
		msgToSign = b.MsgToSign(signCtx)
	} else {
		msgToSign = b.MsgToSign("")
	}

	sig, err := ds.Em.SignEOTS(ds.GetBtcPkBIP340().MustMarshal(), ds.State.GetChainID(), msgToSign, b.GetHeight())
	if err != nil {
		if strings.Contains(err.Error(), failedPreconditionErrStr) {
			return nil, ErrFailedPrecondition
		}

		return nil, fmt.Errorf("failed to sign EOTS: %w", err)
	}

	return bbntypes.NewSchnorrEOTSSigFromModNScalar(sig), nil
}

func (ds *DefaultFinalitySubmitter) GetPubRandList(startHeight uint64, numPubRand uint32) ([]*btcec.FieldVal, error) {
	pubRandList, err := ds.Em.CreateRandomnessPairList(
		ds.GetBtcPkBIP340().MustMarshal(),
		ds.State.GetChainID(),
		startHeight,
		numPubRand,
	)
	if err != nil {
		return nil, fmt.Errorf("failed to create public randomness list: %w", err)
	}

	return pubRandList, nil
}

func (ds *DefaultFinalitySubmitter) getVotingPowerWithRetry(ctx context.Context, height uint64) (bool, error) {
	var (
		hasPower bool
		err      error
	)

	if err := retry.Do(func() error {
		hasPower, err = ds.ConsumerCtrl.QueryFinalityProviderHasPower(ctx, api.NewQueryFinalityProviderHasPowerRequest(
			ds.GetBtcPk(),
			height,
		))
		if err != nil {
			return fmt.Errorf("failed to query the voting power: %w", err)
		}

		return nil
	}, RtyAtt, RtyDel, RtyErr, retry.OnRetry(func(n uint, err error) {
		ds.Logger.Debug(
			"failed to query the voting power",
			zap.Uint("attempt", n+1),
			zap.Uint("max_attempts", RtyAttNum),
			zap.Error(err),
		)
	})); err != nil {
		return false, fmt.Errorf("failed to query the voting power: %w", err)
	}

	return hasPower, nil
}
