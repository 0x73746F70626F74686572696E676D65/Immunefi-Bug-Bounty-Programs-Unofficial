export const REDEEM_VERSION = 192;
