package e2e

import (
	"encoding/hex"
	"fmt"
	"math/rand"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"testing"
	"time"

	appparams "github.com/babylonlabs-io/babylon/v3/app/params"
	"github.com/babylonlabs-io/babylon/v3/app/signingcontext"

	"github.com/babylonlabs-io/babylon-sdk/tests/e2e/cosmos-integration-e2e/clientcontroller/babylon"
	cwconfig "github.com/babylonlabs-io/babylon-sdk/tests/e2e/cosmos-integration-e2e/clientcontroller/config"
	"github.com/babylonlabs-io/babylon-sdk/tests/e2e/cosmos-integration-e2e/clientcontroller/cosmwasm"

	sdkmath "cosmossdk.io/math"
	wasmparams "github.com/CosmWasm/wasmd/app/params"
	wasmtypes "github.com/CosmWasm/wasmd/x/wasm/types"
	bbnparams "github.com/babylonlabs-io/babylon/v3/app/params"
	txformat "github.com/babylonlabs-io/babylon/v3/btctxformatter"
	"github.com/babylonlabs-io/babylon/v3/client/config"
	"github.com/babylonlabs-io/babylon/v3/testutil/datagen"
	bbn "github.com/babylonlabs-io/babylon/v3/types"
	btcctypes "github.com/babylonlabs-io/babylon/v3/x/btccheckpoint/types"
	btclctypes "github.com/babylonlabs-io/babylon/v3/x/btclightclient/types"
	bstypes "github.com/babylonlabs-io/babylon/v3/x/btcstaking/types"
	bsctypes "github.com/babylonlabs-io/babylon/v3/x/btcstkconsumer/types"
	ckpttypes "github.com/babylonlabs-io/babylon/v3/x/checkpointing/types"
	epochingtypes "github.com/babylonlabs-io/babylon/v3/x/epoching/types"
	ftypes "github.com/babylonlabs-io/babylon/v3/x/finality/types"
	itypes "github.com/babylonlabs-io/babylon/v3/x/incentive/types"
	"github.com/btcsuite/btcd/btcec/v2"
	"github.com/btcsuite/btcd/chaincfg"
	"github.com/btcsuite/btcd/wire"
	coretypes "github.com/cometbft/cometbft/rpc/core/types"
	"github.com/cosmos/cosmos-sdk/codec"
	codectypes "github.com/cosmos/cosmos-sdk/codec/types"
	sdk "github.com/cosmos/cosmos-sdk/types"
	"github.com/cosmos/cosmos-sdk/types/bech32"
	sdkquerytypes "github.com/cosmos/cosmos-sdk/types/query"
	"github.com/cosmos/cosmos-sdk/x/auth/tx"
	authtypes "github.com/cosmos/cosmos-sdk/x/auth/types"
	channeltypes "github.com/cosmos/ibc-go/v10/modules/core/04-channel/types"
	"github.com/stretchr/testify/require"
	"github.com/stretchr/testify/suite"
	"go.uber.org/zap"
)

const (
	babylonPrefix = "bbn"
	// Consumer chain address prefixes (hardcoded from demo/app/params)
	consumerBech32PrefixAccAddr  = "bbnc"
	consumerBech32PrefixAccPub   = "bbnc" + "pub"
	consumerBech32PrefixValAddr  = "bbnc" + "valoper"
	consumerBech32PrefixValPub   = "bbnc" + "valoperpub"
	consumerBech32PrefixConsAddr = "bbnc" + "valcons"
	consumerBech32PrefixConsPub  = "bbnc" + "valconspub"
)

var (
	r   = rand.New(rand.NewSource(time.Now().Unix()))
	net = &chaincfg.SimNetParams

	minCommissionRate                   = sdkmath.LegacyNewDecWithPrec(5, 2) // 5%
	babylonFpBTCSK, babylonFpBTCPK, _   = datagen.GenRandomBTCKeyPair(r)
	babylonFpBTCSK2, babylonFpBTCPK2, _ = datagen.GenRandomBTCKeyPair(r)
	stakingValue                        = int64(2 * 10e8)

	randListInfo1 *datagen.RandListInfo
	randListInfo2 *datagen.RandListInfo

	babylonChainID = "chain-test"

	consumerFpBTCSK                       *btcec.PrivateKey
	consumerFpBTCPK                       *btcec.PublicKey
	consumerDelBtcSk, consumerDelBtcPk, _ = datagen.GenRandomBTCKeyPair(r)
)

func getFirstIBCDenom(balance sdk.Coins) string {
	// Look up the ugly IBC denom
	denoms := balance.Denoms()
	var denomB string
	for _, d := range denoms {
		if strings.HasPrefix(d, "ibc/") {
			denomB = d
			break
		}
	}
	return denomB
}

// TestBCDConsumerIntegrationTestSuite includes babylon<->bcd integration related tests
func TestBCDConsumerIntegrationTestSuite(t *testing.T) {
	suite.Run(t, new(BCDConsumerIntegrationTestSuite))
}

type BCDConsumerIntegrationTestSuite struct {
	suite.Suite

	babylonController  *babylon.BabylonController
	cosmwasmController *cosmwasm.CosmwasmConsumerController
	consumerID         string
}

func (s *BCDConsumerIntegrationTestSuite) SetupSuite() {
	s.T().Log("setting up e2e integration test suite...")

	err := s.initBabylonController()
	s.Require().NoError(err, "Failed to initialize BabylonController")

	err = s.initCosmwasmController()
	s.Require().NoError(err, "Failed to initialize CosmwasmConsumerController")
}

func (s *BCDConsumerIntegrationTestSuite) TearDownSuite() {
	s.T().Log("tearing down e2e integration test suite...")

	// Get the current working directory
	currentDir, err := os.Getwd()
	if err != nil {
		s.T().Errorf("Failed to get current working directory: %v", err)
		return
	}

	// Construct the path to the Makefile directory
	makefileDir := filepath.Join(currentDir, "../../contrib/images")

	// Run the stop-bcd-consumer-integration make target
	cmd := exec.Command("make", "-C", makefileDir, "stop-bcd-consumer-integration")
	output, err := cmd.CombinedOutput()
	if err != nil {
		s.T().Errorf("Failed to run stop-bcd-consumer-integration: %v\nOutput: %s", err, output)
	} else {
		s.T().Log("Successfully stopped integration test")
	}
}

func (s *BCDConsumerIntegrationTestSuite) Test01ChainStartup() {
	var (
		babylonStatus  *coretypes.ResultStatus
		consumerStatus *coretypes.ResultStatus
		err            error
	)

	// Use Babylon controller
	s.Eventually(func() bool {
		babylonStatus, err = s.babylonController.QueryNodeStatus()
		return err == nil && babylonStatus != nil && babylonStatus.SyncInfo.LatestBlockHeight >= 1
	}, time.Minute, time.Second, "Failed to query Babylon node status", err)
	s.T().Logf("Babylon node status: %v", babylonStatus.SyncInfo.LatestBlockHeight)

	// Use Cosmwasm controller
	s.Eventually(func() bool {
		consumerStatus, err = s.cosmwasmController.GetCometNodeStatus()
		return err == nil && consumerStatus != nil && consumerStatus.SyncInfo.LatestBlockHeight >= 1
	}, time.Minute*2, time.Second, "Failed to query Consumer node status", err)
	s.T().Logf("Consumer node status: %v", consumerStatus.SyncInfo.LatestBlockHeight)
}

// Test02RegisterAndIntegrateConsumer registers a new consumer and
// 1. Verifies that an IBC connection is established between the consumer chain and Babylon
// 2. Checks that the consumer is registered in Babylon's consumer registry
// 3. Validates the consumer registration details in Babylon
// Note: setup-bcd.sh now handles IBC channel creation automatically
func (s *BCDConsumerIntegrationTestSuite) Test02RegisterAndIntegrateConsumer() {
	// Wait for transfer channel (created by setup-bcd.sh)
	s.waitForTransferChannel()

	// Query and set the consumer ID from the IBC client
	s.queryAndSetConsumerID()

	// Register and verify consumer using the IBC client ID
	s.registerVerifyConsumer()

	// Wait for zoneconcierge channel (created by setup-bcd.sh after contracts)
	s.waitForZoneconciergeChannel()

	// Wait for all contracts are set
	s.waitForContractInstantiation()
}

// Test03BTCHeaderPropagation
// 1. Inserts initial BTC headers in Babylon
// 2. Verifies that headers propagate from Babylon -> Consumer
// 3. Creates a fork in Babylon
// 4. Verifies that fork headers propagate from Babylon -> Consumer
func (s *BCDConsumerIntegrationTestSuite) Test03BTCHeaderPropagation() {
	s.T().Log("Starting BTC header propagation test")

	// Insert initial BTC headers in Babylon
	s.T().Log("Inserting initial BTC headers in Babylon")
	header1, err := s.babylonController.InsertNewEmptyBtcHeader(r)
	s.Require().NoError(err)
	s.T().Logf("Inserted header 1 with hash: %s", header1.Hash.MarshalHex())

	header2, err := s.babylonController.InsertNewEmptyBtcHeader(r)
	s.Require().NoError(err)
	s.T().Logf("Inserted header 2 with hash: %s", header2.Hash.MarshalHex())

	header3, err := s.babylonController.InsertNewEmptyBtcHeader(r)
	s.Require().NoError(err)
	s.T().Logf("Inserted header 3 with hash: %s", header3.Hash.MarshalHex())

	// Wait until headers are inserted in Babylon
	s.T().Log("Waiting for headers to be inserted in Babylon")
	var bbnBtcHeaders *btclctypes.QueryMainChainResponse
	s.Eventually(func() bool {
		bbnBtcHeaders, err = s.babylonController.QueryBtcLightClientMainChain()
		return err == nil && bbnBtcHeaders != nil && len(bbnBtcHeaders.Headers) == 4
	}, time.Second*60, time.Second)
	s.T().Logf("Found %d headers in Babylon", len(bbnBtcHeaders.Headers))

	// Reverse the headers (as query returns headers in reverse order)
	reverseHeaders := make([]*btclctypes.BTCHeaderInfoResponse, len(bbnBtcHeaders.Headers))
	for i, header := range bbnBtcHeaders.Headers {
		reverseHeaders[len(bbnBtcHeaders.Headers)-1-i] = header
	}
	// Height 0 is base header, so no need to assert
	s.Require().Equal(header1.Hash.MarshalHex(), reverseHeaders[1].HashHex)
	s.Require().Equal(header2.Hash.MarshalHex(), reverseHeaders[2].HashHex)
	s.Require().Equal(header3.Hash.MarshalHex(), reverseHeaders[3].HashHex)
	s.T().Log("Successfully verified headers in Babylon")

	// Headers should propagate from Babylon -> Consumer
	s.T().Log("Waiting for headers to propagate to Consumer chain")
	var consumerBtcHeaders *cosmwasm.BtcHeadersResponse
	s.Eventually(func() bool {
		consumerBtcHeaders, err = s.cosmwasmController.QueryBtcHeaders(nil)
		return err == nil && consumerBtcHeaders != nil && len(consumerBtcHeaders.Headers) == 4
	}, time.Second*60, time.Second)
	s.T().Logf("Found %d headers in Consumer chain", len(consumerBtcHeaders.Headers))

	s.Require().Equal(header1.Hash.MarshalHex(), consumerBtcHeaders.Headers[1].Hash)
	s.Require().Equal(header2.Hash.MarshalHex(), consumerBtcHeaders.Headers[2].Hash)
	s.Require().Equal(header3.Hash.MarshalHex(), consumerBtcHeaders.Headers[3].Hash)
	s.T().Log("Successfully verified headers in Consumer chain")

	// Create fork from header2
	s.T().Log("Creating fork from header2")
	forkBase := header2 // Known ancestor to fork from
	forkHeader1 := datagen.GenRandomValidBTCHeaderInfoWithParent(r, *forkBase)
	forkHeader2 := datagen.GenRandomValidBTCHeaderInfoWithParent(r, *forkHeader1)
	s.T().Logf("Generated fork headers with hashes: %s, %s", forkHeader1.Hash.MarshalHex(), forkHeader2.Hash.MarshalHex())

	// Insert fork in Babylon
	s.T().Log("Inserting fork headers in Babylon")
	_, err = s.babylonController.InsertBtcBlockHeaders([]bbn.BTCHeaderBytes{
		*forkHeader1.Header,
		*forkHeader2.Header,
	})
	s.Require().NoError(err)
	s.T().Log("Successfully inserted fork headers in Babylon")

	// Wait until headers are inserted in Babylon
	s.T().Log("Waiting for fork headers to be inserted in Babylon")
	s.Eventually(func() bool {
		bbnBtcHeaders, err = s.babylonController.QueryBtcLightClientMainChain()
		return err == nil && bbnBtcHeaders != nil && len(bbnBtcHeaders.Headers) == 5
	}, time.Second*60, time.Second)
	s.T().Logf("Found %d headers in Babylon after fork", len(bbnBtcHeaders.Headers))

	// Reverse the headers (as query returns headers in reverse order)
	reverseHeaders = make([]*btclctypes.BTCHeaderInfoResponse, len(bbnBtcHeaders.Headers))
	for i, header := range bbnBtcHeaders.Headers {
		reverseHeaders[len(bbnBtcHeaders.Headers)-1-i] = header
	}
	s.Require().Equal(forkHeader2.Hash.MarshalHex(), reverseHeaders[4].HashHex)
	s.Require().Equal(forkHeader1.Hash.MarshalHex(), reverseHeaders[3].HashHex)
	s.Require().Equal(header2.Hash.MarshalHex(), reverseHeaders[2].HashHex)
	s.Require().Equal(header1.Hash.MarshalHex(), reverseHeaders[1].HashHex)
	s.T().Log("Successfully verified fork headers in Babylon")

	// Fork headers should propagate from Babylon -> Consumer
	s.T().Log("Waiting for fork headers to propagate to Consumer chain")
	s.Eventually(func() bool {
		consumerBtcHeaders, err = s.cosmwasmController.QueryBtcHeaders(nil)
		return err == nil && consumerBtcHeaders != nil && len(consumerBtcHeaders.Headers) == 5
	}, time.Second*60, time.Second)
	s.T().Logf("Found %d headers in Consumer chain after fork", len(consumerBtcHeaders.Headers))

	s.Require().Equal(forkHeader2.Hash.MarshalHex(), consumerBtcHeaders.Headers[4].Hash)
	s.Require().Equal(forkHeader1.Hash.MarshalHex(), consumerBtcHeaders.Headers[3].Hash)
	s.Require().Equal(header2.Hash.MarshalHex(), consumerBtcHeaders.Headers[2].Hash)
	s.Require().Equal(header1.Hash.MarshalHex(), consumerBtcHeaders.Headers[1].Hash)
	s.T().Log("Successfully verified fork headers in Consumer chain")
}

// Test04ConsumerFeeCollector tests whether the collected fees are sent to the finality contract
func (s *BCDConsumerIntegrationTestSuite) Test04ConsumerFeeCollector() {
	// Get initial finality contract balance on consumer chain
	initialFinalityBalance, err := s.cosmwasmController.QueryFinalityContractBalances()
	s.NoError(err)
	s.T().Logf("Initial finality contract balance: %s", initialFinalityBalance)

	// Generate some transactions to accumulate fees in the fee collector
	// We'll finalize the next epoch which involves multiple transactions (BTC headers, proofs, etc.)
	s.T().Log("Generating transactions to accumulate fees...")
	s.finalizeNextEpoch()

	// Check if finality contract balance increased (indicating rewards were transferred)
	var finalFinalityBalance sdk.Coins
	s.Eventually(func() bool {
		finalFinalityBalance, err = s.cosmwasmController.QueryFinalityContractBalances()
		if err != nil {
			s.T().Logf("Error querying finality contract balance: %v", err)
			return false
		}
		s.T().Logf("Final finality contract balance: %s", finalFinalityBalance)

		// Check if the balance increased (rewards were distributed)
		if finalFinalityBalance.IsAllGTE(initialFinalityBalance) && !finalFinalityBalance.Equal(initialFinalityBalance) {
			s.T().Log("Finality contract balance increased - rewards were successfully distributed!")
			return true
		}
		return false
	}, time.Minute*2, time.Second*5)

	// Assert that rewards distribution occurred
	// TODO: here we only assert the finality balance is increasing but
	//  we should further assert the increased number is correct
	s.True(finalFinalityBalance.IsAllGTE(initialFinalityBalance),
		"Finality contract balance should have increased due to reward distribution")
	s.False(finalFinalityBalance.Equal(initialFinalityBalance),
		"Finality contract balance should have changed from initial balance")

	s.T().Log("Successfully verified rewards distribution to finality contracts via fee collector interception")
}

// Test05CreateConsumerFinalityProvider
// 1. Creates and registers a random number of consumer FPs in Babylon.
// 2. Babylon automatically sends IBC packets to the consumer chain to transmit this data.
// 3. Verifies that the registered consumer FPs in Babylon match the data stored in the consumer chain's contract.
func (s *BCDConsumerIntegrationTestSuite) Test05CreateConsumerFinalityProvider() {
	// generate a random number of finality providers from 1 to 5
	numConsumerFPs := datagen.RandomInt(r, 5) + 1
	fmt.Println("Number of consumer finality providers: ", numConsumerFPs)

	var consumerFps []*bstypes.FinalityProvider
	for i := 0; i < int(numConsumerFPs); i++ {
		consumerFp, SK, PK := s.createVerifyConsumerFP()
		if i == 0 {
			consumerFpBTCSK = SK
			consumerFpBTCPK = PK
		}
		consumerFps = append(consumerFps, consumerFp)
	}

	dataFromContract, err := s.cosmwasmController.QueryFinalityProviders()
	s.Require().NoError(err)

	// create a map of expected finality providers for verification
	fpMap := make(map[string]*bstypes.FinalityProvider)
	for _, consumerFp := range consumerFps {
		fpMap[consumerFp.BtcPk.MarshalHex()] = consumerFp
	}

	// validate that all finality providers match with the consumer list
	for _, consumerFp := range dataFromContract.Fps {
		fpFromMap, ok := fpMap[consumerFp.BtcPkHex]
		s.True(ok)
		s.Equal(fpFromMap.BtcPk.MarshalHex(), consumerFp.BtcPkHex)
		s.Equal(fpFromMap.SlashedBabylonHeight, consumerFp.SlashedHeight)
		s.Equal(fpFromMap.SlashedBtcHeight, consumerFp.SlashedBtcHeight)
		s.Equal(fpFromMap.BsnId, consumerFp.ConsumerId)
	}
}

// Test06MultiStakeToFPs
// 1. Creates a Babylon finality provider
// 2. Creates a pending state delegation multi-staking to both Babylon FP and 1 consumer FP
func (s *BCDConsumerIntegrationTestSuite) Test06MultiStakeToFPs() {
	consumerFp, err := s.babylonController.QueryFinalityProvider(bbn.NewBIP340PubKeyFromBTCPK(consumerFpBTCPK).MarshalHex())
	s.Require().NoError(err)
	s.Require().NotNil(consumerFp)

	// register a babylon finality provider
	babylonFp := s.createVerifyBabylonFP(babylonFpBTCSK)
	// commit and finalize pub rand so Babylon FP has voting power
	randList := s.commitAndFinalizePubRand(babylonFpBTCSK, babylonFpBTCPK, uint64(1))
	randListInfo1 = randList

	// create a delegation and multi-stake to both Babylon and consumer finality providers
	// NOTE: this will create delegation in pending state as covenant sigs are not provided
	delBtcPk, stakingTxHash := s.createBabylonDelegation(babylonFp, consumerFp.FinalityProvider, uint16(10000))

	// check delegation
	delegation, err := s.babylonController.QueryBTCDelegation(stakingTxHash)
	s.Require().NoError(err)
	s.NotNil(delegation)

	// check consumer finality provider delegation
	consumerPendingDelSet, err := s.babylonController.QueryFinalityProviderDelegations(consumerFp.FinalityProvider.BtcPk.MarshalHex(), 1)
	s.Require().NoError(err)
	s.Len(consumerPendingDelSet, 1)
	consumerPendingDels := consumerPendingDelSet[0]
	s.Len(consumerPendingDels.Dels, 1)
	s.Equal(delBtcPk.SerializeCompressed()[1:], consumerPendingDels.Dels[0].BtcPk.MustToBTCPK().SerializeCompressed()[1:])
	s.Len(consumerPendingDels.Dels[0].CovenantSigs, 0)

	// check Babylon finality provider delegation
	pendingDelSet, err := s.babylonController.QueryFinalityProviderDelegations(babylonFp.BtcPk.MarshalHex(), 1)
	s.Require().NoError(err)
	s.Len(pendingDelSet, 1)
	pendingDels := pendingDelSet[0]
	s.Len(pendingDels.Dels, 1)
	s.Equal(delBtcPk.SerializeCompressed()[1:], pendingDels.Dels[0].BtcPk.MustToBTCPK().SerializeCompressed()[1:])
	s.Len(pendingDels.Dels[0].CovenantSigs, 0)
}

func (s *BCDConsumerIntegrationTestSuite) Test07CommitPublicRandomness() {
	// Query consumer finality providers
	consumerFp, err := s.babylonController.QueryFinalityProvider(bbn.NewBIP340PubKeyFromBTCPK(consumerFpBTCPK).MarshalHex())
	s.Require().NoError(err)
	s.Require().NotNil(consumerFp)

	// Commit public randomness at the initial block height on the consumer chain
	consumerInitialHeight := uint64(1)
	numPubRand := uint64(1000)

	signingContext := s.cosmwasmController.GetFpRandCommitContext()
	randListInfo, msgCommitPubRandList, err := datagen.GenRandomMsgCommitPubRandList(r, consumerFpBTCSK, signingContext, consumerInitialHeight, numPubRand)
	s.NoError(err)
	randListInfo2 = randListInfo

	// Submit the public randomness to the consumer chain
	txResp, err := s.cosmwasmController.CommitPubRandList(
		consumerFpBTCPK,
		consumerInitialHeight,
		numPubRand,
		randListInfo.Commitment,
		msgCommitPubRandList.Sig.MustToBTCSig(),
	)
	s.NoError(err)
	s.NotNil(txResp)

	// wait until the consumer chain has finalized the current height
	consumerHeight, err := s.cosmwasmController.QueryLatestBlockHeight()
	s.NoError(err)
	s.T().Logf("Wait until consumer chain has finalized height %d", consumerHeight)
	s.finalizeUntilConsumerHeight(consumerHeight)
}

// Test08ActivateDelegation
// 1. Submits covenant signatures to activate a BTC delegation
// 2. Verifies the delegation is activated on Babylon
// 3. Checks that Babylon sends IBC packets to update the consumer chain
// 4. Verifies the delegation details in the consumer chain contract match Babylon
// 5. Confirms the consumer FP voting power equals the total stake amount
func (s *BCDConsumerIntegrationTestSuite) Test08ActivateDelegation() {
	// Query consumer finality provider
	consumerFp, err := s.babylonController.QueryFinalityProvider(bbn.NewBIP340PubKeyFromBTCPK(consumerFpBTCPK).MarshalHex())
	s.Require().NoError(err)
	s.Require().NotNil(consumerFp)

	// Activate the delegation by submitting covenant sigs
	s.submitCovenantSigs(consumerFp.FinalityProvider)

	// ensure the BTC delegation has covenant sigs now
	activeDelsSet, err := s.babylonController.QueryFinalityProviderDelegations(consumerFp.FinalityProvider.BtcPk.MarshalHex(), 1)
	s.NoError(err)
	s.Len(activeDelsSet, 1)

	activeDels, err := ParseRespsBTCDelToBTCDel(activeDelsSet[0])
	s.NoError(err)
	s.NotNil(activeDels)
	s.Len(activeDels.Dels, 1)

	activeDel := activeDels.Dels[0]
	s.True(activeDel.HasCovenantQuorums(1, 1))

	// Query the staking contract for delegations on the consumer chain
	var dataFromContract *cosmwasm.ConsumerDelegationsResponse
	s.Eventually(func() bool {
		dataFromContract, err = s.cosmwasmController.QueryDelegations()
		return err == nil && dataFromContract != nil && len(dataFromContract.Delegations) == 1
	}, time.Minute*2, time.Second)

	// Assert delegation details
	s.Empty(dataFromContract.Delegations[0].UndelegationInfo.DelegatorUnbondingInfo)
	s.Equal(activeDel.BtcPk.MarshalHex(), dataFromContract.Delegations[0].BtcPkHex)
	s.Len(dataFromContract.Delegations[0].FpBtcPkList, 2)
	s.Equal(activeDel.FpBtcPkList[0].MarshalHex(), dataFromContract.Delegations[0].FpBtcPkList[0])
	s.Equal(activeDel.FpBtcPkList[1].MarshalHex(), dataFromContract.Delegations[0].FpBtcPkList[1])
	s.Equal(activeDel.StartHeight, dataFromContract.Delegations[0].StartHeight)
	s.Equal(activeDel.EndHeight, dataFromContract.Delegations[0].EndHeight)
	s.Equal(activeDel.TotalSat, dataFromContract.Delegations[0].TotalSat)
	s.Equal(hex.EncodeToString(activeDel.StakingTx), hex.EncodeToString(dataFromContract.Delegations[0].StakingTx))
	s.Equal(activeDel.SlashingTx.ToHexStr(), hex.EncodeToString(dataFromContract.Delegations[0].SlashingTx))

	// Query and assert finality provider has total active stake
	s.Eventually(func() bool {
		fpInfo, err := s.cosmwasmController.QueryFinalityProviderInfo(consumerFp.FinalityProvider.BtcPk.MustToBTCPK())
		if err != nil {
			s.T().Logf("Error querying finality provider info: %v", err)
			return false
		}

		return fpInfo != nil &&
			fpInfo.TotalActiveSats == activeDel.TotalSat &&
			fpInfo.BtcPkHex == consumerFp.FinalityProvider.BtcPk.MarshalHex() &&
			!fpInfo.Slashed
	}, time.Minute, time.Second*5)
	// Query and assert finality provider has voting power
	s.Eventually(func() bool {
		height, err := s.cosmwasmController.QueryLatestBlockHeight()
		s.NoError(err)
		fpHasPower, err := s.cosmwasmController.QueryFinalityProviderHasPower(consumerFp.FinalityProvider.BtcPk.MustToBTCPK(), height)
		s.NoError(err)
		return fpHasPower
	}, time.Minute, time.Second*5)
}

func (s *BCDConsumerIntegrationTestSuite) Test09ConsumerFPFinalitySignature() {
	// Query consumer finality providers
	consumerFp, err := s.babylonController.QueryFinalityProvider(bbn.NewBIP340PubKeyFromBTCPK(consumerFpBTCPK).MarshalHex())
	s.Require().NoError(err)
	s.Require().NotNil(consumerFp)

	// Get the activated block height and block on the consumer chain
	consumerActivatedHeight, err := s.cosmwasmController.QueryActivatedHeight()
	s.NoError(err)
	consumerActivatedBlock, err := s.cosmwasmController.QueryIndexedBlock(consumerActivatedHeight)
	s.NoError(err)
	s.NotNil(consumerActivatedBlock)

	// Consumer finality provider submits finality signature for first activated
	// block to the consumer chain
	_, err = s.cosmwasmController.SubmitFinalitySig(
		consumerFpBTCSK,
		consumerFpBTCPK,
		randListInfo2.SRList[consumerActivatedHeight-1],
		&randListInfo2.PRList[consumerActivatedHeight-1],
		randListInfo2.ProofList[consumerActivatedHeight-1].ToProto(),
		consumerActivatedHeight,
	)
	s.NoError(err)
	s.T().Logf("Finality sig for height %d was submitted successfully", consumerActivatedHeight)

	// Ensure consumer finality provider's finality signature is received and stored in the smart contract
	s.Eventually(func() bool {
		fpSigsResponse, err := s.cosmwasmController.QueryFinalitySignature(consumerFp.FinalityProvider.BtcPk.MarshalHex(), consumerActivatedHeight)
		if err != nil {
			s.T().Logf("failed to query finality signature: %s", err.Error())
			return false
		}
		if fpSigsResponse == nil || fpSigsResponse.Signature == nil || len(fpSigsResponse.Signature) == 0 {
			return false
		}
		return true
	}, 30*time.Second, time.Second*5)

	// Once the vote is cast, ensure the block is finalised
	finalizedBlock, err := s.cosmwasmController.QueryIndexedBlock(consumerActivatedHeight)
	s.T().Logf("Finalized block: %v", finalizedBlock)
	s.NoError(err)
	s.NotEmpty(finalizedBlock)
	s.Equal(hex.EncodeToString(finalizedBlock.AppHash), hex.EncodeToString(consumerActivatedBlock.AppHash))
	s.True(finalizedBlock.Finalized)
}

func (s *BCDConsumerIntegrationTestSuite) Test10BsnFpRewards() {
	// Ensure BSN rewards are being gathered.
	// Initially sent to the finality contract, then sent to Babylon on an epoch boundary
	s.Eventually(func() bool {
		balance, err := s.cosmwasmController.QueryFinalityContractBalances()
		if err != nil {
			s.T().Logf("failed to query balance: %s", err.Error())
			return false
		}
		if len(balance) == 0 {
			return false
		}
		positiveBalance := false
		for _, b := range balance {
			denom := b.Denom
			s.T().Logf("Balance of denom '%s': %s", denom, b.Amount.String())
			// Check that the balance of the denom is greater than 0
			if b.Amount.IsPositive() {
				positiveBalance = true
			} else {
				s.T().Logf("balance of denom '%s' is not positive: %s", denom, b.Amount.String())
			}
		}
		return positiveBalance
	}, 30*time.Second, time.Second*5)

	// Wait for an reward_interval on the BSN. So, BSN height has to be a multiple of reward_interval
	s.T().Logf("Waiting for an epoch boundary on the BSN")
	// Get the reward interval from the consumer chain's finality contract config
	finalityConfig, err := s.cosmwasmController.QueryFinalityConfig()
	s.NoError(err)
	rewardInterval := finalityConfig.RewardInterval

	s.Eventually(func() bool {
		bsnHeight, err := s.cosmwasmController.QueryLatestBlockHeight()
		if err != nil {
			s.T().Logf("failed to query latest block height: %s", err.Error())
			return false
		}
		s.T().Logf("BSN height: %d", bsnHeight)
		if (bsnHeight % rewardInterval) == 0 {
			s.T().Logf("reached reward interval in Cosmos BSN")
			return true
		}
		return false
	}, 30*time.Second, time.Second*1)

	// Check they end up in Babylon on an epoch boundary
	// NOTE: The callback function in Babylon will redirect the reward from BTC staking
	// module to incentive module. Thus, although the IBC callback is in BTC staking module,
	// we will have to check the incentive module's balance.
	s.T().Logf("Checking if rewards have been sent to the Babylon '%s' module address", itypes.ModuleName)
	incentiveModuleAddr, err := bech32.ConvertAndEncode(babylonPrefix, authtypes.NewModuleAddress(itypes.ModuleName))
	s.NoError(err)
	s.T().Logf("Incentive module address: %s", incentiveModuleAddr)

	s.Eventually(func() bool {
		balance, err := s.babylonController.QueryBalances(incentiveModuleAddr)
		if err != nil {
			s.T().Logf("failed to query balance: %s", err.Error())
			return false
		}
		if len(balance) == 0 {
			s.T().Logf("no balance found")
			return false
		}
		ibcDenom := getFirstIBCDenom(balance)
		if ibcDenom == "" {
			s.T().Logf("failed to get IBC denom")
			return false
		}
		s.T().Logf("Balance of IBC denom '%s': %s", ibcDenom, balance.AmountOf(ibcDenom).String())
		// Check that the balance of the IBC denom is greater than 0
		return balance.AmountOf(ibcDenom).IsPositive()
	}, time.Minute, time.Second*5)
}

// Test11BabylonFPCascadedSlashing
// 1. Submits a Babylon FP valid finality sig to Babylon.
// 2. The block is finalized.
// 3. Equivocates/ Submits an invalid finality sig to Babylon.
// 4. Babylon FP is slashed.
// 5. Babylon notifies the involved consumer about the delegations.
// 6. Consumer discounts the voting power of other involved consumer FP's in the affected delegations
func (s *BCDConsumerIntegrationTestSuite) Test11BabylonFPCascadedSlashing() {
	// Finalize the next epoch, so that the babylon chain finality is activated
	s.finalizeNextEpoch()

	// Get the last finalized epoch
	lastFinalizedEpoch := s.getLastFinalizedEpoch()
	// get the first non-finalized height
	firstNonFinalizedHeight := lastFinalizedEpoch.FirstBlockHeight + lastFinalizedEpoch.CurrentEpochInterval

	// get the block at the activated height
	firstNonFinalizedBlock, err := s.babylonController.QueryCometBlock(firstNonFinalizedHeight)
	s.NoError(err)
	s.NotNil(firstNonFinalizedBlock)

	// Get the babylon finality provider
	babylonFp, err := s.babylonController.QueryFinalityProviders("")
	s.NoError(err)
	s.NotNil(babylonFp)

	babylonFpBIP340PK := bbn.NewBIP340PubKeyFromBTCPK(babylonFpBTCPK)
	randIdx := firstNonFinalizedHeight - 1 // pub rand was committed from height 1-1000

	// submit finality signature
	signingCtx := signingcontext.FpFinVoteContextV0(babylonChainID, appparams.AccFinality.String())
	txResp, err := s.babylonController.SubmitFinalitySignature(
		babylonFpBTCSK,
		babylonFpBIP340PK,
		randListInfo1.SRList[randIdx],
		&randListInfo1.PRList[randIdx],
		randListInfo1.ProofList[randIdx].ToProto(),
		signingCtx,
		firstNonFinalizedHeight)
	s.NoError(err)
	s.NotNil(txResp)

	// ensure the vote is eventually cast
	var votes []bbn.BIP340PubKey
	s.Eventually(func() bool {
		votes, err = s.babylonController.QueryVotesAtHeight(firstNonFinalizedHeight)
		if err != nil {
			s.T().Logf("Error querying votes: %v", err)
			return false
		}
		return len(votes) > 0
	}, time.Minute, time.Second*5)
	s.Equal(1, len(votes))
	s.Equal(votes[0].MarshalHex(), babylonFpBIP340PK.MarshalHex())

	// equivocate by submitting invalid finality signature
	_, err = s.babylonController.SubmitInvalidFinalitySignature(
		r,
		babylonFpBTCSK,
		babylonFpBIP340PK,
		randListInfo1.SRList[randIdx],
		&randListInfo1.PRList[randIdx],
		randListInfo1.ProofList[randIdx].ToProto(),
		signingCtx,
		firstNonFinalizedHeight,
	)
	s.NoError(err)

	// check the babylon finality provider is slashed
	babylonFpBIP340PKHex := bbn.NewBIP340PubKeyFromBTCPK(babylonFpBTCPK).MarshalHex()
	s.Eventually(func() bool {
		fp, err := s.babylonController.QueryFinalityProvider(babylonFpBIP340PKHex)
		if err != nil {
			s.T().Logf("Error querying finality provider: %v", err)
			return false
		}
		return fp != nil &&
			fp.FinalityProvider.SlashedBtcHeight > 0
	}, time.Minute, time.Second*5)

	// TODO: skip the following checks because current e2e suite does not have
	// vigilante to relay slashing tx to allow Babylon Genesis to relay unbond_del
	// events.
	// // query consumer finality provider
	// consumerFp, err := s.babylonController.QueryFinalityProvider(bbn.NewBIP340PubKeyFromBTCPK(consumerFpBTCPK).MarshalHex())
	// s.Require().NoError(err)
	// s.Require().NotNil(consumerFp)
	//
	// // query and assert finality provider has zero voting power
	// s.Eventually(func() bool {
	// 	height, err := s.cosmwasmController.QueryLatestBlockHeight()
	// 	s.NoError(err)
	// 	fpHasPower, err := s.cosmwasmController.QueryFinalityProviderHasPower(consumerFp.FinalityProvider.BtcPk.MustToBTCPK(), height)
	// 	s.NoError(err)
	// 	return !fpHasPower
	// }, time.Minute, time.Second*5)
}

func (s *BCDConsumerIntegrationTestSuite) Test12ConsumerFPCascadedSlashing() {
	// create a new consumer finality provider
	resp, consumerFpBTCSK2, consumerFpBTCPK2 := s.createVerifyConsumerFP()
	consumerFp, err := s.babylonController.QueryFinalityProvider(resp.BtcPk.MarshalHex())
	s.NoError(err)

	// register a babylon finality provider
	babylonFp := s.createVerifyBabylonFP(babylonFpBTCSK2)

	// create a new delegation and multi-stake to both Babylon and consumer finality provider
	// NOTE: this will create delegation in pending state as covenant sigs are not provided
	_, stakingTxHash := s.createBabylonDelegation(babylonFp, consumerFp.FinalityProvider, uint16(10000))

	// check delegation
	delegation, err := s.babylonController.QueryBTCDelegation(stakingTxHash)
	s.Require().NoError(err)
	s.NotNil(delegation)

	// activate the delegation by submitting covenant sigs
	s.submitCovenantSigs(consumerFp.FinalityProvider)

	// query the staking contract for delegations on the consumer chain
	var dataFromContract *cosmwasm.ConsumerDelegationsResponse
	s.Eventually(func() bool {
		dataFromContract, err = s.cosmwasmController.QueryDelegations()
		return err == nil && dataFromContract != nil && len(dataFromContract.Delegations) == 2
	}, time.Second*30, time.Second)

	// get the latest block height and block on the consumer chain
	consumerNodeStatus, err := s.cosmwasmController.GetCometNodeStatus()
	s.NoError(err)
	consumerLatestBlockHeight := uint64(consumerNodeStatus.SyncInfo.LatestBlockHeight)

	// commit public randomness at the latest block height on the consumer chain
	randListInfo, msgCommitPubRandList, err := datagen.GenRandomMsgCommitPubRandList(r, consumerFpBTCSK2, s.cosmwasmController.GetFpRandCommitContext(), consumerLatestBlockHeight, 200)
	s.NoError(err)

	txResp, err := s.cosmwasmController.CommitPubRandList(consumerFpBTCPK2, consumerLatestBlockHeight, 200, randListInfo.Commitment, msgCommitPubRandList.Sig.MustToBTCSig())
	s.NoError(err)
	s.NotNil(txResp)

	// finalize the consumer chain until the latest block height
	s.finalizeUntilConsumerHeight(consumerLatestBlockHeight)

	// query and assert consumer finality provider has voting power
	s.Eventually(func() bool {
		height, err := s.cosmwasmController.QueryLatestBlockHeight()
		s.NoError(err)
		fpHasPower, err := s.cosmwasmController.QueryFinalityProviderHasPower(consumerFp.FinalityProvider.BtcPk.MustToBTCPK(), height)
		s.NoError(err)
		return fpHasPower
	}, time.Minute, time.Second*5)

	// get the latest block height and block on the consumer chain
	consumerNodeStatus, err = s.cosmwasmController.GetCometNodeStatus()
	s.NoError(err)
	consumerLatestBlockHeight2 := uint64(consumerNodeStatus.SyncInfo.LatestBlockHeight)

	// Consumer finality provider submits finality signature
	idx := consumerLatestBlockHeight2 - consumerLatestBlockHeight
	_, err = s.cosmwasmController.SubmitFinalitySig(
		consumerFpBTCSK2,
		consumerFpBTCPK2,
		randListInfo.SRList[idx],
		&randListInfo.PRList[idx],
		randListInfo.ProofList[idx].ToProto(),
		consumerLatestBlockHeight2,
	)
	s.NoError(err)
	s.T().Logf("Finality sig for height %d was submitted successfully", consumerLatestBlockHeight)

	// ensure consumer finality provider's finality signature is received and stored in the smart contract
	s.Eventually(func() bool {
		fpSigsResponse, err := s.cosmwasmController.QueryFinalitySignature(consumerFp.FinalityProvider.BtcPk.MarshalHex(), consumerLatestBlockHeight2)
		if err != nil {
			s.T().Logf("failed to query finality signature: %s", err.Error())
			return false
		}
		if fpSigsResponse == nil || fpSigsResponse.Signature == nil || len(fpSigsResponse.Signature) == 0 {
			return false
		}
		return true
	}, time.Minute, time.Second*5)

	// consumer finality provider submits invalid finality signature
	txResp, err = s.cosmwasmController.SubmitInvalidFinalitySig(
		r,
		consumerFpBTCSK2,
		consumerFpBTCPK2,
		randListInfo.SRList[idx],
		&randListInfo.PRList[idx],
		randListInfo.ProofList[idx].ToProto(),
		consumerLatestBlockHeight2,
	)
	s.NoError(err)
	s.NotNil(txResp)

	// ensure consumer finality provider is slashed
	s.Eventually(func() bool {
		fp, err := s.cosmwasmController.QueryFinalityProvider(consumerFp.FinalityProvider.BtcPk.MarshalHex())
		if err != nil || fp == nil || fp.SlashedHeight == 0 {
			return false
		}
		fpInfo, err := s.cosmwasmController.QueryFinalityProviderInfo(consumerFp.FinalityProvider.BtcPk.MustToBTCPK())
		if err != nil {
			s.T().Logf("Error querying finality providers by power: %v", err)
			return false
		}

		return fpInfo != nil &&
			fpInfo.BtcPkHex == consumerFp.FinalityProvider.BtcPk.MarshalHex() &&
			fpInfo.Slashed
	}, time.Minute, time.Second*5)
	// query and assert consumer finality provider has zero voting power
	s.Eventually(func() bool {
		height, err := s.cosmwasmController.QueryLatestBlockHeight()
		s.NoError(err)
		fpHasPower, err := s.cosmwasmController.QueryFinalityProviderHasPower(consumerFp.FinalityProvider.BtcPk.MustToBTCPK(), height)
		s.NoError(err)
		return !fpHasPower
	}, time.Minute, time.Second*5)

	// check the babylon finality provider's voting power is discounted (cascaded slashing)
	babylonFpBIP340PKHex := bbn.NewBIP340PubKeyFromBTCPK(babylonFpBTCPK2).MarshalHex()
	s.Eventually(func() bool {
		fp, err := s.babylonController.QueryFinalityProvider(babylonFpBIP340PKHex)
		if err != nil {
			s.T().Logf("Error querying finality provider: %v", err)
			return false
		}
		return fp != nil &&
			fp.FinalityProvider.SlashedBtcHeight == 0 // should not be slashed
	}, time.Minute, time.Second*5)

	// check consumer FP record in Babylon is updated
	consumerFpBIP340PKHex := consumerFp.FinalityProvider.BtcPk.MarshalHex()
	s.Eventually(func() bool {
		fp, err := s.babylonController.QueryFinalityProvider(consumerFpBIP340PKHex)
		if err != nil {
			s.T().Logf("Error querying finality provider: %v", err)
			return false
		}
		if fp == nil {
			s.T().Logf("Finality provider is nil")
			return false
		}
		if fp.FinalityProvider.SlashedBtcHeight == 0 || fp.FinalityProvider.SlashedBabylonHeight == 0 {
			s.T().Logf("Finality provider not slashed yet, SlashedBtcHeight: %d, SlashedBabylonHeight: %d", fp.FinalityProvider.SlashedBtcHeight, fp.FinalityProvider.SlashedBabylonHeight)
			return false
		}
		return true // should be recorded slashed
	}, time.Minute, time.Second*5)
}

// Test13ConsumerDelegationExpiry tests the automatic expiration of BTC delegations
// when the BTC height reaches end_height - unbonding_time (fixed behavior).
// 1. Creates a delegation with a specific timelock
// 2. Activates the delegation and verifies FP has voting power
// 3. Inserts BTC headers to reach end_height - unbonding_time
// 4. Verifies the delegation expires at the CORRECT height (not at end_height)
func (s *BCDConsumerIntegrationTestSuite) Test13ConsumerDelegationExpiry() {
	s.T().Log("Testing natural delegation expiry at end_height - unbonding_time")

	// create a new consumer finality provider
	resp, _, _ := s.createVerifyConsumerFP()
	consumerFp, err := s.babylonController.QueryFinalityProvider(resp.BtcPk.MarshalHex())
	s.NoError(err)

	// register a babylon finality provider
	babylonFpBTCSK3, babylonFpBTCPK3, _ := datagen.GenRandomBTCKeyPair(r)
	babylonFp := s.createVerifyBabylonFP(babylonFpBTCSK3)

	// commit and finalize pub rand so Babylon FP has voting power
	currentHeight, err := s.babylonController.GetCurrentHeight()
	s.NoError(err)
	s.commitAndFinalizePubRand(babylonFpBTCSK3, babylonFpBTCPK3, uint64(currentHeight))

	// Get current BTC height to calculate proper expiry
	currentBtcTipResp, err := s.babylonController.QueryBtcLightClientTip()
	s.NoError(err)
	currentBtcHeight := currentBtcTipResp.Height
	s.T().Logf("Current BTC height: %d", currentBtcHeight)

	// create a new delegation and multi-stake to both Babylon and consumer finality provider
	// NOTE: this will create delegation in pending state as covenant sigs are not provided
	stakingTimeBlocks := uint16(15) // Use 15 blocks for clearer testing
	_, stakingTxHash := s.createBabylonDelegation(babylonFp, consumerFp.FinalityProvider, stakingTimeBlocks)

	// check delegation
	delegation, err := s.babylonController.QueryBTCDelegation(stakingTxHash)
	s.Require().NoError(err)
	s.NotNil(delegation)

	// Log delegation parameters for debugging
	s.T().Logf("Delegation created: start_height=%d, end_height=%d, unbonding_time=%d",
		delegation.StartHeight, delegation.EndHeight, delegation.UnbondingTime)

	// Calculate expected expiry height: end_height - unbonding_time
	expectedExpiryHeight := delegation.EndHeight - delegation.UnbondingTime
	s.T().Logf("Expected expiry at BTC height: %d (end_height %d - unbonding_time %d)",
		expectedExpiryHeight, delegation.EndHeight, delegation.UnbondingTime)

	// activate the delegation by submitting covenant sigs
	s.submitCovenantSigs(consumerFp.FinalityProvider)

	// query the staking contract for delegations on the consumer chain
	var dataFromContract *cosmwasm.ConsumerDelegationsResponse
	s.Eventually(func() bool {
		dataFromContract, err = s.cosmwasmController.QueryDelegations()
		return err == nil && dataFromContract != nil
	}, time.Second*30, time.Second)

	// query and assert consumer finality provider's total stake is active initially
	s.Eventually(func() bool {
		fpInfo, err := s.cosmwasmController.QueryFinalityProviderInfo(consumerFp.FinalityProvider.BtcPk.MustToBTCPK())
		if err != nil {
			s.T().Logf("Error querying finality provider info: %v", err)
			return false
		}
		return fpInfo != nil &&
			fpInfo.TotalActiveSats == delegation.TotalSat &&
			fpInfo.BtcPkHex == consumerFp.FinalityProvider.BtcPk.MarshalHex() &&
			!fpInfo.Slashed
	}, time.Minute, time.Second*5)

	s.T().Logf("✅ Delegation is active before expiry")

	// Insert BTC headers to reach the expected expiry height (end_height - unbonding_time)
	// We need to be careful to insert exactly the right number of headers
	headersToInsert := int(expectedExpiryHeight - currentBtcHeight)
	s.T().Logf("Inserting %d BTC headers to reach expiry height %d", headersToInsert, expectedExpiryHeight)

	for i := 0; i < headersToInsert; i++ {
		_, err := s.babylonController.InsertNewEmptyBtcHeader(r)
		s.Require().NoError(err)
	}

	// Verify the delegation expires at the CORRECT height (end_height - unbonding_time)
	s.Eventually(func() bool {
		fpInfo, err := s.cosmwasmController.QueryFinalityProviderInfo(consumerFp.FinalityProvider.BtcPk.MustToBTCPK())
		if err != nil {
			s.T().Logf("Error querying finality provider info: %v", err)
			return false
		}

		// Check current BTC height
		currentBtcTipResp, err := s.babylonController.QueryBtcLightClientTip()
		if err == nil {
			s.T().Logf("Current BTC height: %d, TotalActiveSats: %d",
				currentBtcTipResp.Height, fpInfo.TotalActiveSats)
		}

		return fpInfo != nil &&
			fpInfo.TotalActiveSats == 0 &&
			fpInfo.BtcPkHex == consumerFp.FinalityProvider.BtcPk.MarshalHex() &&
			!fpInfo.Slashed
	}, time.Minute, time.Second*5)

	s.T().Logf("✅ Delegation expired at the correct height: end_height - unbonding_time = %d - %d = %d",
		delegation.EndHeight, delegation.UnbondingTime, expectedExpiryHeight)
}

// helper function: submitCovenantSigs submits the covenant signatures to activate the BTC delegation
func (s *BCDConsumerIntegrationTestSuite) submitCovenantSigs(consumerFp *bstypes.FinalityProviderResponse) {
	cvSK, _, _, err := getDeterministicCovenantKey()
	s.NoError(err)

	// check consumer finality provider delegation
	pendingDelsSet, err := s.babylonController.QueryFinalityProviderDelegations(consumerFp.BtcPk.MarshalHex(), 1)
	s.Require().NoError(err)
	s.Len(pendingDelsSet, 1)
	pendingDels := pendingDelsSet[0]
	s.Len(pendingDels.Dels, 1)
	pendingDelResp := pendingDels.Dels[0]
	pendingDel, err := ParseRespBTCDelToBTCDel(pendingDelResp)
	s.NoError(err)
	s.Len(pendingDel.CovenantSigs, 0)

	slashingTx := pendingDel.SlashingTx
	stakingTx := pendingDel.StakingTx

	stakingMsgTx, err := bbn.NewBTCTxFromBytes(stakingTx)
	s.NoError(err)
	stakingTxHash := stakingMsgTx.TxHash().String()

	params, err := s.babylonController.QueryBTCStakingParams()
	s.NoError(err)

	fpBTCPKs, err := bbn.NewBTCPKsFromBIP340PKs(pendingDel.FpBtcPkList)
	s.NoError(err)

	stakingInfo, err := pendingDel.GetStakingInfo(params, net)
	s.NoError(err)

	stakingSlashingPathInfo, err := stakingInfo.SlashingPathSpendInfo()
	s.NoError(err)

	/*
		generate and insert new covenant signature, in order to activate the BTC delegation
	*/
	// covenant signatures on slashing tx
	covenantSlashingSigs, err := datagen.GenCovenantAdaptorSigs(
		[]*btcec.PrivateKey{cvSK},
		fpBTCPKs,
		stakingMsgTx,
		stakingSlashingPathInfo.GetPkScriptPath(),
		slashingTx,
	)
	s.NoError(err)

	// cov Schnorr sigs on unbonding signature
	unbondingPathInfo, err := stakingInfo.UnbondingPathSpendInfo()
	s.NoError(err)
	unbondingTx, err := bbn.NewBTCTxFromBytes(pendingDel.BtcUndelegation.UnbondingTx)
	s.NoError(err)

	covUnbondingSigs, err := datagen.GenCovenantUnbondingSigs(
		[]*btcec.PrivateKey{cvSK},
		stakingMsgTx,
		pendingDel.StakingOutputIdx,
		unbondingPathInfo.GetPkScriptPath(),
		unbondingTx,
	)
	s.NoError(err)

	unbondingInfo, err := pendingDel.GetUnbondingInfo(params, net)
	s.NoError(err)
	unbondingSlashingPathInfo, err := unbondingInfo.SlashingPathSpendInfo()
	s.NoError(err)
	covenantUnbondingSlashingSigs, err := datagen.GenCovenantAdaptorSigs(
		[]*btcec.PrivateKey{cvSK},
		fpBTCPKs,
		unbondingTx,
		unbondingSlashingPathInfo.GetPkScriptPath(),
		pendingDel.BtcUndelegation.SlashingTx,
	)
	s.NoError(err)

	covPk, err := covenantSlashingSigs[0].CovPk.ToBTCPK()
	s.NoError(err)

	for i := 0; i < int(params.CovenantQuorum); i++ {
		tx, err := s.babylonController.SubmitCovenantSigs(
			covPk,
			stakingTxHash,
			covenantSlashingSigs[i].AdaptorSigs,
			covUnbondingSigs[i],
			covenantUnbondingSlashingSigs[i].AdaptorSigs,
		)
		s.Require().NoError(err)
		s.Require().NotNil(tx)
	}

	// ensure the BTC delegation has covenant sigs and is active now
	s.Eventually(func() bool {
		activeDelsSet, err := s.babylonController.QueryFinalityProviderDelegations(consumerFp.BtcPk.MarshalHex(), 1)
		s.NoError(err)
		if len(activeDelsSet) != 1 {
			return false
		}
		if len(activeDelsSet[0].Dels) != 1 {
			return false
		}
		if !activeDelsSet[0].Dels[0].Active {
			return false
		}

		activeDels, err := ParseRespsBTCDelToBTCDel(activeDelsSet[0])
		s.NoError(err)
		s.NotNil(activeDels)
		if len(activeDels.Dels) != 1 {
			return false
		}
		if !activeDels.Dels[0].HasCovenantQuorums(1, 1) {
			return false
		}
		return true
	}, time.Minute, time.Second*5, "BTC staking was not activated within the expected time")

	// ensure BTC staking is activated
	s.Eventually(func() bool {
		activatedHeight, err := s.babylonController.QueryActivatedHeight()
		if err != nil {
			s.T().Logf("Error querying activated height: %v", err)
			return false
		}
		return activatedHeight != nil && activatedHeight.Height > 0
	}, 90*time.Second, time.Second*5)
}

// helper function: createBabylonDelegation creates a random BTC delegation multi-staking to Babylon and consumer finality providers
func (s *BCDConsumerIntegrationTestSuite) createBabylonDelegation(babylonFp *bstypes.FinalityProviderResponse, consumerFp *bstypes.FinalityProviderResponse, stakingTimeBlocks uint16) (*btcec.PublicKey, string) {
	delBabylonAddr, err := sdk.AccAddressFromBech32(s.babylonController.MustGetTxSigner())
	s.NoError(err)
	// BTC staking params, BTC delegation key pairs and PoP
	params, err := s.babylonController.QueryStakingParams()
	s.Require().NoError(err)

	// minimal required unbonding time
	unbondingTime := uint16(params.MinUnbondingTime)

	// NOTE: we use the node's secret key as Babylon secret key for the BTC delegation
	sc := signingcontext.StakerPopContextV0(babylonChainID, appparams.AccBTCStaking.String())
	pop, err := datagen.NewPoPBTC(sc, delBabylonAddr, consumerDelBtcSk)
	s.NoError(err)
	// generate staking tx and slashing tx
	testStakingInfo := datagen.GenBTCStakingSlashingInfo(
		r,
		s.T(),
		&chaincfg.RegressionNetParams,
		consumerDelBtcSk,
		[]*btcec.PublicKey{babylonFp.BtcPk.MustToBTCPK(), consumerFp.BtcPk.MustToBTCPK()},
		params.CovenantPks,
		params.CovenantQuorum,
		stakingTimeBlocks,
		stakingValue,
		params.SlashingPkScript,
		params.SlashingRate,
		unbondingTime,
	)

	stakingMsgTx := testStakingInfo.StakingTx
	stakingTxBytes, err := bbn.SerializeBTCTx(stakingMsgTx)
	s.NoError(err)
	stakingTxHash := stakingMsgTx.TxHash().String()
	stakingSlashingPathInfo, err := testStakingInfo.StakingInfo.SlashingPathSpendInfo()
	s.NoError(err)

	// generate proper delegator sig
	delegatorSig, err := testStakingInfo.SlashingTx.Sign(
		stakingMsgTx,
		datagen.StakingOutIdx,
		stakingSlashingPathInfo.GetPkScriptPath(),
		consumerDelBtcSk,
	)
	s.NoError(err)

	// create and insert BTC headers which include the staking tx to get staking tx info
	btcTipHeaderResp, err := s.babylonController.QueryBtcLightClientTip()
	s.NoError(err)
	tipHeader, err := bbn.NewBTCHeaderBytesFromHex(btcTipHeaderResp.HeaderHex)
	s.NoError(err)
	blockWithStakingTx := datagen.CreateBlockWithTransaction(r, tipHeader.ToBlockHeader(), testStakingInfo.StakingTx)
	accumulatedWork := btclctypes.CalcWork(&blockWithStakingTx.HeaderBytes)
	accumulatedWork = btclctypes.CumulativeWork(accumulatedWork, btcTipHeaderResp.Work)
	parentBlockHeaderInfo := &btclctypes.BTCHeaderInfo{
		Header: &blockWithStakingTx.HeaderBytes,
		Hash:   blockWithStakingTx.HeaderBytes.Hash(),
		Height: btcTipHeaderResp.Height + 1,
		Work:   &accumulatedWork,
	}
	headers := make([]bbn.BTCHeaderBytes, 0)
	headers = append(headers, blockWithStakingTx.HeaderBytes)
	for i := 0; i < int(params.ConfirmationTimeBlocks); i++ {
		headerInfo := datagen.GenRandomValidBTCHeaderInfoWithParent(r, *parentBlockHeaderInfo)
		headers = append(headers, *headerInfo.Header)
		parentBlockHeaderInfo = headerInfo
	}
	_, err = s.babylonController.InsertBtcBlockHeaders(headers)
	s.NoError(err)
	inclusionProof := bstypes.NewInclusionProofFromSpvProof(blockWithStakingTx.SpvProof)

	// generate BTC undelegation stuff
	stkTxHash := testStakingInfo.StakingTx.TxHash()
	unbondingValue := stakingValue - datagen.UnbondingTxFee // TODO: parameterise fee
	testUnbondingInfo := datagen.GenBTCUnbondingSlashingInfo(
		r,
		s.T(),
		&chaincfg.RegressionNetParams,
		consumerDelBtcSk,
		[]*btcec.PublicKey{babylonFp.BtcPk.MustToBTCPK(), consumerFp.BtcPk.MustToBTCPK()},
		params.CovenantPks,
		params.CovenantQuorum,
		wire.NewOutPoint(&stkTxHash, datagen.StakingOutIdx),
		stakingTimeBlocks,
		unbondingValue,
		params.SlashingPkScript,
		params.SlashingRate,
		unbondingTime,
	)
	delUnbondingSlashingSig, err := testUnbondingInfo.GenDelSlashingTxSig(consumerDelBtcSk)
	s.NoError(err)

	// submit the message for creating BTC delegation
	delBTCPK := *bbn.NewBIP340PubKeyFromBTCPK(consumerDelBtcPk)

	serializedUnbondingTx, err := bbn.SerializeBTCTx(testUnbondingInfo.UnbondingTx)
	s.NoError(err)

	// submit the BTC delegation to Babylon
	_, err = s.babylonController.CreateBTCDelegation(
		&delBTCPK,
		[]*btcec.PublicKey{babylonFp.BtcPk.MustToBTCPK(), consumerFp.BtcPk.MustToBTCPK()},
		pop,
		uint32(stakingTimeBlocks),
		stakingValue,
		stakingTxBytes,
		inclusionProof,
		testStakingInfo.SlashingTx,
		delegatorSig,
		serializedUnbondingTx,
		uint32(unbondingTime),
		unbondingValue,
		testUnbondingInfo.SlashingTx,
		delUnbondingSlashingSig,
	)
	s.NoError(err)

	return consumerDelBtcPk, stakingTxHash
}

// helper function: createVerifyBabylonFP creates a random Babylon finality provider and verifies it
func (s *BCDConsumerIntegrationTestSuite) createVerifyBabylonFP(babylonFpBTCSK *btcec.PrivateKey) *bstypes.FinalityProviderResponse {
	// NOTE: we use the node's secret key as Babylon secret key for the finality provider
	// babylonFpBTCSK, _, _ := datagen.GenRandomBTCKeyPair(r)
	sdk.SetAddrCacheEnabled(false)
	bbnparams.SetAddressPrefixes()
	fpBabylonAddr, err := sdk.AccAddressFromBech32(s.babylonController.MustGetTxSigner())
	s.NoError(err)

	sc := signingcontext.FpPopContextV0(babylonChainID, appparams.AccBTCStaking.String())
	babylonFp, err := datagen.GenCustomFinalityProvider(r, babylonFpBTCSK, sc, fpBabylonAddr, babylonChainID)

	s.NoError(err)
	babylonFp.Commission = &minCommissionRate
	bbnFpPop, err := babylonFp.Pop.Marshal()
	s.NoError(err)
	bbnDescription, err := babylonFp.Description.Marshal()
	s.NoError(err)

	_, err = s.babylonController.RegisterFinalityProvider(
		babylonChainID,
		babylonFp.BtcPk,
		bbnFpPop,
		babylonFp.Commission,
		bbnDescription,
	)
	s.NoError(err)

	actualFp, err := s.babylonController.QueryFinalityProvider(babylonFp.BtcPk.MarshalHex())
	s.NoError(err)
	s.Equal(babylonFp.Description, actualFp.FinalityProvider.Description)
	s.Equal(babylonFp.Commission, actualFp.FinalityProvider.Commission)
	s.Equal(babylonFp.BtcPk, actualFp.FinalityProvider.BtcPk)
	s.Equal(babylonFp.Pop, actualFp.FinalityProvider.Pop)
	s.Equal(babylonFp.SlashedBabylonHeight, actualFp.FinalityProvider.SlashedBabylonHeight)
	s.Equal(babylonFp.SlashedBtcHeight, actualFp.FinalityProvider.SlashedBtcHeight)
	return actualFp.FinalityProvider
}

// helper function: commitAndFinalizePubRand commits public randomness at the given start height and finalizes it
func (s *BCDConsumerIntegrationTestSuite) commitAndFinalizePubRand(babylonFpBTCSK *btcec.PrivateKey, babylonFpBTCPK *btcec.PublicKey, commitStartHeight uint64) *datagen.RandListInfo {
	// commit public randomness list
	numPubRand := uint64(1000)

	sc := signingcontext.FpRandCommitContextV0(babylonChainID, appparams.AccFinality.String())
	randList, msgCommitPubRandList, err := datagen.GenRandomMsgCommitPubRandList(r, babylonFpBTCSK, sc, commitStartHeight, numPubRand)
	s.NoError(err)

	_, err = s.babylonController.CommitPublicRandomness(msgCommitPubRandList)
	s.NoError(err)

	pubRandCommitMap, err := s.babylonController.QueryLastCommittedPublicRand(babylonFpBTCPK, commitStartHeight)
	s.NoError(err)
	s.Len(pubRandCommitMap, 1)

	var firstPubRandCommit *ftypes.PubRandCommitResponse
	for _, commit := range pubRandCommitMap {
		firstPubRandCommit = commit
		break
	}

	commitEpoch := firstPubRandCommit.EpochNum
	// finalise until the epoch of the first public randomness commit
	s.finalizeUntilEpoch(commitEpoch, true)
	return randList
}

// helper function: createVerifyConsumerFP creates a random consumer finality provider on Babylon
// and verifies its existence.
func (s *BCDConsumerIntegrationTestSuite) createVerifyConsumerFP() (*bstypes.FinalityProvider, *btcec.PrivateKey, *btcec.PublicKey) {
	/*
		create a random consumer finality provider on Babylon
	*/
	// NOTE: we use the node's secret key as Babylon secret key for the finality provider
	consumerFpBTCSecretKey, consumerFpBTCPublicKey, _ := datagen.GenRandomBTCKeyPair(r)
	sdk.SetAddrCacheEnabled(false)
	bbnparams.SetAddressPrefixes()
	fpBabylonAddr, err := sdk.AccAddressFromBech32(s.babylonController.MustGetTxSigner())
	s.NoError(err)

	sc := signingcontext.FpPopContextV0(babylonChainID, appparams.AccBTCStaking.String())
	consumerFp, err := datagen.GenCustomFinalityProvider(r, consumerFpBTCSecretKey, sc, fpBabylonAddr, s.consumerID)
	s.NoError(err)
	consumerFp.Commission = &minCommissionRate
	consumerFpPop, err := consumerFp.Pop.Marshal()
	s.NoError(err)
	consumerDescription, err := consumerFp.Description.Marshal()
	s.NoError(err)

	_, err = s.babylonController.RegisterFinalityProvider(
		s.consumerID,
		consumerFp.BtcPk,
		consumerFpPop,
		consumerFp.Commission,
		consumerDescription,
	)
	s.NoError(err)

	// query the existence of finality provider and assert equivalence
	actualFpResp, err := s.babylonController.QueryFinalityProvider(consumerFp.BtcPk.MarshalHex())
	s.NoError(err)
	s.NotNil(actualFpResp)
	actualFp := actualFpResp.FinalityProvider
	s.Equal(consumerFp.Description, actualFp.Description)
	s.Equal(consumerFp.Commission.String(), actualFp.Commission.String())
	s.Equal(consumerFp.BtcPk, actualFp.BtcPk)
	s.Equal(consumerFp.Pop, actualFp.Pop)
	s.Equal(consumerFp.SlashedBabylonHeight, actualFp.SlashedBabylonHeight)
	s.Equal(consumerFp.SlashedBtcHeight, actualFp.SlashedBtcHeight)
	s.Equal(s.consumerID, actualFp.BsnId)
	return consumerFp, consumerFpBTCSecretKey, consumerFpBTCPublicKey
}

// helper function: initBabylonController initializes the Babylon controller with the default configuration.
func (s *BCDConsumerIntegrationTestSuite) initBabylonController() error {
	cfg := config.DefaultBabylonConfig()
	cfg.BlockTimeout = 10 * time.Minute
	btcParams := &chaincfg.RegressionNetParams // or whichever network you're using
	logger, _ := zap.NewDevelopment()

	// Get the current working directory
	currentDir, err := os.Getwd()
	if err != nil {
		s.T().Fatalf("Failed to get current working directory: %v", err)
	}

	// Construct the path to the Makefile directory
	cfg.KeyDirectory = filepath.Join(currentDir, "../../contrib/images/ibcsim-bcd/.testnets/node0/babylond")
	cfg.GasPrices = "0.02ubbn"
	cfg.GasAdjustment = 20

	sdk.SetAddrCacheEnabled(false)
	bbnparams.SetAddressPrefixes()
	controller, err := babylon.NewBabylonController(&cfg, btcParams, logger)
	if err != nil {
		return err
	}

	s.babylonController = controller
	return nil
}

// helper function: initCosmwasmController initializes the Cosmwasm controller with the default configuration.
func (s *BCDConsumerIntegrationTestSuite) initCosmwasmController() error {
	cfg := cwconfig.DefaultCosmwasmConfig()

	// Get the current working directory
	currentDir, err := os.Getwd()
	if err != nil {
		s.T().Fatalf("Failed to get current working directory: %v", err)
	}

	cfg.ChainID = "bcd-test"
	cfg.KeyDirectory = filepath.Join(currentDir, "../../contrib/images/ibcsim-bcd/.testnets/bcd/bcd-test")
	cfg.AccountPrefix = "bbnc"

	// Use "user" key which is guaranteed to have funds from setup script
	// Both "validator" and "user" keys should have 100B stake tokens, but "user" is more reliably funded
	cfg.Key = "validator"

	// Set appropriate gas prices for the consumer chain
	// The consumer chain uses "stake" as the native denom, not "ustake"
	cfg.GasPrices = "0.002stake"

	// Increase gas adjustment for governance operations which require more gas
	// Default 1.3 is often insufficient for governance voting
	cfg.GasAdjustment = 2.0

	// Set maximum gas amount for governance operations
	// Governance proposals and voting can require significant gas
	cfg.MaxGasAmount = 20000000 // 10M gas units should be sufficient for governance operations

	// Create a logger
	logger, _ := zap.NewDevelopment()

	sdk.SetAddrCacheEnabled(false)

	// Set consumer chain address prefixes (hardcoded)
	sdkConfig := sdk.GetConfig()
	sdkConfig.SetBech32PrefixForAccount(consumerBech32PrefixAccAddr, consumerBech32PrefixAccPub)
	sdkConfig.SetBech32PrefixForValidator(consumerBech32PrefixValAddr, consumerBech32PrefixValPub)
	sdkConfig.SetBech32PrefixForConsensusNode(consumerBech32PrefixConsAddr, consumerBech32PrefixConsPub)

	// Create minimal encoding config for tests (without full app dependency)
	encodingCfg := createTestEncodingConfig()

	wcc, err := cosmwasm.NewCosmwasmConsumerController(cfg, encodingCfg, logger)
	require.NoError(s.T(), err)

	s.cosmwasmController = wcc
	return nil
}

// executeBCDCommand executes a command in the BCD container
func (s *BCDConsumerIntegrationTestSuite) executeBCDCommand(args ...string) (string, error) {
	// Prepare the docker exec command
	dockerArgs := append([]string{"exec", "ibcsim-bcd", "bcd"}, args...)

	cmd := exec.Command("docker", dockerArgs...)
	output, err := cmd.CombinedOutput()
	if err != nil {
		return "", fmt.Errorf("failed to execute BCD command: %v, output: %s", err, string(output))
	}

	return strings.TrimSpace(string(output)), nil
}

// executeContractViaDockerExec executes a CosmWasm contract using docker exec
func (s *BCDConsumerIntegrationTestSuite) executeContractViaDockerExec(contractAddr, execMsg string) (string, error) {
	// Execute the contract via docker exec
	s.T().Logf("🔗 Executing contract %s with message: %s", contractAddr, execMsg)
	
	txOutput, err := s.executeBCDCommand(
		"tx", "wasm", "execute", contractAddr, execMsg,
		"--keyring-backend", "test",
		"--home", "/data/bcd/bcd-test",
		"--from", "validator",
		"--chain-id", "bcd-test", 
		"--node", "http://localhost:26657",
		"--gas", "auto",
		"--gas-adjustment", "1.5",
		"--fees", "1000ustake",
		"--yes",
		"--output", "json",
	)
	if err != nil {
		return "", fmt.Errorf("failed to execute contract: %w", err)
	}
	
	s.T().Logf("✅ Contract execution result: %s", txOutput)
	return txOutput, nil
}

// helper function: waitForIBCConnections waits for the IBC connections to be established between Babylon and the
// Consumer.
func (s *BCDConsumerIntegrationTestSuite) waitForIBCConnections() {
	var babylonChannel *channeltypes.IdentifiedChannel
	// Wait for the custom channel
	s.Eventually(func() bool {
		babylonChannelsResp, err := s.babylonController.IBCChannels()
		if err != nil {
			s.T().Logf("Error querying Babylon IBC channels: %v", err)
			return false
		}
		if len(babylonChannelsResp.Channels) < 1 {
			s.T().Logf("Expected at least one Babylon IBC channel")
			return false
		}
		babylonChannel = babylonChannelsResp.Channels[0]
		if babylonChannel.State != channeltypes.OPEN {
			s.T().Logf("Babylon custom channel state is not OPEN, got %s", babylonChannel.State)
			return false
		}
		s.Equal(channeltypes.ORDERED, babylonChannel.Ordering)
		s.Contains(babylonChannel.Counterparty.PortId, "wasm.")
		return true
	}, time.Minute*4, time.Second*10, "Failed to get expected Babylon custom IBC channel")

	// TODO: For cosmwasmChannel, we need to use ibc v8 as cosmos client has not bumped
	var consumerChannel *channeltypes.IdentifiedChannel
	s.Eventually(func() bool {
		consumerChannelsResp, err := s.cosmwasmController.IBCChannels()
		if err != nil {
			s.T().Logf("Error querying Consumer IBC channels: %v", err)
			return false
		}
		if len(consumerChannelsResp.Channels) < 1 {
			return false
		}
		consumerChannel = consumerChannelsResp.Channels[0]
		if consumerChannel.State != channeltypes.OPEN {
			return false
		}
		s.Equal(channeltypes.ORDERED, consumerChannel.Ordering)
		s.Equal(babylonChannel.PortId, consumerChannel.Counterparty.PortId)
		s.T().Logf("IBC custom channel established successfully")
		return true
	}, time.Minute, time.Second*2, "Failed to get expected Consumer custom IBC channel")

	// Wait for the transfer channel
	s.Eventually(func() bool {
		babylonChannelsResp, err := s.babylonController.IBCChannels()
		if err != nil {
			s.T().Logf("Error querying Babylon IBC channels: %v", err)
			return false
		}
		if len(babylonChannelsResp.Channels) != 2 {
			s.T().Logf("Expected 2 Babylon IBC channels, got %d", len(babylonChannelsResp.Channels))
			return false
		}
		babylonChannel = babylonChannelsResp.Channels[0]
		if babylonChannel.State != channeltypes.OPEN {
			s.T().Logf("Babylon transfer channel state is not OPEN, got %s", babylonChannel.State)
			return false
		}
		s.Equal(channeltypes.UNORDERED, babylonChannel.Ordering)
		s.Contains(babylonChannel.Counterparty.PortId, "transfer")
		return true
	}, time.Minute*3, time.Second*10, "Failed to get expected Babylon transfer IBC channel")

	s.Eventually(func() bool {
		consumerChannelsResp, err := s.cosmwasmController.IBCChannels()
		if err != nil {
			s.T().Logf("Error querying Consumer IBC channels: %v", err)
			return false
		}
		if len(consumerChannelsResp.Channels) != 2 {
			return false
		}
		consumerChannel = consumerChannelsResp.Channels[0]
		if consumerChannel.State != channeltypes.OPEN {
			return false
		}
		s.Equal(channeltypes.UNORDERED, consumerChannel.Ordering)
		s.Equal(babylonChannel.PortId, consumerChannel.Counterparty.PortId)
		s.T().Logf("IBC transfer channel established successfully")
		return true
	}, time.Minute*3, time.Second*10, "Failed to get expected Consumer transfer IBC channel")
}

func (s *BCDConsumerIntegrationTestSuite) waitForContractInstantiation() {
	s.Eventually(func() bool {
		_, err := s.cosmwasmController.QueryBabylonContracts()
		if err != nil {
			s.T().Logf("Error querying Babylon contracts: %v", err)
			return false
		}

		s.T().Logf("Babylon contract instantiated")
		return true
	}, time.Minute*2, time.Second*10, "Babylon contract instantiation failed")
}

func (s *BCDConsumerIntegrationTestSuite) waitForTransferChannel() {
	// Wait for the transfer channel to be established
	s.Eventually(func() bool {
		babylonChannelsResp, err := s.babylonController.IBCChannels()
		if err != nil {
			s.T().Logf("Error querying Babylon IBC channels: %v", err)
			return false
		}
		if len(babylonChannelsResp.Channels) < 1 {
			s.T().Logf("Expected at least one Babylon IBC channel")
			return false
		}

		// Check for transfer channel
		for _, channel := range babylonChannelsResp.Channels {
			if channel.State == channeltypes.OPEN &&
				channel.Ordering == channeltypes.UNORDERED &&
				channel.Counterparty.PortId == "transfer" {
				s.T().Logf("Transfer channel found and open")
				return true
			}
		}
		s.T().Logf("Transfer channel not found or not open")
		return false
	}, time.Minute*3, time.Second*10, "Failed to find open transfer IBC channel")
}

func (s *BCDConsumerIntegrationTestSuite) queryAndSetConsumerID() {
	// Query the actual IBC client ID from the channel information
	s.T().Log("Querying IBC client ID from channel information...")

	// Wait for IBC infrastructure and get the client ID
	s.Eventually(func() bool {
		babylonChannelsResp, err := s.babylonController.IBCChannels()
		if err != nil {
			s.T().Logf("Error querying Babylon IBC channels: %v", err)
			return false
		}
		if len(babylonChannelsResp.Channels) < 1 {
			s.T().Logf("No IBC channels found - IBC infrastructure not ready")
			return false
		}

		// Look for the transfer channel to get the client ID
		for _, channel := range babylonChannelsResp.Channels {
			if channel.PortId == "transfer" && channel.State == channeltypes.OPEN {
				// Extract the client ID from the client state
				// TODO: use hardcoded client id for now as no available query yet
				s.consumerID = "07-tendermint-0"
				return true
			}
		}

		s.T().Logf("Transfer channel not found or not open yet")
		return false
	}, time.Minute*2, time.Second*5, "Failed to get IBC client ID")

	s.Require().NotEmpty(s.consumerID, "Consumer ID was not set")
	s.T().Logf("Using consumer ID: %s", s.consumerID)
}

func (s *BCDConsumerIntegrationTestSuite) waitForZoneconciergeChannel() {
	// Wait for the zoneconcierge channel (ordered, wasm port)
	s.Eventually(func() bool {
		babylonChannelsResp, err := s.babylonController.IBCChannels()
		if err != nil {
			s.T().Logf("Error querying Babylon IBC channels: %v", err)
			return false
		}
		if len(babylonChannelsResp.Channels) < 2 {
			s.T().Logf("Expected at least 2 Babylon IBC channels, got %d", len(babylonChannelsResp.Channels))
			return false
		}

		// Check for zoneconcierge channel (ordered, wasm port)
		for _, channel := range babylonChannelsResp.Channels {
			if channel.State == channeltypes.OPEN &&
				channel.Ordering == channeltypes.ORDERED &&
				strings.Contains(channel.Counterparty.PortId, "wasm.") {
				s.T().Logf("Zoneconcierge channel found and open")
				return true
			}
		}
		s.T().Logf("Zoneconcierge channel not found or not open")
		return false
	}, time.Minute*4, time.Second*10, "Failed to find open zoneconcierge IBC channel")
}

func (s *BCDConsumerIntegrationTestSuite) registerVerifyConsumer() *bsctypes.ConsumerRegister {
	var registeredConsumer *bsctypes.ConsumerRegister
	var err error

	// Register a random consumer on Babylon
	registeredConsumer = bsctypes.NewCosmosConsumerRegister(
		s.consumerID,
		datagen.GenRandomHexStr(r, 5),
		"Chain description: "+datagen.GenRandomHexStr(r, 15),
		datagen.GenBabylonRewardsCommission(r),
	)

	// wait until the consumer is registered
	s.Eventually(func() bool {
		_, err = s.babylonController.RegisterConsumerChain(registeredConsumer.ConsumerId, registeredConsumer.ConsumerName, registeredConsumer.ConsumerDescription)
		if err != nil {
			return false
		}

		consumerRegistryResp, err := s.babylonController.QueryConsumerRegistry(s.consumerID)
		if err != nil {
			return false
		}
		s.Require().NotNil(consumerRegistryResp)
		s.Require().Len(consumerRegistryResp.ConsumerRegisters, 1)
		s.Require().Equal(registeredConsumer.ConsumerId, consumerRegistryResp.ConsumerRegisters[0].ConsumerId)
		s.Require().Equal(registeredConsumer.ConsumerName, consumerRegistryResp.ConsumerRegisters[0].ConsumerName)
		s.Require().Equal(registeredConsumer.ConsumerDescription, consumerRegistryResp.ConsumerRegisters[0].ConsumerDescription)

		return true
	}, 3*time.Minute, 5*time.Second, "Consumer was not registered within the expected time")

	s.T().Logf("Consumer registered: ID=%s, Name=%s, Description=%s",
		registeredConsumer.ConsumerId,
		registeredConsumer.ConsumerName,
		registeredConsumer.ConsumerDescription)

	return registeredConsumer
}

func (s *BCDConsumerIntegrationTestSuite) finalizeUntilConsumerHeight(consumerHeight uint64) {
	s.Eventually(func() bool {
		s.finalizeNextEpoch()
		consumerLastTimestampedHeader, err := s.cosmwasmController.QueryLastBTCTimestampedHeader()
		if err != nil {
			s.T().Logf("error querying last timestamped header: %v", err)
			return false
		}

		if consumerHeight < consumerLastTimestampedHeader.Height {
			s.T().Logf("consumer height %d is now timestamped (last timestamped height %d)!", consumerHeight, consumerLastTimestampedHeader.Height)
			return true
		} else {
			s.T().Logf("consumer height %d is not timestamped (last timestamped height %d) yet", consumerHeight, consumerLastTimestampedHeader.Height)
			return false
		}
	}, 3*time.Minute, time.Second*10)
}

func (s *BCDConsumerIntegrationTestSuite) getLastFinalizedEpoch() *epochingtypes.EpochResponse {
	lastFinalizedCkpt, err := s.babylonController.GetBBNClient().LatestEpochFromStatus(ckpttypes.Finalized)
	s.NoError(err)
	s.NotNil(lastFinalizedCkpt)

	epochs, err := s.babylonController.GetBBNClient().EpochsInfo(&sdkquerytypes.PageRequest{Key: sdk.Uint64ToBigEndian(lastFinalizedCkpt.RawCheckpoint.EpochNum), Limit: 1})
	s.NoError(err)
	s.NotNil(epochs)
	s.Equal(1, len(epochs.Epochs))

	lastFinalizedEpoch := epochs.Epochs[0]
	return lastFinalizedEpoch
}

func (s *BCDConsumerIntegrationTestSuite) finalizeNextEpoch() {
	bbnClient := s.babylonController.GetBBNClient()
	epoch := uint64(1)
	lastFinalizedCkpt, err := bbnClient.LatestEpochFromStatus(ckpttypes.Finalized)
	if err != nil {
		s.T().Logf("no finalized checkpoint found")
	} else {
		epoch = lastFinalizedCkpt.RawCheckpoint.EpochNum + 1
	}
	s.finalizeUntilEpoch(epoch, true)
}

func (s *BCDConsumerIntegrationTestSuite) finalizeUntilEpoch(epoch uint64, wait bool) {
	bbnClient := s.babylonController.GetBBNClient()

	startEpoch := uint64(0)
	lastFinalizedCkpt, err := bbnClient.LatestEpochFromStatus(ckpttypes.Finalized)
	if err != nil {
		s.T().Logf("no finalized checkpoint found")
	} else if lastFinalizedCkpt != nil {
		s.T().Logf("last finalized epoch: %d", lastFinalizedCkpt.RawCheckpoint.EpochNum)
		startEpoch = lastFinalizedCkpt.RawCheckpoint.EpochNum + 1
	}

	if epoch < startEpoch {
		s.T().Logf("epoch %d is less than start epoch %d", epoch, startEpoch)
		return
	}

	// wait until the checkpoint of this epoch is sealed
	if wait {
		s.Eventually(func() bool {
			lastSealedCkpt, err := bbnClient.LatestEpochFromStatus(ckpttypes.Sealed)
			if err != nil {
				return false
			}
			return epoch <= lastSealedCkpt.RawCheckpoint.EpochNum
		}, 1*time.Minute, 1*time.Second)
	}

	s.T().Logf("start finalizing epochs till %d", epoch)
	// Random source for the generation of BTC data
	r := rand.New(rand.NewSource(time.Now().Unix()))

	// get all checkpoints of these epochs
	pagination := &sdkquerytypes.PageRequest{
		Key:   ckpttypes.CkptsObjectKey(startEpoch),
		Limit: epoch - startEpoch + 1,
	}
	resp, err := bbnClient.RawCheckpoints(pagination)
	s.NoError(err)
	if len(resp.RawCheckpoints) == 0 {
		s.T().Logf("no checkpoints found")
		return
	}
	epoch = resp.RawCheckpoints[len(resp.RawCheckpoints)-1].Ckpt.EpochNum
	s.T().Logf("start finalizing checkpointed epochs till %d", epoch)

	submitter := s.babylonController.GetKeyAddress()

	for _, checkpoint := range resp.RawCheckpoints {
		fmt.Println("Checkpoint epoch:", checkpoint.Ckpt.EpochNum)
		fmt.Println("Checkpoint status:", checkpoint.Status)
		if checkpoint.Status == ckpttypes.Finalized {
			continue
		}
		currentBtcTipResp, err := s.babylonController.QueryBtcLightClientTip()
		s.NoError(err)
		tipHeader, err := bbn.NewBTCHeaderBytesFromHex(currentBtcTipResp.HeaderHex)
		s.NoError(err)

		rawCheckpoint, err := checkpoint.Ckpt.ToRawCheckpoint()
		s.NoError(err)

		btcCheckpoint, err := ckpttypes.FromRawCkptToBTCCkpt(rawCheckpoint, submitter)
		s.NoError(err)

		babylonTagBytes, err := hex.DecodeString("01020304")
		s.NoError(err)

		p1, p2, err := txformat.EncodeCheckpointData(
			babylonTagBytes,
			txformat.CurrentVersion,
			btcCheckpoint,
		)
		s.NoError(err)

		tx1 := datagen.CreatOpReturnTransaction(r, p1)

		opReturn1 := datagen.CreateBlockWithTransaction(r, tipHeader.ToBlockHeader(), tx1)
		tx2 := datagen.CreatOpReturnTransaction(r, p2)
		opReturn2 := datagen.CreateBlockWithTransaction(r, opReturn1.HeaderBytes.ToBlockHeader(), tx2)

		// insert headers and proofs
		_, err = s.babylonController.InsertBtcBlockHeaders([]bbn.BTCHeaderBytes{
			opReturn1.HeaderBytes,
			opReturn2.HeaderBytes,
		})
		s.NoError(err)

		_, err = s.babylonController.InsertSpvProofs(submitter.String(), []*btcctypes.BTCSpvProof{
			opReturn1.SpvProof,
			opReturn2.SpvProof,
		})
		s.NoError(err)

		// wait until this checkpoint is submitted
		s.Eventually(func() bool {
			ckpt, err := bbnClient.RawCheckpoint(checkpoint.Ckpt.EpochNum)
			if err != nil {
				return false
			}
			return ckpt.RawCheckpoint.Status == ckpttypes.Submitted
		}, 1*time.Minute, 1*time.Second)
	}

	// insert w BTC headers
	err = s.babylonController.InsertWBTCHeaders(r)
	s.NoError(err)

	// wait until the checkpoint of this epoch is finalised
	s.Eventually(func() bool {
		lastFinalizedCkpt, err := bbnClient.LatestEpochFromStatus(ckpttypes.Finalized)
		if err != nil {
			s.T().Logf("failed to get last finalized epoch: %v", err)
			return false
		}
		if epoch <= lastFinalizedCkpt.RawCheckpoint.EpochNum {
			s.T().Logf("epoch %d is finalised", epoch)
		} else {
			s.T().Logf("epoch %d is not finalised yet", epoch)
		}
		return epoch <= lastFinalizedCkpt.RawCheckpoint.EpochNum
	}, 1*time.Minute, 1*time.Second)
}

// helper function: getDeterministicCovenantKey returns a single, constant private key and its corresponding public key.
// This function is for testing purposes only and should never be used in production environments.
func getDeterministicCovenantKey() (*btcec.PrivateKey, *btcec.PublicKey, string, error) {
	// This is a constant private key for testing purposes only
	const constantPrivateKeyHex = "1234567890abcdef1234567890abcdef1234567890abcdef1234567890abcdef"

	privateKeyBytes, err := hex.DecodeString(constantPrivateKeyHex)
	if err != nil {
		return nil, nil, "", err
	}

	privateKey, publicKey := btcec.PrivKeyFromBytes(privateKeyBytes)

	// Convert to BIP340 public key
	bip340PubKey := bbn.NewBIP340PubKeyFromBTCPK(publicKey)

	// Get the hex representation of the BIP340 public key
	publicKeyHex := bip340PubKey.MarshalHex()

	if publicKeyHex != "bb50e2d89a4ed70663d080659fe0ad4b9bc3e06c17a227433966cb59ceee020d" {
		return nil, nil, "", fmt.Errorf("public key hex is not expected")
	}

	return privateKey, publicKey, publicKeyHex, nil
}

// ParseRespsBTCDelToBTCDel parses an BTC delegation response to BTC Delegation
func ParseRespsBTCDelToBTCDel(resp *bstypes.BTCDelegatorDelegationsResponse) (btcDels *bstypes.BTCDelegatorDelegations, err error) {
	if resp == nil {
		return nil, nil
	}
	btcDels = &bstypes.BTCDelegatorDelegations{
		Dels: make([]*bstypes.BTCDelegation, len(resp.Dels)),
	}

	for i, delResp := range resp.Dels {
		del, err := ParseRespBTCDelToBTCDel(delResp)
		if err != nil {
			return nil, err
		}
		btcDels.Dels[i] = del
	}
	return btcDels, nil
}

// createTestEncodingConfig creates a minimal encoding config for e2e tests
// without depending on the full demo app
func createTestEncodingConfig() wasmparams.EncodingConfig {
	// Create basic encoding components
	interfaceRegistry := codectypes.NewInterfaceRegistry()
	cdc := codec.NewProtoCodec(interfaceRegistry)
	amino := codec.NewLegacyAmino()

	// Register necessary interfaces for CosmWasm
	wasmtypes.RegisterInterfaces(interfaceRegistry)
	wasmtypes.RegisterLegacyAminoCodec(amino)

	// Create transaction config
	txConfig := tx.NewTxConfig(cdc, tx.DefaultSignModes)

	return wasmparams.EncodingConfig{
		InterfaceRegistry: interfaceRegistry,
		Codec:             cdc,
		TxConfig:          txConfig,
		Amino:             amino,
	}
}

// ParseRespBTCDelToBTCDel parses an BTC delegation response to BTC Delegation
func ParseRespBTCDelToBTCDel(resp *bstypes.BTCDelegationResponse) (btcDel *bstypes.BTCDelegation, err error) {
	stakingTx, err := hex.DecodeString(resp.StakingTxHex)
	if err != nil {
		return nil, err
	}

	delSig, err := bbn.NewBIP340SignatureFromHex(resp.DelegatorSlashSigHex)
	if err != nil {
		return nil, err
	}

	slashingTx, err := bstypes.NewBTCSlashingTxFromHex(resp.SlashingTxHex)
	if err != nil {
		return nil, err
	}

	btcDel = &bstypes.BTCDelegation{
		StakerAddr:       resp.StakerAddr,
		BtcPk:            resp.BtcPk,
		FpBtcPkList:      resp.FpBtcPkList,
		StartHeight:      resp.StartHeight,
		EndHeight:        resp.EndHeight,
		TotalSat:         resp.TotalSat,
		StakingTx:        stakingTx,
		DelegatorSig:     delSig,
		StakingOutputIdx: resp.StakingOutputIdx,
		CovenantSigs:     resp.CovenantSigs,
		UnbondingTime:    resp.UnbondingTime,
		SlashingTx:       slashingTx,
	}

	if resp.UndelegationResponse != nil {
		ud := resp.UndelegationResponse
		unbondTx, err := hex.DecodeString(ud.UnbondingTxHex)
		if err != nil {
			return nil, err
		}

		slashTx, err := bstypes.NewBTCSlashingTxFromHex(ud.SlashingTxHex)
		if err != nil {
			return nil, err
		}

		delSlashingSig, err := bbn.NewBIP340SignatureFromHex(ud.DelegatorSlashingSigHex)
		if err != nil {
			return nil, err
		}

		btcDel.BtcUndelegation = &bstypes.BTCUndelegation{
			UnbondingTx:              unbondTx,
			CovenantUnbondingSigList: ud.CovenantUnbondingSigList,
			CovenantSlashingSigs:     ud.CovenantSlashingSigs,
			SlashingTx:               slashTx,
			DelegatorSlashingSig:     delSlashingSig,
		}

		if ud.DelegatorUnbondingInfoResponse != nil {
			var spendStakeTx []byte = make([]byte, 0)
			if ud.DelegatorUnbondingInfoResponse.SpendStakeTxHex != "" {
				spendStakeTx, err = hex.DecodeString(ud.DelegatorUnbondingInfoResponse.SpendStakeTxHex)
				if err != nil {
					return nil, err
				}
			}

			btcDel.BtcUndelegation.DelegatorUnbondingInfo = &bstypes.DelegatorUnbondingInfo{
				SpendStakeTx: spendStakeTx,
			}
		}
	}

	return btcDel, nil
}
