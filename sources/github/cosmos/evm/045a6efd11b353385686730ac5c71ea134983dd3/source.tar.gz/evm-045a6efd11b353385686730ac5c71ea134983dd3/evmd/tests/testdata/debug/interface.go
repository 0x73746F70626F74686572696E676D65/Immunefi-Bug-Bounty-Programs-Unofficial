package debug

import (
	"math/big"

	sdk "github.com/cosmos/cosmos-sdk/types"
	"github.com/cosmos/evm/x/vm/statedb"
	evmtypes "github.com/cosmos/evm/x/vm/types"
	"github.com/ethereum/go-ethereum/accounts/abi"
	"github.com/ethereum/go-ethereum/common"
)

type EVMKeeper interface {
	CallEVM(ctx sdk.Context, stateDB *statedb.StateDB, abi abi.ABI, from, contract common.Address, commit bool, callFromPrecompile bool, gasCap *big.Int, method string, args ...interface{}) (*evmtypes.MsgEthereumTxResponse, error)
	CallEVMWithData(
		ctx sdk.Context,
		stateDB *statedb.StateDB,
		from common.Address,
		contract *common.Address,
		data []byte,
		commit bool,
		callFromPrecompile bool,
		gasCap *big.Int,
	) (*evmtypes.MsgEthereumTxResponse, error)
}
