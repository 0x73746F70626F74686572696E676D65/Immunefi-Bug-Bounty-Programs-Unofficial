---
name: Bug Report 
about: Create a report to help us squash bugs!

---

<!-- < < < < < < < < < < < < < < < < < < < < < < < < < < < < < < < < < ☺ 
v                            ✰  Thanks for opening an issue! ✰    
v    Before smashing the submit button please review the template.
v    Please also ensure that this is not a duplicate issue :)  
☺ > > > > > > > > > > > > > > > > > > > > > > > > > > > > > > > > >  -->

## Summary of Bug

<!-- Concisely describe the issue -->

## Expected Behaviour

<!-- What is the expected behaviour? -->

## Version

<!-- git commit hash or release version -->

## Steps to Reproduce

<!-- What commands in order should someone run to reproduce your problem? -->

____

#### For Admin Use

- [ ] Not duplicate issue
- [ ] Appropriate labels applied
- [ ] Appropriate contributors tagged/assigned
- [ ] Estimate provided
