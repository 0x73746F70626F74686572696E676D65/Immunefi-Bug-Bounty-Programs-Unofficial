// SPDX-License-Identifier: Apache-2.0

use solana_ibc_macros::ibc_app;

// on_timeout_packet returning Result<Vec<u8>> instead of Result<()>
#[ibc_app]
pub mod my_app {
    pub fn on_recv_packet(ctx: Ctx, msg: OnRecvPacketMsg) -> Result<Vec<u8>> {
        Ok(vec![])
    }

    pub fn on_acknowledgement_packet(ctx: Ctx, msg: OnAcknowledgementPacketMsg) -> Result<()> {
        Ok(())
    }

    pub fn on_timeout_packet(ctx: Ctx, msg: OnTimeoutPacketMsg) -> Result<Vec<u8>> {
        Ok(vec![])
    }
}

fn main() {}
