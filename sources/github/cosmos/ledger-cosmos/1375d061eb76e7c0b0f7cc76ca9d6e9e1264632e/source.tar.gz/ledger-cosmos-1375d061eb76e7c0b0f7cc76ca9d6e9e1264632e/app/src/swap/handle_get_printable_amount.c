/*******************************************************************************
 *   (c) 2016 Ledger
 *   (c) 2018 - 2023 Zondax AG
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 ********************************************************************************/
#include "bignum.h"
#include "crypto.h"
#include "lib_standard_app/swap_lib_calls.h"
#include "swap.h"
#include "swap_utils.h"
#include "zxformat.h"

void handle_get_printable_amount(get_printable_amount_parameters_t *params) {
  if (params == NULL || params->coin_configuration == NULL ||
      params->amount == NULL) {
    return;
  }

  uint8_t amount[COIN_AMOUNT_MAXSIZE] = {0};
  MEMZERO(amount, sizeof(amount));
  MEMZERO(params->printable_amount, sizeof(params->printable_amount));

  if (params->amount_length > COIN_AMOUNT_MAXSIZE ||
      params->coin_configuration_length < 2) {
    return;
  }

  uint8_t coin_len = params->coin_configuration[0];
  if (coin_len == 0 || params->coin_configuration_length < 1 + coin_len) {
    return;
  }

  memcpy(amount + COIN_AMOUNT_MAXSIZE - params->amount_length, params->amount,
         params->amount_length);

  char tmp_amount[110] = {0};
  int8_t chain_index = find_chain_index_by_coin_config(
      (char *)&params->coin_configuration[1], coin_len);
  if (chain_index == -1) {
    return;
  }
  zxerr_t zxerr = bytesAmountToStringBalance(amount, sizeof(amount), tmp_amount,
                                             sizeof(tmp_amount), chain_index);

  if (zxerr != zxerr_ok || strnlen(tmp_amount, sizeof(tmp_amount)) >=
                               sizeof(params->printable_amount)) {
    return;
  }
  strncpy(params->printable_amount, tmp_amount,
          sizeof(params->printable_amount) - 1);
}
