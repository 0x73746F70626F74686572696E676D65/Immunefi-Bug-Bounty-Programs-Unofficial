/*******************************************************************************
 *   (c) 2019 Zondax GmbH
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 ********************************************************************************/

#pragma once

#ifdef __cplusplus
extern "C" {
#endif

#include "coin.h"
#include "parser_impl.h"

#define OUTPUT_HANDLER_SIZE 600
#define MAX_CONTENT_SIZE 550
#define MAX_TITLE_SIZE 40
#define PRINTABLE_TITLE_SIZE 17
#define PRINTABLE_PAGINATED_TITLE_SIZE 10
#define SCREEN_BREAK ":"
#define SCREEN_INDENT ">"
#define TITLE_TRUNCATE_REPLACE "---"

// Buffer sizes for parser operations
#define FORMATTED_AMOUNT_BUFFER_SIZE 160
// Must hold the longest entry in key_substitutions plus its terminator, or the
// key path is silently clamped and the friendly label can never match. Longest
// today is "msgs/value/msg/validator_src_address" (36).
#define QUERY_KEY_BUFFER_SIZE 48

// JSON amount object token structure constants
// Token structure: [object, key:"amount", value, key:"denom", value]
#define AMOUNT_OBJECT_TOKEN_COUNT 4
#define AMOUNT_KEY_TOKEN_OFFSET 1
#define AMOUNT_VALUE_TOKEN_OFFSET 2
#define DENOM_KEY_TOKEN_OFFSET 3
#define DENOM_VALUE_TOKEN_OFFSET 4

const char *parser_getErrorDescription(parser_error_t err);

//// parses a tx buffer
parser_error_t parser_parse(parser_context_t *ctx, const uint8_t *data,
                            size_t dataLen, parser_tx_t *tx_obj);

//// verifies tx fields
parser_error_t parser_validate(const parser_context_t *ctx);

//// returns the number of items in the current parsing context
parser_error_t parser_getNumItems(const parser_context_t *ctx,
                                  uint8_t *num_items);

// retrieves a readable output for each field / page
parser_error_t parser_getItem(const parser_context_t *ctx, uint8_t displayIdx,
                              char *outKey, uint16_t outKeyLen, char *outVal,
                              uint16_t outValLen, uint8_t pageIdx,
                              uint8_t *pageCount);

#ifdef __cplusplus
}
#endif
