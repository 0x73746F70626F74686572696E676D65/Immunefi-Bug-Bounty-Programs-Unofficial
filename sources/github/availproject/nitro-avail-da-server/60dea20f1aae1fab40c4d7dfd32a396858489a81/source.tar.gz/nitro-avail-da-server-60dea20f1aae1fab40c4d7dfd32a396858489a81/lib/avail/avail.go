package avail

import (
	"bytes"
	"context"
	"os"

	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/http"
	"time"

	"github.com/ethereum/go-ethereum/log"
	"github.com/vedhavyas/go-subkey/v2"

	"github.com/availproject/avail-go-sdk/primitives"
	avail_sdk "github.com/availproject/avail-go-sdk/sdk"
	s3_storage_service "github.com/availproject/nitro-avail-da-server/lib/avail/s3StorageService"
)

const (
	AvailMessageHeaderFlag byte = 0x0a
	AvailNetworkID              = 42
	BridgeApiTimeout            = time.Duration(1200)
	AvailRPCTimeout             = time.Duration(120)
	BridgeApiWaitInterval       = time.Duration(420)
	BridgeApiRetryCount         = 10
	TurboDARetryCount           = 10
	VectorXTimeout              = time.Duration(10000)
)

var (
	ErrAvailDAClientInit          = errors.New("unable to initialize to connect with AvailDA")
	ErrBatchSubmitToAvailDAFailed = errors.New("unable to submit batch to AvailDA")
	ErrWrongAvailDAPointer        = errors.New("unable to retrieve batch, wrong blobPointer")
)

type AvailBackend struct {
	logger log.Logger

	sdk     avail_sdk.SDK
	acc     subkey.KeyPair
	address string
	appId   int

	httpApi string

	// TurboDA
	turboDAEnabled bool
	turboDAUrl     string
	turboDAApiKey  string

	// AvailDA bridge
	bridgeEnabled bool
	bridgeApi     string
	bridgeTimeout int

	// S3 Fallback service
	fallbackS3Service *s3_storage_service.S3StorageService
}

func New(config Config, logger log.Logger) (*AvailBackend, error) {

	if logger == nil {
		handler := log.NewTerminalHandler(os.Stdout, true)
		logger = log.NewLogger(handler)
	}

	logger.Info("AvailDAInfo: ✏️ Avail backend client is being initialized...")
	logger.Debug("AvailDADebug: AvailDA config", "ws-api-url", config.WsApiUrl, "http-api-url", config.HttpApiUrl, "app-id", config.AppID, "tubo-da-enabled", config.TurboDAEnabled, "turbo-da-url", config.TurboDAUrl, "bridge-enabled", config.BridgeEnabled, "bridge-api-url", config.BridgeApiUrl, "bridge-timeout", config.BridgeTimeout)

	sdk, err := avail_sdk.NewSDK(config.HttpApiUrl)
	if err != nil {
		logger.Error("AvailDAError: ⚠️ error connecting", "URL", config.HttpApiUrl, "Err", err)
		return nil, err
	}
	appId := 0
	// if app id is greater than 0 then it must be created before submitting data
	if config.AppID != 0 {
		appId = config.AppID
	}

	var acc subkey.KeyPair = avail_sdk.Account.Alice()
	if !config.TurboDAEnabled {
		acc, err = avail_sdk.Account.NewKeyPair(config.Seed)
		if err != nil {
			logger.Error("AvailDAError: ⚠️ unable to generate keypair from given seed")
		}
	}

	var fallbackS3Service *s3_storage_service.S3StorageService
	if config.FallbackS3ServiceConfig.Enable {
		logger.Debug("AvailDADebug: ℹ️ Fallback S3 config", "s3-bucket", config.FallbackS3ServiceConfig.Bucket, "region", config.FallbackS3ServiceConfig.Region, "object-prefix", config.FallbackS3ServiceConfig)
		fallbackS3Service, err = s3_storage_service.NewS3StorageService(config.FallbackS3ServiceConfig, logger)
		if err != nil {
			return nil, fmt.Errorf("AvailDAError: unable to intialize s3 storage service for fallback, %w. %w", err, ErrAvailDAClientInit)
		}
	}

	logger.Debug("AvailDADebug: 🔑 Using KeyringPair", "address", acc.SS58Address(AvailNetworkID))
	logger.Info("AvailDAInfo:✌️ Avail backend client is created successfully")

	return &AvailBackend{
		logger:  logger,
		sdk:     sdk,
		acc:     acc,
		address: acc.SS58Address(AvailNetworkID),
		appId:   appId,
		httpApi: config.HttpApiUrl,

		turboDAEnabled: config.TurboDAEnabled,
		turboDAUrl:     config.TurboDAUrl,
		turboDAApiKey:  config.TurboDAApiKey,

		bridgeEnabled: config.BridgeEnabled,
		bridgeApi:     config.BridgeApiUrl,
		bridgeTimeout: config.BridgeTimeout,

		fallbackS3Service: fallbackS3Service,
	}, nil
}

func (a *AvailBackend) Init() error {
	return nil
}

type TransactionDetails struct {
	BlockNumber uint32
	BlockHash   primitives.H256
	TxIndex     uint32
}

func (a *AvailBackend) SubmitData(ctx context.Context, sequence []byte) (TransactionDetails, error) {
	resultCh := make(chan struct {
		details TransactionDetails
		err     error
	}, 1)

	// Run the blocking SDK call in a goroutine
	go func() {
		// Transaction will be signed, sent, and watched
		// If the transaction was dropped or never executed, the system will retry it
		// for 2 more times using the same nonce and app id.
		//
		// Waits for finalization to finalize the transaction.
		a.logger.Info("AvailDAInfo: 📤 Submitting data to Avail chain")
		if a.turboDAEnabled {
			a.logger.Info("AvailDAInfo: 📤 Turbo DA is enabled, submitting data using Turbo DA")
			txDetails, err := submitDataToTurboDA(ctx, a.logger, a.turboDAUrl, a.turboDAApiKey, sequence, TurboDARetryCount)
			if err != nil {
				err = fmt.Errorf("cannot submit data to Turbo DA: %v", err)
			}
			resultCh <- struct {
				details TransactionDetails
				err     error
			}{txDetails, err}
		} else {
			// Now submit to Avail chain
			tx := a.sdk.Tx.DataAvailability.SubmitData(sequence)
			txDetails, err := tx.ExecuteAndWatchFinalization(
				a.acc,
				avail_sdk.NewTransactionOptions().WithAppId(uint32(a.appId)),
			)

			if err == nil {
				// Check success
				// Returns None if there was no way to determine the
				// success status of a transaction. Otherwise it returns
				// true or false.
				status := txDetails.IsSuccessful().UnsafeUnwrap()
				if !status {
					err = fmt.Errorf("⚠️ extrinsic failed on avail chain, status: %v", status)
				}
			}

			resultCh <- struct {
				details TransactionDetails
				err     error
			}{TransactionDetails{BlockNumber: txDetails.BlockNumber, BlockHash: txDetails.BlockHash, TxIndex: txDetails.TxIndex}, err}
		}
	}()

	// Now wait for either SDK result or context cancellation
	select {
	case <-ctx.Done():
		return TransactionDetails{}, ctx.Err()
	case res := <-resultCh:
		if res.err != nil {
			return TransactionDetails{}, fmt.Errorf("⚠️ extrinsic got rejected: %w", res.err)
		}

		a.logger.Debug("AvailDADebug: ✅ Data is included in Avail chain", "address", a.address, "appID", a.appId, "block_number", res.details.BlockNumber, "block_hash", res.details.BlockHash, "tx_index", res.details.TxIndex)
		return TransactionDetails{BlockNumber: res.details.BlockNumber, BlockHash: res.details.BlockHash, TxIndex: res.details.TxIndex}, nil
	}
}

type IndexType string

const (
	LeafIndex IndexType = "leaf"
	TxIndex   IndexType = "tx"
)

func (a *AvailBackend) GetData(blockNumber uint32, index uint32, indexType IndexType) ([]byte, error) {
	blockHash, err := a.sdk.Client.BlockHash(blockNumber)
	if err != nil {
		return nil, fmt.Errorf("❎ Cannot get block hash: %w", err)
	}

	block, err := avail_sdk.NewBlock(a.sdk.Client, blockHash)
	if err != nil {
		return nil, fmt.Errorf("❎ Cannot get block: %w", err)
	}

	var blob avail_sdk.DataSubmission

	switch indexType {
	case LeafIndex:
		blobs := block.DataSubmissions(avail_sdk.Filter{})
		if int(index) >= len(blobs) {
			return nil, fmt.Errorf("❎ Unable to retrieve blob at index %d from block %d", index, blockNumber)
		}
		blob = blobs[index]

	case TxIndex:
		blobs := block.DataSubmissions(avail_sdk.Filter{}.WTxIndex(index))
		if len(blobs) == 0 {
			return nil, fmt.Errorf("❎ No blobs found for transaction index %d in block %d", index, blockNumber)
		}
		blob = blobs[0]

	default:
		return nil, fmt.Errorf("❎ Invalid index type: %v", indexType)
	}

	signerAddress, err := primitives.NewAccountIdFromMultiAddress(blob.TxSigner)
	if err != nil {
		a.logger.Warn("AvailDAWarn:‼️ Unable to extract the signer address for the blob")
	}

	a.logger.Debug("AvailDADebug: ✅ Data retrieved from Avail chain", "signerAddress", signerAddress.ToHuman(), "appID", blob.AppId, "extrinsicHash", blob.TxHash)
	return blob.Data, nil
}

type TurboDAResponse struct {
	SubmissionID string `json:"submission_id"`
}

type TurboDAStatusResponse struct {
	Data  *TurboDAStatusData `json:"data"`
	Error interface{}        `json:"error"`
	ID    string             `json:"id"`
	State string             `json:"state"`
}

type TurboDAStatusData struct {
	AmountData  string `json:"amount_data"`
	BlockHash   string `json:"block_hash"`
	BlockNumber int64  `json:"block_number"`
	CreatedAt   string `json:"created_at"`
	DataBilted  string `json:"data_bilted"`
	DataHash    string `json:"data_hash"`
	Fees        string `json:"fees"`
	TxHash      string `json:"tx_hash"`
	TxIndex     int64  `json:"tx_index"`
	UserID      string `json:"user_id"`
}

func submitDataToTurboDA(ctx context.Context, logger log.Logger, url string, apiKey string, data []byte, maxAttempts int) (TransactionDetails, error) {
	req, err := http.NewRequestWithContext(ctx, http.MethodPost, url+"/v1/submit_raw_data", bytes.NewReader(data))
	if err != nil {
		return TransactionDetails{}, fmt.Errorf("failed to create request to Turbo DA: %w", err)
	}
	req.Header.Set("Content-Type", "application/octet-stream")
	req.Header.Set("x-api-key", apiKey)

	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		return TransactionDetails{}, fmt.Errorf("failed to post data to Turbo DA: %w", err)
	}
	defer resp.Body.Close()

	respData, err := io.ReadAll(resp.Body)
	if err != nil {
		return TransactionDetails{}, fmt.Errorf("failed to read response from Turbo DA: %w", err)
	}

	if resp.StatusCode != http.StatusOK {
		return TransactionDetails{}, fmt.Errorf("turbo da error: status code %d", resp.StatusCode)
	}

	var postResp TurboDAResponse
	if err := json.Unmarshal(respData, &postResp); err != nil {
		return TransactionDetails{}, fmt.Errorf("failed to unmarshal response from Turbo DA: %w", err)
	}

	getURL := fmt.Sprintf("%s/v1/get_submission_info?submission_id=%s", url, postResp.SubmissionID)

	var statusResp TurboDAStatusResponse
	for attempt := 1; attempt <= maxAttempts; attempt++ {
		select {
		case <-ctx.Done():
			return TransactionDetails{}, ctx.Err()
		default:
		}

		req, err := http.NewRequestWithContext(ctx, http.MethodGet, getURL, nil)
		if err != nil {
			return TransactionDetails{}, fmt.Errorf("failed to create status request: %w", err)
		}
		req.Header.Set("x-api-key", apiKey)

		resp, err := http.DefaultClient.Do(req)
		if err != nil {
			logger.Warn("AvailDAWarn: ⚠️ Failed to fetch submission", "attempt", attempt, "maxAttempts", maxAttempts, "err", err)
		} else {
			body, _ := io.ReadAll(resp.Body)
			resp.Body.Close()

			if err := json.Unmarshal(body, &statusResp); err != nil {
				logger.Warn("AvailDAWarn: ⚠️ Invalid JSON from Turbo DA", "err", err)
			} else {
				logger.Info("AvailDAInfo: ⏳ Attempt %d/%d | State: %s", attempt, maxAttempts, statusResp.State)
				if statusResp.State == "Finalized" {
					log.Info("AvailDAInfo: ✅ Turbo DA finalized submission", "ID", postResp.SubmissionID)
					blockHash, err := primitives.NewBlockHashFromHexString(statusResp.Data.BlockHash)
					if err != nil {
						return TransactionDetails{}, fmt.Errorf("invalid block hash from Turbo DA: %w", err)
					}
					return TransactionDetails{BlockNumber: uint32(statusResp.Data.BlockNumber), BlockHash: blockHash, TxIndex: uint32(statusResp.Data.TxIndex)}, nil
				}
			}
		}

		// exponential backoff with cap
		sleep := time.Duration(minInt(30, 2<<attempt)) * time.Second
		logger.Info("AvailDAInfo: 🕒 Waiting %s before next check...", sleep)
		time.Sleep(sleep)
	}

	return TransactionDetails{}, fmt.Errorf("submission %s did not finalize within %d attempts", postResp.SubmissionID, maxAttempts)
}

func (a *AvailBackend) getMerkleProofFromAvailBridge(ctx context.Context, blockHash primitives.H256, txIndex uint32) (*MerkleProofInput, error) {

	a.logger.Info("AvailDAInfo: ℹ️ Querying merkle proof of data submitted from Avail Bridge for attesting on settlement layer", "blockHash", blockHash, "txIndex", txIndex)
	var input *BridgeAPIResponse
	waitTime := time.Duration(a.bridgeTimeout) * time.Second
	retryCount := BridgeApiRetryCount
	for retryCount > 0 {
		url := fmt.Sprintf("%s/eth/proof/%s?index=%d", a.bridgeApi, blockHash.String(), txIndex)
		a.logger.Debug("AvailDAInfo: ℹ️ Querying Bridge for merkle proof", "URL", url)
		req, err := http.NewRequestWithContext(ctx, http.MethodGet, url, nil)
		if err != nil {
			return nil, fmt.Errorf("new request: %w", err)
		}

		resp, err := http.DefaultClient.Do(req)
		if err == nil && resp.StatusCode == http.StatusOK {
			defer resp.Body.Close()
			a.logger.Info("AvailDAInfo: ✅ Attestation proof received")
			data, err := io.ReadAll(resp.Body)
			if err != nil {
				return nil, fmt.Errorf("cannot read body:%w", err)
			}
			input = &BridgeAPIResponse{}
			err = json.Unmarshal(data, input)
			if err != nil {
				return nil, fmt.Errorf("cannot unmarshal data:%w", err)
			}
			break
		}

		if resp != nil {
			resp.Body.Close()
		}
		a.logger.Debug("AvailDAWarn: ⏳ Attestation proof RPC errored", "response_code", resp.StatusCode, "retry_count_left", (retryCount - 1), "retrying_in", waitTime)

		timer := time.NewTimer(waitTime)
		defer timer.Stop()

		select {
		case <-ctx.Done():
			return nil, ctx.Err()
		case <-timer.C:
			retryCount--
		}
	}

	if input == nil {
		return nil, fmt.Errorf("didn't get any proof from bridge api")
	}

	a.logger.Debug("AvailDAInfo: 🔗 Attestation proof", "input", input)

	merkleProofInput := NewMerkleProofInput(input)

	return merkleProofInput, nil
}

func minInt(a, b int) int {
	if a < b {
		return a
	}
	return b
}
