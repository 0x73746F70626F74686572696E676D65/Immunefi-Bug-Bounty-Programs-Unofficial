package main

import (
	"os"
	"strconv"

	"github.com/availproject/nitro-avail-da-server/lib/avail"
	s3_storage_service "github.com/availproject/nitro-avail-da-server/lib/avail/s3StorageService"
)

func LoadAvailConfig() avail.Config {
	return avail.Config{
		WsApiUrl:   os.Getenv("AVAIL_WS_API"),
		HttpApiUrl: os.Getenv("AVAIL_HTTP_API"),
		AppID:      atoi(os.Getenv("AVAIL_APP_ID")),
		Seed:       os.Getenv("AVAIL_SEED"),

		TurboDAEnabled: os.Getenv("AVAIL_TURBO_ENABLED") == "true",
		TurboDAUrl:     os.Getenv("AVAIL_TURBO_URL"),
		TurboDAApiKey:  os.Getenv("AVAIL_TURBO_KEY"),

		BridgeEnabled: os.Getenv("AVAIL_BRIDGE_ENABLED") == "true",
		BridgeApiUrl:  os.Getenv("AVAIL_BRIDGE_API"),
		BridgeTimeout: atoi(os.Getenv("AVAIL_BRIDGE_TIMEOUT")),

		FallbackS3ServiceConfig: s3_storage_service.S3StorageServiceConfig{
			Enable:              os.Getenv("S3_FALLBACK_ENABLED") == "true",
			AccessKey:           os.Getenv("S3_FALLBACK_ACCESS_KEY"),
			SecretKey:           os.Getenv("S3_FALLBACK_SECRET_KEY"),
			Bucket:              os.Getenv("S3_FALLBACK_BUCKET"),
			Region:              os.Getenv("S3_FALLBACK_REGION"),
			ObjectPrefix:        os.Getenv("S3_FALLBACK_OBJECT_PREFIX"),
			DiscardAfterTimeout: os.Getenv("S3_FALLBACK_DISCARD_AFTER_TIMEOUT") == "true",
			Concurrency:         atoi(os.Getenv("S3_FALLBACK_CONCURRENCY")),
		},
	}
}

func atoi(s string) int {
	v, _ := strconv.Atoi(s)
	return v
}
