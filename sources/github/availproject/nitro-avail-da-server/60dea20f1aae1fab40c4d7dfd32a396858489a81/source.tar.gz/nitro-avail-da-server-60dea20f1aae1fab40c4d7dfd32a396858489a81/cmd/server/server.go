package main

import (
	"context"
	"net/http"
	"os"
	"os/signal"
	"syscall"
	"time"

	"github.com/availproject/nitro-avail-da-server/lib/avail"
	"github.com/availproject/nitro-avail-da-server/service"
	"github.com/ethereum/go-ethereum/log"
	"github.com/ethereum/go-ethereum/rpc"
)

func main() {

	// Setup logger
	handler := log.NewTerminalHandler(os.Stdout, true)
	logger := log.NewLogger(handler)
	log.SetDefault(logger)

	// Context for graceful shutdown
	ctx, stop := signal.NotifyContext(context.Background(), syscall.SIGINT, syscall.SIGTERM)
	defer stop()

	// Read port from env (default 8080)
	portStr := os.Getenv("PORT")
	if portStr == "" {
		portStr = "8080"
		logger.Debug("Using default port", "port", portStr)
	}
	port := ":" + portStr

	server := rpc.NewServer()
	httpServer := &http.Server{
		Addr:    port,
		Handler: server,
	}

	// Initialize Avail backend
	config := LoadAvailConfig()
	avail, err := avail.New(config, logger)
	if err != nil {
		logger.Crit("Failed to create Avail backend", "error", err)
	}

	// Register DA service
	logger.Info("Registering DA service")
	if err := server.RegisterName("daprovider", &service.DAService{Logger: logger, Avail: avail}); err != nil {
		logger.Crit("Failed to register DA service", "error", err)
	}

	// Start server in goroutine
	go func() {
		logger.Info("Server listening", "port", port)
		if err := httpServer.ListenAndServe(); err != nil && err != http.ErrServerClosed {
			logger.Crit("Server failed", "error", err)
		}
	}()

	// Wait for shutdown signal
	<-ctx.Done()
	logger.Info("Shutdown signal received")

	// Graceful shutdown
	shutdownCtx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	if err := httpServer.Shutdown(shutdownCtx); err != nil {
		logger.Crit("Server shutdown failed", "error", err)
	}

	logger.Info("Server shutdown complete")
}
