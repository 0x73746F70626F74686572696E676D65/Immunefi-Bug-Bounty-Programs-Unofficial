package service

import (
	"context"

	"github.com/availproject/nitro-avail-da-server/lib/avail"
	"github.com/ethereum/go-ethereum/common"
	"github.com/ethereum/go-ethereum/log"
)

type DAService struct {
	Logger log.Logger
	Avail  *avail.AvailBackend
}

// Store posts the batch data to the invoking DA provider
// And returns sequencerMsg which is later used to retrieve the batch data
func (s *DAService) Store(ctx context.Context, message []byte,
	timeout uint64) ([]byte, error) {
	s.Logger.Debug("Storing data", "value", string(message))
	return []byte("data"), nil
}

// RecoverPayload fetches the underlying payload from the DA provider given the batch header information
func (s *DAService) RecoverPayload(ctx context.Context, batchNum uint64,
	batchBlockHash common.Hash,
	sequencerMsg []byte) ([]byte, error) {
	s.Logger.Debug("Recovering payload", "batchNum", batchNum, "batchBlockHash", batchBlockHash)
	return []byte("data"), nil
}

// CollectPreimages collects preimages from the DA provider given the batch header information
func (s *DAService) CollectPreimages(ctx context.Context, batchNum uint64,
	batchBlockHash common.Hash,
	sequencerMsg []byte) (common.Hash, error) {
	s.Logger.Debug("Collecting preimages", "batchNum", batchNum, "batchBlockHash", batchBlockHash)
	return common.Hash{}, nil
}

// GenerateReadPreimageProof generates a proof for a specific preimage at a given offset.
// The proof format depends on the implementation and must be compatible with the Solidity
// IDACertificateValidator contract.
func (s *DAService) GenerateReadPreimageProof(ctx context.Context, offset uint64,
	certificate []byte) ([]byte, error) {
	s.Logger.Debug("Generating read preimage proof", "offset", offset)
	return []byte("proof"), nil
}

// GenerateCertificateValidityProof returns a proof of whether the certificate
// is valid according to the DA system's rules.
func (s *DAService) GenerateCertificateValidityProof(ctx context.Context, certificate []byte) ([]byte, error) {
	s.Logger.Debug("Generating certificate validity proof")
	return []byte("proof"), nil
}
