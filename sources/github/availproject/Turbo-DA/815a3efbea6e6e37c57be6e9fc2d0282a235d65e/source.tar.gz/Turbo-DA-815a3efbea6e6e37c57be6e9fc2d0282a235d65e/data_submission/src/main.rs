pub mod auth;
pub mod config;
pub mod redis;
pub mod routes;
pub mod utils;
pub mod workload_scheduler;

use crate::{
    auth::Auth, config::AppConfig, redis::Redis, 
};
use actix_cors::Cors;
use actix_web::{
    middleware::Logger,
    web::{self},
    App, HttpServer,
};

use crate::routes::{
    data_retrieval::{get_pre_image, get_submission_info},
    data_submission::{submit_data, submit_raw_data},
    health::health_check,
};
use diesel_async::{
    pooled_connection::{deadpool::Pool, AsyncDieselConnectionManager},
    AsyncPgConnection,
};
use enigma::EnigmaEncryptionService;
use observability::init_tracer;
use std::sync::Arc;
use tokio::sync::broadcast;
use turbo_da_core::utils::generate_keygen_list;
use workload_scheduler::consumer::Consumer;

#[tokio::main]
#[tracing::instrument(name = "data_submission_service")]
async fn main() -> Result<(), std::io::Error> {
    let _guard = init_tracer("data_submission");

    let app_config = AppConfig::default().load_config()?;

    tracing::info!(
        port = app_config.port,
        threads = app_config.number_of_threads,
        pool_size = app_config.max_pool_size,
        endpoints = app_config.avail_rpc_endpoint.len(),
        "data submission service starting"
    );
    let accounts =
        generate_keygen_list(app_config.number_of_threads, &app_config.private_keys).await;
    let shared_keypair = web::Data::new(accounts);

    let db_config =
        AsyncDieselConnectionManager::<AsyncPgConnection>::new(&app_config.database_url);

    let pool: Pool<AsyncPgConnection> = Pool::builder(db_config)
        .max_size(app_config.max_pool_size)
        .build()
        .expect("Failed to create pool");

    let shared_pool = web::Data::new(pool);

    let (sender, _receiver) = broadcast::channel(app_config.broadcast_channel_size);

    let shared_redis = Redis::new(app_config.redis_url.as_str());

    let enigma = web::Data::new(EnigmaEncryptionService::new(app_config.enigma_url.clone()));

    let consumer_server = Consumer::new(
        Arc::new(sender.clone()),
        Arc::new(shared_keypair.clone()),
        Arc::new(shared_pool.clone()),
        Arc::new(app_config.avail_rpc_endpoint.clone()),
        Arc::new(enigma.clone()),
        Arc::new(shared_redis.clone()),
        app_config.number_of_threads,
    );

    let port = app_config.port;

    let shared_config = web::Data::new(app_config);

    tokio::spawn(async move {
        consumer_server.start_workers().await;
    });

    HttpServer::new(move || {
        let shared_producer_send = web::Data::new(sender.clone());

        App::new()
            .wrap(Cors::permissive())
            .wrap(Logger::default())
            .service(health_check)
            .service(
                web::scope("/v1")
                    .wrap(Auth::new(
                        shared_redis.clone(),
                        shared_config.database_url.clone(),
                    ))
                    .app_data(web::PayloadConfig::new(shared_config.payload_size))
                    .app_data(shared_producer_send.clone())
                    .app_data(shared_config.clone())
                    .app_data(shared_pool.clone())
                    .app_data(shared_keypair.clone())
                    .app_data(enigma.clone())
                    .service(submit_data)
                    .service(submit_raw_data)
                    .service(get_pre_image)
                    .service(get_submission_info)
           )
    })
    .bind(format!("0.0.0.0:{}", port))?
    .run()
    .await
}
