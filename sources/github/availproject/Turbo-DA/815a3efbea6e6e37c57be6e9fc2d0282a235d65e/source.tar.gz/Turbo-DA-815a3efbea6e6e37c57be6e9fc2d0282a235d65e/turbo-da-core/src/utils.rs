/// A collection of utils
/// - Keygeneration
/// - Keylist generation
use actix_web::{
    web::{self},
    HttpMessage, HttpRequest, HttpResponse,
};
use alloy::primitives::Address;
use avail_rust::{
    avail_rust_core::rpc::{chain, system::chain},
    constants::dev_accounts,
    Client as AvailClient, Keypair, Options,
};

use bigdecimal::BigDecimal;
use clerk_rs::validators::authorizer::ClerkJwt;
use db::schema::credit_requests::chain_id;
use diesel_async::{
    pooled_connection::deadpool::{Object, Pool},
    AsyncPgConnection,
};
use lazy_static::lazy_static;
use reqwest::Client;
use serde::{Deserialize, Serialize};
use serde_json::json;
use std::{collections::HashMap, str::FromStr, sync::Arc};
use tokio::time::{sleep, Duration};
use uuid::Uuid;
use validator::ValidationError;

/// Generates a list of keypairs from provided private keys
///
/// # Arguments
/// * `number_of_threads` - Number of keypairs to generate
/// * `private_keys` - Array of private key strings to generate keypairs from
pub async fn generate_keygen_list(number_of_threads: i32, private_keys: &[String]) -> Vec<Keypair> {
    let mut keypairs = Vec::new();

    for i in 0..number_of_threads {
        keypairs.push(create_keypair(&private_keys[i as usize]));
    }

    keypairs
}

/// Creates a keypair from a private key string
///
/// # Arguments
/// * `private_key` - Private key as a hex string
pub fn create_keypair(private_key: &String) -> Keypair {
    let bytes = hex::decode(private_key).expect("Failed to decode hex string");
    let byte_array: [u8; 32] = bytes.try_into().expect("Slice with incorrect length");
    Keypair::from_secret_key(byte_array)
        .unwrap_or_else(|_| panic!("Fatal: Couldn't parse the private key {:?}", private_key))
}

/// Formats a byte size into a human readable string with appropriate units
///
/// # Arguments
/// * `bytes` - Size in bytes to format
pub fn format_size(bytes: usize) -> String {
    const UNITS: [&str; 6] = ["B", "KB", "MB", "GB", "TB", "PB"];
    let mut size = bytes as f64;
    let mut unit_index = 0;

    while size >= 1024.0 && unit_index < UNITS.len() - 1 {
        size /= 1024.0;
        unit_index += 1;
    }

    format!("{:.2} {}", size, UNITS[unit_index])
}

/// Generates a new UUID v4 for submission identification
pub fn generate_submission_id() -> Uuid {
    Uuid::new_v4()
}

/// Validates if a string is a valid Ethereum address
///
/// # Arguments
/// * `address` - Address string to validate
pub fn is_valid_ethereum_address(address: &str) -> Result<(), ValidationError> {
    match Address::from_str(address) {
        Ok(_) => Ok(()),
        Err(_) => Err(ValidationError::new("Invalid Ethereum address")),
    }
}

/// Gets a database connection from the connection pool
///
/// # Arguments
/// * `pool` - Database connection pool
pub async fn get_connection(
    pool: &web::Data<Pool<AsyncPgConnection>>,
) -> Result<Object<AsyncPgConnection>, HttpResponse> {
    match pool.get().await {
        Ok(conn) => Ok(conn),
        Err(err) => {
            tracing::error!("Failed to get a database connection: {}", err);
            return Err(HttpResponse::InternalServerError().json(json!({
                "state": "ERROR",
                "error": "Database connection error"
            })));
        }
    }
}

/// Retrieves user ID from HTTP request headers
///
/// # Arguments
/// * `http_request` - HTTP request to extract user ID from
pub fn retrieve_user_id(http_request: &HttpRequest) -> Option<String> {
    let headers = http_request.headers();

    for (name, value) in headers.iter() {
        if name == "user_id" {
            if let Ok(user_id) = value.to_str() {
                return Some(user_id.to_string());
            }
        }
    }
    None
}
/// Retrieves user ID from JWT in HTTP request
///
/// # Arguments
/// * `http_request` - HTTP request containing JWT with user ID
///
/// # Returns
/// * `Option<String>` - User ID if found in JWT, None otherwise
pub fn retrieve_user_id_from_jwt(http_request: &HttpRequest) -> Option<String> {
    let jwt = http_request.extensions().get::<ClerkJwt>().cloned();
    if let Some(jwt) = jwt {
        jwt.other
            .get("user_email")
            .map(|id| id.to_string().trim_matches('"').to_string())
    } else {
        None
    }
}

/// Retrieves email address from HTTP request headers
///
/// # Arguments
/// * `http_request` - HTTP request to extract email from
pub fn retrieve_email_address(http_request: &HttpRequest) -> Option<String> {
    let headers = http_request.headers();

    for (name, value) in headers.iter() {
        if name == "user_email" {
            if let Ok(user_email) = value.to_str() {
                return Some(user_email.to_string());
            }
        }
    }
    None
}

#[derive(Serialize, Deserialize, Debug, Clone)]
pub struct Price {
    pub btc: Option<f64>,
    pub btc_market_cap: Option<f64>,
    pub eth: Option<f64>,
    pub usd: Option<f64>,
}

/// Gets current prices for Avail and specified token from CoinGecko API
///
/// # Arguments
/// * `client` - HTTP client for making requests
/// * `coingecko_api_url` - CoinGecko API URL
/// * `coingecko_api_key` - CoinGecko API key
/// * `token` - Token to get price for
pub async fn get_prices(
    client: &Client,
    coingecko_api_url: &str,
    coingecko_api_key: &str,
    token: &str,
) -> Result<(f64, f64), String> {
    let params = [
        ("ids", format!("avail,{}", token)),
        ("vs_currencies", "usd".to_string()),
    ];

    let response = client
        .get(coingecko_api_url)
        .query(&params)
        .header("accept", "application/json")
        .header("x-cg-pro-api-key", coingecko_api_key)
        .send()
        .await
        .map_err(|e| e.to_string())?;

    let json = response
        .json::<HashMap<String, Price>>()
        .await
        .map_err(|e| e.to_string())?;

    let coin_price = match json.get(token) {
        Some(val) => val.usd.ok_or_else(|| price_not_found_error(token))?,
        None => {
            let msg = price_not_found_error(token);
            return Err(msg);
        }
    };

    let avail_price = match json.get("avail") {
        Some(val) => val.usd.ok_or_else(|| price_not_found_error("avail"))?,
        None => {
            let msg = price_not_found_error("avail");
            return Err(msg);
        }
    };

    Ok((coin_price, avail_price))
}

pub struct Convertor<'a> {
    pub sdk: &'a AvailClient,
    pub account: &'a Keypair,
    pub one_kb: Vec<u8>,
}

impl<'a> Convertor<'a> {
    pub fn new(sdk: &'a AvailClient, account: &'a Keypair) -> Self {
        Convertor {
            sdk,
            account,
            one_kb: vec![0u8; 1024],
        }
    }
    pub async fn get_gas_price_for_data(&self, data: Vec<u8>) -> BigDecimal {
        let tx = self.sdk.tx().data_availability().submit_data(data);

        let options = Options::default();
        let query_info = match tx
            .estimate_extrinsic_fees(self.account, options, None)
            .await
        {
            Ok(info) => info,
            Err(e) => {
                tracing::error!(error = ?e, "failed to get payment query info");
                return BigDecimal::from(u128::MAX);
            }
        };
        BigDecimal::from(query_info.final_fee())
    }

    pub async fn calculate_credit_utlisation(&self, data: Vec<u8>) -> BigDecimal {
        let data_posted_amount = data.len() as u128;

        if data_posted_amount < self.one_kb.len() as u128 {
            return BigDecimal::from(self.one_kb.len() as u128);
        }

        // (1KB_fee / data_posted_fee) * data_posted_amount = data_billed
        let one_kb_fee = self.get_gas_price_for_data(self.one_kb.clone()).await;
        let data_posted_fee = self.get_gas_price_for_data(data).await;

        one_kb_fee / data_posted_fee * BigDecimal::from(data_posted_amount as u128)
    }
}

/// Token information structure
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Token {
    pub name: String,
    pub symbol: String,
    pub address: String,
    pub decimals: u32,
    pub coin_gecho_id: String,
}

lazy_static! {
    pub static ref TOKEN_MAP: HashMap<u32, HashMap<String, Token>> = {
        let mut m = HashMap::new();
        let mut chain_map = HashMap::new();

        chain_map.insert(
            "0x0000000000000000000000000000000000000000".to_lowercase(),
            Token {
                address: "0x0000000000000000000000000000000000000000".to_lowercase(),
                decimals: 18,
                name: "Ether".to_string(),
                symbol: "ETH".to_string(),
                coin_gecho_id: "ethereum".to_string(),
            },
        );
        chain_map.insert(
            "0xf50f2b4d58ce2a24b62e480d795a974ed0f77a58".to_lowercase(),
            Token {
                address: "0xf50f2b4d58ce2a24b62e480d795a974ed0f77a58".to_lowercase(),
                decimals: 18,
                name: "Avail".to_string(),
                symbol: "AVAIL".to_string(),
                coin_gecho_id: "avail".to_string(),
            },
        );
        chain_map.insert(
            "0x036CbD53842c5426634e7929541eC2318f3dCF7e".to_lowercase(),
            Token {
                address: "0x036CbD53842c5426634e7929541eC2318f3dCF7e".to_lowercase(),
                decimals: 6,
                name: "USDC".to_string(),
                symbol: "USDC".to_string(),
                coin_gecho_id: "usd-coin".to_string(),
            },
        );
        m.insert(84532, chain_map.clone());

        chain_map.clear();

        chain_map.insert(
            "0x0000000000000000000000000000000000000000".to_lowercase(),
            Token {
                address: "0x0000000000000000000000000000000000000000".to_lowercase(),
                decimals: 18,
                name: "Ether".to_string(),
                symbol: "ETH".to_string(),
                coin_gecho_id: "ethereum".to_string(),
            },
        );

        chain_map.insert(
            "0xfde4C96c8593536E31F229EA8f37b2ADa2699bb2".to_lowercase(),
            Token {
                address: "0xfde4C96c8593536E31F229EA8f37b2ADa2699bb2".to_lowercase(),
                decimals: 6,
                name: "USDT".to_string(),
                symbol: "USDT".to_string(),
                coin_gecho_id: "tether".to_string(),
            },
        );

        chain_map.insert(
            "0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913".to_lowercase(),
            Token {
                address: "0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913".to_lowercase(),
                decimals: 6,
                name: "USDC".to_string(),
                symbol: "USDC".to_string(),
                coin_gecho_id: "usd-coin".to_string(),
            },
        );

        chain_map.insert(
            "0xd89d90d26b48940fa8f58385fe84625d468e057a".to_lowercase(),
            Token {
                address: "0xd89d90d26b48940fa8f58385fe84625d468e057a".to_lowercase(),
                decimals: 18,
                name: "Avail".to_string(),
                symbol: "AVAIL".to_string(),
                coin_gecho_id: "avail".to_string(),
            },
        );
        m.insert(8453, chain_map.clone());

        chain_map.clear();
        chain_map.insert(
            "0x0000000000000000000000000000000000000000".to_lowercase(),
            Token {
                address: "0x0000000000000000000000000000000000000000".to_lowercase(),
                decimals: 18,
                name: "Avail".to_string(),
                symbol: "AVAIL".to_string(),
                coin_gecho_id: "avail".to_string(),
            },
        );
        m.insert(0, chain_map);
        m
    };
}

const WAIT_TIME: u64 = 5;
pub async fn generate_avail_sdk(endpoints: &Arc<Vec<String>>) -> AvailClient {
    let mut attempts = 0;

    loop {
        if attempts >= endpoints.len() {
            attempts = 0;
        }
        let endpoint = &endpoints[attempts];
        tracing::info!(endpoint = ?endpoint, "attempting to connect endpoint");
        match AvailClient::new(endpoint).await {
            Ok(sdk) => {
                tracing::info!(endpoint = %endpoint, "connected successfully to endpoint");
                return sdk;
            }
            Err(e) => {
                tracing::error!(
                    error = ?e,
                    endpoint = %endpoint,
                    "failed to connect to endpoint"
                );
                attempts += 1;
            }
        }

        tracing::warn!("all endpoints failed, waiting 5 seconds before next retry");
        sleep(Duration::from_secs(WAIT_TIME)).await;
    }
}

/// Retrieves user ID from HTTP request headers
///
/// # Arguments
/// * `http_request` - HTTP request to extract user ID from
pub fn retrieve_account_id(http_request: &HttpRequest) -> Option<Uuid> {
    let headers = http_request.headers();

    for (name, value) in headers.iter() {
        if name == "account_id" {
            if let Ok(account_id) = value.to_str() {
                return Uuid::parse_str(account_id).ok();
            }
        }
    }
    None
}

fn price_not_found_error(token: &str) -> String {
    format!("{:?} price not found from coingecho", token)
}

const AVAIL_TOKEN_DECIMALS: usize = 18_usize;

pub async fn calculate_avail_token_equivalent(
    coingecko_api_url: &str,
    coingecko_api_key: &str,
    token_amount: &BigDecimal,
    chain: &u32,
    token_address: &str,
) -> Result<BigDecimal, String> {
    let http_client = Client::new();

    tracing::debug!(token_address = %token_address, "token address");

    let token_info = TOKEN_MAP
        .get(chain)
        .ok_or("Invalid Chainid")?
        .get(token_address)
        .ok_or("Invalid Token Address")?;

    let (token_usd_price, avail_usd_price) = get_prices(
        &http_client,
        &coingecko_api_url,
        &coingecko_api_key,
        token_info.coin_gecho_id.as_str(),
    )
    .await
    .map_err(|e| format!("Failed to fetch prices for {}: {}", token_info.symbol, e))?;

    let token_avail_ratio = token_usd_price / avail_usd_price;

    let equivalent_amount;
    if token_info.name == "Avail" {
        let token_avail_ratio_decimal =
            BigDecimal::from_str(token_avail_ratio.to_string().as_str())
                .map_err(|e| format!("Failed to convert price ratio to decimal: {}", e))?;

        equivalent_amount = token_amount * token_avail_ratio_decimal;
    } else {
        tracing::debug!(token_usd_price = %token_usd_price, "current token usd price");
        tracing::debug!(avail_usd_price = %avail_usd_price, "current avail usd price");

        let token_avail_ratio_decimal =
            BigDecimal::from_str(token_avail_ratio.to_string().as_str())
                .map_err(|e| format!("Failed to convert price ratio to decimal: {}", e))?;

        equivalent_amount = token_avail_ratio_decimal
            * token_amount
            * BigDecimal::from(10_u64.pow(AVAIL_TOKEN_DECIMALS as u32))
            / BigDecimal::from(10_u64.pow(token_info.decimals as u32));
    };

    Ok(equivalent_amount.round(0))
}

pub async fn get_amount_to_be_credited(
    coin_gecho_api_url: &String,
    coin_gecho_api_key: &String,
    avail_rpc_url: &String,
    chain: &u32,
    address: &String,
    amount: &BigDecimal,
) -> Result<BigDecimal, String> {
    let price = calculate_avail_token_equivalent(
        &coin_gecho_api_url,
        &coin_gecho_api_key,
        &amount,
        &chain,
        &address,
    )
    .await
    .map_err(|e| format!("Failed to get price for {}: {}", address, e))?;

    let client = AvailClient::new(avail_rpc_url)
        .await
        .map_err(|e| format!("Failed to create SDK client: {:?}", e))?;

    let account = dev_accounts::alice();
    let converter = Convertor::new(&client, &account);
    let price_per_kb = converter
        .get_gas_price_for_data(converter.one_kb.clone())
        .await;

    Ok((price / price_per_kb * BigDecimal::from(converter.one_kb.len() as u128)).round(3))
}
