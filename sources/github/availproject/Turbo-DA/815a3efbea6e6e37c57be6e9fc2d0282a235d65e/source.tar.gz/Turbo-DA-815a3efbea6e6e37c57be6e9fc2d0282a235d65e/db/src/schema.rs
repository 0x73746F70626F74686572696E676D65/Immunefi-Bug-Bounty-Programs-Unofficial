// @generated automatically by Diesel CLI.

diesel::table! {
    api_keys (api_key) {
        #[max_length = 255]
        api_key -> Varchar,
        created_at -> Timestamp,
        #[max_length = 255]
        user_id -> Varchar,
        #[max_length = 255]
        identifier -> Varchar,
        app_id -> Uuid,
    }
}

diesel::table! {
    apps (id) {
        id -> Uuid,
        user_id -> Varchar,
        app_id -> Int4,
        app_name -> Nullable<Varchar>,
        app_description -> Nullable<Varchar>,
        app_logo -> Nullable<Varchar>,
        credit_balance -> Numeric,
        credit_used -> Numeric,
        fallback_credit_used -> Numeric,
        metadata_path -> Nullable<Varchar>,
        created_at -> Timestamptz,
        updated_at -> Timestamptz,
        credit_selection -> Nullable<Int2>,
        encryption -> Bool,
        barred -> Bool,
    }
}

diesel::table! {
    credit_requests (id) {
        id -> Int4,
        user_id -> Varchar,
        amount_credit -> Nullable<Numeric>,
        chain_id -> Nullable<Int4>,
        #[max_length = 50]
        request_status -> Varchar,
        created_at -> Timestamp,
        tx_hash -> Nullable<Varchar>,
        #[max_length = 50]
        request_type -> Varchar,
        app_id -> Nullable<Uuid>,
        updated_at -> Timestamp,
        #[max_length = 255]
        token_address -> Nullable<Varchar>,
        amount_paid -> Nullable<Numeric>,
    }
}

diesel::table! {
    customer_expenditures (id) {
        id -> Uuid,
        user_id -> Varchar,
        amount_data -> Varchar,
        fees -> Nullable<Numeric>,
        converted_fees -> Nullable<Numeric>,
        to_address -> Nullable<Varchar>,
        block_number -> Nullable<Int4>,
        block_hash -> Nullable<Varchar>,
        extrinsic_index -> Nullable<Int4>,
        data_hash -> Nullable<Varchar>,
        tx_hash -> Nullable<Varchar>,
        created_at -> Timestamp,
        retry_count -> Int4,
        error -> Nullable<Varchar>,
        payload -> Nullable<Bytea>,
        updated_at -> Timestamp,
        app_id -> Uuid,
        wallet -> Nullable<Bytea>,
        ciphertext_hash -> Nullable<Bytea>,
        plaintext_hash -> Nullable<Bytea>,
        signature_ciphertext_hash -> Nullable<Bytea>,
        signature_plaintext_hash -> Nullable<Bytea>,
        address -> Nullable<Bytea>,
        ephemeral_pub_key -> Nullable<Bytea>,
    }
}

diesel::table! {
    indexer_block_numbers (id) {
        id -> Int4,
        chain_id -> Int4,
        block_number -> Int4,
        block_hash -> Varchar,
        created_at -> Timestamp,
    }
}

diesel::table! {
    mpc_participants (id) {
        id -> Uuid,
        app_id -> Uuid,
        participant_address -> Varchar,
        created_at -> Timestamp,
    }
}

diesel::table! {
    public_keys (id) {
        id -> Uuid,
        user_id -> Varchar,
        public_address -> Varchar,
        created_at -> Timestamp,
    }
}

diesel::table! {
    users (id) {
        id -> Varchar,
        name -> Varchar,
        credit_balance -> Numeric,
        credit_used -> Numeric,
        allocated_credit_balance -> Numeric,
        sumsub_timestamp -> Nullable<Timestamp>,
    }
}

diesel::joinable!(api_keys -> apps (app_id));
diesel::joinable!(api_keys -> users (user_id));
diesel::joinable!(apps -> users (user_id));
diesel::joinable!(credit_requests -> apps (app_id));
diesel::joinable!(credit_requests -> users (user_id));
diesel::joinable!(customer_expenditures -> apps (app_id));
diesel::joinable!(customer_expenditures -> users (user_id));
diesel::joinable!(mpc_participants -> apps (app_id));
diesel::joinable!(public_keys -> users (user_id));

diesel::allow_tables_to_appear_in_same_query!(
    api_keys,
    apps,
    credit_requests,
    customer_expenditures,
    indexer_block_numbers,
    mpc_participants,
    public_keys,
    users,
);
