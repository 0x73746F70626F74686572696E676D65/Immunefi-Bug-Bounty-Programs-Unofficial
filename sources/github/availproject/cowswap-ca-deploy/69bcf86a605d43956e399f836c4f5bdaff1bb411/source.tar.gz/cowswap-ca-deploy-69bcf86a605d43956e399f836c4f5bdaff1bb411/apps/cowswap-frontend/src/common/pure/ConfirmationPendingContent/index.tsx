export { ConfirmationPendingContent } from './ConfirmationPendingContent'
