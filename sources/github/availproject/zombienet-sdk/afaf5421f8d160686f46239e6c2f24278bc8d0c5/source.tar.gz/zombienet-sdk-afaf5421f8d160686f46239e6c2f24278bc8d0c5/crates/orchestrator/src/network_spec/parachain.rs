use std::{
    collections::{HashMap, HashSet},
    path::PathBuf,
};

use configuration::{
    shared::{helpers::generate_unique_node_name_from_names, resources::Resources},
    types::{Arg, AssetLocation, Chain, Command, Image, JsonOverrides},
    NodeConfig, ParachainConfig, RegistrationStrategy,
};
use provider::DynNamespace;
use serde::{Deserialize, Serialize};
use support::{fs::FileSystem, replacer::apply_replacements};
use tracing::debug;

use super::node::NodeSpec;
use crate::{
    errors::OrchestratorError,
    generators::{
        chain_spec::{ChainSpec, Context, ParaGenesisConfig},
        para_artifact::*,
    },
    shared::{constants::DEFAULT_CHAIN_SPEC_TPL_COMMAND, types::ChainDefaultContext},
    ScopedFilesystem,
};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ParachainSpec {
    // `name` of the parachain (used in some corner cases)
    // name: Option<Chain>,
    /// Parachain id
    pub(crate) id: u32,

    /// Unique id of the parachain, in the patter of <para_id>-<n>
    /// where the suffix is only present if more than one parachain is set with the same id
    pub(crate) unique_id: String,

    /// Default command to run the node. Can be overridden on each node.
    pub(crate) default_command: Option<Command>,

    /// Default image to use (only podman/k8s). Can be overridden on each node.
    pub(crate) default_image: Option<Image>,

    /// Default resources. Can be overridden on each node.
    pub(crate) default_resources: Option<Resources>,

    /// Default database snapshot. Can be overridden on each node.
    pub(crate) default_db_snapshot: Option<AssetLocation>,

    /// Default arguments to use in nodes. Can be overridden on each node.
    pub(crate) default_args: Vec<Arg>,

    /// Chain-spec, only needed by cumulus based paras
    pub(crate) chain_spec: Option<ChainSpec>,

    /// Do not automatically assign a bootnode role if no nodes are marked as bootnodes.
    pub(crate) no_default_bootnodes: bool,

    /// Registration strategy to use
    pub(crate) registration_strategy: RegistrationStrategy,

    /// Number of cores to assign at genesis
    pub(crate) num_cores: Option<u32>,

    /// Onboard as parachain or parathread
    pub(crate) onboard_as_parachain: bool,

    /// Is the parachain cumulus-based
    pub(crate) is_cumulus_based: bool,

    /// Is the parachain evm-based
    pub(crate) is_evm_based: bool,

    /// Initial balance
    pub(crate) initial_balance: u128,

    /// Genesis state (head) to register the parachain
    pub(crate) genesis_state: ParaArtifact,

    /// Genesis WASM to register the parachain
    pub(crate) genesis_wasm: ParaArtifact,

    /// Genesis overrides as JSON value.
    pub(crate) genesis_overrides: Option<serde_json::Value>,

    /// Wasm override path/url to use.
    pub(crate) wasm_override: Option<AssetLocation>,

    /// Collators to spawn
    pub(crate) collators: Vec<NodeSpec>,

    /// Raw chain-spec override path, url or inline json to use.
    pub(crate) raw_spec_override: Option<JsonOverrides>,

    /// Bootnodes addresses to use for the parachain nodes
    pub(crate) bootnodes_addresses: Vec<multiaddr::Multiaddr>,
    /// Optional post-process script configured for this parachain
    pub(crate) post_process_script: Option<String>,
}

impl ParachainSpec {
    pub fn from_config(
        config: &ParachainConfig,
        relay_chain: Chain,
    ) -> Result<ParachainSpec, OrchestratorError> {
        let main_cmd = if let Some(cmd) = config.default_command() {
            cmd
        } else if let Some(first_node) = config.collators().first() {
            let Some(cmd) = first_node.command() else {
                return Err(OrchestratorError::InvalidConfig(format!("Parachain {}, either default_command or command in the first node needs to be set.", config.id())));
            };

            cmd
        } else {
            return Err(OrchestratorError::InvalidConfig(format!(
                "Parachain {}, without nodes and default_command isn't set.",
                config.id()
            )));
        };

        // TODO: internally we use image as String
        let main_image = config
            .default_image()
            .or(config.collators().first().and_then(|node| node.image()))
            .map(|image| image.as_str().to_string());

        let chain_spec = if config.is_cumulus_based() {
            // we need a chain-spec
            let chain_name = if let Some(chain_name) = config.chain() {
                chain_name.as_str()
            } else {
                ""
            };

            let chain_spec_builder = if chain_name.is_empty() {
                // if the chain don't have name use the unique_id for the name of the file
                ChainSpec::new(
                    config.unique_id().to_string(),
                    Context::Para {
                        relay_chain,
                        para_id: config.id(),
                    },
                )
            } else {
                let chain_spec_file_name = if config.unique_id().contains('-') {
                    &format!("{}-{}", chain_name, config.unique_id())
                } else {
                    chain_name
                };
                ChainSpec::new(
                    chain_spec_file_name,
                    Context::Para {
                        relay_chain,
                        para_id: config.id(),
                    },
                )
            };
            let chain_spec_builder = chain_spec_builder.set_chain_name(chain_name);

            let replacements = HashMap::from([
                ("disableBootnodes", "--disable-default-bootnode"),
                ("mainCommand", main_cmd.as_str()),
            ]);
            let tmpl = if let Some(tmpl) = config.chain_spec_command() {
                apply_replacements(tmpl, &replacements)
            } else {
                apply_replacements(DEFAULT_CHAIN_SPEC_TPL_COMMAND, &replacements)
            };

            let chain_spec = chain_spec_builder
                .command(
                    tmpl.as_str(),
                    config.chain_spec_command_is_local(),
                    config.chain_spec_command_output_path(),
                )
                .image(main_image.clone());

            let chain_spec = if let Some(chain_spec_path) = config.chain_spec_path() {
                chain_spec.asset_location(chain_spec_path.clone())
            } else {
                chain_spec
            };

            // add chain-spec runtime if present
            let chain_spec = if let Some(chain_spec_runtime) = config.chain_spec_runtime() {
                chain_spec.runtime(chain_spec_runtime.clone())
            } else {
                chain_spec
            };

            Some(chain_spec)
        } else {
            None
        };

        // build the `node_specs`
        let chain_context = ChainDefaultContext {
            default_command: config.default_command(),
            default_image: config.default_image(),
            default_resources: config.default_resources(),
            default_db_snapshot: config.default_db_snapshot(),
            default_args: config.default_args(),
        };

        // We want to track the errors for all the nodes and report them ones
        let mut errs: Vec<OrchestratorError> = Default::default();
        let mut collators: Vec<NodeSpec> = Default::default();

        let mut nodes: Vec<NodeConfig> = config.collators().into_iter().cloned().collect();
        nodes.extend(
            config
                .group_collators_configs()
                .into_iter()
                .flat_map(|node_group| node_group.expand_group_configs()),
        );

        let mut names = HashSet::new();
        for node_config in nodes {
            match NodeSpec::from_config(&node_config, &chain_context, true, config.is_evm_based()) {
                Ok(mut node) => {
                    let unique_name = generate_unique_node_name_from_names(node.name, &mut names);
                    node.name = unique_name;
                    collators.push(node)
                },
                Err(err) => errs.push(err),
            }
        }
        // Precedence when deciding the genesis state artifact: path -> generator -> default command
        let genesis_state = if let Some(path) = config.genesis_state_path() {
            ParaArtifact::new(
                ParaArtifactType::State,
                ParaArtifactBuildOption::Path(path.to_string()),
            )
        } else if let Some(cmd) = config.genesis_state_generator() {
            ParaArtifact::new(
                ParaArtifactType::State,
                ParaArtifactBuildOption::CommandWithCustomArgs(cmd.clone()),
            )
            .image(main_image.clone())
        } else {
            ParaArtifact::new(
                ParaArtifactType::State,
                ParaArtifactBuildOption::Command(main_cmd.as_str().into()),
            )
            .image(main_image.clone())
        };

        debug!(
            "Parachain {} genesis state artifact: {:?}",
            config.id(),
            genesis_state
        );

        let genesis_wasm = if let Some(path) = config.genesis_wasm_path() {
            ParaArtifact::new(
                ParaArtifactType::Wasm,
                ParaArtifactBuildOption::Path(path.to_string()),
            )
        } else {
            let cmd = if let Some(cmd) = config.genesis_wasm_generator() {
                cmd.as_str()
            } else {
                main_cmd.as_str()
            };
            ParaArtifact::new(
                ParaArtifactType::Wasm,
                ParaArtifactBuildOption::Command(cmd.into()),
            )
            .image(main_image.clone())
        };

        let para_spec = ParachainSpec {
            id: config.id(),
            // ensure unique id is set at this point, if not just set to the para_id
            unique_id: if config.unique_id().is_empty() {
                config.id().to_string()
            } else {
                config.unique_id().to_string()
            },
            default_command: config.default_command().cloned(),
            default_image: config.default_image().cloned(),
            default_resources: config.default_resources().cloned(),
            default_db_snapshot: config.default_db_snapshot().cloned(),
            wasm_override: config.wasm_override().cloned(),
            default_args: config.default_args().into_iter().cloned().collect(),
            chain_spec,
            no_default_bootnodes: config.no_default_bootnodes(),
            num_cores: config.num_cores(),
            registration_strategy: config
                .registration_strategy()
                .unwrap_or(&RegistrationStrategy::InGenesis)
                .clone(),
            onboard_as_parachain: config.onboard_as_parachain(),
            is_cumulus_based: config.is_cumulus_based(),
            is_evm_based: config.is_evm_based(),
            initial_balance: config.initial_balance(),
            genesis_state,
            genesis_wasm,
            genesis_overrides: config.genesis_overrides().cloned(),
            collators,
            raw_spec_override: config.raw_spec_override().cloned(),
            bootnodes_addresses: config.bootnodes_addresses().into_iter().cloned().collect(),
            post_process_script: config.post_process_script().map(str::to_string),
        };

        Ok(para_spec)
    }

    pub fn registration_strategy(&self) -> &RegistrationStrategy {
        &self.registration_strategy
    }

    pub fn get_genesis_config(&self) -> Result<ParaGenesisConfig<&PathBuf>, OrchestratorError> {
        let genesis_config = ParaGenesisConfig {
            state_path: self.genesis_state.artifact_path().ok_or(
                OrchestratorError::InvariantError(
                    "artifact path for state must be set at this point",
                ),
            )?,
            wasm_path: self.genesis_wasm.artifact_path().ok_or(
                OrchestratorError::InvariantError(
                    "artifact path for wasm must be set at this point",
                ),
            )?,
            id: self.id,
            as_parachain: self.onboard_as_parachain,
        };
        Ok(genesis_config)
    }

    pub fn id(&self) -> u32 {
        self.id
    }

    pub fn chain_spec(&self) -> Option<&ChainSpec> {
        self.chain_spec.as_ref()
    }

    pub fn chain_spec_mut(&mut self) -> Option<&mut ChainSpec> {
        self.chain_spec.as_mut()
    }

    /// Build parachain chain-spec
    ///
    /// This function customize the chain-spec (if is possible) and build the raw version
    /// of the chain-spec.
    pub(crate) async fn build_chain_spec<'a, T>(
        &mut self,
        relay_chain_id: &str,
        ns: &DynNamespace,
        scoped_fs: &ScopedFilesystem<'a, T>,
        post_process_script: Option<&str>,
    ) -> Result<Option<PathBuf>, anyhow::Error>
    where
        T: FileSystem,
    {
        let cloned = self.clone();
        let chain_spec_raw_path = if let Some(chain_spec) = self.chain_spec.as_mut() {
            debug!("parachain chain-spec building!");
            chain_spec.build(ns, scoped_fs).await?;
            debug!("parachain chain-spec built!");

            chain_spec
                .customize_para(&cloned, relay_chain_id, scoped_fs)
                .await?;
            debug!("parachain chain-spec customized!");
            // Run post-process script if configured for this parachain (run against plain spec before building raw)
            if let Some(script_cmd) = post_process_script {
                chain_spec
                    .run_post_process_script(script_cmd, scoped_fs)
                    .await?;
            }

            chain_spec
                .build_raw(ns, scoped_fs, Some(relay_chain_id.try_into()?))
                .await?;
            debug!("parachain chain-spec raw built!");

            // override wasm if needed
            if let Some(ref wasm_override) = self.wasm_override {
                chain_spec.override_code(scoped_fs, wasm_override).await?;
            }

            // override raw spec if needed
            if let Some(ref raw_spec_override) = self.raw_spec_override {
                chain_spec
                    .override_raw_spec(scoped_fs, raw_spec_override)
                    .await?;
            }

            let chain_spec_raw_path =
                chain_spec
                    .raw_path()
                    .ok_or(OrchestratorError::InvariantError(
                        "chain-spec raw path should be set now",
                    ))?;

            Some(chain_spec_raw_path.to_path_buf())
        } else {
            None
        };
        Ok(chain_spec_raw_path)
    }

    /// Get the bootnodes addresses for the parachain spec
    pub(crate) fn bootnodes_addresses(&self) -> Vec<&multiaddr::Multiaddr> {
        self.bootnodes_addresses.iter().collect()
    }
}
