// Copyright 2020-2024 SubQuery Pte Ltd authors & contributors
// SPDX-License-Identifier: GPL-3.0

import {Injectable} from '@nestjs/common';
import {Pool} from 'pg';
import {Config} from '../configure';

@Injectable()
export class ProjectService {
  constructor(private readonly pool: Pool, private readonly config: Config) {}

  async getProjectSchema(name: string): Promise<string> {
    // After subqueries table has been deprecated, project may not be present in subqueries table
    const result = await this.pool
      .query<{schema_name: string}, any[]>(`SELECT schema_name FROM information_schema.schemata`)
      .then((obj) => obj.rows.map((x) => x.schema_name))
      .catch((e) => {
        throw new Error(`Unable to fetch all database schemas: ${e}`);
      });
    if (result.includes(name)) {
      return name;
    } else {
      // fallback to subqueries table
      const {rows} = await this.pool.query(
        `SELECT *
        FROM public.subqueries
        WHERE name = $1`,
        [name]
      );
      if (rows.length === 0) {
        throw new Error(`unknown project name ${this.config.get('name')}`);
      }
      return rows[0].db_schema;
    }
  }
}
