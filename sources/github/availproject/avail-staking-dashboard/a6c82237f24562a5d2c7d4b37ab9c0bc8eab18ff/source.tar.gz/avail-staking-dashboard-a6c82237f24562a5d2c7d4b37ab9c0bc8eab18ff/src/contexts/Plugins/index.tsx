// Copyright 2024 @polkadot-cloud/polkadot-staking-dashboard authors & contributors
// SPDX-License-Identifier: GPL-3.0-only

import { isNotZero, setStateWithRef } from '@w3ux/utils';
import type { ReactNode } from 'react';
import { createContext, useContext, useRef, useState } from 'react';
import type { Plugin } from 'config/plugins';
import * as defaults from './defaults';
import type { PluginsContextInterface } from './types';
import { useEffectIgnoreInitial } from '@w3ux/hooks';
import { useApi } from 'contexts/Api';
import { useNetwork } from 'contexts/Network';
import { useActiveAccounts } from 'contexts/ActiveAccounts';
import { SubscanController } from 'controllers/Subscan';
import { getAvailablePlugins } from './Utils';

export const PluginsContext = createContext<PluginsContextInterface>(
  defaults.defaultPluginsContext
);

export const usePlugins = () => useContext(PluginsContext);

export const PluginsProvider = ({ children }: { children: ReactNode }) => {
  const { network, networkData } = useNetwork();
  const { isReady, activeEra } = useApi();
  const { activeAccount } = useActiveAccounts();

  // Store the currently active plugins.
  const [plugins, setPlugins] = useState<Plugin[]>(getAvailablePlugins());
  const pluginsRef = useRef(plugins);

  // Toggle a plugin.
  const togglePlugin = (key: Plugin) => {
    let localPlugins = [...plugins];
    const found = localPlugins.find((p) => p === key);

    if (found) {
      localPlugins = localPlugins.filter((p) => p !== key);
    } else {
      localPlugins.push(key);
    }

    localStorage.setItem('plugins', JSON.stringify(localPlugins));
    setStateWithRef(localPlugins, setPlugins, pluginsRef);
  };

  // Check if a plugin is currently enabled.
  const pluginEnabled = (key: Plugin) => pluginsRef.current.includes(key);

  // Reset payouts on Subscan plugin not enabled. Otherwise fetch payouts.
  useEffectIgnoreInitial(() => {
    if (!plugins.includes('subscan') || !networkData.subscanPrefix) {
      SubscanController.resetData();
      if (plugins.includes('subscan')) {
        togglePlugin('subscan');
      }
    } else if (isReady && isNotZero(activeEra.index)) {
      SubscanController.network = networkData.subscanPrefix;
      if (activeAccount) {
        SubscanController.handleFetchPayouts(activeAccount);
      }
    }
  }, [plugins.includes('subscan'), isReady, network, activeAccount, activeEra]);

  return (
    <PluginsContext.Provider
      value={{
        togglePlugin,
        pluginEnabled,
        plugins: pluginsRef.current,
      }}
    >
      {children}
    </PluginsContext.Provider>
  );
};
