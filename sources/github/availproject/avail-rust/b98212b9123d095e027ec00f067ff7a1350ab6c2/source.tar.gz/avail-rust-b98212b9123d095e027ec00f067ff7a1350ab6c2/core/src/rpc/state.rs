use super::Error;
use codec::Decode;
use primitive_types::H256;
use subxt_metadata::Metadata;
use subxt_rpcs::{RpcClient, methods::legacy::RuntimeVersion, rpc_params};

pub async fn call(client: &RpcClient, method: &str, data: &[u8], at: Option<H256>) -> Result<String, Error> {
	let data = std::format!("0x{}", const_hex::encode(data));
	let params = rpc_params![method, data, at];
	let value = client.request("state_call", params).await?;
	Ok(value)
}

pub async fn get_metadata(client: &RpcClient, at: Option<H256>) -> Result<Metadata, Error> {
	let res: Vec<u8> = get_metadata_bytes(client, at).await?;
	let mut slice = res.as_slice();
	let metadata = Metadata::decode(&mut slice);
	metadata.map_err(|e| Error::DecodingFailed(e.to_string()))
}

pub async fn get_storage(client: &RpcClient, key: &str, at: Option<H256>) -> Result<Option<Vec<u8>>, Error> {
	let params = rpc_params![key, at];
	let value: Option<String> = client.request("state_getStorage", params).await?;
	let Some(value) = value else {
		return Ok(None);
	};
	let value = const_hex::decode(value.trim_start_matches("0x"));
	let value = value.map_err(Error::from)?;
	Ok(Some(value))
}

pub async fn get_keys_paged(
	client: &RpcClient,
	prefix: Option<&str>,
	count: u32,
	start_key: Option<&str>,
	at: Option<H256>,
) -> Result<Vec<String>, Error> {
	let params = rpc_params![prefix, count, start_key, at];
	let value: Vec<String> = client.request("state_getKeysPaged", params).await?;
	Ok(value)
}

pub async fn get_metadata_bytes(client: &RpcClient, at: Option<H256>) -> Result<Vec<u8>, Error> {
	let value: String = client.request("state_getMetadata", rpc_params![at]).await?;
	let value = const_hex::decode(value.trim_start_matches("0x"));
	let value = value.map_err(Error::from)?;
	Ok(value)
}

pub async fn get_runtime_version(client: &RpcClient, at: Option<H256>) -> Result<RuntimeVersion, Error> {
	let value = client.request("state_getRuntimeVersion", rpc_params![at]).await?;
	Ok(value)
}
