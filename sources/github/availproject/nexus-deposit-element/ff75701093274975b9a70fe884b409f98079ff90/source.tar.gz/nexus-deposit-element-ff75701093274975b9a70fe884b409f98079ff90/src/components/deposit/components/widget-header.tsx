"use client";

import { ConnectButton } from "@rainbow-me/rainbowkit";
import { CloseIcon, LeftChevronIcon, UnplugIcon } from "./icons";

interface WidgetHeaderProps {
  title: string;
  depositTargetLogo?: string;
  onBack?: () => void;
  onClose?: () => void;
}

const WidgetHeader = ({
  title,
  onBack,
  onClose,
  depositTargetLogo,
}: WidgetHeaderProps) => {
  const renderWalletButton = () => (
    <ConnectButton.Custom>
      {({
        account,
        chain,
        mounted,
        authenticationStatus,
        openAccountModal,
        openConnectModal,
      }) => {
        const ready = mounted && authenticationStatus !== "loading";
        const connected =
          ready &&
          Boolean(account) &&
          Boolean(chain) &&
          (!authenticationStatus || authenticationStatus === "authenticated");

        const handleClick = () => {
          if (connected) {
            openAccountModal?.();
            return;
          }
          openConnectModal?.();
        };

        return (
          <button
            type="button"
            onClick={handleClick}
            disabled={!ready}
            aria-label={
              connected
                ? "Open wallet account modal"
                : "Open wallet connect modal"
            }
            className="h-5 w-5 flex items-center justify-center group/wallet disabled:opacity-50"
          >
            <UnplugIcon className="h-5 w-5 text-muted-foreground group-hover/wallet:text-foreground transition-colors" />
          </button>
        );
      }}
    </ConnectButton.Custom>
  );

  return (
    <div className="flex items-center justify-between px-6 pb-3">
      <div className="flex items-center gap-x-4">
        {onBack ? (
          <button
            type="button"
            onClick={onBack}
            className="h-5 w-5 flex items-center justify-center group/back"
          >
            <LeftChevronIcon className="h-5 w-5 text-muted-foreground group-hover/back:text-foreground" />
          </button>
        ) : depositTargetLogo ? (
          <img
            src={depositTargetLogo}
            alt="Deposit target"
            width={20}
            height={20}
            className="h-5 w-5"
          />
        ) : (
          <div className="size-5 bg-background/20 rounded-full"></div>
        )}
        {renderWalletButton()}
      </div>
      <h2 className="font-display text-center text-[15px] font-medium tracking-[0.3px]">
        {title}
      </h2>
      <button
        type="button"
        onClick={onClose}
        className="h-5 w-5 flex items-center justify-center group/close"
      >
        <CloseIcon className="h-5 w-5 text-muted-foreground group-hover/close:text-foreground transition-colors" />
      </button>
    </div>
  );
};

export default WidgetHeader;
