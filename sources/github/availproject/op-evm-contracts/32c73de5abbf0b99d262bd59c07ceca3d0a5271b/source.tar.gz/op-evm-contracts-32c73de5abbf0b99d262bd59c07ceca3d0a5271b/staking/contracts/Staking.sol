// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.9;

import "contracts/Address.sol";

contract Staking {
    using Address for address;

    // Parameters
    uint256 public constant DEFAULT_STAKING_THRESHOLD = 1 ether;
    uint256 public constant DEFAULT_MIN_SLASH_PERCENTAGE = 1;
    string public  constant NODE_SEQUENCER = "sequencer";
    string public  constant NODE_WATCHTOWER = "watchtower";

    string[] public AVAILABLE_NODE_TYPES = ["sequencer", "watchtower"];

    // Properties
    uint256 public _minStakingThreshold;
    uint256 public _slashPercentage;

    address[] public _participants;
    mapping(address => bool) public _addressToIsParticipant;
    mapping(address => uint256) public _addressToStakedAmount;
    mapping(address => uint256) public _addressToParticipantIndex;
    mapping(address => string) public _addressToNodeType;
    uint256 public _stakedAmount;

    uint256 public _minimumNumParticipants;
    uint256 public _maximumNumParticipants;
    uint256 public _minimumNumSequencers;
    uint256 public _minimumNumWatchtowers;
    uint256 public _maximumNumSequencers;
    uint256 public _maximumNumWatchtowers;

    // For now, we are going to have 3 separated array storages for each node type
    address[] public _sequencers;
    mapping(address => bool) public _addressToIsSequencer;
    mapping(address => uint256) public _addressToSequencerIndex;

    address[] public _sequencers_in_probation;
    mapping(address => bool) public _addressToIsSequencerInProbationAddr;
    mapping(address => uint256) public _addressToSequencerInProbationIndex;

    address[] public _watchtowers;
    mapping(address => bool) public _addressToIsWatchtower;
    mapping(address => uint256) public _addressToWatchtowerIndex;

    address[] public _dispute_watchtowers;
    mapping(address => bool) public _addressToIsDisputedWatchtower;
    mapping(address => uint256) public _addressToDisputedWatchtowerIndex;
    mapping(address => uint256) public _addressToSequencerToDisputedWatchtower;
    mapping(address => address) public _addressDisputedWatchtowerToSequencer;
    mapping(address => bool) public _addressDisputedWatchtowerToSequencerExists;
    mapping(address => address) public _addressDisputedSequencerToWatchtower;
    mapping(address => bool) public _addressDisputedSequencerToWatchtowerExists;

    // Events
    event Staked(address indexed account, uint256 amount);
    event Unstaked(address indexed account, uint256 amount);
    event Slashed(address indexed account, uint256 newAmount, uint256 slashedAmount, address indexed feeRecipientAddr);

    // Fraud Dispute Resolution Events
    event DisputeResolutionBegan(address indexed account);
    event DisputeResolutionEnded(address indexed account);

    // Modifiers
    modifier onlyEOA() {
        require(!msg.sender.isContract(), "Only EOA can call function");
        _;
    }

    modifier onlyStaker() {
        require(
            _addressToStakedAmount[msg.sender] > 0,
            "Only staker can call function"
        );
        _;
    }


    modifier onlyWatchtower() {
        require(
            _isWatchtower(msg.sender) == true,
            "Only watchtower can call function"
        );
        _;
    }

    modifier onlySequencer() {
        require(
            _isSequencer(msg.sender) == true,
            "Only sequencer can call function"
        );
        _;
    }

    constructor(uint256 minNumParticipants, uint256 maxNumParticipants) {
        require(
            minNumParticipants <= maxNumParticipants,
            "Min participants number can not be greater than max num of participants"
        );
        _minimumNumParticipants = minNumParticipants;
        _maximumNumParticipants = maxNumParticipants;
    }

    // PARTICIPANT LIMITER SETTERS-GETTERS

    function SetMinNumParticipants(uint256 minimumNumParticipants) public returns (uint256) {
        _minimumNumParticipants = minimumNumParticipants;
        return _minimumNumParticipants;
    }

    function SetMaxNumParticipants(uint256 maximumNumParticipants) public returns (uint256) {
        _maximumNumParticipants = maximumNumParticipants;
        return _maximumNumParticipants;
    }

    function SetMinNumSequencers(uint256 minimumNumSequencers) public returns (uint256) {
        _minimumNumSequencers = minimumNumSequencers;
        return _minimumNumSequencers;
    }

    function SetMaxNumSequencers(uint256 maximumNumSequencers) public returns (uint256) {
        _maximumNumSequencers = maximumNumSequencers;
        return _maximumNumSequencers;
    }

    function SetMinNumWatchtowers(uint256 minimumNumWatchtowers) public returns (uint256) {
        _minimumNumWatchtowers = minimumNumWatchtowers;
        return _minimumNumWatchtowers;
    }

    function SetMaxNumWatchtowers(uint256 maximumNumWatchtowers) public returns (uint256) {
        _maximumNumWatchtowers = maximumNumWatchtowers;
        return _maximumNumWatchtowers;
    }

    // VIEW FUNCTIONS 

    function GetSlashPercentage() public view returns (uint256) {
        return _getSlashPercentage();
    }

    function GetMinNumSequencers() public view returns (uint256) {
        return _minimumNumSequencers;
    }

    function GetMaxNumSequencers() public view returns (uint256) {
        return _maximumNumSequencers;
    }

    function GetMinNumWatchtowers() public view returns (uint256) {
        return _minimumNumWatchtowers;
    }

    function GetMaxNumWatchtowers() public view returns (uint256) {
        return _maximumNumWatchtowers;
    }

    function GetMinNumParticipants() public view returns (uint256) {
        return _minimumNumParticipants;
    }

    function GetMaxNumParticipants() public view returns (uint256) {
        return _maximumNumParticipants;
    }

    function GetAvailableNodeTypes() public view returns (string[] memory) {
        return AVAILABLE_NODE_TYPES;
    }

    function GetCurrentParticipants() public view returns (address[] memory) {
        return _participants;
    }

    function GetCurrentSequencers() public view returns (address[] memory) {
        return _sequencers;
    }

    function GetCurrentWatchtowers() public view returns (address[] memory) {
        return _watchtowers;
    }

    function GetCurrentDisputeWatchtowers() public view returns (address[] memory) {
        return _dispute_watchtowers;
    }

    function GetDisputedSequencerAddrs(address watchtowerAddr) public view returns (address) {
        return _addressDisputedWatchtowerToSequencer[watchtowerAddr];
    }

    function GetDisputedWatchtowerAddr(address sequencerAddr) public view returns (address) {
        return _addressDisputedSequencerToWatchtower[sequencerAddr];
    }

    function GetCurrentStakedAmount() public view returns (uint256) {
        return _stakedAmount;
    }

    function GetCurrentAccountStakedAmount(address addr) public view returns (uint256) {
        return _addressToStakedAmount[addr];
    }

    function IsSequencer(address addr) public view returns (bool) {
        return _addressToIsSequencer[addr];
    }

    function IsWatchtower(address addr) public view returns (bool) {
        return _addressToIsWatchtower[addr];
    }

    function GetCurrentStakingThreshold() public view returns (uint256) {
        return _getStakingThreshold();
    }

    // -- END VIEW FUNCTIONS 


    // PUBLIC FRAUD DISPUTE RESOLUTION FUNCTIONS

    function GetCurrentSequencersInProbation() public view returns (address[] memory) {
        return _sequencers_in_probation;
    }
    
    function BeginDisputeResolution(address sequencerAddr) public onlyWatchtower {
        _appendToSequencersInProbationSet(sequencerAddr);
        _appendToDisputeWatchtowersSet(msg.sender);
        _appendToDisputedAddressesSet(msg.sender, sequencerAddr);
        emit DisputeResolutionBegan(sequencerAddr);
    }

    function EndDisputeResolution(address sequencerAddr) public {
        _deleteFromSequencersInProbationSet(sequencerAddr);
        emit DisputeResolutionEnded(sequencerAddr);
    }

    // -- END FRAUD DISPUTE RESOLUTION FUNCTIONS

    // PUBLIC STAKING FUNCTIONS

    function SetSlashPercentage(uint256 newPercentage) public onlyEOA {
        _slashPercentage = newPercentage;
    }

    function SetStakingMinThreshold(uint256 newThreshold) public onlyEOA {
        _minStakingThreshold = newThreshold;
    }

    function stake(string memory nodeType) public payable onlyEOA {
        _stake(nodeType);
    }

    function unstake() public onlyEOA onlyStaker {
        _unstake();
    }

    // TODO: onlySequencer 
    function slash(address slashAddr) public onlyEOA onlyStaker onlySequencer {
        _slash(slashAddr);
    }

    // -- END PUBLIC STAKING FUNCTIONS

    // PRIVATE FUNCTIONS

    function _stake(string memory nodeType) private {
        require(
            _isNodeTypeArgumentSequencer(nodeType) || _isNodeTypeArgumentWatchtower(nodeType),
            "Provided node type has to match available node types"
        );

        require(
            msg.value >= _getStakingThreshold(),
            "Insuficient staking amount provided. Has to be larger than staking minimum threshold"
        );

        require(
            _canBecomeSequencer(msg.sender, nodeType),
            "Sender is already sequencer. Rejecting stake request."
        );

        require(
            _canBecomeWatchTower(msg.sender, nodeType),
            "Sender is already watchtower. Rejecting stake request."
        );

        _stakedAmount += msg.value;
        _addressToStakedAmount[msg.sender] += msg.value;

        // Function will ensure that participant is appended only once.
        _appendToParticipantSet(msg.sender);

        if (_isNodeTypeArgumentSequencer(nodeType)) {
            _appendToSequencerSet(msg.sender);
        } else if (_isNodeTypeArgumentWatchtower(nodeType)) {
            _appendToWatchtowerSet(msg.sender);
        }

        emit Staked(msg.sender, msg.value);
    }

    function _unstake() private {
        require(
            _isParticipant(msg.sender),
            "Sender has to be part of staking poll in order to unstake its share. Unstake rejected."
        );

        uint256 amount = _addressToStakedAmount[msg.sender];

        _addressToStakedAmount[msg.sender] = 0;
        _stakedAmount -= amount;

        // Delete from participants
        _deleteFromParticipants(msg.sender);

        // If possible, delete from the sequencers list
        if(_isSequencer(msg.sender)) {
            _deleteFromSequencers(msg.sender);
        }

        // If possible, delete from the watchtower list
        if(_isWatchtower(msg.sender)) {
            _deleteFromWatchtowers(msg.sender);
        }

        payable(msg.sender).transfer(amount);
        emit Unstaked(msg.sender, amount);
    }

    // TODO:
    // - Make sure slashing amount is properly transferred to appropriate participants
    // - Append slashed with time interval into the mapping so next sequencer set won't include it.
    // - onlySequencer (can do the slashing)
    function _slash(address slashAddr) private {
        address feeRecipientAddr;

        if (_addressDisputedSequencerToWatchtowerExists[slashAddr] == true) {
            feeRecipientAddr = _addressDisputedSequencerToWatchtower[slashAddr];
        } else if (_addressDisputedWatchtowerToSequencerExists[slashAddr] == true) {
            feeRecipientAddr = _addressDisputedWatchtowerToSequencer[slashAddr];
        }

        uint256 amount = _addressToStakedAmount[slashAddr];
        uint256 slashAmount = _calculateSlashFeeForAddress(amount, _getSlashPercentage() * 100);

        uint256 newSlashedAccountAmount = amount - slashAmount;
        _addressToStakedAmount[slashAddr] = newSlashedAccountAmount;
        _stakedAmount -= slashAmount;

        payable(feeRecipientAddr).transfer(slashAmount);
        emit Slashed(msg.sender, _stakedAmount, slashAmount, feeRecipientAddr);

        if(_isSequencerInProbation(slashAddr)) {
            _deleteFromSequencersInProbationSet(slashAddr);
            _deleteFromDisputeWatchtowerSet(feeRecipientAddr);
            emit DisputeResolutionEnded(slashAddr);
        }

        if(_isDisputedWatchtower(slashAddr)) {
            _deleteFromSequencersInProbationSet(feeRecipientAddr);
            _deleteFromDisputeWatchtowerSet(slashAddr);
            emit DisputeResolutionEnded(slashAddr);
        }
    }

    function _deleteFromParticipants(address staker) private {
        require(
            _participants.length > _minimumNumParticipants,
            "Staking participants can't be less than the minimum required participant num"
        );

        require(
            _addressToParticipantIndex[staker] < _participants.length,
            "participant index out of range in mapping"
        );

        // index of removed address
        uint256 index = _addressToParticipantIndex[staker];
        uint256 lastIndex = _participants.length - 1;

        if (index != lastIndex) {
            // exchange between the element and last to pop for delete
            address lastAddr = _participants[lastIndex];
            _participants[index] = lastAddr;
            _addressToParticipantIndex[lastAddr] = index;
        }

        _addressToIsParticipant[staker] = false;
        _addressToParticipantIndex[staker] = 0;
        _participants.pop();
    }


    function _deleteFromSequencers(address staker) private {
        require(
            _addressToSequencerIndex[staker] < _sequencers.length,
            "sequencer index out of range in mapping"
        );

        // index of removed address
        uint256 index = _addressToSequencerIndex[staker];
        uint256 lastIndex = _sequencers.length - 1;

        if (index != lastIndex) {
            // exchange between the element and last to pop for delete
            address lastAddr = _sequencers[lastIndex];
            _sequencers[index] = lastAddr;
            _addressToSequencerIndex[lastAddr] = index;
        }

        _addressToIsSequencer[staker] = false;
        _addressToSequencerIndex[staker] = 0;
        _sequencers.pop();
    }

    function _deleteFromWatchtowers(address staker) private {
        require(
            _addressToWatchtowerIndex[staker] < _watchtowers.length,
            "watchtower index out of range in mapping"
        );

        // index of removed address
        uint256 index = _addressToWatchtowerIndex[staker];
        uint256 lastIndex = _watchtowers.length - 1;

        if (index != lastIndex) {
            // exchange between the element and last to pop for delete
            address lastAddr = _watchtowers[lastIndex];
            _watchtowers[index] = lastAddr;
            _addressToWatchtowerIndex[lastAddr] = index;
        }

        _addressToIsWatchtower[staker] = false;
        _addressToWatchtowerIndex[staker] = 0;
        _watchtowers.pop();
    }

    function _appendToSequencersInProbationSet(address newMaliciousAddr) private {
        _addressToIsSequencerInProbationAddr[newMaliciousAddr] = true;
        _addressToSequencerInProbationIndex[newMaliciousAddr] = _sequencers_in_probation.length;
        _sequencers_in_probation.push(newMaliciousAddr);
    }

    function _appendToDisputeWatchtowersSet(address newWatchtower) private {
        _addressToIsDisputedWatchtower[newWatchtower] = true;
        _addressToDisputedWatchtowerIndex[newWatchtower] = _dispute_watchtowers.length;
        _dispute_watchtowers.push(newWatchtower);
    }


    function _deleteFromSequencersInProbationSet(address participant) private {
        require(
            _isSequencerInProbation(participant),
            "Address has to be in probation in order to delete it from the probation sequencers list."
        );

        require(
            _addressToSequencerInProbationIndex[participant] < _sequencers_in_probation.length,
            "malicious participant index out of range in mapping"
        );

        // index of removed address
        uint256 index = _addressToSequencerInProbationIndex[participant];
        uint256 lastIndex = _sequencers_in_probation.length - 1;

        if (index != lastIndex) {
            // exchange between the element and last to pop for delete
            address lastAddr = _sequencers_in_probation[lastIndex];
            _sequencers_in_probation[index] = lastAddr;
            _addressToSequencerInProbationIndex[lastAddr] = index;
        }

        _addressToIsSequencerInProbationAddr[participant] = false;
        _addressToSequencerInProbationIndex[participant] = 0;
        _sequencers_in_probation.pop();
    }

    function _deleteFromDisputeWatchtowerSet(address watchtowerAddr) private {
        require(
            _isDisputedWatchtower(watchtowerAddr),
            "Address has to be in disputed watchtowers in order to delete it from the list."
        );

        require(
            _addressToDisputedWatchtowerIndex[watchtowerAddr] < _dispute_watchtowers.length,
            "Disputed watchtower address index out of range in mapping"
        );

        // index of removed address
        uint256 index = _addressToDisputedWatchtowerIndex[watchtowerAddr];
        uint256 lastIndex = _dispute_watchtowers.length - 1;

        if (index != lastIndex) {
            // exchange between the element and last to pop for delete
            address lastAddr = _dispute_watchtowers[lastIndex];
            _dispute_watchtowers[index] = lastAddr;
            _addressToDisputedWatchtowerIndex[lastAddr] = index;
        }

        _addressToIsDisputedWatchtower[watchtowerAddr] = false;
        _addressToDisputedWatchtowerIndex[watchtowerAddr] = 0;
        _dispute_watchtowers.pop();
    }

    // Append to participant set only if participant is not already set.
    // Due to possibility to be multi-node participant, we need to make this check.
    function _appendToParticipantSet(address newParticipant) private {
        if(!_addressToIsParticipant[newParticipant]) {
            _addressToIsParticipant[newParticipant] = true;
            _addressToParticipantIndex[newParticipant] = _participants.length;
            _participants.push(newParticipant);
        }
    }

    function _appendToSequencerSet(address newSequencer) private {
        _addressToIsSequencer[newSequencer] = true;
        _addressToSequencerIndex[newSequencer] = _sequencers.length;
        _sequencers.push(newSequencer);
    }


    function _appendToWatchtowerSet(address newWatchtower) private {
        _addressToIsWatchtower[newWatchtower] = true;
        _addressToWatchtowerIndex[newWatchtower] = _watchtowers.length;
        _watchtowers.push(newWatchtower);
    }

    function _appendToDisputedAddressesSet(address watchtowerAddr, address sequencerAddr) private {
        _addressDisputedWatchtowerToSequencer[watchtowerAddr] = sequencerAddr;
        _addressDisputedWatchtowerToSequencerExists[watchtowerAddr] = true;
        _addressDisputedSequencerToWatchtower[sequencerAddr] = watchtowerAddr;
        _addressDisputedSequencerToWatchtowerExists[sequencerAddr] = true;
    }

    function _isSequencerInProbation(address account) private view returns (bool) {
        return _addressToIsSequencerInProbationAddr[account];
    }

    function _isParticipant(address account) private view returns (bool) {
        return _addressToIsParticipant[account];
    }

    function _isSequencer(address account) private view returns (bool) {
        return _addressToIsSequencer[account];
    }
    
    function _isWatchtower(address account) private view returns (bool) {
        return _addressToIsWatchtower[account];
    }

    function _isDisputedWatchtower(address account) private view returns (bool) {
        return _addressToIsDisputedWatchtower[account];
    }

    // Check if it is already sequencer as participant cannot become twice sequencer
    function _canBecomeSequencer(address account, string memory nodeType) private view returns (bool)  {
        if(_isNodeTypeArgumentSequencer(nodeType) && _addressToIsSequencer[account]) {
           return false; 
        }

        return true;
    }

    // Check if it is already watchtower as participant cannot become twice watchtower
    function _canBecomeWatchTower(address account, string memory nodeType) private view returns (bool)  {
        if(_isNodeTypeArgumentWatchtower(nodeType) && _addressToIsWatchtower[account]) {
           return false; 
        }

        return true;
    }

    function _isNodeTypeArgumentSequencer(string memory _nodeType) private pure returns (bool) {
        // Compare string keccak256 hashes to check equality
        if (keccak256(abi.encodePacked(NODE_SEQUENCER)) == keccak256(abi.encodePacked(_nodeType))) {
            return true;
        }

        return false;
    }

    function _isNodeTypeArgumentWatchtower(string memory _nodeType) private pure returns (bool) {
        // Compare string keccak256 hashes to check equality
        if (keccak256(abi.encodePacked(NODE_WATCHTOWER)) == keccak256(abi.encodePacked(_nodeType))) {
            return true;
        }

        return false;
    }

    function _getStakingThreshold() private view returns (uint256) {
        if (_minStakingThreshold > 0) {
            return _minStakingThreshold;
        } else {
            return DEFAULT_STAKING_THRESHOLD;
        }
    }

    function _getSlashPercentage() private view returns (uint256) {
        if (_slashPercentage <= 0) {
            return DEFAULT_MIN_SLASH_PERCENTAGE;
        } else {
            return _slashPercentage;
        }
    }

    function _calculateSlashFeeForAddress(uint256 amount, uint256 basePoints) private pure returns (uint256) {
        require((amount * basePoints) >= 10_000, "Amount is too low to calculate fee");
        return amount * basePoints / 10_000;
    }

    // -- END PRIVATE FUNCTIONS
}