"use client";

import { bridge, isInitialized } from "../lib/nexus";

export default function BridgeButton({
  className,
  onResult,
}: {
  className?: string;
  onResult?: (r: any) => void;
}) {
  const onClick = async () => {
    if (!isInitialized()) return alert("Initialize first");
    const res = await bridge();
    onResult?.(res);
    console.log(res);
  };
  return (
    <button className={className} onClick={onClick} disabled={!isInitialized()}>
      Bridge
    </button>
  );
}
