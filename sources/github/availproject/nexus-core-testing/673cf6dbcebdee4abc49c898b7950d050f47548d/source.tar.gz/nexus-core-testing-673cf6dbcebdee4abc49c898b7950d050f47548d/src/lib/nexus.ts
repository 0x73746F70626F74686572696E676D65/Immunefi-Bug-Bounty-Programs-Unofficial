import {
  NexusSDK,
  BridgeResult,
  NEXUS_EVENTS,
  SUPPORTED_CHAINS,
  type ExactOutSwapInput,
  type SwapStepType,
} from "@avail-project/nexus-core";
import type { Hex } from "viem";

export const sdk = new NexusSDK({ network: "mainnet" });

type Source = { tokenAddress: Hex; chainId: number };

// Thin wrapper that calls sdk.isInitialized() from the SDK
export function isInitialized() {
  return sdk.isInitialized();
}

export async function initializeWithProvider(provider: any) {
  if (!provider) throw new Error("No EIP-1193 provider (e.g., MetaMask) found");

  //If the SDK is already initialized, return
  if (sdk.isInitialized()) return;

  //If the SDK is not initialized, initialize it with the provider passed as a parameter
  await sdk.initialize(provider);
}

export async function deinit() {
  //If the SDK is not initialized, return
  if (!sdk.isInitialized()) return;

  //If the SDK is initialized, de-initialize it
  await sdk.deinit();
}

export async function getUnifiedBalances() {
  //Get the unified balances from the SDK
  return await sdk.getBalancesForBridge();
}

export async function bridge() {
  const bridgeResult: BridgeResult = await sdk.bridge(
    {
      token: "USDC",
      amount: BigInt(500000),
      toChainId: 4114, // Citrea Mainnet
    },
    {
      onEvent: (event) => {
        if (event.name === NEXUS_EVENTS.STEPS_LIST) {
          // render steps if you wish to display them to the user
        } else if (event.name === NEXUS_EVENTS.STEP_COMPLETE) {
          // Returned per step of intent fulfillment. You can use this to mark the step as done and show the explorer URL if present.
          const step = event.args;
          if (step.type === "INTENT_SUBMITTED") {
            const url = (step as any).data?.explorerURL;
            if (url) console.log("Explorer:", url);
          }
        }
      },
    },
  );
  return bridgeResult;
}

export async function swapExactOutDirect() {
  const swapSupportedChains = sdk.getSwapSupportedChains();
  console.log(swapSupportedChains);

  const input = {
    fromSources: [
      {
        chainId: 8453,
        tokenAddress: "0x0000000000000000000000000000000000000000" as Hex,
      },
    ] satisfies Source[],
    toChainId: 1,
    toTokenAddress: "0x0000000000000000000000000000000000000000" as Hex,
    toAmount: BigInt(1000),
  };

  const result = await sdk.swapWithExactOut(input, {
    onEvent: (event) => {
      if (event.name === NEXUS_EVENTS.SWAP_STEP_COMPLETE) {
        const step = event.args as SwapStepType & {
          explorerURL?: string;
          completed?: boolean;
        };
        if (step?.type === "SOURCE_SWAP_HASH" && step.explorerURL) {
          console.log("SOURCE_SWAP_HASH: ", step.explorerURL);
        }
        if (step?.type === "DESTINATION_SWAP_HASH" && step.explorerURL) {
          console.log("DESTINATION_SWAP_HASH: ", step.explorerURL);
        }
      }
    },
  });
  if (!result?.success) {
    throw new Error(result?.error || "Swap failed");
  }
  return result;
}
