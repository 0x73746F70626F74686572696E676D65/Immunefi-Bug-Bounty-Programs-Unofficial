import { getDefaultConfig } from "@rainbow-me/rainbowkit";
import {
  mainnet,
  arbitrum,
  polygon,
  optimism,
  base,
  avalanche,
  sepolia,
  arbitrumSepolia,
} from "wagmi/chains";

const walletConnectProjectId = process.env.WALLET_CONNECT_PROJECT_ID;

export const config = getDefaultConfig({
  appName: "Nexus SDK with RainbowKit",
  projectId: walletConnectProjectId!, // Get this from https://cloud.walletconnect.com/
  chains: [
    mainnet,
    arbitrum,
    polygon,
    optimism,
    base,
    avalanche,
    sepolia,
    arbitrumSepolia,
  ],
  ssr: true, // If your dApp uses server side rendering (SSR)
});
