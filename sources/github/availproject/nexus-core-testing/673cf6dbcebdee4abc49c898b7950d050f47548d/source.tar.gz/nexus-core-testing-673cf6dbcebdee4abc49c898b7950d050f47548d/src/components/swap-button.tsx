"use client";

import { bridge, swapExactOutDirect, isInitialized } from "../lib/nexus";

export default function SwapButton({
  className,
  onResult,
}: {
  className?: string;
  onResult?: (r: any) => void;
}) {
  const onClick = async () => {
    if (!isInitialized()) return alert("Initialize first");
    const res = await swapExactOutDirect();
    onResult?.(res);
    console.log(res);
  };
  return (
    <button className={className} onClick={onClick} disabled={!isInitialized()}>
      Swap
    </button>
  );
}
