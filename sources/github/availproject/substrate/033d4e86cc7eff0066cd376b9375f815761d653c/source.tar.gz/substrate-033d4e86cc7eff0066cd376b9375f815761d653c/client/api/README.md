Substrate client interfaces.

License: GPL-3.0-or-later WITH Classpath-exception-2.0