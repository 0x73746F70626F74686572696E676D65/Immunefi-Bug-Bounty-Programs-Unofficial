declare module 'eth-provider';
