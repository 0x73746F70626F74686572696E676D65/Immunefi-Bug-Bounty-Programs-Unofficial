use crate::error::ClientError;
use jsonrpsee_core::{client::ClientT, traits::ToRpcParams, JsonRawValue as RawValue};
use jsonrpsee_http_client::HttpClient as JRPSHttpClient;
use sdk_core::{
	crypto::{AccountId, Ss58Codec},
	types::{
		avail::{
			block::SignedBlock,
			kate::{BlockLength, Cell, GDataProof, GRow, ProofResponse},
			BlockHeader, RuntimeVersion,
		},
		OpaqueTransaction, H256,
	},
};
use serde::Serialize;

#[derive(Debug, Clone, Default)]
pub struct RpcParams(Vec<u8>);
impl ToRpcParams for RpcParams {
	fn to_rpc_params(self) -> Result<Option<Box<RawValue>>, serde_json::Error> {
		let params = self.build();
		Ok(params)
	}
}

impl RpcParams {
	/// Create a new empty set of [`RpcParams`].
	pub fn new() -> Self {
		Self(Vec::new())
	}
	/// Push a parameter into our [`RpcParams`]. This serializes it to JSON
	/// in the process, and so will return an error if this is not possible.
	pub fn push<P: Serialize>(&mut self, param: P) -> Result<(), ClientError> {
		match self.0.len() {
			0 => self.0.push(b'['),
			_ => self.0.push(b','),
		};
		serde_json::to_writer(&mut self.0, &param).map_err(|e| ClientError::SerdeJson(e))?;

		Ok(())
	}
	/// Build a [`RawValue`] from our params, returning `None` if no parameters
	/// were provided.
	pub fn build(mut self) -> Option<Box<RawValue>> {
		if self.0.is_empty() {
			None
		} else {
			self.0.push(b']');
			let s = unsafe { String::from_utf8_unchecked(self.0) };
			Some(RawValue::from_string(s).expect("Should be valid JSON"))
		}
	}
}

pub async fn system_account_next_index(
	client: &JRPSHttpClient,
	account_id: &AccountId,
) -> Result<u32, ClientError> {
	let mut params = RpcParams::new();
	params.push(account_id.to_ss58check())?;

	let value: Result<u32, _> = client
		.request::<u32, _>("system_accountNextIndex", params)
		.await;

	value.map_err(|e| ClientError::Jsonrpsee(e))
}

pub async fn account_nonce_api_account_nonce(
	client: &JRPSHttpClient,
	account_id: &AccountId,
	block_hash: H256,
) -> Result<u32, ClientError> {
	use parity_scale_codec::Decode;

	let mut params = RpcParams::new();
	params.push("AccountNonceApi_account_nonce")?;
	params.push(account_id.to_hex_string())?;
	params.push(Some(block_hash.to_hex_string()))?;

	let encoded_value: Result<String, _> = client.request::<String, _>("state_call", params).await;
	let encoded_value: String = encoded_value.map_err(ClientError::from)?;
	let encoded_value = hex::decode(&encoded_value[2..]).map_err(ClientError::from)?;

	u32::decode(&mut encoded_value.as_ref()).map_err(ClientError::from)
}

pub async fn fetch_best_block_hash(client: &JRPSHttpClient) -> Result<H256, ClientError> {
	let value: Result<String, _> = client
		.request::<_, _>("chain_getBlockHash", RpcParams::new())
		.await;
	let value: String = value.map_err(ClientError::from)?;

	H256::from_hex_string(&value).map_err(ClientError::from)
}

pub async fn fetch_finalized_block_hash(client: &JRPSHttpClient) -> Result<H256, ClientError> {
	let value: Result<String, _> = client
		.request::<_, _>("chain_getFinalizedHead", RpcParams::new())
		.await;
	let value: String = value.map_err(ClientError::from)?;

	H256::from_hex_string(&value).map_err(ClientError::from)
}

pub async fn chain_spec_v1_genesis_hash(client: &JRPSHttpClient) -> Result<H256, ClientError> {
	let value: Result<String, _> = client
		.request::<_, _>("chainSpec_v1_genesisHash", RpcParams::new())
		.await;
	let value: String = value.map_err(ClientError::from)?;

	H256::from_hex_string(&value).map_err(ClientError::from)
}

pub async fn state_get_runtime_version(
	client: &JRPSHttpClient,
) -> Result<RuntimeVersion, ClientError> {
	let value: Result<RuntimeVersion, _> = client
		.request::<_, _>("state_getRuntimeVersion", RpcParams::new())
		.await;

	value.map_err(ClientError::from)
}

pub async fn fetch_block_header(
	client: &JRPSHttpClient,
	hash: Option<H256>,
) -> Result<BlockHeader, ClientError> {
	let mut params: RpcParams = RpcParams::new();
	if let Some(hash) = hash {
		params.push(hash.to_hex_string())?;
	}

	let value: Result<BlockHeader, _> = client.request::<_, _>("chain_getHeader", params).await;

	value.map_err(ClientError::from)
}

pub async fn fetch_block(
	client: &JRPSHttpClient,
	hash: Option<H256>,
) -> Result<SignedBlock, ClientError> {
	let mut params: RpcParams = RpcParams::new();
	if let Some(hash) = hash {
		params.push(hash.to_hex_string())?;
	}

	let value: Result<SignedBlock, _> = client.request::<_, _>("chain_getBlock", params).await;

	value.map_err(ClientError::from)
}

pub async fn author_submit_extrinsic(
	client: &JRPSHttpClient,
	extrinsic: OpaqueTransaction,
) -> Result<H256, ClientError> {
	let mut params = RpcParams::new();
	params.push(extrinsic.data.to_hex_string())?;

	let value: Result<String, _> = client
		.request::<_, _>("author_submitExtrinsic", params)
		.await;
	let value: String = value.map_err(ClientError::from)?;

	H256::from_hex_string(&value).map_err(ClientError::from)
}

pub async fn fetch_kate_block_length(
	client: &JRPSHttpClient,
	hash: Option<H256>,
) -> Result<BlockLength, ClientError> {
	let mut params: RpcParams = RpcParams::new();
	if let Some(hash) = hash {
		params.push(hash.to_hex_string())?;
	}

	let value: Result<BlockLength, _> = client.request::<_, _>("kate_blockLength", params).await;

	value.map_err(ClientError::from)
}

pub async fn fetch_kate_query_data_proof(
	client: &JRPSHttpClient,
	transaction_index: u32,
	hash: Option<H256>,
) -> Result<ProofResponse, ClientError> {
	let mut params: RpcParams = RpcParams::new();
	params.push(transaction_index)?;
	if let Some(hash) = hash {
		params.push(hash.to_hex_string())?;
	}

	let value: Result<ProofResponse, _> =
		client.request::<_, _>("kate_queryDataProof", params).await;

	value.map_err(ClientError::from)
}

pub async fn fetch_kate_query_proof(
	client: &JRPSHttpClient,
	cells: Vec<Cell>,
	hash: Option<H256>,
) -> Result<Vec<GDataProof>, ClientError> {
	let mut params: RpcParams = RpcParams::new();
	params.push(cells)?;
	if let Some(hash) = hash {
		params.push(hash.to_hex_string())?;
	}

	let value: Result<Vec<GDataProof>, _> = client.request::<_, _>("kate_queryProof", params).await;

	value.map_err(ClientError::from)
}

pub async fn fetch_kate_query_rows(
	client: &JRPSHttpClient,
	rows: Vec<u32>,
	hash: Option<H256>,
) -> Result<Vec<GRow>, ClientError> {
	let mut params: RpcParams = RpcParams::new();
	params.push(rows)?;
	if let Some(hash) = hash {
		params.push(hash.to_hex_string())?;
	}

	let value: Result<Vec<GRow>, _> = client.request::<_, _>("kate_queryRows", params).await;

	value.map_err(ClientError::from)
}
