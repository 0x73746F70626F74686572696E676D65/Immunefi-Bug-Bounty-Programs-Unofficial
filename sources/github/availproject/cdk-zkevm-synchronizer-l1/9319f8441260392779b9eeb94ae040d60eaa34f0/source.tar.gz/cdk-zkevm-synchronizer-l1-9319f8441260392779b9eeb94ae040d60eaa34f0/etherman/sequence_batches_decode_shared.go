package etherman

import (
	"bytes"
	"encoding/json"
	"fmt"
	"strings"

	"github.com/0xPolygonHermez/zkevm-synchronizer-l1/dataavailability"
	"github.com/0xPolygonHermez/zkevm-synchronizer-l1/etherman/smartcontracts/polygonzkevm"
	ethtypes "github.com/0xPolygonHermez/zkevm-synchronizer-l1/etherman/types"
	"github.com/ethereum/go-ethereum/accounts/abi"
	"github.com/ethereum/go-ethereum/common"
)

type batchInfo struct {
	num      uint64
	hash     common.Hash
	isForced bool
}

type DecodedSequenceBatchesCallData struct {
	InputByteData []byte
	Data          []interface{}
}

type SequenceBatchesBase struct {
	signature []byte
	name      string
	smcABI    abi.ABI
}

func NewSequenceBatchesBase(signature []byte, name string, abiStr string) (*SequenceBatchesBase, error) {
	smcAbi, err := abi.JSON(strings.NewReader(abiStr))
	if err != nil {
		return nil, err
	}
	return &SequenceBatchesBase{signature: signature, name: name, smcABI: smcAbi}, nil
}

// MatchMethodId returns true if the methodId is the one for the sequenceBatchesEtrog method
func (s *SequenceBatchesBase) MatchMethodId(methodId []byte) bool {
	return bytes.Equal(methodId, s.signature)
}

// NameMethodID returns name
func (s *SequenceBatchesBase) NameMethodID(methodId []byte) string {
	if s.MatchMethodId(methodId) {
		return s.name
	}
	return ""
}

func (s *SequenceBatchesBase) SmcABI() abi.ABI {
	return s.smcABI

}

func decodeSequenceCallData(smcAbi abi.ABI, txData []byte) (*DecodedSequenceBatchesCallData, error) {
	// Extract coded txs.
	// Recover Method from signature and ABI
	method, err := smcAbi.MethodById(txData[:4])
	if err != nil {
		return nil, err
	}

	// Unpack method inputs
	data, err := method.Inputs.Unpack(txData[4:])
	if err != nil {
		return nil, err
	}
	bytedata, err := json.Marshal(data[0])
	if err != nil {
		return nil, err
	}
	return &DecodedSequenceBatchesCallData{InputByteData: bytedata, Data: data}, nil
}

func createBatchInfo(sequencesValidium []polygonzkevm.PolygonValidiumEtrogValidiumBatchData, lastBatchNumber uint64) []batchInfo {
	// Pair the batch number, hash, and if it is forced. This will allow
	// retrieval from different sources, and keep them in original order.

	var batchInfos []batchInfo
	for i, d := range sequencesValidium {
		bn := lastBatchNumber - uint64(len(sequencesValidium)-(i+1))
		forced := d.ForcedTimestamp > 0
		h := d.TransactionsHash
		batchInfos = append(batchInfos, batchInfo{num: bn, hash: h, isForced: forced})
	}
	return batchInfos
}

func createSequencedBatchList(sequencesValidium []polygonzkevm.PolygonValidiumEtrogValidiumBatchData, batchInfos []batchInfo, batchData []dataavailability.BatchL2Data,
	l1InfoRoot common.Hash, sequencer common.Address, txHash common.Hash, nonce uint64, coinbase common.Address,
	maxSequenceTimestamp uint64, initSequencedBatchNumber uint64,
	metaData *ethtypes.SequencedBatchMetadata) []ethtypes.SequencedBatch {
	sequencedBatches := make([]ethtypes.SequencedBatch, len(sequencesValidium))
	for i, info := range batchInfos {
		bn := info.num
		s := ethtypes.EtrogSequenceData{
			Transactions:         batchData[i].Data,
			ForcedGlobalExitRoot: sequencesValidium[i].ForcedGlobalExitRoot,
			ForcedTimestamp:      sequencesValidium[i].ForcedTimestamp,
			ForcedBlockHashL1:    sequencesValidium[i].ForcedBlockHashL1,
		}
		if metaData != nil {
			switch batchData[i].Source {
			case dataavailability.External:
				metaData.SourceBatchData = ethtypes.SourceBatchDataValidiumDAExternal
			case dataavailability.Trusted:
				metaData.SourceBatchData = ethtypes.SourceBatchDataValidiumDATrusted

				metaData.SourceBatchData = string(batchData[i].Source)
			}
		}
		batch := ethtypes.SequencedBatch{
			BatchNumber:       bn,
			L1InfoRoot:        &l1InfoRoot,
			SequencerAddr:     sequencer,
			TxHash:            txHash,
			Nonce:             nonce,
			Coinbase:          coinbase,
			EtrogSequenceData: &s,
			Metadata:          metaData,
		}

		elderberry := &ethtypes.SequencedBatchElderberryData{
			MaxSequenceTimestamp:     maxSequenceTimestamp,
			InitSequencedBatchNumber: initSequencedBatchNumber,
		}
		batch.SequencedBatchElderberryData = elderberry
		sequencedBatches[i] = batch
	}
	return sequencedBatches
}

func getBatchL2Data(da dataavailability.BatchDataProvider, batchInfos []batchInfo, daMessage []byte) (map[uint64]dataavailability.BatchL2Data, error) {
	var batchNums []uint64
	var batchHashes []common.Hash
	for _, info := range batchInfos {
		if !info.isForced {
			batchNums = append(batchNums, info.num)
			batchHashes = append(batchHashes, info.hash)
		}
	}
	if len(batchNums) == 0 {
		return nil, nil
	}

	batchL2Data, err := da.GetBatchL2Data(batchNums, batchHashes, daMessage)
	if err != nil {
		return nil, err
	}

	if len(batchL2Data) != len(batchNums) {
		return nil,
			fmt.Errorf("failed to retrieve all batch data. Expected %d, got %d", len(batchNums), len(batchL2Data))
	}

	data := make(map[uint64]dataavailability.BatchL2Data)
	for i, bn := range batchNums {
		data[bn] = batchL2Data[i]
	}

	return data, nil
}

func retrieveBatchData(da dataavailability.BatchDataProvider, batchInfos []batchInfo, daMessage []byte) ([]dataavailability.BatchL2Data, error) {
	validiumData, err := getBatchL2Data(da, batchInfos, daMessage)
	if err != nil {
		return nil, err
	}

	data := make([]dataavailability.BatchL2Data, len(batchInfos))
	for i, info := range batchInfos {
		bn := info.num
		data[i] = validiumData[bn]

	}
	return data, nil
}
