<script lang="ts" setup>
defineProps({
  color: {
    type: String,
    default: '#000',
  },
})
</script>

<template>
  <svg
    width="14"
    height="14"
    viewBox="0 0 14 14"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
  >
    <path
      d="M1 1L13 13"
      :stroke="color"
      stroke-width="2"
      stroke-linecap="round"
    />
    <path
      d="M13 1L1 13"
      :stroke="color"
      stroke-width="2"
      stroke-linecap="round"
    />
  </svg>
</template>
