import { RpcError } from "../../errors/sdk-error"
import { FeeDetails, RuntimeDispatchInfo } from "./../types"
import { Decoder, Encoder } from "./../scale"
import { u8aToHex } from "@polkadot/util"
import { call as stateCall } from "./state"
import { HashLike } from "../../types"
import { FeeDetailsScale, RuntimeDispatchInfoScale } from "../scale/types"

export async function runtimeApiRawCall(
  endpoint: string,
  method: string,
  data: string | Uint8Array,
  at?: HashLike,
): Promise<string> {
  return stateCall(endpoint, method, data, at)
}

/// Parameter "tx" is hex encoded transaction.
export async function TransactionPaymentApi_queryInfo(
  endpoint: string,
  tx: string,
  at?: string,
): Promise<RuntimeDispatchInfo> {
  try {
    const len = tx.startsWith("0x") ? (tx.length - 2) / 2 : tx.length / 2
    const encodedLen = u8aToHex(Encoder.u32(len))
    tx += encodedLen.slice(2)

    if (at != undefined) {
      const value = await runtimeApiRawCall(endpoint, "TransactionPaymentApi_query_info", tx, at)
      const decoder = Decoder.from(value)
      return RuntimeDispatchInfoScale.decode(decoder)
    } else {
      const value = await runtimeApiRawCall(endpoint, "TransactionPaymentApi_query_info", tx)
      const decoder = Decoder.from(value)
      return RuntimeDispatchInfoScale.decode(decoder)
    }
  } catch (e: any) {
    throw new RpcError(e instanceof Error ? e.message : String(e))
  }
}

/// Parameter "tx" is hex encoded transaction.
export async function TransactionPaymentApi_queryFeeDetails(
  endpoint: string,
  tx: string,
  at?: string,
): Promise<FeeDetails> {
  try {
    const len = tx.startsWith("0x") ? (tx.length - 2) / 2 : tx.length / 2
    const encodedLen = u8aToHex(Encoder.u32(len))
    tx += encodedLen.slice(2)

    if (at != undefined) {
      const value = await runtimeApiRawCall(endpoint, "TransactionPaymentApi_query_fee_details", tx, at)

      const decoder = Decoder.from(value)

      return FeeDetailsScale.decode(decoder)
    } else {
      const value = await runtimeApiRawCall(endpoint, "TransactionPaymentApi_query_fee_details", tx)

      const decoder = Decoder.from(value)

      return FeeDetailsScale.decode(decoder)
    }
  } catch (e: any) {
    throw new RpcError(e instanceof Error ? e.message : String(e))
  }
}

export async function TransactionPaymentCallApi_queryCallInfo(
  endpoint: string,
  call: string,
  at?: string,
): Promise<RuntimeDispatchInfo> {
  try {
    const len = call.startsWith("0x") ? (call.length - 2) / 2 : call.length / 2
    const encodedLen = u8aToHex(Encoder.u32(len))
    call += encodedLen.slice(2)

    if (at != undefined) {
      const value = await runtimeApiRawCall(endpoint, "TransactionPaymentCallApi_query_call_info", call, at)
      const decoder = Decoder.from(value)

      return RuntimeDispatchInfoScale.decode(decoder)
    } else {
      const value = await runtimeApiRawCall(endpoint, "TransactionPaymentCallApi_query_call_info", call)
      const decoder = Decoder.from(value)

      return RuntimeDispatchInfoScale.decode(decoder)
    }
  } catch (e: any) {
    throw new RpcError(e instanceof Error ? e.message : String(e))
  }
}

export async function TransactionPaymentCallApi_queryCallFeeDetails(
  endpoint: string,
  call: string,
  at?: string,
): Promise<FeeDetails> {
  try {
    const len = call.startsWith("0x") ? (call.length - 2) / 2 : call.length / 2
    const encodedLen = u8aToHex(Encoder.u32(len))
    call += encodedLen.slice(2)

    if (at != undefined) {
      const value = await runtimeApiRawCall(endpoint, "TransactionPaymentCallApi_query_call_fee_details", call, at)

      const decoder = Decoder.from(value)

      return FeeDetailsScale.decode(decoder)
    } else {
      const value = await runtimeApiRawCall(endpoint, "TransactionPaymentCallApi_query_call_fee_details", call)

      const decoder = Decoder.from(value)

      return FeeDetailsScale.decode(decoder)
    }
  } catch (e: any) {
    throw new RpcError(e instanceof Error ? e.message : String(e))
  }
}
