import { addHeader } from "./../../interface"
import { Decoder } from "./../../scale/decoder"
import { Encoder } from "./../../scale/encoder"
import { PALLET_ID } from "./header"

export { PALLET_ID }

export class Remark extends addHeader(PALLET_ID, 0) {
  constructor(
    public remark: Uint8Array, // Vec<u8>,
  ) {
    super()
  }

  static decode(decoder: Decoder): Remark {
    const remark = decoder.vecU8()

    return new Remark(remark)
  }

  encode(): Uint8Array {
    return Encoder.vecU8(this.remark)
  }
}

export class SetCode extends addHeader(PALLET_ID, 2) {
  constructor(
    public code: Uint8Array, // Vec<u8>,
  ) {
    super()
  }

  static decode(decoder: Decoder): SetCode {
    const code = decoder.vecU8()

    return new SetCode(code)
  }

  encode(): Uint8Array {
    return Encoder.vecU8(this.code)
  }
}

export class SetCodeWithoutChecks extends addHeader(PALLET_ID, 3) {
  constructor(
    public code: Uint8Array, // Vec<u8>,
  ) {
    super()
  }

  static decode(decoder: Decoder): SetCodeWithoutChecks {
    const code = decoder.vecU8()

    return new SetCodeWithoutChecks(code)
  }

  encode(): Uint8Array {
    return Encoder.vecU8(this.code)
  }
}

export class RemarkWithEvent extends addHeader(PALLET_ID, 7) {
  constructor(
    public remark: Uint8Array, // Vec<u8>,
  ) {
    super()
  }

  static decode(decoder: Decoder): RemarkWithEvent {
    const remark = decoder.vecU8()

    return new RemarkWithEvent(remark)
  }

  encode(): Uint8Array {
    return Encoder.vecU8(this.remark)
  }
}
