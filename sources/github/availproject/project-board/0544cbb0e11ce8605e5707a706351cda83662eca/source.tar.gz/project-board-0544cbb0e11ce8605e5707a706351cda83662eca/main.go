package main

import "github.com/thunderkeys/project-board/cmd"

func main() {
	cmd.Execute()
}
