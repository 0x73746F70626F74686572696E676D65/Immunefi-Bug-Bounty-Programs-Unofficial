package cmd

import (
	"fmt"

	"github.com/expr-lang/expr"
	"github.com/spf13/cobra"
	"github.com/thunderkeys/project-board/internal/cache"
	"github.com/thunderkeys/project-board/internal/config"
	"github.com/thunderkeys/project-board/internal/display"
)

var flagShowRaw bool

var showCmd = &cobra.Command{
	Use:     "show <issue-number>",
	Short:   "Show full details for an item",
	GroupID: "work",
	Args:    cobra.ExactArgs(1),
	RunE:    runShow,
}

func init() {
	showCmd.Flags().BoolVar(&flagShowRaw, "raw", false, "Show all fields without item_type display rules")
	rootCmd.AddCommand(showCmd)
}

func runShow(cmd *cobra.Command, args []string) error {
	cfg, err := config.Load()
	if err != nil {
		return err
	}
	if err := cfg.Validate(); err != nil {
		return err
	}

	dbPath, err := config.DBPath()
	if err != nil {
		return err
	}
	db, err := cache.Open(dbPath)
	if err != nil {
		return fmt.Errorf("opening cache: %w", err)
	}
	defer db.Close()

	var issueNum int
	if _, err := fmt.Sscanf(args[0], "%d", &issueNum); err != nil {
		return fmt.Errorf("invalid issue number: %q", args[0])
	}

	display.WarnIfStale(db)

	it, err := db.ItemByNumber(issueNum)
	if err != nil {
		return fmt.Errorf("looking up item: %w", err)
	}
	if it == nil {
		return fmt.Errorf("issue #%d not found in cache; run 'project-board sync'", issueNum)
	}

	var sprint *cache.Sprint
	if it.SprintIterationID != "" {
		sprint, err = db.SprintByIterationID(it.SprintIterationID)
		if err != nil {
			return err
		}
	}

	// Resolve item type and apply display rules unless --raw.
	hiddenFields := map[string]bool{}
	showSubitems := true // on by default; suppress with hide_subitems: true in item_type config
	if !flagShowRaw && len(cfg.ItemTypes) > 0 {
		itemType := matchItemType(cfg, cache.ItemEnv(*it))
		if itemType != nil {
			for _, h := range itemType.Hide {
				hiddenFields[h] = true
			}
			if itemType.HideSubitems {
				showSubitems = false
			}
		}
	}

	display.PrintTask(*it, sprint, hiddenFields)

	if showSubitems {
		children, err := db.ChildItems(it.IssueNodeID)
		if err != nil {
			return fmt.Errorf("querying sub-items: %w", err)
		}
		if len(children) > 0 {
			fmt.Println()
			envs := buildEnvs(children)
			display.PrintItems(children, envs, nil)
		}
	}

	return nil
}

// matchItemType returns the first configured ItemType whose match expr is true for env.
func matchItemType(cfg *config.Config, env map[string]any) *config.ItemType {
	for i := range cfg.ItemTypes {
		it := &cfg.ItemTypes[i]
		if it.Match == "" || it.Match == "true" {
			return it
		}
		prog, err := expr.Compile(it.Match, expr.AsBool())
		if err != nil {
			continue
		}
		result, err := expr.Run(prog, env)
		if err != nil {
			continue
		}
		if b, ok := result.(bool); ok && b {
			return it
		}
	}
	return nil
}

// buildEnvs builds ItemEnv maps for a slice of items, adding the "assignee" display key.
func buildEnvs(items []cache.Item) []map[string]any {
	envs := make([]map[string]any, len(items))
	for i, it := range items {
		e := cache.ItemEnv(it)
		e["assignee"] = display.BuildAssigneeString(it.Assignees)
		envs[i] = e
	}
	return envs
}
