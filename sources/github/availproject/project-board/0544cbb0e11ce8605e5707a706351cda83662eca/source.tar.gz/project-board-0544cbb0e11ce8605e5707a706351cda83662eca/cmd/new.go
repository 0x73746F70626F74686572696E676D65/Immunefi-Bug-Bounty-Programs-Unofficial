package cmd

import (
	"fmt"
	"strings"

	"github.com/spf13/cobra"
	"github.com/thunderkeys/project-board/internal/cache"
	"github.com/thunderkeys/project-board/internal/config"
	gh "github.com/thunderkeys/project-board/internal/github"
)

var newCmd = &cobra.Command{
	Use:   "new key=value ...",
	Short: "Create a new item on the project board",
	Long: `Create a new issue and add it to the project board.

Required: title=<string>

Special keys:
  title=<string>        Issue title (required)
  body=<string>         Issue body / description
  repo=owner/name       Repository (overrides config default_repo)
  template=<name>       Load body from a stored issue template

All other keys are set as project board field values after creation.
Sprint values accept offsets (current, next, previous, current+N).

Examples:
  project-board new title="Fix login bug" status=Backlog
  project-board new title="Q3 Initiative" kind=Epic
  project-board new title="Implement auth" sprint=current status="In Progress" team=Platform
  project-board new title="New feature" template=slice`,
	Args:    cobra.MinimumNArgs(1),
	RunE:    runNew,
	GroupID: "work",
}

func init() {
	rootCmd.AddCommand(newCmd)
}

func runNew(cmd *cobra.Command, args []string) error {
	cfg, err := config.Load()
	if err != nil {
		return err
	}
	if err := cfg.Validate(); err != nil {
		return err
	}
	if err := config.EnsureConfigDir(); err != nil {
		return fmt.Errorf("cannot create config dir: %w", err)
	}

	pairs, err := parseKeyValues(args)
	if err != nil {
		return err
	}

	// Extract special keys.
	var title, body, repo, templateName string
	var fieldPairs [][2]string
	for _, kv := range pairs {
		switch kv[0] {
		case "title":
			title = kv[1]
		case "body":
			body = kv[1]
		case "repo":
			repo = kv[1]
		case "template":
			templateName = kv[1]
		default:
			fieldPairs = append(fieldPairs, kv)
		}
	}

	if title == "" {
		return fmt.Errorf("title= is required")
	}

	repoStr := cfg.DefaultRepo
	if repo != "" {
		repoStr = repo
	}
	if repoStr == "" {
		return fmt.Errorf("no repo specified; set default_repo in config or use repo=owner/name")
	}
	parts := strings.SplitN(repoStr, "/", 2)
	if len(parts) != 2 {
		return fmt.Errorf("repo must be in owner/name format, got %q", repoStr)
	}
	repoOwner, repoName := parts[0], parts[1]

	dbPath, err := config.DBPath()
	if err != nil {
		return err
	}
	db, err := cache.Open(dbPath)
	if err != nil {
		return fmt.Errorf("opening cache: %w", err)
	}
	defer db.Close()

	projectNodeID, _, err := db.GetMeta("project_node_id")
	if err != nil || projectNodeID == "" {
		return fmt.Errorf("project node ID not found; run 'project-board sync' first")
	}

	// Load template body if requested and no explicit body given.
	if body == "" && templateName != "" {
		if tmpl, ok, _ := db.GetMeta("template_" + templateName); ok && tmpl != "" {
			body = tmpl
		} else {
			return fmt.Errorf("template %q not found in cache; run 'project-board sync'", templateName)
		}
	}

	client := gh.NewClient(cfg.GitHubToken)

	fmt.Printf("Resolving repository %s/%s...\n", repoOwner, repoName)
	repoID, err := client.ResolveRepoNodeID(repoOwner, repoName)
	if err != nil {
		return fmt.Errorf("resolving repo: %w", err)
	}

	fmt.Printf("Creating issue %q...\n", title)
	issueNodeID, issueNum, issueURL, err := client.CreateIssue(repoID, title, body)
	if err != nil {
		return fmt.Errorf("creating issue: %w", err)
	}
	fmt.Printf("Created issue #%d: %s\n", issueNum, issueURL)

	fmt.Println("Adding to project board...")
	itemNodeID, err := client.AddToProject(projectNodeID, issueNodeID)
	if err != nil {
		return fmt.Errorf("adding to project: %w", err)
	}

	// Apply field key=value pairs.
	for _, kv := range fieldPairs {
		key, value := kv[0], kv[1]
		if value == "" {
			continue
		}
		field, err := db.FieldByNormalizedKey(key)
		if err != nil || field == nil {
			fmt.Printf("Warning: field %q not found; skipping.\n", key)
			continue
		}
		if err := setProjectField(client, db, cfg, projectNodeID, itemNodeID, field, value); err != nil {
			fmt.Printf("Warning: could not set %s: %v\n", field.Name, err)
		}
	}

	fmt.Printf("\nDone. #%d: %s\n", issueNum, issueURL)
	return nil
}

// setProjectField dispatches a project field update based on field type.
func setProjectField(client *gh.Client, db *cache.DB, cfg *config.Config, projectNodeID, itemNodeID string, field *cache.Field, value string) error {
	switch field.FieldType {
	case "single_select":
		optionID := ""
		for _, opt := range field.Options {
			if strings.EqualFold(opt.Name, value) {
				optionID = opt.OptionID
				break
			}
		}
		if optionID == "" {
			names := make([]string, len(field.Options))
			for i, o := range field.Options {
				names[i] = o.Name
			}
			return fmt.Errorf("unknown value %q; available: %s", value, strings.Join(names, ", "))
		}
		fmt.Printf("Setting %s to %q...\n", field.Name, value)
		return client.UpdateFieldSingleSelect(projectNodeID, itemNodeID, field.NodeID, optionID)

	case "iteration":
		sprint, err := resolveSprintByNameOrOffset(db, value)
		if err != nil {
			return err
		}
		fmt.Printf("Setting %s to %q...\n", field.Name, sprint.Title)
		return client.UpdateFieldIteration(projectNodeID, itemNodeID, field.NodeID, sprint.IterationID)

	case "text":
		fmt.Printf("Setting %s to %q...\n", field.Name, value)
		return client.UpdateFieldText(projectNodeID, itemNodeID, field.NodeID, value)
	}
	return nil
}

