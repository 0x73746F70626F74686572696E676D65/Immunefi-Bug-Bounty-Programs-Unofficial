package cmd

import (
	"fmt"
	"strings"
	"time"

	"github.com/expr-lang/expr"
	"github.com/spf13/cobra"
	"github.com/thunderkeys/project-board/internal/cache"
	"github.com/thunderkeys/project-board/internal/config"
	"github.com/thunderkeys/project-board/internal/display"
)

var (
	querySprintArg  string
	queryTeam       string
	queryColumns    string
	queryView       string
)

var queryCmd = &cobra.Command{
	Use:   "query [expr]",
	Short: "Query items with an optional filter expression",
	Long: `Query project board items using an optional filter expression.

The expression is evaluated against each item's fields using expr-lang syntax.
Field names use normalized lowercase keys (spaces replaced with underscores).

Built-in fields: number, title, state, has_parent, parent, status, sprint, team, priority, kind
Custom project fields are available by their normalized name.

Examples:
  project-board query
  project-board query "kind == 'Epic'"
  project-board query "status == 'In Progress' and team == 'Platform'"
  project-board query "kind == 'Epic' and (status == 'Active' or status == 'Paused')"
  project-board query "kind == nil"
  project-board query --sprint current --team Engineering
  project-board query --view current-sprint`,
	Args:    cobra.MaximumNArgs(1),
	RunE:    runQuery,
	GroupID: "work",
}

func init() {
	queryCmd.Flags().StringVar(&querySprintArg, "sprint", "", "Pre-filter by sprint (current, next, previous, current+N)")
	queryCmd.Flags().StringVar(&queryTeam, "team", "", "Pre-filter by team")
	queryCmd.Flags().StringVar(&queryColumns, "columns", "", "Comma-separated columns to display")
	queryCmd.Flags().StringVar(&queryView, "view", "", "Use a named view from config")
	rootCmd.AddCommand(queryCmd)
}

func runQuery(cmd *cobra.Command, args []string) error {
	cfg, err := config.Load()
	if err != nil {
		return err
	}

	dbPath, err := config.DBPath()
	if err != nil {
		return err
	}
	db, err := cache.Open(dbPath)
	if err != nil {
		return fmt.Errorf("opening cache: %w", err)
	}
	defer db.Close()

	display.WarnIfStale(db)

	// Resolve view settings.
	var view *config.View
	if queryView != "" {
		view = cfg.FindView(queryView)
		if view == nil {
			return fmt.Errorf("view %q not found in config", queryView)
		}
	}

	// Determine filter expression: CLI arg > view query > none.
	filterExpr := ""
	if len(args) > 0 {
		filterExpr = args[0]
	} else if view != nil {
		filterExpr = view.Query
	}

	// Determine columns: --columns flag > view columns > default.
	columns := display.DefaultColumns
	if queryColumns != "" {
		columns = strings.Split(queryColumns, ",")
		for i := range columns {
			columns[i] = strings.TrimSpace(columns[i])
		}
	} else if view != nil && len(view.Columns) > 0 {
		columns = view.Columns
	}

	// Determine team: flag > config default (only if also filtering by sprint).
	team := queryTeam
	if team == "" && querySprintArg != "" {
		team = cfg.DefaultTeam
	}

	// Resolve sprint pre-filter.
	sprintIterID := ""
	var sprintForHeader *cache.Sprint
	if querySprintArg != "" {
		q, err := cache.ParseSprintQuery(querySprintArg)
		if err != nil {
			return err
		}
		// For simplicity, single-sprint pre-filter only (ranges handled post-filter).
		if !q.IsRange {
			sprint, err := db.ResolveSprintByOffset(time.Now(), q.Offset)
			if err != nil {
				return err
			}
			sprintIterID = sprint.IterationID
			sprintForHeader = sprint
		}
	}

	// Load items with optional pre-filters.
	items, err := db.AllItems(team, sprintIterID)
	if err != nil {
		return fmt.Errorf("querying items: %w", err)
	}

	// Compile and apply filter expression.
	if filterExpr != "" {
		prog, err := expr.Compile(filterExpr, expr.AsBool())
		if err != nil {
			return fmt.Errorf("invalid filter expression: %w\n\nHint: use == for equality (e.g. kind == 'Epic'), not =", err)
		}
		var filtered []cache.Item
		for _, it := range items {
			env := cache.ItemEnv(it)
			result, err := expr.Run(prog, env)
			if err != nil {
				continue
			}
			if b, ok := result.(bool); ok && b {
				filtered = append(filtered, it)
			}
		}
		items = filtered
	}

	// Print sprint header if pre-filtered to one sprint.
	if sprintForHeader != nil {
		fmt.Printf("Sprint: %s  (%s)\n\n", sprintForHeader.Title, cache.SprintDateRange(sprintForHeader))
	}

	envs := buildEnvs(items)
	display.PrintItems(items, envs, columns)
	return nil
}
