package cmd

import (
	"fmt"
	"os"

	"github.com/spf13/cobra"
)

var rootCmd = &cobra.Command{
	Use:   "project-board",
	Short: "GitHub ProjectV2 board CLI — sync, query, and update items",
	Long: `project-board syncs a GitHub ProjectV2 board to a local SQLite cache
and lets you query, view, create, update, and archive items from the terminal.

Configuration: ~/.config/project-board/config.yaml`,
	SilenceUsage:  true,
	SilenceErrors: true,
}

// Execute runs the root command.
func Execute() {
	if err := rootCmd.Execute(); err != nil {
		fmt.Fprintln(os.Stderr, "Error:", err)
		os.Exit(1)
	}
}

func init() {
	rootCmd.AddGroup(&cobra.Group{ID: "work", Title: "Commands:"})
	rootCmd.AddGroup(&cobra.Group{ID: "util", Title: "Utilities:"})
}
