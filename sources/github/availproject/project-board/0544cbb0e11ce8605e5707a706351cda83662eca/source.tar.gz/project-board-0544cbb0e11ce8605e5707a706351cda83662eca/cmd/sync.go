package cmd

import (
	"encoding/json"
	"fmt"
	"strings"
	"time"

	"github.com/spf13/cobra"
	"github.com/thunderkeys/project-board/internal/cache"
	"github.com/thunderkeys/project-board/internal/config"
	gh "github.com/thunderkeys/project-board/internal/github"
)

var syncCmd = &cobra.Command{
	Use:     "sync",
	Short:   "Download all project board items to the local cache",
	RunE:    runSync,
	GroupID: "util",
}

func init() {
	rootCmd.AddCommand(syncCmd)
}

func runSync(cmd *cobra.Command, args []string) error {
	cfg, err := config.Load()
	if err != nil {
		return err
	}
	if err := cfg.Validate(); err != nil {
		return err
	}
	if err := config.EnsureConfigDir(); err != nil {
		return fmt.Errorf("cannot create config dir: %w", err)
	}

	dbPath, err := config.DBPath()
	if err != nil {
		return err
	}
	db, err := cache.Open(dbPath)
	if err != nil {
		return fmt.Errorf("opening cache: %w", err)
	}
	defer db.Close()

	// Warn if already fresh.
	last, ok, err := db.LastSyncedAt()
	if err == nil && ok {
		age := time.Since(last)
		if age < time.Hour {
			fmt.Printf("Cache is already fresh (synced %s ago). Continuing anyway...\n", formatDuration(age))
		}
	}

	client := gh.NewClient(cfg.GitHubToken)

	// Step 1: Resolve project node ID.
	ref, err := gh.ParseProjectURL(cfg.ProjectURL)
	if err != nil {
		return fmt.Errorf("parsing project URL: %w", err)
	}

	projectNodeID, _, _ := db.GetMeta("project_node_id")
	if projectNodeID == "" {
		fmt.Println("Resolving project...")
		nodeID, title, err := client.ResolveProjectNodeID(ref)
		if err != nil {
			return fmt.Errorf("resolving project node ID: %w", err)
		}
		projectNodeID = nodeID
		if err := db.SetMeta("project_node_id", projectNodeID); err != nil {
			return err
		}
		if err := db.SetMeta("project_title", title); err != nil {
			return err
		}
		fmt.Printf("Project: %s\n", title)
	} else {
		title, _, _ := db.GetMeta("project_title")
		fmt.Printf("Project: %s\n", title)
	}

	// Step 2: Fetch fields and sprints.
	fmt.Println("Fetching fields...")
	fields, err := client.FetchFields(projectNodeID)
	if err != nil {
		return fmt.Errorf("fetching fields: %w", err)
	}

	for _, f := range fields {
		fieldID, err := db.UpsertField(cache.Field{
			NodeID:        f.ID,
			Name:          f.Name,
			FieldType:     f.FieldType,
			NormalizedKey: cache.NormalizeFieldKey(f.Name),
		})
		if err != nil {
			return fmt.Errorf("upserting field %q: %w", f.Name, err)
		}
		for _, opt := range f.Options {
			if err := db.UpsertFieldOption(fieldID, opt.ID, opt.Name); err != nil {
				return fmt.Errorf("upserting field option %q: %w", opt.Name, err)
			}
		}
		for _, it := range f.Iterations {
			if err := db.UpsertSprint(cache.Sprint{
				IterationID:  it.ID,
				Title:        it.Title,
				StartDate:    it.StartDate,
				DurationDays: it.Duration,
				IsCompleted:  false,
			}); err != nil {
				return fmt.Errorf("upserting sprint %q: %w", it.Title, err)
			}
		}
		for _, it := range f.CompletedIterations {
			if err := db.UpsertSprint(cache.Sprint{
				IterationID:  it.ID,
				Title:        it.Title,
				StartDate:    it.StartDate,
				DurationDays: it.Duration,
				IsCompleted:  true,
			}); err != nil {
				return fmt.Errorf("upserting completed sprint %q: %w", it.Title, err)
			}
		}
	}
	fmt.Printf("  %d fields loaded.\n", len(fields))

	if err := db.SetMeta("sprint_field", cfg.SprintField); err != nil {
		return err
	}
	if err := db.SetMeta("team_field", cfg.TeamField); err != nil {
		return err
	}

	// Step 3: Fetch issue templates (store all by filename, no hardcoded kind matching).
	if cfg.TemplateRepo != "" {
		parts := strings.SplitN(cfg.TemplateRepo, "/", 2)
		if len(parts) == 2 {
			fmt.Printf("Fetching issue templates from %s...\n", cfg.TemplateRepo)
			templates, err := client.FetchIssueTemplates(parts[0], parts[1])
			if err != nil {
				fmt.Printf("  Warning: could not fetch templates: %v\n", err)
			} else {
				stored := 0
				for filename, raw := range templates {
					_, body, err := gh.ParseIssueFormTemplate(raw)
					if err != nil {
						continue
					}
					if err := db.SetMeta("template_"+filename, body); err != nil {
						return fmt.Errorf("storing template %q: %w", filename, err)
					}
					stored++
				}
				fmt.Printf("  %d template(s) stored.\n", stored)
			}
		}
	}

	// Step 4: Fetch items.
	fmt.Print("Fetching items...")
	syncedAt := time.Now().UTC().Format(time.RFC3339)

	allItems, err := client.FetchItems(projectNodeID, func(fetched, _ int) {
		fmt.Printf("\rFetching items... %d", fetched)
	})
	if err != nil {
		return fmt.Errorf("fetching items: %w", err)
	}
	fmt.Println()

	sprintFieldName := cfg.SprintField
	teamFieldName := cfg.TeamField

	count := 0
	for _, item := range allItems {
		if item.Content == nil {
			continue
		}

		// Extract well-known field values into dedicated columns.
		var sprintIterID, sprintTitle, statusName, statusOptionID, teamArea, priority, kind, epicStatus, outcome string

		// Build the generic custom_fields JSON from ALL field values.
		customFields := map[string]any{}

		for _, fv := range item.FieldValues {
			nk := cache.NormalizeFieldKey(fv.FieldName)
			switch fv.Type {
			case "iteration":
				if strings.EqualFold(fv.FieldName, sprintFieldName) {
					sprintIterID = fv.IterationID
					sprintTitle = fv.IterTitle
					customFields["sprint"] = fv.IterTitle
				}
				customFields[nk] = fv.IterTitle
			case "single_select":
				customFields[nk] = fv.OptionName
				switch {
				case strings.EqualFold(fv.FieldName, "Status"):
					statusName = fv.OptionName
					statusOptionID = fv.OptionID
					customFields["status"] = fv.OptionName
				case strings.EqualFold(fv.FieldName, teamFieldName):
					teamArea = fv.OptionName
					customFields["team"] = fv.OptionName
				case strings.EqualFold(fv.FieldName, "Priority"):
					priority = fv.OptionName
					customFields["priority"] = fv.OptionName
				case strings.EqualFold(fv.FieldName, "Kind"):
					kind = fv.OptionName
					customFields["kind"] = fv.OptionName
				case strings.EqualFold(fv.FieldName, "EpicStatus"):
					epicStatus = fv.OptionName
				case strings.EqualFold(fv.FieldName, "Outcome"):
					outcome = fv.OptionName
				}
			case "text":
				customFields[nk] = fv.Text
				if strings.EqualFold(fv.FieldName, teamFieldName) {
					teamArea = fv.Text
					customFields["team"] = fv.Text
				}
			}
		}

		customFieldsJSON, _ := json.Marshal(customFields)
		assigneesJSON, _ := json.Marshal(item.Content.Assignees)
		labelsJSON, _ := json.Marshal(item.Content.Labels)
		if item.Content.Assignees == nil {
			assigneesJSON = []byte("[]")
		}
		if item.Content.Labels == nil {
			labelsJSON = []byte("[]")
		}

		if err := db.UpsertItem(cache.Item{
			ItemNodeID:        item.ID,
			IssueNodeID:       item.Content.ID,
			IssueNumber:       item.Content.Number,
			IssueURL:          item.Content.URL,
			Title:             item.Content.Title,
			Body:              item.Content.Body,
			State:             item.Content.State,
			SprintIterationID: sprintIterID,
			SprintTitle:       sprintTitle,
			Status:            statusName,
			StatusOptionID:    statusOptionID,
			TeamArea:          teamArea,
			Priority:          priority,
			Assignees:         string(assigneesJSON),
			Labels:            string(labelsJSON),
			SyncedAt:          syncedAt,
			Kind:              kind,
			EpicStatus:        epicStatus,
			Outcome:           outcome,
			ParentIssueNodeID: item.Content.ParentID,
			CustomFields:      string(customFieldsJSON),
		}); err != nil {
			return fmt.Errorf("upserting item #%d: %w", item.Content.Number, err)
		}
		count++
	}

	if err := db.SetMeta("last_synced_at", syncedAt); err != nil {
		return err
	}

	fmt.Printf("Done. %d items synced.\n", count)
	return nil
}

func formatDuration(d time.Duration) string {
	d = d.Truncate(time.Minute)
	h := int(d.Hours())
	m := int(d.Minutes()) % 60
	if h > 0 && m > 0 {
		return fmt.Sprintf("%dh%dm", h, m)
	}
	if h > 0 {
		return fmt.Sprintf("%dh", h)
	}
	if m > 0 {
		return fmt.Sprintf("%dm", m)
	}
	return "less than a minute"
}
