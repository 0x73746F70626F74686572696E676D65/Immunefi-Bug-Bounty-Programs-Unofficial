package cmd

import (
	"encoding/json"
	"fmt"
	"strconv"
	"strings"
	"time"

	"github.com/spf13/cobra"
	"github.com/thunderkeys/project-board/internal/cache"
	"github.com/thunderkeys/project-board/internal/config"
	gh "github.com/thunderkeys/project-board/internal/github"
)

var updateCmd = &cobra.Command{
	Use:   "update <issue-number> key=value ...",
	Short: "Update fields on an item",
	Long: `Update one or more fields on a project board item using key=value pairs.

Special keys:
  title=<string>        Update the issue title
  body=<string>         Update the issue body
  state=open|closed     Open or close the issue
  parent=<number>       Set parent issue (GitHub sub-issue relationship)
  parent=               Clear parent issue

All other keys are looked up as project board field names (normalized).
Use an empty value to clear a field: status=

Sprint values accept offsets (current, next, previous, current+N) or sprint titles.

Examples:
  project-board update 42 status="In Progress"
  project-board update 42 sprint=next
  project-board update 42 title="New title" status=Done
  project-board update 42 parent=10
  project-board update 42 parent=
  project-board update 42 sprint=`,
	Args: cobra.MinimumNArgs(2),
	RunE: runUpdate,
	GroupID: "work",
}

func init() {
	rootCmd.AddCommand(updateCmd)
}

func runUpdate(cmd *cobra.Command, args []string) error {
	cfg, err := config.Load()
	if err != nil {
		return err
	}
	if err := cfg.Validate(); err != nil {
		return err
	}

	dbPath, err := config.DBPath()
	if err != nil {
		return err
	}
	db, err := cache.Open(dbPath)
	if err != nil {
		return fmt.Errorf("opening cache: %w", err)
	}
	defer db.Close()

	var issueNum int
	if _, err := fmt.Sscanf(args[0], "%d", &issueNum); err != nil {
		return fmt.Errorf("invalid issue number: %q", args[0])
	}

	pairs, err := parseKeyValues(args[1:])
	if err != nil {
		return err
	}

	it, err := db.ItemByNumber(issueNum)
	if err != nil {
		return fmt.Errorf("looking up item: %w", err)
	}
	if it == nil {
		return fmt.Errorf("issue #%d not found in cache; run 'project-board sync'", issueNum)
	}

	projectNodeID, _, err := db.GetMeta("project_node_id")
	if err != nil || projectNodeID == "" {
		return fmt.Errorf("project node ID not found; run 'project-board sync' first")
	}

	client := gh.NewClient(cfg.GitHubToken)

	for _, kv := range pairs {
		key, value := kv[0], kv[1]
		if err := applyUpdate(cfg, db, client, it, projectNodeID, key, value); err != nil {
			return err
		}
	}

	return nil
}

func applyUpdate(cfg *config.Config, db *cache.DB, client *gh.Client, it *cache.Item, projectNodeID, key, value string) error {
	switch key {
	case "title":
		if value == "" {
			return fmt.Errorf("title cannot be empty")
		}
		fmt.Printf("Updating title to %q...\n", value)
		if err := client.UpdateIssue(it.IssueNodeID, value, "", ""); err != nil {
			return fmt.Errorf("updating title: %w", err)
		}
		return db.UpdateItemTitle(it.ItemNodeID, value)

	case "body":
		fmt.Println("Updating body...")
		if err := client.UpdateIssue(it.IssueNodeID, "", value, ""); err != nil {
			return fmt.Errorf("updating body: %w", err)
		}
		return db.UpdateItemBody(it.ItemNodeID, value)

	case "state":
		var ghState string
		switch strings.ToLower(value) {
		case "open", "reopen":
			ghState = "OPEN"
		case "closed", "close":
			ghState = "CLOSED"
		default:
			return fmt.Errorf("state must be 'open' or 'closed', got %q", value)
		}
		if it.State == ghState {
			fmt.Printf("Issue is already %s.\n", strings.ToLower(ghState))
			return nil
		}
		fmt.Printf("Setting state to %s...\n", strings.ToLower(ghState))
		if err := client.UpdateIssue(it.IssueNodeID, "", "", ghState); err != nil {
			return fmt.Errorf("updating state: %w", err)
		}
		return db.UpdateItemState(it.ItemNodeID, ghState)

	case "parent":
		return applyParentUpdate(db, client, it, value)
	}

	// Generic project board field update.
	return applyFieldUpdate(cfg, db, client, it, projectNodeID, key, value)
}

func applyParentUpdate(db *cache.DB, client *gh.Client, it *cache.Item, value string) error {
	if value == "" {
		if it.ParentIssueNodeID == "" {
			fmt.Println("No parent set; nothing to clear.")
			return nil
		}
		parent, err := db.ItemByIssueNodeID(it.ParentIssueNodeID)
		if err != nil {
			return fmt.Errorf("looking up parent: %w", err)
		}
		if parent == nil {
			return fmt.Errorf("parent not found in cache; run 'project-board sync'")
		}
		fmt.Printf("Removing from parent #%d...\n", parent.IssueNumber)
		if err := client.RemoveSubIssue(parent.IssueNodeID, it.IssueNodeID); err != nil {
			return fmt.Errorf("removing parent: %w", err)
		}
		return db.UpdateItemParent(it.ItemNodeID, "")
	}

	parentNum, err := strconv.Atoi(value)
	if err != nil {
		return fmt.Errorf("parent must be an issue number, got %q", value)
	}
	parent, err := db.ItemByNumber(parentNum)
	if err != nil {
		return fmt.Errorf("looking up parent #%d: %w", parentNum, err)
	}
	if parent == nil {
		return fmt.Errorf("issue #%d not found in cache; run 'project-board sync'", parentNum)
	}
	fmt.Printf("Setting parent to #%d...\n", parentNum)
	if err := client.AddSubIssue(parent.IssueNodeID, it.IssueNodeID, true); err != nil {
		return fmt.Errorf("setting parent: %w", err)
	}
	return db.UpdateItemParent(it.ItemNodeID, parent.IssueNodeID)
}

func applyFieldUpdate(cfg *config.Config, db *cache.DB, client *gh.Client, it *cache.Item, projectNodeID, key, value string) error {
	field, err := db.FieldByNormalizedKey(key)
	if err != nil {
		return fmt.Errorf("looking up field %q: %w", key, err)
	}
	if field == nil {
		return fmt.Errorf("unknown field %q (run 'project-board sync' if this is a new field)", key)
	}

	if value == "" {
		fmt.Printf("Clearing %s...\n", field.Name)
		if err := client.ClearProjectField(projectNodeID, it.ItemNodeID, field.NodeID); err != nil {
			return fmt.Errorf("clearing %s: %w", field.Name, err)
		}
		// Update dedicated cache columns where applicable.
		return clearDedicatedColumn(db, it, key)
	}

	switch field.FieldType {
	case "single_select":
		optionID := ""
		for _, opt := range field.Options {
			if strings.EqualFold(opt.Name, value) {
				optionID = opt.OptionID
				break
			}
		}
		if optionID == "" {
			names := make([]string, len(field.Options))
			for i, o := range field.Options {
				names[i] = o.Name
			}
			return fmt.Errorf("unknown value %q for %s; available: %s", value, field.Name, strings.Join(names, ", "))
		}
		fmt.Printf("Setting %s to %q...\n", field.Name, value)
		if err := client.UpdateFieldSingleSelect(projectNodeID, it.ItemNodeID, field.NodeID, optionID); err != nil {
			return fmt.Errorf("updating %s: %w", field.Name, err)
		}
		return setDedicatedColumn(db, it, key, value, optionID)

	case "iteration":
		sprint, err := resolveSprintByNameOrOffset(db, value)
		if err != nil {
			return err
		}
		fmt.Printf("Setting %s to %q...\n", field.Name, sprint.Title)
		if err := client.UpdateFieldIteration(projectNodeID, it.ItemNodeID, field.NodeID, sprint.IterationID); err != nil {
			return fmt.Errorf("updating %s: %w", field.Name, err)
		}
		return db.UpdateItemSprint(it.ItemNodeID, sprint.IterationID, sprint.Title)

	case "text":
		fmt.Printf("Setting %s to %q...\n", field.Name, value)
		if err := client.UpdateFieldText(projectNodeID, it.ItemNodeID, field.NodeID, value); err != nil {
			return fmt.Errorf("updating %s: %w", field.Name, err)
		}
		return nil

	default:
		return fmt.Errorf("unsupported field type %q for field %s", field.FieldType, field.Name)
	}
}

// setDedicatedColumn updates dedicated cache columns for known fields and custom_fields JSON.
func setDedicatedColumn(db *cache.DB, it *cache.Item, key, value, optionID string) error {
	switch key {
	case "status":
		return db.UpdateItemStatus(it.ItemNodeID, value, optionID)
	case "kind":
		return db.UpdateItemKind(it.ItemNodeID, value)
	}
	return updateCustomFieldsKey(db, it, key, value)
}

func clearDedicatedColumn(db *cache.DB, it *cache.Item, key string) error {
	switch key {
	case "status":
		return db.UpdateItemStatus(it.ItemNodeID, "", "")
	case "kind":
		return db.UpdateItemKind(it.ItemNodeID, "")
	case "sprint":
		return db.UpdateItemSprint(it.ItemNodeID, "", "")
	}
	return updateCustomFieldsKey(db, it, key, nil)
}

// updateCustomFieldsKey patches a single key in the item's custom_fields JSON in the cache.
func updateCustomFieldsKey(db *cache.DB, it *cache.Item, key string, value any) error {
	var fields map[string]any
	if it.CustomFields != "" && it.CustomFields != "{}" {
		if err := json.Unmarshal([]byte(it.CustomFields), &fields); err != nil {
			fields = map[string]any{}
		}
	} else {
		fields = map[string]any{}
	}
	if value == nil {
		delete(fields, key)
	} else {
		fields[key] = value
	}
	b, err := json.Marshal(fields)
	if err != nil {
		return err
	}
	return db.UpdateItemCustomFields(it.ItemNodeID, string(b))
}

// resolveSprintByNameOrOffset tries to resolve a sprint by offset string first,
// then by exact title match.
func resolveSprintByNameOrOffset(db *cache.DB, value string) (*cache.Sprint, error) {
	offset, err := cache.ParseSprintArg(value)
	if err == nil {
		return db.ResolveSprintByOffset(time.Now(), offset)
	}
	// Try by title.
	sprint, err2 := db.SprintByTitle(value)
	if err2 != nil {
		return nil, fmt.Errorf("resolving sprint %q: %w", value, err2)
	}
	if sprint == nil {
		return nil, fmt.Errorf("sprint %q not found (try: current, next, previous, current+N, or a sprint title)", value)
	}
	return sprint, nil
}

// parseKeyValues parses "key=value" arguments into pairs.
// Values may contain "=" (only the first "=" is the separator).
func parseKeyValues(args []string) ([][2]string, error) {
	var pairs [][2]string
	for _, arg := range args {
		idx := strings.IndexByte(arg, '=')
		if idx < 0 {
			return nil, fmt.Errorf("argument %q is not in key=value format", arg)
		}
		key := strings.TrimSpace(arg[:idx])
		value := arg[idx+1:]
		if key == "" {
			return nil, fmt.Errorf("empty key in argument %q", arg)
		}
		pairs = append(pairs, [2]string{key, value})
	}
	return pairs, nil
}
