package cmd

import (
	"fmt"

	"github.com/spf13/cobra"
	"github.com/thunderkeys/project-board/internal/config"
	"github.com/thunderkeys/project-board/internal/cache"
	gh "github.com/thunderkeys/project-board/internal/github"
)

var archiveCmd = &cobra.Command{
	Use:     "archive <issue-number>",
	Short:   "Archive an item on the project board",
	GroupID: "work",
	Args:    cobra.ExactArgs(1),
	RunE:    runArchive,
}

func init() {
	rootCmd.AddCommand(archiveCmd)
}

func runArchive(cmd *cobra.Command, args []string) error {
	cfg, err := config.Load()
	if err != nil {
		return err
	}
	if err := cfg.Validate(); err != nil {
		return err
	}

	dbPath, err := config.DBPath()
	if err != nil {
		return err
	}
	db, err := cache.Open(dbPath)
	if err != nil {
		return fmt.Errorf("opening cache: %w", err)
	}
	defer db.Close()

	var issueNum int
	if _, err := fmt.Sscanf(args[0], "%d", &issueNum); err != nil {
		return fmt.Errorf("invalid issue number: %q", args[0])
	}

	it, err := db.ItemByNumber(issueNum)
	if err != nil {
		return fmt.Errorf("looking up item: %w", err)
	}
	if it == nil {
		return fmt.Errorf("issue #%d not found in cache; run 'project-board sync'", issueNum)
	}

	projectNodeID, _, err := db.GetMeta("project_node_id")
	if err != nil || projectNodeID == "" {
		return fmt.Errorf("project node ID not found; run 'project-board sync' first")
	}

	client := gh.NewClient(cfg.GitHubToken)

	fmt.Printf("Archiving #%d %q...\n", it.IssueNumber, it.Title)
	if err := client.ArchiveProjectItem(projectNodeID, it.ItemNodeID); err != nil {
		return fmt.Errorf("archiving item: %w", err)
	}
	fmt.Println("Done.")
	return nil
}
