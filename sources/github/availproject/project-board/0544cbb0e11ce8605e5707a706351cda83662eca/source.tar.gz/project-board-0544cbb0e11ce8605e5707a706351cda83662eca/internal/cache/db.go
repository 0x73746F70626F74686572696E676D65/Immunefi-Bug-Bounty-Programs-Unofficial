package cache

import (
	"database/sql"
	"fmt"
	"strings"
	"time"

	_ "modernc.org/sqlite"
)

const schema = `
CREATE TABLE IF NOT EXISTS meta (
    key   TEXT PRIMARY KEY,
    value TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS sprints (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    iteration_id  TEXT NOT NULL UNIQUE,
    title         TEXT NOT NULL,
    start_date    TEXT NOT NULL,
    duration_days INTEGER NOT NULL,
    is_completed  INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS fields (
    id             INTEGER PRIMARY KEY AUTOINCREMENT,
    node_id        TEXT NOT NULL UNIQUE,
    name           TEXT NOT NULL,
    field_type     TEXT NOT NULL,
    normalized_key TEXT NOT NULL DEFAULT ''
);

CREATE TABLE IF NOT EXISTS field_options (
    id        INTEGER PRIMARY KEY AUTOINCREMENT,
    field_id  INTEGER NOT NULL REFERENCES fields(id),
    option_id TEXT NOT NULL,
    name      TEXT NOT NULL,
    UNIQUE(field_id, option_id)
);

CREATE TABLE IF NOT EXISTS items (
    id                   INTEGER PRIMARY KEY AUTOINCREMENT,
    item_node_id         TEXT NOT NULL UNIQUE,
    issue_node_id        TEXT NOT NULL,
    issue_number         INTEGER NOT NULL,
    issue_url            TEXT NOT NULL,
    title                TEXT NOT NULL,
    body                 TEXT NOT NULL DEFAULT '',
    state                TEXT NOT NULL,
    sprint_iteration_id  TEXT,
    status               TEXT,
    status_option_id     TEXT,
    team_area            TEXT,
    priority             TEXT,
    assignees            TEXT NOT NULL DEFAULT '',
    labels               TEXT NOT NULL DEFAULT '',
    synced_at            TEXT NOT NULL,
    kind                 TEXT NOT NULL DEFAULT '',
    epic_status          TEXT NOT NULL DEFAULT '',
    outcome              TEXT NOT NULL DEFAULT '',
    parent_issue_node_id TEXT NOT NULL DEFAULT '',
    sprint_title         TEXT NOT NULL DEFAULT '',
    custom_fields        TEXT NOT NULL DEFAULT '{}'
);
`

// DB wraps a SQLite database connection.
type DB struct {
	db *sql.DB
}

// Open opens (or creates) the SQLite database at the given path.
func Open(path string) (*DB, error) {
	db, err := sql.Open("sqlite", path+"?_journal_mode=WAL&_foreign_keys=on")
	if err != nil {
		return nil, fmt.Errorf("opening db: %w", err)
	}
	db.SetMaxOpenConns(1) // SQLite: single writer
	if err := applySchema(db); err != nil {
		db.Close()
		return nil, err
	}
	return &DB{db: db}, nil
}

// Close closes the underlying database connection.
func (d *DB) Close() error {
	return d.db.Close()
}

func columnExists(db *sql.DB, table, column string) (bool, error) {
	rows, err := db.Query(`PRAGMA table_info(` + table + `)`)
	if err != nil {
		return false, err
	}
	defer rows.Close()
	for rows.Next() {
		var cid, pk int
		var name, colType, notNull string
		var dflt sql.NullString
		if err := rows.Scan(&cid, &name, &colType, &notNull, &dflt, &pk); err != nil {
			return false, err
		}
		if name == column {
			return true, nil
		}
	}
	return false, rows.Err()
}

func applySchema(db *sql.DB) error {
	if _, err := db.Exec(schema); err != nil {
		return fmt.Errorf("applying schema: %w", err)
	}
	type colMigration struct {
		table  string
		column string
		ddl    string
	}
	migrations := []colMigration{
		{"items", "kind", `ALTER TABLE items ADD COLUMN kind TEXT NOT NULL DEFAULT ''`},
		{"items", "epic_status", `ALTER TABLE items ADD COLUMN epic_status TEXT NOT NULL DEFAULT ''`},
		{"items", "outcome", `ALTER TABLE items ADD COLUMN outcome TEXT NOT NULL DEFAULT ''`},
		{"items", "parent_issue_node_id", `ALTER TABLE items ADD COLUMN parent_issue_node_id TEXT NOT NULL DEFAULT ''`},
		{"items", "sprint_title", `ALTER TABLE items ADD COLUMN sprint_title TEXT NOT NULL DEFAULT ''`},
		{"items", "custom_fields", `ALTER TABLE items ADD COLUMN custom_fields TEXT NOT NULL DEFAULT '{}'`},
		{"fields", "normalized_key", `ALTER TABLE fields ADD COLUMN normalized_key TEXT NOT NULL DEFAULT ''`},
	}
	for _, m := range migrations {
		has, err := columnExists(db, m.table, m.column)
		if err != nil {
			return fmt.Errorf("checking column %q on %q: %w", m.column, m.table, err)
		}
		if has {
			continue
		}
		if _, err := db.Exec(m.ddl); err != nil {
			return fmt.Errorf("adding column %q to %q: %w", m.column, m.table, err)
		}
	}
	return nil
}

// ---- meta ----

// GetMeta retrieves a value from the meta table. Returns ("", false) if not found.
func (d *DB) GetMeta(key string) (string, bool, error) {
	var val string
	err := d.db.QueryRow(`SELECT value FROM meta WHERE key = ?`, key).Scan(&val)
	if err == sql.ErrNoRows {
		return "", false, nil
	}
	if err != nil {
		return "", false, fmt.Errorf("get meta %q: %w", key, err)
	}
	return val, true, nil
}

// SetMeta upserts a key/value pair in the meta table.
func (d *DB) SetMeta(key, value string) error {
	_, err := d.db.Exec(
		`INSERT INTO meta(key, value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value`,
		key, value,
	)
	if err != nil {
		return fmt.Errorf("set meta %q: %w", key, err)
	}
	return nil
}

// LastSyncedAt parses and returns last_synced_at from meta.
func (d *DB) LastSyncedAt() (time.Time, bool, error) {
	val, ok, err := d.GetMeta("last_synced_at")
	if err != nil || !ok {
		return time.Time{}, ok, err
	}
	t, err := time.Parse(time.RFC3339, val)
	if err != nil {
		return time.Time{}, false, fmt.Errorf("parse last_synced_at: %w", err)
	}
	return t, true, nil
}

// ---- sprints ----

// Sprint is a stored sprint/iteration.
type Sprint struct {
	ID           int64
	IterationID  string
	Title        string
	StartDate    string // YYYY-MM-DD
	DurationDays int
	IsCompleted  bool
}

// UpsertSprint inserts or updates a sprint record.
func (d *DB) UpsertSprint(s Sprint) error {
	completed := 0
	if s.IsCompleted {
		completed = 1
	}
	_, err := d.db.Exec(`
		INSERT INTO sprints(iteration_id, title, start_date, duration_days, is_completed)
		VALUES(?,?,?,?,?)
		ON CONFLICT(iteration_id) DO UPDATE SET
			title=excluded.title,
			start_date=excluded.start_date,
			duration_days=excluded.duration_days,
			is_completed=excluded.is_completed
	`, s.IterationID, s.Title, s.StartDate, s.DurationDays, completed)
	if err != nil {
		return fmt.Errorf("upsert sprint %q: %w", s.IterationID, err)
	}
	return nil
}

// AllSprints returns all sprints ordered by start_date ascending.
func (d *DB) AllSprints() ([]Sprint, error) {
	rows, err := d.db.Query(`SELECT id, iteration_id, title, start_date, duration_days, is_completed FROM sprints ORDER BY start_date ASC`)
	if err != nil {
		return nil, fmt.Errorf("query sprints: %w", err)
	}
	defer rows.Close()
	var sprints []Sprint
	for rows.Next() {
		var s Sprint
		var completed int
		if err := rows.Scan(&s.ID, &s.IterationID, &s.Title, &s.StartDate, &s.DurationDays, &completed); err != nil {
			return nil, err
		}
		s.IsCompleted = completed == 1
		sprints = append(sprints, s)
	}
	return sprints, rows.Err()
}

// SprintByIterationID looks up a sprint by its iteration ID.
func (d *DB) SprintByIterationID(iterationID string) (*Sprint, error) {
	var s Sprint
	var completed int
	err := d.db.QueryRow(
		`SELECT id, iteration_id, title, start_date, duration_days, is_completed FROM sprints WHERE iteration_id = ?`,
		iterationID,
	).Scan(&s.ID, &s.IterationID, &s.Title, &s.StartDate, &s.DurationDays, &completed)
	if err == sql.ErrNoRows {
		return nil, nil
	}
	if err != nil {
		return nil, fmt.Errorf("lookup sprint %q: %w", iterationID, err)
	}
	s.IsCompleted = completed == 1
	return &s, nil
}

// SprintByTitle looks up a sprint by its title (case-insensitive).
func (d *DB) SprintByTitle(title string) (*Sprint, error) {
	var s Sprint
	var completed int
	err := d.db.QueryRow(
		`SELECT id, iteration_id, title, start_date, duration_days, is_completed FROM sprints WHERE title = ? COLLATE NOCASE`,
		title,
	).Scan(&s.ID, &s.IterationID, &s.Title, &s.StartDate, &s.DurationDays, &completed)
	if err == sql.ErrNoRows {
		return nil, nil
	}
	if err != nil {
		return nil, fmt.Errorf("lookup sprint by title %q: %w", title, err)
	}
	s.IsCompleted = completed == 1
	return &s, nil
}

// ---- fields ----

// Field is a stored project field.
type Field struct {
	ID            int64
	NodeID        string
	Name          string
	FieldType     string // 'iteration', 'single_select', 'text'
	NormalizedKey string
	Options       []FieldOption
}

// FieldOption is an option for a single_select field.
type FieldOption struct {
	ID       int64
	FieldID  int64
	OptionID string
	Name     string
}

// UpsertField inserts or updates a field record (without options).
func (d *DB) UpsertField(f Field) (int64, error) {
	_, err := d.db.Exec(`
		INSERT INTO fields(node_id, name, field_type, normalized_key)
		VALUES(?,?,?,?)
		ON CONFLICT(node_id) DO UPDATE SET
			name=excluded.name,
			field_type=excluded.field_type,
			normalized_key=excluded.normalized_key
	`, f.NodeID, f.Name, f.FieldType, f.NormalizedKey)
	if err != nil {
		return 0, fmt.Errorf("upsert field %q: %w", f.NodeID, err)
	}
	var id int64
	err = d.db.QueryRow(`SELECT id FROM fields WHERE node_id = ?`, f.NodeID).Scan(&id)
	if err != nil {
		return 0, fmt.Errorf("get field id %q: %w", f.NodeID, err)
	}
	return id, nil
}

// UpsertFieldOption inserts or updates a field option.
func (d *DB) UpsertFieldOption(fieldID int64, optionID, name string) error {
	_, err := d.db.Exec(`
		INSERT INTO field_options(field_id, option_id, name)
		VALUES(?,?,?)
		ON CONFLICT(field_id, option_id) DO UPDATE SET name=excluded.name
	`, fieldID, optionID, name)
	if err != nil {
		return fmt.Errorf("upsert field option %q: %w", optionID, err)
	}
	return nil
}

// FieldByName looks up a field by its name (case-insensitive) and loads its options.
func (d *DB) FieldByName(name string) (*Field, error) {
	var f Field
	err := d.db.QueryRow(
		`SELECT id, node_id, name, field_type, normalized_key FROM fields WHERE name = ? COLLATE NOCASE`, name,
	).Scan(&f.ID, &f.NodeID, &f.Name, &f.FieldType, &f.NormalizedKey)
	if err == sql.ErrNoRows {
		return nil, nil
	}
	if err != nil {
		return nil, fmt.Errorf("lookup field %q: %w", name, err)
	}
	return d.loadFieldOptions(&f)
}

// FieldByNormalizedKey looks up a field by normalized key and loads its options.
// Falls back to computing the normalized key from the field name for pre-migration rows.
func (d *DB) FieldByNormalizedKey(key string) (*Field, error) {
	rows, err := d.db.Query(`SELECT id, node_id, name, field_type, normalized_key FROM fields`)
	if err != nil {
		return nil, fmt.Errorf("query fields: %w", err)
	}
	defer rows.Close()
	for rows.Next() {
		var f Field
		if err := rows.Scan(&f.ID, &f.NodeID, &f.Name, &f.FieldType, &f.NormalizedKey); err != nil {
			return nil, err
		}
		stored := f.NormalizedKey
		if stored == "" {
			stored = NormalizeFieldKey(f.Name)
		}
		if stored == key {
			if err := rows.Close(); err != nil {
				return nil, err
			}
			return d.loadFieldOptions(&f)
		}
	}
	return nil, rows.Err()
}

// AllFields returns all fields with their options.
func (d *DB) AllFields() ([]Field, error) {
	rows, err := d.db.Query(`SELECT id, node_id, name, field_type, normalized_key FROM fields ORDER BY name`)
	if err != nil {
		return nil, fmt.Errorf("query fields: %w", err)
	}
	defer rows.Close()
	var fields []Field
	for rows.Next() {
		var f Field
		if err := rows.Scan(&f.ID, &f.NodeID, &f.Name, &f.FieldType, &f.NormalizedKey); err != nil {
			return nil, err
		}
		fields = append(fields, f)
	}
	if err := rows.Err(); err != nil {
		return nil, err
	}
	for i := range fields {
		if _, err := d.loadFieldOptions(&fields[i]); err != nil {
			return nil, err
		}
	}
	return fields, nil
}

func (d *DB) loadFieldOptions(f *Field) (*Field, error) {
	rows, err := d.db.Query(
		`SELECT id, field_id, option_id, name FROM field_options WHERE field_id = ?`, f.ID,
	)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	for rows.Next() {
		var o FieldOption
		if err := rows.Scan(&o.ID, &o.FieldID, &o.OptionID, &o.Name); err != nil {
			return nil, err
		}
		f.Options = append(f.Options, o)
	}
	return f, rows.Err()
}

// ---- items ----

// Item is a stored project board item.
type Item struct {
	ID                  int64
	ItemNodeID          string
	IssueNodeID         string
	IssueNumber         int
	IssueURL            string
	Title               string
	Body                string
	State               string
	SprintIterationID   string
	Status              string
	StatusOptionID      string
	TeamArea            string
	Priority            string
	Assignees           string // JSON array
	Labels              string // JSON array
	SyncedAt            string
	Kind                string
	EpicStatus          string
	Outcome             string
	ParentIssueNodeID   string
	SprintTitle         string
	CustomFields        string // JSON object of all project field values
	ParentIssueNumber   int    // computed via JOIN, not stored
}

const itemSelectCols = `
	i.id, i.item_node_id, i.issue_node_id, i.issue_number, i.issue_url,
	i.title, i.body, i.state,
	COALESCE(i.sprint_iteration_id,''), COALESCE(i.status,''), COALESCE(i.status_option_id,''),
	COALESCE(i.team_area,''), COALESCE(i.priority,''), i.assignees, i.labels, i.synced_at,
	i.kind, i.epic_status, i.outcome, i.parent_issue_node_id,
	COALESCE(i.sprint_title,''), COALESCE(i.custom_fields,'{}'),
	COALESCE(p.issue_number, 0)`

const itemJoin = `FROM items i LEFT JOIN items p ON p.issue_node_id = i.parent_issue_node_id`

// UpsertItem inserts or updates a project item.
func (d *DB) UpsertItem(it Item) error {
	_, err := d.db.Exec(`
		INSERT INTO items(item_node_id, issue_node_id, issue_number, issue_url, title, body, state,
			sprint_iteration_id, status, status_option_id, team_area, priority, assignees, labels, synced_at,
			kind, epic_status, outcome, parent_issue_node_id, sprint_title, custom_fields)
		VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
		ON CONFLICT(item_node_id) DO UPDATE SET
			issue_node_id=excluded.issue_node_id,
			issue_number=excluded.issue_number,
			issue_url=excluded.issue_url,
			title=excluded.title,
			body=excluded.body,
			state=excluded.state,
			sprint_iteration_id=excluded.sprint_iteration_id,
			status=excluded.status,
			status_option_id=excluded.status_option_id,
			team_area=excluded.team_area,
			priority=excluded.priority,
			assignees=excluded.assignees,
			labels=excluded.labels,
			synced_at=excluded.synced_at,
			kind=excluded.kind,
			epic_status=excluded.epic_status,
			outcome=excluded.outcome,
			parent_issue_node_id=excluded.parent_issue_node_id,
			sprint_title=excluded.sprint_title,
			custom_fields=excluded.custom_fields
	`,
		it.ItemNodeID, it.IssueNodeID, it.IssueNumber, it.IssueURL,
		it.Title, it.Body, it.State,
		nullableString(it.SprintIterationID),
		nullableString(it.Status),
		nullableString(it.StatusOptionID),
		nullableString(it.TeamArea),
		nullableString(it.Priority),
		it.Assignees, it.Labels, it.SyncedAt,
		it.Kind, it.EpicStatus, it.Outcome, it.ParentIssueNodeID,
		it.SprintTitle, it.CustomFields,
	)
	if err != nil {
		return fmt.Errorf("upsert item %q: %w", it.ItemNodeID, err)
	}
	return nil
}

// ItemByNumber looks up an item by its GitHub issue number.
func (d *DB) ItemByNumber(number int) (*Item, error) {
	rows, err := d.db.Query(`SELECT `+itemSelectCols+` `+itemJoin+` WHERE i.issue_number = ?`, number)
	if err != nil {
		return nil, fmt.Errorf("query item: %w", err)
	}
	defer rows.Close()
	var items []*Item
	for rows.Next() {
		it, err := scanItemRow(rows)
		if err != nil {
			return nil, err
		}
		items = append(items, it)
	}
	if err := rows.Err(); err != nil {
		return nil, err
	}
	if len(items) == 0 {
		return nil, nil
	}
	if len(items) > 1 {
		var urls []string
		for _, it := range items {
			urls = append(urls, it.IssueURL)
		}
		return nil, fmt.Errorf("issue number %d is ambiguous (found in multiple repos: %s); use sync to disambiguate", number, strings.Join(urls, ", "))
	}
	return items[0], nil
}

// ItemByIssueNodeID looks up an item by its GitHub issue node ID (globally unique).
func (d *DB) ItemByIssueNodeID(nodeID string) (*Item, error) {
	rows, err := d.db.Query(`SELECT `+itemSelectCols+` `+itemJoin+` WHERE i.issue_node_id = ?`, nodeID)
	if err != nil {
		return nil, fmt.Errorf("query item by node ID: %w", err)
	}
	defer rows.Close()
	if rows.Next() {
		it, err := scanItemRow(rows)
		if err != nil {
			return nil, err
		}
		return it, rows.Err()
	}
	return nil, rows.Err()
}

// AllItems returns all items, optionally pre-filtered by team and/or sprint iteration ID.
// Empty strings mean no filter for that dimension.
func (d *DB) AllItems(team, sprintIterID string) ([]Item, error) {
	q := `SELECT ` + itemSelectCols + ` ` + itemJoin + ` WHERE 1=1`
	args := []any{}
	if team != "" {
		q += ` AND i.team_area = ? COLLATE NOCASE`
		args = append(args, team)
	}
	if sprintIterID != "" {
		q += ` AND i.sprint_iteration_id = ?`
		args = append(args, sprintIterID)
	}
	q += ` ORDER BY i.issue_number ASC`

	rows, err := d.db.Query(q, args...)
	if err != nil {
		return nil, fmt.Errorf("query items: %w", err)
	}
	defer rows.Close()
	var items []Item
	for rows.Next() {
		it, err := scanItemRow(rows)
		if err != nil {
			return nil, err
		}
		items = append(items, *it)
	}
	return items, rows.Err()
}

// ItemsForTeamSprint returns items matching a team and sprint iteration ID.
func (d *DB) ItemsForTeamSprint(team, sprintIterationID string) ([]Item, error) {
	return d.AllItems(team, sprintIterationID)
}

// ChildItems returns all items whose parent is the given issue (by issue node ID).
func (d *DB) ChildItems(parentIssueNodeID string) ([]Item, error) {
	rows, err := d.db.Query(`SELECT `+itemSelectCols+` `+itemJoin+` WHERE i.parent_issue_node_id = ? ORDER BY i.issue_number ASC`, parentIssueNodeID)
	if err != nil {
		return nil, fmt.Errorf("query child items: %w", err)
	}
	defer rows.Close()
	var items []Item
	for rows.Next() {
		it, err := scanItemRow(rows)
		if err != nil {
			return nil, err
		}
		items = append(items, *it)
	}
	return items, rows.Err()
}

// UpdateItemTitle updates just the title of an item in the cache.
func (d *DB) UpdateItemTitle(itemNodeID, title string) error {
	_, err := d.db.Exec(`UPDATE items SET title=? WHERE item_node_id=?`, title, itemNodeID)
	return err
}

// UpdateItemStatus updates the status fields of an item in the cache.
func (d *DB) UpdateItemStatus(itemNodeID, status, statusOptionID string) error {
	_, err := d.db.Exec(`UPDATE items SET status=?, status_option_id=? WHERE item_node_id=?`,
		status, statusOptionID, itemNodeID)
	return err
}

// UpdateItemSprint updates the sprint of an item in the cache.
func (d *DB) UpdateItemSprint(itemNodeID, iterationID, sprintTitle string) error {
	_, err := d.db.Exec(`UPDATE items SET sprint_iteration_id=?, sprint_title=? WHERE item_node_id=?`,
		nullableString(iterationID), sprintTitle, itemNodeID)
	return err
}

// UpdateItemBody updates the body of an item in the cache.
func (d *DB) UpdateItemBody(itemNodeID, body string) error {
	_, err := d.db.Exec(`UPDATE items SET body=? WHERE item_node_id=?`, body, itemNodeID)
	return err
}

// UpdateItemState updates the state (OPEN/CLOSED) of an item in the cache.
func (d *DB) UpdateItemState(itemNodeID, state string) error {
	_, err := d.db.Exec(`UPDATE items SET state=? WHERE item_node_id=?`, state, itemNodeID)
	return err
}

// UpdateItemParent updates the parent_issue_node_id of an item in the cache.
func (d *DB) UpdateItemParent(itemNodeID, parentIssueNodeID string) error {
	_, err := d.db.Exec(`UPDATE items SET parent_issue_node_id=? WHERE item_node_id=?`, parentIssueNodeID, itemNodeID)
	return err
}

// UpdateItemKind updates the kind field of an item in the cache.
func (d *DB) UpdateItemKind(itemNodeID, kind string) error {
	_, err := d.db.Exec(`UPDATE items SET kind=? WHERE item_node_id=?`, kind, itemNodeID)
	return err
}

// UpdateItemCustomFields replaces the entire custom_fields JSON for an item.
func (d *DB) UpdateItemCustomFields(itemNodeID, customFieldsJSON string) error {
	_, err := d.db.Exec(`UPDATE items SET custom_fields=? WHERE item_node_id=?`, customFieldsJSON, itemNodeID)
	return err
}

type scanner interface {
	Scan(dest ...any) error
}

func scanItemRow(rows *sql.Rows) (*Item, error) {
	var it Item
	err := rows.Scan(
		&it.ID, &it.ItemNodeID, &it.IssueNodeID, &it.IssueNumber, &it.IssueURL,
		&it.Title, &it.Body, &it.State,
		&it.SprintIterationID, &it.Status, &it.StatusOptionID,
		&it.TeamArea, &it.Priority, &it.Assignees, &it.Labels, &it.SyncedAt,
		&it.Kind, &it.EpicStatus, &it.Outcome, &it.ParentIssueNodeID,
		&it.SprintTitle, &it.CustomFields,
		&it.ParentIssueNumber,
	)
	if err != nil {
		return nil, fmt.Errorf("scan item row: %w", err)
	}
	return &it, nil
}

func nullableString(s string) interface{} {
	if s == "" {
		return nil
	}
	return s
}
