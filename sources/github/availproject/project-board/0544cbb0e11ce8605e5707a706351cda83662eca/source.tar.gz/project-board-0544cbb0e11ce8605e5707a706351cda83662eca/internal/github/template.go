package github

import (
	"strings"

	"gopkg.in/yaml.v3"
)

// issueFormYAML is the top-level structure of a GitHub issue form template.
type issueFormYAML struct {
	Name  string          `yaml:"name"`
	Body  []issueFormBody `yaml:"body"`
}

type issueFormBody struct {
	Type       string              `yaml:"type"`
	Attributes issueFormAttributes `yaml:"attributes"`
}

type issueFormAttributes struct {
	Label       string `yaml:"label"`
	Description string `yaml:"description"`
	Value       string `yaml:"value"`   // for markdown blocks
	Placeholder string `yaml:"placeholder"`
}

// ParseIssueFormTemplate converts a GitHub issue form YAML template into a
// plain Markdown body suitable for use with the createIssue API.
// textarea fields become ## headers with an HTML comment hint.
// markdown fields are included as-is.
func ParseIssueFormTemplate(raw []byte) (name string, body string, err error) {
	var form issueFormYAML
	if err := yaml.Unmarshal(raw, &form); err != nil {
		return "", "", err
	}

	var sb strings.Builder
	for i, block := range form.Body {
		if i > 0 {
			sb.WriteString("\n")
		}
		switch block.Type {
		case "textarea":
			sb.WriteString("## ")
			sb.WriteString(block.Attributes.Label)
			sb.WriteString("\n")
			if block.Attributes.Description != "" {
				sb.WriteString("<!-- ")
				sb.WriteString(block.Attributes.Description)
				sb.WriteString(" -->\n")
			}
			sb.WriteString("\n")
		case "markdown":
			val := strings.TrimSpace(block.Attributes.Value)
			if val != "" {
				sb.WriteString(val)
				sb.WriteString("\n")
			}
		}
	}

	return form.Name, strings.TrimSpace(sb.String()), nil
}
