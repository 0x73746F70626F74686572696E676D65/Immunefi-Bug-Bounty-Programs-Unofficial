package config

import (
	"fmt"
	"os"
	"path/filepath"

	"gopkg.in/yaml.v3"
)

// ItemType describes how to match and display a category of items.
type ItemType struct {
	Name             string   `yaml:"name"`
	Match            string   `yaml:"match"`             // expr expression; "true" = catch-all default
	Hide             []string `yaml:"hide"`              // normalized field keys to hide in show output
	HideSubitems     bool     `yaml:"hide_subitems"`     // suppress child item list in show output
	TerminalStatuses []string `yaml:"terminal_statuses"` // statuses that mean "done"
	Template         string   `yaml:"template"`          // template name to use when creating this item type
}

// View describes a saved query with display configuration.
type View struct {
	Name          string   `yaml:"name"`
	Query         string   `yaml:"query"`         // expr expression
	Columns       []string `yaml:"columns"`       // normalized field keys to display
	GroupBy       string   `yaml:"group_by"`      // normalized field key to group by
	ShowHierarchy bool     `yaml:"show_hierarchy"` // expand sub-items in list output
}

// Config holds all configuration loaded from config.yaml.
type Config struct {
	GitHubToken  string     `yaml:"github_token"`
	ProjectURL   string     `yaml:"project_url"`
	DefaultTeam  string     `yaml:"default_team"`
	DefaultRepo  string     `yaml:"default_repo"`
	TemplateRepo string     `yaml:"template_repo"` // repo to fetch issue templates from; defaults to default_repo
	TeamField    string     `yaml:"team_field"`
	SprintField  string     `yaml:"sprint_field"`
	ItemTypes    []ItemType `yaml:"item_types"`
	Views        []View     `yaml:"views"`
}

// ConfigDir returns the path to ~/.config/project-board/.
func ConfigDir() (string, error) {
	home, err := os.UserHomeDir()
	if err != nil {
		return "", fmt.Errorf("cannot determine home directory: %w", err)
	}
	return filepath.Join(home, ".config", "project-board"), nil
}

// ConfigPath returns the full path to the config file.
func ConfigPath() (string, error) {
	dir, err := ConfigDir()
	if err != nil {
		return "", err
	}
	return filepath.Join(dir, "config.yaml"), nil
}

// DBPath returns the full path to the SQLite cache database.
func DBPath() (string, error) {
	dir, err := ConfigDir()
	if err != nil {
		return "", err
	}
	return filepath.Join(dir, "cache.db"), nil
}

// Load reads and parses the config file. Returns a clear error if missing.
func Load() (*Config, error) {
	path, err := ConfigPath()
	if err != nil {
		return nil, err
	}

	data, err := os.ReadFile(path)
	if err != nil {
		if os.IsNotExist(err) {
			return nil, fmt.Errorf("config not found. Create %s", path)
		}
		return nil, fmt.Errorf("reading config: %w", err)
	}

	var cfg Config
	if err := yaml.Unmarshal(data, &cfg); err != nil {
		return nil, fmt.Errorf("parsing config: %w", err)
	}

	// Apply defaults for optional fields.
	if cfg.TeamField == "" {
		cfg.TeamField = "Team / Area"
	}
	if cfg.SprintField == "" {
		cfg.SprintField = "Sprint"
	}
	if cfg.TemplateRepo == "" {
		cfg.TemplateRepo = cfg.DefaultRepo
	}

	return &cfg, nil
}

// Validate checks that required fields are present.
func (c *Config) Validate() error {
	if c.GitHubToken == "" {
		return fmt.Errorf("github_token is required in config")
	}
	if c.ProjectURL == "" {
		return fmt.Errorf("project_url is required in config")
	}
	return nil
}

// FindView returns the named view by its Name field, or nil if not found.
func (c *Config) FindView(name string) *View {
	for i := range c.Views {
		if c.Views[i].Name == name {
			return &c.Views[i]
		}
	}
	return nil
}

// EnsureConfigDir creates the config directory if it does not exist.
func EnsureConfigDir() error {
	dir, err := ConfigDir()
	if err != nil {
		return err
	}
	return os.MkdirAll(dir, 0o700)
}
