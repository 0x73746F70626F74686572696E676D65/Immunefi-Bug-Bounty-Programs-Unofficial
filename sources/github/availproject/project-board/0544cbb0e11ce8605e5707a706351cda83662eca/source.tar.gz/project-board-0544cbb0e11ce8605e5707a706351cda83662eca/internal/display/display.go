package display

import (
	"encoding/json"
	"fmt"
	"strings"
	"time"

	"github.com/thunderkeys/project-board/internal/cache"
)

const staleThreshold = time.Hour

// WarnIfStale checks last_synced_at and prints a warning if the cache is older than 1 hour.
func WarnIfStale(db *cache.DB) {
	t, ok, err := db.LastSyncedAt()
	if err != nil || !ok {
		fmt.Println("⚠  Cache has never been synced. Run 'project-board sync' first.")
		return
	}
	age := time.Since(t)
	if age > staleThreshold {
		fmt.Printf("⚠  Cache is %s old. Run 'project-board sync' to refresh.\n", formatAge(age))
	}
}

// DefaultColumns are used when no view or --columns flag is set.
var DefaultColumns = []string{"number", "title", "status", "sprint", "assignee"}

// PrintItems renders a table of items using the specified columns.
// envs must correspond 1:1 with items; each env is from cache.ItemEnv.
func PrintItems(items []cache.Item, envs []map[string]any, columns []string) {
	if len(columns) == 0 {
		columns = DefaultColumns
	}

	// Build column widths: fixed for number, flexible for others.
	widths := make([]int, len(columns))
	for i, col := range columns {
		widths[i] = max(len(col), columnDefaultWidth(col))
	}
	// Measure data widths.
	for _, env := range envs {
		for i, col := range columns {
			v := columnValue(col, env)
			if len(v) > widths[i] {
				widths[i] = len(v)
			}
		}
	}
	// Cap title column.
	for i, col := range columns {
		if col == "title" && widths[i] > 50 {
			widths[i] = 50
		}
	}

	// Header.
	header := formatRow(columns, widths)
	fmt.Println(header)
	fmt.Println(strings.Repeat("─", len(header)))

	for i, it := range items {
		_ = it
		row := make([]string, len(columns))
		for j, col := range columns {
			v := columnValue(col, envs[i])
			row[j] = truncate(v, widths[j])
		}
		fmt.Println(formatRow(row, widths))
	}

	if len(items) == 0 {
		fmt.Println("(no items)")
	}
}

func formatRow(values []string, widths []int) string {
	parts := make([]string, len(values))
	for i, v := range values {
		parts[i] = fmt.Sprintf("%-*s", widths[i], v)
	}
	return strings.TrimRight(strings.Join(parts, "  "), " ")
}

func columnValue(col string, env map[string]any) string {
	if col == "assignee" {
		// Special: pull from the item env's assignees field which is a JSON array stored separately.
		// The caller should put assignees in the env as a pre-formatted string under "assignee".
		if v, ok := env["assignee"]; ok {
			return fmt.Sprintf("%v", v)
		}
		return ""
	}
	v, ok := env[col]
	if !ok || v == nil {
		return ""
	}
	return fmt.Sprintf("%v", v)
}

func columnDefaultWidth(col string) int {
	switch col {
	case "number":
		return 6
	case "title":
		return 40
	case "status":
		return 14
	case "sprint":
		return 12
	case "assignee":
		return 14
	default:
		return 12
	}
}

// PrintTask renders full detail for a single item.
// hiddenFields is a set of normalized field keys to suppress (from item_type config).
func PrintTask(it cache.Item, sprint *cache.Sprint, hiddenFields map[string]bool) {
	fmt.Printf("#%d  %s\n", it.IssueNumber, it.Title)
	fmt.Println(strings.Repeat("─", 44))

	printFieldIf("Kind", it.Kind, hiddenFields)
	printFieldIf("Status", it.Status, hiddenFields)
	printFieldIf("EpicStatus", it.EpicStatus, hiddenFields)
	printFieldIf("Outcome", it.Outcome, hiddenFields)

	if it.ParentIssueNumber > 0 {
		printFieldIf("Parent", fmt.Sprintf("#%d", it.ParentIssueNumber), hiddenFields)
	}

	if sprint != nil {
		printFieldIf("Sprint", fmt.Sprintf("%s  (%s)", sprint.Title, cache.SprintDateRange(sprint)), hiddenFields)
	} else if it.SprintTitle != "" {
		printFieldIf("Sprint", it.SprintTitle, hiddenFields)
	}

	printFieldIf("Team", it.TeamArea, hiddenFields)
	printFieldIf("Priority", it.Priority, hiddenFields)

	assignees := ParseJSONStringArray(it.Assignees)
	if len(assignees) > 0 {
		printFieldIf("Assignees", strings.Join(assignees, ", "), hiddenFields)
	}

	labels := ParseJSONStringArray(it.Labels)
	if len(labels) > 0 {
		printFieldIf("Labels", strings.Join(labels, ", "), hiddenFields)
	}

	printFieldIf("State", it.State, hiddenFields)
	printFieldIf("URL", it.IssueURL, hiddenFields)

	if it.Body != "" {
		fmt.Println()
		fmt.Println(it.Body)
	}
}

func printFieldIf(label, value string, hidden map[string]bool) {
	if value == "" {
		return
	}
	key := cache.NormalizeFieldKey(label)
	if hidden[key] || hidden[strings.ToLower(label)] {
		return
	}
	fmt.Printf("%-10s %s\n", label+":", value)
}

// formatAge returns a human-friendly age like "3h", "25m", "2h30m".
func formatAge(d time.Duration) string {
	d = d.Truncate(time.Minute)
	h := int(d.Hours())
	m := int(d.Minutes()) % 60
	if h > 0 && m > 0 {
		return fmt.Sprintf("%dh%dm", h, m)
	}
	if h > 0 {
		return fmt.Sprintf("%dh", h)
	}
	return fmt.Sprintf("%dm", m)
}

func truncate(s string, n int) string {
	s = strings.TrimSpace(s)
	runes := []rune(s)
	if len(runes) <= n {
		return s
	}
	return string(runes[:n-1]) + "…"
}

// ParseJSONStringArray is exported for use in commands.
func ParseJSONStringArray(s string) []string {
	return parseJSONStringArray(s)
}

func parseJSONStringArray(s string) []string {
	if s == "" || s == "null" {
		return nil
	}
	var arr []string
	if err := json.Unmarshal([]byte(s), &arr); err != nil {
		return nil
	}
	return arr
}

// BuildAssigneeString formats an assignees JSON array as a display string.
func BuildAssigneeString(assigneesJSON string) string {
	logins := parseJSONStringArray(assigneesJSON)
	if len(logins) == 0 {
		return ""
	}
	s := logins[0]
	if len(logins) > 1 {
		s += fmt.Sprintf("+%d", len(logins)-1)
	}
	return s
}

func max(a, b int) int {
	if a > b {
		return a
	}
	return b
}
