package github

import (
	"bytes"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"regexp"
	"strconv"
	"strings"
	"time"
)

const graphqlEndpoint = "https://api.github.com/graphql"

// Client handles GitHub GraphQL API calls.
type Client struct {
	token      string
	httpClient *http.Client
}

// NewClient creates a new GitHub GraphQL client with the given token.
func NewClient(token string) *Client {
	return &Client{
		token: token,
		httpClient: &http.Client{
			Timeout: 30 * time.Second,
		},
	}
}

// graphqlRequest sends a GraphQL request and decodes the response into result.
func (c *Client) graphqlRequest(query string, variables map[string]interface{}, result interface{}) error {
	body := map[string]interface{}{
		"query":     query,
		"variables": variables,
	}
	encoded, err := json.Marshal(body)
	if err != nil {
		return fmt.Errorf("encoding request: %w", err)
	}

	req, err := http.NewRequest("POST", graphqlEndpoint, bytes.NewReader(encoded))
	if err != nil {
		return fmt.Errorf("creating request: %w", err)
	}
	req.Header.Set("Authorization", "bearer "+c.token)
	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("GraphQL-Features", "sub_issues")

	resp, err := c.httpClient.Do(req)
	if err != nil {
		return fmt.Errorf("http request: %w", err)
	}
	defer resp.Body.Close()

	raw, err := io.ReadAll(resp.Body)
	if err != nil {
		return fmt.Errorf("reading response: %w", err)
	}

	if resp.StatusCode != http.StatusOK {
		return fmt.Errorf("github API returned %d: %s", resp.StatusCode, truncate(string(raw), 500))
	}

	// Check for GraphQL errors.
	var errResp struct {
		Errors []struct {
			Message string `json:"message"`
		} `json:"errors"`
	}
	if err := json.Unmarshal(raw, &errResp); err == nil && len(errResp.Errors) > 0 {
		msgs := make([]string, len(errResp.Errors))
		for i, e := range errResp.Errors {
			msgs[i] = e.Message
		}
		return fmt.Errorf("github graphql error: %s", strings.Join(msgs, "; "))
	}

	if err := json.Unmarshal(raw, result); err != nil {
		return fmt.Errorf("decoding response: %w", err)
	}
	return nil
}

// ---- Project URL parsing ----

// ProjectRef holds parsed information from a project URL.
type ProjectRef struct {
	IsOrg  bool
	Owner  string
	Number int
}

var (
	orgProjectRe  = regexp.MustCompile(`^https?://github\.com/orgs/([^/]+)/projects/(\d+)`)
	userProjectRe = regexp.MustCompile(`^https?://github\.com/users/([^/]+)/projects/(\d+)`)
)

// ParseProjectURL parses a GitHub project URL into a ProjectRef.
func ParseProjectURL(url string) (*ProjectRef, error) {
	if m := orgProjectRe.FindStringSubmatch(url); m != nil {
		n, _ := strconv.Atoi(m[2])
		return &ProjectRef{IsOrg: true, Owner: m[1], Number: n}, nil
	}
	if m := userProjectRe.FindStringSubmatch(url); m != nil {
		n, _ := strconv.Atoi(m[2])
		return &ProjectRef{IsOrg: false, Owner: m[1], Number: n}, nil
	}
	// Also handle https://github.com/orgs/{org}/projects/{N} without explicit /orgs/
	// or plain https://github.com/{owner}/projects/{N} (user form without /users/)
	plainRe := regexp.MustCompile(`^https?://github\.com/([^/]+)/projects/(\d+)`)
	if m := plainRe.FindStringSubmatch(url); m != nil {
		n, _ := strconv.Atoi(m[2])
		return &ProjectRef{IsOrg: false, Owner: m[1], Number: n}, nil
	}
	return nil, fmt.Errorf("cannot parse project URL %q (expected https://github.com/orgs/ORG/projects/N or https://github.com/users/USER/projects/N)", url)
}

// ---- Resolve project node ID ----

// ResolveProjectNodeID resolves the project URL to a GitHub node ID.
func (c *Client) ResolveProjectNodeID(ref *ProjectRef) (string, string, error) {
	var nodeID, title string
	if ref.IsOrg {
		const q = `query($org: String!, $number: Int!) {
  organization(login: $org) {
    projectV2(number: $number) {
      id
      title
    }
  }
}`
		var resp struct {
			Data struct {
				Organization struct {
					ProjectV2 struct {
						ID    string `json:"id"`
						Title string `json:"title"`
					} `json:"projectV2"`
				} `json:"organization"`
			} `json:"data"`
		}
		if err := c.graphqlRequest(q, map[string]interface{}{
			"org":    ref.Owner,
			"number": ref.Number,
		}, &resp); err != nil {
			return "", "", err
		}
		nodeID = resp.Data.Organization.ProjectV2.ID
		title = resp.Data.Organization.ProjectV2.Title
	} else {
		const q = `query($user: String!, $number: Int!) {
  user(login: $user) {
    projectV2(number: $number) {
      id
      title
    }
  }
}`
		var resp struct {
			Data struct {
				User struct {
					ProjectV2 struct {
						ID    string `json:"id"`
						Title string `json:"title"`
					} `json:"projectV2"`
				} `json:"user"`
			} `json:"data"`
		}
		if err := c.graphqlRequest(q, map[string]interface{}{
			"user":   ref.Owner,
			"number": ref.Number,
		}, &resp); err != nil {
			return "", "", err
		}
		nodeID = resp.Data.User.ProjectV2.ID
		title = resp.Data.User.ProjectV2.Title
	}
	if nodeID == "" {
		return "", "", fmt.Errorf("project not found or no access")
	}
	return nodeID, title, nil
}

// ---- Field types ----

// FieldData represents raw field data from the GraphQL response.
type FieldData struct {
	ID        string
	Name      string
	FieldType string // "text", "single_select", "iteration"
	Options   []FieldOptionData
	Iterations []IterationData
	CompletedIterations []IterationData
}

// FieldOptionData is an option for a single_select field.
type FieldOptionData struct {
	ID   string
	Name string
}

// IterationData is a sprint/iteration from an iteration field.
type IterationData struct {
	ID           string
	Title        string
	StartDate    string
	Duration     int
	IsCompleted  bool
}

// FetchFields fetches all project fields and sprint iterations.
func (c *Client) FetchFields(projectID string) ([]FieldData, error) {
	const q = `query($projectID: ID!) {
  node(id: $projectID) {
    ... on ProjectV2 {
      fields(first: 50) {
        nodes {
          ... on ProjectV2Field {
            id
            name
          }
          ... on ProjectV2SingleSelectField {
            id
            name
            options { id name }
          }
          ... on ProjectV2IterationField {
            id
            name
            configuration {
              iterations { id title startDate duration }
              completedIterations { id title startDate duration }
            }
          }
        }
      }
    }
  }
}`
	var resp struct {
		Data struct {
			Node struct {
				Fields struct {
					Nodes []json.RawMessage `json:"nodes"`
				} `json:"fields"`
			} `json:"node"`
		} `json:"data"`
	}
	if err := c.graphqlRequest(q, map[string]interface{}{"projectID": projectID}, &resp); err != nil {
		return nil, err
	}

	var fields []FieldData
	for _, raw := range resp.Data.Node.Fields.Nodes {
		// Try to detect the field type by which fields are present.
		var probe struct {
			ID            string `json:"id"`
			Name          string `json:"name"`
			Options       []struct {
				ID   string `json:"id"`
				Name string `json:"name"`
			} `json:"options"`
			Configuration *struct {
				Iterations []struct {
					ID        string `json:"id"`
					Title     string `json:"title"`
					StartDate string `json:"startDate"`
					Duration  int    `json:"duration"`
				} `json:"iterations"`
				CompletedIterations []struct {
					ID        string `json:"id"`
					Title     string `json:"title"`
					StartDate string `json:"startDate"`
					Duration  int    `json:"duration"`
				} `json:"completedIterations"`
			} `json:"configuration"`
		}
		if err := json.Unmarshal(raw, &probe); err != nil {
			continue
		}
		if probe.ID == "" {
			continue
		}

		fd := FieldData{ID: probe.ID, Name: probe.Name}
		if probe.Configuration != nil {
			fd.FieldType = "iteration"
			for _, it := range probe.Configuration.Iterations {
				fd.Iterations = append(fd.Iterations, IterationData{
					ID: it.ID, Title: it.Title, StartDate: it.StartDate, Duration: it.Duration,
				})
			}
			for _, it := range probe.Configuration.CompletedIterations {
				fd.CompletedIterations = append(fd.CompletedIterations, IterationData{
					ID: it.ID, Title: it.Title, StartDate: it.StartDate, Duration: it.Duration,
					IsCompleted: true,
				})
			}
		} else if len(probe.Options) > 0 {
			fd.FieldType = "single_select"
			for _, o := range probe.Options {
				fd.Options = append(fd.Options, FieldOptionData{ID: o.ID, Name: o.Name})
			}
		} else {
			fd.FieldType = "text"
		}
		fields = append(fields, fd)
	}
	return fields, nil
}

// ---- Items ----

// ItemData is a raw project board item from GraphQL.
type ItemData struct {
	ID      string // PVTI_... project item node ID
	Type    string
	Content *IssueContent
	// Field values indexed by field name
	SprintIterationID string
	SprintTitle       string
	StatusName        string
	StatusOptionID    string
	TeamArea          string
	Priority          string
	// Raw field values for further processing
	FieldValues []ItemFieldValue
}

// IssueContent holds the issue data within a project item.
type IssueContent struct {
	ID           string
	Number       int
	Title        string
	Body         string
	State        string
	URL          string
	Assignees    []string
	Labels       []string
	ParentNumber int    // 0 if no parent
	ParentID     string // empty if no parent
}

// ItemFieldValue holds a raw field value from GraphQL.
type ItemFieldValue struct {
	FieldName  string
	FieldID    string
	Type       string // "single_select", "iteration", "text"
	// single_select
	OptionID   string
	OptionName string
	// iteration
	IterationID string
	IterTitle   string
	// text
	Text string
}

// FetchItems fetches all project items via pagination.
// progressFn is called after each page with the running total.
func (c *Client) FetchItems(projectID string, progressFn func(fetched, total int)) ([]ItemData, error) {
	const q = `query($projectID: ID!, $cursor: String) {
  node(id: $projectID) {
    ... on ProjectV2 {
      items(first: 100, after: $cursor) {
        pageInfo { hasNextPage endCursor }
        nodes {
          id
          type
          content {
            ... on Issue {
              id
              number
              title
              body
              state
              url
              assignees(first: 10) { nodes { login } }
              labels(first: 20) { nodes { name } }
              parent { id number }
            }
          }
          fieldValues(first: 20) {
            nodes {
              ... on ProjectV2ItemFieldSingleSelectValue {
                optionId
                name
                field {
                  ... on ProjectV2SingleSelectField { id name }
                }
              }
              ... on ProjectV2ItemFieldIterationValue {
                iterationId
                title
                field {
                  ... on ProjectV2IterationField { id name }
                }
              }
              ... on ProjectV2ItemFieldTextValue {
                text
                field {
                  ... on ProjectV2Field { id name }
                }
              }
            }
          }
        }
      }
    }
  }
}`

	var all []ItemData
	var cursor *string

	for {
		vars := map[string]interface{}{"projectID": projectID}
		if cursor != nil {
			vars["cursor"] = *cursor
		}

		var resp struct {
			Data struct {
				Node struct {
					Items struct {
						PageInfo struct {
							HasNextPage bool   `json:"hasNextPage"`
							EndCursor   string `json:"endCursor"`
						} `json:"pageInfo"`
						Nodes []json.RawMessage `json:"nodes"`
					} `json:"items"`
				} `json:"node"`
			} `json:"data"`
		}
		if err := c.graphqlRequest(q, vars, &resp); err != nil {
			return nil, err
		}

		for _, raw := range resp.Data.Node.Items.Nodes {
			item, err := parseItemRaw(raw)
			if err != nil {
				continue
			}
			if item != nil {
				all = append(all, *item)
			}
		}

		if progressFn != nil {
			progressFn(len(all), -1)
		}

		if !resp.Data.Node.Items.PageInfo.HasNextPage {
			break
		}
		end := resp.Data.Node.Items.PageInfo.EndCursor
		cursor = &end
	}

	return all, nil
}

func parseItemRaw(raw json.RawMessage) (*ItemData, error) {
	var probe struct {
		ID   string          `json:"id"`
		Type string          `json:"type"`
		Content json.RawMessage `json:"content"`
		FieldValues struct {
			Nodes []json.RawMessage `json:"nodes"`
		} `json:"fieldValues"`
	}
	if err := json.Unmarshal(raw, &probe); err != nil {
		return nil, err
	}
	if probe.Type != "ISSUE" || probe.Content == nil {
		return nil, nil
	}

	var issueProbe struct {
		ID     string `json:"id"`
		Number int    `json:"number"`
		Title  string `json:"title"`
		Body   string `json:"body"`
		State  string `json:"state"`
		URL    string `json:"url"`
		Assignees struct {
			Nodes []struct{ Login string `json:"login"` } `json:"nodes"`
		} `json:"assignees"`
		Labels struct {
			Nodes []struct{ Name string `json:"name"` } `json:"nodes"`
		} `json:"labels"`
		Parent *struct {
			ID     string `json:"id"`
			Number int    `json:"number"`
		} `json:"parent"`
	}
	if err := json.Unmarshal(probe.Content, &issueProbe); err != nil {
		return nil, err
	}
	if issueProbe.ID == "" {
		return nil, nil
	}

	content := &IssueContent{
		ID:     issueProbe.ID,
		Number: issueProbe.Number,
		Title:  issueProbe.Title,
		Body:   issueProbe.Body,
		State:  issueProbe.State,
		URL:    issueProbe.URL,
	}
	if issueProbe.Parent != nil {
		content.ParentNumber = issueProbe.Parent.Number
		content.ParentID = issueProbe.Parent.ID
	}
	item := &ItemData{
		ID:      probe.ID,
		Type:    probe.Type,
		Content: content,
	}
	for _, a := range issueProbe.Assignees.Nodes {
		item.Content.Assignees = append(item.Content.Assignees, a.Login)
	}
	for _, l := range issueProbe.Labels.Nodes {
		item.Content.Labels = append(item.Content.Labels, l.Name)
	}

	// Parse field values.
	for _, fvRaw := range probe.FieldValues.Nodes {
		fv := parseFieldValueRaw(fvRaw)
		if fv != nil {
			item.FieldValues = append(item.FieldValues, *fv)
		}
	}

	return item, nil
}

func parseFieldValueRaw(raw json.RawMessage) *ItemFieldValue {
	// Try single select
	var ssProbe struct {
		OptionId string `json:"optionId"`
		Name     string `json:"name"`
		Field    *struct {
			ID   string `json:"id"`
			Name string `json:"name"`
		} `json:"field"`
		IterationId string `json:"iterationId"`
		Title       string `json:"title"`
		Text        string `json:"text"`
	}
	if err := json.Unmarshal(raw, &ssProbe); err != nil {
		return nil
	}
	if ssProbe.Field == nil {
		return nil
	}

	fv := &ItemFieldValue{
		FieldName: ssProbe.Field.Name,
		FieldID:   ssProbe.Field.ID,
	}

	if ssProbe.IterationId != "" {
		fv.Type = "iteration"
		fv.IterationID = ssProbe.IterationId
		fv.IterTitle = ssProbe.Title
	} else if ssProbe.OptionId != "" {
		fv.Type = "single_select"
		fv.OptionID = ssProbe.OptionId
		fv.OptionName = ssProbe.Name
	} else if ssProbe.Text != "" {
		fv.Type = "text"
		fv.Text = ssProbe.Text
	} else {
		return nil
	}
	return fv
}

// ---- Mutations ----

// CreateIssue creates a new issue and returns its node ID, number, and URL.
func (c *Client) CreateIssue(repoID, title, body string) (string, int, string, error) {
	const q = `mutation($repoId: ID!, $title: String!, $body: String) {
  createIssue(input: {
    repositoryId: $repoId
    title: $title
    body: $body
  }) {
    issue { id number url }
  }
}`
	var resp struct {
		Data struct {
			CreateIssue struct {
				Issue struct {
					ID     string `json:"id"`
					Number int    `json:"number"`
					URL    string `json:"url"`
				} `json:"issue"`
			} `json:"createIssue"`
		} `json:"data"`
	}
	if err := c.graphqlRequest(q, map[string]interface{}{
		"repoId": repoID,
		"title":  title,
		"body":   body,
	}, &resp); err != nil {
		return "", 0, "", err
	}
	issue := resp.Data.CreateIssue.Issue
	return issue.ID, issue.Number, issue.URL, nil
}

// AddToProject adds an issue (by content node ID) to a project and returns the project item ID.
func (c *Client) AddToProject(projectID, contentID string) (string, error) {
	const q = `mutation($projectId: ID!, $contentId: ID!) {
  addProjectV2ItemById(input: { projectId: $projectId contentId: $contentId }) {
    item { id }
  }
}`
	var resp struct {
		Data struct {
			AddProjectV2ItemById struct {
				Item struct {
					ID string `json:"id"`
				} `json:"item"`
			} `json:"addProjectV2ItemById"`
		} `json:"data"`
	}
	if err := c.graphqlRequest(q, map[string]interface{}{
		"projectId": projectID,
		"contentId": contentID,
	}, &resp); err != nil {
		return "", err
	}
	return resp.Data.AddProjectV2ItemById.Item.ID, nil
}

// UpdateFieldSingleSelect sets a single-select field value on a project item.
func (c *Client) UpdateFieldSingleSelect(projectID, itemID, fieldID, optionID string) error {
	const q = `mutation($projectId: ID!, $itemId: ID!, $fieldId: ID!, $value: ProjectV2FieldValue!) {
  updateProjectV2ItemFieldValue(input: {
    projectId: $projectId
    itemId: $itemId
    fieldId: $fieldId
    value: $value
  }) {
    projectV2Item { id }
  }
}`
	return c.graphqlRequest(q, map[string]interface{}{
		"projectId": projectID,
		"itemId":    itemID,
		"fieldId":   fieldID,
		"value":     map[string]interface{}{"singleSelectOptionId": optionID},
	}, &struct{}{})
}

// UpdateFieldIteration sets an iteration field value on a project item.
func (c *Client) UpdateFieldIteration(projectID, itemID, fieldID, iterationID string) error {
	const q = `mutation($projectId: ID!, $itemId: ID!, $fieldId: ID!, $value: ProjectV2FieldValue!) {
  updateProjectV2ItemFieldValue(input: {
    projectId: $projectId
    itemId: $itemId
    fieldId: $fieldId
    value: $value
  }) {
    projectV2Item { id }
  }
}`
	return c.graphqlRequest(q, map[string]interface{}{
		"projectId": projectID,
		"itemId":    itemID,
		"fieldId":   fieldID,
		"value":     map[string]interface{}{"iterationId": iterationID},
	}, &struct{}{})
}

// UpdateFieldText sets a text field value on a project item.
func (c *Client) UpdateFieldText(projectID, itemID, fieldID, text string) error {
	const q = `mutation($projectId: ID!, $itemId: ID!, $fieldId: ID!, $value: ProjectV2FieldValue!) {
  updateProjectV2ItemFieldValue(input: {
    projectId: $projectId
    itemId: $itemId
    fieldId: $fieldId
    value: $value
  }) {
    projectV2Item { id }
  }
}`
	return c.graphqlRequest(q, map[string]interface{}{
		"projectId": projectID,
		"itemId":    itemID,
		"fieldId":   fieldID,
		"value":     map[string]interface{}{"text": text},
	}, &struct{}{})
}

// ClearProjectField removes a field value from a project item.
func (c *Client) ClearProjectField(projectID, itemID, fieldID string) error {
	const q = `mutation($projectId: ID!, $itemId: ID!, $fieldId: ID!) {
  clearProjectV2ItemFieldValue(input: {
    projectId: $projectId
    itemId: $itemId
    fieldId: $fieldId
  }) {
    projectV2Item { id }
  }
}`
	return c.graphqlRequest(q, map[string]interface{}{
		"projectId": projectID,
		"itemId":    itemID,
		"fieldId":   fieldID,
	}, &struct{}{})
}

// UpdateIssue updates the title, body, and/or state of an issue.
// Pass empty strings to leave title/body unchanged; pass "" for state to skip.
func (c *Client) UpdateIssue(issueNodeID, title, body, state string) error {
	const q = `mutation($issueId: ID!, $title: String, $body: String, $state: IssueState) {
  updateIssue(input: { id: $issueId title: $title body: $body state: $state }) {
    issue { id number title state }
  }
}`
	vars := map[string]interface{}{"issueId": issueNodeID}
	if title != "" {
		vars["title"] = title
	}
	if body != "" {
		vars["body"] = body
	}
	if state != "" {
		vars["state"] = state
	}
	return c.graphqlRequest(q, vars, &struct{}{})
}

// ResolveRepoNodeID returns the node ID for a repository given owner/name.
func (c *Client) ResolveRepoNodeID(owner, name string) (string, error) {
	const q = `query($owner: String!, $name: String!) {
  repository(owner: $owner, name: $name) { id }
}`
	var resp struct {
		Data struct {
			Repository struct {
				ID string `json:"id"`
			} `json:"repository"`
		} `json:"data"`
	}
	if err := c.graphqlRequest(q, map[string]interface{}{
		"owner": owner,
		"name":  name,
	}, &resp); err != nil {
		return "", err
	}
	if resp.Data.Repository.ID == "" {
		return "", fmt.Errorf("repository %s/%s not found", owner, name)
	}
	return resp.Data.Repository.ID, nil
}

// GetIssueIntID returns the integer database ID for an issue (needed for the sub-issues REST API).
func (c *Client) GetIssueIntID(owner, repo string, number int) (int64, error) {
	url := fmt.Sprintf("https://api.github.com/repos/%s/%s/issues/%d", owner, repo, number)
	req, err := http.NewRequest("GET", url, nil)
	if err != nil {
		return 0, err
	}
	req.Header.Set("Authorization", "bearer "+c.token)
	req.Header.Set("Accept", "application/vnd.github+json")
	resp, err := c.httpClient.Do(req)
	if err != nil {
		return 0, err
	}
	defer resp.Body.Close()
	var issue struct {
		ID int64 `json:"id"`
	}
	if err := json.NewDecoder(resp.Body).Decode(&issue); err != nil {
		return 0, err
	}
	return issue.ID, nil
}

// AddSubIssue adds a sub-issue to a parent issue using the GraphQL addSubIssue mutation.
// epicIssueNodeID and subIssueNodeID are GitHub issue node IDs. replaceParent re-parents
// the sub-issue if it already belongs to a different parent.
func (c *Client) AddSubIssue(epicIssueNodeID, subIssueNodeID string, replaceParent bool) error {
	const q = `mutation($issueId: ID!, $subIssueId: ID!, $replaceParent: Boolean) {
  addSubIssue(input: { issueId: $issueId subIssueId: $subIssueId replaceParent: $replaceParent }) {
    issue { id }
  }
}`
	return c.graphqlRequest(q, map[string]interface{}{
		"issueId":       epicIssueNodeID,
		"subIssueId":    subIssueNodeID,
		"replaceParent": replaceParent,
	}, &struct{}{})
}

// RemoveSubIssue removes a sub-issue from its parent using the GraphQL removeSubIssue mutation.
// parentIssueNodeID and subIssueNodeID are GitHub issue node IDs (e.g. I_kwDO...).
func (c *Client) RemoveSubIssue(parentIssueNodeID, subIssueNodeID string) error {
	const q = `mutation($issueId: ID!, $subIssueId: ID!) {
  removeSubIssue(input: { issueId: $issueId subIssueId: $subIssueId }) {
    issue { id }
  }
}`
	return c.graphqlRequest(q, map[string]interface{}{
		"issueId":    parentIssueNodeID,
		"subIssueId": subIssueNodeID,
	}, &struct{}{})
}

// FetchIssueTemplates fetches all .yml files from .github/ISSUE_TEMPLATE/ in
// the given repo and returns them keyed by filename (without extension).
func (c *Client) FetchIssueTemplates(owner, repo string) (map[string][]byte, error) {
	url := fmt.Sprintf("https://api.github.com/repos/%s/%s/contents/.github/ISSUE_TEMPLATE", owner, repo)
	req, err := http.NewRequest("GET", url, nil)
	if err != nil {
		return nil, err
	}
	req.Header.Set("Authorization", "bearer "+c.token)
	req.Header.Set("Accept", "application/vnd.github+json")

	resp, err := c.httpClient.Do(req)
	if err != nil {
		return nil, fmt.Errorf("listing templates: %w", err)
	}
	defer resp.Body.Close()
	if resp.StatusCode == http.StatusNotFound {
		return nil, nil
	}
	if resp.StatusCode != http.StatusOK {
		return nil, fmt.Errorf("listing templates: HTTP %d", resp.StatusCode)
	}

	var entries []struct {
		Name        string `json:"name"`
		DownloadURL string `json:"download_url"`
	}
	if err := json.NewDecoder(resp.Body).Decode(&entries); err != nil {
		return nil, fmt.Errorf("decoding template list: %w", err)
	}

	result := make(map[string][]byte)
	for _, e := range entries {
		if !strings.HasSuffix(e.Name, ".yml") && !strings.HasSuffix(e.Name, ".yaml") {
			continue
		}
		fileReq, err := http.NewRequest("GET", e.DownloadURL, nil)
		if err != nil {
			continue
		}
		fileReq.Header.Set("Authorization", "bearer "+c.token)
		fileResp, err := c.httpClient.Do(fileReq)
		if err != nil || fileResp.StatusCode != http.StatusOK {
			fileResp.Body.Close()
			continue
		}
		raw, _ := io.ReadAll(fileResp.Body)
		fileResp.Body.Close()
		name := strings.TrimSuffix(strings.TrimSuffix(e.Name, ".yaml"), ".yml")
		result[name] = raw
	}
	return result, nil
}

// ArchiveProjectItem archives a project item (removes it from active views without deleting the issue).
func (c *Client) ArchiveProjectItem(projectID, itemID string) error {
	const q = `mutation($projectId: ID!, $itemId: ID!) {
  archiveProjectV2Item(input: { projectId: $projectId itemId: $itemId }) {
    item { id }
  }
}`
	return c.graphqlRequest(q, map[string]interface{}{
		"projectId": projectID,
		"itemId":    itemID,
	}, &struct{}{})
}

func truncate(s string, n int) string {
	if len(s) <= n {
		return s
	}
	return s[:n] + "..."
}
