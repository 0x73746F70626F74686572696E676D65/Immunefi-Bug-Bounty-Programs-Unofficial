package cache

import (
	"fmt"
	"strconv"
	"strings"
	"time"
)

// SprintQuery describes a single sprint or a range of sprints relative to current.
type SprintQuery struct {
	// IsRange is true when the query selects multiple sprints.
	IsRange bool
	// Single-sprint offset (used when IsRange is false).
	Offset int
	// Range bounds (inclusive). nil means unbounded.
	From *int
	To   *int
}

// parseOffset parses a sprint token like "current", "next", "previous",
// "current+2", "current-1" into an integer offset.
func parseOffset(arg string) (int, error) {
	switch arg {
	case "", "current":
		return 0, nil
	case "next":
		return 1, nil
	case "previous":
		return -1, nil
	}
	if strings.HasPrefix(arg, "current+") {
		n, err := strconv.Atoi(arg[8:])
		if err != nil {
			return 0, fmt.Errorf("invalid sprint argument %q", arg)
		}
		return n, nil
	}
	if strings.HasPrefix(arg, "current-") {
		n, err := strconv.Atoi(arg[8:])
		if err != nil {
			return 0, fmt.Errorf("invalid sprint argument %q", arg)
		}
		return -n, nil
	}
	return 0, fmt.Errorf("invalid sprint argument %q (use: current, next, previous, current+N, current-N)", arg)
}

// ParseSprintArg parses a single-sprint argument and returns an integer offset.
// Kept for backwards compatibility with callers that don't need range support.
func ParseSprintArg(arg string) (int, error) {
	return parseOffset(strings.TrimSpace(arg))
}

// ParseSprintQuery parses a sprint argument that may be a single sprint or a
// range expression. Supported range forms:
//
//	<current   — all sprints before current (exclusive)
//	<=current  — all sprints up to and including current
//	>current   — all sprints after current (exclusive)
//	>=current  — current and all future sprints
//	all        — every sprint
//
// Any offset expression (current, next, current+2, …) is valid in place of
// "current" on either side.
func ParseSprintQuery(arg string) (SprintQuery, error) {
	arg = strings.TrimSpace(arg)
	if arg == "all" {
		return SprintQuery{IsRange: true}, nil
	}
	// Range prefixes: <=, <, >=, >
	for _, prefix := range []string{"<=", "<", ">=", ">"} {
		if strings.HasPrefix(arg, prefix) {
			rest := arg[len(prefix):]
			offset, err := parseOffset(rest)
			if err != nil {
				return SprintQuery{}, err
			}
			q := SprintQuery{IsRange: true}
			switch prefix {
			case "<":
				o := offset - 1
				q.To = &o
			case "<=":
				q.To = &offset
			case ">":
				o := offset + 1
				q.From = &o
			case ">=":
				q.From = &offset
			}
			return q, nil
		}
	}
	// Single sprint.
	offset, err := parseOffset(arg)
	if err != nil {
		return SprintQuery{}, err
	}
	return SprintQuery{Offset: offset}, nil
}

// ResolveSprintsByQuery returns the sprints matching q. For a single-sprint
// query it returns a one-element slice. For a range it returns all sprints
// within the bounds (relative to current), in ascending order.
func (d *DB) ResolveSprintsByQuery(today time.Time, q SprintQuery) ([]Sprint, error) {
	if !q.IsRange {
		s, err := d.ResolveSprintByOffset(today, q.Offset)
		if err != nil {
			return nil, err
		}
		return []Sprint{*s}, nil
	}
	sprints, err := d.AllSprints()
	if err != nil {
		return nil, err
	}
	if len(sprints) == 0 {
		return nil, fmt.Errorf("no sprints found in cache; run 'project-board sync' first")
	}
	currentIdx := -1
	for i, s := range sprints {
		start, err := time.Parse("2006-01-02", s.StartDate)
		if err != nil {
			continue
		}
		end := start.AddDate(0, 0, s.DurationDays)
		if !today.Before(start) && today.Before(end) {
			currentIdx = i
			break
		}
	}
	if currentIdx == -1 {
		for i, s := range sprints {
			start, err := time.Parse("2006-01-02", s.StartDate)
			if err != nil {
				continue
			}
			if start.After(today) {
				currentIdx = i
				break
			}
		}
		if currentIdx == -1 {
			currentIdx = len(sprints) - 1
		}
	}
	fromIdx := 0
	toIdx := len(sprints) - 1
	if q.From != nil {
		fromIdx = currentIdx + *q.From
		if fromIdx < 0 {
			fromIdx = 0
		}
	}
	if q.To != nil {
		toIdx = currentIdx + *q.To
		if toIdx >= len(sprints) {
			toIdx = len(sprints) - 1
		}
	}
	if fromIdx > toIdx {
		return nil, nil
	}
	return sprints[fromIdx : toIdx+1], nil
}

// ResolveSprintByOffset finds the sprint at the given offset relative to the
// current sprint. Offset 0 = current, +1 = next, -1 = previous, etc.
// Returns an error if today falls in no sprint for offset 0 or if the offset
// is out of bounds.
func (d *DB) ResolveSprintByOffset(today time.Time, offset int) (*Sprint, error) {
	sprints, err := d.AllSprints()
	if err != nil {
		return nil, err
	}
	if len(sprints) == 0 {
		return nil, fmt.Errorf("no sprints found in cache; run 'project-board sync' first")
	}

	// Find the current sprint index: today >= start_date AND today < start_date + duration_days
	currentIdx := -1
	for i, s := range sprints {
		start, err := time.Parse("2006-01-02", s.StartDate)
		if err != nil {
			continue
		}
		end := start.AddDate(0, 0, s.DurationDays)
		if !today.Before(start) && today.Before(end) {
			currentIdx = i
			break
		}
	}

	if currentIdx == -1 {
		// No sprint contains today. For offset 0, find the nearest upcoming sprint.
		for i, s := range sprints {
			start, err := time.Parse("2006-01-02", s.StartDate)
			if err != nil {
				continue
			}
			if start.After(today) {
				currentIdx = i
				break
			}
		}
		// If still not found, use the last sprint.
		if currentIdx == -1 {
			currentIdx = len(sprints) - 1
		}
	}

	targetIdx := currentIdx + offset
	if targetIdx < 0 || targetIdx >= len(sprints) {
		return nil, fmt.Errorf("sprint not found (offset out of range)")
	}
	result := sprints[targetIdx]
	return &result, nil
}

// SprintDateRange returns a human-readable date range string like "Mar 23 – Apr 6".
func SprintDateRange(s *Sprint) string {
	start, err := time.Parse("2006-01-02", s.StartDate)
	if err != nil {
		return ""
	}
	end := start.AddDate(0, 0, s.DurationDays-1)
	startStr := start.Format("Jan 2")
	endStr := end.Format("Jan 2")
	return startStr + " \u2013 " + endStr
}
