package cache

import (
	"encoding/json"
	"regexp"
	"strings"
)

var nonAlphaNum = regexp.MustCompile(`[^a-z0-9]+`)

// NormalizeFieldKey converts a field display name to a normalized key for expr environments.
// Examples: "Team / Area" → "team_area", "Sprint" → "sprint", "EpicStatus" → "epicstatus"
func NormalizeFieldKey(name string) string {
	key := nonAlphaNum.ReplaceAllString(strings.ToLower(name), "_")
	return strings.Trim(key, "_")
}

// ItemEnv builds the expr evaluation environment for an item.
// All project field values come from the item's CustomFields JSON.
// Well-known issue-level fields (number, title, state, has_parent, parent) are always present.
func ItemEnv(it Item) map[string]any {
	env := map[string]any{
		"number":     it.IssueNumber,
		"title":      it.Title,
		"state":      it.State,
		"has_parent": it.ParentIssueNodeID != "",
		"parent":     nil,
	}
	if it.ParentIssueNumber > 0 {
		env["parent"] = it.ParentIssueNumber
	}

	// Project field values from custom_fields JSON.
	if it.CustomFields != "" && it.CustomFields != "{}" {
		var custom map[string]any
		if err := json.Unmarshal([]byte(it.CustomFields), &custom); err == nil {
			for k, v := range custom {
				env[k] = v
			}
		}
	}

	// Fallback to dedicated columns for items synced before custom_fields was added.
	if _, ok := env["status"]; !ok {
		env["status"] = nilIfEmpty(it.Status)
	}
	if _, ok := env["sprint"]; !ok {
		env["sprint"] = nilIfEmpty(it.SprintTitle)
	}
	if _, ok := env["team"]; !ok {
		env["team"] = nilIfEmpty(it.TeamArea)
	}
	if _, ok := env["priority"]; !ok {
		env["priority"] = nilIfEmpty(it.Priority)
	}
	if _, ok := env["kind"]; !ok {
		env["kind"] = nilIfEmpty(it.Kind)
	}

	return env
}

func nilIfEmpty(s string) any {
	if s == "" {
		return nil
	}
	return s
}
