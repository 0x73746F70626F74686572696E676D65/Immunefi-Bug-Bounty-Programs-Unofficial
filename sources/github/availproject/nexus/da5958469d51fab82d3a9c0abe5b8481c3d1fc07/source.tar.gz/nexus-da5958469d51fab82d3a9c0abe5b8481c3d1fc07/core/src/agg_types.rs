use crate::types::{InitAccount, NexusRollupPI, SubmitProof, TxSignature};
use serde::{Deserialize, Serialize};

#[derive(Serialize, Deserialize, Debug, PartialEq)]
pub struct SubmitProofTransaction {
    pub signature: TxSignature,
    pub params: SubmitProof,
    pub proof: Vec<u8>,
}

#[derive(Clone, Serialize, Deserialize, Debug, PartialEq, Eq)]
pub struct RuntimeTransaction {
    pub signature: TxSignature,
    pub params: SubmitProof,
}

#[derive(Clone, Serialize, Deserialize, Debug, PartialEq, Eq)]
pub struct AggregatedTransaction {
    pub submit_proof_txs: Vec<RuntimeTransaction>,
    pub aggregated_proof: Vec<u8>,
}

#[derive(Clone, Serialize, Deserialize, Debug, PartialEq, Eq)]
pub struct AggregatedPublicInput(Vec<NexusRollupPI>);

#[derive(Clone, Serialize, Deserialize, Debug, PartialEq, Eq)]
pub struct InitTransaction {
    pub signature: TxSignature,
    pub params: InitAccount,
}
