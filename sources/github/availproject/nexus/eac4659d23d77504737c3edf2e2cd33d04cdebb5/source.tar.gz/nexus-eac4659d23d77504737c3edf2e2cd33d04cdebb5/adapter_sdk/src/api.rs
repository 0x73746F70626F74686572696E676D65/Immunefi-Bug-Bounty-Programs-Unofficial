use std::collections::HashMap;

use anyhow::anyhow;
use nexus_core::types::{AccountWithProof, NexusBlockWithTransactions, NexusHeader, Transaction, TransactionWithStatus, H256};

#[derive(Debug, Clone)]
pub struct NexusAPI {
    url: String,
    client: reqwest::Client,
}

impl NexusAPI {
    pub fn new(url: &str) -> Self {
        Self {
            url: String::from(url),
            client: reqwest::Client::new(),
        }
    }

    pub async fn send_tx(&self, tx: Transaction) -> Result<String, anyhow::Error> {
        let url_with_tx = format!("{}/tx", self.url);

        let response = self.client.post(url_with_tx).json(&tx).send().await?;

        // Check if the request was successful
        if response.status().is_success() {
            Ok(match response.text().await {
                Ok(i) => i,
                Err(e) => return Err(anyhow!(e)),
            })
        } else {
            Err(anyhow!(
                "Post transaction call failed with status code: {}",
                response.status()
            ))
        }
    }

    pub async fn get_header(&self, hash: &H256) -> Result<NexusHeader, anyhow::Error> {
        let hash_hex = hex::encode(hash.as_slice());

        let url_with_hash = format!("{}/header?hash={}", self.url, hash_hex);

        let response = self.client.get(&url_with_hash).send().await?;

        if response.status().is_success() {
            let nexus_header: NexusHeader = response.json().await?;

            Ok(nexus_header)
        } else {
            Err(anyhow!(
                "Request failed with status code: {}",
                response.status()
            ))
        }
    }

    pub async fn get_range(&self) -> Result<Vec<H256>, anyhow::Error> {
        let response = reqwest::get(format!("{}/range", self.url)).await?;

        // Check if the request was successful
        if !response.status().is_success() {
            println!(
                "⛔️ Request to nexus failed with status {}. Nexus must be down",
                response.status()
            );

            return Err(anyhow!(
                "GET request failed with status: {}",
                response.status()
            ));
        }

        let range: Vec<H256> = response.json().await?;

        Ok(range)
    }

    pub async fn get_account_state(&self, app_account_id: &H256) -> Result<AccountWithProof, anyhow::Error> {
        let app_account_id = hex::encode(app_account_id.as_slice());
        let mut params = HashMap::new();
        params.insert("app_account_id".to_string(), app_account_id.to_string());

        let response = self.client.get(&format!("{}/account", self.url)).query(&params).send().await?;

        if response.status().is_success() {
            let account: AccountWithProof = response.json().await?;

            Ok(account)
        } else {
            Err(anyhow!(
                "Request failed with status code: {}, url: {}",
                response.status(),
                &format!("{}/account", self.url)
            ))
        }
    }

    pub async fn get_block(&self, block_number: u32) -> Result<NexusBlockWithTransactions, anyhow::Error> {
        let mut params = HashMap::new();
        params.insert("block_number".to_string(), block_number.to_string());

        let response = self.client.get(&format!("{}/block", self.url)).query(&params).send().await?;

        if response.status().is_success() {
            let block: NexusBlockWithTransactions = response.json().await?;

            Ok(block)
        } else {
            Err(anyhow!(
                "Request failed with status code: {}, url: {}",
                response.status(),
                &format!("{}/block", self.url)
            ))
        }
    }

    pub async fn get_transaction_status(&self, hash: &H256) -> Result<TransactionWithStatus, anyhow::Error> {
        let mut params = HashMap::new();
        params.insert("tx_hash".to_string(), hash.to_string());

        let response = self.client.get(&format!("{}/tx_status", self.url)).query(&params).send().await?;

        if response.status().is_success() {
            let tx_status: TransactionWithStatus = response.json().await?;
            Ok(tx_status)
        } else {
            Err(anyhow!(
                "Request failed with status code: {}, url: {}",
                response.status(),
                &format!("{}/tx_status", self.url)
            ))
        }
    }
}
