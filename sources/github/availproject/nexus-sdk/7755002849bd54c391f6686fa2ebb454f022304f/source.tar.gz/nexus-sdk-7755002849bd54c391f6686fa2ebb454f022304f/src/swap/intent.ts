import Decimal from 'decimal.js';
import type { Hex } from 'viem';
import type { ChainListType } from '../domain';
import { equalFold } from '../services/strings';
import { resolveExactInAmountBasis, selectExactInQuoteOutput } from './amount-basis';
import { type SwapData, type SwapIntent, SwapMode, type SwapRoute } from './types';

// ---------------------------------------------------------------------------
// createSwapIntent
// ---------------------------------------------------------------------------

/**
 * Builds a user-friendly intent object for the onIntent hook.
 * This is used to display swap details before the user approves.
 */
export const createSwapIntent = (
  route: SwapRoute,
  input: SwapData,
  chainList: ChainListType
): SwapIntent => {
  const dstChainData = chainList.getChainByID(route.destination.chainId);
  const exactInAmountBasis = resolveExactInAmountBasis(route.exactInAmountBasis);
  const identityAmount =
    input.mode === SwapMode.EXACT_IN
      ? (route.destination.identityOutput?.amount ?? new Decimal(0))
      : new Decimal(0);
  const identityValue =
    input.mode === SwapMode.EXACT_IN
      ? (route.destination.identityOutput?.value ?? new Decimal(0))
      : new Decimal(0);

  // Destination amount. A non-positive `toAmountRaw` in EXACT_OUT is the reservation /
  // gas-only sentinel — no tokens are delivered to the user, so the amount is "0" rather
  // than the garbage `formatTokenAmount` would produce from a negative bigint.
  let destinationAmount: string;
  if (input.mode === SwapMode.EXACT_OUT) {
    destinationAmount =
      input.data.toAmountRaw > 0n
        ? formatTokenAmount(input.data.toAmountRaw, route.dstTokenInfo.decimals)
        : '0';
  } else {
    // EXACT_IN: use swap output if available, else inputAmount.min
    if (route.destination.swap.tokenSwap) {
      destinationAmount = new Decimal(
        selectExactInQuoteOutput(route.destination.swap.tokenSwap.quote, exactInAmountBasis).amount
      )
        .plus(identityAmount)
        .toFixed();
    } else {
      destinationAmount = route.destination.inputAmount.min.plus(identityAmount).toFixed();
    }
  }

  // Destination value (USD) — destination-facing value semantics. When the route runs
  // a destination swap the aggregator reports the USD value; when toToken IS COT there's
  // no swap, so we price the amount via oracle (falling back to the raw amount since
  // COT is USDC, ≈$1). Reservation/gas-only sentinels (toAmountRaw ≤ 0n in EXACT_OUT)
  // deliver no tokens, so the value collapses to "0".
  let destinationValue: string | undefined;
  if (input.mode === SwapMode.EXACT_OUT && (input.data.toAmountRaw ?? 0n) <= 0n) {
    destinationValue = '0';
  } else if (route.destination.swap.tokenSwap) {
    destinationValue = new Decimal(
      selectExactInQuoteOutput(route.destination.swap.tokenSwap.quote, exactInAmountBasis).value
    )
      .plus(identityValue)
      .toString();
  } else {
    // No destination swap. Path A (directDestination) delivers the toToken via token-role SOURCE
    // swaps on the dst chain, so sum their aggregator-reported USD values — the direct analog of a
    // destination tokenSwap's `output.value`, and accurate without an oracle (the SDK never
    // guarantees the toToken price is in `oraclePrices`). Falls through to the oracle/amount path
    // when that's unavailable: a non-Path-A route (toToken IS COT, ≈$1), an aggregator that reported
    // no price (value 0), or identity-only holdings with no swap leg.
    const directSwapValue = route.directDestination
      ? route.source.swaps
          .filter((s) => s.chainID === route.destination.chainId && s.outputRole !== 'gas')
          .reduce(
            (sum, s) => sum.plus(selectExactInQuoteOutput(s.quote, exactInAmountBasis).value),
            new Decimal(0)
          )
      : new Decimal(0);
    if (directSwapValue.gt(0)) {
      destinationValue = directSwapValue.plus(identityValue).toString();
    } else {
      const oraclePrice = route.extras.oraclePrices.find(
        (entry) =>
          entry.chainId === route.destination.chainId &&
          equalFold(entry.tokenAddress, route.dstTokenInfo.contractAddress)
      );
      destinationValue = oraclePrice
        ? new Decimal(destinationAmount).mul(oraclePrice.priceUsd).toString()
        : destinationAmount;
    }
  }

  // Gas info — sourced from the destination gas swap's output (native delivered to EOA). Path A has
  // no dst swap; it delivers gas via SOURCE swaps tagged `outputRole === 'gas'`, so fall back to the
  // sum of those legs when `gasSwap` is null. Tag-based (not native-output-based) so an EXACT_IN Path A
  // that delivers a NATIVE toToken doesn't count its delivery legs as gas.
  const nativeCurrency = dstChainData.nativeCurrency ?? { symbol: 'ETH', decimals: 18 };
  const gasOutputRaw =
    route.destination.swap.gasSwap?.quote.output.amountRaw ??
    route.bridge?.destinationGas?.amountRaw ??
    route.source.swaps
      .filter((swap) => swap.chainID === route.destination.chainId && swap.outputRole === 'gas')
      .reduce((sum, swap) => sum + swap.quote.output.amountRaw, 0n);
  const gasAmount =
    gasOutputRaw > 0n ? formatTokenAmount(gasOutputRaw, nativeCurrency.decimals) : '0';
  const gasValue = undefined;

  // Bridge fees
  let bridgeFees: SwapIntent['feesAndBuffer']['bridge'] = null;
  if (route.bridge) {
    const fees = route.bridge.estimatedFees;
    const total = fees.caGas.plus(fees.protocol).plus(fees.solver);
    bridgeFees = {
      caGas: fees.caGas.toString(),
      protocol: fees.protocol.toString(),
      solver: fees.solver.toString(),
      total: total.toString(),
    };
  }

  // Sources
  const sources: SwapIntent['sources'] = route.extras.assetsUsed.map((asset) => {
    const chain = chainList.getChainByID(asset.chainID);
    const balance = route.extras.balances.find(
      (entry) =>
        entry.chainID === asset.chainID && equalFold(entry.tokenAddress, asset.tokenAddress)
    );
    const sourceValue =
      balance && new Decimal(balance.amount).gt(0)
        ? new Decimal(asset.amount).div(balance.amount).mul(balance.value).toFixed()
        : undefined;

    return {
      amount: asset.amount,
      value: sourceValue,
      chain: {
        id: asset.chainID,
        logo: chain.custom?.icon ?? '',
        name: chain.name ?? `Chain ${asset.chainID}`,
      },
      token: {
        contractAddress: asset.tokenAddress,
        decimals: asset.decimals,
        symbol: asset.symbol,
      },
    };
  });

  return {
    destination: {
      amount: destinationAmount,
      value: destinationValue,
      chain: {
        id: route.destination.chainId,
        logo: dstChainData.custom?.icon ?? '',
        name: dstChainData.name ?? `Chain ${route.destination.chainId}`,
      },
      token: {
        contractAddress: route.dstTokenInfo.contractAddress,
        decimals: route.dstTokenInfo.decimals,
        symbol: route.dstTokenInfo.symbol,
      },
      gas: {
        amount: gasAmount,
        value: gasValue,
        token: {
          contractAddress: '0x' as Hex, // Native currency uses zero address
          decimals: nativeCurrency.decimals ?? 18,
          symbol: nativeCurrency.symbol ?? 'ETH',
        },
      },
    },
    feesAndBuffer: {
      buffer: route.buffer.amount,
      bridge: bridgeFees,
    },
    bridgeProvider: route.bridge?.provider ?? null,
    sources,
  };
};

function formatTokenAmount(amount: bigint, decimals: number): string {
  const divisor = 10n ** BigInt(decimals);
  const whole = amount / divisor;
  const remainder = amount % divisor;
  if (remainder === 0n) return whole.toString();
  const remainderStr = remainder.toString().padStart(decimals, '0').replace(/0+$/, '');
  return `${whole}.${remainderStr}`;
}
