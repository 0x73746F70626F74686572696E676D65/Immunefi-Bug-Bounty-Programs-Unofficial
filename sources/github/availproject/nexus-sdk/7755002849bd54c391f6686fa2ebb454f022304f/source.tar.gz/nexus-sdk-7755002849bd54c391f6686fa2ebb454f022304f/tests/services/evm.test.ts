import { beforeEach, describe, expect, it, vi } from 'vitest';
import { UserRejectedRequestError, type WalletClient } from 'viem';
import { ExecutionError, UserActionError } from '../../src/domain/errors';
import {
  confirmStepReceipt,
  getL1Fee,
  switchChain,
  waitForTxReceipt,
} from '../../src/services/evm';
import * as evmService from '../../src/services/evm';

const readContract = vi.fn();

vi.mock('viem', async () => {
  const actual = await vi.importActual<typeof import('viem')>('viem');
  return {
    ...actual,
    createPublicClient: vi.fn(() => ({ readContract })),
    fallback: vi.fn((transports) => transports[0]),
    http: vi.fn((url) => url),
  };
});

describe('getL1Fee', () => {
  beforeEach(() => {
    readContract.mockReset();
  });

  it('sums fees across multiple OP stack transactions', async () => {
    readContract.mockResolvedValueOnce(97n).mockResolvedValueOnce(143n);

    const fee = await getL1Fee(
      {
        id: 84532,
        name: 'Base Sepolia',
        rpcUrls: { default: { http: ['https://base-sepolia.example'] } },
      } as never,
      [
        {
          toAddress: '0x0000000000000000000000000000000000000001',
          input: '0x01',
        },
        {
          toAddress: '0x0000000000000000000000000000000000000002',
          input: '0x02',
        },
      ]
    );

    expect(fee).toBe(240n);
    expect(readContract).toHaveBeenCalledTimes(2);
  });
});

describe('confirmStepReceipt', () => {
  const step = { stepId: 'source_swap:42161', stepType: 'source_swap', label: 'Source swap' };
  const TX = '0xabc0000000000000000000000000000000000000000000000000000000000001' as const;

  const makeClient = (
    status: 'success' | 'reverted',
    onArgs?: (a: { confirmations: number }) => void
  ) =>
    ({
      waitForTransactionReceipt: async (a: { confirmations: number }) => {
        onArgs?.(a);
        return { status };
      },
    }) as never;

  it('returns the txHash when the receipt succeeds', async () => {
    await expect(confirmStepReceipt(makeClient('success'), TX, 42161, step)).resolves.toBe(TX);
  });

  it('throws a step-tagged ExecutionError on revert', async () => {
    const error = await confirmStepReceipt(makeClient('reverted'), TX, 42161, step).catch((e) => e);
    expect(error).toBeInstanceOf(ExecutionError);
    expect(error).toMatchObject({
      code: 'execution/tx_onchain_reverted',
      message: 'Source swap reverted on chain 42161',
      context: {
        service: 'rpc',
        stepId: 'source_swap:42161',
        stepType: 'source_swap',
        chainId: 42161,
      },
    });
  });

  it('waits 1 block on every chain', async () => {
    let confirmations: number | undefined;
    const capture = (a: { confirmations: number }) => {
      confirmations = a.confirmations;
    };
    await confirmStepReceipt(makeClient('success', capture), TX, 1, step);
    expect(confirmations).toBe(1);
    await confirmStepReceipt(makeClient('success', capture), TX, 42161, step);
    expect(confirmations).toBe(1);
  });

  it('keeps confirmation count separate from the receipt timeout', async () => {
    const waitForTransactionReceipt = vi.fn().mockResolvedValue({ status: 'success' });

    await confirmStepReceipt(
      { waitForTransactionReceipt } as never,
      TX,
      42161,
      step,
      { confirmations: 2 }
    );

    expect(waitForTransactionReceipt).toHaveBeenCalledWith({
      confirmations: 2,
      hash: TX,
      timeout: 180_000,
    });
  });
});

describe('waitForTxReceipt', () => {
  const TX = '0xabc0000000000000000000000000000000000000000000000000000000000001' as const;

  it('uses the 3-minute default and falls back to a direct receipt lookup when waiting fails', async () => {
    const waitError = new Error('receipt wait timed out');
    const waitForTransactionReceipt = vi.fn().mockRejectedValue(waitError);
    const receipt = { status: 'success' } as const;
    const getTransactionReceipt = vi.fn().mockResolvedValue(receipt);

    await expect(
      waitForTxReceipt(
        TX,
        {
          waitForTransactionReceipt,
          getTransactionReceipt,
        } as never
      )
    ).resolves.toEqual([receipt, null]);

    expect(waitForTransactionReceipt).toHaveBeenCalledWith({
      confirmations: 1,
      hash: TX,
      timeout: 180_000,
    });
    expect(getTransactionReceipt).toHaveBeenCalledWith({ hash: TX });
  });

  it('accepts named confirmation and timeout options', async () => {
    const waitForTransactionReceipt = vi.fn().mockResolvedValue({ status: 'success' });

    await waitForTxReceipt(
      TX,
      { waitForTransactionReceipt } as never,
      { confirmations: 2, timeout: 4_000 }
    );

    expect(waitForTransactionReceipt).toHaveBeenCalledWith({
      confirmations: 2,
      hash: TX,
      timeout: 4_000,
    });
  });
});

describe('switchChain', () => {
  it('stops after a rejected switch without prompting to add the chain', async () => {
    const client = {
      getChainId: vi.fn().mockResolvedValue(1),
      switchChain: vi.fn().mockRejectedValue(new UserRejectedRequestError(new Error('denied'))),
      addChain: vi.fn(),
    } as unknown as WalletClient;

    const error = await switchChain(client, { id: 8453 } as never).catch((caught) => caught);

    expect(error).toBeInstanceOf(UserActionError);
    expect(error).toMatchObject({ code: 'user_action/tx_send_denied' });
    expect(client.switchChain).toHaveBeenCalledTimes(1);
    expect(client.addChain).not.toHaveBeenCalled();
  });
});

describe('evm service exports', () => {
  it('does not keep unused allowance write helpers without local chain switching', () => {
    expect(evmService).not.toHaveProperty('erc20SetAllowance');
  });
});
