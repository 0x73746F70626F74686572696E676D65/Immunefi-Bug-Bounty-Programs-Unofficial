import { describe, expect, it, vi } from 'vitest';
import Decimal from 'decimal.js';
import type { Hex } from 'viem';
import {
  classifyFastPath,
  greedyUsdPrefix,
  selectRoughEligibleSources,
} from '../../src/swap/route';
import { CurrencyID } from '../../src/swap/cot';
import { SwapMode } from '../../src/swap/types';
import type { ChainListType } from '../../src/domain';
import {
  ARB_CHAIN,
  BASE_CHAIN,
  OP_CHAIN,
  USDC_ARB,
  USDC_BASE,
  USDC_OP,
  USDT_ARB,
  USDT_BASE,
  USDT_OP,
  WETH,
  makeSwapChainList,
  makeSwapChainListWithUsdtCot as makeChainListWithUsdtCot,
} from '../helpers/swap';

type Member = { chainID: number; tokenAddress: Hex };

const classify = (over: {
  chainList?: ChainListType;
  members: Member[];
  dstTokenAddress: Hex;
  allowDirectDestination: boolean;
  toAmountRaw?: bigint;
  mode?: SwapMode;
  cotCurrencyId?: number;
}) =>
  classifyFastPath({
    chainList: over.chainList ?? makeSwapChainList(),
    members: over.members,
    dstChainId: BASE_CHAIN,
    dstTokenAddress: over.dstTokenAddress,
    cotCurrencyId: over.cotCurrencyId ?? CurrencyID.USDC,
    allowDirectDestination: over.allowDirectDestination,
    toAmountRaw: over.toAmountRaw ?? 1_000_000n,
    mode: over.mode ?? SwapMode.EXACT_OUT,
  });

describe('classifyFastPath', () => {
  it('A (direct): all members on the destination chain + a token swap is needed', () => {
    expect(
      classify({
        members: [
          { chainID: BASE_CHAIN, tokenAddress: WETH },
          { chainID: BASE_CHAIN, tokenAddress: USDC_BASE },
        ],
        dstTokenAddress: WETH,
        allowDirectDestination: true,
      })
    ).toEqual({ kind: 'direct' });
  });

  it('A does not fire when a member is off the destination chain (falls to family checks)', () => {
    // Cross-chain WETH→WETH: WETH is non-mesh → no family → null (default COT flow).
    expect(
      classify({
        members: [
          { chainID: BASE_CHAIN, tokenAddress: WETH },
          { chainID: ARB_CHAIN, tokenAddress: WETH },
        ],
        dstTokenAddress: WETH,
        allowDirectDestination: true,
      })
    ).toBeNull();
  });

  it('A does not fire when the caller disallows direct destination routing', () => {
    expect(
      classify({
        members: [{ chainID: BASE_CHAIN, tokenAddress: USDC_BASE }],
        dstTokenAddress: USDC_BASE,
        allowDirectDestination: false,
      })
    ).toBeNull();
  });

  it('B1 (same-token-out): EXACT_OUT, uniform non-COT family == destination family, no gas', () => {
    expect(
      classify({
        members: [
          { chainID: ARB_CHAIN, tokenAddress: USDT_ARB },
          { chainID: OP_CHAIN, tokenAddress: USDT_OP },
        ],
        dstTokenAddress: USDT_BASE,
        allowDirectDestination: true,
        mode: SwapMode.EXACT_OUT,
      })
    ).toEqual({ kind: 'same-token-out', familyId: CurrencyID.USDT });
  });

  it('B1 includes the current COT when a source must bridge', () => {
    expect(
      classify({
        members: [{ chainID: ARB_CHAIN, tokenAddress: USDC_ARB }],
        dstTokenAddress: USDC_BASE,
        allowDirectDestination: false,
        mode: SwapMode.EXACT_OUT,
      })
    ).toEqual({ kind: 'same-token-out', familyId: CurrencyID.USDC });
  });

  it('B1 does not fire on EXACT_IN (that is the existing buildSameTokenBridgeRoute path)', () => {
    // Same-family but EXACT_IN: the classifier leaves it to the EXACT_IN same-token dispatch.
    expect(
      classify({
        members: [{ chainID: ARB_CHAIN, tokenAddress: USDT_ARB }],
        dstTokenAddress: USDT_BASE,
        allowDirectDestination: true,
        mode: SwapMode.EXACT_IN,
      })
    ).toBeNull();
  });

  it('leaves stable-family optimization to the settlement selector', () => {
    expect(
      classify({
        chainList: makeChainListWithUsdtCot(),
        members: [
          { chainID: ARB_CHAIN, tokenAddress: USDT_ARB },
          { chainID: OP_CHAIN, tokenAddress: USDT_OP },
        ],
        dstTokenAddress: WETH, // non-mesh destination
        allowDirectDestination: true,
        mode: SwapMode.EXACT_IN,
      })
    ).toBeNull();
  });

  it('strict-ALL: a mixed-family member set disqualifies every family path (null)', () => {
    expect(
      classify({
        chainList: makeChainListWithUsdtCot(),
        members: [
          { chainID: ARB_CHAIN, tokenAddress: USDT_ARB },
          { chainID: OP_CHAIN, tokenAddress: USDC_OP },
        ],
        dstTokenAddress: WETH,
        allowDirectDestination: true,
        mode: SwapMode.EXACT_IN,
      })
    ).toBeNull();
  });

  it('a non-mesh source (WETH) to a non-mesh destination is null', () => {
    expect(
      classify({
        members: [{ chainID: ARB_CHAIN, tokenAddress: WETH }],
        dstTokenAddress: WETH,
        allowDirectDestination: true,
        mode: SwapMode.EXACT_IN,
      })
    ).toBeNull();
  });
});

describe('RES — greedyUsdPrefix / selectRoughEligibleSources', () => {
  const holdings = [
    { chainID: BASE_CHAIN, tokenAddress: USDC_BASE, value: 5 },
    { chainID: ARB_CHAIN, tokenAddress: USDC_ARB, value: 5 },
    { chainID: OP_CHAIN, tokenAddress: USDC_OP, value: 5 },
  ];

  it('greedyUsdPrefix returns the leading prefix that first reaches the target, including the tipping member', () => {
    // target 8 → add 5 (<8), add 5 (=10 ≥ 8, but the check runs BEFORE the 3rd) → prefix = first two.
    expect(greedyUsdPrefix(holdings, new Decimal(8))).toEqual([holdings[0], holdings[1]]);
  });

  it('greedyUsdPrefix returns everything when the target exceeds total value', () => {
    expect(greedyUsdPrefix(holdings, new Decimal(999))).toEqual(holdings);
  });

  it('selectRoughEligibleSources KEEPS dst-chain members and applies the headroom to the target', () => {
    // dstUsd 9 × (1 + 0.01) = 9.09 → 5 (<9.09), 10 (≥9.09) → first two, and the BASE (dst) member stays.
    const res = selectRoughEligibleSources(holdings, new Decimal(9));
    expect(res).toEqual([holdings[0], holdings[1]]);
    expect(res.some((h) => h.chainID === BASE_CHAIN)).toBe(true);
  });
});
