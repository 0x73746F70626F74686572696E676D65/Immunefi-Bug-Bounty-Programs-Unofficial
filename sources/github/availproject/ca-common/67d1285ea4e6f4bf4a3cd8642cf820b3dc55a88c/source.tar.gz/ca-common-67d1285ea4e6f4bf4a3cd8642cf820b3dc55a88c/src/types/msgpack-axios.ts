import axios from "axios";
import { pack as msgpack, unpack as msgunpack } from 'msgpackr'

const noDataMethods = new Set(['get', 'head'])

export const msgpackableAxios = axios.create({
  responseType: "arraybuffer",
  transformRequest: [
    function (data, headers) {
      if (noDataMethods.has((this.method as string).toLowerCase()))
        return;
      headers["Content-Type"] = "application/msgpack";
      return msgpack(data);
    },
  ],
  transformResponse: [(data) => msgunpack(data)],
  headers: {
    Accept: "application/msgpack",
  },
})
