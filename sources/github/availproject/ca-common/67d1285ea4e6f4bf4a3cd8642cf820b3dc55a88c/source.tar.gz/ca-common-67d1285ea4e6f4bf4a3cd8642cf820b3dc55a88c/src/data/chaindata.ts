import { Hex, hexToBytes, toHex } from "viem";

import { Universe } from "../proto/definition";
import { ChainIDKeyedMap, OmniversalChainID } from "./chainid";
import { Currency } from "./currency";
import { PermitVariant } from "../permitutils";
import { ezPadTo32Hex } from "./utils";

const RawData = [
  {
    Universe: 0,
    ChainID32:
      "0x0000000000000000000000000000000000000000000000000000000000000001",
    Currencies: [
      {
        CurrencyID: 1,
        PermitVariant: PermitVariant.EIP2612Canonical,
        PermitContractVersion: 2,
        TokenContractAddress:
          "0x000000000000000000000000a0b86991c6218b36c1d19d4a2e9eb0ce3606eb48",
        TokenDecimals: 6,
        IsGasToken: false,
      },
      {
        CurrencyID: 2,
        PermitVariant: PermitVariant.Unsupported,
        TokenContractAddress:
          "0x000000000000000000000000dac17f958d2ee523a2206206994597c13d831ec7",
        TokenDecimals: 6,
        IsGasToken: false,
      },
      {
        CurrencyID: 3,
        PermitVariant: PermitVariant.Unsupported,
        TokenContractAddress:
          "0x0000000000000000000000000000000000000000000000000000000000000000",
        TokenDecimals: 18,
        IsGasToken: true,
      },
    ],
  },

  {
    Universe: 0,
    ChainID32:
      "0x000000000000000000000000000000000000000000000000000000000000a4b1",
    Currencies: [
      {
        CurrencyID: 1,
        PermitVariant: PermitVariant.EIP2612Canonical,
        PermitContractVersion: 2,
        TokenContractAddress:
          "0x000000000000000000000000af88d065e77c8cc2239327c5edb3a432268e5831",
        TokenDecimals: 6,
        IsGasToken: false,
      },
      {
        CurrencyID: 2,
        PermitVariant: PermitVariant.EIP2612Canonical,
        PermitContractVersion: 1,
        TokenContractAddress:
          "0x000000000000000000000000fd086bc7cd5c481dcc9c85ebe478a1c0b69fcbb9",
        TokenDecimals: 6,
        IsGasToken: false,
      },
      {
        CurrencyID: 3,
        PermitVariant: PermitVariant.Unsupported,
        TokenContractAddress:
          "0x0000000000000000000000000000000000000000000000000000000000000000",
        TokenDecimals: 18,
        IsGasToken: true,
      },
    ],
  },
  {
    Universe: 0,
    ChainID32:
      "0x000000000000000000000000000000000000000000000000000000000000000a",
    Currencies: [
      {
        CurrencyID: 1,
        PermitVariant: PermitVariant.EIP2612Canonical,
        PermitContractVersion: 2,
        TokenContractAddress:
          "0x0000000000000000000000000b2c639c533813f4aa9d7837caf62653d097ff85",
        TokenDecimals: 6,
        IsGasToken: false,
      },
      {
        CurrencyID: 2,
        PermitVariant: PermitVariant.Unsupported,
        TokenContractAddress:
          "0x00000000000000000000000094b008aa00579c1307b0ef2c499ad98a8ce58e58",
        TokenDecimals: 6,
        IsGasToken: false,
      },
      {
        CurrencyID: 3,
        PermitVariant: PermitVariant.Unsupported,
        TokenContractAddress:
          "0x0000000000000000000000000000000000000000000000000000000000000000",
        TokenDecimals: 18,
        IsGasToken: true,
      },
    ],
  },
  {
    Universe: 0,
    ChainID32:
      "0x0000000000000000000000000000000000000000000000000000000000000089",
    Currencies: [
      {
        CurrencyID: 1,
        PermitVariant: PermitVariant.EIP2612Canonical,
        PermitContractVersion: 2,
        TokenContractAddress:
          "0x0000000000000000000000003c499c542cef5e3811e1192ce70d8cc03d5c3359",
        TokenDecimals: 6,
        IsGasToken: false,
      },
      {
        CurrencyID: 2,
        PermitVariant: PermitVariant.PolygonEMT,
        PermitContractVersion: 1,
        TokenContractAddress:
          "0x000000000000000000000000c2132d05d31c914a87c6611c10748aeb04b58e8f",
        TokenDecimals: 6,
        IsGasToken: false,
      },
      {
        CurrencyID: 4,
        PermitVariant: PermitVariant.Unsupported,
        TokenContractAddress:
          "0x0000000000000000000000000000000000000000000000000000000000000000",
        TokenDecimals: 18,
        IsGasToken: true,
      },
    ],
  },
  {
    Universe: 0,
    ChainID32:
      "0x000000000000000000000000000000000000000000000000000000000000a86a",
    Currencies: [
      {
        CurrencyID: 1,
        PermitVariant: PermitVariant.EIP2612Canonical,
        PermitContractVersion: 2,
        TokenContractAddress:
          "0x000000000000000000000000b97ef9ef8734c71904d8002f8b6bc66dd9c48a6e",
        TokenDecimals: 6,
        IsGasToken: false,
      },
      {
        CurrencyID: 2,
        PermitVariant: PermitVariant.EIP2612Canonical,
        PermitContractVersion: 1,
        TokenContractAddress:
          "0x0000000000000000000000009702230a8ea53601f5cd2dc00fdbc13d4df4a8c7",
        TokenDecimals: 6,
        IsGasToken: false,
      },
      {
        CurrencyID: 5,
        PermitVariant: PermitVariant.Unsupported,
        PermitContractVersion: 1,
        TokenContractAddress:
          "0x0000000000000000000000000000000000000000000000000000000000000000",
        TokenDecimals: 18,
        IsGasToken: true,
      },
    ],
  },
  {
    Universe: 0,
    ChainID32:
      "0x000000000000000000000000000000000000000000000000000000000000e708",
    Currencies: [
      {
        CurrencyID: 1,
        PermitVariant: PermitVariant.EIP2612Canonical,
        PermitContractVersion: 2,
        TokenContractAddress:
          "0x000000000000000000000000176211869ca2b568f2a7d4ee941e073a821ee1ff",
        TokenDecimals: 6,
        IsGasToken: false,
      },
      {
        CurrencyID: 2,
        PermitVariant: PermitVariant.EIP2612Canonical,
        PermitContractVersion: 1,
        TokenContractAddress:
          "0x000000000000000000000000a219439258ca9da29e9cc4ce5596924745e12b93",
        TokenDecimals: 6,
        IsGasToken: false,
      },
      {
        CurrencyID: 3,
        PermitVariant: PermitVariant.Unsupported,
        TokenContractAddress:
          "0x0000000000000000000000000000000000000000000000000000000000000000",
        TokenDecimals: 18,
        IsGasToken: true,
      },
    ],
  },
  {
    Universe: 0,
    ChainID32:
      "0x0000000000000000000000000000000000000000000000000000000000082750",
    Currencies: [
      {
        CurrencyID: 1,
        PermitVariant: PermitVariant.EIP2612Canonical,
        PermitContractVersion: 2,
        TokenContractAddress:
          "0x00000000000000000000000006efdbff2a14a7c8e15944d1f4a48f9f95f663a4",
        TokenDecimals: 6,
        IsGasToken: false,
      },
      {
        CurrencyID: 2,
        PermitVariant: PermitVariant.EIP2612Canonical,
        PermitContractVersion: 1,
        TokenContractAddress:
          "0x000000000000000000000000f55bec9cafdbe8730f096aa55dad6d22d44099df",
        TokenDecimals: 6,
        IsGasToken: false,
      },
      {
        CurrencyID: 3,
        PermitVariant: PermitVariant.Unsupported,
        TokenContractAddress:
          "0x0000000000000000000000000000000000000000000000000000000000000000",
        TokenDecimals: 18,
        IsGasToken: true,
      },
    ],
  },
  {
    Universe: 0,
    ChainID32:
      "0x0000000000000000000000000000000000000000000000000000000000002105",
    Currencies: [
      {
        CurrencyID: 1,
        PermitVariant: PermitVariant.EIP2612Canonical,
        PermitContractVersion: 2,
        TokenContractAddress:
          "0x000000000000000000000000833589fcd6edb6e08f4c7c32d4f71b54bda02913",
        TokenDecimals: 6,
        IsGasToken: false,
      },
      {
        CurrencyID: 2,
        PermitVariant: PermitVariant.Unsupported,
        TokenContractAddress:
          "0x000000000000000000000000fde4c96c8593536e31f229ea8f37b2ada2699bb2",
        TokenDecimals: 6,
        IsGasToken: false,
      },
      {
        CurrencyID: 3,
        PermitVariant: PermitVariant.Unsupported,
        TokenContractAddress:
          "0x0000000000000000000000000000000000000000000000000000000000000000",
        TokenDecimals: 18,
        IsGasToken: true,
      },
    ],
  },
  {
    Universe: 0,
    ChainID32:
      "0x00000000000000000000000000000000000000000000000000000000000003e7",
    Currencies: [
      {
        CurrencyID: 1,
        PermitVariant: PermitVariant.EIP2612Canonical,
        PermitContractVersion: 2,
        TokenContractAddress:
          "0x000000000000000000000000b88339cb7199b77e23db6e890353e22632ba630f",
        TokenDecimals: 6,
        IsGasToken: false,
      },
      {
        CurrencyID: 2,
        PermitVariant: PermitVariant.EIP2612Canonical,
        PermitContractVersion: 1,
        TokenContractAddress:
          "0x000000000000000000000000B8CE59FC3717ada4C02eaDF9682A9e934F625ebb",
        TokenDecimals: 6,
        IsGasToken: false,
      },
      {
        CurrencyID: 16,
        PermitVariant: PermitVariant.Unsupported,
        TokenContractAddress:
          "0x0000000000000000000000000000000000000000000000000000000000000000",
        TokenDecimals: 18,
        IsGasToken: true,
      },
    ],
  },
  {
    Universe: 0,
    ChainID32:
      "0x0000000000000000000000000000000000000000000000000000000000002019",
    Currencies: [
      {
        CurrencyID: 2,
        PermitVariant: PermitVariant.EIP2612Canonical,
        PermitContractVersion: 1,
        TokenContractAddress:
          "0x000000000000000000000000d077a400968890eacc75cdc901f0356c943e4fdb",
        TokenDecimals: 6,
        IsGasToken: false,
      },
      {
        CurrencyID: 17,
        PermitVariant: PermitVariant.Unsupported,
        TokenContractAddress:
          "0x0000000000000000000000000000000000000000000000000000000000000000",
        TokenDecimals: 18,
        IsGasToken: true,
      },
    ],
  },
  {
    Universe: 0,
    ChainID32:
      "0x000000000000000000000000000000000000000000000000000000000000c3b8",
    Currencies: [
      {
        CurrencyID: 1,
        PermitVariant: PermitVariant.EIP2612Canonical,
        PermitContractVersion: 2,
        TokenContractAddress:
          "0x0000000000000000000000009aa0f72392b5784ad86c6f3e899bcc053d00db4f",
        TokenDecimals: 6,
        IsGasToken: false,
      },
      {
        CurrencyID: 2,
        PermitVariant: PermitVariant.EIP2612Canonical,
        PermitContractVersion: 1,
        TokenContractAddress:
          "0x0000000000000000000000006386da73545ae4e2b2e0393688fa8b65bb9a7169",
        TokenDecimals: 6,
        IsGasToken: false,
      },
      {
        CurrencyID: 3,
        PermitVariant: PermitVariant.EIP2612Canonical,
        PermitContractVersion: 1,
        TokenContractAddress:
          "0x00000000000000000000000072af9f169b619d85a47dfa8fefbcd39de55c567d",
        TokenDecimals: 18,
        IsGasToken: false,
      },
      {
        CurrencyID: 18,
        PermitVariant: PermitVariant.Unsupported,
        TokenContractAddress:
          "0x0000000000000000000000000000000000000000000000000000000000000000",
        TokenDecimals: 18,
        IsGasToken: true,
      },
    ],
  },
  {
    Universe: 0,
    ChainID32:
      "0x0000000000000000000000000000000000000000000000000000000000000038",
    Currencies: [
      {
        CurrencyID: 1,
        PermitVariant: PermitVariant.Unsupported,
        TokenContractAddress:
          "0x0000000000000000000000008ac76a51cc950d9822d68b83fe1ad97b32cd580d",
        TokenDecimals: 18,
        IsGasToken: false,
      },
      {
        CurrencyID: 2,
        PermitVariant: PermitVariant.Unsupported,
        TokenContractAddress:
          "0x00000000000000000000000055d398326f99059ff775485246999027b3197955",
        TokenDecimals: 18,
        IsGasToken: false,
      },
      {
        CurrencyID: 3,
        PermitVariant: PermitVariant.Unsupported,
        TokenContractAddress:
          "0x0000000000000000000000002170ed0880ac9a755fd29b2688956bd959f933f8",
        TokenDecimals: 18,
        IsGasToken: false,
      },
      {
        CurrencyID: 6,
        PermitVariant: PermitVariant.Unsupported,
        TokenContractAddress:
          "0x0000000000000000000000000000000000000000000000000000000000000000",
        TokenDecimals: 18,
        IsGasToken: true,
      },
    ],
  },
  {
    Universe: 1,
    ChainID32:
      "0x00000000000000000000000000000000000000000000000000000000000026a1",
    Currencies: [
      {
        CurrencyID: 1,
        PermitVariant: PermitVariant.Unsupported,
        TokenContractAddress:
          "0x286c479da40dc953bddc3bb4c453b608bba2e0ac483b077bd475174115395e6b",
        TokenDecimals: 6,
        IsGasToken: false,
      },
      {
        CurrencyID: 2,
        PermitVariant: PermitVariant.Unsupported,
        TokenContractAddress:
          "0xa0265fb5c32f6e8db3197af3c7eb05c48ae373605b8165b6f4a51c5b0ba4812e",
        TokenDecimals: 6,
        IsGasToken: false,
      },
      {
        CurrencyID: 3,
        PermitVariant: PermitVariant.Unsupported,
        TokenContractAddress:
          "0xf8f8b6283d7fa5b672b530cbb84fcccb4ff8dc40f8176ef4544ddb1f1952ad07",
        TokenDecimals: 9,
        IsGasToken: true,
      },
    ],
  },
  {
    Universe: 0,
    ChainID32:
      "0x0000000000000000000000000000000000000000000000000000000000066eee",
    Currencies: [
      {
        CurrencyID: 1,
        PermitVariant: PermitVariant.EIP2612Canonical,
        PermitContractVersion: 2,
        TokenContractAddress:
          "0x00000000000000000000000075faf114eafb1bdbe2f0316df893fd58ce46aa4d",
        TokenDecimals: 6,
        IsGasToken: false,
      },
      {
        CurrencyID: 2,
        PermitVariant: PermitVariant.EIP2612Canonical,
        PermitContractVersion: 1,
        TokenContractAddress:
          "0x000000000000000000000000f954d4a5859b37de88a91bdbb8ad309056fb04b1",
        TokenDecimals: 18,
        IsGasToken: false,
      },
      {
        CurrencyID: 3,
        PermitVariant: PermitVariant.Unsupported,
        TokenContractAddress:
          "0x0000000000000000000000000000000000000000000000000000000000000000",
        TokenDecimals: 18,
        IsGasToken: true,
      },
    ],
  },
  {
    Universe: 0,
    ChainID32:
      "0x0000000000000000000000000000000000000000000000000000000000aa37dc",
    Currencies: [
      {
        CurrencyID: 1,
        PermitVariant: PermitVariant.EIP2612Canonical,
        PermitContractVersion: 2,
        TokenContractAddress:
          "0x0000000000000000000000005fd84259d66cd46123540766be93dfe6d43130d7",
        TokenDecimals: 6,
        IsGasToken: false,
      },
      {
        CurrencyID: 2,
        PermitVariant: PermitVariant.EIP2612Canonical,
        PermitContractVersion: 1,
        TokenContractAddress:
          "0x0000000000000000000000006462693c2f21ac0e517f12641d404895030f7426",
        TokenDecimals: 18,
        IsGasToken: false,
      },
      {
        CurrencyID: 3,
        PermitVariant: PermitVariant.Unsupported,
        TokenContractAddress:
          "0x0000000000000000000000000000000000000000000000000000000000000000",
        TokenDecimals: 18,
        IsGasToken: true,
      },
    ],
  },
  {
    Universe: 0,
    ChainID32:
      "0x0000000000000000000000000000000000000000000000000000000000013882",
    Currencies: [
      {
        CurrencyID: 1,
        PermitVariant: PermitVariant.EIP2612Canonical,
        PermitContractVersion: 2,
        TokenContractAddress:
          "0x00000000000000000000000041e94eb019c0762f9bfcf9fb1e58725bfb0e7582",
        TokenDecimals: 6,
        IsGasToken: false,
      },
      {
        CurrencyID: 4,
        PermitVariant: PermitVariant.Unsupported,
        TokenContractAddress:
          "0x0000000000000000000000000000000000000000000000000000000000000000",
        TokenDecimals: 18,
        IsGasToken: true,
      },
    ],
  },
  {
    Universe: 0,
    ChainID32:
      "0x0000000000000000000000000000000000000000000000000000000000014a34",
    Currencies: [
      {
        CurrencyID: 1,
        PermitVariant: PermitVariant.EIP2612Canonical,
        PermitContractVersion: 2,
        TokenContractAddress:
          "0x000000000000000000000000036cbd53842c5426634e7929541ec2318f3dcf7e",
        TokenDecimals: 6,
        IsGasToken: false,
      },
      {
        CurrencyID: 3,
        PermitVariant: PermitVariant.Unsupported,
        TokenContractAddress:
          "0x0000000000000000000000000000000000000000000000000000000000000000",
        TokenDecimals: 18,
        IsGasToken: true,
      },
    ],
  },
  {
    Universe: 0,
    ChainID32:
      "0x0000000000000000000000000000000000000000000000000000000000aa36a7",
    Currencies: [
      {
        CurrencyID: 1,
        TokenContractAddress:
          "0x0000000000000000000000001c7d4b196cb0c7b01d743fbc6116a902379c7238",
        PermitVariant: PermitVariant.EIP2612Canonical,
        PermitContractVersion: 2,
        TokenDecimals: 6,
        USDPriceOracleAddress: "0x0000000000000000000000000000000000000000",
        IsGasToken: false,
      },
      {
        CurrencyID: 3,
        TokenContractAddress:
          "0x0000000000000000000000000000000000000000000000000000000000000000",
        PermitVariant: PermitVariant.Unsupported,
        TokenDecimals: 18,
        USDPriceOracleAddress: "0x0000000000000000000000000000000000000000",
        IsGasToken: true,
      },
    ],
  },
  {
    Universe: 0,
    ChainID32:
      "0x000000000000000000000000000000000000000000000000000000000000279f",
    Currencies: [
      {
        CurrencyID: 1,
        TokenContractAddress:
          "0x000000000000000000000000f817257fed379853cde0fa4f97ab987181b1e5ea",
        PermitVariant: PermitVariant.Unsupported,
        TokenDecimals: 6,
        IsGasToken: false,
      },
      {
        CurrencyID: 2,
        TokenContractAddress:
          "0x0000000000000000000000001c56f176d6735888fbb6f8bd9adad8ad7a023a0b",
        PermitVariant: PermitVariant.Unsupported,
        TokenDecimals: 18,
        IsGasToken: false,
      },
      {
        CurrencyID: 20,
        TokenContractAddress:
          "0x0000000000000000000000000000000000000000000000000000000000000000",
        PermitVariant: PermitVariant.Unsupported,
        TokenDecimals: 18,
        IsGasToken: true,
      },
    ],
  },
  {
    Universe: 0,
    ChainID32:
      "0x000000000000000000000000000000000000000000000000000000000000008f",
    Currencies: [
      {
        CurrencyID: 1,
        TokenContractAddress:
          "0x000000000000000000000000754704Bc059F8C67012fEd69BC8A327a5aafb603",
        PermitVariant: PermitVariant.EIP2612Canonical,
        PermitContractVersion: 2,
        TokenDecimals: 6,
        IsGasToken: false,
      },
      {
        CurrencyID: 20,
        TokenContractAddress:
          "0x0000000000000000000000000000000000000000000000000000000000000000",
        PermitVariant: PermitVariant.Unsupported,
        TokenDecimals: 18,
        IsGasToken: true,
      },
    ],
  },
  {
    Universe: 3,
    ChainID32:
      "0x0000000000000000000000000000000000000000000000000000000094a9059e",
    Currencies: [
      {
        CurrencyID: 2,
        TokenContractAddress:
          "0x00000000000000000000000042a1e39aefA49290F2B3F9ed688D7cecf86CD6E0",
        PermitVariant: PermitVariant.Unsupported,
        TokenDecimals: 6,
        IsGasToken: false,
      },
      {
        CurrencyID: 13,
        TokenContractAddress:
          "0x0000000000000000000000000000000000000000000000000000000000000000",
        PermitVariant: PermitVariant.Unsupported,
        TokenDecimals: 6,
        IsGasToken: true,
      },
    ],
  },
  {
    Universe: 3,
    ChainID32:
      "0x000000000000000000000000000000000000000000000000000000002b6653dc",
    Currencies: [
      {
        CurrencyID: 2,
        TokenContractAddress:
          "0x000000000000000000000000a614f803B6FD780986A42c78Ec9c7f77e6DeD13C",
        PermitVariant: PermitVariant.Unsupported,
        TokenDecimals: 6,
        IsGasToken: false,
      },
      {
        CurrencyID: 13,
        TokenContractAddress:
          "0x0000000000000000000000000000000000000000000000000000000000000000",
        PermitVariant: PermitVariant.Unsupported,
        TokenDecimals: 6,
        IsGasToken: true,
      },
    ],
  },
  //megaeth mainnet
  {
    Universe: 0,
    ChainID32:
      "0x00000000000000000000000000000000000000000000000000000000000010e6",
    Currencies: [
      {
        CurrencyID: 1,
        TokenContractAddress:
          "0x000000000000000000000000FAfDdbb3FC7688494971a79cc65DCa3EF82079E7",
        PermitVariant: PermitVariant.EIP2612Canonical,
        PermitContractVersion: 1,
        TokenDecimals: 18,
        IsGasToken: false,
      },
      {
        CurrencyID: 3,
        TokenContractAddress:
          "0x0000000000000000000000000000000000000000000000000000000000000000",
        PermitVariant: PermitVariant.Unsupported,
        TokenDecimals: 18,
        IsGasToken: true,
      },
      {
        CurrencyID: 2,
        TokenContractAddress:
          "0x000000000000000000000000B8CE59FC3717ada4C02eaDF9682A9e934F625ebb",
        PermitVariant: PermitVariant.EIP2612Canonical,
        PermitContractVersion: 1,
        TokenDecimals: 6,
        IsGasToken: false,
      },
    ],
  },
  //citrea mainnet
  {
    Universe: 0,
    ChainID32:
      "0x0000000000000000000000000000000000000000000000000000000000001012",
    Currencies: [
      {
        CurrencyID: 1,
        TokenContractAddress:
          "0x000000000000000000000000E045e6c36cF77FAA2CfB54466D71A3aEF7bbE839",
        PermitVariant: PermitVariant.EIP2612Canonical,
        PermitContractVersion: 2,
        TokenDecimals: 6,
        IsGasToken: false,
      },
      {
        CurrencyID: 2,
        PermitVariant: PermitVariant.EIP2612Canonical,
        PermitContractVersion: 1,
        TokenContractAddress:
          "0x0000000000000000000000009f3096Bac87e7F03DC09b0B416eB0DF837304dc4",
        TokenDecimals: 6,
        IsGasToken: false,
      },
      {
        CurrencyID: 21,
        TokenContractAddress:
          "0x0000000000000000000000000000000000000000000000000000000000000000",
        PermitVariant: PermitVariant.Unsupported,
        TokenDecimals: 18,
        IsGasToken: true,
      },
    ],
  },
  // Citrea Testnet
  {
    Universe: 0,
    ChainID32:
      "0x00000000000000000000000000000000000000000000000000000000000013fb",
    Currencies: [
      {
        CurrencyID: 1,
        TokenContractAddress:
          "0x000000000000000000000000b669dC8cC6D044307Ba45366C0c836eC3c7e31AA",
        PermitVariant: PermitVariant.EIP2612Canonical,
        PermitContractVersion: 2,
        TokenDecimals: 6,
        IsGasToken: false,
      },
      {
        CurrencyID: 21,
        TokenContractAddress:
          "0x0000000000000000000000000000000000000000000000000000000000000000",
        PermitVariant: PermitVariant.Unsupported,
        TokenDecimals: 18,
        IsGasToken: true,
      },
    ],
  },
];

class CurrencyMap {
  private readonly map = new Map<string, Currency>();

  constructor(currencies: Currency[]) {
    for (const cur of currencies) {
      this.map.set(toHex(cur.tokenAddress), cur);
    }
  }

  get(input: Parameters<typeof ezPadTo32Hex>[0]) {
    return this.map.get(ezPadTo32Hex(input));
  }
}

export type ChainDatum = {
  ChainID: OmniversalChainID;
  Universe: Universe;
  ChainID32: Uint8Array;
  Currencies: Currency[];
  CurrencyMap: CurrencyMap;
};

// Certain data fields are auto-generated while others are not.
export const Chaindata: ChainDatum[] = RawData.map((ch) => {
  const ch32 = hexToBytes(<Hex>ch.ChainID32);
  const currencies = ch.Currencies.map((cur) => {
    return new Currency(
      cur.CurrencyID,
      hexToBytes(<Hex>cur.TokenContractAddress),
      cur.TokenDecimals,
      cur.PermitVariant,
      cur.PermitContractVersion,
      cur.IsGasToken,
    );
  });
  return {
    Universe: ch.Universe,
    ChainID: new OmniversalChainID(ch.Universe, ch32),
    ChainID32: ch32,
    Currencies: currencies,
    CurrencyMap: new CurrencyMap(currencies),
  };
});

export const ChaindataMap = new ChainIDKeyedMap(
  Chaindata.map((ch) => [ch.ChainID, ch]),
);
export const RPCURLMap = new ChainIDKeyedMap([
  [
    new OmniversalChainID(Universe.ETHEREUM, 421614),
    "https://rpcs.avail.so/arbitrumsepolia",
  ],
  [
    new OmniversalChainID(Universe.ETHEREUM, 11155420),
    "https://rpcs.avail.so/optimismsepolia",
  ],
  [
    new OmniversalChainID(Universe.ETHEREUM, 80002),
    "https://rpcs.avail.so/polygonamoy",
  ],
  [
    new OmniversalChainID(Universe.ETHEREUM, 84532),
    "https://rpcs.avail.so/basesepolia",
  ],
  [
    new OmniversalChainID(Universe.ETHEREUM, 11155111),
    "https://rpcs.avail.so/sepolia",
  ],
  [
    new OmniversalChainID(Universe.ETHEREUM, 137),
    "https://rpcs.avail.so/polygon",
  ],
  [
    new OmniversalChainID(Universe.ETHEREUM, 42161),
    "https://rpcs.avail.so/arbitrum",
  ],
  [
    new OmniversalChainID(Universe.ETHEREUM, 10),
    "https://rpcs.avail.so/optimism",
  ],
  [
    new OmniversalChainID(Universe.ETHEREUM, 8453),
    "https://rpcs.avail.so/base",
  ],
  [new OmniversalChainID(Universe.ETHEREUM, 1), "https://rpcs.avail.so/eth"],
  [
    new OmniversalChainID(Universe.ETHEREUM, 534352),
    "https://rpcs.avail.so/scroll",
  ],
  [
    new OmniversalChainID(Universe.ETHEREUM, 43114),
    "https://rpcs.avail.so/avalanche",
  ],
  [
    new OmniversalChainID(Universe.ETHEREUM, 999),
    "https://rpcs.avail.so/hyperevm",
  ],
  [
    new OmniversalChainID(Universe.ETHEREUM, 8217),
    "https://rpcs.avail.so/kaia",
  ],
  [
    new OmniversalChainID(Universe.ETHEREUM, 50104),
    "https://sophon.gateway.tenderly.co/1d4STFT7zmG0vM5QowibCw",
  ],
  [new OmniversalChainID(Universe.ETHEREUM, 56), "https://rpcs.avail.so/bsc"],
  [
    new OmniversalChainID(Universe.ETHEREUM, 10143),
    "https://rpcs.avail.so/monadtestnet",
  ],
  [
    new OmniversalChainID(Universe.ETHEREUM, 143),
    "https://rpcs.avail.so/monad",
  ],
  [
    new OmniversalChainID(Universe.ETHEREUM, 4326),
    "https://rpcs.avail.so/megaeth",
  ],
  [
    new OmniversalChainID(Universe.ETHEREUM, 4114),
    "https://rpcs.avail.so/citrea",
  ],
  [
    new OmniversalChainID(Universe.ETHEREUM, 5115),
    "https://rpcs.avail.so/citrea-testnet",
  ],
]);
