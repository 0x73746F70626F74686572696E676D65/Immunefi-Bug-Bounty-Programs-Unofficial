<script setup lang="ts">
import { ref, type Ref } from 'vue'

import AppLoader from '@/components/AppLoader.vue'
import { openOnRampMoneyHostedUI } from '@/utils/onrampmoney.ramp'
import { openTransak } from '@/utils/transak'
import { useImage } from '@/utils/useImage'

const getImage = useImage()

type BuyTokenProps = {
  transakNetwork?: string
  onRampMoney?: number | false | undefined
}

const props = defineProps<BuyTokenProps>()

const emit = defineEmits(['close'])
const selectedProvider: Ref<'transak' | 'ramp' | 'onramp.money' | ''> = ref('')
const isLoading = ref(false)
const showStatusModal: Ref<'success' | 'failed' | 'cancelled' | ''> = ref('')
const statusText = ref({
  title: '',
  message: '',
})

function handleTransak() {
  isLoading.value = true
  openTransak(props.transakNetwork as string)
  handleStatusModalText('Transak')
}

function handleStatusModalText(provider: 'Transak' | 'Ramp' | 'onramp.money') {
  setTimeout(() => {
    isLoading.value = false
  }, 1500)
  showStatusModal.value = 'success'
  statusText.value = {
    title: `You selected ${provider}`,
    message:
      'Your buy transaction is in progress in another browser tab. Meanwhile, you can close this popup and resume wallet access.',
  }
}

function handleOnRampMoney() {
  if (props.onRampMoney === undefined || props.onRampMoney === false) {
    throw new Error('!!!')
  }
  isLoading.value = true
  openOnRampMoneyHostedUI(props.onRampMoney)
  handleStatusModalText('onramp.money')
}

function handleBuy() {
  if (selectedProvider.value === 'transak') {
    handleTransak()
  } else if (selectedProvider.value === 'onramp.money') {
    handleOnRampMoney()
  }
}

function handleDone() {
  if (showStatusModal.value === 'success') {
    return emit('close')
  }
  showStatusModal.value = ''
  statusText.value = {
    title: '',
    message: '',
  }
}
</script>

<template>
  <div>
    <AppLoader v-if="isLoading" message="Processing..." />
    <div
      v-else-if="showStatusModal"
      class="overflow-auto flex flex-col gap-4 justify-between p-2"
    >
      <img src="@/assets/images/success.svg" class="h-16 w-16 self-center" />
      <div class="flex flex-col gap-2">
        <div class="text-base font-medium text-center">
          {{ statusText.title }}
        </div>
        <div class="text-sm text-gray-spanish-light text-center">
          {{ statusText.message }}
        </div>
      </div>
    </div>
    <div v-else class="flex flex-col p-1">
      <div class="flex flex-col gap-3">
        <p class="font-Nohemi font-medium text-center text-xl">
          Select Provider
        </p>
        <p class="text-xs text-zinc-400">
          You will be taken to the provider website in a different tab once you
          choose the provider and click PROCEED.
        </p>
      </div>
      <form class="flex flex-col mt-5 space-y-4" @submit.prevent="handleBuy">
        <div class="flex flex-col gap-2">
          <div
            class="bg-gray-zinc dark:bg-black-arsenic flex gap-3 p-4 items-center justify-between border-1 rounded-sm transition-all duration-300 ease-in-out"
            :class="{
              'opacity-60 cursor-not-allowed': !props.transakNetwork,
              'hover:border-gray-100 cursor-pointer': props.transakNetwork,
              'border-gray-800 dark:border-gray-200':
                selectedProvider !== 'transak',
            }"
            @click.stop="
              props.transakNetwork ? (selectedProvider = 'transak') : void 0
            "
          >
            <label for="Transak" class="flex gap-2 items-center cursor-pointer">
              <img src="@/assets/images/transak.png" class="h-xl w-xl" />
              <span class="text-base font-normal">Transak</span>
            </label>
            <input
              id="Transak"
              v-model="selectedProvider"
              type="radio"
              value="transak"
              name="provider"
              :disabled="!props.transakNetwork"
              class="radio"
            />
          </div>
        </div>
        <div class="flex space-x-3 bg-blue-dark-sky p-3 rounded-sm">
          <img
            class="w-4 h-4 mt-1"
            :src="getImage('info-circle', undefined, 'svg')"
          />
          <p class="text-xs text-white-200">
            Your wallet address will be auto-filled, please verify. The time
            taken for funds to reflect in the wallet varies based on payment
            method.
          </p>
        </div>
        <div class="flex mt-8">
          <button
            class="flex-1 btn-primary py-[10px]"
            :disabled="!selectedProvider?.trim().length"
          >
            Proceed
          </button>
        </div>
      </form>
    </div>
  </div>
</template>
