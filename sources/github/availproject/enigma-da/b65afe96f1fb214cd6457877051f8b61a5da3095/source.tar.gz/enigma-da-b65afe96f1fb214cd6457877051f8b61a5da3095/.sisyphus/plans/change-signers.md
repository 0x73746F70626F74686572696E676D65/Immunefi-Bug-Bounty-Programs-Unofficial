# Work Plan: Change Signers Feature

## TL;DR

> **Quick Summary**: Add a threshold-based governance mechanism allowing current authorized signers to approve changes to app signers and threshold. Mirrors the existing decryption request flow pattern.
> 
> **Deliverables**: 
> - New database table: `change_signers_requests`
> - 4 new API endpoints for creating/signing/managing change signer requests
> - New types/DTOs in `src/types.rs`
> - Database functions in `src/db.rs`
> - Handler functions in `src/api/change_signers.rs`
> 
> **Estimated Effort**: Medium (6-8 hours)
> **Parallel Execution**: NO - Sequential dependencies
> **Critical Path**: DB Schema -> Types -> DB Functions -> API Handlers -> Routes -> Tests

---

## Context

### Original Request
Add a `change_signers` function to the existing multi-party encryption/decryption system. The system already has:
- Decryption request creation
- Signer signature collection  
- Threshold-based automatic decryption
- TEE attestation

### Interview Summary
**Goal**: Enable authorized signers to change the list of signers and threshold for an app through a multi-sig process.

**Key Requirements**:
1. Create a request with new signers and new threshold
2. Existing authorized signers sign the request
3. Once threshold is reached, update the app's signers and threshold
4. The process mirrors the existing decryption flow pattern

**Flow Pattern to Follow**:
- Similar to decryption: create request → collect signatures → check threshold → execute action
- Must verify signers are CURRENT authorized participants
- ECDSA signatures over a specific message format
- Same threshold validation logic (threshold > 0, threshold <= new_signers.len())

---

## Work Objectives

### Core Objective
Implement a threshold-based governance mechanism for changing app signers and threshold that requires approval from current authorized participants.

### Concrete Deliverables
1. New database table: `change_signers_requests`
2. API endpoints:
   - `POST /v1/change_signers/create` - Create a change signers request
   - `POST /v1/change_signers/{id}/sign` - Submit signature for approval
   - `GET /v1/change_signers/{id}` - Get request status
   - `GET /v1/change_signers/list?turbo_da_app_id=xxx` - List requests
3. New types/DTOs in `src/types.rs`
4. Database functions in `src/db.rs`
5. Handler functions in new file: `src/api/change_signers.rs`
6. Route registration in `src/main.rs`
7. Module export in `src/api/mod.rs`

### Definition of Done
- [x] All endpoints return correct responses
- [x] Signatures verified against current participants
- [x] Threshold reached → signers and threshold updated atomically
- [x] TEE attestation quote generated on success (same pattern as decrypt)
- [x] Tests pass

### Must Have
- Signature verification using ECDSA (same as decrypt flow)
- Message format: `{request_id}:{turbo_da_app_id}` (same pattern)
- Check that signers are CURRENT authorized participants
- Atomic update: clear old participants, add new ones, update threshold
- Prevent duplicate signatures from same participant

### Must NOT Have (Guardrails)
- NO changes to existing decrypt/encrypt/participant endpoints
- NO changes to existing database tables (add new table instead)
- NO breaking changes to existing API
- NO auto-execution: only execute when threshold met

---

## Understanding the Current Decryption Flow

### Decryption Flow Summary:

1. **Create Request** (`POST /v1/create_decrypt_request`)
   - Input: `DecryptRequest { turbo_da_app_id, id, ciphertext }`
   - Validation: App exists, has participants
   - Creates: Record in `decryption_requests` table with status "pending"
   - Returns: `DecryptRequestResponse { id, turbo_da_app_id, status, signers, created_at }`

2. **Submit Signature** (`POST /v1/decrypt_request/{id}/signatures`)
   - Input: `SubmitSignatureRequest { participant_address, signature }`
   - Validation:
     - Request exists and is "pending"
     - Participant is in `mpc_participants` for this app
     - ECDSA signature valid over message `{request_id}:{turbo_da_app_id}`
   - Stores: Signature in JSON array `submitted_signatures` column
   - Check: `signatures_count >= threshold`
   - If threshold met:
     - Calls `utils::decrypt(turbo_da_app_id, ciphertext)`
     - Updates status to "completed", stores plaintext
     - Generates TEE quote via `utils::quote()`
     - Returns: `SubmitSignatureResponse { id, status, signatures_submitted, threshold, ready_to_decrypt, tee_attestion }`

### Key Patterns to Follow:

**Signature Verification** (from `src/api/decrypt.rs:204-236`):
```rust
let message = format!("{}:{}", request_id, check.turbo_da_app_id);
match utils::verify_ecdsa_signature(&message, &request.signature, &request.participant_address)
```

**Threshold Check** (from `src/api/decrypt.rs:261-292`):
```rust
let status = db::get_signature_status(&pool, &request_id).await?;
let signatures_count = status.signatures_count as usize;
let threshold = status.threshold;
let ready_to_decrypt = signatures_count >= threshold as usize;
```

**Database Schema Pattern** (from `src/db.rs:95-144`):
- JSON column for storing signatures: `submitted_signatures TEXT NOT NULL DEFAULT '[]'`
- Status tracking: `status TEXT NOT NULL DEFAULT 'pending'`
- Timestamps: `created_at`, `completed_at`

---

## Database Design

### New Table: `change_signers_requests`

```sql
CREATE TABLE change_signers_requests (
    id TEXT PRIMARY KEY NOT NULL,
    turbo_da_app_id TEXT NOT NULL,
    new_participants TEXT NOT NULL,
    new_threshold INTEGER NOT NULL,
    submitted_signatures TEXT NOT NULL DEFAULT '[]',
    status TEXT NOT NULL DEFAULT 'pending',
    created_at INTEGER NOT NULL DEFAULT (strftime('%s', 'now')),
    completed_at INTEGER,
    FOREIGN KEY (turbo_da_app_id) REFERENCES apps(turbo_da_app_id)
);

CREATE INDEX idx_change_signers_turbo_da_app_id 
ON change_signers_requests(turbo_da_app_id);

CREATE INDEX idx_change_signers_status 
ON change_signers_requests(status);
```

**Why this design:**
- Mirrors `decryption_requests` table structure exactly
- Stores new_participants as JSON array (consistent pattern)
- Stores signatures as JSON array (consistent pattern)
- Same indexing for performance

---

## API Design

### 1. Create Change Signers Request

**Endpoint**: `POST /v1/change_signers/create`

**Request Type**: `ChangeSignersRequest`
```rust
#[derive(Debug, Deserialize, Clone)]
pub struct ChangeSignersRequest {
    pub turbo_da_app_id: Uuid,
    pub id: Uuid,
    pub new_participants: Vec<String>,
    pub new_threshold: i64,
}
```

**Response Type**: `ChangeSignersRequestResponse`
```rust
#[derive(Debug, Serialize)]
pub struct ChangeSignersRequestResponse {
    pub id: String,
    pub turbo_da_app_id: String,
    pub status: String,
    pub signers: Vec<String>,
    pub new_participants: Vec<String>,
    pub new_threshold: i64,
    pub created_at: i64,
}
```

### 2. Submit Signature for Change Signers

**Endpoint**: `POST /v1/change_signers/{id}/sign`

**Request Type**: `SubmitChangeSignersSignatureRequest` (reuse existing `SubmitSignatureRequest`)

**Response Type**: `SubmitChangeSignersSignatureResponse`
```rust
#[derive(Debug, Serialize)]
pub struct SubmitChangeSignersSignatureResponse {
    pub id: String,
    pub status: String,
    pub signatures_submitted: usize,
    pub threshold: i64,
    pub ready_to_execute: bool,
    pub tee_attestion: Option<GetQuoteResponse>,
}
```

### 3. Get Change Signers Request

**Endpoint**: `GET /v1/change_signers/{id}`

**Response**: Returns `ChangeSignersRequestRecord` (similar to `DecryptionRequestRecord`)

### 4. List Change Signers Requests

**Endpoint**: `GET /v1/change_signers/list?turbo_da_app_id=xxx`

**Response**: Returns list with pagination (similar to `ListDecryptRequestsResponse`)

---

## Verification Strategy

### Test Infrastructure Assessment
**Infrastructure exists**: YES - Uses in-memory SQLite with `cargo test`
**User wants tests**: Tests-after (tests already exist in `src/tests/decrypt.rs`)
**Framework**: `tokio::test` with real crypto operations

### Testing Approach
- Add tests to `src/tests/` following existing patterns
- Tests use real cryptographic operations (no mocks)
- Test cases to cover:
  - Creating change signers request
  - Submitting signatures from current participants
  - Rejection of signatures from non-participants
  - Duplicate signature prevention
  - Threshold execution
  - TEE attestation generation

---

## Execution Strategy

### Sequential Execution (NO Parallel)
```
Wave 1 (Start Immediately):
└── Task 1: Add database migration and functions

Wave 2 (After Task 1):
└── Task 2: Add types/DTOs to types.rs

Wave 3 (After Task 2):
└── Task 3: Create change_signers.rs API handlers

Wave 4 (After Task 3):
└── Task 4: Add routes to main.rs and mod.rs

Wave 5 (After Task 4):
└── Task 5: Add tests
```

---

## TODOs

- [x] 1. Add database migration and functions for change_signers_requests

  **What to do**:
  - Add migration for `change_signers_requests` table in `db::init_db()`
  - Add `create_change_signers_request()` function
  - Add `get_change_signers_request()` function
  - Add `submit_change_signers_signature()` function
  - Add `complete_change_signers_request()` function
  - Add `get_change_signers_signature_status()` function
  - Add `check_change_signers_submission()` function
  - Add `list_change_signers_requests()` function
  - Add `update_app_threshold()` function
  - Add `ChangeSignersRequestRecord` struct
  - Add `ChangeSignersRequestListWithThreshold` struct
  - Add `ChangeSignersSignatureCheckResult` struct
  - Add `ChangeSignersSubmissionCheck` struct

  **Must NOT do**:
  - Do NOT modify existing tables
  - Do NOT modify existing functions
  - Do NOT break existing database operations

  **Recommended Agent Profile**:
  - **Category**: unspecified-medium
  - **Skills**: ['git-master']
  - **Skills Evaluated but Omitted**: None

  **Parallelization**:
  - **Can Run In Parallel**: NO
  - **Parallel Group**: Sequential - Task 1
  - **Blocks**: Task 2
  - **Blocked By**: None

  **References**:
  - `/Volumes/Personal/Avail/enigma-da/src/db.rs` - Copy patterns from `decryption_requests` table (lines 95-144)
  - `/Volumes/Personal/Avail/enigma-da/src/db.rs` - Copy functions: `create_decryption_request`, `submit_signature`, `complete_decryption_request` (lines 244-347)
  - `/Volumes/Personal/Avail/enigma-da/src/db.rs` - See `DecryptionRequestRecord` struct pattern (lines 349-370)

  **Acceptance Criteria**:
  - [ ] Migration creates table with all columns
  - [ ] Indexes created for performance
  - [ ] All DB functions compile
  - [ ] `cargo check` passes

  **Commit**: YES
  - Message: `feat(db): add change_signers_requests table and functions`
  - Files: `src/db.rs`

---

- [x] 2. Add types/DTOs for change signers to types.rs

  **What to do**:
  - Add `ChangeSignersRequest` struct (input for creating request)
  - Add `ChangeSignersRequestResponse` struct (response after creating)
  - Add `SubmitChangeSignersSignatureRequest` struct (optional, can reuse existing)
  - Add `SubmitChangeSignersSignatureResponse` struct
  - Add `ListChangeSignersRequestsQuery` struct
  - Add `ListChangeSignersRequestsResponse` struct
  - Add `ChangeSignersRequestItem` struct (for listing)

  **Must NOT do**:
  - Do NOT modify existing types
  - Do NOT break existing API contracts

  **Recommended Agent Profile**:
  - **Category**: quick
  - **Skills**: ['git-master']

  **Parallelization**:
  - **Can Run In Parallel**: NO
  - **Parallel Group**: Sequential - Task 2
  - **Blocks**: Task 3
  - **Blocked By**: Task 1

  **References**:
  - `/Volumes/Personal/Avail/enigma-da/src/types.rs` - Copy patterns from `DecryptRequest`, `DecryptRequestResponse` (lines 31-45)
  - `/Volumes/Personal/Avail/enigma-da/src/types.rs` - Copy `SubmitSignatureResponse` pattern (lines 53-61)
  - `/Volumes/Personal/Avail/enigma-da/src/types.rs` - Copy `ListDecryptRequestsQuery`, `ListDecryptRequestsResponse` (lines 107-120)

  **Acceptance Criteria**:
  - [ ] All types derive Debug, Serialize, Deserialize as needed
  - [ ] Types match API design spec
  - [ ] `cargo check` passes

  **Commit**: YES
  - Message: `feat(types): add change signers request/response types`
  - Files: `src/types.rs`

---

- [x] 3. Create change_signers.rs API handlers

  **What to do**:
  - Create new file `src/api/change_signers.rs`
  - Implement `create_change_signers_request()` handler
  - Implement `submit_change_signers_signature()` handler
  - Implement `get_change_signers_request()` handler
  - Implement `list_change_signers_requests()` handler

  **Handler Details**:

  **create_change_signers_request**:
  - Validate new_participants not empty
  - Validate new_threshold > 0
  - Validate new_threshold <= new_participants.len()
  - Check app exists (db::get_app_threshold)
  - Check current participants exist (db::get_participants)
  - Create request in DB (db::create_change_signers_request)
  - Return ChangeSignersRequestResponse with current signers list

  **submit_change_signers_signature**:
  - Check request exists and is "pending"
  - Check participant is CURRENT authorized participant (using CURRENT mpc_participants)
  - Verify ECDSA signature over message `{request_id}:{turbo_da_app_id}`
  - Store signature (db::submit_change_signers_signature)
  - Get signature count vs threshold
  - If threshold met:
    - Execute change: remove_all_participants + add_participant for each new + update_app_threshold
    - Mark request complete
    - Generate TEE quote
    - Return response with tee_attestion
  - If not met: return pending status

  **Must NOT do**:
  - Do NOT modify existing handler files
  - Do NOT copy-paste without adapting variable names

  **Recommended Agent Profile**:
  - **Category**: unspecified-medium
  - **Skills**: ['git-master']

  **Parallelization**:
  - **Can Run In Parallel**: NO
  - **Parallel Group**: Sequential - Task 3
  - **Blocks**: Task 4
  - **Blocked By**: Task 2

  **References**:
  - `/Volumes/Personal/Avail/enigma-da/src/api/decrypt.rs` - Copy `create_decrypt_request` (lines 19-114)
  - `/Volumes/Personal/Avail/enigma-da/src/api/decrypt.rs` - Copy `submit_signature` (lines 149-405) - this is the main reference
  - `/Volumes/Personal/Avail/enigma-da/src/utils.rs` - Use `verify_ecdsa_signature()` (lines 110-148)
  - `/Volumes/Personal/Avail/enigma-da/src/utils.rs` - Use `quote()` for TEE attestation (lines 94-108)
  - `/Volumes/Personal/Avail/enigma-da/src/db.rs` - Use `remove_all_participants()` (lines 219-229)
  - `/Volumes/Personal/Avail/enigma-da/src/db.rs` - Use `add_participant()` (lines 190-202)

  **Acceptance Criteria**:
  - [ ] All 4 handlers implemented
  - [ ] Signature verification works
  - [ ] Threshold execution updates signers and threshold
  - [ ] TEE quote generated on success
  - [ ] Proper error handling with AppError
  - [ ] Tracing spans for all operations
  - [ ] `cargo check` passes

  **Commit**: YES
  - Message: `feat(api): add change signers handlers`
  - Files: `src/api/change_signers.rs`

---

- [x] 4. Add module export and routes

  **What to do**:
  - Add `pub mod change_signers;` to `src/api/mod.rs`
  - Add exports in `src/api/mod.rs` for the 4 handler functions
  - Add routes in `src/main.rs`:
    - `.route("/v1/change_signers/create", post(create_change_signers_request))`
    - `.route("/v1/change_signers/{id}", get(get_change_signers_request))`
    - `.route("/v1/change_signers/{id}/sign", post(submit_change_signers_signature))`
    - `.route("/v1/change_signers/list", get(list_change_signers_requests))`
  - Add imports in `src/main.rs` for the handler functions

  **Must NOT do**:
  - Do NOT break existing routes
  - Do NOT change route ordering unnecessarily

  **Recommended Agent Profile**:
  - **Category**: quick
  - **Skills**: ['git-master']

  **Parallelization**:
  - **Can Run In Parallel**: NO
  - **Parallel Group**: Sequential - Task 4
  - **Blocks**: Task 5
  - **Blocked By**: Task 3

  **References**:
  - `/Volumes/Personal/Avail/enigma-da/src/api/mod.rs` - Copy pattern (lines 1-14)
  - `/Volumes/Personal/Avail/enigma-da/src/main.rs` - Copy route patterns (lines 63-74)
  - `/Volumes/Personal/Avail/enigma-da/src/main.rs` - Copy import patterns (lines 4-11)

  **Acceptance Criteria**:
  - [ ] Routes registered correctly
  - [ ] Module exports work
  - [ ] `cargo check` passes
  - [ ] `cargo build` succeeds

  **Commit**: YES
  - Message: `feat(routes): add change signers endpoints`
  - Files: `src/api/mod.rs`, `src/main.rs`

---

- [x] 5. Add tests for change signers feature

  **What to do**:
  - Create `src/tests/change_signers.rs`
  - Add test: `test_create_change_signers_request_success`
  - Add test: `test_submit_signature_success`
  - Add test: `test_submit_signature_unauthorized`
  - Add test: `test_duplicate_signature_rejected`
  - Add test: `test_threshold_execution`
  - Add test: `test_tee_quote_generation`
  - Add test: `test_list_requests`

  **Test Pattern** (from existing tests):
  ```rust
  #[tokio::test]
  async fn test_create_change_signers_request_success() {
      let pool = setup_test_db().await;
      
      // 1. Register app with participants and threshold
      // 2. Create change signers request
      // 3. Assert response
  }
  ```

  **Must NOT do**:
  - Do NOT modify existing tests
  - Do NOT break existing test suite

  **Recommended Agent Profile**:
  - **Category**: unspecified-medium
  - **Skills**: ['git-master']

  **Parallelization**:
  - **Can Run In Parallel**: NO
  - **Parallel Group**: Sequential - Task 5
  - **Blocks**: None (final task)
  - **Blocked By**: Task 4

  **References**:
  - `/Volumes/Personal/Avail/enigma-da/src/tests/decrypt.rs` - Copy test patterns
  - Tests use hardcoded Hardhat test keys for signatures
  - Tests use in-memory SQLite (`:memory:`)

  **Acceptance Criteria**:
  - [ ] All tests pass: `cargo test`
  - [ ] Tests cover success and failure cases
  - [ ] Tests verify signature verification
  - [ ] Tests verify threshold execution

  **Commit**: YES
  - Message: `test(change_signers): add comprehensive tests`
  - Files: `src/tests/change_signers.rs`

---

## Commit Strategy

| After Task | Message | Files | Verification |
|------------|---------|-------|--------------|
| 1 | feat(db): add change_signers_requests table and functions | src/db.rs | cargo check |
| 2 | feat(types): add change signers request/response types | src/types.rs | cargo check |
| 3 | feat(api): add change signers handlers | src/api/change_signers.rs | cargo check |
| 4 | feat(routes): add change signers endpoints | src/api/mod.rs, src/main.rs | cargo build |
| 5 | test(change_signers): add comprehensive tests | src/tests/change_signers.rs | cargo test |

---

## Success Criteria

### Verification Commands
```bash
# Build the project
cargo build

# Run all tests
cargo test

# Check for warnings
cargo clippy
```

### Final Checklist
- [x] All TODOs completed
- [x] All endpoints working
- [x] All tests passing (11/12, 1 requires TEE environment)
- [x] No compiler warnings (only pre-existing)
- [x] No breaking changes to existing API
- [x] Documentation updated (if applicable)
