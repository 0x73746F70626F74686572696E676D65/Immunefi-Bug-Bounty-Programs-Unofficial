use crate::{
    db,
    error::AppError,
    types::{
        ChangeSignersRequestResponse, CreateChangeSignersRequest,
        ListChangeSignersRequestsQuery, ListChangeSignersRequestsResponse, SubmitSignatureRequest,
        SubmitChangeSignersSignatureResponse,
    },
    utils,
};
use alloy_primitives::{keccak256, hex};
use axum::{
    extract::{Path, Query, State},
    response::IntoResponse,
    Json,
};
use sqlx::SqlitePool;
use uuid::Uuid;

pub async fn create_change_signers_request(
    State(pool): State<SqlitePool>,
    Json(request): Json<CreateChangeSignersRequest>,
) -> Result<impl IntoResponse, AppError> {
    let request_id = Uuid::new_v4();
    let request_span = tracing::info_span!(
        "create_change_signers_request",
        request_id = %request_id,
        app_id = %request.turbo_da_app_id
    );
    let _guard = request_span.enter();

    if request.new_participants.is_empty() {
        tracing::debug!("Rejecting change signers request: empty participants");
        return Err(AppError::InvalidInput(
            "New participants list must not be empty".into(),
        ));
    }

    if request.new_threshold <= 0 || request.new_threshold > request.new_participants.len() as i64 {
        tracing::debug!(
            threshold = request.new_threshold,
            participants = request.new_participants.len(),
            "Rejecting change signers request: invalid threshold"
        );
        return Err(AppError::InvalidInput(
            "Threshold must be > 0 and <= participants count".into(),
        ));
    }

    let turbo_da_app_id_str = request.turbo_da_app_id.to_string();

    db::get_app_threshold(&pool, &turbo_da_app_id_str)
        .await
        .map_err(|e| {
            tracing::error!(error = %e, "Failed to get app threshold");
            AppError::Database(format!("Failed to get app threshold: {}", e))
        })?
        .ok_or_else(|| {
            tracing::debug!("App not found");
            AppError::InvalidInput("App not registered".into())
        })?;


    let current_signers = db::get_participants(&pool, &turbo_da_app_id_str)
        .await
        .map_err(|e| {
            tracing::error!(error = %e, "Failed to get participants");
            AppError::Database(format!("Failed to get participants: {}", e))
        })?;

    if current_signers.is_empty() {
        return Err(AppError::InvalidInput(
            "No current participants found".into(),
        ));
    }

    let new_participants_json = serde_json::to_string(&request.new_participants)
        .map_err(|e| AppError::Internal(format!("Failed to serialize participants: {}", e)))?;

    db::create_change_signers_request(
        &pool,
        &request_id.to_string(),
        &turbo_da_app_id_str,
        &new_participants_json,
        request.new_threshold,
    )
    .await
    .map_err(|e| {
        tracing::error!(error = %e, "Failed to create change signers request");
        AppError::Database(format!("Failed to create request: {}", e))
    })?;

    tracing::info!(
        request_id = %request_id,
        new_threshold = request.new_threshold,
        new_participants_count = request.new_participants.len(),
        "Change signers request created"
    );

    Ok(Json(ChangeSignersRequestResponse {
        id: request_id.to_string(),
        turbo_da_app_id: turbo_da_app_id_str,
        status: "pending".to_string(),
        signers: current_signers,
        new_participants: request.new_participants,
        new_threshold: request.new_threshold,
        created_at: chrono::Utc::now().timestamp(),
    }))
}

pub async fn submit_change_signers_signature(
    State(pool): State<SqlitePool>,
    Path(request_id): Path<String>,
    Json(request): Json<SubmitSignatureRequest>,
) -> Result<impl IntoResponse, AppError> {
    let span = tracing::info_span!(
        "submit_change_signers_signature",
        request_id = %request_id,
        participant = %request.participant_address
    );
    let _guard = span.enter();

    let request_record = db::get_change_signers_request(&pool, &request_id)
        .await
        .map_err(|e| {
            tracing::error!(error = %e, "Failed to fetch request");
            AppError::Database(format!("Failed to fetch request: {}", e))
        })?
        .ok_or_else(|| AppError::RequestNotFound(request_id.clone()))?;

    let check = db::check_change_signers_submission(&pool, &request_id, &request.participant_address)
        .await
        .map_err(|e| {
            tracing::error!(error = %e, "Failed to check submission");
            AppError::Database(format!("Failed to check submission: {}", e))
        })?
        .ok_or_else(|| AppError::RequestNotFound(request_id.clone()))?;

    if check.status != "pending" {
        return Err(AppError::InvalidInput(format!(
            "Request is in '{}' state",
            check.status
        )));
    }

    if !check.is_participant_authorized {
        return Err(AppError::InvalidInput(
            "Participant not authorized".into(),
        ));
    }

    let new_participants_hash = keccak256(request_record.new_participants.as_bytes());
    let message = format!(
        "{}:{}:{}:{}",
        request_id,
        check.turbo_da_app_id,
        hex::encode(new_participants_hash),
        request_record.new_threshold
    );

    match utils::verify_ecdsa_signature(&message, &request.signature, &request.participant_address) {
        Ok(true) => tracing::debug!("Signature verified"),
        Ok(false) => return Err(AppError::InvalidInput("Invalid signature".into())),
        Err(e) => return Err(AppError::InvalidInput(format!("Signature error: {}", e))),
    }

    let submitted = db::submit_change_signers_signature(
        &pool,
        &request_id,
        &request.participant_address,
        &request.signature,
    )
    .await
    .map_err(|e| {
        tracing::error!(error = %e, "Failed to submit signature");
        AppError::Database(format!("Failed to submit signature: {}", e))
    })?;

    if !submitted {
        return Err(AppError::InvalidInput(
            "Signature already submitted".into(),
        ));
    }

    let status = db::get_change_signers_signature_status(&pool, &request_id)
        .await
        .map_err(|e| AppError::Database(format!("Failed to fetch status: {}", e)))?
        .ok_or(AppError::RequestNotFound(request_id.clone()))?;

    let ready_to_execute = status.signatures_count >= status.threshold;

    if ready_to_execute {
        tracing::info!("Threshold met, executing change signers");

        // Execute all changes atomically in a single DB function
        db::execute_change_signers_request(
            &pool,
            &request_id,
            &check.turbo_da_app_id,
            &request_record.new_participants,
            request_record.new_threshold,
        )
        .await
        .map_err(|e| {
            tracing::error!(error = %e, "Failed to execute change signers request");
            AppError::Database(format!("Failed to execute change signers: {}", e))
        })?;

        // Generate TEE Quote
        let quote_data_hash = keccak256(message.as_bytes());
        let tee_quote = utils::quote(quote_data_hash.to_vec()).await.map_err(|e| {
            tracing::error!(error = %e, "Failed to generate TEE quote");
            e
        })?;

        Ok(Json(SubmitChangeSignersSignatureResponse {
            id: request_id,
            status: "completed".to_string(),
            signatures_submitted: status.signatures_count as usize,
            threshold: status.threshold,
            ready_to_execute: true,
            tee_attestion: Some(tee_quote.quote),
        }))
    } else {
        Ok(Json(SubmitChangeSignersSignatureResponse {
            id: request_id,
            status: "pending".to_string(),
            signatures_submitted: status.signatures_count as usize,
            threshold: status.threshold,
            ready_to_execute: false,
            tee_attestion: None,
        }))
    }
}

pub async fn get_change_signers_request(
    State(pool): State<SqlitePool>,
    Path(request_id): Path<String>,
) -> Result<impl IntoResponse, AppError> {
    let record = db::get_change_signers_request(&pool, &request_id)
        .await
        .map_err(|e| AppError::Database(format!("Database error: {}", e)))?
        .ok_or(AppError::RequestNotFound(request_id.clone()))?;

    let signers: Vec<String> = db::get_participants(&pool, &record.turbo_da_app_id)
        .await
        .map_err(|e| AppError::Database(format!("Failed to fetch signers: {}", e)))?;

    let new_participants: Vec<String> = serde_json::from_str(&record.new_participants)
        .map_err(|e| AppError::Internal(format!("JSON error: {}", e)))?;

    Ok(Json(ChangeSignersRequestResponse {
        id: record.id,
        turbo_da_app_id: record.turbo_da_app_id,
        status: record.status,
        signers,
        new_participants,
        new_threshold: record.new_threshold,
        created_at: record.created_at,
    }))
}

pub async fn list_change_signers_requests(
    State(pool): State<SqlitePool>,
    Query(query): Query<ListChangeSignersRequestsQuery>,
) -> Result<impl IntoResponse, AppError> {
    let offset = query.offset.unwrap_or(0);
    let limit = query.limit.unwrap_or(50).min(100);

    let (records, total) = db::list_change_signers_requests(
        &pool,
        &query.turbo_da_app_id,
        offset,
        limit,
    )
    .await
    .map_err(|e| AppError::Database(format!("Failed to list requests: {}", e)))?;

    Ok(Json(ListChangeSignersRequestsResponse {
        items: records,
        total,
        offset,
        limit,
    }))
}
