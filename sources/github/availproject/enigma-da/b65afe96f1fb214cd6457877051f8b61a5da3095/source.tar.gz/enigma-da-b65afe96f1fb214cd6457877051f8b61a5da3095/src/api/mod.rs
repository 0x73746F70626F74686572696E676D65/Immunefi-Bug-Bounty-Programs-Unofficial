pub mod change_signers;
pub mod decrypt;
pub mod encrypt;
pub mod participant;

use axum::response::IntoResponse;
use axum::Json;
pub use change_signers::{
    create_change_signers_request, get_change_signers_request, list_change_signers_requests,
    submit_change_signers_signature,
};
pub use decrypt::{
    create_decrypt_request, get_decrypt_request, list_decrypt_requests, submit_signature,
};
pub use encrypt::encrypt;
pub use participant::register;
use serde_json::json;

pub async fn health() -> impl IntoResponse {
    Json(json!({ "status": "healthy" }))
}
