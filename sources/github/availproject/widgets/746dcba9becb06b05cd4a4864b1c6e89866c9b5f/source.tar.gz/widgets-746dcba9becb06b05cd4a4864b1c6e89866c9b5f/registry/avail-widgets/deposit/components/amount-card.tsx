"use client";

import { useCallback, useRef, useEffect, useState, useMemo } from "react";
import type { SwapMaxParams } from "@avail-project/nexus-core";
import { TokenIcon } from "./token-icon";
import { ErrorBanner } from "./error-banner";
import { PercentageSelector } from "./percentage-selector";
import { parseCurrencyInput } from "../utils";
import { UpDownArrows } from "./icons";
import { usdFormatter } from "../../common";
import { type DestinationConfig } from "../types";
import { Skeleton } from "../../ui/skeleton";
import {
  BALANCE_SAFETY_MARGIN,
  CHARACTER_ANIMATION_DURATION_MS,
  SHINE_ANIMATION_DURATION_MS,
  MAX_INPUT_WIDTH_PX,
} from "../constants/widget";
import { TOKEN_IMAGES } from "../constants/assets";
import { useNexus } from "../../nexus/NexusProvider";

// Hoisted RegExp to avoid recreation on every render (js-hoist-regexp)
const NUMERIC_INPUT_REGEX = /^\d*\.?\d*$/;

interface AmountCardProps {
  amount?: string;
  onAmountChange?: (amount: string) => void;
  selectedTokenAmount?: number;
  maxSwapInput?: SwapMaxParams;
  onErrorStateChange?: (hasError: boolean) => void;
  totalSelectedBalance: number;
  totalBalance: {
    balance: number;
    usdBalance: number;
  };
  destinationConfig: DestinationConfig;
}

function AmountCard({
  amount: externalAmount,
  onAmountChange,
  selectedTokenAmount = 0,
  maxSwapInput,
  onErrorStateChange,
  totalSelectedBalance,
  totalBalance,
  destinationConfig,
}: AmountCardProps) {
  const [internalAmount, setInternalAmount] = useState("");
  const amount = externalAmount ?? internalAmount;
  const setAmount = onAmountChange ?? setInternalAmount;

  const [inputWidth, setInputWidth] = useState(0);
  const [isShining, setIsShining] = useState(false);
  const [isCalculatingMax, setIsCalculatingMax] = useState(false);
  const [animatingIndices, setAnimatingIndices] = useState<Set<number>>(
    new Set(),
  );
  const prevAmountRef = useRef<string>("");
  const prevLengthRef = useRef(0);
  const measureRef = useRef<HTMLSpanElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const displayValue = amount || "";
  const measureText = displayValue || "0";

  // Split display value into characters for animation
  const displayChars = displayValue.split("");
  const { nexusSDK, getFiatValue } = useNexus();

  // Track which characters should animate (newly added ones)
  useEffect(() => {
    const currentLength = displayValue.length;
    const prevLength = prevLengthRef.current;

    // Only animate when characters are added (not removed)
    if (currentLength > prevLength) {
      const newIndices = new Set<number>();
      for (let i = prevLength; i < currentLength; i++) {
        newIndices.add(i);
      }
      setAnimatingIndices(newIndices);

      // Clear animation after it completes
      const timer = setTimeout(() => {
        setAnimatingIndices(new Set());
      }, CHARACTER_ANIMATION_DURATION_MS);

      prevLengthRef.current = currentLength;
      return () => clearTimeout(timer);
    }

    prevLengthRef.current = currentLength;
  }, [displayValue]);

  // Calculate numeric amount for USD equivalent
  const numericAmount = useMemo(() => {
    if (!amount) return 0;
    const parsed = parseFloat(amount.replace(/,/g, ""));
    return isNaN(parsed) ? 0 : parsed;
  }, [amount]);

  // Check if amount exceeds wallet balance
  const exceedsBalance = useMemo(() => {
    if (!amount) return false;
    const numericAmount = parseFloat(amount.replace(/,/g, ""));
    return !isNaN(numericAmount) && numericAmount > totalBalance?.usdBalance;
  }, [amount, totalBalance?.usdBalance]);

  // Check if amount exceeds selected token amount but is within wallet balance
  const exceedsSelectedTokens = useMemo(() => {
    if (!amount || selectedTokenAmount === 0) return false;
    const numericAmount = parseFloat(amount.replace(/,/g, ""));
    return (
      !isNaN(numericAmount) &&
      numericAmount > selectedTokenAmount &&
      numericAmount <= totalBalance?.usdBalance
    );
  }, [amount, selectedTokenAmount, totalBalance?.usdBalance]);

  useEffect(() => {
    if (measureRef.current) {
      setInputWidth(measureRef.current.offsetWidth);
    }
  }, [measureText]);

  // Trigger shine effect when USD amount changes
  useEffect(() => {
    if (amount && amount !== prevAmountRef.current && numericAmount > 0) {
      setIsShining(true);
      const timer = setTimeout(() => {
        setIsShining(false);
      }, SHINE_ANIMATION_DURATION_MS);
      prevAmountRef.current = amount;
      return () => clearTimeout(timer);
    }
    prevAmountRef.current = amount;
  }, [amount, numericAmount]);

  // Notify parent of error state changes
  useEffect(() => {
    const hasError = exceedsBalance || exceedsSelectedTokens;
    onErrorStateChange?.(hasError);
  }, [exceedsBalance, exceedsSelectedTokens, onErrorStateChange]);

  const handleInputChange = useCallback(
    (e: React.ChangeEvent<HTMLInputElement>) => {
      const rawValue = parseCurrencyInput(e.target.value);

      // Validate numeric input (allow unlimited decimals)
      if (rawValue === "" || NUMERIC_INPUT_REGEX.test(rawValue)) {
        setAmount(rawValue);
      }
    },
    [setAmount],
  );

  const handlePercentageClick = useCallback(
    async (percentage: number) => {
      const safeBalance = selectedTokenAmount * BALANCE_SAFETY_MARGIN;
      const setFallbackAmount = () => {
        const calculatedAmount = safeBalance * percentage;
        const newAmount = usdFormatter
          .format(calculatedAmount)
          .replace("$", "");
        setAmount(newAmount);
      };

      if (percentage === 1 && nexusSDK && maxSwapInput) {
        setIsCalculatingMax(true);
        try {
          const maxAmountResult = await nexusSDK.calculateMaxForSwap(
            maxSwapInput,
          );
          const maxTokenAmount = Number.parseFloat(maxAmountResult.maxAmount);

          if (Number.isFinite(maxTokenAmount) && maxTokenAmount > 0) {
            const maxAmountUsd = getFiatValue(
              maxTokenAmount,
              maxAmountResult.symbol || destinationConfig.tokenSymbol,
            );

            if (Number.isFinite(maxAmountUsd) && maxAmountUsd > 0) {
              setAmount(usdFormatter.format(maxAmountUsd).replace("$", ""));
              return;
            }
          }
        } catch (error) {
          console.error("Failed to calculate max swap amount", error);
        } finally {
          setIsCalculatingMax(false);
        }
      }

      setFallbackAmount();
    },
    [
      setAmount,
      selectedTokenAmount,
      nexusSDK,
      maxSwapInput,
      getFiatValue,
      destinationConfig.tokenSymbol,
    ],
  );

  const handleDoubleClick = useCallback(() => {
    // Select all text on double click
    if (inputRef.current) {
      inputRef.current.select();
    }
  }, []);

  // Handle keyboard shortcuts like Ctrl+A
  const handleKeyDown = useCallback(
    (e: React.KeyboardEvent<HTMLInputElement>) => {
      if (e.ctrlKey && e.key === "a") {
        e.preventDefault();
        if (inputRef.current) {
          inputRef.current.select();
        }
      }
    },
    [],
  );

  return (
    <div className="py-8 min-h-53 w-full rounded-lg border bg-base text-muted-foreground shadow-[0_1px_12px_0_rgba(91,91,91,0.05)]">
      {/* Hidden span to measure text width */}
      <span
        ref={measureRef}
        className="absolute invisible whitespace-pre font-display text-[32px] font-medium tracking-[0.8px] tabular-nums"
        aria-hidden="true"
      >
        {measureText}
      </span>

      {/* Amount Input Section */}
      <div
        className={`w-full flex items-center justify-center gap-3 transition-all duration-300 ease-out ${
          numericAmount > 0 ? "-mt-0.5" : "mt-1.5"
        }`}
      >
        <TokenIcon
          tokenSrc={
            destinationConfig.tokenLogo ??
            TOKEN_IMAGES[destinationConfig.tokenSymbol]
          }
          protocolSrc={destinationConfig?.depositTargetLogo}
          tokenAlt="USDC"
        />
        <div className="relative">
          {/* Animated digits layer (behind input) */}
          {isCalculatingMax ? (
            <Skeleton className="h-10 w-28 rounded-md" aria-hidden="true" />
          ) : (
            <div
              className="flex items-center pointer-events-none"
              aria-hidden="true"
            >
              {displayChars.map((char, index) => (
                <span
                  key={`${index}-${char}-${
                    animatingIndices.has(index) ? "anim" : "static"
                  }`}
                  className={`font-display text-[32px] font-medium tracking-[0.8px] tabular-nums inline-block ${
                    animatingIndices.has(index) ? "animate-digit-in" : ""
                  } ${amount ? "text-card-foreground" : "text-muted-foreground"}`}
                >
                  {char}
                </span>
              ))}
              {/* Placeholder when empty */}
              {displayValue.length === 0 && (
                <span className="text-muted-foreground font-display text-[32px] font-medium tracking-[0.8px] tabular-nums">
                  0
                </span>
              )}
            </div>
          )}

          {/* Real input overlaid with transparent text (for cursor positioning) */}
          <input
            ref={inputRef}
            type="text"
            inputMode="decimal"
            value={displayValue}
            onChange={handleInputChange}
            onDoubleClick={handleDoubleClick}
            onKeyDown={handleKeyDown}
            placeholder="0"
            style={{
              width:
                inputWidth > 0
                  ? Math.min(inputWidth + 4, MAX_INPUT_WIDTH_PX)
                  : undefined,
              maxWidth: "calc(100vw - 100px)",
            }}
            className="absolute inset-0 font-display text-[32px] font-medium tracking-[0.8px] tabular-nums bg-transparent border-none outline-none min-w-[22px] text-transparent caret-card-foreground placeholder:text-transparent"
            disabled={isCalculatingMax}
          />
        </div>
      </div>

      {/* Token equivalent - animated height reveal */}
      <div
        className={`grid transition-all duration-300 ease-out ${
          numericAmount > 0
            ? "grid-rows-[1fr] opacity-100"
            : "grid-rows-[0fr] opacity-0 mt-2"
        }`}
      >
        <div className="overflow-hidden">
          <div className="flex items-center justify-center gap-1 text-muted-foreground h-5">
            {isCalculatingMax ? (
              <Skeleton className="h-4 w-20 rounded-sm" aria-hidden="true" />
            ) : (
              <>
                <span
                  key={isShining ? "shining" : "static"}
                  className={`text-[13px] ${
                    isShining ? "animate-glare-shine" : ""
                  }`}
                >
                  {(() => {
                    const rate = getFiatValue(1, destinationConfig.tokenSymbol);
                    if (rate > 0 && numericAmount > 0) {
                      const tokenAmount = numericAmount / rate;
                      const formatted =
                        tokenAmount < 0.000001
                          ? tokenAmount.toExponential(2)
                          : tokenAmount < 1
                            ? tokenAmount.toPrecision(4)
                            : tokenAmount.toLocaleString(undefined, {
                                maximumFractionDigits: 6,
                              });
                      return `≈ ${formatted} ${destinationConfig.tokenSymbol}`;
                    }
                    return `~ ${usdFormatter.format(numericAmount)}`;
                  })()}
                </span>
                <UpDownArrows className="w-4 h-4" />
              </>
            )}
          </div>
        </div>
      </div>

      {/* Percentage Selector */}
      <div className={numericAmount > 0 ? "-mt-px" : ""}>
        <PercentageSelector
          onPercentageClick={handlePercentageClick}
          disabled={isCalculatingMax}
          loadingMax={isCalculatingMax}
        />
      </div>

      {/* Balance Display */}
      <div className="mt-8.25 font-sans text-sm leading-4.5 text-base-foreground-2 text-center">
        Balance: {usdFormatter.format(totalSelectedBalance)}
      </div>

      {/* Error Banner */}
      {exceedsBalance && (
        <div className="mt-4 mx-4">
          <ErrorBanner message="You don't have enough wallet balance." />
        </div>
      )}
      {exceedsSelectedTokens && (
        <div className="mt-4 mx-4">
          <ErrorBanner message="Amount exceeds your selected token balance. Select more tokens or reduce the amount to continue." />
        </div>
      )}
    </div>
  );
}

export default AmountCard;
