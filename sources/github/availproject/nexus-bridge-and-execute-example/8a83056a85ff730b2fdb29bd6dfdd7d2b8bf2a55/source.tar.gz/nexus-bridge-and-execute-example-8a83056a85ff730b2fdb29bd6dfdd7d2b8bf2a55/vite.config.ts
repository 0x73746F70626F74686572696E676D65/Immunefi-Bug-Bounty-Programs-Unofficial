import { defineConfig, type Plugin } from "vite";
import react from "@vitejs/plugin-react";
import tailwindcss from "@tailwindcss/vite";
import path from "path";
import {
  nodePolyfills,
  type PolyfillOptions,
} from "vite-plugin-node-polyfills";

const nodePolyfillsFix = (options?: PolyfillOptions | undefined): Plugin => {
  const origPlugin = nodePolyfills(options);
  return {
    ...origPlugin,
    // eslint-disable-next-line
    resolveId(this, source: string, importer: string | undefined, opts: any) {
      const m =
        /^vite-plugin-node-polyfills\/shims\/(buffer|global|process)$/.exec(
          source
        );
      if (m) {
        return `node_modules/vite-plugin-node-polyfills/shims/${m[1]}/dist/index.cjs`;
      } else {
        if (typeof origPlugin.resolveId === "function") {
          return origPlugin.resolveId.call(this, source, importer, opts);
        }
      }
    },
  };
};

// https://vite.dev/config/
export default defineConfig({
  plugins: [
    react(),
    tailwindcss(),
    nodePolyfillsFix({
      exclude: [
        "http",
        "http2",
        "https",
        "child_process",
        "dns",
        "dgram",
        "domain",
        "vm",
        "tls",
        "sys",
        "repl",
        "readline",
        "os",
        "net",
        "cluster",
        "console",
      ],
    }),
  ],
  resolve: {
    alias: {
      "@": path.resolve(__dirname, "./src"),
    },
  },
});
