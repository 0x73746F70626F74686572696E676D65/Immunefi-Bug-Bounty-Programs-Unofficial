import { NexusSDK } from "@avail-project/nexus-core";

const nexus = new NexusSDK({
  network: "devnet",
  debug: true,
});

export default nexus;
