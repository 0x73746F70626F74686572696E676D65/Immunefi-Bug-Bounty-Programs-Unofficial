import type {
  EthereumProvider,
  UserAssetDatum,
} from "@avail-project/nexus-core";
import { create } from "zustand";

interface Store {
  wallet: string;
  provider: EthereumProvider | null;
  discoveredProviders: {
    info: {
      uuid: string;
      name: string;
      icon: string;
      rdns: string;
    };
    provider: EthereumProvider;
  }[];

  isNexusInitialized: boolean;
  balances: UserAssetDatum[];
  initializeNexus: () => void;
  setWallet: (wallet: string) => void;
  setProvider: (provider: EthereumProvider) => void;
  addDiscoveredProvider: (
    info: { uuid: string; name: string; icon: string; rdns: string },
    provider: EthereumProvider
  ) => void;
  setBalances: (balances: UserAssetDatum[]) => void;
}

export const useStore = create<Store>((set) => ({
  wallet: "",
  provider: null,
  discoveredProviders: [],
  isNexusInitialized: false,
  balances: [],
  initializeNexus: () => set({ isNexusInitialized: true }),
  setWallet: (wallet) => set({ wallet }),
  setProvider: (provider) => set({ provider }),
  addDiscoveredProvider: (info, provider) =>
    set((state) => {
      if (state.discoveredProviders.find((p) => p.info.name === info.name)) {
        return {};
      }
      return {
        discoveredProviders: [...state.discoveredProviders, { info, provider }],
      };
    }),
  setBalances: (balances) => set({ balances }),
}));
