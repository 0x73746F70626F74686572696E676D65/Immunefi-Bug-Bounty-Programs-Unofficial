import { Button } from "./components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "./components/ui/card";
import nexus from "./lib/nexus";
import { useStore } from "./store";
import {
  PopoverContent,
  Popover,
  PopoverTrigger,
} from "./components/ui/popover";
import Decimal from "decimal.js";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { encodeFunctionData } from "viem";

export default function AppHome() {
  const store = useStore();

  async function handleInitializeNexus() {
    await nexus.initialize(store.provider!);
    store.initializeNexus();
    const balances = await nexus.getUnifiedBalances(false);
    store.setBalances(balances);
  }

  function getAaveData() {
    const aaveABI = [
      {
        inputs: [
          { internalType: "address", name: "asset", type: "address" },
          {
            internalType: "uint256",
            name: "amount",
            type: "uint256",
          },
          {
            internalType: "address",
            name: "onBehalfOf",
            type: "address",
          },
          {
            internalType: "uint16",
            name: "referralCode",
            type: "uint16",
          },
        ],
        name: "supply",
        outputs: [],
        stateMutability: "nonpayable",
        type: "function",
      },
    ] as const;
    const encodedData = encodeFunctionData({
      abi: aaveABI,
      functionName: "supply",
      args: [
        "0xc2132d05d31c914a87c6611c10748aeb04b58e8f", // USDT on Polygon
        BigInt(new Decimal(0.1).mul(Decimal.pow(10, 6)).toFixed()), // Amount
        store.wallet as `0x${string}`, // currently deposited on behalf of current user, but can be deposited on behalf of any other address
        0, // referral code, keep it 0 always
      ],
    });
    return {
      data: encodedData,
      to: "0x794a61358D6845594F94dc1DB02A252b5b4814aD" as `0x${string}`, // Aave Pool on Polygon
    };
  }

  function getFluidData() {
    const fluidABI = [
      {
        inputs: [
          {
            internalType: "uint256",
            name: "assets_",
            type: "uint256",
          },
          {
            internalType: "address",
            name: "receiver_",
            type: "address",
          },
        ],
        name: "deposit",
        outputs: [
          {
            internalType: "uint256",
            name: "shares_",
            type: "uint256",
          },
        ],
        stateMutability: "nonpayable",
        type: "function",
      },
      {
        inputs: [
          {
            internalType: "uint256",
            name: "assets_",
            type: "uint256",
          },
          {
            internalType: "address",
            name: "receiver_",
            type: "address",
          },
          {
            internalType: "uint256",
            name: "minAmountOut_",
            type: "uint256",
          },
        ],
        name: "deposit",
        outputs: [
          {
            internalType: "uint256",
            name: "shares_",
            type: "uint256",
          },
        ],
        stateMutability: "nonpayable",
        type: "function",
      },
    ];
    const encodedData = encodeFunctionData({
      abi: fluidABI,
      functionName: "deposit",
      args: [
        BigInt(new Decimal(0.1).mul(Decimal.pow(10, 6)).toFixed()), // Amount of USDT to deposit
        store.wallet as `0x${string}`, // receiver of the deposit, currently deposited on behalf of current user, but can be deposited on behalf of any other address
      ],
    });
    return {
      data: encodedData,
      to: "0x6f5e34eFf43D9ab7c977512509C53840B5EfBA85" as `0x${string}`, // Fluid USDT Pool on Polygon
    };
  }

  async function handleBridgeAndExecute(type: "fluid" | "aave") {
    try {
      const { data, to } = type === "aave" ? getAaveData() : getFluidData();

      const result = await nexus.bridgeAndExecute(
        {
          amount: BigInt(new Decimal(0.1).mul(Decimal.pow(10, 6)).toFixed()),
          token: "USDT",
          toChainId: 137,
          // sourceChains: [8453] // Optional,
          execute: {
            to, // to the contract address of example Aave or Fluid,
            data, // hex data encoded using the abi of the contract (using ethers or viem)
            tokenApproval: {
              token: "USDT",
              amount: BigInt(
                new Decimal(0.1).mul(Decimal.pow(10, 6)).toFixed()
              ),
              spender: to, // Should be the contract address or spender address of example Aave or Fluid
            },
          },
        },
        {
          onEvent: (event) => {
            switch (event.name) {
              case "STEPS_LIST": {
                event.args.forEach((args) => {
                  switch (args.type) {
                    case "ALLOWANCE_ALL_DONE": // typeID: "AAAD"
                    case "APPROVAL": // typeID: "AP"
                    case "INTENT_ACCEPTED": // typeID: "IA"
                    case "INTENT_COLLECTION_COMPLETE": // typeID: "ICC"
                    case "INTENT_DEPOSITS_CONFIRMED": // typeID: "UIDC"
                    case "INTENT_FULFILLED": // typeID: "IF"
                    case "INTENT_HASH_SIGNED": // typeID: "IHS"
                    case "TRANSACTION_CONFIRMED": // typeID: "CN"
                    case "TRANSACTION_SENT": {
                      // typeID: "TS"
                      console.log(args.type, args.typeID);
                      return;
                    }
                    case "INTENT_SUBMITTED": {
                      // typeID: "IS", data: {explorerURL: string, intentID: number}
                      // values of data.explorerURL will be blank string "" and data.intentID will be null or 0 since this step isn't completed yet
                      console.log(
                        args.data.explorerURL,
                        args.data.intentID,
                        args.type,
                        args.typeID
                      );
                      return;
                    }

                    case "INTENT_COLLECTION": {
                      // typeID: "IC_${index}", data: {confirmed: number, total: number}
                      // values of data.confirmed and data.total will be null or 0 since this step isn't completed yet
                      console.log(
                        args.data.confirmed,
                        args.data.total,
                        args.type,
                        args.typeID
                      );
                      return;
                    }
                    case "ALLOWANCE_APPROVAL_MINED": // typeID: "AAM_${index}", data: {chainID: number, chainName: string}
                    case "ALLOWANCE_USER_APPROVAL": {
                      // typeID: "AUA_${index}", data: {chainID: number, chainName: string}
                      console.log(
                        args.data.chainID,
                        args.data.chainName,
                        args.type,
                        args.typeID
                      );
                      return;
                    }
                    case "INTENT_DEPOSIT": {
                      // typeID: "ID_${index}", data: {amount: string, chainID: number, chainName: string}
                      console.log(
                        args.data.amount,
                        args.data.chainID,
                        args.data.chainName,
                        args.type,
                        args.typeID
                      );
                      return;
                    }
                  }
                });
                return;
              }
              case "STEP_COMPLETE": {
                const args = event.args;
                switch (args.type) {
                  case "ALLOWANCE_ALL_DONE": // typeID: "AAAD"
                  case "APPROVAL": // typeID: "AP"
                  case "INTENT_ACCEPTED": // typeID: "IA"
                  case "INTENT_COLLECTION_COMPLETE": // typeID: "ICC"
                  case "INTENT_DEPOSITS_CONFIRMED": // typeID: "UIDC"
                  case "INTENT_FULFILLED": // typeID: "IF"
                  case "INTENT_HASH_SIGNED": // typeID: "IHS"
                  case "TRANSACTION_CONFIRMED": // typeID: "CN"
                  case "TRANSACTION_SENT": {
                    // typeID: "TS"
                    console.log(args.type, args.typeID);
                    return;
                  }
                  case "INTENT_SUBMITTED": {
                    // typeID: "IS", data: {explorerURL: string, intentID: number}
                    console.log(
                      args.data.explorerURL,
                      args.data.intentID,
                      args.type,
                      args.typeID
                    );
                    return;
                  }

                  case "INTENT_COLLECTION": {
                    // typeID: "IC_${index}", data: {confirmed: number, total: number}
                    console.log(
                      args.data.confirmed,
                      args.data.total,
                      args.type,
                      args.typeID
                    );
                    return;
                  }
                  case "ALLOWANCE_APPROVAL_MINED": // typeID: "AAM_${index}", data: {chainID: number, chainName: string}
                  case "ALLOWANCE_USER_APPROVAL": {
                    // typeID: "AUA_${index}", data: {chainID: number, chainName: string}
                    console.log(
                      args.data.chainID,
                      args.data.chainName,
                      args.type,
                      args.typeID
                    );
                    return;
                  }
                  case "INTENT_DEPOSIT": {
                    // typeID: "ID_${index}", data: {amount: string, chainID: number, chainName: string}
                    console.log(
                      args.data.amount,
                      args.data.chainID,
                      args.data.chainName,
                      args.type,
                      args.typeID
                    );
                    return;
                  }
                }
                return;
              }
              case "SWAP_STEP_COMPLETE": {
                const args = event.args;
                switch (args.type) {
                  case "CREATE_PERMIT_FOR_SOURCE_SWAP": // typeID: "CREATE_PERMIT_FOR_SOURCE_SWAP_${number}_${string}"
                  case "CREATE_PERMIT_EOA_TO_EPHEMERAL": {
                    // typeID: "CREATE_PERMIT_EOA_TO_EPHEMERAL_${number}_${string}",
                    // chain: {id: number, name: string}, completed: boolean, symbol: string
                    console.log(
                      args.type,
                      args.typeID,
                      args.chain.id,
                      args.chain.name,
                      args.completed,
                      args.symbol
                    );
                    return;
                  }
                  case "SWAP_START": // typeID: "SWAP_START"
                  case "SOURCE_SWAP_BATCH_TX": // typeID: "SOURCE_SWAP_BATCH_TX"
                  case "SWAP_COMPLETE": // typeID: "SWAP_COMPLETE"
                  case "DETERMINING_SWAP": // typeID: "DETERMINING_SWAP"
                  case "DESTINATION_SWAP_BATCH_TX": {
                    // typeID: "DESTINATION_SWAP_BATCH_TX",
                    // completed: boolean
                    console.log(args.type, args.typeID, args.completed);
                    return;
                  }
                  case "SOURCE_SWAP_HASH": // typeID: "SOURCE_SWAP_HASH_{bigint}"
                  case "DESTINATION_SWAP_HASH": {
                    // typeID: "DESTINATION_SWAP_HASH_{number}",
                    // chain: {id: number, name: string}, completed: boolean, explorerURL: string
                    console.log(
                      args.type,
                      args.typeID,
                      args.chain.id,
                      args.chain.name,
                      args.completed,
                      args.explorerURL
                    );
                    return;
                  }
                  case "RFF_ID": {
                    // typeID: "RFF_ID", data: number, completed: boolean
                    console.log(
                      args.type,
                      args.typeID,
                      args.data,
                      args.completed
                    );
                    return;
                  }
                }
                return;
              }
            }
          },
        }
      );
      console.log("Result");
      console.log("Destination Chain ID: ", result.toChainId);
      console.log("Is Bridge Skipped: ", result.bridgeSkipped);

      if (!result.bridgeSkipped) {
        console.log("Bridge Transaction: ", result.bridgeExplorerUrl);
      }

      console.log(
        "Approval Transaction Hash: ",
        result.approvalTransactionHash
      );
      console.log("Execute Transaction: ", result.executeExplorerUrl);
      console.log("Execute Transaction Hash: ", result.executeTransactionHash);
    } catch (error) {
      // Catch all the errors here
      console.error(error);
    }
  }

  return (
    <>
      <div className="flex flex-col gap-5  w-full max-w-120">
        <Card className="p-5">
          <CardContent className="flex flex-col gap-2 ">
            <Button onClick={handleInitializeNexus}>Initialize Nexus</Button>
            <Popover>
              <PopoverTrigger asChild>
                <Button disabled={!store.isNexusInitialized}>
                  Show Unified Balance
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-80 overflow-y-auto max-h-80">
                <Accordion type="multiple" className="w-full">
                  <div className="flex flex-col w-full">
                    {store.balances.map((balance) => (
                      <AccordionItem value={balance.symbol}>
                        <AccordionTrigger className="bg-transparent">
                          <div
                            className="flex flex-col gap-1 grow"
                            key={balance.symbol}
                          >
                            <div className="flex items-center justify-between">
                              <div className="flex items-center gap-2">
                                {balance.icon ? (
                                  <img
                                    src={balance.icon}
                                    alt={balance.symbol}
                                    className="w-4 h-4"
                                  />
                                ) : (
                                  <div className="w-4 h-4 bg-gray-800 rounded-full">
                                    {balance.symbol.charAt(0)}
                                  </div>
                                )}
                                <span className="font-semibold">
                                  {balance.symbol}
                                </span>
                              </div>
                              <span className="font-semibold">
                                {new Decimal(balance.balance)
                                  .toDecimalPlaces(6)
                                  .toFixed()}
                              </span>
                            </div>
                          </div>
                        </AccordionTrigger>
                        <AccordionContent className="pl-4 pb-4 flex flex-col gap-1">
                          {balance.breakdown.map((b) => (
                            <div
                              key={`${balance.symbol}-${b.chain.id}-${b.balance}`}
                              className="flex items-center justify-between"
                            >
                              <div className="flex items-center gap-1">
                                {b.chain.logo ? (
                                  <img
                                    src={b.chain.logo}
                                    alt={b.chain.name}
                                    className="w-3 h-3"
                                  />
                                ) : (
                                  <div className="w-3 h-3 bg-gray-800 rounded-full">
                                    {b.chain.name.charAt(0)}
                                  </div>
                                )}
                                <span className="text-sm">{b.chain.name}</span>
                              </div>
                              <span className="text-sm font-semibold">
                                {new Decimal(b.balance)
                                  .toDecimalPlaces(6)
                                  .toFixed()}
                              </span>
                            </div>
                          ))}
                        </AccordionContent>
                      </AccordionItem>
                    ))}
                  </div>
                </Accordion>
              </PopoverContent>
            </Popover>
          </CardContent>
        </Card>
        <Card className="p-5">
          <CardHeader>
            <CardTitle>Bridge And Execute</CardTitle>
            <CardDescription className="text-xs">
              Bridges the tokens to destination chain and executes the contract
              call. Make sure to have less than 0.1 USDT on Polygon Mainnet and
              more than 0.1 USDT in all the supported chains combined to
              experience this
            </CardDescription>
          </CardHeader>
          <CardContent className="flex flex-col gap-2 ">
            <Button
              disabled={!store.isNexusInitialized}
              onClick={() => handleBridgeAndExecute("aave")}
            >
              0.1 USDT on Polygon to Aave
            </Button>
            <Button
              disabled={!store.isNexusInitialized}
              onClick={() => handleBridgeAndExecute("fluid")}
            >
              0.1 USDT on Polygon to Fluid
            </Button>
          </CardContent>
        </Card>
      </div>
    </>
  );
}
