import type { EthereumProvider } from "@avail-project/nexus-core";
import { Button } from "./components/ui/button";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "./components/ui/popover";
import { useStore } from "./store";

export default function ConnectWallet() {
  const store = useStore();

  async function handleConnectWallet(provider: EthereumProvider) {
    try {
      const accounts = (await provider.request({
        method: "eth_requestAccounts",
      })) as string[];
      console.log(accounts);
      store.setProvider(provider);
      store.setWallet(accounts[0]);
    } catch (error) {
      console.error(error);
    }
  }

  return (
    <>
      <Popover>
        <PopoverTrigger asChild>
          <Button>Connect Wallet</Button>
        </PopoverTrigger>
        <PopoverContent className="w-80">
          <div className="flex flex-col w-full gap-2">
            <span className="text-sm font-medium">Available Wallets</span>
            {store.discoveredProviders.map((provider) => (
              <Button
                key={provider.info.name}
                className="flex gap-2 items-center"
                onClick={() => handleConnectWallet(provider.provider)}
              >
                <img
                  src={provider.info.icon}
                  alt={provider.info.name}
                  className="w-4 h-4"
                />
                <span>{provider.info.name}</span>
              </Button>
            ))}
          </div>
        </PopoverContent>
      </Popover>
    </>
  );
}
