import { useEffect } from "react";
import "./App.css";
import type { EthereumProvider } from "@avail-project/nexus-core";
import { useStore } from "./store";
import ConnectWallet from "./ConnectWallet";
import AppHome from "./AppHome";

function App() {
  const store = useStore();

  useEffect(() => {
    // Using EIP 6963 to connect to a injected wallets
    // The DApp listens to announced providers
    // @ts-expect-error - EIP 6963 is not a standard event
    window.addEventListener(
      "eip6963:announceProvider",
      (event: {
        detail: {
          info: {
            uuid: string;
            name: string;
            icon: string;
            rdns: string;
          };
          provider: EthereumProvider;
        };
      }) => {
        console.log(event);
        if (event.detail)
          store.addDiscoveredProvider(event.detail.info, event.detail.provider);
      }
    );

    // The DApp dispatches a request event which will be heard by
    // Wallets' code that had run earlier
    window.dispatchEvent(new Event("eip6963:requestProvider"));
  }, []);

  return (
    <>
      <div>{store.wallet ? <AppHome /> : <ConnectWallet />}</div>
    </>
  );
}

export default App;
