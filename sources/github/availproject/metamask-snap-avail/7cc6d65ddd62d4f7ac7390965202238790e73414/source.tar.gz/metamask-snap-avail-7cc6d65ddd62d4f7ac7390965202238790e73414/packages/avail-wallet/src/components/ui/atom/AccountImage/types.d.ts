declare module '@metamask/jazzicon';
