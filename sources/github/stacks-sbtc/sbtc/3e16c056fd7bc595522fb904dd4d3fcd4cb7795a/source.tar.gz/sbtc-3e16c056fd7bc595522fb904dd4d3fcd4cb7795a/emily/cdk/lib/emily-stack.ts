// Import the AWS CDK
import * as cdk from 'aws-cdk-lib';
import * as apig from 'aws-cdk-lib/aws-apigateway';
import * as dynamodb from 'aws-cdk-lib/aws-dynamodb';
import * as iam from 'aws-cdk-lib/aws-iam';
import * as lambda from 'aws-cdk-lib/aws-lambda';
import * as route53 from 'aws-cdk-lib/aws-route53';
import * as route53Targets from 'aws-cdk-lib/aws-route53-targets';
import * as s3 from 'aws-cdk-lib/aws-s3';
import * as certificatemanager from 'aws-cdk-lib/aws-certificatemanager';
import * as logs from 'aws-cdk-lib/aws-logs';
import * as cr from 'aws-cdk-lib/custom-resources';
import { Construct } from 'constructs';
import { Constants } from './constants';
import { EmilyStackProps } from './emily-stack-props';
import { EmilyStackUtils } from './emily-stack-utils';

/**
 * @class EmilyStack
 * @classdesc Creates a stack with DynamoDB tables and a Lambda function.
 */
export class EmilyStack extends cdk.Stack {

    /**
     * @constructor
     * @param {Construct} scope The AWS CDK construct scope.
     * @param {string} id The stack ID.
     * @param {EmilyStackProps} props The stack properties.
     */
    constructor(scope: Construct, id: string, props: EmilyStackProps) {
        super(scope, id, props);

        // Set persistent resources to be deleted when the stack is deleted in a development environment.
        //
        // In a production environment we don't want to do this as it would result in data loss
        // without an explicit action to delete the resources.
        const persistentResourceRemovalPolicy: cdk.RemovalPolicy = EmilyStackUtils.isDevelopmentStack()
            ? cdk.RemovalPolicy.DESTROY
            : cdk.RemovalPolicy.RETAIN;

        // we should support 'undefine' type because the PIT option is not available in local DynamoDB
        // and will make it crash
        const pointInTimeRecovery: undefined | boolean = EmilyStackUtils.isDevelopmentStack() ? undefined : true;

        const depositTableId: string = 'DepositTable';
        const depositTableName: string = EmilyStackUtils.getResourceName(depositTableId, props);
        const depositTable: dynamodb.Table = this.createOrUpdateDepositTable(
            depositTableId,
            depositTableName,
            persistentResourceRemovalPolicy,
            pointInTimeRecovery,
        );

        const withdrawalTableId: string = 'WithdrawalTable';
        const withdrawalTableName: string = EmilyStackUtils.getResourceName(withdrawalTableId, props);
        const withdrawalTable: dynamodb.Table = this.createOrUpdateWithdrawalTable(
            withdrawalTableId,
            withdrawalTableName,
            persistentResourceRemovalPolicy,
            pointInTimeRecovery,
        );

        const chainstateTableId: string = 'ChainstateTable';
        const chainstateTableName: string = EmilyStackUtils.getResourceName(chainstateTableId, props);
        const chainstateTable: dynamodb.Table = this.createOrUpdateChainstateTable(
            chainstateTableId,
            chainstateTableName,
            persistentResourceRemovalPolicy,
            pointInTimeRecovery,
        );

        const limitTableId: string = 'LimitTable';
        const limitTableName: string = EmilyStackUtils.getResourceName(limitTableId, props);
        const limitTable: dynamodb.Table = this.createOrUpdateLimitTable(
            limitTableId,
            limitTableName,
            persistentResourceRemovalPolicy,
            pointInTimeRecovery,
        );

        const throttleTableId: string = 'ThrottleTable';
        const throttleTableName: string = EmilyStackUtils.getResourceName(throttleTableId, props);
        const throttleTable: dynamodb.Table = this.createOrUpdateThrottleTable(
            throttleTableId,
            throttleTableName,
            persistentResourceRemovalPolicy,
            pointInTimeRecovery,
        );

        if (!EmilyStackUtils.isTablesOnly()) {
            const operationLambda: lambda.Function = this.createOrUpdateOperationLambda(
                depositTableName,
                withdrawalTableName,
                chainstateTableName,
                limitTableName,
                throttleTableName,
                persistentResourceRemovalPolicy,
                props
            );

            // Create an alias for the lambda.
            const alias = new lambda.Alias(this, "OperationLambdaAlias", {
                aliasName: "Current",
                version: operationLambda.currentVersion,
            });

            // Give the operation lambda full access to the DynamoDB tables.
            depositTable.grantReadWriteData(operationLambda);
            withdrawalTable.grantReadWriteData(operationLambda);
            chainstateTable.grantReadWriteData(operationLambda);
            limitTable.grantReadWriteData(operationLambda);
            throttleTable.grantReadWriteData(operationLambda);

            const sanctionsBucket: s3.Bucket = this.createSanctionsBucket(
                persistentResourceRemovalPolicy,
                props,
            );

            const emilyApis: apig.SpecRestApi[] = this.createOrUpdateApi(
                alias,
                sanctionsBucket,
                props,
            );
        }
    }

    /**
     * Creates the private S3 bucket that backs the sanctions list served at
     * `GET /sanctions` on the public API.
     * @param {cdk.RemovalPolicy} removalPolicy The removal policy for the bucket.
     * @param {EmilyStackProps} props The stack properties.
     * @returns {s3.Bucket} The created or updated S3 bucket.
     */
    createSanctionsBucket(
        removalPolicy: cdk.RemovalPolicy,
        props: EmilyStackProps,
    ): s3.Bucket {
        const bucketId: string = 'SanctionsLists';
        return new s3.Bucket(this, bucketId, {
            bucketName: EmilyStackUtils.getResourceName(bucketId, props).toLowerCase(),
            blockPublicAccess: s3.BlockPublicAccess.BLOCK_ALL,
            encryption: s3.BucketEncryption.S3_MANAGED,
            enforceSSL: true,
            removalPolicy,
            autoDeleteObjects: removalPolicy === cdk.RemovalPolicy.DESTROY,
        });
    }

    /**
     * Creates or updates a DynamoDB table for deposits.
     * @param {string} tableId The id of the table AWS resource.
     * @param {string} tableName The name of the DynamoDB table.
     * @param {cdk.RemovalPolicy} removalPolicy The removal policy for the table.
     * @returns {dynamodb.Table} The created or updated DynamoDB table.
     * @post A DynamoDB table with configured indexes is returned.
     */
    createOrUpdateDepositTable(
        depositTableId: string,
        depositTableName: string,
        removalPolicy: cdk.RemovalPolicy,
        pointInTimeRecovery: undefined | boolean,
    ): dynamodb.Table {
        const table: dynamodb.Table = new dynamodb.Table(this, depositTableId, {
            tableName: depositTableName,
            partitionKey: {
                name: 'BitcoinTxid',
                type: dynamodb.AttributeType.STRING,
            },
            sortKey: {
                name: 'BitcoinTxOutputIndex',
                type: dynamodb.AttributeType.NUMBER,
            },
            removalPolicy: removalPolicy,
            billingMode: dynamodb.BillingMode.PAY_PER_REQUEST, // On-demand provisioning
            pointInTimeRecovery: pointInTimeRecovery,
        });

        const byStatusIndexName: string = "DepositStatus";
        table.addGlobalSecondaryIndex({
            indexName: byStatusIndexName,
            partitionKey: {
                name: 'OpStatus',
                type: dynamodb.AttributeType.STRING
            },
            sortKey: {
                name: 'LastUpdateHeight',
                type: dynamodb.AttributeType.NUMBER
            },
            projectionType: dynamodb.ProjectionType.INCLUDE,
            nonKeyAttributes: [
                "BitcoinTxid",
                "BitcoinTxOutputIndex",
                "Recipient",
                "Amount",
                "LastUpdateBlockHash",
                "ReclaimScript",
                "DepositScript",
            ]
        });

        const byRecipientIndexName: string = "DepositRecipient";
        table.addGlobalSecondaryIndex({
            indexName: byRecipientIndexName,
            partitionKey: {
                name: 'Recipient',
                type: dynamodb.AttributeType.STRING
            },
            sortKey: {
                name: 'LastUpdateHeight',
                type: dynamodb.AttributeType.NUMBER
            },
            projectionType: dynamodb.ProjectionType.INCLUDE,
            nonKeyAttributes: [
                "BitcoinTxid",
                "BitcoinTxOutputIndex",
                "OpStatus",
                "Amount",
                "LastUpdateBlockHash",
                "ReclaimScript",
                "DepositScript",
            ]
        });

        // Index to efficiently query deposits that comes from a specific address
        const byReclaimPubkeysHashIndexName: string = "DepositReclaimPubkeysHashIndex";
        table.addGlobalSecondaryIndex({
            indexName: byReclaimPubkeysHashIndexName,
            partitionKey: {
                name: 'ReclaimPubkeysHash',
                type: dynamodb.AttributeType.STRING
            },
            sortKey: {
                name: 'LastUpdateHeight',
                type: dynamodb.AttributeType.NUMBER
            },
            projectionType: dynamodb.ProjectionType.INCLUDE,
            nonKeyAttributes: [
                "BitcoinTxid",
                "BitcoinTxOutputIndex",
                "Recipient",
                "OpStatus",
                "Amount",
                "LastUpdateBlockHash",
                "ReclaimScript",
                "DepositScript",
            ]
        });
        return table;
    }

    /**
     * Creates or updates a DynamoDB table for withdrawals.
     * @param {string} tableId The id of the table AWS resource.
     * @param {string} tableName The name of the DynamoDB table.
     * @param {cdk.RemovalPolicy} removalPolicy The removal policy for the table.
     * @returns {dynamodb.Table} The created or updated DynamoDB table.
     * @post A DynamoDB table with configured indexes is returned.
     */
    createOrUpdateWithdrawalTable(
        tableId: string,
        tableName: string,
        removalPolicy: cdk.RemovalPolicy,
        pointInTimeRecovery: undefined | boolean,
    ): dynamodb.Table {
        // Create DynamoDB table to store the messages. Encrypted by default.
        const table: dynamodb.Table = new dynamodb.Table(this, tableId, {
            tableName: tableName,
            partitionKey: {
                name: 'RequestId',
                type: dynamodb.AttributeType.NUMBER,
            },
            sortKey: {
                name: 'StacksBlockHash',
                type: dynamodb.AttributeType.STRING,
            },
            removalPolicy: removalPolicy,
            billingMode: dynamodb.BillingMode.PAY_PER_REQUEST, // On-demand provisioning
            pointInTimeRecovery: pointInTimeRecovery,
        });

        const byStatusIndexName: string = "WithdrawalStatus";
        table.addGlobalSecondaryIndex({
            indexName: byStatusIndexName,
            partitionKey: {
                name: 'OpStatus',
                type: dynamodb.AttributeType.STRING
            },
            sortKey: {
                name: 'LastUpdateHeight',
                type: dynamodb.AttributeType.NUMBER
            },
            projectionType: dynamodb.ProjectionType.INCLUDE,
            nonKeyAttributes: [
                "RequestId",
                "StacksBlockHash",
                "StacksBlockHeight",
                "Recipient",
                "Sender",
                "Amount",
                "LastUpdateBlockHash",
                "Txid",
            ]
        });

        const byRecipientIndexName: string = "WithdrawalRecipient";
        table.addGlobalSecondaryIndex({
            indexName: byRecipientIndexName,
            partitionKey: {
                name: 'Recipient',
                type: dynamodb.AttributeType.STRING
            },
            sortKey: {
                name: 'LastUpdateHeight',
                type: dynamodb.AttributeType.NUMBER
            },
            projectionType: dynamodb.ProjectionType.INCLUDE,
            nonKeyAttributes: [
                "RequestId",
                "StacksBlockHash",
                "StacksBlockHeight",
                "OpStatus",
                "Sender",
                "Amount",
                "LastUpdateBlockHash",
                "Txid",
            ]
        });

        const bySenderIndexName: string = "WithdrawalSender";
        table.addGlobalSecondaryIndex({
            indexName: bySenderIndexName,
            partitionKey: {
                name: 'Sender',
                type: dynamodb.AttributeType.STRING
            },
            sortKey: {
                name: 'LastUpdateHeight',
                type: dynamodb.AttributeType.NUMBER
            },
            projectionType: dynamodb.ProjectionType.INCLUDE,
            nonKeyAttributes: [
                "RequestId",
                "StacksBlockHash",
                "StacksBlockHeight",
                "OpStatus",
                "Recipient",
                "Amount",
                "LastUpdateBlockHash",
                "Txid",
            ]
        });
        return table;
    }

    /**
     * Creates or updates a DynamoDB table for chain state.
     * @param {string} tableId The id of the table AWS resource.
     * @param {string} tableName The name of the DynamoDB table.
     * @returns {dynamodb.Table} The created or updated DynamoDB table.
     * @post A DynamoDB table is returned without additional configuration.
     */
    createOrUpdateChainstateTable(
        tableId: string,
        tableName: string,
        removalPolicy: cdk.RemovalPolicy,
        pointInTimeRecovery: undefined | boolean,
    ): dynamodb.Table {
        // Create DynamoDB table to store the messages. Encrypted by default.
        const table = new dynamodb.Table(this, tableId, {
            tableName: tableName,
            partitionKey: {
                name: 'Height',
                type: dynamodb.AttributeType.NUMBER,
            },
            sortKey: {
                name: 'Hash',
                type: dynamodb.AttributeType.STRING,
            },
            removalPolicy: removalPolicy,
            billingMode: dynamodb.BillingMode.PAY_PER_REQUEST, // On-demand provisioning
            pointInTimeRecovery: pointInTimeRecovery,
        });
        const byBitcoinHeight: string = "BitcoinBlockHeightIndex";
        table.addGlobalSecondaryIndex({
            indexName: byBitcoinHeight,
            partitionKey: {
                name: 'BitcoinHeight',
                type: dynamodb.AttributeType.NUMBER
            },
            sortKey: {
                name: 'Height',
                type: dynamodb.AttributeType.NUMBER
            },
            projectionType: dynamodb.ProjectionType.INCLUDE,
            nonKeyAttributes: [
                "Hash",
            ]
        });
        return table;
    }

     /**
     * Creates or updates a DynamoDB table for throttle keys.
     * @param {string} tableId The id of the table AWS resource.
     * @param {string} tableName The name of the DynamoDB table.
     * @returns {dynamodb.Table} The created or updated DynamoDB table.
     * @post A DynamoDB table is returned without additional configuration.
     */
     createOrUpdateThrottleTable(
        tableId: string,
        tableName: string,
        removalPolicy: cdk.RemovalPolicy,
        pointInTimeRecovery: undefined | boolean,
    ): dynamodb.Table {
        // Create DynamoDB table to store the messages. Encrypted by default.
        const table =  new dynamodb.Table(this, tableId, {
            tableName: tableName,
            partitionKey: {
                name: 'Hash',
                type: dynamodb.AttributeType.STRING,
            },
            sortKey: {
                name: 'CreatedAt',
                type: dynamodb.AttributeType.NUMBER,
            },
            removalPolicy: removalPolicy,
            billingMode: dynamodb.BillingMode.PAY_PER_REQUEST, // On-demand provisioning
            pointInTimeRecovery: pointInTimeRecovery,
        });
        return table;
    }

    /**
     * Creates or updates a DynamoDB table for limits.
     * @param {string} tableId The id of the table AWS resource.
     * @param {string} tableName The name of the DynamoDB table.
     * @returns {dynamodb.Table} The created or updated DynamoDB table.
     * @post A DynamoDB table is returned without additional configuration.
     */
    createOrUpdateLimitTable(
        tableId: string,
        tableName: string,
        removalPolicy: cdk.RemovalPolicy,
        pointInTimeRecovery: undefined | boolean,
    ): dynamodb.Table {
        // Create DynamoDB table to store the messages. Encrypted by default.
        return new dynamodb.Table(this, tableId, {
            tableName: tableName,
            partitionKey: {
                name: 'Account',
                type: dynamodb.AttributeType.STRING,
            },
            sortKey: {
                name: 'Timestamp',
                type: dynamodb.AttributeType.NUMBER,
            },
            removalPolicy: removalPolicy,
            billingMode: dynamodb.BillingMode.PAY_PER_REQUEST, // On-demand provisioning
            pointInTimeRecovery: pointInTimeRecovery,
        });
    }

    /**
     * Creates or updates the operation Lambda function.
     * @param {string} depositTableName The name of the deposit DynamoDB table.
     * @param {string} withdrawalTableName The name of the withdrawal DynamoDB table.
     * @param {string} chainstateTableName The name of the chainstate DynamoDB table.
     * @param {EmilyStackProps} props The stack properties.
     * @returns {lambda.Function} The created or updated Lambda function.
     * @post Lambda function with environment variables set and permissions for DynamoDB access is returned.
     */
    createOrUpdateOperationLambda(
        depositTableName: string,
        withdrawalTableName: string,
        chainstateTableName: string,
        limitTableName: string,
        throttleTableName: string,
        removalPolicy: cdk.RemovalPolicy,
        props: EmilyStackProps,
    ): lambda.Function {

        const operationLambdaId: string = "OperationLambda";
        const operationLambda: lambda.Function = new lambda.Function(this, operationLambdaId, {
            functionName: EmilyStackUtils.getResourceName(operationLambdaId, props),
            architecture: lambda.Architecture.X86_64,
            runtime: lambda.Runtime.PROVIDED_AL2023,
            code: lambda.Code.fromAsset(EmilyStackUtils.getPathFromProjectRoot(
                props.stageName === Constants.UNIT_TEST_STAGE_NAME
                    ? "emily/cdk/test/assets/empty-lambda.zip"
                    : "target/lambda/emily-lambda/bootstrap.zip"
            )),
            // Lambda should be very fast. Something is wrong if it takes > 5 seconds.
            timeout: cdk.Duration.seconds(5),
            handler: "main",
            environment: {
                // Give lambda access to the table name.
                DEPOSIT_TABLE_NAME: depositTableName,
                WITHDRAWAL_TABLE_NAME: withdrawalTableName,
                CHAINSTATE_TABLE_NAME: chainstateTableName,
                LIMIT_TABLE_NAME: limitTableName,
                THROTTLEDOWN_TABLE_NAME: throttleTableName,
                // Declare an environment variable that will be overwritten in local SAM
                // deployments the AWS stack. SAM can only set environment variables that are
                // already expected to be present in the lambda.
                IS_LOCAL: "false",
                IS_MAINNET: props.stageName == Constants.PROD_STAGE_NAME || props.stageName == Constants.PRIVATE_MAINNET_STAGE_NAME ? "true" : "false",
                VERSION: EmilyStackUtils.getLambdaGitIdentifier(),
                DEPLOYER_ADDRESS: props.deployerAddress,
            },
            description: `Emily Api Handler. ${EmilyStackUtils.getLambdaGitIdentifier()}`,
            currentVersionOptions: {
                removalPolicy,
            }
        });

        // Return lambda resource.
        return operationLambda;
    }

    /**
     * Creates or updates the API Gateway to connect with the Lambda function.
     * @param {lambda.Alias} operationLambda The Lambda function to connect to the API.
     * @param {s3.IBucket} sanctionsBucket The sanctions S3 bucket.
     * @param {EmilyStackProps} props The stack properties.
     * @returns {apig.SpecRestApi[]} The created or updated API Gateways.
     * @post API Gateways with execute permissions linked to the Lambda function are returned.
     */
    createOrUpdateApi(
        operationLambda: lambda.Alias,
        sanctionsBucket: s3.IBucket,
        props: EmilyStackProps
    ): apig.SpecRestApi[] {

        let apisToCreate = [
            {
                purpose: "public",
                numApiKeys: EmilyStackUtils.getNumSignerApiKeys(),
            },
            {
                purpose: "private",
                numApiKeys: 1,
            },
        ];
        // Add testing api if it's a development stack.
        if (EmilyStackUtils.isDevelopmentStack()) {
            apisToCreate.push({
                purpose: "testing",
                numApiKeys: 3,
            });
        }
        // Create all the apis.
        return apisToCreate
            .map((apiToCreate) => this.createOrUpdateSpecificApi(
                operationLambda,
                apiToCreate.numApiKeys,
                apiToCreate.purpose as "public" | "private" | "testing",
                sanctionsBucket,
                props
            ));
    }

    /**
     * Creates or updates a specific API Gateway to connect with the Lambda function.
     * @param {lambda.Alias} operationLambda The Lambda function to connect to the API.
     * @param {number} numApiKeys The number of API keys to create for the API.
     * @param {string} apiPurpose The purpose of the API.
     * @param {s3.IBucket} sanctionsBucket The sanctions S3 bucket.
     * @param {EmilyStackProps} props The stack properties.
     * @returns {apig.SpecRestApi} The created or updated API Gateway.
     * @post An API Gateway with execute permissions linked to the Lambda function is returned.
     */
    createOrUpdateSpecificApi(
        operationLambda: lambda.Alias,
        numApiKeys: number,
        apiPurpose: "public" | "private" | "testing",
        sanctionsBucket: s3.IBucket,
        props: EmilyStackProps,
    ): apig.SpecRestApi {
        const apiPurposeTitleCase = apiPurpose.charAt(0).toUpperCase() + apiPurpose.slice(1);
        const apiPurposeResourceIdSuffix = apiPurpose === "public" ? "" : `-${apiPurposeTitleCase}`;

        const apiId: string = `EmilyAPI${apiPurposeResourceIdSuffix}`;
        const api: apig.SpecRestApi = new apig.SpecRestApi(this, apiId, {
            restApiName: EmilyStackUtils.getResourceName(apiId, props),
            apiDefinition: EmilyStackUtils.restApiDefinitionWithLambdaIntegration(
                EmilyStackUtils.getPathFromProjectRoot(
                    `emily/openapi-gen/generated-specs/${apiPurpose}-emily-openapi-spec.json`
                ),
                [
                    // This must match the Lambda name from the @aws.apigateway#integration trait in the
                    // smithy operations and resources that should be handled by this Lambda.
                    ["OperationLambda", operationLambda]
                ],
            ),
            deployOptions: { stageName: props.stageName },
        });

        // Create a usage plan that will be used by the Signers. This will allow us to throttle
        // the general API more than the signers.
        const apiUsagePlanId: string = `SignerApiUsagePlan${apiPurposeResourceIdSuffix}`;
        const apiUsagePlan = api.addUsagePlan(apiUsagePlanId, {
            name: EmilyStackUtils.getResourceName(apiUsagePlanId, props),
            throttle: {
                // These are very high limits. We can adjust them down as needed.
                rateLimit: 100,
                burstLimit: 200,
            },
            apiStages: [
                {
                    api: api,
                    stage: api.deploymentStage,
                }
            ]
        });

        let api_keys = [];
        for (let i = 0; i < numApiKeys; i++) {
            // Create an API Key
            const apiKeyId: string = `ApiKey${apiPurposeResourceIdSuffix}-${i}`;
            const apiKey = api.addApiKey(apiKeyId, {
                apiKeyName: EmilyStackUtils.getResourceName(apiKeyId, props),
            });

            // Associate the API Key with the Usage Plan and specify stages
            apiUsagePlan.addApiKey(apiKey);
            api_keys.push(apiKey);
        }

        // Give the rest api execute ARN permission to invoke the lambda.
        const apiInvokeLambdaPermissionId: string = `ApiInvokeLambdaPermission${apiPurposeResourceIdSuffix}`;
        operationLambda.addPermission(apiInvokeLambdaPermissionId, {
            principal: new iam.ServicePrincipal("apigateway.amazonaws.com"),
            action: "lambda:InvokeFunction",
            sourceArn: api.arnForExecuteApi(),
        });

        // Add the sanctions list to the API.
        this.addSanctionsRoute(api, sanctionsBucket, apiPurposeResourceIdSuffix);

        // Only add the custom domain name it's specified.
        let customRootDomainNameRoot = EmilyStackUtils.getCustomRootDomainName();
        let hostedZoneId = EmilyStackUtils.getHostedZoneId();
        if (customRootDomainNameRoot !== undefined) {
            // Error if the hosted zone ID is not provided.
            if (hostedZoneId === undefined) {
                throw new Error("Custom domain name specified but hosted zone ID not provided.");
            }

            // Create the custom domain name of the format:
            //   if stage != prod: [purpose].[stage].[customRootDomainNameRoot]
            //   if stage == prod: [purpose].[customRootDomainNameRoot]
            const stagePrefix = EmilyStackUtils.getStageName() === Constants.PROD_STAGE_NAME
                ? ""
                : `${EmilyStackUtils.getStageName()}.`;
            const purposePrefix = apiPurpose != "public" ? `${apiPurpose}.` : "";
            const customDomainName = `${purposePrefix}${stagePrefix}${customRootDomainNameRoot}`;

            // Get zone.
            const hostedZoneResourceId = `HostedZone${apiPurposeResourceIdSuffix}`;
            const hostedZone = route53.HostedZone.fromHostedZoneAttributes(this, hostedZoneResourceId, {
                hostedZoneId: hostedZoneId,
                zoneName: customDomainName,
            });

            // Get certificate.
            const DomainCertificateId = `DomainCertificate${apiPurposeResourceIdSuffix}`;
            const certificate = new certificatemanager.Certificate(this, DomainCertificateId, {
                domainName: customDomainName,
                validation: certificatemanager.CertificateValidation.fromDns(hostedZone),
            });

            // Create a custom domain.
            let customDomainId = `CustomDomain${apiPurposeResourceIdSuffix}`;
            const customDomain = new apig.DomainName(this, customDomainId, {
                domainName: customDomainName,
                certificate: certificate,
                // If the endpoint is in us-east-1 then we'll use EDGE because it's a better faster
                // option globally. If the stack is in any region other than us-east-1 you'll need
                // to make the certificate in us-east-1 independently and then reference it here if you
                // want to use the EDGE endpoint type. That's a big pain and simply not worth it,
                // especially if we only deploy "prod" in us-east-1.
                endpointType: this.region == 'us-east-1' && !EmilyStackUtils.isDevelopmentStack()
                    ? apig.EndpointType.EDGE
                    : apig.EndpointType.REGIONAL,
            });

            // Map custom domain to API Gateway
            let basePathMappingId = `BasePathMapping${apiPurposeResourceIdSuffix}`;
            new apig.BasePathMapping(this, basePathMappingId, {
                domainName: customDomain,
                restApi: api,
                stage: api.deploymentStage,
            });

            // Create a Route 53 alias record
            let aliasRecordId = `AliasRecord${apiPurposeResourceIdSuffix}`;
            new route53.ARecord(this, aliasRecordId, {
                zone: hostedZone,
                target: route53.RecordTarget.fromAlias(new route53Targets.ApiGatewayDomain(customDomain)),
            });
        }

        // Return api resource.
        return api;
    }

    /**
     * Wires `GET /sanctions` on the API Gateway to fetch a single object from
     * the sanctions bucket via an AWS service integration.
     * @param {apig.SpecRestApi} api The API Gateway.
     * @param {s3.IBucket} sanctionsBucket The sanctions S3 bucket.
     * @param {string} apiPurposeResourceIdSuffix The resource suffix.
     * @post The method is added to the API Gateway.
     */
    addSanctionsRoute(
        api: apig.SpecRestApi,
        sanctionsBucket: s3.IBucket,
        apiPurposeResourceIdSuffix: string,
    ): void {
        // Dedicated role assumed by API Gateway to read the sanctions object.
        const integrationRoleId = `SanctionsIntegrationRole${apiPurposeResourceIdSuffix}`;
        const integrationRole = new iam.Role(this, integrationRoleId, {
            assumedBy: new iam.ServicePrincipal('apigateway.amazonaws.com'),
        });
        sanctionsBucket.grantRead(integrationRole, Constants.SANCTIONS_OBJECT_KEY);

        const integration = new apig.AwsIntegration({
            service: 's3',
            integrationHttpMethod: 'GET',
            // `path` is interpreted as `{bucket}/{key}` for the S3 service.
            path: `${sanctionsBucket.bucketName}/${Constants.SANCTIONS_OBJECT_KEY}`,
            options: {
                credentialsRole: integrationRole,
                // Pass the upstream Content-Type through and surface S3 error
                // statuses as 404/500 instead of the default 200.
                integrationResponses: [
                    {
                        statusCode: '200',
                        responseParameters: {
                            'method.response.header.Content-Type':
                                'integration.response.header.Content-Type',
                        },
                    },
                    {
                        statusCode: '404',
                        selectionPattern: '4\\d{2}',
                    },
                    {
                        statusCode: '500',
                        selectionPattern: '5\\d{2}',
                    },
                ],
            },
        });

        const sanctionsResource = api.root.addResource('sanctions');
        sanctionsResource.addMethod('GET', integration, {
            apiKeyRequired: true,
            methodResponses: [
                {
                    statusCode: '200',
                    responseParameters: {
                        'method.response.header.Content-Type': true,
                    },
                },
                { statusCode: '404' },
                { statusCode: '500' },
            ],
        });
    }
}
