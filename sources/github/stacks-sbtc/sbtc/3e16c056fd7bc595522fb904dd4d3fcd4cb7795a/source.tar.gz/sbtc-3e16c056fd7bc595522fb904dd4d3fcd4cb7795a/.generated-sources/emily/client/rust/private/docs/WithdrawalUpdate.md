# WithdrawalUpdate

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**expected_fulfillment_info** | Option<[**models::ExpectedFulfillmentInfo**](ExpectedFulfillmentInfo.md)> |  | [optional]
**fulfillment** | Option<[**models::Fulfillment**](Fulfillment.md)> |  | [optional]
**request_id** | **u64** | The id of the Stacks withdrawal request that initiated the sBTC operation. | 
**status** | [**models::WithdrawalStatus**](WithdrawalStatus.md) |  | 
**status_message** | **String** | The status message of the withdrawal. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


