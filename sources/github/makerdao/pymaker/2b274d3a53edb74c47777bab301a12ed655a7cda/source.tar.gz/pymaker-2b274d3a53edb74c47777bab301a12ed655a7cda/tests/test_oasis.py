# This file is part of Maker Keeper Framework.
#
# Copyright (C) 2017-2018 reverendus
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU Affero General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU Affero General Public License for more details.
#
# You should have received a copy of the GNU Affero General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
from typing import List
from unittest.mock import Mock

import logging
import pytest
import time
from web3 import HTTPProvider
from web3 import Web3

from pymaker import Address, Wad, Contract, Transact
from pymaker.approval import directly
from pymaker.oasis import SimpleMarket, MatchingMarket, Order
from pymaker.token import DSToken
from pymaker.model import Token
from tests.helpers import wait_until_mock_called, is_hashable

PAST_BLOCKS = 100


class OasisMockPriceOracle(Contract):
    """A mock price Oracle for deploying Oasis MatchingMarket contract"""

    abi = Contract._load_abi(__name__, 'abi/OasisMockPriceOracle.abi')
    bin = Contract._load_bin(__name__, 'abi/OasisMockPriceOracle.bin')

    def __init__(self, web3: Web3, address: Address):
        assert(isinstance(web3, Web3))
        assert(isinstance(address, Address))

        self.web3 = web3
        self.address = address
        self._contract = self._get_contract(web3, self.abi, address)

    @staticmethod
    def deploy(web3: Web3):
        return OasisMockPriceOracle(web3=web3, address=Contract._deploy(web3, OasisMockPriceOracle.abi,
                                                                        OasisMockPriceOracle.bin, []))

    def set_price(self, price: Wad):
        assert isinstance(price, Wad)
        return Transact(self, self.web3, self.abi, self.address, self._contract, 'setPrice', [price.value])

    def __eq__(self, other):
        return self.address == other.address

    def __repr__(self):
        return f"OasisMockPriceOracle('{self.address}')"


class GeneralMarketTest:
    def setup_method(self):
        # reduce logspew
        logging.getLogger("web3").setLevel(logging.INFO)
        logging.getLogger("urllib3").setLevel(logging.INFO)
        logging.getLogger("asyncio").setLevel(logging.INFO)

        self.web3 = Web3(HTTPProvider("http://localhost:8555"))
        self.web3.eth.defaultAccount = self.web3.eth.accounts[0]
        self.our_address = Address(self.web3.eth.defaultAccount)

        self.price_oracle = OasisMockPriceOracle.deploy(self.web3)
        self.price_oracle.set_price(Wad.from_number(10))

        self.token1 = DSToken.deploy(self.web3, 'AAA')
        self.token1_tokenclass = Token('AAA', self.token1.address, 18)
        self.token1.mint(Wad.from_number(10000)).transact()
        self.token2 = DSToken.deploy(self.web3, 'BBB')
        self.token2_tokenclass = Token('BBB', self.token2.address, 18)
        self.token2.mint(Wad.from_number(10000)).transact()
        self.token3 = DSToken.deploy(self.web3, 'CCC')
        self.token3_tokenclass = Token('CCC', self.token3.address, 18)
        self.token3.mint(Wad.from_number(10000)).transact()
        self.otc = None

    def test_approve_and_make_and_getters(self):

        if isinstance(self.otc, MatchingMarket):
            pay_val = self.token1_tokenclass
            buy_val = self.token2_tokenclass
        else:
            pay_val = self.token1.address
            buy_val = self.token2.address

        # given
        assert self.otc.get_last_order_id() == 0

        # when
        self.otc.approve([self.token1], directly())
        self.otc.make(pay_val, Wad.from_number(1),
                      buy_val, Wad.from_number(2)).transact()

        # then
        assert self.otc.get_last_order_id() == 1

        # and
        assert self.otc.get_order(1).order_id == 1
        assert self.otc.get_order(1).pay_token == self.token1.address
        assert self.otc.get_order(1).pay_amount == Wad.from_number(1)
        assert self.otc.get_order(1).buy_token == self.token2.address
        assert self.otc.get_order(1).buy_amount == Wad.from_number(2)
        assert self.otc.get_order(1).maker == self.our_address
        assert self.otc.get_order(1).timestamp != 0

        # and
        assert self.otc.get_orders() == [self.otc.get_order(1)]

    def test_make_returns_new_order_ids(self):

        if isinstance(self.otc, MatchingMarket):
            pay_val = self.token1_tokenclass
            buy_val = self.token2_tokenclass
        else:
            pay_val = self.token1.address
            buy_val = self.token2.address

        # given
        self.otc.approve([self.token1], directly())

        # expect
        for number in range(1, 10):
            receipt = self.otc.make(pay_val, Wad.from_number(1),
                                    buy_val, Wad.from_number(2)).transact()

            assert receipt.result == number
            assert self.otc.get_last_order_id() == number

    def test_get_orders_by_pair(self):

        if isinstance(self.otc, MatchingMarket):
            token1_val = self.token1_tokenclass
            token2_val = self.token2_tokenclass
            token3_val = self.token3_tokenclass

        else:
            token1_val = self.token1.address
            token2_val = self.token2.address
            token3_val = self.token3.address


        # given
        self.otc.approve([self.token1, self.token2, self.token3], directly())

        # when
        self.otc.make(token1_val, Wad.from_number(1),
                      token2_val, Wad.from_number(2)).transact()

        self.otc.make(token1_val, Wad.from_number(1),
                      token2_val, Wad.from_number(4)).transact()

        self.otc.make(token1_val, Wad.from_number(1),
                      token2_val, Wad.from_number(3)).transact()

        self.otc.make(token1_val, Wad.from_number(1),
                      token3_val, Wad.from_number(2)).transact()

        self.otc.make(token1_val, Wad.from_number(1),
                      token3_val, Wad.from_number(4)).transact()

        self.otc.make(token1_val, Wad.from_number(1),
                      token3_val, Wad.from_number(3)).transact()

        self.otc.make(token2_val, Wad.from_number(1),
                      token3_val, Wad.from_number(2)).transact()

        self.otc.make(token2_val, Wad.from_number(1),
                      token3_val, Wad.from_number(4)).transact()

        self.otc.make(token2_val, Wad.from_number(1),
                      token3_val, Wad.from_number(3)).transact()

        self.otc.make(token2_val, Wad.from_number(1),
                      token1_val, Wad.from_number(5)).transact()

        self.otc.make(token2_val, Wad.from_number(1),
                      token1_val, Wad.from_number(6)).transact()

        # then
        def order_ids(orders: List[Order]) -> List[int]:
            return list(map(lambda order: order.order_id, orders))

        assert len(self.otc.get_orders()) == 11
        assert order_ids(self.otc.get_orders(token1_val, token2_val)) == [1, 2, 3]
        assert order_ids(self.otc.get_orders(token1_val, token3_val)) == [4, 5, 6]
        assert order_ids(self.otc.get_orders(token2_val, token3_val)) == [7, 8, 9]
        assert order_ids(self.otc.get_orders(token2_val, token1_val)) == [10, 11]

        # when
        self.otc.kill(8).transact()

        # then
        assert order_ids(self.otc.get_orders(token2_val, token3_val)) == [7, 9]

    def test_get_orders_by_maker(self):

        if isinstance(self.otc, MatchingMarket):
            token1_val = self.token1_tokenclass
            token2_val = self.token2_tokenclass

        else:
            token1_val = self.token1.address
            token2_val = self.token2.address

        # given
        maker1 = self.our_address
        maker2 = Address(self.web3.eth.accounts[1])

        # and
        self.token1.transfer(maker2, Wad.from_number(500)).transact()

        # when
        self.otc.approve([self.token1], directly())
        self.otc.make(token1_val, Wad.from_number(1),
                      token2_val, Wad.from_number(2)).transact()

        # and
        self.web3.eth.defaultAccount = self.web3.eth.accounts[1]
        self.otc.approve([self.token1], directly())
        self.otc.make(token1_val, Wad.from_number(1),
                      token2_val, Wad.from_number(2)).transact()
        self.web3.eth.defaultAccount = self.web3.eth.accounts[0]

        # then
        assert len(self.otc.get_orders()) == 2
        assert len(self.otc.get_orders_by_maker(maker1)) == 1
        assert len(self.otc.get_orders_by_maker(maker2)) == 1

        # and
        assert self.otc.get_orders_by_maker(maker1)[0].maker == maker1
        assert self.otc.get_orders_by_maker(maker2)[0].maker == maker2

    def test_order_comparison(self):


        if isinstance(self.otc, MatchingMarket):
            token1_val = self.token1_tokenclass
            token2_val = self.token2_tokenclass

        else:
            token1_val = self.token1.address
            token2_val = self.token2.address

        # when
        self.otc.approve([self.token1], directly())
        self.otc.make(token1_val, Wad.from_number(1),
                      token2_val, Wad.from_number(2)).transact()

        # and
        self.otc.make(token1_val, Wad.from_number(3),
                      token2_val, Wad.from_number(4)).transact()

        # then
        assert self.otc.get_last_order_id() == 2
        assert self.otc.get_order(1) == self.otc.get_order(1)
        assert self.otc.get_order(1) != self.otc.get_order(2)

    def test_order_hashable(self):

        if isinstance(self.otc, MatchingMarket):
            pay_val = self.token1_tokenclass
            buy_val = self.token2_tokenclass
        else:
            pay_val = self.token1.address
            buy_val = self.token2.address

        # given
        self.otc.approve([self.token1], directly())
        self.otc.make(pay_val, Wad.from_number(1),
                      buy_val, Wad.from_number(2)).transact()

        # expect
        assert is_hashable(self.otc.get_order(1))

    def test_take_partial(self):

        if isinstance(self.otc, MatchingMarket):
            pay_val = self.token1_tokenclass
            buy_val = self.token2_tokenclass
        else:
            pay_val = self.token1.address
            buy_val = self.token2.address

        # given
        self.otc.approve([self.token1], directly())
        self.otc.make(pay_val, Wad.from_number(1),
                      buy_val, Wad.from_number(2)).transact()

        # when
        self.otc.approve([self.token2], directly())
        self.otc.take(1, Wad.from_number(0.25)).transact()

        # then
        assert self.otc.get_order(1).pay_amount == Wad.from_number(0.75)
        assert self.otc.get_order(1).buy_amount == Wad.from_number(1.5)
        assert self.otc.get_orders() == [self.otc.get_order(1)]
        assert self.otc.get_last_order_id() == 1

    def test_remaining_sell_and_buy_amounts(self):

        if isinstance(self.otc, MatchingMarket):
            pay_val = self.token1_tokenclass
            buy_val = self.token2_tokenclass
        else:
            pay_val = self.token1.address
            buy_val = self.token2.address

        # given
        self.otc.approve([self.token1], directly())
        self.otc.make(pay_val, Wad.from_number(1),
                      buy_val, Wad.from_number(2)).transact()

        # and
        assert self.otc.get_order(1).remaining_sell_amount == Wad.from_number(1)
        assert self.otc.get_order(1).remaining_buy_amount == Wad.from_number(2)

        # when
        self.otc.approve([self.token2], directly())
        self.otc.take(1, Wad.from_number(0.25)).transact()

        # then
        assert self.otc.get_order(1).remaining_sell_amount == Wad.from_number(0.75)
        assert self.otc.get_order(1).remaining_buy_amount == Wad.from_number(1.5)

    def test_take_complete(self):

        if isinstance(self.otc, MatchingMarket):
            pay_val = self.token1_tokenclass
            buy_val = self.token2_tokenclass
        else:
            pay_val = self.token1.address
            buy_val = self.token2.address

        # given
        self.otc.approve([self.token1], directly())
        self.otc.make(pay_val, Wad.from_number(1),
                      buy_val, Wad.from_number(2)).transact()

        # when
        self.otc.approve([self.token2], directly())
        self.otc.take(1, Wad.from_number(1)).transact()

        # then
        assert self.otc.get_order(1) is None
        assert self.otc.get_orders() == []
        assert self.otc.get_last_order_id() == 1

    def test_kill(self):

        if isinstance(self.otc, MatchingMarket):
            pay_val = self.token1_tokenclass
            buy_val = self.token2_tokenclass
        else:
            pay_val = self.token1.address
            buy_val = self.token2.address

        # given
        self.otc.approve([self.token1], directly())
        self.otc.make(pay_val, Wad.from_number(1),
                      buy_val, Wad.from_number(2)).transact()

        # when
        self.otc.kill(1).transact(gas=4000000)

        # then
        assert self.otc.get_order(1) is None
        assert self.otc.get_orders() == []
        assert self.otc.get_last_order_id() == 1

    def test_no_past_events_on_startup(self):
        assert self.otc.past_make(PAST_BLOCKS) == []
        assert self.otc.past_bump(PAST_BLOCKS) == []
        assert self.otc.past_take(PAST_BLOCKS) == []
        assert self.otc.past_kill(PAST_BLOCKS) == []

    def test_past_make(self):

        if isinstance(self.otc, MatchingMarket):
            pay_val = self.token1_tokenclass
            buy_val = self.token2_tokenclass
        else:
            pay_val = self.token1.address
            buy_val = self.token2.address

        # when
        self.otc.approve([self.token1], directly())
        self.otc.make(pay_val, Wad.from_number(1),
                      buy_val, Wad.from_number(2)).transact()

        # then
        past_make = self.otc.past_make(PAST_BLOCKS)
        assert len(past_make) == 1
        assert past_make[0].order_id == 1
        assert past_make[0].maker == self.our_address
        assert past_make[0].pay_token == self.token1.address
        assert past_make[0].pay_amount == Wad.from_number(1)
        assert past_make[0].buy_token == self.token2.address
        assert past_make[0].buy_amount == Wad.from_number(2)
        assert past_make[0].timestamp != 0
        assert past_make[0].raw['blockNumber'] > 0

    def test_past_bump(self):

        if isinstance(self.otc, MatchingMarket):
            pay_val = self.token1_tokenclass
            buy_val = self.token2_tokenclass
        else:
            pay_val = self.token1.address
            buy_val = self.token2.address

        # when
        self.otc.approve([self.token1], directly())
        self.otc.make(pay_val, Wad.from_number(1),
                      buy_val, Wad.from_number(2)).transact()
        self.otc.bump(1).transact()

        # then
        past_bump = self.otc.past_bump(PAST_BLOCKS)
        assert len(past_bump) == 1
        assert past_bump[0].order_id == 1
        assert past_bump[0].maker == self.our_address
        assert past_bump[0].pay_token == self.token1.address
        assert past_bump[0].pay_amount == Wad.from_number(1)
        assert past_bump[0].buy_token == self.token2.address
        assert past_bump[0].buy_amount == Wad.from_number(2)
        assert past_bump[0].timestamp != 0
        assert past_bump[0].raw['blockNumber'] > 0

    def test_past_take(self):

        if isinstance(self.otc, MatchingMarket):
            pay_val = self.token1_tokenclass
            buy_val = self.token2_tokenclass
        else:
            pay_val = self.token1.address
            buy_val = self.token2.address

        # when
        self.otc.approve([self.token1], directly())
        self.otc.make(pay_val, Wad.from_number(1),
                      buy_val, Wad.from_number(2)).transact()

        # and
        self.otc.approve([self.token2], directly())
        self.otc.take(1, Wad.from_number(0.5)).transact()

        # then
        past_take = self.otc.past_take(PAST_BLOCKS)
        assert len(past_take) == 1
        assert past_take[0].order_id == 1
        assert past_take[0].maker == self.our_address
        assert past_take[0].taker == self.our_address
        assert past_take[0].pay_token == self.token1.address
        assert past_take[0].buy_token == self.token2.address
        assert past_take[0].take_amount == Wad.from_number(0.5)
        assert past_take[0].give_amount == Wad.from_number(1)
        assert past_take[0].timestamp != 0
        assert past_take[0].raw['blockNumber'] > 0

    def test_past_take_with_filter(self):

        if isinstance(self.otc, MatchingMarket):
            pay_val = self.token1_tokenclass
            buy_val = self.token2_tokenclass
        else:
            pay_val = self.token1.address
            buy_val = self.token2.address

        # when
        self.otc.approve([self.token1], directly())
        self.otc.make(pay_val, Wad.from_number(1),
                      buy_val, Wad.from_number(2)).transact()

        # and
        self.otc.approve([self.token2], directly())
        self.otc.take(1, Wad.from_number(0.5)).transact()

        # then
        assert len(self.otc.past_take(PAST_BLOCKS, {'maker': self.our_address.address})) == 1
        assert len(self.otc.past_take(PAST_BLOCKS, {'taker': self.our_address.address})) == 1
        assert len(self.otc.past_take(PAST_BLOCKS, {'maker': '0x0101010101020202020203030303030404040404'})) == 0
        assert len(self.otc.past_take(PAST_BLOCKS, {'taker': '0x0101010101020202020203030303030404040404'})) == 0

    def test_past_kill(self):

        if isinstance(self.otc, MatchingMarket):
            pay_val = self.token1_tokenclass
            buy_val = self.token2_tokenclass
        else:
            pay_val = self.token1.address
            buy_val = self.token2.address

        # when
        self.otc.approve([self.token1], directly())
        self.otc.make(pay_val, Wad.from_number(1),
                      buy_val, Wad.from_number(2)).transact()

        # and
        self.otc.kill(1).transact()

        # then
        past_kill = self.otc.past_kill(PAST_BLOCKS)
        assert len(past_kill) == 1
        assert past_kill[0].order_id == 1
        assert past_kill[0].maker == self.our_address
        assert past_kill[0].pay_token == self.token1.address
        assert past_kill[0].pay_amount == Wad.from_number(1)
        assert past_kill[0].buy_token == self.token2.address
        assert past_kill[0].buy_amount == Wad.from_number(2)
        assert past_kill[0].timestamp != 0
        assert past_kill[0].raw['blockNumber'] > 0


class TestSimpleMarket(GeneralMarketTest):
    def setup_method(self):
        GeneralMarketTest.setup_method(self)
        self.otc = SimpleMarket.deploy(self.web3)

    def test_fail_when_no_contract_under_that_address(self):
        # expect
        with pytest.raises(Exception):
            SimpleMarket(web3=self.web3, address=Address('0xdeadadd1e5500000000000000000000000000000'))

    def test_should_have_printable_representation(self):
        assert repr(self.otc) == f"SimpleMarket('{self.otc.address}')"


class TestMatchingMarket(GeneralMarketTest):
    def setup_method(self):
        GeneralMarketTest.setup_method(self)
        self.otc = MatchingMarket.deploy(self.web3, self.token1.address, Wad(0), self.price_oracle.address)
        self.otc.add_token_pair_whitelist(self.token1.address, self.token2.address).transact()
        self.otc.add_token_pair_whitelist(self.token1.address, self.token3.address).transact()
        self.otc.add_token_pair_whitelist(self.token2.address, self.token3.address).transact()

    def test_fail_when_no_contract_under_that_address(self):
        # expect
        with pytest.raises(Exception):
            MatchingMarket(web3=self.web3, address=Address('0xdeadadd1e5500000000000000000000000000000'))

    def test_simple_matching(self):

        # given
        self.otc.approve([self.token1, self.token2], directly())
        self.otc.make(p_token=self.token1_tokenclass, pay_amount=Wad.from_number(1),
                      b_token=self.token2_tokenclass, buy_amount=Wad.from_number(2)).transact()

        # when
        self.otc.make(p_token=self.token2_tokenclass, pay_amount=Wad.from_number(2.5),
                      b_token=self.token1_tokenclass, buy_amount=Wad.from_number(1)).transact()

        # then
        assert self.otc.get_order(1) is None
        assert self.otc.get_order(2) is None

        # and
        assert self.otc.get_last_order_id() == 1

    def test_advanced_matching(self):
        # given
        self.otc.approve([self.token1, self.token2], directly())
        self.otc.make(p_token=self.token1_tokenclass, pay_amount=Wad.from_number(1),
                      b_token=self.token2_tokenclass, buy_amount=Wad.from_number(2)).transact()
        self.otc.make(p_token=self.token1_tokenclass, pay_amount=Wad.from_number(1),
                      b_token=self.token2_tokenclass, buy_amount=Wad.from_number(2.2)).transact()
        self.otc.make(p_token=self.token1_tokenclass, pay_amount=Wad.from_number(1),
                      b_token=self.token2_tokenclass, buy_amount=Wad.from_number(1.8)).transact()
        self.otc.make(p_token=self.token1_tokenclass, pay_amount=Wad.from_number(1),
                      b_token=self.token2_tokenclass, buy_amount=Wad.from_number(2.1)).transact()
        self.otc.make(p_token=self.token1_tokenclass, pay_amount=Wad.from_number(1),
                      b_token=self.token2_tokenclass, buy_amount=Wad.from_number(1.9)).transact()

        # when
        self.otc.make(p_token=self.token2_tokenclass, pay_amount=Wad.from_number(20.1),
                      b_token=self.token1_tokenclass, buy_amount=Wad.from_number(10)).transact(gas=4000000)

        # then
        assert self.otc.get_order(1) is None
        assert self.otc.get_order(2) is not None
        assert self.otc.get_order(3) is None
        assert self.otc.get_order(4) is not None
        assert self.otc.get_order(5) is None

        # and
        assert self.otc.get_last_order_id() == 6

        # and
        assert self.otc.get_order(6).order_id == 6
        assert self.otc.get_order(6).pay_token == self.token2.address
        assert self.otc.get_order(6).pay_amount == Wad.from_number(14.07)
        assert self.otc.get_order(6).buy_token == self.token1.address
        assert self.otc.get_order(6).buy_amount == Wad.from_number(7)
        assert self.otc.get_order(6).maker == self.our_address
        assert self.otc.get_order(6).timestamp != 0

    def test_should_have_printable_representation(self):
        assert repr(self.otc) == f"MatchingMarket('{self.otc.address}')"


class TestMatchingMarketWithSupportContract(TestMatchingMarket):
    def setup_method(self):
        GeneralMarketTest.setup_method(self)

        support_abi = Contract._load_abi(__name__, '../pymaker/abi/MakerOtcSupportMethods.abi')
        support_bin = Contract._load_bin(__name__, '../pymaker/abi/MakerOtcSupportMethods.bin')
        support_address = Contract._deploy(self.web3, support_abi, support_bin, [])

        self.price_oracle = OasisMockPriceOracle.deploy(self.web3)
        self.otc = MatchingMarket.deploy(self.web3, self.token1.address, Wad(0), self.price_oracle.address, support_address)
        self.otc.add_token_pair_whitelist(self.token1.address, self.token2.address).transact()
        self.otc.add_token_pair_whitelist(self.token1.address, self.token3.address).transact()
        self.otc.add_token_pair_whitelist(self.token2.address, self.token3.address).transact()

    def test_fail_when_no_support_contract_under_that_address(self):
        # expect
        with pytest.raises(Exception):
            MatchingMarket(web3=self.web3,
                           address=self.otc.address,
                           support_address=Address('0xdeadadd1e5500000000000000000000000000000'))


class TestMatchingMarketDecimal:
    def setup_method(self):
        self.web3 = Web3(HTTPProvider("http://localhost:8555"))
        self.web3.eth.defaultAccount = self.web3.eth.accounts[0]
        self.our_address = Address(self.web3.eth.defaultAccount)
        self.token1 = DSToken.deploy(self.web3, 'AAA')
        self.token1_tokenclass = Token('AAA', self.token1.address, 18)
        self.token1.mint(Wad.from_number(10000)).transact()
        self.token2 = DSToken.deploy(self.web3, 'BBB')
        self.token2_tokenclass = Token('BBB', self.token2.address, 6)
        self.token2.mint(Wad.from_number(10000)).transact()

        support_abi = Contract._load_abi(__name__, '../pymaker/abi/MakerOtcSupportMethods.abi')
        support_bin = Contract._load_bin(__name__, '../pymaker/abi/MakerOtcSupportMethods.bin')
        support_address = Contract._deploy(self.web3, support_abi, support_bin, [])

        price_oracle = OasisMockPriceOracle.deploy(self.web3)
        self.otc = MatchingMarket.deploy(self.web3, self.token1.address, Wad(0), price_oracle.address, support_address)
        self.otc.add_token_pair_whitelist(self.token1.address, self.token2.address).transact()
        self.otc.approve([self.token1, self.token2], directly())

    def test_get_orders(self):
        buy_amount_order1 = Wad.from_number(5.124988526145090209)
        pay_amount_order1 = Wad.from_number(5.024999999999999500)

        buy_amount_order2 = Wad.from_number(5.102550000000000000)
        pay_amount_order2 = Wad.from_number(5.000000000000000000)

        # given
        self.otc.make(p_token=self.token2_tokenclass, pay_amount=self.token2_tokenclass.unnormalize_amount(pay_amount_order1),
                      b_token=self.token1_tokenclass, buy_amount=buy_amount_order1).transact()

        self.otc.make(p_token=self.token1_tokenclass, pay_amount=pay_amount_order2,
                      b_token=self.token2_tokenclass, buy_amount=self.token2_tokenclass.unnormalize_amount(buy_amount_order2)).transact()

        # then
        assert self.otc.get_orders(self.token1_tokenclass, self.token2_tokenclass)[0].buy_amount == buy_amount_order2
        assert self.token2_tokenclass.unnormalize_amount(self.otc.get_orders(self.token2_tokenclass, self.token1_tokenclass)[0].pay_amount) == self.token2_tokenclass.unnormalize_amount(pay_amount_order1)

class TestMatchingMarketPosition:
    def setup_method(self):
        self.web3 = Web3(HTTPProvider("http://localhost:8555"))
        self.web3.eth.defaultAccount = self.web3.eth.accounts[0]
        self.our_address = Address(self.web3.eth.defaultAccount)
        self.token1 = DSToken.deploy(self.web3, 'AAA')
        self.token1.mint(Wad.from_number(10000)).transact()
        self.token1_tokenclass = Token('AAA', self.token1.address, 18)
        self.token2 = DSToken.deploy(self.web3, 'BBB')
        self.token2.mint(Wad.from_number(10000)).transact()
        self.token2_tokenclass = Token('BBB', self.token2.address, 18)
        price_oracle = OasisMockPriceOracle.deploy(self.web3)
        self.otc = MatchingMarket.deploy(self.web3, self.token1.address, Wad(0), price_oracle.address)
        self.otc.add_token_pair_whitelist(self.token1.address, self.token2.address).transact()
        self.otc.approve([self.token1, self.token2], directly())
        for amount in [11,55,44,34,36,21,45,51,15]:
            self.otc.make(p_token=self.token1_tokenclass, pay_amount=Wad.from_number(1),
                          b_token=self.token2_tokenclass, buy_amount=Wad.from_number(amount)).transact()

    def test_should_calculate_correct_order_position(self):
        # expect
        assert self.otc.position(p_token=self.token1_tokenclass, pay_amount=Wad.from_number(1),
                                 b_token=self.token2_tokenclass, buy_amount=Wad.from_number(35)) == 4

    @pytest.mark.skip(reason="Works unreliably with ganache-cli")
    def test_should_use_correct_order_position_by_default(self):
        # when
        explicit_position = self.otc.position(p_token=self.token1_tokenclass, pay_amount=Wad.from_number(1),
                                              b_token=self.token2_tokenclass, buy_amount=Wad.from_number(35))
        explicit_receipt = self.otc.make(p_token=self.token1_tokenclass, pay_amount=Wad.from_number(1),
                                         b_token=self.token2_tokenclass, buy_amount=Wad.from_number(35),
                                         pos=explicit_position).transact()
        explicit_gas_used = explicit_receipt.gas_used

        # and
        self.setup_method()
        implicit_receipt = self.otc.make(p_token=self.token1_tokenclass, pay_amount=Wad.from_number(1),
                                         b_token=self.token2_tokenclass, buy_amount=Wad.from_number(35)).transact()
        implicit_gas_used = implicit_receipt.gas_used

        # then
        assert explicit_gas_used == implicit_gas_used

    @pytest.mark.skip(reason="Stopped working as expected after recent `maker-otc` upgrade")
    def test_calculated_order_position_should_bring_gas_savings(self):
        # when
        position = self.otc.position(p_token=self.token1_tokenclass, pay_amount=Wad.from_number(1),
                                     b_token=self.token2_tokenclass, buy_amount=Wad.from_number(35))
        gas_used_optimal = self.otc.make(p_token=self.token1_tokenclass, pay_amount=Wad.from_number(1),
                                         b_token=self.token2_tokenclass, buy_amount=Wad.from_number(35),
                                         pos=position).transact().gas_used

        # and
        self.setup_method()
        gas_used_minus_1 = self.otc.make(p_token=self.token1_tokenclass, pay_amount=Wad.from_number(1),
                                         b_token=self.token2_tokenclass, buy_amount=Wad.from_number(35),
                                         pos=position-1).transact().gas_used

        # and
        self.setup_method()
        gas_used_plus_1 = self.otc.make(p_token=self.token1_tokenclass, pay_amount=Wad.from_number(1),
                                        b_token=self.token2_tokenclass, buy_amount=Wad.from_number(35),
                                        pos=position+1).transact().gas_used

        # then
        assert gas_used_optimal < gas_used_minus_1
        assert gas_used_optimal < gas_used_plus_1
