Script outputs for Goerli.
