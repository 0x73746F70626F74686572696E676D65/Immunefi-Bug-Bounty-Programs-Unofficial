Script inputs for Goerli.
