//! Builder for the `FinalizeSettle` instruction.

use cow_settlement_interface::{
    data::intent::{Asset, OrderIntent},
    pda::{
        buffer::find_buffer_pda,
        order::find_order_pda,
        state::{STATE_PDA, STATE_PDA_AND_BUMP},
    },
    Instruction, Pubkey,
};

use super::begin_settle::TokenProgram;

/// A settled order whose proceeds are pushed to it: `intent` identifies the
/// order (its buy account is the push destination and its buy asset selects the
/// canonical source buffer) and `amount` is the quantity to push.
pub struct FinalizedIntent<'a> {
    pub intent: &'a OrderIntent,
    pub amount: u64,
}

/// Builder for a `FinalizeSettle` instruction pushing each order's proceeds to
/// its buy token account.
///
/// The destination is the order intent's buy account and the source is the
/// canonical buffer PDA for its buy mint (see [`find_buffer_pda`]), the only
/// buffer `BeginSettle` accepts as the source of that order's push. An order
/// buying [`Asset::Native`] SOL has no buffer, so its source is the settlement
/// state PDA, whose lamports pay it. The
/// orders are sorted by their canonical order PDA (the same key
/// [`BeginSettle`](super::begin_settle::BeginSettle) orders its settled-order
/// list by) so the two instructions present the orders
/// in the same order and their lists line up.
pub struct FinalizeSettle<'a> {
    pub program_id: Pubkey,
    pub begin_ix_index: u16,
    /// By default, a settlement support both token programs at the same time.
    /// If you know you only need a single token program, you can make the byte
    /// size of the settlement transaction a bit smaller and reduce the total
    /// accounts used in the transaction by specifying the
    /// only token program you need here.
    pub only_token_program: Option<TokenProgram>,
    pub orders: &'a [FinalizedIntent<'a>],
}

impl From<FinalizeSettle<'_>> for Instruction {
    fn from(builder: FinalizeSettle<'_>) -> Self {
        // Sort the orders by their canonical order PDA, the key `BeginSettle`
        // lays its settled orders out by, so the two instruction lists align.
        // For BeginSettle, sorting can take place in the interface. But the
        // order PDAs don't appear in the actual FinalizeSettle instruction, so
        // the sorting can only happen here.
        let num_orders = builder.orders.len();
        let mut orders: Vec<usize> = (0..num_orders).collect();
        orders.sort_by_key(|&i| {
            find_order_pda(&builder.program_id, &builder.orders[i].intent.uid()).0
        });

        let mut source_buffers: Vec<Pubkey> = Vec::with_capacity(num_orders);
        let mut destinations = Vec::with_capacity(num_orders);
        let mut bumps = Vec::with_capacity(num_orders);
        let mut amounts = Vec::with_capacity(num_orders);
        for &i in &orders {
            let intent = builder.orders[i].intent;
            let (source, bump, destination) = match &intent.buy {
                Asset::Native(account) => (STATE_PDA, STATE_PDA_AND_BUMP.1, *account),
                Asset::TokenProgram(token) => {
                    let (buffer, buffer_bump) = find_buffer_pda(&builder.program_id, &token.mint);
                    (buffer, buffer_bump, token.token_account)
                }
            };
            source_buffers.push(source);
            destinations.push(destination);
            bumps.push(bump);
            amounts.push(builder.orders[i].amount);
        }
        cow_settlement_interface::instruction::settle::FinalizeSettle {
            program_id: builder.program_id,
            state_pda: STATE_PDA,
            begin_ix_index: builder.begin_ix_index,
            only_token_program: builder.only_token_program,
            source_buffers: &source_buffers,
            destinations: &destinations,
            bumps: &bumps,
            amounts: &amounts,
        }
        .into()
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use ::proptest::{prelude::*, test_runner::TestCaseError};
    use cow_settlement_interface::{
        data::intent::fixtures::arb_order_intent,
        fixtures::pubkey_from_seed,
        instruction::{
            fixtures::fake_account_from_array,
            settle::{FinalizeSettleInput, Push, INSTRUCTIONS_SYSVAR_ID},
            InstructionInputParsing,
        },
    };

    #[test]
    fn native_sol_order_pushes_from_the_state_pda() {
        let program_id = pubkey_from_seed("program id");
        let recipient = pubkey_from_seed("recipient wallet");
        let intent = OrderIntent {
            buy: Asset::Native(recipient),
            ..OrderIntent::default()
        };
        let ix = Instruction::from(FinalizeSettle {
            program_id,
            begin_ix_index: 0,
            orders: &[FinalizedIntent {
                intent: &intent,
                amount: 1_337,
            }],
            only_token_program: None,
        });

        let accounts: Vec<_> = ix
            .accounts
            .iter()
            .map(|meta| fake_account_from_array(meta.pubkey.to_bytes()))
            .collect();
        let parsed = FinalizeSettleInput::parse(&ix.data, &accounts)
            .expect("the builder emits a parseable finalize");
        let pushes: Vec<_> = parsed.pushes.iter().collect();
        let [push] = pushes.as_slice() else {
            panic!("one order pushes once, got {} pushes", pushes.len());
        };

        assert_eq!(push.source_buffer.address(), &STATE_PDA);
        assert_eq!(push.bump, STATE_PDA_AND_BUMP.1);
        assert_eq!(push.destination.address(), &recipient);
        assert_eq!(push.amount, 1_337);
    }

    proptest! {
        // `FinalizeSettle` derives each order's source buffer from its buy mint
        // and destination from the intent, sorting by canonical order PDA like
        // `BeginSettle` so the on-chain parser recovers exactly those pushes in
        // that order.
        #[test]
        fn finalize_settle_derives_buffers_from_mints(
            begin_ix_index in any::<u16>(),
            cases in prop::collection::vec(
                (arb_order_intent(), any::<u64>()),
                1..=5,
            ),
        ) {
            let program_id = pubkey_from_seed("program id");
            let orders: Vec<FinalizedIntent> = cases
                .iter()
                .map(|(intent, amount)| FinalizedIntent {
                    intent,
                    amount: *amount,
                })
                .collect();
            let ix = Instruction::from(FinalizeSettle {
                program_id,
                begin_ix_index,
                only_token_program: None,
                orders: &orders,
            });

            // Expected pushes: each order's buffer PDA (and its canonical bump),
            // buy account, and amount, sorted by the order's canonical PDA
            // (the builder's order).
            struct ExpectedPush {
                order_pda: Pubkey,
                buffer: Pubkey,
                bump: u8,
                destination: Pubkey,
                amount: u64,
            }
            let mut expected: Vec<ExpectedPush> = orders
                .iter()
                .map(|order| {
                    let (order_pda, _bump) = find_order_pda(&program_id, &order.intent.uid());
                    let (buffer, bump, destination) = match &order.intent.buy {
                        Asset::Native(account) => {
                            (STATE_PDA, STATE_PDA_AND_BUMP.1, *account)
                        }
                        Asset::TokenProgram(token) => {
                            let (buffer, bump) = find_buffer_pda(&program_id, &token.mint);
                            (buffer, bump, token.token_account)
                        }
                    };
                    ExpectedPush {
                        order_pda,
                        buffer,
                        bump,
                        destination,
                        amount: order.amount,
                    }
                })
                .collect();
            expected.sort_by_key(|push| push.order_pda);

            let accounts: Vec<_> = ix
                .accounts
                .iter()
                .map(|meta| fake_account_from_array(meta.pubkey.to_bytes()))
                .collect();
            let parsed = FinalizeSettleInput::parse(&ix.data, &accounts)
                .map_err(|e| TestCaseError::fail(format!("parse failed: {e:?}")))?;

            prop_assert_eq!(parsed.begin_ix_index, begin_ix_index);
            prop_assert_eq!(
                parsed.instructions_sysvar_account.address(),
                &INSTRUCTIONS_SYSVAR_ID,
            );
            prop_assert_eq!(parsed.state_pda_account.address(), &STATE_PDA);

            let parsed_pushes: Vec<_> = parsed.pushes.iter().collect();
            prop_assert_eq!(parsed_pushes.len(), expected.len());
            for (push, expected) in parsed_pushes.iter().zip(&expected) {
                let Push {
                    source_buffer,
                    destination,
                    bump,
                    amount
                } = push;
                prop_assert_eq!(source_buffer.address(), &expected.buffer);
                prop_assert_eq!(destination.address(), &expected.destination);
                prop_assert_eq!(bump, &expected.bump);
                prop_assert_eq!(amount, &expected.amount);
            }
        }
    }
}
