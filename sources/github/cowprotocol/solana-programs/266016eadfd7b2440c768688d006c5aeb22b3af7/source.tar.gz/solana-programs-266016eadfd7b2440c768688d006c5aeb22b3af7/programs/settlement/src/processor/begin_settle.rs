//! `BeginSettle` instruction handler.

use std::ops::Deref;

use cow_settlement_interface::{
    data::{
        intent::{Asset, Flags, OrderKind},
        order::{FillAmounts, OrderAccount},
    },
    instruction::{
        settle::{
            finalize_push_data, BeginSettleInput, Push, SettledOrder, SettledOrders,
            FINALIZE_FIXED_ACCOUNTS,
        },
        InstructionInputParsing,
    },
    pda::{buffer::validate_buffer_pda, state::validate_is_state_pda},
    recover_discriminator, SettlementError, SettlementInstruction,
};
use pinocchio::{
    cpi::Signer,
    error::ProgramError,
    sysvars::{
        clock::Clock,
        instructions::{Instructions, IntrospectedInstruction},
        Sysvar,
    },
    AccountView, Address, ProgramResult,
};
use pinocchio_token::instructions::Transfer;

use crate::processor::utils::auth::with_state_pda_signer;
use crate::processor::utils::{
    auth::require_solver,
    cpi::is_cpi_call,
    intent::OrderIntentAccessor,
    settle::validate_counterpart,
    token::{owning_token_program, read_token_account},
};

pub fn process_begin_settle(
    program_id: &Address,
    accounts: &mut [AccountView],
    instruction_data: &[u8],
) -> ProgramResult {
    if is_cpi_call() {
        return Err(SettlementError::CalledViaCpi.into());
    }

    let input = BeginSettleInput::parse(instruction_data, accounts)?;

    validate_is_state_pda(input.state_pda_account.address().as_array())?;
    require_solver(input.state_pda_account, input.solver_account)?;

    // We use `instructions_sysvar_account` from the input but this could be
    // any address since parsing doesn't validate the input. We rely on the
    // fact that the Pinocchio library already checks that the input account
    // is the expected one.
    let instructions = Instructions::try_from(input.instructions_sysvar_account)?;
    let current_index = instructions.load_current_index();

    // Reciprocity: the input index is a finalize_settle instruction and that
    // instruction points to the current one.
    validate_counterpart(
        program_id,
        &instructions,
        current_index,
        input.finalize_ix_index,
        SettlementInstruction::FinalizeSettle,
    )?;

    validate_no_nested_settlement(
        program_id,
        &instructions,
        current_index,
        input.finalize_ix_index,
    )?;

    let finalize_ix = instructions.load_instruction_at(usize::from(input.finalize_ix_index))?;

    with_state_pda_signer(|signer| {
        settle_orders(
            program_id,
            input.state_pda_account,
            signer,
            &input.orders,
            &finalize_ix,
        )
    })
}

/// The `[source_buffer, destination]` address pair of each push carried by the
/// paired `FinalizeSettle`, seen through instruction introspection, in order.
///
/// The push structure isn't validated here: the paired `FinalizeSettle` re-parses
/// the same instruction from its own data and rejects a push count that disagrees
/// with its accounts. The caller pairs these pushes with the settled orders
/// one-to-one, which is what catches a count mismatch.
fn push_accounts<'a>(
    instruction: &'a IntrospectedInstruction<'a>,
) -> impl Iterator<Item = (&'a Address, &'a Address)> {
    // Each push occupies a `[source_buffer, destination]` meta pair after the
    // fixed accounts.
    let account_at = |index: usize| {
        // The index stays below `num_account_metas`, so the lookup, whose only
        // error is an out-of-bounds index, always succeeds.
        &instruction
            .get_instruction_account_at(index)
            .expect("index within num_account_metas")
            .key
    };
    (FINALIZE_FIXED_ACCOUNTS + 1..instruction.num_account_metas())
        .step_by(2)
        .map(move |destination_index| {
            (
                account_at(
                    destination_index
                        .checked_sub(1)
                        .expect("a destination index is preceded by its source buffer"),
                ),
                account_at(destination_index),
            )
        })
}

/// The paired pushes `BeginSettle` settles against: each push's accounts (read
/// from the finalize's account metas) with the bump and amount it carries (read
/// from the finalize's instruction data), in push order.
///
/// These are the same [`Push`]es `FinalizeSettle` itself parses, seen through
/// introspection rather than held as accounts: hence `Push<Address>` where the
/// finalize has `Push<AccountView>`.
fn finalize_pushes<'a>(
    finalize_ix: &'a IntrospectedInstruction<'a>,
) -> Result<impl Iterator<Item = Push<'a, Address>>, ProgramError> {
    let data = finalize_push_data(finalize_ix.get_instruction_data())?;
    Ok(push_accounts(finalize_ix).zip(data).map(
        |((source_buffer, destination), (bump, amount))| Push {
            source_buffer,
            destination,
            bump,
            amount,
        },
    ))
}

/// Reject a `BeginSettle` whose pair encloses another settlement: no
/// `BeginSettle`/`FinalizeSettle` of this program may appear strictly between
/// `current_index` and `finalize_ix_index`. The bounds themselves are excluded.
#[must_use = "ignoring the output may lead to an unintended on-chain state"]
fn validate_no_nested_settlement<T: Deref<Target = [u8]>>(
    program_id: &Address,
    instructions: &Instructions<T>,
    current_index: u16,
    finalize_ix_index: u16,
) -> ProgramResult {
    if finalize_ix_index <= current_index {
        return Err(SettlementError::FinalizeBeforeInitialize.into());
    }

    let search_start = current_index
        .checked_add(1)
        .expect("the finalize index is tested to be larger, no overflow can happen");
    for i in search_start..finalize_ix_index {
        let inner = instructions.load_instruction_at(usize::from(i))?;
        // Skip instructions belonging to a different program.
        if inner.get_program_id() != program_id {
            continue;
        }
        // If it can't recover the discriminator, it's fine: we expect that
        // instruction to fail, but this isn't something that matters here.
        // If the discriminator is valid, then it should not be the start
        // or end of a settlement.
        if let Ok((discriminator, _)) = recover_discriminator(inner.get_instruction_data()) {
            if [
                SettlementInstruction::BeginSettle,
                SettlementInstruction::FinalizeSettle,
            ]
            .contains(&discriminator)
            {
                return Err(SettlementError::BeginFinalizePairOverlap.into());
            }
        }
    }

    Ok(())
}

/// Validate each order against its push, and pull user funds, signing the pulls
/// as the canonical state PDA (the user's delegate). Orders must be strictly
/// increasing by address, which rejects duplicates.
///
/// Each order is paid by exactly one push. The orders and the finalize's pushes
/// are both laid out sorted by order PDA, so order `i` is paid by push `i`, and
/// that push's destination must be order `i`'s buy token account. Pairing them in
/// a single pass (one push consumed per order, with none left over) rejects any
/// count mismatch without counting the orders up front.
///
/// Further validation and the actual pulls are processed through
/// [`process_order`].
#[must_use = "ignoring the output may lead to an unintended on-chain state"]
fn settle_orders(
    program_id: &Address,
    state_pda_account: &AccountView,
    state_pda_signer: &Signer,
    orders: &SettledOrders<'_, AccountView>,
    finalize_ix: &IntrospectedInstruction,
) -> ProgramResult {
    // Orders must be passed strictly increasing by address; this rejects
    // duplicates (settling the same order twice) without a separate scan.
    let mut previous: Option<&Address> = None;

    let now = Clock::get()?.unix_timestamp;

    // Pull one push (destination and amount) per order; running out mid-loop
    // means fewer pushes than orders. A leftover push (more pushes than orders)
    // is caught after.
    let mut pushes = finalize_pushes(finalize_ix)?;

    for order in orders.iter() {
        let order_pda_address = order.order_pda.address();
        if previous.is_some_and(|previous| order_pda_address <= previous) {
            return Err(SettlementError::OrdersNotStrictlyIncreasing.into());
        }
        previous = Some(order_pda_address);

        let push = pushes
            .next()
            .ok_or(SettlementError::SettledOrderPushCountMismatch)?;

        process_order(
            program_id,
            order,
            &push,
            now,
            state_pda_account,
            state_pda_signer,
        )?;
    }

    if pushes.next().is_some() {
        return Err(SettlementError::SettledOrderPushCountMismatch.into());
    }

    Ok(())
}

/// Validate a single order, process its pulls, and confirm its push pays it.
/// This checks that the order is valid, settleable, and that the push pays the
/// intent's buy token account in the intent's buy mint out of the intent's sell
/// mint. Once the order passes those checks, its pulls are executed and its
/// settlement limit price is validated against the intent.
#[must_use = "ignoring the output may lead to an unintended on-chain state"]
fn process_order(
    program_id: &Address,
    order: SettledOrder<'_, AccountView>,
    push: &Push<Address>,
    now: i64,
    state_account: &AccountView,
    state_pda_signer: &Signer,
) -> ProgramResult {
    let SettledOrder {
        order_pda,
        sell_token_account,
        destinations,
        amounts,
    } = order;

    let mut order_pda = *order_pda;
    // We intentionally keep the borrow alive. This is a security feature: for
    // example, if the token transfer involves a CPI that cancels the order and
    // recreates it, the transaction reverts. The borrow must live until we
    // write back.
    let mut order = OrderAccount::load_from_pda_mut(&mut order_pda, program_id)?;
    if order.cancelled()? {
        return Err(SettlementError::OrderCancelled.into());
    }
    let intent = OrderIntentAccessor::from_order(&order)?;
    let prior_fill = order.filled_amounts();
    let intent = &intent;

    if now > i64::from(intent.valid_to()) {
        return Err(SettlementError::OrderExpired.into());
    }

    // The push paying this order must send to the order's buy token account.
    if push.destination.as_array() != intent.buy_token_account() {
        return Err(SettlementError::PushDestinationMismatch.into());
    }

    // We also validate the buffer specified in the push is derived from the buy_mint.
    // This effectively transitively verifies `intent.buy_token_account`
    // matches `intent.buy_mint` by relying on the SPL token restriction that transfer
    // mints must match.
    // If its a native SOL buy order, the "source buffer" should be the state pda.
    let buy_mint = intent.buy_mint();
    if Asset::is_native_sol(buy_mint) {
        validate_is_state_pda(push.source_buffer.as_array())?;
    } else {
        validate_buffer_pda(push.source_buffer, buy_mint, push.bump)?;
    }

    // The sell token account must be the one named in the intent, owned by
    // the intent owner: an order can only sell funds its own owner controls.
    if sell_token_account.address().as_array() != intent.sell_token_account() {
        return Err(SettlementError::SellTokenAccountMismatch.into());
    }
    // The pulls below move this account's tokens, so they are issued against
    // the token program that owns it. An account under neither program isn't a
    // token account at all.
    let token_program = owning_token_program(sell_token_account)
        .map_err(|_| SettlementError::SellTokenAccountInvalid)?;
    // Assert the order intent owner and sell mint match those of the sell token
    // account.
    // `read_token_account` confirms this is a real token account of that token
    // program before we read its owner and mint, and reads by value, so nothing
    // is left borrowing the account when the transfers below touch it.
    let sell_token = read_token_account(token_program, sell_token_account)
        .map_err(|_| SettlementError::SellTokenAccountInvalid)?;
    if sell_token.owner.as_array() != intent.owner() {
        return Err(SettlementError::SellTokenOwnerMismatch.into());
    }
    // Like the buy side, the account could have been recreated for another
    // mint after the order was created.
    if sell_token.mint.as_array() != intent.sell_mint() {
        return Err(SettlementError::SellMintMismatch.into());
    }

    // Pull the configured amounts out of the sell token account, summing them
    // into `amount_in` as we go. The state PDA is the SPL delegate, so it signs
    // each transfer via `signer`.
    let mut amount_in: u64 = 0;
    for (destination, amount) in destinations.iter().zip(amounts) {
        let amount = u64::from_le_bytes(*amount);
        amount_in = amount_in
            .checked_add(amount)
            .ok_or(SettlementError::PullAmountOverflow)?;
        Transfer::new(sell_token_account, destination, state_account, amount)
            .invoke_signed_with_unverified_program(
                core::slice::from_ref(state_pda_signer),
                &token_program.address(),
            )?;
    }

    let settled = FillAmounts {
        withdrawn: amount_in,
        received: push.amount,
    };
    validate_limit_price(intent, &settled)?;
    let final_amounts = validated_final_amounts(intent, prior_fill, settled)?;

    order.set_amounts(final_amounts);

    Ok(())
}

/// Check a settlement's executed price for one order against its limit, using
/// the total pulled from the sell account (`amount_in`) and what the paired push
/// pays in (`amount_out`). The check is local, so a favorable price in another
/// settlement never excuses a bad one here.
#[must_use = "ignoring the output may lead to an unintended on-chain state"]
fn validate_limit_price(
    intent: &OrderIntentAccessor,
    settled: &FillAmounts,
) -> Result<(), SettlementError> {
    let (amount_in, amount_out) = (settled.withdrawn, settled.received);
    // Limit price: the executed price must be at least the order's limit, that is,
    //   amount_out >= amount_in * (buy_amount / sell_amount),
    // rearranged division-free to avoid rounding.
    // Every factor is a `u64`, so each product is at most `u64::MAX^2 < u128::MAX`.
    let lhs = u128::from(amount_out)
        .checked_mul(u128::from(intent.sell_amount().get()))
        .expect("u64 * u64 always fits in u128");
    let rhs = u128::from(amount_in)
        .checked_mul(u128::from(intent.buy_amount().get()))
        .expect("u64 * u64 always fits in u128");
    if lhs < rhs {
        return Err(SettlementError::LimitPriceViolated);
    }

    Ok(())
}

/// Fold this settlement's `amount_in`/`amount_out` into the order's stored
/// cumulative totals `amount_withdrawn`/`amount_received` and check the result,
/// returning the updated totals to persist. A `u64` overflow of either total is
/// rejected, despite this in exceptional circumstances being reasonable.
/// The order never fills beyond its (`Sell`: sold; `Buy`: bought) amount; and a
/// non-`partially_fillable` order must be filled completely. The other side is
/// bounded by the limit price.
fn validated_final_amounts(
    intent: &OrderIntentAccessor,
    prior: FillAmounts,
    settled: FillAmounts,
) -> Result<FillAmounts, SettlementError> {
    let withdrawn = prior
        .withdrawn
        .checked_add(settled.withdrawn)
        .ok_or(SettlementError::AmountWithdrawnOverflow)?;
    let received = prior
        .received
        .checked_add(settled.received)
        .ok_or(SettlementError::AmountReceivedOverflow)?;

    let Flags {
        kind,
        partially_fillable,
        ..
    } = intent.flags();
    let (filled, order_amount) = match kind {
        OrderKind::Sell => (withdrawn, intent.sell_amount().get()),
        OrderKind::Buy => (received, intent.buy_amount().get()),
    };
    if filled != order_amount && !partially_fillable {
        return Err(SettlementError::OrderNotExactlyFilled);
    } else if filled > order_amount {
        return Err(SettlementError::FillExceedsOrderAmount);
    }

    Ok(FillAmounts {
        withdrawn,
        received,
    })
}

#[cfg(test)]
mod tests {
    use super::*;

    use cow_settlement_interface::data::intent::fixtures::{arb_order_intent, sample_intent};
    use cow_settlement_interface::data::intent::{EncodedOrderIntent, Flags, OrderIntent};
    use cow_settlement_interface::fixtures::IntoNonZero;
    use cow_settlement_interface::instruction::fixtures::fake_account;
    use cow_settlement_interface::instruction::settle::fixtures::arb_pushes;
    use cow_settlement_interface::instruction::settle::{FinalizeSettle, FinalizeSettleInput};
    use cow_settlement_interface::instruction::InstructionInputParsing;
    use cow_settlement_interface::Pubkey;
    use proptest::prelude::*;
    use solana_instruction::{BorrowedAccountMeta, BorrowedInstruction, Instruction};

    /// The largest value any amount can take on-chain (an SPL amount is a `u64`).
    const MAX: u64 = u64::MAX;

    /// The order parameters that define an intent for these checks: the
    /// order's `sell`/`buy` amounts, `kind`, and fillability. Grouping them
    /// keeps a settlement's amounts visually separate from the order it fills.
    #[derive(Debug)]
    struct IntentSpec {
        sell: u64,
        buy: u64,
        kind: OrderKind,
        partially_fillable: bool,
    }

    impl IntentSpec {
        fn build(&self) -> EncodedOrderIntent {
            EncodedOrderIntent::from(&OrderIntent {
                sell_amount: self.sell.nz(),
                buy_amount: self.buy.nz(),
                ..sample_intent(Flags {
                    created_on_chain: true,
                    kind: self.kind,
                    partially_fillable: self.partially_fillable,
                })
            })
        }
    }

    /// A `validate_limit_price` scenario: the amount pulled from the sell
    /// account (`a_in`) and paid in by the push (`a_out`), plus the order's
    /// limit (`sell`, `buy`).
    struct Case {
        a_in: u64,
        a_out: u64,
        sell: u64,
        buy: u64,
    }

    /// Concrete settlements whose executed price meets or beats the order's
    /// limit, so the check accepts them.
    #[test]
    fn accepts_prices_at_or_above_limit() {
        #[rustfmt::skip]
        let cases = [
            // Full fill exactly at the limit price.
            Case { a_in: 1_000, a_out: 2_000, sell: 1_000, buy: 2_000 },
            // Full fill paying one token above the required amount.
            Case { a_in: 1_000, a_out: 2_001, sell: 1_000, buy: 2_000 },
            // Partial fill exactly at the limit price.
            Case { a_in: 500, a_out: 1_000, sell: 1_000, buy: 2_000 },
            // Taking in one token less.
            Case { a_in: 999, a_out: 2_000, sell: 1_000, buy: 2_000 },
            // Nothing pulled, nothing paid.
            Case { a_in: 0, a_out: 0, sell: 1_000, buy: 2_000 },
            // User gets free money!
            Case { a_in: 0, a_out: 1_337, sell: 1_000, buy: 2_000 },
            // The largest products the check can form, `u64::MAX * u64::MAX`.
            Case { a_in: MAX, a_out: MAX, sell: MAX, buy: MAX },
            // Pulling one token less at the maximal price beats the limit.
            Case { a_in: MAX - 1, a_out: MAX, sell: MAX, buy: MAX },
        ];

        for Case {
            a_in,
            a_out,
            sell,
            buy,
        } in cases
        {
            let encoded = IntentSpec {
                sell,
                buy,
                kind: OrderKind::Sell,
                partially_fillable: true,
            }
            .build();
            let intent = OrderIntentAccessor::attach(&encoded).expect("sample must attach");
            assert_eq!(
                validate_limit_price(
                    &intent,
                    &FillAmounts {
                        withdrawn: a_in,
                        received: a_out
                    }
                ),
                Ok(()),
                "in={a_in} out={a_out} sell={sell} buy={buy}",
            );
        }
    }

    /// Concrete settlements whose executed price falls below the order's limit,
    /// so the check rejects them.
    #[test]
    fn rejects_prices_below_limit() {
        #[rustfmt::skip]
        let cases = [
            // Full fill paying one token less than required.
            Case { a_in: 1_000, a_out: 1_999, sell: 1_000, buy: 2_000 },
            // Partial fill paying one token less than required.
            Case { a_in: 500, a_out: 999, sell: 1_000, buy: 2_000 },
            // Tokens pulled but nothing paid in return.
            Case { a_in: 1, a_out: 0, sell: 1_000, buy: 2_000 },
            // Price far below the limit.
            Case { a_in: 1, a_out: 1, sell: 1, buy: 1_000_000 },
            // Straight-out stealing.
            Case { a_in: 42, a_out: 0, sell: 31_337, buy: 31_337 },
            // Paying one token less than the maximal amount must be caught,
            // not wrap around to acceptance.
            Case { a_in: MAX, a_out: MAX - 1, sell: MAX, buy: MAX },
        ];

        for Case {
            a_in,
            a_out,
            sell,
            buy,
        } in cases
        {
            let encoded = IntentSpec {
                sell,
                buy,
                kind: OrderKind::Sell,
                partially_fillable: true,
            }
            .build();
            let intent = OrderIntentAccessor::attach(&encoded).expect("sample must attach");
            assert_eq!(
                validate_limit_price(
                    &intent,
                    &FillAmounts {
                        withdrawn: a_in,
                        received: a_out
                    }
                ),
                Err(SettlementError::LimitPriceViolated),
                "in={a_in} out={a_out} sell={sell} buy={buy}",
            );
        }
    }

    /// A `validated_final_amounts` scenario: the order's prior stored fill
    /// (`withdrawn` sold, `received` bought), this settlement's
    /// `amount_in`/`amount_out`, and the `intent` being filled.
    #[derive(Debug)]
    struct FillCase {
        withdrawn: u64,
        received: u64,
        amount_in: u64,
        amount_out: u64,
        intent: IntentSpec,
    }

    impl FillCase {
        fn build(&self) -> EncodedOrderIntent {
            self.intent.build()
        }
    }

    /// Settlements the check accepts, returning the folded totals: within the
    /// exact side's amount, and a fill-or-kill order filled completely.
    #[test]
    fn accepts_fills_within_amounts() {
        let cases = [
            // Fresh partial sell fill, within the sell amount.
            FillCase {
                withdrawn: 0,
                received: 0,
                amount_in: 500,
                amount_out: 1_000,
                intent: IntentSpec {
                    sell: 1_000,
                    buy: 2_000,
                    kind: OrderKind::Sell,
                    partially_fillable: true,
                },
            },
            // A second fill completing the sell order.
            FillCase {
                withdrawn: 500,
                received: 1_000,
                amount_in: 500,
                amount_out: 1_000,
                intent: IntentSpec {
                    sell: 1_000,
                    buy: 2_000,
                    kind: OrderKind::Sell,
                    partially_fillable: true,
                },
            },
            // A `Sell` order tracks buy proceeds but isn't capped by them.
            FillCase {
                withdrawn: 0,
                received: 0,
                amount_in: 500,
                amount_out: 9_000,
                intent: IntentSpec {
                    sell: 1_000,
                    buy: 2_000,
                    kind: OrderKind::Sell,
                    partially_fillable: true,
                },
            },
            // Fill-or-kill sell, filled exactly in one settlement.
            FillCase {
                withdrawn: 0,
                received: 0,
                amount_in: 1_000,
                amount_out: 2_000,
                intent: IntentSpec {
                    sell: 1_000,
                    buy: 2_000,
                    kind: OrderKind::Sell,
                    partially_fillable: false,
                },
            },
            // Partial buy fill, within the buy amount.
            FillCase {
                withdrawn: 0,
                received: 0,
                amount_in: 1_000,
                amount_out: 500,
                intent: IntentSpec {
                    sell: 2_000,
                    buy: 1_000,
                    kind: OrderKind::Buy,
                    partially_fillable: true,
                },
            },
            // Fill-or-kill buy, filled exactly.
            FillCase {
                withdrawn: 0,
                received: 0,
                amount_in: 2_000,
                amount_out: 1_000,
                intent: IntentSpec {
                    sell: 2_000,
                    buy: 1_000,
                    kind: OrderKind::Buy,
                    partially_fillable: false,
                },
            },
            // A no-op settlement on a partially fillable order.
            FillCase {
                withdrawn: 0,
                received: 0,
                amount_in: 0,
                amount_out: 0,
                intent: IntentSpec {
                    sell: 1_000,
                    buy: 2_000,
                    kind: OrderKind::Sell,
                    partially_fillable: true,
                },
            },
            // Folding up to the maximal total without overflowing.
            FillCase {
                withdrawn: MAX - 1,
                received: 0,
                amount_in: 1,
                amount_out: 0,
                intent: IntentSpec {
                    sell: MAX,
                    buy: 1,
                    kind: OrderKind::Sell,
                    partially_fillable: false,
                },
            },
            // Sanity checks: this function only bounds the order's exact side, so
            // the other side isn't capped and could reach `u64::MAX`: a `Sell`
            // order never checks the buy side, a `Buy` order never checks the sell
            // side. A real settlement's limit price rules these out, so they
            // aren't expected to ever be relevant in an actual settlement.
            FillCase {
                withdrawn: 0,
                received: 0,
                amount_in: 1_000,
                amount_out: MAX,
                intent: IntentSpec {
                    sell: 1_000,
                    buy: 2_000,
                    kind: OrderKind::Sell,
                    partially_fillable: true,
                },
            },
            FillCase {
                withdrawn: 0,
                received: 0,
                amount_in: MAX,
                amount_out: 1_000,
                intent: IntentSpec {
                    sell: 2_000,
                    buy: 1_000,
                    kind: OrderKind::Buy,
                    partially_fillable: true,
                },
            },
        ];

        for case in cases {
            let encoded = case.build();
            let intent = OrderIntentAccessor::attach(&encoded).expect("sample must attach");
            let expected = FillAmounts {
                withdrawn: case
                    .withdrawn
                    .checked_add(case.amount_in)
                    .expect("no overflow"),
                received: case
                    .received
                    .checked_add(case.amount_out)
                    .expect("no overflow"),
            };
            assert_eq!(
                validated_final_amounts(
                    &intent,
                    FillAmounts {
                        withdrawn: case.withdrawn,
                        received: case.received,
                    },
                    FillAmounts {
                        withdrawn: case.amount_in,
                        received: case.amount_out,
                    },
                ),
                Ok(expected),
                "{case:?}",
            );
        }
    }

    /// Settlements the check rejects: the exact side over its amount, a fill-or-
    /// kill order left partially filled, and a cumulative total that overflows.
    #[test]
    fn rejects_overfill_incomplete_fill_or_kill_or_overflow() {
        use SettlementError::{
            AmountReceivedOverflow, AmountWithdrawnOverflow, FillExceedsOrderAmount,
            OrderNotExactlyFilled,
        };
        let cases = [
            // Sell one token over the sell amount.
            (
                FillCase {
                    withdrawn: 0,
                    received: 0,
                    amount_in: 1_001,
                    amount_out: 0,
                    intent: IntentSpec {
                        sell: 1_000,
                        buy: 2_000,
                        kind: OrderKind::Sell,
                        partially_fillable: true,
                    },
                },
                FillExceedsOrderAmount,
            ),
            // Buy one token over the buy amount.
            (
                FillCase {
                    withdrawn: 0,
                    received: 0,
                    amount_in: 0,
                    amount_out: 1_001,
                    intent: IntentSpec {
                        sell: 2_000,
                        buy: 1_000,
                        kind: OrderKind::Buy,
                        partially_fillable: true,
                    },
                },
                FillExceedsOrderAmount,
            ),
            // A second fill pushing the cumulative sell past the sell amount.
            (
                FillCase {
                    withdrawn: 601,
                    received: 0,
                    amount_in: 400,
                    amount_out: 0,
                    intent: IntentSpec {
                        sell: 1_000,
                        buy: 2_000,
                        kind: OrderKind::Sell,
                        partially_fillable: true,
                    },
                },
                FillExceedsOrderAmount,
            ),
            // A second fill pushing the cumulative buy past the buy amount.
            (
                FillCase {
                    withdrawn: 0,
                    received: 601,
                    amount_in: 0,
                    amount_out: 400,
                    intent: IntentSpec {
                        sell: 2_000,
                        buy: 1_000,
                        kind: OrderKind::Buy,
                        partially_fillable: true,
                    },
                },
                FillExceedsOrderAmount,
            ),
            // Fill-or-kill sell left partially filled.
            (
                FillCase {
                    withdrawn: 0,
                    received: 0,
                    amount_in: 999,
                    amount_out: 2_000,
                    intent: IntentSpec {
                        sell: 1_000,
                        buy: 2_000,
                        kind: OrderKind::Sell,
                        partially_fillable: false,
                    },
                },
                OrderNotExactlyFilled,
            ),
            // Fill-or-kill buy left partially filled.
            (
                FillCase {
                    withdrawn: 0,
                    received: 0,
                    amount_in: 2_000,
                    amount_out: 999,
                    intent: IntentSpec {
                        sell: 2_000,
                        buy: 1_000,
                        kind: OrderKind::Buy,
                        partially_fillable: false,
                    },
                },
                OrderNotExactlyFilled,
            ),
            // Fill-or-kill order not filled at all.
            (
                FillCase {
                    withdrawn: 0,
                    received: 0,
                    amount_in: 0,
                    amount_out: 0,
                    intent: IntentSpec {
                        sell: 1_000,
                        buy: 2_000,
                        kind: OrderKind::Sell,
                        partially_fillable: false,
                    },
                },
                OrderNotExactlyFilled,
            ),
            // The cumulative withdrawn total overflows a `u64`.
            (
                FillCase {
                    withdrawn: MAX,
                    received: 0,
                    amount_in: 1,
                    amount_out: 0,
                    intent: IntentSpec {
                        sell: 42,
                        buy: 1337,
                        kind: OrderKind::Sell,
                        partially_fillable: true,
                    },
                },
                AmountWithdrawnOverflow,
            ),
            // The cumulative received total overflows a `u64`.
            (
                FillCase {
                    withdrawn: 0,
                    received: MAX,
                    amount_in: 0,
                    amount_out: 1,
                    intent: IntentSpec {
                        sell: 42,
                        buy: 1337,
                        kind: OrderKind::Sell,
                        partially_fillable: true,
                    },
                },
                AmountReceivedOverflow,
            ),
        ];

        for (case, error) in cases {
            let encoded = case.build();
            let intent = OrderIntentAccessor::attach(&encoded).expect("sample must attach");
            assert_eq!(
                validated_final_amounts(
                    &intent,
                    FillAmounts {
                        withdrawn: case.withdrawn,
                        received: case.received,
                    },
                    FillAmounts {
                        withdrawn: case.amount_in,
                        received: case.amount_out,
                    },
                ),
                Err(error),
                "{case:?}",
            );
        }
    }

    proptest! {
        /// The limit-price check never panics for any intent and any `u64`
        /// amounts: each product is `u64 * u64`, always within `u128`.
        #[test]
        fn validate_limit_price_never_panics(
            intent in arb_order_intent(),
            amount_in in any::<u64>(),
            push_amount in any::<u64>(),
        ) {
            let encoded = EncodedOrderIntent::from(&intent);
            let _ = validate_limit_price(
                &OrderIntentAccessor::attach(&encoded).expect("valid intent attaches"),
                &FillAmounts {
                    withdrawn: amount_in,
                    received: push_amount,
                },
            );
        }
    }

    /// Encode `ix` as the introspected instruction from the instructions
    /// sysvar.
    fn introspected_instruction(ix: &Instruction) -> IntrospectedInstruction<'static> {
        // From the Solana docs for `BorrowedInstruction`: "This struct is
        // used by the runtime when constructing the instructions sysvar."
        let borrowed = BorrowedInstruction {
            program_id: &ix.program_id,
            accounts: ix
                .accounts
                .iter()
                .map(|meta| BorrowedAccountMeta {
                    pubkey: &meta.pubkey,
                    is_signer: meta.is_signer,
                    is_writable: meta.is_writable,
                })
                .collect(),
            data: &ix.data,
        };
        // From the Solana docs for this function: "construct the account data
        // for the instructions sysvar."
        let instructions_sysvar_data =
            solana_instructions_sysvar::construct_instructions_data(&[borrowed])
                .expect("instruction serialization should succeed for well-formed instructions");
        // SAFETY: from Pinocchio's docs for `new_unchecked`: "this function is
        // unsafe because it does not check if the provided data is from the
        // Sysvar Account."
        // We built the data using `construct_instructions_data`, so we know the
        // data is correctly built.
        // https://docs.rs/pinocchio/0.11.1/pinocchio/sysvars/instructions/struct.Instructions.html#method.new_unchecked
        // https://docs.rs/solana-instructions-sysvar/3.0.0/src/solana_instructions_sysvar/lib.rs.html#85-141
        let instructions = unsafe { Instructions::new_unchecked(instructions_sysvar_data) };
        // Leak the buffer so the returned view can borrow it for the rest of the
        // test process.
        let instructions: &'static Instructions<Vec<u8>> = Box::leak(Box::new(instructions));
        instructions
            .load_instruction_at(0)
            .expect("the finalize is the only instruction, at index 0")
    }

    proptest! {
        /// `BeginSettle` settles against a paired `FinalizeSettle`'s pushes via
        /// `finalize_pushes`: each push's source buffer and destination (from the
        /// account metas) paired with its bump and amount (from the instruction
        /// data). For any well-formed finalize those must match both the builder's
        /// inputs and what `FinalizeSettleInput` parses from the same instruction.
        #[test]
        fn finalize_pushes_matches_parser(
            program_id in any::<[u8; 32]>(),
            state_pda in any::<[u8; 32]>(),
            begin_ix_index in any::<u16>(),
            (source_buffers, destinations, bumps, amounts) in arb_pushes(0..=16usize),
        ) {
            let ix = Instruction::from(FinalizeSettle {
                program_id: Pubkey::new_from_array(program_id),
                state_pda: Pubkey::new_from_array(state_pda),
                begin_ix_index,
                only_token_program: None,
                source_buffers: &source_buffers,
                destinations: &destinations,
                bumps: &bumps,
                amounts: &amounts,
            });

            let introspected_instruction = introspected_instruction(&ix);
            let introspected: Vec<Push<'_, Address>> =
                finalize_pushes(&introspected_instruction)
                    .expect("well-formed finalize data")
                    .collect();

            let accounts: Vec<AccountView> =
                ix.accounts.iter().map(|account| fake_account(account.pubkey)).collect();
            let parsed_raw = FinalizeSettleInput::parse(&ix.data, &accounts)
                .expect("a well-formed finalize parses");
            let parsed: Vec<Push<'_, Address>> = parsed_raw
                .pushes
                .iter()
                .map(|p| Push {
                    source_buffer: p.source_buffer.address(),
                    destination: p.destination.address(),
                    bump: p.bump,
                    amount: p.amount
                })
                .collect();

            // The builder's inputs, the ground truth both views should recover.
            let expected: Vec<Push<'_, Address>> = source_buffers
                .iter()
                .zip(&destinations)
                .zip(bumps.iter().copied().zip(amounts.iter().copied()))
                .map(|((source_buffer, destination), (bump, amount))| Push {
                    source_buffer,
                    destination,
                    bump,
                    amount,
                })
                .collect();

            prop_assert_eq!(&introspected, &expected);
            prop_assert_eq!(&parsed, &expected);
        }
    }
}
