//! Token-2022 helpers for the settlement integration tests.
//!
//! Unlike the legacy program, Token-2022 lets a mint be closed and its address
//! reused for something else entirely. A buffer PDA is derived from the mint
//! address alone, so a buffer outlives the mint it was created for. These
//! helpers drive that lifecycle: create a mint under a chosen extension set,
//! close it, and put a different mint at the same address.

use cow_settlement_interface::token_program::TokenProgram;
use solana_sdk::{instruction::Instruction, pubkey::Pubkey};
use spl_token_2022_interface::{
    extension::{transfer_fee::instruction::initialize_transfer_fee_config, ExtensionType},
    instruction::{initialize_mint_close_authority, initialize_non_transferable_mint},
    state::{Account, Mint},
};

/// The Token-2022 program, spelled once so the builders below can take it.
const TOKEN_2022_PROGRAM_ID: Pubkey = TokenProgram::Token2022.address();

/// Transfer-fee parameters for [`Extensions::CloseAuthorityAndTransferFee`].
/// nothing reads them back, but `InitializeTransferFeeConfig` demands values.
pub const FEE_BASIS_POINTS: u64 = 50;
pub const MAXIMUM_FEE: u64 = 1_000;

/// Defines a set of token account/mint configurations we are interested in testing
#[derive(Clone, Copy, Debug, Default)]
pub enum Extensions {
    None,
    CloseAuthorityOnly,
    CloseAuthorityAndNonTransferable,
    #[default]
    CloseAuthorityAndTransferFee,
}

pub struct RequiredInitAccountExtensionType(ExtensionType);

impl RequiredInitAccountExtensionType {
    /// Copied from the unnecessarily private function in spl_token_2022_interface
    /// https://docs.rs/spl-token-2022-interface/latest/src/spl_token_2022_interface/extension/mod.rs.html#1296
    pub fn required_init_account_extensions(&self) -> &'static [ExtensionType] {
        match self.0 {
            ExtensionType::TransferFeeConfig => &[ExtensionType::TransferFeeAmount],
            ExtensionType::NonTransferable => &[
                ExtensionType::NonTransferableAccount,
                ExtensionType::ImmutableOwner,
            ],
            ExtensionType::TransferHook => &[ExtensionType::TransferHookAccount],
            ExtensionType::Pausable => &[ExtensionType::PausableAccount],
            _ => &[],
        }
    }
}

impl Extensions {
    /// The extensions which should be configured on the mint
    fn mint(self) -> &'static [ExtensionType] {
        match self {
            Self::None => &[],
            Self::CloseAuthorityOnly => &[ExtensionType::MintCloseAuthority],
            Self::CloseAuthorityAndNonTransferable => &[
                ExtensionType::MintCloseAuthority,
                ExtensionType::NonTransferable,
            ],
            Self::CloseAuthorityAndTransferFee => &[
                ExtensionType::MintCloseAuthority,
                ExtensionType::TransferFeeConfig,
            ],
        }
    }

    /// The extensions which should be configured on the token account
    /// Includes the required mint accounts by default, plus any additionally
    /// specified optional token account extensions
    fn token_account(self) -> Vec<ExtensionType> {
        let mut extensions = vec![];

        // required extensions by mint
        for mint_extension in self.mint() {
            extensions.extend_from_slice(
                RequiredInitAccountExtensionType(*mint_extension)
                    .required_init_account_extensions(),
            );
        }

        // additional extensions for this configuration
        // more will be added in the future
        #[allow(clippy::match_single_binding)]
        extensions.extend_from_slice(match self {
            _ => &[],
        });

        extensions
    }

    /// The data length the mint itself has to be allocated at. Token-2022
    /// insists on exactly the length its extensions need, so this is what
    /// [`super::token::create_mint_at_under`] allocates a mint under it at.
    pub(crate) fn mint_len(self) -> usize {
        ExtensionType::try_calculate_account_len::<Mint>(self.mint())
            .expect("every mint extension used here has a fixed length")
    }

    /// The data length a token account holding the mint has to be allocated at,
    /// which is what `create_buffer` asks the token program for.
    pub fn token_account_len(self) -> usize {
        ExtensionType::try_calculate_account_len::<Account>(&self.token_account())
            .expect("every account extension used here has a fixed length")
    }

    /// The instructions initializing the extensions on `mint`, with `authority`
    /// filling every authority they ask for. Token-2022 requires all of them to
    /// run before `InitializeMint`, and insists the mint be allocated at exactly
    /// the length they need.
    pub(crate) fn initializers(self, mint: &Pubkey, authority: &Pubkey) -> Vec<Instruction> {
        self.mint()
            .iter()
            .map(|extension| {
                match extension {
                    ExtensionType::MintCloseAuthority => initialize_mint_close_authority(
                        &TOKEN_2022_PROGRAM_ID,
                        mint,
                        Some(authority),
                    ),
                    ExtensionType::NonTransferable => {
                        initialize_non_transferable_mint(&TOKEN_2022_PROGRAM_ID, mint)
                    }
                    ExtensionType::TransferFeeConfig => initialize_transfer_fee_config(
                        &TOKEN_2022_PROGRAM_ID,
                        mint,
                        Some(authority),
                        Some(authority),
                        FEE_BASIS_POINTS.try_into().unwrap(),
                        MAXIMUM_FEE,
                    ),
                    other => panic!("no initializer is wired up for {other:?}"),
                }
                .expect("extension initializer should build")
            })
            .collect()
    }
}
