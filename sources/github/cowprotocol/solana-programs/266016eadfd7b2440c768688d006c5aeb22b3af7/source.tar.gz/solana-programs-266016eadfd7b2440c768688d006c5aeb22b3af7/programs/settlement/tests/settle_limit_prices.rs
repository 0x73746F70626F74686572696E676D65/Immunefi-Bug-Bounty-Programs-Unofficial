//! Integration tests for the per-order amount checks `BeginSettle` runs on a
//! settlement: the limit price, the sell/buy caps, and the fill-or-kill
//! requirement, plus the cumulative fill tracking that enforces the caps across
//! several settlements. Each test settles one or more orders in a minimal
//! `[BeginSettle, FinalizeSettle]` pair, pulling `amount_in` of the sell token
//! and pushing `amount_out` of the buy token, and asserts the settlement either
//! succeeds or is rejected with the expected error.

use crate::common::{
    assert_instruction_error_at,
    order::{buy_account, read_order, OrderBuilder},
    send,
    settlement::{build_staged_settlement, stage_order, StagedOrder, BEGIN_INDEX},
    setup_settle_ready, token,
};
use cow_settlement_client::cow_settlement_interface::{
    data::intent::{OrderIntent, OrderKind},
    pda::order::find_order_pda,
    SettlementError,
};
use litesvm::LiteSVM;
use solana_sdk::{
    pubkey::Pubkey,
    signature::{Keypair, Signer},
    transaction::TransactionError,
};

mod common;

/// Read `intent`'s order PDA and return its persisted `(amount_withdrawn,
/// amount_received)` cumulative fill totals.
fn order_fill(svm: &LiteSVM, program_id: &Pubkey, intent: &OrderIntent) -> (u64, u64) {
    let (order_pda, _bump) = find_order_pda(program_id, &intent.uid());
    let order = read_order(svm, &order_pda);
    (order.amount_withdrawn, order.amount_received)
}

/// Do everything required to settle the input intent with the specified in/out
/// amounts as long as the limit price is respected.
fn settle(
    svm: &mut LiteSVM,
    program_id: &Pubkey,
    payer: &Keypair,
    solver: &Keypair,
    intent: &OrderIntent,
    amount_in: u64,
    amount_out: u64,
) -> Result<(), TransactionError> {
    settle_all(
        svm,
        program_id,
        payer,
        solver,
        &[(intent, &[amount_in], amount_out)],
    )
}

/// Like [`settle`] but settles several orders and pulls in a single settlement.
fn settle_all(
    svm: &mut LiteSVM,
    program_id: &Pubkey,
    payer: &Keypair,
    solver: &Keypair,
    orders: &[(&OrderIntent, &[u64], u64)],
) -> Result<(), TransactionError> {
    let staged: Vec<StagedOrder> = orders
        .iter()
        .map(|&(intent, pulls, amount_out)| {
            stage_order(svm, program_id, payer, intent, pulls, amount_out)
        })
        .collect();
    let instructions = build_staged_settlement(program_id, &solver.pubkey(), &staged, vec![]);
    // The solver settles and pays: it's the fee payer and the only signer the
    // pair needs (`BeginSettle` names it as its solver-signer). `payer` above
    // only funds the order/buffer setup.
    send(svm, solver, &instructions).map(|_| ())
}

// --- Limit price ---------------------------------------------------------

#[test]
fn sell_order_succeeds_at_limit_price() {
    let (mut svm, program_id, payer, solver) = setup_settle_ready();

    // Sell up to 1_200_000 for at least 3_600_000: a 3:1 limit.
    let intent = OrderBuilder::new(&mut svm, &program_id, &payer)
        .sell_amount(1_200_000)
        .buy_amount(3_600_000)
        .build();

    // Sell 400_000, receive exactly the proportional minimum 1_200_000.
    settle(
        &mut svm,
        &program_id,
        &payer,
        &solver,
        &intent,
        400_000,
        1_200_000,
    )
    .expect("a price exactly at the limit should be accepted");
    assert_eq!(token::balance(&svm, &buy_account(&intent)), 1_200_000);
}

#[test]
fn sell_order_below_limit_price_is_rejected() {
    let (mut svm, program_id, payer, solver) = setup_settle_ready();

    // Sell up to 900_000 for at least 1_800_000: a 2:1 limit.
    let intent = OrderBuilder::new(&mut svm, &program_id, &payer)
        .sell_amount(900_000)
        .buy_amount(1_800_000)
        .build();

    // One token short of the proportional minimum (600_000) for the pull.
    assert_instruction_error_at(
        BEGIN_INDEX,
        settle(
            &mut svm,
            &program_id,
            &payer,
            &solver,
            &intent,
            300_000,
            599_999,
        ),
        SettlementError::LimitPriceViolated,
    );
}

#[test]
fn sell_order_above_limit_price_succeeds() {
    let (mut svm, program_id, payer, solver) = setup_settle_ready();

    // Sell up to 500_000 for at least 2_500_000: a 5:1 limit.
    let intent = OrderBuilder::new(&mut svm, &program_id, &payer)
        .sell_amount(500_000)
        .buy_amount(2_500_000)
        .build();

    // A better-than-limit price (more buy than the 500_000 minimum) is fine.
    settle(
        &mut svm,
        &program_id,
        &payer,
        &solver,
        &intent,
        100_000,
        750_000,
    )
    .expect("a better-than-limit price should be accepted");
    assert_eq!(token::balance(&svm, &buy_account(&intent)), 750_000);
}

#[test]
fn buy_order_succeeds_at_limit_price() {
    let (mut svm, program_id, payer, solver) = setup_settle_ready();

    // Buy up to 800_000, spending at most 2_400_000: a 3:1 limit.
    let intent = OrderBuilder::new(&mut svm, &program_id, &payer)
        .kind(OrderKind::Buy)
        .sell_amount(2_400_000)
        .buy_amount(800_000)
        .build();

    // Buy 400_000 for exactly the proportional maximum spend of 1_200_000.
    settle(
        &mut svm,
        &program_id,
        &payer,
        &solver,
        &intent,
        1_200_000,
        400_000,
    )
    .expect("a price exactly at the limit should be accepted");
    assert_eq!(token::balance(&svm, &buy_account(&intent)), 400_000);
}

#[test]
fn buy_order_above_limit_price_succeeds() {
    let (mut svm, program_id, payer, solver) = setup_settle_ready();

    // Buy up to 800_000, spending at most 2_400_000: a 3:1 limit.
    let intent = OrderBuilder::new(&mut svm, &program_id, &payer)
        .kind(OrderKind::Buy)
        .sell_amount(2_400_000)
        .buy_amount(800_000)
        .build();

    // A better-than-limit price (less spent than the 1_200_000 maximum) is fine.
    settle(
        &mut svm,
        &program_id,
        &payer,
        &solver,
        &intent,
        900_000,
        400_000,
    )
    .expect("a better-than-limit price should be accepted");
    assert_eq!(token::balance(&svm, &buy_account(&intent)), 400_000);
}

#[test]
fn buy_order_below_limit_price_is_rejected() {
    let (mut svm, program_id, payer, solver) = setup_settle_ready();

    // Buy up to 500_000, spending at most 2_000_000: a 4:1 limit.
    let intent = OrderBuilder::new(&mut svm, &program_id, &payer)
        .kind(OrderKind::Buy)
        .sell_amount(2_000_000)
        .buy_amount(500_000)
        .build();

    // One token more than the proportional maximum spend (800_000) for the buy.
    assert_instruction_error_at(
        BEGIN_INDEX,
        settle(
            &mut svm,
            &program_id,
            &payer,
            &solver,
            &intent,
            800_001,
            200_000,
        ),
        SettlementError::LimitPriceViolated,
    );
}

// --- Per-order locality --------------------------------------------------

/// Settle a generous order (well above its limit) against a violating one (just
/// below its own), both of the given kinds and on a shared token pair, and
/// assert the whole settlement is rejected for the violation.
fn assert_locality_rejected(generous_kind: OrderKind, violating_kind: OrderKind) {
    // Order has a 2:1 limit.
    const SELL_AMOUNT: u64 = 900_000;
    const BUY_AMOUNT: u64 = 1_800_000;

    let (mut svm, program_id, payer, solver) = setup_settle_ready();
    let sell_mint = token::create_mint(&mut svm, &payer);
    let buy_mint = token::create_mint(&mut svm, &payer);

    // Both orders are partially fillable and trade the shared token pair at the
    // same limit; only their kind and fill (below) differ.
    let mut order = |kind| {
        OrderBuilder::new(&mut svm, &program_id, &payer)
            .kind(kind)
            .partially_fillable(true)
            .sell_mint(&sell_mint)
            .buy_mint(&buy_mint)
            .sell_amount(SELL_AMOUNT)
            .buy_amount(BUY_AMOUNT)
            .build()
    };
    let generous = order(generous_kind);
    let violating = order(violating_kind);

    let result = settle_all(
        &mut svm,
        &program_id,
        &payer,
        &solver,
        &[
            // Far above the 2:1 limit.
            (&generous, &[250_000], 1_000_000),
            // One token short of the 600_000 the 300_000 pull requires.
            (&violating, &[300_000], 599_999),
        ],
    );
    assert_eq!(
        result.err(),
        Some(TransactionError::InstructionError(
            BEGIN_INDEX,
            SettlementError::LimitPriceViolated.into(),
        )),
        "generous={generous_kind:?} violating={violating_kind:?}",
    );
}

#[test]
fn settlement_rejected_when_one_order_below_limit() {
    // The check is per order: one order far above its limit can't excuse another
    // below its own. Sweep every buy/sell combination on a shared token pair.
    for generous_kind in [OrderKind::Sell, OrderKind::Buy] {
        for violating_kind in [OrderKind::Sell, OrderKind::Buy] {
            assert_locality_rejected(generous_kind, violating_kind);
        }
    }
}

// --- Multiple pulls ------------------------------------------------------

#[test]
fn multiple_pulls_clearing_the_limit_are_accepted() {
    let (mut svm, program_id, payer, solver) = setup_settle_ready();

    // Sell up to 1_000_000 for at least 2_000_000: a 2:1 limit.
    let intent = OrderBuilder::new(&mut svm, &program_id, &payer)
        .sell_amount(1_000_000)
        .buy_amount(2_000_000)
        .build();

    // Three pulls totalling 600_000 need at least 1_200_000 back; paying exactly
    // that clears the limit. The check sums the pulls, so the split is irrelevant.
    settle_all(
        &mut svm,
        &program_id,
        &payer,
        &solver,
        &[(&intent, &[300_000, 200_000, 100_000], 1_200_000)],
    )
    .expect("a payment clearing the limit for the summed pull should be accepted");
    assert_eq!(token::balance(&svm, &buy_account(&intent)), 1_200_000);
}

#[test]
fn multiple_pulls_below_the_limit_are_rejected() {
    let (mut svm, program_id, payer, solver) = setup_settle_ready();

    // Sell up to 1_000_000 for at least 2_000_000: a 2:1 limit.
    let intent = OrderBuilder::new(&mut svm, &program_id, &payer)
        .sell_amount(1_000_000)
        .buy_amount(2_000_000)
        .build();

    // One token short of the 1_200_000 the summed 600_000 pull requires; the
    // shortfall can't be hidden by splitting the pull across parts.
    assert_instruction_error_at(
        BEGIN_INDEX,
        settle_all(
            &mut svm,
            &program_id,
            &payer,
            &solver,
            &[(&intent, &[300_000, 200_000, 100_000], 1_199_999)],
        ),
        SettlementError::LimitPriceViolated,
    );
}

// --- Fill amounts (caps, fill-or-kill, cumulative) -----------------------

#[test]
fn sell_order_cannot_exceed_its_sell_amount() {
    let (mut svm, program_id, payer, solver) = setup_settle_ready();

    let intent = OrderBuilder::new(&mut svm, &program_id, &payer)
        .kind(OrderKind::Sell)
        .sell_amount(1_000_000)
        .buy_amount(2_000_000)
        .build();

    // Pull 1_500_000 > the 1_000_000 sell amount, paid to match the limit price
    // so only the sell cap can reject it.
    assert_instruction_error_at(
        BEGIN_INDEX,
        settle(
            &mut svm,
            &program_id,
            &payer,
            &solver,
            &intent,
            1_500_000,
            3_000_000,
        ),
        SettlementError::FillExceedsOrderAmount,
    );
}

#[test]
fn buy_order_cannot_exceed_its_buy_amount() {
    let (mut svm, program_id, payer, solver) = setup_settle_ready();

    // Buy up to 1_000_000, spending at most 2_000_000.
    let intent = OrderBuilder::new(&mut svm, &program_id, &payer)
        .kind(OrderKind::Buy)
        .sell_amount(2_000_000)
        .buy_amount(1_000_000)
        .build();

    // Receive 1_500_000 > the 1_000_000 buy amount, spending within the limit.
    assert_instruction_error_at(
        BEGIN_INDEX,
        settle(
            &mut svm,
            &program_id,
            &payer,
            &solver,
            &intent,
            1_000_000,
            1_500_000,
        ),
        SettlementError::FillExceedsOrderAmount,
    );
}

#[test]
fn fill_or_kill_order_must_be_filled_completely() {
    let (mut svm, program_id, payer, solver) = setup_settle_ready();

    let intent = OrderBuilder::new(&mut svm, &program_id, &payer)
        .kind(OrderKind::Sell)
        .partially_fillable(false)
        .sell_amount(1_000_000)
        .buy_amount(2_000_000)
        .build();

    // Selling only half a fill-or-kill order isn't allowed, even at the limit.
    assert_instruction_error_at(
        BEGIN_INDEX,
        settle(
            &mut svm,
            &program_id,
            &payer,
            &solver,
            &intent,
            500_000,
            1_000_000,
        ),
        SettlementError::OrderNotExactlyFilled,
    );
}

#[test]
fn partially_fillable_order_fills_across_settlements() {
    let (mut svm, program_id, payer, solver) = setup_settle_ready();

    // Sell up to 1_000_000 for at least 2_000_000: a 2:1 limit.
    let intent = OrderBuilder::new(&mut svm, &program_id, &payer)
        .kind(OrderKind::Sell)
        .partially_fillable(true)
        .sell_amount(1_000_000)
        .buy_amount(2_000_000)
        .build();

    // Two settlements that together fill the order exactly, each at the limit.
    settle(
        &mut svm,
        &program_id,
        &payer,
        &solver,
        &intent,
        400_000,
        800_000,
    )
    .expect("the first partial fill should be accepted");
    // The first fill's totals are persisted to the order PDA.
    assert_eq!(order_fill(&svm, &program_id, &intent), (400_000, 800_000));

    settle(
        &mut svm,
        &program_id,
        &payer,
        &solver,
        &intent,
        600_000,
        1_200_000,
    )
    .expect("a second fill completing the order should be accepted");
    // The second fill accumulates onto the first.
    assert_eq!(
        order_fill(&svm, &program_id, &intent),
        (1_000_000, 2_000_000)
    );

    // The buy token account accumulates both settlements' proceeds.
    assert_eq!(token::balance(&svm, &buy_account(&intent)), 2_000_000);
}

#[test]
fn order_cannot_be_overfilled_across_settlements() {
    let (mut svm, program_id, payer, solver) = setup_settle_ready();

    let intent = OrderBuilder::new(&mut svm, &program_id, &payer)
        .kind(OrderKind::Sell)
        .partially_fillable(true)
        .sell_amount(1_000_000)
        .buy_amount(2_000_000)
        .build();

    // Fill 600_000 first; the order PDA now records 600_000 withdrawn.
    settle(
        &mut svm,
        &program_id,
        &payer,
        &solver,
        &intent,
        600_000,
        1_200_000,
    )
    .expect("the first partial fill should be accepted");

    // A second 500_000 pull would take 1_100_000 in total, past the sell amount.
    assert_instruction_error_at(
        BEGIN_INDEX,
        settle(
            &mut svm,
            &program_id,
            &payer,
            &solver,
            &intent,
            500_000,
            1_000_000,
        ),
        SettlementError::FillExceedsOrderAmount,
    );
}

#[test]
fn buy_order_cannot_be_overfilled_across_settlements() {
    let (mut svm, program_id, payer, solver) = setup_settle_ready();

    // Buy up to 1_000_000, spending at most 2_000_000: a 2:1 limit.
    let intent = OrderBuilder::new(&mut svm, &program_id, &payer)
        .kind(OrderKind::Buy)
        .partially_fillable(true)
        .sell_amount(2_000_000)
        .buy_amount(1_000_000)
        .build();

    // Buy 600_000 first (spending 1_200_000 at the limit); the order PDA now
    // records 600_000 received.
    settle(
        &mut svm,
        &program_id,
        &payer,
        &solver,
        &intent,
        1_200_000,
        600_000,
    )
    .expect("the first partial buy should be accepted");

    // Buying another 500_000 would total 1_100_000, past the buy amount, even
    // though this settlement's spend stays within the limit price.
    assert_instruction_error_at(
        BEGIN_INDEX,
        settle(
            &mut svm,
            &program_id,
            &payer,
            &solver,
            &intent,
            1_000_000,
            500_000,
        ),
        SettlementError::FillExceedsOrderAmount,
    );
}

#[test]
fn fill_or_kill_order_cannot_be_settled_twice() {
    let (mut svm, program_id, payer, solver) = setup_settle_ready();

    let intent = OrderBuilder::new(&mut svm, &program_id, &payer)
        .kind(OrderKind::Sell)
        .partially_fillable(false)
        .sell_amount(1_000_000)
        .buy_amount(2_000_000)
        .build();

    // A full fill-or-kill fill is accepted once.
    settle(
        &mut svm,
        &program_id,
        &payer,
        &solver,
        &intent,
        1_000_000,
        2_000_000,
    )
    .expect("a full fill-or-kill fill should be accepted");

    // Advance the blockhash so the identical second attempt (same amounts to the
    // same accounts) isn't rejected as a duplicate transaction before it runs.
    svm.expire_blockhash();

    // Settling it again would take more than the sell amount in total. Being
    // fill-or-kill, the resulting cumulative fill isn't exactly the order's
    // amount, so it's rejected as not exactly filled.
    assert_instruction_error_at(
        BEGIN_INDEX,
        settle(
            &mut svm,
            &program_id,
            &payer,
            &solver,
            &intent,
            1_000_000,
            2_000_000,
        ),
        SettlementError::OrderNotExactlyFilled,
    );
}

#[test]
fn partially_fillable_order_cannot_be_settled_twice_in_one_settlement() {
    let (mut svm, program_id, payer, solver) = setup_settle_ready();

    let intent = OrderBuilder::new(&mut svm, &program_id, &payer)
        .kind(OrderKind::Sell)
        .partially_fillable(true)
        .sell_amount(1_000)
        .buy_amount(10)
        .build();

    let staged = stage_order(&mut svm, &program_id, &payer, &intent, &[1], 1_337);
    let instructions = build_staged_settlement(
        &program_id,
        &solver.pubkey(),
        &[staged.clone(), staged],
        vec![],
    );

    assert_instruction_error_at(
        BEGIN_INDEX,
        send(&mut svm, &solver, &instructions).map(|_| ()),
        SettlementError::OrdersNotStrictlyIncreasing,
    );
}

#[test]
fn settlement_rejected_when_one_order_exceeds_its_amount() {
    let (mut svm, program_id, payer, solver) = setup_settle_ready();

    // The cap is per order: one order settled within its amount can't excuse
    // another pulled past its sell amount in the same settlement.
    let ok = OrderBuilder::new(&mut svm, &program_id, &payer)
        .kind(OrderKind::Sell)
        .partially_fillable(true)
        .sell_amount(1_000_000)
        .buy_amount(2_000_000)
        .build();
    let overfilled = OrderBuilder::new(&mut svm, &program_id, &payer)
        .kind(OrderKind::Sell)
        .partially_fillable(false)
        .sell_amount(1_000_000)
        .buy_amount(2_000_000)
        .build();

    assert_instruction_error_at(
        BEGIN_INDEX,
        settle_all(
            &mut svm,
            &program_id,
            &payer,
            &solver,
            &[
                // Within its amount and at the limit.
                (&ok, &[400_000], 800_000),
                // Pulls 1_500_000 > its 1_000_000 sell amount. Being
                // fill-or-kill, this over-fill is rejected as not exactly
                // filled rather than as an over-fill.
                (&overfilled, &[1_500_000], 3_000_000),
            ],
        ),
        SettlementError::OrderNotExactlyFilled,
    );
}
