//! Integration tests for the settled-orders list carried by `BeginSettle`.
//!
//! Each settlement transaction here is the minimal `[BeginSettle, FinalizeSettle]`
//! pair (begin at [`BEGIN_INDEX`] pointing to finalize at [`FINALIZE_INDEX`], and
//! vice versa) so that the begin/finalize pairing always validates and execution
//! reaches the order-list checks, which is what these tests exercise.
//!
//! `BeginSettle` pairs one push with each order and checks that push pays the
//! order's buy token account, so even a settlement expected to be rejected during
//! order validation must pair with a finalize whose pushes match the orders in
//! both count and destination. [`settle_and_pay`] builds exactly such a
//! fully-working settlement, so every test here builds one with it and either
//! sends it unmodified (when the rejection is already baked into the orders or
//! accounts passed in) or mutates its `BeginSettle` instruction in place
//! afterwards (a wrong account, a wrong token program, a wrong state PDA, an
//! extra account). A few tests are the exception and build the raw instruction
//! directly, because what they exercise can't come out of the client builder,
//! whose output is a properly built instruction.

use crate::common::{
    assert_instruction_error_at,
    benchmark::BenchLabel,
    buffer, create_account,
    order::{
        buy_account, buy_mint, create_order_pda, sample_intent, settlable_intent, OrderBuilder,
    },
    replace_first_matching_account, send, send_metered, set_unix_timestamp,
    settlement::{build_settlement, BEGIN_INDEX, FINALIZE_INDEX},
    setup_settle_ready, token, unique_pubkey,
};
use cow_settlement_client::cow_settlement_interface::{
    instruction::settle::{
        BeginSettle as BeginSettleRaw, FinalizeSettle as FinalizeSettleRaw,
        FINALIZE_FIXED_ACCOUNTS, INSTRUCTIONS_SYSVAR_ID,
    },
    pda::{buffer::find_buffer_pda, order::find_order_pda, state::STATE_PDA},
    Instruction, SettlementError, SettlementInstruction,
};
use cow_settlement_client::instruction::{
    BeginSettle, FinalizeSettle, FinalizedIntent, InitializedIntent, Pull, TokenProgram,
};
use cow_settlement_client::pda::order::DecodedOrderAccount;
use cow_settlement_interface::data::intent::{Asset, OrderIntent, TokenAsset};
use litesvm::LiteSVM;
use litesvm_token::spl_token::error::TokenError;
use solana_program_pack::Pack;
use solana_sdk::{
    instruction::{AccountMeta, InstructionError},
    pubkey::Pubkey,
    signature::{Keypair, Signer},
    transaction::{Transaction, TransactionError},
};

mod common;

/// Assert the transaction failed in `BeginSettle` (at [`BEGIN_INDEX`]) with
/// `expected`.
#[track_caller]
fn assert_begin_error<T>(
    result: Result<T, TransactionError>,
    expected: impl Into<InstructionError>,
) {
    assert_instruction_error_at(BEGIN_INDEX, result, expected);
}

/// Assert the solver's payment clears the order's limit price for the amount
/// pulled. Guards these happy-path tests against a payment silently chosen
/// below the limit.
fn sanity_check_clears_limit(intent: &OrderIntent, pulled: u64, paid: u64) {
    let proceeds = u128::from(paid).strict_mul(u128::from(intent.sell_amount.get()));
    let required = u128::from(intent.buy_amount.get()).strict_mul(u128::from(pulled));
    assert!(
        proceeds >= required,
        "test setup error: paid {paid} for {pulled} pulled must clear the {}/{} limit",
        intent.buy_amount,
        intent.sell_amount,
    );
}

/// A list of empty transfer lists, one per order. Used for settling `n` orders
/// without pulling any funds.
fn no_pulls(n: usize) -> Vec<&'static [Pull]> {
    vec![&[]; n]
}

/// Build the `[BeginSettle, FinalizeSettle]` instructions settling `orders` and
/// paying each one a zero amount: the finalize pushes zero from each order's
/// canonical buy-token buffer to its buy token account, lining up one-to-one
/// with the orders so `BeginSettle`'s push pass passes. The buffer for each
/// order's buy mint is created on demand (hence `&mut svm`, unlike the other
/// builders). Use it for settlements expected to succeed whose orders pull
/// nothing (so the limit price is trivially met). Real push amounts are
/// exercised by [`settle_and_pay_amounts`] and `finalize_settle_pushes.rs`.
fn settle_and_pay(
    svm: &mut LiteSVM,
    program_id: &Pubkey,
    payer: &Keypair,
    solver: &Keypair,
    orders: &[InitializedIntent],
) -> Vec<Instruction> {
    settle_and_pay_amounts(
        svm,
        program_id,
        payer,
        solver,
        orders,
        &vec![0; orders.len()],
    )
}

/// Build the `[BeginSettle, FinalizeSettle]` instructions settling `orders` and
/// paying each one a real buy `amount`, funding each order's buy-token buffer
/// with that amount first so the push can draw from it. `push_amounts` is
/// parallel to `orders`. Use it for round-trip settlements that pull sell tokens
/// and must therefore pay enough buy tokens to clear the order's limit price.
fn settle_and_pay_amounts(
    svm: &mut LiteSVM,
    program_id: &Pubkey,
    payer: &Keypair,
    solver: &Keypair,
    orders: &[InitializedIntent],
    push_amounts: &[u64],
) -> Vec<Instruction> {
    let settled: Vec<FinalizedIntent> = orders
        .iter()
        .zip(push_amounts)
        .map(|(order, &amount)| {
            buffer::ensure_funded(svm, program_id, payer, &buy_mint(order.intent), amount);
            FinalizedIntent {
                intent: order.intent,
                amount,
            }
        })
        .collect();

    let begin = BeginSettle {
        program_id: *program_id,
        solver: solver.pubkey(),
        finalize_ix_index: FINALIZE_INDEX.into(),
        auction_id: 0,
        only_token_program: None,
        orders,
    };
    let finalize = FinalizeSettle {
        program_id: *program_id,
        begin_ix_index: BEGIN_INDEX.into(),
        only_token_program: None,
        orders: &settled,
    };
    vec![begin.into(), finalize.into()]
}

#[test]
fn settles_a_single_order() {
    let (mut svm, program_id, payer, solver) = setup_settle_ready();

    let intent = OrderBuilder::new(&mut svm, &program_id, &payer).build();
    let instructions = settle_and_pay(
        &mut svm,
        &program_id,
        &payer,
        &solver,
        &[InitializedIntent {
            intent: &intent,
            pulls: &[],
        }],
    );
    send_metered(&mut svm, &solver, &instructions, BenchLabel::Settle)
        .expect("settlement should succeed");
}

#[test]
fn settles_multiple_orders() {
    let (mut svm, program_id, payer, solver) = setup_settle_ready();

    let mut intents = Vec::new();
    for salt in 0..3u8 {
        intents.push(
            OrderBuilder::new(&mut svm, &program_id, &payer)
                .salt(salt)
                .build(),
        );
    }

    let orders: Vec<InitializedIntent> = intents
        .iter()
        .map(|intent| InitializedIntent { intent, pulls: &[] })
        .collect();
    let instructions = settle_and_pay(&mut svm, &program_id, &payer, &solver, &orders);
    send_metered(&mut svm, &solver, &instructions, BenchLabel::Settle)
        .expect("multi-order settlement should succeed");
}

#[test]
fn rejects_wrong_stored_bump() {
    let (mut svm, program_id, payer, solver) = setup_settle_ready();

    let intent = OrderBuilder::new(&mut svm, &program_id, &payer).build();
    let (order_pda, bump) = find_order_pda(&program_id, &intent.uid());

    let data = DecodedOrderAccount {
        bump: bump ^ 0x01,
        cancelled: false,
        amount_withdrawn: 0,
        amount_received: 0,
        created_by: payer.pubkey(),
        intent: intent.clone(),
    }
    .encode();

    common::create_account_at(&mut svm, order_pda, &program_id, &data);

    let instructions = settle_and_pay(
        &mut svm,
        &program_id,
        &payer,
        &solver,
        &[InitializedIntent {
            intent: &intent,
            pulls: &[],
        }],
    );
    assert_begin_error(
        send(&mut svm, &solver, &instructions),
        SettlementError::AccountNotDerivable,
    );
}

#[test]
fn rejects_fabricated_program_owned_account() {
    let (mut svm, program_id, payer, solver) = setup_settle_ready();
    let mint = token::create_mint(&mut svm, &payer);

    let sell_token = token::create_token_account(&mut svm, &payer, &mint, &payer.pubkey());
    let intent = OrderIntent {
        sell: TokenAsset {
            mint,
            token_account: sell_token,
        },
        ..sample_intent(payer.pubkey(), 0)
    };
    let (_real_order_pda, bump) = find_order_pda(&program_id, &intent.uid());
    let body = DecodedOrderAccount {
        bump,
        cancelled: false,
        amount_withdrawn: 0,
        amount_received: 0,
        created_by: payer.pubkey(),
        intent: intent.clone(),
    }
    .encode();
    // A program-owned account holding a valid order body (canonical bump
    // included), but sitting at an address that isn't the canonical order PDA.
    let fake_order = create_account(&mut svm, &program_id, &body);

    let begin = BeginSettleRaw {
        program_id,
        state_pda: STATE_PDA,
        solver: solver.pubkey(),
        finalize_ix_index: 1,
        auction_id: 0,
        only_token_program: None,
        order_pdas: &[fake_order],
        sell_token_accounts: &[sell_token],
        pulls: &no_pulls(1),
    };
    // Mostly placeholder values: the transaction will reject before reaching
    // this instruction, we just want to make sure that `BeginSettle` validates.
    let finalize = FinalizeSettleRaw {
        program_id,
        state_pda: STATE_PDA,
        begin_ix_index: 0,
        only_token_program: None,
        source_buffers: &[unique_pubkey()],
        destinations: &[buy_account(&intent)],
        bumps: &[0],
        amounts: &[0],
    };
    let instructions = vec![begin.into(), finalize.into()];

    assert_begin_error(
        send(&mut svm, &solver, &instructions),
        SettlementError::AccountNotDerivable,
    );
}

#[test]
fn rejects_non_order_account_in_order_slot() {
    let (mut svm, program_id, payer, solver) = setup_settle_ready();
    let mint = token::create_mint(&mut svm, &payer);

    let sell_token = token::create_token_account(&mut svm, &payer, &mint, &payer.pubkey());

    // Put a token account in the order slot. Its 165-byte data can't decode as a
    // order body, so it's rejected before the canonical-address check.
    // The client builder always references a real order PDA, so build the raw
    // instruction by hand.
    let begin = BeginSettleRaw {
        program_id,
        state_pda: STATE_PDA,
        solver: solver.pubkey(),
        finalize_ix_index: 1,
        auction_id: 0,
        only_token_program: None,
        order_pdas: &[sell_token],
        sell_token_accounts: &[sell_token],
        pulls: &no_pulls(1),
    };
    // The finalize just carries a placeholder push matching the order in count.
    let finalize = FinalizeSettleRaw {
        program_id,
        state_pda: STATE_PDA,
        begin_ix_index: 0,
        only_token_program: None,
        source_buffers: &[unique_pubkey()],
        destinations: &[unique_pubkey()],
        bumps: &[0],
        amounts: &[0],
    };
    let instructions = vec![begin.into(), finalize.into()];

    assert_begin_error(
        send(&mut svm, &solver, &instructions),
        InstructionError::InvalidAccountData,
    );
}

#[test]
fn rejects_sell_token_account_mismatch() {
    let (mut svm, program_id, payer, solver) = setup_settle_ready();
    let mint = token::create_mint(&mut svm, &payer);

    // Supply a different token account than the one the order's intent names.
    let intent = OrderBuilder::new(&mut svm, &program_id, &payer).build();
    let wrong_sell_token = token::create_token_account(&mut svm, &payer, &mint, &payer.pubkey());
    let mut instructions = settle_and_pay(
        &mut svm,
        &program_id,
        &payer,
        &solver,
        &[InitializedIntent {
            intent: &intent,
            pulls: &[],
        }],
    );
    replace_first_matching_account(
        &mut instructions[usize::from(BEGIN_INDEX)],
        &intent.sell.token_account,
        wrong_sell_token,
    );

    assert_begin_error(
        send(&mut svm, &solver, &instructions),
        SettlementError::SellTokenAccountMismatch,
    );
}

#[test]
fn rejects_sell_token_owner_mismatch() {
    let (mut svm, program_id, payer, solver) = setup_settle_ready();
    let sell_mint = token::create_mint(&mut svm, &payer);
    let buy_mint = token::create_mint(&mut svm, &payer);

    let other_owner = unique_pubkey();
    let sell_token = token::create_token_account(&mut svm, &payer, &sell_mint, &other_owner);
    let buy_token = token::create_token_account(&mut svm, &payer, &buy_mint, &payer.pubkey());

    let intent = OrderIntent {
        sell: TokenAsset {
            mint: sell_mint,
            token_account: sell_token,
        },
        buy: Asset::try_from(TokenAsset {
            mint: buy_mint,
            token_account: buy_token,
        })
        .expect("not native SOL"),
        ..sample_intent(payer.pubkey(), 1)
    };
    create_order_pda(&mut svm, &program_id, &payer, &intent);

    let instructions = settle_and_pay(
        &mut svm,
        &program_id,
        &payer,
        &solver,
        &[InitializedIntent {
            intent: &intent,
            pulls: &[],
        }],
    );
    assert_begin_error(
        send(&mut svm, &solver, &instructions),
        SettlementError::SellTokenOwnerMismatch,
    );
}

#[test]
fn rejects_non_token_sell_account() {
    let (mut svm, program_id, payer, solver) = setup_settle_ready();

    let non_token = unique_pubkey();

    let settlable = settlable_intent(&mut svm, &payer, payer.pubkey(), 1);
    let intent = OrderIntent {
        sell: TokenAsset {
            token_account: non_token,
            ..settlable.sell
        },
        ..settlable
    };
    create_order_pda(&mut svm, &program_id, &payer, &intent);

    let instructions = settle_and_pay(
        &mut svm,
        &program_id,
        &payer,
        &solver,
        &[InitializedIntent {
            intent: &intent,
            pulls: &[],
        }],
    );
    assert_begin_error(
        send(&mut svm, &solver, &instructions),
        SettlementError::SellTokenAccountInvalid,
    );
}

/// Even if a token account parses, we should still correctly identify if its unsupported
#[test]
fn rejects_sell_account_under_a_unsupported_token_program() {
    let (mut svm, program_id, payer, solver) = setup_settle_ready();

    let amount = 1_000_000;

    // We set up a standard token account, ready to trade
    let mint = common::token::create_mint(&mut svm, &payer);
    let account = common::token::create_token_account(&mut svm, &payer, &mint, &payer.pubkey());
    common::token::fund_and_delegate(&mut svm, &payer, &account, amount);

    // We clone the previous mint but assign it to a fake program
    let fake_token_program = create_account(&mut svm, &payer.pubkey(), &[]);
    let sell_mint = common::token::clone_under_new_program(&mut svm, &mint, &fake_token_program);
    // We replace the mint of the previous account with the new mint
    let mut token =
        litesvm_token::get_spl_account::<litesvm_token::spl_token::state::Account>(&svm, &account)
            .expect("the freshly delegated account is a valid token account");
    token.mint = sell_mint;
    let mut data = vec![0u8; litesvm_token::spl_token::state::Account::LEN];
    token.pack_into_slice(&mut data);
    let sell_token_account = unique_pubkey();
    common::create_account_at(&mut svm, sell_token_account, &unique_pubkey(), &data);

    let intent = OrderIntent {
        sell: TokenAsset {
            mint: sell_mint,
            token_account: sell_token_account,
        },
        ..settlable_intent(&mut svm, &payer, payer.pubkey(), 1)
    };
    create_order_pda(&mut svm, &program_id, &payer, &intent);

    let instructions = settle_and_pay(
        &mut svm,
        &program_id,
        &payer,
        &solver,
        &[InitializedIntent {
            intent: &intent,
            pulls: &[],
        }],
    );
    assert_begin_error(
        send(&mut svm, &solver, &instructions),
        SettlementError::SellTokenAccountInvalid,
    );
    assert_eq!(
        token::balance(&svm, &sell_token_account),
        amount,
        "the clone's tokens must be left where they were"
    );
}

#[test]
fn rejects_sell_token_account_recreated_for_another_mint() {
    let (mut svm, program_id, payer, solver) = setup_settle_ready();

    let intent = OrderBuilder::new(&mut svm, &program_id, &payer).build();
    let another_mint = token::create_mint(&mut svm, &payer);
    token::overwrite_token_account(&mut svm, &payer, &intent.sell.token_account, &another_mint);

    let instructions = settle_and_pay(
        &mut svm,
        &program_id,
        &payer,
        &solver,
        &[InitializedIntent {
            intent: &intent,
            pulls: &[],
        }],
    );
    assert_begin_error(
        send(&mut svm, &solver, &instructions),
        SettlementError::SellMintMismatch,
    );
}

#[test]
fn rejects_duplicate_orders() {
    let (mut svm, program_id, payer, solver) = setup_settle_ready();

    let intent = OrderBuilder::new(&mut svm, &program_id, &payer).build();
    let instructions = settle_and_pay(
        &mut svm,
        &program_id,
        &payer,
        &solver,
        &[
            InitializedIntent {
                intent: &intent,
                pulls: &[],
            },
            InitializedIntent {
                intent: &intent,
                pulls: &[],
            },
        ],
    );
    assert_begin_error(
        send(&mut svm, &solver, &instructions),
        SettlementError::OrdersNotStrictlyIncreasing,
    );
}

#[test]
fn rejects_orders_in_wrong_address_order() {
    let (mut svm, program_id, payer, solver) = setup_settle_ready();

    let first = OrderBuilder::new(&mut svm, &program_id, &payer)
        .salt(0)
        .build();
    let second = OrderBuilder::new(&mut svm, &program_id, &payer)
        .salt(1)
        .build();

    let (first_pda, _) = find_order_pda(&program_id, &first.uid());
    let (second_pda, _) = find_order_pda(&program_id, &second.uid());

    // Lay out the two distinct orders strictly decreasing by PDA address, which
    // the program rejects. The interface builders would sort them, so build both
    // instructions by hand in the current wire format. Begin data is
    // `[discriminator, finalize_ix_index (LE), order_count, transfer_count×n]`
    // (no transfers here) and begin accounts are `[solver, instructions_sysvar,
    // state_pda, spl_token_program, token_2022_program, (order_pda,
    // sell_token_account)...]`. The finalize's push destinations are laid out in
    // the same decreasing order, so the first order's destination check passes
    // and the second order trips the ordering check.
    let mut orders = [(first_pda, &first), (second_pda, &second)];
    orders.sort_by_key(|&(pda, ..)| std::cmp::Reverse(pda));

    let mut data = vec![SettlementInstruction::BeginSettle.discriminator()];
    data.extend_from_slice(&u16::from(FINALIZE_INDEX).to_le_bytes());
    data.extend_from_slice(&0i64.to_le_bytes()); // auction id
    data.push(orders.len() as u8);
    // No transfers: one zero transfer-count byte per order.
    data.extend(orders.iter().map(|_| 0u8));

    let mut accounts = vec![
        // The signing solver, registered by `setup_settle_ready`.
        AccountMeta::new_readonly(solver.pubkey(), true),
        AccountMeta::new_readonly(INSTRUCTIONS_SYSVAR_ID, false),
        AccountMeta::new_readonly(STATE_PDA, false),
    ];
    // Narrowed to the legacy program, so Token-2022's slot holds the placeholder.
    accounts.extend(
        [TokenProgram::SplToken.address(), INSTRUCTIONS_SYSVAR_ID]
            .map(|address| AccountMeta::new_readonly(address, false)),
    );
    for (order_pda, intent) in orders {
        accounts.push(AccountMeta::new_readonly(order_pda, false));
        accounts.push(AccountMeta::new(intent.sell.token_account, false));
    }
    let begin = Instruction {
        program_id,
        accounts,
        data,
    };

    // One zero-amount push per order, paying each order's buy token account and
    // aligned with begin's decreasing order. `BeginSettle` only reaches the
    // ordering check on the second order, so the first order's push has to be
    // well-formed: canonical buffer for that order's buy mint included.
    let ((source_buffers, bumps), destinations): ((Vec<Pubkey>, Vec<u8>), Vec<Pubkey>) = orders
        .iter()
        .map(|(_, intent)| {
            (
                find_buffer_pda(&program_id, &buy_mint(intent)),
                buy_account(intent),
            )
        })
        .unzip();
    let amounts = vec![0u64; orders.len()];
    let finalize = FinalizeSettleRaw {
        program_id,
        state_pda: STATE_PDA,
        begin_ix_index: BEGIN_INDEX.into(),
        only_token_program: None,
        source_buffers: &source_buffers,
        destinations: &destinations,
        bumps: &bumps,
        amounts: &amounts,
    };
    let instructions = vec![begin, finalize.into()];
    assert_begin_error(
        send(&mut svm, &solver, &instructions),
        SettlementError::OrdersNotStrictlyIncreasing,
    );
}

#[test]
fn rejects_cancelled_order() {
    let (mut svm, program_id, payer, solver) = setup_settle_ready();

    let intent = OrderBuilder::new(&mut svm, &program_id, &payer).build();

    // There's no cancel instruction yet, and `CreateOrder` always writes an
    // active order, so write the PDA directly with the `cancelled` flag set. The
    // account still sits at the canonical PDA holding a matching intent, so it
    // clears the provenance check and the cancelled flag is what trips the
    // rejection.
    let (order_pda, bump) = find_order_pda(&program_id, &intent.uid());
    let data = DecodedOrderAccount {
        bump,
        cancelled: true,
        amount_withdrawn: 0,
        amount_received: 0,
        created_by: payer.pubkey(),
        intent: intent.clone(),
    }
    .encode();

    common::create_account_at(&mut svm, order_pda, &program_id, &data);

    let instructions = settle_and_pay(
        &mut svm,
        &program_id,
        &payer,
        &solver,
        &[InitializedIntent {
            intent: &intent,
            pulls: &[],
        }],
    );
    assert_begin_error(
        send(&mut svm, &solver, &instructions),
        SettlementError::OrderCancelled,
    );
}

#[test]
fn rejects_expired_order() {
    let (mut svm, program_id, payer, solver) = setup_settle_ready();

    let valid_to = 1_000_000;
    let intent = OrderBuilder::new(&mut svm, &program_id, &payer)
        .valid_to(valid_to)
        .build();
    let after_expiration = i64::from(valid_to) + 1;
    set_unix_timestamp(&mut svm, after_expiration);

    let instructions = settle_and_pay(
        &mut svm,
        &program_id,
        &payer,
        &solver,
        &[InitializedIntent {
            intent: &intent,
            pulls: &[],
        }],
    );
    assert_begin_error(
        send(&mut svm, &solver, &instructions),
        SettlementError::OrderExpired,
    );
}

#[test]
fn settles_order_at_exact_valid_to() {
    let (mut svm, program_id, payer, solver) = setup_settle_ready();

    let valid_to = 1_000_000;
    let intent = OrderBuilder::new(&mut svm, &program_id, &payer)
        .valid_to(valid_to)
        .build();
    set_unix_timestamp(&mut svm, i64::from(valid_to));

    let instructions = settle_and_pay(
        &mut svm,
        &program_id,
        &payer,
        &solver,
        &[InitializedIntent {
            intent: &intent,
            pulls: &[],
        }],
    );
    send(&mut svm, &solver, &instructions)
        .expect("an order is still settleable at exactly valid_to");
}

#[test]
fn pulls_funds_to_destination() {
    let (mut svm, program_id, payer, solver) = setup_settle_ready();
    let sell_mint = token::create_mint(&mut svm, &payer);

    // Sell 2_000_000 for at least 4_000_000 at limit price.
    let amount = 2_000_000;
    let paid = 4_000_000;
    let intent = OrderBuilder::new(&mut svm, &program_id, &payer)
        .sell_mint(&sell_mint)
        .sell_amount(amount)
        .buy_amount(paid)
        .build();
    let sell_token = intent.sell.token_account;
    let initial_amount = 42_000_000;
    token::fund_and_delegate(&mut svm, &payer, &sell_token, initial_amount);
    let destination = token::create_token_account(&mut svm, &payer, &sell_mint, &unique_pubkey());

    let instructions = settle_and_pay_amounts(
        &mut svm,
        &program_id,
        &payer,
        &solver,
        &[InitializedIntent {
            intent: &intent,
            pulls: &[Pull {
                destination,
                amount,
            }],
        }],
        &[paid],
    );
    send_metered(&mut svm, &solver, &instructions, BenchLabel::Settle)
        .expect("a pull within the approved delegation, paid at the limit, should succeed");

    assert_eq!(token::balance(&svm, &destination), amount);
    assert_eq!(token::balance(&svm, &sell_token), initial_amount - amount);
    assert_eq!(
        token::delegated_amount(&svm, &sell_token),
        initial_amount - amount
    );
}

/// This test checks a security invariant.
/// The order account is held mutably borrowed for the entirety of an order's
/// settlement. In the middle, a transfer CPI takes place.
/// We confirm here that the CPI reverts if it tries to access the order account
/// itself.
#[test]
fn rejects_pull_targeting_the_order_account() {
    let (mut svm, program_id, payer, solver) = setup_settle_ready();
    let sell_mint = token::create_mint(&mut svm, &payer);

    let amount = 2_000_000;
    let paid = 4_000_000;
    let intent = OrderBuilder::new(&mut svm, &program_id, &payer)
        .sell_mint(&sell_mint)
        .sell_amount(amount)
        .buy_amount(paid)
        .build();
    let sell_token = intent.sell.token_account;
    token::fund_and_delegate(&mut svm, &payer, &sell_token, 42_000_000);

    // Point the pull at the order's own PDA rather than a token account.
    let (order_pda, _) = find_order_pda(&program_id, &intent.uid());

    let instructions = settle_and_pay_amounts(
        &mut svm,
        &program_id,
        &payer,
        &solver,
        &[InitializedIntent {
            intent: &intent,
            pulls: &[Pull {
                // Quick and dirty check: the solver sends the funds to the
                // order PDA. This isn't realistic but serves the purpose of
                // this test well without involving things like Token2022 and
                // hooks.
                destination: order_pda,
                amount,
            }],
        }],
        &[paid],
    );
    assert_begin_error(
        send(&mut svm, &solver, &instructions),
        InstructionError::AccountBorrowFailed,
    );
}

#[test]
fn pulls_to_multiple_destinations() {
    let (mut svm, program_id, payer, solver) = setup_settle_ready();
    let sell_mint = token::create_mint(&mut svm, &payer);

    let intent = OrderBuilder::new(&mut svm, &program_id, &payer)
        .sell_mint(&sell_mint)
        .build();
    let sell_token = intent.sell.token_account;
    let initial_amount: u64 = 1_000_000;
    token::fund_and_delegate(&mut svm, &payer, &sell_token, initial_amount);
    let dest0 = token::create_token_account(&mut svm, &payer, &sell_mint, &unique_pubkey());
    let dest1 = token::create_token_account(&mut svm, &payer, &sell_mint, &unique_pubkey());

    let pulled0 = 300_000;
    let pulled1 = 100_000;
    let paid = 800_000;
    sanity_check_clears_limit(&intent, pulled0 + pulled1, paid);
    let instructions = settle_and_pay_amounts(
        &mut svm,
        &program_id,
        &payer,
        &solver,
        &[InitializedIntent {
            intent: &intent,
            pulls: &[
                Pull {
                    destination: dest0,
                    amount: pulled0,
                },
                Pull {
                    destination: dest1,
                    amount: pulled1,
                },
            ],
        }],
        &[paid],
    );
    send_metered(&mut svm, &solver, &instructions, BenchLabel::Settle)
        .expect("multiple pulls from one order should succeed");

    assert_eq!(token::balance(&svm, &dest0), pulled0);
    assert_eq!(token::balance(&svm, &dest1), pulled1);
    assert_eq!(
        token::balance(&svm, &sell_token),
        initial_amount - pulled0 - pulled1
    );
    assert_eq!(
        token::delegated_amount(&svm, &sell_token),
        initial_amount - pulled0 - pulled1
    );
}

#[test]
fn pulls_from_multiple_orders() {
    let (mut svm, program_id, payer, solver) = setup_settle_ready();
    let sell_mint = token::create_mint(&mut svm, &payer);

    // Two distinct orders, each selling from its own token account.
    let first = OrderBuilder::new(&mut svm, &program_id, &payer)
        .sell_mint(&sell_mint)
        .salt(0)
        .build();
    let second = OrderBuilder::new(&mut svm, &program_id, &payer)
        .sell_mint(&sell_mint)
        .salt(1)
        .build();
    let initial_amount_first = 1_337_000;
    let initial_amount_second = 31_337_000;
    token::fund_and_delegate(
        &mut svm,
        &payer,
        &first.sell.token_account,
        initial_amount_first,
    );
    token::fund_and_delegate(
        &mut svm,
        &payer,
        &second.sell.token_account,
        initial_amount_second,
    );
    let dest_first = token::create_token_account(&mut svm, &payer, &sell_mint, &unique_pubkey());
    let dest_second = token::create_token_account(&mut svm, &payer, &sell_mint, &unique_pubkey());

    let pulled_first = 42_000;
    let pulled_second = 67_000;
    let paid_first = 2 * pulled_first;
    let paid_second = 2 * pulled_second;
    sanity_check_clears_limit(&first, pulled_first, paid_first);
    sanity_check_clears_limit(&second, pulled_second, paid_second);
    let instructions = settle_and_pay_amounts(
        &mut svm,
        &program_id,
        &payer,
        &solver,
        &[
            InitializedIntent {
                intent: &first,
                pulls: &[Pull {
                    destination: dest_first,
                    amount: pulled_first,
                }],
            },
            InitializedIntent {
                intent: &second,
                pulls: &[Pull {
                    destination: dest_second,
                    amount: pulled_second,
                }],
            },
        ],
        &[paid_first, paid_second],
    );
    send_metered(&mut svm, &solver, &instructions, BenchLabel::Settle)
        .expect("pulls from several orders should succeed");

    assert_eq!(token::balance(&svm, &dest_first), pulled_first);
    assert_eq!(token::balance(&svm, &dest_second), pulled_second);
    assert_eq!(
        token::balance(&svm, &first.sell.token_account),
        initial_amount_first - pulled_first
    );
    assert_eq!(
        token::balance(&svm, &second.sell.token_account),
        initial_amount_second - pulled_second
    );
}

#[test]
fn rejects_pulls_summing_beyond_u64() {
    let (mut svm, program_id, payer, solver) = setup_settle_ready();
    let sell_mint = token::create_mint(&mut svm, &payer);

    let intent = OrderBuilder::new(&mut svm, &program_id, &payer)
        .sell_mint(&sell_mint)
        .build();
    let sell_token = intent.sell.token_account;
    token::fund_and_delegate(&mut svm, &payer, &sell_token, 1);
    let dest0 = token::create_token_account(&mut svm, &payer, &sell_mint, &unique_pubkey());
    let dest1 = token::create_token_account(&mut svm, &payer, &sell_mint, &unique_pubkey());

    // Two pulls whose declared amounts sum is larger than `u64::MAX`.
    // No real token account could hold this, but a solver can craft the
    // instruction data, so the sum must reject it rather than wrap.
    let instructions = settle_and_pay_amounts(
        &mut svm,
        &program_id,
        &payer,
        &solver,
        &[InitializedIntent {
            intent: &intent,
            pulls: &[
                Pull {
                    destination: dest0,
                    amount: 1,
                },
                Pull {
                    destination: dest1,
                    amount: u64::MAX,
                },
            ],
        }],
        &[0],
    );
    assert_begin_error(
        send(&mut svm, &solver, &instructions),
        SettlementError::PullAmountOverflow,
    );
}

#[test]
fn zero_pulls_moves_nothing() {
    let (mut svm, program_id, payer, solver) = setup_settle_ready();
    // The intent specifies a sell mint. We want to see that, when no pull is
    // specified, this account isn't touched in the transaction.
    let sell_mint = token::create_mint(&mut svm, &payer);
    let buy_mint = token::create_mint(&mut svm, &payer);
    let intent = OrderBuilder::new(&mut svm, &program_id, &payer)
        .sell_mint(&sell_mint)
        .buy_mint(&buy_mint)
        .build();
    let sell_token = intent.sell.token_account;

    let initial_amount = 42_000_000;
    token::mint_to(&mut svm, &payer, &sell_mint, &sell_token, initial_amount);

    // `settle_and_pay` builds exactly the settlement this test needs: begin
    // settles the order with no pulls, and finalize pushes a zero amount from the
    // buy buffer (created on demand) to the buy token account. Build the
    // transaction by hand rather than via `send`, so the account keys used to
    // interpret the recorded token instructions come straight from the message
    // that was executed instead of a separately compiled copy.
    let instructions = settle_and_pay(
        &mut svm,
        &program_id,
        &payer,
        &solver,
        &[InitializedIntent {
            intent: &intent,
            pulls: &[],
        }],
    );
    let transaction = Transaction::new_signed_with_payer(
        &instructions,
        Some(&payer.pubkey()),
        &[&payer, &solver],
        svm.latest_blockhash(),
    );
    let account_keys = transaction.message.account_keys.clone();
    let transaction = svm
        .send_transaction(transaction)
        .expect("settling without pulling should succeed");

    // No token instruction references the sell token account (the sell mint's
    // only account here): the lone token transfer is the buy-side push, which
    // draws from `buy_mint`'s buffer. Its balance is also left untouched.
    token::assert_no_token_instruction_touching(&transaction, &account_keys, &sell_token);
    assert_eq!(token::balance(&svm, &sell_token), initial_amount);
}

#[test]
fn rejects_wrong_state_pda() {
    let (mut svm, program_id, payer, solver) = setup_settle_ready();

    let intent = OrderBuilder::new(&mut svm, &program_id, &payer).build();
    let mut instructions = settle_and_pay(
        &mut svm,
        &program_id,
        &payer,
        &solver,
        &[InitializedIntent {
            intent: &intent,
            pulls: &[],
        }],
    );

    // Swap the state PDA account `BeginSettle` references for a bogus one.
    replace_first_matching_account(
        &mut instructions[usize::from(BEGIN_INDEX)],
        &STATE_PDA,
        unique_pubkey(),
    );

    assert_begin_error(
        send(&mut svm, &solver, &instructions),
        SettlementError::StateAccountMismatch,
    );
}

#[test]
fn rejects_a_token_program_the_instruction_doesnt_name() {
    let (mut svm, program_id, payer, solver) = setup_settle_ready();
    let sell_mint = token::create_mint(&mut svm, &payer);

    // A real pull, unlike the tests above: the token program is only reached
    // once there is a transfer to issue against it.
    let amount = 1_000;
    let intent = OrderBuilder::new(&mut svm, &program_id, &payer)
        .sell_mint(&sell_mint)
        .sell_amount(amount)
        .buy_amount(amount)
        .build();
    let sell_token = intent.sell.token_account;
    token::fund_and_delegate(&mut svm, &payer, &sell_token, amount);
    let destination = token::create_token_account(&mut svm, &payer, &sell_mint, &unique_pubkey());

    let mut instructions = settle_and_pay_amounts(
        &mut svm,
        &program_id,
        &payer,
        &solver,
        &[InitializedIntent {
            intent: &intent,
            pulls: &[Pull {
                destination,
                amount,
            }],
        }],
        &[amount],
    );
    sanity_check_clears_limit(&intent, amount, amount);

    // Swap the SPL Token program account `BeginSettle` references for an invalid one.
    replace_first_matching_account(
        &mut instructions[usize::from(BEGIN_INDEX)],
        &TokenProgram::SplToken.address(),
        unique_pubkey(),
    );

    assert_begin_error(
        send(&mut svm, &solver, &instructions),
        InstructionError::MissingAccount,
    );
    assert_eq!(
        token::balance(&svm, &sell_token),
        amount,
        "a settlement that never reached its token program must move nothing"
    );
}

#[test]
fn rejects_pull_delegated_to_incorrect_address() {
    let (mut svm, program_id, payer, solver) = setup_settle_ready();
    let sell_mint = token::create_mint(&mut svm, &payer);

    let intent = OrderBuilder::new(&mut svm, &program_id, &payer)
        .sell_mint(&sell_mint)
        .build();
    let amount = 100_000;
    let sell_token = intent.sell.token_account;
    // Funds are present but some account other than the state PDA was
    // approved as a delegate.
    token::mint_to(&mut svm, &payer, &sell_mint, &sell_token, 1_000_000);
    token::delegate(&mut svm, &payer, &sell_token, &unique_pubkey(), amount);
    let destination = token::create_token_account(&mut svm, &payer, &sell_mint, &unique_pubkey());

    let instructions = settle_and_pay(
        &mut svm,
        &program_id,
        &payer,
        &solver,
        &[InitializedIntent {
            intent: &intent,
            pulls: &[Pull {
                destination,
                amount,
            }],
        }],
    );
    assert_begin_error(
        send(&mut svm, &solver, &instructions),
        InstructionError::Custom(TokenError::OwnerMismatch as u32),
    );
}

#[test]
fn rejects_pull_exceeding_delegation() {
    let (mut svm, program_id, payer, solver) = setup_settle_ready();
    let sell_mint = token::create_mint(&mut svm, &payer);

    let intent = OrderBuilder::new(&mut svm, &program_id, &payer)
        .sell_mint(&sell_mint)
        .build();
    let sell_token = intent.sell.token_account;
    // Funded generously, but the state PDA is delegated only 100_000.
    let initial_amount = 42_000_000;
    let delegated = 100_000;
    token::mint_to(&mut svm, &payer, &sell_mint, &sell_token, initial_amount);
    token::delegate(&mut svm, &payer, &sell_token, &STATE_PDA, delegated);
    let destination = token::create_token_account(&mut svm, &payer, &sell_mint, &unique_pubkey());

    let instructions = settle_and_pay(
        &mut svm,
        &program_id,
        &payer,
        &solver,
        &[InitializedIntent {
            intent: &intent,
            pulls: &[Pull {
                destination,
                amount: 200_000,
            }],
        }],
    );
    assert_begin_error(
        send(&mut svm, &solver, &instructions),
        InstructionError::Custom(TokenError::InsufficientFunds as u32),
    );
    assert_eq!(token::balance(&svm, &sell_token), initial_amount);
    assert_eq!(token::balance(&svm, &destination), 0);
    // The rejected pull must not have consumed any of the delegation.
    assert_eq!(token::delegated_amount(&svm, &sell_token), delegated);
}

#[test]
fn rejects_extra_account() {
    let (mut svm, program_id, payer, solver) = setup_settle_ready();

    let intent = OrderBuilder::new(&mut svm, &program_id, &payer).build();
    let mut instructions = settle_and_pay(
        &mut svm,
        &program_id,
        &payer,
        &solver,
        &[InitializedIntent {
            intent: &intent,
            pulls: &[],
        }],
    );

    // Append one extra account to `BeginSettle`, so the account count no longer
    // matches the `2n + T` the instruction data implies.
    instructions[usize::from(BEGIN_INDEX)]
        .accounts
        .push(AccountMeta::new_readonly(unique_pubkey(), false));

    assert_begin_error(
        send(&mut svm, &solver, &instructions),
        SettlementError::AccountCountNotMatchingOrderCount,
    );
}

#[test]
fn rejects_push_to_wrong_destination() {
    let (mut svm, program_id, payer, solver) = setup_settle_ready();
    let intent = OrderBuilder::new(&mut svm, &program_id, &payer).build();
    let orders = [FinalizedIntent {
        intent: &intent,
        amount: 100,
    }];

    let mut finalize = Instruction::from(FinalizeSettle {
        program_id,
        begin_ix_index: BEGIN_INDEX.into(),
        only_token_program: None,
        orders: &orders,
    });
    // Redirect the push to an account that isn't the order's buy token account.
    // Finalize accounts: `[FINALIZE_FIXED_ACCOUNTS..., source, destination]`.
    let destination_index = FINALIZE_FIXED_ACCOUNTS + 1;
    finalize.accounts[destination_index].pubkey = unique_pubkey();

    let instructions = build_settlement(&program_id, &solver.pubkey(), &orders, finalize);
    assert_begin_error(
        send(&mut svm, &solver, &instructions),
        SettlementError::PushDestinationMismatch,
    );
}

#[test]
fn rejects_push_if_buffer_does_not_match_buy_mint() {
    let (mut svm, program_id, payer, solver) = setup_settle_ready();
    let buy_mint = token::create_mint(&mut svm, &payer);
    let other_mint = token::create_mint(&mut svm, &payer);
    let intent = OrderBuilder::new(&mut svm, &program_id, &payer)
        .buy_mint(&buy_mint)
        .build();
    let orders = [FinalizedIntent {
        intent: &intent,
        amount: 100,
    }];
    buffer::ensure_funded(&mut svm, &program_id, &payer, &other_mint, 1_000);

    let (other_buffer, other_bump) = find_buffer_pda(&program_id, &other_mint);
    let finalize = FinalizeSettleRaw {
        program_id,
        state_pda: STATE_PDA,
        begin_ix_index: BEGIN_INDEX.into(),
        only_token_program: None,
        source_buffers: &[other_buffer],
        destinations: &[buy_account(&intent)],
        bumps: &[other_bump],
        amounts: &[100],
    };

    let instructions = build_settlement(&program_id, &solver.pubkey(), &orders, finalize);
    assert_begin_error(
        send(&mut svm, &solver, &instructions),
        SettlementError::PushSourceNotBuffer,
    );
}

#[test]
fn rejects_fewer_pushes_than_orders() {
    let (mut svm, program_id, payer, solver) = setup_settle_ready();
    let intent = OrderBuilder::new(&mut svm, &program_id, &payer).build();
    let orders = [FinalizedIntent {
        intent: &intent,
        amount: 100,
    }];

    // A finalize carrying no pushes, paired with a begin settling one order.
    let finalize = FinalizeSettle {
        program_id,
        begin_ix_index: BEGIN_INDEX.into(),
        only_token_program: None,
        orders: &[],
    };

    let instructions = build_settlement(&program_id, &solver.pubkey(), &orders, finalize);
    assert_begin_error(
        send(&mut svm, &solver, &instructions),
        SettlementError::SettledOrderPushCountMismatch,
    );
}

#[test]
fn rejects_more_pushes_than_orders() {
    let (mut svm, program_id, payer, solver) = setup_settle_ready();
    let intent = OrderBuilder::new(&mut svm, &program_id, &payer).build();

    // A finalize that pushes to one order, paired with a begin that settles none,
    // so the extra push has no order to account for it.
    let finalize = FinalizeSettle {
        program_id,
        begin_ix_index: BEGIN_INDEX.into(),
        only_token_program: None,
        orders: &[FinalizedIntent {
            intent: &intent,
            amount: 0,
        }],
    };

    let instructions = build_settlement(&program_id, &solver.pubkey(), &[], finalize);
    assert_begin_error(
        send(&mut svm, &solver, &instructions),
        SettlementError::SettledOrderPushCountMismatch,
    );
}

#[test]
fn rejects_partial_push_amount_in_finalize_settle() {
    let (mut svm, program_id, payer, solver) = setup_settle_ready();
    let intent = OrderBuilder::new(&mut svm, &program_id, &payer).build();
    let orders = [FinalizedIntent {
        intent: &intent,
        amount: 100,
    }];

    let mut finalize = Instruction::from(FinalizeSettle {
        program_id,
        begin_ix_index: BEGIN_INDEX.into(),
        only_token_program: None,
        orders: &orders,
    });
    // Drop one byte from the finalize instruction so the trailing amount is no
    // longer a whole `u64`. `BeginSettle` reads the finalize's push amounts, so
    // it rejects the malformed encoding before the finalize instruction runs.
    finalize.data.pop();

    let instructions = build_settlement(&program_id, &solver.pubkey(), &orders, finalize);
    assert_begin_error(
        send(&mut svm, &solver, &instructions),
        InstructionError::InvalidInstructionData,
    );
}
