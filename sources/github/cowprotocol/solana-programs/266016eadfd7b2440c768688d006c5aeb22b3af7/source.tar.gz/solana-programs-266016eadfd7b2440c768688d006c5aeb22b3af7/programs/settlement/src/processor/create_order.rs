//! `CreateOrder` instruction handler.

use cow_settlement_interface::{
    data::{
        intent::EncodedOrderIntent,
        order::{self, OrderAccount},
    },
    instruction::{create_order::CreateOrderInput, InstructionInputParsing},
    pda::order::order_pda_seeds,
    SettlementError,
};
use pinocchio::{error::ProgramError, AccountView, Address, ProgramResult};

use crate::processor::utils::{intent::OrderIntentAccessor, pda::CanonicalPda};

pub fn process_create_order(
    program_id: &Address,
    accounts: &mut [AccountView],
    instruction_data: &[u8],
) -> ProgramResult {
    let CreateOrderInput {
        intent_bytes,
        owner,
        created_by,
        order_pda,
    } = CreateOrderInput::parse(instruction_data, accounts)?;

    // The order is authenticated by its owner's signature.
    if !owner.is_signer() {
        return Err(ProgramError::MissingRequiredSignature);
    }

    process_new_onchain_order(
        program_id,
        (order_pda, &intent_bytes),
        owner.address(),
        created_by,
        false,
    )
}

/// Create a new on-chain order PDA at the specified address, with the given
/// encoded intent data, owned by the expected order, and flagged as created by
/// the specified address. `cancelled` is the order's initial state: `false` for
/// a normal creation, `true` when the order is created already cancelled.
///
/// This function performs all necessary validity checks and reverts if the
/// order has already been created before.
pub(crate) fn process_new_onchain_order(
    program_id: &Address,
    (order_pda, intent_bytes): (&AccountView, &[u8; EncodedOrderIntent::SIZE]),
    expected_owner: &Address,
    created_by: &AccountView,
    cancelled: bool,
) -> ProgramResult {
    let intent = OrderIntentAccessor::attach(intent_bytes)?;
    let intent_uid = intent.uid();

    if expected_owner.as_array() != intent.owner() {
        return Err(SettlementError::OwnerMismatch.into());
    }
    // The intent commits to how it's authenticated, and this is the on-chain
    // creation flow.
    if !intent.flags().created_on_chain {
        return Err(SettlementError::OrderCreatedOnChainMismatch.into());
    }

    let bump = CanonicalPda {
        program_id,
        payer: created_by,
        pda: order_pda,
        size: order::SIZE as u64,
        owner: program_id,
        seeds: order_pda_seeds(&intent_uid),
    }
    .create_new()?;

    // A copied `AccountView` handle writes through to the same runtime account.
    let mut order_pda = *order_pda;
    OrderAccount::initialize(
        order_pda.try_borrow_mut()?,
        bump,
        cancelled,
        0,
        0,
        created_by.address(),
        intent_bytes,
    )?;

    Ok(())
}

#[cfg(test)]
mod tests {
    use cow_settlement_interface::data::intent::fixtures::{BUY_AMOUNT_OFFSET, SELL_AMOUNT_OFFSET};
    use cow_settlement_interface::data::intent::{Flags, OrderIntent, OrderKind};
    use cow_settlement_interface::instruction::create_order::fixtures::{
        default_order_data, valid_intent_bytes, NUM_ACCOUNTS,
    };
    use cow_settlement_interface::instruction::fixtures::{
        fake_account, fake_account_from, fake_sequential_accounts,
    };
    use cow_settlement_interface::ID as PROGRAM_ID;

    use pinocchio::account::RuntimeAccount;

    use super::*;

    #[test]
    fn process_create_order_propagates_parse_error() {
        let intent_bytes = valid_intent_bytes();
        let mut data = default_order_data(&intent_bytes);
        // We generate a parse error by having less bytes than necessary.
        data.pop();
        let mut accounts = fake_sequential_accounts::<NUM_ACCOUNTS>();

        assert_eq!(
            process_create_order(&PROGRAM_ID, &mut accounts, &data),
            Err(ProgramError::InvalidInstructionData),
        );
    }

    #[test]
    fn process_create_order_rejects_invalid_encoded_intent() {
        let valid_bytes = valid_intent_bytes();
        let intent = OrderIntent::try_from(&valid_bytes).expect("should be valid");
        let intent_bytes_buy = EncodedOrderIntent::from(&OrderIntent {
            flags: Flags {
                kind: OrderKind::Buy,
                ..intent.flags
            },
            ..intent.clone()
        });
        let intent_bytes_sell = EncodedOrderIntent::from(&OrderIntent {
            flags: Flags {
                kind: OrderKind::Sell,
                ..intent.flags
            },
            ..intent
        });
        fn first_differing_byte(lhs: &[u8], rhs: &[u8]) -> Option<usize> {
            lhs.iter().zip(rhs).position(|(l, r)| l != r)
        }
        let kind_offset =
            first_differing_byte(intent_bytes_buy.as_slice(), intent_bytes_sell.as_slice())
                .expect("kind is different");

        let mut intent_bytes: [u8; EncodedOrderIntent::SIZE] = (&intent_bytes_buy).into();
        // Invalid order kind
        intent_bytes[kind_offset] = 0x42;

        let data = default_order_data(&intent_bytes);
        let mut accounts = fake_sequential_accounts::<NUM_ACCOUNTS>();
        // The owner must sign for the handler to reach intent validation; the
        // intent bytes are what's invalid here.
        accounts[0] = fake_account_from(RuntimeAccount {
            is_signer: 1,
            ..Default::default()
        });

        assert_eq!(
            process_create_order(&PROGRAM_ID, &mut accounts, &data),
            Err(ProgramError::InvalidInstructionData),
        );
    }

    #[test]
    fn process_create_order_rejects_nonsigner_owner() {
        let intent_bytes = valid_intent_bytes();
        let data = default_order_data(&intent_bytes);
        let intent: OrderIntent = (&intent_bytes).try_into().expect("should be valid");
        let owner_account = fake_account(intent.owner);

        // Test setup: owner is not a signer.
        assert!(!owner_account.is_signer());

        let mut accounts = fake_sequential_accounts::<NUM_ACCOUNTS>();
        accounts[0] = owner_account;

        assert_eq!(
            process_create_order(&PROGRAM_ID, &mut accounts, &data),
            Err(ProgramError::MissingRequiredSignature),
        );
    }

    #[test]
    fn process_create_order_rejects_owner_mismatch() {
        let intent_bytes = valid_intent_bytes();
        let data = default_order_data(&intent_bytes);
        let intent: OrderIntent = (&intent_bytes).try_into().expect("should be valid");
        let owner_runtime_account = RuntimeAccount {
            address: Address::new_from_array([0x67; 32]),
            is_signer: 1,
            ..Default::default()
        };

        // Test setup: owner doesn't match.
        assert_ne!(owner_runtime_account.address, intent.owner);

        let mut accounts = fake_sequential_accounts::<NUM_ACCOUNTS>();
        accounts[0] = fake_account_from(owner_runtime_account);

        assert_eq!(
            process_create_order(&PROGRAM_ID, &mut accounts, &data),
            Err(SettlementError::OwnerMismatch.into()),
        );
    }

    #[test]
    fn process_create_order_rejects_intent_not_created_on_chain() {
        let valid_bytes = valid_intent_bytes();
        let intent = OrderIntent::try_from(&valid_bytes).expect("should be valid");
        let intent_bytes: [u8; EncodedOrderIntent::SIZE] =
            (&EncodedOrderIntent::from(&OrderIntent { ..intent })).into();
        let data = default_order_data(&intent_bytes);
        let owner_runtime_account = RuntimeAccount {
            address: intent.owner,
            is_signer: 1,
            ..Default::default()
        };

        let mut accounts = fake_sequential_accounts::<NUM_ACCOUNTS>();
        accounts[0] = fake_account_from(owner_runtime_account);

        assert_eq!(
            process_create_order(&PROGRAM_ID, &mut accounts, &data),
            Err(SettlementError::OrderCreatedOnChainMismatch.into()),
        );
    }

    #[test]
    fn process_create_order_rejects_zero_amount() {
        // A zero amount can't be built through the NonZeroU64-typed
        // OrderIntent, so we build the wire bytes directly: a valid intent with
        // one amount slot zeroed.
        for offset in [SELL_AMOUNT_OFFSET, BUY_AMOUNT_OFFSET] {
            let mut intent_bytes = valid_intent_bytes();
            intent_bytes[offset..offset + 8].fill(0);
            let data = default_order_data(&intent_bytes);

            let mut accounts = fake_sequential_accounts::<NUM_ACCOUNTS>();
            accounts[0] = fake_account_from(RuntimeAccount {
                is_signer: 1,
                ..Default::default()
            });

            assert_eq!(
                process_create_order(&PROGRAM_ID, &mut accounts, &data),
                Err(SettlementError::ZeroOrderAmount.into()),
            );
        }
    }
}
