use {
    crate::{
        boundary,
        database::{Postgres, order_events::store_order_events},
        domain::{
            self,
            settlement::{SettlementEvent, TradeEvent, transaction::EncodedTrade},
        },
    },
    ::winner_selection::state::RankedItem,
    alloy::primitives::{Address, B256},
    anyhow::Context,
    bigdecimal::{BigDecimal, ToPrimitive},
    boundary::database::byte_array::ByteArray,
    bytes::Bytes,
    chrono::{DateTime, Utc},
    database::{
        events::EventIndex,
        leader_pg_lock::LeaderLock,
        order_events::{OrderEventLabel, OrderFilterReason},
        order_execution::Asset,
        orders::{
            BuyTokenDestination as DbBuyTokenDestination,
            SellTokenSource as DbSellTokenSource,
            SigningScheme as DbSigningScheme,
        },
        solver_competition_v2::{self, Order, Solution},
    },
    domain::{
        auction::order::{
            BuyTokenDestination as DomainBuyTokenDestination,
            SellTokenSource as DomainSellTokenSource,
            SigningScheme as DomainSigningScheme,
        },
        competition::Score,
    },
    eth_domain_types as eth,
    futures::{StreamExt, TryStreamExt},
    number::conversions::{big_decimal_to_u256, u256_to_big_decimal, u256_to_big_uint},
    shared::db_order_conversions::{fast_path_order_into_model, full_order_into_model_order},
    std::{
        collections::{HashMap, HashSet},
        ops::DerefMut,
        sync::Arc,
        time::Duration,
    },
    tokio::sync::mpsc,
    tracing::{Instrument, instrument},
};

pub mod dto;

#[derive(Clone)]
pub struct Persistence {
    s3: Option<s3::Uploader>,
    postgres: Arc<Postgres>,
    /// Writing into this channel will cause the auction to be written to the
    /// DB in an orderly manner (FIFO).
    upload_queue: mpsc::UnboundedSender<AuctionUpload>,
}

struct AuctionUpload {
    auction_id: domain::auction::Id,
    /// The serialized auction, containing everything but the auction_id.
    json: Bytes,
}

impl Persistence {
    pub async fn new(config: Option<s3::Config>, postgres: Arc<Postgres>) -> Self {
        let sender = Self::spawn_db_upload_task(postgres.clone());

        Self {
            s3: match config {
                Some(config) => Some(s3::Uploader::new(config).await),
                None => None,
            },
            postgres,
            upload_queue: sender,
        }
    }

    /// Spawns a task that writes the most recent auction to the DB. Uploads
    /// happen on a FIFO basis so the last write will always be the most
    /// recent auction.
    fn spawn_db_upload_task(db: Arc<Postgres>) -> mpsc::UnboundedSender<AuctionUpload> {
        let (sender, mut receiver) = mpsc::unbounded_channel::<AuctionUpload>();
        tokio::task::spawn(async move {
            while let Some(upload) = receiver.recv().await {
                if let Err(err) = db
                    .replace_current_auction(upload.auction_id, upload.json)
                    .await
                {
                    tracing::error!(?err, "failed to replace auction in DB");
                }
            }
            tracing::error!("auction upload task terminated unexpectedly");
        });
        sender
    }

    pub async fn leader(&self, key: String) -> LeaderLock {
        LeaderLock::new(self.postgres.pool.clone(), key, Duration::from_millis(200))
    }

    /// Fetches the ID that should be used for the next auction.
    pub async fn get_next_auction_id(&self) -> Result<domain::auction::Id, DatabaseError> {
        let _timer = Metrics::get()
            .database_queries
            .with_label_values(&["get_next_auction_id"])
            .start_timer();
        self.postgres
            .get_next_auction_id()
            .await
            .map_err(DatabaseError)
    }

    /// Archives the auction to the DB and, if configured, to S3.
    ///
    /// Only the conversion into the archival shape is on the run loop's
    /// critical path; the serialization and both sinks happen in background
    /// tasks. The auction is taken by reference so the conversion doesn't
    /// need a deep clone.
    #[instrument(skip_all)]
    pub fn archive_auction(&self, id: domain::auction::Id, auction: &domain::RawAuctionData) {
        let auction_data = {
            let _timer = observe::metrics::metrics()
                .on_auction_overhead_start("autopilot", "convert_auction");
            dto::auction::from_domain(auction)
        };

        let upload_to_s3 = !auction.orders.is_empty();
        let this = self.clone();
        let span = tracing::Span::current();
        tokio::task::spawn_blocking(move || {
            span.in_scope(|| {
                let json = match serde_json::to_vec(&auction_data).map(Bytes::from) {
                    Ok(json) => json,
                    Err(err) => {
                        tracing::error!(?err, ?id, "failed to serialize auction");
                        return;
                    }
                };

                this.upload_queue
                    .send(AuctionUpload {
                        auction_id: id,
                        json: json.clone(),
                    })
                    .expect("upload queue should be alive at all times");

                if upload_to_s3 {
                    this.upload_auction_to_s3(id, json);
                }
            })
        });
    }

    /// Spawns a background task that uploads the already serialized auction to
    /// S3.
    fn upload_auction_to_s3(&self, id: domain::auction::Id, json: Bytes) {
        let Some(s3) = self.s3.clone() else {
            return;
        };
        tokio::task::spawn(async move {
            match s3.upload_json_bytes(id.to_string(), json).await {
                Ok(key) => tracing::info!(?key, "uploaded auction to s3"),
                Err(err) => tracing::warn!(?err, "failed to upload auction to s3"),
            }
        });
    }

    /// Finds solvable orders based on the order's min validity period.
    pub async fn all_solvable_orders(
        &self,
        min_valid_to: u32,
    ) -> anyhow::Result<boundary::SolvableOrders> {
        self.postgres
            .all_solvable_orders(min_valid_to)
            .await
            .context("failed to fetch all solvable orders")
    }

    /// Save all valid solutions that participated in the competition for an
    /// auction, together with the reference score of each participating solver.
    pub async fn save_solutions(
        &self,
        auction_id: domain::auction::Id,
        solutions: impl Iterator<Item = &domain::competition::Bid>,
        reference_scores: HashMap<Address, Score>,
    ) -> Result<(), DatabaseError> {
        let _timer = Metrics::get()
            .database_queries
            .with_label_values(&["save_solutions"])
            .start_timer();

        let reference_scores: Vec<_> = reference_scores
            .into_iter()
            .map(|(solver, score)| database::reference_scores::Score {
                auction_id,
                solver: ByteArray(solver.0.0),
                reference_score: u256_to_big_decimal(&score.get().0),
            })
            .collect();

        let mut ex = self.postgres.pool.begin().await?;

        database::solver_competition_v2::save(
            &mut ex,
            auction_id,
            &solutions
                .enumerate()
                .map(|(uid, bid)| {
                    let solution = Solution {
                        uid: uid.try_into().context("uid overflow")?,
                        id: BigDecimal::from(bid.solution().id()),
                        solver: ByteArray(bid.solution().solver().0.0),
                        is_winner: bid.is_winner(),
                        filtered_out: bid.is_filtered_out(),
                        score: u256_to_big_decimal(&bid.score().get().0),
                        orders: bid
                            .solution()
                            .orders()
                            .iter()
                            .map(|(order_uid, order)| Order {
                                uid: ByteArray(order_uid.0),
                                sell_token: ByteArray(order.sell.token.into_array()),
                                buy_token: ByteArray(order.buy.token.into_array()),
                                limit_sell: u256_to_big_decimal(&order.sell.amount.0),
                                limit_buy: u256_to_big_decimal(&order.buy.amount.0),
                                executed_sell: u256_to_big_decimal(&order.executed_sell.0),
                                executed_buy: u256_to_big_decimal(&order.executed_buy.0),
                                side: order.side.into(),
                            })
                            .collect(),
                        price_tokens: vec![],
                        price_values: vec![],
                    };
                    Ok::<_, DatabaseError>(solution)
                })
                .collect::<Result<Vec<_>, DatabaseError>>()?,
        )
        .await?;

        database::reference_scores::insert(&mut ex, &reference_scores).await?;

        Ok(ex.commit().await?)
    }

    /// Inserts an order event for each order uid in the given set.
    /// Unique order uids are required to avoid inserting events with the same
    /// label within the same order_uid. If this function encounters an error it
    /// will only be printed. More elaborate error handling is not necessary
    /// because this is just debugging information.
    pub fn store_order_events(
        &self,
        order_uids: impl IntoIterator<Item = domain::OrderUid>,
        label: boundary::OrderEventLabel,
    ) {
        let order_uids: Vec<_> = order_uids.into_iter().collect();
        self.store_order_events_owned(order_uids, std::convert::identity, label, None);
    }

    /// A variants of [`store_order_events`] where [`items`] is already an owned
    /// collection which allows us to move the logic to convert an item to a
    /// [`domain::OrderUid`] into the background task as well.
    #[instrument(skip_all)]
    pub fn store_order_events_owned<I, F>(
        &self,
        items: I,
        convert: F,
        label: boundary::OrderEventLabel,
        reason: Option<OrderFilterReason>,
    ) where
        I: IntoIterator + Send + 'static,
        I::IntoIter: Send,
        I::Item: Send,
        F: (Fn(I::Item) -> domain::OrderUid) + Send + 'static,
    {
        let db = self.postgres.clone();
        tokio::spawn(
            async move {
                let order_uids = items.into_iter().map(convert);
                match db.pool.acquire().await {
                    Ok(mut tx) => {
                        store_order_events(&mut tx, order_uids, label, reason, Utc::now()).await;
                    }
                    Err(err) => {
                        tracing::error!(
                            ?err,
                            "failed to acquire a connection to store order events!"
                        );
                    }
                };
            }
            .instrument(tracing::Span::current()),
        );
    }

    /// Saves the given fee policies to the DB as a single batch.
    pub async fn store_fee_policies(
        &self,
        auction_id: domain::auction::Id,
        fee_policies: Vec<(domain::OrderUid, Vec<domain::fee::Policy>)>,
    ) -> anyhow::Result<()> {
        let _timer = Metrics::get()
            .database_queries
            .with_label_values(&["store_fee_policies"])
            .start_timer();

        let mut ex = self.postgres.pool.begin().await.context("begin")?;
        for chunk in fee_policies.chunks(self.postgres.config.insert_batch_size.get()) {
            crate::database::fee_policies::insert_batch(&mut ex, auction_id, chunk.iter().cloned())
                .await
                .context("fee_policies::insert_batch")?;
        }

        ex.commit().await.context("commit")
    }

    /// Tries to find the transaction executing a given solution proposed
    /// by the solver.
    pub async fn find_settlement_transaction(
        &self,
        auction_id: i64,
        solver: eth::Address,
        solution_uid: usize,
    ) -> Result<Option<eth::TxId>, DatabaseError> {
        let _timer = Metrics::get()
            .database_queries
            .with_label_values(&["find_settlement_transaction"])
            .start_timer();

        let mut ex = self.postgres.pool.acquire().await.context("acquire")?;
        Ok(database::settlements::find_settlement_transaction(
            &mut ex,
            auction_id,
            ByteArray(solver.0.0),
            solution_uid
                .try_into()
                .context("could not convert solution id to i64")?,
        )
        .await?
        .map(|hash| B256::new(hash.0).into()))
    }

    /// Save auction related data to the database.
    pub async fn save_auction(
        &self,
        auction: &domain::Auction,
        deadline: u64, // to become part of the auction struct
    ) -> Result<(), DatabaseError> {
        let _timer = Metrics::get()
            .database_queries
            .with_label_values(&["save_auction"])
            .start_timer();

        let mut ex = self.postgres.pool.acquire().await?;

        database::auction::save(
            &mut ex,
            database::auction::Auction {
                id: auction.id,
                block: i64::try_from(auction.block).context("block overflow")?,
                deadline: i64::try_from(deadline).context("deadline overflow")?,
                order_uids: auction
                    .orders
                    .iter()
                    .map(|order| ByteArray(order.uid.0))
                    .collect(),
                price_tokens: auction
                    .prices
                    .keys()
                    .map(|token| ByteArray(token.into_array()))
                    .collect(),
                price_values: auction
                    .prices
                    .values()
                    .map(|price| u256_to_big_decimal(&price.get().0))
                    .collect(),
                surplus_capturing_jit_order_owners: auction
                    .surplus_capturing_jit_order_owners
                    .iter()
                    .map(|owner| ByteArray(owner.0.0))
                    .collect(),
                // Mapped one-to-one with `order_uids` above; all-or-nothing
                // because caps are computed for every order iff penalties are
                // enabled.
                penalty_caps_native: auction
                    .orders
                    .iter()
                    .map(|order| {
                        order
                            .penalty_cap_native
                            .map(|cap| u256_to_big_decimal(&cap.0))
                    })
                    .collect(),
            },
        )
        .await?;

        // Inserting into `competition_auctions` grows the pending list of its
        // GIN index, which periodically causes DB latency spikes. Clean
        // it right where the need originates, without blocking auction
        // post-processing.
        let postgres = self.postgres.clone();
        tokio::spawn(async move {
            if let Err(err) = postgres.gin_clean_pending_list().await {
                tracing::warn!(?err, "failed to clean gin pending list");
            }
        });

        Ok(())
    }

    /// Get auction data to post-process the given trades.
    pub async fn get_auction(
        &self,
        auction_id: domain::auction::Id,
        trades: &[EncodedTrade],
    ) -> Result<domain::settlement::Auction, error::Auction> {
        let _timer = Metrics::get()
            .database_queries
            .with_label_values(&["get_auction"])
            .start_timer();

        let mut ex = self
            .postgres
            .pool
            .begin()
            .await
            .map_err(error::Auction::DatabaseError)?;

        let auction_row = database::auction::fetch(&mut ex, auction_id)
            .await
            .map_err(error::Auction::DatabaseError)?
            .ok_or(error::Auction::NotFound)?;

        let surplus_capturing_jit_order_owners = auction_row
            .surplus_capturing_jit_order_owners
            .into_iter()
            .map(|owner| eth::Address::new(owner.0))
            .collect();

        let prices = auction_row
            .price_tokens
            .into_iter()
            .zip(auction_row.price_values)
            .map(|(token, price)| {
                let token = eth::Address::new(token.0).into();
                let price = big_decimal_to_u256(&price)
                    .ok_or(domain::auction::InvalidPrice)
                    .and_then(|p| domain::auction::Price::try_new(p.into()))
                    .map_err(|_err| error::Auction::InvalidPrice(token));
                price.map(|price| (token, price))
            })
            .collect::<Result<_, _>>()?;

        let block = u64::try_from(auction_row.block)
            .map_err(|_| error::Auction::NotFound)?
            .into();

        let orders = {
            // Code that uses the data assembled by this function determines JIT
            // orders by their presence in the `orders =>
            // fee_policies` mapping. If an order has a mapping it
            // is assumed that this was a regular order and not a JIT order.
            // So in order to not misclassify JIT orders as regular orders we
            // only fetch fee policies for orders that were part of
            // the original auction.
            let auction_orders: HashSet<domain::OrderUid> = auction_row
                .order_uids
                .into_iter()
                .map(|order| domain::OrderUid(order.0))
                .collect();
            let relevant_orders: HashSet<_> = trades
                .iter()
                .filter(|t| auction_orders.contains(&t.uid))
                .map(|t| t.uid)
                .collect();

            // get fee policies for all orders that were part of the competition
            // auction
            let fee_policies = database::fee_policies::fetch_all(
                &mut ex,
                relevant_orders
                    .iter()
                    .map(|o| (auction_id, ByteArray(o.0)))
                    .collect::<Vec<_>>()
                    .as_slice(),
            )
            .await
            .map_err(error::Auction::DatabaseError)?
            .into_iter()
            .map(|((_, order), policies)| (domain::OrderUid(order.0), policies))
            .collect::<HashMap<_, _>>();

            // get quotes for all orders with PriceImprovement fee policy
            let quotes = self
                .postgres
                .read_quotes(fee_policies.iter().filter_map(|(order_uid, policies)| {
                    policies
                        .iter()
                        .any(|policy| {
                            matches!(
                                policy.kind,
                                database::fee_policies::FeePolicyKind::PriceImprovement
                            )
                        })
                        .then_some(order_uid)
                }))
                .await
                .map_err(error::Auction::DatabaseError)?;

            // compile order data
            let mut orders = HashMap::new();
            for order in relevant_orders.iter() {
                let order_policies = match fee_policies.get(order) {
                    Some(policies) => policies
                        .iter()
                        .cloned()
                        .map(|policy| {
                            dto::fee_policy::try_into_domain(policy, quotes.get(order))
                                .map_err(|err| error::Auction::InvalidFeePolicy(err, *order))
                        })
                        .collect::<Result<Vec<_>, _>>()?,
                    None => vec![],
                };
                orders.insert(*order, order_policies);
            }
            orders
        };

        Ok(domain::settlement::Auction {
            id: auction_id,
            block,
            orders,
            prices,
            surplus_capturing_jit_order_owners,
        })
    }

    /// Computes solvable orders based on the latest observed block number,
    /// order creation timestamp, and minimum validity period.
    pub async fn solvable_orders_after(
        &self,
        mut current_orders: HashMap<domain::OrderUid, Arc<model::order::Order>>,
        mut current_quotes: HashMap<domain::OrderUid, Arc<domain::Quote>>,
        after_timestamp: DateTime<Utc>,
        after_block: u64,
        min_valid_to: u32,
    ) -> anyhow::Result<boundary::SolvableOrders> {
        tracing::debug!(?after_timestamp, ?after_block, "fetch orders updated since");
        let after_block = i64::try_from(after_block).context("block number value exceeds i64")?;
        let started_at = chrono::offset::Utc::now();
        let mut tx = self.postgres.pool.begin().await.context("begin")?;
        // Set the transaction isolation level to REPEATABLE READ
        // so all the SELECT queries below are executed in the same database
        // snapshot taken at the moment before the first query is
        // executed.
        sqlx::query("SET TRANSACTION ISOLATION LEVEL REPEATABLE READ")
            .execute(tx.deref_mut())
            .await?;

        // Find order uids for orders that were updated after the given block.
        let updated_order_uids = {
            let _timer = Metrics::get()
                .database_queries
                .with_label_values(&["updated_order_uids"])
                .start_timer();

            database::orders::updated_order_uids_after(&mut tx, after_block).await?
        };

        // Fetch the orders that were updated after the given block and were
        // created or cancelled after the given timestamp.
        let next_orders: HashMap<domain::OrderUid, Arc<model::order::Order>> = {
            let _timer = Metrics::get()
                .database_queries
                .with_label_values(&["open_orders_after"])
                .start_timer();

            database::orders::open_orders_by_time_or_uids(
                &mut tx,
                &updated_order_uids,
                after_timestamp,
                started_at.timestamp(),
            )
            .map(|result| match result {
                Ok(order) => full_order_into_model_order(order)
                    .map(|order| (domain::OrderUid(order.metadata.uid.0), Arc::new(order))),
                Err(err) => Err(anyhow::Error::from(err)),
            })
            .try_collect()
            .await?
        };

        let latest_settlement_block = database::orders::latest_settlement_block(&mut tx)
            .await?
            .to_u64()
            .context("latest_settlement_block is not u64")?;

        // Insert new / updated orders or remove invalidated orders
        // and the associated quote.
        for (uid, order) in next_orders {
            let invalidated = order.metadata.invalidated;
            let onchain_error = order
                .metadata
                .onchain_order_data
                .as_ref()
                .is_some_and(|data| data.placement_error.is_some());
            let fulfilled = {
                match order.data.kind {
                    model::order::OrderKind::Sell => {
                        order.metadata.executed_sell_amount
                            >= u256_to_big_uint(&order.data.sell_amount)
                    }
                    model::order::OrderKind::Buy => {
                        order.metadata.executed_buy_amount
                            >= u256_to_big_uint(&order.data.buy_amount)
                    }
                }
            };

            if invalidated || onchain_error || fulfilled {
                current_orders.remove(&uid);
                current_quotes.remove(&uid);
            } else {
                current_orders.insert(uid, order);
            }
        }

        // Filter out all the expired orders and their quotes.
        current_orders.retain(|uid, order| {
            let expired = order.data.valid_to < min_valid_to
                || order
                    .metadata
                    .ethflow_data
                    .as_ref()
                    .is_some_and(|data| data.user_valid_to < i64::from(min_valid_to));

            if expired {
                current_quotes.remove(uid);
                false
            } else {
                true
            }
        });

        {
            let _timer = Metrics::get()
                .database_queries
                .with_label_values(&["read_quotes"])
                .start_timer();

            // Fetch quotes only for newly created and also on-chain placed
            // orders due to the following case: if a block
            // containing an on-chain order (e.g., ethflow) gets
            // reorganized, the same order with the same
            // UID might be created in the new block, and the temporary quote
            // associated with it may have changed in the meantime.
            let order_uids = current_orders
                .values()
                .filter_map(|order| {
                    (order.metadata.onchain_user.is_some()
                        || order.metadata.creation_date > after_timestamp)
                        .then_some(ByteArray(order.metadata.uid.0))
                })
                .collect::<Vec<_>>();

            for quote in database::orders::read_quotes(&mut tx, &order_uids).await? {
                let order_uid = domain::OrderUid(quote.order_uid.0);
                match dto::quote::into_domain(quote) {
                    Ok(quote) => {
                        current_quotes.insert(order_uid, Arc::new(quote));
                    }
                    Err(err) => tracing::warn!(?order_uid, ?err, "failed to convert quote from db"),
                }
            }
        };

        Ok(boundary::SolvableOrders {
            orders: current_orders,
            quotes: current_quotes,
            latest_settlement_block,
            fetched_from_db: started_at,
        })
    }

    /// Returns the oldest settlement event for which the accociated auction is
    /// not yet populated in the database.
    pub async fn get_settlements_without_auction(
        &self,
    ) -> Result<Vec<SettlementEvent>, DatabaseError> {
        let _timer = Metrics::get()
            .database_queries
            .with_label_values(&["get_settlement_without_auction"])
            .start_timer();

        let mut ex = self.postgres.pool.acquire().await?;
        let events = database::settlements::get_settlements_without_auction(&mut ex)
            .await?
            .into_iter()
            .map(|event| {
                let event = SettlementEvent {
                    block: u64::try_from(event.block_number)
                        .context("negative block")?
                        .into(),
                    log_index: u64::try_from(event.log_index).context("negative log index")?,
                    transaction: eth::TxId(B256::new(event.tx_hash.0)),
                };
                Ok::<_, DatabaseError>(event)
            })
            .collect::<Result<Vec<_>, _>>()?;
        Ok(events)
    }

    /// Returns the trade events that are associated with the settlement event
    pub async fn get_trades_for_settlement(
        &self,
        settlement: &SettlementEvent,
    ) -> Result<Vec<TradeEvent>, DatabaseError> {
        let _timer = Metrics::get()
            .database_queries
            .with_label_values(&["get_trades_for_settlement"])
            .start_timer();

        let mut ex = self.postgres.pool.acquire().await?;
        database::trades::get_trades_for_settlement(
            &mut ex,
            EventIndex {
                block_number: i64::try_from(settlement.block.0).context("block overflow")?,
                log_index: i64::try_from(settlement.log_index).context("log index overflow")?,
            },
        )
        .await?
        .into_iter()
        .map(|event| {
            let event = TradeEvent {
                block: u64::try_from(event.block_number)
                    .context("negative block")?
                    .into(),
                log_index: u64::try_from(event.log_index).context("negative log index")?,
                order_uid: domain::OrderUid(event.order_uid.0).into(),
            };
            Ok::<_, DatabaseError>(event)
        })
        .collect()
    }

    pub async fn save_settlement(
        &self,
        event: SettlementEvent,
        settlement: Option<&domain::settlement::Settlement>,
    ) -> Result<(), DatabaseError> {
        let _timer = Metrics::get()
            .database_queries
            .with_label_values(&["save_settlement"])
            .start_timer();

        let mut ex = self.postgres.pool.begin().await?;

        let block_number = i64::try_from(event.block.0).context("block overflow")?;
        let log_index = i64::try_from(event.log_index).context("log index overflow")?;
        let auction_id = settlement.map(|s| s.auction_id()).unwrap_or_default();
        tracing::debug!(hash = ?event.transaction, ?auction_id, "saving settlement details for tx");

        database::settlements::update_settlement_auction(
            &mut ex,
            block_number,
            log_index,
            auction_id,
        )
        .await?;

        if let Some(settlement) = settlement {
            let domain::settlement::SettlementMetrics {
                gas,
                gas_price,
                surplus,
                fee,
                fee_breakdown,
                jit_orders,
            } = settlement.summarize();
            let solver: database::Address = ByteArray(settlement.solver().0.0);

            tracing::debug!(
                ?auction_id,
                hash = ?event.transaction,
                ?solver,
                ?gas,
                ?gas_price,
                ?surplus,
                ?fee,
                ?fee_breakdown,
                ?jit_orders,
                "settlement update",
            );

            database::settlements::update_settlement_solver_and_gas(
                &mut ex,
                block_number,
                log_index,
                solver,
                settlement.solution_uid(),
                // We're not expecting this to actually happen, BUT, since this is the cost of a
                // transaction we'll double count this value if 1 transaction has 2 settlements
                u256_to_big_decimal(&gas.0),
                u256_to_big_decimal(&gas_price.0.0),
            )
            .await?;

            database::trades::attribute_gas_cost(
                &mut ex,
                EventIndex {
                    block_number,
                    log_index,
                },
                u256_to_big_decimal(&gas.0),
                u256_to_big_decimal(&gas_price.0.0),
                &settlement
                    .surplus_capturing_jit_order_owners()
                    .iter()
                    .map(|owner| ByteArray(owner.0.0))
                    .collect::<Vec<_>>(),
            )
            .await?;

            store_order_events(
                &mut ex,
                fee_breakdown.keys().cloned(),
                OrderEventLabel::Traded,
                None,
                Utc::now(),
            )
            .await;

            for (order, order_fee) in fee_breakdown {
                database::order_execution::save(
                    &mut ex,
                    &ByteArray(order.0),
                    auction_id,
                    block_number,
                    Asset {
                        token: ByteArray(order_fee.total.token.into_array()),
                        amount: u256_to_big_decimal(&order_fee.total.amount.0),
                    },
                    &order_fee
                        .protocol
                        .into_iter()
                        .map(|executed| Asset {
                            token: ByteArray(executed.fee.token.into_array()),
                            amount: u256_to_big_decimal(&executed.fee.amount.0),
                        })
                        .collect::<Vec<_>>(),
                )
                .await?;
            }

            if !jit_orders.is_empty() {
                // each jit order should have a corresponding trade event, try
                // to find them
                let trade_events = self
                    .get_trades_for_settlement(&event)
                    .await?
                    .into_iter()
                    .map(|event| (event.order_uid, (event.block, event.log_index)))
                    .collect::<HashMap<_, (_, _)>>();

                database::jit_orders::insert(
                    &mut ex,
                    &jit_orders
                        .into_iter()
                        .filter_map(|jit_order| match trade_events.get(&jit_order.uid.into()) {
                            Some((block_number, log_index)) => {
                                Some(database::jit_orders::JitOrder {
                                    block_number: i64::try_from(block_number.0).ok()?,
                                    log_index: i64::try_from(*log_index).ok()?,
                                    uid: ByteArray(jit_order.uid.0),
                                    owner: ByteArray(jit_order.uid.owner().0.0),
                                    creation_timestamp: chrono::DateTime::from_timestamp(
                                        i64::from(jit_order.created),
                                        0,
                                    )
                                        .unwrap_or_default(),
                                    sell_token: ByteArray(jit_order.sell.token.into_array()),
                                    buy_token: ByteArray(jit_order.buy.token.into_array()),
                                    sell_amount: u256_to_big_decimal(&jit_order.sell.amount.0),
                                    buy_amount: u256_to_big_decimal(&jit_order.buy.amount.0),
                                    valid_to: i64::from(jit_order.valid_to),
                                    app_data: ByteArray(jit_order.app_data.0),
                                    fee_amount: u256_to_big_decimal(&jit_order.fee_amount.0),
                                    kind: jit_order.side.into(),
                                    partially_fillable: jit_order.partially_fillable,
                                    signature: jit_order.signature.to_bytes(),
                                    receiver: ByteArray(*jit_order.receiver.raw_bytes()),
                                    signing_scheme: match jit_order.signature.scheme() {
                                        DomainSigningScheme::Eip712 => DbSigningScheme::Eip712,
                                        DomainSigningScheme::EthSign => DbSigningScheme::EthSign,
                                        DomainSigningScheme::Eip1271 => DbSigningScheme::Eip1271,
                                        DomainSigningScheme::PreSign => DbSigningScheme::PreSign,
                                    },
                                    sell_token_balance: match jit_order.sell_token_balance {
                                        DomainSellTokenSource::Erc20 => DbSellTokenSource::Erc20,
                                        DomainSellTokenSource::External => {
                                            DbSellTokenSource::External
                                        }
                                        DomainSellTokenSource::Internal => {
                                            DbSellTokenSource::Internal
                                        }
                                    },
                                    buy_token_balance: match jit_order.buy_token_balance {
                                        DomainBuyTokenDestination::Erc20 => {
                                            DbBuyTokenDestination::Erc20
                                        }
                                        DomainBuyTokenDestination::Internal => {
                                            DbBuyTokenDestination::Internal
                                        }
                                    },
                                })
                            }
                            None => {
                                tracing::warn!(order_uid = ?jit_order.uid, "missing trade event for jit order");
                                None
                            }
                        })
                        .collect::<Vec<_>>(),
                )
                    .await?;
            }
        }

        ex.commit().await?;
        Ok(())
    }

    pub async fn store_settlement_execution_started(
        &self,
        event: domain::settlement::ExecutionStarted,
    ) -> Result<(), DatabaseError> {
        let mut ex = self.postgres.pool.acquire().await.context("acquire")?;
        let _timer = Metrics::get()
            .database_queries
            .with_label_values(&["insert_settlement_execution_event"])
            .start_timer();

        database::settlement_executions::insert(
            &mut ex,
            event.auction_id,
            ByteArray(event.solver.0.0),
            event
                .solution_uid
                .try_into()
                .context("solution uid overflow")?,
            event.start_timestamp,
            event
                .start_block
                .try_into()
                .context("start block overflow")?,
            event
                .deadline_block
                .try_into()
                .context("deadline block overflow")?,
        )
        .await?;

        Ok(())
    }

    pub async fn store_settlement_execution_ended(
        &self,
        event: domain::settlement::ExecutionEnded,
    ) -> Result<(), DatabaseError> {
        let mut ex = self.postgres.pool.acquire().await.context("acquire")?;
        let _timer = Metrics::get()
            .database_queries
            .with_label_values(&["update_settlement_execution_event"])
            .start_timer();

        database::settlement_executions::update(
            &mut ex,
            event.auction_id,
            ByteArray(event.solver.0.0),
            event
                .solution_uid
                .try_into()
                .context("solution uid overflow")?,
            event.end_timestamp,
            event.end_block.try_into().context("end block overflow")?,
            event.outcome,
        )
        .await?;

        Ok(())
    }

    pub async fn get_solver_winning_solutions(
        &self,
        auction_id: domain::auction::Id,
        solver: eth::Address,
    ) -> Result<Vec<Solution>, DatabaseError> {
        let mut ex = self.postgres.pool.acquire().await.context("acquire")?;
        let _timer = Metrics::get()
            .database_queries
            .with_label_values(&["fetch_solver_winning_solutions"])
            .start_timer();

        Ok(
            database::solver_competition_v2::fetch_solver_winning_solutions(
                &mut ex,
                auction_id,
                ByteArray(solver.0.0),
            )
            .await
            .context("solver_competition::fetch_solver_winning_solutions")?,
        )
    }

    /// Fetches orders which are currently inflight. Those orders should
    /// be omitted from the current auction to avoid onchain reverts.
    #[instrument(skip_all)]
    pub async fn fetch_in_flight_orders(
        &self,
        current_block: u64,
    ) -> anyhow::Result<HashSet<crate::domain::OrderUid>> {
        let _timer = Metrics::get()
            .database_queries
            .with_label_values(&["inflight_orders"])
            .start_timer();

        let mut ex = self.postgres.pool.acquire().await.context("acquire")?;
        let orders =
            solver_competition_v2::fetch_in_flight_orders(&mut ex, current_block.cast_signed())
                .await?;
        Ok(orders
            .into_iter()
            .map(|o| crate::domain::OrderUid(o.0))
            .collect())
    }

    /// Sets `orders.valid_from` for a fast-path order the handler has
    /// classified. Writing this column is what makes the order eligible
    /// for the solvable-orders cache — either immediately (`now`, when
    /// fast-path settle isn't going to fire) or delayed by the
    /// exclusivity window.
    #[instrument(skip_all)]
    pub async fn set_order_valid_from(
        &self,
        uid: domain::OrderUid,
        valid_from: u32,
    ) -> anyhow::Result<()> {
        let _timer = Metrics::get()
            .database_queries
            .with_label_values(&["set_order_valid_from"])
            .start_timer();
        let mut ex = self.postgres.pool.acquire().await.context("acquire")?;
        database::orders::set_valid_from(&mut ex, &ByteArray(uid.0), valid_from).await?;
        Ok(())
    }

    /// Bulk-flushes fast-path orders whose `valid_from` was never
    /// populated: their `new_order` notification landed while the
    /// autopilot was down, and by the time it comes back the intended
    /// exclusivity window has long since elapsed. Running the full
    /// fast-path against a stale quote would just settle against
    /// moved on-chain prices, so we drop them straight into the next
    /// regular auction by setting `valid_from = now`. Returns the
    /// number of rows updated.
    pub async fn flush_pending_fast_path_backlog(&self, now: u32) -> anyhow::Result<u64> {
        let _timer = Metrics::get()
            .database_queries
            .with_label_values(&["flush_pending_fast_path_backlog"])
            .start_timer();
        let mut ex = self.postgres.pool.acquire().await.context("acquire")?;
        Ok(database::orders::flush_pending_fast_path_backlog(&mut ex, now).await?)
    }

    /// Returns the order iff it is a fast-path order the handler still
    /// owes a `valid_from` write to. Callers use `Some` as the "we own
    /// this order" signal — non-fast-path orders (or ones the handler
    /// already classified) return `None` and must be left alone.
    ///
    /// [`FastPathOrder::staged`] carries the staged quote competition
    /// when one exists; ethflow fast-path orders that never went
    /// through the quoter return `None` there, meaning no
    /// out-of-competition settle is possible and the caller should just
    /// mark the order eligible for the regular auction.
    #[instrument(skip_all)]
    pub async fn pending_fast_path_order(
        &self,
        uid: domain::OrderUid,
    ) -> anyhow::Result<Option<FastPathOrder>> {
        let _timer = Metrics::get()
            .database_queries
            .with_label_values(&["pending_fast_path_order"])
            .start_timer();

        let row = {
            let mut ex = self.postgres.pool.acquire().await.context("acquire")?;
            database::fast_path::pending_fast_path_order(&mut ex, &ByteArray(uid.0)).await?
        };

        let Some(pending) = row else {
            return Ok(None);
        };

        let model_order = fast_path_order_into_model(&pending)?;
        let staged = match (pending.quote_id, pending.competition) {
            (Some(quote_id), Some(competition)) => Some(StagedFastPathCompetition {
                quote_id,
                data: serde_json::from_value(competition)
                    .context("deserialize staged quote competition")?,
            }),
            // The LEFT JOIN returns both columns as NULL together — no
            // staged data means no fast-path settle is possible.
            _ => None,
        };
        Ok(Some(FastPathOrder {
            model_order,
            staged,
        }))
    }

    /// Moves a fast-path order's staged competition into the permanent
    /// tables. In a single transaction, writes `competition_auctions`,
    /// the pre-built `proposed_solutions` / `proposed_trade_executions`
    /// rows carried on the [`FastPathPromotion`], its fee-policy rows, and
    /// deletes the `quote_competitions` staging row.
    ///
    /// All fee math and per-solution encoding decisions are done by the
    /// caller (`fast_path.rs`) — this function only stitches the caller's
    /// domain values into the surrounding DB rows and inserts everything
    /// atomically.
    pub async fn finalize_fast_path(&self, promotion: FastPathPromotion) -> anyhow::Result<()> {
        let _timer = Metrics::get()
            .database_queries
            .with_label_values(&["finalize_fast_path"])
            .start_timer();

        let (price_tokens, price_values): (Vec<_>, Vec<_>) = promotion
            .native_prices
            .iter()
            .map(|(token, value)| (ByteArray(token.0.0), u256_to_big_decimal(value)))
            .unzip();

        let auction_row = database::auction::Auction {
            id: promotion.auction_id,
            block: i64::try_from(promotion.block).context("block does not fit in i64")?,
            deadline: i64::try_from(promotion.deadline).context("deadline does not fit in i64")?,
            order_uids: vec![ByteArray(promotion.order_uid.0)],
            price_tokens,
            price_values,
            surplus_capturing_jit_order_owners: Vec::new(),
            penalty_caps_native: Some(vec![promotion.penalty_cap_native]),
        };

        let policy_rows: Vec<_> = promotion
            .fee_policies
            .iter()
            .map(|p| dto::fee_policy::from_domain(promotion.auction_id, promotion.order_uid, *p))
            .collect();

        let mut tx = self.postgres.pool.begin().await.context("begin")?;
        database::auction::save(tx.deref_mut(), auction_row)
            .await
            .context("save competition_auctions row")?;
        database::solver_competition_v2::save(&mut tx, promotion.auction_id, &promotion.solutions)
            .await
            .context("save proposed_solutions / proposed_trade_executions")?;
        database::reference_scores::insert(&mut tx, &[promotion.reference_score])
            .await
            .context("insert fast-path reference_scores")?;
        database::fee_policies::insert_batch(tx.deref_mut(), policy_rows)
            .await
            .context("insert fast-path fee policies")?;
        database::fast_path::delete_competition(tx.deref_mut(), promotion.quote_id)
            .await
            .context("delete quote_competitions staging row")?;
        database::orders::set_valid_from(
            tx.deref_mut(),
            &ByteArray(promotion.order_uid.0),
            promotion.valid_from,
        )
        .await
        .context("set valid_from")?;
        tx.commit().await.context("commit")?;
        Ok(())
    }
}

/// A pending fast-path order the handler has fetched. `staged` is
/// present when the order went through the API quoter (and can
/// therefore be settled out of competition); ethflow fast-path orders
/// arrive with `staged = None` and fall straight through to the regular
/// auction.
#[derive(Debug)]
pub struct FastPathOrder {
    /// The order in the raw API model form. Callers pass this to
    /// `ProtocolFees::apply` and can then convert it to `domain::Order` via
    /// `boundary::order::to_domain` once the resulting policies are known.
    pub model_order: model::order::Order,
    /// Staged quote competition, when one is available.
    pub staged: Option<StagedFastPathCompetition>,
}

/// The staged quote competition produced when the fast-path order was
/// quoted. Carries the `quote_id` back to `finalize_fast_path` so the
/// staging row can be dropped atomically with the promotion.
#[derive(Debug)]
pub struct StagedFastPathCompetition {
    pub quote_id: database::quotes::QuoteId,
    pub data: shared::quote_storage::StagedQuoteCompetition,
}

impl StagedFastPathCompetition {
    /// The winning solution. Non-empty by construction of
    /// `save_quote_competition`, which bails out when no quotes were
    /// produced.
    pub fn winner(&self) -> &shared::quote_storage::StagedSolution {
        self.data
            .solutions
            .first()
            .expect("staged competition is guaranteed to have at least one solution")
    }
}

/// All the data needed to finalize a fast path order. The finalization happens
/// by promoting the data that was so far only in the temporary
/// `quote_competitions` table into the persistent tables that describe the
/// usual auctions (e.g. `competition_auctions`, `proposed_solutions`, etc.).
pub struct FastPathPromotion {
    pub quote_id: database::quotes::QuoteId,
    pub auction_id: database::auction::AuctionId,
    pub order_uid: domain::OrderUid,
    /// Block and deadline recorded on the promoted competition row — the
    /// window the fast-path handler committed to when asking the driver to
    /// settle.
    pub block: u64,
    pub deadline: u64,
    /// Unix timestamp (seconds) the order becomes eligible for the
    /// regular auction if the fast-path settle attempt doesn't land in
    /// time. Written atomically with the rest of the promotion so the
    /// order can never be observed "settle-committed, exclusivity not
    /// claimed" from another connection.
    pub valid_from: u32,
    pub native_prices: HashMap<eth::Address, eth::U256>,
    /// Fully-built solver-competition rows (one per staged solution).
    /// Constructed by the caller so per-bid encoding decisions —
    /// `filtered_out`, score, executed amounts — live in the domain
    /// handler rather than here.
    pub solutions: Vec<database::solver_competition_v2::Solution>,
    pub fee_policies: Vec<domain::fee::Policy>,
    pub reference_score: database::reference_scores::Score,
    /// Cap of the penalty the solver will get for not executing the order.
    /// Denominated in the native token.
    pub penalty_cap_native: BigDecimal,
}

#[derive(prometheus_metric_storage::MetricStorage)]
struct Metrics {
    /// Timing of db queries.
    #[metric(name = "persistence_database_queries", labels("type"))]
    database_queries: prometheus::HistogramVec,
}

impl Metrics {
    fn get() -> &'static Self {
        Metrics::instance(observe::metrics::get_storage_registry()).unwrap()
    }
}

#[derive(Debug, thiserror::Error)]
#[error("failed communication with the database")]
pub struct DatabaseError(#[from] pub anyhow::Error);

impl From<sqlx::Error> for DatabaseError {
    fn from(err: sqlx::Error) -> Self {
        Self(err.into())
    }
}

pub mod error {
    use super::*;

    #[derive(Debug, thiserror::Error)]
    pub enum Auction {
        #[error("failed communication with the database: {0}")]
        DatabaseError(#[from] sqlx::Error),
        #[error("auction not found")]
        NotFound,
        #[error("invalid fee policy fetched from database: {0} for order: {1}")]
        InvalidFeePolicy(dto::fee_policy::Error, domain::OrderUid),
        #[error("invalid price fetched from database for token: {0:?}")]
        InvalidPrice(eth::TokenAddress),
    }
}
