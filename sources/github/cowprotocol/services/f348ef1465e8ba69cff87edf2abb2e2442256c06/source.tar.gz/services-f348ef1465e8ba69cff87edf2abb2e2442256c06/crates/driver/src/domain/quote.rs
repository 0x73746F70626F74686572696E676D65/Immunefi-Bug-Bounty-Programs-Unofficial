use {
    super::competition::{Competition, auction, solution},
    crate::{
        boundary,
        domain::{
            self,
            competition::{self, order},
            liquidity,
            time,
        },
        infra::{
            self,
            blockchain::{self, Ethereum},
            solver::{self, Solver},
        },
        util,
    },
    chrono::Utc,
    eth_domain_types as eth,
    std::collections::{HashMap, HashSet},
};

/// A quote describing the expected outcome of an order.
#[derive(derive_more::Debug)]
pub struct Quote {
    pub clearing_prices: HashMap<eth::Address, eth::U256>,
    #[debug(ignore)]
    pub pre_interactions: Vec<domain::Interaction>,
    #[debug(ignore)]
    pub interactions: Vec<domain::Interaction>,
    pub solver: eth::Address,
    pub gas: Option<eth::Gas>,
    /// Which `tx.origin` is required to make the quote simulation pass.
    #[debug(ignore)]
    pub tx_origin: Option<eth::Address>,
    #[debug(ignore)]
    pub jit_orders: Vec<solution::trade::Jit>,
}

impl Quote {
    fn try_new(eth: &Ethereum, solution: &competition::Solution) -> Result<Self, Error> {
        let clearing_prices = Self::compute_clearing_prices(solution)?;

        Ok(Self {
            clearing_prices,
            pre_interactions: solution.pre_interactions().to_vec(),
            interactions: solution
                .interactions()
                .iter()
                .map(|i| encode::interaction(i, eth.contracts().settlement().address()))
                .collect::<Result<Vec<_>, _>>()?
                .into_iter()
                .flatten()
                .collect(),
            solver: solution.solver().address(),
            gas: solution.gas(),
            tx_origin: *solution.solver().quote_tx_origin(),
            jit_orders: solution
                .trades()
                .iter()
                .filter_map(|trade| match trade {
                    solution::Trade::Jit(jit) => Some(jit.clone()),
                    _ => None,
                })
                .collect(),
        })
    }

    /// Compute clearing prices for the quote.
    ///
    /// Uses uniform clearing prices from the solution. If the quoted order
    /// carries fee policies (e.g. an injected solver fee, see
    /// [`Solver::solver_fee`]), the pair's prices are replaced with the
    /// trade's custom prices, which include the effect of those policies as
    /// applied by the regular protocol fee machinery when the solution was
    /// formed.
    fn compute_clearing_prices(
        solution: &competition::Solution,
    ) -> Result<HashMap<eth::Address, eth::U256>, Error> {
        // Start with uniform clearing prices
        let mut prices: HashMap<eth::Address, eth::U256> = solution
            .clearing_prices()
            .into_iter()
            .map(|(token, amount)| (token.into(), amount))
            .collect();

        // Quote competitions contain only a single order (see
        // `fake_auction()`), so there's at most one fulfillment in the
        // solution.
        if let Some(trade) = solution.trades().iter().find(|trade| match trade {
            solution::Trade::Fulfillment(fulfillment) => {
                !fulfillment.order().protocol_fees.is_empty()
            }
            _ => false,
        }) {
            let sell_token: eth::Address = trade.sell().token.into();
            let buy_token: eth::Address = trade.buy().token.into();
            let uniform_clearing = solution::trade::ClearingPrices {
                sell: *prices
                    .get(&sell_token)
                    .ok_or(QuotingFailed::ClearingSellMissing)?,
                buy: *prices
                    .get(&buy_token)
                    .ok_or(QuotingFailed::ClearingBuyMissing)?,
            };
            let custom_prices = trade
                .custom_prices(&uniform_clearing)
                .map_err(|_| QuotingFailed::Math)?;

            prices.insert(sell_token, custom_prices.sell);
            prices.insert(buy_token, custom_prices.buy);
        }

        Ok(prices)
    }
}

/// An order which needs to be quoted.
#[derive(Debug)]
pub struct Order {
    pub tokens: Tokens,
    pub amount: order::TargetAmount,
    pub side: order::Side,
    pub deadline: chrono::DateTime<chrono::Utc>,
    pub enable_fast_path: bool,
    pub quote_id: Id,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub struct Id(pub i64);

impl Order {
    /// Generate a quote for this order. This calls `/solve` on the solver with
    /// a "fake" auction which contains a single order, and then determines
    /// the quote for the order based on the solution that the solver
    /// returns.
    pub async fn quote(
        &self,
        eth: &Ethereum,
        solver: &Solver,
        liquidity: &infra::liquidity::Fetcher,
        tokens: &infra::tokens::Fetcher,
        competition: &Competition,
    ) -> Result<Quote, Error> {
        if self.enable_fast_path && !solver.fast_path_enabled() {
            return Err(Error::QuotingFailed(QuotingFailed::FastPathNotSupported));
        }

        let liquidity = match solver.liquidity() {
            solver::Liquidity::Fetch => {
                liquidity
                    .fetch(&self.token_liquidity(), infra::liquidity::AtBlock::Recent)
                    .await
            }
            solver::Liquidity::Skip => Default::default(),
        };

        let auction = self.single_order_auction(eth, tokens).await?;
        // Inject the solver fee like the competition does, so it is applied
        // by the regular protocol fee machinery when the solution is formed.
        let auction = match solver.solver_fee() {
            Some(policy) => auction.with_solver_fee(&policy),
            None => auction,
        };
        let auction = competition
            .risk_detector
            .filter_unsupported_orders_in_auction(auction)
            .await;
        if auction.orders.is_empty() {
            return Err(QuotingFailed::UnsupportedToken.into());
        }
        let solutions = solver.solve(&auction, &liquidity).await?;
        // TODO(#1468): choose the best solution in the future, but for now just
        // pick the first solution.
        let solution = solutions
            .into_iter()
            .find(|solution| !solution.is_empty(auction.surplus_capturing_jit_order_owners()))
            .ok_or(QuotingFailed::NoSolutions)?;
        let quote = Quote::try_new(eth, &solution)?;

        if self.enable_fast_path {
            // For some cases (e.g. RWA trades) the true execution path can't be
            // committed to at the time of quoting. In those cases solvers may
            // return an execution plan. Since caching and executing
            // those solutions later on clearly does not work the driver detects
            // that and returns `FastPathNotSupported` instead.
            //
            // Technically `pre-`/`post-interactions`, `wrappers` and
            // `flashloans` can also be considered part of the
            // execution plan but the heart of it are the regular
            // interactions so to avoid false positives we pin
            // the check only to them.
            if solution.interactions().is_empty() {
                return Err(Error::QuotingFailed(QuotingFailed::FastPathNotSupported));
            }

            // Now that we are reasonably sure that the solution can actually be
            // executed we cache it so it can be settled later by its quote id.
            competition
                .cache_quote_solution(self.quote_id, auction.clone(), solution)
                .await;
        }

        Ok(quote)
    }

    /// The single-order auction a quote is solved in. Token prices are unset
    /// (`None`): a quote carries no native prices.
    async fn single_order_auction(
        &self,
        eth: &Ethereum,
        tokens: &infra::tokens::Fetcher,
    ) -> Result<competition::Auction, Error> {
        let tokens = tokens.get(&[self.buy().token, self.sell().token]).await;

        let buy_token_metadata = tokens.get(&self.buy().token);
        let sell_token_metadata = tokens.get(&self.sell().token);

        competition::Auction::new(
            auction::Kind::Quote(self.quote_id),
            vec![competition::Order {
                data: std::sync::Arc::new(competition::order::OrderData {
                    uid: Default::default(),
                    receiver: eth::Receiver::OWNER,
                    created: u32::try_from(Utc::now().timestamp())
                        .unwrap_or(u32::MIN)
                        .into(),
                    valid_to: util::Timestamp::MAX,
                    buy: self.buy(),
                    sell: self.sell(),
                    side: self.side,
                    pre_interactions: Default::default(),
                    post_interactions: Default::default(),
                    sell_token_balance: competition::order::SellTokenBalance::Erc20,
                    buy_token_balance: competition::order::BuyTokenBalance::Erc20,
                    signature: competition::order::Signature {
                        scheme: competition::order::signature::Scheme::Eip1271,
                        data: Default::default(),
                        signer: Default::default(),
                    },
                    protocol_fees: Default::default(),
                    quote: Default::default(),
                    penalty_cap_native: Default::default(),
                }),
                app_data: Default::default(),
                partial: competition::order::Partial::No,
            }],
            [
                auction::Token {
                    decimals: sell_token_metadata.and_then(|m| m.decimals),
                    symbol: sell_token_metadata.and_then(|m| m.symbol.clone()),
                    address: self.tokens.sell,
                    price: None,
                    available_balance: sell_token_metadata.map(|m| m.balance.0).unwrap_or_default(),
                    trusted: false,
                },
                auction::Token {
                    decimals: buy_token_metadata.and_then(|m| m.decimals),
                    symbol: buy_token_metadata.and_then(|m| m.symbol.clone()),
                    address: self.tokens.buy,
                    price: None,
                    available_balance: buy_token_metadata.map(|m| m.balance.0).unwrap_or_default(),
                    trusted: false,
                },
            ]
            .into_iter(),
            self.deadline,
            eth,
            HashSet::default(),
        )
        .await
        .map_err(|err| match err {
            auction::Error::Blockchain(e) => e.into(),
        })
    }

    /// The asset being bought, or [`eth::U256::one`] if this is a sell, to
    /// facilitate surplus.
    fn buy(&self) -> eth::Asset {
        match self.side {
            order::Side::Sell => eth::Asset {
                amount: eth::U256::ONE.into(),
                token: self.tokens.buy,
            },
            order::Side::Buy => eth::Asset {
                amount: self.amount.into(),
                token: self.tokens.buy,
            },
        }
    }

    /// The asset being sold, or a very large value if this is a buy, to
    /// facilitate surplus.
    fn sell(&self) -> eth::Asset {
        match self.side {
            order::Side::Sell => eth::Asset {
                amount: self.amount.into(),
                token: self.tokens.sell,
            },
            // Note that we intentionally do not use [`eth::U256::max_value()`]
            // as an order with this would cause overflows with the smart
            // contract, so buy orders requiring excessively large sell amounts
            // would not work anyway. Instead we use `2 ** 144`, the rationale
            // being that Uniswap V2 pool reserves are 112-bit integers. Noting
            // that `256 - 112 = 144`, this means that we can use it to trade a full
            // `type(uint112).max` without overflowing a `uint256` on the smart
            // contract level. Requiring to trade more than `type(uint112).max`
            // is unlikely and would not work with Uniswap V2 anyway.
            order::Side::Buy => eth::Asset {
                // NOTE: the saturating strategy here is slightly irrelevant since we know that 1 <<
                // 144 fits within U256
                amount: (eth::U256::ONE.saturating_shl(144)).into(),
                token: self.tokens.sell,
            },
        }
    }

    /// Returns the token pairs to fetch liquidity for.
    fn token_liquidity(&self) -> HashSet<liquidity::TokenPair> {
        liquidity::TokenPair::try_new(self.tokens.sell(), self.tokens.buy())
            .ok()
            .into_iter()
            .collect()
    }
}

#[derive(Clone, Copy, Debug, Eq, Hash, PartialEq)]
pub struct Tokens {
    sell: eth::TokenAddress,
    buy: eth::TokenAddress,
}

impl Tokens {
    pub fn new(sell: eth::TokenAddress, buy: eth::TokenAddress) -> Self {
        Self { sell, buy }
    }

    pub fn sell(&self) -> eth::TokenAddress {
        self.sell
    }

    pub fn buy(&self) -> eth::TokenAddress {
        self.buy
    }
}

mod encode {
    use {
        crate::domain::{self, competition::solution},
        alloy::primitives::Address,
        eth_domain_types::allowance::{Approval, Required},
        num::rational::Ratio,
    };

    const DEFAULT_QUOTE_SLIPPAGE_BPS: u32 = 100;

    pub(super) fn interaction(
        interaction: &solution::Interaction,
        settlement: &Address,
    ) -> Result<Vec<domain::Interaction>, solution::encoding::Error> {
        let slippage = solution::slippage::Parameters {
            relative: Ratio::new_raw(DEFAULT_QUOTE_SLIPPAGE_BPS.into(), 10_000.into()),
            max: None,
            min: None,
            prices: Default::default(),
        };

        let encoded = match interaction {
            solution::Interaction::Custom(interaction) => domain::Interaction {
                value: interaction.value,
                target: *interaction.target,
                call_data: interaction.call_data.clone(),
            },
            solution::Interaction::Liquidity(liquidity) => {
                solution::encoding::liquidity_interaction(liquidity, &slippage, settlement)?
            }
        };

        Ok(interaction
            .allowances()
            .iter()
            .flat_map(|Required(allowance)| {
                let approval = Approval(*allowance);
                // When encoding approvals for quotes, reset the allowance
                // instead of just setting it. This is required
                // as some tokens only allow you to approve a
                // non-0 value if the allowance was 0 to begin
                // with, such as Tether USD.
                //
                // Alternatively, we could check existing allowances and only
                // encode the approvals if needed, but this
                // would only result in small gas optimizations
                // which is mostly inconsequential for quotes and not
                // worth the performance hit.
                vec![
                    solution::encoding::approve(&approval.revoke().0),
                    solution::encoding::approve(&approval.max().0),
                ]
            })
            .chain(std::iter::once(encoded))
            .collect())
    }
}

#[derive(Debug, thiserror::Error)]
pub enum Error {
    /// This can happen e.g. if there's no available liquidity for the tokens
    /// which the user is trying to trade.
    #[error(transparent)]
    QuotingFailed(#[from] QuotingFailed),
    #[error("{0:?}")]
    DeadlineExceeded(#[from] time::DeadlineExceeded),
    /// Encountered an unexpected error reading blockchain data.
    #[error("blockchain error: {0:?}")]
    Blockchain(#[from] blockchain::Error),
    #[error("solver error: {0:?}")]
    Solver(#[from] solver::Error),
    #[error("boundary error: {0:?}")]
    Boundary(#[from] boundary::Error),
    #[error("encoding error: {0:?}")]
    Encoding(#[from] solution::encoding::Error),
}

#[derive(Debug, thiserror::Error)]
pub enum QuotingFailed {
    #[error("missing sell price in solution clearing prices")]
    ClearingSellMissing,
    #[error("missing buy price in solution clearing prices")]
    ClearingBuyMissing,
    #[error("solver returned no solutions")]
    NoSolutions,
    #[error("math error computing custom prices")]
    Math,
    #[error("token is unsupported by this solver")]
    UnsupportedToken,
    #[error("solver does not support fast path quotes")]
    FastPathNotSupported,
}

#[derive(Debug, thiserror::Error)]
#[error("the quoted tokens are the same")]
pub struct SameTokens;
