use {
    super::{Auction, Order, order},
    crate::{
        domain::{
            competition::order::{SellTokenBalance, app_data::AppData},
            liquidity,
        },
        infra::{self, api::routes::solve::dto::SolveRequest, observe::metrics, tokens},
    },
    account_balances::{BalanceFetching, Query},
    anyhow::{Context, Result},
    axum::{
        body::{self, Body},
        http::Request,
    },
    balance_overrides::BalanceOverrideRequest,
    eth_domain_types::{self as eth},
    futures::{FutureExt, StreamExt, future::BoxFuture, stream::FuturesUnordered},
    itertools::Itertools,
    model::{interaction::InteractionData, order::SellTokenSource},
    std::{
        collections::HashMap,
        future::Future,
        sync::Arc,
        time::{Duration, Instant},
    },
    tokio::sync::Mutex,
    tracing::{Instrument, instrument},
};

type Shared<T> = futures::future::Shared<BoxFuture<'static, T>>;

type BalanceGroup = (order::Trader, eth::TokenAddress, order::SellTokenBalance);
type Balances = HashMap<BalanceGroup, order::SellAmount>;

/// Tasks for fetching data needed to properly process auctions.
/// These are shared by all connected solvers.
/// The reason why we have 1 task per piece of data instead of 1 task
/// that returns all the data is that this allows for better composition.
/// For example if you have some logic that only depends on one or 2 of the
/// tasks you can simply await only those and already start with your new task
/// while the third task can continue in the background.
#[derive(Clone, Debug)]
pub struct DataFetchingTasks {
    pub auction: Shared<Arc<Auction>>,
    pub balances: Shared<Arc<Balances>>,
    pub app_data:
        Shared<Arc<HashMap<order::app_data::AppDataHash, Arc<app_data::ValidatedAppData>>>>,
    pub liquidity: Shared<Arc<Vec<liquidity::Liquidity>>>,
}

/// All the components used for fetching the necessary data.
pub struct Utilities {
    eth: infra::Ethereum,
    app_data_retriever: Option<order::app_data::AppDataRetriever>,
    liquidity_fetcher: infra::liquidity::Fetcher,
    tokens: tokens::Fetcher,
    balance_fetcher: Arc<dyn BalanceFetching>,
}

impl std::fmt::Debug for Utilities {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.debug_struct("Utilities").finish()
    }
}

/// All the data used to ensure that we only run 1 instance of
/// [`DataFetchingTasks`] per auction shared by all the connected solvers.
#[derive(Debug)]
struct ControlBlock {
    /// Auction for which the data aggregation task was spawned.
    auction_id: i64,
    /// Data aggregation task.
    tasks: DataFetchingTasks,
}

#[derive(Debug)]
pub struct DataAggregator {
    utilities: Arc<Utilities>,
    control: Mutex<ControlBlock>,
}

impl DataAggregator {
    /// Resolves the order's app-data hash to the underlying JSON if it isn't
    /// already resolved.
    pub async fn resolve_app_data(&self, order: &mut Order) {
        let AppData::Hash(hash) = &order.app_data else {
            return;
        };
        let Some(retriever) = self.utilities.app_data_retriever.as_ref() else {
            return;
        };
        if let Ok(Some(doc)) = retriever.get_cached_or_fetch(hash).await {
            order.app_data = doc.into();
        }
    }

    /// Aggregates all the data that is needed to pre-process the given auction.
    /// Uses a shared futures internally to make sure that the works happens
    /// only once for all connected solvers to share.
    pub async fn start_or_get_tasks_for_auction(
        &self,
        request: Request<Body>,
    ) -> Result<DataFetchingTasks> {
        let mut lock = self.control.lock().await;
        let current_auction = &lock.auction_id;

        // Figure out for which auction this `/solve` request was issued
        // by looking at the `X-Auction-Id` header.
        let request_auction_id: i64 = request
            .headers()
            .get("X-Auction-Id")
            .context("request has no X-Auction-Id header")?
            .to_str()
            .context("X-Auction-Id header is not ASCII")?
            .parse()
            .context("could not parse X-Auction-Id header as i64")?;

        // Some other driver is already doing the pre-processing for this
        // auction. Stop processing here and just await the existing task.
        if request_auction_id == *current_auction {
            init_auction_id_in_span(Some(request_auction_id));
            tracing::debug!("await running data aggregation task");
            return Ok(lock.tasks.clone());
        }

        let tasks = self.assemble_tasks(request).await?;

        tracing::debug!("started new data aggregation task");
        lock.auction_id = request_auction_id;
        lock.tasks = tasks.clone();

        Ok(tasks)
    }

    pub fn new(
        eth: infra::Ethereum,
        app_data_retriever: Option<order::app_data::AppDataRetriever>,
        liquidity_fetcher: infra::liquidity::Fetcher,
        tokens: tokens::Fetcher,
        balance_fetcher: Arc<dyn BalanceFetching>,
    ) -> Self {
        Self {
            utilities: Arc::new(Utilities {
                eth,
                app_data_retriever,
                liquidity_fetcher,
                tokens,
                balance_fetcher,
            }),
            control: Mutex::new(ControlBlock {
                auction_id: Default::default(),
                tasks: DataFetchingTasks {
                    auction: futures::future::pending().boxed().shared(),
                    balances: futures::future::pending().boxed().shared(),
                    app_data: futures::future::pending().boxed().shared(),
                    liquidity: futures::future::pending().boxed().shared(),
                },
            }),
        }
    }

    async fn assemble_tasks(&self, request: Request<Body>) -> Result<DataFetchingTasks> {
        let auction = self.utilities.parse_request(request).await?;

        let balances =
            Self::spawn_shared(Arc::clone(&self.utilities).fetch_balances(Arc::clone(&auction)));

        let app_data = Self::spawn_shared(
            Arc::clone(&self.utilities).collect_orders_app_data(Arc::clone(&auction)),
        );

        let liquidity =
            Self::spawn_shared(Arc::clone(&self.utilities).fetch_liquidity(Arc::clone(&auction)));

        Ok(DataFetchingTasks {
            auction: futures::future::ready(auction).boxed().shared(),
            balances,
            app_data,
            liquidity,
        })
    }

    /// Spawns an async task and returns a `Shared` handle to its result.
    /// Errors are not handled as we are deferring all error handling to where
    /// the shared future is awaited.
    /// The future is being started immediately and polled in the background so
    /// the caller doen't have to manage data dependencies directly.
    fn spawn_shared<T>(fut: impl Future<Output = T> + Send + 'static) -> Shared<T>
    where
        T: Send + Sync + Clone + 'static,
    {
        let shared = fut.instrument(tracing::Span::current()).boxed().shared();

        // Start the computation in the background
        tokio::spawn(shared.clone());

        shared
    }
}

impl Utilities {
    /// Parses the JSON body of the `/solve` request during the unified
    /// auction pre-processing since eagerly deserializing these requests
    /// is surprisingly costly because their are so big.
    async fn parse_request(&self, solve_request: Request<Body>) -> Result<Arc<Auction>> {
        let solve_request = collect_request_body(solve_request).await?;

        let auction_dto: SolveRequest = {
            let _timer = metrics::get().processing_stage_timer("parse_dto");
            let _timer2 =
                observe::metrics::metrics().on_auction_overhead_start("driver", "parse_dto");
            // deserialization takes tens of milliseconds so run it on a
            // blocking task
            tokio::task::spawn_blocking(move || {
                serde_json::from_slice(&solve_request)
                    .inspect_err(|err| {
                        tracing::warn!(?err, "failed to parse /solve request body");
                    })
                    .context("could not parse solve request")
            })
            .await
            .context("failed to await blocking task")??
        };

        // now that we finally know the auction id we can set it in the span
        init_auction_id_in_span(Some(auction_dto.id()));

        let auction_domain = {
            let _timer = metrics::get().processing_stage_timer("convert_to_domain");
            let _timer2 = observe::metrics::metrics()
                .on_auction_overhead_start("driver", "convert_to_domain");
            let app_data = self
                .app_data_retriever
                .as_ref()
                .map(|retriever| retriever.get_cached())
                .unwrap_or_default();
            let auction = auction_dto
                .into_domain(&self.eth, &self.tokens, app_data)
                .await
                .context("could not convert auction DTO to domain type")?;
            Arc::new(auction)
        };

        Ok(auction_domain)
    }

    /// Fetches the tradable balance for every order owner.
    async fn fetch_balances(self: Arc<Self>, auction: Arc<Auction>) -> Arc<Balances> {
        let _timer = metrics::get().processing_stage_timer("fetch_balances");
        let _timer2 =
            observe::metrics::metrics().on_auction_overhead_start("driver", "fetch_balances");

        // Collect trader/token/source/interaction tuples for fetching available
        // balances. Note that we are pessimistic here, if a trader is selling
        // the same token with the same source in two different orders using a
        // different set of pre-interactions, then we fetch the balance as if no
        // pre-interactions were specified. This is done to avoid creating
        // dependencies between orders (i.e. order 1 is required for executing
        // order 2) which we currently cannot express with the solver interface.
        let queries = auction
            .orders
            .iter()
            .chunk_by(|order| (order.trader(), order.sell.token, order.sell_token_balance))
            .into_iter()
            .map(|((trader, token, source), mut orders)| {
                let first = orders.next().expect("group contains at least 1 order");
                let mut others = orders;
                let all_setups_equal = others.all(|order| {
                    order.pre_interactions == first.pre_interactions
                        && order.app_data.flashloan() == first.app_data.flashloan()
                });
                Query {
                    owner: trader.0,
                    token: *token,
                    source: match source {
                        SellTokenBalance::Erc20 => SellTokenSource::Erc20,
                        SellTokenBalance::Internal => SellTokenSource::Internal,
                        SellTokenBalance::External => SellTokenSource::External,
                    },
                    interactions: if all_setups_equal {
                        first
                            .pre_interactions
                            .iter()
                            .map(|i| InteractionData {
                                target: i.target,
                                value: i.value.0,
                                call_data: i.call_data.0.to_vec(),
                            })
                            .collect()
                    } else {
                        Vec::default()
                    },
                    balance_override: if all_setups_equal {
                        first
                            .app_data
                            .flashloan()
                            .map(|loan| BalanceOverrideRequest {
                                token: loan.token,
                                amount: loan.amount,
                                holder: loan.receiver,
                            })
                    } else {
                        None
                    },
                }
            })
            .collect::<Vec<_>>();

        let balances = self.balance_fetcher.get_balances(&queries).await;

        let result: HashMap<_, _> = queries
            .into_iter()
            .zip(balances)
            .filter_map(|(query, balance)| {
                let balance = balance.ok()?;
                Some((
                    (
                        order::Trader(query.owner),
                        query.token.into(),
                        match query.source {
                            SellTokenSource::Erc20 => SellTokenBalance::Erc20,
                            SellTokenSource::Internal => SellTokenBalance::Internal,
                            SellTokenSource::External => SellTokenBalance::External,
                        },
                    ),
                    order::SellAmount(balance),
                ))
            })
            .collect();

        Arc::new(result)
    }

    /// Fetches the app data for all orders in the auction.
    /// Returns a map from app data hash to the fetched app data.
    async fn collect_orders_app_data(
        self: Arc<Self>,
        auction: Arc<Auction>,
    ) -> Arc<HashMap<order::app_data::AppDataHash, Arc<app_data::ValidatedAppData>>> {
        let Some(app_data_retriever) = &self.app_data_retriever else {
            return Default::default();
        };

        let _timer = metrics::get().processing_stage_timer("fetch_app_data");
        let _timer2 =
            observe::metrics::metrics().on_auction_overhead_start("driver", "fetch_app_data");

        let futures: FuturesUnordered<_> = auction
            .orders
            .iter()
            .flat_map(|order| match order.app_data {
                AppData::Full(_) => None,
                // only fetch appdata we don't already have in full
                AppData::Hash(hash) => Some(hash),
            })
            .unique()
            .map(async move |app_data_hash| {
                let fetched_app_data = app_data_retriever
                    .get_cached_or_fetch(&app_data_hash)
                    .await
                    .inspect_err(|err| {
                        tracing::warn!(?app_data_hash, ?err, "failed to fetch app data");
                    })
                    .ok()
                    .flatten();

                (app_data_hash, fetched_app_data)
            })
            .collect();

        // Only await responses for a short amount of time. Even if we don't
        // await all futures fully the remaining appdata requests will
        // finish in background tasks. That way we should have enough
        // time to immediately fetch appdatas of new orders (once the
        // cache is filled). But we also don't run the risk of stalling
        // the driver completely until everything is fetched.
        // In practice that means the solver will only see a few appdatas in the
        // first auction after a restart. But on subsequent auctions
        // everything should be available.
        const MAX_APP_DATA_WAIT: Duration = Duration::from_millis(500);
        let app_data: HashMap<_, _> = futures
            .take_until(tokio::time::sleep(MAX_APP_DATA_WAIT))
            .filter_map(async move |(hash, json)| Some((hash, json?)))
            .collect()
            .await;

        Arc::new(app_data)
    }

    async fn fetch_liquidity(
        self: Arc<Self>,
        auction: Arc<Auction>,
    ) -> Arc<Vec<liquidity::Liquidity>> {
        let _timer = metrics::get().processing_stage_timer("fetch_liquidity");
        let _timer2 =
            observe::metrics::metrics().on_auction_overhead_start("driver", "fetch_liquidity");
        let pairs = auction.liquidity_pairs();
        Arc::new(
            self.liquidity_fetcher
                .fetch(&pairs, infra::liquidity::AtBlock::Latest)
                .await,
        )
    }
}

fn init_auction_id_in_span(id: Option<i64>) {
    let Some(id) = id else {
        return;
    };
    let current_span = tracing::Span::current();
    debug_assert!(current_span.has_field("auction_id"));
    current_span.record("auction_id", id);
}

#[instrument(skip_all)]
async fn collect_request_body(request: Request<Body>) -> Result<body::Bytes> {
    tracing::trace!("start streaming request body");
    let _timer =
        observe::metrics::metrics().on_auction_overhead_start("driver", "stream_http_body");
    let start = Instant::now();

    let body_bytes = axum::body::to_bytes(request.into_body(), usize::MAX)
        .await
        .context("failed to stream request body")?;

    let duration = start.elapsed();
    tracing::debug!(?duration, "finished streaming request body");
    Ok(body_bytes)
}
