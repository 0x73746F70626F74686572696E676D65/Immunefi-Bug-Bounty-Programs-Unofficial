use {
    ::alloy::{
        consensus::Transaction as _,
        primitives::{Address, Bytes, U256},
        providers::{Provider, ext::TxPoolApi},
        sol_types::SolConstructor,
    },
    contracts::Solver7702Delegate::Solver7702Delegate,
    driver::infra::solver::eip7702::{DELEGATION_PREFIX, MAX_APPROVED_CALLERS, delegate_address},
    e2e::setup::{colocation, *},
    ethrpc::{
        Web3,
        alloy::{CallBuilderExt, EvmProviderExt},
    },
    model::{
        order::{OrderCreation, OrderKind},
        signature::EcdsaSigningScheme,
    },
    number::units::EthUnit,
    std::time::Duration,
};

/// Tests that the driver can process two settlement requests concurrently,
/// resulting in both settlement transactions being pending in the mempool
/// simultaneously.
///
/// Bypasses the autopilot (which settles one solution per auction) and sends
/// two /solve + /settle requests directly to the driver.
///
/// Uses EIP-7702 delegation: the driver deploys Solver7702Delegate for the
/// submission accounts and delegates the solver EOA to it. Two submission
/// accounts send settlement txs through the solver EOA in parallel, each using
/// their own nonce.
#[tokio::test]
#[ignore]
async fn local_node_parallel_settlement_submission() {
    run_test(test_parallel_settlement_submission).await;
}

async fn test_parallel_settlement_submission(web3: Web3) {
    let mut onchain = OnchainComponents::deploy(web3.clone()).await;

    let [solver] = onchain.make_solvers(10u64.eth()).await;
    let [trader] = onchain.make_accounts(10u64.eth()).await;
    // Two submission accounts for parallel settlement via EIP-7702.
    let [submitter_a, submitter_b] = onchain.make_accounts(10u64.eth()).await;

    // Deploy two independent token pairs so settlements don't conflict on the
    // same Uniswap pool when mined in the same block.
    let [token_a, token_b] = onchain
        .deploy_tokens_with_weth_uni_v2_pools(1_000u64.eth(), 1_000u64.eth())
        .await;

    // Fund trader with WETH and approve the vault relayer.
    onchain
        .contracts()
        .weth
        .deposit()
        .from(trader.address())
        .value(5u64.eth())
        .send_and_watch()
        .await
        .unwrap();
    onchain
        .contracts()
        .weth
        .approve(onchain.contracts().allowance, 5u64.eth())
        .from(trader.address())
        .send_and_watch()
        .await
        .unwrap();

    // Start driver + baseline solver. Each /solve call is a separate auction
    // so solutions are independent regardless of merge_solutions.
    let mut solver_engine = colocation::start_baseline_solver(
        "test_solver".into(),
        solver.clone(),
        *onchain.contracts().weth.address(),
        vec![],
        1,
        false,
    )
    .await;
    solver_engine.submission_keys = vec![submitter_a.clone(), submitter_b.clone()];

    colocation::start_driver(
        onchain.contracts(),
        vec![solver_engine],
        colocation::LiquidityProvider::UniswapV2,
    );

    // Wait for the driver to become available.
    let driver_url = "http://localhost:11088/test_solver";
    wait_for_condition(TIMEOUT, || async {
        reqwest::get(format!("{driver_url}/healthz")).await.is_ok()
    })
    .await
    .expect("driver did not start in time");
    assert_solver_delegates_to_expected_contract(
        &web3,
        solver.address(),
        [submitter_a.address(), submitter_b.address()],
    )
    .await;

    let valid_to = model::time::now_in_epoch_seconds() + 300;
    let make_buy_order = |buy_token: Address| {
        OrderCreation {
            sell_token: *onchain.contracts().weth.address(),
            sell_amount: 2u64.eth(),
            buy_token,
            buy_amount: 1u64.eth(),
            valid_to,
            kind: OrderKind::Buy,
            ..Default::default()
        }
        .sign(
            EcdsaSigningScheme::Eip712,
            &onchain.contracts().domain_separator,
            &trader.signer,
        )
    };
    let order_a = make_buy_order(*token_a.address());
    let order_b = make_buy_order(*token_b.address());

    onchain.mint_block().await;

    let block_number = web3.provider.get_block_number().await.unwrap();
    let http = reqwest::Client::builder()
        .timeout(Duration::from_secs(30))
        .build()
        .unwrap();

    // Send /solve for each order as a separate auction. The driver caches
    // the resulting settlement for each, keyed by (auction_id, solution_id).
    let solution_id_a =
        solve_order(&http, driver_url, 1, &order_a, trader.address(), &onchain).await;
    let solution_id_b =
        solve_order(&http, driver_url, 2, &order_b, trader.address(), &onchain).await;

    // Disable automine so settlement txs stay pending in the mempool.
    web3.provider
        .evm_set_automine(false)
        .await
        .expect("Must be able to disable automine");

    // Send both /settle requests concurrently. With parallel submission, both
    // submission accounts send txs to the solver EOA simultaneously.
    let submission_deadline = block_number + 100;
    let settle_url = format!("{driver_url}/settle");
    let spawn_settle = |auction_id: &'static str, solution_id: u64| {
        let http = http.clone();
        let settle_url = settle_url.clone();
        tokio::spawn(async move {
            http.post(&settle_url)
                .json(&serde_json::json!({
                    "solutionId": solution_id,
                    "submissionDeadlineLatestBlock": submission_deadline,
                    "auctionId": auction_id
                }))
                .send()
                .await
        })
    };
    let settle_a = spawn_settle("1", solution_id_a);
    let settle_b = spawn_settle("2", solution_id_b);

    // Assert that TWO settlement txs are pending simultaneously: one direct
    // (solver EOA → settlement contract) and one delegated (submission EOA →
    // solver EOA via EIP-7702 delegation). The driver uses the direct slot
    // when no settlement is in flight (cheaper), and falls back to 7702 for
    // concurrent submissions.
    let solver_address = solver.address();
    let settlement_address = *onchain.contracts().gp_settlement.address();
    let parallel_txs_observed = wait_for_condition(Duration::from_secs(15), || {
        let web3 = web3.clone();
        async move {
            let txpool = web3
                .provider
                .txpool_content()
                .await
                .expect("must be able to inspect mempool");
            let pending: Vec<_> = txpool
                .pending
                .values()
                .flat_map(|nonce_map| nonce_map.values())
                .collect();

            let direct = pending
                .iter()
                .filter(|tx| tx.inner.to() == Some(settlement_address))
                .count();
            let delegated = pending
                .iter()
                .filter(|tx| tx.inner.to() == Some(solver_address))
                .count();

            tracing::debug!(direct, delegated, "checking for parallel pending txs");
            direct == 1 && delegated == 1
        }
    })
    .await;

    assert!(
        parallel_txs_observed.is_ok(),
        "Expected one direct settlement tx (to settlement contract) and one delegated tx (to \
         solver EOA via EIP-7702) pending simultaneously."
    );

    // Re-enable automine and verify both orders get settled.
    web3.provider
        .evm_set_automine(true)
        .await
        .expect("Must be able to enable automine");

    // Wait for the /settle HTTP calls to complete (they block until mined).
    assert_settle_success(settle_a.await, "1").await;
    assert_settle_success(settle_b.await, "2").await;

    for token in [&token_a, &token_b] {
        wait_for_condition(TIMEOUT, || async {
            let balance = token.balanceOf(trader.address()).call().await.unwrap();
            balance > U256::ZERO
        })
        .await
        .unwrap();
    }
}

async fn assert_solver_delegates_to_expected_contract(
    web3: &Web3,
    solver: Address,
    callers: [Address; 2],
) {
    let delegate = solver_delegate_address(callers);
    let delegate_code = web3.provider.get_code_at(delegate).await.unwrap();
    assert!(
        !delegate_code.is_empty(),
        "delegate contract was not deployed"
    );

    let solver_code = web3.provider.get_code_at(solver).await.unwrap();
    let mut expected_solver_code = Vec::from(DELEGATION_PREFIX);
    expected_solver_code.extend_from_slice(delegate.as_slice());
    assert_eq!(
        solver_code.as_ref(),
        expected_solver_code,
        "solver EOA does not delegate to expected Solver7702Delegate"
    );
}

fn solver_delegate_address(callers: [Address; 2]) -> Address {
    let mut approved_callers = [Address::ZERO; MAX_APPROVED_CALLERS];
    approved_callers[..callers.len()].copy_from_slice(&callers);
    let init_code = Solver7702Delegate::BYTECODE
        .iter()
        .chain(&SolConstructor::abi_encode(
            &Solver7702Delegate::constructorCall {
                approvedCallers: approved_callers,
            },
        ))
        .copied()
        .collect::<Bytes>();

    let local = delegate_address(&callers).unwrap();
    assert_eq!(
        local,
        driver::infra::solver::eip7702::CREATE2_DEPLOYER
            .create2_from_code(driver::infra::solver::eip7702::CREATE2_SALT, &init_code)
    );
    local
}

/// Sends a /solve request to the driver for a single order and returns the
/// solution_id from the response.
async fn solve_order(
    http: &reqwest::Client,
    driver_url: &str,
    auction_id: i64,
    order: &OrderCreation,
    owner: Address,
    onchain: &OnchainComponents,
) -> u64 {
    let weth = onchain.contracts().weth.address();
    let uid = order
        .data()
        .uid(&onchain.contracts().domain_separator, owner);
    let sig_bytes = order.signature.to_bytes();
    let deadline = (chrono::Utc::now() + chrono::Duration::seconds(3)).to_rfc3339();

    let response = http
        .post(format!("{driver_url}/solve"))
        .header("X-Auction-Id", auction_id.to_string())
        .json(&serde_json::json!({
            "id": auction_id.to_string(),
            "tokens": [
                {"address": format!("{weth:?}"), "price": "1000000000000000000", "trusted": true},
                {"address": format!("{:?}", order.buy_token), "price": "1000000000000000000", "trusted": false},
            ],
            "orders": [{
                "uid": format!("{uid}"),
                "sellToken": format!("{:?}", order.sell_token),
                "buyToken": format!("{:?}", order.buy_token),
                "sellAmount": order.sell_amount.to_string(),
                "buyAmount": order.buy_amount.to_string(),
                "protocolFees": [],
                "created": model::time::now_in_epoch_seconds(),
                "validTo": order.valid_to,
                "kind": "buy",
                "receiver": format!("{:?}", Address::ZERO),
                "owner": format!("{owner:?}"),
                "partiallyFillable": false,
                "executed": "0",
                "preInteractions": [],
                "postInteractions": [],
                "class": "limit",
                "appData": format!("0x{}", const_hex::encode([0u8; 32])),
                "signingScheme": "eip712",
                "signature": format!("0x{}", const_hex::encode(&sig_bytes)),
            }],
            "deadline": deadline,
        }))
        .send()
        .await
        .expect("failed to send /solve request");

    let status = response.status();
    let text = response
        .text()
        .await
        .expect("failed to read /solve response");
    assert!(status.is_success(), "/solve failed ({status}): {text}");

    let body: serde_json::Value = serde_json::from_str(&text).expect("invalid JSON from /solve");

    let solution_id = body["solutions"][0]["solutionId"]
        .as_u64()
        .unwrap_or_else(|| panic!("no solutionId in /solve response: {text}"));

    tracing::info!(auction_id, solution_id, "solve succeeded");
    solution_id
}

async fn assert_settle_success(
    settle_result: Result<reqwest::Result<reqwest::Response>, tokio::task::JoinError>,
    auction_id: &str,
) {
    let response = settle_result
        .unwrap_or_else(|err| panic!("/settle task for auction {auction_id} panicked: {err}"))
        .unwrap_or_else(|err| panic!("/settle request for auction {auction_id} failed: {err}"));
    let status = response.status();
    let body = response.text().await.unwrap_or_else(|err| {
        panic!("failed to read /settle response for auction {auction_id}: {err}")
    });
    assert!(
        status.is_success(),
        "/settle failed for auction {auction_id} ({status}): {body}"
    );
}
