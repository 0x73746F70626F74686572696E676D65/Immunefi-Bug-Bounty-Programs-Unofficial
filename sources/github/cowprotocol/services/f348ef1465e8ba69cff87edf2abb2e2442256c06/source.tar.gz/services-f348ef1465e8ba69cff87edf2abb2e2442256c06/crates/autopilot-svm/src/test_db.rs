//! Database helpers for the crate's `solana_db_` tests.

use sqlx::PgPool;

pub(crate) async fn pool() -> PgPool {
    PgPool::connect("postgresql://").await.unwrap()
}

/// Empty every `solana.*` table a test can touch. Tests wipe at the start so
/// a failure leaves its state behind for inspection.
pub(crate) async fn wipe(pool: &PgPool) {
    sqlx::query(
        "TRUNCATE solana.trades, solana.settlements, solana.settlement_executions, \
         solana.order_pda, solana.orders, solana.indexer_state, solana.order_events, \
         solana.auctions, solana.competition_auctions, solana.proposed_solutions, \
         solana.proposed_trade_executions, solana.reference_scores",
    )
    .execute(pool)
    .await
    .unwrap();
}
