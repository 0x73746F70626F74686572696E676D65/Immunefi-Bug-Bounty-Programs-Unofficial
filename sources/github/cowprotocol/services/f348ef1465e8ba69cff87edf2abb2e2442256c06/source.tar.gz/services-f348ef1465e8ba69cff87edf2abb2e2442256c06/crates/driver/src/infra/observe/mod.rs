//! This module implements the observability for the driver. It exposes
//! functions which represent events that are meaningful to the system. These
//! functions are called when the corresponding events occur. They log the event
//! and update the metrics, if the event is worth measuring.

use {
    super::{Mempool, solver::Timeouts},
    crate::{
        boundary,
        domain::{
            Liquidity,
            competition::{
                self,
                Solution,
                Solved,
                solution::{self, Settlement, settlement::EncodedSettlement},
            },
            mempools::{self, SubmissionSuccess},
            quote::{self, Quote},
            time::{Deadline, Remaining},
        },
        infra::solver,
        util::http,
    },
    eth_domain_types as eth,
    ethrpc::block_stream::BlockInfo,
    observe::tracing::lazy::Lazy,
    std::{
        collections::{BTreeMap, HashSet},
        time::Duration,
    },
    url::Url,
};

pub mod metrics;

/// Setup the observability. The log argument configures the tokio tracing
/// framework.
pub fn init(obs_config: observe::Config) {
    observe::tracing::init::initialize_reentrant(&obs_config);
    metrics::init();
    #[cfg(unix)]
    observe::heap_dump_handler::spawn_heap_dump_handler();
}

/// Observe a received auction.
pub fn auction(auction_id: i64) {
    tracing::debug!(id=?auction_id, "received auction");
}

/// Observe that liquidity fetching is about to start.
pub fn fetching_liquidity() {
    tracing::trace!("fetching liquidity");
}

/// Observe the fetched liquidity.
pub fn fetched_liquidity(liquidity: &[Liquidity]) {
    let mut grouped: BTreeMap<&'static str, usize> = Default::default();
    for liquidity in liquidity {
        *grouped.entry((&liquidity.kind).into()).or_default() += 1;
    }
    tracing::debug!(liquidity = ?grouped, "fetched liquidity sources");
}

/// Observe that fetching liquidity failed.
pub fn fetching_liquidity_failed(err: &boundary::Error) {
    tracing::warn!(?err, "failed to fetch liquidity");
}

pub fn duplicated_solution_id(solver: &solver::Name, id: &solution::Id) {
    tracing::debug!(?id, "discarded solution: duplicated id");
    metrics::get()
        .dropped_solutions
        .with_label_values(&[solver.as_str(), "DuplicateId"])
        .inc();
}

/// Observe the solutions returned by the solver.
pub fn solutions(
    solutions: &[Solution],
    surplus_capturing_jit_order_owners: &HashSet<eth::Address>,
) {
    if solutions
        .iter()
        .any(|s| !s.is_empty(surplus_capturing_jit_order_owners))
    {
        tracing::info!(?solutions, "computed solutions");
    } else {
        tracing::debug!("no solutions");
    }
}

/// Observe that a solution was discarded because it is empty.
pub fn empty_solution(solver: &solver::Name, id: &solution::Id) {
    tracing::debug!(?id, "discarded solution: empty");
    metrics::get()
        .dropped_solutions
        .with_label_values(&[solver.as_str(), "EmptySolution"])
        .inc();
}

// Observe that postprocessing (encoding & merging) of solutions is about to
// start.
pub fn postprocessing(solutions: &[Solution], deadline: chrono::DateTime<chrono::Utc>) {
    tracing::debug!(
        solutions = ?solutions.len(),
        remaining = ?deadline.remaining(),
        "postprocessing solutions"
    );
}

// Observe that postprocessing didn't complete before the timeout.
pub fn postprocessing_timed_out(completed: &[Settlement]) {
    tracing::debug!(
        completed = ?completed.len(),
        "postprocessing solutions timed out"
    );
}

/// Observe that a solution is about to be encoded into a settlement.
pub fn encoding(id: &solution::Id) {
    tracing::trace!(?id, "encoding settlement");
}

/// Observe that settlement encoding failed.
pub fn encoding_failed(
    solver: &solver::Name,
    id: &solution::Id,
    err: &solution::Error,
    orders: &[competition::order::Uid],
) {
    tracing::info!(
        ?id,
        ?orders,
        ?err,
        "discarded solution: settlement encoding"
    );
    metrics::get()
        .dropped_solutions
        .with_label_values(&[solver.as_str(), "SettlementEncoding"])
        .inc();
}

/// Observe that two solutions were merged.
pub fn merged(first: &Solution, other: &Solution, result: &Solution) {
    tracing::trace!(?first, ?other, ?result, "merged solutions");
}

/// Observe that scoring is about to start.
pub fn scoring(settlement: &Settlement) {
    tracing::trace!(
        solution = ?settlement.solution(),
        gas = ?settlement.gas,
        "scoring settlement"
    );
}

/// Observe that scoring failed.
pub fn scoring_failed(solver: &solver::Name, err: &solution::error::Scoring) {
    tracing::info!(%solver, ?err, "discarded solution: scoring");
    metrics::get()
        .dropped_solutions
        .with_label_values(&[solver.as_str(), "Scoring"])
        .inc();
}

/// Observe the settlement score.
pub fn score(settlement: &Settlement, score: &eth::Ether) {
    tracing::info!(
        solution = ?settlement.solution(),
        score = ?score,
        "scored settlement"
    );
}

// Observe that the winning settlement started failing upon arrival of a new
// block
pub fn winner_voided(solver: &solver::Name, block: BlockInfo, err: &simulator::RevertError) {
    tracing::warn!(block = block.number, ?err, "solution reverts on new block");
    metrics::get()
        .dropped_solutions
        .with_label_values(&[solver.as_str(), "SimulationRevert"])
        .inc();
}

pub fn revealing() {
    tracing::trace!("revealing");
}

pub fn revealed(solver: &solver::Name, result: &Result<competition::Revealed, competition::Error>) {
    match result {
        Ok(calldata) => {
            tracing::info!(?calldata, "revealed");
            metrics::get()
                .reveals
                .with_label_values(&[solver.as_str(), "Success"])
                .inc();
        }
        Err(err) => {
            tracing::warn!(?err, "failed to reveal");
            metrics::get()
                .reveals
                .with_label_values(&[solver.as_str(), competition_error(err)])
                .inc();
        }
    }
}

/// Observe that the settlement process is about to start.
pub fn settling() {
    tracing::trace!("settling solution");
}

/// Observe the result of the settlement process.
pub fn settled(solver: &solver::Name, result: &Result<competition::Settled, competition::Error>) {
    match result {
        Ok(calldata) => {
            tracing::info!(?calldata, "settled solution");
            metrics::get()
                .settlements
                .with_label_values(&[solver.as_str(), "Success"])
                .inc();
        }
        Err(err) => {
            tracing::warn!(?err, "failed to settle");
            metrics::get()
                .settlements
                .with_label_values(&[solver.as_str(), competition_error(err)])
                .inc();
        }
    }
}

/// Observe the result of solving an auction.
pub fn solved(solver: &str, result: &Result<Vec<Solved>, competition::Error>) {
    match result {
        Ok(solutions) if solutions.is_empty() => {
            tracing::debug!("no solution found");
            metrics::get()
                .solutions
                .with_label_values(&[solver, "SolutionNotFound"])
                .inc();
        }
        Ok(solutions) => {
            tracing::info!(?solutions, "solved auction");
            metrics::get()
                .solutions
                .with_label_values(&[solver, "Success"])
                .inc_by(solutions.len() as u64);
        }
        Err(err) => {
            tracing::warn!(?err, "failed to solve auction");
            metrics::get()
                .solutions
                .with_label_values(&[solver, competition_error(err)])
                .inc();
        }
    }
}

/// Observe the result of quoting an auction.
pub fn quoted(solver: &solver::Name, order: &quote::Order, result: &Result<Quote, quote::Error>) {
    match result {
        Ok(quote) => {
            tracing::info!(?order, ?quote, "quoted order");
            metrics::get()
                .quotes
                .with_label_values(&[solver.as_str(), "Success"])
                .inc();
        }
        Err(err) => {
            tracing::warn!(?order, ?err, "failed to quote order");
            metrics::get()
                .quotes
                .with_label_values(&[
                    solver.as_str(),
                    match err {
                        quote::Error::QuotingFailed(quote::QuotingFailed::ClearingSellMissing) => {
                            "ClearingSellMissing"
                        }
                        quote::Error::QuotingFailed(quote::QuotingFailed::ClearingBuyMissing) => {
                            "ClearingBuyMissing"
                        }
                        quote::Error::QuotingFailed(quote::QuotingFailed::NoSolutions) => {
                            "NoSolutions"
                        }
                        quote::Error::QuotingFailed(quote::QuotingFailed::Math) => "MathError",
                        quote::Error::QuotingFailed(quote::QuotingFailed::UnsupportedToken) => {
                            "UnsupportedToken"
                        }
                        quote::Error::QuotingFailed(quote::QuotingFailed::FastPathNotSupported) => {
                            "FastPathNotSupported"
                        }
                        quote::Error::DeadlineExceeded(_) => "DeadlineExceeded",
                        quote::Error::Blockchain(_) => "BlockchainError",
                        quote::Error::Solver(solver::Error::Http(_)) => "SolverHttpError",
                        quote::Error::Solver(solver::Error::Deserialize(_)) => {
                            "SolverDeserializeError"
                        }
                        quote::Error::Solver(solver::Error::Dto(_)) => "SolverDtoError",
                        quote::Error::Solver(solver::Error::CustomError(_)) => "SolverCustomError",
                        quote::Error::Boundary(_) => "Unknown",
                        quote::Error::Encoding(_) => "Encoding",
                    },
                ])
                .inc();
        }
    }
}

/// Observe that the API routes for a solver are being mounted.
pub fn mounting_solver(solver: &solver::Name, path: &str) {
    tracing::debug!(%solver, path, "mounting solver");
}

/// Observe that a request is about to be sent to the solver.
pub fn solver_request(endpoint: &Url, req: impl AsRef<[u8]>) {
    let req = Lazy(|| String::from_utf8_lossy(req.as_ref()));
    tracing::trace!(%endpoint, %req, "sending request to solver");
}

/// Observe how long serializing and streaming the solve request body to a
/// solver took, both the isolated serialization cost and the total including
/// the solver transfer.
pub fn serialized_solve_request(solver: &solver::Name, serialize: Duration, total: Duration) {
    let metrics = metrics::get();
    metrics
        .solve_request_body_time
        .with_label_values(&[solver.as_str(), "serialization"])
        .observe(serialize.as_secs_f64());
    metrics
        .solve_request_body_time
        .with_label_values(&[solver.as_str(), "total"])
        .observe(total.as_secs_f64());
}

/// Observe that a response was received from the solver.
pub fn solver_response(
    endpoint: &Url,
    res: Result<&str, &http::Error>,
    solver: &str,
    compute_time: Duration,
    is_quote_request: bool,
) {
    match res {
        Ok(res) => {
            tracing::trace!(%endpoint, %res, "received response from solver")
        }
        Err(err) => {
            tracing::warn!(%endpoint, ?err, "failed to receive response from solver")
        }
    }
    let kind = if is_quote_request { "quote" } else { "auction" };
    metrics::get()
        .used_solve_time
        .with_label_values(&[solver, kind])
        .observe(compute_time.as_secs_f64());
}

/// Log a single mempool submission attempt. Called inline from the racing
/// task so that errors from mempools that later get superseded are still
/// visible in logs. Metrics are emitted separately from `update_metrics`
/// once the race outcome is known.
pub fn mempool_log(
    mempool: &Mempool,
    settlement: &EncodedSettlement,
    result: &Result<SubmissionSuccess, mempools::Error>,
) {
    match result {
        Ok(submission) => tracing::info!(
            txid = ?submission.tx_hash,
            %mempool,
            ?settlement,
            "sending transaction via mempool succeeded",
        ),
        Err(mempools::Error::Disabled) => tracing::debug!(
            %mempool,
            "mempool disabled, not sending transaction",
        ),
        Err(err) => tracing::warn!(
            ?err,
            %mempool,
            ?settlement,
            "sending transaction via mempool failed",
        ),
    }
}

/// Emit per-mempool race counters with the final, reclassified label
/// (`Success` / `Revert` / `Expired` / `Other` / `Superseded` / `Disabled`).
/// Called once per mempool after the race resolves.
pub fn mempool_submission_result(mempool: &Mempool, label: &str, blocks_passed: Option<u64>) {
    let name = mempool.to_string();
    metrics::get()
        .mempool_submission
        .with_label_values(&[name.as_str(), label])
        .inc();
    if let Some(blocks) = blocks_passed {
        metrics::get()
            .mempool_submission_results_blocks_passed
            .with_label_values(&[name.as_str(), label])
            .inc_by(blocks);
    }
}

/// Observe that an invalid DTO was received.
pub fn invalid_dto(err: &impl std::error::Error, dto: &str) {
    tracing::warn!(?err, ?dto, "received invalid dto");
}

/// Observe that the quoting process is about to start.
pub fn quoting(order: &quote::Order) {
    tracing::trace!(?order, "quoting");
}

fn competition_error(err: &competition::Error) -> &'static str {
    match err {
        competition::Error::SolutionNotAvailable => "SolutionNotAvailable",
        competition::Error::DeadlineExceeded(_) => "DeadlineExceeded",
        competition::Error::Solver(solver::Error::Http(_)) => "SolverHttpError",
        competition::Error::Solver(solver::Error::Deserialize(_)) => "SolverDeserializeError",
        competition::Error::Solver(solver::Error::Dto(_)) => "SolverDtoError",
        competition::Error::Solver(solver::Error::CustomError(_)) => "SolverCustomError",
        competition::Error::SubmissionError => "SubmissionError",
        competition::Error::TooManyPendingSettlements => "TooManyPendingSettlements",
        competition::Error::NoValidOrdersFound => "NoValidOrdersFound",
        competition::Error::MalformedRequest => "MalformedRequest",
        competition::Error::FastPathOrderMismatch => "FastPathOrderMismatch",
        competition::Error::FastPathLimitNotMet => "FastPathLimitNotMet",
        competition::Error::FastPathInvalidOrder(_) => "FastPathInvalidOrder",
        competition::Error::FastPathSettlement(_) => "FastPathSettlement",
        competition::Error::EncodingFailed(_) => "EncodingFailed",
    }
}

pub fn deadline(deadline: &Deadline, timeouts: &Timeouts) {
    tracing::trace!(?deadline, ?timeouts, "computed deadline");
}

pub fn sending_solve_request(solver: &str, remaining_time: Duration, is_quote_request: bool) {
    tracing::trace!(?remaining_time, "sending solve request");
    let kind = if is_quote_request { "quote" } else { "auction" };
    metrics::get()
        .remaining_solve_time
        .with_label_values(&[solver, kind])
        .observe(remaining_time.as_secs_f64());
}

#[derive(Debug, Eq, PartialEq, Ord, PartialOrd)]
pub enum OrderExcludedFromAuctionReason {
    CouldNotFetchBalance,
    InsufficientBalance,
    OrderWithZeroAmountRemaining,
}
