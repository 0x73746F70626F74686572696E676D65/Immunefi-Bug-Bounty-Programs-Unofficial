use {
    super::Postgres,
    crate::{boundary, domain, infra::persistence::dto},
    alloy::primitives::Address,
    anyhow::{Context, Result},
    bigdecimal::BigDecimal,
    bytes::Bytes,
    chrono::{DateTime, Utc},
    futures::{
        StreamExt,
        TryStreamExt,
        future::{BoxFuture, FutureExt},
    },
    model::{order::Order, quote::QuoteId},
    num::ToPrimitive,
    price_estimation::QuoteIdGenerating,
    shared::{
        db_order_conversions::full_order_into_model_order,
        order_quoting::{QuoteCompetition, QuoteData, QuoteSearchParameters, QuoteStoring},
        quote_storage::{find_quote, get_quote, save_quote},
    },
    std::{collections::HashMap, ops::DerefMut, sync::Arc},
};

#[async_trait::async_trait]
impl QuoteStoring for Postgres {
    async fn save(&self, data: QuoteCompetition) -> Result<QuoteId> {
        let _timer = super::Metrics::get()
            .database_queries
            .with_label_values(&["save_quote"])
            .start_timer();

        save_quote(&self.pool, data).await
    }

    async fn get(&self, id: QuoteId) -> Result<Option<QuoteData>> {
        let _timer = super::Metrics::get()
            .database_queries
            .with_label_values(&["get_quote"])
            .start_timer();

        get_quote(&self.pool, id).await
    }

    async fn find(
        &self,
        params: QuoteSearchParameters,
        expiration: DateTime<Utc>,
    ) -> Result<Option<(QuoteId, QuoteData)>> {
        let _timer = super::Metrics::get()
            .database_queries
            .with_label_values(&["find_quote"])
            .start_timer();

        find_quote(&self.pool, params, expiration).await
    }

    async fn next_quote_id(&self) -> Result<QuoteId> {
        let _timer = super::Metrics::get()
            .database_queries
            .with_label_values(&["next_quote_id"])
            .start_timer();
        let mut ex = self.pool.acquire().await?;
        database::quotes::next_id(&mut ex)
            .await
            .context("failed to allocate next quote id")
    }
}

impl Postgres {
    pub async fn all_solvable_orders(&self, min_valid_to: u32) -> Result<boundary::SolvableOrders> {
        let _timer = super::Metrics::get()
            .database_queries
            .with_label_values(&["solvable_orders"])
            .start_timer();

        let start = chrono::offset::Utc::now();
        let mut ex = self.pool.begin().await?;
        // Set the transaction isolation level to REPEATABLE READ
        // so the both SELECT queries below are executed in the same database
        // snapshot taken at the moment before the first query is
        // executed.
        sqlx::query("SET TRANSACTION ISOLATION LEVEL REPEATABLE READ")
            .execute(ex.deref_mut())
            .await?;
        let orders: HashMap<domain::OrderUid, Arc<Order>> =
            database::orders::solvable_orders(&mut ex, i64::from(min_valid_to), start.timestamp())
                .map(|result| match result {
                    Ok(order) => full_order_into_model_order(order)
                        .map(|order| (domain::OrderUid(order.metadata.uid.0), Arc::new(order))),
                    Err(err) => Err(anyhow::Error::from(err)),
                })
                .try_collect()
                .await?;
        let latest_settlement_block = database::orders::latest_settlement_block(&mut ex)
            .await?
            .to_u64()
            .context("latest_settlement_block is not u64")?;
        let quotes = self
            .read_quotes(orders.keys())
            .await?
            .into_iter()
            .map(|(uid, quote)| (uid, Arc::new(quote)))
            .collect();
        Ok(boundary::SolvableOrders {
            orders,
            quotes,
            latest_settlement_block,
            fetched_from_db: start,
        })
    }

    pub async fn get_next_auction_id(&self) -> Result<dto::AuctionId> {
        let _timer = super::Metrics::get()
            .database_queries
            .with_label_values(&["get_next_auction_id"])
            .start_timer();

        let mut ex = self.pool.acquire().await?;
        let id = database::auction::get_next_auction_id(&mut ex).await?;
        Ok(id)
    }

    pub async fn replace_current_auction(
        &self,
        new_auction_id: dto::AuctionId,
        json: Bytes,
    ) -> Result<()> {
        let _timer = super::Metrics::get()
            .database_queries
            .with_label_values(&["insert_auction_with_id"])
            .start_timer();

        let data = std::str::from_utf8(&json).context("serialized auction is not valid UTF-8")?;

        let mut ex = self.pool.acquire().await?;
        database::auction::insert_auction_with_id(&mut ex, new_auction_id, data).await?;
        Ok(())
    }

    pub async fn fetch_latest_prices(&self) -> Result<HashMap<Address, BigDecimal>> {
        let _timer = super::Metrics::get()
            .database_queries
            .with_label_values(&["fetch_latest_prices"])
            .start_timer();

        let mut ex = self.pool.acquire().await?;
        Ok(database::auction::fetch_latest_prices(&mut ex)
            .await?
            .into_iter()
            .map(|auction_price| (Address::new(auction_price.token.0), auction_price.price))
            .collect::<HashMap<_, _>>())
    }
}

impl QuoteIdGenerating for Postgres {
    fn generate(&self, n: usize) -> BoxFuture<'_, Result<Vec<QuoteId>>> {
        async move {
            let _timer = super::Metrics::get()
                .database_queries
                .with_label_values(&["next_quote_id_generator"])
                .start_timer();
            let mut ex = self.pool.acquire().await?;
            database::quotes::next_ids(&mut ex, n)
                .await
                .context("failed to allocate quote ids")
        }
        .boxed()
    }
}
