use {
    chain::Chain,
    contracts::{FlashLoanRouter, GPv2Settlement, WETH9, support::Balances},
    eth_domain_types as eth,
    ethrpc::Web3,
};

#[derive(Debug, Clone)]
pub struct Contracts {
    settlement: GPv2Settlement::Instance,
    vault_relayer: eth::ContractAddress,
    signatures: contracts::support::Signatures::Instance,
    weth: WETH9::Instance,

    /// The domain separator for settlement contract used for signing orders.
    settlement_domain_separator: eth::DomainSeparator,

    /// Single router that supports multiple flashloans in the
    /// same settlement.
    // TODO: make this non-optional when contracts are deployed
    // everywhere
    flashloan_router: Option<FlashLoanRouter::Instance>,
    balance_helper: Balances::Instance,

    /// Contract that reverts when the current block exceeds a deadline.
    /// Used to guarantee on-chain that a settlement cannot be included
    /// after its submission deadline.
    deadline_check: contracts::support::DeadlineCheck::Instance,
    web3: Web3,
}

#[derive(Debug, Default, Clone)]
pub struct Addresses {
    pub settlement: Option<eth::ContractAddress>,
    pub signatures: Option<eth::ContractAddress>,
    pub weth: Option<eth::ContractAddress>,
    pub balances: Option<eth::ContractAddress>,
    pub flashloan_router: Option<eth::ContractAddress>,
    pub deadline_check: Option<eth::ContractAddress>,
}

impl Contracts {
    pub(super) async fn new(
        web3: &Web3,
        chain: Chain,
        addresses: Addresses,
    ) -> Result<Self, alloy::contract::Error> {
        let settlement = GPv2Settlement::Instance::new(
            addresses
                .settlement
                .map(Into::into)
                .or_else(|| GPv2Settlement::deployment_address(&chain.id()))
                .unwrap(),
            web3.provider.clone(),
        );
        let vault_relayer = settlement.vaultRelayer().call().await?;
        let balance_helper = Balances::Instance::new(
            addresses
                .balances
                .map(Into::into)
                .or_else(|| Balances::deployment_address(&chain.id()))
                .unwrap(),
            web3.provider.clone(),
        );
        let signatures = contracts::support::Signatures::Instance::new(
            addresses
                .signatures
                .map(Into::into)
                .or_else(|| contracts::support::Signatures::deployment_address(&chain.id()))
                .unwrap(),
            web3.provider.clone(),
        );

        let weth = WETH9::Instance::new(
            addresses
                .weth
                .map(Into::into)
                .or_else(|| WETH9::deployment_address(&chain.id()))
                .unwrap(),
            web3.provider.clone(),
        );

        let settlement_domain_separator = eth::DomainSeparator(
            settlement
                .domainSeparator()
                .call()
                .await
                .expect("domain separator")
                .0,
        );

        // TODO: use `address_for()` once contracts are deployed
        let flashloan_router = addresses
            .flashloan_router
            .or_else(|| {
                FlashLoanRouter::deployment_address(&chain.id()).map(eth::ContractAddress::from)
            })
            .map(|address| FlashLoanRouter::Instance::new(*address, web3.provider.clone()));

        let deadline_check = contracts::support::DeadlineCheck::Instance::new(
            addresses
                .deadline_check
                .map(Into::into)
                .or_else(|| contracts::support::DeadlineCheck::deployment_address(&chain.id()))
                .unwrap(),
            web3.provider.clone(),
        );

        Ok(Self {
            settlement,
            vault_relayer: vault_relayer.into(),
            signatures,
            weth,
            settlement_domain_separator,
            flashloan_router,
            balance_helper,
            deadline_check,
            web3: web3.clone(),
        })
    }

    pub fn settlement(&self) -> &GPv2Settlement::Instance {
        &self.settlement
    }

    pub fn signatures(&self) -> &contracts::support::Signatures::Instance {
        &self.signatures
    }

    pub fn vault_relayer(&self) -> eth::ContractAddress {
        self.vault_relayer
    }

    pub fn weth(&self) -> &WETH9::Instance {
        &self.weth
    }

    pub fn weth_address(&self) -> eth::WrappedNativeToken {
        (*self.weth.address()).into()
    }

    pub fn settlement_domain_separator(&self) -> &eth::DomainSeparator {
        &self.settlement_domain_separator
    }

    pub fn flashloan_router(&self) -> Option<&FlashLoanRouter::Instance> {
        self.flashloan_router.as_ref()
    }

    pub fn balance_helper(&self) -> &Balances::Instance {
        &self.balance_helper
    }

    pub fn deadline_check(&self) -> &contracts::support::DeadlineCheck::Instance {
        &self.deadline_check
    }

    pub fn web3(&self) -> &Web3 {
        &self.web3
    }
}
