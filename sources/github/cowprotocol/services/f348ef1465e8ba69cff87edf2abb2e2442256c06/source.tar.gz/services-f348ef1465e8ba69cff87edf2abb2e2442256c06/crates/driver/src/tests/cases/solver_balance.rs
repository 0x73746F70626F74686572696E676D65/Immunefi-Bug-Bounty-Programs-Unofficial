use {
    crate::tests::{
        setup,
        setup::{ab_order, ab_pool, ab_solution, test_solver},
    },
    eth_domain_types as eth,
};

/// Test that the `/solve` request errors when solver balance is too low.
#[tokio::test]
#[ignore]
async fn test_unfunded() {
    let test = setup()
        .pool(ab_pool())
        .order(ab_order())
        .solution(ab_solution())
        .solvers(vec![
            test_solver().name("unfunded").balance(eth::U256::ZERO),
        ])
        .done()
        .await;

    let solve = test.solve_with_solver("unfunded").await;
    solve.ok().empty();
}

/// Test that the `/solve` request succeeds when the solver has just enough
/// funds
#[tokio::test]
#[ignore]
async fn test_just_enough_funded() {
    let test = setup()
        .pool(ab_pool())
        .order(ab_order())
        .solution(ab_solution())
        .solvers(vec![
            test_solver()
            .name("barely_funded")
            // The solution uses ~500k gas units
            // With gas costs <20gwei, 0.01 ETH should suffice
            .balance(eth::U256::from(10).pow(eth::U256::from(16))),
        ])
        .done()
        .await;

    let id = test.solve_with_solver("barely_funded").await.ok().id();
    test.settle_with_solver("barely_funded", id)
        .await
        .ok()
        .await;
}
