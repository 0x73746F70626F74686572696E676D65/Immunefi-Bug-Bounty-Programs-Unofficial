//! Fans the auction out to the configured drivers.

use {
    crate::{
        domain::{
            auction::{Auction, Order, OrderKind},
            cycle::{SolanaCycle, Solution},
        },
        infra::driver::{Driver, dto},
        run_loop::SolverCompetition,
    },
    async_trait::async_trait,
    chain_types::solana::{IntentHash, Solana},
    std::{
        collections::{HashMap, HashSet},
        sync::Arc,
        time::Duration,
    },
    winner_selection::{Side, solution},
};

/// Sends `/solve` to every driver and converts the answers into attributable
/// solutions for the arbitrator.
pub struct DriverCompetition {
    drivers: Vec<Arc<Driver>>,
    /// How long a driver gets to answer `/solve`.
    solve_deadline: Duration,
}

impl DriverCompetition {
    pub fn new(drivers: Vec<Arc<Driver>>, solve_deadline: Duration) -> Self {
        Self {
            drivers,
            solve_deadline,
        }
    }
}

#[async_trait]
impl SolverCompetition<SolanaCycle> for DriverCompetition {
    async fn solve(&self, auction: &Auction) -> Vec<Solution> {
        let request = &dto::SolveRequest {
            id: auction.id,
            deadline: chrono::Utc::now() + self.solve_deadline,
            orders: auction.orders.iter().map(dto::Order::from).collect(),
        };
        let by_uid: HashMap<IntentHash, &Order> = auction
            .orders
            .iter()
            .map(|order| (order.uid, order))
            .collect();

        // The deadline sent to the drivers is also enforced here: a response
        // landing after it is dropped, so one hung driver cannot hold the
        // loop for the HTTP client's whole ceiling.
        let budget = self.solve_deadline;
        let responses = futures::future::join_all(self.drivers.iter().enumerate().map(
            |(driver_index, driver)| async move {
                match tokio::time::timeout(budget, driver.solve(request)).await {
                    Ok(Ok(response)) => Some((driver_index, driver, response)),
                    Ok(Err(err)) => {
                        tracing::warn!(driver = %driver.name, ?err, "solve failed");
                        None
                    }
                    Err(_) => {
                        tracing::warn!(driver = %driver.name, "solve missed the deadline");
                        None
                    }
                }
            },
        ))
        .await;

        let mut solutions = Vec::new();
        // `(solver, solution id)` attributes a ranked solution back to its
        // driver, so a duplicate would misdispatch the settlement: keep the
        // first and drop the rest.
        let mut seen = HashSet::new();
        for (driver_index, driver, response) in responses.into_iter().flatten() {
            for dto_solution in response.solutions {
                let duplicate = !seen.insert((dto_solution.solver, dto_solution.solution_id));
                if duplicate {
                    tracing::warn!(
                        driver = %driver.name,
                        solution_id = dto_solution.solution_id,
                        "duplicate solver and solution id, dropped"
                    );
                    continue;
                }
                match convert(driver_index, dto_solution, &by_uid) {
                    Ok(solution) => {
                        tracing::debug!(
                            driver = %driver.name,
                            solution = solution.inner.id(),
                            orders = ?solution
                                .inner
                                .orders()
                                .iter()
                                .map(|o| format!(
                                    "{} {:?} sell {:?}/{:?} buy {:?}/{:?}",
                                    o.uid,
                                    o.side,
                                    o.executed_sell,
                                    o.sell_amount,
                                    o.executed_buy,
                                    o.buy_amount
                                ))
                                .collect::<Vec<_>>(),
                            "proposed solution"
                        );
                        solutions.push(solution);
                    }
                    Err(uids) => tracing::warn!(
                        driver = %driver.name,
                        orders = ?uids.iter().map(ToString::to_string).collect::<Vec<_>>(),
                        "solution names orders outside the auction, dropped"
                    ),
                }
            }
        }
        solutions
    }
}

/// A wire solution becomes an arbitrator solution by joining each traded
/// order against the auction for its limits and tokens. A trade naming an
/// order outside the auction voids the whole solution: its intent cannot be
/// scored.
fn convert(
    driver_index: usize,
    dto_solution: dto::Solution,
    by_uid: &HashMap<IntentHash, &Order>,
) -> Result<Solution, Vec<IntentHash>> {
    let mut missing = Vec::new();
    let orders: Vec<_> = dto_solution
        .orders
        .iter()
        .filter_map(|(uid, amounts)| {
            let Some(order) = by_uid.get(uid) else {
                missing.push(*uid);
                return None;
            };
            Some(solution::Order::<Solana> {
                uid: *uid,
                sell_token: order.sell_token,
                buy_token: order.buy_token,
                sell_amount: order.sell_amount,
                buy_amount: order.buy_amount,
                executed_sell: amounts.executed_sell,
                executed_buy: amounts.executed_buy,
                side: match order.kind {
                    OrderKind::Sell => Side::Sell,
                    OrderKind::Buy => Side::Buy,
                },
            })
        })
        .collect();
    if !missing.is_empty() {
        return Err(missing);
    }
    Ok(Solution {
        driver_index,
        inner: solution::Solution::new(dto_solution.solution_id, dto_solution.solver, orders),
    })
}
