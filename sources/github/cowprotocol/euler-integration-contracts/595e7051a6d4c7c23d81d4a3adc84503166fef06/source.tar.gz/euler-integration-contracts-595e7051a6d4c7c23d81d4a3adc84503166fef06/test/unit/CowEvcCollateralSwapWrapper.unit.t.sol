// SPDX-License-Identifier: MIT OR Apache-2.0
pragma solidity ^0.8;

import {IEVC} from "evc/EthereumVaultConnector.sol";
import {UnitTestBase} from "./UnitTestBase.sol";
import {Vm} from "forge-std/Vm.sol";
import {FfiUtils} from "./FfiUtils.sol";

import {CowEvcBaseWrapper} from "../../src/CowEvcBaseWrapper.sol";
import {CowEvcCollateralSwapWrapper} from "../../src/CowEvcCollateralSwapWrapper.sol";
import {ICowSettlement} from "../../src/CowWrapper.sol";
import {MockERC20, MockVault} from "./mocks/MockERC20AndVaults.sol";
import {Constants} from "../helpers/Constants.sol";

// this is required because foundry doesn't have a cheatcode for override any transient storage.
contract TestableCollateralSwapWrapper is CowEvcCollateralSwapWrapper {
    constructor(address _evc, ICowSettlement _settlement) CowEvcCollateralSwapWrapper(_evc, _settlement) {}

    function setExpectedEvcInternalSettleCall(bytes memory call) external {
        expectedEvcInternalSettleCallHash = keccak256(call);
    }
}

/// @title Unit tests for CowEvcCollateralSwapWrapper
/// @notice Comprehensive unit tests focusing on isolated functionality testing with mocks
contract CowEvcCollateralSwapWrapperUnitTest is UnitTestBase {
    using FfiUtils for Vm;
    MockERC20 public mockFromAsset;
    MockERC20 public mockToAsset;
    MockVault public mockFromVault;
    MockVault public mockToVault;

    uint256 constant DEFAULT_SWAP_AMOUNT = 1000e18;

    // Constants from the contract
    bytes32 private constant KIND_SELL = keccak256("sell");
    bytes32 private constant KIND_BUY = keccak256("buy");

    /// @notice Get default CollateralSwapParams for testing
    function _getDefaultParams() internal view returns (CowEvcCollateralSwapWrapper.CollateralSwapParams memory) {
        return CowEvcCollateralSwapWrapper.CollateralSwapParams({
            owner: OWNER,
            account: ACCOUNT,
            deadline: block.timestamp + 1 hours,
            fromVault: address(mockFromVault),
            toVault: address(mockToVault),
            fromAmount: DEFAULT_SWAP_AMOUNT,
            disableSourceCollateral: false
        });
    }

    /// @notice Encode wrapper data
    function _encodeWrapperData(CowEvcCollateralSwapWrapper.CollateralSwapParams memory params, bytes memory signature)
        internal
        pure
        returns (bytes memory)
    {
        return abi.encode(params, signature);
    }

    /// @notice Encode wrapper data with length prefix for single chained wrapper
    /// @dev Combines encoding params+signature and adding length prefix
    function _encodeSingleChainedWrapperData(
        CowEvcCollateralSwapWrapper.CollateralSwapParams memory params,
        bytes memory signature
    ) internal pure returns (bytes memory) {
        bytes memory wrapperData = _encodeWrapperData(params, signature);
        return abi.encodePacked(uint16(wrapperData.length), wrapperData);
    }

    function _prepareSuccessfulPermitFlow()
        internal
        view
        override
        returns (bytes memory settleData, bytes memory wrapperData)
    {
        // A permit settlement is triggered by having signature data in `wrapperData`.
        // For unit testing, we can just use 65 bytes of "zero" signtaure since we're not actually verifying it here.
        wrapperData = _encodeSingleChainedWrapperData(_getDefaultParams(), new bytes(65));
        settleData = _getEmptySettleData();
    }

    function _prepareSuccessfulPreApproveFlow()
        internal
        view
        override
        returns (bytes memory settleData, bytes memory wrapperData, bytes32 hash)
    {
        CowEvcCollateralSwapWrapper.CollateralSwapParams memory params = _getDefaultParams();

        // A pre-hash settlement is triggered by having 0-length signature data in `wrapperData`.
        wrapperData = _encodeSingleChainedWrapperData(params, new bytes(0));
        settleData = _getEmptySettleData();
        hash = CowEvcCollateralSwapWrapper(address(wrapper)).getApprovalHash(params);
    }

    function setUp() public override {
        super.setUp();
        mockFromAsset = new MockERC20("Mock Asset From", "MOCKFROM");
        mockToAsset = new MockERC20("Mock Asset To", "MOCKTO");
        mockFromVault = new MockVault(mockEvc, address(mockFromAsset), "Mock From Vault", "eMOCKFROM");
        mockToVault = new MockVault(mockEvc, address(mockToAsset), "Mock To Vault", "eMOCKTO");

        wrapper = CowEvcBaseWrapper(
            new TestableCollateralSwapWrapper(address(mockEvc), ICowSettlement(address(mockSettlement)))
        );

        mockFromVault.mint(ACCOUNT, 1000e18);

        mockFromVault.mint(OWNER, 2000e18);

        vm.prank(OWNER);
        require(mockFromVault.approve(address(wrapper), 2000e18));
    }

    /*//////////////////////////////////////////////////////////////
                        CONSTRUCTOR TESTS
    //////////////////////////////////////////////////////////////*/

    function test_Constructor_SetsDomainSeparator() public view {
        bytes32 expectedDomainSeparator = keccak256(
            abi.encode(
                Constants.EIP712_DOMAIN_TYPE_HASH,
                keccak256("CowEvcCollateralSwapWrapper"),
                keccak256("1"),
                block.chainid,
                address(wrapper)
            )
        );
        assertEq(wrapper.DOMAIN_SEPARATOR(), expectedDomainSeparator, "DOMAIN_SEPARATOR incorrect");
    }

    // Uses forge's provided `eip712` function to get the typehash of the actual struct definition and ensure it matches
    function test_Constructor_CorrectParamsTypeHash() public {
        string[] memory inputs = new string[](3);
        inputs[0] = "bash";
        inputs[1] = "-c";
        inputs[2] =
            "forge eip712 --json ./src/CowEvcCollateralSwapWrapper.sol | jq -r '.[] | select(.type | startswith(\"CollateralSwapParams\")) | .hash'";
        assertEq(
            abi.decode(vm.ffiOrSkip(inputs), (bytes32)),
            wrapper.PARAMS_TYPE_HASH(),
            "PARAMS_TYPE_HASH does not match up to params object"
        );
    }

    /*//////////////////////////////////////////////////////////////
                    APPROVAL HASH TESTS
    //////////////////////////////////////////////////////////////*/

    function test_GetApprovalHash_DifferentForDifferentParams() public view {
        CowEvcCollateralSwapWrapper.CollateralSwapParams memory params1 = _getDefaultParams();

        // Change owner field
        CowEvcCollateralSwapWrapper.CollateralSwapParams memory params2 = _getDefaultParams();
        params2.owner = ACCOUNT;

        // Change fromAmount field
        CowEvcCollateralSwapWrapper.CollateralSwapParams memory params3 = _getDefaultParams();
        params3.fromAmount = 2000e18;

        bytes32 hash1 = CowEvcCollateralSwapWrapper(address(wrapper)).getApprovalHash(params1);
        bytes32 hash2 = CowEvcCollateralSwapWrapper(address(wrapper)).getApprovalHash(params2);
        bytes32 hash3 = CowEvcCollateralSwapWrapper(address(wrapper)).getApprovalHash(params3);

        assertNotEq(hash1, hash2, "Hash should differ for different params");
        assertNotEq(hash1, hash3, "Hash should differ for different params");
    }

    /*//////////////////////////////////////////////////////////////
                    WRAPPED SETTLE TESTS
    //////////////////////////////////////////////////////////////*/
    function test_WrappedSettle_PreApprovedHashRevertsIfDeadlineExceeded() public {
        CowEvcCollateralSwapWrapper.CollateralSwapParams memory params = _getDefaultParams();
        params.account = OWNER; // Same account
        params.deadline = block.timestamp - 1; // Past deadline

        bytes32 hash = CowEvcCollateralSwapWrapper(address(wrapper)).getApprovalHash(params);
        vm.prank(OWNER);
        wrapper.setPreApprovedHash(hash, true);

        bytes memory settleData = _getEmptySettleData();
        bytes memory wrapperData = _encodeSingleChainedWrapperData(params, new bytes(0));

        vm.prank(SOLVER);
        vm.expectRevert(
            abi.encodeWithSelector(
                CowEvcBaseWrapper.OperationDeadlineExceeded.selector, params.deadline, block.timestamp
            )
        );
        wrapper.wrappedSettle(settleData, wrapperData);
    }

    /*//////////////////////////////////////////////////////////////
                    ENCODE PERMIT DATA TESTS
    //////////////////////////////////////////////////////////////*/

    function test_EncodePermitData_IsCorrectSameOwnerAccount() public view {
        CowEvcCollateralSwapWrapper.CollateralSwapParams memory params = _getDefaultParams();
        params.account = OWNER;

        bytes memory permitData = CowEvcCollateralSwapWrapper(address(wrapper)).encodePermitData(params);
        (IEVC.BatchItem[] memory items, bytes32 paramsHash) = _decodePermitData(permitData);

        // For same owner and account, only the enableCollateral call should be needed, no transfer
        assertEq(items.length, 1, "Should have correct batch item count");
        assertEq(items[0].targetContract, address(mockEvc), "Should target EVC");
        assertEq(
            items[0].data,
            abi.encodeCall(IEVC.enableCollateral, (params.account, params.toVault)),
            "Should call enableCollateral"
        );
        assertEq(items[0].onBehalfOfAccount, address(0), "Should have zero onBehalfOfAccount");

        assertEq(
            paramsHash,
            CowEvcCollateralSwapWrapper(address(wrapper)).getApprovalHash(params),
            "Params hash should match"
        );
    }

    function test_EncodePermitData_IsCorrectDifferentOwnerAccount() public view {
        CowEvcCollateralSwapWrapper.CollateralSwapParams memory params = _getDefaultParams();

        bytes memory permitData = CowEvcCollateralSwapWrapper(address(wrapper)).encodePermitData(params);
        (IEVC.BatchItem[] memory items, bytes32 paramsHash) = _decodePermitData(permitData);

        assertEq(items.length, 2, "Should have correct batch item count");
        assertEq(items[0].targetContract, params.fromVault, "Should target fromVault");
        assertEq(
            items[0].data,
            abi.encodeCall(MockERC20.transfer, (address(OWNER), params.fromAmount)),
            "Should call transfer"
        );
        assertEq(items[0].onBehalfOfAccount, ACCOUNT, "Should be sent on behalf of the account");
        assertEq(items[1].targetContract, address(mockEvc), "Should target EVC");
        assertEq(
            items[1].data,
            abi.encodeCall(IEVC.enableCollateral, (params.account, params.toVault)),
            "Should call enableCollateral"
        );
        assertEq(items[1].onBehalfOfAccount, address(0), "Should have zero onBehalfOfAccount");

        assertEq(
            paramsHash,
            CowEvcCollateralSwapWrapper(address(wrapper)).getApprovalHash(params),
            "Params hash should match"
        );
    }

    function test_EncodePermitData_IsCorrectDisableCollateral() public view {
        CowEvcCollateralSwapWrapper.CollateralSwapParams memory params = _getDefaultParams();
        params.account = OWNER;
        params.disableSourceCollateral = true;

        bytes memory permitData = CowEvcCollateralSwapWrapper(address(wrapper)).encodePermitData(params);
        (IEVC.BatchItem[] memory items, bytes32 paramsHash) = _decodePermitData(permitData);

        // When disableSourceCollateral is true, there should be an additional batch item to disable the old collateral
        assertEq(items.length, 2, "Should have correct batch item count");

        assertEq(items[0].targetContract, address(mockEvc), "Should target EVC");
        assertEq(
            items[0].data,
            abi.encodeCall(IEVC.disableCollateral, (params.account, params.fromVault)),
            "Should call disableCollateral"
        );
        assertEq(items[0].onBehalfOfAccount, address(0), "Should have zero onBehalfOfAccount");

        assertEq(items[1].targetContract, address(mockEvc), "Should target EVC");
        assertEq(
            items[1].data,
            abi.encodeCall(IEVC.enableCollateral, (params.account, params.toVault)),
            "Should call enableCollateral"
        );
        assertEq(items[1].onBehalfOfAccount, address(0), "Should have zero onBehalfOfAccount");

        assertEq(
            paramsHash,
            CowEvcCollateralSwapWrapper(address(wrapper)).getApprovalHash(params),
            "Params hash should match"
        );
    }

    function test_EncodePermitData_IsCorrectDifferentOwnerAccountDisableCollateral() public view {
        CowEvcCollateralSwapWrapper.CollateralSwapParams memory params = _getDefaultParams();
        params.disableSourceCollateral = true;

        bytes memory permitData = CowEvcCollateralSwapWrapper(address(wrapper)).encodePermitData(params);
        (IEVC.BatchItem[] memory items, bytes32 paramsHash) = _decodePermitData(permitData);

        // When both different owner/account and disableSourceCollateral are true, there should be 3 batch items
        assertEq(items.length, 3, "Should have correct batch item count");
        assertEq(items[0].targetContract, params.fromVault, "Should target fromVault");
        assertEq(
            items[0].data,
            abi.encodeCall(MockERC20.transfer, (address(OWNER), params.fromAmount)),
            "Should call transfer"
        );
        assertEq(items[0].onBehalfOfAccount, ACCOUNT, "Should be sent on behalf of the account");

        assertEq(items[1].targetContract, address(mockEvc), "Should target EVC");
        assertEq(
            items[1].data,
            abi.encodeCall(IEVC.disableCollateral, (params.account, params.fromVault)),
            "Should call disableCollateral"
        );
        assertEq(items[1].onBehalfOfAccount, address(0), "Should have zero onBehalfOfAccount");

        assertEq(items[2].targetContract, address(mockEvc), "Should target EVC");
        assertEq(
            items[2].data,
            abi.encodeCall(IEVC.enableCollateral, (params.account, params.toVault)),
            "Should call enableCollateral"
        );
        assertEq(items[2].onBehalfOfAccount, address(0), "Should have zero onBehalfOfAccount");

        assertEq(
            paramsHash,
            CowEvcCollateralSwapWrapper(address(wrapper)).getApprovalHash(params),
            "Params hash should match"
        );
    }

    /*//////////////////////////////////////////////////////////////
                    EDGE CASE TESTS
    //////////////////////////////////////////////////////////////*/

    function test_WrappedSettle_ZeroCollateralSwap_SameOwnerAccount() public {
        CowEvcCollateralSwapWrapper.CollateralSwapParams memory params = _getDefaultParams();
        params.account = OWNER; // Same as owner
        params.fromAmount = 0; // Zero swap amount

        bytes32 hash = CowEvcCollateralSwapWrapper(address(wrapper)).getApprovalHash(params);
        vm.prank(OWNER);
        wrapper.setPreApprovedHash(hash, true);

        bytes memory settleData = _getEmptySettleData();
        bytes memory wrapperData = _encodeSingleChainedWrapperData(params, new bytes(0));

        // Setup expected EVC internal settle call
        TestableCollateralSwapWrapper(address(wrapper))
            .setExpectedEvcInternalSettleCall(
                abi.encodeCall(CowEvcBaseWrapper.evcInternalSettle, (settleData, wrapperData, new bytes(0)))
            );

        // The call should succeed - there's no validation preventing 0 amount transfers
        vm.prank(SOLVER);
        vm.expectEmit();
        emit CowEvcCollateralSwapWrapper.CowEvcCollateralSwapped(
            params.owner, params.account, params.fromVault, params.toVault, 0, false
        );
        wrapper.wrappedSettle(settleData, wrapperData);
    }

    function test_WrappedSettle_ZeroCollateralSwap_DifferentOwnerAccount() public {
        CowEvcCollateralSwapWrapper.CollateralSwapParams memory params = _getDefaultParams();
        params.fromAmount = 0; // Zero swap amount

        bytes32 hash = CowEvcCollateralSwapWrapper(address(wrapper)).getApprovalHash(params);
        vm.prank(OWNER);
        wrapper.setPreApprovedHash(hash, true);

        bytes memory settleData = _getEmptySettleData();
        bytes memory wrapperData = _encodeSingleChainedWrapperData(params, new bytes(0));

        // Setup expected EVC internal settle call
        TestableCollateralSwapWrapper(address(wrapper))
            .setExpectedEvcInternalSettleCall(
                abi.encodeCall(CowEvcBaseWrapper.evcInternalSettle, (settleData, wrapperData, new bytes(0)))
            );

        // With different owner/account, a transfer of 0 tokens should be attempted
        // This should succeed as transferring 0 tokens is typically allowed
        vm.prank(SOLVER);
        vm.expectEmit();
        emit CowEvcCollateralSwapWrapper.CowEvcCollateralSwapped(
            params.owner, params.account, params.fromVault, params.toVault, 0, false
        );
        wrapper.wrappedSettle(settleData, wrapperData);
    }

    function test_WrappedSettle_SameFromAndToVault() public {
        CowEvcCollateralSwapWrapper.CollateralSwapParams memory params = _getDefaultParams();
        params.toVault = params.fromVault; // Same vault for both from and to

        bytes32 hash = CowEvcCollateralSwapWrapper(address(wrapper)).getApprovalHash(params);
        vm.prank(OWNER);
        wrapper.setPreApprovedHash(hash, true);

        bytes memory settleData = _getEmptySettleData();
        bytes memory wrapperData = _encodeSingleChainedWrapperData(params, new bytes(0));

        // Setup expected EVC internal settle call
        TestableCollateralSwapWrapper(address(wrapper))
            .setExpectedEvcInternalSettleCall(
                abi.encodeCall(CowEvcBaseWrapper.evcInternalSettle, (settleData, wrapperData, new bytes(0)))
            );

        // No validation prevents swapping from/to the same vault
        // Transaction should succeed but accomplishes nothing economically useful
        vm.prank(SOLVER);
        vm.expectEmit();
        emit CowEvcCollateralSwapWrapper.CowEvcCollateralSwapped(
            params.owner, params.account, params.fromVault, params.fromVault, DEFAULT_SWAP_AMOUNT, false
        );
        wrapper.wrappedSettle(settleData, wrapperData);
    }
}
