// SPDX-License-Identifier: MIT OR Apache-2.0
pragma solidity ^0.8;

import {IEVC} from "evc/EthereumVaultConnector.sol";

import {CowWrapper, ICowSettlement} from "./CowWrapper.sol";
import {PreApprovedHashes} from "./PreApprovedHashes.sol";
import {Errors} from "./Errors.sol";

/// @title CowEvcBaseWrapper
/// @notice Shared components for implementing Euler wrappers.
abstract contract CowEvcBaseWrapper is CowWrapper, PreApprovedHashes {
    /// @dev location in memory of the parameters describing the wrapper implementation.
    type ParamsLocation is bytes32;

    IEVC public immutable EVC;

    /// @dev The EIP-712 domain type hash used for computing the domain
    /// separator.
    bytes32 public constant DOMAIN_TYPE_HASH =
        keccak256("EIP712Domain(string name,string version,uint256 chainId,address verifyingContract)");

    /// @dev Used by EIP-712 signing to prevent signatures from being replayed
    bytes32 public immutable DOMAIN_SEPARATOR;

    /// @dev The EVC nonce namespace to use when calling `EVC.permit` to authorize this contract.
    /// See: https://evc.wtf/docs/concepts/internals/permit/#nonce-namespaces
    uint256 public immutable NONCE_NAMESPACE;

    /// @dev The length of the parameters consumed by this wrapper. Used in order to know how much data to read after the ParamsLocation for the hash.
    /// Ideally this should be computed by creating the parameters struct and then `abi.encode().length` to ensure its always the correct size.
    uint256 internal immutable PARAMS_SIZE;

    /// @dev The EIP-712 type hash of the parameters structure used by this wrapper.
    bytes32 public immutable PARAMS_TYPE_HASH;

    /// @dev How long to make the `items` array without calculating it. Determines the maximum number of EVC operations that can be batched.
    /// This value depends on the each concrete wrapper implementation. It should include the settlement and any operations before and after it.
    uint256 internal immutable MAX_BATCH_OPERATIONS;

    /// @dev Indicates that the current operation cannot be completed with the given msgSender
    error Unauthorized(address msgSender);

    /// @dev Indicates that the pre-approved hash is no longer able to be executed because the block timestamp is too old
    error OperationDeadlineExceeded(uint256 validToTimestamp, uint256 currentTimestamp);

    /// @dev Indicates that the EVC called `evcInternalSettle` in an invalid way
    error InvalidCallback();

    /// @dev Indicates that the EVC called `evcInternalSettle` with an `onBehalfOf` account that is not this contract, which is required for the callback to be valid
    error InvalidOnBehalfOf(address onBehalfOf, address expected);

    /// @dev Indicates that neither `_encodeBatchItemsBefore` nor `_encodeBatchItemsAfter` requested permission, meaning the provided permit signature is unused.
    error UnusedPermitSignature();

    error IncorrectPermissionConfiguration(bool beforePermissionRequested, bool afterPermissionRequested);

    /// @dev Used to ensure that the EVC is calling back this contract with the correct data
    bytes32 internal transient expectedEvcInternalSettleCallHash;

    constructor(address _evc, ICowSettlement _settlement, bytes32 _domainName, bytes32 _domainVersion)
        CowWrapper(_settlement)
    {
        require(_evc.code.length > 0, "EVC address is invalid");
        EVC = IEVC(_evc);
        NONCE_NAMESPACE = uint256(uint160(address(this)));
        DOMAIN_SEPARATOR =
            keccak256(abi.encode(DOMAIN_TYPE_HASH, _domainName, _domainVersion, block.chainid, address(this)));
    }

    /// @notice Encode batch items to execute before the settlement
    /// @dev By default we return the default value (empty array, false).
    /// At least one between this function and `_encodeBatchItemsAfter` should need permission (i.e., use the permit signature) for the permit flow to be secure.
    /// @param location The memory storage position where the parameters needed to encode the batch items have been saved
    /// @return items Array of batch items to execute
    /// @return needsPermission Whether these items require user signature or prior authorization as an operator
    function _encodeBatchItemsBefore(ParamsLocation location)
        internal
        view
        virtual
        returns (IEVC.BatchItem[] memory items, bool needsPermission)
    {}

    /// @notice Encode batch items to execute after the settlement
    /// @dev By default we return the default value (empty array, false).
    /// At least one between this function and `_encodeBatchItemsBefore` should need permission (i.e., use the permit signature) for the permit flow to be secure.
    /// @param location The memory storage position where the parameters needed to encode the batch items have been saved
    /// @return items Array of batch items to execute
    /// @return needsPermission Whether these items require user signature or prior authorization as an operator
    function _encodeBatchItemsAfter(ParamsLocation location)
        internal
        view
        virtual
        returns (IEVC.BatchItem[] memory items, bool needsPermission)
    {}

    /// @dev This function makes strong assumptions on the memory layout of the struct in memory.
    /// It assumes:
    ///  - The struct itself doesn't contain any dynamic-length types.
    ///  - The struct is encoded in memory with zero padding.
    /// @param params The memory location of the struct data
    /// @return digest The EIP-712 compliant digest
    function _getApprovalHash(ParamsLocation params) internal view returns (bytes32 digest) {
        bytes32 structHash;
        bytes32 separator = DOMAIN_SEPARATOR;
        bytes32 typeHash = PARAMS_TYPE_HASH;
        uint256 paramsSize = PARAMS_SIZE;
        assembly {
            // Build structHash = keccak256(typeHash || encodeData(params))
            let wordBeforeParamPtr := sub(params, 0x20)
            // Subtraction overflow causes the next line to revert with out of gas if params isn't allocated
            let wordBeforeParam := mload(wordBeforeParamPtr)
            mstore(wordBeforeParamPtr, typeHash)
            structHash := keccak256(wordBeforeParamPtr, add(0x20, paramsSize))
            // Restore original content
            mstore(wordBeforeParamPtr, wordBeforeParam)

            // Build digest = keccak256("\x19\x01" || domainSeparator || structHash)
            let ptr := mload(0x40)
            mstore(ptr, "\x19\x01")
            mstore(add(ptr, 0x02), separator)
            mstore(add(ptr, 0x22), structHash)
            digest := keccak256(ptr, 0x42)
        }
    }

    /// @notice Generates the permit data that would be used for the given EVC batch items (presumably generated from params)
    function _encodePermitData(IEVC.BatchItem[] memory items, ParamsLocation params)
        internal
        view
        returns (bytes memory)
    {
        // The abi.encodeCall() part consists of the batch call that we want to execute. The additional data tacked on the end is to ensure
        // the provided parameters are all validated against the user signature, even if `items` doesn't completely use the parameters in effect.
        return abi.encodePacked(abi.encodeCall(IEVC.batch, items), _getApprovalHash(params));
    }

    /// @notice This function is called by EVC and continues the CoW settlement process inside an EVC batch while including any necessary security check.
    function evcInternalSettle(
        bytes calldata settleData,
        bytes calldata wrapperData,
        bytes calldata remainingWrapperData
    ) external {
        require(msg.sender == address(EVC), Unauthorized(msg.sender));
        (address onBehalfOf,) = EVC.getCurrentOnBehalfOfAccount(address(0));
        require(onBehalfOf == address(this), InvalidOnBehalfOf(onBehalfOf, address(this)));
        require(expectedEvcInternalSettleCallHash == keccak256(msg.data), InvalidCallback());
        expectedEvcInternalSettleCallHash = bytes32(0);

        _evcInternalSettle(settleData, wrapperData, remainingWrapperData);
    }

    function _makeInternalSettleCallbackData(
        bytes calldata settleData,
        bytes calldata wrapperData,
        bytes calldata remainingWrapperData
    ) internal pure returns (bytes memory) {
        return abi.encodeCall(CowEvcBaseWrapper.evcInternalSettle, (settleData, wrapperData, remainingWrapperData));
    }

    function _invokeEvc(
        bytes memory evcInternalSettleCallback,
        ParamsLocation param,
        bytes memory signature,
        address owner,
        address account,
        uint256 deadline
    ) internal {
        // Subaccounts in the EVC can be any account that shares the highest 19 bits as the owner.
        // Here we verify that the subaccount address has been specified is, in fact, a subaccount of the owner.
        // Otherwise its concievably possible that a transfer could happen between an owner with an unauthorized subaccount.
        require(
            bytes19(bytes20(owner)) == bytes19(bytes20(account)),
            Errors.SubaccountMustBeControlledByOwner(account, owner)
        );

        // There are 2 ways that this contract can validate user operations: 1) the user pre-approves a hash with an on-chain call and grants this contract ability to operate on the user's behalf, or 2) they issue a signature which can be used to call EVC.permit()
        // The choice of the flow is based on whether `signature` has length zero. If so, then we use the hash approval flow (1).
        // Otherwise, the signature is assumed to be one for EVC.permit (2).
        // The permit signature is verified against the permit generated by `_encodePermitData`; the parameters are validated because they are unequivocally encoded in the signed permit.
        if (signature.length == 0) {
            _consumePreApprovedHash(owner, _getApprovalHash(param));
            // The deadline is checked by `EVC.permit()`, so we only check it here if we are using a pre-approved hash (aka, no signature) which would bypass that call
            require(deadline >= block.timestamp, OperationDeadlineExceeded(deadline, block.timestamp));
        }

        // Build the EVC batch items for swapping collateral
        IEVC.BatchItem[] memory items = new IEVC.BatchItem[](MAX_BATCH_OPERATIONS);

        uint256 itemIndex = 0;

        {
            // add any EVC actions that have to be performed before
            IEVC.BatchItem[] memory partialItems;
            bool beforePermissionRequested;
            bool afterPermissionRequested;

            (partialItems, beforePermissionRequested) = _encodeBatchItemsBefore(param);
            itemIndex = _addEvcBatchItems(
                items,
                partialItems,
                itemIndex,
                owner,
                deadline,
                beforePermissionRequested ? signature : new bytes(0),
                param
            );

            // add the EVC callback to this (which calls settlement)
            expectedEvcInternalSettleCallHash = keccak256(evcInternalSettleCallback);
            items[itemIndex++] = IEVC.BatchItem({
                onBehalfOfAccount: address(this),
                targetContract: address(this),
                value: 0,
                data: evcInternalSettleCallback
            });

            // add the EVC actions that have to be performed after
            (partialItems, afterPermissionRequested) = _encodeBatchItemsAfter(param);
            itemIndex = _addEvcBatchItems(
                items,
                partialItems,
                itemIndex,
                owner,
                deadline,
                afterPermissionRequested ? signature : new bytes(0),
                param
            );

            // exactly one of the two encodeBatchItems functions needs to request permission (aka, use the signature or pre-approved hash),
            // otherwise the signature provided is not actually needed for any of the operations, which would be a security risk.
            // Conversely, if both of them request permission, its not a security risk, but it's not supported.
            // So we check that of them requested permission, and if not, we revert.
            require(
                beforePermissionRequested != afterPermissionRequested,
                IncorrectPermissionConfiguration(beforePermissionRequested, afterPermissionRequested)
            );
        }

        // shorten the length of the generated array to its actual length
        // We assume as an a invariant that the code above will not generate a `itemIndex` greater than `MAX_BATCH_OPERATIONS` at this point
        // because we always add an item to the items array when we increment `itemIndex`, and if the itemIndex goes out of bounds,
        // solidity will revert
        assembly ("memory-safe") {
            mstore(items, itemIndex)
        }

        // 3. Account status check (automatically done by EVC at end of batch)
        // For more info, see: https://evc.wtf/docs/concepts/internals/account-status-checks
        // No explicit item needed - EVC handles this

        // Execute all items in a single batch
        EVC.batch(items);

        // The pre approved hash flow needs the user to set this contract as an operator for both the owner address itself and the subaccount.
        // The EVC treats owner and subaccount operator authorizations separately, so we need to relinquish them separately
        if (signature.length == 0) {
            // This function returns both account and subaccount operator authorizations as a bitmask.
            // So we can do one call to find out what accounts are authorized, and then remove them as needed.
            uint256 mask = EVC.getOperator(bytes19(bytes20(owner)), address(this));

            // check subaccount control
            // despite the lint, the shift is correct. This is the same way
            // the calculation is done in the EthereumVaultConnector contract.
            // https://github.com/euler-xyz/ethereum-vault-connector/blob/v1.0.1/src/EthereumVaultConnector.sol#L387
            /// forge-lint: disable-next-line(incorrect-shift)
            if ((mask & (1 << (uint160(owner) ^ uint160(account)))) > 0) {
                EVC.setAccountOperator(account, address(this), false);
            }

            // check owner account control. If the owner is the subaccount, there is no need to set the operator again.
            if (owner != account && mask & 1 > 0) {
                EVC.setAccountOperator(owner, address(this), false);
            }
        }
    }

    /// @dev Helper function to add IEVC.BatchItem to the EVC.batch call with any authorization that may be required.
    /// Depending on whether a signature is provided, this function will either copy `addItems` into `fullItems` at the given position,
    /// or `addItems` will be condensed into a single `EVC.permit` call and then added to the batch as a single item.
    /// @param fullItems The items which will ultimately be executed by EVC.batch
    /// @param addItems The items which need to be added to fullItems with appropriate authorization wrapping as needed
    /// @param itemIndex The index in `fullItems` starting from which `addItems` should be written
    /// @param owner The owner who is granting permission to execute the operations. Needed to construct the `EVC.permit`
    /// @param deadline The time at which the permit signature would expire. needed to construct the `EVC.permit`
    /// @param signature The signature used to validate the EVC.permit. If this is set to `new bytes(0)`, no permit will be used, and the items will be copied directly instead.
    /// @param param The input parameters for this trade. Needed to construct the `EVC.permit`, as the params data hash is appended to the end of the batch to ensure the signed `EVC.permit` can't be used with parameters that the user didn't sign.
    /// @return The index immediately after the last item written to `fullItems`
    function _addEvcBatchItems(
        IEVC.BatchItem[] memory fullItems,
        IEVC.BatchItem[] memory addItems,
        uint256 itemIndex,
        address owner,
        uint256 deadline,
        bytes memory signature,
        ParamsLocation param
    ) internal view returns (uint256) {
        // There are two ways this contract can be executed: either the user approves this contract as
        // an operator and supplies a pre-approved hash for the operation to take, or they submit a permit hash
        // for this specific instance. If its the permit hash route, here we call `permit` instead of `batch` raw so that the EVC can authorize it.
        // If there is an issue with the signature, the EVC will revert the batch call, which will bubble up through this contract to revert the entire wrappedSettle call.
        if (signature.length > 0) {
            fullItems[itemIndex++] = IEVC.BatchItem({
                onBehalfOfAccount: address(0),
                targetContract: address(EVC),
                value: 0,
                data: abi.encodeCall(
                    IEVC.permit,
                    (
                        owner,
                        address(this),
                        uint256(NONCE_NAMESPACE),
                        EVC.getNonce(bytes19(bytes20(owner)), NONCE_NAMESPACE),
                        deadline,
                        0, // value field (no ETH transferred to the EVC)
                        _encodePermitData(addItems, param),
                        signature
                    )
                )
            });
        } else {
            // copy the operations to execute. this contract can operate on behalf of the user directly
            for (uint256 i; i < addItems.length; i++) {
                fullItems[itemIndex + i] = addItems[i];
            }

            itemIndex += addItems.length;
        }

        return itemIndex;
    }

    function _evcInternalSettle(
        bytes calldata settleData,
        bytes calldata wrapperData,
        bytes calldata remainingWrapperData
    ) internal virtual;
}
