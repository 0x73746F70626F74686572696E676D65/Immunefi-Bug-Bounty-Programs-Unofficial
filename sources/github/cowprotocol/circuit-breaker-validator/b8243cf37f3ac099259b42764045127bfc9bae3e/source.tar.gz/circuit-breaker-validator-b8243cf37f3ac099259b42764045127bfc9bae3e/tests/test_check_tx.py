"""Dummy test"""

from unittest.mock import Mock

import pytest
from hexbytes import HexBytes
from circuit_breaker_validator.models import (
    OnchainSettlementData,
    OffchainSettlementData,
    OnchainTrade,
    OffchainTrade,
    Hook,
    Hooks,
)
from circuit_breaker_validator.check_tx import (
    check_solver,
    check_orders,
    check_hooks,
)


@pytest.mark.parametrize(
    "onchain_solver,offchain_solver,expected_result",
    [
        # succeed if solver is equal
        (HexBytes("0x01"), HexBytes("0x01"), True),
        # fail if solver is different
        (HexBytes("0x01"), HexBytes("0x02"), False),
    ],
)
def test_check_solver(onchain_solver, offchain_solver, expected_result):
    """Test that check_solver returns the expected result based on solver comparison"""
    tx_hash = HexBytes("0x00")

    onchain_data = Mock(spec=OnchainSettlementData)
    offchain_data = Mock(spec=OffchainSettlementData)
    onchain_data.tx_hash = tx_hash
    onchain_data.solver = onchain_solver
    offchain_data.solver = offchain_solver

    assert check_solver(onchain_data, offchain_data) == expected_result


@pytest.mark.parametrize(
    "scenario,expected_result",
    [
        # Order with zero surplus that was not revealed - fails due to 1-to-1 mapping requirement
        ("zero_surplus_not_revealed", False),
        # Order with zero surplus that was revealed - should pass
        ("zero_surplus_revealed", True),
        # Order with non-zero surplus that was not revealed
        ("nonzero_surplus_not_revealed", False),
        # Order with matching amounts and non-zero surplus - should pass
        ("matching_amounts_with_surplus", True),
        # Order with mismatched buy amount
        ("mismatched_buy_amount", False),
        # Order with mismatched sell amount
        ("mismatched_sell_amount", False),
        # More executed trades than proposed (no 1-to-1 mapping)
        ("more_executed_than_proposed", False),
        # More proposed trades than executed (no 1-to-1 mapping)
        ("more_proposed_than_executed", False),
        # Executed trade not in proposed (different order_uid)
        ("executed_not_in_proposed", False),
        # Proposed trade not in executed (different order_uid)
        ("proposed_not_in_executed", False),
        # Same order_uid executed twice on-chain but proposed once
        ("duplicate_onchain_order_uid", False),
        # Multiple matching trades with correct 1-to-1 mapping
        ("multiple_trades_matching", True),
        # Empty trades on both sides - valid 1-to-1 mapping
        ("empty_trades_both_sides", True),
    ],
)
def test_check_orders(scenario, expected_result):
    """Test that check_orders returns the expected result based on the scenario"""
    tx_hash = HexBytes("0x00")
    order_uid = HexBytes("0x01")
    sell_amount = 10**25
    buy_amount = 99 * 10**25

    if scenario == "zero_surplus_not_revealed":
        # Order with zero surplus that was not revealed - fails 1-to-1 mapping
        owner = HexBytes("0x11")

        trade = Mock(spec=OnchainTrade)
        trade.order_uid = order_uid
        trade.owner = owner
        trade.surplus = Mock(return_value=0)

        onchain_data = Mock(spec=OnchainSettlementData)
        onchain_data.tx_hash = tx_hash
        onchain_data.trades = [trade]

        offchain_data = Mock(spec=OffchainSettlementData)
        offchain_data.trades = []

    elif scenario == "zero_surplus_revealed":
        # Order with zero surplus that was revealed - passes
        owner = HexBytes("0x11")

        onchain_trade = Mock(spec=OnchainTrade)
        onchain_trade.order_uid = order_uid
        onchain_trade.owner = owner
        onchain_trade.sell_amount = sell_amount
        onchain_trade.buy_amount = buy_amount
        onchain_trade.surplus = Mock(return_value=0)

        offchain_trade = Mock(spec=OffchainTrade)
        offchain_trade.order_uid = order_uid
        offchain_trade.owner = owner
        offchain_trade.sell_amount = sell_amount
        offchain_trade.buy_amount = buy_amount

        onchain_data = Mock(spec=OnchainSettlementData)
        onchain_data.tx_hash = tx_hash
        onchain_data.trades = [onchain_trade]

        offchain_data = Mock(spec=OffchainSettlementData)
        offchain_data.trades = [offchain_trade]

    elif scenario == "nonzero_surplus_not_revealed":
        # Order with non-zero surplus that was not revealed - fails 1-to-1 mapping
        owner = HexBytes("0x11")

        trade = Mock(spec=OnchainTrade)
        trade.order_uid = order_uid
        trade.owner = owner
        trade.surplus = Mock(return_value=1)

        onchain_data = Mock(spec=OnchainSettlementData)
        onchain_data.tx_hash = tx_hash
        onchain_data.trades = [trade]

        offchain_data = Mock(spec=OffchainSettlementData)
        offchain_data.trades = []

    elif scenario == "matching_amounts_with_surplus":
        # Order with matching amounts and non-zero surplus - passes
        # (surplus is no longer restricted to whitelisted/auction orders)
        owner = HexBytes("0x11")

        onchain_trade = Mock(spec=OnchainTrade)
        onchain_trade.order_uid = order_uid
        onchain_trade.owner = owner
        onchain_trade.sell_amount = sell_amount
        onchain_trade.buy_amount = buy_amount
        onchain_trade.surplus = Mock(return_value=1)

        offchain_trade = Mock(spec=OffchainTrade)
        offchain_trade.order_uid = order_uid
        offchain_trade.owner = owner
        offchain_trade.sell_amount = sell_amount
        offchain_trade.buy_amount = buy_amount

        onchain_data = Mock(spec=OnchainSettlementData)
        onchain_data.tx_hash = tx_hash
        onchain_data.trades = [onchain_trade]

        offchain_data = Mock(spec=OffchainSettlementData)
        offchain_data.trades = [offchain_trade]

    elif scenario == "mismatched_buy_amount":
        # Order with mismatched buy amount
        owner = HexBytes("0x12")

        onchain_trade = Mock(spec=OnchainTrade)
        onchain_trade.order_uid = order_uid
        onchain_trade.owner = owner
        onchain_trade.sell_amount = sell_amount
        onchain_trade.buy_amount = buy_amount
        onchain_trade.surplus = Mock(return_value=1)

        offchain_trade = Mock(spec=OffchainTrade)
        offchain_trade.order_uid = order_uid
        offchain_trade.owner = owner
        offchain_trade.sell_amount = sell_amount
        offchain_trade.buy_amount = buy_amount + 1  # Mismatched buy amount

        onchain_data = Mock(spec=OnchainSettlementData)
        onchain_data.tx_hash = tx_hash
        onchain_data.trades = [onchain_trade]

        offchain_data = Mock(spec=OffchainSettlementData)
        offchain_data.trades = [offchain_trade]

    elif scenario == "mismatched_sell_amount":
        # Order with mismatched sell amount
        owner = HexBytes("0x12")

        onchain_trade = Mock(spec=OnchainTrade)
        onchain_trade.order_uid = order_uid
        onchain_trade.owner = owner
        onchain_trade.sell_amount = sell_amount
        onchain_trade.buy_amount = buy_amount
        onchain_trade.surplus = Mock(return_value=1)

        offchain_trade = Mock(spec=OffchainTrade)
        offchain_trade.order_uid = order_uid
        offchain_trade.owner = owner
        offchain_trade.sell_amount = sell_amount + 1  # Mismatched sell amount
        offchain_trade.buy_amount = buy_amount

        onchain_data = Mock(spec=OnchainSettlementData)
        onchain_data.tx_hash = tx_hash
        onchain_data.trades = [onchain_trade]

        offchain_data = Mock(spec=OffchainSettlementData)
        offchain_data.trades = [offchain_trade]

    elif scenario == "more_executed_than_proposed":
        # More executed trades than proposed (no 1-to-1 mapping)
        owner = HexBytes("0x12")
        order_uid_2 = HexBytes("0x02")

        onchain_trade_1 = Mock(spec=OnchainTrade)
        onchain_trade_1.order_uid = order_uid
        onchain_trade_1.owner = owner
        onchain_trade_1.sell_amount = sell_amount
        onchain_trade_1.buy_amount = buy_amount
        onchain_trade_1.surplus = Mock(return_value=0)

        onchain_trade_2 = Mock(spec=OnchainTrade)
        onchain_trade_2.order_uid = order_uid_2
        onchain_trade_2.owner = owner
        onchain_trade_2.sell_amount = sell_amount
        onchain_trade_2.buy_amount = buy_amount
        onchain_trade_2.surplus = Mock(return_value=0)

        offchain_trade = Mock(spec=OffchainTrade)
        offchain_trade.order_uid = order_uid
        offchain_trade.owner = owner
        offchain_trade.sell_amount = sell_amount
        offchain_trade.buy_amount = buy_amount

        onchain_data = Mock(spec=OnchainSettlementData)
        onchain_data.tx_hash = tx_hash
        onchain_data.trades = [onchain_trade_1, onchain_trade_2]

        offchain_data = Mock(spec=OffchainSettlementData)
        offchain_data.trades = [offchain_trade]

    elif scenario == "more_proposed_than_executed":
        # More proposed trades than executed (no 1-to-1 mapping)
        owner = HexBytes("0x12")
        order_uid_2 = HexBytes("0x02")

        onchain_trade = Mock(spec=OnchainTrade)
        onchain_trade.order_uid = order_uid
        onchain_trade.owner = owner
        onchain_trade.sell_amount = sell_amount
        onchain_trade.buy_amount = buy_amount
        onchain_trade.surplus = Mock(return_value=0)

        offchain_trade_1 = Mock(spec=OffchainTrade)
        offchain_trade_1.order_uid = order_uid
        offchain_trade_1.owner = owner
        offchain_trade_1.sell_amount = sell_amount
        offchain_trade_1.buy_amount = buy_amount

        offchain_trade_2 = Mock(spec=OffchainTrade)
        offchain_trade_2.order_uid = order_uid_2
        offchain_trade_2.owner = owner
        offchain_trade_2.sell_amount = sell_amount
        offchain_trade_2.buy_amount = buy_amount

        onchain_data = Mock(spec=OnchainSettlementData)
        onchain_data.tx_hash = tx_hash
        onchain_data.trades = [onchain_trade]

        offchain_data = Mock(spec=OffchainSettlementData)
        offchain_data.trades = [offchain_trade_1, offchain_trade_2]

    elif scenario == "executed_not_in_proposed":
        # Executed trade not in proposed trades
        owner = HexBytes("0x12")
        order_uid_2 = HexBytes("0x02")

        onchain_trade = Mock(spec=OnchainTrade)
        onchain_trade.order_uid = order_uid_2  # Different order_uid
        onchain_trade.owner = owner
        onchain_trade.sell_amount = sell_amount
        onchain_trade.buy_amount = buy_amount
        onchain_trade.surplus = Mock(return_value=0)

        offchain_trade = Mock(spec=OffchainTrade)
        offchain_trade.order_uid = order_uid
        offchain_trade.owner = owner
        offchain_trade.sell_amount = sell_amount
        offchain_trade.buy_amount = buy_amount

        onchain_data = Mock(spec=OnchainSettlementData)
        onchain_data.tx_hash = tx_hash
        onchain_data.trades = [onchain_trade]

        offchain_data = Mock(spec=OffchainSettlementData)
        offchain_data.trades = [offchain_trade]

    elif scenario == "proposed_not_in_executed":
        # Proposed trade not in executed trades
        owner = HexBytes("0x12")
        order_uid_2 = HexBytes("0x02")

        onchain_trade = Mock(spec=OnchainTrade)
        onchain_trade.order_uid = order_uid
        onchain_trade.owner = owner
        onchain_trade.sell_amount = sell_amount
        onchain_trade.buy_amount = buy_amount
        onchain_trade.surplus = Mock(return_value=0)

        offchain_trade = Mock(spec=OffchainTrade)
        offchain_trade.order_uid = order_uid_2  # Different order_uid
        offchain_trade.owner = owner
        offchain_trade.sell_amount = sell_amount
        offchain_trade.buy_amount = buy_amount

        onchain_data = Mock(spec=OnchainSettlementData)
        onchain_data.tx_hash = tx_hash
        onchain_data.trades = [onchain_trade]

        offchain_data = Mock(spec=OffchainSettlementData)
        offchain_data.trades = [offchain_trade]

    elif scenario == "duplicate_onchain_order_uid":
        # Same order_uid appears twice on-chain, once off-chain.
        owner = HexBytes("0x12")

        onchain_trade_1 = Mock(spec=OnchainTrade)
        onchain_trade_1.order_uid = order_uid
        onchain_trade_1.owner = owner
        onchain_trade_1.sell_amount = sell_amount
        onchain_trade_1.buy_amount = buy_amount
        onchain_trade_1.surplus = Mock(return_value=0)

        onchain_trade_2 = Mock(spec=OnchainTrade)
        onchain_trade_2.order_uid = order_uid  # Duplicate order_uid
        onchain_trade_2.owner = owner
        onchain_trade_2.sell_amount = sell_amount
        onchain_trade_2.buy_amount = buy_amount
        onchain_trade_2.surplus = Mock(return_value=0)

        offchain_trade = Mock(spec=OffchainTrade)
        offchain_trade.order_uid = order_uid
        offchain_trade.owner = owner
        offchain_trade.sell_amount = sell_amount
        offchain_trade.buy_amount = buy_amount

        onchain_data = Mock(spec=OnchainSettlementData)
        onchain_data.tx_hash = tx_hash
        onchain_data.trades = [onchain_trade_1, onchain_trade_2]

        offchain_data = Mock(spec=OffchainSettlementData)
        offchain_data.trades = [offchain_trade]

    elif scenario == "multiple_trades_matching":
        # Multiple trades with correct 1-to-1 mapping
        owner = HexBytes("0x12")
        order_uid_2 = HexBytes("0x02")
        order_uid_3 = HexBytes("0x03")

        onchain_trade_1 = Mock(spec=OnchainTrade)
        onchain_trade_1.order_uid = order_uid
        onchain_trade_1.owner = owner
        onchain_trade_1.sell_amount = sell_amount
        onchain_trade_1.buy_amount = buy_amount
        onchain_trade_1.surplus = Mock(return_value=100)

        onchain_trade_2 = Mock(spec=OnchainTrade)
        onchain_trade_2.order_uid = order_uid_2
        onchain_trade_2.owner = owner
        onchain_trade_2.sell_amount = sell_amount * 2
        onchain_trade_2.buy_amount = buy_amount * 2
        onchain_trade_2.surplus = Mock(return_value=200)

        onchain_trade_3 = Mock(spec=OnchainTrade)
        onchain_trade_3.order_uid = order_uid_3
        onchain_trade_3.owner = owner
        onchain_trade_3.sell_amount = sell_amount // 2
        onchain_trade_3.buy_amount = buy_amount // 2
        onchain_trade_3.surplus = Mock(return_value=50)

        offchain_trade_1 = Mock(spec=OffchainTrade)
        offchain_trade_1.order_uid = order_uid
        offchain_trade_1.sell_amount = sell_amount
        offchain_trade_1.buy_amount = buy_amount

        offchain_trade_2 = Mock(spec=OffchainTrade)
        offchain_trade_2.order_uid = order_uid_2
        offchain_trade_2.sell_amount = sell_amount * 2
        offchain_trade_2.buy_amount = buy_amount * 2

        offchain_trade_3 = Mock(spec=OffchainTrade)
        offchain_trade_3.order_uid = order_uid_3
        offchain_trade_3.sell_amount = sell_amount // 2
        offchain_trade_3.buy_amount = buy_amount // 2

        onchain_data = Mock(spec=OnchainSettlementData)
        onchain_data.tx_hash = tx_hash
        onchain_data.trades = [onchain_trade_1, onchain_trade_2, onchain_trade_3]

        offchain_data = Mock(spec=OffchainSettlementData)
        offchain_data.trades = [offchain_trade_1, offchain_trade_2, offchain_trade_3]

    elif scenario == "empty_trades_both_sides":
        # Empty trades on both sides - valid 1-to-1 mapping (no trades)

        onchain_data = Mock(spec=OnchainSettlementData)
        onchain_data.tx_hash = tx_hash
        onchain_data.trades = []

        offchain_data = Mock(spec=OffchainSettlementData)
        offchain_data.trades = []

    assert check_orders(onchain_data, offchain_data) == expected_result


@pytest.mark.parametrize(
    "scenario,expected_result",
    [
        # No hooks defined - should pass
        ("no_hooks", True),
        # All hooks executed correctly - should pass
        ("all_hooks_executed", True),
        # Missing pre-hook - should fail
        ("missing_pre_hook", False),
        # Missing post-hook - should fail
        ("missing_post_hook", False),
        # Incorrect gas limit - should fail
        ("incorrect_gas_limit", False),
        # First fill with pre-hooks - should pass
        ("first_fill_with_pre_hooks", True),
        # Subsequent fill without pre-hooks - should pass
        ("subsequent_fill_no_pre_hooks", True),
        # Subsequent fill with pre-hooks present - should pass
        ("subsequent_fill_with_pre_hooks", True),
        # Multiple hooks executed correctly - should pass
        ("multiple_hooks", True),
        # Multiple orders with the same hook, executed only once - should pass
        ("multiple_orders_same_hook_executed_once", True),
    ],
)
def test_check_hooks(scenario, expected_result):
    """Test that check_hooks returns the expected result based on the scenario"""
    tx_hash = HexBytes("0x00")
    order_uid = HexBytes("0x01")

    # Create base hooks for testing
    pre_hook = Hook(
        target=HexBytes("0xC01De8aB58f29E4d9fa9e274eC7c05a04e397312"),
        calldata=HexBytes("0xc2985578"),
        gas_limit=1030000,
    )
    post_hook = Hook(
        target=HexBytes("0xD02De8aB58f29E4d9fa9e274eC7c05a04e397313"),
        calldata=HexBytes("0xd3985579"),
        gas_limit=2040000,
    )

    if scenario == "no_hooks":
        # No hooks defined in offchain data
        onchain_data = Mock(spec=OnchainSettlementData)
        onchain_data.tx_hash = tx_hash
        onchain_data.hook_candidates = Hooks()

        offchain_data = Mock(spec=OffchainSettlementData)
        offchain_data.order_hooks = {}
        offchain_data.trades = []

    elif scenario == "all_hooks_executed":
        # All hooks executed correctly
        executed_pre_hook = Hook(
            target=pre_hook.target,
            calldata=pre_hook.calldata,
            gas_limit=pre_hook.gas_limit,  # Must match exactly
        )
        executed_post_hook = Hook(
            target=post_hook.target,
            calldata=post_hook.calldata,
            gas_limit=post_hook.gas_limit,
        )

        onchain_data = Mock(spec=OnchainSettlementData)
        onchain_data.tx_hash = tx_hash
        onchain_data.hook_candidates = Hooks(
            pre_hooks=[executed_pre_hook],
            post_hooks=[executed_post_hook],
        )

        offchain_trade = Mock(spec=OffchainTrade)
        offchain_trade.order_uid = order_uid
        offchain_trade.already_executed_amount = 0  # First fill

        offchain_data = Mock(spec=OffchainSettlementData)
        offchain_data.order_hooks = {
            order_uid: Hooks(pre_hooks=[pre_hook], post_hooks=[post_hook])
        }
        offchain_data.trades = [offchain_trade]

    elif scenario == "missing_pre_hook":
        # Pre-hook is missing in executed hooks
        executed_post_hook = Hook(
            target=post_hook.target,
            calldata=post_hook.calldata,
            gas_limit=0,
        )

        onchain_data = Mock(spec=OnchainSettlementData)
        onchain_data.tx_hash = tx_hash
        onchain_data.hook_candidates = Hooks(
            pre_hooks=[],  # Missing pre-hook
            post_hooks=[executed_post_hook],
        )

        offchain_trade = Mock(spec=OffchainTrade)
        offchain_trade.order_uid = order_uid
        offchain_trade.already_executed_amount = 0  # First fill

        offchain_data = Mock(spec=OffchainSettlementData)
        offchain_data.order_hooks = {
            order_uid: Hooks(pre_hooks=[pre_hook], post_hooks=[post_hook])
        }
        offchain_data.trades = [offchain_trade]

    elif scenario == "missing_post_hook":
        # Post-hook is missing in executed hooks
        executed_pre_hook = Hook(
            target=pre_hook.target,
            calldata=pre_hook.calldata,
            gas_limit=pre_hook.gas_limit,
        )

        onchain_data = Mock(spec=OnchainSettlementData)
        onchain_data.tx_hash = tx_hash
        onchain_data.hook_candidates = Hooks(
            pre_hooks=[executed_pre_hook],
            post_hooks=[],  # Missing post-hook
        )

        offchain_trade = Mock(spec=OffchainTrade)
        offchain_trade.order_uid = order_uid
        offchain_trade.already_executed_amount = 0  # First fill

        offchain_data = Mock(spec=OffchainSettlementData)
        offchain_data.order_hooks = {
            order_uid: Hooks(pre_hooks=[pre_hook], post_hooks=[post_hook])
        }
        offchain_data.trades = [offchain_trade]

    elif scenario == "incorrect_gas_limit":
        # Executed hook has incorrect gas limit
        executed_pre_hook = Hook(
            target=pre_hook.target,
            calldata=pre_hook.calldata,
            gas_limit=1000,  # Different from the required 1030000
        )
        executed_post_hook = Hook(
            target=post_hook.target,
            calldata=post_hook.calldata,
            gas_limit=post_hook.gas_limit,
        )

        onchain_data = Mock(spec=OnchainSettlementData)
        onchain_data.tx_hash = tx_hash
        onchain_data.hook_candidates = Hooks(
            pre_hooks=[executed_pre_hook],
            post_hooks=[executed_post_hook],
        )

        offchain_trade = Mock(spec=OffchainTrade)
        offchain_trade.order_uid = order_uid
        offchain_trade.already_executed_amount = 0  # First fill

        offchain_data = Mock(spec=OffchainSettlementData)
        offchain_data.order_hooks = {
            order_uid: Hooks(pre_hooks=[pre_hook], post_hooks=[post_hook])
        }
        offchain_data.trades = [offchain_trade]

    elif scenario == "first_fill_with_pre_hooks":
        # First fill - pre-hooks should be executed
        executed_pre_hook = Hook(
            target=pre_hook.target,
            calldata=pre_hook.calldata,
            gas_limit=pre_hook.gas_limit,
        )
        executed_post_hook = Hook(
            target=post_hook.target,
            calldata=post_hook.calldata,
            gas_limit=post_hook.gas_limit,
        )

        onchain_data = Mock(spec=OnchainSettlementData)
        onchain_data.tx_hash = tx_hash
        onchain_data.hook_candidates = Hooks(
            pre_hooks=[executed_pre_hook],
            post_hooks=[executed_post_hook],
        )

        offchain_trade = Mock(spec=OffchainTrade)
        offchain_trade.order_uid = order_uid
        offchain_trade.already_executed_amount = 0  # First fill

        offchain_data = Mock(spec=OffchainSettlementData)
        offchain_data.order_hooks = {
            order_uid: Hooks(pre_hooks=[pre_hook], post_hooks=[post_hook])
        }
        offchain_data.trades = [offchain_trade]

    elif scenario == "subsequent_fill_no_pre_hooks":
        # Subsequent fill - pre-hooks should NOT be executed
        executed_post_hook = Hook(
            target=post_hook.target,
            calldata=post_hook.calldata,
            gas_limit=post_hook.gas_limit,
        )

        onchain_data = Mock(spec=OnchainSettlementData)
        onchain_data.tx_hash = tx_hash
        onchain_data.hook_candidates = Hooks(
            pre_hooks=[],  # No pre-hooks for subsequent fill
            post_hooks=[executed_post_hook],
        )

        offchain_trade = Mock(spec=OffchainTrade)
        offchain_trade.order_uid = order_uid
        offchain_trade.already_executed_amount = 1000  # Subsequent fill

        offchain_data = Mock(spec=OffchainSettlementData)
        offchain_data.order_hooks = {
            order_uid: Hooks(pre_hooks=[pre_hook], post_hooks=[post_hook])
        }
        offchain_data.trades = [offchain_trade]

    elif scenario == "subsequent_fill_with_pre_hooks":
        # Subsequent fill where pre-hooks are present in onchain execution
        # In this case we skip pre-hook validation entirely because
        # is_first_fill=False, so it only checks post-hooks and returns True
        executed_pre_hook = Hook(
            target=pre_hook.target,
            calldata=pre_hook.calldata,
            gas_limit=pre_hook.gas_limit,
        )
        executed_post_hook = Hook(
            target=post_hook.target,
            calldata=post_hook.calldata,
            gas_limit=post_hook.gas_limit,
        )

        onchain_data = Mock(spec=OnchainSettlementData)
        onchain_data.tx_hash = tx_hash
        onchain_data.hook_candidates = Hooks(
            pre_hooks=[executed_pre_hook],
            post_hooks=[executed_post_hook],
        )

        offchain_trade = Mock(spec=OffchainTrade)
        offchain_trade.order_uid = order_uid
        offchain_trade.already_executed_amount = 1000

        offchain_data = Mock(spec=OffchainSettlementData)
        offchain_data.order_hooks = {
            order_uid: Hooks(pre_hooks=[pre_hook], post_hooks=[post_hook])
        }
        offchain_data.trades = [offchain_trade]

    elif scenario == "multiple_hooks":
        # Multiple hooks executed correctly
        pre_hook_2 = Hook(
            target=HexBytes("0xC02De8aB58f29E4d9fa9e274eC7c05a04e397313"),
            calldata=HexBytes("0xc3985579"),
            gas_limit=1040000,
        )
        post_hook_2 = Hook(
            target=HexBytes("0xD03De8aB58f29E4d9fa9e274eC7c05a04e397314"),
            calldata=HexBytes("0xd4985580"),
            gas_limit=2050000,
        )

        executed_pre_hook_1 = Hook(
            target=pre_hook.target,
            calldata=pre_hook.calldata,
            gas_limit=pre_hook.gas_limit,
        )
        executed_pre_hook_2 = Hook(
            target=pre_hook_2.target,
            calldata=pre_hook_2.calldata,
            gas_limit=pre_hook_2.gas_limit,
        )
        executed_post_hook_1 = Hook(
            target=post_hook.target,
            calldata=post_hook.calldata,
            gas_limit=post_hook.gas_limit,
        )
        executed_post_hook_2 = Hook(
            target=post_hook_2.target,
            calldata=post_hook_2.calldata,
            gas_limit=post_hook_2.gas_limit,
        )

        onchain_data = Mock(spec=OnchainSettlementData)
        onchain_data.tx_hash = tx_hash
        onchain_data.hook_candidates = Hooks(
            pre_hooks=[executed_pre_hook_1, executed_pre_hook_2],
            post_hooks=[executed_post_hook_1, executed_post_hook_2],
        )

        offchain_trade = Mock(spec=OffchainTrade)
        offchain_trade.order_uid = order_uid
        offchain_trade.already_executed_amount = 0  # First fill

        offchain_data = Mock(spec=OffchainSettlementData)
        offchain_data.order_hooks = {
            order_uid: Hooks(
                pre_hooks=[pre_hook, pre_hook_2],
                post_hooks=[post_hook, post_hook_2],
            )
        }
        offchain_data.trades = [offchain_trade]

    elif scenario == "multiple_orders_same_hook_executed_once":
        # Multiple orders require the same hook, but it's only executed once onchain
        # This should pass because we only check that the hook exists in candidates
        order_uid_2 = HexBytes("0x02")

        # Same hook executed once
        executed_pre_hook = Hook(
            target=pre_hook.target,
            calldata=pre_hook.calldata,
            gas_limit=pre_hook.gas_limit,
        )
        executed_post_hook = Hook(
            target=post_hook.target,
            calldata=post_hook.calldata,
            gas_limit=post_hook.gas_limit,
        )

        onchain_data = Mock(spec=OnchainSettlementData)
        onchain_data.tx_hash = tx_hash
        onchain_data.hook_candidates = Hooks(
            pre_hooks=[executed_pre_hook],  # Hook executed only once
            post_hooks=[executed_post_hook],
        )

        # Two trades, both with the same hooks
        offchain_trade_1 = Mock(spec=OffchainTrade)
        offchain_trade_1.order_uid = order_uid
        offchain_trade_1.already_executed_amount = 0  # First fill

        offchain_trade_2 = Mock(spec=OffchainTrade)
        offchain_trade_2.order_uid = order_uid_2
        offchain_trade_2.already_executed_amount = 0  # First fill

        offchain_data = Mock(spec=OffchainSettlementData)
        offchain_data.order_hooks = {
            order_uid: Hooks(pre_hooks=[pre_hook], post_hooks=[post_hook]),
            order_uid_2: Hooks(pre_hooks=[pre_hook], post_hooks=[post_hook]),
        }
        offchain_data.trades = [offchain_trade_1, offchain_trade_2]

    assert check_hooks(onchain_data, offchain_data) == expected_result
