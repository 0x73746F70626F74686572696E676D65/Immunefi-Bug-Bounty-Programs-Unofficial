with all_hooks as (    
    select * 
    from "query_5534333(lookback_time_unit='{{time_unit}}', lookback_units='{{units}}', blockchain='ethereum')"
    union all
    select * 
    from "query_5534333(lookback_time_unit='{{time_unit}}', lookback_units='{{units}}', blockchain='gnosis')"
    union all
    select * 
    from "query_5534333(lookback_time_unit='{{time_unit}}', lookback_units='{{units}}', blockchain='base')"
    union all
    select * 
    from "query_5534333(lookback_time_unit='{{time_unit}}', lookback_units='{{units}}', blockchain='arbitrum')"
    union all
    select * 
    from "query_5534333(lookback_time_unit='{{time_unit}}', lookback_units='{{units}}', blockchain='avalanche_c')"
    union all
    select * 
    from "query_5534333(lookback_time_unit='{{time_unit}}', lookback_units='{{units}}', blockchain='polygon')"    
    union all
    select * 
    from "query_5534333(lookback_time_unit='{{time_unit}}', lookback_units='{{units}}', blockchain='lens')"    
    union all
    select * 
    from "query_5534333(lookback_time_unit='{{time_unit}}', lookback_units='{{units}}', blockchain='bnb')"        
    union all
    select * 
    from "query_5534333(lookback_time_unit='{{time_unit}}', lookback_units='{{units}}', blockchain='linea')"        
    union all
    select * 
    from "query_5534333(lookback_time_unit='{{time_unit}}', lookback_units='{{units}}', blockchain='plasma')"            
    union all
    select * 
    from "query_5534333(lookback_time_unit='{{time_unit}}', lookback_units='{{units}}', blockchain='ink')"    
)
select * 
from all_hooks
where 
    not(hook_success) 
    and hook_app_id like 'cow-sdk://bridging%'
