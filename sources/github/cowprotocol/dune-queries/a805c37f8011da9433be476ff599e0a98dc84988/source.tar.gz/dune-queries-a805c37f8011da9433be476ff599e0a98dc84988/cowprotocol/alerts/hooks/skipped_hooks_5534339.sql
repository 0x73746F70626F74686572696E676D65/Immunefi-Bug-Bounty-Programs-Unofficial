--noqa: disable=all
with all_hooks as (    
    select * 
    from "query_5534333(lookback_time_unit='{{time_unit}}', lookback_units='{{units}}', blockchain='ethereum')"
    union all
    select * 
    from "query_5534333(lookback_time_unit='{{time_unit}}', lookback_units='{{units}}', blockchain='gnosis')"
    union all
    select * 
    from "query_5534333(lookback_time_unit='{{time_unit}}', lookback_units='{{units}}', blockchain='base')"
    union all
    select * 
    from "query_5534333(lookback_time_unit='{{time_unit}}', lookback_units='{{units}}', blockchain='arbitrum')"
    union all
    select * 
    from "query_5534333(lookback_time_unit='{{time_unit}}', lookback_units='{{units}}', blockchain='avalanche_c')"
    union all
    select * 
    from "query_5534333(lookback_time_unit='{{time_unit}}', lookback_units='{{units}}', blockchain='polygon')"    
    union all
    select * 
    from "query_5534333(lookback_time_unit='{{time_unit}}', lookback_units='{{units}}', blockchain='lens')"    
    union all
    select * 
    from "query_5534333(lookback_time_unit='{{time_unit}}', lookback_units='{{units}}', blockchain='bnb')"        
    union all
    select * 
    from "query_5534333(lookback_time_unit='{{time_unit}}', lookback_units='{{units}}', blockchain='linea')"        
    union all
    select * 
    from "query_5534333(lookback_time_unit='{{time_unit}}', lookback_units='{{units}}', blockchain='plasma')"    
)
select * 
from all_hooks
where 
    hook_success is null
    and not( hook_app_id in (
        'cow-swap://libs/hook-dapp-lib/permit',
        'PERMIT_TOKEN',
        '1db4bacb661a90fb6b475fd5b585acba9745bc373573c65ecc3e8f5bfd5dee1f',
        'cow.fi',
        'Fordefi',
        'UNI_V2_DEPOSIT')
    )
    and not(hook_app_id like 'cow-sdk://flashloans/aave%')
