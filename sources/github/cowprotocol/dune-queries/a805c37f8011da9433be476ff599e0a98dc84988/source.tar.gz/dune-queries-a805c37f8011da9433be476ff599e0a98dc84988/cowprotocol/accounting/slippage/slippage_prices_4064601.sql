-- This query computes prices for use in slippage on CoW Protocol
--
-- It gives hourly prices for all tokens transferred to or from the protocol.
--
-- Parameters:
--  {{start_time}} - the timestamp for which the analysis should start (inclusively)
--  {{end_time}} - the timestamp for which the analysis should end (exclusively)
--  {{blockchain}} - network to run the analysis on
--
-- The columns of the result are
-- - hour: hour for which a price is valid
-- - token_address: address of token with a price. contract address for erc20 tokens,
--   0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee for native token
-- - decimals: decimals of the token, can be null
-- - price_unit: USD price of one unit (i.e. pow(10, decimals) atoms) of a token
-- - price_atom: USD price of one atom (i.e. 1. / pow(10, decimals) units) of a token

-- Fetch a list of token addresses and times we need prices for. We use hourly prices only.
with token_times as (
    select
        token_address,
        date_trunc('hour', block_time) as hour --noqa: RF04
    from "query_4021257(blockchain='{{blockchain}}',start_time='{{start_time}}',end_time='{{end_time}}')"
    where token_address != 0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee
    group by 1, 2
),

aave_tokens_mapping as (
    select distinct
        chain as blockchain,
        atoken as atoken_address,
        asset as underlying_address
    from aave_v3_multichain.poolconfigurator_evt_reserveinitialized
    union distinct
    select distinct
        'ethereum' as blockchain,
        atoken as atoken_address,
        asset as underlying_address
    from aave_v3_lido_ethereum.poolconfigurator_evt_reserveinitialized
    union distinct
    select distinct
        'ethereum' as blockchain,
        atoken as atoken_address,
        asset as underlying_address
    from aave_v3_ethereum.etherfipoolconfiguratorinstance_evt_reserveinitialized
),

token_times_enriched as (
    -- All tokens are associated with a proxy address which is used for finding a price feed instead of the original contract address
    select
        tt.token_address,
        coalesce(atm.underlying_address, tt.token_address) as proxy_address,
        tt.hour
    from token_times as tt left join aave_tokens_mapping as atm
        on tt.token_address = atm.atoken_address and atm.blockchain = '{{blockchain}}'
),

-- Precise prices are prices from the Dune price feed.
precise_prices as (
    select
        tte.hour,
        tte.token_address,
        p.decimals,
        avg(p.price) as price_unit,
        avg(p.price) / pow(10, p.decimals) as price_atom
    from token_times_enriched as tte inner join prices.usd as p
        on
        tte.hour = date_trunc('hour', p.minute)
        and p.contract_address = tte.proxy_address
        and p.blockchain = '{{blockchain}}'
    group by 1, 2, 3
),

-- Intrinsic prices are prices reconstructed from exchange rates from within the auction
-- A price can be reconstructed if there was a trade with another token which did have a Dune price.
-- If there a multiple prices reconstructed in this way, an average is taken.
-- The native token is excluded from this analysis since we will explicitly get a price for that later.
intrinsic_prices as (
    select
        hour,
        token_address,
        decimals,
        avg(price_unit) as price_unit,
        avg(price_atom) as price_atom
    from (
        select
            date_trunc('hour', block_time) as hour, --noqa: RF04
            buy_token_address as token_address,
            round(log(10, atoms_bought / units_bought)) as decimals,
            usd_value / units_bought as price_unit,
            usd_value / atoms_bought as price_atom
        from cow_protocol_{{blockchain}}.trades
        where
            block_time >= cast('{{start_time}}' as timestamp)
            and block_time < cast('{{end_time}}' as timestamp)
            and buy_token_address != 0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee
            and units_sold * units_bought > 0
        union distinct
        select
            date_trunc('hour', block_time) as hour, --noqa: RF04
            sell_token_address as token_address,
            round(log(10, atoms_sold / units_sold)) as decimals,
            usd_value / units_sold as price_unit,
            usd_value / atoms_sold as price_atom
        from cow_protocol_{{blockchain}}.trades
        where
            block_time >= cast('{{start_time}}' as timestamp)
            and block_time < cast('{{end_time}}' as timestamp)
            and sell_token_address != 0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee
            and units_sold * units_bought > 0
    ) as combined
    group by 1, 2, 3
),

-- The final price is the Dune price if it exists and the intrinsic price otherwise. If both prices
-- are not available, the price is null.
prices_pre as (
    select
        tt.hour,
        tt.token_address,
        coalesce(
            precise.decimals,
            intrinsic.decimals
        ) as decimals,
        coalesce(
            precise.price_unit,
            intrinsic.price_unit
        ) as price_unit,
        coalesce(
            precise.price_atom,
            intrinsic.price_atom
        ) as price_atom
    from token_times as tt
    left join precise_prices as precise
        on
        tt.hour = precise.hour
        and tt.token_address = precise.token_address
    left join intrinsic_prices as intrinsic
        on
        tt.hour = intrinsic.hour
        and tt.token_address = intrinsic.token_address
),

prices as (
    select
        hour,
        token_address,
        decimals,
        case
            when '{{blockchain}}' = 'base' and token_address = 0x22af33fe49fd1fa80c7149773dde5890d3c76f3b and hour >= timestamp '2025-03-04 00:00' and hour <= timestamp '2025-03-11 00:00' then 0.00029585
            when '{{blockchain}}' = 'ethereum' and token_address = 0x4d5f47fa6a74757f35c14fd3a6ef8e3c9bc514e8 and hour >= timestamp '2025-08-31 03:00' and hour <= timestamp '2025-08-31 04:00' then 4459.365
            when '{{blockchain}}' = 'ethereum' and token_address = 0x23878914efe38d27c4d67ab83ed1b93a74d4086a and hour >= timestamp '2025-08-31 03:00' and hour <= timestamp '2025-08-31 04:00' then 0.9983
            when '{{blockchain}}' = 'ethereum' and token_address = 0x0b925ed163218f6662a35e0f0371ac234f9e9371 and hour >= timestamp '2025-08-29 19:00' and hour <= timestamp '2025-08-29 20:00' then 5254.7182
            when '{{blockchain}}' = 'ethereum' and token_address = 0x23878914efe38d27c4d67ab83ed1b93a74d4086a and hour >= timestamp '2025-08-29 19:00' and hour <= timestamp '2025-08-29 20:00' then 0.9983
            when '{{blockchain}}' = 'base' and token_address = 0x2e285de4c868d225949dbdaf82cd5e28497c52bf and hour >= timestamp '2025-09-23 15:00' and hour <= timestamp '2025-09-23 16:00' then 0.003
            when '{{blockchain}}' = 'base' and token_address = 0x7Ce02e86354EA0Cc3b302AeAdC0Ab56bC7EB44b8 and hour >= timestamp '2025-10-09 19:00' and hour <= timestamp '2025-10-09 20:00' then 0.8263 -- noqa:CP02
            when '{{blockchain}}' = 'base' and token_address = 0x63706e401c06ac8513145b7687A14804d17f814b and hour >= timestamp '2025-10-22 00:00' and hour <= timestamp '2025-10-22 00:00' then 225.99 -- noqa:CP02
            when '{{blockchain}}' = 'ethereum' and token_address = 0x5c6Ee304399DBdB9C8Ef030aB642B10820DB8F56 and hour >= timestamp '2025-12-30 03:00' and hour <= timestamp '2025-12-30 04:00' then 2.8 -- noqa:CP02
            when '{{blockchain}}' = 'gnosis' and token_address = 0xcb444e90d8198415266c6a2724b7900fb12fc56e and hour >= timestamp '2025-12-30 00:00' then 0.0
            when '{{blockchain}}' = 'ethereum' and token_address = 0x3231cb76718cdef2155fc47b5286d82e6eda273f and hour >= timestamp '2026-01-13 00:00' then 0.0
            when '{{blockchain}}' = 'gnosis' and token_address = 0x5cb9073902f2035222b9749f8fb0c9bfe5527108 and hour >= timestamp '2026-07-28 00:00' then 0.0
            when '{{blockchain}}' = 'ethereum' and token_address = 0x4956b52ae2ff65d74ca2d61207523288e4528f96 and hour >= timestamp '2026-03-22 15:00' and hour <= timestamp '2026-03-22 19:00' then 0.23292903653351268
            when '{{blockchain}}' = 'ethereum' and token_address = 0xfcc5c47be19d06bf83eb04298b026f81069ff65b and hour >= timestamp '2026-05-27 09:00' and hour <= timestamp '2026-05-27 10:00' then 0.133
            when '{{blockchain}}' = 'ethereum' and token_address = 0x01791f726b4103694969820be083196cc7c045ff and hour >= timestamp '2026-05-27 10:00' and hour <= timestamp '2026-05-27 11:00' then 0.105
            when '{{blockchain}}' = 'ethereum' and token_address = 0x60d48c1a161559255aaf572f3c1ce4185578dcfe and hour >= timestamp '2026-07-14 13:00' and hour <= timestamp '2026-07-14 14:00' then 0.0
            when '{{blockchain}}' = 'ethereum' and token_address = 0x4e15361fd6b4bb609fa63c81a2be19d873717870 and hour >= timestamp '2026-07-30 09:00' and hour <= timestamp '2026-07-30 10:00' then 0.0284 -- noqa:CP02
            when '{{blockchain}}' = 'ethereum' and token_address = 0x230f1e241c621d5af670dad83ebcdd18971e2995 and hour >= timestamp '2026-08-24 15:00' and hour <= timestamp '2026-08-24 23:59' then 0.005 -- noqa:CP02
            else price_unit
        end as price_unit,
        case
            when '{{blockchain}}' = 'base' and token_address = 0x22af33fe49fd1fa80c7149773dde5890d3c76f3b and hour >= timestamp '2025-03-04 00:00' and hour <= timestamp '2025-03-11 00:00' then 0.00029585 / pow(10, 18)
            when '{{blockchain}}' = 'ethereum' and token_address = 0x4d5f47fa6a74757f35c14fd3a6ef8e3c9bc514e8 and hour >= timestamp '2025-08-31 03:00' and hour <= timestamp '2025-08-31 04:00' then 4459.365 / pow(10, 18)
            when '{{blockchain}}' = 'ethereum' and token_address = 0x23878914efe38d27c4d67ab83ed1b93a74d4086a and hour >= timestamp '2025-08-31 03:00' and hour <= timestamp '2025-08-31 04:00' then 0.9983 / pow(10, 6)
            when '{{blockchain}}' = 'ethereum' and token_address = 0x0b925ed163218f6662a35e0f0371ac234f9e9371 and hour >= timestamp '2025-08-29 19:00' and hour <= timestamp '2025-08-29 20:00' then 5254.7182 / pow(10,18)
            when '{{blockchain}}' = 'ethereum' and token_address = 0x23878914efe38d27c4d67ab83ed1b93a74d4086a and hour >= timestamp '2025-08-29 19:00' and hour <= timestamp '2025-08-29 20:00' then 0.9983 / pow(10, 6)
            when '{{blockchain}}' = 'base' and token_address = 0x2e285de4c868d225949dbdaf82cd5e28497c52bf and hour >= timestamp '2025-09-23 15:00' and hour <= timestamp '2025-09-23 16:00' then 0.003 / pow(10, 18)
            when '{{blockchain}}' = 'base' and token_address = 0x7Ce02e86354EA0Cc3b302AeAdC0Ab56bC7EB44b8 and hour >= timestamp '2025-10-09 19:00' and hour <= timestamp '2025-10-09 20:00' then 0.8263 / pow(10, 18) -- noqa:CP02
            when '{{blockchain}}' = 'base' and token_address = 0x63706e401c06ac8513145b7687A14804d17f814b and hour >= timestamp '2025-10-22 00:00' and hour <= timestamp '2025-10-22 00:00' then 225.99 / pow(10, 18) -- noqa:CP02
            when '{{blockchain}}' = 'ethereum' and token_address = 0x5c6Ee304399DBdB9C8Ef030aB642B10820DB8F56 and hour >= timestamp '2025-12-30 03:00' and hour <= timestamp '2025-12-30 04:00' then 2.8 / pow(10, 18) -- noqa:CP02
            when '{{blockchain}}' = 'gnosis' and token_address = 0xcb444e90d8198415266c6a2724b7900fb12fc56e and hour >= timestamp '2025-12-30 00:00' then 0.0
            when '{{blockchain}}' = 'ethereum' and token_address = 0x3231cb76718cdef2155fc47b5286d82e6eda273f and hour >= timestamp '2026-01-13 00:00' then 0.0
            when '{{blockchain}}' = 'gnosis' and token_address = 0x5cb9073902f2035222b9749f8fb0c9bfe5527108 and hour >= timestamp '2026-07-28 00:00' then 0.0
            when '{{blockchain}}' = 'ethereum' and token_address = 0x4956b52ae2ff65d74ca2d61207523288e4528f96 and hour >= timestamp '2026-03-22 15:00' and hour <= timestamp '2026-03-22 19:00' then 0.23292903653351268 / pow(10, 18)
            when '{{blockchain}}' = 'ethereum' and token_address = 0xfcc5c47be19d06bf83eb04298b026f81069ff65b and hour >= timestamp '2026-05-27 09:00' and hour <= timestamp '2026-05-27 10:00' then 0.133 / pow(10, 18)
            when '{{blockchain}}' = 'ethereum' and token_address = 0x01791f726b4103694969820be083196cc7c045ff and hour >= timestamp '2026-05-27 10:00' and hour <= timestamp '2026-05-27 11:00' then 0.105 / pow(10, 18)
            when '{{blockchain}}' = 'ethereum' and token_address = 0x60d48c1a161559255aaf572f3c1ce4185578dcfe and hour >= timestamp '2026-07-14 13:00' and hour <= timestamp '2026-07-14 14:00' then 0.0
            when '{{blockchain}}' = 'ethereum' and token_address = 0x4e15361fd6b4bb609fa63c81a2be19d873717870 and hour >= timestamp '2026-07-30 09:00' and hour <= timestamp '2026-07-30 10:00' then 0.0284 / pow(10, 18) -- noqa:CP02
            when '{{blockchain}}' = 'ethereum' and token_address = 0x230f1e241c621d5af670dad83ebcdd18971e2995 and hour >= timestamp '2026-08-24 15:00' and hour <= timestamp '2026-08-24 23:59' then 0.005  / pow(10, 18) -- noqa:CP02
            else price_atom
        end as price_atom
    from prices_pre
),

wrapped_native_token as (
    select
        case '{{blockchain}}'
            when 'ethereum' then 0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2 -- WETH
            when 'gnosis' then 0xe91d153e0b41518a2ce8dd3d7944fa863463a97d -- WXDAI
            when 'arbitrum' then 0x82af49447d8a07e3bd95bd0d56f35241523fbab1 -- WETH
            when 'base' then 0x4200000000000000000000000000000000000006 -- WETH
            when 'avalanche_c' then 0xb31f66aa3c1e785363f0875a1b74e27b85fd66c7 -- WAVAX
            when 'polygon' then 0x0d500b1d8e8ef31e21c99d1db9a6444d3adf1270 -- WPOL
            when 'lens' then 0x6bdc36e20d267ff0dd6097799f82e78907105e2f -- WGHO
            when 'bnb' then 0xbb4cdb9cbd36b01bd1cbaebf2de08d9173bc095c -- WBNB
            when 'linea' then 0xe5d7c2a44ffddf6b295a15c148167daaaf5cf34f -- WETH
            when 'plasma' then 0x6100e367285b01f48d07953803a2d8dca5d19873 -- WXPL
            when 'ink' then 0x4200000000000000000000000000000000000006 -- WETH
        end as native_token_address
),

-- The price of the native token is reconstructed from it chain-dependent wrapped version.
native_token_prices as (
    select -- noqa: ST06
        date_trunc('hour', minute) as hour, --noqa: RF04
        0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee as token_address,
        18 as decimals,
        avg(price) as price_unit,
        avg(price) / pow(10, 18) as price_atom
    from prices.usd
    where
        blockchain = '{{blockchain}}'
        and contract_address = (select native_token_address from wrapped_native_token)
        and minute >= cast('{{start_time}}' as timestamp) and minute < cast('{{end_time}}' as timestamp)
    group by 1, 2, 3
)

select * from prices
union all
select * from native_token_prices
