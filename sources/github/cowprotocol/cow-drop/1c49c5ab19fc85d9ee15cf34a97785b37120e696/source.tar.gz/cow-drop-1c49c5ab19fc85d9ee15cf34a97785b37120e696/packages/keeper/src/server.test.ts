import type { Server } from 'node:http'
import type { AddressInfo } from 'node:net'
import { runInNewContext } from 'node:vm'
import { compileRecipe } from '@cowprotocol/cow-drop-sdk'
import { afterEach, describe, expect, it } from 'vitest'
import { keccak256 } from 'viem'

import { createEventBus } from './events.js'
import { CHAIN_ID, OWNER, deployment, fakeSubmitter, recipeJson, registered } from './fixtures.js'
import { DEFAULT_POLICY } from './policy.js'
import { createKeeperServer, openApiDocument, ROUTES, type ServerOptions } from './server.js'
import { memoryStore } from './store.js'

const servers: Server[] = []
afterEach(() => {
  // Same reason `service.close()` does it: an open SSE stream never ends, so `close()` alone would
  // leave the socket and its keepalive behind and leak into the next test.
  for (const server of servers) {
    server.closeAllConnections()
    server.close()
  }
  servers.length = 0
})

async function serve(overrides: Partial<ServerOptions> = {}) {
  const store = overrides.store ?? memoryStore()
  const events = overrides.events ?? createEventBus()
  const server = createKeeperServer({
    store,
    deployment: deployment(),
    events,
    policy: DEFAULT_POLICY,
    submitter: fakeSubmitter([]).submitter,
    ...overrides,
  })

  await new Promise<void>((resolve) => server.listen(0, resolve))
  servers.push(server)
  const { port } = server.address() as AddressInfo
  return { base: `http://127.0.0.1:${port}`, store, events }
}

/** `Response.json()` is `unknown` under strict TS, and every assertion here reaches into the body. */
async function json(response: Response): Promise<any> {
  return response.json()
}

function post(base: string, path: string, body: unknown, init: RequestInit = {}) {
  return fetch(`${base}${path}`, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(body),
    ...init,
  })
}

describe('POST /v1/drops', () => {
  it('creates on the first call and reports the same drop on the second', async () => {
    // Idempotent, so a client whose POST timed out can retry — and be told truthfully that it is safe.
    const { base } = await serve()
    const recipe = recipeJson()
    const address = compileRecipe(recipe).address

    const first = await post(base, '/v1/drops', { recipe, address })
    const second = await post(base, '/v1/drops', { recipe, address })

    expect(first.status).toBe(201)
    expect(second.status).toBe(200)
    expect((await json(second)).drop.address).toBe(address.toLowerCase())
  })

  it('409s an address the client derived differently, and names both', async () => {
    const { base } = await serve()
    const recipe = recipeJson()
    const wrong = `0x${'11'.repeat(20)}`

    const response = await post(base, '/v1/drops', { recipe, address: wrong })
    const body = await json(response)

    expect(response.status).toBe(409)
    expect(body).toMatchObject({ error: 'address-mismatch', supplied: wrong })
    expect(body.derived).toBe(compileRecipe(recipe).address)
  })

  it('400s a recipe that does not compile, with the SDK\'s own message', async () => {
    const { base } = await serve()
    const response = await post(base, '/v1/drops', { recipe: { ...recipeJson(), version: 99 } })

    expect(response.status).toBe(400)
    expect((await json(response)).error).toBe('invalid-recipe')
  })

  it('422s a recipe for a chain this keeper does not serve', async () => {
    const { base } = await serve()
    const response = await post(base, '/v1/drops', { recipe: recipeJson({ chainId: 1 }) })

    expect(response.status).toBe(422)
    expect((await json(response))).toMatchObject({ error: 'wrong-chain', expected: CHAIN_ID })
  })

  it('415s anything that is not JSON, and 400s JSON that is not', async () => {
    const { base } = await serve()

    expect((await fetch(`${base}/v1/drops`, { method: 'POST', body: 'hi' })).status).toBe(415)
    expect(
      (await fetch(`${base}/v1/drops`, {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: '{oops',
      })).status,
    ).toBe(400)
  })

  it('413s a body past the cap without buffering all of it', async () => {
    const { base } = await serve({ maxBodyBytes: 512 })
    const response = await post(base, '/v1/drops', { recipe: recipeJson({ label: 'x'.repeat(4096) }) })

    expect(response.status).toBe(413)
  })

  it('429s once the registry is full', async () => {
    // Registration grants nothing, but it is not free — every entry is a recipe stored forever.
    const { base } = await serve({ maxDrops: 1 })
    await post(base, '/v1/drops', { recipe: recipeJson() })

    const response = await post(base, '/v1/drops', { recipe: recipeJson({ label: 'second' }) })
    expect(response.status).toBe(429)
  })
})

describe('POST /v1/drops/unregister', () => {
  it('takes the recipe, not just the address', async () => {
    // Unregistering someone else's drop costs them their subsidy for free, so it asks for the one
    // thing only somebody holding the recipe has.
    const { base, store } = await serve()
    const recipe = recipeJson()
    await post(base, '/v1/drops', { recipe })

    const response = await post(base, '/v1/drops/unregister', { recipe })

    expect(response.status).toBe(200)
    expect((await store.get(CHAIN_ID, compileRecipe(recipe).address))?.status).toBe('retired')
  })

  it('404s a recipe nobody registered', async () => {
    const { base } = await serve()
    expect((await post(base, '/v1/drops/unregister', { recipe: recipeJson() })).status).toBe(404)
  })

  it('400s without a recipe, rather than accepting an address', async () => {
    const { base } = await serve()
    expect((await post(base, '/v1/drops/unregister', {})).status).toBe(400)
  })

  it('409s while an activation is in flight, and leaves the drop reconcilable', async () => {
    // Retiring here would abandon a transaction the keeper has already paid for. 409 rather than 400:
    // the request is well formed and succeeds on its own once the next tick reconciles the receipt.
    const { base, store } = await serve()
    const recipe = recipeJson()
    await post(base, '/v1/drops', { recipe })
    const address = compileRecipe(recipe).address.toLowerCase() as `0x${string}`
    const ref = `0x${'ab'.repeat(32)}` as const
    await store.update(CHAIN_ID, address, (current) => ({
      ...current,
      status: 'activating',
      pending: {
        ref,
        nonce: 1,
        gasLimit: '300000',
        maxFeePerGas: '2000000000',
        reservedWei: '600000000000000',
        sentAt: 0,
        sentAtBlock: '100',
        replacements: 0,
      },
    }))

    const response = await post(base, '/v1/drops/unregister', { recipe })

    expect(response.status).toBe(409)
    expect(await json(response)).toMatchObject({ error: 'activating', ref })
    expect((await store.get(CHAIN_ID, address))?.status).toBe('activating')
  })

  it('emits the same retired event the keeper emits itself', async () => {
    // An operator watching the stream should not have to guess why a drop stopped being polled.
    const { base, events } = await serve()
    const recipe = recipeJson()
    await post(base, '/v1/drops', { recipe })

    const seen: unknown[] = []
    events.subscribe([compileRecipe(recipe).address.toLowerCase() as `0x${string}`], (event) => seen.push(event))
    await post(base, '/v1/drops/unregister', { recipe })

    expect(seen).toEqual([expect.objectContaining({ type: 'retired', reason: 'unregistered' })])
  })

  it('resumes watching when the same recipe is registered again', async () => {
    // End to end, because this is the pair the UI's toggle presses: stop, then start.
    const { base, store } = await serve()
    const recipe = recipeJson()
    await post(base, '/v1/drops', { recipe })
    await post(base, '/v1/drops/unregister', { recipe })

    const response = await post(base, '/v1/drops', { recipe })

    // 200, not 201: the same record resumed, so capacity is not taken twice.
    expect(response.status).toBe(200)
    expect((await json(response)).drop).toMatchObject({ status: 'watching', watching: true })
    expect(await store.active(CHAIN_ID)).toHaveLength(1)
  })
})

describe('GET /v1/drops/:address', () => {
  it('serves the drop, case-insensitively, and 404s otherwise', async () => {
    const { base } = await serve()
    const recipe = recipeJson()
    const address = compileRecipe(recipe).address
    await post(base, '/v1/drops', { recipe })

    expect((await fetch(`${base}/v1/drops/${address}`)).status).toBe(200)
    expect((await fetch(`${base}/v1/drops/${address.toLowerCase()}`)).status).toBe(200)
    expect((await fetch(`${base}/v1/drops/0x${'22'.repeat(20)}`)).status).toBe(404)
  })

  it('includes the activation history, so a reload can reconcile what it missed', async () => {
    const { base } = await serve()
    await post(base, '/v1/drops', { recipe: recipeJson() })

    const drop = (await json(await fetch(`${base}/v1/drops/${compileRecipe(recipeJson()).address}`))).drop
    expect(drop.activations).toEqual([])
    expect(drop.hints.tokens).toHaveLength(1)
  })
})

describe('GET /v1/drops?owner=', () => {
  it('400s without an owner, rather than dumping every drop it holds', async () => {
    // The filter is the design, not a convenience: unfiltered, this is every recipe the keeper holds —
    // labels, token hints, balances and activation history for everybody.
    const { base } = await serve()
    const response = await fetch(`${base}/v1/drops`)

    expect(response.status).toBe(400)
    expect((await json(response)).error).toBe('invalid-request')
  })

  it('400s a malformed owner rather than answering that it has none', async () => {
    // A typo and an empty registry must not read the same: the page asking this exists to tell
    // "you have nothing" from "we asked wrong".
    const { base } = await serve()
    expect((await fetch(`${base}/v1/drops?owner=0xnope`)).status).toBe(400)
  })

  it('lists an owner\'s drops, newest first', async () => {
    const { base } = await serve()
    // Distinct labels give distinct addresses, so these are two drops rather than one registered twice.
    await post(base, '/v1/drops', { recipe: recipeJson({ label: 'older' }) })
    await post(base, '/v1/drops', { recipe: recipeJson({ label: 'newer' }) })

    const body = await json(await fetch(`${base}/v1/drops?owner=${OWNER}`))

    expect(body.total).toBe(2)
    expect(body.truncated).toBe(false)
    expect(body.drops).toHaveLength(2)
    expect(body.drops.map((drop: any) => drop.label)).toContain('newer')
  })

  it('answers an owner it has never seen with an empty list, and still names the chain', async () => {
    // The chain assertion is the point: the empty answer is the only one carrying no drops to read it
    // from, and it is exactly when the UI must say "this keeper has nothing for you".
    const { base } = await serve()
    const body = await json(await fetch(`${base}/v1/drops?owner=0x${'11'.repeat(20)}`))

    expect(body.drops).toEqual([])
    expect(body.total).toBe(0)
    expect(body.chainId).toBe(CHAIN_ID)
  })

  it('does not serve one owner\'s drops to another', async () => {
    const { base } = await serve()
    const other = `0x${'33'.repeat(20)}` as const
    await post(base, '/v1/drops', { recipe: recipeJson() })
    await post(base, '/v1/drops', { recipe: recipeJson({ owner: other }) })

    const mine = await json(await fetch(`${base}/v1/drops?owner=${OWNER}`))
    const theirs = await json(await fetch(`${base}/v1/drops?owner=${other}`))

    expect(mine.drops).toHaveLength(1)
    expect(theirs.drops).toHaveLength(1)
    expect(mine.drops[0].address).not.toBe(theirs.drops[0].address)
  })

  it('matches an owner whatever its casing', async () => {
    // Registration lowercases the owner, so a checksummed query has to find it anyway.
    const { base } = await serve()
    await post(base, '/v1/drops', { recipe: recipeJson() })

    const shouted = `0x${OWNER.slice(2).toUpperCase()}`
    expect((await json(await fetch(`${base}/v1/drops?owner=${shouted}`))).drops).toHaveLength(1)
  })

  it('includes retired drops, because the drop nothing is watching is the one worth seeing', async () => {
    // It may still be holding money, and the owner is the person who needs to know.
    const { base } = await serve()
    const recipe = recipeJson()
    await post(base, '/v1/drops', { recipe })
    await post(base, '/v1/drops/unregister', { recipe })

    const body = await json(await fetch(`${base}/v1/drops?owner=${OWNER}`))

    expect(body.drops).toHaveLength(1)
    expect(body.drops[0]).toMatchObject({ watching: false, retiredReason: 'unregistered' })
  })

  it('never serves the recipe or setupData', async () => {
    // The privacy guarantee as an assertion: `setupData` is the activation authority, and this route is
    // enumerable by guessing an address. Fails loudly the day someone widens `toWire`.
    const { base } = await serve()
    await post(base, '/v1/drops', { recipe: recipeJson() })

    const drop = (await json(await fetch(`${base}/v1/drops?owner=${OWNER}`))).drops[0]
    expect(drop.recipe).toBeUndefined()
    expect(drop.setupData).toBeUndefined()
  })

  it('caps the list and says so rather than truncating silently', async () => {
    const { base } = await serve({ maxListed: 1 })
    await post(base, '/v1/drops', { recipe: recipeJson({ label: 'one' }) })
    await post(base, '/v1/drops', { recipe: recipeJson({ label: 'two' }) })

    const body = await json(await fetch(`${base}/v1/drops?owner=${OWNER}`))

    expect(body.drops).toHaveLength(1)
    expect(body.total).toBe(2)
    expect(body.truncated).toBe(true)
  })
})

describe('CORS', () => {
  it('answers the preflight a JSON POST always triggers', async () => {
    // The web app has no dev proxy, so this is on the critical path rather than an afterthought.
    const { base } = await serve()
    const response = await fetch(`${base}/v1/drops`, { method: 'OPTIONS' })

    expect(response.status).toBe(204)
    expect(response.headers.get('access-control-allow-methods')).toContain('POST')
    expect(response.headers.get('access-control-allow-headers')).toContain('content-type')
  })

  it('sets the origin header on every response, 404s included', async () => {
    const { base } = await serve()
    expect((await fetch(`${base}/nope`)).headers.get('access-control-allow-origin')).toBe('*')
  })

  it('echoes a configured origin and varies on it', async () => {
    const { base } = await serve({ allowOrigin: 'https://drop.cow.fi' })
    const allowed = await fetch(`${base}/v1/health`, { headers: { origin: 'https://drop.cow.fi' } })
    const other = await fetch(`${base}/v1/health`, { headers: { origin: 'https://evil.example' } })

    expect(allowed.headers.get('access-control-allow-origin')).toBe('https://drop.cow.fi')
    expect(allowed.headers.get('vary')).toBe('Origin')
    expect(other.headers.get('access-control-allow-origin')).toBeNull()
  })
})

describe('GET /v1/health and /v1/policy', () => {
  it('reports the payer and the budget left', async () => {
    const { base } = await serve()
    const health = await json(await fetch(`${base}/v1/health`))

    expect(health.ok).toBe(true)
    expect(health.chainId).toBe(CHAIN_ID)
    expect(health.remainingTodayWei).toBe(DEFAULT_POLICY.dailyBudgetWei.toString())
  })

  it('is unhealthy when the payer cannot cover its floor', async () => {
    // So a keeper that has run out of gas is noticed by a monitor, not by a user.
    const { base } = await serve({ submitter: { ...fakeSubmitter([]).submitter, balance: async () => 0n } })
    expect((await fetch(`${base}/v1/health`)).status).toBe(503)
  })

  it('says whether it is subsidising before anyone commits to registering', async () => {
    const { base } = await serve()
    expect((await json(await fetch(`${base}/v1/policy`))).subsidising).toBe(true)
  })
})


describe('GET /v1/about', () => {
  it('publishes the contracts behind the generation number, named and addressed', async () => {
    // The mismatch this catches is silent: a keeper on a generation the client did not compile
    // against derives a different address for the same recipe, and the drop is funded before it
    // exists. Comparing the numbers is not enough — these are what the numbers stand for.
    const { base } = await serve()
    const body = await json(await fetch(`${base}/v1/about`))
    const deployed = deployment()

    expect(body.chainId).toBe(CHAIN_ID)
    expect(body.generation).toBe(deployed.generation)
    expect(body.contracts.factory).toEqual({
      name: 'COWShedExecutorFactory',
      address: deployed.factory,
      dropAddress: true,
    })
    expect(body.contracts.cowOrderPoster.dropAddress).toBe(false)
    expect(body.proxyCreationCodeHash).toBe(keccak256(deployed.proxyCreationCode))
  })

  it('covers every address of the deployment', async () => {
    // Hand-maintained, so an address added to `DropAddresses` and not to the table would otherwise
    // just be quietly missing from the one place a client goes to check what it is talking to.
    const { base } = await serve()
    const body = await json(await fetch(`${base}/v1/about`))
    const { chainId, generation, proxyCreationCode, ...addresses } = deployment()

    expect(Object.keys(body.contracts).sort()).toEqual(Object.keys(addresses).sort())
  })
})

describe('GET /v1/events', () => {
  it('requires a drop filter', async () => {
    const { base } = await serve()
    expect((await fetch(`${base}/v1/events`)).status).toBe(400)
  })

  it('opens with a hello carrying the head and a snapshot', async () => {
    // So a client that connects late is never blank, and never has to guess what it missed.
    const { base } = await serve()
    const recipe = recipeJson()
    await post(base, '/v1/drops', { recipe })
    const address = compileRecipe(recipe).address.toLowerCase()

    const response = await fetch(`${base}/v1/events?drop=${address}`)
    expect(response.headers.get('content-type')).toContain('text/event-stream')

    const reader = response.body!.getReader()
    const hello = await readUntil(reader, 'event: hello')
    expect(hello).toContain('event: hello')
    expect(hello).toContain(address)
    // The browser is told how fast to reconnect, once, before anything else.
    expect(hello).toContain('retry: 3000')
    await reader.cancel()
  })

  it('streams an event for a watched drop, framed on one line', async () => {
    const { base, events } = await serve()
    const address = compileRecipe(recipeJson()).address.toLowerCase() as `0x${string}`

    const response = await fetch(`${base}/v1/events?drop=${address}`)
    const reader = response.body!.getReader()
    await readUntil(reader, 'event: hello')

    events.emit({ type: 'registered', chainId: CHAIN_ID, drop: address, owner: address, label: 'x' })
    const chunk = await readUntil(reader, 'event: registered')

    const registered = chunk.slice(chunk.indexOf('id:'))
    expect(registered).toMatch(/^id: \d+\nevent: registered\ndata: \{.*\}\n\n/)
    // A newline inside `data:` would silently truncate the frame, so the payload must be one line.
    expect(registered.split('data: ')[1]?.split('\n')[0]).toContain('"type":"registered"')
    await reader.cancel()
  })

  it('does not send another drop\'s events', async () => {
    const { base, events } = await serve()
    const mine = `0x${'11'.repeat(20)}` as `0x${string}`
    const theirs = `0x${'22'.repeat(20)}` as `0x${string}`

    const response = await fetch(`${base}/v1/events?drop=${mine}`)
    const reader = response.body!.getReader()
    await readUntil(reader, 'event: hello')

    events.emit({ type: 'registered', chainId: CHAIN_ID, drop: theirs, owner: theirs, label: 'not mine' })
    events.emit({ type: 'registered', chainId: CHAIN_ID, drop: mine, owner: mine, label: 'mine' })

    const chunk = await readUntil(reader, 'event: registered')
    expect(chunk).toContain('"label":"mine"')
    expect(chunk).not.toContain('not mine')
    await reader.cancel()
  })
})

/**
 * Read the stream until `marker` shows up.
 *
 * Chunk boundaries are the transport's business, not the protocol's — `retry:` may or may not share a
 * packet with the `hello` frame — so a test that counts reads is testing TCP rather than the server.
 */
async function readUntil(
  reader: ReadableStreamDefaultReader<Uint8Array>,
  marker: string,
  limit = 20,
): Promise<string> {
  let text = ''
  for (let i = 0; i < limit && !text.includes(marker); i++) {
    const { value, done } = await reader.read()
    if (done) break
    text += new TextDecoder().decode(value)
  }
  return text
}

describe('GET /v1/openapi.json', () => {
  it('describes every documented route', async () => {
    const { base } = await serve()

    const document = await json(await fetch(`${base}/v1/openapi.json`))

    expect(document.openapi).toBe('3.1.0')
    for (const route of ROUTES) {
      expect(document.paths[route.path]?.[route.method.toLowerCase()]?.summary).toBe(route.summary)
    }
  })

  it('declares the address path parameter', async () => {
    // Without it the document says `/v1/drops/{address}` takes no input, which is worse than silence:
    // a generated client would emit a request to the literal path.
    const document = openApiDocument(100, 2) as any

    expect(document.paths['/v1/drops/{address}'].get.parameters).toEqual([
      { name: 'address', in: 'path', required: true, schema: { type: 'string', pattern: '^0x[0-9a-fA-F]{40}$' } },
    ])
  })

  it('declares the owner query parameter, without claiming the POST takes one', async () => {
    // `/v1/drops` carries two methods now. The last assertion is the one that matters: it catches the
    // path item being overwritten rather than merged, which would publish only whichever route came
    // last — and it pins the parameter to the GET, so a generated client does not send `owner` on a
    // registration.
    const document = openApiDocument(100, 2) as any

    expect(document.paths['/v1/drops'].get.parameters).toEqual([
      { name: 'owner', in: 'query', required: true, schema: { type: 'string', pattern: '^0x[0-9a-fA-F]{40}$' } },
    ])
    expect(document.paths['/v1/drops'].post).toBeDefined()
    expect(document.paths['/v1/drops'].post.parameters).toBeUndefined()
  })
})

describe('ROUTES', () => {
  it('lists only routes the router actually serves', async () => {
    // The table feeds both the OpenAPI document and the boot banner, and it is maintained by hand.
    // This is what stops it drifting into advertising a route that 404s. A documented route may answer
    // 400 or 503 here — what it must never do is claim not to exist. `GET /v1/drops` answers 400,
    // because it requires an `owner` and this walk sends none.
    //
    // Seeded with a real drop because `GET /v1/drops/<address>` answers 404 for an address it does not
    // hold, which is a missing *record* rather than a missing route. Only a registered address
    // distinguishes the two.
    const drop = registered()
    const { base } = await serve({ store: memoryStore([drop]) })

    for (const route of ROUTES) {
      const path = route.path.replace('{address}', drop.address)
      const response = await fetch(`${base}${path}`, {
        method: route.method,
        ...(route.method === 'POST' ? { headers: { 'content-type': 'application/json' }, body: '{}' } : {}),
      })

      expect(response.status, `${route.method} ${path}`).not.toBe(404)
      await response.text()
    }
  })
})

/**
 * Runs the docs page's own inline script against a fake `location`, and reports the spec URL it asked
 * Swagger UI for.
 *
 * The script is executed rather than pattern-matched because the failure this guards against is the
 * script arriving *syntactically intact but semantically dead*: written with a regex, TypeScript
 * consumes the backslashes inside the template literal and the browser receives `replace(//docs/?$/,`
 * — a line comment that deletes the SwaggerUIBundle call. The HTML still contains every expected
 * substring, the page still returns 200, and it renders blank. Only running it catches that.
 */
function specUrlAskedFor(html: string, pathname: string): string {
  const script = /<script>([\s\S]*?)<\/script>/.exec(html)?.[1]
  if (!script) throw new Error('the docs page has no inline script')

  let url: unknown
  runInNewContext(script, {
    location: { pathname },
    window: {},
    SwaggerUIBundle: (options: { url: string }) => {
      url = options.url
      return {}
    },
  })

  if (typeof url !== 'string') throw new Error('the inline script never called SwaggerUIBundle')
  return url
}

describe('GET /v1/docs', () => {
  it('serves Swagger UI as html', async () => {
    const { base } = await serve()

    const response = await fetch(`${base}/v1/docs`)
    const html = await response.text()

    expect(response.status).toBe(200)
    expect(response.headers.get('content-type')).toBe('text/html; charset=utf-8')
    expect(html).toContain('swagger-ui-bundle.js')
  })

  it('points Swagger UI at the sibling spec, with or without a trailing slash', async () => {
    // The router strips trailing slashes, so `/v1/docs/` is served too — and a relative `openapi.json`
    // would resolve to `/v1/docs/openapi.json` there and 404.
    const { base } = await serve()
    const html = await (await fetch(`${base}/v1/docs`)).text()

    expect(specUrlAskedFor(html, '/v1/docs')).toBe('/v1/openapi.json')
    expect(specUrlAskedFor(html, '/v1/docs/')).toBe('/v1/openapi.json')
  })

  it('survives being mounted under a proxy subpath', async () => {
    const { base } = await serve()
    const html = await (await fetch(`${base}/v1/docs`)).text()

    expect(specUrlAskedFor(html, '/keeper/v1/docs')).toBe('/keeper/v1/openapi.json')
  })
})
