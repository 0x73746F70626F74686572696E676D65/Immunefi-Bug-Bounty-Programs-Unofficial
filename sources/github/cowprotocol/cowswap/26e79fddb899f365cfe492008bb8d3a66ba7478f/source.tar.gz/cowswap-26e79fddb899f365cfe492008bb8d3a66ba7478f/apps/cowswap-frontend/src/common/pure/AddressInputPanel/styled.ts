import { Media, UI } from '@cowprotocol/ui'

import SVG from 'react-inlinesvg'
import styled, { css, keyframes } from 'styled-components/macro'

export const ReceiverPanel = styled.div`
  display: flex;
  flex-direction: column;
  border-radius: 16px;
  background-color: var(${UI.COLOR_PAPER_DARKER});
  width: 100%;
`

export const ReceiverHeader = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 12px 16px;

  ${Media.upToSmall()} {
    flex-direction: column;
    align-items: center;
    gap: 8px;
    padding: 16px;
  }
`

export const ChainLabelGroup = styled.div`
  display: flex;
  align-items: center;
  gap: 8px;
`

export const ChainIconImg = styled.img`
  width: 18px;
  height: 18px;
  border-radius: 50%;
`

export const ChainNameLabel = styled.span`
  font-size: 14px;
  font-weight: 500;
`

export const ReceiverActions = styled.div`
  display: flex;
  align-items: center;
  gap: 8px;

  ${Media.upToSmall()} {
    gap: 34px;
  }
`

export const ActionBtn = styled.button`
  font-size: 13px;
  font-weight: 400;
  color: inherit;
  opacity: 0.7;
  display: inline-flex;
  align-items: center;
  gap: 4px;

  &:hover {
    opacity: 1;
  }
`

export const ActionExternalLink = styled.a`
  padding: 0;
  margin: 0;
  font-size: 13px;
  font-weight: 400;
  cursor: pointer;
  color: inherit;
  opacity: 0.7;
  text-decoration: none;
  display: inline-flex;
  align-items: center;
  gap: 4px;

  &:hover {
    opacity: 1;
  }
`

export const QrIconWrapper = styled.span`
  display: inline-flex;
  align-items: center;
`

export const ReceiverInputWrapper = styled.div`
  padding: 0 16px 12px;
`

export const ReceiverInputRow = styled.div`
  display: flex;
  align-items: center;
  gap: 8px;

  ${Media.upToSmall()} {
    justify-content: center;
  }
`

export const ValidCheckmark = styled(SVG)`
  width: 14px;
  height: 14px;
  flex: 0 0 auto;

  > path {
    fill: var(${UI.COLOR_SUCCESS});
  }
`

export const ReceiverInput = styled.input<{ $error?: boolean; $compact?: boolean }>`
  font-size: var(${UI.FONT_SIZE_LARGER});
  letter-spacing: -0.2px;
  flex: 1 1 auto;
  // Flex items default to min-width: auto, which stops them shrinking below their content's
  // natural size - e.g. a focused, full-length (untruncated) address next to the checkmark
  // would push the whole row (and page) wider instead of the input shrinking to fit.
  min-width: 0;
  transition: color 0.2s step-start;
  color: ${({ $error }) => ($error ? `var(${UI.COLOR_DANGER})` : 'inherit')};
  overflow: hidden;
  text-overflow: ellipsis;
  font-weight: 500;
  width: 100%;
  appearance: textfield;
  -webkit-appearance: textfield;

  &&::placeholder {
    color: inherit;
    opacity: 0.5;
  }

  &:focus::placeholder {
    color: transparent;
  }

  ::-webkit-search-decoration {
    -webkit-appearance: none;
  }

  ::-webkit-outer-spin-button,
  ::-webkit-inner-spin-button {
    -webkit-appearance: none;
  }

  ${Media.upToSmall()} {
    // Only shrink-to-fit and center for a confirmed valid (checkmark-showing) non-EVM address,
    // whose displayed value is already short/JS-truncated. field-sizing: content grows the box
    // to fit the full value with no truncation, which is fine there but would blow out the
    // layout for an invalid or full-length EVM address - so those keep the default left-aligned,
    // width: 100% input with the standard overflow: hidden + text-overflow: ellipsis above,
    // which already keeps the checkmark next to the start of the (ellipsis-truncated) text.
    ${({ $compact }) =>
      $compact &&
      css`
        text-align: center;
        flex: 0 1 auto;
        // Shrink to fit the (usually short, truncated) address so ReceiverInputRow's
        // justify-content: center centers the checkmark together with the address,
        // instead of centering the address text alone inside a full-width input.
        width: auto;
        // field-sizing sizes the box to the actual rendered value, unlike the HTML size
        // attribute (kept as a fallback below) which only approximates via character count
        // and can leave the box - and therefore the centered text - wider than the content.
        field-sizing: content;

        &:focus {
          // field-sizing: content overrides an explicit width entirely (that's its purpose), so
          // it must be reset back to the default here - otherwise the box stays sized to the
          // full, untruncated value shown on focus instead of respecting width: 100% below.
          field-sizing: fixed;
          width: 100%;
        }
      `}
  }
`

export const ReceiverErrorText = styled.p`
  font-size: 13px;
  color: var(${UI.COLOR_DANGER});
  padding-top: 8px;
  margin: 0;
`

export const ConfirmationRow = styled.div<{ $isConfirmed?: boolean }>`
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 24px 10px;

  background: ${({ $isConfirmed }) => ($isConfirmed ? `var(${UI.COLOR_SUCCESS_BG})` : `var(${UI.COLOR_INFO_BG})`)};
  color: var(${UI.COLOR_INFO_TEXT});
  border-radius: 0 0 16px 16px;
  padding: 16px;
  font-size: 14px;
  font-weight: 400;
  line-height: 1.2;
  width: 100%;

  input[type='checkbox'] {
    accent-color: var(${UI.COLOR_SUCCESS});
    flex-shrink: 0;
    cursor: pointer;
  }
`

export const ConfirmationLabel = styled.label<{ $confirmed: boolean }>`
  color: ${({ $confirmed }) => ($confirmed ? `var(${UI.COLOR_SUCCESS})` : 'inherit')};
  cursor: pointer;
  user-select: none;
  font-weight: 500;
`

// QR Modal

export const QrModalWrapper = styled.div`
  display: flex;
  flex-direction: column;
  gap: 16px;
  padding: 16px;
`

export const VideoContainer = styled.div`
  position: relative;
  width: 100%;
`

export const CameraVideo = styled.video`
  width: 100%;
  border-radius: 12px;
  display: block;
`

export const CornerBracketOverlay = styled.div`
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  pointer-events: none;
  border-radius: 12px;
  overflow: hidden;

  > span {
    position: absolute;
    width: 24px;
    height: 24px;
    border: 3px solid white;
  }

  > span.tl {
    top: 12px;
    left: 12px;
    border-right: none;
    border-bottom: none;
  }

  > span.tr {
    top: 12px;
    right: 12px;
    border-left: none;
    border-bottom: none;
  }

  > span.bl {
    bottom: 12px;
    left: 12px;
    border-right: none;
    border-top: none;
  }

  > span.br {
    bottom: 12px;
    right: 12px;
    border-left: none;
    border-top: none;
  }
`

const scanAnimation = keyframes`
  0%   { top: 10%; }
  50%  { top: 90%; }
  100% { top: 10%; }
`

export const ScanLineAnimation = styled.div`
  position: absolute;
  left: 16px;
  right: 16px;
  height: 2px;
  background: red;
  animation: ${scanAnimation} 2s ease-in-out infinite;
  pointer-events: none;
`

export const CameraSwitchBtn = styled.button`
  position: absolute;
  top: 8px;
  right: 8px;
  width: 40px;
  height: 40px;
  border-radius: 50%;
  background: rgba(0, 0, 0, 0.5);
  display: flex;
  align-items: center;
  justify-content: center;
  color: white;
  font-size: 18px;

  &:hover {
    background: rgba(0, 0, 0, 0.7);
  }
`

export const QrInstructions = styled.p`
  text-align: center;
  margin: 0;
  font-size: 14px;
`

export const QrSubText = styled.p`
  text-align: center;
  margin: 0;
  font-size: 12px;
  opacity: 0.6;
`
