import React, { useState } from 'react'

import iconMinusSrc from '@cowprotocol/assets/images/icon-minus.svg'
import iconPlusSrc from '@cowprotocol/assets/images/icon-plus.svg'
import { Media, UI } from '@cowprotocol/ui'

import SVG from 'react-inlinesvg'
import styled from 'styled-components/macro'

const Wrapper = styled.div<{ $fontSize?: number }>`
  --titleSize: 26px;
  --color: var(${UI.COLOR_NEUTRAL_10});
  display: flex;
  flex-flow: column wrap;
  align-items: flex-start;
  gap: 10px;
  margin: 24px 0;
  width: 100%;
  font-size: ${({ $fontSize }) => `${$fontSize ?? 24}px`};
  font-weight: var(${UI.FONT_WEIGHT_BOLD});

  ${Media.upToMedium()} {
    --titleSize: 18px;
  }

  a {
    color: var(--color);
    font-weight: inherit;
    text-decoration: underline;
  }

  details {
    --borderRadius: 56px;
    display: flex;
    flex-flow: column wrap;
    width: 100%;
    margin: 0 auto;
    padding: 0;
    line-height: 1;
    font-size: inherit;
    font-weight: inherit;
    position: relative;
    background: var(${UI.COLOR_NEUTRAL_95});
    border-radius: var(--borderRadius);

    ${Media.upToMedium()} {
      font-size: 18px;
    }
  }

  details > summary {
    display: flex;
    align-items: center;
    justify-content: space-between;
    font-weight: inherit;
    cursor: pointer;
    margin: 0;
    padding: 4px 4px 4px 21px;
    list-style-type: none;
    line-height: 1.2;
    position: relative;
    font-size: var(--titleSize);

    ${Media.upToMedium()} {
      padding: 14px 4px 14px 21px;
    }

    &::marker,
    &::-webkit-details-marker {
      display: none;
    }

    > i {
      --size: 56px;
      width: var(--size);
      height: var(--size);
      min-height: var(--size);
      min-width: var(--size);
      border-radius: var(--size);
      background: transparent;
      transition: background 0.2s ease-in-out;
      display: flex;
      align-items: center;
      justify-content: center;

      &:hover {
        background: var(${UI.COLOR_NEUTRAL_100});
      }
    }

    > i > svg {
      width: 100%;
      height: 100%;
      padding: 8px;
      fill: currentColor;
    }
  }

  details > div {
    --padding: 21px;
    font-size: inherit;
    line-height: 1.8;
    color: var(${UI.COLOR_NEUTRAL_40});
    font-weight: var(${UI.FONT_WEIGHT_NORMAL});
    margin: 0;
    padding: 0 33% var(--padding) var(--padding);

    ${Media.upToMedium()} {
      padding: 0 var(--padding) var(--padding) var(--padding);
    }
  }

  details[open] {
    --borderRadius: 32px;
  }

  details[open] > div {
  }

  details[open] > summary {
  }
`

interface FAQItemProps {
  question: string
  answer: string | React.ReactNode
}

const FAQItem: React.FC<FAQItemProps> = ({ question, answer }) => {
  const [isOpen, setIsOpen] = useState(false)

  const handleToggle = (e: React.MouseEvent): void => {
    e.preventDefault()
    setIsOpen(!isOpen)
  }

  return (
    <details open={isOpen}>
      <summary onClick={handleToggle}>
        {question}
        {isOpen ? (
          <i>
            <SVG src={iconMinusSrc} />
          </i>
        ) : (
          <i>
            <SVG src={iconPlusSrc} />
          </i>
        )}
      </summary>
      {isOpen && <div>{answer}</div>}
    </details>
  )
}

interface FAQComponentProps {
  faqs: FAQItemProps[]
  fontSize?: number
}

const FAQComponent: React.FC<FAQComponentProps> = ({ faqs, fontSize }) => {
  return (
    <Wrapper $fontSize={fontSize}>
      {faqs.map((faq, index) => (
        <FAQItem key={index} question={faq.question} answer={faq.answer} />
      ))}
    </Wrapper>
  )
}

export default FAQComponent
