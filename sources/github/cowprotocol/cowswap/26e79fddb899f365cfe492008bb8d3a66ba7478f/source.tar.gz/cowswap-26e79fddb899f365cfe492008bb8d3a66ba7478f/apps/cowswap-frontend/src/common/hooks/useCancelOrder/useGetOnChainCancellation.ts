/* eslint-disable @typescript-eslint/no-restricted-imports */ // TODO: Don't use 'modules' import
import { useCallback } from 'react'

import { useConfig } from 'wagmi'

import { getIsNativeToken } from '@cowprotocol/common-utils'

import { useLingui } from '@lingui/react/macro'

import { Order } from 'legacy/state/orders/actions'

import { useCancelTwapOrder } from 'modules/twap/hooks/useCancelTwapOrder'

import {
  getEthFlowCancellation,
  getOnChainCancellation,
  OnChainCancellation,
} from 'common/hooks/useCancelOrder/onChainCancellation'
import { useEthFlowContractData, useGP2SettlementContractData } from 'common/hooks/useContract'
import { getIsComposableCowParentOrder } from 'utils/orderUtils/getIsComposableCowParentOrder'
import { getIsTheLastTwapPart } from 'utils/orderUtils/getIsTheLastTwapPart'

export function useGetOnChainCancellation(): (order: Order) => Promise<OnChainCancellation> {
  const config = useConfig()
  const ethFlowContract = useEthFlowContractData()
  const settlementContract = useGP2SettlementContractData()
  const cancelTwapOrder = useCancelTwapOrder()
  const { t } = useLingui()

  const ethFlowChainId = ethFlowContract.chainId
  const settlementChainId = settlementContract.chainId

  return useCallback(
    (order: Order) => {
      if (ethFlowChainId !== settlementChainId) {
        throw new Error(
          t`Chain Id from contracts should match (ethFlow=${ethFlowChainId}, settlement=${settlementChainId})`,
        )
      }

      if (getIsTheLastTwapPart(order.composableCowInfo)) {
        return cancelTwapOrder(order.composableCowInfo!.parentId! as `0x${string}`, order)
      }

      if (getIsComposableCowParentOrder(order)) {
        return cancelTwapOrder(order.composableCowInfo!.id! as `0x${string}`, order)
      }

      if (order.isEoaTwapOrder && order.composableCowInfo?.parentId) {
        return cancelTwapOrder(order.composableCowInfo.parentId as `0x${string}`, order, { partOnly: true })
      }

      const isEthFlowOrder = getIsNativeToken(order.inputToken)

      if (isEthFlowOrder) {
        return getEthFlowCancellation({ config, ethFlowContract, order })
      }

      return getOnChainCancellation({ config, order, settlementContract })
    },
    [config, ethFlowChainId, settlementChainId, settlementContract, t, cancelTwapOrder, ethFlowContract],
  )
}
