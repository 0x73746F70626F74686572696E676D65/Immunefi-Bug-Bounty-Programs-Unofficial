import { useAtomValue, useSetAtom } from 'jotai'
import { useResetAtom } from 'jotai/utils'
import { useCallback } from 'react'

import { calculateGasMargin } from '@cowprotocol/common-utils'
import { isSolanaChain } from '@cowprotocol/cow-sdk'
import { Command } from '@cowprotocol/types'
import { useWalletDetails, useWalletInfo } from '@cowprotocol/wallet'
import { WidgetHookEvents } from '@cowprotocol/widget-lib'

import { useCloseModal, useOpenModal } from 'legacy/state/application/hooks'
import { ApplicationModal } from 'legacy/state/application/reducer'
import { useGasPrices } from 'legacy/state/gas/hooks'
import { Order } from 'legacy/state/orders/actions'

// eslint-disable-next-line @typescript-eslint/no-restricted-imports
import { buildOrderWidgetHookPayload, callWidgetHook } from 'modules/injectedWidget'

import { useGetOnChainCancellation } from 'common/hooks/useCancelOrder/useGetOnChainCancellation'
import { isOrderCancellable } from 'common/utils/isOrderCancellable'
import { isOrderOffChainCancellable } from 'common/utils/isOrderOffChainCancellable'
import useNativeCurrency from 'lib/hooks/useNativeCurrency'

import {
  CancellationModalContext,
  cancellationModalContextAtom,
  CancellationType,
  updateCancellationModalContextAtom,
} from './state'
import { useOffChainCancelOrder } from './useOffChainCancelOrder'
import { useSendOnChainCancellation } from './useSendOnChainCancellation'
import { useSolanaCancelOrder } from './useSolanaCancelOrder'

import { getSwapErrorMessage } from '../../utils/getSwapErrorMessage'

export type UseCancelOrderReturn = Command | null

/**
 *
 * This hook encapsulates all the logic related to order cancellation, be it off or on-chain
 * It returns a callback which in turn returns a callback
 * It also handles the modal display logic
 *
 * The first callback takes an Order object to construct the callback which will trigger the cancellation modal display
 * It checks whether the order is eligible for cancellation and set's up which type of cancellation can be used (on or off-chain)
 * In case the order is not eligible, it returns null. This should be used to control whether a cancel button should be displayed
 */
export function useCancelOrder(): (order: Order) => UseCancelOrderReturn {
  const { chainId } = useWalletInfo()
  const { allowsOffchainSigning } = useWalletDetails()
  const openModal = useOpenModal(ApplicationModal.CANCELLATION)
  const closeModal = useCloseModal(ApplicationModal.CANCELLATION)
  const { isPendingSignature } = useAtomValue(cancellationModalContextAtom)
  const setContext = useSetAtom(updateCancellationModalContextAtom)
  const resetContext = useResetAtom(cancellationModalContextAtom)
  const offChainOrderCancel = useOffChainCancelOrder()
  const sendOnChainCancellation = useSendOnChainCancellation()
  const solanaCancelOrder = useSolanaCancelOrder()
  const getOnChainTxInfo = useGetOnChainCancellation()
  const gasPrices = useGasPrices(chainId)
  const nativeCurrency = useNativeCurrency()

  return useCallback(
    (order: Order) => {
      // Check the 'cancellability'

      // The wallet must support off-chain signing
      const isOffChainCancellable = allowsOffchainSigning && isOrderOffChainCancellable(order)

      // When the order is not cancellable, there won't be a callback
      if (!isOrderCancellable(order)) {
        return null
      }

      // When dismissing the modal, close it and also reset context
      const onDismiss = (): void => {
        closeModal()
        resetContext()
      }

      // The callback to trigger the cancellation
      const triggerCancellation = async (type: CancellationType): Promise<void> => {
        const cancelFn = isSolanaChain(chainId)
          ? solanaCancelOrder
          : type === 'offChain'
            ? offChainOrderCancel
            : sendOnChainCancellation

        try {
          setContext({ isPendingSignature: true, error: null })
          // Actual cancellation is triggered here
          await cancelFn(order)
          onDismiss()
          // When done, dismiss the modal
        } catch (e) {
          onDismiss()
          if (!isPendingSignature) return

          const swapErrorMessage = getSwapErrorMessage(e?.body?.description || e, chainId)
          setContext({ error: swapErrorMessage })
        }
        setContext({ isPendingSignature: false })
      }

      // The callback returned that triggers the modal
      return () => {
        void (async () => {
          const isWidgetHookPassed = await callWidgetHook(
            WidgetHookEvents.ON_BEFORE_ORDER_CANCEL,
            buildOrderWidgetHookPayload(order),
          ).catch(() => false)

          if (!isWidgetHookPassed) return

          // Updates the cancellation context with details pertaining the order
          setContext({
            orderId: order.id,
            order,
            chainId,
            defaultType: isOffChainCancellable ? 'offChain' : 'onChain',
            onDismiss,
            triggerCancellation,
            nativeCurrency,
          })
          // Display the actual modal
          openModal()
          // Estimate tx cost in case when OnChain cancellation is used
          estimateOnChainTxCost(order, chainId, getOnChainTxInfo, gasPrices, setContext)
        })()
      }
    },
    [
      allowsOffchainSigning,
      chainId,
      closeModal,
      sendOnChainCancellation,
      offChainOrderCancel,
      solanaCancelOrder,
      openModal,
      resetContext,
      setContext,
      getOnChainTxInfo,
      gasPrices,
      nativeCurrency,
      isPendingSignature,
    ],
  )
}

// Solana has no gas estimate here (fees are negligible); txCost stays null and the modal shows "Unknown"
function estimateOnChainTxCost(
  order: Order,
  chainId: number | null,
  getOnChainTxInfo: ReturnType<typeof useGetOnChainCancellation>,
  gasPrices: ReturnType<typeof useGasPrices>,
  setContext: (state: Partial<CancellationModalContext>) => void,
): void {
  if (chainId && isSolanaChain(chainId)) return

  getOnChainTxInfo(order).then(({ estimatedGas }) => {
    const gasPrice = BigInt(gasPrices?.average || '0')
    const txCost = calculateGasMargin(estimatedGas) * gasPrice

    setContext({ txCost })
  })
}
