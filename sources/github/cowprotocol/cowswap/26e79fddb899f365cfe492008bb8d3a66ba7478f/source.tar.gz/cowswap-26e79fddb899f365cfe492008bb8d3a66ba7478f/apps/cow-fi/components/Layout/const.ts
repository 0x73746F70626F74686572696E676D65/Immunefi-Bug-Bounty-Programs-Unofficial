import { initGtm } from '@cowprotocol/analytics'
import { MenuItem, ProductVariant, UI } from '@cowprotocol/ui'

import { CowFiCategory } from 'src/common/analytics/types'

import { COW_SWAP_CTA } from '@/const/cta'

const analytics = initGtm()

export const PAGE_MAX_WIDTH = 1760
export const THEME_MODE = 'light'
export const PRODUCT_VARIANT = ProductVariant.CowDao

const LEARN_NAV_ITEM: MenuItem = {
  label: 'Learn',
  children: [
    {
      href: '/learn',
      label: 'Knowledge Base',
    },
    {
      href: 'https://docs.cow.fi/',
      label: 'Docs',
      external: true,
      utmContent: 'menubar-nav-item-docs',
    },
  ],
}

export function getNavItems(isSolversEnabled: boolean): MenuItem[] {
  return [getAboutNavItem(), getProductsNavItem(isSolversEnabled), LEARN_NAV_ITEM]
}

function getAboutNavItem(): MenuItem {
  return {
    label: 'About',
    children: [
      {
        label: 'Stats',
        href: 'https://dune.com/cowprotocol/cow-swap-home',
        external: true,
      },
      {
        label: 'Governance',
        href: 'https://docs.cow.fi/governance',
        external: true,
      },
      {
        label: 'Grants',
        href: 'https://grants.cow.fi/',
        external: true,
      },
      { label: 'Careers', href: '/careers' },
    ],
  }
}

function getProductsNavItem(isSolversEnabled: boolean): MenuItem {
  return {
    label: 'Products',
    children: [
      {
        label: 'CoW Swap',
        href: '/cow-swap',
      },
      {
        label: 'CoW Protocol',
        href: '/cow-protocol',
      },
      {
        label: 'More',
        children: [
          {
            label: 'Widget',
            href: '/widget',
          },
          {
            label: 'CoW Explorer',
            href: 'https://explorer.cow.fi/',
            external: true,
            utmContent: 'menubar-nav-item-cow-explorer',
          },
          ...(isSolversEnabled
            ? [
                {
                  label: 'Solvers',
                  href: 'https://explorer.cow.fi/solvers',
                  external: true,
                  utmContent: 'menubar-nav-item-solvers',
                },
              ]
            : []),
        ],
      },
    ],
  }
}

export const NAV_ADDITIONAL_BUTTONS = [
  {
    label: COW_SWAP_CTA.text,
    href: COW_SWAP_CTA.deeplinkHref,
    utmContent: 'menubar-nav-button-trade-on-cow-swap',
    onClick: () =>
      analytics.sendEvent({
        category: CowFiCategory.NAVIGATION,
        action: 'Click Trade on CoW Swap',
        label: 'menubar-nav-button',
      }),
    external: true,
    isButton: true,
    bgColor: `var(${UI.COLOR_BLUE_300_PRIMARY})`,
    color: `var(${UI.COLOR_BLUE_900_PRIMARY})`,
  },
]
