/* eslint-disable @typescript-eslint/no-restricted-imports */ // TODO: Don't use 'modules' import
import { useCallback } from 'react'

import { useCowAnalytics } from '@cowprotocol/analytics'
import { isInjectedWidget } from '@cowprotocol/common-utils'
import { OrderKind } from '@cowprotocol/cow-sdk'
import { CurrencyAmount } from '@cowprotocol/currency'
import { useTokensByAddressMap } from '@cowprotocol/tokens'
import { ClosableBanner } from '@cowprotocol/ui'
import { useIsSmartContractWallet, useWalletInfo } from '@cowprotocol/wallet'

import { t } from '@lingui/core/macro'

import { useIsDarkMode } from 'legacy/state/user/hooks'

import { getDefaultTradeRawState } from 'modules/trade'
import { useYieldRawState } from 'modules/yield/hooks/useYieldRawState'
import { useVampireAttack, useVampireAttackFirstTarget } from 'modules/yield/shared'

import { CowSwapAnalyticsCategory, toCowSwapGtmEvent } from 'common/analytics/types'
import { BANNER_IDS } from 'common/constants/banners'
import { Routes } from 'common/constants/routes'
import { useIsProviderNetworkUnsupported } from 'common/hooks/useIsProviderNetworkUnsupported'
import { useTradeNavigate } from 'common/modules/tradeNavigation'
import { CoWAmmBannerContent } from 'common/pure/CoWAmmBannerContent'

interface BannerProps {
  isTokenSelectorView?: boolean
}

// TODO: Break down this large function into smaller functions
// TODO: Add proper return type annotation
// eslint-disable-next-line @typescript-eslint/explicit-function-return-type
export function CoWAmmBanner({ isTokenSelectorView }: BannerProps) {
  const isDarkMode = useIsDarkMode()
  const isInjectedWidgetMode = isInjectedWidget()
  const { chainId, account } = useWalletInfo()
  const isChainIdUnsupported = useIsProviderNetworkUnsupported()
  const vampireAttackContext = useVampireAttack()
  const tokensByAddress = useTokensByAddressMap()
  const tradeNavigate = useTradeNavigate()
  const vampireAttackFirstTarget = useVampireAttackFirstTarget()
  const isSmartContractWallet = useIsSmartContractWallet()
  const yieldState = useYieldRawState()
  const cowAnalytics = useCowAnalytics()

  const key = isTokenSelectorView ? 'tokenSelector' : 'global'

  const handleCTAClick = useCallback(() => {
    const target = vampireAttackFirstTarget?.target
    const defaulTradeState = getDefaultTradeRawState(chainId)

    const targetTrade = target
      ? {
          inputCurrencyId: target.token.address || null,
          outputCurrencyId: target.alternative.address || null,
        }
      : {
          inputCurrencyId: yieldState.inputCurrencyId || defaulTradeState.inputCurrencyId,
          outputCurrencyId: yieldState.outputCurrencyId || defaulTradeState.outputCurrencyId,
        }

    const targetTradeParams = {
      amount: target
        ? CurrencyAmount.fromRawAmount(target.token, target.tokenBalance.toString()).toFixed(6)
        : undefined,
      kind: OrderKind.SELL,
    }

    cowAnalytics.sendEvent({
      category: CowSwapAnalyticsCategory.COWSWAP,
      action: `CoW AMM Banner [${key}] CTA Clicked`,
    })

    tradeNavigate(chainId, targetTrade, targetTradeParams, Routes.YIELD)
  }, [key, chainId, yieldState, vampireAttackFirstTarget, tradeNavigate, cowAnalytics])

  const bannerId = `${BANNER_IDS.COW_AMM}_${key}${isTokenSelectorView ? account : ''}`

  const callback = useCallback(
    (close: () => void) => {
      return vampireAttackContext ? (
        <CoWAmmBannerContent
          id={bannerId}
          isDarkMode={isDarkMode}
          title={t`CoW AMM`}
          ctaText={isSmartContractWallet ? t`Booooost APR!` : t`Booooost APR gas-free!`}
          isTokenSelectorView={!!isTokenSelectorView}
          vampireAttackContext={vampireAttackContext}
          tokensByAddress={tokensByAddress}
          onCtaClick={() => {
            handleCTAClick()
            close()
          }}
          onClose={close}
          data-click-event={toCowSwapGtmEvent({
            category: CowSwapAnalyticsCategory.COWSWAP,
            action: `CoW AMM Banner [${key}] Close`,
          })}
        />
      ) : (
        <></>
      )
    },
    [
      bannerId,
      isDarkMode,
      isSmartContractWallet,
      isTokenSelectorView,
      vampireAttackContext,
      tokensByAddress,
      key,
      handleCTAClick,
    ],
  )

  if (isInjectedWidgetMode || !account || isChainIdUnsupported || !vampireAttackContext) return null

  return <ClosableBanner storageKey={bannerId} callback={callback} />
}
