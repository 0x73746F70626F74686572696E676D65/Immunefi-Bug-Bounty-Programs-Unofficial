export type EnvironmentName = 'local' | 'development' | 'pr' | 'production'
export const ALL_ENVIRONMENTS: EnvironmentName[] = ['local', 'development', 'pr', 'production']

export interface EnvironmentChecks {
  isProd: boolean
  isPr: boolean
  isDev: boolean
  isLocal: boolean
}

function getConfiguredEnvironmentName(): EnvironmentName {
  const env = process.env.NEXT_PUBLIC_ENVIRONMENT?.trim().toLowerCase()

  if (!env) {
    throw new Error(`Missing NEXT_PUBLIC_ENVIRONMENT. Expected one of: ${ALL_ENVIRONMENTS.join(', ')}`)
  }

  if (!isEnvironmentName(env)) {
    throw new Error(`Invalid NEXT_PUBLIC_ENVIRONMENT="${env}". Expected one of: ${ALL_ENVIRONMENTS.join(', ')}`)
  }

  return env
}

function getEnvironmentChecks(environmentName: EnvironmentName): EnvironmentChecks {
  return {
    isLocal: environmentName === 'local',
    isDev: environmentName === 'development',
    isPr: environmentName === 'pr',
    isProd: environmentName === 'production',
  }
}

function isEnvironmentName(value: string): value is EnvironmentName {
  return ALL_ENVIRONMENTS.includes(value as EnvironmentName)
}

const configuredEnvironmentName = getConfiguredEnvironmentName()

export function checkEnvironment(): EnvironmentChecks {
  return getEnvironmentChecks(configuredEnvironmentName)
}

const { isLocal, isDev, isPr, isProd } = checkEnvironmentUsingWindow()

function checkEnvironmentUsingWindow(): EnvironmentChecks {
  return checkEnvironment()
}

function getEnvironmentName(): EnvironmentName {
  if (isProd) {
    return 'production'
  } else if (isPr) {
    return 'pr'
  } else if (isDev) {
    return 'development'
  } else if (isLocal) {
    return 'local'
  } else {
    return configuredEnvironmentName
  }
}

export const environmentName: EnvironmentName = getEnvironmentName()

export { isLocal, isDev, isPr, isProd }
