import { initGtm } from '@cowprotocol/analytics'
import svgBitsSrc from '@cowprotocol/assets/images/image-bits.svg'
import svgCoinsSrc from '@cowprotocol/assets/images/image-coins.svg'
import svgDiscordSrc from '@cowprotocol/assets/images/image-discord.svg'
import svgForumSrc from '@cowprotocol/assets/images/image-forum.svg'
import svgSnapshotSrc from '@cowprotocol/assets/images/image-snapshot.svg'
import { Color, ProductVariant, UI } from '@cowprotocol/ui'

import SVG from 'react-inlinesvg'
import { CowFiCategory } from 'src/common/analytics/types'

import { Link, LinkType } from '@/components/Link'
import { COW_SWAP_CTA } from '@/const/cta'
import {
  ContainerCard,
  ContainerCardSection,
  SectionTitleText,
  SectionTitleWrapper,
  TopicCard,
  TopicCardInner,
  TopicDescription,
  TopicImage,
  TopicList,
  TopicTitle,
} from '@/styles/styled'

const analytics = initGtm()

export const PRODUCT_LIST = [
  {
    title: 'CoW Protocol',
    description: 'Open-source, permissionless DEX aggregation protocol',
    linkHref: '/cow-protocol',
    linkText: 'Start building',
    linkEvent: 'click-start-building',
    bgColor: Color.cowfi_purple_dark,
    textColor: Color.cowfi_purple_bright,
    descriptionColor: Color.cowfi_purple_bright,
    linkBgColor: Color.cowfi_purple_bright,
    linkColor: Color.cowfi_purple_dark,
    productVariant: ProductVariant.CowDao,
    iconImage: svgBitsSrc,
  },
  {
    title: 'CoW Swap',
    description: 'The DEX that lets you do what you want',
    linkHref: COW_SWAP_CTA.deeplinkHref,
    linkText: COW_SWAP_CTA.text,
    linkEvent: COW_SWAP_CTA.action,
    linkExternal: true,
    linkUtmContent: 'home-page-trade-on-cow-swap',
    bgColor: `var(${UI.COLOR_BLUE_300_PRIMARY})`,
    textColor: `var(${UI.COLOR_BLUE_900_PRIMARY})`,
    descriptionColor: `var(${UI.COLOR_BLUE_900_PRIMARY})`,
    linkBgColor: `var(${UI.COLOR_BLUE_900_PRIMARY})`,
    linkColor: `var(${UI.COLOR_BLUE_300_PRIMARY})`,
    productVariant: ProductVariant.CowDao,
    iconImage: svgCoinsSrc,
  },
]

export const CHANNEL_LIST = [
  {
    title: 'Discord',
    href: 'https://discord.com/invite/cowprotocol',
    linkEvent: 'click-discord',
    iconColor: Color.cowfi_discord_pink,
    textColor: `var(${UI.COLOR_NEUTRAL_10})`,
    iconImage: svgDiscordSrc,
  },
  {
    title: 'Forum',
    href: 'https://forum.cow.fi/',
    linkEvent: 'click-forum',
    iconColor: Color.cowamm_dark_green,
    textColor: Color.neutral98,
    iconImage: svgForumSrc,
  },
  {
    title: 'Snapshot',
    href: 'https://snapshot.org/#/cow.eth',
    linkEvent: 'click-snapshot',
    iconColor: Color.cowfi_snapshot_red,
    textColor: Color.neutral98,
    iconImage: svgSnapshotSrc,
  },
]

export const PRODUCT_CONTAINERS = (
  <ContainerCard bgColor={`var(${UI.COLOR_NEUTRAL_100})`}>
    <ContainerCardSection>
      <SectionTitleWrapper color={`var(${UI.COLOR_NEUTRAL_0})`} maxWidth={1200} margin="100px auto">
        <SectionTitleText lineHeight={1.6} lineHeightMobile={1.8} fontSizeMobile={28}>
          CoW DAO develops the <span className="wordtag-orange">most user-protective</span> products in DeFi – so you
          can <span className="wordtag-purple">do more</span> with <span className="wordtag-blue">less worry</span>
        </SectionTitleText>
      </SectionTitleWrapper>

      <TopicList columns={2}>
        {PRODUCT_LIST.map((topic, index) => (
          <TopicCard
            key={index}
            contentAlign={'left'}
            bgColor={topic.bgColor}
            textColor={topic.textColor}
            padding={'32px'}
            asProp="div"
          >
            <TopicCardInner contentAlign="left">
              <TopicTitle fontSize={51}>{topic.title}</TopicTitle>
              <TopicDescription fontSize={28} color={topic.descriptionColor}>
                {topic.description}
              </TopicDescription>
              <Link
                bgColor={topic.linkBgColor}
                color={topic.linkColor}
                href={topic.linkHref}
                linkType={LinkType.TopicButton}
                onClick={() =>
                  analytics.sendEvent({
                    category: CowFiCategory.HOME,
                    action: topic.linkEvent,
                  })
                }
                external={topic.linkExternal}
                utmContent={topic.linkUtmContent}
              >
                {topic.linkText}
              </Link>
            </TopicCardInner>
            <TopicImage
              iconColor="transparent"
              bgColor="transparent"
              margin={'0 0 0 auto'}
              height={'236px'}
              width={'auto'}
            >
              <SVG src={topic.iconImage} title={topic.title} />
            </TopicImage>
          </TopicCard>
        ))}
      </TopicList>
    </ContainerCardSection>
  </ContainerCard>
)
