import { atom } from 'jotai'
import { atomWithReset } from 'jotai/utils'

import { TokenWithLogo } from '@cowprotocol/common-const'
import { Command } from '@cowprotocol/types'

import type { Order } from 'legacy/state/orders/actions'

import { MAINNET_NATIVE_CURRENCY } from 'lib/hooks/useNativeCurrency'

export type CancellationModalContext = {
  order?: Order
  chainId: number | null
  orderId: string | null
  error: string | null
  txCost: bigint | null
  nativeCurrency: TokenWithLogo
  isPendingSignature: boolean
  onDismiss: Command | null
  triggerCancellation: ((type: CancellationType) => Promise<void>) | null
  defaultType: CancellationType
}
export type CancellationType = 'offChain' | 'onChain'

const defaultCancellationModalContext: CancellationModalContext = {
  chainId: null,
  orderId: null,
  error: null,
  txCost: null,
  nativeCurrency: MAINNET_NATIVE_CURRENCY,
  isPendingSignature: false,
  onDismiss: null,
  triggerCancellation: null,
  defaultType: 'offChain',
}

export const cancellationModalContextAtom = atomWithReset<CancellationModalContext>(defaultCancellationModalContext)

export const updateCancellationModalContextAtom = atom(
  null,
  (get, set, nextState: Partial<CancellationModalContext>) => {
    set(cancellationModalContextAtom, () => {
      const prevState = get(cancellationModalContextAtom)

      return { ...prevState, ...nextState }
    })
  },
)
