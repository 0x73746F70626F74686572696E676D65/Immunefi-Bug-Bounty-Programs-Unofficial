'use client'

import iconBuildWithCowSrc from '@cowprotocol/assets/images/icon-build-with-cow.svg'
import iconBulbCowSrc from '@cowprotocol/assets/images/icon-bulb-cow.svg'
import iconCowLensSrc from '@cowprotocol/assets/images/icon-cow-lens.svg'
import iconCrownCowSrc from '@cowprotocol/assets/images/icon-crown-cow.svg'
import iconFaqSrc from '@cowprotocol/assets/images/icon-faq.svg'
import iconGhostSrc from '@cowprotocol/assets/images/icon-ghost.svg'
import iconCurveSrc from '@cowprotocol/assets/images/icon-logo-curve.svg'
import iconLidoSrc from '@cowprotocol/assets/images/icon-logo-lido.svg'
import iconSafeSrc from '@cowprotocol/assets/images/icon-logo-safe.svg'
import iconOwlSrc from '@cowprotocol/assets/images/icon-owl.svg'
import iconSecureSrc from '@cowprotocol/assets/images/icon-secure.svg'
import svgBatchauctionsSrc from '@cowprotocol/assets/images/image-batchauctions.svg'
import svgCowBitsSrc from '@cowprotocol/assets/images/image-cow-bits.svg'
import svgIntentsSrc from '@cowprotocol/assets/images/image-intents.svg'
import svgLeadingSrc from '@cowprotocol/assets/images/image-leading.svg'
import svgSolversSrc from '@cowprotocol/assets/images/image-solvers.svg'
import { Color, ProductLogo, ProductVariant, UI } from '@cowprotocol/ui'

import { CowFiCategory, toCowFiGtmEvent } from 'src/common/analytics/types'

import FAQ from '@/components/FAQ'
import LazySVG from '@/components/LazySVG'
import { Link, LinkType } from '@/components/Link'
import {
  ADVANCED_ORDER_TYPES,
  ALL_LOGOS,
  CASE_STUDIES,
  COW_PROTOCOL_SECTIONS,
  useFaqData,
  TOP_LOGOS,
  UNIQUE_TRADING_LOGIC,
} from '@/data/cow-protocol/const'
import {
  ContainerCard,
  ContainerCardSection,
  HeroContainer,
  HeroButtonWrapper,
  HeroContent,
  HeroDescription,
  HeroImage,
  HeroSubtitle,
  HeroTitle,
  MetricsCard,
  MetricsItem,
  PageWrapper,
  SectionImage,
  SectionTitleDescription,
  SectionTitleIcon,
  SectionTitleText,
  SectionTitleWrapper,
  TopicCard,
  TopicCardInner,
  TopicDescription,
  TopicImage,
  TopicList,
  TopicTitle,
} from '@/styles/styled'

export default function Page() {
  const faqData = useFaqData()

  return (
    <PageWrapper>
      <HeroContainer variant="secondary">
        <HeroContent variant="secondary">
          <HeroSubtitle color={Color.cowfi_purple3}>CoW Protocol</HeroSubtitle>
          <HeroTitle maxWidth={530}>Swap what you want, build what you want</HeroTitle>
          <HeroDescription>
            CoW Protocol has the largest solver competition and the most advanced developer framework - so you can build
            any DeFi-related action you can imagine
          </HeroDescription>
          <HeroButtonWrapper>
            <Link
              bgColor={Color.cowfi_purple3}
              color={Color.cowfi_purple_bright}
              href="mailto:hello@cow.fi?subject=Help%20me%20build%20with%20CoW%20Protocol"
              external
              linkType={LinkType.HeroButton}
              data-click-event={toCowFiGtmEvent({
                category: CowFiCategory.COWPROTOCOL,
                action: 'Get in touch',
              })}
            >
              Get in touch
            </Link>
            <Link
              bgColor="transparent"
              color={Color.cowfi_purple3}
              href="https://docs.cow.fi/category/tutorials"
              external
              linkType={LinkType.HeroButton}
              data-click-event={toCowFiGtmEvent({
                category: CowFiCategory.COWPROTOCOL,
                action: 'Start Building Tutorial Navigation',
              })}
            >
              Start building
            </Link>
          </HeroButtonWrapper>
        </HeroContent>
        <HeroImage width={470} height={470} color={Color.cowfi_purple3}>
          <LazySVG src={svgCowBitsSrc} />
        </HeroImage>
      </HeroContainer>

      <MetricsCard bgColor={Color.cowfi_purple_bright} color={Color.cowfi_purple3} columns={3} touchFooter>
        <MetricsItem dividerColor={Color.cowfi_purple4}>
          <h2>29</h2>
          <p>active solvers settling batches</p>
        </MetricsItem>
        <MetricsItem dividerColor={Color.cowfi_purple4}>
          <h2>#1</h2>
          <p>intent-based DEX protocol by volume</p>
        </MetricsItem>

        <MetricsItem>
          <h2>2.1B+</h2>
          <p>all time transactions</p>
        </MetricsItem>

        <Link
          bgColor="transparent"
          color={Color.cowfi_purple3}
          margin="24px auto 0"
          gridFullWidth
          href="https://dune.com/cowprotocol/cow-swap-home"
          external
          linkType={LinkType.SectionTitleButton}
          utmContent="cow-protocol-metrics"
          data-click-event={toCowFiGtmEvent({
            category: CowFiCategory.COWPROTOCOL,
            action: 'View Metrics On Dune',
          })}
        >
          View all metrics on DUNE &#8599;
        </Link>
      </MetricsCard>

      <ContainerCard bgColor={`var(${UI.COLOR_NEUTRAL_98})`}>
        <ContainerCardSection>
          <SectionTitleWrapper color={`var(${UI.COLOR_NEUTRAL_0})`} maxWidth={700} gap={56}>
            <SectionTitleIcon $size={82}>
              <LazySVG src={iconCrownCowSrc} />
            </SectionTitleIcon>
            <SectionTitleText>The leading intents-based DEX aggregation protocol</SectionTitleText>
            <SectionTitleDescription maxWidth={900} color={`var(${UI.COLOR_NEUTRAL_50})`}>
              CoW Protocol leverages intents, batch auctions, and the largest solver network in DeFi to bring
              surplus-capturing, MEV-protected trades to users
            </SectionTitleDescription>
          </SectionTitleWrapper>
          <SectionImage>
            <LazySVG src={svgLeadingSrc} />
          </SectionImage>
        </ContainerCardSection>
      </ContainerCard>

      <ContainerCard bgColor={'transparent'}>
        <ContainerCardSection>
          <SectionTitleWrapper>
            <SectionTitleIcon $size={132}>
              <LazySVG src={iconCowLensSrc} />
            </SectionTitleIcon>
            <SectionTitleText>How it works</SectionTitleText>
            <SectionTitleDescription maxWidth={900} color={`var(${UI.COLOR_NEUTRAL_50})`}>
              CoW Protocol hosts a continuous competition between solvers to find better prices and protect users from
              MEV
            </SectionTitleDescription>
          </SectionTitleWrapper>

          <TopicList columns={1} columnsTablet={1} maxWidth={1470}>
            <TopicCard columns="repeat(2, 1fr)" columnsTablet="1fr" gap={100} horizontal asProp="div">
              <TopicCardInner contentAlign="left">
                <TopicTitle fontSize={51}>Intents</TopicTitle>
                <TopicDescription fontSize={28} color={`var(${UI.COLOR_NEUTRAL_50})`}>
                  CoW Protocol users sign an &quot;intent to trade&quot; message instead of directly executing orders
                  on-chain (like on Uniswap). This lets solvers trade on behalf of the user
                </TopicDescription>
                <Link
                  bgColor={Color.cowfi_purple3}
                  color={Color.cowfi_purple_bright}
                  href="https://docs.cow.fi/cow-protocol/reference/core/intents"
                  external
                  data-click-event={toCowFiGtmEvent({
                    category: CowFiCategory.COWPROTOCOL,
                    action: 'Open Intents Documentation',
                  })}
                  linkType={LinkType.TopicButton}
                >
                  Learn more
                </Link>
              </TopicCardInner>
              <TopicImage
                iconColor="transparent"
                width={590}
                height={590}
                heightMobile={'auto'}
                widthMobile={'100%'}
                orderReverseMobile
                orderReverseTablet
                borderRadius={90}
              >
                <LazySVG src={svgIntentsSrc} />
              </TopicImage>
            </TopicCard>

            <TopicCard columns="1fr auto" columnsTablet="1fr" gap={100} horizontal asProp="div">
              <TopicImage
                iconColor="transparent"
                width={590}
                height={590}
                heightMobile={'auto'}
                widthMobile={'100%'}
                orderReverseMobile
                orderReverseTablet
                borderRadius={90}
              >
                <LazySVG src={svgSolversSrc} />
              </TopicImage>
              <TopicCardInner contentAlign="left">
                <TopicTitle fontSize={51}>Solvers</TopicTitle>
                <TopicDescription fontSize={28} color={`var(${UI.COLOR_NEUTRAL_50})`}>
                  Professional third parties known as solvers find the most optimal trade path from a combination of
                  public and private liquidity sources - finding better prices than most users could find on their own
                </TopicDescription>
                <Link
                  bgColor={Color.cowfi_purple3}
                  color={Color.cowfi_purple_bright}
                  href="https://docs.cow.fi/category/solver"
                  external
                  data-click-event={toCowFiGtmEvent({
                    category: CowFiCategory.COWPROTOCOL,
                    action: 'Open Solvers Documentation',
                  })}
                  linkType={LinkType.TopicButton}
                >
                  Learn more
                </Link>
              </TopicCardInner>
            </TopicCard>

            <TopicCard columns="1fr auto" columnsTablet="1fr" gap={100} horizontal asProp="div">
              <TopicCardInner contentAlign="left">
                <TopicTitle fontSize={51}>Batch Auctions</TopicTitle>
                <TopicDescription fontSize={28} color={`var(${UI.COLOR_NEUTRAL_50})`}>
                  Solvers compete for the right to settle trades in batches, which give users additional MEV protection
                  and allow for Coincidence of Wants.
                  <br />
                  <br />
                  The solver that wins the batch auction is the solver that finds the most surplus - so they win when
                  you win
                </TopicDescription>
                <Link
                  bgColor={Color.cowfi_purple3}
                  color={Color.cowfi_purple_bright}
                  href="/learn/understanding-batch-auctions"
                  data-click-event={toCowFiGtmEvent({
                    category: CowFiCategory.COWPROTOCOL,
                    action: 'Open Batch Auctions Documentation',
                  })}
                  linkType={LinkType.TopicButton}
                >
                  Learn more
                </Link>
              </TopicCardInner>
              <TopicImage
                iconColor="transparent"
                width={590}
                height={590}
                heightMobile={'auto'}
                widthMobile={'100%'}
                orderReverseMobile
                borderRadius={90}
              >
                <LazySVG src={svgBatchauctionsSrc} />
              </TopicImage>
            </TopicCard>
          </TopicList>
        </ContainerCardSection>
      </ContainerCard>

      <ContainerCard bgColor={`var(${UI.COLOR_NEUTRAL_0})`} color={`var(${UI.COLOR_NEUTRAL_98})`}>
        <ContainerCardSection>
          <SectionTitleWrapper padding="150px 0 0">
            <ProductLogo variant={ProductVariant.CowProtocol} theme="dark" logoIconOnly height={60} />
            <SectionTitleText>Going where others can&apos;t</SectionTitleText>
            <SectionTitleDescription color={`var(${UI.COLOR_NEUTRAL_60})`}>
              Thanks to its unique architecture, CoW Protocol can do things other DEXs can&apos;t
            </SectionTitleDescription>
          </SectionTitleWrapper>

          <SectionTitleWrapper padding="50px 0">
            <SectionTitleText>Advanced order types</SectionTitleText>
          </SectionTitleWrapper>
          <TopicList columns={3} columnsTablet={2}>
            {ADVANCED_ORDER_TYPES.map((topic) => (
              <TopicCard
                key={topic.title}
                contentAlign="left"
                bgColor={topic.bgColor}
                textColor={topic.textColor}
                padding="32px"
                asProp="div"
              >
                <TopicCardInner contentAlign="left">
                  <TopicTitle color={topic.titleColor}>{topic.title}</TopicTitle>
                  <TopicDescription fontSize={21} color={topic.textColor}>
                    {topic.description}
                  </TopicDescription>
                </TopicCardInner>
                <TopicImage
                  iconColor="transparent"
                  bgColor="transparent"
                  margin="auto 0 0 auto"
                  height="auto"
                  width="100%"
                >
                  <LazySVG src={topic.imageSrc} />
                </TopicImage>
              </TopicCard>
            ))}
          </TopicList>

          <SectionTitleWrapper padding="150px 0 50px">
            <SectionTitleText textAlign="center">Unique trading logic</SectionTitleText>
          </SectionTitleWrapper>
          <TopicList columns={3} columnsTablet={2}>
            {UNIQUE_TRADING_LOGIC.map((topic) => (
              <TopicCard
                key={topic.title}
                contentAlign="left"
                bgColor={topic.bgColor}
                textColor={topic.textColor}
                padding="32px"
                asProp="div"
              >
                <TopicCardInner contentAlign="left">
                  <TopicTitle color={topic.titleColor}>{topic.title}</TopicTitle>
                  <TopicDescription fontSize={21} color={topic.textColor}>
                    {topic.description}
                  </TopicDescription>
                </TopicCardInner>
                <TopicImage
                  iconColor="transparent"
                  bgColor="transparent"
                  margin="auto 0 0 auto"
                  height="auto"
                  width="100%"
                >
                  <LazySVG src={topic.imageSrc} />
                </TopicImage>
              </TopicCard>
            ))}
          </TopicList>
        </ContainerCardSection>
      </ContainerCard>

      <ContainerCard bgColor={'transparent'}>
        <ContainerCardSection>
          <SectionTitleWrapper maxWidth={878} color={`var(${UI.COLOR_NEUTRAL_10})`}>
            <SectionTitleIcon $size={128}>
              <LazySVG src={iconBulbCowSrc} />
            </SectionTitleIcon>
            <SectionTitleText textAlign="center">Powering innovation across DeFi</SectionTitleText>
          </SectionTitleWrapper>

          <TopicList columns={3} columnsTablet={2}>
            <TopicCard
              contentAlign={'left'}
              bgColor={Color.cowfi_purple3}
              textColor={Color.cowfi_purple_bright}
              padding={'32px'}
              asProp="div"
            >
              <TopicImage iconColor={Color.cowfi_purple1} bgColor="transparent" height={96} width={'auto'}>
                <LazySVG src={iconCurveSrc} />
              </TopicImage>
              <TopicCardInner contentAlign="left">
                <TopicTitle color={`var(${UI.COLOR_NEUTRAL_100})`}>Automating advanced treasury tasks</TopicTitle>
                <TopicDescription fontSize={21} color={Color.cowfi_purple_bright}>
                  Curve uses programmatic orders from CoW Protocol to streamline their fee burning processes. With the
                  integration in place, Curve can take fees in any token and convert them automatically to CRV, while
                  generating surplus and protecting themselves from MEV
                </TopicDescription>
              </TopicCardInner>
            </TopicCard>

            <TopicCard
              contentAlign={'left'}
              bgColor={Color.cowfi_purple3}
              textColor={Color.cowfi_purple_bright}
              padding={'32px'}
              asProp="div"
            >
              <TopicImage iconColor={Color.cowfi_purple1} bgColor="transparent" height={96} width={'auto'}>
                <LazySVG src={iconLidoSrc} />
              </TopicImage>
              <TopicCardInner contentAlign="left">
                <TopicTitle color={`var(${UI.COLOR_NEUTRAL_100})`}>
                  Adding security to sensitive transactions
                </TopicTitle>
                <TopicDescription fontSize={21} color={Color.cowfi_purple_bright}>
                  Lido leverages programmatic orders as the backbone of &quot;stonks&quot; - a set of smart contracts
                  that they use to manage treasury ops smoothly and securely without taking custody of funds. Stonks
                  allows Lido DAO to &quot;set and forget&quot; complex trade intents without compromising the prices
                  they receive on future swaps - minimizing time spent and human error
                </TopicDescription>
              </TopicCardInner>
            </TopicCard>

            <TopicCard
              contentAlign={'left'}
              bgColor={Color.cowfi_purple3}
              textColor={Color.cowfi_purple_bright}
              padding={'32px'}
              asProp="div"
            >
              <TopicImage iconColor={Color.cowfi_purple1} bgColor="transparent" height={96} width={'auto'}>
                <LazySVG src={iconSafeSrc} />
              </TopicImage>
              <TopicCardInner contentAlign="left">
                <TopicTitle color={`var(${UI.COLOR_NEUTRAL_100})`}>Powering native swaps</TopicTitle>
                <TopicDescription fontSize={21} color={Color.cowfi_purple_bright}>
                  Safe chose CoW Protocol to power native swaps on the Safe app. The team chose to build on top of the
                  CoW widget (the simplest way to integrate CoW Protocol) and is now earning revenue by offering
                  MEV-protected swaps to its users
                </TopicDescription>
              </TopicCardInner>
            </TopicCard>
          </TopicList>
        </ContainerCardSection>
      </ContainerCard>

      <ContainerCard bgColor={`var(${UI.COLOR_NEUTRAL_10})`} color={`var(${UI.COLOR_NEUTRAL_98})`}>
        <ContainerCardSection>
          <SectionTitleWrapper padding="150px 0 0">
            <SectionTitleIcon $multiple $size={60}>
              <LazySVG src={iconOwlSrc} />
              <ProductLogo variant={ProductVariant.CowProtocol} theme="dark" logoIconOnly height={60} />
              <LazySVG src={iconGhostSrc} />
            </SectionTitleIcon>
            <SectionTitleText>Trusted by the best</SectionTitleText>
          </SectionTitleWrapper>

          <TopicList columns={3}>
            {TOP_LOGOS.map((logo) => (
              <TopicCard
                key={logo.url}
                contentAlign={'center'}
                bgColor={`var(${UI.COLOR_NEUTRAL_100})`}
                padding={'42px'}
                href={logo.url}
                target="_blank"
                rel="noopener noreferrer nofollow"
                data-click-event={toCowFiGtmEvent({
                  category: CowFiCategory.COWPROTOCOL,
                  action: `Visit Partner ${logo.alt}`,
                })}
              >
                <TopicImage
                  iconColor={`var(${UI.COLOR_NEUTRAL_20})`}
                  bgColor={'transparent'}
                  width={'100%'}
                  height={54}
                  margin={'auto'}
                >
                  <LazySVG src={logo.src} title={logo.alt} />
                </TopicImage>
              </TopicCard>
            ))}

            {CASE_STUDIES.map((study) => (
              <TopicCard
                key={study.link}
                bgColor={`var(${UI.COLOR_NEUTRAL_100})`}
                padding={'52px'}
                gap={16}
                asProp="div"
              >
                <TopicImage iconColor={Color.cowfi_purple3} bgColor="transparent" height={96} width={'auto'}>
                  <LazySVG src={study.logo} />
                </TopicImage>
                <TopicCardInner>
                  <TopicTitle fontSize={38}>{study.title}</TopicTitle>
                  <TopicDescription fontSize={21}>{study.description}</TopicDescription>
                  <Link
                    bgColor={Color.cowfi_purple3}
                    color={Color.cowfi_purple_bright}
                    fontSize={27}
                    href={study.link}
                    external
                    linkType={LinkType.TopicButton}
                    utmContent={`cow-protocol-case-study-${study.title}`}
                    data-click-event={toCowFiGtmEvent({
                      category: CowFiCategory.COWPROTOCOL,
                      action: `Read Case Study ${study.title}`,
                    })}
                  >
                    Read more
                  </Link>
                </TopicCardInner>
              </TopicCard>
            ))}
          </TopicList>

          <TopicList columns={4} columnsTablet={2}>
            {ALL_LOGOS.map((logo) => (
              <TopicCard
                key={logo.url}
                contentAlign={'center'}
                bgColor={`var(${UI.COLOR_NEUTRAL_100})`}
                padding={'42px'}
                href={logo.url}
                target="_blank"
                rel="noopener noreferrer nofollow"
                data-click-event={toCowFiGtmEvent({
                  category: CowFiCategory.COWPROTOCOL,
                  action: `Visit Partner ${logo.alt}`,
                })}
              >
                <TopicImage
                  iconColor={`var(${UI.COLOR_NEUTRAL_20})`}
                  bgColor={'transparent'}
                  width={90}
                  height={90}
                  margin={'auto'}
                >
                  <LazySVG src={logo.src} title={logo.alt} />
                </TopicImage>
              </TopicCard>
            ))}
          </TopicList>
        </ContainerCardSection>
      </ContainerCard>

      <ContainerCard bgColor={'transparent'}>
        <ContainerCardSection>
          <SectionTitleWrapper color={`var(${UI.COLOR_NEUTRAL_10})`} maxWidth={1100}>
            <SectionTitleIcon $size={78}>
              <LazySVG src={iconBuildWithCowSrc} />
            </SectionTitleIcon>
            <SectionTitleText>Build with CoW Protocol</SectionTitleText>
          </SectionTitleWrapper>

          <TopicList columns={3} columnsTablet={2}>
            {COW_PROTOCOL_SECTIONS.map((topic) => (
              <TopicCard
                key={topic.title}
                contentAlign="left"
                bgColor={topic.bgColor}
                textColor={topic.textColor}
                padding="32px"
                asProp="div"
              >
                <TopicCardInner contentAlign="left">
                  <TopicTitle color={topic.titleColor}>{topic.title}</TopicTitle>
                  <TopicDescription fontSize={21} color={topic.textColor} minHeight={220}>
                    {topic.description}
                  </TopicDescription>
                  <Link
                    bgColor={topic.textColor}
                    color={topic.bgColor}
                    fontSize={27}
                    fontSizeMobile={24}
                    href={topic.linkHref}
                    linkType={LinkType.TopicButton}
                    data-click-event={toCowFiGtmEvent({
                      category: CowFiCategory.COWPROTOCOL,
                      action: topic.linkEvent,
                    })}
                    utmContent={topic.linkUtmContent}
                    external={topic.linkHref.startsWith('http')}
                  >
                    {topic.linkText}
                  </Link>
                </TopicCardInner>
                <TopicImage
                  iconColor={Color.cowfi_purple3}
                  bgColor="transparent"
                  margin="0 0 0 auto"
                  height={187}
                  width="auto"
                >
                  <LazySVG src={topic.imageSrc} />
                </TopicImage>
              </TopicCard>
            ))}
          </TopicList>
        </ContainerCardSection>
      </ContainerCard>

      <ContainerCard bgColor={'transparent'}>
        <ContainerCardSection>
          <SectionTitleWrapper maxWidth={1000}>
            <SectionTitleIcon $size={100}>
              <LazySVG src={iconSecureSrc} />
            </SectionTitleIcon>
            <SectionTitleText textAlign="center">Want to build a solver?</SectionTitleText>
            <SectionTitleDescription fontSize={28} color={`var(${UI.COLOR_NEUTRAL_30})`}>
              Solvers are the backbone of CoW Protocol. In a nutshell, solvers are optimization algorithms that compete
              to find CoW Protocol users the best possible settlements for their trade intents.
              <br />
              <br />
              Advanced solver teams can earn hundreds of thousands of dollars per year by winning batch auctions
              frequently.
              <br />
              <br />
              Learn more about building a solver by reading the CoW Protocol docs
            </SectionTitleDescription>

            <Link
              bgColor={Color.cowfi_purple3}
              color={Color.cowfi_purple_bright}
              href="https://docs.cow.fi/category/solver"
              external
              linkType={LinkType.SectionTitleButton}
              utmContent="cow-protocol-solvers"
              margin="28px 0 0"
              data-click-event={toCowFiGtmEvent({
                category: CowFiCategory.COWPROTOCOL,
                action: 'Open Solver Development Documentation',
              })}
            >
              Read the docs
            </Link>
          </SectionTitleWrapper>
        </ContainerCardSection>
      </ContainerCard>

      <ContainerCard bgColor={`var(${UI.COLOR_NEUTRAL_90})`} color={`var(${UI.COLOR_NEUTRAL_10})`} touchFooter>
        <ContainerCardSection>
          <SectionTitleWrapper>
            <SectionTitleIcon $size={62}>
              <LazySVG src={iconFaqSrc} />
            </SectionTitleIcon>
            <SectionTitleText>FAQs</SectionTitleText>
          </SectionTitleWrapper>

          <FAQ faqs={faqData} />
        </ContainerCardSection>
      </ContainerCard>
    </PageWrapper>
  )
}
