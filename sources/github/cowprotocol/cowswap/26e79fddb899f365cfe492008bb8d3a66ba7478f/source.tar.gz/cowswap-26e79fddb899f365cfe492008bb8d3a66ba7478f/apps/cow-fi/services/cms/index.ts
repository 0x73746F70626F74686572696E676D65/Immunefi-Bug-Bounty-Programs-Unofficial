import { CmsClient, components } from '@cowprotocol/cms'

import { PaginationParam } from 'types'

import { isValidCmsSlug, normalizeSearchArticlesInput } from 'util/cmsValidation'
import { toQueryParams } from 'util/queryParams'

import { CMS_BASE_URL, DEFAULT_PAGE_SIZE, clientAddons } from './config'
import { collectAllPages, getPopulateConfig, querySerializer, toResourceSlugParams } from './helpers'

export type Article = Schemas['ArticleListResponseDataItem']
export type ArticleListResponse = {
  data: Article[]
  meta: {
    pagination: {
      page: number
      pageSize: number
      pageCount: number
      total: number
    }
  }
}

export type CampaignSummary = {
  campaign: string
  count: number
}
export type Category = Schemas['CategoryListResponseDataItem']

export type Resource = Schemas['ResourceListResponseDataItem']

export type ResourceListResponse = {
  data: Resource[]
  meta: {
    pagination: {
      page: number
      pageSize: number
      pageCount: number
      total: number
    }
  }
}

export type ResourceSlugParam = {
  campaign: string
  slug: string
}

export type SharedRichTextComponent = Schemas['SharedRichTextComponent']
type Schemas = components['schemas']

const SKIP_CMS_FETCH_DURING_BUILD =
  process.env.NEXT_PHASE === 'phase-production-build' || process.env.SKIP_COW_FI_CMS_FETCH === 'true'

function handleCmsBuildFailure<T>(operation: string, error: unknown, fallback: T): T {
  if (SKIP_CMS_FETCH_DURING_BUILD) {
    console.error(`[cow-fi] ${operation} failed during build. Skipping CMS fetch.`, error)
    return fallback
  }

  throw error
}

/**
 * Open API Fetch client. See docs for usage https://openapi-ts.pages.dev/openapi-fetch/
 * Instantiated here (not via @cowprotocol/core) so content pages don't pull trading/wallet code.
 */
export const client = CmsClient({
  url: CMS_BASE_URL,
})

export type Page = Schemas['PageListResponseDataItem']

/**
 * Returns all article slugs.
 *
 * @returns Slugs
 */
export async function getAllArticleSlugs(): Promise<string[]> {
  try {
    const { data, error, response } = await client.GET('/articles', {
      params: {
        query: {
          fields: ['slug'],
          'pagination[pageSize]': DEFAULT_PAGE_SIZE,
        },
      },
      querySerializer,
      ...clientAddons,
    })

    if (error) {
      console.error(`Error ${response.status} getting article slugs: ${response.url}`, error)
      throw error
    }

    return data.data
      .filter((article: Article) => article.attributes)
      .map((article: Article) => article.attributes!.slug)
  } catch (error) {
    return handleCmsBuildFailure('getAllArticleSlugs', error, [])
  }
}

/**
 * Returns all category slugs.
 *
 * @returns Slugs
 */
export async function getAllCategorySlugs(): Promise<string[]> {
  const categories = await getCategories()

  return categories.map((category) => category.attributes!.slug!)
}

/**
 * Returns every published resource matching the given filters, across CMS pages.
 */
export async function getAllResources({
  filters = {},
  pageSize = DEFAULT_PAGE_SIZE,
}: { filters?: Record<string, unknown>; pageSize?: number } = {}): Promise<Resource[]> {
  try {
    return await collectAllPages(async (page) => {
      const result = await getResources({ page, pageSize, filters })

      return {
        items: result.data,
        page: result.meta.pagination.page,
        pageCount: result.meta.pagination.pageCount,
      }
    })
  } catch (error) {
    return handleCmsBuildFailure('getAllResources', error, [])
  }
}

/**
 * Returns all resource slugs grouped by campaign.
 */
export async function getAllResourceSlugs(): Promise<ResourceSlugParam[]> {
  try {
    const resources = await collectAllPages(async (page) => {
      const { data, error, response } = await client.GET('/resources', {
        params: {
          query: {
            fields: ['slug', 'campaign'],
            'pagination[page]': page,
            'pagination[pageSize]': DEFAULT_PAGE_SIZE,
          },
        },
        querySerializer,
        ...clientAddons,
      })

      if (error) {
        console.error(`Error ${response.status} getting resource slugs: ${response.url}`, error)
        throw error
      }

      return {
        items: data.data,
        page: data.meta.pagination.page,
        pageCount: data.meta.pagination.pageCount,
      }
    })

    return toResourceSlugParams(resources)
  } catch (error) {
    return handleCmsBuildFailure('getAllResourceSlugs', error, [])
  }
}

/**
 * Get article by slug.
 *
 * @param slug Slug of the article
 *
 * @throws Error if slug is not found
 * @throws Error if multiple articles are found with the same slug
 *
 * @returns Article with the given slug
 */
export async function getArticleBySlug(slug: string): Promise<Article | null> {
  if (!slug) throw new Error('Article slug is required') // Fail fast - no silent failures per CMS architecture

  try {
    const result = await getBySlugAux(slug, '/articles')
    return result
  } catch (error) {
    console.error(`Error getting article by slug ${slug}:`, error)
    throw error
  }
}

/**
 * Get articles sorted by descending published date.
 *
 * @returns Articles for the given page
 */
export async function getArticles({
  page = 0,
  pageSize = DEFAULT_PAGE_SIZE,
  filters = {},
}: PaginationParam & { filters?: Record<string, unknown> } = {}): Promise<ArticleListResponse> {
  try {
    const { data, error, response } = await client.GET('/articles', {
      params: {
        query: {
          'populate[0]': 'cover',
          'populate[1]': 'blocks',
          'populate[2]': 'seo',
          'populate[3]': 'authorsBio',
          'pagination[page]': page,
          'pagination[pageSize]': pageSize,
          sort: 'publishDate:desc,publishedAt:desc',
          filters,
        },
      },
      querySerializer,
      ...clientAddons,
    })

    if (error) {
      console.error(`Error ${response.status} getting articles: ${response.url}. Page ${page}`, error)
      throw error
    }

    return { data: data.data, meta: data.meta }
  } catch (error) {
    return handleCmsBuildFailure('getArticles', error, {
      data: [],
      meta: {
        pagination: {
          page,
          pageSize,
          pageCount: 0,
          total: 0,
        },
      },
    })
  }
}

/**
 * Returns campaign summaries derived from published resources.
 */
export async function getCampaignSummaries(): Promise<CampaignSummary[]> {
  const slugs = await getAllResourceSlugs()
  const counts = new Map<string, number>()

  for (const { campaign } of slugs) {
    counts.set(campaign, (counts.get(campaign) ?? 0) + 1)
  }

  return Array.from(counts.entries())
    .map(([campaign, count]) => ({ campaign, count }))
    .sort((a, b) => a.campaign.localeCompare(b.campaign))
}

/**
 * Get categories with images.
 *
 * @returns Categories with their associated images
 */
export async function getCategories(): Promise<Category[]> {
  try {
    const { data, error, response } = await client.GET('/categories?populate=*', {
      params: {
        pagination: {
          page: 0,
          pageSize: DEFAULT_PAGE_SIZE,
        },
        sort: 'name:asc',
      },
      ...clientAddons,
    })

    if (error) {
      console.error(`Error ${response.status} getting categories: ${response.url}`, error)
      throw error
    }

    return data.data
  } catch (err) {
    console.error('An unexpected error occurred:', err)
    return handleCmsBuildFailure('getCategories', err, [])
  }
}

/**
 * Get category by slug.
 *
 * @param slug Slug of the category
 *
 * @throws Error if slug is not found
 * @throws Error if multiple categories are found with the same slug
 *
 * @returns Category with the given slug
 */
export async function getCategoryBySlug(slug: string): Promise<Category | null> {
  return getBySlugAux(slug, '/categories')
}

/**
 * Get page by slug.
 *
 * @param slug Slug of the page
 *
 * @throws Error if slug is not found
 * @throws Error if multiple pages are found with the same slug
 *
 * @returns Page with the given slug
 */
export async function getPageBySlug(slug: string): Promise<Page | null> {
  return getBySlugAux(slug, '/pages')
}

/**
 * Get resource by slug.
 */
export async function getResourceBySlug(slug: string): Promise<Resource | null> {
  if (!slug) throw new Error('Resource slug is required')

  try {
    return await getBySlugAux(slug, '/resources')
  } catch (error) {
    console.error(`Error getting resource by slug ${slug}:`, error)
    throw error
  }
}

/**
 * Get resources sorted by descending published date.
 */
export async function getResources({
  page = 0,
  pageSize = DEFAULT_PAGE_SIZE,
  filters = {},
}: PaginationParam & { filters?: Record<string, unknown> } = {}): Promise<ResourceListResponse> {
  try {
    const { data, error, response } = await client.GET('/resources', {
      params: {
        query: {
          'populate[0]': 'cover',
          'populate[1]': 'blocks',
          'populate[2]': 'seo',
          'pagination[page]': page,
          'pagination[pageSize]': pageSize,
          sort: 'publishDate:desc,publishedAt:desc',
          filters,
        },
      },
      querySerializer,
      ...clientAddons,
    })

    if (error) {
      console.error(`Error ${response.status} getting resources: ${response.url}. Page ${page}`, error)
      throw error
    }

    return { data: data.data, meta: data.meta }
  } catch (error) {
    return handleCmsBuildFailure('getResources', error, {
      data: [],
      meta: {
        pagination: {
          page,
          pageSize,
          pageCount: 0,
          total: 0,
        },
      },
    })
  }
}

/**
 * Search for articles containing a search term across multiple fields.
 * Uses Strapi's filtering capabilities to perform the search server-side.
 *
 * @param searchTerm The term to search for
 * @param page The page number (0-indexed)
 * @param pageSize The number of articles per page
 * @returns Articles matching the search term with pagination info
 */
export async function searchArticles({
  searchTerm,
  page = 0,
  pageSize = DEFAULT_PAGE_SIZE,
}: {
  searchTerm: string
  page?: number
  pageSize?: number
}): Promise<ArticleListResponse> {
  const {
    searchTerm: trimmedSearchTerm,
    page: normalizedPage,
    pageSize: normalizedPageSize,
  } = normalizeSearchArticlesInput({ searchTerm, page, pageSize })

  if (!trimmedSearchTerm) {
    return {
      data: [],
      meta: { pagination: { page: normalizedPage, pageSize: normalizedPageSize, pageCount: 0, total: 0 } },
    }
  }

  try {
    const queryParams = {
      filters: {
        $or: [
          { title: { $startsWithi: trimmedSearchTerm } },
          { title: { $containsi: trimmedSearchTerm } },
          { description: { $containsi: trimmedSearchTerm } },
        ],
      },
      pagination: {
        page: normalizedPage,
        pageSize: normalizedPageSize,
      },
      sort: ['title:asc'],
      populate: ['cover', 'blocks', 'seo', 'authorsBio'],
      publicationState: 'live', // Ensure published content
    }

    const { data, error, response } = await client.GET('/articles', {
      params: {
        query: toQueryParams(queryParams),
      },
      ...clientAddons,
    })

    if (error) {
      console.error(`Search failed (${response.status}):`, error)
      throw new Error(`Search failed: ${error.message}`)
    }

    return { data: data.data, meta: data.meta }
  } catch (error) {
    console.error('Search error:', error)
    throw new Error('Unable to complete search. Please try again.')
  }
}

async function getBySlugAux(slug: string, endpoint: '/articles'): Promise<Article | null>
async function getBySlugAux(slug: string, endpoint: '/categories'): Promise<Category | null>
async function getBySlugAux(slug: string, endpoint: '/pages'): Promise<Page | null>
async function getBySlugAux(slug: string, endpoint: '/resources'): Promise<Resource | null>
async function getBySlugAux(
  slug: string,
  endpoint: '/categories' | '/articles' | '/pages' | '/resources',
): Promise<unknown | null> {
  if (!slug) throw new Error('Slug is required') // Fail fast - no silent failures per CMS architecture
  if (!isValidCmsSlug(slug)) return null

  try {
    const entity = endpoint.slice(1, -1)
    const populate = getPopulateConfig(endpoint)

    const queryParams = {
      filters: { slug: { $eq: slug } },
      pagination: { page: 1, pageSize: 2 },
      populate,
    }

    const { data, error } = await client.GET(endpoint, {
      params: { query: toQueryParams(queryParams) },
      ...clientAddons,
    })

    if (error) {
      console.error(`Error getting slug ${slug} for ${entity}`, error)
      throw error
    }

    const { total } = data.meta.pagination
    if (total === 0) return null
    if (total > 1) throw new Error(`Multiple ${entity} found with slug ${slug}`)

    return data.data[0]
  } catch (error) {
    return handleCmsBuildFailure(`getBySlugAux(${endpoint}, ${slug})`, error, null)
  }
}
