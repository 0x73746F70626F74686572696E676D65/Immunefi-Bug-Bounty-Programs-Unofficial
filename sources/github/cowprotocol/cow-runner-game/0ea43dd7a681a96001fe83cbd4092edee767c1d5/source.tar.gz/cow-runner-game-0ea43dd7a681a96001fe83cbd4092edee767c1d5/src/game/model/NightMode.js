import { getRandomNum, IS_HIDPI } from '.'

/**
* Nightmode shows a moon and stars on the horizon.
*/
export class NightMode {
  constructor (canvas, spritePos, containerWidth) {
    this.spritePos = spritePos;
    this.canvas = canvas;
    this.canvasCtx = canvas.getContext('2d');
    this.xPos = containerWidth - 50;
    this.yPos = 30;
    this.currentPhase = 0;
    this.opacity = 0;
    this.containerWidth = containerWidth;
    this.stars = [];
    this.drawStars = false;
    this.placeStars();
  }

  /**
  * @enum {number}
  */
  static config = {
    FADE_SPEED: 0.035,
    HEIGHT: 40,
    MOON_SPEED: 0.25,
    NUM_STARS: 2,
    STAR_SIZE: 9,
    STAR_SPEED: 0.3,
    STAR_MAX_Y: 70,
    WIDTH: 20
  };
  
  static phases = [140, 120, 100, 60, 40, 20, 0];

  /**
   * Update moving moon, changing phases.
   * @param {boolean} activated Whether night mode is activated.
   * @param {number} delta
   */
  update (activated, delta) {
      // Moon phase.
      if (activated && this.opacity == 0) {
          this.currentPhase++;
  
          if (this.currentPhase >= NightMode.phases.length) {
              this.currentPhase = 0;
          }
      }
  
      // Fade in / out.
      if (activated && (this.opacity < 1 || this.opacity == 0)) {
          this.opacity += NightMode.config.FADE_SPEED;
      } else if (this.opacity > 0) {
          this.opacity -= NightMode.config.FADE_SPEED;
      }
  
      // Set moon positioning.
      if (this.opacity > 0) {
          this.xPos = this.updateXPos(this.xPos, NightMode.config.MOON_SPEED);
  
          // Update stars.
          if (this.drawStars) {
              for (var i = 0; i < NightMode.config.NUM_STARS; i++) {
                  this.stars[i].x = this.updateXPos(this.stars[i].x,
                      NightMode.config.STAR_SPEED);
              }
          }
          this.draw();
      } else {
          this.opacity = 0;
          this.placeStars();
      }
      this.drawStars = true;
  }
  
  updateXPos (currentPos, speed) {
      if (currentPos < -NightMode.config.WIDTH) {
          currentPos = this.containerWidth;
      } else {
          currentPos -= speed;
      }
      return currentPos;
  }
  
  draw () {
      var moonSourceWidth = this.currentPhase == 3 ? NightMode.config.WIDTH * 2 :
          NightMode.config.WIDTH;
      var moonSourceHeight = NightMode.config.HEIGHT;
      var moonSourceX = this.spritePos.x + NightMode.phases[this.currentPhase];
      var moonOutputWidth = moonSourceWidth;
      var starSize = NightMode.config.STAR_SIZE;
      var starSourceX = Runner.spriteDefinition.LDPI.STAR.x;
  
      if (IS_HIDPI) {
          moonSourceWidth *= 2;
          moonSourceHeight *= 2;
          moonSourceX = this.spritePos.x +
              (NightMode.phases[this.currentPhase] * 2);
          starSize *= 2;
          starSourceX = Runner.spriteDefinition.HDPI.STAR.x;
      }
  
      this.canvasCtx.save();
      this.canvasCtx.globalAlpha = this.opacity;
  
      // Stars.
      if (this.drawStars) {
          for (var i = 0; i < NightMode.config.NUM_STARS; i++) {
              this.canvasCtx.drawImage(Runner.imageSprite,
                  starSourceX, this.stars[i].sourceY, starSize, starSize,
                  Math.round(this.stars[i].x), this.stars[i].y,
                  NightMode.config.STAR_SIZE, NightMode.config.STAR_SIZE);
          }
      }
  
      // Moon.
      this.canvasCtx.drawImage(Runner.imageSprite, moonSourceX,
          this.spritePos.y, moonSourceWidth, moonSourceHeight,
          Math.round(this.xPos), this.yPos,
          moonOutputWidth, NightMode.config.HEIGHT);
  
      this.canvasCtx.globalAlpha = 1;
      this.canvasCtx.restore();
  }
  
  // Do star placement.
  placeStars () {
      var segmentSize = Math.round(this.containerWidth /
          NightMode.config.NUM_STARS);
  
      for (var i = 0; i < NightMode.config.NUM_STARS; i++) {
          this.stars[i] = {};
          this.stars[i].x = getRandomNum(segmentSize * i, segmentSize * (i + 1));
          this.stars[i].y = getRandomNum(0, NightMode.config.STAR_MAX_Y);
  
          if (IS_HIDPI) {
              this.stars[i].sourceY = Runner.spriteDefinition.HDPI.STAR.y +
                  NightMode.config.STAR_SIZE * 2 * i;
          } else {
              this.stars[i].sourceY = Runner.spriteDefinition.LDPI.STAR.y +
                  NightMode.config.STAR_SIZE * i;
          }
      }
  }
  
  reset () {
      this.currentPhase = 0;
      this.opacity = 0;
      this.update(false);
  }
}