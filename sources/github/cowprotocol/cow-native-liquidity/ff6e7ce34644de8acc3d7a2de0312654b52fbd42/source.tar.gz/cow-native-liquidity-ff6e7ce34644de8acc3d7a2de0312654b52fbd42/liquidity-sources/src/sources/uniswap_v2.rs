//! Uniswap V2 baseline liquidity source implementation.

pub mod macros;
pub mod pair_provider;
pub mod pool_cache;
pub mod pool_fetching;

use macros::impl_uniswap_like_liquidity;

impl_uniswap_like_liquidity! {
    factory: contracts::UniswapV2Factory,
    init_code_digest: "96e8ac4277198ff8b6f785478aa9a39f403cb768dd02cbee326c3e7da348845f",
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::{test, token_pair::TokenPair};
    use ethcontract_mock::Mock;

    #[tokio::test]
    async fn test_create2_mainnet() {
        // https://info.uniswap.org/pair/0x3e8468f66d30fc99f745481d4b383f89861702c6
        let (mainnet_pair_provider, _) = get_liquidity_source(&Mock::new(1).web3()).await.unwrap();
        let mainnet_pair = TokenPair::new(test::tokens::GNO, test::tokens::WETH).unwrap();
        assert_eq!(
            mainnet_pair_provider.pair_address(&mainnet_pair),
            addr!("3e8468f66d30fc99f745481d4b383f89861702c6")
        );

        // Rinkeby
        let (rinkeby_pair_provider, _) = get_liquidity_source(&Mock::new(4).web3()).await.unwrap();
        let rinkeby_pair = TokenPair::new(
            addr!("a7D1C04fAF998F9161fC9F800a99A809b84cfc9D"),
            addr!("c778417e063141139fce010982780140aa0cd5ab"),
        )
        .unwrap();
        assert_eq!(
            rinkeby_pair_provider.pair_address(&rinkeby_pair),
            addr!("9B79462e2A47487856D5521963449c573e273E79")
        );
    }
}
