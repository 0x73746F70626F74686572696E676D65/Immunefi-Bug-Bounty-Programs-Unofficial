import { useState } from 'react'
import { useMutation } from '@tanstack/react-query'
import { importErc20 } from '../api/erc20'
import type { Network, Token } from '../types'

interface Props {
  network: Network
  onImported: (token: Token) => void
  onClose: () => void
}

/** Modal that reads a pasted ERC-20's symbol/decimals on-chain (via viem). */
export function ImportTokenDialog({ network, onImported, onClose }: Props) {
  const [address, setAddress] = useState('')
  const isValid = /^0x[0-9a-fA-F]{40}$/.test(address.trim())

  const importMut = useMutation({
    mutationFn: (addr: string) => importErc20(network, addr),
    onSuccess: (token) => {
      // brief pause so the "Found …" success line is visible
      setTimeout(() => onImported(token), 350)
    },
  })

  const submit = () => {
    if (isValid && !importMut.isPending) importMut.mutate(address.trim())
  }

  const status = importMut.isPending
    ? { text: 'Reading symbol() and decimals()…', cls: '' }
    : importMut.isSuccess
      ? { text: `Found ${importMut.data.symbol} (${importMut.data.decimals} decimals).`, cls: 'ok' }
      : importMut.isError
        ? { text: `Could not import: ${(importMut.error as Error).message}`, cls: 'err' }
        : address && !isValid
          ? { text: 'That is not a valid 0x address.', cls: 'err' }
          : { text: '', cls: '' }

  return (
    <div className="overlay" onClick={(e) => e.target === e.currentTarget && onClose()}>
      <div className="dialog" role="dialog" aria-modal="true" aria-label="Import token">
        <h3>Import token</h3>
        <p>Paste any ERC-20 address. Symbol and decimals are read on-chain, USD price from the BFF.</p>
        <input
          autoFocus
          spellCheck={false}
          autoComplete="off"
          placeholder="0x…"
          value={address}
          onChange={(e) => setAddress(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && submit()}
        />
        <div className={`dialog-status ${status.cls}`}>{status.text}</div>
        <div className="dialog-actions">
          <button className="btn-ghost" onClick={onClose}>
            Cancel
          </button>
          <button className="btn-primary" disabled={!isValid || importMut.isPending} onClick={submit}>
            Import token
          </button>
        </div>
      </div>
    </div>
  )
}
