# CoW Swap · Streaming Quotes

A production-shaped React app for the CoW Protocol streaming-quote endpoint
([`POST /api/v1/quote/stream`](https://api.cow.fi/docs/#/default/quoteStream)).
It opens a Server-Sent Events stream and renders each solver's quote as it
arrives, ranking them live and feeding the best one back into the swap form.

This is the "serious integration" rewrite of the single-file prototype in
[`../cow-quote-stream.html`](../cow-quote-stream.html), which remains as a
reference. Every hand-rolled piece of the prototype is replaced by a mature
library here.

## Compare view (default)

The header has a **Compare / Stream only** toggle. In *Compare*, the same swap
request is fired at **both** endpoints at once and raced side by side:

- **Classic** (`POST /api/v1/quote`) blocks until the whole solver competition
  finishes, then reveals a single price.
- **Streaming** (`POST /api/v1/quote/stream`) paints the first solver's price in
  a few hundred ms, logs each quote as it arrives, and upgrades the headline
  price only when a better one lands.

A summary strip reports the time-to-first-price gap (e.g. *"streaming showed a
price 23× sooner"*). Both sides converge on the **same** winning quote — the
point being that streaming buys latency without costing quote quality. This is
the partner-facing "why switch" demo; see
[`src/components/CompareView.tsx`](src/components/CompareView.tsx),
[`src/hooks/useClassicQuote.ts`](src/hooks/useClassicQuote.ts), and
[`src/lib/streamStats.ts`](src/lib/streamStats.ts).

## Stack

| Concern | Library |
| --- | --- |
| SSE over POST | [`@microsoft/fetch-event-source`](https://github.com/Azure/fetch-event-source) |
| Payload validation | [`zod`](https://zod.dev) (schemas mirror the orderbook OpenAPI spec) |
| Token/decimal math + on-chain reads | [`viem`](https://viem.sh) |
| Server-state caching (USD prices, token import) | [`@tanstack/react-query`](https://tanstack.com/query) |
| Build/dev | Vite + TypeScript (strict) |

## Why each choice

- **`@microsoft/fetch-event-source`** — the browser `EventSource` is GET-only,
  but this endpoint is a POST with a JSON body. This library does POST SSE,
  frame parsing, and reconnect control. We opt *out* of auto-reconnect because
  the stream is one-shot (see [`src/api/quoteStream.ts`](src/api/quoteStream.ts)).
- **zod** runs at the network boundary. Every SSE frame is validated before it
  reaches the UI, so a malformed payload is a caught error instead of a
  `BigInt(undefined)` crash mid-render ([`src/api/schemas.ts`](src/api/schemas.ts)).
- **viem** owns the money math (`parseUnits`/`formatUnits`) and the ERC-20
  metadata reads (`readContract` with `erc20Abi`, plus the `erc20Abi_bytes32`
  fallback for tokens like MKR) — no hand-rolled BigInt or ABI hex decoding
  ([`src/lib/amounts.ts`](src/lib/amounts.ts), [`src/api/erc20.ts`](src/api/erc20.ts)).
- **TanStack Query** replaces the prototype's manual `Map` cache + 30s TTL +
  sequence counter for USD prices: it dedupes, caches per token, and discards
  responses for superseded keys ([`src/hooks/useUsdPrice.ts`](src/hooks/useUsdPrice.ts)).
- **The stream lifecycle is an explicit reducer state machine**
  (`idle → connecting → streaming → done/error`) instead of scattered globals
  and an abort controller ([`src/hooks/useQuoteStream.ts`](src/hooks/useQuoteStream.ts)).
- **Rendering is a keyed list**, so only the genuinely-new quote row mounts and
  animates — the prototype rebuilt `innerHTML` on every event, replaying the
  animation on all rows.

## Layout

```
src/
  config/     chains.ts, tokens.ts          network + token config
  api/        schemas.ts (zod), quoteStream.ts (SSE client),
              prices.ts, erc20.ts (viem)
  lib/        amounts.ts (viem), ranking.ts, useDebounced.ts
  hooks/      useQuoteStream.ts (state machine), useUsdPrice.ts (react-query)
  components/ TokenSelect, StreamPanel, QuoteRow, ImportTokenDialog
  App.tsx     container: form state + wiring
```

## Run

```bash
npm install
npm run dev      # http://localhost:5173
npm run build    # tsc -b && vite build
npm run lint     # oxlint
```

Order placement and signing are intentionally disabled — this is a
quote-streaming demo. It calls the public CoW and BFF APIs directly from the
browser; no key required.
