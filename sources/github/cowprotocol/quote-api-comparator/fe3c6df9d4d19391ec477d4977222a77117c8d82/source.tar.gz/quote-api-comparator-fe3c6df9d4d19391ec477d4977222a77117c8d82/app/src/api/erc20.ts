import { createPublicClient, http, erc20Abi, erc20Abi_bytes32, getAddress, hexToString } from 'viem'
import { RPC_URL } from '../config/chains'
import type { Network, Token } from '../types'

/**
 * Read `symbol()` and `decimals()` for an ERC-20 straight from chain via viem —
 * replacing hand-rolled `eth_call` + ABI hex decoding. Falls back to the
 * bytes32 `symbol()` variant used by older tokens (e.g. MKR).
 */
export async function importErc20(network: Network, rawAddress: string): Promise<Token> {
  const address = getAddress(rawAddress) // checksums + validates
  const client = createPublicClient({ transport: http(RPC_URL[network]) })

  const decimals = await client.readContract({ address, abi: erc20Abi, functionName: 'decimals' })
  if (!(decimals >= 0 && decimals <= 36)) throw new Error('implausible decimals')

  let symbol: string
  try {
    symbol = await client.readContract({ address, abi: erc20Abi, functionName: 'symbol' })
  } catch {
    // Older tokens (e.g. MKR) return a null-padded bytes32; the `size` option
    // makes viem trim the trailing zero bytes before decoding.
    const raw = await client.readContract({ address, abi: erc20Abi_bytes32, functionName: 'symbol' })
    symbol = hexToString(raw, { size: 32 })
  }

  return {
    symbol: symbol.trim() || `${address.slice(0, 6)}…`,
    address,
    decimals: Number(decimals),
    custom: true,
  }
}
