import { API_BASE } from '../config/chains'
import type { Network } from '../types'
import {
  OrderQuoteResponseSchema,
  PriceEstimationErrorSchema,
  type OrderQuoteResponse,
  type QuoteRequestBody,
} from './schemas'

/**
 * The classic blocking quote: `POST /api/v1/quote`. Same request body as the
 * stream, but the server waits for the whole solver competition and returns the
 * single best quote as one JSON `OrderQuoteResponse` — no SSE, no client-side
 * ranking.
 */
export async function fetchClassicQuote(
  network: Network,
  body: QuoteRequestBody,
  signal: AbortSignal,
): Promise<OrderQuoteResponse> {
  const res = await fetch(`${API_BASE}/${network}/api/v1/quote`, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(body),
    signal,
  })

  if (!res.ok) {
    let message = `HTTP ${res.status}`
    const parsed = PriceEstimationErrorSchema.safeParse(await res.json().catch(() => undefined))
    if (parsed.success) message = `${parsed.data.errorType}: ${parsed.data.description}`
    throw new Error(message)
  }

  return OrderQuoteResponseSchema.parse(await res.json())
}
