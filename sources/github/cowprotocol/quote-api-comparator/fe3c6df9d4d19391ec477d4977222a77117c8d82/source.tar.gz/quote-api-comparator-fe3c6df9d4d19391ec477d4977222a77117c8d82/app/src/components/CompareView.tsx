import { fromAtoms } from '../lib/amounts'
import { relevantAmount } from '../lib/ranking'
import { computeStreamStats } from '../lib/streamStats'
import { useStopwatch } from '../hooks/useStopwatch'
import type { QuoteStreamState, StreamedQuote } from '../hooks/useQuoteStream'
import type { ClassicQuoteState } from '../hooks/useClassicQuote'
import type { OrderKind, PriceQuality, Token } from '../types'

interface Props {
  classic: ClassicQuoteState
  stream: QuoteStreamState
  ranked: StreamedQuote[]
  kind: OrderKind
  sellToken?: Token
  buyToken?: Token
  priceQuality: PriceQuality
  /** Stable id for the current request, so the stopwatches reset per request. */
  requestKey: string
  validationError?: string | null
}

/**
 * Side-by-side race: the same request fired at `POST /api/v1/quote` (blocking)
 * and `POST /api/v1/quote/stream` (progressive), so the time-to-first-price gap
 * is visible directly.
 */
export function CompareView({
  classic,
  stream,
  ranked,
  kind,
  sellToken,
  buyToken,
  priceQuality,
  requestKey,
  validationError,
}: Props) {
  const outToken = kind === 'sell' ? buyToken : sellToken
  const stats = computeStreamStats(stream.quotes, kind)

  const classicMs = classic.status === 'success' ? classic.elapsedMs : null
  const streamFirstMs = stats.firstMs

  return (
    <div className="compare-grid">
      <div className="compare-summary">
        {validationError ? (
          <span className="compare-summary-error">{validationError}</span>
        ) : streamFirstMs != null && classicMs != null ? (
          streamFirstMs <= classicMs ? (
            <span>
              ⚡ Streaming showed a price in <b>{streamFirstMs} ms</b> —{' '}
              <b>{(classicMs / streamFirstMs).toFixed(1)}× sooner</b> than classic's <b>{classicMs} ms</b>.
            </span>
          ) : (
            <span>
              Classic returned in <b>{classicMs} ms</b> from the{' '}
              <b className="mono">{priceQuality}</b> pool; streaming's first price was{' '}
              <b>{streamFirstMs} ms</b> — but streaming ran the full verified competition, not just{' '}
              <span className="mono">{priceQuality}</span>.
            </span>
          )
        ) : (
          <span className="compare-summary-idle">
            Enter an amount — both endpoints fire from the same request, and you can watch the gap.
          </span>
        )}
      </div>

      <ClassicPanel
        state={classic}
        outToken={outToken}
        kind={kind}
        priceQuality={priceQuality}
        requestKey={requestKey}
      />
      <StreamPanelRace
        state={stream}
        stats={stats}
        best={ranked[0]}
        outToken={outToken}
        kind={kind}
        priceQuality={priceQuality}
        requestKey={requestKey}
      />
    </div>
  )
}

/* ---------- classic (blocking) ---------- */

function ClassicPanel({
  state,
  outToken,
  kind,
  priceQuality,
  requestKey,
}: {
  state: ClassicQuoteState
  outToken?: Token
  kind: OrderKind
  priceQuality: PriceQuality
  requestKey: string
}) {
  const running = state.status === 'loading'
  const ticking = useStopwatch(requestKey, running)
  const clock = running ? ticking : state.status === 'success' || state.status === 'error' ? state.elapsedMs : 0

  return (
    <div className="race-panel">
      <div className="race-head">
        <div>
          <div className="race-title">Classic</div>
          <div className="race-endpoint mono">POST /api/v1/quote</div>
          <div className="race-param">
            priceQuality: <b>{priceQuality}</b> · honored
          </div>
        </div>
        <div className={`race-clock mono ${running ? 'running' : ''}`}>{clock} ms</div>
      </div>

      {state.status === 'loading' && (
        <div className="race-waiting">
          <div className="skeleton" />
          <div className="race-waiting-note">
            Blocking until the full solver competition finishes — nothing to show yet.
          </div>
        </div>
      )}

      {state.status === 'success' && state.quote && outToken && (
        <div className="race-result">
          <div className="race-firstprice bad">first &amp; only price after {state.elapsedMs} ms</div>
          <div className="race-price streamed" key={requestKey}>
            {fromAtoms(relevantAmount(state.quote, kind), outToken.decimals)}{' '}
            <span className="sym">{outToken.symbol}</span>
          </div>
          <div className="race-tags">
            <span className={`badge ${state.quote.verified ? 'verified' : 'unverified'}`}>
              {state.quote.verified ? '✓ verified' : 'unverified'}
            </span>
            <span className="race-note">server picked the winner · one response</span>
          </div>
          {state.quote.id == null ? (
            <div className="race-warn">⚠ no quote id — display-only, must re-quote to place an order</div>
          ) : (
            <div className="race-note mono">quote id {state.quote.id} · signable</div>
          )}
        </div>
      )}

      {state.status === 'error' && <div className="stream-error">{state.error}</div>}
      {state.status === 'idle' && <div className="race-idle">idle</div>}
    </div>
  )
}

/* ---------- streaming (progressive) ---------- */

function StreamPanelRace({
  state,
  stats,
  best,
  outToken,
  kind,
  priceQuality,
  requestKey,
}: {
  state: QuoteStreamState
  stats: ReturnType<typeof computeStreamStats>
  best?: StreamedQuote
  outToken?: Token
  kind: OrderKind
  priceQuality: PriceQuality
  requestKey: string
}) {
  const running = state.status === 'connecting' || state.status === 'streaming'
  const ticking = useStopwatch(requestKey, running)
  const clock = running ? ticking : state.status === 'done' || state.status === 'error' ? state.elapsedMs : 0
  const count = stats.events.length

  return (
    <div className="race-panel">
      <div className="race-head">
        <div>
          <div className="race-title">Streaming</div>
          <div className="race-endpoint mono">POST /api/v1/quote/stream</div>
          <div className="race-param muted">
            priceQuality: <b>{priceQuality}</b> · ignored (always full + verified)
          </div>
        </div>
        <div className={`race-clock mono ${running ? 'running' : ''}`}>{clock} ms</div>
      </div>

      {state.status === 'connecting' && count === 0 && (
        <div className="race-waiting">
          <div className="skeleton" />
          <div className="race-waiting-note">connecting…</div>
        </div>
      )}

      {best && outToken && (
        <div className="race-result">
          <div className="race-firstprice good">
            first price at {stats.firstMs} ms
            {stats.upgrades > 0 && <span className="race-upgrades"> · best upgraded {stats.upgrades}×</span>}
          </div>
          {/* key on upgrade count so the flash replays only when the best actually improves */}
          <div className="race-price streamed" key={`${requestKey}-${stats.upgrades}`}>
            {fromAtoms(relevantAmount(best, kind), outToken.decimals)}{' '}
            <span className="sym">{outToken.symbol}</span>
          </div>
          <div className="race-tags">
            <span className={`badge ${best.verified ? 'verified' : 'unverified'}`}>
              {best.verified ? '✓ verified' : 'unverified'}
            </span>
            <span className="race-note">
              {running ? `streaming… ${count} quote${count === 1 ? '' : 's'}` : `closed · ${count} quotes`}
            </span>
          </div>
        </div>
      )}

      {count > 0 && outToken && (
        <div className="race-log">
          {stats.events.map((e, i) => (
            <div className={`race-log-row ${e.improvedBest ? 'improved' : ''}`} key={e.quote.id ?? i}>
              <span className="mono race-log-ms">+{e.quote.receivedMs} ms</span>
              <span className="race-log-amount">
                {fromAtoms(e.value, outToken.decimals)} {outToken.symbol}
              </span>
              {e.improvedBest ? (
                <span className="race-log-flag up">▲ new best</span>
              ) : (
                <span className="race-log-flag">·</span>
              )}
            </div>
          ))}
        </div>
      )}

      {state.status === 'error' && <div className="stream-error">{state.error}</div>}
      {state.status === 'idle' && count === 0 && <div className="race-idle">idle</div>}
    </div>
  )
}
