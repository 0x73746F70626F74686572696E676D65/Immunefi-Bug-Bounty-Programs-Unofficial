import { relevantAmount } from './ranking'
import type { StreamedQuote } from '../hooks/useQuoteStream'
import type { OrderKind } from '../types'

export interface StreamEvent {
  quote: StreamedQuote
  value: bigint
  /** True when this quote became the new best on arrival. */
  improvedBest: boolean
}

export interface StreamStats {
  /** Quotes in arrival order, each flagged if it improved the running best. */
  events: StreamEvent[]
  /** ms until the first usable price was shown. */
  firstMs: number | null
  /** How many times the best price improved *after* the first quote. */
  upgrades: number
}

/**
 * Walk the quotes in arrival order (not ranked order) to reconstruct what the
 * user actually saw over time: when the first price landed, and how many times
 * the displayed best price improved afterwards. This is the "changing quote,
 * only if better" story the streaming endpoint tells.
 */
export function computeStreamStats(arrivalOrder: StreamedQuote[], kind: OrderKind): StreamStats {
  let best: bigint | null = null
  let upgrades = 0
  const events: StreamEvent[] = arrivalOrder.map((quote) => {
    const value = relevantAmount(quote, kind)
    const isBetter = best === null || (kind === 'sell' ? value > best : value < best)
    if (isBetter) {
      if (best !== null) upgrades++ // don't count the very first quote as an upgrade
      best = value
    }
    return { quote, value, improvedBest: isBetter }
  })
  return { events, firstMs: arrivalOrder[0]?.receivedMs ?? null, upgrades }
}
