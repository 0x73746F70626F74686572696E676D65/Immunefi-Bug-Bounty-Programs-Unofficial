import type { Network } from '../types'

export const API_BASE = 'https://api.cow.fi'
export const BFF_BASE = 'https://bff.cow.fi'
/** CoW token-image CDN. One URL pattern per chain: `<base>/<chainId>/<address>/logo.png`. */
export const TOKEN_IMAGE_BASE = 'https://files.cow.fi/token-lists/images'

export const NETWORKS: { id: Network; label: string }[] = [
  { id: 'mainnet', label: 'Ethereum' },
  { id: 'xdai', label: 'Gnosis Chain' },
  { id: 'arbitrum_one', label: 'Arbitrum One' },
  { id: 'base', label: 'Base' },
]

export const CHAIN_ID: Record<Network, number> = {
  mainnet: 1,
  xdai: 100,
  arbitrum_one: 42161,
  base: 8453,
}

export const RPC_URL: Record<Network, string> = {
  mainnet: 'https://ethereum-rpc.publicnode.com',
  xdai: 'https://rpc.gnosischain.com',
  arbitrum_one: 'https://arb1.arbitrum.io/rpc',
  base: 'https://mainnet.base.org',
}

/**
 * How long (ms) the server keeps the stream open for solvers to report.
 * Passed as `timeout` in the request body; larger networks get more time.
 */
export const QUOTE_TIMEOUT_MS: Record<Network, number> = {
  mainnet: 5000,
  xdai: 1000,
  arbitrum_one: 2500,
  base: 1000,
}
