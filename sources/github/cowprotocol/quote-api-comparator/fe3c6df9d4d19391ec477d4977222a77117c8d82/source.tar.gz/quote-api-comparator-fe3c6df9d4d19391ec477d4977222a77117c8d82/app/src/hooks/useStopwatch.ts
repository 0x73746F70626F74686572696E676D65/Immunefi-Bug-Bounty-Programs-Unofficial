import { useEffect, useRef, useState } from 'react'

/**
 * A live-ticking elapsed-ms counter, reset whenever `resetKey` changes and only
 * running while `running` is true. Purely cosmetic — it drives the "counting
 * up" feel during an in-flight request; authoritative timings come from the
 * quote hooks.
 */
export function useStopwatch(resetKey: string, running: boolean): number {
  const [ms, setMs] = useState(0)
  const startRef = useRef(0)

  useEffect(() => {
    startRef.current = performance.now()
    setMs(0)
  }, [resetKey])

  useEffect(() => {
    if (!running) return
    const id = setInterval(() => setMs(Math.round(performance.now() - startRef.current)), 80)
    return () => clearInterval(id)
  }, [running, resetKey])

  return ms
}
