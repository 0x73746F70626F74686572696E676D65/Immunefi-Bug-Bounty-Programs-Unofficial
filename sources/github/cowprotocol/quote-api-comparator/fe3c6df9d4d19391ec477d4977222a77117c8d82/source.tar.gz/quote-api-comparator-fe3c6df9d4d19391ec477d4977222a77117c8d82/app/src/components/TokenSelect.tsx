import { useEffect, useRef, useState } from 'react'
import { CHAIN_ID, TOKEN_IMAGE_BASE } from '../config/chains'
import type { Network, Token } from '../types'

interface Props {
  network: Network
  tokens: Token[]
  value?: string
  onSelect: (address: `0x${string}`) => void
  onImport: () => void
}

/** CoW's token-image CDN follows one pattern for every chain, so the URL can be
 *  computed for any token (including user-imported ones) instead of bundling a list. */
function iconUrl(network: Network, address: string) {
  return `${TOKEN_IMAGE_BASE}/${CHAIN_ID[network]}/${address.toLowerCase()}/logo.png`
}

function fallbackHue(symbol: string) {
  let h = 0
  for (const c of symbol) h = (h * 31 + c.charCodeAt(0)) % 360
  return h
}

function TokenIcon({ network, token }: { network: Network; token: Token }) {
  const [failed, setFailed] = useState(false)
  if (failed) {
    return (
      <span
        className="token-icon token-icon-fallback"
        style={{ background: `hsl(${fallbackHue(token.symbol)} 60% 82%)` }}
      >
        {token.symbol.slice(0, 2).toUpperCase()}
      </span>
    )
  }
  return (
    <img
      className="token-icon"
      src={iconUrl(network, token.address)}
      alt=""
      loading="lazy"
      onError={() => setFailed(true)}
    />
  )
}

/**
 * Token picker: a pill button that opens a popover listing the network's tokens
 * with icons, plus an "Import token…" entry that hands off to the import dialog.
 */
export function TokenSelect({ network, tokens, value, onSelect, onImport }: Props) {
  const [open, setOpen] = useState(false)
  const rootRef = useRef<HTMLDivElement>(null)
  const selected = tokens.find((t) => t.address.toLowerCase() === value?.toLowerCase())

  useEffect(() => {
    if (!open) return
    const onDown = (e: PointerEvent) => {
      if (!rootRef.current?.contains(e.target as Node)) setOpen(false)
    }
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setOpen(false)
    }
    document.addEventListener('pointerdown', onDown)
    document.addEventListener('keydown', onKey)
    return () => {
      document.removeEventListener('pointerdown', onDown)
      document.removeEventListener('keydown', onKey)
    }
  }, [open])

  return (
    <div className="token-select" ref={rootRef}>
      <button
        type="button"
        className="token-pill"
        aria-haspopup="listbox"
        aria-expanded={open}
        onClick={() => setOpen((o) => !o)}
      >
        {selected && <TokenIcon key={network + selected.address} network={network} token={selected} />}
        <span>{selected?.symbol ?? 'Select'}</span>
        <svg className="chev" width="10" height="7" viewBox="0 0 10 7" aria-hidden="true">
          <path d="M1 1l4 4 4-4" stroke="currentColor" strokeWidth="2" fill="none" strokeLinecap="round" />
        </svg>
      </button>

      {open && (
        <div className="token-popover" role="listbox" aria-label="Select token">
          {tokens.map((t) => {
            const isSelected = t.address.toLowerCase() === value?.toLowerCase()
            return (
              <button
                key={t.address}
                type="button"
                role="option"
                aria-selected={isSelected}
                className={`token-option${isSelected ? ' selected' : ''}`}
                onClick={() => {
                  onSelect(t.address)
                  setOpen(false)
                }}
              >
                <TokenIcon network={network} token={t} />
                <span className="token-option-symbol">{t.symbol}</span>
                <span className="token-option-addr mono">
                  {t.address.slice(0, 6)}…{t.address.slice(-4)}
                </span>
              </button>
            )
          })}
          <button
            type="button"
            className="token-option token-import"
            onClick={() => {
              setOpen(false)
              onImport()
            }}
          >
            ＋ Import token…
          </button>
        </div>
      )}
    </div>
  )
}
