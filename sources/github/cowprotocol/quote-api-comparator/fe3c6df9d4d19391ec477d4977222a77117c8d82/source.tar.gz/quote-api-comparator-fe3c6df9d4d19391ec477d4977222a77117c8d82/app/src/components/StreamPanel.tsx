import { QuoteRow } from './QuoteRow'
import { relevantAmount } from '../lib/ranking'
import type { QuoteStreamState, StreamedQuote } from '../hooks/useQuoteStream'
import type { OrderKind, Token } from '../types'

interface Props {
  state: QuoteStreamState
  ranked: StreamedQuote[]
  kind: OrderKind
  sellToken?: Token
  buyToken?: Token
  /** Overrides the stream error with a form-level validation message. */
  validationError?: string | null
}

/** The live solver-competition panel: status line, quote rows, and footer. */
export function StreamPanel({ state, ranked, kind, sellToken, buyToken, validationError }: Props) {
  const { status } = state
  const count = ranked.length
  const error = validationError ?? (status === 'error' ? state.error : null)
  const loading = status === 'connecting' || status === 'streaming'
  const best = ranked[0]

  return (
    <div className="stream-panel">
      <div className="stream-head">
        <h2>Solver competition · live</h2>
        <StreamStatus status={status} count={count} elapsedMs={state.elapsedMs} hasError={Boolean(error)} />
      </div>
      <div className="stream-sub">
        Quotes stream in one-by-one from <span className="mono">POST /api/v1/quote/stream</span> as each
        solver responds. Best quote wins and fills the swap form.
      </div>

      <div className="quote-list">
        {error ? (
          <div className="stream-error">{error}</div>
        ) : count > 0 && sellToken && buyToken ? (
          ranked.map((q, i) => (
            <QuoteRow
              key={q.id ?? `${q.quote.sellAmount}-${q.quote.buyAmount}-${i}`}
              quote={q}
              rank={i}
              kind={kind}
              sellToken={sellToken}
              buyToken={buyToken}
              bestAmount={relevantAmount(best, kind)}
            />
          ))
        ) : loading ? (
          <>
            <div className="skeleton" />
            <div className="skeleton" />
          </>
        ) : (
          <div className="empty-state">
            <div className="cow-face">🐄</div>
            Enter an amount to open the quote stream.
            <br />
            Moo.
          </div>
        )}
      </div>

      {best && !error && (
        <div className="stream-footer">
          Quotes expire {new Date(best.expiration).toLocaleTimeString()} · ranked by{' '}
          {kind === 'sell' ? 'highest buy amount' : 'lowest sell amount'} · delta vs. best in bps
        </div>
      )}
    </div>
  )
}

function StreamStatus({
  status,
  count,
  elapsedMs,
  hasError,
}: {
  status: QuoteStreamState['status']
  count: number
  elapsedMs: number
  hasError: boolean
}) {
  if (hasError) return <span className="stream-status">error</span>

  const plural = count === 1 ? '' : 's'
  switch (status) {
    case 'connecting':
      return (
        <span className="stream-status">
          <span className="pulse" />
          connecting…
        </span>
      )
    case 'streaming':
      return (
        <span className="stream-status">
          <span className="pulse" />
          streaming… {count} quote{plural}
        </span>
      )
    case 'done':
      return (
        <span className="stream-status">
          closed · {count} quote{plural} in {elapsedMs} ms
        </span>
      )
    default:
      return <span className="stream-status">idle</span>
  }
}
