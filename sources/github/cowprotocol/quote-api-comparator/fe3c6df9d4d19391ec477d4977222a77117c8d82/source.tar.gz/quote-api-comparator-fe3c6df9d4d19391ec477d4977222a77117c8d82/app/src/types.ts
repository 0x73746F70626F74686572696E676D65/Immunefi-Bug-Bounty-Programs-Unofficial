export type Network = 'mainnet' | 'xdai' | 'arbitrum_one' | 'base'

export type OrderKind = 'sell' | 'buy'

export type PriceQuality = 'fast' | 'optimal' | 'verified'

export interface Token {
  symbol: string
  address: `0x${string}`
  decimals: number
  /** true when the user imported it on-chain rather than it coming from the default list */
  custom?: boolean
}
