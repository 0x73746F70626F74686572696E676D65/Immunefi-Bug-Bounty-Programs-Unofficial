import { z } from 'zod'
import type { OrderKind, PriceQuality } from '../types'

/**
 * Zod schemas mirroring the CoW Protocol orderbook OpenAPI spec
 * (`OrderQuoteResponse`, `OrderParameters`, `PriceEstimationError`).
 *
 * These run at the network boundary: every SSE frame is validated before it
 * reaches the UI, so a malformed payload becomes a caught, typed error instead
 * of a `BigInt(undefined)` crash deep in the render path.
 *
 * Inbound fields the spec marks required but that aren't load-bearing for this
 * UI (gasAmount/gasPrice/…) are kept `.optional()` so one missing field never
 * discards an otherwise-usable quote. `.passthrough()` preserves unknown fields.
 */

const TokenAmount = z.string() // uint256 in atoms, decimal-encoded
const Address = z.string()

export const OrderKindSchema: z.ZodType<OrderKind> = z.enum(['buy', 'sell'])

export const OrderParametersSchema = z
  .object({
    sellToken: Address,
    buyToken: Address,
    receiver: Address.nullable().optional(),
    sellAmount: TokenAmount,
    buyAmount: TokenAmount,
    validTo: z.number(),
    appData: z.string(),
    appDataHash: z.string().optional(),
    feeAmount: TokenAmount,
    gasAmount: z.string().optional(),
    gasPrice: z.string().optional(),
    sellTokenPrice: z.string().optional(),
    kind: OrderKindSchema,
    partiallyFillable: z.boolean(),
    signingScheme: z.string().optional(),
  })
  .passthrough()

export const OrderQuoteResponseSchema = z
  .object({
    quote: OrderParametersSchema,
    from: Address.optional(),
    expiration: z.string(), // ISO 8601 UTC
    // `fast` quotes are not stored, so `id` comes back null — it's only present
    // for quotes you can actually place an order from (optimal/verified).
    id: z.number().nullable().optional(),
    verified: z.boolean(),
    protocolFeeBps: z.string().optional(),
  })
  .passthrough()

export type OrderQuoteResponse = z.infer<typeof OrderQuoteResponseSchema>

export const PriceEstimationErrorSchema = z
  .object({
    errorType: z.string(),
    description: z.string(),
    data: z.unknown().optional(),
  })
  .passthrough()

export type PriceEstimationError = z.infer<typeof PriceEstimationErrorSchema>

/** BFF USD-price endpoint payload. */
export const UsdPriceSchema = z.object({ price: z.number().finite().nullable() }).passthrough()

/**
 * Request body for `POST /api/v1/quote[/stream]`. This is the `OrderQuoteRequest`
 * shape: a required base plus exactly one of the three amount fields depending
 * on `kind` and whether the amount is before/after fee.
 */
export interface QuoteRequestBody {
  sellToken: string
  buyToken: string
  from: string
  receiver?: string
  appData: string
  kind: OrderKind
  /** Honored by `/quote`; ignored by `/quote/stream` (always full + verified). */
  priceQuality?: PriceQuality
  /** ms; omit for the server default. */
  timeout?: number
  sellAmountBeforeFee?: string
  sellAmountAfterFee?: string
  buyAmountAfterFee?: string
}
