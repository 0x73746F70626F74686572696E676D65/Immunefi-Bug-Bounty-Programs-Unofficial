import { BFF_BASE, CHAIN_ID } from '../config/chains'
import type { Network } from '../types'
import { UsdPriceSchema } from './schemas'

/** USD price for one atomic unit's worth of a token, or `null` if unavailable. */
export async function fetchUsdPrice(network: Network, address: string): Promise<number | null> {
  const res = await fetch(`${BFF_BASE}/${CHAIN_ID[network]}/tokens/${address}/usdPrice`)
  if (!res.ok) return null
  const parsed = UsdPriceSchema.safeParse(await res.json())
  return parsed.success ? parsed.data.price : null
}
