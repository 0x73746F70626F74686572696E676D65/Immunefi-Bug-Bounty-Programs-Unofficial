import { useEffect, useReducer } from 'react'
import { fetchClassicQuote } from '../api/classicQuote'
import type { OrderQuoteResponse, QuoteRequestBody } from '../api/schemas'
import type { Network } from '../types'

export type ClassicStatus = 'idle' | 'loading' | 'success' | 'error'

export interface ClassicQuoteState {
  status: ClassicStatus
  quote: OrderQuoteResponse | null
  error: string | null
  elapsedMs: number
}

export interface ClassicQuoteParams {
  network: Network
  body: QuoteRequestBody
}

const INITIAL: ClassicQuoteState = { status: 'idle', quote: null, error: null, elapsedMs: 0 }

type Action =
  | { type: 'reset' }
  | { type: 'loading' }
  | { type: 'success'; quote: OrderQuoteResponse; elapsedMs: number }
  | { type: 'error'; error: string; elapsedMs: number }

function reducer(_state: ClassicQuoteState, action: Action): ClassicQuoteState {
  switch (action.type) {
    case 'reset':
      return INITIAL
    case 'loading':
      return { status: 'loading', quote: null, error: null, elapsedMs: 0 }
    case 'success':
      return { status: 'success', quote: action.quote, error: null, elapsedMs: action.elapsedMs }
    case 'error':
      return { status: 'error', quote: null, error: action.error, elapsedMs: action.elapsedMs }
  }
}

function paramsKey(params: ClassicQuoteParams | null): string {
  return params ? `${params.network}:${JSON.stringify(params.body)}` : ''
}

/**
 * Fetch the classic blocking quote for `params` (null to stay idle). Mirrors
 * `useQuoteStream`'s lifecycle so the two can be raced head-to-head from the
 * same inputs; `elapsedMs` is the time to the single response — which for the
 * blocking endpoint is also its time-to-first-price.
 */
export function useClassicQuote(params: ClassicQuoteParams | null): ClassicQuoteState {
  const [state, dispatch] = useReducer(reducer, INITIAL)
  const key = paramsKey(params)

  useEffect(() => {
    if (!params) {
      dispatch({ type: 'reset' })
      return
    }

    const controller = new AbortController()
    const t0 = performance.now()
    const since = () => Math.round(performance.now() - t0)

    dispatch({ type: 'loading' })
    fetchClassicQuote(params.network, params.body, controller.signal)
      .then((quote) => {
        if (!controller.signal.aborted) dispatch({ type: 'success', quote, elapsedMs: since() })
      })
      .catch((err: unknown) => {
        if (controller.signal.aborted) return
        dispatch({ type: 'error', error: err instanceof Error ? err.message : String(err), elapsedMs: since() })
      })

    return () => controller.abort()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [key])

  return state
}
