import { fromAtoms } from '../lib/amounts'
import { deltaBps, relevantAmount } from '../lib/ranking'
import type { StreamedQuote } from '../hooks/useQuoteStream'
import type { OrderKind, Token } from '../types'

interface Props {
  quote: StreamedQuote
  rank: number
  kind: OrderKind
  sellToken: Token
  buyToken: Token
  bestAmount: bigint
}

/** One solver's quote. The relevant amount depends on the order side. */
export function QuoteRow({ quote, rank, kind, sellToken, buyToken, bestAmount }: Props) {
  const isBest = rank === 0
  const value = relevantAmount(quote, kind)
  const outToken = kind === 'sell' ? buyToken : sellToken
  const bps = deltaBps(value, bestAmount, kind)

  return (
    <div className={`quote-row ${isBest ? 'best' : ''}`}>
      <div className="rank">{rank + 1}</div>
      <div className="q-amount">
        {fromAtoms(value, outToken.decimals)} <span className="sym">{outToken.symbol}</span>
      </div>
      <div className="q-right">
        <span className={`badge ${quote.verified ? 'verified' : 'unverified'}`}>
          {quote.verified ? '✓ verified' : 'unverified'}
        </span>
        {isBest ? (
          <span className="delta zero">best quote</span>
        ) : (
          <span className="delta neg">−{bps.toLocaleString(undefined, { maximumFractionDigits: 1 })} bps</span>
        )}
      </div>
      <div className="q-meta">
        <span>+{quote.receivedMs} ms</span>
        <span>
          fee {fromAtoms(quote.quote.feeAmount, sellToken.decimals, 4)} {sellToken.symbol}
        </span>
        {quote.id != null && <span className="mono">id {quote.id}</span>}
        {quote.protocolFeeBps && <span>protocol fee {quote.protocolFeeBps} bps</span>}
      </div>
    </div>
  )
}
