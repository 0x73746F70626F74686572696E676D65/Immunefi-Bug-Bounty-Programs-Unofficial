import { parseUnits, formatUnits } from 'viem'

/**
 * Decimal string → atoms (bigint), or `null` if the input isn't a positive
 * number. viem's `parseUnits` owns the rounding/precision edge cases we would
 * otherwise be hand-rolling.
 */
export function toAtoms(input: string, decimals: number): bigint | null {
  const s = input.trim()
  if (s === '' || s === '.' || !/^\d*\.?\d*$/.test(s)) return null
  try {
    const v = parseUnits(s, decimals)
    return v > 0n ? v : null
  } catch {
    return null
  }
}

/**
 * Atoms → human decimal string, trimmed to `maxSignificant` significant
 * fractional digits for display (full precision is preserved upstream).
 */
export function fromAtoms(atoms: bigint | string, decimals: number, maxSignificant = 6): string {
  let value: bigint
  try {
    value = typeof atoms === 'bigint' ? atoms : BigInt(atoms)
  } catch {
    return '—'
  }
  const full = formatUnits(value, decimals)
  return trimForDisplay(full, maxSignificant)
}

function trimForDisplay(decimalStr: string, maxSignificant: number): string {
  const [intPart, fracPart = ''] = decimalStr.split('.')
  if (!fracPart) return intPart
  // For numbers >= 1 keep up to maxSignificant fractional digits; for small
  // numbers keep more so we don't collapse "0.0000123" to "0".
  const keep = intPart !== '0' ? maxSignificant : Math.max(maxSignificant, fracPart.length)
  const trimmed = fracPart.slice(0, keep).replace(/0+$/, '')
  return trimmed ? `${intPart}.${trimmed}` : intPart
}

export const formatUsd = (v: number): string =>
  '≈ $' + v.toLocaleString(undefined, { maximumFractionDigits: v < 1 ? 4 : 2 })
