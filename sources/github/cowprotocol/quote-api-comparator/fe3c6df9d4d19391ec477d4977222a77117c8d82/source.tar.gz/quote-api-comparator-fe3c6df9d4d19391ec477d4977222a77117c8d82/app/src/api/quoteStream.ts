import { fetchEventSource } from '@microsoft/fetch-event-source'
import { API_BASE } from '../config/chains'
import type { Network } from '../types'
import {
  OrderQuoteResponseSchema,
  PriceEstimationErrorSchema,
  type OrderQuoteResponse,
  type PriceEstimationError,
  type QuoteRequestBody,
} from './schemas'

export interface StreamHandlers {
  onOpen?: () => void
  onQuote: (quote: OrderQuoteResponse) => void
  /** A terminal `error` event, or a non-stream HTTP error body. */
  onApiError: (error: PriceEstimationError) => void
}

/** Thrown internally to stop `fetchEventSource`'s reconnect loop on normal close. */
class StreamClosed extends Error {}
/** Thrown when the initial response is not a usable event stream. */
class FatalResponse extends Error {}

/**
 * Open the streaming-quote SSE and drive `handlers` until the stream closes or
 * `signal` aborts. Resolves on normal close; rejects only on a real transport
 * error (never on a superseded/aborted request).
 *
 * Uses `@microsoft/fetch-event-source` rather than the browser `EventSource`
 * because this endpoint is a POST with a JSON body — `EventSource` is GET-only.
 * It also handles frame parsing, and we opt out of its auto-reconnect (this is
 * a one-shot stream, not a persistent channel).
 */
export async function streamQuotes(
  network: Network,
  body: QuoteRequestBody,
  handlers: StreamHandlers,
  signal: AbortSignal,
): Promise<void> {
  const url = `${API_BASE}/${network}/api/v1/quote/stream`

  try {
    await fetchEventSource(url, {
      method: 'POST',
      headers: { 'content-type': 'application/json', accept: 'text/event-stream' },
      body: JSON.stringify(body),
      signal,
      // The stream is short-lived (1–5s); keep it running if the tab is hidden
      // instead of aborting + reconnecting on visibility change.
      openWhenHidden: true,

      async onopen(res) {
        const contentType = res.headers.get('content-type') ?? ''
        if (res.ok && contentType.includes('text/event-stream')) {
          handlers.onOpen?.()
          return
        }
        // Non-stream response (e.g. 400/404): surface the API error body.
        const parsed = PriceEstimationErrorSchema.safeParse(await safeJson(res))
        if (parsed.success) handlers.onApiError(parsed.data)
        throw new FatalResponse(parsed.success ? parsed.data.errorType : `HTTP ${res.status}`)
      },

      onmessage(ev) {
        if (!ev.data) return
        let json: unknown
        try {
          json = JSON.parse(ev.data)
        } catch {
          return // drop unparseable frame
        }
        if (ev.event === 'error') {
          const parsed = PriceEstimationErrorSchema.safeParse(json)
          if (parsed.success) handlers.onApiError(parsed.data)
          return
        }
        const parsed = OrderQuoteResponseSchema.safeParse(json)
        if (parsed.success) handlers.onQuote(parsed.data)
        // A frame that fails validation is dropped rather than crashing render.
      },

      onclose() {
        // Server ended the stream normally — stop, don't reconnect.
        throw new StreamClosed()
      },

      onerror(err) {
        // Returning would retry with backoff; we rethrow to stop the loop and
        // let the caller's catch classify the failure.
        throw err
      },
    })
  } catch (err) {
    if (err instanceof StreamClosed) return // normal completion
    if (signal.aborted) return // superseded by a newer request
    if (err instanceof FatalResponse) return // already reported via onApiError
    throw err
  }
}

async function safeJson(res: Response): Promise<unknown> {
  try {
    return await res.json()
  } catch {
    return undefined
  }
}
