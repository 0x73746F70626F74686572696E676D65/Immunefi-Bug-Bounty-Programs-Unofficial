import { useEffect, useMemo, useState, type ReactNode } from 'react'
import { DEFAULT_FROM, DEFAULT_TOKENS, ZERO_APP_DATA } from './config/tokens'
import { fromAtoms, formatUsd, toAtoms } from './lib/amounts'
import { rankQuotes } from './lib/ranking'
import { useDebounced } from './lib/useDebounced'
import { useQuoteStream, type QuoteStreamParams } from './hooks/useQuoteStream'
import { useClassicQuote } from './hooks/useClassicQuote'
import { useUsdPrice } from './hooks/useUsdPrice'
import type { QuoteRequestBody } from './api/schemas'
import type { Network, OrderKind, PriceQuality, Token } from './types'
import { TokenSelect } from './components/TokenSelect'
import { StreamPanel } from './components/StreamPanel'
import { CompareView } from './components/CompareView'
import { ImportTokenDialog } from './components/ImportTokenDialog'

type View = 'compare' | 'stream'

const ADDRESS_RE = /^0x[0-9a-fA-F]{40}$/

const PRICE_QUALITIES: PriceQuality[] = ['fast', 'optimal', 'verified']

const DEFAULT_PRICE_QUALITY: PriceQuality = 'optimal'
const DEFAULT_TIMEOUT_MS = '2000'

// Partners are handed pre-configured links, e.g. `?priceQuality=fast&timeout=2000`.
// A present-but-empty `timeout` (or 0) means "no explicit timeout" — the server default.
function readParamsFromUrl(): { priceQuality: PriceQuality; timeoutMs: string } {
  const sp = new URLSearchParams(window.location.search)
  const pqRaw = sp.get('priceQuality')
  const priceQuality = PRICE_QUALITIES.includes(pqRaw as PriceQuality)
    ? (pqRaw as PriceQuality)
    : DEFAULT_PRICE_QUALITY
  if (!sp.has('timeout')) return { priceQuality, timeoutMs: DEFAULT_TIMEOUT_MS }
  const digits = (sp.get('timeout') ?? '').replace(/[^\d]/g, '')
  const n = Number(digits)
  const timeoutMs = digits === '' || !Number.isFinite(n) || n <= 0 ? '' : String(n)
  return { priceQuality, timeoutMs }
}

function App() {
  // Locked to Ethereum mainnet — chain switching is intentionally disabled.
  const network: Network = 'mainnet'
  // Required by the API on every quote request, but not user-facing — no wallet is
  // connected, so it stays pinned to the demo default and is sent behind the scenes.
  const from = DEFAULT_FROM
  const [customTokens, setCustomTokens] = useState<Record<Network, Token[]>>({
    mainnet: [],
    xdai: [],
    arbitrum_one: [],
    base: [],
  })
  const [sellAddr, setSellAddr] = useState(DEFAULT_TOKENS.mainnet[0].address)
  const [buyAddr, setBuyAddr] = useState(DEFAULT_TOKENS.mainnet[1].address)
  const [sellInput, setSellInput] = useState('')
  const [buyInput, setBuyInput] = useState('')
  const [kind, setKind] = useState<OrderKind>('sell')
  const [importSide, setImportSide] = useState<OrderKind | null>(null)
  const [view, setView] = useState<View>('compare')
  const [priceQuality, setPriceQuality] = useState<PriceQuality>(() => readParamsFromUrl().priceQuality)
  const [timeoutMs, setTimeoutMs] = useState(() => readParamsFromUrl().timeoutMs)

  // Reflect the two partner-tunable params back into the query string (replace, not
  // push, so we don't spam history) — the address bar is always a shareable link,
  // with both params spelled out even when they're at their defaults.
  useEffect(() => {
    const sp = new URLSearchParams(window.location.search)
    sp.set('priceQuality', priceQuality)
    sp.set('timeout', timeoutMs)
    const qs = sp.toString()
    const next = `${window.location.pathname}${qs ? `?${qs}` : ''}${window.location.hash}`
    window.history.replaceState(null, '', next)
  }, [priceQuality, timeoutMs])

  const tokens = useMemo(
    () => [...DEFAULT_TOKENS[network], ...customTokens[network]],
    [network, customTokens],
  )
  const sellToken = tokens.find((t) => t.address === sellAddr)
  const buyToken = tokens.find((t) => t.address === buyAddr)

  const fromTrimmed = from.trim()
  const fromValid = ADDRESS_RE.test(fromTrimmed)
  const editedInput = kind === 'sell' ? sellInput : buyInput

  // Build the request only when everything is valid; memoised so its identity
  // is stable across unrelated re-renders (keeps the debounce from resetting).
  const trimmedTimeout = timeoutMs.trim()
  const timeoutValue =
    trimmedTimeout === '' || !Number.isFinite(Number(trimmedTimeout)) || Number(trimmedTimeout) <= 0
      ? undefined
      : Math.round(Number(trimmedTimeout))

  const params = useMemo<QuoteStreamParams | null>(() => {
    if (!sellToken || !buyToken || sellToken.address === buyToken.address || !fromValid) return null
    const editedToken = kind === 'sell' ? sellToken : buyToken
    const atoms = toAtoms(editedInput, editedToken.decimals)
    if (!atoms) return null
    const body: QuoteRequestBody = {
      sellToken: sellToken.address,
      buyToken: buyToken.address,
      from: fromTrimmed,
      receiver: fromTrimmed,
      appData: ZERO_APP_DATA,
      kind,
      priceQuality,
      ...(timeoutValue != null ? { timeout: timeoutValue } : {}),
      ...(kind === 'sell'
        ? { sellAmountBeforeFee: atoms.toString() }
        : { buyAmountAfterFee: atoms.toString() }),
    }
    return { network, body }
  }, [network, sellToken, buyToken, kind, editedInput, fromTrimmed, fromValid, priceQuality, timeoutValue])

  const debouncedParams = useDebounced(params, 600)
  const stream = useQuoteStream(debouncedParams)
  // Race the classic endpoint from the same request, but only in compare view.
  const classic = useClassicQuote(view === 'compare' ? debouncedParams : null)
  const requestKey = debouncedParams
    ? `${debouncedParams.network}:${JSON.stringify(debouncedParams.body)}`
    : 'idle'

  const ranked = useMemo(() => rankQuotes(stream.quotes, kind), [stream.quotes, kind])
  const best = ranked[0]

  const sellPrice = useUsdPrice(network, sellToken?.address)
  const buyPrice = useUsdPrice(network, buyToken?.address)

  // Derived field values: the edited side echoes the user; the other side shows
  // the best quote (no imperative DOM writes).
  const sellFieldValue =
    kind === 'sell' ? sellInput : best && sellToken ? fromAtoms(best.quote.sellAmount, sellToken.decimals) : ''
  const buyFieldValue =
    kind === 'buy' ? buyInput : best && buyToken ? fromAtoms(best.quote.buyAmount, buyToken.decimals) : ''

  const hasEdited = editedInput.trim() !== ''
  const validationError =
    hasEdited && sellToken && buyToken && sellToken.address === buyToken.address
      ? 'Pick two different tokens. Even cows don’t trade grass for grass.'
      : hasEdited && !fromValid
        ? 'The account address (top right) is not a valid 0x address.'
        : null

  // Rate + fee + fiat, all from the best quote.
  let rateLine = ''
  let feeLine = ''
  let sellFiat: ReactNode = ''
  let buyFiat: ReactNode = ''
  if (best && sellToken && buyToken) {
    const sellF = Number(fromAtoms(best.quote.sellAmount, sellToken.decimals, 12))
    const buyF = Number(fromAtoms(best.quote.buyAmount, buyToken.decimals, 12))
    if (sellF > 0) {
      rateLine = `1 ${sellToken.symbol} = ${(buyF / sellF).toLocaleString(undefined, {
        maximumSignificantDigits: 6,
      })} ${buyToken.symbol}`
    }
    feeLine = `network fee ≈ ${fromAtoms(best.quote.feeAmount, sellToken.decimals, 4)} ${sellToken.symbol}`

    const ps = sellPrice.data
    const pb = buyPrice.data
    sellFiat = ps != null ? formatUsd(sellF * ps) : 'no USD estimate'
    if (pb == null) {
      buyFiat = 'no USD estimate'
    } else {
      const buyUsd = buyF * pb
      let impact: ReactNode = null
      if (ps != null && sellF * ps > 0) {
        const pct = (buyUsd / (sellF * ps) - 1) * 100
        const cls = pct <= -5 ? 'impact-bad' : pct <= -1 ? 'impact-warn' : 'impact-ok'
        impact = (
          <span className={cls} title="Price impact from BFF USD estimates">
            ({pct >= 0 ? '+' : ''}
            {pct.toFixed(2)}%)
          </span>
        )
      }
      buyFiat = (
        <>
          {formatUsd(buyUsd)} {impact}
        </>
      )
    }
  }


  const flip = () => {
    setSellAddr(buyAddr)
    setBuyAddr(sellAddr)
    setSellInput(buyInput)
    setBuyInput(sellInput)
    setKind((k) => (k === 'sell' ? 'buy' : 'sell'))
  }

  const handleImported = (token: Token) => {
    setCustomTokens((prev) => {
      const list = prev[network]
      if (list.some((t) => t.address.toLowerCase() === token.address.toLowerCase())) return prev
      return { ...prev, [network]: [...list, token] }
    })
    if (importSide === 'sell') setSellAddr(token.address)
    else setBuyAddr(token.address)
    setImportSide(null)
  }

  return (
    <>
      <header>
        <div className="logo">
          <svg viewBox="0 0 36 24" role="img" aria-label="CoW logo">
            <path
              fill="currentColor"
              fillRule="evenodd"
              d="M13.653 24a4.011 4.011 0 0 1-3.824-2.79L7.11 12.666H5.44a4.01 4.01 0 0 1-3.825-2.791L0 4.8h6.058L2.863 0h30.274l-3.195 4.8H36l-1.615 5.076a4.01 4.01 0 0 1-3.825 2.79h-1.67l-2.72 8.544A4.01 4.01 0 0 1 22.346 24h-8.693ZM11.6 10.333c0 1.289.965 2.334 2.156 2.334 1.19 0 2.155-1.045 2.155-2.334 0-1.288-.965-2.333-2.155-2.333S11.6 9.045 11.6 10.333Zm12.8 0c0 1.289-.965 2.334-2.156 2.334-1.19 0-2.155-1.045-2.155-2.334 0-1.288.965-2.333 2.155-2.333S24.4 9.045 24.4 10.333Z"
              clipRule="evenodd"
            />
          </svg>
          <span>Quote API Comparator</span>
        </div>
        <div className="header-right">
          <div className="seg" role="tablist" aria-label="View">
            <button
              className={view === 'compare' ? 'active' : ''}
              onClick={() => setView('compare')}
              role="tab"
              aria-selected={view === 'compare'}
            >
              Compare
            </button>
            <button
              className={view === 'stream' ? 'active' : ''}
              onClick={() => setView('stream')}
              role="tab"
              aria-selected={view === 'stream'}
            >
              Stream only
            </button>
          </div>
          <div className="network-badge" title="Network">
            <span className="net-dot" />
            Ethereum
          </div>
          <a className="nav-link" href="guide.html" target="_blank" rel="noopener">
            Guide ↗
          </a>
        </div>
      </header>

      <div className={`wrap ${view === 'compare' ? 'wrap-compare' : ''}`}>
        {/* ======== swap card ======== */}
        <div className="swap-card">
          <div className="swap-head">
            <h1>Swap</h1>
            <span className="settings">Slippage: auto</span>
          </div>

          <div className="field">
            <div className="field-label">
              <span>You sell</span>
              <span>{kind === 'buy' ? 'estimated' : ''}</span>
            </div>
            <div className="field-row">
              <input
                key={kind === 'sell' ? 'sell-edit' : `sell-derived-${ranked.length}`}
                className={`amount-input ${kind !== 'sell' ? 'streamed' : ''}`}
                inputMode="decimal"
                placeholder="0"
                autoComplete="off"
                value={sellFieldValue}
                onChange={(e) => {
                  setKind('sell')
                  setSellInput(e.target.value)
                }}
              />
              <TokenSelect
                network={network}
                tokens={tokens}
                value={sellAddr}
                onSelect={setSellAddr}
                onImport={() => setImportSide('sell')}
              />
            </div>
            <div className="fiat">{sellFiat}</div>
          </div>

          <div className="flip-wrap">
            <button className="flip-btn" title="Switch tokens" onClick={flip}>
              ↓
            </button>
          </div>

          <div className="field">
            <div className="field-label">
              <span>You receive (est.)</span>
              <span>{kind === 'sell' ? 'estimated' : ''}</span>
            </div>
            <div className="field-row">
              <input
                key={kind === 'buy' ? 'buy-edit' : `buy-derived-${ranked.length}`}
                className={`amount-input ${kind !== 'buy' ? 'streamed' : ''}`}
                inputMode="decimal"
                placeholder="0"
                autoComplete="off"
                value={buyFieldValue}
                onChange={(e) => {
                  setKind('buy')
                  setBuyInput(e.target.value)
                }}
              />
              <TokenSelect
                network={network}
                tokens={tokens}
                value={buyAddr}
                onSelect={setBuyAddr}
                onImport={() => setImportSide('buy')}
              />
            </div>
            <div className="fiat">{buyFiat}</div>
          </div>

          <div className="rate-line">
            <span>{rateLine}</span>
            <span>{feeLine}</span>
          </div>

          <div className="params">
            <div className="params-row">
              <span className="params-label">Price quality</span>
              <div className="seg seg-sm">
                {(['fast', 'optimal', 'verified'] as PriceQuality[]).map((pq) => (
                  <button
                    key={pq}
                    className={priceQuality === pq ? 'active' : ''}
                    onClick={() => setPriceQuality(pq)}
                  >
                    {pq}
                  </button>
                ))}
              </div>
            </div>
            <div className="params-row">
              <span className="params-label">Timeout</span>
              <div className="timeout-field">
                <input
                  className="timeout-input mono"
                  inputMode="numeric"
                  placeholder="server default"
                  value={timeoutMs}
                  onChange={(e) => setTimeoutMs(e.target.value.replace(/[^\d]/g, ''))}
                />
                <span className="timeout-unit">ms</span>
              </div>
            </div>
          </div>

          <div className="cta-note">
            Params apply to both calls · <span className="mono">priceQuality</span> is ignored by the
            stream
          </div>
        </div>

        {/* ======== solver stream / comparison ======== */}
        {view === 'compare' ? (
          <CompareView
            classic={classic}
            stream={stream}
            ranked={ranked}
            kind={kind}
            sellToken={sellToken}
            buyToken={buyToken}
            priceQuality={priceQuality}
            requestKey={requestKey}
            validationError={validationError}
          />
        ) : (
          <StreamPanel
            state={stream}
            ranked={ranked}
            kind={kind}
            sellToken={sellToken}
            buyToken={buyToken}
            validationError={validationError}
          />
        )}
      </div>

      {importSide && (
        <ImportTokenDialog
          network={network}
          onImported={handleImported}
          onClose={() => setImportSide(null)}
        />
      )}
    </>
  )
}

export default App
