import type { OrderKind } from '../types'
import type { OrderQuoteResponse } from '../api/schemas'
import type { StreamedQuote } from '../hooks/useQuoteStream'

/** The amount that determines quote quality for the given side. */
export function relevantAmount(q: OrderQuoteResponse, kind: OrderKind): bigint {
  return BigInt(kind === 'sell' ? q.quote.buyAmount : q.quote.sellAmount)
}

/**
 * Rank quotes best-first: a sell order maximises the buy amount received; a buy
 * order minimises the sell amount paid.
 */
export function rankQuotes(quotes: StreamedQuote[], kind: OrderKind): StreamedQuote[] {
  return [...quotes].sort((a, b) => {
    const av = relevantAmount(a, kind)
    const bv = relevantAmount(b, kind)
    if (av === bv) return 0
    const aBetter = kind === 'sell' ? av > bv : av < bv
    return aBetter ? -1 : 1
  })
}

/** How much worse `value` is than `best`, in basis points (always >= 0). */
export function deltaBps(value: bigint, best: bigint, kind: OrderKind): number {
  if (best <= 0n) return 0
  const diff = kind === 'sell' ? best - value : value - best
  return Number((diff * 100_000n) / best) / 10
}
