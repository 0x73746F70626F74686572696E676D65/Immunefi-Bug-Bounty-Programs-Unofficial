import { useQuery } from '@tanstack/react-query'
import { fetchUsdPrice } from '../api/prices'
import type { Network } from '../types'

/**
 * USD price via TanStack Query. This replaces the demo's hand-rolled `Map`
 * cache + 30s TTL + `fiatSeq` staleness counter: Query dedupes concurrent
 * lookups, caches per token, and discards responses for superseded keys.
 */
export function useUsdPrice(network: Network, address?: string) {
  return useQuery({
    queryKey: ['usdPrice', network, address?.toLowerCase()],
    queryFn: () => fetchUsdPrice(network, address!),
    enabled: Boolean(address),
    staleTime: 30_000,
    gcTime: 60_000,
    retry: 1,
  })
}
