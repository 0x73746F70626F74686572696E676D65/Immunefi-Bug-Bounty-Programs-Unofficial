import { useEffect, useReducer } from 'react'
import { streamQuotes } from '../api/quoteStream'
import type { OrderQuoteResponse, QuoteRequestBody } from '../api/schemas'
import type { Network } from '../types'

/** A received quote, tagged with how long after stream start it arrived. */
export type StreamedQuote = OrderQuoteResponse & { receivedMs: number }

export type StreamStatus = 'idle' | 'connecting' | 'streaming' | 'done' | 'error'

export interface QuoteStreamState {
  status: StreamStatus
  quotes: StreamedQuote[]
  error: string | null
  elapsedMs: number
}

export interface QuoteStreamParams {
  network: Network
  body: QuoteRequestBody
}

const INITIAL: QuoteStreamState = { status: 'idle', quotes: [], error: null, elapsedMs: 0 }

type Action =
  | { type: 'reset' }
  | { type: 'open' }
  | { type: 'streaming' }
  | { type: 'quote'; quote: OrderQuoteResponse; receivedMs: number }
  | { type: 'apiError'; error: string }
  | { type: 'transportError'; error: string }
  | { type: 'done'; elapsedMs: number }

/**
 * Explicit state machine for the stream lifecycle. Modelling it here replaces
 * the demo's scattered globals (abort controller + `fiatSeq` counter + manual
 * status strings) with one reducer whose transitions are easy to reason about.
 *
 * Behaviour parity with the reference: an API error is only surfaced when no
 * quotes have arrived yet — once we have quotes, a late error doesn't blow away
 * a usable result.
 */
function reducer(state: QuoteStreamState, action: Action): QuoteStreamState {
  switch (action.type) {
    case 'reset':
      return INITIAL
    case 'open':
      return { status: 'connecting', quotes: [], error: null, elapsedMs: 0 }
    case 'streaming':
      return state.status === 'connecting' ? { ...state, status: 'streaming' } : state
    case 'quote':
      return {
        ...state,
        status: 'streaming',
        quotes: [...state.quotes, { ...action.quote, receivedMs: action.receivedMs }],
      }
    case 'apiError':
      return state.quotes.length ? state : { ...state, status: 'error', error: action.error }
    case 'transportError':
      return state.quotes.length
        ? { ...state, status: 'done' }
        : { ...state, status: 'error', error: action.error }
    case 'done':
      return state.status === 'error' ? state : { ...state, status: 'done', elapsedMs: action.elapsedMs }
  }
}

/** Serialises params into a stable key so the effect only restarts on real changes. */
function paramsKey(params: QuoteStreamParams | null): string {
  return params ? `${params.network}:${JSON.stringify(params.body)}` : ''
}

/**
 * Subscribe to the quote stream for `params`. Pass `null` to stay idle.
 * Changing params aborts the in-flight stream and starts a fresh one;
 * unmounting aborts. All race handling lives in this one effect.
 */
export function useQuoteStream(params: QuoteStreamParams | null): QuoteStreamState {
  const [state, dispatch] = useReducer(reducer, INITIAL)
  const key = paramsKey(params)

  useEffect(() => {
    if (!params) {
      dispatch({ type: 'reset' })
      return
    }

    const controller = new AbortController()
    const t0 = performance.now()
    const since = () => Math.round(performance.now() - t0)

    dispatch({ type: 'open' })
    streamQuotes(
      params.network,
      params.body,
      {
        onOpen: () => dispatch({ type: 'streaming' }),
        onQuote: (quote) => dispatch({ type: 'quote', quote, receivedMs: since() }),
        onApiError: (e) => dispatch({ type: 'apiError', error: `${e.errorType}: ${e.description}` }),
      },
      controller.signal,
    )
      .then(() => {
        if (!controller.signal.aborted) dispatch({ type: 'done', elapsedMs: since() })
      })
      .catch((err: unknown) => {
        if (controller.signal.aborted) return
        const message = err instanceof Error ? err.message : String(err)
        dispatch({ type: 'transportError', error: `Could not reach the API: ${message}` })
      })

    return () => controller.abort()
    // `key` captures every meaningful change in `params`.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [key])

  return state
}
