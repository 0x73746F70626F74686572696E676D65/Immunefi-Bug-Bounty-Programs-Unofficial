//! Loads ERC20 token lists over HTTP and exposes the set of token addresses
//! for the active EVM network.
//!
//! [`TokenListFetcher`] is single-network: each instance is bound to one
//! [`EvmNetwork`] and filters every fetched list down to that chain. Results
//! are cached per URL via [`moka`] with a TTL, and concurrent fetches of the
//! same URL are coalesced, so multiple subscriptions sharing one fetcher never
//! trigger duplicate HTTP calls. Retries on transient HTTP failures are handled
//! with exponential backoff ([`backon`]).

use crate::config::constants::{
    MAX_TOKEN_LIST_RESPONSE_BYTES, TOKEN_LIST_FETCH_TIMEOUT, USER_AGENT,
};
use crate::services::url_guard;
use crate::{domain::EvmNetwork, metrics::Metrics};
use alloy::primitives::Address;
use backon::{ExponentialBuilder, Retryable};
use futures::future::try_join_all;
use futures::StreamExt;
use moka::future::Cache;
use reqwest::{Client, Response};
use serde::Deserialize;
use std::sync::Arc;
use std::{
    collections::HashSet,
    time::{Duration, Instant},
};

const CACHE_CAPACITY: u64 = 256;

/// How many unparseable active-chain addresses to include verbatim in the
/// paired warn (the metric carries the full count).
const INVALID_ADDRESS_LOG_SAMPLES: usize = 5;
/// Per-sample length cap for those log entries.
const MAX_SAMPLE_CHARS: usize = 64;

type ListUrl = String;

type ChainTokens = HashSet<Address>;

/// Errors surfaced by [`TokenListFetcher`].
#[derive(Debug, Clone, thiserror::Error)]
pub enum FetcherError {
    #[error("unable to load token list, url: {0}, error: {1}")]
    UnableToLoadList(String, String),

    /// The URL failed the SSRF guard ([`url_guard::validate_url`]) — wrong
    /// scheme, or a non-public host while private hosts are disallowed.
    #[error("token list url not allowed, url: {0}, reason: {1}")]
    UrlNotAllowed(String, String),
}

pub struct TokenListFetcher {
    cache: Cache<ListUrl, ChainTokens>,
    // http client
    client: Client,
    // backoff configuration
    backoff_cfg: ExponentialBuilder,
    metrics: Arc<Metrics>,
    // active network; the fetcher is single-chain, so it filters lists by this one
    network: EvmNetwork,
    // SSRF escape hatch: when true, token-list URLs may point at private /
    // loopback hosts (local dev, integration tests). Always false in prod.
    allow_private_hosts: bool,
}

#[derive(Debug, Deserialize)]
struct ApiResponse {
    /// Raw entries; parsed leniently per item in
    /// [`TokenListFetcher::fetch_list_and_filter_by_chain`] — see the comment
    /// there for why strict typed deserialization is not an option.
    tokens: Vec<serde_json::Value>,
}

/// The subset of a token-list entry this service needs. `address` stays a
/// string at this stage: multi-chain lists carry non-EVM addresses that must
/// not be forced through the 20-byte [`Address`] parser wholesale.
#[derive(Debug, Deserialize)]
#[serde(rename_all = "camelCase")]
struct RawToken {
    address: String,
    chain_id: u64,
}

impl TokenListFetcher {
    pub fn new(
        cache_ttl: Duration,
        backoff_cfg: ExponentialBuilder,
        metrics: Arc<Metrics>,
        network: EvmNetwork,
        allow_private_hosts: bool,
    ) -> Self {
        if allow_private_hosts {
            tracing::warn!(
                "ALLOW_PRIVATE_TOKEN_LISTS is enabled — token-list URLs may reach \
                 private/loopback hosts. This must never be on in a deployed environment."
            );
        }

        Self {
            cache: Cache::builder()
                .time_to_live(cache_ttl)
                .max_capacity(CACHE_CAPACITY)
                .build(),
            client: Self::build_client(allow_private_hosts),
            backoff_cfg,
            metrics,
            network,
            allow_private_hosts,
        }
    }

    /// Build the HTTP client for token-list fetches. Always applies a
    /// whole-request timeout and a bounded redirect policy; when private
    /// hosts are disallowed, DNS resolution additionally goes through
    /// [`url_guard::PublicOnlyDnsResolver`] so redirects and DNS-rebinding
    /// cannot smuggle the client into the internal network.
    fn build_client(allow_private_hosts: bool) -> Client {
        let builder = Client::builder()
            .timeout(TOKEN_LIST_FETCH_TIMEOUT)
            .user_agent(USER_AGENT)
            .redirect(url_guard::redirect_policy(allow_private_hosts));

        let builder = if allow_private_hosts {
            builder
        } else {
            builder.dns_resolver(Arc::new(url_guard::PublicOnlyDnsResolver))
        };

        builder.build().expect("token-list http client")
    }

    /// Fetches the given token lists, filters them down to the fetcher's active
    /// network and returns the union of all token addresses across the lists.
    ///
    /// Caching and in-flight de-duplication are delegated to [`moka`]: per-URL
    /// results are cached with a TTL, and concurrent requests for the same URL
    /// are coalesced into a single fetch.
    ///
    /// Fails fast: if any list fails to load (after retries), the whole call
    /// returns an error. This is intentional — clients must receive every
    /// requested token, otherwise we cannot rely on the reported balances.
    /// A failed fetch is not cached, so a subsequent call retries it.
    pub async fn get_tokens(&self, urls: &[String]) -> Result<ChainTokens, FetcherError> {
        let t0 = Instant::now();

        let token_lists_handlers = urls.iter().map(|url| {
            let url_clone = url.clone();

            async move {
                self.cache
                    .try_get_with(
                        url_clone.clone(),
                        self.fetch_list_and_filter_by_chain(&url_clone),
                    )
                    .await
            }
        });

        let result = try_join_all(token_lists_handlers).await;

        // Whole-request resolution latency (all lists, cache hits included).
        // Recorded on both paths so a failing set is still visible.
        self.metrics
            .token_lists_resolve_duration_ms
            .record(t0.elapsed().as_millis() as f64);

        let tokens = result.map_err(|err| (*err).clone())?.into_iter().flatten();
        Ok(tokens.collect())
    }

    async fn fetch_list_and_filter_by_chain(&self, url: &str) -> Result<ChainTokens, FetcherError> {
        url_guard::validate_url(url, self.allow_private_hosts).map_err(|reason| {
            self.metrics.token_list_url_rejected_total.increment(1);
            tracing::warn!(url, reason, "token list url rejected by ssrf guard");
            FetcherError::UrlNotAllowed(url.into(), reason)
        })?;

        let network = self.network;
        let tokens = self.fetch_list(url).await?.tokens;

        let mut invalid_count = 0usize;
        let mut invalid_samples: Vec<String> = Vec::new();
        let token_set: ChainTokens = tokens
            .into_iter()
            .filter_map(|raw| {
                let token: RawToken = serde_json::from_value(raw).ok()?;
                if token.chain_id != network.chain_id() {
                    return None;
                }
                match token.address.parse::<Address>() {
                    Ok(address) => Some(address),
                    Err(_) => {
                        invalid_count += 1;
                        if invalid_samples.len() < INVALID_ADDRESS_LOG_SAMPLES {
                            // char-capped: the value is attacker-suppliable and
                            // must not dump megabytes into a log line
                            invalid_samples
                                .push(token.address.chars().take(MAX_SAMPLE_CHARS).collect());
                        }
                        None
                    }
                }
            })
            .collect();

        if invalid_count > 0 {
            self.metrics
                .token_list_invalid_addresses_total
                .increment(invalid_count as u64);
            tracing::warn!(
                url,
                skipped = invalid_count,
                samples = ?invalid_samples,
                "token list entries on the active chain had unparseable addresses; skipped"
            );
        }

        Ok(token_set)
    }

    /// Fetch, download and parse a single list. Reached only on a cache miss
    /// (moka runs this once per uncached URL), so the metrics and the log
    /// below fire per actual network load, never for a cache hit — exactly
    /// one line per outcome, naming the URL either way.
    async fn fetch_list(&self, url: &str) -> Result<ApiResponse, FetcherError> {
        let t0 = Instant::now();
        let outcome = self.load_and_parse(url).await;
        let elapsed_ms = t0.elapsed().as_millis() as f64;

        match &outcome {
            Ok((_, bytes)) => {
                self.metrics.token_list_loaded_total.increment(1);
                self.metrics.token_list_loaded_time_in_ms.record(elapsed_ms);
                tracing::info!(
                    url = %url,
                    time_ms = elapsed_ms as u64,
                    bytes = *bytes,
                    "token list loaded"
                );
            }
            Err(err) => {
                self.metrics.token_list_load_failed_total.increment(1);
                tracing::warn!(
                    url = %url,
                    time_ms = elapsed_ms as u64,
                    error = %err,
                    "token list load failed"
                );
            }
        }

        outcome.map(|(parsed, _)| parsed)
    }

    /// Transport (with retries) + capped body download + JSON parse for one
    /// list. Returns the parsed response and the raw body size; every failure
    /// surfaces as [`FetcherError::UnableToLoadList`] carrying the URL and the
    /// underlying reason (which [`Self::fetch_list`] logs).
    async fn load_and_parse(&self, url: &str) -> Result<(ApiResponse, usize), FetcherError> {
        let response = self.fetch_with_backoff(url).await?;

        let body = Self::read_body_capped(response, MAX_TOKEN_LIST_RESPONSE_BYTES)
            .await
            .map_err(|err| FetcherError::UnableToLoadList(url.into(), err))?;

        let parsed: ApiResponse = serde_json::from_slice(&body)
            .map_err(|err| FetcherError::UnableToLoadList(url.into(), err.to_string()))?;

        Ok((parsed, body.len()))
    }

    /// Read a response body while enforcing `cap` — both up front via
    /// `Content-Length` and incrementally while streaming, so a body without
    /// (or lying about) the header still cannot grow past the cap.
    async fn read_body_capped(response: Response, cap: usize) -> Result<Vec<u8>, String> {
        if let Some(len) = response.content_length() {
            if len > cap as u64 {
                return Err(format!(
                    "token list response too large: {len} bytes (cap: {cap})"
                ));
            }
        }

        let mut body: Vec<u8> = Vec::new();
        let mut stream = response.bytes_stream();
        while let Some(chunk) = stream.next().await {
            let chunk = chunk.map_err(|err| err.to_string())?;
            if body.len() + chunk.len() > cap {
                return Err(format!("token list response exceeded {cap} bytes cap"));
            }
            body.extend_from_slice(&chunk);
        }

        Ok(body)
    }

    async fn fetch_with_backoff(&self, url: &str) -> Result<Response, FetcherError> {
        // Failure accounting (metric + warn) is centralised in `fetch_list`,
        // so this only maps the transport error into the domain error.
        (|| async { self.client.get(url).send().await?.error_for_status() })
            .retry(self.backoff_cfg)
            .await
            .map_err(|err| FetcherError::UnableToLoadList(url.into(), err.to_string()))
    }
}

#[cfg(test)]
mod token_list_fetcher_tests {
    use super::*;
    use wiremock::matchers::method;
    use wiremock::{Mock, MockServer, ResponseTemplate};

    const BACK_OFFS: u64 = 3;

    fn make_token_list_resp_template(tokens: Vec<(u64, Address)>) -> ResponseTemplate {
        let token_list = serde_json::json!({
            "tokens": tokens.iter().map(|(chain_id, address)| {
                serde_json::json!({ "chainId": chain_id, "address": address })
            }).collect::<Vec<_>>()
        });

        ResponseTemplate::new(200).set_body_json(token_list)
    }

    fn make_token_list(chain_ids: Vec<u64>, len: usize) -> Vec<(u64, Address)> {
        chain_ids
            .into_iter()
            .flat_map(|chain_id| (0..len).map(move |_| (chain_id, Address::random())))
            .collect()
    }

    fn make_error_resp_template() -> ResponseTemplate {
        let error = serde_json::json!({
            "message": "unavailable"
        });

        ResponseTemplate::new(500).set_body_json(error)
    }

    fn make_fetcher() -> Arc<TokenListFetcher> {
        let back_off = ExponentialBuilder::default()
            .with_min_delay(Duration::from_millis(1))
            .with_max_delay(Duration::from_millis(20))
            .with_max_times(BACK_OFFS as usize)
            .with_jitter();

        // wiremock serves from 127.0.0.1 — private hosts must be allowed here
        Arc::new(TokenListFetcher::new(
            Duration::from_millis(300),
            back_off,
            Arc::new(Metrics::install()),
            EvmNetwork::Eth,
            true,
        ))
    }

    #[tokio::test]
    async fn test_fail_backoffs() {
        let server = MockServer::start().await;

        let resp_template = make_error_resp_template();
        let retries = BACK_OFFS + 1;
        Mock::given(method("GET"))
            .respond_with(resp_template)
            .expect(retries)
            .mount(&server)
            .await;

        let fetcher = make_fetcher();
        let result = Arc::clone(&fetcher).get_tokens(&[server.uri()]).await;

        assert!(result.is_err());
    }

    #[tokio::test]
    async fn test_fail_and_success_after() {
        let server = MockServer::start().await;

        // fail case
        let resp_template = make_error_resp_template();
        let retries = BACK_OFFS + 1;
        Mock::given(method("GET"))
            .respond_with(resp_template)
            .up_to_n_times(retries)
            .with_priority(1)
            .mount(&server)
            .await;

        let fetcher = make_fetcher();
        let result = Arc::clone(&fetcher).get_tokens(&[server.uri()]).await;

        assert!(result.is_err());

        // success after if there is a new client
        let resp_template = make_token_list_resp_template(vec![]);
        Mock::given(method("GET"))
            .respond_with(resp_template)
            .with_priority(2)
            .expect(1)
            .mount(&server)
            .await;

        let response = Arc::clone(&fetcher).get_tokens(&[server.uri()]).await;
        assert!(response.is_ok());
    }

    #[tokio::test]
    async fn test_cache() {
        let server = MockServer::start().await;
        let token_list = make_token_list(vec![1, 2, 100], 3);
        let network = EvmNetwork::Eth;
        let expected_list_by_chain: HashSet<_> = token_list
            .clone()
            .into_iter()
            .filter_map(|(chain_id, address)| {
                if chain_id == network.chain_id() {
                    Some(address)
                } else {
                    None
                }
            })
            .collect();

        let resp_template = make_token_list_resp_template(token_list.clone());
        Mock::given(method("GET"))
            .respond_with(resp_template)
            .expect(2)
            .mount(&server)
            .await;

        let fetcher = make_fetcher();
        // warm up cache
        let _ = Arc::clone(&fetcher)
            .get_tokens(&[server.uri()])
            .await
            .unwrap();

        // cache is still valid
        tokio::time::sleep(Duration::from_millis(100)).await;

        let tokens = Arc::clone(&fetcher)
            .get_tokens(&[server.uri()])
            .await
            .unwrap();

        assert_eq!(expected_list_by_chain, tokens);

        // invalidate cache
        tokio::time::sleep(Duration::from_millis(200)).await;

        let tokens = Arc::clone(&fetcher)
            .get_tokens(&[server.uri()])
            .await
            .unwrap();

        assert_eq!(expected_list_by_chain, tokens);
    }

    /// Regression: tokens.uniswap.org started carrying Solana entries
    /// (chainId 501000101, base58 addresses). Strict typed deserialization
    /// used to fail the entire list on the first such entry — and with it
    /// every session that referenced the list.
    #[tokio::test]
    async fn test_non_evm_entries_do_not_fail_the_list() {
        let server = MockServer::start().await;
        let evm_token = Address::random();

        let body = serde_json::json!({
            "tokens": [
                { "chainId": 1, "address": evm_token, "symbol": "OK" },
                // real-world Solana entry shape from tokens.uniswap.org
                {
                    "chainId": 501000101,
                    "address": "5mbK36SZ7J19An8jFochhQS4of8g6BwUjbeCSxBSoWdp",
                    "symbol": "$MICHI",
                    "decimals": 6
                },
                // active chain but unparseable address — skipped, not fatal
                { "chainId": 1, "address": "not-an-address" },
                // malformed entry with no address at all
                { "chainId": 1 }
            ]
        });
        Mock::given(method("GET"))
            .respond_with(ResponseTemplate::new(200).set_body_json(body))
            .expect(1)
            .mount(&server)
            .await;

        let fetcher = make_fetcher();
        let tokens = Arc::clone(&fetcher)
            .get_tokens(&[server.uri()])
            .await
            .unwrap();

        assert_eq!(tokens, HashSet::from([evm_token]));
    }

    #[tokio::test]
    async fn test_concurrent_request_deduplication() {
        let server = MockServer::start().await;
        let token_list = make_token_list(vec![1, 2, 100], 3);

        let resp_template = make_token_list_resp_template(token_list.clone());
        Mock::given(method("GET"))
            .respond_with(resp_template)
            .expect(1)
            .mount(&server)
            .await;

        let fetcher = make_fetcher();

        let handlers: Vec<_> = (0..10)
            .map(|_| {
                let urls = [server.uri()];
                let fetcher = Arc::clone(&fetcher);
                tokio::spawn(async move { fetcher.get_tokens(&urls).await })
            })
            .collect();

        for handler in handlers {
            let result = handler.await;
            assert!(result.is_ok());
        }
    }
}
