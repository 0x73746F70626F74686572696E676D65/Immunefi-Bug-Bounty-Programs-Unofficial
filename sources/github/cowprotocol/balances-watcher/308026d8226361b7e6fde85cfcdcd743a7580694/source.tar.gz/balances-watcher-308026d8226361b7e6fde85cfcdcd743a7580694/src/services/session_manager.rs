use crate::config::back_off_config::get_token_list_fetcher_backoff;
use crate::domain::{BalanceEvent, EvmNetwork, Session};
use crate::graceful_shutdown::LifeCycle;
use crate::metrics::Metrics;
use crate::services::block_watcher::BlockWatcher;
use crate::services::cleanup_stream;
use crate::services::event_dispatcher::{Erc20TransferEvent, Erc20TransferEventDispatcher};
use crate::services::health::AppHealth;
use crate::services::rpc_client::RpcClient;
use crate::services::snapshot_updater::SnapshotUpdater;
use crate::services::subscription_manager::{SubscriptionError, SubscriptionManager};
use crate::services::token_list_fetcher::{FetcherError, TokenListFetcher};
use crate::ws_connection::WsConnection;
use alloy::primitives::Address;
use alloy::transports::http::reqwest::StatusCode;
use axum::response::sse::{Event, KeepAlive};
use axum::response::{IntoResponse, Response, Sse};
use axum::Json;
use futures::stream;
use futures::Stream;
use futures::StreamExt;
use serde::Serialize;
use std::collections::{HashMap, HashSet};
use std::convert::Infallible;
use std::sync::Arc;
use std::time::Duration;
use tokio::sync::{broadcast, mpsc};
use tokio_stream::wrappers::BroadcastStream;

const TOKEN_LIST_CACHE_TTL: Duration = Duration::from_hours(5);

/// State for [`SessionManager::broadcast_events_with_lag_close`]'s `unfold`.
/// `Closed` is entered right after the lag-close event so the very next poll
/// ends the stream.
enum LagCloseState {
    Streaming(BroadcastStream<BalanceEvent>),
    Closed,
}

pub struct SessionConfig {
    // interval for multicall for the whole watched token list
    pub snapshot_interval: usize,
    // how many tokens we watch regarding session
    pub token_limit: usize,
    // network that manager handles
    pub active_network: EvmNetwork,
    // allow token-list URLs on private/loopback hosts (local dev & tests only)
    pub allow_private_token_lists: bool,
}

/// Per-network session orchestrator.
///
/// One `SessionManager` exists per process — the service is single-network, so
/// the balance fetcher and WS connection pool are owned directly here (no
/// network → resource lookup map). Responsibilities:
/// - fetch & cache token lists
/// - spawn watchers for new sessions
/// - update watched token sets on session updates
/// - bridge subscription events to SSE clients
pub struct SessionManager {
    sub_manager: Arc<SubscriptionManager>,
    rpc_client: Arc<RpcClient>,
    fetcher: Arc<TokenListFetcher>,
    event_dispatcher: Arc<Erc20TransferEventDispatcher>,
    block_watcher: Arc<BlockWatcher>,
    lifecycle: LifeCycle,
    metrics: Arc<Metrics>,
    config: SessionConfig,
}

pub struct SessionContext {
    pub session: Session,
    pub custom_tokens: Vec<Address>,
    pub tokens_lists_urls: Vec<String>,
}

#[derive(Serialize)]
pub struct StreamError {
    pub code: u16,
    pub message: String,
}

impl StreamError {
    pub fn new(code: u16, message: String) -> StreamError {
        StreamError { code, message }
    }
    pub fn from(err: SessionError) -> StreamError {
        match err {
            SessionError::SessionIsNotCreated => {
                StreamError::new(404, String::from("Session is not created"))
            }
            _ => StreamError::new(500, String::from("Internal server error")),
        }
    }
}

impl IntoResponse for StreamError {
    fn into_response(self) -> Response {
        let status = StatusCode::from_u16(self.code).unwrap_or(StatusCode::INTERNAL_SERVER_ERROR);

        (status, Json(self)).into_response()
    }
}

#[derive(Clone, Debug, thiserror::Error)]
pub enum SessionError {
    #[error("Token list not found: {0}")]
    TokenListNotFound(String),

    #[error("Token list url not allowed: {0} ({1})")]
    TokenListUrlNotAllowed(String, String),

    #[error("Token limit exceeded, max count is {0}, current count is {1}")]
    TokenLimitExceeded(usize, usize),

    #[error("Session is not created")]
    SessionIsNotCreated,

    #[error("Too many client_ids for this owner (limit: {0})")]
    OwnerClientLimitExceeded(usize),
}

impl SessionManager {
    pub fn spawn(
        rpc_client: Arc<RpcClient>,
        metrics: Arc<Metrics>,
        lifecycle: LifeCycle,
        config: SessionConfig,
        ws_url: String,
    ) -> Arc<Self> {
        let token_list_fetcher = TokenListFetcher::new(
            TOKEN_LIST_CACHE_TTL,
            get_token_list_fetcher_backoff(),
            Arc::clone(&metrics),
            config.active_network,
            config.allow_private_token_lists,
        );

        let sub_manager = Arc::new(SubscriptionManager::new(
            Arc::clone(&metrics),
            Arc::clone(&rpc_client),
            lifecycle.clone(),
        ));
        Arc::clone(&sub_manager).spawn_cleanup();

        // dedicated WS socket for `newHeads`
        let block_ws =
            WsConnection::new(ws_url, Arc::clone(&metrics), lifecycle.cancel_token.clone());

        let (block_watcher, block_head_rx) = BlockWatcher::spawn(
            config.active_network,
            Arc::clone(&metrics),
            lifecycle.clone(),
            block_ws,
            Arc::clone(&rpc_client),
        );

        let (tx, rx) = mpsc::channel::<Erc20TransferEvent>(256);
        let event_dispatcher = Erc20TransferEventDispatcher::spawn(
            config.active_network,
            Arc::clone(&metrics),
            Arc::clone(&rpc_client),
            Arc::clone(&block_watcher),
            block_head_rx,
            lifecycle.clone(),
            tx,
        );

        let manager = Arc::new(Self {
            sub_manager: Arc::clone(&sub_manager),
            event_dispatcher,
            block_watcher,
            fetcher: Arc::new(token_list_fetcher),
            rpc_client,
            lifecycle,
            metrics,
            config,
        });

        Arc::clone(&manager).spawn_erc20_transfer_listener(rx);

        manager
    }

    pub async fn upsert(self: Arc<Self>, ctx: SessionContext) -> Result<(), SessionError> {
        let session = ctx.session;

        // Single-network instance: the fetcher & ws pool are pre-bound. No
        // session-time lookup, no "provider not defined" branch.
        let rpc_client = Arc::clone(&self.rpc_client);

        let new_watched_tokens = Arc::clone(&self)
            .fetch_and_extend_tokens(session, ctx.tokens_lists_urls, ctx.custom_tokens)
            .await?;

        if new_watched_tokens.len() > self.config.token_limit {
            self.metrics.tokens_limit_exceeded_total.increment(1);
            tracing::warn!(
                tokens_len = new_watched_tokens.len(),
                limit = self.config.token_limit,
                "client request rejected: watched-token limit exceeded",
            );
            return Err(SessionError::TokenLimitExceeded(
                new_watched_tokens.len(),
                self.config.token_limit,
            ));
        }

        let (sub, maybe_queue_rx_out) = self
            .sub_manager
            .upsert(session, new_watched_tokens)
            .await
            .map_err(Self::map_subscription_error)?;

        if let Some(queue_result_rx) = maybe_queue_rx_out {
            tracing::debug!(
                session = %session,
                "upsert: spawning watchers"
            );

            let snapshot_updater = Arc::new(SnapshotUpdater::new(
                self.lifecycle.task_tracker.clone(),
                rpc_client,
                sub,
                Arc::clone(&self.metrics),
                session,
                Arc::clone(&self.block_watcher),
            ));

            snapshot_updater
                .spawn_watchers(queue_result_rx, self.config.snapshot_interval)
                .await;

            tracing::debug!(
                session = %session,
                "upsert: watchers spawned"
            );
        }

        Ok(())
    }

    /// Aggregate health across all owned subsystems. Consumed by `/health`
    /// to log the exact failing reason before returning 503.
    pub fn health_status(&self) -> AppHealth {
        AppHealth {
            block_watcher: self.block_watcher.health_status(),
            event_dispatcher: self.event_dispatcher.health_status(),
        }
    }

    fn spawn_erc20_transfer_listener(
        self: Arc<Self>,
        mut receiver: mpsc::Receiver<Erc20TransferEvent>,
    ) {
        Arc::clone(&self).lifecycle.task_tracker.spawn(async move {
            let this = Arc::clone(&self);
            loop {
                let this = Arc::clone(&this);

                tokio::select! {
                    _ = this.lifecycle.cancel_token.cancelled() => break,
                    next = receiver.recv() => {
                        match next {
                            Some(event) => {
                                let queues = this
                                    .sub_manager
                                    .owned_queues_watching(&event.owner, &event.token)
                                    .await;

                                // Fan out the Transfer to every session on this
                                // owner. With `Session = (network, owner, client_id)`
                                // one owner can hold N sessions and each has its own
                                // per-session refresh queue → we enqueue into all of
                                // them; a slow queue must not delay the others, so
                                // we drive the sends in parallel.
                                //
                                // Yes, this is deliberate RPC amplification (N
                                // multicalls per Transfer when N devices watch the
                                // same wallet). Kept as-is for now because snapshot
                                // fetching is tightly coupled to per-session state
                                // (watched-token set, broadcast tx, snapshot updater).
                                // The right long-term fix is to lift the snapshot
                                // layer out of the subscription: dedupe watched
                                // tokens per-owner, run one multicall against the
                                // union, and fan the results back into per-session
                                // broadcasts. That's a separate rework — tracked as
                                // a follow-up, not blocking the client_id change.
                                futures::future::join_all(
                                    queues.iter().map(|q| q.enqueue(event.token, event.block)),
                                )
                                .await;
                            },
                            None => break,
                        }
                    }
                }
            }
        });
    }

    // fetch tokens from lists and add weth9 as watched
    async fn fetch_and_extend_tokens(
        self: Arc<Self>,
        session: Session,
        token_lists_urls: Vec<String>,
        custom_tokens: Vec<Address>,
    ) -> Result<HashSet<Address>, SessionError> {
        let token_list_fetcher = Arc::clone(&self.fetcher);

        let mut tokens = token_list_fetcher
            .get_tokens(&token_lists_urls)
            .await
            .map_err(|err| match err {
                FetcherError::UnableToLoadList(url, _) => SessionError::TokenListNotFound(url),
                FetcherError::UrlNotAllowed(url, reason) => {
                    SessionError::TokenListUrlNotAllowed(url, reason)
                }
            })?;
        tokens.extend(custom_tokens);
        // token lists doesn't contain weth9 address, we always should insert it
        tokens.insert(session.network.weth9_address());
        // native token tracking is intentionally not supported by this service.
        // Clients (and some token lists) commonly include the native sentinel
        // (0xEee…EEeE) alongside ERC20 addresses; strip it once here so it
        // never reaches `balanceOf` downstream.
        if tokens.remove(&session.network.native_token_address()) {
            tracing::debug!(
                session = %session,
                "dropped native token sentinel from watched set"
            );
        }

        Ok(tokens)
    }

    fn balance_event_to_sse(event: BalanceEvent) -> Result<Event, axum::Error> {
        #[derive(Serialize)]
        struct BalancesResponse {
            balances: HashMap<Address, String>,
        }
        #[derive(Serialize)]
        struct ErrorEvent {
            code: u16,
            message: String,
        }

        match event {
            BalanceEvent::BalanceUpdate(balances) => Event::default()
                .event("balance_update")
                .json_data(BalancesResponse { balances }),
            BalanceEvent::Error { code, message } => Event::default()
                .event("error")
                .json_data(ErrorEvent { code, message }),
        }
    }

    /// Bridge the per-session broadcast channel into a stream of
    /// [`BalanceEvent`]s, converting a broadcast `Lagged` into a clean close.
    ///
    /// The wire protocol is snapshot-then-diffs: the initial snapshot is sent
    /// once and diffs are never re-sent. If a slow client's receiver overflows
    /// the broadcast ring buffer, those diffs are lost for good — the server's
    /// snapshot has already advanced, so the periodic refresh won't re-emit
    /// them either. Silently continuing would leave the client permanently
    /// stale. Instead we emit one `Error { code: 503 }` event and end the
    /// stream, so the client reconnects and is re-seeded with a full snapshot.
    fn broadcast_events_with_lag_close(
        rx: broadcast::Receiver<BalanceEvent>,
        metrics: Arc<Metrics>,
        session: Session,
    ) -> impl Stream<Item = BalanceEvent> {
        stream::unfold(
            LagCloseState::Streaming(BroadcastStream::new(rx)),
            move |state| {
                let metrics = Arc::clone(&metrics);
                async move {
                    let mut stream = match state {
                        LagCloseState::Closed => return None,
                        LagCloseState::Streaming(stream) => stream,
                    };

                    match stream.next().await {
                        // Sender dropped (session reaped) — end the stream.
                        None => None,
                        Some(Ok(event)) => Some((event, LagCloseState::Streaming(stream))),
                        Some(Err(err)) => {
                            metrics.broadcast_lagged_total.increment(1);
                            tracing::warn!(
                                error = %err,
                                session = %session,
                                "sse client lagged behind broadcast, closing stream to force reconnect",
                            );
                            let close_event = BalanceEvent::Error {
                                code: 503,
                                message: "event stream lagged; reconnect for a fresh snapshot"
                                    .into(),
                            };
                            Some((close_event, LagCloseState::Closed))
                        }
                    }
                }
            },
        )
    }

    pub async fn create_sse_connection(
        self: Arc<Self>,
        session: Session,
    ) -> Result<Sse<impl Stream<Item = Result<Event, Infallible>>>, StreamError> {
        let (rx, subscription) = self.sub_manager.subscribe(session).await.map_err(|err| {
            let err = Self::map_subscription_error(err);
            StreamError::from(err)
        })?;

        let balance_snapshot = subscription.current_snapshot().await;

        // Build an initial stream that delivers the snapshot directly to this client only,
        // avoiding a broadcast that would redundantly push to all existing subscribers.
        let initial_stream = if balance_snapshot.is_empty() {
            tracing::debug!(
                session = %session,
                "balance snapshot is empty"
            );
            stream::iter(vec![])
        } else {
            tracing::debug!(
                session = %session,
                "sending first balance snapshot to new sse connection (full)"
            );

            let balance_snapshot: HashMap<Address, String> = balance_snapshot
                .into_iter()
                .map(|(address, balance)| (address, balance.amount.to_string()))
                .collect();
            let event = BalanceEvent::BalanceUpdate(balance_snapshot);

            match Self::balance_event_to_sse(event) {
                Ok(sse_event) => stream::iter(vec![Ok(sse_event)]),
                Err(err) => {
                    tracing::error!(
                        error = %err,
                        "failed to serialize initial snapshot as sse event",
                    );
                    stream::iter(vec![])
                }
            }
        };

        let manager_for_cleanup = Arc::clone(&self.sub_manager);
        let metrics = Arc::clone(&self.metrics);

        let broadcast_stream = Self::broadcast_events_with_lag_close(rx, metrics, session)
            .filter_map(move |event| async move {
                match Self::balance_event_to_sse(event) {
                    Ok(sse_event) => Some(Ok(sse_event)),
                    Err(err) => {
                        tracing::error!(
                            error = %err,
                            "failed to serialize balance event as sse event",
                        );
                        None
                    }
                }
            });

        let sse_stream = initial_stream.chain(broadcast_stream);

        let cleanup_stream =
            cleanup_stream::CleanupStream::new(sse_stream, manager_for_cleanup, session);

        Ok(Sse::new(cleanup_stream).keep_alive(KeepAlive::default()))
    }

    fn map_subscription_error(sub_error: SubscriptionError) -> SessionError {
        match sub_error {
            SubscriptionError::SessionNotRegistered => SessionError::SessionIsNotCreated,
            SubscriptionError::OwnerClientLimitExceeded { limit } => {
                SessionError::OwnerClientLimitExceeded(limit)
            }
        }
    }
}

#[cfg(test)]
mod broadcast_lag_tests {
    //! Regression tests for the lagged-SSE-client fix.
    //!
    //! Diffs are broadcast once and never re-sent, so a client whose receiver
    //! overflows the broadcast ring buffer used to silently miss updates and
    //! drift permanently stale (the old code logged a warning and dropped the
    //! events). The stream must instead emit a single 503 close event and end,
    //! so the client reconnects for a fresh snapshot.

    use super::*;
    use crate::domain::EvmNetwork;
    use uuid::Uuid;

    fn test_session() -> Session {
        Session {
            owner: Address::ZERO,
            network: EvmNetwork::Eth,
            client_id: Uuid::from_u128(1),
        }
    }

    fn balance_update_event(n: u8) -> BalanceEvent {
        let mut balances = HashMap::new();
        balances.insert(Address::from([n; 20]), n.to_string());
        BalanceEvent::BalanceUpdate(balances)
    }

    /// The regression: overflow the ring buffer, then the stream must yield
    /// exactly one 503 error event and stop — no silent drop, no further
    /// events.
    #[tokio::test]
    async fn lagged_client_gets_close_event_then_stream_ends() {
        let metrics = Arc::new(Metrics::install());
        // Tiny buffer so we can overflow it deterministically.
        let (tx, rx) = broadcast::channel(4);

        // Send more than capacity with nobody draining: the receiver falls
        // behind by more than the buffer, so its first recv yields `Lagged`.
        for i in 0..8u8 {
            tx.send(balance_update_event(i)).expect("receiver is alive");
        }

        let events: Vec<BalanceEvent> =
            SessionManager::broadcast_events_with_lag_close(rx, metrics, test_session())
                .collect()
                .await;

        assert_eq!(
            events.len(),
            1,
            "lagged stream must yield only the close event, got {events:?}"
        );
        match &events[0] {
            BalanceEvent::Error { code, .. } => assert_eq!(*code, 503),
            other => panic!("expected a 503 error close event, got {other:?}"),
        }
    }

    /// A client that keeps up receives every diff in order, and the stream
    /// ends cleanly when the sender is dropped — no spurious close event.
    #[tokio::test]
    async fn healthy_client_receives_all_events_without_close() {
        let metrics = Arc::new(Metrics::install());
        let (tx, rx) = broadcast::channel(16);

        for i in 0..3u8 {
            tx.send(balance_update_event(i)).expect("receiver is alive");
        }
        drop(tx); // no more events → the stream should end on its own

        let events: Vec<BalanceEvent> =
            SessionManager::broadcast_events_with_lag_close(rx, metrics, test_session())
                .collect()
                .await;

        assert_eq!(
            events.len(),
            3,
            "every in-capacity event must pass through untouched"
        );
        for event in &events {
            match event {
                BalanceEvent::BalanceUpdate(_) => {}
                other => panic!("healthy stream must not inject a close event: {other:?}"),
            }
        }
    }
}
