//! The [`Env`] handle stitches anvil + service + token-list server together.
//! Each test spawns its own [`Env`] to keep on-chain state isolated.

use alloy::network::EthereumWallet;
use alloy::node_bindings::AnvilInstance;
use alloy::primitives::{Address, U256};
use alloy::providers::DynProvider;
use alloy::signers::local::PrivateKeySigner;
use balances_watcher::config::network_config::NetworkConfig;
use balances_watcher::domain::EvmNetwork;
use balances_watcher::graceful_shutdown::LifeCycle;
use balances_watcher::metrics::Metrics;
use balances_watcher::spawn_server;
use metrics_exporter_prometheus::{PrometheusBuilder, PrometheusHandle};
use std::sync::{Arc, OnceLock};
use std::time::Duration;
use tokio_util::sync::CancellationToken;

use super::api::start_token_list_server;
use super::onchain::{
    install_infrastructure, spawn_anvil, Weth9, CUSTOM_TOKEN_ADDRESS, WETH9_ADDRESS,
};
use super::rpc_proxy::RpcProxy;

/// Prometheus recorder is a process-wide singleton — `install_recorder`
/// after the first successful call returns Err, but there's no way to fish
/// out the existing handle. Cache it here so every `Env::spawn` (and hence
/// every parallel test's `/metrics` endpoint) is backed by the same handle
/// that was actually installed.
static METRICS_HANDLE: OnceLock<PrometheusHandle> = OnceLock::new();

fn shared_metrics_handle() -> PrometheusHandle {
    METRICS_HANDLE
        .get_or_init(|| {
            PrometheusBuilder::new()
                .install_recorder()
                .expect("first-ever install_recorder should succeed")
        })
        .clone()
}

/// A live integration environment. Dropping it cancels the balances-watcher
/// service; the anvil child process is killed by `AnvilInstance::Drop`.
pub struct Env {
    pub anvil: AnvilInstance,
    pub provider: DynProvider,
    pub deployer: PrivateKeySigner,
    pub deployer_wallet: EthereumWallet,
    pub owner: Address,
    /// Base URL of the balances-watcher service (e.g. `http://127.0.0.1:XXXX`).
    pub service_url: String,
    /// Base URL of the in-process token-list server.
    pub token_list_url: String,
    _token_list_cancel: CancellationToken,
    service_lifecycle: LifeCycle,
}

impl Env {
    /// Full startup: anvil → infra bytecode → token-list server →
    /// balances-watcher service. Anything failing aborts the test with a
    /// pointed panic message.
    pub async fn spawn() -> Self {
        Self::spawn_with_network(EvmNetwork::Eth).await
    }

    /// Same as [`Self::spawn`] but with an explicit network. The network
    /// picks per-chain timings (`block_time`-derived stall timeout,
    /// `max_block_lag`) — timing-sensitive tests spawn a fast chain (e.g.
    /// Ink: 3s stall timeout) so they run in seconds instead of mainnet's
    /// 36s windows. Anvil doesn't care what chain we claim to be.
    pub async fn spawn_with_network(network: EvmNetwork) -> Self {
        let (env, _no_proxy) = Self::spawn_inner(network, false).await;
        env
    }

    /// Same as [`Self::spawn_with_network`], but the service's HTTP RPC is
    /// routed through a programmable fault-injection [`RpcProxy`]; the WS
    /// `newHeads` subscription stays wired straight to anvil. Lets tests
    /// degrade `eth_getLogs` (delays, range caps, poisoned blocks) while
    /// the chain keeps running honestly underneath — the shape of a real
    /// provider incident, where heads keep flowing over WS while the HTTP
    /// side struggles.
    pub async fn spawn_with_rpc_proxy(network: EvmNetwork) -> (Self, RpcProxy) {
        let (env, proxy) = Self::spawn_inner(network, true).await;
        (
            env,
            proxy.expect("spawn_inner(with_proxy = true) always builds a proxy"),
        )
    }

    async fn spawn_inner(network: EvmNetwork, with_proxy: bool) -> (Self, Option<RpcProxy>) {
        let (anvil, provider, deployer, deployer_wallet) = spawn_anvil().await;
        install_infrastructure(&provider).await;

        let proxy = if with_proxy {
            Some(RpcProxy::spawn(anvil.endpoint()).await)
        } else {
            None
        };
        let rpc_http_url = proxy
            .as_ref()
            .map(|proxy| proxy.url.clone())
            .unwrap_or_else(|| anvil.endpoint());

        let owner = deployer.address();
        let (token_list_url, _token_list_cancel) = start_token_list_server(WETH9_ADDRESS).await;

        let service_lifecycle = LifeCycle::spawn();
        let metrics_handler = shared_metrics_handle();
        let metrics = Arc::new(Metrics::install());

        let network_cfg = NetworkConfig {
            network,
            rpc_http_url,
            snapshot_interval: 5,
            max_watched_tokens_limit: 1500,
            // the in-process token-list server lives on 127.0.0.1
            allow_private_token_lists: true,
        };

        let server = spawn_server(
            "127.0.0.1:0",
            network_cfg,
            anvil.ws_endpoint(),
            metrics,
            metrics_handler,
            service_lifecycle.clone(),
        )
        .await
        .expect("spawn_server");

        // Let BlockWatcher establish its `newHeads` subscription before the
        // first POST, otherwise the snapshot updater parks and the initial
        // SSE `balance_update` races the connect.
        tokio::time::sleep(Duration::from_millis(1000)).await;

        let env = Self {
            service_url: format!("http://{}", server.local_addr),
            anvil,
            provider,
            deployer,
            deployer_wallet,
            owner,
            token_list_url,
            _token_list_cancel,
            service_lifecycle,
        };
        (env, proxy)
    }

    /// `WETH.deposit()` with `amount` wei attached. Triggers a Deposit log.
    pub async fn weth_deposit(&self, amount: U256) {
        Weth9::new(WETH9_ADDRESS, &self.provider)
            .deposit()
            .value(amount)
            .send()
            .await
            .expect("weth deposit send")
            .get_receipt()
            .await
            .expect("weth deposit receipt");
    }

    /// `WETH.withdraw(amount)`. Triggers a Withdrawal log.
    pub async fn weth_withdraw(&self, amount: U256) {
        Weth9::new(WETH9_ADDRESS, &self.provider)
            .withdraw(amount)
            .send()
            .await
            .expect("weth withdraw send")
            .get_receipt()
            .await
            .expect("weth withdraw receipt");
    }

    /// `WETH.transfer(to, amount)`. Triggers a Transfer log.
    pub async fn weth_transfer(&self, to: Address, amount: U256) {
        Weth9::new(WETH9_ADDRESS, &self.provider)
            .transfer(to, amount)
            .send()
            .await
            .expect("weth transfer send")
            .get_receipt()
            .await
            .expect("weth transfer receipt");
    }

    /// Mint balance on the throwaway custom ERC20 for the owner. The
    /// contract at `CUSTOM_TOKEN_ADDRESS` is a plain WETH9 clone, so
    /// `deposit()` is a convenient minting primitive.
    pub async fn custom_deposit(&self, amount: U256) {
        Weth9::new(CUSTOM_TOKEN_ADDRESS, &self.provider)
            .deposit()
            .value(amount)
            .send()
            .await
            .expect("custom deposit send")
            .get_receipt()
            .await
            .expect("custom deposit receipt");
    }

    /// `customToken.transfer(to, amount)`. Emits a standard ERC20 Transfer
    /// event, so the dispatcher path fires just like it would for any other
    /// watched token.
    pub async fn custom_transfer(&self, to: Address, amount: U256) {
        Weth9::new(CUSTOM_TOKEN_ADDRESS, &self.provider)
            .transfer(to, amount)
            .send()
            .await
            .expect("custom transfer send")
            .get_receipt()
            .await
            .expect("custom transfer receipt");
    }

    /// A second EOA to use as a Transfer destination — anvil pre-funds
    /// `keys()[1]` so we can use its address safely.
    pub fn peer_address(&self) -> Address {
        let signer: PrivateKeySigner = self.anvil.keys()[1].clone().into();
        signer.address()
    }

    /// Second pre-funded address distinct from `owner` — useful when a test
    /// wants two independent owners on the same chain.
    pub fn second_owner(&self) -> Address {
        let signer: PrivateKeySigner = self.anvil.keys()[2].clone().into();
        signer.address()
    }
}

impl Drop for Env {
    fn drop(&mut self) {
        self.service_lifecycle.cancel_token.cancel();
    }
}

/// Service-only environment: balances-watcher without anvil. The RPC
/// endpoints point at a closed local port and are never successfully
/// dialled — good enough for tests that exercise the HTTP surface without
/// touching the chain (URL-guard rejections and friends). Unlike [`Env`],
/// tests built on this don't need `#[ignore]` or foundry on PATH.
pub struct ServiceEnv {
    /// Base URL of the balances-watcher service (e.g. `http://127.0.0.1:XXXX`).
    pub service_url: String,
    lifecycle: LifeCycle,
}

impl ServiceEnv {
    pub async fn spawn(allow_private_token_lists: bool) -> Self {
        let lifecycle = LifeCycle::spawn();
        let metrics_handler = shared_metrics_handle();
        let metrics = Arc::new(Metrics::install());

        let network_cfg = NetworkConfig {
            network: EvmNetwork::Eth,
            // port 9 (discard) — connection-refused instantly, never answers
            rpc_http_url: "http://127.0.0.1:9".to_string(),
            snapshot_interval: 3600,
            max_watched_tokens_limit: 1500,
            allow_private_token_lists,
        };

        let server = spawn_server(
            "127.0.0.1:0",
            network_cfg,
            "ws://127.0.0.1:9".to_string(),
            metrics,
            metrics_handler,
            lifecycle.clone(),
        )
        .await
        .expect("spawn_server (service-only)");

        Self {
            service_url: format!("http://{}", server.local_addr),
            lifecycle,
        }
    }
}

impl Drop for ServiceEnv {
    fn drop(&mut self) {
        self.lifecycle.cancel_token.cancel();
    }
}
