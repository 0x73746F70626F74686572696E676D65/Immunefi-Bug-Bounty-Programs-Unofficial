# Changelog

## [1.2.8](https://github.com/cowprotocol/cow-sdk/compare/sdk-subgraph-v1.2.7...sdk-subgraph-v1.2.8) (2026-09-29)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.14.2
    * @cowprotocol/sdk-config bumped to 2.7.2

## [1.2.7](https://github.com/cowprotocol/cow-sdk/compare/sdk-subgraph-v1.2.6...sdk-subgraph-v1.2.7) (2026-09-25)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.14.1
    * @cowprotocol/sdk-config bumped to 2.7.1

## [1.2.6](https://github.com/cowprotocol/cow-sdk/compare/sdk-subgraph-v1.2.5...sdk-subgraph-v1.2.6) (2026-09-21)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.14.0

## [1.2.5](https://github.com/cowprotocol/cow-sdk/compare/sdk-subgraph-v1.2.4...sdk-subgraph-v1.2.5) (2026-09-18)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.13.1
    * @cowprotocol/sdk-config bumped to 2.7.0

## [1.2.4](https://github.com/cowprotocol/cow-sdk/compare/sdk-subgraph-v1.2.3...sdk-subgraph-v1.2.4) (2026-09-16)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.13.0

## [1.2.3](https://github.com/cowprotocol/cow-sdk/compare/sdk-subgraph-v1.2.2...sdk-subgraph-v1.2.3) (2026-09-07)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.12.3
    * @cowprotocol/sdk-config bumped to 2.6.0

## [1.2.2](https://github.com/cowprotocol/cow-sdk/compare/sdk-subgraph-v1.2.1...sdk-subgraph-v1.2.2) (2026-09-04)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.12.2
    * @cowprotocol/sdk-config bumped to 2.5.0

## [1.2.1](https://github.com/cowprotocol/cow-sdk/compare/sdk-subgraph-v1.2.0...sdk-subgraph-v1.2.1) (2026-07-29)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.12.1
    * @cowprotocol/sdk-config bumped to 2.4.0

## [1.2.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-subgraph-v1.1.2...sdk-subgraph-v1.2.0) (2026-06-15)


### ✨ Features

* per-package test coverage badges, updated in CI ([#895](https://github.com/cowprotocol/cow-sdk/issues/895)) ([c73246c](https://github.com/cowprotocol/cow-sdk/commit/c73246cc52c4fc79b2628b7c5f580695fd3dc1e2))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.12.0
    * @cowprotocol/sdk-config bumped to 2.3.1

## [1.1.2](https://github.com/cowprotocol/cow-sdk/compare/sdk-subgraph-v1.1.1...sdk-subgraph-v1.1.2) (2026-06-08)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.11.2
    * @cowprotocol/sdk-config bumped to 2.3.0

## [1.1.1](https://github.com/cowprotocol/cow-sdk/compare/sdk-subgraph-v1.1.0...sdk-subgraph-v1.1.1) (2026-06-02)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.11.1
    * @cowprotocol/sdk-config bumped to 2.2.1

## [1.1.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-subgraph-v1.0.8...sdk-subgraph-v1.1.0) (2026-05-27)


### ✨ Features

* move solana to supported chain id ([#873](https://github.com/cowprotocol/cow-sdk/issues/873)) ([da8a7c2](https://github.com/cowprotocol/cow-sdk/commit/da8a7c24cd07afcd465199844c480ebe3e81383d))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.11.0
    * @cowprotocol/sdk-config bumped to 2.2.0

## [1.0.8](https://github.com/cowprotocol/cow-sdk/compare/sdk-subgraph-v1.0.7...sdk-subgraph-v1.0.8) (2026-05-22)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.10.3
    * @cowprotocol/sdk-config bumped to 2.1.0

## [1.0.7](https://github.com/cowprotocol/cow-sdk/compare/sdk-subgraph-v1.0.6...sdk-subgraph-v1.0.7) (2026-04-16)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.10.2
    * @cowprotocol/sdk-config bumped to 2.0.0

## [1.0.6](https://github.com/cowprotocol/cow-sdk/compare/sdk-subgraph-v1.0.5...sdk-subgraph-v1.0.6) (2026-04-14)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.10.1
    * @cowprotocol/sdk-config bumped to 1.2.0

## [1.0.5](https://github.com/cowprotocol/cow-sdk/compare/sdk-subgraph-v1.0.4...sdk-subgraph-v1.0.5) (2026-04-08)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.10.0
    * @cowprotocol/sdk-config bumped to 1.1.3

## [1.0.4](https://github.com/cowprotocol/cow-sdk/compare/sdk-subgraph-v1.0.3...sdk-subgraph-v1.0.4) (2026-04-01)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.9.0

## [1.0.3](https://github.com/cowprotocol/cow-sdk/compare/sdk-subgraph-v1.0.2...sdk-subgraph-v1.0.3) (2026-03-17)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.8.2
    * @cowprotocol/sdk-config bumped to 1.1.2

## [1.0.2](https://github.com/cowprotocol/cow-sdk/compare/sdk-subgraph-v1.0.1...sdk-subgraph-v1.0.2) (2026-03-16)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.8.1
    * @cowprotocol/sdk-config bumped to 1.1.1

## [1.0.1](https://github.com/cowprotocol/cow-sdk/compare/sdk-subgraph-v1.0.0...sdk-subgraph-v1.0.1) (2026-03-16)


### 🔧 Miscellaneous

* release main ([#826](https://github.com/cowprotocol/cow-sdk/issues/826)) ([baaa708](https://github.com/cowprotocol/cow-sdk/commit/baaa7088ac15b89fb83310e54aa52f09d19132ff))
* release main ([#832](https://github.com/cowprotocol/cow-sdk/issues/832)) ([5dafcb8](https://github.com/cowprotocol/cow-sdk/commit/5dafcb8ec5593250dba1ff6e9fdbf8eb11d974cf))
* revert release ([#833](https://github.com/cowprotocol/cow-sdk/issues/833)) ([0c40a9b](https://github.com/cowprotocol/cow-sdk/commit/0c40a9b3ee828c7ede66576f02e1b571e96140cd))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.8.0
    * @cowprotocol/sdk-config bumped to 1.1.0

## [1.0.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-subgraph-v0.3.8...sdk-subgraph-v1.0.0) (2026-03-10)


### ⚠ BREAKING CHANGES

* **chains:** Remove support for Lens.

### ✨ Features

* **chains:** Remove Lens ([#818](https://github.com/cowprotocol/cow-sdk/issues/818)) ([e8c74a0](https://github.com/cowprotocol/cow-sdk/commit/e8c74a078e5940901591652164af7b2ffb7b1fa6))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.7.1
    * @cowprotocol/sdk-config bumped to 1.0.0

## [0.3.8](https://github.com/cowprotocol/cow-sdk/compare/sdk-subgraph-v0.3.7...sdk-subgraph-v0.3.8) (2026-03-04)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.7.0
    * @cowprotocol/sdk-config bumped to 0.10.0

## [0.3.7](https://github.com/cowprotocol/cow-sdk/compare/sdk-subgraph-v0.3.6...sdk-subgraph-v0.3.7) (2026-03-04)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.6.3
    * @cowprotocol/sdk-config bumped to 0.9.0

## [0.3.6](https://github.com/cowprotocol/cow-sdk/compare/sdk-subgraph-v0.3.5...sdk-subgraph-v0.3.6) (2026-02-20)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.6.2
    * @cowprotocol/sdk-config bumped to 0.8.1

## [0.3.5](https://github.com/cowprotocol/cow-sdk/compare/sdk-subgraph-v0.3.4...sdk-subgraph-v0.3.5) (2026-02-18)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.6.1
    * @cowprotocol/sdk-config bumped to 0.8.0

## [0.3.4](https://github.com/cowprotocol/cow-sdk/compare/sdk-subgraph-v0.3.3...sdk-subgraph-v0.3.4) (2026-02-05)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.6.0

## [0.3.3](https://github.com/cowprotocol/cow-sdk/compare/sdk-subgraph-v0.3.2...sdk-subgraph-v0.3.3) (2026-02-02)


### 🔧 Miscellaneous

* revert revert Ink network ([#789](https://github.com/cowprotocol/cow-sdk/issues/789)) ([a00dbbd](https://github.com/cowprotocol/cow-sdk/commit/a00dbbd6a26238bcee2d4452487d16551560c59f))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.5.4
    * @cowprotocol/sdk-config bumped to 0.7.3

## [0.3.2](https://github.com/cowprotocol/cow-sdk/compare/sdk-subgraph-v0.3.1...sdk-subgraph-v0.3.2) (2026-02-02)


### 🐛 Bug Fixes

* support decimals in protocolFeeBps ([#787](https://github.com/cowprotocol/cow-sdk/issues/787)) ([f53ae65](https://github.com/cowprotocol/cow-sdk/commit/f53ae65931d85e354779767ed67e0e4df944a2bc))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.5.3
    * @cowprotocol/sdk-config bumped to 0.7.2

## [0.3.1](https://github.com/cowprotocol/cow-sdk/compare/sdk-subgraph-v0.3.0...sdk-subgraph-v0.3.1) (2026-01-28)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.5.2
    * @cowprotocol/sdk-config bumped to 0.7.1

## [0.3.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-subgraph-v0.2.7...sdk-subgraph-v0.3.0) (2026-01-28)


### ✨ Features

* **ink:** reapply "feat/COW-163: Add Ink network ([#781](https://github.com/cowprotocol/cow-sdk/issues/781))" ([7c23332](https://github.com/cowprotocol/cow-sdk/commit/7c23332dac4f8c91d5f75ae68297906e20f20362))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.5.1
    * @cowprotocol/sdk-config bumped to 0.7.0

## [0.2.7](https://github.com/cowprotocol/cow-sdk/compare/sdk-subgraph-v0.2.6...sdk-subgraph-v0.2.7) (2026-01-19)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.5.0
    * @cowprotocol/sdk-config bumped to 0.6.3

## [0.2.6](https://github.com/cowprotocol/cow-sdk/compare/sdk-subgraph-v0.2.5...sdk-subgraph-v0.2.6) (2025-12-11)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-config bumped to 0.6.2

## [0.2.5](https://github.com/cowprotocol/cow-sdk/compare/sdk-subgraph-v0.2.4...sdk-subgraph-v0.2.5) (2025-12-05)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-config bumped to 0.6.1

## [0.2.4](https://github.com/cowprotocol/cow-sdk/compare/sdk-subgraph-v0.2.3...sdk-subgraph-v0.2.4) (2025-12-04)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-config bumped to 0.6.0

## [0.2.3](https://github.com/cowprotocol/cow-sdk/compare/sdk-subgraph-v0.2.2...sdk-subgraph-v0.2.3) (2025-12-03)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-config bumped to 0.5.0

## [0.2.2](https://github.com/cowprotocol/cow-sdk/compare/sdk-subgraph-v0.2.1...sdk-subgraph-v0.2.2) (2025-11-27)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-config bumped to 0.4.1

## [0.2.1](https://github.com/cowprotocol/cow-sdk/compare/sdk-subgraph-v0.2.0...sdk-subgraph-v0.2.1) (2025-11-24)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.4.0
    * @cowprotocol/sdk-config bumped to 0.4.0

## [0.2.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-subgraph-v0.1.4...sdk-subgraph-v0.2.0) (2025-11-05)


### ✨ Features

* **new-chains:** add q4 chains ([#606](https://github.com/cowprotocol/cow-sdk/issues/606)) ([2501382](https://github.com/cowprotocol/cow-sdk/commit/2501382e80acb7f6bb0f87adbb5a9325de2c56cc))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-config bumped to 0.3.0

## [0.1.4](https://github.com/cowprotocol/cow-sdk/compare/sdk-subgraph-v0.1.3...sdk-subgraph-v0.1.4) (2025-10-29)


### 🔧 Miscellaneous

* release main ([#620](https://github.com/cowprotocol/cow-sdk/issues/620)) ([b36394a](https://github.com/cowprotocol/cow-sdk/commit/b36394a2ba38957edb47ffc4451ea6624d66737b))
* revert release ([#634](https://github.com/cowprotocol/cow-sdk/issues/634)) ([fc7bf61](https://github.com/cowprotocol/cow-sdk/commit/fc7bf61444619d4b2c3a3dd55b7ce52c197b1878))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.3.0

## [0.1.3](https://github.com/cowprotocol/cow-sdk/compare/sdk-subgraph-v0.1.2...sdk-subgraph-v0.1.3) (2025-10-24)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.2.2
    * @cowprotocol/sdk-config bumped to 0.2.0

## [0.1.2](https://github.com/cowprotocol/cow-sdk/compare/sdk-subgraph-v0.1.1...sdk-subgraph-v0.1.2) (2025-10-08)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.2.1

## [0.1.1](https://github.com/cowprotocol/cow-sdk/compare/sdk-subgraph-v0.1.0...sdk-subgraph-v0.1.1) (2025-10-06)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.2.0

## [0.1.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-subgraph-v0.2.7-beta.0...sdk-subgraph-v0.1.0) (2025-09-17)


### ⚠ BREAKING CHANGES

* release cow-sdk v7

### ✨ Features

* release cow-sdk v7 ([6cd3e57](https://github.com/cowprotocol/cow-sdk/commit/6cd3e573687b1ffdbc0fdcb8cdbb414d88546e38))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.1.0
    * @cowprotocol/sdk-config bumped to 0.1.0

## [0.2.7-beta.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-subgraph-v0.2.6-beta.0...sdk-subgraph-v0.2.7-beta.0) (2025-09-17)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.5.0-beta.0

## [0.2.6-beta.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-subgraph-v0.2.5-beta.0...sdk-subgraph-v0.2.6-beta.0) (2025-09-16)


### 📚 Documentation

* update README to focus on main use cases ([#493](https://github.com/cowprotocol/cow-sdk/issues/493)) ([a05cb1b](https://github.com/cowprotocol/cow-sdk/commit/a05cb1ba11b5f9895d7cfe6262cf74c4089fd73c))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.4.0-beta.0
    * @cowprotocol/sdk-config bumped to 0.3.3-beta.0

## [0.2.5-beta.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-subgraph-v0.2.4-beta.0...sdk-subgraph-v0.2.5-beta.0) (2025-09-15)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-config bumped to 0.3.2-beta.0

## [0.2.4-beta.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-subgraph-v0.2.3-beta.0...sdk-subgraph-v0.2.4-beta.0) (2025-09-15)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-config bumped to 0.3.1-beta.0

## [0.2.3-beta.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-subgraph-v0.2.2-beta.0...sdk-subgraph-v0.2.3-beta.0) (2025-09-11)


### 🔧 Miscellaneous

* release main ([#488](https://github.com/cowprotocol/cow-sdk/issues/488)) ([6344fa6](https://github.com/cowprotocol/cow-sdk/commit/6344fa619465e6f94637677823a18646f06fa7c9))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.3.0-beta.0

## [0.2.2-beta.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-subgraph-v0.2.1-beta.0...sdk-subgraph-v0.2.2-beta.0) (2025-09-11)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-config bumped to 0.3.0-beta.0

## [0.2.1-beta.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-subgraph-v0.2.0-beta.0...sdk-subgraph-v0.2.1-beta.0) (2025-09-01)


### 🐛 Bug Fixes

* improve unknown/any types ([#443](https://github.com/cowprotocol/cow-sdk/issues/443)) ([e6b8a40](https://github.com/cowprotocol/cow-sdk/commit/e6b8a40578583cf6d1ecd208434782422f308ef0))

## [0.2.0-beta.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-subgraph-v0.1.0-beta.0...sdk-subgraph-v0.2.0-beta.0) (2025-08-28)


### ✨ Features

* allow changing backoff and limiter per request ([#208](https://github.com/cowprotocol/cow-sdk/issues/208)) ([ebea5ca](https://github.com/cowprotocol/cow-sdk/commit/ebea5ca0858aeb89ae3e5d5407c8903c3ca5178d))
* **lib-agnostic:** migrate latest Bridging changes ([#426](https://github.com/cowprotocol/cow-sdk/issues/426)) ([2359d9b](https://github.com/cowprotocol/cow-sdk/commit/2359d9b903e80ae5bab0cdb92d8cf52ae250da36))
* **lib-agnostic:** migrate latest SDK changes ([#427](https://github.com/cowprotocol/cow-sdk/issues/427)) ([323bab6](https://github.com/cowprotocol/cow-sdk/commit/323bab61eb5adeb4a58bc15e25ffb29d2e1afcbf))
* **sdk-agnostic-lib:** create cow trading package ([#368](https://github.com/cowprotocol/cow-sdk/issues/368)) ([0a4534a](https://github.com/cowprotocol/cow-sdk/commit/0a4534aababce4f5d8bab991cd6ae9f51842d719))
* **sdk-agnostic-lib:** Create weiroll package ([#371](https://github.com/cowprotocol/cow-sdk/issues/371)) ([8f6a2e1](https://github.com/cowprotocol/cow-sdk/commit/8f6a2e16e5e7a43a5afc43cf5faab174be916b2e))
* **subgraph:** refactor subgraph package ([84d6f26](https://github.com/cowprotocol/cow-sdk/commit/84d6f268f7e96b946797d4650bc0cee742afcb23))


### 🔧 Miscellaneous

* **docs:** apply PR suggestions and create subgraph README ([#406](https://github.com/cowprotocol/cow-sdk/issues/406)) ([d09a219](https://github.com/cowprotocol/cow-sdk/commit/d09a219c934289a30677be685915d57e9a4451be))
* **sdk-agnostic-lib:** improve scripts and types ([#407](https://github.com/cowprotocol/cow-sdk/issues/407)) ([c4b5e08](https://github.com/cowprotocol/cow-sdk/commit/c4b5e086ce46086e9430d5f03ed330502349fbf3))
* **sdk-agnostic-lib:** merge multiple PRs to avoid conflicts and speed up base branch sync ([#354](https://github.com/cowprotocol/cow-sdk/issues/354)) ([55d3068](https://github.com/cowprotocol/cow-sdk/commit/55d3068c52217dd2618d8c180ab4fed8c9334c72))
* **subgraph:** create package, tsconfig and jest config ([0255736](https://github.com/cowprotocol/cow-sdk/commit/02557362739c27a9777540d73b15092f745814f7))
* **subgraph:** move subgraph to monorepo package ([017d146](https://github.com/cowprotocol/cow-sdk/commit/017d14673eeaacc255b438e69138c83c2d310b28))
* **subgraph:** update pnpm-lock and run lint ([3f8144b](https://github.com/cowprotocol/cow-sdk/commit/3f8144be4839f5596763a25d505524a7318ebcbc))
