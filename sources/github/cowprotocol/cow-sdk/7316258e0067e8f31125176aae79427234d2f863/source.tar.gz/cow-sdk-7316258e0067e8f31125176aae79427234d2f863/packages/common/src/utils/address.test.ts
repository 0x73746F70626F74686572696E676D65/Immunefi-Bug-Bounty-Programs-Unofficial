import { isEvmAddress, isBtcAddress, isSolanaAddress, BtcAddressKey, EvmAddressKey, SolAddressKey } from './address'
import { SOL_NATIVE_CURRENCY_ADDRESS } from '@cowprotocol/sdk-config'

describe('isEvmAddress', () => {
  describe('valid EVM addresses', () => {
    it('should return true for valid lowercase EVM address', () => {
      const address = '0x742d35cc6634c0532925a3b844bc9e7595f0bebd'
      expect(isEvmAddress(address)).toBe(true)
      // Type guard should work
      const evmKey: EvmAddressKey = address
      expect(evmKey).toBe(address)
    })

    it('should return true for valid uppercase EVM address', () => {
      const address = '0x742D35CC6634C0532925A3B844BC9E7595F0BEBD'
      expect(isEvmAddress(address)).toBe(true)
    })

    it('should return true for valid mixed case EVM address', () => {
      const address = '0x742d35Cc6634C0532925a3B844Bc9e7595f0bEbD'
      expect(isEvmAddress(address)).toBe(true)
    })

    it('should return true for zero address', () => {
      expect(isEvmAddress('0x0000000000000000000000000000000000000000')).toBe(true)
    })

    it('should return true for address with all f characters', () => {
      expect(isEvmAddress('0xffffffffffffffffffffffffffffffffffffffff')).toBe(true)
    })
  })

  describe('invalid EVM addresses', () => {
    it('should return false for address without 0x prefix', () => {
      expect(isEvmAddress('742d35cc6634c0532925a3b844bc9e7595f0bebd')).toBe(false)
    })

    it('should return false for address with wrong length (too short)', () => {
      expect(isEvmAddress('0x742d35cc6634c0532925a3b844bc9e7595f0be')).toBe(false)
    })

    it('should return false for address with wrong length (too long)', () => {
      expect(isEvmAddress('0x742d35cc6634c0532925a3b844bc9e7595f0bebd00')).toBe(false)
    })

    it('should return false for address with invalid hex characters', () => {
      expect(isEvmAddress('0x742d35cc6634c0532925a3b844bc9e7595f0bebg')).toBe(false)
    })

    it('should return false for empty string', () => {
      expect(isEvmAddress('')).toBe(false)
    })

    it('should return false for non-string values', () => {
      expect(isEvmAddress(null as any)).toBe(false)
      expect(isEvmAddress(undefined as any)).toBe(false)
      expect(isEvmAddress(123 as any)).toBe(false)
      expect(isEvmAddress({} as any)).toBe(false)
    })

    it('should return false for BTC address (legacy)', () => {
      expect(isEvmAddress('1A1zP1eP5QGefi2DMPTfTL5SLmv7DivfNa')).toBe(false)
    })

    it('should return false for BTC address (Bech32)', () => {
      expect(isEvmAddress('bc1qw508d6qejxtdg4y5r3zarvary0c5xw7kv8f3t4')).toBe(false)
    })
  })
})

describe('isBtcAddress', () => {
  describe('valid BTC addresses - Legacy (P2PKH)', () => {
    it('should return true for valid legacy address starting with 1', () => {
      const address = '1A1zP1eP5QGefi2DMPTfTL5SLmv7DivfNa'
      expect(isBtcAddress(address)).toBe(true)
      // Type guard should work
      const btcKey: BtcAddressKey = address
      expect(btcKey).toBe(address)
    })

    it('should return true for valid legacy address starting with 3 (P2SH)', () => {
      expect(isBtcAddress('3J98t1WpEZ73CNmQviecrnyiWrnqRhWNLy')).toBe(true)
    })

    it('should return true for valid legacy address with minimum length', () => {
      expect(isBtcAddress('1A1zP1eP5QGefi2DMPTfTL5SLmv7DivfN')).toBe(true)
    })

    it('should return true for valid legacy address with maximum length', () => {
      expect(isBtcAddress('3J98t1WpEZ73CNmQviecrnyiWrnqRhWNLy')).toBe(true)
    })
  })

  describe('valid BTC addresses - Bech32 (P2WPKH/P2WSH)', () => {
    it('should return true for valid Bech32 mainnet address (bc1)', () => {
      const address = 'bc1qw508d6qejxtdg4y5r3zarvary0c5xw7kv8f3t4'
      expect(isBtcAddress(address)).toBe(true)
    })

    it('should return true for valid Bech32 mainnet address (uppercase)', () => {
      expect(isBtcAddress('BC1QW508D6QEJXTDG4Y5R3ZARVARY0C5XW7KV8F3T4')).toBe(true)
    })

    it('should return true for longer Bech32 address (P2WSH)', () => {
      expect(
        isBtcAddress('bc1qrp33g0q5c5txsp9arysrx4k6zdkfs4nce4xj0gdcccefvpysxf3qccfmv3'),
      ).toBe(true)
    })
  })

  describe('invalid BTC addresses', () => {
    it('should return false for address that is too short', () => {
      // 9 chars — clearly below the legacy P2PKH/P2SH minimum (≈26).
      expect(isBtcAddress('1A1zP1eP5')).toBe(false)
    })

    it('should return false for address that is too long', () => {
      // bc1 + 70 Bech32 chars = 73 chars, exceeds the practical P2WSH max (62).
      expect(
        isBtcAddress('bc1qw508d6qejxtdg4y5r3zarvary0c5xw7kv8f3t4qw508d6qejxtdg4y5r3zarvary0c5xw'),
      ).toBe(false)
    })

    it('should return false for EVM address', () => {
      expect(isBtcAddress('0x742d35cc6634c0532925a3b844bc9e7595f0bebd')).toBe(false)
    })

    it('should return false for empty string', () => {
      expect(isBtcAddress('')).toBe(false)
    })

    it('should return false for non-string values', () => {
      expect(isBtcAddress(null as any)).toBe(false)
      expect(isBtcAddress(undefined as any)).toBe(false)
      expect(isBtcAddress(123 as any)).toBe(false)
      expect(isBtcAddress({} as any)).toBe(false)
    })

    it('should return false for invalid legacy address format', () => {
      expect(isBtcAddress('0A1zP1eP5QGefi2DMPTfTL5SLmv7DivfNa')).toBe(false) // starts with 0
      expect(isBtcAddress('2A1zP1eP5QGefi2DMPTfTL5SLmv7DivfNa')).toBe(false) // starts with 2
    })

    it('should return false for invalid Bech32 address', () => {
      expect(isBtcAddress('ac1qw508d6qejxtdg4y5r3zarvary0c5xw7kv8f3t4')).toBe(false) // wrong prefix
      expect(isBtcAddress('bc0qw508d6qejxtdg4y5r3zarvary0c5xw7kv8f3t4')).toBe(false) // wrong prefix
    })

    it('should return false for mixed-case Bech32 address (BIP-173 forbids it)', () => {
      // Mixed-case Bech32 produces a different checksum than its case-normalized form,
      // so it's invalid by spec. Accepting it would let malformed addresses through.
      expect(isBtcAddress('bc1QW508d6qejxtdg4y5r3zarvary0c5xw7kv8f3t4')).toBe(false)
    })
  })

  describe('case sensitivity', () => {
    it('accepts strictly all-lowercase or all-uppercase Bech32; rejects mixed case', () => {
      const lower = 'bc1qw508d6qejxtdg4y5r3zarvary0c5xw7kv8f3t4'
      const upper = 'BC1QW508D6QEJXTDG4Y5R3ZARVARY0C5XW7KV8F3T4'
      const mixed = 'bc1QW508d6qejxtdg4y5r3zarvary0c5xw7kv8f3t4'

      expect(isBtcAddress(lower)).toBe(true)
      expect(isBtcAddress(upper)).toBe(true)
      // BIP-173 explicitly forbids mixed case.
      expect(isBtcAddress(mixed)).toBe(false)

      // Lower- and upper-case variants are distinct string values even though they
      // represent the same Bech32 address per the spec.
      expect(lower).not.toBe(upper)
    })
  })
})

describe('isSolanaAddress', () => {
  describe('valid Solana addresses', () => {
    it('should return true for SOL_NATIVE_CURRENCY_ADDRESS', () => {
      expect(isSolanaAddress(SOL_NATIVE_CURRENCY_ADDRESS)).toBe(true)
      const solKey: SolAddressKey = SOL_NATIVE_CURRENCY_ADDRESS
      expect(solKey).toBe(SOL_NATIVE_CURRENCY_ADDRESS)
    })

    it('should return true for a standard 44-char wallet address', () => {
      expect(isSolanaAddress('BYPsjxa3YuZESQz1dKuBw1QSFCSpecsm8nCQhY5xbU1Z')).toBe(true)
    })

    it('should return true for a token program address', () => {
      expect(isSolanaAddress('TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA')).toBe(true)
    })
  })

  describe('invalid Solana addresses', () => {
    // Note: legacy BTC P2PKH/P2SH addresses share the base58 alphabet with Solana and
    // can fall within Solana's valid length range (32-44). They are indistinguishable
    // by character/length alone — callers needing to discriminate should check
    // `isBtcAddress` first. Hence no assertion for `isSolanaAddress(BTC_CURRENCY_ADDRESS)`
    // here; we test BTC Bech32 below, which IS distinguishable (different alphabet).

    it('should return false for EVM address', () => {
      expect(isSolanaAddress('0x742d35cc6634c0532925a3b844bc9e7595f0bebd')).toBe(false)
    })

    it('should return false for address that is too short', () => {
      expect(isSolanaAddress('11111111111111111111111111111')).toBe(false) // 29 chars
    })

    it('should return false for address that is too long', () => {
      expect(isSolanaAddress('BYPsjxa3YuZESQz1dKuBw1QSFCSpecsm8nCQhY5xbU1Za')).toBe(false) // 45 chars
    })

    it('should return false for address containing invalid Base58 chars (0, O, I, l)', () => {
      expect(isSolanaAddress('0YPsjxa3YuZESQz1dKuBw1QSFCSpecsm8nCQhY5xbU1Z')).toBe(false) // contains 0
      expect(isSolanaAddress('OYPsjxa3YuZESQz1dKuBw1QSFCSpecsm8nCQhY5xbU1Z')).toBe(false) // contains O
      expect(isSolanaAddress('IYPsjxa3YuZESQz1dKuBw1QSFCSpecsm8nCQhY5xbU1Z')).toBe(false) // contains I
      expect(isSolanaAddress('lYPsjxa3YuZESQz1dKuBw1QSFCSpecsm8nCQhY5xbU1Z')).toBe(false) // contains l
    })

    it('should return false for empty string', () => {
      expect(isSolanaAddress('')).toBe(false)
    })

    it('should return false for non-string values', () => {
      expect(isSolanaAddress(null as any)).toBe(false)
      expect(isSolanaAddress(undefined as any)).toBe(false)
      expect(isSolanaAddress(123 as any)).toBe(false)
      expect(isSolanaAddress({} as any)).toBe(false)
    })

    it('should return false for BTC Bech32 address', () => {
      expect(isSolanaAddress('bc1qw508d6qejxtdg4y5r3zarvary0c5xw7kv8f3t4')).toBe(false)
    })
  })
})
