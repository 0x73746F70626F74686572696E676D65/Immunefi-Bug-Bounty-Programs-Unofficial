import { BungeeQuoteResult } from './BungeeBridgeProvider'
import { BungeeQuote, BungeeQuoteWithBuildTx } from './types'
import { BungeeTxDataBytesIndices } from './const/misc'
import { BungeeBridge, BungeeBridgeNames } from './types'
import { BridgeQuoteAmountsAndCosts, QuoteBridgeRequest } from '../../types'
import { OrderKind } from '@cowprotocol/sdk-order-book'
import stringify from 'json-stable-stringify'

/**
 * Convert a QuoteBridgeRequest to a BungeeQuoteResult
 * @param request - The QuoteBridgeRequest to convert
 * @param slippageBps
 * @param bungeeQuoteWithBuildTx
 * @returns The BungeeQuoteResult
 */
export function toBridgeQuoteResult(
  request: QuoteBridgeRequest,
  slippageBps: number,
  bungeeQuoteWithBuildTx: BungeeQuoteWithBuildTx,
): BungeeQuoteResult {
  const { kind } = request
  const { bungeeQuote, buildTx } = bungeeQuoteWithBuildTx

  return {
    id: bungeeQuoteWithBuildTx.bungeeQuote.route.quoteId.toString(),
    isSell: kind === OrderKind.SELL,
    amountsAndCosts: toAmountsAndCosts(request, slippageBps, bungeeQuote),
    quoteTimestamp: Number(bungeeQuote.quoteTimestamp),
    expectedFillTimeSeconds: Number(bungeeQuote.route.estimatedTime),
    quoteBody: stringify(bungeeQuote),
    fees: {
      // @note routeFee is taken in the src chain intermediate token
      bridgeFee: BigInt(bungeeQuote.route.routeDetails.routeFee.amount),
      // @note bungee api does not return destination gas fee separately
      // it is included in the routeFee
      destinationGasFee: BigInt(0),
    },
    // @note bungee api does not return limits
    limits: {
      minDeposit: BigInt(0),
      maxDeposit: BigInt(0),
    },
    bungeeQuote,
    buildTx,
  }
}

function toAmountsAndCosts(
  request: QuoteBridgeRequest,
  slippageBps: number,
  bungeeQuote: BungeeQuote,
): BridgeQuoteAmountsAndCosts {
  const { amount } = request

  // Get the amounts before fees
  const sellAmountBeforeFee = BigInt(amount)
  const buyAmountFromBungeeQuote = bungeeQuote.route.output.amount
  const buyAmountBeforeFee = BigInt(buyAmountFromBungeeQuote)
  // @note buyAmountAfterFee does not change, since routeFee is taken in the src chain intermediate token
  const buyAmountAfterFee = buyAmountBeforeFee

  // Calculate the fee
  const feeSellToken = bungeeQuote.route.routeDetails.routeFee.amount
  const feeSellTokenBig = BigInt(feeSellToken)
  // @note bungee's output.amount is already net of the routeFee (the fee is deducted from the input
  // on the src chain). So the true exchange rate must compare the output against the post-fee sell
  // amount, not the pre-fee sell amount. Using sellAmountBeforeFee here would understate the rate and
  // produce an invalid feeBuyToken (e.g. 83813 instead of 400000 for a 1:1 USDC->USDC bridge).
  // feeBuyToken = feeSellToken * (buyAmountAfterFee / (sellAmountBeforeFee - feeSellToken))
  const sellAmountAfterFee = sellAmountBeforeFee - feeSellTokenBig
  const feeBuyToken = sellAmountAfterFee > 0n ? (feeSellTokenBig * buyAmountAfterFee) / sellAmountAfterFee : 0n

  // Apply slippage
  const buyAmountAfterSlippage = applyBps(buyAmountAfterFee, slippageBps)

  // Calculate bridge fee bps from input amount routeFee
  // input amount and routeFee would be in token decimals so we need to convert to bigInt
  const bridgeFeeBps = calculateFeeBps(BigInt(bungeeQuote.route.routeDetails.routeFee.amount), BigInt(amount))

  return {
    beforeFee: {
      sellAmount: sellAmountBeforeFee,
      buyAmount: buyAmountBeforeFee,
    },
    afterFee: {
      // @note sellAmount does not change: the user deposits the full sellAmountBeforeFee into the
      // bridge. The routeFee is a cost (see costs.bridgingFee.amountInSellCurrency), not a reduction
      // of the sold amount. Keeping it constant across tiers matches the other bridge providers.
      sellAmount: sellAmountBeforeFee,
      buyAmount: buyAmountAfterFee,
    },
    afterSlippage: {
      sellAmount: sellAmountBeforeFee,
      buyAmount: buyAmountAfterSlippage,
    },

    costs: {
      bridgingFee: {
        feeBps: bridgeFeeBps,
        amountInSellCurrency: BigInt(feeSellToken),
        amountInBuyCurrency: feeBuyToken,
      },
    },
    slippageBps,
  }
}

/**
 * Decodes the txData from Bungee API
 * @param txData - The txData to decode
 * @returns The routeId and encoded function data
 */
export function decodeBungeeBridgeTxData(txData: string) {
  if (!txData || txData.length < 10) {
    throw new Error('Invalid txData: too short')
  }
  if (!txData.startsWith('0x')) {
    throw new Error('Invalid txData: must start with 0x')
  }

  // remove first two characters = 0x
  const txDataWithout0x = txData.slice(2)
  if (txDataWithout0x.length < 8) {
    throw new Error('Invalid txData: insufficient data for routeId')
  }

  // first four bytes are the routeId
  const routeId = `0x${txDataWithout0x.slice(0, 8)}`

  // rest is the encoded function data
  const encodedFunctionData = `0x${txDataWithout0x.slice(8)}`
  if (encodedFunctionData.length < 10) {
    throw new Error('Invalid txData: insufficient data for function selector')
  }

  // first 2+8 characters of encodedFunctionData are the function selector
  const functionSelector = `${encodedFunctionData.slice(0, 10)}`

  return { routeId, encodedFunctionData, functionSelector }
}

export function applyBps(amount: bigint, bps: number): bigint {
  return (amount * BigInt(10_000 - bps)) / 10_000n
}

export function calculateFeeBps(feeAmountBig: bigint, amountBig: bigint): number {
  if (amountBig === 0n) {
    throw new Error('Denominator is 0')
  }

  if (feeAmountBig > amountBig) {
    throw new Error('Fee amount is greater than amount')
  }

  // feeAmount will always be less than amount
  // so the max value for the bps will be 10_000
  // so Number conversion here should be safe
  return Number((feeAmountBig * 10_000n + amountBig / 2n) / amountBig)
}

/**
 * Converts an object to URLSearchParams, handling arrays by joining values with commas
 * @param params Object to convert to URLSearchParams
 * @returns URLSearchParams instance
 *
 * @example
 * const params = {
 *   userAddress: '0x123',
 *   includeBridges: ['across', 'cctp-v2']
 * }
 * const searchParams = objectToSearchParams(params)
 * Results in: ?userAddress=0x123&includeBridges=across,cctp-v2
 */
export function objectToSearchParams(params: object): URLSearchParams {
  const searchParams = new URLSearchParams()

  Object.entries(params).forEach(([key, value]) => {
    if (Array.isArray(value)) {
      searchParams.append(key, value.join(','))
    } else {
      searchParams.append(key, String(value))
    }
  })

  return searchParams
}

// Helper function to get enum value from display name
export const getBungeeBridgeFromDisplayName = (displayName: string): BungeeBridge | undefined => {
  return BungeeBridgeNames[displayName]
}

// Helper function to get display name from enum value
export const getDisplayNameFromBungeeBridge = (bridge: BungeeBridge): string | undefined => {
  return Object.entries(BungeeBridge).find(([_, value]) => value === bridge)?.[0]
}

export const decodeAmountsBungeeTxData = (
  txData: string,
  bridge: BungeeBridge,
): {
  inputAmountBytes: string
  inputAmountBigNumber: bigint
  outputAmountBytes?: string
  outputAmountBigNumber?: bigint
} => {
  if (!txData || !txData.startsWith('0x')) {
    throw new Error('Invalid txData format')
  }

  const { functionSelector } = decodeBungeeBridgeTxData(txData)

  const bridgeIndices = BungeeTxDataBytesIndices[bridge]
  if (!bridgeIndices) {
    throw new Error(`Unsupported bridge type: ${bridge}`)
  }

  const functionParams = BungeeTxDataBytesIndices[bridge][functionSelector]

  if (!functionParams) {
    throw new Error(`decodeAmountsBungeeTxData() no functionParams in [${functionSelector}]`)
  }

  // decode input amount
  const inputAmountEndIndex =
    functionParams.inputAmount.bytesString_startIndex + functionParams.inputAmount.bytesString_length
  if (txData.length < inputAmountEndIndex) {
    throw new Error(
      `Invalid txData: insufficient data for inputAmount. Expected at least ${inputAmountEndIndex} characters, got ${txData.length}`,
    )
  }

  const inputAmountBytes = `0x${txData.slice(functionParams.inputAmount.bytesString_startIndex, inputAmountEndIndex)}`
  const inputAmountBigNumber = BigInt(inputAmountBytes)

  if ('outputAmount' in functionParams) {
    const outputAmountEndIndex =
      functionParams.outputAmount.bytesString_startIndex + functionParams.outputAmount.bytesString_length
    if (txData.length < outputAmountEndIndex) {
      throw new Error(
        `Invalid txData: insufficient data for outputAmount. Expected at least ${outputAmountEndIndex} characters, got ${txData.length}`,
      )
    }

    const outputAmountBytes = `0x${txData.slice(
      functionParams.outputAmount.bytesString_startIndex,
      outputAmountEndIndex,
    )}`
    const outputAmountBigNumber = BigInt(outputAmountBytes)

    return {
      inputAmountBytes,
      inputAmountBigNumber,
      outputAmountBytes,
      outputAmountBigNumber,
    }
  }

  return {
    inputAmountBytes,
    inputAmountBigNumber,
  }
}
