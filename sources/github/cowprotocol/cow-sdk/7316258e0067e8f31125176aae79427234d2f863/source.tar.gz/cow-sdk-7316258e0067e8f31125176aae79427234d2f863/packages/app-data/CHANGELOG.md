# Changelog

## [6.0.8](https://github.com/cowprotocol/cow-sdk/compare/sdk-app-data-v6.0.7...sdk-app-data-v6.0.8) (2026-09-29)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.14.2
  * devDependencies
    * @cowprotocol/sdk-config bumped to 2.7.2
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.4.18
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.4.18
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.33

## [6.0.7](https://github.com/cowprotocol/cow-sdk/compare/sdk-app-data-v6.0.6...sdk-app-data-v6.0.7) (2026-09-25)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.14.1
  * devDependencies
    * @cowprotocol/sdk-config bumped to 2.7.1
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.4.17
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.4.17
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.32

## [6.0.6](https://github.com/cowprotocol/cow-sdk/compare/sdk-app-data-v6.0.5...sdk-app-data-v6.0.6) (2026-09-21)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.14.0
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.4.16
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.4.16
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.31

## [6.0.5](https://github.com/cowprotocol/cow-sdk/compare/sdk-app-data-v6.0.4...sdk-app-data-v6.0.5) (2026-09-18)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.13.1
  * devDependencies
    * @cowprotocol/sdk-config bumped to 2.7.0
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.4.15
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.4.15
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.30

## [6.0.4](https://github.com/cowprotocol/cow-sdk/compare/sdk-app-data-v6.0.3...sdk-app-data-v6.0.4) (2026-09-16)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.13.0
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.4.14
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.4.14
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.29

## [6.0.3](https://github.com/cowprotocol/cow-sdk/compare/sdk-app-data-v6.0.2...sdk-app-data-v6.0.3) (2026-09-14)


### 🔧 Miscellaneous

* update coverage badges ([#948](https://github.com/cowprotocol/cow-sdk/issues/948)) ([151d7a4](https://github.com/cowprotocol/cow-sdk/commit/151d7a4bc51194ffa7dc46a102eb2bc0e3537124))

## [6.0.2](https://github.com/cowprotocol/cow-sdk/compare/sdk-app-data-v6.0.1...sdk-app-data-v6.0.2) (2026-09-07)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.12.3
  * devDependencies
    * @cowprotocol/sdk-config bumped to 2.6.0
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.4.13
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.4.13
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.28

## [6.0.1](https://github.com/cowprotocol/cow-sdk/compare/sdk-app-data-v6.0.0...sdk-app-data-v6.0.1) (2026-09-04)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.12.2
  * devDependencies
    * @cowprotocol/sdk-config bumped to 2.5.0
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.4.12
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.4.12
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.27

## [6.0.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-app-data-v5.3.3...sdk-app-data-v6.0.0) (2026-08-03)


### ⚠ BREAKING CHANGES

* **app-data:** remove `AppDataSdk.legacy` methods ([#946](https://github.com/cowprotocol/cow-sdk/issues/946)) ([46a21b2](https://github.com/cowprotocol/cow-sdk/commit/46a21b2420883e4fc40b686c76d6a65f27467211))


## [5.3.3](https://github.com/cowprotocol/cow-sdk/compare/sdk-app-data-v5.3.2...sdk-app-data-v5.3.3) (2026-07-29)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.12.1
  * devDependencies
    * @cowprotocol/sdk-config bumped to 2.4.0
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.4.11
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.4.11
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.26

## [5.3.2](https://github.com/cowprotocol/cow-sdk/compare/sdk-app-data-v5.3.1...sdk-app-data-v5.3.2) (2026-07-22)


### Dependencies

* The following workspace dependencies were updated
  * devDependencies
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.25

## [5.3.1](https://github.com/cowprotocol/cow-sdk/compare/sdk-app-data-v5.3.0...sdk-app-data-v5.3.1) (2026-06-23)


### 🐛 Bug Fixes

* near-bridging ([#908](https://github.com/cowprotocol/cow-sdk/issues/908)) ([b4d471c](https://github.com/cowprotocol/cow-sdk/commit/b4d471c8ebc7646d00bd6f6fd097b0692ac08f40))

## [5.3.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-app-data-v5.2.0...sdk-app-data-v5.3.0) (2026-06-15)


### ✨ Features

* per-package test coverage badges, updated in CI ([#895](https://github.com/cowprotocol/cow-sdk/issues/895)) ([c73246c](https://github.com/cowprotocol/cow-sdk/commit/c73246cc52c4fc79b2628b7c5f580695fd3dc1e2))


### 🔧 Miscellaneous

* update coverage badges ([#903](https://github.com/cowprotocol/cow-sdk/issues/903)) ([c9e4b94](https://github.com/cowprotocol/cow-sdk/commit/c9e4b94fa77c364dfd1df5c61b67326c023e4731))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.12.0
  * devDependencies
    * @cowprotocol/sdk-config bumped to 2.3.1
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.4.10
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.4.10
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.24

## [5.2.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-app-data-v5.1.4...sdk-app-data-v5.2.0) (2026-06-08)


### ✨ Features

* **app-data:** rename MetadataApi to AppDataSdk ([#893](https://github.com/cowprotocol/cow-sdk/issues/893)) ([9c4567f](https://github.com/cowprotocol/cow-sdk/commit/9c4567fc8d46baec47101afd540dee7d635d6237))


### 🐛 Bug Fixes

* **app-data:** bump maxVolumeBps cap ([#896](https://github.com/cowprotocol/cow-sdk/issues/896)) ([1e98a71](https://github.com/cowprotocol/cow-sdk/commit/1e98a71dbccc75c13dd185bb8d75b8f92f6ecc8f))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.11.2
  * devDependencies
    * @cowprotocol/sdk-config bumped to 2.3.0
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.4.9
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.4.9
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.23

## [5.1.4](https://github.com/cowprotocol/cow-sdk/compare/sdk-app-data-v5.1.3...sdk-app-data-v5.1.4) (2026-06-02)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.11.1
  * devDependencies
    * @cowprotocol/sdk-config bumped to 2.2.1
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.4.8
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.4.8
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.22

## [5.1.3](https://github.com/cowprotocol/cow-sdk/compare/sdk-app-data-v5.1.2...sdk-app-data-v5.1.3) (2026-05-27)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.11.0
  * devDependencies
    * @cowprotocol/sdk-config bumped to 2.2.0
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.4.7
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.4.7
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.21

## [5.1.2](https://github.com/cowprotocol/cow-sdk/compare/sdk-app-data-v5.1.1...sdk-app-data-v5.1.2) (2026-05-22)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.10.3
  * devDependencies
    * @cowprotocol/sdk-config bumped to 2.1.0
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.4.6
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.4.6
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.20

## [5.1.1](https://github.com/cowprotocol/cow-sdk/compare/sdk-app-data-v5.1.0...sdk-app-data-v5.1.1) (2026-05-20)


### 🐛 Bug Fixes

* app data cid lazy import ([#883](https://github.com/cowprotocol/cow-sdk/issues/883)) ([fd0235b](https://github.com/cowprotocol/cow-sdk/commit/fd0235b63e957ce268ce0c93626e45a396cea06e))


### Dependencies

* The following workspace dependencies were updated
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.4.5
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.4.5
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.19

## [5.1.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-app-data-v5.0.0...sdk-app-data-v5.1.0) (2026-04-28)


### ✨ Features

* update ipfsOnlyHash deps ([#869](https://github.com/cowprotocol/cow-sdk/issues/869)) ([d6b30cf](https://github.com/cowprotocol/cow-sdk/commit/d6b30cfc248cb7d93f9b00113da7412b45b58194))

## [5.0.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-app-data-v4.7.0...sdk-app-data-v5.0.0) (2026-04-16)


### ⚠ BREAKING CHANGES

* bring cow.fi back ([#863](https://github.com/cowprotocol/cow-sdk/issues/863))

### ✨ Features

* bring cow.fi back ([#863](https://github.com/cowprotocol/cow-sdk/issues/863)) ([d607fd2](https://github.com/cowprotocol/cow-sdk/commit/d607fd2cfbc93ace39de04f3a7870f723fdd9b21))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.10.2
  * devDependencies
    * @cowprotocol/sdk-config bumped to 2.0.0
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.4.4
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.4.4
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.18

## [4.7.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-app-data-v4.6.14...sdk-app-data-v4.7.0) (2026-04-14)


### ✨ Features

* migrate to cow.finance domain ([#860](https://github.com/cowprotocol/cow-sdk/issues/860)) ([a4e7633](https://github.com/cowprotocol/cow-sdk/commit/a4e76333b7a276baec5c977f44b15498550d8e50))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.10.1
  * devDependencies
    * @cowprotocol/sdk-config bumped to 1.2.0
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.4.3
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.4.3
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.17

## [4.6.14](https://github.com/cowprotocol/cow-sdk/compare/sdk-app-data-v4.6.13...sdk-app-data-v4.6.14) (2026-04-08)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.10.0
  * devDependencies
    * @cowprotocol/sdk-config bumped to 1.1.3
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.4.2
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.4.2
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.16

## [4.6.13](https://github.com/cowprotocol/cow-sdk/compare/sdk-app-data-v4.6.12...sdk-app-data-v4.6.13) (2026-04-01)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.9.0
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.4.1
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.4.1
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.15

## [4.6.12](https://github.com/cowprotocol/cow-sdk/compare/sdk-app-data-v4.6.11...sdk-app-data-v4.6.12) (2026-03-17)


### Dependencies

* The following workspace dependencies were updated
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.4.0
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.4.0

## [4.6.11](https://github.com/cowprotocol/cow-sdk/compare/sdk-app-data-v4.6.10...sdk-app-data-v4.6.11) (2026-03-17)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.8.2
  * devDependencies
    * @cowprotocol/sdk-config bumped to 1.1.2
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.3.14
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.3.14
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.14

## [4.6.10](https://github.com/cowprotocol/cow-sdk/compare/sdk-app-data-v4.6.9...sdk-app-data-v4.6.10) (2026-03-16)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.8.1
  * devDependencies
    * @cowprotocol/sdk-config bumped to 1.1.1
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.3.13
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.3.13
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.13

## [4.6.9](https://github.com/cowprotocol/cow-sdk/compare/sdk-app-data-v4.6.8...sdk-app-data-v4.6.9) (2026-03-16)


### 🔧 Miscellaneous

* release main ([#826](https://github.com/cowprotocol/cow-sdk/issues/826)) ([baaa708](https://github.com/cowprotocol/cow-sdk/commit/baaa7088ac15b89fb83310e54aa52f09d19132ff))
* release main ([#832](https://github.com/cowprotocol/cow-sdk/issues/832)) ([5dafcb8](https://github.com/cowprotocol/cow-sdk/commit/5dafcb8ec5593250dba1ff6e9fdbf8eb11d974cf))
* revert release ([#833](https://github.com/cowprotocol/cow-sdk/issues/833)) ([0c40a9b](https://github.com/cowprotocol/cow-sdk/commit/0c40a9b3ee828c7ede66576f02e1b571e96140cd))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.8.0
  * devDependencies
    * @cowprotocol/sdk-config bumped to 1.1.0
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.3.12
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.3.12
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.12

## [4.6.8](https://github.com/cowprotocol/cow-sdk/compare/sdk-app-data-v4.6.7...sdk-app-data-v4.6.8) (2026-03-10)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.7.1
  * devDependencies
    * @cowprotocol/sdk-config bumped to 1.0.0
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.3.11
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.3.11
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.11

## [4.6.7](https://github.com/cowprotocol/cow-sdk/compare/sdk-app-data-v4.6.6...sdk-app-data-v4.6.7) (2026-03-04)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.7.0
  * devDependencies
    * @cowprotocol/sdk-config bumped to 0.10.0
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.3.10
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.3.10
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.10

## [4.6.6](https://github.com/cowprotocol/cow-sdk/compare/sdk-app-data-v4.6.5...sdk-app-data-v4.6.6) (2026-03-04)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.6.3
  * devDependencies
    * @cowprotocol/sdk-config bumped to 0.9.0
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.3.9
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.3.9
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.9

## [4.6.5](https://github.com/cowprotocol/cow-sdk/compare/sdk-app-data-v4.6.4...sdk-app-data-v4.6.5) (2026-02-20)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.6.2
  * devDependencies
    * @cowprotocol/sdk-config bumped to 0.8.1
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.3.8
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.3.8
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.8

## [4.6.4](https://github.com/cowprotocol/cow-sdk/compare/sdk-app-data-v4.6.3...sdk-app-data-v4.6.4) (2026-02-18)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.6.1
  * devDependencies
    * @cowprotocol/sdk-config bumped to 0.8.0
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.3.7
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.3.7
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.7

## [4.6.3](https://github.com/cowprotocol/cow-sdk/compare/sdk-app-data-v4.6.2...sdk-app-data-v4.6.3) (2026-02-05)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.6.0
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.3.6
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.3.6
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.6

## [4.6.2](https://github.com/cowprotocol/cow-sdk/compare/sdk-app-data-v4.6.1...sdk-app-data-v4.6.2) (2026-02-02)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.5.4
  * devDependencies
    * @cowprotocol/sdk-config bumped to 0.7.3
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.3.5
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.3.5
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.5

## [4.6.1](https://github.com/cowprotocol/cow-sdk/compare/sdk-app-data-v4.6.0...sdk-app-data-v4.6.1) (2026-02-02)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.5.3
  * devDependencies
    * @cowprotocol/sdk-config bumped to 0.7.2
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.3.4
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.3.4
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.4

## [4.6.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-app-data-v4.5.2...sdk-app-data-v4.6.0) (2026-01-28)


### ✨ Features

* allow new code property in referrer schema ([#774](https://github.com/cowprotocol/cow-sdk/issues/774)) ([2b648b6](https://github.com/cowprotocol/cow-sdk/commit/2b648b6a1db03fd34002c49572d8e8e556d03593))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.5.2
  * devDependencies
    * @cowprotocol/sdk-config bumped to 0.7.1
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.3.3
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.3.3
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.3

## [4.5.2](https://github.com/cowprotocol/cow-sdk/compare/sdk-app-data-v4.5.1...sdk-app-data-v4.5.2) (2026-01-28)


### 🐛 Bug Fixes

* **app-data:** rename `is_omittable` property as camelCase in appData ([6b16d0d](https://github.com/cowprotocol/cow-sdk/commit/6b16d0dab7831035651529169c572df79e79640d))
* **app-data:** rename `is_omittable` property in wrappers app data ([bb5c637](https://github.com/cowprotocol/cow-sdk/commit/bb5c6375135937389974916267fee850666fa2dd))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.5.1
  * devDependencies
    * @cowprotocol/sdk-config bumped to 0.7.0
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.3.2
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.3.2
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.2

## [4.5.1](https://github.com/cowprotocol/cow-sdk/compare/sdk-app-data-v4.5.0...sdk-app-data-v4.5.1) (2026-01-19)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.5.0
  * devDependencies
    * @cowprotocol/sdk-config bumped to 0.6.3
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.3.1
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.3.1
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.1

## [4.5.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-app-data-v4.4.0...sdk-app-data-v4.5.0) (2025-12-25)


### ✨ Features

* **app-data:** add user terms consents ([#763](https://github.com/cowprotocol/cow-sdk/issues/763)) ([1fc0b26](https://github.com/cowprotocol/cow-sdk/commit/1fc0b26ba250505db19c9189dd52a5e021c9616e))
* **bridge:** extend bridging appData with attestation data ([#756](https://github.com/cowprotocol/cow-sdk/issues/756)) ([ff04417](https://github.com/cowprotocol/cow-sdk/commit/ff044172bdfa2997393e2bf9a331119815d2fc12))

## [4.4.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-app-data-v4.3.6...sdk-app-data-v4.4.0) (2025-12-22)


### ✨ Features

* **app-data:** add `wrappers` to app-data ([#746](https://github.com/cowprotocol/cow-sdk/issues/746)) ([6d1868a](https://github.com/cowprotocol/cow-sdk/commit/6d1868a7430a33caa46caa7bf41465e42ecd5a8f))

## [4.3.6](https://github.com/cowprotocol/cow-sdk/compare/sdk-app-data-v4.3.5...sdk-app-data-v4.3.6) (2025-12-11)


### Dependencies

* The following workspace dependencies were updated
  * devDependencies
    * @cowprotocol/sdk-config bumped to 0.6.2

## [4.3.5](https://github.com/cowprotocol/cow-sdk/compare/sdk-app-data-v4.3.4...sdk-app-data-v4.3.5) (2025-12-05)


### Dependencies

* The following workspace dependencies were updated
  * devDependencies
    * @cowprotocol/sdk-config bumped to 0.6.1

## [4.3.4](https://github.com/cowprotocol/cow-sdk/compare/sdk-app-data-v4.3.3...sdk-app-data-v4.3.4) (2025-12-04)


### Dependencies

* The following workspace dependencies were updated
  * devDependencies
    * @cowprotocol/sdk-config bumped to 0.6.0

## [4.3.3](https://github.com/cowprotocol/cow-sdk/compare/sdk-app-data-v4.3.2...sdk-app-data-v4.3.3) (2025-12-03)


### Dependencies

* The following workspace dependencies were updated
  * devDependencies
    * @cowprotocol/sdk-config bumped to 0.5.0

## [4.3.2](https://github.com/cowprotocol/cow-sdk/compare/sdk-app-data-v4.3.1...sdk-app-data-v4.3.2) (2025-12-03)


### 📚 Documentation

* **app-data:** updated readme ([#725](https://github.com/cowprotocol/cow-sdk/issues/725)) ([c86fb55](https://github.com/cowprotocol/cow-sdk/commit/c86fb55f0a97b50da935da24e1f57796b86b4325))

## [4.3.1](https://github.com/cowprotocol/cow-sdk/compare/sdk-app-data-v4.3.0...sdk-app-data-v4.3.1) (2025-11-27)


### Dependencies

* The following workspace dependencies were updated
  * devDependencies
    * @cowprotocol/sdk-config bumped to 0.4.1

## [4.3.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-app-data-v4.2.0...sdk-app-data-v4.3.0) (2025-11-24)


### ✨ Features

* **bridge:** add quote id and signature metadata ([#701](https://github.com/cowprotocol/cow-sdk/issues/701)) ([35a25a7](https://github.com/cowprotocol/cow-sdk/commit/35a25a7fcc2724073355b3dba4b8f6d3b7419032))

## [4.2.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-app-data-v4.1.6...sdk-app-data-v4.2.0) (2025-11-24)


### ✨ Features

* **bridge:** support Near bridge provider ([#642](https://github.com/cowprotocol/cow-sdk/issues/642)) ([c7d8633](https://github.com/cowprotocol/cow-sdk/commit/c7d86335601cfd772d72dfe65a0e941ce916769a))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.4.0
  * devDependencies
    * @cowprotocol/sdk-config bumped to 0.4.0
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.3.0
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.3.0
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.0

## [4.1.6](https://github.com/cowprotocol/cow-sdk/compare/sdk-app-data-v4.1.5...sdk-app-data-v4.1.6) (2025-11-05)


### Dependencies

* The following workspace dependencies were updated
  * devDependencies
    * @cowprotocol/sdk-config bumped to 0.3.0

## [4.1.5](https://github.com/cowprotocol/cow-sdk/compare/sdk-app-data-v4.1.4...sdk-app-data-v4.1.5) (2025-10-29)


### 🔧 Miscellaneous

* release main ([#620](https://github.com/cowprotocol/cow-sdk/issues/620)) ([b36394a](https://github.com/cowprotocol/cow-sdk/commit/b36394a2ba38957edb47ffc4451ea6624d66737b))
* revert release ([#634](https://github.com/cowprotocol/cow-sdk/issues/634)) ([fc7bf61](https://github.com/cowprotocol/cow-sdk/commit/fc7bf61444619d4b2c3a3dd55b7ce52c197b1878))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.3.0
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.2.0
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.2.0
    * @cowprotocol/sdk-viem-adapter bumped to 0.2.0

## [4.1.4](https://github.com/cowprotocol/cow-sdk/compare/sdk-app-data-v4.1.3...sdk-app-data-v4.1.4) (2025-10-24)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.2.2
  * devDependencies
    * @cowprotocol/sdk-config bumped to 0.2.0
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.1.3
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.1.3
    * @cowprotocol/sdk-viem-adapter bumped to 0.1.3

## [4.1.3](https://github.com/cowprotocol/cow-sdk/compare/sdk-app-data-v4.1.2...sdk-app-data-v4.1.3) (2025-10-17)


### 🐛 Bug Fixes

* **app-data:** remove dappId validation ([#591](https://github.com/cowprotocol/cow-sdk/issues/591)) ([9db80c3](https://github.com/cowprotocol/cow-sdk/commit/9db80c34923c6b12ed9ecb3ed26ca1a99acd2b8f))


### 🔧 Miscellaneous

* release main ([#592](https://github.com/cowprotocol/cow-sdk/issues/592)) ([e4d7212](https://github.com/cowprotocol/cow-sdk/commit/e4d7212af322beced743e985bd1fbedaef66cdcb))

## [4.1.2](https://github.com/cowprotocol/cow-sdk/compare/sdk-app-data-v4.1.1...sdk-app-data-v4.1.2) (2025-10-15)


### 🐛 Bug Fixes

* **app-data:** fix typos and ids in schemas ([#586](https://github.com/cowprotocol/cow-sdk/issues/586)) ([5a4461a](https://github.com/cowprotocol/cow-sdk/commit/5a4461a2a171689db04f7c805c9e2c835bbd36dd))

## [4.1.1](https://github.com/cowprotocol/cow-sdk/compare/sdk-app-data-v4.1.0...sdk-app-data-v4.1.1) (2025-10-08)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.2.1
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.1.2
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.1.2
    * @cowprotocol/sdk-viem-adapter bumped to 0.1.2

## [4.1.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-app-data-v4.0.1...sdk-app-data-v4.1.0) (2025-10-08)


### ✨ Features

* **app-data:** update flashloan schema to 0.2.0 ([#572](https://github.com/cowprotocol/cow-sdk/issues/572)) ([e909dbd](https://github.com/cowprotocol/cow-sdk/commit/e909dbd059077fa80c52c9651b4ae2b6f6edd97c))

## [4.0.1](https://github.com/cowprotocol/cow-sdk/compare/sdk-app-data-v4.0.0...sdk-app-data-v4.0.1) (2025-10-06)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.2.0
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.1.1
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.1.1
    * @cowprotocol/sdk-viem-adapter bumped to 0.1.1

## [4.0.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-app-data-v4.1.7-beta.0...sdk-app-data-v4.0.0) (2025-09-17)


### ⚠ BREAKING CHANGES

* release cow-sdk v7

### ✨ Features

* release cow-sdk v7 ([6cd3e57](https://github.com/cowprotocol/cow-sdk/commit/6cd3e573687b1ffdbc0fdcb8cdbb414d88546e38))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.1.0
  * devDependencies
    * @cowprotocol/sdk-config bumped to 0.1.0
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.1.0
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.1.0
    * @cowprotocol/sdk-viem-adapter bumped to 0.1.0

## [4.1.7-beta.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-app-data-v4.1.6-beta.0...sdk-app-data-v4.1.7-beta.0) (2025-09-17)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.5.0-beta.0
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.2.5-beta.0
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.2.5-beta.0
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.1-beta.0

## [4.1.6-beta.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-app-data-v4.1.5-beta.0...sdk-app-data-v4.1.6-beta.0) (2025-09-16)


### Dependencies

* The following workspace dependencies were updated
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.2.4-beta.0
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.2.4-beta.0

## [4.1.5-beta.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-app-data-v4.1.4-beta.0...sdk-app-data-v4.1.5-beta.0) (2025-09-16)


### 📚 Documentation

* update README to focus on main use cases ([#493](https://github.com/cowprotocol/cow-sdk/issues/493)) ([a05cb1b](https://github.com/cowprotocol/cow-sdk/commit/a05cb1ba11b5f9895d7cfe6262cf74c4089fd73c))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.4.0-beta.0
  * devDependencies
    * @cowprotocol/sdk-config bumped to 0.3.3-beta.0
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.2.3-beta.0
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.2.3-beta.0
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.0-beta.0

## [4.1.4-beta.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-app-data-v4.1.3-beta.0...sdk-app-data-v4.1.4-beta.0) (2025-09-15)


### Dependencies

* The following workspace dependencies were updated
  * devDependencies
    * @cowprotocol/sdk-config bumped to 0.3.2-beta.0

## [4.1.3-beta.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-app-data-v4.1.2-beta.0...sdk-app-data-v4.1.3-beta.0) (2025-09-15)


### Dependencies

* The following workspace dependencies were updated
  * devDependencies
    * @cowprotocol/sdk-config bumped to 0.3.1-beta.0

## [4.1.2-beta.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-app-data-v4.1.1-beta.0...sdk-app-data-v4.1.2-beta.0) (2025-09-11)


### 🔧 Miscellaneous

* release main ([#488](https://github.com/cowprotocol/cow-sdk/issues/488)) ([6344fa6](https://github.com/cowprotocol/cow-sdk/commit/6344fa619465e6f94637677823a18646f06fa7c9))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.3.0-beta.0
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.2.2-beta.0
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.2.2-beta.0
    * @cowprotocol/sdk-viem-adapter bumped to 0.2.2-beta.0

## [4.1.1-beta.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-app-data-v4.1.0-beta.0...sdk-app-data-v4.1.1-beta.0) (2025-09-11)


### Dependencies

* The following workspace dependencies were updated
  * devDependencies
    * @cowprotocol/sdk-config bumped to 0.3.0-beta.0

## [4.1.0-beta.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-app-data-v4.0.0-beta.0...sdk-app-data-v4.1.0-beta.0) (2025-08-28)


### ✨ Features

* allow changing backoff and limiter per request ([#208](https://github.com/cowprotocol/cow-sdk/issues/208)) ([ebea5ca](https://github.com/cowprotocol/cow-sdk/commit/ebea5ca0858aeb89ae3e5d5407c8903c3ca5178d))
* copy entire src, tests folders, and package/tsconfig files from app-data project into the monorepo ([70ef622](https://github.com/cowprotocol/cow-sdk/commit/70ef622eac14cb38837144ab15418eff27d8cba7))
* implement adapter usage in app-data; update app-data config and test files ([422afd2](https://github.com/cowprotocol/cow-sdk/commit/422afd2e7613d6f7558764f149b15aae4be65390))
* **lib-agnostic:** migrate latest Bridging changes ([#426](https://github.com/cowprotocol/cow-sdk/issues/426)) ([2359d9b](https://github.com/cowprotocol/cow-sdk/commit/2359d9b903e80ae5bab0cdb92d8cf52ae250da36))
* **lib-agnostic:** migrate latest SDK changes ([#427](https://github.com/cowprotocol/cow-sdk/issues/427)) ([323bab6](https://github.com/cowprotocol/cow-sdk/commit/323bab61eb5adeb4a58bc15e25ffb29d2e1afcbf))
* **monorepo-config:** adjust all package.json and scripts ([23dc2a5](https://github.com/cowprotocol/cow-sdk/commit/23dc2a5db02ce3734b55e1151c8579f9a42a4bc5))
* **sdk-agnostic-lib:** create app data package ([#327](https://github.com/cowprotocol/cow-sdk/issues/327)) ([8b61261](https://github.com/cowprotocol/cow-sdk/commit/8b612615bc280dee2e5f4767794bc03f590d4764))
* **sdk-agnostic-lib:** create cow trading package ([#368](https://github.com/cowprotocol/cow-sdk/issues/368)) ([0a4534a](https://github.com/cowprotocol/cow-sdk/commit/0a4534aababce4f5d8bab991cd6ae9f51842d719))
* **sdk-agnostic-lib:** Create weiroll package ([#371](https://github.com/cowprotocol/cow-sdk/issues/371)) ([8f6a2e1](https://github.com/cowprotocol/cow-sdk/commit/8f6a2e16e5e7a43a5afc43cf5faab174be916b2e))


### 🐛 Bug Fixes

* **lib-agnostic:** add setProvider() method to adapters ([#432](https://github.com/cowprotocol/cow-sdk/issues/432)) ([64c0ea9](https://github.com/cowprotocol/cow-sdk/commit/64c0ea94d802aa167b978ae0859353d801de0911))
* **sdk:** reduce sdks in umbrella ([#433](https://github.com/cowprotocol/cow-sdk/issues/433)) ([22b1cb6](https://github.com/cowprotocol/cow-sdk/commit/22b1cb6e572fcd3a7b3878d725113ac420f470e6))


### 🔧 Miscellaneous

* fix lint and remove cow-sdk from lint. ([46decb7](https://github.com/cowprotocol/cow-sdk/commit/46decb72050c1b9481b24d9b10b6a4c4f2abe0c3))
* fix merge ([5c511de](https://github.com/cowprotocol/cow-sdk/commit/5c511deedd0c7821df6affefc9623c79a68c96c7))
* lint files ([8f1d0a5](https://github.com/cowprotocol/cow-sdk/commit/8f1d0a555141e995e475e58e4b3abc087ec2a9f3))
* **lint:** lint ([881e345](https://github.com/cowprotocol/cow-sdk/commit/881e3451add9d911047daebe4e36fe777d95927a))
* merge main 28-06-2025 ([#452](https://github.com/cowprotocol/cow-sdk/issues/452)) ([4c198ce](https://github.com/cowprotocol/cow-sdk/commit/4c198ce34890740bf0a0fe859620a9e1ad432bed))
* move constants to sdk-common ([c1336c3](https://github.com/cowprotocol/cow-sdk/commit/c1336c3af5dc51c649c9435919e5e1054a6f94d5))
* **sdk-agnostic-lib:** improve scripts and types ([#407](https://github.com/cowprotocol/cow-sdk/issues/407)) ([c4b5e08](https://github.com/cowprotocol/cow-sdk/commit/c4b5e086ce46086e9430d5f03ed330502349fbf3))
* **sdk-agnostic-lib:** merge multiple PRs to avoid conflicts and speed up base branch sync ([#354](https://github.com/cowprotocol/cow-sdk/issues/354)) ([55d3068](https://github.com/cowprotocol/cow-sdk/commit/55d3068c52217dd2618d8c180ab4fed8c9334c72))
