# Changelog

## [2.7.2](https://github.com/cowprotocol/cow-sdk/compare/sdk-config-v2.7.1...sdk-config-v2.7.2) (2026-09-29)


### 🐛 Bug Fixes

* solana icon ([#1039](https://github.com/cowprotocol/cow-sdk/issues/1039)) ([c0275af](https://github.com/cowprotocol/cow-sdk/commit/c0275afbcca90d15549b01f2dd82c949c259f166))

## [2.7.1](https://github.com/cowprotocol/cow-sdk/compare/sdk-config-v2.7.0...sdk-config-v2.7.1) (2026-09-25)


### 🔧 Miscellaneous

* bump contract version ([566f50f](https://github.com/cowprotocol/cow-sdk/commit/566f50f638c7462a25b2ac743f3a65e981ffb3a9))

## [2.7.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-config-v2.6.0...sdk-config-v2.7.0) (2026-09-18)


### ✨ Features

* **solana:** migrate to 0.4 settlement program ([#1019](https://github.com/cowprotocol/cow-sdk/issues/1019)) ([9baf9cb](https://github.com/cowprotocol/cow-sdk/commit/9baf9cbb650434ed6b1a46ce63b9c82b0736be76))

## [2.6.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-config-v2.5.0...sdk-config-v2.6.0) (2026-09-07)


### ✨ Features

* derive pda address from the seed ([#995](https://github.com/cowprotocol/cow-sdk/issues/995)) ([e7bf33f](https://github.com/cowprotocol/cow-sdk/commit/e7bf33ffdcc27ff4121573988b23443df9097e14))

## [2.5.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-config-v2.4.0...sdk-config-v2.5.0) (2026-09-04)


### ✨ Features

* trading sdk for solana ([#973](https://github.com/cowprotocol/cow-sdk/issues/973)) ([60b39b9](https://github.com/cowprotocol/cow-sdk/commit/60b39b93883889d794f02138b8dbef74f7dc6c5b))

## [2.4.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-config-v2.3.1...sdk-config-v2.4.0) (2026-07-29)


### ✨ Features

* **config:** add sol settlement address ([#950](https://github.com/cowprotocol/cow-sdk/issues/950)) ([2cbe87a](https://github.com/cowprotocol/cow-sdk/commit/2cbe87a0a9e26394190684d52cbda6e06dc97c71))

## [2.3.1](https://github.com/cowprotocol/cow-sdk/compare/sdk-config-v2.3.0...sdk-config-v2.3.1) (2026-06-15)


### ♻️ Refactoring

* rename util function ([#899](https://github.com/cowprotocol/cow-sdk/issues/899)) ([095e280](https://github.com/cowprotocol/cow-sdk/commit/095e280ce0fa99f6fc71efd61ea146c70f061684))

## [2.3.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-config-v2.2.1...sdk-config-v2.3.0) (2026-06-08)


### ✨ Features

* internal ids for evm chains ([#891](https://github.com/cowprotocol/cow-sdk/issues/891)) ([1c3c961](https://github.com/cowprotocol/cow-sdk/commit/1c3c9619c3d0ee832ce43a2d695ad650c2ec7a18))

## [2.2.1](https://github.com/cowprotocol/cow-sdk/compare/sdk-config-v2.2.0...sdk-config-v2.2.1) (2026-06-02)


### 🐛 Bug Fixes

* trigger release please ([#890](https://github.com/cowprotocol/cow-sdk/issues/890)) ([cc11990](https://github.com/cowprotocol/cow-sdk/commit/cc11990047e4d77a450582a84a07a453f4a7ccc8))

## [2.2.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-config-v2.1.0...sdk-config-v2.2.0) (2026-05-27)


### ✨ Features

* move solana to supported chain id ([#873](https://github.com/cowprotocol/cow-sdk/issues/873)) ([da8a7c2](https://github.com/cowprotocol/cow-sdk/commit/da8a7c24cd07afcd465199844c480ebe3e81383d))

## [2.1.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-config-v2.0.0...sdk-config-v2.1.0) (2026-05-22)


### ✨ Features

* **order-book:** add bearer token support in ApiContext ([#825](https://github.com/cowprotocol/cow-sdk/issues/825)) ([d605ba4](https://github.com/cowprotocol/cow-sdk/commit/d605ba4579d3fe12b043ecb22d2608018e0962ba))

## [2.0.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-config-v1.2.0...sdk-config-v2.0.0) (2026-04-16)


### ⚠ BREAKING CHANGES

* bring cow.fi back ([#863](https://github.com/cowprotocol/cow-sdk/issues/863))

### ✨ Features

* bring cow.fi back ([#863](https://github.com/cowprotocol/cow-sdk/issues/863)) ([d607fd2](https://github.com/cowprotocol/cow-sdk/commit/d607fd2cfbc93ace39de04f3a7870f723fdd9b21))

## [1.2.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-config-v1.1.3...sdk-config-v1.2.0) (2026-04-14)


### ✨ Features

* migrate to cow.finance domain ([#860](https://github.com/cowprotocol/cow-sdk/issues/860)) ([a4e7633](https://github.com/cowprotocol/cow-sdk/commit/a4e76333b7a276baec5c977f44b15498550d8e50))

## [1.1.3](https://github.com/cowprotocol/cow-sdk/compare/sdk-config-v1.1.2...sdk-config-v1.1.3) (2026-04-08)


### 🐛 Bug Fixes

* use adaptToken if contract address is empty ([#850](https://github.com/cowprotocol/cow-sdk/issues/850)) ([d57c397](https://github.com/cowprotocol/cow-sdk/commit/d57c3972d9104fbf846e15a831d004d4e20b961f))

## [1.1.2](https://github.com/cowprotocol/cow-sdk/compare/sdk-config-v1.1.1...sdk-config-v1.1.2) (2026-03-17)


### 🐛 Bug Fixes

* use pnpm trusted publishing ([#841](https://github.com/cowprotocol/cow-sdk/issues/841)) ([1885b6f](https://github.com/cowprotocol/cow-sdk/commit/1885b6fa2a006670e3bb51a2ac8b60ed9c157eba))

## [1.1.1](https://github.com/cowprotocol/cow-sdk/compare/sdk-config-v1.1.0...sdk-config-v1.1.1) (2026-03-16)


### 🐛 Bug Fixes

* use standard npm publishing ([#839](https://github.com/cowprotocol/cow-sdk/issues/839)) ([b2e2966](https://github.com/cowprotocol/cow-sdk/commit/b2e2966dbe96b7e20880af966e6e6024055d2845))

## [1.1.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-config-v1.0.0...sdk-config-v1.1.0) (2026-03-16)


### ✨ Features

* update settlement and vault relayer contracts on staging ([#807](https://github.com/cowprotocol/cow-sdk/issues/807)) ([0f9a03e](https://github.com/cowprotocol/cow-sdk/commit/0f9a03e6bfa3468630e46735f7583618ae711b73))


### 🔧 Miscellaneous

* release main ([#826](https://github.com/cowprotocol/cow-sdk/issues/826)) ([baaa708](https://github.com/cowprotocol/cow-sdk/commit/baaa7088ac15b89fb83310e54aa52f09d19132ff))
* release main ([#832](https://github.com/cowprotocol/cow-sdk/issues/832)) ([5dafcb8](https://github.com/cowprotocol/cow-sdk/commit/5dafcb8ec5593250dba1ff6e9fdbf8eb11d974cf))
* remove unused lens assets ([#823](https://github.com/cowprotocol/cow-sdk/issues/823)) ([9cb9513](https://github.com/cowprotocol/cow-sdk/commit/9cb9513e49aa22a3a0f33546184b17f89d3d9c76))
* revert release ([#833](https://github.com/cowprotocol/cow-sdk/issues/833)) ([0c40a9b](https://github.com/cowprotocol/cow-sdk/commit/0c40a9b3ee828c7ede66576f02e1b571e96140cd))

## [1.0.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-config-v0.10.0...sdk-config-v1.0.0) (2026-03-10)


### ⚠ BREAKING CHANGES

* **chains:** Remove support for Lens.

### ✨ Features

* **chains:** Remove Lens ([#818](https://github.com/cowprotocol/cow-sdk/issues/818)) ([e8c74a0](https://github.com/cowprotocol/cow-sdk/commit/e8c74a078e5940901591652164af7b2ffb7b1fa6))

## [0.10.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-config-v0.9.0...sdk-config-v0.10.0) (2026-03-04)


### ✨ Features

* Add non-evm chains types & guards & address validators  ([#792](https://github.com/cowprotocol/cow-sdk/issues/792)) ([b4b6047](https://github.com/cowprotocol/cow-sdk/commit/b4b6047889190f668f6409aeee7079ba6095f9ae))

## [0.9.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-config-v0.8.1...sdk-config-v0.9.0) (2026-03-04)


### ✨ Features

* add API endpoints for partners ([#809](https://github.com/cowprotocol/cow-sdk/issues/809)) ([59900e8](https://github.com/cowprotocol/cow-sdk/commit/59900e854a336e294ec881bd70bb13e579ff48ec))

## [0.8.1](https://github.com/cowprotocol/cow-sdk/compare/sdk-config-v0.8.0...sdk-config-v0.8.1) (2026-02-20)


### 🐛 Bug Fixes

* **networks:** remove isUnderDevelopment flag from Ink ([#803](https://github.com/cowprotocol/cow-sdk/issues/803)) ([8baeaa6](https://github.com/cowprotocol/cow-sdk/commit/8baeaa657f0f7760ea26917b68cbf0ab70ac4905))
* **networks:** remove isUnderDevelopment flag from Ink ([#803](https://github.com/cowprotocol/cow-sdk/issues/803)) ([8baeaa6](https://github.com/cowprotocol/cow-sdk/commit/8baeaa657f0f7760ea26917b68cbf0ab70ac4905))

## [0.8.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-config-v0.7.3...sdk-config-v0.8.0) (2026-02-18)


### ✨ Features

* **deprecated-chains:** add isDeprecated flag and mark Lens as such ([#801](https://github.com/cowprotocol/cow-sdk/issues/801)) ([e0663c6](https://github.com/cowprotocol/cow-sdk/commit/e0663c69c0b5d92bae45570f27105d6cfd04b96a))

## [0.7.3](https://github.com/cowprotocol/cow-sdk/compare/sdk-config-v0.7.2...sdk-config-v0.7.3) (2026-02-02)


### 🔧 Miscellaneous

* revert revert Ink network ([#789](https://github.com/cowprotocol/cow-sdk/issues/789)) ([a00dbbd](https://github.com/cowprotocol/cow-sdk/commit/a00dbbd6a26238bcee2d4452487d16551560c59f))

## [0.7.2](https://github.com/cowprotocol/cow-sdk/compare/sdk-config-v0.7.1...sdk-config-v0.7.2) (2026-02-02)


### 🐛 Bug Fixes

* support decimals in protocolFeeBps ([#787](https://github.com/cowprotocol/cow-sdk/issues/787)) ([f53ae65](https://github.com/cowprotocol/cow-sdk/commit/f53ae65931d85e354779767ed67e0e4df944a2bc))

## [0.7.1](https://github.com/cowprotocol/cow-sdk/compare/sdk-config-v0.7.0...sdk-config-v0.7.1) (2026-01-28)


### 🐛 Bug Fixes

* **ink:** swap Ink logo with filled version ([#783](https://github.com/cowprotocol/cow-sdk/issues/783)) ([bfc0ba7](https://github.com/cowprotocol/cow-sdk/commit/bfc0ba72108bf376bdcdd2194ba312c6b8a50e3a))

## [0.7.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-config-v0.6.3...sdk-config-v0.7.0) (2026-01-28)


### ✨ Features

* **ink:** reapply "feat/COW-163: Add Ink network ([#781](https://github.com/cowprotocol/cow-sdk/issues/781))" ([7c23332](https://github.com/cowprotocol/cow-sdk/commit/7c23332dac4f8c91d5f75ae68297906e20f20362))

## [0.6.3](https://github.com/cowprotocol/cow-sdk/compare/sdk-config-v0.6.2...sdk-config-v0.6.3) (2026-01-19)


### 🐛 Bug Fixes

* unify spelling for chain explorers ([#773](https://github.com/cowprotocol/cow-sdk/issues/773)) ([e89c4ba](https://github.com/cowprotocol/cow-sdk/commit/e89c4baa769b9f14982e8f4c7d19fdb8a6e2e5f6))

## [0.6.2](https://github.com/cowprotocol/cow-sdk/compare/sdk-config-v0.6.1...sdk-config-v0.6.2) (2025-12-11)


### 🐛 Bug Fixes

* remove isUnderDevelopment flag from plasma ([#739](https://github.com/cowprotocol/cow-sdk/issues/739)) ([b9cf7b7](https://github.com/cowprotocol/cow-sdk/commit/b9cf7b7a6405d27b11719128a7680a771bc3e602))

## [0.6.1](https://github.com/cowprotocol/cow-sdk/compare/sdk-config-v0.6.0...sdk-config-v0.6.1) (2025-12-05)


### 🐛 Bug Fixes

* linea no longer under dev ([#734](https://github.com/cowprotocol/cow-sdk/issues/734)) ([548bf29](https://github.com/cowprotocol/cow-sdk/commit/548bf2917a71117bf981b254d0211baacdbc9fff))

## [0.6.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-config-v0.5.0...sdk-config-v0.6.0) (2025-12-04)


### ✨ Features

* use aws for token and chain images ([#724](https://github.com/cowprotocol/cow-sdk/issues/724)) ([1b23c5e](https://github.com/cowprotocol/cow-sdk/commit/1b23c5e5f7e1763b710b95f444ad052395808277))


### 🔧 Miscellaneous

* revert use aws for token and chain images ([#724](https://github.com/cowprotocol/cow-sdk/issues/724)) ([f73bc96](https://github.com/cowprotocol/cow-sdk/commit/f73bc96156796ce4928f64f963295501dfc69a5c))

## [0.5.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-config-v0.4.1...sdk-config-v0.5.0) (2025-12-03)


### ✨ Features

* use aws for token and chain images ([#724](https://github.com/cowprotocol/cow-sdk/issues/724)) ([2a8e220](https://github.com/cowprotocol/cow-sdk/commit/2a8e2205acc5143efecbc9caee89d01f32570e0d))

## [0.4.1](https://github.com/cowprotocol/cow-sdk/compare/sdk-config-v0.4.0...sdk-config-v0.4.1) (2025-11-27)


### 🐛 Bug Fixes

* use the blue linea logo instead of the yellow one ([#717](https://github.com/cowprotocol/cow-sdk/issues/717)) ([e044446](https://github.com/cowprotocol/cow-sdk/commit/e0444463b7097b8ebc0134aeacfdf460e4b51684))

## [0.4.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-config-v0.3.0...sdk-config-v0.4.0) (2025-11-24)


### ✨ Features

* **bridge:** support Near bridge provider ([#642](https://github.com/cowprotocol/cow-sdk/issues/642)) ([c7d8633](https://github.com/cowprotocol/cow-sdk/commit/c7d86335601cfd772d72dfe65a0e941ce916769a))

## [0.3.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-config-v0.2.0...sdk-config-v0.3.0) (2025-11-05)


### ✨ Features

* **new-chains:** add q4 chains ([#606](https://github.com/cowprotocol/cow-sdk/issues/606)) ([2501382](https://github.com/cowprotocol/cow-sdk/commit/2501382e80acb7f6bb0f87adbb5a9325de2c56cc))

## [0.2.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-config-v0.1.0...sdk-config-v0.2.0) (2025-10-24)


### ✨ Features

* add isUnderDevelopment flag to chain info ([#597](https://github.com/cowprotocol/cow-sdk/issues/597)) ([f502fa9](https://github.com/cowprotocol/cow-sdk/commit/f502fa9aea85915ef92192539ec1ff9f2651e534))

## [0.1.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-config-v0.3.3-beta.0...sdk-config-v0.1.0) (2025-09-17)


### ⚠ BREAKING CHANGES

* release cow-sdk v7

### ✨ Features

* release cow-sdk v7 ([6cd3e57](https://github.com/cowprotocol/cow-sdk/commit/6cd3e573687b1ffdbc0fdcb8cdbb414d88546e38))

## [0.3.3-beta.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-config-v0.3.2-beta.0...sdk-config-v0.3.3-beta.0) (2025-09-16)


### 📚 Documentation

* update README to focus on main use cases ([#493](https://github.com/cowprotocol/cow-sdk/issues/493)) ([a05cb1b](https://github.com/cowprotocol/cow-sdk/commit/a05cb1ba11b5f9895d7cfe6262cf74c4089fd73c))

## [0.3.2-beta.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-config-v0.3.1-beta.0...sdk-config-v0.3.2-beta.0) (2025-09-15)


### 🐛 Bug Fixes

* fix gnosis native token url ([#501](https://github.com/cowprotocol/cow-sdk/issues/501)) ([4d5176e](https://github.com/cowprotocol/cow-sdk/commit/4d5176e85594f45d96a5d9d7aa7285cbf3cfebf2))

## [0.3.1-beta.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-config-v0.3.0-beta.0...sdk-config-v0.3.1-beta.0) (2025-09-15)


### 🐛 Bug Fixes

* **config:** make native token address lower in url ([#499](https://github.com/cowprotocol/cow-sdk/issues/499)) ([96e0dc6](https://github.com/cowprotocol/cow-sdk/commit/96e0dc6fd837f9b67025d6e05959ad9b773c0ed4))

## [0.3.0-beta.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-config-v0.2.1-beta.0...sdk-config-v0.3.0-beta.0) (2025-09-11)


### ✨ Features

* test release of packages ([#485](https://github.com/cowprotocol/cow-sdk/issues/485)) ([74109d8](https://github.com/cowprotocol/cow-sdk/commit/74109d893417c14c1ee476be8040704183e800c6))

## [0.2.1-beta.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-config-v0.2.0-beta.0...sdk-config-v0.2.1-beta.0) (2025-09-01)


### 🐛 Bug Fixes

* migrate lens eth-flow contract address ([#468](https://github.com/cowprotocol/cow-sdk/issues/468)) ([91c87b2](https://github.com/cowprotocol/cow-sdk/commit/91c87b2e31c1b80ef1703d986f4c49811897f3a0))

## [0.2.0-beta.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-config-v0.1.0-beta.0...sdk-config-v0.2.0-beta.0) (2025-08-28)


### ✨ Features

* add monorepo package network images ([#429](https://github.com/cowprotocol/cow-sdk/issues/429)) ([56ef05b](https://github.com/cowprotocol/cow-sdk/commit/56ef05b84a25955cbe6d1f8f74df0ff0fa2bdfff))
* allow changing backoff and limiter per request ([#208](https://github.com/cowprotocol/cow-sdk/issues/208)) ([ebea5ca](https://github.com/cowprotocol/cow-sdk/commit/ebea5ca0858aeb89ae3e5d5407c8903c3ca5178d))
* create config package ([212c4a7](https://github.com/cowprotocol/cow-sdk/commit/212c4a74eae46ff6150138300334e0565f581ad1))
* **lib-agnostic:** migrate latest Bridging changes ([#426](https://github.com/cowprotocol/cow-sdk/issues/426)) ([2359d9b](https://github.com/cowprotocol/cow-sdk/commit/2359d9b903e80ae5bab0cdb92d8cf52ae250da36))
* **lib-agnostic:** migrate latest SDK changes ([#427](https://github.com/cowprotocol/cow-sdk/issues/427)) ([323bab6](https://github.com/cowprotocol/cow-sdk/commit/323bab61eb5adeb4a58bc15e25ffb29d2e1afcbf))
* **monorepo-config:** adjust all package.json and scripts ([23dc2a5](https://github.com/cowprotocol/cow-sdk/commit/23dc2a5db02ce3734b55e1151c8579f9a42a4bc5))
* refactor config ([f7fcf73](https://github.com/cowprotocol/cow-sdk/commit/f7fcf73a7fde59b47a5aa2432fddea8e1648fd94))
* **sdk-agnostic-lib:** create cow trading package ([#368](https://github.com/cowprotocol/cow-sdk/issues/368)) ([0a4534a](https://github.com/cowprotocol/cow-sdk/commit/0a4534aababce4f5d8bab991cd6ae9f51842d719))
* **sdk-agnostic-lib:** Create weiroll package ([#371](https://github.com/cowprotocol/cow-sdk/issues/371)) ([8f6a2e1](https://github.com/cowprotocol/cow-sdk/commit/8f6a2e16e5e7a43a5afc43cf5faab174be916b2e))


### ♻️ Refactoring

* move cow-error and wallets.ts and remove duplicate types ([4a7e5d6](https://github.com/cowprotocol/cow-sdk/commit/4a7e5d6d035ccebf05cce437f0409220f39b643a))


### 🔧 Miscellaneous

* migrate latest changes from main 26-08-2025 ([#445](https://github.com/cowprotocol/cow-sdk/issues/445)) ([698937c](https://github.com/cowprotocol/cow-sdk/commit/698937c0feff3a254873371bc1ef791917e6294e))
* **sdk-agnostic-lib:** merge multiple PRs to avoid conflicts and speed up base branch sync ([#354](https://github.com/cowprotocol/cow-sdk/issues/354)) ([55d3068](https://github.com/cowprotocol/cow-sdk/commit/55d3068c52217dd2618d8c180ab4fed8c9334c72))
* update sdk-config tsconfig ([8666af4](https://github.com/cowprotocol/cow-sdk/commit/8666af48c60cd1d6e945f8412b192029299f7c90))
