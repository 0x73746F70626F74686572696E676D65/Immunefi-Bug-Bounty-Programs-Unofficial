# Changelog

## [1.1.16](https://github.com/cowprotocol/cow-sdk/compare/sdk-order-signing-v1.1.15...sdk-order-signing-v1.1.16) (2026-10-01)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-order-book bumped to 4.3.0

## [1.1.15](https://github.com/cowprotocol/cow-sdk/compare/sdk-order-signing-v1.1.14...sdk-order-signing-v1.1.15) (2026-09-29)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.14.2
    * @cowprotocol/sdk-config bumped to 2.7.2
    * @cowprotocol/sdk-contracts-ts bumped to 3.7.2
    * @cowprotocol/sdk-order-book bumped to 4.2.1
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.4.18
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.4.18
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.33

## [1.1.14](https://github.com/cowprotocol/cow-sdk/compare/sdk-order-signing-v1.1.13...sdk-order-signing-v1.1.14) (2026-09-25)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-order-book bumped to 4.2.0

## [1.1.13](https://github.com/cowprotocol/cow-sdk/compare/sdk-order-signing-v1.1.12...sdk-order-signing-v1.1.13) (2026-09-25)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.14.1
    * @cowprotocol/sdk-config bumped to 2.7.1
    * @cowprotocol/sdk-contracts-ts bumped to 3.7.1
    * @cowprotocol/sdk-order-book bumped to 4.1.1
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.4.17
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.4.17
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.32

## [1.1.12](https://github.com/cowprotocol/cow-sdk/compare/sdk-order-signing-v1.1.11...sdk-order-signing-v1.1.12) (2026-09-21)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.14.0
    * @cowprotocol/sdk-contracts-ts bumped to 3.7.0
    * @cowprotocol/sdk-order-book bumped to 4.1.0
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.4.16
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.4.16
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.31

## [1.1.11](https://github.com/cowprotocol/cow-sdk/compare/sdk-order-signing-v1.1.10...sdk-order-signing-v1.1.11) (2026-09-18)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.13.1
    * @cowprotocol/sdk-config bumped to 2.7.0
    * @cowprotocol/sdk-contracts-ts bumped to 3.6.0
    * @cowprotocol/sdk-order-book bumped to 4.0.6
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.4.15
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.4.15
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.30

## [1.1.10](https://github.com/cowprotocol/cow-sdk/compare/sdk-order-signing-v1.1.9...sdk-order-signing-v1.1.10) (2026-09-16)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.13.0
    * @cowprotocol/sdk-contracts-ts bumped to 3.5.2
    * @cowprotocol/sdk-order-book bumped to 4.0.5
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.4.14
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.4.14
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.29

## [1.1.9](https://github.com/cowprotocol/cow-sdk/compare/sdk-order-signing-v1.1.8...sdk-order-signing-v1.1.9) (2026-09-07)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.12.3
    * @cowprotocol/sdk-config bumped to 2.6.0
    * @cowprotocol/sdk-contracts-ts bumped to 3.5.1
    * @cowprotocol/sdk-order-book bumped to 4.0.4
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.4.13
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.4.13
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.28

## [1.1.8](https://github.com/cowprotocol/cow-sdk/compare/sdk-order-signing-v1.1.7...sdk-order-signing-v1.1.8) (2026-09-04)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.12.2
    * @cowprotocol/sdk-config bumped to 2.5.0
    * @cowprotocol/sdk-contracts-ts bumped to 3.5.0
    * @cowprotocol/sdk-order-book bumped to 4.0.3
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.4.12
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.4.12
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.27

## [1.1.7](https://github.com/cowprotocol/cow-sdk/compare/sdk-order-signing-v1.1.6...sdk-order-signing-v1.1.7) (2026-09-01)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-contracts-ts bumped to 3.4.0

## [1.1.6](https://github.com/cowprotocol/cow-sdk/compare/sdk-order-signing-v1.1.5...sdk-order-signing-v1.1.6) (2026-07-29)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.12.1
    * @cowprotocol/sdk-config bumped to 2.4.0
    * @cowprotocol/sdk-contracts-ts bumped to 3.3.3
    * @cowprotocol/sdk-order-book bumped to 4.0.2
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.4.11
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.4.11
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.26

## [1.1.5](https://github.com/cowprotocol/cow-sdk/compare/sdk-order-signing-v1.1.4...sdk-order-signing-v1.1.5) (2026-07-28)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-contracts-ts bumped to 3.3.2

## [1.1.4](https://github.com/cowprotocol/cow-sdk/compare/sdk-order-signing-v1.1.3...sdk-order-signing-v1.1.4) (2026-07-22)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-contracts-ts bumped to 3.3.1

## [1.1.3](https://github.com/cowprotocol/cow-sdk/compare/sdk-order-signing-v1.1.2...sdk-order-signing-v1.1.3) (2026-07-22)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-contracts-ts bumped to 3.3.0
  * devDependencies
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.25

## [1.1.2](https://github.com/cowprotocol/cow-sdk/compare/sdk-order-signing-v1.1.1...sdk-order-signing-v1.1.2) (2026-06-23)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-contracts-ts bumped to 3.2.1

## [1.1.1](https://github.com/cowprotocol/cow-sdk/compare/sdk-order-signing-v1.1.0...sdk-order-signing-v1.1.1) (2026-06-17)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-order-book bumped to 4.0.1

## [1.1.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-order-signing-v1.0.6...sdk-order-signing-v1.1.0) (2026-06-15)


### ✨ Features

* per-package test coverage badges, updated in CI ([#895](https://github.com/cowprotocol/cow-sdk/issues/895)) ([c73246c](https://github.com/cowprotocol/cow-sdk/commit/c73246cc52c4fc79b2628b7c5f580695fd3dc1e2))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.12.0
    * @cowprotocol/sdk-config bumped to 2.3.1
    * @cowprotocol/sdk-contracts-ts bumped to 3.2.0
    * @cowprotocol/sdk-order-book bumped to 4.0.0
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.4.10
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.4.10
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.24

## [1.0.6](https://github.com/cowprotocol/cow-sdk/compare/sdk-order-signing-v1.0.5...sdk-order-signing-v1.0.6) (2026-06-08)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.11.2
    * @cowprotocol/sdk-config bumped to 2.3.0
    * @cowprotocol/sdk-contracts-ts bumped to 3.1.2
    * @cowprotocol/sdk-order-book bumped to 3.2.2
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.4.9
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.4.9
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.23

## [1.0.5](https://github.com/cowprotocol/cow-sdk/compare/sdk-order-signing-v1.0.4...sdk-order-signing-v1.0.5) (2026-06-02)


### 🔧 Miscellaneous

* Update openapi.yml version ([#888](https://github.com/cowprotocol/cow-sdk/issues/888)) ([b8a3726](https://github.com/cowprotocol/cow-sdk/commit/b8a37263195afba0a12a42c879eb13c1a2cc2e8b))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.11.1
    * @cowprotocol/sdk-config bumped to 2.2.1
    * @cowprotocol/sdk-contracts-ts bumped to 3.1.1
    * @cowprotocol/sdk-order-book bumped to 3.2.1
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.4.8
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.4.8
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.22

## [1.0.4](https://github.com/cowprotocol/cow-sdk/compare/sdk-order-signing-v1.0.3...sdk-order-signing-v1.0.4) (2026-05-27)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.11.0
    * @cowprotocol/sdk-config bumped to 2.2.0
    * @cowprotocol/sdk-contracts-ts bumped to 3.1.0
    * @cowprotocol/sdk-order-book bumped to 3.2.0
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.4.7
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.4.7
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.21

## [1.0.3](https://github.com/cowprotocol/cow-sdk/compare/sdk-order-signing-v1.0.2...sdk-order-signing-v1.0.3) (2026-05-22)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.10.3
    * @cowprotocol/sdk-config bumped to 2.1.0
    * @cowprotocol/sdk-contracts-ts bumped to 3.0.3
    * @cowprotocol/sdk-order-book bumped to 3.1.0
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.4.6
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.4.6
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.20

## [1.0.2](https://github.com/cowprotocol/cow-sdk/compare/sdk-order-signing-v1.0.1...sdk-order-signing-v1.0.2) (2026-05-20)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-contracts-ts bumped to 3.0.2
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.4.5
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.4.5
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.19

## [1.0.1](https://github.com/cowprotocol/cow-sdk/compare/sdk-order-signing-v1.0.0...sdk-order-signing-v1.0.1) (2026-04-20)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-contracts-ts bumped to 3.0.1

## [1.0.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-order-signing-v0.3.0...sdk-order-signing-v1.0.0) (2026-04-16)


### ⚠ BREAKING CHANGES

* bring cow.fi back ([#863](https://github.com/cowprotocol/cow-sdk/issues/863))

### ✨ Features

* bring cow.fi back ([#863](https://github.com/cowprotocol/cow-sdk/issues/863)) ([d607fd2](https://github.com/cowprotocol/cow-sdk/commit/d607fd2cfbc93ace39de04f3a7870f723fdd9b21))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.10.2
    * @cowprotocol/sdk-config bumped to 2.0.0
    * @cowprotocol/sdk-contracts-ts bumped to 3.0.0
    * @cowprotocol/sdk-order-book bumped to 3.0.0
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.4.4
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.4.4
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.18

## [0.3.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-order-signing-v0.2.5...sdk-order-signing-v0.3.0) (2026-04-14)


### ✨ Features

* migrate to cow.finance domain ([#860](https://github.com/cowprotocol/cow-sdk/issues/860)) ([a4e7633](https://github.com/cowprotocol/cow-sdk/commit/a4e76333b7a276baec5c977f44b15498550d8e50))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.10.1
    * @cowprotocol/sdk-config bumped to 1.2.0
    * @cowprotocol/sdk-contracts-ts bumped to 2.5.0
    * @cowprotocol/sdk-order-book bumped to 2.1.0
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.4.3
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.4.3
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.17

## [0.2.5](https://github.com/cowprotocol/cow-sdk/compare/sdk-order-signing-v0.2.4...sdk-order-signing-v0.2.5) (2026-04-08)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.10.0
    * @cowprotocol/sdk-config bumped to 1.1.3
    * @cowprotocol/sdk-contracts-ts bumped to 2.4.0
    * @cowprotocol/sdk-order-book bumped to 2.0.5
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.4.2
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.4.2
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.16

## [0.2.4](https://github.com/cowprotocol/cow-sdk/compare/sdk-order-signing-v0.2.3...sdk-order-signing-v0.2.4) (2026-04-01)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.9.0
    * @cowprotocol/sdk-contracts-ts bumped to 2.3.0
    * @cowprotocol/sdk-order-book bumped to 2.0.4
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.4.1
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.4.1
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.15

## [0.2.3](https://github.com/cowprotocol/cow-sdk/compare/sdk-order-signing-v0.2.2...sdk-order-signing-v0.2.3) (2026-03-17)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-contracts-ts bumped to 2.2.0
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.4.0
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.4.0

## [0.2.2](https://github.com/cowprotocol/cow-sdk/compare/sdk-order-signing-v0.2.1...sdk-order-signing-v0.2.2) (2026-03-17)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.8.2
    * @cowprotocol/sdk-config bumped to 1.1.2
    * @cowprotocol/sdk-contracts-ts bumped to 2.1.2
    * @cowprotocol/sdk-order-book bumped to 2.0.3
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.3.14
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.3.14
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.14

## [0.2.1](https://github.com/cowprotocol/cow-sdk/compare/sdk-order-signing-v0.2.0...sdk-order-signing-v0.2.1) (2026-03-16)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.8.1
    * @cowprotocol/sdk-config bumped to 1.1.1
    * @cowprotocol/sdk-contracts-ts bumped to 2.1.1
    * @cowprotocol/sdk-order-book bumped to 2.0.2
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.3.13
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.3.13
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.13

## [0.2.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-order-signing-v0.1.38...sdk-order-signing-v0.2.0) (2026-03-16)


### ✨ Features

* update settlement and vault relayer contracts on staging ([#807](https://github.com/cowprotocol/cow-sdk/issues/807)) ([0f9a03e](https://github.com/cowprotocol/cow-sdk/commit/0f9a03e6bfa3468630e46735f7583618ae711b73))


### 🔧 Miscellaneous

* release main ([#826](https://github.com/cowprotocol/cow-sdk/issues/826)) ([baaa708](https://github.com/cowprotocol/cow-sdk/commit/baaa7088ac15b89fb83310e54aa52f09d19132ff))
* release main ([#832](https://github.com/cowprotocol/cow-sdk/issues/832)) ([5dafcb8](https://github.com/cowprotocol/cow-sdk/commit/5dafcb8ec5593250dba1ff6e9fdbf8eb11d974cf))
* revert release ([#833](https://github.com/cowprotocol/cow-sdk/issues/833)) ([0c40a9b](https://github.com/cowprotocol/cow-sdk/commit/0c40a9b3ee828c7ede66576f02e1b571e96140cd))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.8.0
    * @cowprotocol/sdk-config bumped to 1.1.0
    * @cowprotocol/sdk-contracts-ts bumped to 2.1.0
    * @cowprotocol/sdk-order-book bumped to 2.0.1
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.3.12
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.3.12
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.12

## [0.1.38](https://github.com/cowprotocol/cow-sdk/compare/sdk-order-signing-v0.1.37...sdk-order-signing-v0.1.38) (2026-03-10)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.7.1
    * @cowprotocol/sdk-config bumped to 1.0.0
    * @cowprotocol/sdk-contracts-ts bumped to 2.0.0
    * @cowprotocol/sdk-order-book bumped to 2.0.0
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.3.11
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.3.11
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.11

## [0.1.37](https://github.com/cowprotocol/cow-sdk/compare/sdk-order-signing-v0.1.36...sdk-order-signing-v0.1.37) (2026-03-10)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-order-book bumped to 1.1.2

## [0.1.36](https://github.com/cowprotocol/cow-sdk/compare/sdk-order-signing-v0.1.35...sdk-order-signing-v0.1.36) (2026-03-04)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.7.0
    * @cowprotocol/sdk-config bumped to 0.10.0
    * @cowprotocol/sdk-contracts-ts bumped to 1.8.0
    * @cowprotocol/sdk-order-book bumped to 1.1.1
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.3.10
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.3.10
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.10

## [0.1.35](https://github.com/cowprotocol/cow-sdk/compare/sdk-order-signing-v0.1.34...sdk-order-signing-v0.1.35) (2026-03-04)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.6.3
    * @cowprotocol/sdk-config bumped to 0.9.0
    * @cowprotocol/sdk-contracts-ts bumped to 1.7.0
    * @cowprotocol/sdk-order-book bumped to 1.1.0
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.3.9
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.3.9
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.9

## [0.1.34](https://github.com/cowprotocol/cow-sdk/compare/sdk-order-signing-v0.1.33...sdk-order-signing-v0.1.34) (2026-02-26)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-order-book bumped to 1.0.0

## [0.1.33](https://github.com/cowprotocol/cow-sdk/compare/sdk-order-signing-v0.1.32...sdk-order-signing-v0.1.33) (2026-02-20)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.6.2
    * @cowprotocol/sdk-config bumped to 0.8.1
    * @cowprotocol/sdk-contracts-ts bumped to 1.6.1
    * @cowprotocol/sdk-order-book bumped to 0.6.6
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.3.8
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.3.8
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.8

## [0.1.32](https://github.com/cowprotocol/cow-sdk/compare/sdk-order-signing-v0.1.31...sdk-order-signing-v0.1.32) (2026-02-18)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.6.1
    * @cowprotocol/sdk-config bumped to 0.8.0
    * @cowprotocol/sdk-contracts-ts bumped to 1.6.0
    * @cowprotocol/sdk-order-book bumped to 0.6.5
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.3.7
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.3.7
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.7

## [0.1.31](https://github.com/cowprotocol/cow-sdk/compare/sdk-order-signing-v0.1.30...sdk-order-signing-v0.1.31) (2026-02-05)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.6.0
    * @cowprotocol/sdk-contracts-ts bumped to 1.5.0
    * @cowprotocol/sdk-order-book bumped to 0.6.4
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.3.6
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.3.6
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.6

## [0.1.30](https://github.com/cowprotocol/cow-sdk/compare/sdk-order-signing-v0.1.29...sdk-order-signing-v0.1.30) (2026-02-02)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.5.4
    * @cowprotocol/sdk-config bumped to 0.7.3
    * @cowprotocol/sdk-contracts-ts bumped to 1.4.2
    * @cowprotocol/sdk-order-book bumped to 0.6.3
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.3.5
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.3.5
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.5

## [0.1.29](https://github.com/cowprotocol/cow-sdk/compare/sdk-order-signing-v0.1.28...sdk-order-signing-v0.1.29) (2026-02-02)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.5.3
    * @cowprotocol/sdk-config bumped to 0.7.2
    * @cowprotocol/sdk-contracts-ts bumped to 1.4.1
    * @cowprotocol/sdk-order-book bumped to 0.6.2
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.3.4
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.3.4
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.4

## [0.1.28](https://github.com/cowprotocol/cow-sdk/compare/sdk-order-signing-v0.1.27...sdk-order-signing-v0.1.28) (2026-01-28)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.5.2
    * @cowprotocol/sdk-config bumped to 0.7.1
    * @cowprotocol/sdk-contracts-ts bumped to 1.4.0
    * @cowprotocol/sdk-order-book bumped to 0.6.1
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.3.3
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.3.3
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.3

## [0.1.27](https://github.com/cowprotocol/cow-sdk/compare/sdk-order-signing-v0.1.26...sdk-order-signing-v0.1.27) (2026-01-28)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.5.1
    * @cowprotocol/sdk-config bumped to 0.7.0
    * @cowprotocol/sdk-contracts-ts bumped to 1.3.0
    * @cowprotocol/sdk-order-book bumped to 0.6.0
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.3.2
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.3.2
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.2

## [0.1.26](https://github.com/cowprotocol/cow-sdk/compare/sdk-order-signing-v0.1.25...sdk-order-signing-v0.1.26) (2026-01-22)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-contracts-ts bumped to 1.2.0

## [0.1.25](https://github.com/cowprotocol/cow-sdk/compare/sdk-order-signing-v0.1.24...sdk-order-signing-v0.1.25) (2026-01-21)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-contracts-ts bumped to 1.1.1

## [0.1.24](https://github.com/cowprotocol/cow-sdk/compare/sdk-order-signing-v0.1.23...sdk-order-signing-v0.1.24) (2026-01-19)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.5.0
    * @cowprotocol/sdk-config bumped to 0.6.3
    * @cowprotocol/sdk-contracts-ts bumped to 1.1.0
    * @cowprotocol/sdk-order-book bumped to 0.5.1
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.3.1
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.3.1
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.1

## [0.1.23](https://github.com/cowprotocol/cow-sdk/compare/sdk-order-signing-v0.1.22...sdk-order-signing-v0.1.23) (2025-12-22)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-order-book bumped to 0.5.0

## [0.1.22](https://github.com/cowprotocol/cow-sdk/compare/sdk-order-signing-v0.1.21...sdk-order-signing-v0.1.22) (2025-12-19)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-contracts-ts bumped to 1.0.0

## [0.1.21](https://github.com/cowprotocol/cow-sdk/compare/sdk-order-signing-v0.1.20...sdk-order-signing-v0.1.21) (2025-12-11)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-config bumped to 0.6.2
    * @cowprotocol/sdk-contracts-ts bumped to 0.8.1
    * @cowprotocol/sdk-order-book bumped to 0.4.4

## [0.1.20](https://github.com/cowprotocol/cow-sdk/compare/sdk-order-signing-v0.1.19...sdk-order-signing-v0.1.20) (2025-12-10)


### 🔧 Miscellaneous

* release main ([#741](https://github.com/cowprotocol/cow-sdk/issues/741)) ([32fb8bb](https://github.com/cowprotocol/cow-sdk/commit/32fb8bbe6b1172c2666f330d0d50cdc2f7c2554f))
* revert not published release ([5facf05](https://github.com/cowprotocol/cow-sdk/commit/5facf05c67121404b7b5aa1e77950961b06eca81))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-contracts-ts bumped to 0.8.0

## [0.1.19](https://github.com/cowprotocol/cow-sdk/compare/sdk-order-signing-v0.1.18...sdk-order-signing-v0.1.19) (2025-12-05)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-config bumped to 0.6.1
    * @cowprotocol/sdk-contracts-ts bumped to 0.7.4
    * @cowprotocol/sdk-order-book bumped to 0.4.3

## [0.1.18](https://github.com/cowprotocol/cow-sdk/compare/sdk-order-signing-v0.1.17...sdk-order-signing-v0.1.18) (2025-12-04)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-config bumped to 0.6.0
    * @cowprotocol/sdk-contracts-ts bumped to 0.7.3
    * @cowprotocol/sdk-order-book bumped to 0.4.2

## [0.1.17](https://github.com/cowprotocol/cow-sdk/compare/sdk-order-signing-v0.1.16...sdk-order-signing-v0.1.17) (2025-12-03)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-config bumped to 0.5.0
    * @cowprotocol/sdk-contracts-ts bumped to 0.7.2
    * @cowprotocol/sdk-order-book bumped to 0.4.1

## [0.1.16](https://github.com/cowprotocol/cow-sdk/compare/sdk-order-signing-v0.1.15...sdk-order-signing-v0.1.16) (2025-12-01)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-order-book bumped to 0.4.0

## [0.1.15](https://github.com/cowprotocol/cow-sdk/compare/sdk-order-signing-v0.1.14...sdk-order-signing-v0.1.15) (2025-11-27)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-order-book bumped to 0.3.2

## [0.1.14](https://github.com/cowprotocol/cow-sdk/compare/sdk-order-signing-v0.1.13...sdk-order-signing-v0.1.14) (2025-11-27)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-config bumped to 0.4.1
    * @cowprotocol/sdk-contracts-ts bumped to 0.7.1
    * @cowprotocol/sdk-order-book bumped to 0.3.1

## [0.1.13](https://github.com/cowprotocol/cow-sdk/compare/sdk-order-signing-v0.1.12...sdk-order-signing-v0.1.13) (2025-11-24)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-contracts-ts bumped to 0.7.0

## [0.1.12](https://github.com/cowprotocol/cow-sdk/compare/sdk-order-signing-v0.1.11...sdk-order-signing-v0.1.12) (2025-11-24)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.4.0
    * @cowprotocol/sdk-config bumped to 0.4.0
    * @cowprotocol/sdk-contracts-ts bumped to 0.6.0
    * @cowprotocol/sdk-order-book bumped to 0.3.0
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.3.0
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.3.0
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.0

## [0.1.11](https://github.com/cowprotocol/cow-sdk/compare/sdk-order-signing-v0.1.10...sdk-order-signing-v0.1.11) (2025-11-07)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-contracts-ts bumped to 0.5.0

## [0.1.10](https://github.com/cowprotocol/cow-sdk/compare/sdk-order-signing-v0.1.9...sdk-order-signing-v0.1.10) (2025-11-05)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-config bumped to 0.3.0
    * @cowprotocol/sdk-contracts-ts bumped to 0.4.4
    * @cowprotocol/sdk-order-book bumped to 0.2.0

## [0.1.9](https://github.com/cowprotocol/cow-sdk/compare/sdk-order-signing-v0.1.8...sdk-order-signing-v0.1.9) (2025-10-30)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-contracts-ts bumped to 0.4.3

## [0.1.8](https://github.com/cowprotocol/cow-sdk/compare/sdk-order-signing-v0.1.7...sdk-order-signing-v0.1.8) (2025-10-29)


### 🔧 Miscellaneous

* release main ([#620](https://github.com/cowprotocol/cow-sdk/issues/620)) ([b36394a](https://github.com/cowprotocol/cow-sdk/commit/b36394a2ba38957edb47ffc4451ea6624d66737b))
* revert release ([#634](https://github.com/cowprotocol/cow-sdk/issues/634)) ([fc7bf61](https://github.com/cowprotocol/cow-sdk/commit/fc7bf61444619d4b2c3a3dd55b7ce52c197b1878))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.3.0
    * @cowprotocol/sdk-contracts-ts bumped to 0.4.2
    * @cowprotocol/sdk-order-book bumped to 0.1.4
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.2.0
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.2.0
    * @cowprotocol/sdk-viem-adapter bumped to 0.2.0

## [0.1.7](https://github.com/cowprotocol/cow-sdk/compare/sdk-order-signing-v0.1.6...sdk-order-signing-v0.1.7) (2025-10-24)


### 🐛 Bug Fixes

* **trading:** add EIP1271 signature support ([#584](https://github.com/cowprotocol/cow-sdk/issues/584)) ([ca9e834](https://github.com/cowprotocol/cow-sdk/commit/ca9e834e2b0edf8a757e01383b2218d5ecfbe25e))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.2.2
    * @cowprotocol/sdk-config bumped to 0.2.0
    * @cowprotocol/sdk-contracts-ts bumped to 0.4.1
    * @cowprotocol/sdk-order-book bumped to 0.1.3
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.1.3
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.1.3
    * @cowprotocol/sdk-viem-adapter bumped to 0.1.3

## [0.1.6](https://github.com/cowprotocol/cow-sdk/compare/sdk-order-signing-v0.1.5...sdk-order-signing-v0.1.6) (2025-10-15)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-contracts-ts bumped to 0.4.0

## [0.1.5](https://github.com/cowprotocol/cow-sdk/compare/sdk-order-signing-v0.1.4...sdk-order-signing-v0.1.5) (2025-10-08)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.2.1
    * @cowprotocol/sdk-contracts-ts bumped to 0.3.1
    * @cowprotocol/sdk-order-book bumped to 0.1.2
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.1.2
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.1.2
    * @cowprotocol/sdk-viem-adapter bumped to 0.1.2

## [0.1.4](https://github.com/cowprotocol/cow-sdk/compare/sdk-order-signing-v0.1.3...sdk-order-signing-v0.1.4) (2025-10-06)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.2.0
    * @cowprotocol/sdk-contracts-ts bumped to 0.3.0
    * @cowprotocol/sdk-order-book bumped to 0.1.1
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.1.1
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.1.1
    * @cowprotocol/sdk-viem-adapter bumped to 0.1.1

## [0.1.3](https://github.com/cowprotocol/cow-sdk/compare/sdk-order-signing-v0.1.2...sdk-order-signing-v0.1.3) (2025-09-24)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-contracts-ts bumped to 0.2.1

## [0.1.2](https://github.com/cowprotocol/cow-sdk/compare/sdk-order-signing-v0.1.1...sdk-order-signing-v0.1.2) (2025-09-23)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-contracts-ts bumped to 0.2.0

## [0.1.1](https://github.com/cowprotocol/cow-sdk/compare/sdk-order-signing-v0.1.0...sdk-order-signing-v0.1.1) (2025-09-22)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-contracts-ts bumped to 0.1.1

## [0.1.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-order-signing-v0.2.8-beta.0...sdk-order-signing-v0.1.0) (2025-09-17)


### ⚠ BREAKING CHANGES

* release cow-sdk v7

### ✨ Features

* release cow-sdk v7 ([6cd3e57](https://github.com/cowprotocol/cow-sdk/commit/6cd3e573687b1ffdbc0fdcb8cdbb414d88546e38))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.1.0
    * @cowprotocol/sdk-config bumped to 0.1.0
    * @cowprotocol/sdk-contracts-ts bumped to 0.1.0
    * @cowprotocol/sdk-order-book bumped to 0.1.0
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.1.0
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.1.0
    * @cowprotocol/sdk-viem-adapter bumped to 0.1.0

## [0.2.8-beta.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-order-signing-v0.2.7-beta.0...sdk-order-signing-v0.2.8-beta.0) (2025-09-17)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.5.0-beta.0
    * @cowprotocol/sdk-contracts-ts bumped to 2.3.0-beta.0
    * @cowprotocol/sdk-order-book bumped to 0.3.1-beta.0
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.2.5-beta.0
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.2.5-beta.0
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.1-beta.0

## [0.2.7-beta.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-order-signing-v0.2.6-beta.0...sdk-order-signing-v0.2.7-beta.0) (2025-09-16)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-contracts-ts bumped to 2.2.1-beta.0
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.2.4-beta.0
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.2.4-beta.0

## [0.2.6-beta.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-order-signing-v0.2.5-beta.0...sdk-order-signing-v0.2.6-beta.0) (2025-09-16)


### 📚 Documentation

* update README to focus on main use cases ([#493](https://github.com/cowprotocol/cow-sdk/issues/493)) ([a05cb1b](https://github.com/cowprotocol/cow-sdk/commit/a05cb1ba11b5f9895d7cfe6262cf74c4089fd73c))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.4.0-beta.0
    * @cowprotocol/sdk-config bumped to 0.3.3-beta.0
    * @cowprotocol/sdk-contracts-ts bumped to 2.2.0-beta.0
    * @cowprotocol/sdk-order-book bumped to 0.3.0-beta.0
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.2.3-beta.0
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.2.3-beta.0
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.0-beta.0

## [0.2.5-beta.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-order-signing-v0.2.4-beta.0...sdk-order-signing-v0.2.5-beta.0) (2025-09-15)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-config bumped to 0.3.2-beta.0
    * @cowprotocol/sdk-contracts-ts bumped to 2.1.7-beta.0
    * @cowprotocol/sdk-order-book bumped to 0.2.4-beta.0

## [0.2.4-beta.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-order-signing-v0.2.3-beta.0...sdk-order-signing-v0.2.4-beta.0) (2025-09-15)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-config bumped to 0.3.1-beta.0
    * @cowprotocol/sdk-contracts-ts bumped to 2.1.6-beta.0
    * @cowprotocol/sdk-order-book bumped to 0.2.3-beta.0

## [0.2.3-beta.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-order-signing-v0.2.2-beta.0...sdk-order-signing-v0.2.3-beta.0) (2025-09-15)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-contracts-ts bumped to 2.1.5-beta.0

## [0.2.2-beta.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-order-signing-v0.2.1-beta.0...sdk-order-signing-v0.2.2-beta.0) (2025-09-11)


### 🔧 Miscellaneous

* release main ([#488](https://github.com/cowprotocol/cow-sdk/issues/488)) ([6344fa6](https://github.com/cowprotocol/cow-sdk/commit/6344fa619465e6f94637677823a18646f06fa7c9))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.3.0-beta.0
    * @cowprotocol/sdk-contracts-ts bumped to 2.1.4-beta.0
    * @cowprotocol/sdk-order-book bumped to 0.2.2-beta.0
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.2.2-beta.0
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.2.2-beta.0
    * @cowprotocol/sdk-viem-adapter bumped to 0.2.2-beta.0

## [0.2.1-beta.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-order-signing-v0.2.0-beta.0...sdk-order-signing-v0.2.1-beta.0) (2025-09-11)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-config bumped to 0.3.0-beta.0
    * @cowprotocol/sdk-contracts-ts bumped to 2.1.3-beta.0
    * @cowprotocol/sdk-order-book bumped to 0.2.1-beta.0

## [0.2.0-beta.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-order-signing-v0.1.0-beta.0...sdk-order-signing-v0.2.0-beta.0) (2025-08-28)


### ✨ Features

* allow changing backoff and limiter per request ([#208](https://github.com/cowprotocol/cow-sdk/issues/208)) ([ebea5ca](https://github.com/cowprotocol/cow-sdk/commit/ebea5ca0858aeb89ae3e5d5407c8903c3ca5178d))
* move order-signing to new package ([c60daab](https://github.com/cowprotocol/cow-sdk/commit/c60daabcd3e9311913f27b519561b7b992958cf4))
* refactor order-signing ([8e28d1b](https://github.com/cowprotocol/cow-sdk/commit/8e28d1bdbda9632347cacaae906298e736f4a7b3))
* refactor order-signing tests ([2d99282](https://github.com/cowprotocol/cow-sdk/commit/2d99282382da1545cd205cf246db0f055e7e0415))
* **sdk-agnostic-lib:** create cow trading package ([#368](https://github.com/cowprotocol/cow-sdk/issues/368)) ([0a4534a](https://github.com/cowprotocol/cow-sdk/commit/0a4534aababce4f5d8bab991cd6ae9f51842d719))
* **sdk-agnostic-lib:** Create weiroll package ([#371](https://github.com/cowprotocol/cow-sdk/issues/371)) ([8f6a2e1](https://github.com/cowprotocol/cow-sdk/commit/8f6a2e16e5e7a43a5afc43cf5faab174be916b2e))
* simplify OrderSigningUtils to use static methods only ([#417](https://github.com/cowprotocol/cow-sdk/issues/417)) ([899ca43](https://github.com/cowprotocol/cow-sdk/commit/899ca4325be831b6711468d1df3733d98fe913b0))


### 🐛 Bug Fixes

* **lib-agnostic:** add setProvider() method to adapters ([#432](https://github.com/cowprotocol/cow-sdk/issues/432)) ([64c0ea9](https://github.com/cowprotocol/cow-sdk/commit/64c0ea94d802aa167b978ae0859353d801de0911))


### 🔧 Miscellaneous

* **sdk-agnostic-lib:** improve scripts and types ([#407](https://github.com/cowprotocol/cow-sdk/issues/407)) ([c4b5e08](https://github.com/cowprotocol/cow-sdk/commit/c4b5e086ce46086e9430d5f03ed330502349fbf3))
* **sdk-agnostic-lib:** merge multiple PRs to avoid conflicts and speed up base branch sync ([#354](https://github.com/cowprotocol/cow-sdk/issues/354)) ([55d3068](https://github.com/cowprotocol/cow-sdk/commit/55d3068c52217dd2618d8c180ab4fed8c9334c72))
