import { AdditionalTargetChainId, ChainInfo, SupportedChainId, TargetChainId } from '../types'
import { mainnet } from '../details/mainnet'
import { gnosisChain } from '../details/gnosis'
import { arbitrumOne } from '../details/arbitrum'
import { base } from '../details/base'
import { sepolia } from '../details/sepolia'
import { avalanche } from '../details/avalanche'
import { polygon } from '../details/polygon'
import { bnb } from '../details/bnb'
import { optimism } from '../details/optimism'
import { linea } from '../details/linea'
import { plasma } from '../details/plasma'
import { ink } from '../details/ink'
import { bitcoin } from '../details/bitcoin'
import { solana } from '../details/solana'

/**
 * Details of all supported chains.
 */
export const ALL_SUPPORTED_CHAINS_MAP: Record<SupportedChainId, ChainInfo> = {
  [SupportedChainId.MAINNET]: mainnet,
  [SupportedChainId.GNOSIS_CHAIN]: gnosisChain,
  [SupportedChainId.ARBITRUM_ONE]: arbitrumOne,
  [SupportedChainId.BASE]: base,
  [SupportedChainId.AVALANCHE]: avalanche,
  [SupportedChainId.POLYGON]: polygon,
  [SupportedChainId.BNB]: bnb,
  [SupportedChainId.PLASMA]: plasma,
  [SupportedChainId.LINEA]: linea,
  [SupportedChainId.INK]: ink,
  [SupportedChainId.SEPOLIA]: sepolia,
  [SupportedChainId.SOLANA]: solana,
}

/**
 * All supported chains.
 */
export const ALL_SUPPORTED_CHAINS = Object.values(ALL_SUPPORTED_CHAINS_MAP)

/**
 * The list of supported chains.
 */
export const ALL_SUPPORTED_CHAIN_IDS: SupportedChainId[] = ALL_SUPPORTED_CHAINS.map(
  (chain) => chain.id,
) as SupportedChainId[]

/**
 * Chains where new trading is allowed (excludes deprecated chains).
 */
export const TRADABLE_SUPPORTED_CHAINS: ChainInfo[] = Object.values(ALL_SUPPORTED_CHAINS_MAP).filter(
  (chain) => !chain.isDeprecated,
)

/**
 * Chain ids where new trading is allowed (excludes deprecated chains).
 */
export const TRADABLE_SUPPORTED_CHAIN_IDS: SupportedChainId[] = TRADABLE_SUPPORTED_CHAINS.map(
  (chain) => chain.id,
) as SupportedChainId[]

/**
 * Maps a chain where you can bridge to, but not sell tokens from (not supported by CoW Protocol)
 */
export const ADDITIONAL_TARGET_CHAINS_MAP: Record<AdditionalTargetChainId, ChainInfo> = {
  [AdditionalTargetChainId.OPTIMISM]: optimism,
  [AdditionalTargetChainId.BITCOIN]: bitcoin,
}

/**
 * All chains where you can bridge to, but not sell tokens from (not supported by CoW Protocol).
 */
export const ALL_ADDITIONAL_TARGET_CHAINS = Object.values(ADDITIONAL_TARGET_CHAINS_MAP)

/**
 * The list of chains where you can bridge to, but not sell tokens from (not supported by CoW Protocol).
 */
export const ALL_ADDITIONAL_TARGET_CHAIN_IDS: AdditionalTargetChainId[] = ALL_ADDITIONAL_TARGET_CHAINS.map(
  (chain) => chain.id,
) as AdditionalTargetChainId[]


/**
 * All chains (both supported by CoW Protocol, or chains where you can bridge to)
 */
export const ALL_CHAINS = ALL_SUPPORTED_CHAINS.concat(ALL_ADDITIONAL_TARGET_CHAINS)

/**
 * All chain ids (both supported by CoW Protocol, or chains where you can bridge to)
 */
export const ALL_CHAINS_IDS: TargetChainId[] = ALL_CHAINS.map((chain) => chain.id) as TargetChainId[]

/**
 * Map of all chains keyed by chain id (both supported by CoW Protocol, or chains where you can bridge to).
 */
export const ALL_CHAINS_MAP: Record<TargetChainId, ChainInfo> = ALL_CHAINS.reduce(
  (acc, chain) => ({ ...acc, [chain.id]: chain }),
  {} as Record<TargetChainId, ChainInfo>,
)
