# Changelog

## [9.2.17](https://github.com/cowprotocol/cow-sdk/compare/cow-sdk-v9.2.16...cow-sdk-v9.2.17) (2026-10-01)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-order-book bumped to 4.3.0
    * @cowprotocol/sdk-order-signing bumped to 1.1.16
    * @cowprotocol/sdk-trading bumped to 2.7.4

## [9.2.16](https://github.com/cowprotocol/cow-sdk/compare/cow-sdk-v9.2.15...cow-sdk-v9.2.16) (2026-09-29)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-app-data bumped to 6.0.8
    * @cowprotocol/sdk-common bumped to 0.14.2
    * @cowprotocol/sdk-config bumped to 2.7.2
    * @cowprotocol/sdk-contracts-ts bumped to 3.7.2
    * @cowprotocol/sdk-order-book bumped to 4.2.1
    * @cowprotocol/sdk-order-signing bumped to 1.1.15
    * @cowprotocol/sdk-trading bumped to 2.7.3

## [9.2.15](https://github.com/cowprotocol/cow-sdk/compare/cow-sdk-v9.2.14...cow-sdk-v9.2.15) (2026-09-25)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-order-book bumped to 4.2.0
    * @cowprotocol/sdk-order-signing bumped to 1.1.14
    * @cowprotocol/sdk-trading bumped to 2.7.2

## [9.2.14](https://github.com/cowprotocol/cow-sdk/compare/cow-sdk-v9.2.13...cow-sdk-v9.2.14) (2026-09-25)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-app-data bumped to 6.0.7
    * @cowprotocol/sdk-common bumped to 0.14.1
    * @cowprotocol/sdk-config bumped to 2.7.1
    * @cowprotocol/sdk-contracts-ts bumped to 3.7.1
    * @cowprotocol/sdk-order-book bumped to 4.1.1
    * @cowprotocol/sdk-order-signing bumped to 1.1.13
    * @cowprotocol/sdk-trading bumped to 2.7.1

## [9.2.13](https://github.com/cowprotocol/cow-sdk/compare/cow-sdk-v9.2.12...cow-sdk-v9.2.13) (2026-09-21)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-app-data bumped to 6.0.6
    * @cowprotocol/sdk-common bumped to 0.14.0
    * @cowprotocol/sdk-contracts-ts bumped to 3.7.0
    * @cowprotocol/sdk-order-book bumped to 4.1.0
    * @cowprotocol/sdk-order-signing bumped to 1.1.12
    * @cowprotocol/sdk-trading bumped to 2.7.0

## [9.2.12](https://github.com/cowprotocol/cow-sdk/compare/cow-sdk-v9.2.11...cow-sdk-v9.2.12) (2026-09-18)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-app-data bumped to 6.0.5
    * @cowprotocol/sdk-common bumped to 0.13.1
    * @cowprotocol/sdk-config bumped to 2.7.0
    * @cowprotocol/sdk-contracts-ts bumped to 3.6.0
    * @cowprotocol/sdk-order-book bumped to 4.0.6
    * @cowprotocol/sdk-order-signing bumped to 1.1.11
    * @cowprotocol/sdk-trading bumped to 2.6.0

## [9.2.11](https://github.com/cowprotocol/cow-sdk/compare/cow-sdk-v9.2.10...cow-sdk-v9.2.11) (2026-09-16)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-app-data bumped to 6.0.4
    * @cowprotocol/sdk-common bumped to 0.13.0
    * @cowprotocol/sdk-contracts-ts bumped to 3.5.2
    * @cowprotocol/sdk-order-book bumped to 4.0.5
    * @cowprotocol/sdk-order-signing bumped to 1.1.10
    * @cowprotocol/sdk-trading bumped to 2.5.0

## [9.2.10](https://github.com/cowprotocol/cow-sdk/compare/cow-sdk-v9.2.9...cow-sdk-v9.2.10) (2026-09-14)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-app-data bumped to 6.0.3
    * @cowprotocol/sdk-trading bumped to 2.4.2

## [9.2.9](https://github.com/cowprotocol/cow-sdk/compare/cow-sdk-v9.2.8...cow-sdk-v9.2.9) (2026-09-07)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-app-data bumped to 6.0.2
    * @cowprotocol/sdk-common bumped to 0.12.3
    * @cowprotocol/sdk-config bumped to 2.6.0
    * @cowprotocol/sdk-contracts-ts bumped to 3.5.1
    * @cowprotocol/sdk-order-book bumped to 4.0.4
    * @cowprotocol/sdk-order-signing bumped to 1.1.9
    * @cowprotocol/sdk-trading bumped to 2.4.1

## [9.2.8](https://github.com/cowprotocol/cow-sdk/compare/cow-sdk-v9.2.7...cow-sdk-v9.2.8) (2026-09-04)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-app-data bumped to 6.0.1
    * @cowprotocol/sdk-common bumped to 0.12.2
    * @cowprotocol/sdk-config bumped to 2.5.0
    * @cowprotocol/sdk-contracts-ts bumped to 3.5.0
    * @cowprotocol/sdk-order-book bumped to 4.0.3
    * @cowprotocol/sdk-order-signing bumped to 1.1.8
    * @cowprotocol/sdk-trading bumped to 2.4.0

## [9.2.7](https://github.com/cowprotocol/cow-sdk/compare/cow-sdk-v9.2.6...cow-sdk-v9.2.7) (2026-09-01)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-contracts-ts bumped to 3.4.0
    * @cowprotocol/sdk-order-signing bumped to 1.1.7
    * @cowprotocol/sdk-trading bumped to 2.3.0

## [9.2.6](https://github.com/cowprotocol/cow-sdk/compare/cow-sdk-v9.2.5...cow-sdk-v9.2.6) (2026-07-29)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-app-data bumped to 5.3.3
    * @cowprotocol/sdk-common bumped to 0.12.1
    * @cowprotocol/sdk-config bumped to 2.4.0
    * @cowprotocol/sdk-contracts-ts bumped to 3.3.3
    * @cowprotocol/sdk-order-book bumped to 4.0.2
    * @cowprotocol/sdk-order-signing bumped to 1.1.6
    * @cowprotocol/sdk-trading bumped to 2.2.6

## [9.2.5](https://github.com/cowprotocol/cow-sdk/compare/cow-sdk-v9.2.4...cow-sdk-v9.2.5) (2026-07-28)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-contracts-ts bumped to 3.3.2
    * @cowprotocol/sdk-order-signing bumped to 1.1.5
    * @cowprotocol/sdk-trading bumped to 2.2.5

## [9.2.4](https://github.com/cowprotocol/cow-sdk/compare/cow-sdk-v9.2.3...cow-sdk-v9.2.4) (2026-07-22)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-contracts-ts bumped to 3.3.1
    * @cowprotocol/sdk-order-signing bumped to 1.1.4
    * @cowprotocol/sdk-trading bumped to 2.2.4

## [9.2.3](https://github.com/cowprotocol/cow-sdk/compare/cow-sdk-v9.2.2...cow-sdk-v9.2.3) (2026-07-22)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-app-data bumped to 5.3.2
    * @cowprotocol/sdk-contracts-ts bumped to 3.3.0
    * @cowprotocol/sdk-order-signing bumped to 1.1.3
    * @cowprotocol/sdk-trading bumped to 2.2.3

## [9.2.2](https://github.com/cowprotocol/cow-sdk/compare/cow-sdk-v9.2.1...cow-sdk-v9.2.2) (2026-06-23)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-app-data bumped to 5.3.1
    * @cowprotocol/sdk-contracts-ts bumped to 3.2.1
    * @cowprotocol/sdk-order-signing bumped to 1.1.2
    * @cowprotocol/sdk-trading bumped to 2.2.2

## [9.2.1](https://github.com/cowprotocol/cow-sdk/compare/cow-sdk-v9.2.0...cow-sdk-v9.2.1) (2026-06-17)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-order-book bumped to 4.0.1
    * @cowprotocol/sdk-order-signing bumped to 1.1.1
    * @cowprotocol/sdk-trading bumped to 2.2.1

## [9.2.0](https://github.com/cowprotocol/cow-sdk/compare/cow-sdk-v9.1.5...cow-sdk-v9.2.0) (2026-06-15)


### ✨ Features

* per-package test coverage badges, updated in CI ([#895](https://github.com/cowprotocol/cow-sdk/issues/895)) ([c73246c](https://github.com/cowprotocol/cow-sdk/commit/c73246cc52c4fc79b2628b7c5f580695fd3dc1e2))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-app-data bumped to 5.3.0
    * @cowprotocol/sdk-common bumped to 0.12.0
    * @cowprotocol/sdk-config bumped to 2.3.1
    * @cowprotocol/sdk-contracts-ts bumped to 3.2.0
    * @cowprotocol/sdk-order-book bumped to 4.0.0
    * @cowprotocol/sdk-order-signing bumped to 1.1.0
    * @cowprotocol/sdk-trading bumped to 2.2.0

## [9.1.5](https://github.com/cowprotocol/cow-sdk/compare/cow-sdk-v9.1.4...cow-sdk-v9.1.5) (2026-06-08)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-app-data bumped to 5.2.0
    * @cowprotocol/sdk-common bumped to 0.11.2
    * @cowprotocol/sdk-config bumped to 2.3.0
    * @cowprotocol/sdk-contracts-ts bumped to 3.1.2
    * @cowprotocol/sdk-order-book bumped to 3.2.2
    * @cowprotocol/sdk-order-signing bumped to 1.0.6
    * @cowprotocol/sdk-trading bumped to 2.1.2

## [9.1.4](https://github.com/cowprotocol/cow-sdk/compare/cow-sdk-v9.1.3...cow-sdk-v9.1.4) (2026-06-02)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-app-data bumped to 5.1.4
    * @cowprotocol/sdk-common bumped to 0.11.1
    * @cowprotocol/sdk-config bumped to 2.2.1
    * @cowprotocol/sdk-contracts-ts bumped to 3.1.1
    * @cowprotocol/sdk-order-book bumped to 3.2.1
    * @cowprotocol/sdk-order-signing bumped to 1.0.5
    * @cowprotocol/sdk-trading bumped to 2.1.1

## [9.1.3](https://github.com/cowprotocol/cow-sdk/compare/cow-sdk-v9.1.2...cow-sdk-v9.1.3) (2026-05-27)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-app-data bumped to 5.1.3
    * @cowprotocol/sdk-common bumped to 0.11.0
    * @cowprotocol/sdk-config bumped to 2.2.0
    * @cowprotocol/sdk-contracts-ts bumped to 3.1.0
    * @cowprotocol/sdk-order-book bumped to 3.2.0
    * @cowprotocol/sdk-order-signing bumped to 1.0.4
    * @cowprotocol/sdk-trading bumped to 2.1.0

## [9.1.2](https://github.com/cowprotocol/cow-sdk/compare/cow-sdk-v9.1.1...cow-sdk-v9.1.2) (2026-05-22)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-app-data bumped to 5.1.2
    * @cowprotocol/sdk-common bumped to 0.10.3
    * @cowprotocol/sdk-config bumped to 2.1.0
    * @cowprotocol/sdk-contracts-ts bumped to 3.0.3
    * @cowprotocol/sdk-order-book bumped to 3.1.0
    * @cowprotocol/sdk-order-signing bumped to 1.0.3
    * @cowprotocol/sdk-trading bumped to 2.0.5

## [9.1.1](https://github.com/cowprotocol/cow-sdk/compare/cow-sdk-v9.1.0...cow-sdk-v9.1.1) (2026-05-20)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-app-data bumped to 5.1.1
    * @cowprotocol/sdk-contracts-ts bumped to 3.0.2
    * @cowprotocol/sdk-order-signing bumped to 1.0.2
    * @cowprotocol/sdk-trading bumped to 2.0.4

## [9.1.0](https://github.com/cowprotocol/cow-sdk/compare/cow-sdk-v9.0.2...cow-sdk-v9.1.0) (2026-04-28)


### ✨ Features

* update ipfsOnlyHash deps ([#869](https://github.com/cowprotocol/cow-sdk/issues/869)) ([d6b30cf](https://github.com/cowprotocol/cow-sdk/commit/d6b30cfc248cb7d93f9b00113da7412b45b58194))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-app-data bumped to 5.1.0
    * @cowprotocol/sdk-trading bumped to 2.0.3

## [9.0.2](https://github.com/cowprotocol/cow-sdk/compare/cow-sdk-v9.0.1...cow-sdk-v9.0.2) (2026-04-22)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-trading bumped to 2.0.2

## [9.0.1](https://github.com/cowprotocol/cow-sdk/compare/cow-sdk-v9.0.0...cow-sdk-v9.0.1) (2026-04-20)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-contracts-ts bumped to 3.0.1
    * @cowprotocol/sdk-order-signing bumped to 1.0.1
    * @cowprotocol/sdk-trading bumped to 2.0.1

## [9.0.0](https://github.com/cowprotocol/cow-sdk/compare/cow-sdk-v8.1.0...cow-sdk-v9.0.0) (2026-04-16)


### ⚠ BREAKING CHANGES

* bring cow.fi back ([#863](https://github.com/cowprotocol/cow-sdk/issues/863))

### ✨ Features

* bring cow.fi back ([#863](https://github.com/cowprotocol/cow-sdk/issues/863)) ([d607fd2](https://github.com/cowprotocol/cow-sdk/commit/d607fd2cfbc93ace39de04f3a7870f723fdd9b21))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-app-data bumped to 5.0.0
    * @cowprotocol/sdk-common bumped to 0.10.2
    * @cowprotocol/sdk-config bumped to 2.0.0
    * @cowprotocol/sdk-contracts-ts bumped to 3.0.0
    * @cowprotocol/sdk-order-book bumped to 3.0.0
    * @cowprotocol/sdk-order-signing bumped to 1.0.0
    * @cowprotocol/sdk-trading bumped to 2.0.0

## [8.1.0](https://github.com/cowprotocol/cow-sdk/compare/cow-sdk-v8.0.6...cow-sdk-v8.1.0) (2026-04-14)


### ✨ Features

* migrate to cow.finance domain ([#860](https://github.com/cowprotocol/cow-sdk/issues/860)) ([a4e7633](https://github.com/cowprotocol/cow-sdk/commit/a4e76333b7a276baec5c977f44b15498550d8e50))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-app-data bumped to 4.7.0
    * @cowprotocol/sdk-common bumped to 0.10.1
    * @cowprotocol/sdk-config bumped to 1.2.0
    * @cowprotocol/sdk-contracts-ts bumped to 2.5.0
    * @cowprotocol/sdk-order-book bumped to 2.1.0
    * @cowprotocol/sdk-order-signing bumped to 0.3.0
    * @cowprotocol/sdk-trading bumped to 1.3.0

## [8.0.6](https://github.com/cowprotocol/cow-sdk/compare/cow-sdk-v8.0.5...cow-sdk-v8.0.6) (2026-04-08)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-app-data bumped to 4.6.14
    * @cowprotocol/sdk-common bumped to 0.10.0
    * @cowprotocol/sdk-config bumped to 1.1.3
    * @cowprotocol/sdk-contracts-ts bumped to 2.4.0
    * @cowprotocol/sdk-order-book bumped to 2.0.5
    * @cowprotocol/sdk-order-signing bumped to 0.2.5
    * @cowprotocol/sdk-trading bumped to 1.2.2

## [8.0.5](https://github.com/cowprotocol/cow-sdk/compare/cow-sdk-v8.0.4...cow-sdk-v8.0.5) (2026-04-01)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-app-data bumped to 4.6.13
    * @cowprotocol/sdk-common bumped to 0.9.0
    * @cowprotocol/sdk-contracts-ts bumped to 2.3.0
    * @cowprotocol/sdk-order-book bumped to 2.0.4
    * @cowprotocol/sdk-order-signing bumped to 0.2.4
    * @cowprotocol/sdk-trading bumped to 1.2.1

## [8.0.4](https://github.com/cowprotocol/cow-sdk/compare/cow-sdk-v8.0.3...cow-sdk-v8.0.4) (2026-03-17)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-app-data bumped to 4.6.12
    * @cowprotocol/sdk-contracts-ts bumped to 2.2.0
    * @cowprotocol/sdk-order-signing bumped to 0.2.3
    * @cowprotocol/sdk-trading bumped to 1.2.0

## [8.0.3](https://github.com/cowprotocol/cow-sdk/compare/cow-sdk-v8.0.2...cow-sdk-v8.0.3) (2026-03-17)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-app-data bumped to 4.6.11
    * @cowprotocol/sdk-common bumped to 0.8.2
    * @cowprotocol/sdk-config bumped to 1.1.2
    * @cowprotocol/sdk-contracts-ts bumped to 2.1.2
    * @cowprotocol/sdk-order-book bumped to 2.0.3
    * @cowprotocol/sdk-order-signing bumped to 0.2.2
    * @cowprotocol/sdk-trading bumped to 1.1.2

## [8.0.2](https://github.com/cowprotocol/cow-sdk/compare/cow-sdk-v8.0.1...cow-sdk-v8.0.2) (2026-03-16)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-app-data bumped to 4.6.10
    * @cowprotocol/sdk-common bumped to 0.8.1
    * @cowprotocol/sdk-config bumped to 1.1.1
    * @cowprotocol/sdk-contracts-ts bumped to 2.1.1
    * @cowprotocol/sdk-order-book bumped to 2.0.2
    * @cowprotocol/sdk-order-signing bumped to 0.2.1
    * @cowprotocol/sdk-trading bumped to 1.1.1

## [8.0.1](https://github.com/cowprotocol/cow-sdk/compare/cow-sdk-v8.0.0...cow-sdk-v8.0.1) (2026-03-16)


### 🔧 Miscellaneous

* release main ([#826](https://github.com/cowprotocol/cow-sdk/issues/826)) ([baaa708](https://github.com/cowprotocol/cow-sdk/commit/baaa7088ac15b89fb83310e54aa52f09d19132ff))
* release main ([#832](https://github.com/cowprotocol/cow-sdk/issues/832)) ([5dafcb8](https://github.com/cowprotocol/cow-sdk/commit/5dafcb8ec5593250dba1ff6e9fdbf8eb11d974cf))
* revert release ([#833](https://github.com/cowprotocol/cow-sdk/issues/833)) ([0c40a9b](https://github.com/cowprotocol/cow-sdk/commit/0c40a9b3ee828c7ede66576f02e1b571e96140cd))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-app-data bumped to 4.6.9
    * @cowprotocol/sdk-common bumped to 0.8.0
    * @cowprotocol/sdk-config bumped to 1.1.0
    * @cowprotocol/sdk-contracts-ts bumped to 2.1.0
    * @cowprotocol/sdk-order-book bumped to 2.0.1
    * @cowprotocol/sdk-order-signing bumped to 0.2.0
    * @cowprotocol/sdk-trading bumped to 1.1.0

## [8.0.0](https://github.com/cowprotocol/cow-sdk/compare/cow-sdk-v7.4.2...cow-sdk-v8.0.0) (2026-03-10)


### ⚠ BREAKING CHANGES

* **chains:** Remove support for Lens.

### ✨ Features

* **chains:** Remove Lens ([#818](https://github.com/cowprotocol/cow-sdk/issues/818)) ([e8c74a0](https://github.com/cowprotocol/cow-sdk/commit/e8c74a078e5940901591652164af7b2ffb7b1fa6))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-app-data bumped to 4.6.8
    * @cowprotocol/sdk-common bumped to 0.7.1
    * @cowprotocol/sdk-config bumped to 1.0.0
    * @cowprotocol/sdk-contracts-ts bumped to 2.0.0
    * @cowprotocol/sdk-order-book bumped to 2.0.0
    * @cowprotocol/sdk-order-signing bumped to 0.1.38
    * @cowprotocol/sdk-trading bumped to 1.0.4

## [7.4.2](https://github.com/cowprotocol/cow-sdk/compare/cow-sdk-v7.4.1...cow-sdk-v7.4.2) (2026-03-10)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-order-book bumped to 1.1.2
    * @cowprotocol/sdk-order-signing bumped to 0.1.37
    * @cowprotocol/sdk-trading bumped to 1.0.3

## [7.4.1](https://github.com/cowprotocol/cow-sdk/compare/cow-sdk-v7.4.0...cow-sdk-v7.4.1) (2026-03-04)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-app-data bumped to 4.6.7
    * @cowprotocol/sdk-common bumped to 0.7.0
    * @cowprotocol/sdk-config bumped to 0.10.0
    * @cowprotocol/sdk-contracts-ts bumped to 1.8.0
    * @cowprotocol/sdk-order-book bumped to 1.1.1
    * @cowprotocol/sdk-order-signing bumped to 0.1.36
    * @cowprotocol/sdk-trading bumped to 1.0.2

## [7.4.0](https://github.com/cowprotocol/cow-sdk/compare/cow-sdk-v7.3.8...cow-sdk-v7.4.0) (2026-03-04)


### ✨ Features

* add API endpoints for partners ([#809](https://github.com/cowprotocol/cow-sdk/issues/809)) ([59900e8](https://github.com/cowprotocol/cow-sdk/commit/59900e854a336e294ec881bd70bb13e579ff48ec))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-app-data bumped to 4.6.6
    * @cowprotocol/sdk-common bumped to 0.6.3
    * @cowprotocol/sdk-config bumped to 0.9.0
    * @cowprotocol/sdk-contracts-ts bumped to 1.7.0
    * @cowprotocol/sdk-order-book bumped to 1.1.0
    * @cowprotocol/sdk-order-signing bumped to 0.1.35
    * @cowprotocol/sdk-trading bumped to 1.0.1

## [7.3.8](https://github.com/cowprotocol/cow-sdk/compare/cow-sdk-v7.3.7...cow-sdk-v7.3.8) (2026-02-26)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-order-book bumped to 1.0.0
    * @cowprotocol/sdk-order-signing bumped to 0.1.34
    * @cowprotocol/sdk-trading bumped to 1.0.0

## [7.3.7](https://github.com/cowprotocol/cow-sdk/compare/cow-sdk-v7.3.6...cow-sdk-v7.3.7) (2026-02-20)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-app-data bumped to 4.6.5
    * @cowprotocol/sdk-common bumped to 0.6.2
    * @cowprotocol/sdk-config bumped to 0.8.1
    * @cowprotocol/sdk-contracts-ts bumped to 1.6.1
    * @cowprotocol/sdk-order-book bumped to 0.6.6
    * @cowprotocol/sdk-order-signing bumped to 0.1.33
    * @cowprotocol/sdk-trading bumped to 0.11.1

## [7.3.6](https://github.com/cowprotocol/cow-sdk/compare/cow-sdk-v7.3.5...cow-sdk-v7.3.6) (2026-02-18)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-app-data bumped to 4.6.4
    * @cowprotocol/sdk-common bumped to 0.6.1
    * @cowprotocol/sdk-config bumped to 0.8.0
    * @cowprotocol/sdk-contracts-ts bumped to 1.6.0
    * @cowprotocol/sdk-order-book bumped to 0.6.5
    * @cowprotocol/sdk-order-signing bumped to 0.1.32
    * @cowprotocol/sdk-trading bumped to 0.11.0

## [7.3.5](https://github.com/cowprotocol/cow-sdk/compare/cow-sdk-v7.3.4...cow-sdk-v7.3.5) (2026-02-05)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-app-data bumped to 4.6.3
    * @cowprotocol/sdk-common bumped to 0.6.0
    * @cowprotocol/sdk-contracts-ts bumped to 1.5.0
    * @cowprotocol/sdk-order-book bumped to 0.6.4
    * @cowprotocol/sdk-order-signing bumped to 0.1.31
    * @cowprotocol/sdk-trading bumped to 0.10.1

## [7.3.4](https://github.com/cowprotocol/cow-sdk/compare/cow-sdk-v7.3.3...cow-sdk-v7.3.4) (2026-02-03)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-trading bumped to 0.10.0

## [7.3.3](https://github.com/cowprotocol/cow-sdk/compare/cow-sdk-v7.3.2...cow-sdk-v7.3.3) (2026-02-02)


### 🔧 Miscellaneous

* revert revert Ink network ([#789](https://github.com/cowprotocol/cow-sdk/issues/789)) ([a00dbbd](https://github.com/cowprotocol/cow-sdk/commit/a00dbbd6a26238bcee2d4452487d16551560c59f))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-app-data bumped to 4.6.2
    * @cowprotocol/sdk-common bumped to 0.5.4
    * @cowprotocol/sdk-config bumped to 0.7.3
    * @cowprotocol/sdk-contracts-ts bumped to 1.4.2
    * @cowprotocol/sdk-order-book bumped to 0.6.3
    * @cowprotocol/sdk-order-signing bumped to 0.1.30
    * @cowprotocol/sdk-trading bumped to 0.9.4

## [7.3.2](https://github.com/cowprotocol/cow-sdk/compare/cow-sdk-v7.3.1...cow-sdk-v7.3.2) (2026-02-02)


### 🐛 Bug Fixes

* support decimals in protocolFeeBps ([#787](https://github.com/cowprotocol/cow-sdk/issues/787)) ([f53ae65](https://github.com/cowprotocol/cow-sdk/commit/f53ae65931d85e354779767ed67e0e4df944a2bc))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-app-data bumped to 4.6.1
    * @cowprotocol/sdk-common bumped to 0.5.3
    * @cowprotocol/sdk-config bumped to 0.7.2
    * @cowprotocol/sdk-contracts-ts bumped to 1.4.1
    * @cowprotocol/sdk-order-book bumped to 0.6.2
    * @cowprotocol/sdk-order-signing bumped to 0.1.29
    * @cowprotocol/sdk-trading bumped to 0.9.3

## [7.3.1](https://github.com/cowprotocol/cow-sdk/compare/cow-sdk-v7.3.0...cow-sdk-v7.3.1) (2026-01-28)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-app-data bumped to 4.6.0
    * @cowprotocol/sdk-common bumped to 0.5.2
    * @cowprotocol/sdk-config bumped to 0.7.1
    * @cowprotocol/sdk-contracts-ts bumped to 1.4.0
    * @cowprotocol/sdk-order-book bumped to 0.6.1
    * @cowprotocol/sdk-order-signing bumped to 0.1.28
    * @cowprotocol/sdk-trading bumped to 0.9.2

## [7.3.0](https://github.com/cowprotocol/cow-sdk/compare/cow-sdk-v7.2.13...cow-sdk-v7.3.0) (2026-01-28)


### ✨ Features

* **ink:** reapply "feat/COW-163: Add Ink network ([#781](https://github.com/cowprotocol/cow-sdk/issues/781))" ([7c23332](https://github.com/cowprotocol/cow-sdk/commit/7c23332dac4f8c91d5f75ae68297906e20f20362))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-app-data bumped to 4.5.2
    * @cowprotocol/sdk-common bumped to 0.5.1
    * @cowprotocol/sdk-config bumped to 0.7.0
    * @cowprotocol/sdk-contracts-ts bumped to 1.3.0
    * @cowprotocol/sdk-order-book bumped to 0.6.0
    * @cowprotocol/sdk-order-signing bumped to 0.1.27
    * @cowprotocol/sdk-trading bumped to 0.9.1

## [7.2.13](https://github.com/cowprotocol/cow-sdk/compare/cow-sdk-v7.2.12...cow-sdk-v7.2.13) (2026-01-22)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-contracts-ts bumped to 1.2.0
    * @cowprotocol/sdk-order-signing bumped to 0.1.26
    * @cowprotocol/sdk-trading bumped to 0.9.0

## [7.2.12](https://github.com/cowprotocol/cow-sdk/compare/cow-sdk-v7.2.11...cow-sdk-v7.2.12) (2026-01-21)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-contracts-ts bumped to 1.1.1
    * @cowprotocol/sdk-order-signing bumped to 0.1.25
    * @cowprotocol/sdk-trading bumped to 0.8.2

## [7.2.11](https://github.com/cowprotocol/cow-sdk/compare/cow-sdk-v7.2.10...cow-sdk-v7.2.11) (2026-01-19)


### 🔧 Miscellaneous

* remove `under development` comment from Linea and Plasma ([#770](https://github.com/cowprotocol/cow-sdk/issues/770)) ([cbb5361](https://github.com/cowprotocol/cow-sdk/commit/cbb53611674553e40d42ffcb3d0f599f49ec2fa1))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-app-data bumped to 4.5.1
    * @cowprotocol/sdk-common bumped to 0.5.0
    * @cowprotocol/sdk-config bumped to 0.6.3
    * @cowprotocol/sdk-contracts-ts bumped to 1.1.0
    * @cowprotocol/sdk-order-book bumped to 0.5.1
    * @cowprotocol/sdk-order-signing bumped to 0.1.24
    * @cowprotocol/sdk-trading bumped to 0.8.1

## [7.2.10](https://github.com/cowprotocol/cow-sdk/compare/cow-sdk-v7.2.9...cow-sdk-v7.2.10) (2026-01-15)


### 📚 Documentation

* update Low-Level SDK Usage Example ([#766](https://github.com/cowprotocol/cow-sdk/issues/766)) ([0b6949c](https://github.com/cowprotocol/cow-sdk/commit/0b6949cff628d390c17db8661cd917e486c75af3))

## [7.2.9](https://github.com/cowprotocol/cow-sdk/compare/cow-sdk-v7.2.8...cow-sdk-v7.2.9) (2025-12-25)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-app-data bumped to 4.5.0
    * @cowprotocol/sdk-trading bumped to 0.8.0

## [7.2.8](https://github.com/cowprotocol/cow-sdk/compare/cow-sdk-v7.2.7...cow-sdk-v7.2.8) (2025-12-24)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-trading bumped to 0.7.4

## [7.2.7](https://github.com/cowprotocol/cow-sdk/compare/cow-sdk-v7.2.6...cow-sdk-v7.2.7) (2025-12-22)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-app-data bumped to 4.4.0
    * @cowprotocol/sdk-order-book bumped to 0.5.0
    * @cowprotocol/sdk-order-signing bumped to 0.1.23
    * @cowprotocol/sdk-trading bumped to 0.7.3

## [7.2.6](https://github.com/cowprotocol/cow-sdk/compare/cow-sdk-v7.2.5...cow-sdk-v7.2.6) (2025-12-19)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-contracts-ts bumped to 1.0.0
    * @cowprotocol/sdk-order-signing bumped to 0.1.22
    * @cowprotocol/sdk-trading bumped to 0.7.2

## [7.2.5](https://github.com/cowprotocol/cow-sdk/compare/cow-sdk-v7.2.4...cow-sdk-v7.2.5) (2025-12-11)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-app-data bumped to 4.3.6
    * @cowprotocol/sdk-config bumped to 0.6.2
    * @cowprotocol/sdk-contracts-ts bumped to 0.8.1
    * @cowprotocol/sdk-order-book bumped to 0.4.4
    * @cowprotocol/sdk-order-signing bumped to 0.1.21
    * @cowprotocol/sdk-trading bumped to 0.7.1

## [7.2.4](https://github.com/cowprotocol/cow-sdk/compare/cow-sdk-v7.2.3...cow-sdk-v7.2.4) (2025-12-10)


### 🔧 Miscellaneous

* release main ([#741](https://github.com/cowprotocol/cow-sdk/issues/741)) ([32fb8bb](https://github.com/cowprotocol/cow-sdk/commit/32fb8bbe6b1172c2666f330d0d50cdc2f7c2554f))
* revert not published release ([5facf05](https://github.com/cowprotocol/cow-sdk/commit/5facf05c67121404b7b5aa1e77950961b06eca81))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-contracts-ts bumped to 0.8.0
    * @cowprotocol/sdk-order-signing bumped to 0.1.20
    * @cowprotocol/sdk-trading bumped to 0.7.0

## [7.2.3](https://github.com/cowprotocol/cow-sdk/compare/cow-sdk-v7.2.2...cow-sdk-v7.2.3) (2025-12-05)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-app-data bumped to 4.3.5
    * @cowprotocol/sdk-config bumped to 0.6.1
    * @cowprotocol/sdk-contracts-ts bumped to 0.7.4
    * @cowprotocol/sdk-order-book bumped to 0.4.3
    * @cowprotocol/sdk-order-signing bumped to 0.1.19
    * @cowprotocol/sdk-trading bumped to 0.6.3

## [7.2.2](https://github.com/cowprotocol/cow-sdk/compare/cow-sdk-v7.2.1...cow-sdk-v7.2.2) (2025-12-04)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-app-data bumped to 4.3.4
    * @cowprotocol/sdk-config bumped to 0.6.0
    * @cowprotocol/sdk-contracts-ts bumped to 0.7.3
    * @cowprotocol/sdk-order-book bumped to 0.4.2
    * @cowprotocol/sdk-order-signing bumped to 0.1.18
    * @cowprotocol/sdk-trading bumped to 0.6.2

## [7.2.1](https://github.com/cowprotocol/cow-sdk/compare/cow-sdk-v7.2.0...cow-sdk-v7.2.1) (2025-12-03)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-app-data bumped to 4.3.3
    * @cowprotocol/sdk-config bumped to 0.5.0
    * @cowprotocol/sdk-contracts-ts bumped to 0.7.2
    * @cowprotocol/sdk-order-book bumped to 0.4.1
    * @cowprotocol/sdk-order-signing bumped to 0.1.17
    * @cowprotocol/sdk-trading bumped to 0.6.1

## [7.2.0](https://github.com/cowprotocol/cow-sdk/compare/cow-sdk-v7.1.6...cow-sdk-v7.2.0) (2025-12-03)


### ✨ Features

* **app-data:** add UTM Tracking for Developer Attribution ([#722](https://github.com/cowprotocol/cow-sdk/issues/722)) ([0cd79d1](https://github.com/cowprotocol/cow-sdk/commit/0cd79d185630cc44b111979e873e30c760904976))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-app-data bumped to 4.3.2
    * @cowprotocol/sdk-trading bumped to 0.6.0

## [7.1.6](https://github.com/cowprotocol/cow-sdk/compare/cow-sdk-v7.1.5...cow-sdk-v7.1.6) (2025-12-01)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-order-book bumped to 0.4.0
    * @cowprotocol/sdk-order-signing bumped to 0.1.16
    * @cowprotocol/sdk-trading bumped to 0.5.4

## [7.1.5](https://github.com/cowprotocol/cow-sdk/compare/cow-sdk-v7.1.4...cow-sdk-v7.1.5) (2025-11-27)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-order-book bumped to 0.3.2
    * @cowprotocol/sdk-order-signing bumped to 0.1.15
    * @cowprotocol/sdk-trading bumped to 0.5.3

## [7.1.4](https://github.com/cowprotocol/cow-sdk/compare/cow-sdk-v7.1.3...cow-sdk-v7.1.4) (2025-11-27)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-app-data bumped to 4.3.1
    * @cowprotocol/sdk-config bumped to 0.4.1
    * @cowprotocol/sdk-contracts-ts bumped to 0.7.1
    * @cowprotocol/sdk-order-book bumped to 0.3.1
    * @cowprotocol/sdk-order-signing bumped to 0.1.14
    * @cowprotocol/sdk-trading bumped to 0.5.2

## [7.1.3](https://github.com/cowprotocol/cow-sdk/compare/cow-sdk-v7.1.2...cow-sdk-v7.1.3) (2025-11-24)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-app-data bumped to 4.3.0
    * @cowprotocol/sdk-contracts-ts bumped to 0.7.0
    * @cowprotocol/sdk-order-signing bumped to 0.1.13
    * @cowprotocol/sdk-trading bumped to 0.5.1

## [7.1.2](https://github.com/cowprotocol/cow-sdk/compare/cow-sdk-v7.1.1...cow-sdk-v7.1.2) (2025-11-24)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-app-data bumped to 4.2.0
    * @cowprotocol/sdk-common bumped to 0.4.0
    * @cowprotocol/sdk-config bumped to 0.4.0
    * @cowprotocol/sdk-contracts-ts bumped to 0.6.0
    * @cowprotocol/sdk-order-book bumped to 0.3.0
    * @cowprotocol/sdk-order-signing bumped to 0.1.12
    * @cowprotocol/sdk-trading bumped to 0.5.0

## [7.1.1](https://github.com/cowprotocol/cow-sdk/compare/cow-sdk-v7.1.0...cow-sdk-v7.1.1) (2025-11-07)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-contracts-ts bumped to 0.5.0
    * @cowprotocol/sdk-order-signing bumped to 0.1.11
    * @cowprotocol/sdk-trading bumped to 0.4.6

## [7.1.0](https://github.com/cowprotocol/cow-sdk/compare/cow-sdk-v7.0.13...cow-sdk-v7.1.0) (2025-11-05)


### ✨ Features

* **new-chains:** add q4 chains ([#606](https://github.com/cowprotocol/cow-sdk/issues/606)) ([2501382](https://github.com/cowprotocol/cow-sdk/commit/2501382e80acb7f6bb0f87adbb5a9325de2c56cc))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-app-data bumped to 4.1.6
    * @cowprotocol/sdk-config bumped to 0.3.0
    * @cowprotocol/sdk-contracts-ts bumped to 0.4.4
    * @cowprotocol/sdk-order-book bumped to 0.2.0
    * @cowprotocol/sdk-order-signing bumped to 0.1.10
    * @cowprotocol/sdk-trading bumped to 0.4.5

## [7.0.13](https://github.com/cowprotocol/cow-sdk/compare/cow-sdk-v7.0.12...cow-sdk-v7.0.13) (2025-10-30)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-contracts-ts bumped to 0.4.3
    * @cowprotocol/sdk-order-signing bumped to 0.1.9
    * @cowprotocol/sdk-trading bumped to 0.4.4

## [7.0.12](https://github.com/cowprotocol/cow-sdk/compare/cow-sdk-v7.0.11...cow-sdk-v7.0.12) (2025-10-29)


### 🔧 Miscellaneous

* release main ([#620](https://github.com/cowprotocol/cow-sdk/issues/620)) ([b36394a](https://github.com/cowprotocol/cow-sdk/commit/b36394a2ba38957edb47ffc4451ea6624d66737b))
* revert release ([#634](https://github.com/cowprotocol/cow-sdk/issues/634)) ([fc7bf61](https://github.com/cowprotocol/cow-sdk/commit/fc7bf61444619d4b2c3a3dd55b7ce52c197b1878))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-app-data bumped to 4.1.5
    * @cowprotocol/sdk-common bumped to 0.3.0
    * @cowprotocol/sdk-contracts-ts bumped to 0.4.2
    * @cowprotocol/sdk-order-book bumped to 0.1.4
    * @cowprotocol/sdk-order-signing bumped to 0.1.8
    * @cowprotocol/sdk-trading bumped to 0.4.3

## [7.0.11](https://github.com/cowprotocol/cow-sdk/compare/cow-sdk-v7.0.10...cow-sdk-v7.0.11) (2025-10-24)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-app-data bumped to 4.1.4
    * @cowprotocol/sdk-common bumped to 0.2.2
    * @cowprotocol/sdk-config bumped to 0.2.0
    * @cowprotocol/sdk-contracts-ts bumped to 0.4.1
    * @cowprotocol/sdk-order-book bumped to 0.1.3
    * @cowprotocol/sdk-order-signing bumped to 0.1.7
    * @cowprotocol/sdk-trading bumped to 0.4.2

## [7.0.10](https://github.com/cowprotocol/cow-sdk/compare/cow-sdk-v7.0.9...cow-sdk-v7.0.10) (2025-10-17)


### 🔧 Miscellaneous

* release main ([#592](https://github.com/cowprotocol/cow-sdk/issues/592)) ([e4d7212](https://github.com/cowprotocol/cow-sdk/commit/e4d7212af322beced743e985bd1fbedaef66cdcb))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-app-data bumped to 4.1.3
    * @cowprotocol/sdk-trading bumped to 0.4.1

## [7.0.9](https://github.com/cowprotocol/cow-sdk/compare/cow-sdk-v7.0.8...cow-sdk-v7.0.9) (2025-10-15)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-app-data bumped to 4.1.2
    * @cowprotocol/sdk-contracts-ts bumped to 0.4.0
    * @cowprotocol/sdk-order-signing bumped to 0.1.6
    * @cowprotocol/sdk-trading bumped to 0.4.0

## [7.0.8](https://github.com/cowprotocol/cow-sdk/compare/cow-sdk-v7.0.7...cow-sdk-v7.0.8) (2025-10-08)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-app-data bumped to 4.1.1
    * @cowprotocol/sdk-common bumped to 0.2.1
    * @cowprotocol/sdk-contracts-ts bumped to 0.3.1
    * @cowprotocol/sdk-order-book bumped to 0.1.2
    * @cowprotocol/sdk-order-signing bumped to 0.1.5
    * @cowprotocol/sdk-trading bumped to 0.3.2

## [7.0.7](https://github.com/cowprotocol/cow-sdk/compare/cow-sdk-v7.0.6...cow-sdk-v7.0.7) (2025-10-08)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-app-data bumped to 4.1.0
    * @cowprotocol/sdk-trading bumped to 0.3.1

## [7.0.6](https://github.com/cowprotocol/cow-sdk/compare/cow-sdk-v7.0.5...cow-sdk-v7.0.6) (2025-10-07)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-trading bumped to 0.3.0

## [7.0.5](https://github.com/cowprotocol/cow-sdk/compare/cow-sdk-v7.0.4...cow-sdk-v7.0.5) (2025-10-07)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-trading bumped to 0.2.1

## [7.0.4](https://github.com/cowprotocol/cow-sdk/compare/cow-sdk-v7.0.3...cow-sdk-v7.0.4) (2025-10-06)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-app-data bumped to 4.0.1
    * @cowprotocol/sdk-common bumped to 0.2.0
    * @cowprotocol/sdk-contracts-ts bumped to 0.3.0
    * @cowprotocol/sdk-order-book bumped to 0.1.1
    * @cowprotocol/sdk-order-signing bumped to 0.1.4
    * @cowprotocol/sdk-trading bumped to 0.2.0

## [7.0.3](https://github.com/cowprotocol/cow-sdk/compare/cow-sdk-v7.0.2...cow-sdk-v7.0.3) (2025-09-24)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-contracts-ts bumped to 0.2.1
    * @cowprotocol/sdk-order-signing bumped to 0.1.3
    * @cowprotocol/sdk-trading bumped to 0.1.3

## [7.0.2](https://github.com/cowprotocol/cow-sdk/compare/cow-sdk-v7.0.1...cow-sdk-v7.0.2) (2025-09-23)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-contracts-ts bumped to 0.2.0
    * @cowprotocol/sdk-order-signing bumped to 0.1.2
    * @cowprotocol/sdk-trading bumped to 0.1.2

## [7.0.1](https://github.com/cowprotocol/cow-sdk/compare/cow-sdk-v7.0.0...cow-sdk-v7.0.1) (2025-09-22)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-contracts-ts bumped to 0.1.1
    * @cowprotocol/sdk-order-signing bumped to 0.1.1
    * @cowprotocol/sdk-trading bumped to 0.1.1

## [7.0.0](https://github.com/cowprotocol/cow-sdk/compare/cow-sdk-v7.1.3-beta.0...cow-sdk-v7.0.0) (2025-09-17)


### ⚠ BREAKING CHANGES

* release cow-sdk v7

### ✨ Features

* release cow-sdk v7 ([6cd3e57](https://github.com/cowprotocol/cow-sdk/commit/6cd3e573687b1ffdbc0fdcb8cdbb414d88546e38))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-app-data bumped to 4.0.0
    * @cowprotocol/sdk-common bumped to 0.1.0
    * @cowprotocol/sdk-config bumped to 0.1.0
    * @cowprotocol/sdk-contracts-ts bumped to 0.1.0
    * @cowprotocol/sdk-order-book bumped to 0.1.0
    * @cowprotocol/sdk-order-signing bumped to 0.1.0
    * @cowprotocol/sdk-trading bumped to 0.1.0

## [7.1.3-beta.0](https://github.com/cowprotocol/cow-sdk/compare/cow-sdk-v7.1.2-beta.0...cow-sdk-v7.1.3-beta.0) (2025-09-17)


### 🔧 Miscellaneous

* make doc links absolute ([f03aabb](https://github.com/cowprotocol/cow-sdk/commit/f03aabb745e0cf51e3c9d5d8464f733e2668d544))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-app-data bumped to 4.1.7-beta.0
    * @cowprotocol/sdk-common bumped to 0.5.0-beta.0
    * @cowprotocol/sdk-contracts-ts bumped to 2.3.0-beta.0
    * @cowprotocol/sdk-order-book bumped to 0.3.1-beta.0
    * @cowprotocol/sdk-order-signing bumped to 0.2.8-beta.0
    * @cowprotocol/sdk-trading bumped to 0.3.2-beta.0

## [7.1.2-beta.0](https://github.com/cowprotocol/cow-sdk/compare/cow-sdk-v7.1.1-beta.0...cow-sdk-v7.1.2-beta.0) (2025-09-16)


### 🔧 Miscellaneous

* fix TypeDoc Entry Point ([#509](https://github.com/cowprotocol/cow-sdk/issues/509)) ([82c2a11](https://github.com/cowprotocol/cow-sdk/commit/82c2a11599e517fee43c9e9506ee64a602160d09))

## [7.1.1-beta.0](https://github.com/cowprotocol/cow-sdk/compare/cow-sdk-v7.1.0-beta.0...cow-sdk-v7.1.1-beta.0) (2025-09-16)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-app-data bumped to 4.1.6-beta.0
    * @cowprotocol/sdk-contracts-ts bumped to 2.2.1-beta.0
    * @cowprotocol/sdk-order-signing bumped to 0.2.7-beta.0
    * @cowprotocol/sdk-trading bumped to 0.3.1-beta.0

## [7.1.0-beta.0](https://github.com/cowprotocol/cow-sdk/compare/cow-sdk-v7.0.6-beta.0...cow-sdk-v7.1.0-beta.0) (2025-09-16)


### ✨ Features

* add migration guide and wagmi example ([#498](https://github.com/cowprotocol/cow-sdk/issues/498)) ([21be05d](https://github.com/cowprotocol/cow-sdk/commit/21be05d5b6472de26120ebefe4626341af9a062d))


### 📚 Documentation

* update README to focus on main use cases ([#493](https://github.com/cowprotocol/cow-sdk/issues/493)) ([a05cb1b](https://github.com/cowprotocol/cow-sdk/commit/a05cb1ba11b5f9895d7cfe6262cf74c4089fd73c))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-app-data bumped to 4.1.5-beta.0
    * @cowprotocol/sdk-common bumped to 0.4.0-beta.0
    * @cowprotocol/sdk-config bumped to 0.3.3-beta.0
    * @cowprotocol/sdk-contracts-ts bumped to 2.2.0-beta.0
    * @cowprotocol/sdk-order-book bumped to 0.3.0-beta.0
    * @cowprotocol/sdk-order-signing bumped to 0.2.6-beta.0
    * @cowprotocol/sdk-trading bumped to 0.3.0-beta.0

## [7.0.6-beta.0](https://github.com/cowprotocol/cow-sdk/compare/cow-sdk-v7.0.5-beta.0...cow-sdk-v7.0.6-beta.0) (2025-09-15)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-app-data bumped to 4.1.4-beta.0
    * @cowprotocol/sdk-bridging bumped to 0.2.6-beta.0
    * @cowprotocol/sdk-composable bumped to 0.2.6-beta.0
    * @cowprotocol/sdk-config bumped to 0.3.2-beta.0
    * @cowprotocol/sdk-contracts-ts bumped to 2.1.7-beta.0
    * @cowprotocol/sdk-cow-shed bumped to 0.2.5-beta.0
    * @cowprotocol/sdk-order-book bumped to 0.2.4-beta.0
    * @cowprotocol/sdk-order-signing bumped to 0.2.5-beta.0
    * @cowprotocol/sdk-subgraph bumped to 0.2.5-beta.0
    * @cowprotocol/sdk-trading bumped to 0.2.6-beta.0
    * @cowprotocol/sdk-weiroll bumped to 0.2.4-beta.0

## [7.0.5-beta.0](https://github.com/cowprotocol/cow-sdk/compare/cow-sdk-v7.0.4-beta.0...cow-sdk-v7.0.5-beta.0) (2025-09-15)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-app-data bumped to 4.1.3-beta.0
    * @cowprotocol/sdk-bridging bumped to 0.2.5-beta.0
    * @cowprotocol/sdk-composable bumped to 0.2.5-beta.0
    * @cowprotocol/sdk-config bumped to 0.3.1-beta.0
    * @cowprotocol/sdk-contracts-ts bumped to 2.1.6-beta.0
    * @cowprotocol/sdk-cow-shed bumped to 0.2.4-beta.0
    * @cowprotocol/sdk-order-book bumped to 0.2.3-beta.0
    * @cowprotocol/sdk-order-signing bumped to 0.2.4-beta.0
    * @cowprotocol/sdk-subgraph bumped to 0.2.4-beta.0
    * @cowprotocol/sdk-trading bumped to 0.2.5-beta.0
    * @cowprotocol/sdk-weiroll bumped to 0.2.3-beta.0

## [7.0.4-beta.0](https://github.com/cowprotocol/cow-sdk/compare/cow-sdk-v7.0.3-beta.0...cow-sdk-v7.0.4-beta.0) (2025-09-15)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-bridging bumped to 0.2.4-beta.0
    * @cowprotocol/sdk-composable bumped to 0.2.4-beta.0
    * @cowprotocol/sdk-contracts-ts bumped to 2.1.5-beta.0
    * @cowprotocol/sdk-cow-shed bumped to 0.2.3-beta.0
    * @cowprotocol/sdk-order-signing bumped to 0.2.3-beta.0
    * @cowprotocol/sdk-trading bumped to 0.2.4-beta.0

## [7.0.3-beta.0](https://github.com/cowprotocol/cow-sdk/compare/cow-sdk-v7.0.2-beta.0...cow-sdk-v7.0.3-beta.0) (2025-09-11)


### 🔧 Miscellaneous

* release main ([#488](https://github.com/cowprotocol/cow-sdk/issues/488)) ([6344fa6](https://github.com/cowprotocol/cow-sdk/commit/6344fa619465e6f94637677823a18646f06fa7c9))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-app-data bumped to 4.1.2-beta.0
    * @cowprotocol/sdk-bridging bumped to 0.2.3-beta.0
    * @cowprotocol/sdk-common bumped to 0.3.0-beta.0
    * @cowprotocol/sdk-composable bumped to 0.2.3-beta.0
    * @cowprotocol/sdk-contracts-ts bumped to 2.1.4-beta.0
    * @cowprotocol/sdk-cow-shed bumped to 0.2.2-beta.0
    * @cowprotocol/sdk-order-book bumped to 0.2.2-beta.0
    * @cowprotocol/sdk-order-signing bumped to 0.2.2-beta.0
    * @cowprotocol/sdk-subgraph bumped to 0.2.3-beta.0
    * @cowprotocol/sdk-trading bumped to 0.2.3-beta.0
    * @cowprotocol/sdk-weiroll bumped to 0.2.2-beta.0

## [7.0.2-beta.0](https://github.com/cowprotocol/cow-sdk/compare/cow-sdk-v7.0.1-beta.0...cow-sdk-v7.0.2-beta.0) (2025-09-11)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-app-data bumped to 4.1.1-beta.0
    * @cowprotocol/sdk-bridging bumped to 0.2.2-beta.0
    * @cowprotocol/sdk-composable bumped to 0.2.2-beta.0
    * @cowprotocol/sdk-config bumped to 0.3.0-beta.0
    * @cowprotocol/sdk-contracts-ts bumped to 2.1.3-beta.0
    * @cowprotocol/sdk-cow-shed bumped to 0.2.1-beta.0
    * @cowprotocol/sdk-order-book bumped to 0.2.1-beta.0
    * @cowprotocol/sdk-order-signing bumped to 0.2.1-beta.0
    * @cowprotocol/sdk-subgraph bumped to 0.2.2-beta.0
    * @cowprotocol/sdk-trading bumped to 0.2.2-beta.0
    * @cowprotocol/sdk-weiroll bumped to 0.2.1-beta.0

## [7.0.1-beta.0](https://github.com/cowprotocol/cow-sdk/compare/cow-sdk-v7.0.0-beta.0...cow-sdk-v7.0.1-beta.0) (2025-09-04)


### 🔧 Miscellaneous

* bump sdk beta version ([#473](https://github.com/cowprotocol/cow-sdk/issues/473)) ([00142d3](https://github.com/cowprotocol/cow-sdk/commit/00142d3e524ebf7a023814ba91ee3a66ed796444))

## [7.0.0-beta.0](https://github.com/cowprotocol/cow-sdk/compare/cow-sdk-v6.3.2...cow-sdk-v7.0.0-beta.0) (2025-08-28)


### ✨ Features

* allow changing backoff and limiter per request ([#208](https://github.com/cowprotocol/cow-sdk/issues/208)) ([ebea5ca](https://github.com/cowprotocol/cow-sdk/commit/ebea5ca0858aeb89ae3e5d5407c8903c3ca5178d))
* **lib-agnostic:** add nodejs examples for every adapter ([#440](https://github.com/cowprotocol/cow-sdk/issues/440)) ([43972e6](https://github.com/cowprotocol/cow-sdk/commit/43972e68ff728a9a882bbdc667b2c0821b273449))
* **sdk-agnostic-lib:** create cow trading package ([#368](https://github.com/cowprotocol/cow-sdk/issues/368)) ([0a4534a](https://github.com/cowprotocol/cow-sdk/commit/0a4534aababce4f5d8bab991cd6ae9f51842d719))
* **sdk-agnostic-lib:** Create weiroll package ([#371](https://github.com/cowprotocol/cow-sdk/issues/371)) ([8f6a2e1](https://github.com/cowprotocol/cow-sdk/commit/8f6a2e16e5e7a43a5afc43cf5faab174be916b2e))
* simplify OrderSigningUtils to use static methods only ([#417](https://github.com/cowprotocol/cow-sdk/issues/417)) ([899ca43](https://github.com/cowprotocol/cow-sdk/commit/899ca4325be831b6711468d1df3733d98fe913b0))


### 🐛 Bug Fixes

* add adapter param to BridgingSdk and update docs ([#450](https://github.com/cowprotocol/cow-sdk/issues/450)) ([667a36e](https://github.com/cowprotocol/cow-sdk/commit/667a36e4437309e1d292b8f9fd5e8f568922749f))
* **sdk:** reduce sdks in umbrella ([#433](https://github.com/cowprotocol/cow-sdk/issues/433)) ([22b1cb6](https://github.com/cowprotocol/cow-sdk/commit/22b1cb6e572fcd3a7b3878d725113ac420f470e6))


### 🔧 Miscellaneous

* **docs:** apply PR suggestions and create subgraph README ([#406](https://github.com/cowprotocol/cow-sdk/issues/406)) ([d09a219](https://github.com/cowprotocol/cow-sdk/commit/d09a219c934289a30677be685915d57e9a4451be))
* **sdk-agnostic-lib:** improve scripts and types ([#407](https://github.com/cowprotocol/cow-sdk/issues/407)) ([c4b5e08](https://github.com/cowprotocol/cow-sdk/commit/c4b5e086ce46086e9430d5f03ed330502349fbf3))
