import { PublicKey } from '@solana/web3.js'
import { OrderKind, SigningScheme } from '@cowprotocol/sdk-order-book'
import type { QuoteResults } from '@cowprotocol/sdk-trading'

import { postSolanaSwapOrderFromQuote } from './postSwapOrderFromQuote'
import { encodeOrderIntent, hashOrderIntent, SolanaOrderIntent, toOrderId } from './orderIntent'
import { findOrderPda } from './orderPda'
import { SolanaQuote } from './types'

function fillPubkey(byte: number): PublicKey {
  return new PublicKey(new Uint8Array(32).fill(byte))
}

async function buildFixtureQuote(): Promise<SolanaQuote> {
  const programId = fillPubkey(0x01)
  const intent: SolanaOrderIntent = {
    owner: fillPubkey(0x11),
    buyTokenAccount: fillPubkey(0x22),
    buyMint: fillPubkey(0x33),
    sellTokenAccount: fillPubkey(0x44),
    sellMint: fillPubkey(0x55),
    sellAmount: 100n,
    buyAmount: 200n,
    validTo: 1_700_000_000,
    kind: OrderKind.SELL,
    partiallyFillable: false,
    createdOnChain: true,
    appData: new Uint8Array(32),
  }
  const intentBytes = encodeOrderIntent(intent)
  const uid = await hashOrderIntent(intentBytes)
  const [orderPda] = findOrderPda(programId, uid)

  return {
    intent,
    intentBytes,
    uid,
    orderPda,
    programId,
  }
}

function buildFixtureQuoteResults(orderToSign: unknown = { fake: 'orderToSign' }): QuoteResults {
  return { orderToSign } as unknown as QuoteResults
}

/** Intent-level overrides (`receiver`/`validTo`) are covered directly in `buildSwapOrder.test.ts`; this
 * suite covers what the wrapper adds on top: signing, submission and result mapping. */
describe('postSolanaSwapOrderFromQuote', () => {
  it('signs and sends the CreateOrder instruction, returning the order posting result', async () => {
    const solanaQuote = await buildFixtureQuote()
    const quoteResults = buildFixtureQuoteResults()
    const signAndSend = jest.fn().mockResolvedValue({ signature: 'fake-signature' })

    const result = await postSolanaSwapOrderFromQuote({ quoteResults, solanaQuote }, signAndSend)

    expect(signAndSend).toHaveBeenCalledTimes(1)
    const instruction = signAndSend.mock.calls[0][0]
    expect(instruction.programId.toBase58()).toBe(solanaQuote.programId.toBase58())
    expect(instruction.data[0]).toBe(2)

    expect(result).toEqual({
      orderId: toOrderId(solanaQuote.uid),
      txHash: 'fake-signature',
      signature: 'fake-signature',
      signingScheme: SigningScheme.PRESIGN,
      orderToSign: quoteResults.orderToSign,
    })
  })

  it('returns the order id "0x"-prefixed, matching the order-book API\'s EnrichedOrder.uid format', async () => {
    // The order-book API always returns/expects order ids "0x"-prefixed (like EVM order uids). Without
    // this prefix, any code that looks an order up by the API's uid (e.g. reducer batch actions,
    // notifications) mismatches the locally-stored id and silently fails to find the order.
    const solanaQuote = await buildFixtureQuote()
    const quoteResults = buildFixtureQuoteResults()
    const signAndSend = jest.fn().mockResolvedValue({ signature: 'fake-signature' })

    const result = await postSolanaSwapOrderFromQuote({ quoteResults, solanaQuote }, signAndSend)

    expect(result.orderId.startsWith('0x')).toBe(true)
    expect(result.orderId).toBe(toOrderId(solanaQuote.uid))
  })

  it('propagates a signAndSend rejection', async () => {
    const solanaQuote = await buildFixtureQuote()
    const quoteResults = buildFixtureQuoteResults()
    const signAndSend = jest.fn().mockRejectedValue(new Error('user rejected'))

    await expect(postSolanaSwapOrderFromQuote({ quoteResults, solanaQuote }, signAndSend)).rejects.toThrow(
      'user rejected',
    )
  })

  it('invokes signingStepManager hooks around signing', async () => {
    const solanaQuote = await buildFixtureQuote()
    const quoteResults = buildFixtureQuoteResults()
    const signAndSend = jest.fn().mockResolvedValue({ signature: 'fake-signature' })
    const calls: string[] = []
    const signingStepManager = {
      beforeOrderSign: jest.fn(() => {
        calls.push('before')
      }),
      afterOrderSign: jest.fn(() => {
        calls.push('after')
      }),
    }

    await postSolanaSwapOrderFromQuote({ quoteResults, solanaQuote }, signAndSend, undefined, signingStepManager)

    expect(signingStepManager.beforeOrderSign).toHaveBeenCalledTimes(1)
    expect(signingStepManager.afterOrderSign).toHaveBeenCalledTimes(1)
    expect(calls).toEqual(['before', 'after'])
  })

  it('forwards advancedSettings so the submitted instruction reflects the overridden intent', async () => {
    const solanaQuote = await buildFixtureQuote()
    const quoteResults = buildFixtureQuoteResults()
    const signAndSend = jest.fn().mockResolvedValue({ signature: 'fake-signature' })
    const newValidTo = solanaQuote.intent.validTo + 1_000

    const result = await postSolanaSwapOrderFromQuote({ quoteResults, solanaQuote }, signAndSend, {
      quoteRequest: { validTo: newValidTo },
    })

    const expectedUid = await hashOrderIntent(encodeOrderIntent({ ...solanaQuote.intent, validTo: newValidTo }))

    expect(result.orderId).toBe(toOrderId(expectedUid))
    expect(result.orderId).not.toBe(toOrderId(solanaQuote.uid))
  })
})
