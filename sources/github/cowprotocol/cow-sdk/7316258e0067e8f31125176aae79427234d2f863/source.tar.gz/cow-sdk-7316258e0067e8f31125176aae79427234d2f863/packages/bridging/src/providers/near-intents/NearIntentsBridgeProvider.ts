import { areAddressesEqual, getAddressKey, getGlobalAdapter, setGlobalAdapter } from '@cowprotocol/sdk-common'
import { BTC_CURRENCY_ADDRESS, SOL_NATIVE_CURRENCY_ADDRESS } from '@cowprotocol/sdk-config'
import { CowShedSdk } from '@cowprotocol/sdk-cow-shed'
import { EnrichedOrder, OrderKind } from '@cowprotocol/sdk-order-book'
import { QuoteRequest } from '@defuse-protocol/one-click-sdk-typescript'
import { BridgeStatus } from '../../types'

import { DEFAULT_BRIDGE_SLIPPAGE_BPS, HOOK_DAPP_BRIDGE_PROVIDER_PREFIX, RAW_PROVIDERS_FILES_PATH } from '../../const'
import { BridgeProviderQuoteError, BridgeQuoteErrors } from '../../errors'
import { NearIntentsApi } from './NearIntentsApi'
import {
  ATTESTATION_PREFIX_CONST,
  ATTESTATOR_ADDRESS,
  ATTESTION_VERSION_BYTE,
  NEAR_INTENTS_STATUS_TO_COW_STATUS,
  NEAR_INTENTS_SUPPORTED_NETWORKS,
} from './const'
import { adaptToken, adaptTokens, calculateDeadline, getTokenByAddressAndChainId, hashQuote } from './util'

import type { AbstractProviderAdapter } from '@cowprotocol/sdk-common'
import type { ChainId, ChainInfo, EvmCall, SupportedChainId, TokenInfo } from '@cowprotocol/sdk-config'
import type { CowShedSdkOptions } from '@cowprotocol/sdk-cow-shed'
import type { QuoteResponse } from '@defuse-protocol/one-click-sdk-typescript'
import type { Address, Hex } from 'viem'
import type {
  BridgeProviderInfo,
  BridgeQuoteResult,
  BridgeStatusResult,
  BridgingDepositParams,
  BuyTokensParams,
  GetProviderBuyTokens,
  QuoteBridgeRequest,
  ReceiverAccountBridgeProvider,
} from '../../types'

export const NEAR_INTENTS_HOOK_DAPP_ID = `${HOOK_DAPP_BRIDGE_PROVIDER_PREFIX}/near-intents`
export const REFERRAL = 'cow'

interface DepositAddressContext {
  address: Address
  quoteHash: string
  stringifiedQuote: string
  attestationSignature: string
}

export interface NearIntentsQuoteResult extends BridgeQuoteResult {
  depositAddress: Hex
  attestationSignature: string
  quoteBody: string
}

export interface NearIntentsBridgeProviderOptions {
  cowShedOptions?: CowShedSdkOptions
  apiKey?: string
}

const providerType = 'ReceiverAccountBridgeProvider' as const

export class NearIntentsBridgeProvider implements ReceiverAccountBridgeProvider<NearIntentsQuoteResult> {
  type = providerType

  protected api: NearIntentsApi
  protected cowShedSdk: CowShedSdk

  info: BridgeProviderInfo = {
    name: 'Near Intents',
    logoUrl: `${RAW_PROVIDERS_FILES_PATH}/near-intents/near-intents-logo.png`,
    dappId: NEAR_INTENTS_HOOK_DAPP_ID,
    website: 'https://www.near.org/intents',
    type: providerType,
  }

  constructor(options?: NearIntentsBridgeProviderOptions, _adapter?: AbstractProviderAdapter) {
    const adapter = _adapter || options?.cowShedOptions?.adapter
    if (adapter) {
      setGlobalAdapter(adapter)
    }
    this.api = new NearIntentsApi(options?.apiKey)
    this.cowShedSdk = new CowShedSdk(adapter, options?.cowShedOptions?.factoryOptions)
  }

  async getNetworks(): Promise<ChainInfo[]> {
    return NEAR_INTENTS_SUPPORTED_NETWORKS
  }

  async getBuyTokens(params: BuyTokensParams): Promise<GetProviderBuyTokens> {
    const tokens = adaptTokens(await this.api.getTokens())
    const filteredTokens = tokens.filter((token) => token.chainId === params.buyChainId)

    return {
      tokens: filteredTokens,
      isRouteAvailable: filteredTokens.length > 0,
    }
  }

  async getIntermediateTokens(request: QuoteBridgeRequest): Promise<TokenInfo[]> {
    if (request.kind !== OrderKind.SELL) {
      throw new BridgeProviderQuoteError(BridgeQuoteErrors.ONLY_SELL_ORDER_SUPPORTED, { kind: request.kind })
    }

    const { sellTokenChainId, buyTokenChainId, buyTokenAddress } = request

    const tokens = adaptTokens(await this.api.getTokens())
    const { sourceTokens, targetTokens } = tokens.reduce(
      (acc, token) => {
        if (token.chainId === sellTokenChainId) {
          acc.sourceTokens.set(getAddressKey(token.address) as Address, token)
        }
        if (token.chainId === buyTokenChainId) {
          acc.targetTokens.set(getAddressKey(token.address) as Address, token)
        }
        return acc
      },
      {
        sourceTokens: new Map<Address, TokenInfo>(),
        targetTokens: new Map<Address, TokenInfo>(),
      },
    )

    const targetToken = targetTokens.get(getAddressKey(buyTokenAddress) as Address)

    if (!targetToken) return []

    return Array.from(sourceTokens.values())
  }

  async getQuote(request: QuoteBridgeRequest): Promise<NearIntentsQuoteResult> {
    const {
      sellTokenAddress,
      sellTokenChainId,
      buyTokenAddress,
      buyTokenChainId,
      account,
      amount,
      receiver,
      bridgeRecipient,
      validFor,
      owner,
    } = request

    if (
      areAddressesEqual(sellTokenAddress, BTC_CURRENCY_ADDRESS) ||
      areAddressesEqual(sellTokenAddress, SOL_NATIVE_CURRENCY_ADDRESS)
    ) {
      throw new BridgeProviderQuoteError(BridgeQuoteErrors.NO_ROUTES)
    }

    const tokens = await this.api.getTokens()
    const sellToken = getTokenByAddressAndChainId(tokens, sellTokenAddress, sellTokenChainId)
    const buyToken = getTokenByAddressAndChainId(tokens, buyTokenAddress, buyTokenChainId)
    if (!sellToken || !buyToken) throw new BridgeProviderQuoteError(BridgeQuoteErrors.NO_ROUTES)

    const quoteResponse = await this.api.getQuote({
      dry: false,
      swapType: QuoteRequest.swapType.FLEX_INPUT,
      slippageTolerance: request.bridgeSlippageBps ?? DEFAULT_BRIDGE_SLIPPAGE_BPS,
      originAsset: sellToken.assetId,
      depositType: QuoteRequest.depositType.ORIGIN_CHAIN,
      destinationAsset: buyToken.assetId,
      amount: amount.toString(),
      refundTo: owner || account,
      refundType: QuoteRequest.refundType.ORIGIN_CHAIN,
      recipient: bridgeRecipient || receiver || account,
      recipientType: QuoteRequest.recipientType.DESTINATION_CHAIN,
      deadline: calculateDeadline(validFor || 3600),
      referral: REFERRAL,
    })

    const recoveredDepositAddress = await this.recoverDepositAddress(quoteResponse)

    if (!recoveredDepositAddress || !areAddressesEqual(recoveredDepositAddress.address, ATTESTATOR_ADDRESS)) {
      throw new BridgeProviderQuoteError(BridgeQuoteErrors.QUOTE_DOES_NOT_MATCH_DEPOSIT_ADDRESS)
    }

    const { quote, timestamp: isoDate } = quoteResponse

    const sellAmount = BigInt(quote.amountIn)
    const buyAmount = BigInt(quote.amountOut)
    const minBuyAmount = BigInt(quote.minAmountOut)

    // Slippage is the tolerance we asked for. 1Click documents `minAmountOut` as "Minimum output
    // amount after slippage is applied", and it comes back as exactly
    // `amountOut * (1 - slippageTolerance)`, so this gap is *not* a fee.
    const slippageBps = buyAmount > 0n ? Number(((buyAmount - minBuyAmount) * 10_000n) / buyAmount) : 0

    // 1Click charges exactly two fees, both already reflected in `amountOut`:
    //  - `appFees`, a share of `amountIn` in bps, taken off the input before the swap
    //  - `withdrawFee`, the destination withdrawal cost, in units of the buy token
    // Whatever else separates the two sides is the execution spread, which is not a fee. Deriving
    // the fee from `amountInUsd`/`amountOutUsd` folds that spread in: those are oracle products
    // (`amount * price`), so on cross-asset routes the gap measured 34 bps on USDC->ETH against
    // 10 bps of actual fees, and on ETH->USDC came out *below* the known appFee.
    // `refundFee` is deliberately excluded: it only applies when a swap is refunded.
    const appFeeBps = (quoteResponse.quoteRequest.appFees ?? []).reduce((total, { fee }) => total + fee, 0)
    const withdrawFee = BigInt(quote.withdrawFee ?? 0)

    // The two fees sit on opposite sides of the swap, so converting between currencies uses the rate
    // the swap actually got: gross output over net input.
    const appFee = (sellAmount * BigInt(appFeeBps)) / 10_000n
    const netSellAmount = sellAmount - appFee
    const grossBuyAmount = buyAmount + withdrawFee

    const feeAmountInSellCurrency =
      grossBuyAmount > 0n ? appFee + (withdrawFee * netSellAmount) / grossBuyAmount : appFee
    const feeAmountInBuyCurrency =
      netSellAmount > 0n ? (appFee * grossBuyAmount) / netSellAmount + withdrawFee : withdrawFee
    const feeBps = sellAmount > 0n ? Number((feeAmountInSellCurrency * 10_000n + sellAmount / 2n) / sellAmount) : 0

    return {
      id: recoveredDepositAddress.quoteHash,
      signature: quoteResponse.signature,
      attestationSignature: recoveredDepositAddress.attestationSignature,
      quoteBody: recoveredDepositAddress.stringifiedQuote,
      isSell: request.kind === OrderKind.SELL,
      depositAddress: quote.depositAddress as Hex,
      quoteTimestamp: new Date(isoDate).getTime(),
      expectedFillTimeSeconds: quote.timeEstimate,
      limits: {
        minDeposit: BigInt(quote.minAmountIn),
        maxDeposit: sellAmount,
      },
      fees: {
        // Denominated in the sell currency, i.e. the same value as
        // `costs.bridgingFee.amountInSellCurrency`. This is the SDK's own cross-provider convention
        // (PROVIDER_README.md, plus the Bungee and Across providers), not something 1Click dictates.
        // Like Bungee's `routeFee` this is the fee only, and excludes execution spread.
        bridgeFee: feeAmountInSellCurrency,
        destinationGasFee: BigInt(0),
      },
      amountsAndCosts: {
        beforeFee: {
          // `amountOut` arrives already net of both fees, so the pre-fee buy amount has to add them
          // back. Keeping `beforeFee.buyAmount` at `amountOut` makes consumers that render
          // "expected to receive" as `beforeFee - bridgingFee` subtract the fee a second time, which
          // can push it below `afterSlippage`. Bungee can hold both equal because its `routeFee` is
          // taken in the source token; 1Click's `withdrawFee` comes out of the destination token.
          sellAmount,
          buyAmount: buyAmount + feeAmountInBuyCurrency,
        },
        afterFee: {
          // The sell amount does not change: the user deposits the full `amountIn` and the fees are
          // reported as costs, matching the Bungee and Across providers.
          sellAmount,
          buyAmount,
        },
        afterSlippage: {
          sellAmount,
          buyAmount: minBuyAmount,
        },
        slippageBps,
        costs: {
          bridgingFee: {
            feeBps,
            amountInSellCurrency: feeAmountInSellCurrency,
            amountInBuyCurrency: feeAmountInBuyCurrency,
          },
        },
      },
    }
  }

  async getBridgeReceiverOverride(_request: QuoteBridgeRequest, quote: NearIntentsQuoteResult): Promise<string> {
    return quote.depositAddress
  }

  async getBridgingParams(
    _chainId: ChainId,
    order: EnrichedOrder,
    _txHash: string,
  ): Promise<{ params: BridgingDepositParams; status: BridgeStatusResult } | null> {
    const depositAddress = order.receiver
    if (!depositAddress) return null

    const [tokens, status] = await Promise.all([this.api.getTokens(), this.api.getStatus(depositAddress)])

    // Unpack quote data
    const qr = status.quoteResponse?.quoteRequest
    const swapDetails = status.swapDetails
    const quote = status.quoteResponse?.quote
    const timestampMs = Date.parse(status.quoteResponse?.timestamp ?? '')
    if (!qr || !quote || Number.isNaN(timestampMs)) {
      throw new Error('Malformed quote response from NEAR Intents')
    }

    const quoteTimestamp = Math.floor(timestampMs / 1000)

    // Locate origin/destination tokens
    const inputToken = tokens.find((t) => t.assetId === qr.originAsset)
    const outputToken = tokens.find((t) => t.assetId === qr.destinationAsset)
    if (!inputToken || !outputToken) throw new Error('Token not supported')

    // Normalize to local token shape
    const adaptedInput = adaptToken(inputToken)
    const adaptedOutput = adaptToken(outputToken)
    if (!adaptedInput?.chainId || !adaptedOutput?.chainId) {
      throw new Error('Token not supported')
    }

    // Build response
    return {
      status: {
        fillTimeInSeconds: quote.timeEstimate,
        status: NEAR_INTENTS_STATUS_TO_COW_STATUS[status.status] ?? BridgeStatus.UNKNOWN,
        fillTxHash: status.swapDetails?.destinationChainTxHashes?.[0]?.hash,
      },
      params: {
        inputTokenAddress: adaptedInput.address,
        outputTokenAddress: adaptedOutput.address,
        inputAmount: BigInt(quote.amountIn),
        outputAmount: swapDetails.amountOut ? BigInt(swapDetails.amountOut) : BigInt(quote.amountOut),
        owner: order.owner,
        quoteTimestamp,
        fillDeadline: quoteTimestamp + quote.timeEstimate,
        recipient: qr.recipient,
        sourceChainId: adaptedInput.chainId,
        destinationChainId: adaptedOutput.chainId,
        bridgingId: depositAddress, // NEAR Intents deposit address
      },
    }
  }

  getExplorerUrl(bridgingId: string): string {
    return `https://explorer.near-intents.org/transactions/${bridgingId}`
  }

  async getStatus(bridgingId: string, _originChainId: SupportedChainId): Promise<BridgeStatusResult> {
    // bridingId must be the deposit address
    try {
      const statusResponse = await this.api.getStatus(bridgingId)
      return {
        status: NEAR_INTENTS_STATUS_TO_COW_STATUS[statusResponse.status] || BridgeStatus.UNKNOWN,
        depositTxHash: statusResponse.swapDetails?.originChainTxHashes[0]?.hash,
        fillTxHash: statusResponse.swapDetails?.destinationChainTxHashes[0]?.hash,
      }
    } catch {
      return {
        status: BridgeStatus.UNKNOWN,
      }
    }
  }

  getCancelBridgingTx(_bridgingId: string): Promise<EvmCall> {
    throw new Error('Not implemented')
  }

  getRefundBridgingTx(_bridgingId: string): Promise<EvmCall> {
    throw new Error('Not implemented')
  }

  /**
   * A script to verify depositAddress from appData: https://codesandbox.io/p/sandbox/h7tngy
   */
  async recoverDepositAddress({
    quote,
    quoteRequest,
    timestamp,
  }: QuoteResponse): Promise<DepositAddressContext | null> {
    try {
      if (!quote?.depositAddress) return null

      const utils = getGlobalAdapter().utils
      const { hash: quoteHash, stringifiedQuote } = hashQuote({ quote, quoteRequest, timestamp })

      const depositAddr = utils.getChecksumAddress(quote.depositAddress as Address)
      const { signature } = await this.api.getAttestation({
        quoteHash,
        depositAddress: depositAddr,
      })
      if (!signature || !utils.isHexString(signature)) return null

      // Build message bytes (prefix || version || depositAddress || quoteHash)
      const payload = utils.hexConcat([depositAddr, quoteHash])
      const messageBytes = utils.hexConcat([ATTESTATION_PREFIX_CONST, ATTESTION_VERSION_BYTE, payload])

      const hash = utils.keccak256(messageBytes)

      return {
        address: await utils.recoverAddress(hash, signature),
        quoteHash,
        stringifiedQuote,
        attestationSignature: signature,
      }
    } catch {
      return null
    }
  }
}
