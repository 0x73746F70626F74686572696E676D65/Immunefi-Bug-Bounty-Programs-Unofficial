import { BungeeQuoteResult } from './BungeeBridgeProvider'
import { QuoteBridgeRequest } from '../../types'
import { BungeeTxDataBytesIndices } from './const/misc'
import { InputOutputAmountTxDataBytesIndices } from './types'
import { BUNGEE_APPROVE_AND_BRIDGE_V1_ABI } from './abi'
import { BungeeApproveAndBridgeV1Addresses } from './const/contracts'
import { decodeBungeeBridgeTxData } from './util'
import { ETH_ADDRESS, EvmCall } from '@cowprotocol/sdk-config'
import { areAddressesEqual, getGlobalAdapter } from '@cowprotocol/sdk-common'

export async function createBungeeDepositCall(params: {
  request: QuoteBridgeRequest
  quote: BungeeQuoteResult
}): Promise<EvmCall> {
  const adapter = getGlobalAdapter()

  const { request, quote } = params
  const { bungeeQuote, buildTx } = quote

  const bridge = bungeeQuote.routeBridge
  const { functionSelector: _functionSelector } = decodeBungeeBridgeTxData(buildTx.txData.data)
  const functionSelector = _functionSelector.toLowerCase()

  // Prepare modifyCalldataParams for the bridge contract
  // information required for modifying input amount and output amount
  const functionParams = BungeeTxDataBytesIndices[bridge][functionSelector]

  if (!functionParams) {
    throw new Error(`createBungeeDepositCall() no params for function [${functionSelector}]`)
  }

  const inputAmountStartIndex = functionParams.inputAmount.bytes_startIndex
  let modifyOutputAmount = false
  let outputAmountStartIndex = 0
  const nativeTokenExtraFee = 0n // neither across nor cctp-v2 requires additional native token transfer for now

  // Some bridges encode a second proportional uint256 that must be updated alongside input amount.
  if ('outputAmount' in functionParams) {
    modifyOutputAmount = true
    outputAmountStartIndex = (functionParams as InputOutputAmountTxDataBytesIndices).outputAmount.bytes_startIndex
  }

  // Encode extra data as bytes
  const modifyCalldataParams = adapter.utils.encodeAbi(
    ['uint256', 'bool', 'uint256'],
    [inputAmountStartIndex, modifyOutputAmount, outputAmountStartIndex],
  ) as string
  // Concatenate calldata + modifyCalldataParams
  let data = buildTx.txData.data

  if (data.startsWith('0x')) data = data.slice(2)
  let extra = modifyCalldataParams
  if (extra.startsWith('0x')) extra = extra.slice(2)
  const fullData = '0x' + data + extra

  // use the input amount from
  // but will later be modified by BungeeApproveAndBridge
  const bridgeInputAmount = bungeeQuote.input.amount
  // function approveAndBridge(IERC20 token, uint256 minAmount, address receiver, bytes calldata data) external {

  const callData = adapter.utils.encodeFunction(BUNGEE_APPROVE_AND_BRIDGE_V1_ABI, 'approveAndBridge', [
    // @note sellTokenAddress here will be the intermediate token in usage. the naming might be a bit misleading
    //       see getQuoteWithBridge.ts::getBaseBridgeQuoteRequest()
    request.sellTokenAddress, // token
    bridgeInputAmount, // minAmount
    nativeTokenExtraFee, // nativeTokenExtraFee
    fullData, // data
  ])

  // If native token, set value; otherwise, value is 0
  // use the output amount from the quote
  // but will later be modified by BungeeApproveAndBridge
  const value = areAddressesEqual(request.sellTokenAddress, ETH_ADDRESS) ? BigInt(bridgeInputAmount) : 0n
  const finalValue = value + nativeTokenExtraFee
  // @note sellTokenChainId here will be the intermediate token chainId. the naming might be a bit misleading
  //       see getQuoteWithBridge.ts::getBaseBridgeQuoteRequest()
  const to = BungeeApproveAndBridgeV1Addresses[request.sellTokenChainId]
  if (!to) {
    throw new Error('BungeeApproveAndBridgeV1 not found')
  }

  return {
    to: to,
    data: callData,
    value: finalValue,
  }
}
