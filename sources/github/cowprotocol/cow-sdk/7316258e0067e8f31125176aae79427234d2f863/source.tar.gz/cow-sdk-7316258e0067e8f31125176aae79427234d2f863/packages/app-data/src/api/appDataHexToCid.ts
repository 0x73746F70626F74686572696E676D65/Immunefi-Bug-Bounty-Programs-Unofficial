import { getGlobalAdapter } from '@cowprotocol/sdk-common'
import { MetaDataError } from '../consts'

/**
 *  Convert an app-data hex string to a CID
 *
 * @param appDataHex - The app-data hex string (app-data part of the order struct)
 * @returns The IPFS CID v1 of the content
 */
export async function appDataHexToCid(appDataHex: string): Promise<string> {
  const cid = await _appDataHexToCid(appDataHex)
  _assertCid(cid, appDataHex)
  return cid
}

export function _assertCid(cid: string, appDataHex: string) {
  if (!cid) throw new MetaDataError('Error getting CID from appDataHex: ' + appDataHex)
}

/**
 *  Derive the IPFS CID v1 from the appData hex
 *
 * For reference see  https://github.com/cowprotocol/services/issues/1465 and https://github.com/cowprotocol/services/blob/main/crates/app-data-hash/src/lib.rs
 *
 * @param appDataHex hex with tha appData hash
 * @returns the CID v1 of the content
 */
async function _appDataHexToCid(appDataHex: string): Promise<string> {
  const cidBytes = await _toCidBytes({
    version: 0x01, // CIDv1
    multicodec: 0x55, // Raw codec
    hashingAlgorithm: 0x1b, // keccak hash algorithm
    hashingLength: 32, // keccak hash length (0x20 = 32)
    multihashHex: appDataHex, // 32 bytes of the keccak256 hash
  })

  // Encode to base16
  const { base16 } = await import('multiformats/bases/base16')
  return base16.encode(cidBytes)
}

interface ToCidParams {
  version: number
  multicodec: number
  hashingAlgorithm: number
  hashingLength: number
  multihashHex: string
}

async function _toCidBytes(params: ToCidParams): Promise<Uint8Array> {
  const hashBytes = getGlobalAdapter().utils.arrayify(params.multihashHex)

  // Concat prefix and multihash
  const cidPrefix = Uint8Array.from([params.version, params.multicodec, params.hashingAlgorithm, params.hashingLength])
  const cidBytes = new Uint8Array(cidPrefix.length + hashBytes.length)
  cidBytes.set(cidPrefix)
  cidBytes.set(hashBytes, cidPrefix.length)

  return cidBytes
}
