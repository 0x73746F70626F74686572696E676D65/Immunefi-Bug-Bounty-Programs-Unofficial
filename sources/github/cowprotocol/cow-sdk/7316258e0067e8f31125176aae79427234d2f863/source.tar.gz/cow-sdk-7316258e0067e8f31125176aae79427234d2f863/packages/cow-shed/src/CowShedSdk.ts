import { EvmCall, SupportedChainId } from '@cowprotocol/sdk-config'
import { CowShedHooks } from './contracts/CoWShedHooks'
import {
  ContractsEcdsaSigningScheme as EcdsaSigningScheme,
  ContractsSigningScheme as SigningScheme,
} from '@cowprotocol/sdk-contracts-ts'
import { ICoWShedCall, ICoWShedOptions } from './types'
import { CowShedFactoryAbi } from './abi/CowShedFactoryAbi'

import {
  AbstractProviderAdapter,
  getGlobalAdapter,
  jsonWithBigintReplacer,
  log,
  MAX_UINT256 as NON_EXPIRING_DEADLINE,
  setGlobalAdapter,
  SignerLike,
} from '@cowprotocol/sdk-common'
import { COW_SHED_LATEST_VERSION, CoWShedVersion } from './const'

export interface SignAndEncodeTxArgs {
  /**
   * Calls to pre-authorize on the cow-shed account
   */
  calls: ICoWShedCall[]

  /**
   * Signer for the cow-shed's owner account.
   *
   * The signer will be used to pre-authorise the calls.
   * The cow-shed account will be derived from this signer.
   */
  signer?: SignerLike

  /**
   * Chain ID to use for the transaction.
   */
  chainId: SupportedChainId

  /**
   * Nonce to use for the transaction. If not provided, the current timestamp will be used.
   */
  nonce?: string

  /**
   * Deadline to use for the transaction. If not provided, the maximum uint256 will be used.
   */
  deadline?: bigint

  /**
   * If value is provided, gas won't be estimated and will use the value
   */
  gasLimit?: bigint

  /**
   * Default gas limit to use for the transaction. If not provided, it will throw an error if the gas limit cannot be estimated.
   */
  defaultGasLimit?: bigint

  /**
   * Signing scheme to use for the transaction.
   */
  signingScheme?: EcdsaSigningScheme
}

export interface EncodeExecuteOwnHooksArgs {
  calls: ICoWShedCall[]
  chainId: SupportedChainId
  value?: bigint
}

export interface CowShedCall {
  cowShedAccount: string
  signedMulticall: EvmCall
  gasLimit: bigint
}

export interface CowShedSdkOptions {
  /**
   * Optional adapter for the cow-shed, if not provided, the global adapter will be used.
   */
  adapter?: AbstractProviderAdapter

  /**
   * Custom options for the cow-shed hooks.
   */
  factoryOptions?: ICoWShedOptions
}

export class CowShedSdk {
  protected hooksCache = new Map<SupportedChainId, CowShedHooks>()

  constructor(
    adapter?: AbstractProviderAdapter,
    private factoryOptions?: ICoWShedOptions,
    public readonly version: CoWShedVersion = COW_SHED_LATEST_VERSION,
  ) {
    if (adapter) {
      setGlobalAdapter(adapter)
    }
  }

  getCowShedAccount(chainId: SupportedChainId, ownerAddress: string): string {
    const cowShedHooks = this.getCowShedHooks(chainId)
    return cowShedHooks.proxyOf(ownerAddress)
  }

  encodeExecuteOwnHooks({ calls, chainId, value = 0n }: EncodeExecuteOwnHooksArgs): EvmCall {
    const cowShedHooks = this.getCowShedHooks(chainId)
    return {
      to: cowShedHooks.getFactoryAddress(),
      data: getGlobalAdapter().utils.encodeFunction(CowShedFactoryAbi, 'executeOwnHooks', [calls]) as string,
      value,
    }
  }

  /**
   * Encodes multiple calls into a single pre-authorized call to the cow-shed factory.
   *
   * This single call will create the cow-shed account if it doesn't exist yet, then will execute the calls.
   *
   * @returns pre-authorized multicall details
   */
  async signCalls({
    calls,
    signer: signerParam,
    chainId,
    nonce = CowShedSdk.getNonce(),
    deadline = NON_EXPIRING_DEADLINE,
    gasLimit,
    defaultGasLimit,
    signingScheme = SigningScheme.EIP712,
  }: SignAndEncodeTxArgs): Promise<CowShedCall> {
    const cowShedHooks = this.getCowShedHooks(chainId)
    const adapter = getGlobalAdapter()
    const signer = signerParam ? adapter.createSigner(signerParam) : adapter.signer

    const ownerAddress = await signer.getAddress()
    const cowShedAccount = cowShedHooks.proxyOf(ownerAddress)

    // Sign the calls using cow-shed's owner
    const signature = await cowShedHooks.signCalls(calls, nonce, deadline, signingScheme, signer)

    //  Get the signed transaction's calldata
    const callData = cowShedHooks.encodeExecuteHooksForFactory(calls, nonce, deadline, ownerAddress, signature)

    // Estimate the gas limit for the transaction
    const cowShedFactoryAddress = cowShedHooks.getFactoryAddress()
    const factoryCall = {
      to: cowShedFactoryAddress,
      data: callData,
      value: BigInt(0),
    }
    const gasEstimate =
      gasLimit ||
      (await signer.estimateGas(factoryCall).catch((error) => {
        const factoryCallString = JSON.stringify(factoryCall, jsonWithBigintReplacer, 2)
        const errorMessage = `Error estimating gas for the cow-shed call: ${factoryCallString}. Review the factory call`

        // Return the default gas limit if provided
        if (defaultGasLimit) {
          log(`${errorMessage}, using the default gas limit.`)
          return defaultGasLimit
        }

        // Re-throw the error if no default gas limit is provided
        throw new Error(`${errorMessage}, or provide the defaultGasLimit parameter.`, { cause: error })
      }))

    // Return the details, including the signed transaction data
    return {
      cowShedAccount,
      signedMulticall: factoryCall,
      gasLimit: BigInt(gasEstimate.toString()),
    }
  }

  protected getCowShedHooks(chainId: SupportedChainId) {
    let cowShedHooks = this.hooksCache.get(chainId)

    if (cowShedHooks) {
      // Return cached cow-shed hooks
      return cowShedHooks
    }

    // Create new cow-shed hooks and cache it
    cowShedHooks = new CowShedHooks(chainId, this.factoryOptions, this.version)
    this.hooksCache.set(chainId, cowShedHooks)
    return cowShedHooks
  }

  protected static getNonce(): string {
    const adapter = getGlobalAdapter()
    return adapter.utils.formatBytes32String(Date.now().toString())
  }
}
