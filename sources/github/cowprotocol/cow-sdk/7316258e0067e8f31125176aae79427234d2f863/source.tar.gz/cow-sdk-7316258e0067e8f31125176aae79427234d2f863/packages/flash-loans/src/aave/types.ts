import type { SupportedChainId } from '@cowprotocol/sdk-config'
import type { TradeParameters, SwapAdvancedSettings } from '@cowprotocol/sdk-trading'
import type { AccountAddress } from '@cowprotocol/sdk-common'
import type { Address } from '@cowprotocol/sdk-order-book'
import type { UnsignedOrder } from '@cowprotocol/sdk-order-signing'

export interface FlashLoanHookAmounts {
  flashLoanAmount: string
  flashLoanFeeAmount: string
  sellAssetAmount: string
  buyAssetAmount: string
}
export interface FlashLoanHint {
  amount: string
  receiver: string
  liquidityProvider: string
  protocolAdapter: string
  token: string
}

export interface CollateralOrderData {
  owner: string
  receiver: string
  sellToken: string
  buyToken: string
  sellAmount: string
  buyAmount: string
  kind: string
  validTo: number
  flashLoanAmount: string
  flashLoanFeeAmount: string
  hookSellTokenAmount: string
  hookBuyTokenAmount: string
}

export type EncodedOrder = Record<string, string | number>

export interface CollateralSwapHooksGasLimit {
  preHookGasLimit?: bigint
  postHookGasLimit?: bigint
}
/**
 * Parameters for executing a collateral swap using Aave flash loans.
 */
export interface CollateralSwapParams {
  /** The blockchain network to execute the swap on. */
  chainId: SupportedChainId
  /** Trade parameters including tokens, amounts, and validity period. */
  tradeParameters: TradeParameters
  /** The address of the collateral token to be approved for the flash loan adapter. */
  collateralToken: Address
  /** The flash loan fee as a percentage (e.g., 0.05 for 0.05%). Defaults to 0. */
  flashLoanFeePercent?: number
  /** Optional settings for controlling approval and permit behavior. */
  settings?: {
    /** Set to true to prevent automatic token approval. Default: false. */
    preventApproval?: boolean
    /** EIP-2612 permit data for gasless approval. If provided, uses permit instead of approve. */
    collateralPermit?: CollateralPermitData
    hooksGasLimit?: CollateralSwapHooksGasLimit
  }
}

export interface CollateralSwapTradeParams {
  chainId: SupportedChainId
  validTo: number
  owner: AccountAddress
  flashLoanFeeAmount: bigint
  hooksGasLimit?: CollateralSwapHooksGasLimit
}

export interface CollateralSwapOrder {
  /**
   * Gross amount borrowed via the Aave flash loan, in the underlying token's unit.
   * Populates {@link FlashLoanHookAmounts.flashLoanAmount} on the resulting hooks.
   * Includes the portion that gets repaid as the flash loan fee — i.e. `orderToSign.sellAmount + flashLoanFeeAmount`
   * for a standard collateral swap, since aTokens are 1:1 with the underlying.
   */
  flashLoanAmount: bigint
  /**
   * The unsigned CoW Protocol order that will be signed via EIP-1271. The order's `sellAmount`,
   * `buyAmount`, `sellToken`, `buyToken`, `kind`, and `validTo` are the source of truth for the
   * hooks — flash loan amount and hook buy/sell amounts are derived from this order to guarantee
   * the generated hooks match the order they get attached to.
   */
  orderToSign: UnsignedOrder
  /**
   * Optional EIP-2612 permit signature authorizing the adapter to spend the collateral aToken.
   * When provided, the SDK uses permit-based approval instead of a separate `approve` tx. Leave
   * undefined to fall back to the standard ERC-20 approval flow.
   */
  collateralPermit?: CollateralPermitData
}

export interface CollateralSwapQuoteParams
  extends Omit<TradeParameters, 'owner' | 'validTo'>,
    CollateralSwapTradeParams {}

export interface CollateralSwapPostParams {
  swapSettings: SwapAdvancedSettings
  instanceAddress: AccountAddress
}

export interface CollateralParameters {
  trader: AccountAddress
  collateralToken: string
  amount: bigint
  instanceAddress: AccountAddress
}

export interface CollateralPermitData {
  amount: string
  deadline: number
  v: number
  r: string
  s: string
}
