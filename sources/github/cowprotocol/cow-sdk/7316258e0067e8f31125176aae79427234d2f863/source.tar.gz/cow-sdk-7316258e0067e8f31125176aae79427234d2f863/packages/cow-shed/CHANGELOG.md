# Changelog

## [0.6.2](https://github.com/cowprotocol/cow-sdk/compare/sdk-cow-shed-v0.6.1...sdk-cow-shed-v0.6.2) (2026-09-29)


### 🔧 Miscellaneous

* update coverage badges ([#1026](https://github.com/cowprotocol/cow-sdk/issues/1026)) ([e44f931](https://github.com/cowprotocol/cow-sdk/commit/e44f931c2fc579d31f0773a79aeffd5678a9ed49))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-config bumped to 2.7.2
    * @cowprotocol/sdk-common bumped to 0.14.2
    * @cowprotocol/sdk-contracts-ts bumped to 3.7.2
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.4.18
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.4.18
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.33

## [0.6.1](https://github.com/cowprotocol/cow-sdk/compare/sdk-cow-shed-v0.6.0...sdk-cow-shed-v0.6.1) (2026-09-25)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-config bumped to 2.7.1
    * @cowprotocol/sdk-common bumped to 0.14.1
    * @cowprotocol/sdk-contracts-ts bumped to 3.7.1
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.4.17
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.4.17
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.32

## [0.6.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-cow-shed-v0.5.2...sdk-cow-shed-v0.6.0) (2026-09-23)


### ✨ Features

* **cow-shed:** support v1.2.0 factory flow ([#1025](https://github.com/cowprotocol/cow-sdk/issues/1025)) ([9a14861](https://github.com/cowprotocol/cow-sdk/commit/9a14861d8a5b158bbda2b8a8a9b72d30c5f01466))

## [0.5.2](https://github.com/cowprotocol/cow-sdk/compare/sdk-cow-shed-v0.5.1...sdk-cow-shed-v0.5.2) (2026-09-21)


### 🔧 Miscellaneous

* update coverage badges ([#1011](https://github.com/cowprotocol/cow-sdk/issues/1011)) ([3701bb5](https://github.com/cowprotocol/cow-sdk/commit/3701bb53a4815d553757db70ebd8bba8db02f0db))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.14.0
    * @cowprotocol/sdk-contracts-ts bumped to 3.7.0
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.4.16
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.4.16
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.31

## [0.5.1](https://github.com/cowprotocol/cow-sdk/compare/sdk-cow-shed-v0.5.0...sdk-cow-shed-v0.5.1) (2026-09-18)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-config bumped to 2.7.0
    * @cowprotocol/sdk-common bumped to 0.13.1
    * @cowprotocol/sdk-contracts-ts bumped to 3.6.0
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.4.15
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.4.15
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.30

## [0.5.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-cow-shed-v0.4.8...sdk-cow-shed-v0.5.0) (2026-09-16)


### ✨ Features

* **cow-shed:** support custom deployment domains ([#990](https://github.com/cowprotocol/cow-sdk/issues/990)) ([8ffa557](https://github.com/cowprotocol/cow-sdk/commit/8ffa557b888079d390f7388eb8575b0ca0d42330))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.13.0
    * @cowprotocol/sdk-contracts-ts bumped to 3.5.2
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.4.14
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.4.14
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.29

## [0.4.8](https://github.com/cowprotocol/cow-sdk/compare/sdk-cow-shed-v0.4.7...sdk-cow-shed-v0.4.8) (2026-09-07)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-config bumped to 2.6.0
    * @cowprotocol/sdk-common bumped to 0.12.3
    * @cowprotocol/sdk-contracts-ts bumped to 3.5.1
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.4.13
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.4.13
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.28

## [0.4.7](https://github.com/cowprotocol/cow-sdk/compare/sdk-cow-shed-v0.4.6...sdk-cow-shed-v0.4.7) (2026-09-04)


### 🔧 Miscellaneous

* split integration tests ([#978](https://github.com/cowprotocol/cow-sdk/issues/978)) ([72bbc6f](https://github.com/cowprotocol/cow-sdk/commit/72bbc6f8f88ce66597f36cd08d391ab79e342843))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-config bumped to 2.5.0
    * @cowprotocol/sdk-common bumped to 0.12.2
    * @cowprotocol/sdk-contracts-ts bumped to 3.5.0
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.4.12
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.4.12
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.27

## [0.4.6](https://github.com/cowprotocol/cow-sdk/compare/sdk-cow-shed-v0.4.5...sdk-cow-shed-v0.4.6) (2026-09-01)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-contracts-ts bumped to 3.4.0

## [0.4.5](https://github.com/cowprotocol/cow-sdk/compare/sdk-cow-shed-v0.4.4...sdk-cow-shed-v0.4.5) (2026-07-29)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-config bumped to 2.4.0
    * @cowprotocol/sdk-common bumped to 0.12.1
    * @cowprotocol/sdk-contracts-ts bumped to 3.3.3
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.4.11
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.4.11
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.26

## [0.4.4](https://github.com/cowprotocol/cow-sdk/compare/sdk-cow-shed-v0.4.3...sdk-cow-shed-v0.4.4) (2026-07-28)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-contracts-ts bumped to 3.3.2

## [0.4.3](https://github.com/cowprotocol/cow-sdk/compare/sdk-cow-shed-v0.4.2...sdk-cow-shed-v0.4.3) (2026-07-22)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-contracts-ts bumped to 3.3.1

## [0.4.2](https://github.com/cowprotocol/cow-sdk/compare/sdk-cow-shed-v0.4.1...sdk-cow-shed-v0.4.2) (2026-07-22)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-contracts-ts bumped to 3.3.0
  * devDependencies
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.25

## [0.4.1](https://github.com/cowprotocol/cow-sdk/compare/sdk-cow-shed-v0.4.0...sdk-cow-shed-v0.4.1) (2026-06-23)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-contracts-ts bumped to 3.2.1

## [0.4.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-cow-shed-v0.3.13...sdk-cow-shed-v0.4.0) (2026-06-15)


### ✨ Features

* per-package test coverage badges, updated in CI ([#895](https://github.com/cowprotocol/cow-sdk/issues/895)) ([c73246c](https://github.com/cowprotocol/cow-sdk/commit/c73246cc52c4fc79b2628b7c5f580695fd3dc1e2))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-config bumped to 2.3.1
    * @cowprotocol/sdk-common bumped to 0.12.0
    * @cowprotocol/sdk-contracts-ts bumped to 3.2.0
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.4.10
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.4.10
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.24

## [0.3.13](https://github.com/cowprotocol/cow-sdk/compare/sdk-cow-shed-v0.3.12...sdk-cow-shed-v0.3.13) (2026-06-08)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-config bumped to 2.3.0
    * @cowprotocol/sdk-common bumped to 0.11.2
    * @cowprotocol/sdk-contracts-ts bumped to 3.1.2
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.4.9
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.4.9
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.23

## [0.3.12](https://github.com/cowprotocol/cow-sdk/compare/sdk-cow-shed-v0.3.11...sdk-cow-shed-v0.3.12) (2026-06-02)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-config bumped to 2.2.1
    * @cowprotocol/sdk-common bumped to 0.11.1
    * @cowprotocol/sdk-contracts-ts bumped to 3.1.1
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.4.8
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.4.8
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.22

## [0.3.11](https://github.com/cowprotocol/cow-sdk/compare/sdk-cow-shed-v0.3.10...sdk-cow-shed-v0.3.11) (2026-05-27)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-config bumped to 2.2.0
    * @cowprotocol/sdk-common bumped to 0.11.0
    * @cowprotocol/sdk-contracts-ts bumped to 3.1.0
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.4.7
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.4.7
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.21

## [0.3.10](https://github.com/cowprotocol/cow-sdk/compare/sdk-cow-shed-v0.3.9...sdk-cow-shed-v0.3.10) (2026-05-22)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-config bumped to 2.1.0
    * @cowprotocol/sdk-common bumped to 0.10.3
    * @cowprotocol/sdk-contracts-ts bumped to 3.0.3
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.4.6
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.4.6
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.20

## [0.3.9](https://github.com/cowprotocol/cow-sdk/compare/sdk-cow-shed-v0.3.8...sdk-cow-shed-v0.3.9) (2026-05-20)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-contracts-ts bumped to 3.0.2
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.4.5
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.4.5
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.19

## [0.3.8](https://github.com/cowprotocol/cow-sdk/compare/sdk-cow-shed-v0.3.7...sdk-cow-shed-v0.3.8) (2026-04-20)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-contracts-ts bumped to 3.0.1

## [0.3.7](https://github.com/cowprotocol/cow-sdk/compare/sdk-cow-shed-v0.3.6...sdk-cow-shed-v0.3.7) (2026-04-16)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-config bumped to 2.0.0
    * @cowprotocol/sdk-common bumped to 0.10.2
    * @cowprotocol/sdk-contracts-ts bumped to 3.0.0
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.4.4
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.4.4
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.18

## [0.3.6](https://github.com/cowprotocol/cow-sdk/compare/sdk-cow-shed-v0.3.5...sdk-cow-shed-v0.3.6) (2026-04-14)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-config bumped to 1.2.0
    * @cowprotocol/sdk-common bumped to 0.10.1
    * @cowprotocol/sdk-contracts-ts bumped to 2.5.0
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.4.3
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.4.3
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.17

## [0.3.5](https://github.com/cowprotocol/cow-sdk/compare/sdk-cow-shed-v0.3.4...sdk-cow-shed-v0.3.5) (2026-04-08)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-config bumped to 1.1.3
    * @cowprotocol/sdk-common bumped to 0.10.0
    * @cowprotocol/sdk-contracts-ts bumped to 2.4.0
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.4.2
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.4.2
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.16

## [0.3.4](https://github.com/cowprotocol/cow-sdk/compare/sdk-cow-shed-v0.3.3...sdk-cow-shed-v0.3.4) (2026-04-01)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.9.0
    * @cowprotocol/sdk-contracts-ts bumped to 2.3.0
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.4.1
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.4.1
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.15

## [0.3.3](https://github.com/cowprotocol/cow-sdk/compare/sdk-cow-shed-v0.3.2...sdk-cow-shed-v0.3.3) (2026-03-17)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-contracts-ts bumped to 2.2.0
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.4.0
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.4.0

## [0.3.2](https://github.com/cowprotocol/cow-sdk/compare/sdk-cow-shed-v0.3.1...sdk-cow-shed-v0.3.2) (2026-03-17)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-config bumped to 1.1.2
    * @cowprotocol/sdk-common bumped to 0.8.2
    * @cowprotocol/sdk-contracts-ts bumped to 2.1.2
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.3.14
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.3.14
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.14

## [0.3.1](https://github.com/cowprotocol/cow-sdk/compare/sdk-cow-shed-v0.3.0...sdk-cow-shed-v0.3.1) (2026-03-16)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-config bumped to 1.1.1
    * @cowprotocol/sdk-common bumped to 0.8.1
    * @cowprotocol/sdk-contracts-ts bumped to 2.1.1
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.3.13
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.3.13
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.13

## [0.3.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-cow-shed-v0.2.22...sdk-cow-shed-v0.3.0) (2026-03-16)


### ✨ Features

* update settlement and vault relayer contracts on staging ([#807](https://github.com/cowprotocol/cow-sdk/issues/807)) ([0f9a03e](https://github.com/cowprotocol/cow-sdk/commit/0f9a03e6bfa3468630e46735f7583618ae711b73))


### 🔧 Miscellaneous

* release main ([#826](https://github.com/cowprotocol/cow-sdk/issues/826)) ([baaa708](https://github.com/cowprotocol/cow-sdk/commit/baaa7088ac15b89fb83310e54aa52f09d19132ff))
* release main ([#832](https://github.com/cowprotocol/cow-sdk/issues/832)) ([5dafcb8](https://github.com/cowprotocol/cow-sdk/commit/5dafcb8ec5593250dba1ff6e9fdbf8eb11d974cf))
* revert release ([#833](https://github.com/cowprotocol/cow-sdk/issues/833)) ([0c40a9b](https://github.com/cowprotocol/cow-sdk/commit/0c40a9b3ee828c7ede66576f02e1b571e96140cd))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-config bumped to 1.1.0
    * @cowprotocol/sdk-common bumped to 0.8.0
    * @cowprotocol/sdk-contracts-ts bumped to 2.1.0
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.3.12
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.3.12
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.12

## [0.2.22](https://github.com/cowprotocol/cow-sdk/compare/sdk-cow-shed-v0.2.21...sdk-cow-shed-v0.2.22) (2026-03-10)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-config bumped to 1.0.0
    * @cowprotocol/sdk-common bumped to 0.7.1
    * @cowprotocol/sdk-contracts-ts bumped to 2.0.0
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.3.11
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.3.11
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.11

## [0.2.21](https://github.com/cowprotocol/cow-sdk/compare/sdk-cow-shed-v0.2.20...sdk-cow-shed-v0.2.21) (2026-03-04)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-config bumped to 0.10.0
    * @cowprotocol/sdk-common bumped to 0.7.0
    * @cowprotocol/sdk-contracts-ts bumped to 1.8.0
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.3.10
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.3.10
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.10

## [0.2.20](https://github.com/cowprotocol/cow-sdk/compare/sdk-cow-shed-v0.2.19...sdk-cow-shed-v0.2.20) (2026-03-04)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-config bumped to 0.9.0
    * @cowprotocol/sdk-common bumped to 0.6.3
    * @cowprotocol/sdk-contracts-ts bumped to 1.7.0
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.3.9
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.3.9
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.9

## [0.2.19](https://github.com/cowprotocol/cow-sdk/compare/sdk-cow-shed-v0.2.18...sdk-cow-shed-v0.2.19) (2026-02-20)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-config bumped to 0.8.1
    * @cowprotocol/sdk-common bumped to 0.6.2
    * @cowprotocol/sdk-contracts-ts bumped to 1.6.1
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.3.8
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.3.8
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.8

## [0.2.18](https://github.com/cowprotocol/cow-sdk/compare/sdk-cow-shed-v0.2.17...sdk-cow-shed-v0.2.18) (2026-02-18)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-config bumped to 0.8.0
    * @cowprotocol/sdk-common bumped to 0.6.1
    * @cowprotocol/sdk-contracts-ts bumped to 1.6.0
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.3.7
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.3.7
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.7

## [0.2.17](https://github.com/cowprotocol/cow-sdk/compare/sdk-cow-shed-v0.2.16...sdk-cow-shed-v0.2.17) (2026-02-05)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.6.0
    * @cowprotocol/sdk-contracts-ts bumped to 1.5.0
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.3.6
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.3.6
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.6

## [0.2.16](https://github.com/cowprotocol/cow-sdk/compare/sdk-cow-shed-v0.2.15...sdk-cow-shed-v0.2.16) (2026-02-02)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-config bumped to 0.7.3
    * @cowprotocol/sdk-common bumped to 0.5.4
    * @cowprotocol/sdk-contracts-ts bumped to 1.4.2
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.3.5
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.3.5
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.5

## [0.2.15](https://github.com/cowprotocol/cow-sdk/compare/sdk-cow-shed-v0.2.14...sdk-cow-shed-v0.2.15) (2026-02-02)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-config bumped to 0.7.2
    * @cowprotocol/sdk-common bumped to 0.5.3
    * @cowprotocol/sdk-contracts-ts bumped to 1.4.1
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.3.4
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.3.4
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.4

## [0.2.14](https://github.com/cowprotocol/cow-sdk/compare/sdk-cow-shed-v0.2.13...sdk-cow-shed-v0.2.14) (2026-01-28)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-config bumped to 0.7.1
    * @cowprotocol/sdk-common bumped to 0.5.2
    * @cowprotocol/sdk-contracts-ts bumped to 1.4.0
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.3.3
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.3.3
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.3

## [0.2.13](https://github.com/cowprotocol/cow-sdk/compare/sdk-cow-shed-v0.2.12...sdk-cow-shed-v0.2.13) (2026-01-28)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-config bumped to 0.7.0
    * @cowprotocol/sdk-common bumped to 0.5.1
    * @cowprotocol/sdk-contracts-ts bumped to 1.3.0
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.3.2
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.3.2
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.2

## [0.2.12](https://github.com/cowprotocol/cow-sdk/compare/sdk-cow-shed-v0.2.11...sdk-cow-shed-v0.2.12) (2026-01-22)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-contracts-ts bumped to 1.2.0

## [0.2.11](https://github.com/cowprotocol/cow-sdk/compare/sdk-cow-shed-v0.2.10...sdk-cow-shed-v0.2.11) (2026-01-21)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-contracts-ts bumped to 1.1.1

## [0.2.10](https://github.com/cowprotocol/cow-sdk/compare/sdk-cow-shed-v0.2.9...sdk-cow-shed-v0.2.10) (2026-01-19)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-config bumped to 0.6.3
    * @cowprotocol/sdk-common bumped to 0.5.0
    * @cowprotocol/sdk-contracts-ts bumped to 1.1.0
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.3.1
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.3.1
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.1

## [0.2.9](https://github.com/cowprotocol/cow-sdk/compare/sdk-cow-shed-v0.2.8...sdk-cow-shed-v0.2.9) (2025-12-19)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-contracts-ts bumped to 1.0.0

## [0.2.8](https://github.com/cowprotocol/cow-sdk/compare/sdk-cow-shed-v0.2.7...sdk-cow-shed-v0.2.8) (2025-12-11)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-config bumped to 0.6.2
    * @cowprotocol/sdk-contracts-ts bumped to 0.8.1

## [0.2.7](https://github.com/cowprotocol/cow-sdk/compare/sdk-cow-shed-v0.2.6...sdk-cow-shed-v0.2.7) (2025-12-10)


### 🔧 Miscellaneous

* release main ([#741](https://github.com/cowprotocol/cow-sdk/issues/741)) ([32fb8bb](https://github.com/cowprotocol/cow-sdk/commit/32fb8bbe6b1172c2666f330d0d50cdc2f7c2554f))
* revert not published release ([5facf05](https://github.com/cowprotocol/cow-sdk/commit/5facf05c67121404b7b5aa1e77950961b06eca81))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-contracts-ts bumped to 0.8.0

## [0.2.6](https://github.com/cowprotocol/cow-sdk/compare/sdk-cow-shed-v0.2.5...sdk-cow-shed-v0.2.6) (2025-12-05)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-config bumped to 0.6.1
    * @cowprotocol/sdk-contracts-ts bumped to 0.7.4

## [0.2.5](https://github.com/cowprotocol/cow-sdk/compare/sdk-cow-shed-v0.2.4...sdk-cow-shed-v0.2.5) (2025-12-04)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-config bumped to 0.6.0
    * @cowprotocol/sdk-contracts-ts bumped to 0.7.3

## [0.2.4](https://github.com/cowprotocol/cow-sdk/compare/sdk-cow-shed-v0.2.3...sdk-cow-shed-v0.2.4) (2025-12-03)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-config bumped to 0.5.0
    * @cowprotocol/sdk-contracts-ts bumped to 0.7.2

## [0.2.3](https://github.com/cowprotocol/cow-sdk/compare/sdk-cow-shed-v0.2.2...sdk-cow-shed-v0.2.3) (2025-11-27)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-config bumped to 0.4.1
    * @cowprotocol/sdk-contracts-ts bumped to 0.7.1

## [0.2.2](https://github.com/cowprotocol/cow-sdk/compare/sdk-cow-shed-v0.2.1...sdk-cow-shed-v0.2.2) (2025-11-24)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-contracts-ts bumped to 0.7.0

## [0.2.1](https://github.com/cowprotocol/cow-sdk/compare/sdk-cow-shed-v0.2.0...sdk-cow-shed-v0.2.1) (2025-11-24)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-config bumped to 0.4.0
    * @cowprotocol/sdk-common bumped to 0.4.0
    * @cowprotocol/sdk-contracts-ts bumped to 0.6.0
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.3.0
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.3.0
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.0

## [0.2.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-cow-shed-v0.1.10...sdk-cow-shed-v0.2.0) (2025-11-07)


### ✨ Features

* **cow-shed:** add ttl cache for RPC calls ([#644](https://github.com/cowprotocol/cow-sdk/issues/644)) ([10e1139](https://github.com/cowprotocol/cow-sdk/commit/10e1139f4e8d75ea2c737937d276835a1692ff8a))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-contracts-ts bumped to 0.5.0

## [0.1.10](https://github.com/cowprotocol/cow-sdk/compare/sdk-cow-shed-v0.1.9...sdk-cow-shed-v0.1.10) (2025-11-05)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-config bumped to 0.3.0
    * @cowprotocol/sdk-contracts-ts bumped to 0.4.4

## [0.1.9](https://github.com/cowprotocol/cow-sdk/compare/sdk-cow-shed-v0.1.8...sdk-cow-shed-v0.1.9) (2025-10-30)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-contracts-ts bumped to 0.4.3

## [0.1.8](https://github.com/cowprotocol/cow-sdk/compare/sdk-cow-shed-v0.1.7...sdk-cow-shed-v0.1.8) (2025-10-29)


### 🔧 Miscellaneous

* release main ([#620](https://github.com/cowprotocol/cow-sdk/issues/620)) ([b36394a](https://github.com/cowprotocol/cow-sdk/commit/b36394a2ba38957edb47ffc4451ea6624d66737b))
* revert release ([#634](https://github.com/cowprotocol/cow-sdk/issues/634)) ([fc7bf61](https://github.com/cowprotocol/cow-sdk/commit/fc7bf61444619d4b2c3a3dd55b7ce52c197b1878))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.3.0
    * @cowprotocol/sdk-contracts-ts bumped to 0.4.2
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.2.0
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.2.0
    * @cowprotocol/sdk-viem-adapter bumped to 0.2.0

## [0.1.7](https://github.com/cowprotocol/cow-sdk/compare/sdk-cow-shed-v0.1.6...sdk-cow-shed-v0.1.7) (2025-10-24)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-config bumped to 0.2.0
    * @cowprotocol/sdk-common bumped to 0.2.2
    * @cowprotocol/sdk-contracts-ts bumped to 0.4.1
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.1.3
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.1.3
    * @cowprotocol/sdk-viem-adapter bumped to 0.1.3

## [0.1.6](https://github.com/cowprotocol/cow-sdk/compare/sdk-cow-shed-v0.1.5...sdk-cow-shed-v0.1.6) (2025-10-15)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-contracts-ts bumped to 0.4.0

## [0.1.5](https://github.com/cowprotocol/cow-sdk/compare/sdk-cow-shed-v0.1.4...sdk-cow-shed-v0.1.5) (2025-10-08)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.2.1
    * @cowprotocol/sdk-contracts-ts bumped to 0.3.1
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.1.2
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.1.2
    * @cowprotocol/sdk-viem-adapter bumped to 0.1.2

## [0.1.4](https://github.com/cowprotocol/cow-sdk/compare/sdk-cow-shed-v0.1.3...sdk-cow-shed-v0.1.4) (2025-10-06)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.2.0
    * @cowprotocol/sdk-contracts-ts bumped to 0.3.0
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.1.1
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.1.1
    * @cowprotocol/sdk-viem-adapter bumped to 0.1.1

## [0.1.3](https://github.com/cowprotocol/cow-sdk/compare/sdk-cow-shed-v0.1.2...sdk-cow-shed-v0.1.3) (2025-09-24)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-contracts-ts bumped to 0.2.1

## [0.1.2](https://github.com/cowprotocol/cow-sdk/compare/sdk-cow-shed-v0.1.1...sdk-cow-shed-v0.1.2) (2025-09-23)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-contracts-ts bumped to 0.2.0

## [0.1.1](https://github.com/cowprotocol/cow-sdk/compare/sdk-cow-shed-v0.1.0...sdk-cow-shed-v0.1.1) (2025-09-22)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-contracts-ts bumped to 0.1.1

## [0.1.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-cow-shed-v0.3.0-beta.0...sdk-cow-shed-v0.1.0) (2025-09-17)


### ⚠ BREAKING CHANGES

* release cow-sdk v7

### ✨ Features

* release cow-sdk v7 ([6cd3e57](https://github.com/cowprotocol/cow-sdk/commit/6cd3e573687b1ffdbc0fdcb8cdbb414d88546e38))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-config bumped to 0.1.0
    * @cowprotocol/sdk-common bumped to 0.1.0
    * @cowprotocol/sdk-contracts-ts bumped to 0.1.0
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.1.0
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.1.0
    * @cowprotocol/sdk-viem-adapter bumped to 0.1.0

## [0.3.0-beta.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-cow-shed-v0.2.7-beta.0...sdk-cow-shed-v0.3.0-beta.0) (2025-09-17)


### ✨ Features

* **cow-shed:** validate EIP1271 signature ([#508](https://github.com/cowprotocol/cow-sdk/issues/508)) ([5c72123](https://github.com/cowprotocol/cow-sdk/commit/5c7212323edcea3eadf70973f765619afb1bcaf4))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.5.0-beta.0
    * @cowprotocol/sdk-contracts-ts bumped to 2.3.0-beta.0
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.2.5-beta.0
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.2.5-beta.0
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.1-beta.0

## [0.2.7-beta.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-cow-shed-v0.2.6-beta.0...sdk-cow-shed-v0.2.7-beta.0) (2025-09-16)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-contracts-ts bumped to 2.2.1-beta.0
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.2.4-beta.0
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.2.4-beta.0

## [0.2.6-beta.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-cow-shed-v0.2.5-beta.0...sdk-cow-shed-v0.2.6-beta.0) (2025-09-16)


### 📚 Documentation

* update README to focus on main use cases ([#493](https://github.com/cowprotocol/cow-sdk/issues/493)) ([a05cb1b](https://github.com/cowprotocol/cow-sdk/commit/a05cb1ba11b5f9895d7cfe6262cf74c4089fd73c))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-config bumped to 0.3.3-beta.0
    * @cowprotocol/sdk-common bumped to 0.4.0-beta.0
    * @cowprotocol/sdk-contracts-ts bumped to 2.2.0-beta.0
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.2.3-beta.0
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.2.3-beta.0
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.0-beta.0

## [0.2.5-beta.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-cow-shed-v0.2.4-beta.0...sdk-cow-shed-v0.2.5-beta.0) (2025-09-15)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-config bumped to 0.3.2-beta.0
    * @cowprotocol/sdk-contracts-ts bumped to 2.1.7-beta.0

## [0.2.4-beta.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-cow-shed-v0.2.3-beta.0...sdk-cow-shed-v0.2.4-beta.0) (2025-09-15)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-config bumped to 0.3.1-beta.0
    * @cowprotocol/sdk-contracts-ts bumped to 2.1.6-beta.0

## [0.2.3-beta.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-cow-shed-v0.2.2-beta.0...sdk-cow-shed-v0.2.3-beta.0) (2025-09-15)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-contracts-ts bumped to 2.1.5-beta.0

## [0.2.2-beta.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-cow-shed-v0.2.1-beta.0...sdk-cow-shed-v0.2.2-beta.0) (2025-09-11)


### 🔧 Miscellaneous

* release main ([#488](https://github.com/cowprotocol/cow-sdk/issues/488)) ([6344fa6](https://github.com/cowprotocol/cow-sdk/commit/6344fa619465e6f94637677823a18646f06fa7c9))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.3.0-beta.0
    * @cowprotocol/sdk-contracts-ts bumped to 2.1.4-beta.0
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.2.2-beta.0
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.2.2-beta.0
    * @cowprotocol/sdk-viem-adapter bumped to 0.2.2-beta.0

## [0.2.1-beta.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-cow-shed-v0.2.0-beta.0...sdk-cow-shed-v0.2.1-beta.0) (2025-09-11)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-config bumped to 0.3.0-beta.0
    * @cowprotocol/sdk-contracts-ts bumped to 2.1.3-beta.0

## [0.2.0-beta.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-cow-shed-v0.1.0-beta.0...sdk-cow-shed-v0.2.0-beta.0) (2025-08-28)


### ✨ Features

* allow changing backoff and limiter per request ([#208](https://github.com/cowprotocol/cow-sdk/issues/208)) ([ebea5ca](https://github.com/cowprotocol/cow-sdk/commit/ebea5ca0858aeb89ae3e5d5407c8903c3ca5178d))
* **cow-shed:** create package.json and tsconfig.json ([2548f17](https://github.com/cowprotocol/cow-sdk/commit/2548f17f75319d9615a814fdae5d13c25b9220ee))
* **cow-shed:** refact cow-she to use adapters and fix tests ([25b0986](https://github.com/cowprotocol/cow-sdk/commit/25b098630ae7850e6d09dcdfc9dcd67266cd7df1))
* **lib-agnostic:** migrate latest Bridging changes ([#426](https://github.com/cowprotocol/cow-sdk/issues/426)) ([2359d9b](https://github.com/cowprotocol/cow-sdk/commit/2359d9b903e80ae5bab0cdb92d8cf52ae250da36))
* **lib-agnostic:** migrate latest SDK changes ([#427](https://github.com/cowprotocol/cow-sdk/issues/427)) ([323bab6](https://github.com/cowprotocol/cow-sdk/commit/323bab61eb5adeb4a58bc15e25ffb29d2e1afcbf))
* **sdk-agnostic-lib:** create cow trading package ([#368](https://github.com/cowprotocol/cow-sdk/issues/368)) ([0a4534a](https://github.com/cowprotocol/cow-sdk/commit/0a4534aababce4f5d8bab991cd6ae9f51842d719))
* **sdk-agnostic-lib:** Create weiroll package ([#371](https://github.com/cowprotocol/cow-sdk/issues/371)) ([8f6a2e1](https://github.com/cowprotocol/cow-sdk/commit/8f6a2e16e5e7a43a5afc43cf5faab174be916b2e))


### 🐛 Bug Fixes

* **cow-shed:** fix adapters - estimateGas  and encodeAbi ([76ab995](https://github.com/cowprotocol/cow-sdk/commit/76ab995635247e63213dafb50ff462334977cc6d))
* **lib-agnostic:** add setProvider() method to adapters ([#432](https://github.com/cowprotocol/cow-sdk/issues/432)) ([64c0ea9](https://github.com/cowprotocol/cow-sdk/commit/64c0ea94d802aa167b978ae0859353d801de0911))


### 🔧 Miscellaneous

* add check to verify if the signature is the same across all three adapters in cowshedHooks test ([5558b86](https://github.com/cowprotocol/cow-sdk/commit/5558b867075ab9f0eb75eedf349d9ef96d65055f))
* adjust cow-shed hooks test ([812d18c](https://github.com/cowprotocol/cow-sdk/commit/812d18c7b1cac64668d3643212f34b99efb08ebd))
* apply PR suggestions ([2ff0f7c](https://github.com/cowprotocol/cow-sdk/commit/2ff0f7c74c377b67824da3ba6390edccdaad94f5))
* **cow-shed:** rename CowShedHooks test file ([4bf22a6](https://github.com/cowprotocol/cow-sdk/commit/4bf22a622413446874592c23178648c71fe66368))
* **sdk-agnostic-lib:** improve scripts and types ([#407](https://github.com/cowprotocol/cow-sdk/issues/407)) ([c4b5e08](https://github.com/cowprotocol/cow-sdk/commit/c4b5e086ce46086e9430d5f03ed330502349fbf3))
* **sdk-agnostic-lib:** merge multiple PRs to avoid conflicts and speed up base branch sync ([#354](https://github.com/cowprotocol/cow-sdk/issues/354)) ([55d3068](https://github.com/cowprotocol/cow-sdk/commit/55d3068c52217dd2618d8c180ab4fed8c9334c72))
* **subgraph:** move cow-shed to monorepo package ([2e7b27a](https://github.com/cowprotocol/cow-sdk/commit/2e7b27ae5ec04d03dc919cf508b1c4eb723818aa))
