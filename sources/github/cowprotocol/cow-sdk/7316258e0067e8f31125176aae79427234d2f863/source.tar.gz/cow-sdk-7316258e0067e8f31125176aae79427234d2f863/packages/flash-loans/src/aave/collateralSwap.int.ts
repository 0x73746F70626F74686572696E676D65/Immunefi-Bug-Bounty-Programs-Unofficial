import { createPublicClient, http } from 'viem'
import { privateKeyToAccount } from 'viem/accounts'
import { gnosis } from 'viem/chains'

import { ViemAdapter } from '@cowprotocol/sdk-viem-adapter'
import { getOrderToSign, LimitTradeParameters, TradingSdk } from '@cowprotocol/sdk-trading'
import { SupportedChainId } from '@cowprotocol/sdk-config'
import { OrderKind } from '@cowprotocol/sdk-order-book'

import { AaveCollateralSwapSdk } from './AaveCollateralSwapSdk'
import { AccountAddress } from '@cowprotocol/sdk-common'
import { AaveFlashLoanType, HASH_ZERO } from './const'

// =================== Config ===================
const RPC_URL = 'https://rpc.gnosis.gateway.fm'
const PRIVATE_KEY = process.env.PRIVATE_KEY
// ===============================================================

describe('AaveFlashLoanIntegration.collateralSwap', () => {
  it.skip('Test AaveFlashLoanSdk collateralSwap on Gnosis Chain with swap', async () => {
    const chainId = SupportedChainId.GNOSIS_CHAIN

    if (!PRIVATE_KEY) {
      throw new Error('Set PRIVATE_KEY to run this example')
    }

    const publicClient = createPublicClient({
      chain: gnosis,
      transport: http(RPC_URL),
    })
    const account = privateKeyToAccount(PRIVATE_KEY as `0x${string}`)

    const adapter = new ViemAdapter({ provider: publicClient, signer: account })
    const tradingSdk = new TradingSdk(
      {
        chainId,
        appCode: 'aave-v3-flashloan',
        signer: account,
        env: 'staging',
      },
      {},
      adapter,
    )
    const flashLoanSdk = new AaveCollateralSwapSdk()

    try {
      const result = await flashLoanSdk.collateralSwap(
        {
          chainId: SupportedChainId.GNOSIS_CHAIN,
          collateralToken: '0xd0Dd6cEF72143E22cCED4867eb0d5F2328715533', // aGnoWXDAI
          tradeParameters: {
            sellToken: '0xe91D153E0b41518A2Ce8Dd3D7944Fa863463a97d', // WXDAI
            sellTokenDecimals: 18,
            buyToken: '0x2a22f9c3b484c3629090FeED35F17Ff8F88f76F0', // USDC.e
            buyTokenDecimals: 6,
            amount: '20000000000000000000', // 20 WXDAI
            kind: OrderKind.SELL,
            validFor: 10 * 60, // 10m
            slippageBps: 8,
          },
          flashLoanFeePercent: 0.05, // 0.05%
        },
        tradingSdk,
      )

      expect(result).toEqual({ result: 'orderId' })
    } catch (error) {
      expect((error as { body: unknown }).body || error).toEqual({})
    }
  }, 120_000)

  it.skip('Test AaveFlashLoanSdk collateralSwap on Gnosis Chain with limit order', async () => {
    const chainId = SupportedChainId.GNOSIS_CHAIN

    if (!PRIVATE_KEY) {
      throw new Error('Set PRIVATE_KEY to run this example')
    }

    const publicClient = createPublicClient({
      chain: gnosis,
      transport: http(RPC_URL),
    })
    const account = privateKeyToAccount(PRIVATE_KEY as `0x${string}`)
    const appCode = 'aave-v3-flashloan'

    const adapter = new ViemAdapter({ provider: publicClient, signer: account })
    const tradingSdk = new TradingSdk(
      {
        chainId,
        appCode,
        signer: account,
        env: 'staging',
      },
      {},
      adapter,
    )
    const flashLoanSdk = new AaveCollateralSwapSdk()

    const owner = (await adapter.signer.getAddress()) as AccountAddress
    const sellAmount = 20000000000000000000n // 20 WXDAI
    // The amount is before slippage and partner fee!
    const buyAmount = 18000000n // 18 USDC.e
    const validTo = Math.ceil(Date.now() / 1000) + 10 * 60 // 10m
    const flashLoanFeeBps = 5 // 0.05%
    const slippageBps = 0 // 0.08%
    const partnerFee = {
      volumeBps: 10, // 0.1%
      recipient: owner, // TODO: set a correct partnerFee recipient
    }
    // Set true if you sell native token
    const isEthFlow = false
    const collateralPermit = undefined

    const { flashLoanFeeAmount, sellAmountToSign } = flashLoanSdk.calculateFlashLoanAmounts({
      flashLoanFeeBps,
      sellAmount,
    })

    const limitOrder: LimitTradeParameters = {
      sellToken: '0xe91D153E0b41518A2Ce8Dd3D7944Fa863463a97d', // WXDAI
      sellTokenDecimals: 18,
      buyToken: '0x2a22f9c3b484c3629090FeED35F17Ff8F88f76F0', // USDC.e
      buyTokenDecimals: 6,
      sellAmount: sellAmountToSign.toString(),
      buyAmount: buyAmount.toString(),
      kind: OrderKind.SELL,
      validTo,
      slippageBps,
      partnerFee,
    }

    const orderToSign = getOrderToSign(
      { chainId, from: owner, networkCostsAmount: '0', isEthFlow },
      limitOrder,
      HASH_ZERO,
    )

    const orderPostParams = await flashLoanSdk.getOrderPostingSettings(
      AaveFlashLoanType.CollateralSwap,
      {
        chainId,
        validTo,
        owner,
        flashLoanFeeAmount,
      },
      {
        flashLoanAmount: sellAmount,
        orderToSign,
        collateralPermit,
      },
    )

    try {
      const result = await tradingSdk.postLimitOrder(limitOrder, orderPostParams.swapSettings)

      expect(result).toEqual({ result: 'orderId' })
    } catch (error) {
      expect((error as { body: unknown }).body || error).toEqual({})
    }
  }, 120_000)
})
