# Changelog

## [0.13.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-trading-solana-v0.12.1...sdk-trading-solana-v0.13.0) (2026-10-01)


### ✨ Features

* use partiallySignedTx instead of transaction in order book API ([#1043](https://github.com/cowprotocol/cow-sdk/issues/1043)) ([044732e](https://github.com/cowprotocol/cow-sdk/commit/044732ec63d45f133836778e253897c10f5b4185))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-order-book bumped to 4.3.0
    * @cowprotocol/sdk-trading bumped to 2.7.4

## [0.12.1](https://github.com/cowprotocol/cow-sdk/compare/sdk-trading-solana-v0.12.0...sdk-trading-solana-v0.12.1) (2026-09-29)


### 🔧 Miscellaneous

* update coverage badges ([#1026](https://github.com/cowprotocol/cow-sdk/issues/1026)) ([e44f931](https://github.com/cowprotocol/cow-sdk/commit/e44f931c2fc579d31f0773a79aeffd5678a9ed49))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-app-data bumped to 6.0.8
    * @cowprotocol/sdk-common bumped to 0.14.2
    * @cowprotocol/sdk-config bumped to 2.7.2
    * @cowprotocol/sdk-order-book bumped to 4.2.1
    * @cowprotocol/sdk-trading bumped to 2.7.3

## [0.12.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-trading-solana-v0.11.0...sdk-trading-solana-v0.12.0) (2026-09-28)


### ✨ Features

* **solana:** support buy sol orders ([#1032](https://github.com/cowprotocol/cow-sdk/issues/1032)) ([7627f89](https://github.com/cowprotocol/cow-sdk/commit/7627f89e531573203e6633d3cbd235d2fdf76412))
* **solana:** support order cancellation ([#1034](https://github.com/cowprotocol/cow-sdk/issues/1034)) ([842085a](https://github.com/cowprotocol/cow-sdk/commit/842085a5ef5a656b1e8b616addd33c68bc978547))

## [0.11.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-trading-solana-v0.10.0...sdk-trading-solana-v0.11.0) (2026-09-25)


### ✨ Features

* **solana:** add sponsored transactions ([#1027](https://github.com/cowprotocol/cow-sdk/issues/1027)) ([bf19e47](https://github.com/cowprotocol/cow-sdk/commit/bf19e4750951cef3db83875040b1ae32eb12c63e))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-order-book bumped to 4.2.0
    * @cowprotocol/sdk-trading bumped to 2.7.2

## [0.10.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-trading-solana-v0.9.0...sdk-trading-solana-v0.10.0) (2026-09-25)


### ✨ Features

* **solana:** add limit order builder ([#1029](https://github.com/cowprotocol/cow-sdk/issues/1029)) ([7456023](https://github.com/cowprotocol/cow-sdk/commit/74560231fabb142069e6f796798105dbc0e06df8))


### 🔧 Miscellaneous

* bump contract version ([566f50f](https://github.com/cowprotocol/cow-sdk/commit/566f50f638c7462a25b2ac743f3a65e981ffb3a9))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-app-data bumped to 6.0.7
    * @cowprotocol/sdk-common bumped to 0.14.1
    * @cowprotocol/sdk-config bumped to 2.7.1
    * @cowprotocol/sdk-order-book bumped to 4.1.1
    * @cowprotocol/sdk-trading bumped to 2.7.1

## [0.9.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-trading-solana-v0.8.0...sdk-trading-solana-v0.9.0) (2026-09-21)


### ✨ Features

* **solana:** use cow protocol quotes ([#1023](https://github.com/cowprotocol/cow-sdk/issues/1023)) ([dc76c98](https://github.com/cowprotocol/cow-sdk/commit/dc76c98475855d7d291c762c664050aa06dd12fb))


### 🔧 Miscellaneous

* update coverage badges ([#1011](https://github.com/cowprotocol/cow-sdk/issues/1011)) ([3701bb5](https://github.com/cowprotocol/cow-sdk/commit/3701bb53a4815d553757db70ebd8bba8db02f0db))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-app-data bumped to 6.0.6
    * @cowprotocol/sdk-common bumped to 0.14.0
    * @cowprotocol/sdk-order-book bumped to 4.1.0
    * @cowprotocol/sdk-trading bumped to 2.7.0

## [0.8.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-trading-solana-v0.7.0...sdk-trading-solana-v0.8.0) (2026-09-18)


### ✨ Features

* **solana:** approveCowProtocol method and docs update ([#1017](https://github.com/cowprotocol/cow-sdk/issues/1017)) ([eeb0e70](https://github.com/cowprotocol/cow-sdk/commit/eeb0e7070e7310d87c67fba5883f512b509ce83d))
* **solana:** migrate to 0.4 settlement program ([#1019](https://github.com/cowprotocol/cow-sdk/issues/1019)) ([9baf9cb](https://github.com/cowprotocol/cow-sdk/commit/9baf9cbb650434ed6b1a46ce63b9c82b0736be76))
* **solana:** override appData ([#1018](https://github.com/cowprotocol/cow-sdk/issues/1018)) ([0c2a8cf](https://github.com/cowprotocol/cow-sdk/commit/0c2a8cf967cc2f38a68135dca09a1696e0f42ba6))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-app-data bumped to 6.0.5
    * @cowprotocol/sdk-config bumped to 2.7.0
    * @cowprotocol/sdk-order-book bumped to 4.0.6
    * @cowprotocol/sdk-trading bumped to 2.6.0

## [0.7.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-trading-solana-v0.6.0...sdk-trading-solana-v0.7.0) (2026-09-18)


### ✨ Features

* sol suggested slippage echo ([#1020](https://github.com/cowprotocol/cow-sdk/issues/1020)) ([9bf45df](https://github.com/cowprotocol/cow-sdk/commit/9bf45dfdb815e180d3b0a7bde0ab3a04f3c4d70c))

## [0.6.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-trading-solana-v0.5.1...sdk-trading-solana-v0.6.0) (2026-09-16)


### ✨ Features

* add multiplier configuration for slippage ([#1016](https://github.com/cowprotocol/cow-sdk/issues/1016)) ([ccdaf18](https://github.com/cowprotocol/cow-sdk/commit/ccdaf18958d77016798d899be1ef06c6588f5bb3))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-order-book bumped to 4.0.5
    * @cowprotocol/sdk-trading bumped to 2.5.0

## [0.5.1](https://github.com/cowprotocol/cow-sdk/compare/sdk-trading-solana-v0.5.0...sdk-trading-solana-v0.5.1) (2026-09-14)


### 🔧 Miscellaneous

* update coverage badges ([#948](https://github.com/cowprotocol/cow-sdk/issues/948)) ([151d7a4](https://github.com/cowprotocol/cow-sdk/commit/151d7a4bc51194ffa7dc46a102eb2bc0e3537124))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-trading bumped to 2.4.2

## [0.5.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-trading-solana-v0.4.1...sdk-trading-solana-v0.5.0) (2026-09-09)


### ✨ Features

* **solana:** expose the CreateOrder instruction for bundling ([#999](https://github.com/cowprotocol/cow-sdk/issues/999)) ([cd19b73](https://github.com/cowprotocol/cow-sdk/commit/cd19b7366975e5def6ae2442810a8d2c8f3073ac))
* **solana:** replace sol on wsol in quiotes ([#1003](https://github.com/cowprotocol/cow-sdk/issues/1003)) ([0d588a8](https://github.com/cowprotocol/cow-sdk/commit/0d588a84bfb1fe28ec05dac7c114b1b73cd29e4c))

## [0.4.1](https://github.com/cowprotocol/cow-sdk/compare/sdk-trading-solana-v0.4.0...sdk-trading-solana-v0.4.1) (2026-09-08)


### 🐛 Bug Fixes

* **solana:** add 0x prefix to orderId ([#997](https://github.com/cowprotocol/cow-sdk/issues/997)) ([50c9ff7](https://github.com/cowprotocol/cow-sdk/commit/50c9ff7a3a0bc2513ea56fbd2cd2582bb11afdb1))

## [0.4.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-trading-solana-v0.3.0...sdk-trading-solana-v0.4.0) (2026-09-07)


### ✨ Features

* derive pda address from the seed ([#995](https://github.com/cowprotocol/cow-sdk/issues/995)) ([e7bf33f](https://github.com/cowprotocol/cow-sdk/commit/e7bf33ffdcc27ff4121573988b23443df9097e14))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-config bumped to 2.6.0
    * @cowprotocol/sdk-order-book bumped to 4.0.4
    * @cowprotocol/sdk-trading bumped to 2.4.1

## [0.3.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-trading-solana-v0.2.0...sdk-trading-solana-v0.3.0) (2026-09-04)


### ✨ Features

* trading sdk for solana ([#973](https://github.com/cowprotocol/cow-sdk/issues/973)) ([60b39b9](https://github.com/cowprotocol/cow-sdk/commit/60b39b93883889d794f02138b8dbef74f7dc6c5b))


### 🔧 Miscellaneous

* release main ([#986](https://github.com/cowprotocol/cow-sdk/issues/986)) ([1c82bfb](https://github.com/cowprotocol/cow-sdk/commit/1c82bfb80469a631de5f4e035a06511402e81c4f))

## [0.2.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-trading-solana-v0.1.0...sdk-trading-solana-v0.2.0) (2026-09-04)


### ✨ Features

* trading sdk for solana ([#973](https://github.com/cowprotocol/cow-sdk/issues/973)) ([60b39b9](https://github.com/cowprotocol/cow-sdk/commit/60b39b93883889d794f02138b8dbef74f7dc6c5b))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-config bumped to 2.5.0
    * @cowprotocol/sdk-order-book bumped to 4.0.3
    * @cowprotocol/sdk-trading bumped to 2.4.0
