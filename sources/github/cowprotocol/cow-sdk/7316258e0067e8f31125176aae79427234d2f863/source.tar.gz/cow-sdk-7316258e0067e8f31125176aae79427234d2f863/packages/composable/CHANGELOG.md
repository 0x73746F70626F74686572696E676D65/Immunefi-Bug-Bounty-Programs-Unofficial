# Changelog

## [1.8.4](https://github.com/cowprotocol/cow-sdk/compare/sdk-composable-v1.8.3...sdk-composable-v1.8.4) (2026-10-01)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-order-book bumped to 4.3.0
    * @cowprotocol/sdk-order-signing bumped to 1.1.16

## [1.8.3](https://github.com/cowprotocol/cow-sdk/compare/sdk-composable-v1.8.2...sdk-composable-v1.8.3) (2026-09-29)


### 🔧 Miscellaneous

* update coverage badges ([#1026](https://github.com/cowprotocol/cow-sdk/issues/1026)) ([e44f931](https://github.com/cowprotocol/cow-sdk/commit/e44f931c2fc579d31f0773a79aeffd5678a9ed49))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.14.2
    * @cowprotocol/sdk-config bumped to 2.7.2
    * @cowprotocol/sdk-contracts-ts bumped to 3.7.2
    * @cowprotocol/sdk-cow-shed bumped to 0.6.2
    * @cowprotocol/sdk-order-book bumped to 4.2.1
    * @cowprotocol/sdk-order-signing bumped to 1.1.15
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.4.18
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.4.18
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.33

## [1.8.2](https://github.com/cowprotocol/cow-sdk/compare/sdk-composable-v1.8.1...sdk-composable-v1.8.2) (2026-09-25)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-order-book bumped to 4.2.0
    * @cowprotocol/sdk-order-signing bumped to 1.1.14

## [1.8.1](https://github.com/cowprotocol/cow-sdk/compare/sdk-composable-v1.8.0...sdk-composable-v1.8.1) (2026-09-25)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.14.1
    * @cowprotocol/sdk-config bumped to 2.7.1
    * @cowprotocol/sdk-contracts-ts bumped to 3.7.1
    * @cowprotocol/sdk-cow-shed bumped to 0.6.1
    * @cowprotocol/sdk-order-book bumped to 4.1.1
    * @cowprotocol/sdk-order-signing bumped to 1.1.13
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.4.17
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.4.17
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.32

## [1.8.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-composable-v1.7.2...sdk-composable-v1.8.0) (2026-09-23)


### ✨ Features

* **cow-shed:** support v1.2.0 factory flow ([#1025](https://github.com/cowprotocol/cow-sdk/issues/1025)) ([9a14861](https://github.com/cowprotocol/cow-sdk/commit/9a14861d8a5b158bbda2b8a8a9b72d30c5f01466))
* return cowsheds ([#1030](https://github.com/cowprotocol/cow-sdk/issues/1030)) ([83b9374](https://github.com/cowprotocol/cow-sdk/commit/83b9374b146d421bbbb4b143c4599b2da4d113a4))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-cow-shed bumped to 0.6.0

## [1.7.2](https://github.com/cowprotocol/cow-sdk/compare/sdk-composable-v1.7.1...sdk-composable-v1.7.2) (2026-09-21)


### 🔧 Miscellaneous

* update coverage badges ([#1011](https://github.com/cowprotocol/cow-sdk/issues/1011)) ([3701bb5](https://github.com/cowprotocol/cow-sdk/commit/3701bb53a4815d553757db70ebd8bba8db02f0db))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.14.0
    * @cowprotocol/sdk-contracts-ts bumped to 3.7.0
    * @cowprotocol/sdk-cow-shed bumped to 0.5.2
    * @cowprotocol/sdk-order-book bumped to 4.1.0
    * @cowprotocol/sdk-order-signing bumped to 1.1.12
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.4.16
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.4.16
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.31

## [1.7.1](https://github.com/cowprotocol/cow-sdk/compare/sdk-composable-v1.7.0...sdk-composable-v1.7.1) (2026-09-18)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.13.1
    * @cowprotocol/sdk-config bumped to 2.7.0
    * @cowprotocol/sdk-contracts-ts bumped to 3.6.0
    * @cowprotocol/sdk-cow-shed bumped to 0.5.1
    * @cowprotocol/sdk-order-book bumped to 4.0.6
    * @cowprotocol/sdk-order-signing bumped to 1.1.11
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.4.15
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.4.15
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.30

## [1.7.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-composable-v1.6.1...sdk-composable-v1.7.0) (2026-09-16)


### ✨ Features

* **composable:** add direct JIT Poller helpers ([#958](https://github.com/cowprotocol/cow-sdk/issues/958)) ([2d934d6](https://github.com/cowprotocol/cow-sdk/commit/2d934d68df527c332e4a7d6a7869a9998b112b28))
* **composable:** add Poller registration from CowShed ([#1006](https://github.com/cowprotocol/cow-sdk/issues/1006)) ([5321553](https://github.com/cowprotocol/cow-sdk/commit/532155337b2d6d7a58313f3f60446bfd255aeaf4))
* **composable:** add Poller revocation from CowShed ([#1007](https://github.com/cowprotocol/cow-sdk/issues/1007)) ([6241bf9](https://github.com/cowprotocol/cow-sdk/commit/6241bf9e787cfed240d024a9285f9776122acf5c))
* **composable:** add signed Poller registration ([#959](https://github.com/cowprotocol/cow-sdk/issues/959)) ([ec4be35](https://github.com/cowprotocol/cow-sdk/commit/ec4be353837993405ac7ff5a71831c7da978064e))
* **composable:** add signed Poller revocation ([#960](https://github.com/cowprotocol/cow-sdk/issues/960)) ([ea2ffdb](https://github.com/cowprotocol/cow-sdk/commit/ea2ffdb067ca035bb8a3551e8ffa50c2e921d302))
* **composable:** add signer-aware Poller SDK ([#966](https://github.com/cowprotocol/cow-sdk/issues/966)) ([65d0eac](https://github.com/cowprotocol/cow-sdk/commit/65d0eac03cc21c0e0e55ec75a50ae49934a80272))
* **cow-shed:** support custom deployment domains ([#990](https://github.com/cowprotocol/cow-sdk/issues/990)) ([8ffa557](https://github.com/cowprotocol/cow-sdk/commit/8ffa557b888079d390f7388eb8575b0ca0d42330))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.13.0
    * @cowprotocol/sdk-contracts-ts bumped to 3.5.2
    * @cowprotocol/sdk-cow-shed bumped to 0.5.0
    * @cowprotocol/sdk-order-book bumped to 4.0.5
    * @cowprotocol/sdk-order-signing bumped to 1.1.10
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.4.14
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.4.14
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.29

## [1.6.1](https://github.com/cowprotocol/cow-sdk/compare/sdk-composable-v1.6.0...sdk-composable-v1.6.1) (2026-09-15)


### 🐛 Bug Fixes

* use executedFee instead of the deprecated executedFeeAmount ([#1012](https://github.com/cowprotocol/cow-sdk/issues/1012)) ([1ae7a49](https://github.com/cowprotocol/cow-sdk/commit/1ae7a49bb088e4231d913e919e3d09bcdf0a2272))

## [1.6.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-composable-v1.5.0...sdk-composable-v1.6.0) (2026-09-14)


### ✨ Features

* more twap retrieval methods ([#1008](https://github.com/cowprotocol/cow-sdk/issues/1008)) ([4bfaef6](https://github.com/cowprotocol/cow-sdk/commit/4bfaef6cd609d087dbd47fbee15ca17094fd4f9d))


### 🔧 Miscellaneous

* update coverage badges ([#948](https://github.com/cowprotocol/cow-sdk/issues/948)) ([151d7a4](https://github.com/cowprotocol/cow-sdk/commit/151d7a4bc51194ffa7dc46a102eb2bc0e3537124))

## [1.5.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-composable-v1.4.2...sdk-composable-v1.5.0) (2026-09-09)


### ✨ Features

* allow fetching twap deltas ([#996](https://github.com/cowprotocol/cow-sdk/issues/996)) ([46cf8b6](https://github.com/cowprotocol/cow-sdk/commit/46cf8b68bb7fd6189ae7cfbcd02df44330e88352))
* include scheduled parts ([#1002](https://github.com/cowprotocol/cow-sdk/issues/1002)) ([9fdd914](https://github.com/cowprotocol/cow-sdk/commit/9fdd91494ddfee381e710e587f9e33537bddc7c3))

## [1.4.2](https://github.com/cowprotocol/cow-sdk/compare/sdk-composable-v1.4.1...sdk-composable-v1.4.2) (2026-09-07)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.12.3
    * @cowprotocol/sdk-config bumped to 2.6.0
    * @cowprotocol/sdk-contracts-ts bumped to 3.5.1
    * @cowprotocol/sdk-order-book bumped to 4.0.4
    * @cowprotocol/sdk-order-signing bumped to 1.1.9
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.4.13
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.4.13
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.28

## [1.4.1](https://github.com/cowprotocol/cow-sdk/compare/sdk-composable-v1.4.0...sdk-composable-v1.4.1) (2026-09-04)


### 🔧 Miscellaneous

* split integration tests ([#978](https://github.com/cowprotocol/cow-sdk/issues/978)) ([72bbc6f](https://github.com/cowprotocol/cow-sdk/commit/72bbc6f8f88ce66597f36cd08d391ab79e342843))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.12.2
    * @cowprotocol/sdk-config bumped to 2.5.0
    * @cowprotocol/sdk-contracts-ts bumped to 3.5.0
    * @cowprotocol/sdk-order-book bumped to 4.0.3
    * @cowprotocol/sdk-order-signing bumped to 1.1.8
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.4.12
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.4.12
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.27

## [1.4.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-composable-v1.3.0...sdk-composable-v1.4.0) (2026-09-01)


### ✨ Features

* **composable:** export JIT Poller ABI ([#957](https://github.com/cowprotocol/cow-sdk/issues/957)) ([5f8a863](https://github.com/cowprotocol/cow-sdk/commit/5f8a8632c70a353afe0a9856c1eace1909a9c3da))
* use internal indexer ([#974](https://github.com/cowprotocol/cow-sdk/issues/974)) ([455e44b](https://github.com/cowprotocol/cow-sdk/commit/455e44b5532bc197e66f8b81828bf7fc6608b0d2))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-contracts-ts bumped to 3.4.0
    * @cowprotocol/sdk-order-signing bumped to 1.1.7

## [1.3.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-composable-v1.2.3...sdk-composable-v1.3.0) (2026-08-03)


### ✨ Features

* add new getTwapOrders method ([#928](https://github.com/cowprotocol/cow-sdk/issues/928)) ([494e35f](https://github.com/cowprotocol/cow-sdk/commit/494e35f50ed937db36802aefdb55e24179799580))

## [1.2.3](https://github.com/cowprotocol/cow-sdk/compare/sdk-composable-v1.2.2...sdk-composable-v1.2.3) (2026-07-29)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.12.1
    * @cowprotocol/sdk-config bumped to 2.4.0
    * @cowprotocol/sdk-contracts-ts bumped to 3.3.3
    * @cowprotocol/sdk-order-book bumped to 4.0.2
    * @cowprotocol/sdk-order-signing bumped to 1.1.6
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.4.11
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.4.11
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.26

## [1.2.2](https://github.com/cowprotocol/cow-sdk/compare/sdk-composable-v1.2.1...sdk-composable-v1.2.2) (2026-07-28)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-contracts-ts bumped to 3.3.2
    * @cowprotocol/sdk-order-signing bumped to 1.1.5

## [1.2.1](https://github.com/cowprotocol/cow-sdk/compare/sdk-composable-v1.2.0...sdk-composable-v1.2.1) (2026-07-22)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-contracts-ts bumped to 3.3.1
    * @cowprotocol/sdk-order-signing bumped to 1.1.4

## [1.2.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-composable-v1.1.2...sdk-composable-v1.2.0) (2026-07-22)


### ✨ Features

* **bridge:** support CCTP v2 in Bungee ([#933](https://github.com/cowprotocol/cow-sdk/issues/933)) ([fcb0d26](https://github.com/cowprotocol/cow-sdk/commit/fcb0d2630b93d826474245a7fdf26fb8bccf6d34))


### 🐛 Bug Fixes

* fix typescript errors ([#937](https://github.com/cowprotocol/cow-sdk/issues/937)) ([b00e6ed](https://github.com/cowprotocol/cow-sdk/commit/b00e6ed8d380cc0e665e6e47ecf0ca2c635748a6))


### 🧪 Tests

* **composable:** reach full unit test coverage ([#920](https://github.com/cowprotocol/cow-sdk/issues/920)) ([68d9b7c](https://github.com/cowprotocol/cow-sdk/commit/68d9b7c67573ab311d7f315c6754bb11f4a74642))


### 🔧 Miscellaneous

* update coverage badges ([#935](https://github.com/cowprotocol/cow-sdk/issues/935)) ([db7f12d](https://github.com/cowprotocol/cow-sdk/commit/db7f12d0471aa28c602c9371a6fee17face8f01c))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-contracts-ts bumped to 3.3.0
    * @cowprotocol/sdk-order-signing bumped to 1.1.3
  * devDependencies
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.25

## [1.1.2](https://github.com/cowprotocol/cow-sdk/compare/sdk-composable-v1.1.1...sdk-composable-v1.1.2) (2026-06-23)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-contracts-ts bumped to 3.2.1
    * @cowprotocol/sdk-order-signing bumped to 1.1.2

## [1.1.1](https://github.com/cowprotocol/cow-sdk/compare/sdk-composable-v1.1.0...sdk-composable-v1.1.1) (2026-06-17)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-order-book bumped to 4.0.1
    * @cowprotocol/sdk-order-signing bumped to 1.1.1

## [1.1.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-composable-v1.0.6...sdk-composable-v1.1.0) (2026-06-15)


### ✨ Features

* per-package test coverage badges, updated in CI ([#895](https://github.com/cowprotocol/cow-sdk/issues/895)) ([c73246c](https://github.com/cowprotocol/cow-sdk/commit/c73246cc52c4fc79b2628b7c5f580695fd3dc1e2))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.12.0
    * @cowprotocol/sdk-config bumped to 2.3.1
    * @cowprotocol/sdk-contracts-ts bumped to 3.2.0
    * @cowprotocol/sdk-order-book bumped to 4.0.0
    * @cowprotocol/sdk-order-signing bumped to 1.1.0
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.4.10
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.4.10
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.24

## [1.0.6](https://github.com/cowprotocol/cow-sdk/compare/sdk-composable-v1.0.5...sdk-composable-v1.0.6) (2026-06-08)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.11.2
    * @cowprotocol/sdk-config bumped to 2.3.0
    * @cowprotocol/sdk-contracts-ts bumped to 3.1.2
    * @cowprotocol/sdk-order-book bumped to 3.2.2
    * @cowprotocol/sdk-order-signing bumped to 1.0.6
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.4.9
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.4.9
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.23

## [1.0.5](https://github.com/cowprotocol/cow-sdk/compare/sdk-composable-v1.0.4...sdk-composable-v1.0.5) (2026-06-02)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.11.1
    * @cowprotocol/sdk-config bumped to 2.2.1
    * @cowprotocol/sdk-contracts-ts bumped to 3.1.1
    * @cowprotocol/sdk-order-book bumped to 3.2.1
    * @cowprotocol/sdk-order-signing bumped to 1.0.5
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.4.8
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.4.8
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.22

## [1.0.4](https://github.com/cowprotocol/cow-sdk/compare/sdk-composable-v1.0.3...sdk-composable-v1.0.4) (2026-05-27)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.11.0
    * @cowprotocol/sdk-config bumped to 2.2.0
    * @cowprotocol/sdk-contracts-ts bumped to 3.1.0
    * @cowprotocol/sdk-order-book bumped to 3.2.0
    * @cowprotocol/sdk-order-signing bumped to 1.0.4
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.4.7
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.4.7
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.21

## [1.0.3](https://github.com/cowprotocol/cow-sdk/compare/sdk-composable-v1.0.2...sdk-composable-v1.0.3) (2026-05-22)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.10.3
    * @cowprotocol/sdk-config bumped to 2.1.0
    * @cowprotocol/sdk-contracts-ts bumped to 3.0.3
    * @cowprotocol/sdk-order-book bumped to 3.1.0
    * @cowprotocol/sdk-order-signing bumped to 1.0.3
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.4.6
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.4.6
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.20

## [1.0.2](https://github.com/cowprotocol/cow-sdk/compare/sdk-composable-v1.0.1...sdk-composable-v1.0.2) (2026-05-20)


### 📚 Documentation

* remove info about umbrella sdk ([#874](https://github.com/cowprotocol/cow-sdk/issues/874)) ([bb0280e](https://github.com/cowprotocol/cow-sdk/commit/bb0280e7bfcdd6c2d7b122baf43910d9e4e4299f))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-contracts-ts bumped to 3.0.2
    * @cowprotocol/sdk-order-signing bumped to 1.0.2
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.4.5
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.4.5
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.19

## [1.0.1](https://github.com/cowprotocol/cow-sdk/compare/sdk-composable-v1.0.0...sdk-composable-v1.0.1) (2026-04-20)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-contracts-ts bumped to 3.0.1
    * @cowprotocol/sdk-order-signing bumped to 1.0.1

## [1.0.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-composable-v0.3.0...sdk-composable-v1.0.0) (2026-04-16)


### ⚠ BREAKING CHANGES

* bring cow.fi back ([#863](https://github.com/cowprotocol/cow-sdk/issues/863))

### ✨ Features

* bring cow.fi back ([#863](https://github.com/cowprotocol/cow-sdk/issues/863)) ([d607fd2](https://github.com/cowprotocol/cow-sdk/commit/d607fd2cfbc93ace39de04f3a7870f723fdd9b21))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.10.2
    * @cowprotocol/sdk-config bumped to 2.0.0
    * @cowprotocol/sdk-contracts-ts bumped to 3.0.0
    * @cowprotocol/sdk-order-book bumped to 3.0.0
    * @cowprotocol/sdk-order-signing bumped to 1.0.0
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.4.4
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.4.4
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.18

## [0.3.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-composable-v0.2.5...sdk-composable-v0.3.0) (2026-04-14)


### ✨ Features

* migrate to cow.finance domain ([#860](https://github.com/cowprotocol/cow-sdk/issues/860)) ([a4e7633](https://github.com/cowprotocol/cow-sdk/commit/a4e76333b7a276baec5c977f44b15498550d8e50))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.10.1
    * @cowprotocol/sdk-config bumped to 1.2.0
    * @cowprotocol/sdk-contracts-ts bumped to 2.5.0
    * @cowprotocol/sdk-order-book bumped to 2.1.0
    * @cowprotocol/sdk-order-signing bumped to 0.3.0
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.4.3
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.4.3
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.17

## [0.2.5](https://github.com/cowprotocol/cow-sdk/compare/sdk-composable-v0.2.4...sdk-composable-v0.2.5) (2026-04-08)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.10.0
    * @cowprotocol/sdk-config bumped to 1.1.3
    * @cowprotocol/sdk-contracts-ts bumped to 2.4.0
    * @cowprotocol/sdk-order-book bumped to 2.0.5
    * @cowprotocol/sdk-order-signing bumped to 0.2.5
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.4.2
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.4.2
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.16

## [0.2.4](https://github.com/cowprotocol/cow-sdk/compare/sdk-composable-v0.2.3...sdk-composable-v0.2.4) (2026-04-01)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.9.0
    * @cowprotocol/sdk-contracts-ts bumped to 2.3.0
    * @cowprotocol/sdk-order-book bumped to 2.0.4
    * @cowprotocol/sdk-order-signing bumped to 0.2.4
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.4.1
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.4.1
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.15

## [0.2.3](https://github.com/cowprotocol/cow-sdk/compare/sdk-composable-v0.2.2...sdk-composable-v0.2.3) (2026-03-17)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-contracts-ts bumped to 2.2.0
    * @cowprotocol/sdk-order-signing bumped to 0.2.3
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.4.0
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.4.0

## [0.2.2](https://github.com/cowprotocol/cow-sdk/compare/sdk-composable-v0.2.1...sdk-composable-v0.2.2) (2026-03-17)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.8.2
    * @cowprotocol/sdk-config bumped to 1.1.2
    * @cowprotocol/sdk-contracts-ts bumped to 2.1.2
    * @cowprotocol/sdk-order-book bumped to 2.0.3
    * @cowprotocol/sdk-order-signing bumped to 0.2.2
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.3.14
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.3.14
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.14

## [0.2.1](https://github.com/cowprotocol/cow-sdk/compare/sdk-composable-v0.2.0...sdk-composable-v0.2.1) (2026-03-16)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.8.1
    * @cowprotocol/sdk-config bumped to 1.1.1
    * @cowprotocol/sdk-contracts-ts bumped to 2.1.1
    * @cowprotocol/sdk-order-book bumped to 2.0.2
    * @cowprotocol/sdk-order-signing bumped to 0.2.1
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.3.13
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.3.13
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.13

## [0.2.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-composable-v0.1.38...sdk-composable-v0.2.0) (2026-03-16)


### ✨ Features

* update settlement and vault relayer contracts on staging ([#807](https://github.com/cowprotocol/cow-sdk/issues/807)) ([0f9a03e](https://github.com/cowprotocol/cow-sdk/commit/0f9a03e6bfa3468630e46735f7583618ae711b73))


### 🔧 Miscellaneous

* release main ([#826](https://github.com/cowprotocol/cow-sdk/issues/826)) ([baaa708](https://github.com/cowprotocol/cow-sdk/commit/baaa7088ac15b89fb83310e54aa52f09d19132ff))
* release main ([#832](https://github.com/cowprotocol/cow-sdk/issues/832)) ([5dafcb8](https://github.com/cowprotocol/cow-sdk/commit/5dafcb8ec5593250dba1ff6e9fdbf8eb11d974cf))
* revert release ([#833](https://github.com/cowprotocol/cow-sdk/issues/833)) ([0c40a9b](https://github.com/cowprotocol/cow-sdk/commit/0c40a9b3ee828c7ede66576f02e1b571e96140cd))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.8.0
    * @cowprotocol/sdk-config bumped to 1.1.0
    * @cowprotocol/sdk-contracts-ts bumped to 2.1.0
    * @cowprotocol/sdk-order-book bumped to 2.0.1
    * @cowprotocol/sdk-order-signing bumped to 0.2.0
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.3.12
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.3.12
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.12

## [0.1.38](https://github.com/cowprotocol/cow-sdk/compare/sdk-composable-v0.1.37...sdk-composable-v0.1.38) (2026-03-10)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.7.1
    * @cowprotocol/sdk-config bumped to 1.0.0
    * @cowprotocol/sdk-contracts-ts bumped to 2.0.0
    * @cowprotocol/sdk-order-book bumped to 2.0.0
    * @cowprotocol/sdk-order-signing bumped to 0.1.38
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.3.11
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.3.11
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.11

## [0.1.37](https://github.com/cowprotocol/cow-sdk/compare/sdk-composable-v0.1.36...sdk-composable-v0.1.37) (2026-03-10)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-order-book bumped to 1.1.2
    * @cowprotocol/sdk-order-signing bumped to 0.1.37

## [0.1.36](https://github.com/cowprotocol/cow-sdk/compare/sdk-composable-v0.1.35...sdk-composable-v0.1.36) (2026-03-04)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.7.0
    * @cowprotocol/sdk-config bumped to 0.10.0
    * @cowprotocol/sdk-contracts-ts bumped to 1.8.0
    * @cowprotocol/sdk-order-book bumped to 1.1.1
    * @cowprotocol/sdk-order-signing bumped to 0.1.36
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.3.10
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.3.10
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.10

## [0.1.35](https://github.com/cowprotocol/cow-sdk/compare/sdk-composable-v0.1.34...sdk-composable-v0.1.35) (2026-03-04)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.6.3
    * @cowprotocol/sdk-config bumped to 0.9.0
    * @cowprotocol/sdk-contracts-ts bumped to 1.7.0
    * @cowprotocol/sdk-order-book bumped to 1.1.0
    * @cowprotocol/sdk-order-signing bumped to 0.1.35
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.3.9
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.3.9
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.9

## [0.1.34](https://github.com/cowprotocol/cow-sdk/compare/sdk-composable-v0.1.33...sdk-composable-v0.1.34) (2026-02-26)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-order-book bumped to 1.0.0
    * @cowprotocol/sdk-order-signing bumped to 0.1.34

## [0.1.33](https://github.com/cowprotocol/cow-sdk/compare/sdk-composable-v0.1.32...sdk-composable-v0.1.33) (2026-02-20)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.6.2
    * @cowprotocol/sdk-config bumped to 0.8.1
    * @cowprotocol/sdk-contracts-ts bumped to 1.6.1
    * @cowprotocol/sdk-order-book bumped to 0.6.6
    * @cowprotocol/sdk-order-signing bumped to 0.1.33
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.3.8
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.3.8
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.8

## [0.1.32](https://github.com/cowprotocol/cow-sdk/compare/sdk-composable-v0.1.31...sdk-composable-v0.1.32) (2026-02-18)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.6.1
    * @cowprotocol/sdk-config bumped to 0.8.0
    * @cowprotocol/sdk-contracts-ts bumped to 1.6.0
    * @cowprotocol/sdk-order-book bumped to 0.6.5
    * @cowprotocol/sdk-order-signing bumped to 0.1.32
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.3.7
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.3.7
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.7

## [0.1.31](https://github.com/cowprotocol/cow-sdk/compare/sdk-composable-v0.1.30...sdk-composable-v0.1.31) (2026-02-05)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.6.0
    * @cowprotocol/sdk-contracts-ts bumped to 1.5.0
    * @cowprotocol/sdk-order-book bumped to 0.6.4
    * @cowprotocol/sdk-order-signing bumped to 0.1.31
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.3.6
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.3.6
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.6

## [0.1.30](https://github.com/cowprotocol/cow-sdk/compare/sdk-composable-v0.1.29...sdk-composable-v0.1.30) (2026-02-02)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.5.4
    * @cowprotocol/sdk-config bumped to 0.7.3
    * @cowprotocol/sdk-contracts-ts bumped to 1.4.2
    * @cowprotocol/sdk-order-book bumped to 0.6.3
    * @cowprotocol/sdk-order-signing bumped to 0.1.30
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.3.5
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.3.5
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.5

## [0.1.29](https://github.com/cowprotocol/cow-sdk/compare/sdk-composable-v0.1.28...sdk-composable-v0.1.29) (2026-02-02)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.5.3
    * @cowprotocol/sdk-config bumped to 0.7.2
    * @cowprotocol/sdk-contracts-ts bumped to 1.4.1
    * @cowprotocol/sdk-order-book bumped to 0.6.2
    * @cowprotocol/sdk-order-signing bumped to 0.1.29
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.3.4
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.3.4
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.4

## [0.1.28](https://github.com/cowprotocol/cow-sdk/compare/sdk-composable-v0.1.27...sdk-composable-v0.1.28) (2026-01-28)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.5.2
    * @cowprotocol/sdk-config bumped to 0.7.1
    * @cowprotocol/sdk-contracts-ts bumped to 1.4.0
    * @cowprotocol/sdk-order-book bumped to 0.6.1
    * @cowprotocol/sdk-order-signing bumped to 0.1.28
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.3.3
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.3.3
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.3

## [0.1.27](https://github.com/cowprotocol/cow-sdk/compare/sdk-composable-v0.1.26...sdk-composable-v0.1.27) (2026-01-28)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.5.1
    * @cowprotocol/sdk-config bumped to 0.7.0
    * @cowprotocol/sdk-contracts-ts bumped to 1.3.0
    * @cowprotocol/sdk-order-book bumped to 0.6.0
    * @cowprotocol/sdk-order-signing bumped to 0.1.27
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.3.2
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.3.2
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.2

## [0.1.26](https://github.com/cowprotocol/cow-sdk/compare/sdk-composable-v0.1.25...sdk-composable-v0.1.26) (2026-01-22)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-contracts-ts bumped to 1.2.0
    * @cowprotocol/sdk-order-signing bumped to 0.1.26

## [0.1.25](https://github.com/cowprotocol/cow-sdk/compare/sdk-composable-v0.1.24...sdk-composable-v0.1.25) (2026-01-21)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-contracts-ts bumped to 1.1.1
    * @cowprotocol/sdk-order-signing bumped to 0.1.25

## [0.1.24](https://github.com/cowprotocol/cow-sdk/compare/sdk-composable-v0.1.23...sdk-composable-v0.1.24) (2026-01-19)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.5.0
    * @cowprotocol/sdk-config bumped to 0.6.3
    * @cowprotocol/sdk-contracts-ts bumped to 1.1.0
    * @cowprotocol/sdk-order-book bumped to 0.5.1
    * @cowprotocol/sdk-order-signing bumped to 0.1.24
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.3.1
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.3.1
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.1

## [0.1.23](https://github.com/cowprotocol/cow-sdk/compare/sdk-composable-v0.1.22...sdk-composable-v0.1.23) (2025-12-22)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-order-book bumped to 0.5.0
    * @cowprotocol/sdk-order-signing bumped to 0.1.23

## [0.1.22](https://github.com/cowprotocol/cow-sdk/compare/sdk-composable-v0.1.21...sdk-composable-v0.1.22) (2025-12-19)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-contracts-ts bumped to 1.0.0
    * @cowprotocol/sdk-order-signing bumped to 0.1.22

## [0.1.21](https://github.com/cowprotocol/cow-sdk/compare/sdk-composable-v0.1.20...sdk-composable-v0.1.21) (2025-12-11)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-config bumped to 0.6.2
    * @cowprotocol/sdk-contracts-ts bumped to 0.8.1
    * @cowprotocol/sdk-order-book bumped to 0.4.4
    * @cowprotocol/sdk-order-signing bumped to 0.1.21

## [0.1.20](https://github.com/cowprotocol/cow-sdk/compare/sdk-composable-v0.1.19...sdk-composable-v0.1.20) (2025-12-10)


### 🔧 Miscellaneous

* release main ([#741](https://github.com/cowprotocol/cow-sdk/issues/741)) ([32fb8bb](https://github.com/cowprotocol/cow-sdk/commit/32fb8bbe6b1172c2666f330d0d50cdc2f7c2554f))
* revert not published release ([5facf05](https://github.com/cowprotocol/cow-sdk/commit/5facf05c67121404b7b5aa1e77950961b06eca81))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-contracts-ts bumped to 0.8.0
    * @cowprotocol/sdk-order-signing bumped to 0.1.20

## [0.1.19](https://github.com/cowprotocol/cow-sdk/compare/sdk-composable-v0.1.18...sdk-composable-v0.1.19) (2025-12-05)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-config bumped to 0.6.1
    * @cowprotocol/sdk-contracts-ts bumped to 0.7.4
    * @cowprotocol/sdk-order-book bumped to 0.4.3
    * @cowprotocol/sdk-order-signing bumped to 0.1.19

## [0.1.18](https://github.com/cowprotocol/cow-sdk/compare/sdk-composable-v0.1.17...sdk-composable-v0.1.18) (2025-12-04)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-config bumped to 0.6.0
    * @cowprotocol/sdk-contracts-ts bumped to 0.7.3
    * @cowprotocol/sdk-order-book bumped to 0.4.2
    * @cowprotocol/sdk-order-signing bumped to 0.1.18

## [0.1.17](https://github.com/cowprotocol/cow-sdk/compare/sdk-composable-v0.1.16...sdk-composable-v0.1.17) (2025-12-03)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-config bumped to 0.5.0
    * @cowprotocol/sdk-contracts-ts bumped to 0.7.2
    * @cowprotocol/sdk-order-book bumped to 0.4.1
    * @cowprotocol/sdk-order-signing bumped to 0.1.17

## [0.1.16](https://github.com/cowprotocol/cow-sdk/compare/sdk-composable-v0.1.15...sdk-composable-v0.1.16) (2025-12-01)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-order-book bumped to 0.4.0
    * @cowprotocol/sdk-order-signing bumped to 0.1.16

## [0.1.15](https://github.com/cowprotocol/cow-sdk/compare/sdk-composable-v0.1.14...sdk-composable-v0.1.15) (2025-11-27)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-order-book bumped to 0.3.2
    * @cowprotocol/sdk-order-signing bumped to 0.1.15

## [0.1.14](https://github.com/cowprotocol/cow-sdk/compare/sdk-composable-v0.1.13...sdk-composable-v0.1.14) (2025-11-27)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-config bumped to 0.4.1
    * @cowprotocol/sdk-contracts-ts bumped to 0.7.1
    * @cowprotocol/sdk-order-book bumped to 0.3.1
    * @cowprotocol/sdk-order-signing bumped to 0.1.14

## [0.1.13](https://github.com/cowprotocol/cow-sdk/compare/sdk-composable-v0.1.12...sdk-composable-v0.1.13) (2025-11-24)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-contracts-ts bumped to 0.7.0
    * @cowprotocol/sdk-order-signing bumped to 0.1.13

## [0.1.12](https://github.com/cowprotocol/cow-sdk/compare/sdk-composable-v0.1.11...sdk-composable-v0.1.12) (2025-11-24)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.4.0
    * @cowprotocol/sdk-config bumped to 0.4.0
    * @cowprotocol/sdk-contracts-ts bumped to 0.6.0
    * @cowprotocol/sdk-order-book bumped to 0.3.0
    * @cowprotocol/sdk-order-signing bumped to 0.1.12
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.3.0
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.3.0
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.0

## [0.1.11](https://github.com/cowprotocol/cow-sdk/compare/sdk-composable-v0.1.10...sdk-composable-v0.1.11) (2025-11-07)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-contracts-ts bumped to 0.5.0
    * @cowprotocol/sdk-order-signing bumped to 0.1.11

## [0.1.10](https://github.com/cowprotocol/cow-sdk/compare/sdk-composable-v0.1.9...sdk-composable-v0.1.10) (2025-11-05)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-config bumped to 0.3.0
    * @cowprotocol/sdk-contracts-ts bumped to 0.4.4
    * @cowprotocol/sdk-order-book bumped to 0.2.0
    * @cowprotocol/sdk-order-signing bumped to 0.1.10

## [0.1.9](https://github.com/cowprotocol/cow-sdk/compare/sdk-composable-v0.1.8...sdk-composable-v0.1.9) (2025-10-30)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-contracts-ts bumped to 0.4.3
    * @cowprotocol/sdk-order-signing bumped to 0.1.9

## [0.1.8](https://github.com/cowprotocol/cow-sdk/compare/sdk-composable-v0.1.7...sdk-composable-v0.1.8) (2025-10-29)


### 🔧 Miscellaneous

* release main ([#620](https://github.com/cowprotocol/cow-sdk/issues/620)) ([b36394a](https://github.com/cowprotocol/cow-sdk/commit/b36394a2ba38957edb47ffc4451ea6624d66737b))
* revert release ([#634](https://github.com/cowprotocol/cow-sdk/issues/634)) ([fc7bf61](https://github.com/cowprotocol/cow-sdk/commit/fc7bf61444619d4b2c3a3dd55b7ce52c197b1878))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.3.0
    * @cowprotocol/sdk-contracts-ts bumped to 0.4.2
    * @cowprotocol/sdk-order-book bumped to 0.1.4
    * @cowprotocol/sdk-order-signing bumped to 0.1.8
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.2.0
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.2.0
    * @cowprotocol/sdk-viem-adapter bumped to 0.2.0

## [0.1.7](https://github.com/cowprotocol/cow-sdk/compare/sdk-composable-v0.1.6...sdk-composable-v0.1.7) (2025-10-24)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.2.2
    * @cowprotocol/sdk-config bumped to 0.2.0
    * @cowprotocol/sdk-contracts-ts bumped to 0.4.1
    * @cowprotocol/sdk-order-book bumped to 0.1.3
    * @cowprotocol/sdk-order-signing bumped to 0.1.7
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.1.3
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.1.3
    * @cowprotocol/sdk-viem-adapter bumped to 0.1.3

## [0.1.6](https://github.com/cowprotocol/cow-sdk/compare/sdk-composable-v0.1.5...sdk-composable-v0.1.6) (2025-10-15)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-contracts-ts bumped to 0.4.0
    * @cowprotocol/sdk-order-signing bumped to 0.1.6

## [0.1.5](https://github.com/cowprotocol/cow-sdk/compare/sdk-composable-v0.1.4...sdk-composable-v0.1.5) (2025-10-08)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.2.1
    * @cowprotocol/sdk-contracts-ts bumped to 0.3.1
    * @cowprotocol/sdk-order-book bumped to 0.1.2
    * @cowprotocol/sdk-order-signing bumped to 0.1.5
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.1.2
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.1.2
    * @cowprotocol/sdk-viem-adapter bumped to 0.1.2

## [0.1.4](https://github.com/cowprotocol/cow-sdk/compare/sdk-composable-v0.1.3...sdk-composable-v0.1.4) (2025-10-06)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.2.0
    * @cowprotocol/sdk-contracts-ts bumped to 0.3.0
    * @cowprotocol/sdk-order-book bumped to 0.1.1
    * @cowprotocol/sdk-order-signing bumped to 0.1.4
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.1.1
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.1.1
    * @cowprotocol/sdk-viem-adapter bumped to 0.1.1

## [0.1.3](https://github.com/cowprotocol/cow-sdk/compare/sdk-composable-v0.1.2...sdk-composable-v0.1.3) (2025-09-24)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-contracts-ts bumped to 0.2.1
    * @cowprotocol/sdk-order-signing bumped to 0.1.3

## [0.1.2](https://github.com/cowprotocol/cow-sdk/compare/sdk-composable-v0.1.1...sdk-composable-v0.1.2) (2025-09-23)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-contracts-ts bumped to 0.2.0
    * @cowprotocol/sdk-order-signing bumped to 0.1.2

## [0.1.1](https://github.com/cowprotocol/cow-sdk/compare/sdk-composable-v0.1.0...sdk-composable-v0.1.1) (2025-09-22)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-contracts-ts bumped to 0.1.1
    * @cowprotocol/sdk-order-signing bumped to 0.1.1

## [0.1.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-composable-v0.2.9-beta.0...sdk-composable-v0.1.0) (2025-09-17)


### ⚠ BREAKING CHANGES

* release cow-sdk v7

### ✨ Features

* release cow-sdk v7 ([6cd3e57](https://github.com/cowprotocol/cow-sdk/commit/6cd3e573687b1ffdbc0fdcb8cdbb414d88546e38))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.1.0
    * @cowprotocol/sdk-config bumped to 0.1.0
    * @cowprotocol/sdk-contracts-ts bumped to 0.1.0
    * @cowprotocol/sdk-order-book bumped to 0.1.0
    * @cowprotocol/sdk-order-signing bumped to 0.1.0
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.1.0
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.1.0
    * @cowprotocol/sdk-viem-adapter bumped to 0.1.0

## [0.2.9-beta.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-composable-v0.2.8-beta.0...sdk-composable-v0.2.9-beta.0) (2025-09-17)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.5.0-beta.0
    * @cowprotocol/sdk-contracts-ts bumped to 2.3.0-beta.0
    * @cowprotocol/sdk-order-book bumped to 0.3.1-beta.0
    * @cowprotocol/sdk-order-signing bumped to 0.2.8-beta.0
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.2.5-beta.0
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.2.5-beta.0
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.1-beta.0

## [0.2.8-beta.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-composable-v0.2.7-beta.0...sdk-composable-v0.2.8-beta.0) (2025-09-16)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-contracts-ts bumped to 2.2.1-beta.0
    * @cowprotocol/sdk-order-signing bumped to 0.2.7-beta.0
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.2.4-beta.0
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.2.4-beta.0

## [0.2.7-beta.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-composable-v0.2.6-beta.0...sdk-composable-v0.2.7-beta.0) (2025-09-16)


### 📚 Documentation

* update README to focus on main use cases ([#493](https://github.com/cowprotocol/cow-sdk/issues/493)) ([a05cb1b](https://github.com/cowprotocol/cow-sdk/commit/a05cb1ba11b5f9895d7cfe6262cf74c4089fd73c))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.4.0-beta.0
    * @cowprotocol/sdk-config bumped to 0.3.3-beta.0
    * @cowprotocol/sdk-contracts-ts bumped to 2.2.0-beta.0
    * @cowprotocol/sdk-order-book bumped to 0.3.0-beta.0
    * @cowprotocol/sdk-order-signing bumped to 0.2.6-beta.0
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.2.3-beta.0
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.2.3-beta.0
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.0-beta.0

## [0.2.6-beta.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-composable-v0.2.5-beta.0...sdk-composable-v0.2.6-beta.0) (2025-09-15)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-config bumped to 0.3.2-beta.0
    * @cowprotocol/sdk-contracts-ts bumped to 2.1.7-beta.0
    * @cowprotocol/sdk-order-book bumped to 0.2.4-beta.0
    * @cowprotocol/sdk-order-signing bumped to 0.2.5-beta.0

## [0.2.5-beta.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-composable-v0.2.4-beta.0...sdk-composable-v0.2.5-beta.0) (2025-09-15)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-config bumped to 0.3.1-beta.0
    * @cowprotocol/sdk-contracts-ts bumped to 2.1.6-beta.0
    * @cowprotocol/sdk-order-book bumped to 0.2.3-beta.0
    * @cowprotocol/sdk-order-signing bumped to 0.2.4-beta.0

## [0.2.4-beta.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-composable-v0.2.3-beta.0...sdk-composable-v0.2.4-beta.0) (2025-09-15)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-contracts-ts bumped to 2.1.5-beta.0
    * @cowprotocol/sdk-order-signing bumped to 0.2.3-beta.0

## [0.2.3-beta.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-composable-v0.2.2-beta.0...sdk-composable-v0.2.3-beta.0) (2025-09-11)


### 🔧 Miscellaneous

* release main ([#488](https://github.com/cowprotocol/cow-sdk/issues/488)) ([6344fa6](https://github.com/cowprotocol/cow-sdk/commit/6344fa619465e6f94637677823a18646f06fa7c9))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.3.0-beta.0
    * @cowprotocol/sdk-contracts-ts bumped to 2.1.4-beta.0
    * @cowprotocol/sdk-order-book bumped to 0.2.2-beta.0
    * @cowprotocol/sdk-order-signing bumped to 0.2.2-beta.0
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.2.2-beta.0
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.2.2-beta.0
    * @cowprotocol/sdk-viem-adapter bumped to 0.2.2-beta.0

## [0.2.2-beta.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-composable-v0.2.1-beta.0...sdk-composable-v0.2.2-beta.0) (2025-09-11)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-config bumped to 0.3.0-beta.0
    * @cowprotocol/sdk-contracts-ts bumped to 2.1.3-beta.0
    * @cowprotocol/sdk-order-book bumped to 0.2.1-beta.0
    * @cowprotocol/sdk-order-signing bumped to 0.2.1-beta.0

## [0.2.1-beta.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-composable-v0.2.0-beta.0...sdk-composable-v0.2.1-beta.0) (2025-09-01)


### 🐛 Bug Fixes

* improve unknown/any types ([#443](https://github.com/cowprotocol/cow-sdk/issues/443)) ([e6b8a40](https://github.com/cowprotocol/cow-sdk/commit/e6b8a40578583cf6d1ecd208434782422f308ef0))

## [0.2.0-beta.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-composable-v0.1.0-beta.0...sdk-composable-v0.2.0-beta.0) (2025-08-28)


### ✨ Features

* allow changing backoff and limiter per request ([#208](https://github.com/cowprotocol/cow-sdk/issues/208)) ([ebea5ca](https://github.com/cowprotocol/cow-sdk/commit/ebea5ca0858aeb89ae3e5d5407c8903c3ca5178d))
* enhance composable to test the 3 adapters ([7d1bd77](https://github.com/cowprotocol/cow-sdk/commit/7d1bd776b40a10808b9f6392dda862f610131169))
* move composable package from original sdk to refactor sdk ([a462634](https://github.com/cowprotocol/cow-sdk/commit/a462634111bec8c48444c721381b0cb012fc7ebe))
* refactor composable module to be framework-agnostic ([55032a2](https://github.com/cowprotocol/cow-sdk/commit/55032a2ca11d38d343f5f2c07c96b422671fa9e6))
* **sdk-agnostic-lib:** create cow trading package ([#368](https://github.com/cowprotocol/cow-sdk/issues/368)) ([0a4534a](https://github.com/cowprotocol/cow-sdk/commit/0a4534aababce4f5d8bab991cd6ae9f51842d719))
* **sdk-agnostic-lib:** Create weiroll package ([#371](https://github.com/cowprotocol/cow-sdk/issues/371)) ([8f6a2e1](https://github.com/cowprotocol/cow-sdk/commit/8f6a2e16e5e7a43a5afc43cf5faab174be916b2e))
* update tests to work with ethersV5 adapter ([42a6e5d](https://github.com/cowprotocol/cow-sdk/commit/42a6e5ddf2cdfc59562f095b10158b6a6b9377f7))


### 🐛 Bug Fixes

* **lib-agnostic:** add setProvider() method to adapters ([#432](https://github.com/cowprotocol/cow-sdk/issues/432)) ([64c0ea9](https://github.com/cowprotocol/cow-sdk/commit/64c0ea94d802aa167b978ae0859353d801de0911))


### 🔧 Miscellaneous

* move composable tests file to composable/tests ([9ab599a](https://github.com/cowprotocol/cow-sdk/commit/9ab599abf0c5839456e6bd87b7580fe3f232509f))
* move constants to sdk-common ([c1336c3](https://github.com/cowprotocol/cow-sdk/commit/c1336c3af5dc51c649c9435919e5e1054a6f94d5))
* remove console logs ([ce11a98](https://github.com/cowprotocol/cow-sdk/commit/ce11a98a36e609e963d51b8ffce1cb1995fe090f))
* **sdk-agnostic-lib:** improve scripts and types ([#407](https://github.com/cowprotocol/cow-sdk/issues/407)) ([c4b5e08](https://github.com/cowprotocol/cow-sdk/commit/c4b5e086ce46086e9430d5f03ed330502349fbf3))
* **sdk-agnostic-lib:** merge multiple PRs to avoid conflicts and speed up base branch sync ([#354](https://github.com/cowprotocol/cow-sdk/issues/354)) ([55d3068](https://github.com/cowprotocol/cow-sdk/commit/55d3068c52217dd2618d8c180ab4fed8c9334c72))
