import { Keypair, PublicKey } from '@solana/web3.js'
import { getAssociatedTokenAddressSync, TOKEN_2022_PROGRAM_ID } from '@solana/spl-token'
import { OrderKind, SigningScheme } from '@cowprotocol/sdk-order-book'
import { SOL_NATIVE_CURRENCY_ADDRESS } from '@cowprotocol/sdk-config'
import type { QuoteResults } from '@cowprotocol/sdk-trading'

import { mergeAppData } from './appData'
import { buildSolanaSwapOrder } from './buildSwapOrder'
import { encodeOrderIntent, hashOrderIntent, SolanaOrderIntent, toOrderId } from './orderIntent'
import { findOrderPda } from './orderPda'
import { SolanaQuote } from './types'

function fillPubkey(byte: number): PublicKey {
  return new PublicKey(new Uint8Array(32).fill(byte))
}

async function buildFixtureQuote(
  buyTokenProgramId?: PublicKey,
  intentOverrides: Partial<SolanaOrderIntent> = {},
): Promise<SolanaQuote> {
  const programId = fillPubkey(0x01)
  const intent: SolanaOrderIntent = {
    owner: fillPubkey(0x11),
    buyTokenAccount: fillPubkey(0x22),
    buyMint: fillPubkey(0x33),
    sellTokenAccount: fillPubkey(0x44),
    sellMint: fillPubkey(0x55),
    sellAmount: 100n,
    buyAmount: 200n,
    validTo: 1_700_000_000,
    kind: OrderKind.SELL,
    partiallyFillable: false,
    createdOnChain: true,
    appData: new Uint8Array(32),
    ...intentOverrides,
  }
  const intentBytes = encodeOrderIntent(intent)
  const uid = await hashOrderIntent(intentBytes)
  const [orderPda] = findOrderPda(programId, uid)

  return {
    intent,
    intentBytes,
    uid,
    orderPda,
    programId,
    buyTokenProgramId,
  }
}

function buildFixtureQuoteResults(orderToSign: unknown = { fake: 'orderToSign' }): QuoteResults {
  return {
    orderToSign,
    appDataInfo: { doc: { appCode: 'fixture-app', metadata: {} } },
  } as unknown as QuoteResults
}

describe('buildSolanaSwapOrder', () => {
  it('builds the CreateOrder instruction for the quoted intent', async () => {
    const solanaQuote = await buildFixtureQuote()
    const quoteResults = buildFixtureQuoteResults()

    const order = await buildSolanaSwapOrder({ quoteResults, solanaQuote })

    expect(order.instruction.programId.toBase58()).toBe(solanaQuote.programId.toBase58())
    expect(order.instruction.data[0]).toBe(2)
    expect(Uint8Array.from(order.instruction.data.subarray(1))).toEqual(solanaQuote.intentBytes)
  })

  it('returns the order identity and scheme alongside the instruction', async () => {
    const solanaQuote = await buildFixtureQuote()
    const quoteResults = buildFixtureQuoteResults()

    const order = await buildSolanaSwapOrder({ quoteResults, solanaQuote })

    expect(order.orderId).toBe(toOrderId(solanaQuote.uid))
    expect(order.uid).toEqual(solanaQuote.uid)
    expect(order.orderPda.toBase58()).toBe(solanaQuote.orderPda.toBase58())
    expect(order.intent).toEqual(solanaQuote.intent)
    expect(order.signingScheme).toBe(SigningScheme.PRESIGN)
    expect(order.orderToSign).toBe(quoteResults.orderToSign)
  })

  it('funds the order rent from the owner, so a single wallet signs the whole transaction', async () => {
    const solanaQuote = await buildFixtureQuote()

    const order = await buildSolanaSwapOrder({ quoteResults: buildFixtureQuoteResults(), solanaQuote })

    // accounts[0] is the owner/authenticator, accounts[1] the rent payer (`createdBy`).
    const accounts = order.instruction.keys.map((key) => key.pubkey.toBase58())
    const ownerBase58 = solanaQuote.intent.owner.toBase58()

    expect(accounts.slice(0, 2)).toEqual([ownerBase58, ownerBase58])
    expect(order.feePayer.toBase58()).toBe(ownerBase58)
  })

  it('funds the order rent from the sponsor when one is given, leaving the owner as authenticator', async () => {
    const solanaQuote = await buildFixtureQuote()
    const sponsor = fillPubkey(0x99)

    const order = await buildSolanaSwapOrder({ quoteResults: buildFixtureQuoteResults(), solanaQuote }, undefined, {
      sponsor,
    })

    const accounts = order.instruction.keys.map((key) => key.pubkey.toBase58())

    expect(accounts.slice(0, 2)).toEqual([solanaQuote.intent.owner.toBase58(), sponsor.toBase58()])
    expect(order.feePayer.toBase58()).toBe(sponsor.toBase58())
  })

  // The settlement program's intent carries no `created_by`, so who pays cannot move the order's hash.
  it('keeps the order identity independent of who pays for it', async () => {
    const solanaQuote = await buildFixtureQuote()
    const quoteResults = buildFixtureQuoteResults()

    const ownerPaid = await buildSolanaSwapOrder({ quoteResults, solanaQuote })
    const sponsored = await buildSolanaSwapOrder({ quoteResults, solanaQuote }, undefined, {
      sponsor: fillPubkey(0x99),
    })

    expect(sponsored.orderId).toBe(ownerPaid.orderId)
    expect(sponsored.orderPda.toBase58()).toBe(ownerPaid.orderPda.toBase58())
  })

  it('leaves the quoted intent untouched', async () => {
    const solanaQuote = await buildFixtureQuote()
    const originalValidTo = solanaQuote.intent.validTo

    await buildSolanaSwapOrder({ quoteResults: buildFixtureQuoteResults(), solanaQuote }, {
      quoteRequest: { validTo: originalValidTo + 1_000 },
    })

    expect(solanaQuote.intent.validTo).toBe(originalValidTo)
  })

  it('overriding the receiver derives its associated token account and re-derives uid/orderPda to match', async () => {
    const buyTokenProgramId = TOKEN_2022_PROGRAM_ID
    const solanaQuote = await buildFixtureQuote(buyTokenProgramId)
    const newReceiver = Keypair.generate().publicKey

    const order = await buildSolanaSwapOrder({ quoteResults: buildFixtureQuoteResults(), solanaQuote }, {
      quoteRequest: { receiver: newReceiver.toBase58() },
    })

    const expectedBuyTokenAccount = getAssociatedTokenAddressSync(
      solanaQuote.intent.buyMint,
      newReceiver,
      false,
      buyTokenProgramId,
    )
    const expectedIntent = { ...solanaQuote.intent, buyTokenAccount: expectedBuyTokenAccount }
    const expectedUid = await hashOrderIntent(encodeOrderIntent(expectedIntent))
    const [expectedOrderPda] = findOrderPda(solanaQuote.programId, expectedUid)

    expect(order.intent.buyTokenAccount.toBase58()).toBe(expectedBuyTokenAccount.toBase58())
    expect(Uint8Array.from(order.instruction.data.subarray(1))).toEqual(encodeOrderIntent(expectedIntent))
    expect(order.orderPda.toBase58()).toBe(expectedOrderPda.toBase58())
    expect(order.orderPda.toBase58()).not.toBe(solanaQuote.orderPda.toBase58())
    expect(order.orderId).toBe(toOrderId(expectedUid))
    expect(order.orderId).not.toBe(toOrderId(solanaQuote.uid))
  })

  it('overriding the receiver on a native-SOL buy names that account itself, not a token account', async () => {
    const solanaQuote = await buildFixtureQuote(undefined, {
      buyMint: new PublicKey(SOL_NATIVE_CURRENCY_ADDRESS),
    })
    const newReceiver = Keypair.generate().publicKey

    const order = await buildSolanaSwapOrder({ quoteResults: buildFixtureQuoteResults(), solanaQuote }, {
      quoteRequest: { receiver: newReceiver.toBase58() },
    })

    expect(order.intent.buyTokenAccount.toBase58()).toBe(newReceiver.toBase58())
    expect(order.intent.buyTokenAccount.toBase58()).not.toBe(
      getAssociatedTokenAddressSync(solanaQuote.intent.buyMint, newReceiver, false).toBase58(),
    )
  })

  it('overriding validTo re-derives uid/orderPda to match the posted intent', async () => {
    const solanaQuote = await buildFixtureQuote()
    const newValidTo = solanaQuote.intent.validTo + 1_000

    const order = await buildSolanaSwapOrder({ quoteResults: buildFixtureQuoteResults(), solanaQuote }, {
      quoteRequest: { validTo: newValidTo },
    })

    const expectedIntent = { ...solanaQuote.intent, validTo: newValidTo }
    const expectedUid = await hashOrderIntent(encodeOrderIntent(expectedIntent))
    const [expectedOrderPda] = findOrderPda(solanaQuote.programId, expectedUid)

    expect(order.intent.validTo).toBe(newValidTo)
    expect(order.orderPda.toBase58()).toBe(expectedOrderPda.toBase58())
    expect(order.orderPda.toBase58()).not.toBe(solanaQuote.orderPda.toBase58())
    expect(order.orderId).toBe(toOrderId(expectedUid))
  })

  it('overriding appData merges it into the quoted app-data doc and re-derives uid/orderPda to match', async () => {
    const solanaQuote = await buildFixtureQuote()
    const quoteResults = buildFixtureQuoteResults()
    const appDataOverride = { metadata: { referrer: { code: 'someone' } } }

    const order = await buildSolanaSwapOrder({ quoteResults, solanaQuote }, { appData: appDataOverride })

    const expectedAppData = await mergeAppData(quoteResults.appDataInfo.doc, appDataOverride)
    const expectedIntent = { ...solanaQuote.intent, appData: expectedAppData }
    const expectedUid = await hashOrderIntent(encodeOrderIntent(expectedIntent))
    const [expectedOrderPda] = findOrderPda(solanaQuote.programId, expectedUid)

    expect(order.intent.appData).toEqual(expectedAppData)
    expect(order.orderPda.toBase58()).toBe(expectedOrderPda.toBase58())
    expect(order.orderPda.toBase58()).not.toBe(solanaQuote.orderPda.toBase58())
    expect(order.orderId).toBe(toOrderId(expectedUid))
  })

  it('overriding appData does not throw when the quote has no app-data doc yet, matching getSolanaQuote\'s current stub', async () => {
    const solanaQuote = await buildFixtureQuote()
    // `getSolanaQuote` currently returns `appDataInfo: {} as QuoteResults['appDataInfo']` — no `doc` key at
    // all — until Solana app-data generation is implemented. `buildSolanaSwapOrder` must not crash on it.
    const quoteResults = { orderToSign: {}, appDataInfo: {} } as unknown as QuoteResults

    await expect(
      buildSolanaSwapOrder({ quoteResults, solanaQuote }, { appData: { appCode: 'some-app' } }),
    ).resolves.toBeDefined()
  })

  it('keeps the quoted uid/orderPda when advancedSettings overrides nothing relevant', async () => {
    const solanaQuote = await buildFixtureQuote()

    const order = await buildSolanaSwapOrder({ quoteResults: buildFixtureQuoteResults(), solanaQuote }, {
      quoteRequest: {},
    })

    expect(order.orderId).toBe(toOrderId(solanaQuote.uid))
    expect(order.orderPda.toBase58()).toBe(solanaQuote.orderPda.toBase58())
  })
})
