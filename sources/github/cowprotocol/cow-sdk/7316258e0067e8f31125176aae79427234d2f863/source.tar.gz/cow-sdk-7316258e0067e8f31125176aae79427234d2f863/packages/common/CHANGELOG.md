# Changelog

## [0.14.2](https://github.com/cowprotocol/cow-sdk/compare/sdk-common-v0.14.1...sdk-common-v0.14.2) (2026-09-29)


### 🔧 Miscellaneous

* update coverage badges ([#1026](https://github.com/cowprotocol/cow-sdk/issues/1026)) ([e44f931](https://github.com/cowprotocol/cow-sdk/commit/e44f931c2fc579d31f0773a79aeffd5678a9ed49))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-config bumped to 2.7.2

## [0.14.1](https://github.com/cowprotocol/cow-sdk/compare/sdk-common-v0.14.0...sdk-common-v0.14.1) (2026-09-25)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-config bumped to 2.7.1

## [0.14.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-common-v0.13.1...sdk-common-v0.14.0) (2026-09-21)


### ✨ Features

* **solana:** use cow protocol quotes ([#1023](https://github.com/cowprotocol/cow-sdk/issues/1023)) ([dc76c98](https://github.com/cowprotocol/cow-sdk/commit/dc76c98475855d7d291c762c664050aa06dd12fb))


### 🔧 Miscellaneous

* update coverage badges ([#1011](https://github.com/cowprotocol/cow-sdk/issues/1011)) ([3701bb5](https://github.com/cowprotocol/cow-sdk/commit/3701bb53a4815d553757db70ebd8bba8db02f0db))

## [0.13.1](https://github.com/cowprotocol/cow-sdk/compare/sdk-common-v0.13.0...sdk-common-v0.13.1) (2026-09-18)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-config bumped to 2.7.0

## [0.13.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-common-v0.12.3...sdk-common-v0.13.0) (2026-09-16)


### ✨ Features

* **composable:** add signer-aware Poller SDK ([#966](https://github.com/cowprotocol/cow-sdk/issues/966)) ([65d0eac](https://github.com/cowprotocol/cow-sdk/commit/65d0eac03cc21c0e0e55ec75a50ae49934a80272))

## [0.12.3](https://github.com/cowprotocol/cow-sdk/compare/sdk-common-v0.12.2...sdk-common-v0.12.3) (2026-09-07)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-config bumped to 2.6.0

## [0.12.2](https://github.com/cowprotocol/cow-sdk/compare/sdk-common-v0.12.1...sdk-common-v0.12.2) (2026-09-04)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-config bumped to 2.5.0

## [0.12.1](https://github.com/cowprotocol/cow-sdk/compare/sdk-common-v0.12.0...sdk-common-v0.12.1) (2026-07-29)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-config bumped to 2.4.0

## [0.12.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-common-v0.11.2...sdk-common-v0.12.0) (2026-06-15)


### ✨ Features

* per-package test coverage badges, updated in CI ([#895](https://github.com/cowprotocol/cow-sdk/issues/895)) ([c73246c](https://github.com/cowprotocol/cow-sdk/commit/c73246cc52c4fc79b2628b7c5f580695fd3dc1e2))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-config bumped to 2.3.1

## [0.11.2](https://github.com/cowprotocol/cow-sdk/compare/sdk-common-v0.11.1...sdk-common-v0.11.2) (2026-06-08)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-config bumped to 2.3.0

## [0.11.1](https://github.com/cowprotocol/cow-sdk/compare/sdk-common-v0.11.0...sdk-common-v0.11.1) (2026-06-02)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-config bumped to 2.2.1

## [0.11.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-common-v0.10.3...sdk-common-v0.11.0) (2026-05-27)


### ✨ Features

* move solana to supported chain id ([#873](https://github.com/cowprotocol/cow-sdk/issues/873)) ([da8a7c2](https://github.com/cowprotocol/cow-sdk/commit/da8a7c24cd07afcd465199844c480ebe3e81383d))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-config bumped to 2.2.0

## [0.10.3](https://github.com/cowprotocol/cow-sdk/compare/sdk-common-v0.10.2...sdk-common-v0.10.3) (2026-05-22)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-config bumped to 2.1.0

## [0.10.2](https://github.com/cowprotocol/cow-sdk/compare/sdk-common-v0.10.1...sdk-common-v0.10.2) (2026-04-16)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-config bumped to 2.0.0

## [0.10.1](https://github.com/cowprotocol/cow-sdk/compare/sdk-common-v0.10.0...sdk-common-v0.10.1) (2026-04-14)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-config bumped to 1.2.0

## [0.10.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-common-v0.9.0...sdk-common-v0.10.0) (2026-04-08)


### ✨ Features

* expose address regular expressions ([#858](https://github.com/cowprotocol/cow-sdk/issues/858)) ([1747364](https://github.com/cowprotocol/cow-sdk/commit/17473645636178cb876402d893d6d18a08b477c3))


### 🐛 Bug Fixes

* use adaptToken if contract address is empty ([#850](https://github.com/cowprotocol/cow-sdk/issues/850)) ([d57c397](https://github.com/cowprotocol/cow-sdk/commit/d57c3972d9104fbf846e15a831d004d4e20b961f))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-config bumped to 1.1.3

## [0.9.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-common-v0.8.2...sdk-common-v0.9.0) (2026-04-01)


### ✨ Features

* add sol/btc supports for NEAR ([#844](https://github.com/cowprotocol/cow-sdk/issues/844)) ([9c4ea35](https://github.com/cowprotocol/cow-sdk/commit/9c4ea35eed827bb36eee216fa0a53ed8b44f1756))

## [0.8.2](https://github.com/cowprotocol/cow-sdk/compare/sdk-common-v0.8.1...sdk-common-v0.8.2) (2026-03-17)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-config bumped to 1.1.2

## [0.8.1](https://github.com/cowprotocol/cow-sdk/compare/sdk-common-v0.8.0...sdk-common-v0.8.1) (2026-03-16)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-config bumped to 1.1.1

## [0.8.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-common-v0.7.1...sdk-common-v0.8.0) (2026-03-16)


### ✨ Features

* update settlement and vault relayer contracts on staging ([#807](https://github.com/cowprotocol/cow-sdk/issues/807)) ([0f9a03e](https://github.com/cowprotocol/cow-sdk/commit/0f9a03e6bfa3468630e46735f7583618ae711b73))


### 🔧 Miscellaneous

* release main ([#826](https://github.com/cowprotocol/cow-sdk/issues/826)) ([baaa708](https://github.com/cowprotocol/cow-sdk/commit/baaa7088ac15b89fb83310e54aa52f09d19132ff))
* release main ([#832](https://github.com/cowprotocol/cow-sdk/issues/832)) ([5dafcb8](https://github.com/cowprotocol/cow-sdk/commit/5dafcb8ec5593250dba1ff6e9fdbf8eb11d974cf))
* revert release ([#833](https://github.com/cowprotocol/cow-sdk/issues/833)) ([0c40a9b](https://github.com/cowprotocol/cow-sdk/commit/0c40a9b3ee828c7ede66576f02e1b571e96140cd))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-config bumped to 1.1.0

## [0.7.1](https://github.com/cowprotocol/cow-sdk/compare/sdk-common-v0.7.0...sdk-common-v0.7.1) (2026-03-10)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-config bumped to 1.0.0

## [0.7.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-common-v0.6.3...sdk-common-v0.7.0) (2026-03-04)


### ✨ Features

* Add non-evm chains types & guards & address validators  ([#792](https://github.com/cowprotocol/cow-sdk/issues/792)) ([b4b6047](https://github.com/cowprotocol/cow-sdk/commit/b4b6047889190f668f6409aeee7079ba6095f9ae))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-config bumped to 0.10.0

## [0.6.3](https://github.com/cowprotocol/cow-sdk/compare/sdk-common-v0.6.2...sdk-common-v0.6.3) (2026-03-04)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-config bumped to 0.9.0

## [0.6.2](https://github.com/cowprotocol/cow-sdk/compare/sdk-common-v0.6.1...sdk-common-v0.6.2) (2026-02-20)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-config bumped to 0.8.1

## [0.6.1](https://github.com/cowprotocol/cow-sdk/compare/sdk-common-v0.6.0...sdk-common-v0.6.1) (2026-02-18)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-config bumped to 0.8.0

## [0.6.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-common-v0.5.4...sdk-common-v0.6.0) (2026-02-05)


### ✨ Features

* move address utils ([#795](https://github.com/cowprotocol/cow-sdk/issues/795)) ([d18212c](https://github.com/cowprotocol/cow-sdk/commit/d18212c868ca2c16525a530f7914c9440f147414))
* rename getTokenAddressKey to getAddressKey ([#793](https://github.com/cowprotocol/cow-sdk/issues/793)) ([7fbb9ae](https://github.com/cowprotocol/cow-sdk/commit/7fbb9ae54fb8ce6df78126d2e6c3ac3495a5ded7))

## [0.5.4](https://github.com/cowprotocol/cow-sdk/compare/sdk-common-v0.5.3...sdk-common-v0.5.4) (2026-02-02)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-config bumped to 0.7.3

## [0.5.3](https://github.com/cowprotocol/cow-sdk/compare/sdk-common-v0.5.2...sdk-common-v0.5.3) (2026-02-02)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-config bumped to 0.7.2

## [0.5.2](https://github.com/cowprotocol/cow-sdk/compare/sdk-common-v0.5.1...sdk-common-v0.5.2) (2026-01-28)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-config bumped to 0.7.1

## [0.5.1](https://github.com/cowprotocol/cow-sdk/compare/sdk-common-v0.5.0...sdk-common-v0.5.1) (2026-01-28)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-config bumped to 0.7.0

## [0.5.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-common-v0.4.0...sdk-common-v0.5.0) (2026-01-19)


### ✨ Features

* **bridge:** allow sell token as intermediate token ([#768](https://github.com/cowprotocol/cow-sdk/issues/768)) ([8c367ac](https://github.com/cowprotocol/cow-sdk/commit/8c367ac704ad10003618c8916e32529c5c9eb815))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-config bumped to 0.6.3

## [0.4.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-common-v0.3.0...sdk-common-v0.4.0) (2025-11-24)


### ✨ Features

* **bridge:** add NearIntents bridge provider ([#663](https://github.com/cowprotocol/cow-sdk/issues/663)) ([afd63bc](https://github.com/cowprotocol/cow-sdk/commit/afd63bce3765e2adc81b73357e233399111e3595))

## [0.3.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-common-v0.2.2...sdk-common-v0.3.0) (2025-10-29)


### ✨ Features

* add from/to fields for receipt ([#629](https://github.com/cowprotocol/cow-sdk/issues/629)) ([3dd3868](https://github.com/cowprotocol/cow-sdk/commit/3dd38682741ac93bfbd9b7d9a4fe79df7283dca0))


### 🔧 Miscellaneous

* release main ([#620](https://github.com/cowprotocol/cow-sdk/issues/620)) ([b36394a](https://github.com/cowprotocol/cow-sdk/commit/b36394a2ba38957edb47ffc4451ea6624d66737b))
* revert release ([#634](https://github.com/cowprotocol/cow-sdk/issues/634)) ([fc7bf61](https://github.com/cowprotocol/cow-sdk/commit/fc7bf61444619d4b2c3a3dd55b7ce52c197b1878))

## [0.2.2](https://github.com/cowprotocol/cow-sdk/compare/sdk-common-v0.2.1...sdk-common-v0.2.2) (2025-10-24)


### 🐛 Bug Fixes

* **trading:** add EIP1271 signature support ([#584](https://github.com/cowprotocol/cow-sdk/issues/584)) ([ca9e834](https://github.com/cowprotocol/cow-sdk/commit/ca9e834e2b0edf8a757e01383b2218d5ecfbe25e))

## [0.2.1](https://github.com/cowprotocol/cow-sdk/compare/sdk-common-v0.2.0...sdk-common-v0.2.1) (2025-10-08)


### 🐛 Bug Fixes

* **slippage:** use volatility slippage to calculate volume slippage ([#574](https://github.com/cowprotocol/cow-sdk/issues/574)) ([0d86551](https://github.com/cowprotocol/cow-sdk/commit/0d8655153199707bed13b8303dac4a7c5d50a57a))

## [0.2.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-common-v0.1.0...sdk-common-v0.2.0) (2025-10-06)


### ✨ Features

* add caching to SDK Bridging ([#521](https://github.com/cowprotocol/cow-sdk/issues/521)) ([0c44212](https://github.com/cowprotocol/cow-sdk/commit/0c442121af74c297a002c7c0f608fb3396b9a446))

## [0.1.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-common-v0.5.0-beta.0...sdk-common-v0.1.0) (2025-09-17)


### ⚠ BREAKING CHANGES

* release cow-sdk v7 ([#514](https://github.com/cowprotocol/cow-sdk/issues/514))

### ✨ Features

* release cow-sdk v7 ([#514](https://github.com/cowprotocol/cow-sdk/issues/514)) ([01ebd43](https://github.com/cowprotocol/cow-sdk/commit/01ebd437bd0d54d601a3f00f3ebd2bffd58f7a93))

## [0.5.0-beta.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-common-v0.4.0-beta.0...sdk-common-v0.5.0-beta.0) (2025-09-17)


### ✨ Features

* **cow-shed:** validate EIP1271 signature ([#508](https://github.com/cowprotocol/cow-sdk/issues/508)) ([5c72123](https://github.com/cowprotocol/cow-sdk/commit/5c7212323edcea3eadf70973f765619afb1bcaf4))

## [0.4.0-beta.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-common-v0.3.0-beta.0...sdk-common-v0.4.0-beta.0) (2025-09-16)


### ✨ Features

* add migration guide and wagmi example ([#498](https://github.com/cowprotocol/cow-sdk/issues/498)) ([21be05d](https://github.com/cowprotocol/cow-sdk/commit/21be05d5b6472de26120ebefe4626341af9a062d))


### 📚 Documentation

* update README to focus on main use cases ([#493](https://github.com/cowprotocol/cow-sdk/issues/493)) ([a05cb1b](https://github.com/cowprotocol/cow-sdk/commit/a05cb1ba11b5f9895d7cfe6262cf74c4089fd73c))

## [0.3.0-beta.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-common-v0.2.1-beta.0...sdk-common-v0.3.0-beta.0) (2025-09-11)


### ✨ Features

* test release of packages ([#487](https://github.com/cowprotocol/cow-sdk/issues/487)) ([a6abbfe](https://github.com/cowprotocol/cow-sdk/commit/a6abbfe44ce68f8d32e5350dca2fa12f76826456))


### 🔧 Miscellaneous

* release main ([#488](https://github.com/cowprotocol/cow-sdk/issues/488)) ([6344fa6](https://github.com/cowprotocol/cow-sdk/commit/6344fa619465e6f94637677823a18646f06fa7c9))

## [0.2.1-beta.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-common-v0.2.0-beta.0...sdk-common-v0.2.1-beta.0) (2025-09-01)


### 🐛 Bug Fixes

* improve unknown/any types ([#443](https://github.com/cowprotocol/cow-sdk/issues/443)) ([e6b8a40](https://github.com/cowprotocol/cow-sdk/commit/e6b8a40578583cf6d1ecd208434782422f308ef0))

## [0.2.0-beta.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-common-v0.1.0-beta.0...sdk-common-v0.2.0-beta.0) (2025-08-28)


### ✨ Features

* allow changing backoff and limiter per request ([#208](https://github.com/cowprotocol/cow-sdk/issues/208)) ([ebea5ca](https://github.com/cowprotocol/cow-sdk/commit/ebea5ca0858aeb89ae3e5d5407c8903c3ca5178d))
* **cow-shed:** add estimateGas method to SignerAdapters ([fbb626a](https://github.com/cowprotocol/cow-sdk/commit/fbb626a0f88f6cb206432b4233b2d7d1e7cd4ad4))
* **cow-shed:** refact on common and contract-ts ([4be05aa](https://github.com/cowprotocol/cow-sdk/commit/4be05aa7a376fbc7d2ed5b2d2b6b68e3630b9c59))
* create common package with abstract adapter and context classes ([5e99f36](https://github.com/cowprotocol/cow-sdk/commit/5e99f36ddf1d8380a6ed136a51a7a1ecc4870396))
* enhance composable to test the 3 adapters ([7d1bd77](https://github.com/cowprotocol/cow-sdk/commit/7d1bd776b40a10808b9f6392dda862f610131169))
* **lib-agnostic:** migrate latest SDK changes ([#427](https://github.com/cowprotocol/cow-sdk/issues/427)) ([323bab6](https://github.com/cowprotocol/cow-sdk/commit/323bab61eb5adeb4a58bc15e25ffb29d2e1afcbf))
* **monorepo-config:** adjust all package.json and scripts ([23dc2a5](https://github.com/cowprotocol/cow-sdk/commit/23dc2a5db02ce3734b55e1151c8579f9a42a4bc5))
* refactor composable module to be framework-agnostic ([55032a2](https://github.com/cowprotocol/cow-sdk/commit/55032a2ca11d38d343f5f2c07c96b422671fa9e6))
* refactor contracts-ts ([2e14272](https://github.com/cowprotocol/cow-sdk/commit/2e14272f1a24a232aef584611924055ed657d16c))
* refactor contracts-ts ([b441360](https://github.com/cowprotocol/cow-sdk/commit/b4413600d4a0753e9f608e6a6415e64762a53d3e))
* refactor order-signing ([8e28d1b](https://github.com/cowprotocol/cow-sdk/commit/8e28d1bdbda9632347cacaae906298e736f4a7b3))
* **sdk-agnostic-lib:** create app data package ([#327](https://github.com/cowprotocol/cow-sdk/issues/327)) ([8b61261](https://github.com/cowprotocol/cow-sdk/commit/8b612615bc280dee2e5f4767794bc03f590d4764))
* **sdk-agnostic-lib:** create cow trading package ([#368](https://github.com/cowprotocol/cow-sdk/issues/368)) ([0a4534a](https://github.com/cowprotocol/cow-sdk/commit/0a4534aababce4f5d8bab991cd6ae9f51842d719))
* **sdk-agnostic-lib:** Create weiroll package ([#371](https://github.com/cowprotocol/cow-sdk/issues/371)) ([8f6a2e1](https://github.com/cowprotocol/cow-sdk/commit/8f6a2e16e5e7a43a5afc43cf5faab174be916b2e))


### 🐛 Bug Fixes

* add adapter param to BridgingSdk and update docs ([#450](https://github.com/cowprotocol/cow-sdk/issues/450)) ([667a36e](https://github.com/cowprotocol/cow-sdk/commit/667a36e4437309e1d292b8f9fd5e8f568922749f))
* **lib-agnostic:** add setProvider() method to adapters ([#432](https://github.com/cowprotocol/cow-sdk/issues/432)) ([64c0ea9](https://github.com/cowprotocol/cow-sdk/commit/64c0ea94d802aa167b978ae0859353d801de0911))


### ♻️ Refactoring

* move cow-error and wallets.ts and remove duplicate types ([4a7e5d6](https://github.com/cowprotocol/cow-sdk/commit/4a7e5d6d035ccebf05cce437f0409220f39b643a))


### 🔧 Miscellaneous

* add hashDomain to abstract utils ([f8692c1](https://github.com/cowprotocol/cow-sdk/commit/f8692c1c03b372076f785546d8f022be84206a1d))
* **cow-shed:** copy wallets.ts ([d187b04](https://github.com/cowprotocol/cow-sdk/commit/d187b0493acef0442288aad5265b63252f9d1674))
* fix lint and remove cow-sdk from lint. ([46decb7](https://github.com/cowprotocol/cow-sdk/commit/46decb72050c1b9481b24d9b10b6a4c4f2abe0c3))
* migrate latest changes from main 26-08-2025 ([#445](https://github.com/cowprotocol/cow-sdk/issues/445)) ([698937c](https://github.com/cowprotocol/cow-sdk/commit/698937c0feff3a254873371bc1ef791917e6294e))
* move constants to sdk-common ([c1336c3](https://github.com/cowprotocol/cow-sdk/commit/c1336c3af5dc51c649c9435919e5e1054a6f94d5))
* **sdk-agnostic-lib:** improve scripts and types ([#407](https://github.com/cowprotocol/cow-sdk/issues/407)) ([c4b5e08](https://github.com/cowprotocol/cow-sdk/commit/c4b5e086ce46086e9430d5f03ed330502349fbf3))
* **sdk-agnostic-lib:** merge multiple PRs to avoid conflicts and speed up base branch sync ([#354](https://github.com/cowprotocol/cow-sdk/issues/354)) ([55d3068](https://github.com/cowprotocol/cow-sdk/commit/55d3068c52217dd2618d8c180ab4fed8c9334c72))
