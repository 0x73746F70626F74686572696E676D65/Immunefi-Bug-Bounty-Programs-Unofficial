# Changelog

## [3.3.14](https://github.com/cowprotocol/cow-sdk/compare/sdk-flash-loans-v3.3.13...sdk-flash-loans-v3.3.14) (2026-10-01)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-trading bumped to 2.7.4
    * @cowprotocol/sdk-order-signing bumped to 1.1.16
    * @cowprotocol/sdk-order-book bumped to 4.3.0

## [3.3.13](https://github.com/cowprotocol/cow-sdk/compare/sdk-flash-loans-v3.3.12...sdk-flash-loans-v3.3.13) (2026-09-29)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.14.2
    * @cowprotocol/sdk-app-data bumped to 6.0.8
    * @cowprotocol/sdk-trading bumped to 2.7.3
    * @cowprotocol/sdk-order-signing bumped to 1.1.15
    * @cowprotocol/sdk-order-book bumped to 4.2.1
    * @cowprotocol/sdk-config bumped to 2.7.2
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.4.18
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.4.18
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.33

## [3.3.12](https://github.com/cowprotocol/cow-sdk/compare/sdk-flash-loans-v3.3.11...sdk-flash-loans-v3.3.12) (2026-09-25)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-trading bumped to 2.7.2
    * @cowprotocol/sdk-order-signing bumped to 1.1.14
    * @cowprotocol/sdk-order-book bumped to 4.2.0

## [3.3.11](https://github.com/cowprotocol/cow-sdk/compare/sdk-flash-loans-v3.3.10...sdk-flash-loans-v3.3.11) (2026-09-25)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.14.1
    * @cowprotocol/sdk-app-data bumped to 6.0.7
    * @cowprotocol/sdk-trading bumped to 2.7.1
    * @cowprotocol/sdk-order-signing bumped to 1.1.13
    * @cowprotocol/sdk-order-book bumped to 4.1.1
    * @cowprotocol/sdk-config bumped to 2.7.1
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.4.17
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.4.17
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.32

## [3.3.10](https://github.com/cowprotocol/cow-sdk/compare/sdk-flash-loans-v3.3.9...sdk-flash-loans-v3.3.10) (2026-09-21)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.14.0
    * @cowprotocol/sdk-app-data bumped to 6.0.6
    * @cowprotocol/sdk-trading bumped to 2.7.0
    * @cowprotocol/sdk-order-signing bumped to 1.1.12
    * @cowprotocol/sdk-order-book bumped to 4.1.0
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.4.16
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.4.16
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.31

## [3.3.9](https://github.com/cowprotocol/cow-sdk/compare/sdk-flash-loans-v3.3.8...sdk-flash-loans-v3.3.9) (2026-09-18)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.13.1
    * @cowprotocol/sdk-app-data bumped to 6.0.5
    * @cowprotocol/sdk-trading bumped to 2.6.0
    * @cowprotocol/sdk-order-signing bumped to 1.1.11
    * @cowprotocol/sdk-order-book bumped to 4.0.6
    * @cowprotocol/sdk-config bumped to 2.7.0
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.4.15
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.4.15
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.30

## [3.3.8](https://github.com/cowprotocol/cow-sdk/compare/sdk-flash-loans-v3.3.7...sdk-flash-loans-v3.3.8) (2026-09-16)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.13.0
    * @cowprotocol/sdk-app-data bumped to 6.0.4
    * @cowprotocol/sdk-trading bumped to 2.5.0
    * @cowprotocol/sdk-order-signing bumped to 1.1.10
    * @cowprotocol/sdk-order-book bumped to 4.0.5
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.4.14
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.4.14
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.29

## [3.3.7](https://github.com/cowprotocol/cow-sdk/compare/sdk-flash-loans-v3.3.6...sdk-flash-loans-v3.3.7) (2026-09-14)


### 🔧 Miscellaneous

* update coverage badges ([#948](https://github.com/cowprotocol/cow-sdk/issues/948)) ([151d7a4](https://github.com/cowprotocol/cow-sdk/commit/151d7a4bc51194ffa7dc46a102eb2bc0e3537124))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-app-data bumped to 6.0.3
    * @cowprotocol/sdk-trading bumped to 2.4.2

## [3.3.6](https://github.com/cowprotocol/cow-sdk/compare/sdk-flash-loans-v3.3.5...sdk-flash-loans-v3.3.6) (2026-09-07)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.12.3
    * @cowprotocol/sdk-app-data bumped to 6.0.2
    * @cowprotocol/sdk-trading bumped to 2.4.1
    * @cowprotocol/sdk-order-signing bumped to 1.1.9
    * @cowprotocol/sdk-order-book bumped to 4.0.4
    * @cowprotocol/sdk-config bumped to 2.6.0
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.4.13
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.4.13
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.28

## [3.3.5](https://github.com/cowprotocol/cow-sdk/compare/sdk-flash-loans-v3.3.4...sdk-flash-loans-v3.3.5) (2026-09-04)


### 🔧 Miscellaneous

* split integration tests ([#978](https://github.com/cowprotocol/cow-sdk/issues/978)) ([72bbc6f](https://github.com/cowprotocol/cow-sdk/commit/72bbc6f8f88ce66597f36cd08d391ab79e342843))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.12.2
    * @cowprotocol/sdk-app-data bumped to 6.0.1
    * @cowprotocol/sdk-trading bumped to 2.4.0
    * @cowprotocol/sdk-order-signing bumped to 1.1.8
    * @cowprotocol/sdk-order-book bumped to 4.0.3
    * @cowprotocol/sdk-config bumped to 2.5.0
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.4.12
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.4.12
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.27

## [3.3.4](https://github.com/cowprotocol/cow-sdk/compare/sdk-flash-loans-v3.3.3...sdk-flash-loans-v3.3.4) (2026-09-01)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-trading bumped to 2.3.0
    * @cowprotocol/sdk-order-signing bumped to 1.1.7

## [3.3.3](https://github.com/cowprotocol/cow-sdk/compare/sdk-flash-loans-v3.3.2...sdk-flash-loans-v3.3.3) (2026-07-29)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.12.1
    * @cowprotocol/sdk-app-data bumped to 5.3.3
    * @cowprotocol/sdk-trading bumped to 2.2.6
    * @cowprotocol/sdk-order-signing bumped to 1.1.6
    * @cowprotocol/sdk-order-book bumped to 4.0.2
    * @cowprotocol/sdk-config bumped to 2.4.0
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.4.11
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.4.11
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.26

## [3.3.2](https://github.com/cowprotocol/cow-sdk/compare/sdk-flash-loans-v3.3.1...sdk-flash-loans-v3.3.2) (2026-07-28)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-trading bumped to 2.2.5
    * @cowprotocol/sdk-order-signing bumped to 1.1.5

## [3.3.1](https://github.com/cowprotocol/cow-sdk/compare/sdk-flash-loans-v3.3.0...sdk-flash-loans-v3.3.1) (2026-07-22)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-trading bumped to 2.2.4
    * @cowprotocol/sdk-order-signing bumped to 1.1.4

## [3.3.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-flash-loans-v3.2.2...sdk-flash-loans-v3.3.0) (2026-07-22)


### ✨ Features

* **flash-loans:** add barn (staging) Aave V3 adapters on Base ([#938](https://github.com/cowprotocol/cow-sdk/issues/938)) ([aceb15b](https://github.com/cowprotocol/cow-sdk/commit/aceb15bd0b96f362a6b5a0a27d5d03e603c95565))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-app-data bumped to 5.3.2
    * @cowprotocol/sdk-trading bumped to 2.2.3
    * @cowprotocol/sdk-order-signing bumped to 1.1.3
  * devDependencies
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.25

## [3.2.2](https://github.com/cowprotocol/cow-sdk/compare/sdk-flash-loans-v3.2.1...sdk-flash-loans-v3.2.2) (2026-06-23)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-app-data bumped to 5.3.1
    * @cowprotocol/sdk-trading bumped to 2.2.2
    * @cowprotocol/sdk-order-signing bumped to 1.1.2

## [3.2.1](https://github.com/cowprotocol/cow-sdk/compare/sdk-flash-loans-v3.2.0...sdk-flash-loans-v3.2.1) (2026-06-17)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-trading bumped to 2.2.1
    * @cowprotocol/sdk-order-signing bumped to 1.1.1
    * @cowprotocol/sdk-order-book bumped to 4.0.1

## [3.2.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-flash-loans-v3.1.2...sdk-flash-loans-v3.2.0) (2026-06-15)


### ✨ Features

* per-package test coverage badges, updated in CI ([#895](https://github.com/cowprotocol/cow-sdk/issues/895)) ([c73246c](https://github.com/cowprotocol/cow-sdk/commit/c73246cc52c4fc79b2628b7c5f580695fd3dc1e2))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.12.0
    * @cowprotocol/sdk-app-data bumped to 5.3.0
    * @cowprotocol/sdk-trading bumped to 2.2.0
    * @cowprotocol/sdk-order-signing bumped to 1.1.0
    * @cowprotocol/sdk-order-book bumped to 4.0.0
    * @cowprotocol/sdk-config bumped to 2.3.1
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.4.10
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.4.10
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.24

## [3.1.2](https://github.com/cowprotocol/cow-sdk/compare/sdk-flash-loans-v3.1.1...sdk-flash-loans-v3.1.2) (2026-06-08)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.11.2
    * @cowprotocol/sdk-app-data bumped to 5.2.0
    * @cowprotocol/sdk-trading bumped to 2.1.2
    * @cowprotocol/sdk-order-signing bumped to 1.0.6
    * @cowprotocol/sdk-order-book bumped to 3.2.2
    * @cowprotocol/sdk-config bumped to 2.3.0
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.4.9
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.4.9
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.23

## [3.1.1](https://github.com/cowprotocol/cow-sdk/compare/sdk-flash-loans-v3.1.0...sdk-flash-loans-v3.1.1) (2026-06-02)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.11.1
    * @cowprotocol/sdk-app-data bumped to 5.1.4
    * @cowprotocol/sdk-trading bumped to 2.1.1
    * @cowprotocol/sdk-order-signing bumped to 1.0.5
    * @cowprotocol/sdk-order-book bumped to 3.2.1
    * @cowprotocol/sdk-config bumped to 2.2.1
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.4.8
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.4.8
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.22

## [3.1.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-flash-loans-v3.0.5...sdk-flash-loans-v3.1.0) (2026-05-27)


### ✨ Features

* move solana to supported chain id ([#873](https://github.com/cowprotocol/cow-sdk/issues/873)) ([da8a7c2](https://github.com/cowprotocol/cow-sdk/commit/da8a7c24cd07afcd465199844c480ebe3e81383d))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.11.0
    * @cowprotocol/sdk-app-data bumped to 5.1.3
    * @cowprotocol/sdk-trading bumped to 2.1.0
    * @cowprotocol/sdk-order-signing bumped to 1.0.4
    * @cowprotocol/sdk-order-book bumped to 3.2.0
    * @cowprotocol/sdk-config bumped to 2.2.0
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.4.7
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.4.7
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.21

## [3.0.5](https://github.com/cowprotocol/cow-sdk/compare/sdk-flash-loans-v3.0.4...sdk-flash-loans-v3.0.5) (2026-05-22)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.10.3
    * @cowprotocol/sdk-app-data bumped to 5.1.2
    * @cowprotocol/sdk-trading bumped to 2.0.5
    * @cowprotocol/sdk-order-signing bumped to 1.0.3
    * @cowprotocol/sdk-order-book bumped to 3.1.0
    * @cowprotocol/sdk-config bumped to 2.1.0
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.4.6
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.4.6
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.20

## [3.0.4](https://github.com/cowprotocol/cow-sdk/compare/sdk-flash-loans-v3.0.3...sdk-flash-loans-v3.0.4) (2026-05-20)


### 🐛 Bug Fixes

* **flash-loans:** simplify CollateralSwapOrder interface ([#877](https://github.com/cowprotocol/cow-sdk/issues/877)) ([0edf7d1](https://github.com/cowprotocol/cow-sdk/commit/0edf7d158a65403190de3348097a2e464e24e28d))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-app-data bumped to 5.1.1
    * @cowprotocol/sdk-trading bumped to 2.0.4
    * @cowprotocol/sdk-order-signing bumped to 1.0.2
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.4.5
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.4.5
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.19

## [3.0.3](https://github.com/cowprotocol/cow-sdk/compare/sdk-flash-loans-v3.0.2...sdk-flash-loans-v3.0.3) (2026-04-28)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-app-data bumped to 5.1.0
    * @cowprotocol/sdk-trading bumped to 2.0.3

## [3.0.2](https://github.com/cowprotocol/cow-sdk/compare/sdk-flash-loans-v3.0.1...sdk-flash-loans-v3.0.2) (2026-04-22)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-trading bumped to 2.0.2

## [3.0.1](https://github.com/cowprotocol/cow-sdk/compare/sdk-flash-loans-v3.0.0...sdk-flash-loans-v3.0.1) (2026-04-20)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-trading bumped to 2.0.1
    * @cowprotocol/sdk-order-signing bumped to 1.0.1

## [3.0.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-flash-loans-v2.1.0...sdk-flash-loans-v3.0.0) (2026-04-16)


### ⚠ BREAKING CHANGES

* bring cow.fi back ([#863](https://github.com/cowprotocol/cow-sdk/issues/863))

### ✨ Features

* bring cow.fi back ([#863](https://github.com/cowprotocol/cow-sdk/issues/863)) ([d607fd2](https://github.com/cowprotocol/cow-sdk/commit/d607fd2cfbc93ace39de04f3a7870f723fdd9b21))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.10.2
    * @cowprotocol/sdk-app-data bumped to 5.0.0
    * @cowprotocol/sdk-trading bumped to 2.0.0
    * @cowprotocol/sdk-order-signing bumped to 1.0.0
    * @cowprotocol/sdk-order-book bumped to 3.0.0
    * @cowprotocol/sdk-config bumped to 2.0.0
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.4.4
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.4.4
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.18

## [2.1.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-flash-loans-v2.0.6...sdk-flash-loans-v2.1.0) (2026-04-14)


### ✨ Features

* migrate to cow.finance domain ([#860](https://github.com/cowprotocol/cow-sdk/issues/860)) ([a4e7633](https://github.com/cowprotocol/cow-sdk/commit/a4e76333b7a276baec5c977f44b15498550d8e50))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.10.1
    * @cowprotocol/sdk-app-data bumped to 4.7.0
    * @cowprotocol/sdk-trading bumped to 1.3.0
    * @cowprotocol/sdk-order-signing bumped to 0.3.0
    * @cowprotocol/sdk-order-book bumped to 2.1.0
    * @cowprotocol/sdk-config bumped to 1.2.0
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.4.3
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.4.3
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.17

## [2.0.6](https://github.com/cowprotocol/cow-sdk/compare/sdk-flash-loans-v2.0.5...sdk-flash-loans-v2.0.6) (2026-04-08)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.10.0
    * @cowprotocol/sdk-app-data bumped to 4.6.14
    * @cowprotocol/sdk-trading bumped to 1.2.2
    * @cowprotocol/sdk-order-signing bumped to 0.2.5
    * @cowprotocol/sdk-order-book bumped to 2.0.5
    * @cowprotocol/sdk-config bumped to 1.1.3
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.4.2
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.4.2
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.16

## [2.0.5](https://github.com/cowprotocol/cow-sdk/compare/sdk-flash-loans-v2.0.4...sdk-flash-loans-v2.0.5) (2026-04-01)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.9.0
    * @cowprotocol/sdk-app-data bumped to 4.6.13
    * @cowprotocol/sdk-trading bumped to 1.2.1
    * @cowprotocol/sdk-order-signing bumped to 0.2.4
    * @cowprotocol/sdk-order-book bumped to 2.0.4
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.4.1
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.4.1
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.15

## [2.0.4](https://github.com/cowprotocol/cow-sdk/compare/sdk-flash-loans-v2.0.3...sdk-flash-loans-v2.0.4) (2026-03-17)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-app-data bumped to 4.6.12
    * @cowprotocol/sdk-trading bumped to 1.2.0
    * @cowprotocol/sdk-order-signing bumped to 0.2.3
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.4.0
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.4.0

## [2.0.3](https://github.com/cowprotocol/cow-sdk/compare/sdk-flash-loans-v2.0.2...sdk-flash-loans-v2.0.3) (2026-03-17)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.8.2
    * @cowprotocol/sdk-app-data bumped to 4.6.11
    * @cowprotocol/sdk-trading bumped to 1.1.2
    * @cowprotocol/sdk-order-signing bumped to 0.2.2
    * @cowprotocol/sdk-order-book bumped to 2.0.3
    * @cowprotocol/sdk-config bumped to 1.1.2
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.3.14
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.3.14
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.14

## [2.0.2](https://github.com/cowprotocol/cow-sdk/compare/sdk-flash-loans-v2.0.1...sdk-flash-loans-v2.0.2) (2026-03-16)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.8.1
    * @cowprotocol/sdk-app-data bumped to 4.6.10
    * @cowprotocol/sdk-trading bumped to 1.1.1
    * @cowprotocol/sdk-order-signing bumped to 0.2.1
    * @cowprotocol/sdk-order-book bumped to 2.0.2
    * @cowprotocol/sdk-config bumped to 1.1.1
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.3.13
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.3.13
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.13

## [2.0.1](https://github.com/cowprotocol/cow-sdk/compare/sdk-flash-loans-v2.0.0...sdk-flash-loans-v2.0.1) (2026-03-16)


### 🔧 Miscellaneous

* release main ([#826](https://github.com/cowprotocol/cow-sdk/issues/826)) ([baaa708](https://github.com/cowprotocol/cow-sdk/commit/baaa7088ac15b89fb83310e54aa52f09d19132ff))
* release main ([#832](https://github.com/cowprotocol/cow-sdk/issues/832)) ([5dafcb8](https://github.com/cowprotocol/cow-sdk/commit/5dafcb8ec5593250dba1ff6e9fdbf8eb11d974cf))
* revert release ([#833](https://github.com/cowprotocol/cow-sdk/issues/833)) ([0c40a9b](https://github.com/cowprotocol/cow-sdk/commit/0c40a9b3ee828c7ede66576f02e1b571e96140cd))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.8.0
    * @cowprotocol/sdk-app-data bumped to 4.6.9
    * @cowprotocol/sdk-trading bumped to 1.1.0
    * @cowprotocol/sdk-order-signing bumped to 0.2.0
    * @cowprotocol/sdk-order-book bumped to 2.0.1
    * @cowprotocol/sdk-config bumped to 1.1.0
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.3.12
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.3.12
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.12

## [2.0.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-flash-loans-v1.7.11...sdk-flash-loans-v2.0.0) (2026-03-10)


### ⚠ BREAKING CHANGES

* **chains:** Remove support for Lens.

### ✨ Features

* **chains:** Remove Lens ([#818](https://github.com/cowprotocol/cow-sdk/issues/818)) ([e8c74a0](https://github.com/cowprotocol/cow-sdk/commit/e8c74a078e5940901591652164af7b2ffb7b1fa6))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.7.1
    * @cowprotocol/sdk-app-data bumped to 4.6.8
    * @cowprotocol/sdk-trading bumped to 1.0.4
    * @cowprotocol/sdk-order-signing bumped to 0.1.38
    * @cowprotocol/sdk-order-book bumped to 2.0.0
    * @cowprotocol/sdk-config bumped to 1.0.0
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.3.11
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.3.11
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.11

## [1.7.11](https://github.com/cowprotocol/cow-sdk/compare/sdk-flash-loans-v1.7.10...sdk-flash-loans-v1.7.11) (2026-03-10)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-trading bumped to 1.0.3
    * @cowprotocol/sdk-order-signing bumped to 0.1.37
    * @cowprotocol/sdk-order-book bumped to 1.1.2

## [1.7.10](https://github.com/cowprotocol/cow-sdk/compare/sdk-flash-loans-v1.7.9...sdk-flash-loans-v1.7.10) (2026-03-04)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.7.0
    * @cowprotocol/sdk-app-data bumped to 4.6.7
    * @cowprotocol/sdk-trading bumped to 1.0.2
    * @cowprotocol/sdk-order-signing bumped to 0.1.36
    * @cowprotocol/sdk-order-book bumped to 1.1.1
    * @cowprotocol/sdk-config bumped to 0.10.0
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.3.10
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.3.10
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.10

## [1.7.9](https://github.com/cowprotocol/cow-sdk/compare/sdk-flash-loans-v1.7.8...sdk-flash-loans-v1.7.9) (2026-03-04)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.6.3
    * @cowprotocol/sdk-app-data bumped to 4.6.6
    * @cowprotocol/sdk-trading bumped to 1.0.1
    * @cowprotocol/sdk-order-signing bumped to 0.1.35
    * @cowprotocol/sdk-order-book bumped to 1.1.0
    * @cowprotocol/sdk-config bumped to 0.9.0
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.3.9
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.3.9
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.9

## [1.7.8](https://github.com/cowprotocol/cow-sdk/compare/sdk-flash-loans-v1.7.7...sdk-flash-loans-v1.7.8) (2026-02-26)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-trading bumped to 1.0.0
    * @cowprotocol/sdk-order-signing bumped to 0.1.34
    * @cowprotocol/sdk-order-book bumped to 1.0.0

## [1.7.7](https://github.com/cowprotocol/cow-sdk/compare/sdk-flash-loans-v1.7.6...sdk-flash-loans-v1.7.7) (2026-02-20)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.6.2
    * @cowprotocol/sdk-app-data bumped to 4.6.5
    * @cowprotocol/sdk-trading bumped to 0.11.1
    * @cowprotocol/sdk-order-signing bumped to 0.1.33
    * @cowprotocol/sdk-order-book bumped to 0.6.6
    * @cowprotocol/sdk-config bumped to 0.8.1
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.3.8
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.3.8
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.8

## [1.7.6](https://github.com/cowprotocol/cow-sdk/compare/sdk-flash-loans-v1.7.5...sdk-flash-loans-v1.7.6) (2026-02-18)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.6.1
    * @cowprotocol/sdk-app-data bumped to 4.6.4
    * @cowprotocol/sdk-trading bumped to 0.11.0
    * @cowprotocol/sdk-order-signing bumped to 0.1.32
    * @cowprotocol/sdk-order-book bumped to 0.6.5
    * @cowprotocol/sdk-config bumped to 0.8.0
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.3.7
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.3.7
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.7

## [1.7.5](https://github.com/cowprotocol/cow-sdk/compare/sdk-flash-loans-v1.7.4...sdk-flash-loans-v1.7.5) (2026-02-05)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.6.0
    * @cowprotocol/sdk-app-data bumped to 4.6.3
    * @cowprotocol/sdk-trading bumped to 0.10.1
    * @cowprotocol/sdk-order-signing bumped to 0.1.31
    * @cowprotocol/sdk-order-book bumped to 0.6.4
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.3.6
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.3.6
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.6

## [1.7.4](https://github.com/cowprotocol/cow-sdk/compare/sdk-flash-loans-v1.7.3...sdk-flash-loans-v1.7.4) (2026-02-03)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-trading bumped to 0.10.0

## [1.7.3](https://github.com/cowprotocol/cow-sdk/compare/sdk-flash-loans-v1.7.2...sdk-flash-loans-v1.7.3) (2026-02-02)


### 🔧 Miscellaneous

* revert revert Ink network ([#789](https://github.com/cowprotocol/cow-sdk/issues/789)) ([a00dbbd](https://github.com/cowprotocol/cow-sdk/commit/a00dbbd6a26238bcee2d4452487d16551560c59f))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.5.4
    * @cowprotocol/sdk-app-data bumped to 4.6.2
    * @cowprotocol/sdk-trading bumped to 0.9.4
    * @cowprotocol/sdk-order-signing bumped to 0.1.30
    * @cowprotocol/sdk-order-book bumped to 0.6.3
    * @cowprotocol/sdk-config bumped to 0.7.3
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.3.5
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.3.5
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.5

## [1.7.2](https://github.com/cowprotocol/cow-sdk/compare/sdk-flash-loans-v1.7.1...sdk-flash-loans-v1.7.2) (2026-02-02)


### 🐛 Bug Fixes

* support decimals in protocolFeeBps ([#787](https://github.com/cowprotocol/cow-sdk/issues/787)) ([f53ae65](https://github.com/cowprotocol/cow-sdk/commit/f53ae65931d85e354779767ed67e0e4df944a2bc))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.5.3
    * @cowprotocol/sdk-app-data bumped to 4.6.1
    * @cowprotocol/sdk-trading bumped to 0.9.3
    * @cowprotocol/sdk-order-signing bumped to 0.1.29
    * @cowprotocol/sdk-order-book bumped to 0.6.2
    * @cowprotocol/sdk-config bumped to 0.7.2
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.3.4
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.3.4
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.4

## [1.7.1](https://github.com/cowprotocol/cow-sdk/compare/sdk-flash-loans-v1.7.0...sdk-flash-loans-v1.7.1) (2026-01-28)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.5.2
    * @cowprotocol/sdk-app-data bumped to 4.6.0
    * @cowprotocol/sdk-trading bumped to 0.9.2
    * @cowprotocol/sdk-order-signing bumped to 0.1.28
    * @cowprotocol/sdk-order-book bumped to 0.6.1
    * @cowprotocol/sdk-config bumped to 0.7.1
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.3.3
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.3.3
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.3

## [1.7.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-flash-loans-v1.6.8...sdk-flash-loans-v1.7.0) (2026-01-28)


### ✨ Features

* **ink:** reapply "feat/COW-163: Add Ink network ([#781](https://github.com/cowprotocol/cow-sdk/issues/781))" ([7c23332](https://github.com/cowprotocol/cow-sdk/commit/7c23332dac4f8c91d5f75ae68297906e20f20362))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.5.1
    * @cowprotocol/sdk-app-data bumped to 4.5.2
    * @cowprotocol/sdk-trading bumped to 0.9.1
    * @cowprotocol/sdk-order-signing bumped to 0.1.27
    * @cowprotocol/sdk-order-book bumped to 0.6.0
    * @cowprotocol/sdk-config bumped to 0.7.0
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.3.2
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.3.2
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.2

## [1.6.8](https://github.com/cowprotocol/cow-sdk/compare/sdk-flash-loans-v1.6.7...sdk-flash-loans-v1.6.8) (2026-01-22)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-trading bumped to 0.9.0
    * @cowprotocol/sdk-order-signing bumped to 0.1.26

## [1.6.7](https://github.com/cowprotocol/cow-sdk/compare/sdk-flash-loans-v1.6.6...sdk-flash-loans-v1.6.7) (2026-01-21)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-trading bumped to 0.8.2
    * @cowprotocol/sdk-order-signing bumped to 0.1.25

## [1.6.6](https://github.com/cowprotocol/cow-sdk/compare/sdk-flash-loans-v1.6.5...sdk-flash-loans-v1.6.6) (2026-01-19)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.5.0
    * @cowprotocol/sdk-app-data bumped to 4.5.1
    * @cowprotocol/sdk-trading bumped to 0.8.1
    * @cowprotocol/sdk-order-signing bumped to 0.1.24
    * @cowprotocol/sdk-order-book bumped to 0.5.1
    * @cowprotocol/sdk-config bumped to 0.6.3
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.3.1
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.3.1
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.1

## [1.6.5](https://github.com/cowprotocol/cow-sdk/compare/sdk-flash-loans-v1.6.4...sdk-flash-loans-v1.6.5) (2025-12-25)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-app-data bumped to 4.5.0
    * @cowprotocol/sdk-trading bumped to 0.8.0

## [1.6.4](https://github.com/cowprotocol/cow-sdk/compare/sdk-flash-loans-v1.6.3...sdk-flash-loans-v1.6.4) (2025-12-24)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-trading bumped to 0.7.4

## [1.6.3](https://github.com/cowprotocol/cow-sdk/compare/sdk-flash-loans-v1.6.2...sdk-flash-loans-v1.6.3) (2025-12-22)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-app-data bumped to 4.4.0
    * @cowprotocol/sdk-trading bumped to 0.7.3
    * @cowprotocol/sdk-order-signing bumped to 0.1.23
    * @cowprotocol/sdk-order-book bumped to 0.5.0

## [1.6.2](https://github.com/cowprotocol/cow-sdk/compare/sdk-flash-loans-v1.6.1...sdk-flash-loans-v1.6.2) (2025-12-19)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-trading bumped to 0.7.2
    * @cowprotocol/sdk-order-signing bumped to 0.1.22

## [1.6.1](https://github.com/cowprotocol/cow-sdk/compare/sdk-flash-loans-v1.6.0...sdk-flash-loans-v1.6.1) (2025-12-11)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-app-data bumped to 4.3.6
    * @cowprotocol/sdk-trading bumped to 0.7.1
    * @cowprotocol/sdk-order-signing bumped to 0.1.21
    * @cowprotocol/sdk-order-book bumped to 0.4.4
    * @cowprotocol/sdk-config bumped to 0.6.2

## [1.6.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-flash-loans-v1.5.12...sdk-flash-loans-v1.6.0) (2025-12-10)


### ✨ Features

* **flash-loans:** support flexible gasLimit options ([#736](https://github.com/cowprotocol/cow-sdk/issues/736)) ([14cbb36](https://github.com/cowprotocol/cow-sdk/commit/14cbb362a68462dddc028d5f5852f038f349daa3))


### 🔧 Miscellaneous

* release main ([#741](https://github.com/cowprotocol/cow-sdk/issues/741)) ([32fb8bb](https://github.com/cowprotocol/cow-sdk/commit/32fb8bbe6b1172c2666f330d0d50cdc2f7c2554f))
* revert not published release ([5facf05](https://github.com/cowprotocol/cow-sdk/commit/5facf05c67121404b7b5aa1e77950961b06eca81))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-trading bumped to 0.7.0
    * @cowprotocol/sdk-order-signing bumped to 0.1.20

## [1.5.12](https://github.com/cowprotocol/cow-sdk/compare/sdk-flash-loans-v1.5.11...sdk-flash-loans-v1.5.12) (2025-12-05)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-app-data bumped to 4.3.5
    * @cowprotocol/sdk-trading bumped to 0.6.3
    * @cowprotocol/sdk-order-signing bumped to 0.1.19
    * @cowprotocol/sdk-order-book bumped to 0.4.3
    * @cowprotocol/sdk-config bumped to 0.6.1

## [1.5.11](https://github.com/cowprotocol/cow-sdk/compare/sdk-flash-loans-v1.5.10...sdk-flash-loans-v1.5.11) (2025-12-04)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-app-data bumped to 4.3.4
    * @cowprotocol/sdk-trading bumped to 0.6.2
    * @cowprotocol/sdk-order-signing bumped to 0.1.18
    * @cowprotocol/sdk-order-book bumped to 0.4.2
    * @cowprotocol/sdk-config bumped to 0.6.0

## [1.5.10](https://github.com/cowprotocol/cow-sdk/compare/sdk-flash-loans-v1.5.9...sdk-flash-loans-v1.5.10) (2025-12-03)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-app-data bumped to 4.3.3
    * @cowprotocol/sdk-trading bumped to 0.6.1
    * @cowprotocol/sdk-order-signing bumped to 0.1.17
    * @cowprotocol/sdk-order-book bumped to 0.4.1
    * @cowprotocol/sdk-config bumped to 0.5.0

## [1.5.9](https://github.com/cowprotocol/cow-sdk/compare/sdk-flash-loans-v1.5.8...sdk-flash-loans-v1.5.9) (2025-12-03)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-app-data bumped to 4.3.2
    * @cowprotocol/sdk-trading bumped to 0.6.0

## [1.5.8](https://github.com/cowprotocol/cow-sdk/compare/sdk-flash-loans-v1.5.7...sdk-flash-loans-v1.5.8) (2025-12-01)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-trading bumped to 0.5.4
    * @cowprotocol/sdk-order-signing bumped to 0.1.16
    * @cowprotocol/sdk-order-book bumped to 0.4.0

## [1.5.7](https://github.com/cowprotocol/cow-sdk/compare/sdk-flash-loans-v1.5.6...sdk-flash-loans-v1.5.7) (2025-11-27)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-trading bumped to 0.5.3
    * @cowprotocol/sdk-order-signing bumped to 0.1.15
    * @cowprotocol/sdk-order-book bumped to 0.3.2

## [1.5.6](https://github.com/cowprotocol/cow-sdk/compare/sdk-flash-loans-v1.5.5...sdk-flash-loans-v1.5.6) (2025-11-27)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-app-data bumped to 4.3.1
    * @cowprotocol/sdk-trading bumped to 0.5.2
    * @cowprotocol/sdk-order-signing bumped to 0.1.14
    * @cowprotocol/sdk-order-book bumped to 0.3.1
    * @cowprotocol/sdk-config bumped to 0.4.1

## [1.5.5](https://github.com/cowprotocol/cow-sdk/compare/sdk-flash-loans-v1.5.4...sdk-flash-loans-v1.5.5) (2025-11-24)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-app-data bumped to 4.3.0
    * @cowprotocol/sdk-trading bumped to 0.5.1
    * @cowprotocol/sdk-order-signing bumped to 0.1.13

## [1.5.4](https://github.com/cowprotocol/cow-sdk/compare/sdk-flash-loans-v1.5.3...sdk-flash-loans-v1.5.4) (2025-11-24)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.4.0
    * @cowprotocol/sdk-app-data bumped to 4.2.0
    * @cowprotocol/sdk-trading bumped to 0.5.0
    * @cowprotocol/sdk-order-signing bumped to 0.1.12
    * @cowprotocol/sdk-order-book bumped to 0.3.0
    * @cowprotocol/sdk-config bumped to 0.4.0
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.3.0
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.3.0
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.0

## [1.5.3](https://github.com/cowprotocol/cow-sdk/compare/sdk-flash-loans-v1.5.2...sdk-flash-loans-v1.5.3) (2025-11-20)


### 🐛 Bug Fixes

* **flash-loans:** add hooksGasLimit parameter ([#691](https://github.com/cowprotocol/cow-sdk/issues/691)) ([32ebb2b](https://github.com/cowprotocol/cow-sdk/commit/32ebb2b2ae1a27e31b3ccc141ccf7ec610db2ed6))

## [1.5.2](https://github.com/cowprotocol/cow-sdk/compare/sdk-flash-loans-v1.5.1...sdk-flash-loans-v1.5.2) (2025-11-17)


### 🐛 Bug Fixes

* pump flashloans sdk version ([#687](https://github.com/cowprotocol/cow-sdk/issues/687)) ([d31fb42](https://github.com/cowprotocol/cow-sdk/commit/d31fb421424ed3df81de09b0e2d36b7023466931))

## [1.5.1](https://github.com/cowprotocol/cow-sdk/compare/sdk-flash-loans-v1.5.0...sdk-flash-loans-v1.5.1) (2025-11-17)


### 🔧 Miscellaneous

* allow to set the factory contract and aave pools in the sdk ([#680](https://github.com/cowprotocol/cow-sdk/issues/680)) ([b90529c](https://github.com/cowprotocol/cow-sdk/commit/b90529cd27fdeb4060bc0a53702df6f8104495b7))

## [1.5.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-flash-loans-v1.4.0...sdk-flash-loans-v1.5.0) (2025-11-13)


### ✨ Features

* **flash-loans:** update smartcontract addresses ([#676](https://github.com/cowprotocol/cow-sdk/issues/676)) ([3d78116](https://github.com/cowprotocol/cow-sdk/commit/3d781167dfe6a02646c546b481f058d2ed0f664f))

## [1.4.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-flash-loans-v1.3.0...sdk-flash-loans-v1.4.0) (2025-11-12)


### ✨ Features

* allow aave sdk to provide the helper addresses in the construct… ([#666](https://github.com/cowprotocol/cow-sdk/issues/666)) ([828ae7d](https://github.com/cowprotocol/cow-sdk/commit/828ae7d120a06b9d550c9f7c1e52bb86f783d0b8))

## [1.3.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-flash-loans-v1.2.1...sdk-flash-loans-v1.3.0) (2025-11-07)


### ✨ Features

* **flash-loans:** support Mainnet, Gnosis, and Base for AAVE ([#657](https://github.com/cowprotocol/cow-sdk/issues/657)) ([c7f2327](https://github.com/cowprotocol/cow-sdk/commit/c7f2327f4672a899c2775dd8ab8d3543ad08cdd6))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-trading bumped to 0.4.6
    * @cowprotocol/sdk-order-signing bumped to 0.1.11

## [1.2.1](https://github.com/cowprotocol/cow-sdk/compare/sdk-flash-loans-v1.2.0...sdk-flash-loans-v1.2.1) (2025-11-05)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-app-data bumped to 4.1.6
    * @cowprotocol/sdk-trading bumped to 0.4.5
    * @cowprotocol/sdk-order-signing bumped to 0.1.10
    * @cowprotocol/sdk-order-book bumped to 0.2.0
    * @cowprotocol/sdk-config bumped to 0.3.0

## [1.2.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-flash-loans-v1.1.3...sdk-flash-loans-v1.2.0) (2025-11-05)


### ✨ Features

* **flash-loans:** add dappId to aave hooks ([#645](https://github.com/cowprotocol/cow-sdk/issues/645)) ([b5312af](https://github.com/cowprotocol/cow-sdk/commit/b5312af11d2b164c125aa899a56ee0b1645ba18f))

## [1.1.3](https://github.com/cowprotocol/cow-sdk/compare/sdk-flash-loans-v1.1.2...sdk-flash-loans-v1.1.3) (2025-11-04)


### 🐛 Bug Fixes

* make adapters hook helpers public ([#639](https://github.com/cowprotocol/cow-sdk/issues/639)) ([f8760ae](https://github.com/cowprotocol/cow-sdk/commit/f8760ae6084f7df729f140f9bea799566c217287))

## [1.1.2](https://github.com/cowprotocol/cow-sdk/compare/sdk-flash-loans-v1.1.1...sdk-flash-loans-v1.1.2) (2025-10-30)


### 🐛 Bug Fixes

* flashloan fee calculation now matches aave's ([#622](https://github.com/cowprotocol/cow-sdk/issues/622)) ([8d11b7f](https://github.com/cowprotocol/cow-sdk/commit/8d11b7fbbc8ff797253f26772a0e5c940286f2d9))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-trading bumped to 0.4.4
    * @cowprotocol/sdk-order-signing bumped to 0.1.9

## [1.1.1](https://github.com/cowprotocol/cow-sdk/compare/sdk-flash-loans-v1.1.0...sdk-flash-loans-v1.1.1) (2025-10-29)


### 🐛 Bug Fixes

* fix lint issues ([#631](https://github.com/cowprotocol/cow-sdk/issues/631)) ([2152be4](https://github.com/cowprotocol/cow-sdk/commit/2152be4f75017f033ca7eba0959d82691cef6ee3))


### 🔧 Miscellaneous

* release main ([#620](https://github.com/cowprotocol/cow-sdk/issues/620)) ([b36394a](https://github.com/cowprotocol/cow-sdk/commit/b36394a2ba38957edb47ffc4451ea6624d66737b))
* revert release ([#634](https://github.com/cowprotocol/cow-sdk/issues/634)) ([fc7bf61](https://github.com/cowprotocol/cow-sdk/commit/fc7bf61444619d4b2c3a3dd55b7ce52c197b1878))
* update debt swap test ([#621](https://github.com/cowprotocol/cow-sdk/issues/621)) ([5e0a66b](https://github.com/cowprotocol/cow-sdk/commit/5e0a66b2d7a8c34adf4dc50e3640f462a1e13188))
* update repay test ([#619](https://github.com/cowprotocol/cow-sdk/issues/619)) ([8c81142](https://github.com/cowprotocol/cow-sdk/commit/8c81142197e0b05c73ac7bf84cb9ccd022171d64))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.3.0
    * @cowprotocol/sdk-app-data bumped to 4.1.5
    * @cowprotocol/sdk-trading bumped to 0.4.3
    * @cowprotocol/sdk-order-signing bumped to 0.1.8
    * @cowprotocol/sdk-order-book bumped to 0.1.4
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.2.0
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.2.0
    * @cowprotocol/sdk-viem-adapter bumped to 0.2.0

## [1.1.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-flash-loans-v1.0.0...sdk-flash-loans-v1.1.0) (2025-10-24)


### ✨ Features

* **flash-loans:** support debtSwap and repayCollateral ([#616](https://github.com/cowprotocol/cow-sdk/issues/616)) ([cdd9f8a](https://github.com/cowprotocol/cow-sdk/commit/cdd9f8a3fdc73be56d727f0ec320c2f11516f778))

## 1.0.0 (2025-10-24)


### ✨ Features

* allow changing backoff and limiter per request ([#208](https://github.com/cowprotocol/cow-sdk/issues/208)) ([ebea5ca](https://github.com/cowprotocol/cow-sdk/commit/ebea5ca0858aeb89ae3e5d5407c8903c3ca5178d))


### 🐛 Bug Fixes

* **trading:** add EIP1271 signature support ([#584](https://github.com/cowprotocol/cow-sdk/issues/584)) ([ca9e834](https://github.com/cowprotocol/cow-sdk/commit/ca9e834e2b0edf8a757e01383b2218d5ecfbe25e))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.2.2
    * @cowprotocol/sdk-app-data bumped to 4.1.4
    * @cowprotocol/sdk-trading bumped to 0.4.2
    * @cowprotocol/sdk-order-signing bumped to 0.1.7
    * @cowprotocol/sdk-order-book bumped to 0.1.3
    * @cowprotocol/sdk-config bumped to 0.2.0
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.1.3
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.1.3
    * @cowprotocol/sdk-viem-adapter bumped to 0.1.3
