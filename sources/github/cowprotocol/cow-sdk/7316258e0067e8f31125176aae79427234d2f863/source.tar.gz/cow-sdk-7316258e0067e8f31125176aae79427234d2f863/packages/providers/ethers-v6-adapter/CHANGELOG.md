# Changelog

## [0.4.18](https://github.com/cowprotocol/cow-sdk/compare/sdk-ethers-v6-adapter-v0.4.17...sdk-ethers-v6-adapter-v0.4.18) (2026-09-29)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.14.2

## [0.4.17](https://github.com/cowprotocol/cow-sdk/compare/sdk-ethers-v6-adapter-v0.4.16...sdk-ethers-v6-adapter-v0.4.17) (2026-09-25)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.14.1

## [0.4.16](https://github.com/cowprotocol/cow-sdk/compare/sdk-ethers-v6-adapter-v0.4.15...sdk-ethers-v6-adapter-v0.4.16) (2026-09-21)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.14.0

## [0.4.15](https://github.com/cowprotocol/cow-sdk/compare/sdk-ethers-v6-adapter-v0.4.14...sdk-ethers-v6-adapter-v0.4.15) (2026-09-18)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.13.1

## [0.4.14](https://github.com/cowprotocol/cow-sdk/compare/sdk-ethers-v6-adapter-v0.4.13...sdk-ethers-v6-adapter-v0.4.14) (2026-09-16)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.13.0

## [0.4.13](https://github.com/cowprotocol/cow-sdk/compare/sdk-ethers-v6-adapter-v0.4.12...sdk-ethers-v6-adapter-v0.4.13) (2026-09-07)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.12.3

## [0.4.12](https://github.com/cowprotocol/cow-sdk/compare/sdk-ethers-v6-adapter-v0.4.11...sdk-ethers-v6-adapter-v0.4.12) (2026-09-04)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.12.2

## [0.4.11](https://github.com/cowprotocol/cow-sdk/compare/sdk-ethers-v6-adapter-v0.4.10...sdk-ethers-v6-adapter-v0.4.11) (2026-07-29)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.12.1

## [0.4.10](https://github.com/cowprotocol/cow-sdk/compare/sdk-ethers-v6-adapter-v0.4.9...sdk-ethers-v6-adapter-v0.4.10) (2026-06-15)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.12.0

## [0.4.9](https://github.com/cowprotocol/cow-sdk/compare/sdk-ethers-v6-adapter-v0.4.8...sdk-ethers-v6-adapter-v0.4.9) (2026-06-08)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.11.2

## [0.4.8](https://github.com/cowprotocol/cow-sdk/compare/sdk-ethers-v6-adapter-v0.4.7...sdk-ethers-v6-adapter-v0.4.8) (2026-06-02)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.11.1

## [0.4.7](https://github.com/cowprotocol/cow-sdk/compare/sdk-ethers-v6-adapter-v0.4.6...sdk-ethers-v6-adapter-v0.4.7) (2026-05-27)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.11.0

## [0.4.6](https://github.com/cowprotocol/cow-sdk/compare/sdk-ethers-v6-adapter-v0.4.5...sdk-ethers-v6-adapter-v0.4.6) (2026-05-22)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.10.3

## [0.4.5](https://github.com/cowprotocol/cow-sdk/compare/sdk-ethers-v6-adapter-v0.4.4...sdk-ethers-v6-adapter-v0.4.5) (2026-05-20)


### 📚 Documentation

* remove info about umbrella sdk ([#874](https://github.com/cowprotocol/cow-sdk/issues/874)) ([bb0280e](https://github.com/cowprotocol/cow-sdk/commit/bb0280e7bfcdd6c2d7b122baf43910d9e4e4299f))

## [0.4.4](https://github.com/cowprotocol/cow-sdk/compare/sdk-ethers-v6-adapter-v0.4.3...sdk-ethers-v6-adapter-v0.4.4) (2026-04-16)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.10.2

## [0.4.3](https://github.com/cowprotocol/cow-sdk/compare/sdk-ethers-v6-adapter-v0.4.2...sdk-ethers-v6-adapter-v0.4.3) (2026-04-14)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.10.1

## [0.4.2](https://github.com/cowprotocol/cow-sdk/compare/sdk-ethers-v6-adapter-v0.4.1...sdk-ethers-v6-adapter-v0.4.2) (2026-04-08)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.10.0

## [0.4.1](https://github.com/cowprotocol/cow-sdk/compare/sdk-ethers-v6-adapter-v0.4.0...sdk-ethers-v6-adapter-v0.4.1) (2026-04-01)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.9.0

## [0.4.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-ethers-v6-adapter-v0.3.14...sdk-ethers-v6-adapter-v0.4.0) (2026-03-17)


### ✨ Features

* use address utils to compare addresses ([#827](https://github.com/cowprotocol/cow-sdk/issues/827)) ([50a66ff](https://github.com/cowprotocol/cow-sdk/commit/50a66ff044f98ce0313c6213e31c83c9028836a1))

## [0.3.14](https://github.com/cowprotocol/cow-sdk/compare/sdk-ethers-v6-adapter-v0.3.13...sdk-ethers-v6-adapter-v0.3.14) (2026-03-17)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.8.2

## [0.3.13](https://github.com/cowprotocol/cow-sdk/compare/sdk-ethers-v6-adapter-v0.3.12...sdk-ethers-v6-adapter-v0.3.13) (2026-03-16)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.8.1

## [0.3.12](https://github.com/cowprotocol/cow-sdk/compare/sdk-ethers-v6-adapter-v0.3.11...sdk-ethers-v6-adapter-v0.3.12) (2026-03-16)


### 🔧 Miscellaneous

* release main ([#826](https://github.com/cowprotocol/cow-sdk/issues/826)) ([baaa708](https://github.com/cowprotocol/cow-sdk/commit/baaa7088ac15b89fb83310e54aa52f09d19132ff))
* release main ([#832](https://github.com/cowprotocol/cow-sdk/issues/832)) ([5dafcb8](https://github.com/cowprotocol/cow-sdk/commit/5dafcb8ec5593250dba1ff6e9fdbf8eb11d974cf))
* revert release ([#833](https://github.com/cowprotocol/cow-sdk/issues/833)) ([0c40a9b](https://github.com/cowprotocol/cow-sdk/commit/0c40a9b3ee828c7ede66576f02e1b571e96140cd))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.8.0

## [0.3.11](https://github.com/cowprotocol/cow-sdk/compare/sdk-ethers-v6-adapter-v0.3.10...sdk-ethers-v6-adapter-v0.3.11) (2026-03-10)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.7.1

## [0.3.10](https://github.com/cowprotocol/cow-sdk/compare/sdk-ethers-v6-adapter-v0.3.9...sdk-ethers-v6-adapter-v0.3.10) (2026-03-04)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.7.0

## [0.3.9](https://github.com/cowprotocol/cow-sdk/compare/sdk-ethers-v6-adapter-v0.3.8...sdk-ethers-v6-adapter-v0.3.9) (2026-03-04)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.6.3

## [0.3.8](https://github.com/cowprotocol/cow-sdk/compare/sdk-ethers-v6-adapter-v0.3.7...sdk-ethers-v6-adapter-v0.3.8) (2026-02-20)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.6.2

## [0.3.7](https://github.com/cowprotocol/cow-sdk/compare/sdk-ethers-v6-adapter-v0.3.6...sdk-ethers-v6-adapter-v0.3.7) (2026-02-18)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.6.1

## [0.3.6](https://github.com/cowprotocol/cow-sdk/compare/sdk-ethers-v6-adapter-v0.3.5...sdk-ethers-v6-adapter-v0.3.6) (2026-02-05)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.6.0

## [0.3.5](https://github.com/cowprotocol/cow-sdk/compare/sdk-ethers-v6-adapter-v0.3.4...sdk-ethers-v6-adapter-v0.3.5) (2026-02-02)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.5.4

## [0.3.4](https://github.com/cowprotocol/cow-sdk/compare/sdk-ethers-v6-adapter-v0.3.3...sdk-ethers-v6-adapter-v0.3.4) (2026-02-02)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.5.3

## [0.3.3](https://github.com/cowprotocol/cow-sdk/compare/sdk-ethers-v6-adapter-v0.3.2...sdk-ethers-v6-adapter-v0.3.3) (2026-01-28)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.5.2

## [0.3.2](https://github.com/cowprotocol/cow-sdk/compare/sdk-ethers-v6-adapter-v0.3.1...sdk-ethers-v6-adapter-v0.3.2) (2026-01-28)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.5.1

## [0.3.1](https://github.com/cowprotocol/cow-sdk/compare/sdk-ethers-v6-adapter-v0.3.0...sdk-ethers-v6-adapter-v0.3.1) (2026-01-19)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.5.0

## [0.3.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-ethers-v6-adapter-v0.2.0...sdk-ethers-v6-adapter-v0.3.0) (2025-11-24)


### ✨ Features

* **bridge:** add NearIntents bridge provider ([#663](https://github.com/cowprotocol/cow-sdk/issues/663)) ([afd63bc](https://github.com/cowprotocol/cow-sdk/commit/afd63bce3765e2adc81b73357e233399111e3595))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.4.0

## [0.2.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-ethers-v6-adapter-v0.1.3...sdk-ethers-v6-adapter-v0.2.0) (2025-10-29)


### ✨ Features

* add from/to fields for receipt ([#629](https://github.com/cowprotocol/cow-sdk/issues/629)) ([3dd3868](https://github.com/cowprotocol/cow-sdk/commit/3dd38682741ac93bfbd9b7d9a4fe79df7283dca0))


### 🔧 Miscellaneous

* release main ([#620](https://github.com/cowprotocol/cow-sdk/issues/620)) ([b36394a](https://github.com/cowprotocol/cow-sdk/commit/b36394a2ba38957edb47ffc4451ea6624d66737b))
* revert release ([#634](https://github.com/cowprotocol/cow-sdk/issues/634)) ([fc7bf61](https://github.com/cowprotocol/cow-sdk/commit/fc7bf61444619d4b2c3a3dd55b7ce52c197b1878))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.3.0

## [0.1.3](https://github.com/cowprotocol/cow-sdk/compare/sdk-ethers-v6-adapter-v0.1.2...sdk-ethers-v6-adapter-v0.1.3) (2025-10-24)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.2.2

## [0.1.2](https://github.com/cowprotocol/cow-sdk/compare/sdk-ethers-v6-adapter-v0.1.1...sdk-ethers-v6-adapter-v0.1.2) (2025-10-08)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.2.1

## [0.1.1](https://github.com/cowprotocol/cow-sdk/compare/sdk-ethers-v6-adapter-v0.1.0...sdk-ethers-v6-adapter-v0.1.1) (2025-10-06)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.2.0

## [0.1.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-ethers-v6-adapter-v0.2.5-beta.0...sdk-ethers-v6-adapter-v0.1.0) (2025-09-17)


### ⚠ BREAKING CHANGES

* release cow-sdk v7

### ✨ Features

* release cow-sdk v7 ([6cd3e57](https://github.com/cowprotocol/cow-sdk/commit/6cd3e573687b1ffdbc0fdcb8cdbb414d88546e38))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.1.0

## [0.2.5-beta.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-ethers-v6-adapter-v0.2.4-beta.0...sdk-ethers-v6-adapter-v0.2.5-beta.0) (2025-09-17)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.5.0-beta.0

## [0.2.4-beta.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-ethers-v6-adapter-v0.2.3-beta.0...sdk-ethers-v6-adapter-v0.2.4-beta.0) (2025-09-16)


### 🐛 Bug Fixes

* rename ether to ethers ([#504](https://github.com/cowprotocol/cow-sdk/issues/504)) ([eaf2705](https://github.com/cowprotocol/cow-sdk/commit/eaf2705f269352d3bc2908eb3335ff56ef426823))

## [0.2.3-beta.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-ethers-v6-adapter-v0.2.2-beta.0...sdk-ethers-v6-adapter-v0.2.3-beta.0) (2025-09-16)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.4.0-beta.0

## [0.2.2-beta.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-ethers-v6-adapter-v0.2.1-beta.0...sdk-ethers-v6-adapter-v0.2.2-beta.0) (2025-09-11)


### 🔧 Miscellaneous

* release main ([#488](https://github.com/cowprotocol/cow-sdk/issues/488)) ([6344fa6](https://github.com/cowprotocol/cow-sdk/commit/6344fa619465e6f94637677823a18646f06fa7c9))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.3.0-beta.0

## [0.2.1-beta.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-ethers-v6-adapter-v0.2.0-beta.0...sdk-ethers-v6-adapter-v0.2.1-beta.0) (2025-09-01)


### 🐛 Bug Fixes

* improve unknown/any types ([#443](https://github.com/cowprotocol/cow-sdk/issues/443)) ([e6b8a40](https://github.com/cowprotocol/cow-sdk/commit/e6b8a40578583cf6d1ecd208434782422f308ef0))

## [0.2.0-beta.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-ethers-v6-adapter-v0.1.0-beta.0...sdk-ethers-v6-adapter-v0.2.0-beta.0) (2025-08-28)


### ✨ Features

* add new order-signing features to adapters ([555d55f](https://github.com/cowprotocol/cow-sdk/commit/555d55ff353376c11deef498b76795d5e7dcabca))
* allow changing backoff and limiter per request ([#208](https://github.com/cowprotocol/cow-sdk/issues/208)) ([ebea5ca](https://github.com/cowprotocol/cow-sdk/commit/ebea5ca0858aeb89ae3e5d5407c8903c3ca5178d))
* **cow-shed:** add estimateGas method to SignerAdapters ([fbb626a](https://github.com/cowprotocol/cow-sdk/commit/fbb626a0f88f6cb206432b4233b2d7d1e7cd4ad4))
* **cow-shed:** refact on common and contract-ts ([4be05aa](https://github.com/cowprotocol/cow-sdk/commit/4be05aa7a376fbc7d2ed5b2d2b6b68e3630b9c59))
* enhance adapters and utils with composable features ([8691d42](https://github.com/cowprotocol/cow-sdk/commit/8691d42b8076c7d240a97e6808902f6d8742bcd3))
* implement adapters for ethers v5, ethers v6, and viem ([1231f7c](https://github.com/cowprotocol/cow-sdk/commit/1231f7c1809fd497d15e8945b880a9c3da6fa6b4))
* **lib-agnostic:** add a basic example of tradingSDK with Ethers6 ([#438](https://github.com/cowprotocol/cow-sdk/issues/438)) ([4808e41](https://github.com/cowprotocol/cow-sdk/commit/4808e41a9a08eb6ec091d46b46803f4398fae5a1))
* **lib-agnostic:** migrate latest Bridging changes ([#426](https://github.com/cowprotocol/cow-sdk/issues/426)) ([2359d9b](https://github.com/cowprotocol/cow-sdk/commit/2359d9b903e80ae5bab0cdb92d8cf52ae250da36))
* **lib-agnostic:** migrate latest SDK changes ([#427](https://github.com/cowprotocol/cow-sdk/issues/427)) ([323bab6](https://github.com/cowprotocol/cow-sdk/commit/323bab61eb5adeb4a58bc15e25ffb29d2e1afcbf))
* **sdk-agnostic-lib:** create app data package ([#327](https://github.com/cowprotocol/cow-sdk/issues/327)) ([8b61261](https://github.com/cowprotocol/cow-sdk/commit/8b612615bc280dee2e5f4767794bc03f590d4764))
* **sdk-agnostic-lib:** create cow trading package ([#368](https://github.com/cowprotocol/cow-sdk/issues/368)) ([0a4534a](https://github.com/cowprotocol/cow-sdk/commit/0a4534aababce4f5d8bab991cd6ae9f51842d719))
* **sdk-agnostic-lib:** Create weiroll package ([#371](https://github.com/cowprotocol/cow-sdk/issues/371)) ([8f6a2e1](https://github.com/cowprotocol/cow-sdk/commit/8f6a2e16e5e7a43a5afc43cf5faab174be916b2e))
* update adapters with new contracts-ts features ([aadd9a7](https://github.com/cowprotocol/cow-sdk/commit/aadd9a74771876c21339bfb4731654656a325d96))
* update adapters with new contracts-ts features ([fc94704](https://github.com/cowprotocol/cow-sdk/commit/fc947043316a603e64f3c3d4b07178169d21a9a6))


### 🐛 Bug Fixes

* **cow-shed:** fix adapters - estimateGas  and encodeAbi ([76ab995](https://github.com/cowprotocol/cow-sdk/commit/76ab995635247e63213dafb50ff462334977cc6d))
* **lib-agnostic:** add setProvider() method to adapters ([#432](https://github.com/cowprotocol/cow-sdk/issues/432)) ([64c0ea9](https://github.com/cowprotocol/cow-sdk/commit/64c0ea94d802aa167b978ae0859353d801de0911))


### 🔧 Miscellaneous

* **sdk-agnostic-lib:** improve scripts and types ([#407](https://github.com/cowprotocol/cow-sdk/issues/407)) ([c4b5e08](https://github.com/cowprotocol/cow-sdk/commit/c4b5e086ce46086e9430d5f03ed330502349fbf3))
* **sdk-agnostic-lib:** merge multiple PRs to avoid conflicts and speed up base branch sync ([#354](https://github.com/cowprotocol/cow-sdk/issues/354)) ([55d3068](https://github.com/cowprotocol/cow-sdk/commit/55d3068c52217dd2618d8c180ab4fed8c9334c72))
