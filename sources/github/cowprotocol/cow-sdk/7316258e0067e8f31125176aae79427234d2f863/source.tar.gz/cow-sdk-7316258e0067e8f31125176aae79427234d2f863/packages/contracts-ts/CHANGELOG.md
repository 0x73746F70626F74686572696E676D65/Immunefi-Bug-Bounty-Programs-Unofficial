# Changelog

## [3.7.2](https://github.com/cowprotocol/cow-sdk/compare/sdk-contracts-ts-v3.7.1...sdk-contracts-ts-v3.7.2) (2026-09-29)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.14.2
    * @cowprotocol/sdk-config bumped to 2.7.2
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.4.18
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.4.18
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.33

## [3.7.1](https://github.com/cowprotocol/cow-sdk/compare/sdk-contracts-ts-v3.7.0...sdk-contracts-ts-v3.7.1) (2026-09-25)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.14.1
    * @cowprotocol/sdk-config bumped to 2.7.1
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.4.17
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.4.17
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.32

## [3.7.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-contracts-ts-v3.6.0...sdk-contracts-ts-v3.7.0) (2026-09-21)


### ✨ Features

* **solana:** use cow protocol quotes ([#1023](https://github.com/cowprotocol/cow-sdk/issues/1023)) ([dc76c98](https://github.com/cowprotocol/cow-sdk/commit/dc76c98475855d7d291c762c664050aa06dd12fb))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.14.0
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.4.16
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.4.16
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.31

## [3.6.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-contracts-ts-v3.5.2...sdk-contracts-ts-v3.6.0) (2026-09-18)


### ✨ Features

* **solana:** override appData ([#1018](https://github.com/cowprotocol/cow-sdk/issues/1018)) ([0c2a8cf](https://github.com/cowprotocol/cow-sdk/commit/0c2a8cf967cc2f38a68135dca09a1696e0f42ba6))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.13.1
    * @cowprotocol/sdk-config bumped to 2.7.0
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.4.15
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.4.15
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.30

## [3.5.2](https://github.com/cowprotocol/cow-sdk/compare/sdk-contracts-ts-v3.5.1...sdk-contracts-ts-v3.5.2) (2026-09-16)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.13.0
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.4.14
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.4.14
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.29

## [3.5.1](https://github.com/cowprotocol/cow-sdk/compare/sdk-contracts-ts-v3.5.0...sdk-contracts-ts-v3.5.1) (2026-09-07)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.12.3
    * @cowprotocol/sdk-config bumped to 2.6.0
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.4.13
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.4.13
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.28

## [3.5.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-contracts-ts-v3.4.0...sdk-contracts-ts-v3.5.0) (2026-09-04)


### ✨ Features

* trading sdk for solana ([#973](https://github.com/cowprotocol/cow-sdk/issues/973)) ([60b39b9](https://github.com/cowprotocol/cow-sdk/commit/60b39b93883889d794f02138b8dbef74f7dc6c5b))


### 🔧 Miscellaneous

* split integration tests ([#978](https://github.com/cowprotocol/cow-sdk/issues/978)) ([72bbc6f](https://github.com/cowprotocol/cow-sdk/commit/72bbc6f8f88ce66597f36cd08d391ab79e342843))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.12.2
    * @cowprotocol/sdk-config bumped to 2.5.0
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.4.12
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.4.12
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.27

## [3.4.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-contracts-ts-v3.3.3...sdk-contracts-ts-v3.4.0) (2026-09-01)


### ✨ Features

* use internal indexer ([#974](https://github.com/cowprotocol/cow-sdk/issues/974)) ([455e44b](https://github.com/cowprotocol/cow-sdk/commit/455e44b5532bc197e66f8b81828bf7fc6608b0d2))


### 🔧 Miscellaneous

* fix contracts-ts tests ([#964](https://github.com/cowprotocol/cow-sdk/issues/964)) ([8a756e8](https://github.com/cowprotocol/cow-sdk/commit/8a756e813dd51dcaa815278f71f8880ddc5044f2))

## [3.3.3](https://github.com/cowprotocol/cow-sdk/compare/sdk-contracts-ts-v3.3.2...sdk-contracts-ts-v3.3.3) (2026-07-29)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.12.1
    * @cowprotocol/sdk-config bumped to 2.4.0
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.4.11
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.4.11
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.26

## [3.3.2](https://github.com/cowprotocol/cow-sdk/compare/sdk-contracts-ts-v3.3.1...sdk-contracts-ts-v3.3.2) (2026-07-28)


### 🐛 Bug Fixes

* **bridge:** fix bridge fee in buy token ([#947](https://github.com/cowprotocol/cow-sdk/issues/947)) ([fc60e04](https://github.com/cowprotocol/cow-sdk/commit/fc60e04b2c23677217b1811f37fd1b4bfba4a03a))

## [3.3.1](https://github.com/cowprotocol/cow-sdk/compare/sdk-contracts-ts-v3.3.0...sdk-contracts-ts-v3.3.1) (2026-07-22)


### 🐛 Bug Fixes

* bump version ([#940](https://github.com/cowprotocol/cow-sdk/issues/940)) ([ffaa067](https://github.com/cowprotocol/cow-sdk/commit/ffaa067644c5e3ea28febfff8e1a5d79e82254c3))

## [3.3.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-contracts-ts-v3.2.1...sdk-contracts-ts-v3.3.0) (2026-07-22)


### ✨ Features

* **bridge:** support CCTP v2 in Bungee ([#933](https://github.com/cowprotocol/cow-sdk/issues/933)) ([fcb0d26](https://github.com/cowprotocol/cow-sdk/commit/fcb0d2630b93d826474245a7fdf26fb8bccf6d34))


### Dependencies

* The following workspace dependencies were updated
  * devDependencies
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.25

## [3.2.1](https://github.com/cowprotocol/cow-sdk/compare/sdk-contracts-ts-v3.2.0...sdk-contracts-ts-v3.2.1) (2026-06-23)


### 🐛 Bug Fixes

* near-bridging ([#908](https://github.com/cowprotocol/cow-sdk/issues/908)) ([b4d471c](https://github.com/cowprotocol/cow-sdk/commit/b4d471c8ebc7646d00bd6f6fd097b0692ac08f40))

## [3.2.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-contracts-ts-v3.1.2...sdk-contracts-ts-v3.2.0) (2026-06-15)


### ✨ Features

* per-package test coverage badges, updated in CI ([#895](https://github.com/cowprotocol/cow-sdk/issues/895)) ([c73246c](https://github.com/cowprotocol/cow-sdk/commit/c73246cc52c4fc79b2628b7c5f580695fd3dc1e2))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.12.0
    * @cowprotocol/sdk-config bumped to 2.3.1
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.4.10
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.4.10
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.24

## [3.1.2](https://github.com/cowprotocol/cow-sdk/compare/sdk-contracts-ts-v3.1.1...sdk-contracts-ts-v3.1.2) (2026-06-08)


### 🐛 Bug Fixes

* **app-data:** bump maxVolumeBps cap ([#896](https://github.com/cowprotocol/cow-sdk/issues/896)) ([1e98a71](https://github.com/cowprotocol/cow-sdk/commit/1e98a71dbccc75c13dd185bb8d75b8f92f6ecc8f))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.11.2
    * @cowprotocol/sdk-config bumped to 2.3.0
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.4.9
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.4.9
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.23

## [3.1.1](https://github.com/cowprotocol/cow-sdk/compare/sdk-contracts-ts-v3.1.0...sdk-contracts-ts-v3.1.1) (2026-06-02)


### 🐛 Bug Fixes

* trigger release please ([#890](https://github.com/cowprotocol/cow-sdk/issues/890)) ([cc11990](https://github.com/cowprotocol/cow-sdk/commit/cc11990047e4d77a450582a84a07a453f4a7ccc8))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.11.1
    * @cowprotocol/sdk-config bumped to 2.2.1
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.4.8
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.4.8
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.22

## [3.1.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-contracts-ts-v3.0.3...sdk-contracts-ts-v3.1.0) (2026-05-27)


### ✨ Features

* move solana to supported chain id ([#873](https://github.com/cowprotocol/cow-sdk/issues/873)) ([da8a7c2](https://github.com/cowprotocol/cow-sdk/commit/da8a7c24cd07afcd465199844c480ebe3e81383d))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.11.0
    * @cowprotocol/sdk-config bumped to 2.2.0
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.4.7
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.4.7
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.21

## [3.0.3](https://github.com/cowprotocol/cow-sdk/compare/sdk-contracts-ts-v3.0.2...sdk-contracts-ts-v3.0.3) (2026-05-22)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.10.3
    * @cowprotocol/sdk-config bumped to 2.1.0
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.4.6
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.4.6
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.20

## [3.0.2](https://github.com/cowprotocol/cow-sdk/compare/sdk-contracts-ts-v3.0.1...sdk-contracts-ts-v3.0.2) (2026-05-20)


### Dependencies

* The following workspace dependencies were updated
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.4.5
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.4.5
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.19

## [3.0.1](https://github.com/cowprotocol/cow-sdk/compare/sdk-contracts-ts-v3.0.0...sdk-contracts-ts-v3.0.1) (2026-04-20)


### 🐛 Bug Fixes

* **bridge:** make sender optional in Bungee events response ([#865](https://github.com/cowprotocol/cow-sdk/issues/865)) ([b5eba89](https://github.com/cowprotocol/cow-sdk/commit/b5eba898a3173b5ca0a449f0e50d4b871da303c6))

## [3.0.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-contracts-ts-v2.5.0...sdk-contracts-ts-v3.0.0) (2026-04-16)


### ⚠ BREAKING CHANGES

* bring cow.fi back ([#863](https://github.com/cowprotocol/cow-sdk/issues/863))

### ✨ Features

* bring cow.fi back ([#863](https://github.com/cowprotocol/cow-sdk/issues/863)) ([d607fd2](https://github.com/cowprotocol/cow-sdk/commit/d607fd2cfbc93ace39de04f3a7870f723fdd9b21))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.10.2
    * @cowprotocol/sdk-config bumped to 2.0.0
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.4.4
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.4.4
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.18

## [2.5.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-contracts-ts-v2.4.0...sdk-contracts-ts-v2.5.0) (2026-04-14)


### ✨ Features

* migrate to cow.finance domain ([#860](https://github.com/cowprotocol/cow-sdk/issues/860)) ([a4e7633](https://github.com/cowprotocol/cow-sdk/commit/a4e76333b7a276baec5c977f44b15498550d8e50))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.10.1
    * @cowprotocol/sdk-config bumped to 1.2.0
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.4.3
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.4.3
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.17

## [2.4.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-contracts-ts-v2.3.0...sdk-contracts-ts-v2.4.0) (2026-04-08)


### ✨ Features

* expose address regular expressions ([#858](https://github.com/cowprotocol/cow-sdk/issues/858)) ([1747364](https://github.com/cowprotocol/cow-sdk/commit/17473645636178cb876402d893d6d18a08b477c3))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.10.0
    * @cowprotocol/sdk-config bumped to 1.1.3
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.4.2
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.4.2
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.16

## [2.3.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-contracts-ts-v2.2.0...sdk-contracts-ts-v2.3.0) (2026-04-01)


### ✨ Features

* add sol/btc supports for NEAR ([#844](https://github.com/cowprotocol/cow-sdk/issues/844)) ([9c4ea35](https://github.com/cowprotocol/cow-sdk/commit/9c4ea35eed827bb36eee216fa0a53ed8b44f1756))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.9.0
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.4.1
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.4.1
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.15

## [2.2.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-contracts-ts-v2.1.2...sdk-contracts-ts-v2.2.0) (2026-03-17)


### ✨ Features

* use address utils to compare addresses ([#827](https://github.com/cowprotocol/cow-sdk/issues/827)) ([50a66ff](https://github.com/cowprotocol/cow-sdk/commit/50a66ff044f98ce0313c6213e31c83c9028836a1))


### Dependencies

* The following workspace dependencies were updated
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.4.0
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.4.0

## [2.1.2](https://github.com/cowprotocol/cow-sdk/compare/sdk-contracts-ts-v2.1.1...sdk-contracts-ts-v2.1.2) (2026-03-17)


### 🐛 Bug Fixes

* use pnpm trusted publishing ([#841](https://github.com/cowprotocol/cow-sdk/issues/841)) ([1885b6f](https://github.com/cowprotocol/cow-sdk/commit/1885b6fa2a006670e3bb51a2ac8b60ed9c157eba))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.8.2
    * @cowprotocol/sdk-config bumped to 1.1.2
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.3.14
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.3.14
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.14

## [2.1.1](https://github.com/cowprotocol/cow-sdk/compare/sdk-contracts-ts-v2.1.0...sdk-contracts-ts-v2.1.1) (2026-03-16)


### 🐛 Bug Fixes

* use standard npm publishing ([#839](https://github.com/cowprotocol/cow-sdk/issues/839)) ([b2e2966](https://github.com/cowprotocol/cow-sdk/commit/b2e2966dbe96b7e20880af966e6e6024055d2845))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.8.1
    * @cowprotocol/sdk-config bumped to 1.1.1
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.3.13
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.3.13
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.13

## [2.1.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-contracts-ts-v2.0.0...sdk-contracts-ts-v2.1.0) (2026-03-16)


### ✨ Features

* update settlement and vault relayer contracts on staging ([#807](https://github.com/cowprotocol/cow-sdk/issues/807)) ([0f9a03e](https://github.com/cowprotocol/cow-sdk/commit/0f9a03e6bfa3468630e46735f7583618ae711b73))


### 🐛 Bug Fixes

* update contracts pck version ([#831](https://github.com/cowprotocol/cow-sdk/issues/831)) ([79e0904](https://github.com/cowprotocol/cow-sdk/commit/79e0904e65f0e019f478f1b46e094637f7a763d9))


### 🔧 Miscellaneous

* release main ([#826](https://github.com/cowprotocol/cow-sdk/issues/826)) ([baaa708](https://github.com/cowprotocol/cow-sdk/commit/baaa7088ac15b89fb83310e54aa52f09d19132ff))
* release main ([#832](https://github.com/cowprotocol/cow-sdk/issues/832)) ([5dafcb8](https://github.com/cowprotocol/cow-sdk/commit/5dafcb8ec5593250dba1ff6e9fdbf8eb11d974cf))
* revert release ([#833](https://github.com/cowprotocol/cow-sdk/issues/833)) ([0c40a9b](https://github.com/cowprotocol/cow-sdk/commit/0c40a9b3ee828c7ede66576f02e1b571e96140cd))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.8.0
    * @cowprotocol/sdk-config bumped to 1.1.0
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.3.12
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.3.12
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.12

## [2.0.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-contracts-ts-v1.8.0...sdk-contracts-ts-v2.0.0) (2026-03-10)


### ⚠ BREAKING CHANGES

* **chains:** Remove support for Lens.

### ✨ Features

* **chains:** Remove Lens ([#818](https://github.com/cowprotocol/cow-sdk/issues/818)) ([e8c74a0](https://github.com/cowprotocol/cow-sdk/commit/e8c74a078e5940901591652164af7b2ffb7b1fa6))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.7.1
    * @cowprotocol/sdk-config bumped to 1.0.0
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.3.11
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.3.11
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.11

## [1.8.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-contracts-ts-v1.7.0...sdk-contracts-ts-v1.8.0) (2026-03-04)


### ✨ Features

* Add non-evm chains types & guards & address validators  ([#792](https://github.com/cowprotocol/cow-sdk/issues/792)) ([b4b6047](https://github.com/cowprotocol/cow-sdk/commit/b4b6047889190f668f6409aeee7079ba6095f9ae))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.7.0
    * @cowprotocol/sdk-config bumped to 0.10.0
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.3.10
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.3.10
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.10

## [1.7.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-contracts-ts-v1.6.1...sdk-contracts-ts-v1.7.0) (2026-03-04)


### ✨ Features

* add API endpoints for partners ([#809](https://github.com/cowprotocol/cow-sdk/issues/809)) ([59900e8](https://github.com/cowprotocol/cow-sdk/commit/59900e854a336e294ec881bd70bb13e579ff48ec))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.6.3
    * @cowprotocol/sdk-config bumped to 0.9.0
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.3.9
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.3.9
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.9

## [1.6.1](https://github.com/cowprotocol/cow-sdk/compare/sdk-contracts-ts-v1.6.0...sdk-contracts-ts-v1.6.1) (2026-02-20)


### 🐛 Bug Fixes

* **networks:** remove deprecated network check/error from trading sdk ([#804](https://github.com/cowprotocol/cow-sdk/issues/804)) ([210d26e](https://github.com/cowprotocol/cow-sdk/commit/210d26e556fd79c8a3ac7b8f45f33e766ade4e18))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.6.2
    * @cowprotocol/sdk-config bumped to 0.8.1
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.3.8
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.3.8
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.8

## [1.6.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-contracts-ts-v1.5.0...sdk-contracts-ts-v1.6.0) (2026-02-18)


### ✨ Features

* **deprecated-chains:** add isDeprecated flag and mark Lens as such ([#801](https://github.com/cowprotocol/cow-sdk/issues/801)) ([e0663c6](https://github.com/cowprotocol/cow-sdk/commit/e0663c69c0b5d92bae45570f27105d6cfd04b96a))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.6.1
    * @cowprotocol/sdk-config bumped to 0.8.0
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.3.7
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.3.7
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.7

## [1.5.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-contracts-ts-v1.4.2...sdk-contracts-ts-v1.5.0) (2026-02-05)


### ✨ Features

* move address utils ([#795](https://github.com/cowprotocol/cow-sdk/issues/795)) ([d18212c](https://github.com/cowprotocol/cow-sdk/commit/d18212c868ca2c16525a530f7914c9440f147414))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.6.0
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.3.6
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.3.6
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.6

## [1.4.2](https://github.com/cowprotocol/cow-sdk/compare/sdk-contracts-ts-v1.4.1...sdk-contracts-ts-v1.4.2) (2026-02-02)


### 🔧 Miscellaneous

* revert revert Ink network ([#789](https://github.com/cowprotocol/cow-sdk/issues/789)) ([a00dbbd](https://github.com/cowprotocol/cow-sdk/commit/a00dbbd6a26238bcee2d4452487d16551560c59f))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.5.4
    * @cowprotocol/sdk-config bumped to 0.7.3
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.3.5
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.3.5
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.5

## [1.4.1](https://github.com/cowprotocol/cow-sdk/compare/sdk-contracts-ts-v1.4.0...sdk-contracts-ts-v1.4.1) (2026-02-02)


### 🐛 Bug Fixes

* support decimals in protocolFeeBps ([#787](https://github.com/cowprotocol/cow-sdk/issues/787)) ([f53ae65](https://github.com/cowprotocol/cow-sdk/commit/f53ae65931d85e354779767ed67e0e4df944a2bc))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.5.3
    * @cowprotocol/sdk-config bumped to 0.7.2
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.3.4
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.3.4
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.4

## [1.4.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-contracts-ts-v1.3.0...sdk-contracts-ts-v1.4.0) (2026-01-28)


### ✨ Features

* allow new code property in referrer schema ([#774](https://github.com/cowprotocol/cow-sdk/issues/774)) ([2b648b6](https://github.com/cowprotocol/cow-sdk/commit/2b648b6a1db03fd34002c49572d8e8e556d03593))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.5.2
    * @cowprotocol/sdk-config bumped to 0.7.1
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.3.3
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.3.3
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.3

## [1.3.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-contracts-ts-v1.2.0...sdk-contracts-ts-v1.3.0) (2026-01-28)


### ✨ Features

* **ink:** reapply "feat/COW-163: Add Ink network ([#781](https://github.com/cowprotocol/cow-sdk/issues/781))" ([7c23332](https://github.com/cowprotocol/cow-sdk/commit/7c23332dac4f8c91d5f75ae68297906e20f20362))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.5.1
    * @cowprotocol/sdk-config bumped to 0.7.0
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.3.2
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.3.2
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.2

## [1.2.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-contracts-ts-v1.1.1...sdk-contracts-ts-v1.2.0) (2026-01-22)


### ✨ Features

* **bridge:** add a flag to control intermediate=sell token ([#777](https://github.com/cowprotocol/cow-sdk/issues/777)) ([588dffa](https://github.com/cowprotocol/cow-sdk/commit/588dffaf418b8220293fe803186e3801597282d0))

## [1.1.1](https://github.com/cowprotocol/cow-sdk/compare/sdk-contracts-ts-v1.1.0...sdk-contracts-ts-v1.1.1) (2026-01-21)


### 🐛 Bug Fixes

* add optional apiKey for NearIntentsBridgeProvider ([#775](https://github.com/cowprotocol/cow-sdk/issues/775)) ([7546a4c](https://github.com/cowprotocol/cow-sdk/commit/7546a4c75fe43b5ee8381a45eb6608d5e8593436))

## [1.1.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-contracts-ts-v1.0.0...sdk-contracts-ts-v1.1.0) (2026-01-19)


### ✨ Features

* **bridge:** allow sell token as intermediate token ([#768](https://github.com/cowprotocol/cow-sdk/issues/768)) ([8c367ac](https://github.com/cowprotocol/cow-sdk/commit/8c367ac704ad10003618c8916e32529c5c9eb815))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.5.0
    * @cowprotocol/sdk-config bumped to 0.6.3
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.3.1
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.3.1
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.1

## [1.0.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-contracts-ts-v0.8.1...sdk-contracts-ts-v1.0.0) (2025-12-19)


### ⚠ BREAKING CHANGES

* **bridge:** split swap and bridge slippages ([#750](https://github.com/cowprotocol/cow-sdk/issues/750))

### ✨ Features

* **bridge:** split swap and bridge slippages ([#750](https://github.com/cowprotocol/cow-sdk/issues/750)) ([3ae7b57](https://github.com/cowprotocol/cow-sdk/commit/3ae7b574d1215ae598ec0a519ec003a9f21b7a7f))

## [0.8.1](https://github.com/cowprotocol/cow-sdk/compare/sdk-contracts-ts-v0.8.0...sdk-contracts-ts-v0.8.1) (2025-12-11)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-config bumped to 0.6.2

## [0.8.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-contracts-ts-v0.7.4...sdk-contracts-ts-v0.8.0) (2025-12-10)


### ✨ Features

* **bridge:** determine intermediate token ([#738](https://github.com/cowprotocol/cow-sdk/issues/738)) ([381e885](https://github.com/cowprotocol/cow-sdk/commit/381e885d398623cfd731b439e7e62e8b863736c8))


### 🔧 Miscellaneous

* release main ([#741](https://github.com/cowprotocol/cow-sdk/issues/741)) ([32fb8bb](https://github.com/cowprotocol/cow-sdk/commit/32fb8bbe6b1172c2666f330d0d50cdc2f7c2554f))
* revert not published release ([5facf05](https://github.com/cowprotocol/cow-sdk/commit/5facf05c67121404b7b5aa1e77950961b06eca81))

## [0.7.4](https://github.com/cowprotocol/cow-sdk/compare/sdk-contracts-ts-v0.7.3...sdk-contracts-ts-v0.7.4) (2025-12-05)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-config bumped to 0.6.1

## [0.7.3](https://github.com/cowprotocol/cow-sdk/compare/sdk-contracts-ts-v0.7.2...sdk-contracts-ts-v0.7.3) (2025-12-04)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-config bumped to 0.6.0

## [0.7.2](https://github.com/cowprotocol/cow-sdk/compare/sdk-contracts-ts-v0.7.1...sdk-contracts-ts-v0.7.2) (2025-12-03)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-config bumped to 0.5.0

## [0.7.1](https://github.com/cowprotocol/cow-sdk/compare/sdk-contracts-ts-v0.7.0...sdk-contracts-ts-v0.7.1) (2025-11-27)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-config bumped to 0.4.1

## [0.7.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-contracts-ts-v0.6.0...sdk-contracts-ts-v0.7.0) (2025-11-24)


### ✨ Features

* **bridge:** add quote id and signature metadata ([#701](https://github.com/cowprotocol/cow-sdk/issues/701)) ([35a25a7](https://github.com/cowprotocol/cow-sdk/commit/35a25a7fcc2724073355b3dba4b8f6d3b7419032))

## [0.6.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-contracts-ts-v0.5.0...sdk-contracts-ts-v0.6.0) (2025-11-24)


### ✨ Features

* **bridge:** support Near bridge provider ([#642](https://github.com/cowprotocol/cow-sdk/issues/642)) ([c7d8633](https://github.com/cowprotocol/cow-sdk/commit/c7d86335601cfd772d72dfe65a0e941ce916769a))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.4.0
    * @cowprotocol/sdk-config bumped to 0.4.0
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.3.0
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.3.0
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.0

## [0.5.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-contracts-ts-v0.4.4...sdk-contracts-ts-v0.5.0) (2025-11-07)


### ✨ Features

* **flash-loans:** support Mainnet, Gnosis, and Base for AAVE ([#657](https://github.com/cowprotocol/cow-sdk/issues/657)) ([c7f2327](https://github.com/cowprotocol/cow-sdk/commit/c7f2327f4672a899c2775dd8ab8d3543ad08cdd6))

## [0.4.4](https://github.com/cowprotocol/cow-sdk/compare/sdk-contracts-ts-v0.4.3...sdk-contracts-ts-v0.4.4) (2025-11-05)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-config bumped to 0.3.0

## [0.4.3](https://github.com/cowprotocol/cow-sdk/compare/sdk-contracts-ts-v0.4.2...sdk-contracts-ts-v0.4.3) (2025-10-30)


### 🐛 Bug Fixes

* flashloan fee calculation now matches aave's ([#622](https://github.com/cowprotocol/cow-sdk/issues/622)) ([8d11b7f](https://github.com/cowprotocol/cow-sdk/commit/8d11b7fbbc8ff797253f26772a0e5c940286f2d9))

## [0.4.2](https://github.com/cowprotocol/cow-sdk/compare/sdk-contracts-ts-v0.4.1...sdk-contracts-ts-v0.4.2) (2025-10-29)


### 🔧 Miscellaneous

* release main ([#620](https://github.com/cowprotocol/cow-sdk/issues/620)) ([b36394a](https://github.com/cowprotocol/cow-sdk/commit/b36394a2ba38957edb47ffc4451ea6624d66737b))
* revert release ([#634](https://github.com/cowprotocol/cow-sdk/issues/634)) ([fc7bf61](https://github.com/cowprotocol/cow-sdk/commit/fc7bf61444619d4b2c3a3dd55b7ce52c197b1878))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.3.0
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.2.0
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.2.0
    * @cowprotocol/sdk-viem-adapter bumped to 0.2.0

## [0.4.1](https://github.com/cowprotocol/cow-sdk/compare/sdk-contracts-ts-v0.4.0...sdk-contracts-ts-v0.4.1) (2025-10-24)


### 🐛 Bug Fixes

* **trading:** add EIP1271 signature support ([#584](https://github.com/cowprotocol/cow-sdk/issues/584)) ([ca9e834](https://github.com/cowprotocol/cow-sdk/commit/ca9e834e2b0edf8a757e01383b2218d5ecfbe25e))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.2.2
    * @cowprotocol/sdk-config bumped to 0.2.0
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.1.3
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.1.3
    * @cowprotocol/sdk-viem-adapter bumped to 0.1.3

## [0.4.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-contracts-ts-v0.3.1...sdk-contracts-ts-v0.4.0) (2025-10-15)


### ✨ Features

* **trading:** add validTo parameter to getQuote ([#576](https://github.com/cowprotocol/cow-sdk/issues/576)) ([fcf4258](https://github.com/cowprotocol/cow-sdk/commit/fcf425806044c0ea8b83cfb4116d2f7fb9fcc6e0))


### 🐛 Bug Fixes

* **app-data:** fix typos and ids in schemas ([#586](https://github.com/cowprotocol/cow-sdk/issues/586)) ([5a4461a](https://github.com/cowprotocol/cow-sdk/commit/5a4461a2a171689db04f7c805c9e2c835bbd36dd))

## [0.3.1](https://github.com/cowprotocol/cow-sdk/compare/sdk-contracts-ts-v0.3.0...sdk-contracts-ts-v0.3.1) (2025-10-08)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.2.1
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.1.2
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.1.2
    * @cowprotocol/sdk-viem-adapter bumped to 0.1.2

## [0.3.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-contracts-ts-v0.2.1...sdk-contracts-ts-v0.3.0) (2025-10-06)


### ✨ Features

* **trading:** use suggested slippage from BFF ([#546](https://github.com/cowprotocol/cow-sdk/issues/546)) ([b6a59c7](https://github.com/cowprotocol/cow-sdk/commit/b6a59c780fbfb0f2e840276fe905b2efd810805c))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.2.0
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.1.1
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.1.1
    * @cowprotocol/sdk-viem-adapter bumped to 0.1.1

## [0.2.1](https://github.com/cowprotocol/cow-sdk/compare/sdk-contracts-ts-v0.2.0...sdk-contracts-ts-v0.2.1) (2025-09-24)


### 🐛 Bug Fixes

* **bridge:** multi-quote strategies should not swallow BridgeProviderQuoteError ([#533](https://github.com/cowprotocol/cow-sdk/issues/533)) ([7789699](https://github.com/cowprotocol/cow-sdk/commit/77896999aa2140b70cd2919ede279eb7ebcf0b7b))

## [0.2.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-contracts-ts-v0.1.1...sdk-contracts-ts-v0.2.0) (2025-09-23)


### ✨ Features

* **bridge:** make multi-quote method progressive ([#526](https://github.com/cowprotocol/cow-sdk/issues/526)) ([27536c6](https://github.com/cowprotocol/cow-sdk/commit/27536c63ec91a26323ffb341c1edbef0ab9331a3))

## [0.1.1](https://github.com/cowprotocol/cow-sdk/compare/sdk-contracts-ts-v0.1.0...sdk-contracts-ts-v0.1.1) (2025-09-22)


### 🐛 Bug Fixes

* avoid using adapter in normalizeOrder ([#523](https://github.com/cowprotocol/cow-sdk/issues/523)) ([7c196c3](https://github.com/cowprotocol/cow-sdk/commit/7c196c39a6694924cbec09f159dd237da39d73a2))

## [0.1.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-contracts-ts-v2.3.0-beta.0...sdk-contracts-ts-v0.1.0) (2025-09-17)


### ⚠ BREAKING CHANGES

* release cow-sdk v7 ([#514](https://github.com/cowprotocol/cow-sdk/issues/514))

### ✨ Features

* release cow-sdk v7 ([#514](https://github.com/cowprotocol/cow-sdk/issues/514)) ([01ebd43](https://github.com/cowprotocol/cow-sdk/commit/01ebd437bd0d54d601a3f00f3ebd2bffd58f7a93))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.1.0
    * @cowprotocol/sdk-config bumped to 0.1.0
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.1.0
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.1.0
    * @cowprotocol/sdk-viem-adapter bumped to 0.1.0

## [2.3.0-beta.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-contracts-ts-v2.2.1-beta.0...sdk-contracts-ts-v2.3.0-beta.0) (2025-09-17)


### ✨ Features

* **cow-shed:** validate EIP1271 signature ([#508](https://github.com/cowprotocol/cow-sdk/issues/508)) ([5c72123](https://github.com/cowprotocol/cow-sdk/commit/5c7212323edcea3eadf70973f765619afb1bcaf4))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.5.0-beta.0
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.2.5-beta.0
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.2.5-beta.0
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.1-beta.0

## [2.2.1-beta.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-contracts-ts-v2.2.0-beta.0...sdk-contracts-ts-v2.2.1-beta.0) (2025-09-16)


### 🐛 Bug Fixes

* rename ether to ethers ([#504](https://github.com/cowprotocol/cow-sdk/issues/504)) ([eaf2705](https://github.com/cowprotocol/cow-sdk/commit/eaf2705f269352d3bc2908eb3335ff56ef426823))


### Dependencies

* The following workspace dependencies were updated
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.2.4-beta.0
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.2.4-beta.0

## [2.2.0-beta.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-contracts-ts-v2.1.7-beta.0...sdk-contracts-ts-v2.2.0-beta.0) (2025-09-16)


### ✨ Features

* add migration guide and wagmi example ([#498](https://github.com/cowprotocol/cow-sdk/issues/498)) ([21be05d](https://github.com/cowprotocol/cow-sdk/commit/21be05d5b6472de26120ebefe4626341af9a062d))


### 📚 Documentation

* update README to focus on main use cases ([#493](https://github.com/cowprotocol/cow-sdk/issues/493)) ([a05cb1b](https://github.com/cowprotocol/cow-sdk/commit/a05cb1ba11b5f9895d7cfe6262cf74c4089fd73c))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.4.0-beta.0
    * @cowprotocol/sdk-config bumped to 0.3.3-beta.0
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.2.3-beta.0
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.2.3-beta.0
    * @cowprotocol/sdk-viem-adapter bumped to 0.3.0-beta.0

## [2.1.7-beta.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-contracts-ts-v2.1.6-beta.0...sdk-contracts-ts-v2.1.7-beta.0) (2025-09-15)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-config bumped to 0.3.2-beta.0

## [2.1.6-beta.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-contracts-ts-v2.1.5-beta.0...sdk-contracts-ts-v2.1.6-beta.0) (2025-09-15)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-config bumped to 0.3.1-beta.0

## [2.1.5-beta.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-contracts-ts-v2.1.4-beta.0...sdk-contracts-ts-v2.1.5-beta.0) (2025-09-15)


### 🐛 Bug Fixes

* **bridge:** fix applying affiliate header ([#492](https://github.com/cowprotocol/cow-sdk/issues/492)) ([e4f49c6](https://github.com/cowprotocol/cow-sdk/commit/e4f49c64e60f4aeac97b6b246c36090946df6fcf))

## [2.1.4-beta.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-contracts-ts-v2.1.3-beta.0...sdk-contracts-ts-v2.1.4-beta.0) (2025-09-11)


### 🔧 Miscellaneous

* release main ([#488](https://github.com/cowprotocol/cow-sdk/issues/488)) ([6344fa6](https://github.com/cowprotocol/cow-sdk/commit/6344fa619465e6f94637677823a18646f06fa7c9))


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-common bumped to 0.3.0-beta.0
  * devDependencies
    * @cowprotocol/sdk-ethers-v5-adapter bumped to 0.2.2-beta.0
    * @cowprotocol/sdk-ethers-v6-adapter bumped to 0.2.2-beta.0
    * @cowprotocol/sdk-viem-adapter bumped to 0.2.2-beta.0

## [2.1.3-beta.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-contracts-ts-v2.1.2-beta.0...sdk-contracts-ts-v2.1.3-beta.0) (2025-09-11)


### Dependencies

* The following workspace dependencies were updated
  * dependencies
    * @cowprotocol/sdk-config bumped to 0.3.0-beta.0

## [2.1.2-beta.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-contracts-ts-v2.1.1-beta.0...sdk-contracts-ts-v2.1.2-beta.0) (2025-09-04)


### 🔧 Miscellaneous

* bump sdk beta version ([#473](https://github.com/cowprotocol/cow-sdk/issues/473)) ([00142d3](https://github.com/cowprotocol/cow-sdk/commit/00142d3e524ebf7a023814ba91ee3a66ed796444))

## [2.1.1-beta.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-contracts-ts-v2.1.0-beta.0...sdk-contracts-ts-v2.1.1-beta.0) (2025-09-01)


### 🐛 Bug Fixes

* improve unknown/any types ([#443](https://github.com/cowprotocol/cow-sdk/issues/443)) ([e6b8a40](https://github.com/cowprotocol/cow-sdk/commit/e6b8a40578583cf6d1ecd208434782422f308ef0))

## [2.1.0-beta.0](https://github.com/cowprotocol/cow-sdk/compare/sdk-contracts-ts-v2.0.0-beta.0...sdk-contracts-ts-v2.1.0-beta.0) (2025-08-28)


### ✨ Features

* add contracts-ts package ([780a60f](https://github.com/cowprotocol/cow-sdk/commit/780a60f58bc67b27f161b0abab1f8ef81b2ea64b))
* add contracts-ts package ([af47c0c](https://github.com/cowprotocol/cow-sdk/commit/af47c0cbe1ff93378decdcd4813645a5aeb67288))
* add tests for contracts-ts ([4f39d4d](https://github.com/cowprotocol/cow-sdk/commit/4f39d4d37bf2f67a2686ac6709795c01f4a43ad0))
* add tests for contracts-ts ([9d6a4b8](https://github.com/cowprotocol/cow-sdk/commit/9d6a4b8d3eeaf7a62312f3d1747df3528fd7fbe4))
* allow changing backoff and limiter per request ([#208](https://github.com/cowprotocol/cow-sdk/issues/208)) ([ebea5ca](https://github.com/cowprotocol/cow-sdk/commit/ebea5ca0858aeb89ae3e5d5407c8903c3ca5178d))
* **cow-shed:** refact on common and contract-ts ([4be05aa](https://github.com/cowprotocol/cow-sdk/commit/4be05aa7a376fbc7d2ed5b2d2b6b68e3630b9c59))
* **lib-agnostic:** migrate latest SDK changes ([#427](https://github.com/cowprotocol/cow-sdk/issues/427)) ([323bab6](https://github.com/cowprotocol/cow-sdk/commit/323bab61eb5adeb4a58bc15e25ffb29d2e1afcbf))
* **monorepo-config:** adjust all package.json and scripts ([23dc2a5](https://github.com/cowprotocol/cow-sdk/commit/23dc2a5db02ce3734b55e1151c8579f9a42a4bc5))
* refactor contracts-ts ([2e14272](https://github.com/cowprotocol/cow-sdk/commit/2e14272f1a24a232aef584611924055ed657d16c))
* refactor contracts-ts ([b441360](https://github.com/cowprotocol/cow-sdk/commit/b4413600d4a0753e9f608e6a6415e64762a53d3e))
* **sdk-agnostic-lib:** create cow trading package ([#368](https://github.com/cowprotocol/cow-sdk/issues/368)) ([0a4534a](https://github.com/cowprotocol/cow-sdk/commit/0a4534aababce4f5d8bab991cd6ae9f51842d719))
* **sdk-agnostic-lib:** Create weiroll package ([#371](https://github.com/cowprotocol/cow-sdk/issues/371)) ([8f6a2e1](https://github.com/cowprotocol/cow-sdk/commit/8f6a2e16e5e7a43a5afc43cf5faab174be916b2e))
* simplify OrderSigningUtils to use static methods only ([#417](https://github.com/cowprotocol/cow-sdk/issues/417)) ([899ca43](https://github.com/cowprotocol/cow-sdk/commit/899ca4325be831b6711468d1df3733d98fe913b0))


### 🐛 Bug Fixes

* **lib-agnostic:** add setProvider() method to adapters ([#432](https://github.com/cowprotocol/cow-sdk/issues/432)) ([64c0ea9](https://github.com/cowprotocol/cow-sdk/commit/64c0ea94d802aa167b978ae0859353d801de0911))


### 🔧 Miscellaneous

* apply PR suggestions ([2ff0f7c](https://github.com/cowprotocol/cow-sdk/commit/2ff0f7c74c377b67824da3ba6390edccdaad94f5))
* fix merge ([5c511de](https://github.com/cowprotocol/cow-sdk/commit/5c511deedd0c7821df6affefc9623c79a68c96c7))
* **lint:** lint ([881e345](https://github.com/cowprotocol/cow-sdk/commit/881e3451add9d911047daebe4e36fe777d95927a))
* merge main 28-06-2025 ([#452](https://github.com/cowprotocol/cow-sdk/issues/452)) ([4c198ce](https://github.com/cowprotocol/cow-sdk/commit/4c198ce34890740bf0a0fe859620a9e1ad432bed))
* remove console logs ([ce11a98](https://github.com/cowprotocol/cow-sdk/commit/ce11a98a36e609e963d51b8ffce1cb1995fe090f))
* **sdk-agnostic-lib:** merge multiple PRs to avoid conflicts and speed up base branch sync ([#354](https://github.com/cowprotocol/cow-sdk/issues/354)) ([55d3068](https://github.com/cowprotocol/cow-sdk/commit/55d3068c52217dd2618d8c180ab4fed8c9334c72))
* update contracts-ts config ([68360fc](https://github.com/cowprotocol/cow-sdk/commit/68360fc030cd269d13d5aee8f2e89b53c4b4fc74))
