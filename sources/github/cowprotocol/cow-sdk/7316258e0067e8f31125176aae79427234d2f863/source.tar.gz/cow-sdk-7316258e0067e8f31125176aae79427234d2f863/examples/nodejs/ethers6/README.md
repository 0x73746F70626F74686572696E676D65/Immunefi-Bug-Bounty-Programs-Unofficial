# Node.js example - ethers v6

Run a headless CoW Protocol trade using ethers v6.

## Setup

1. Edit `src/index.ts` and set:

- `PRIVATE_KEY`: your private key (starts with `0x`)
- Optionally adjust `DEFAULT_SELL_AMOUNT`, `RPC_URL`

2. Install deps (at repo root):

```
pnpm install
```

## Run

Dev (TS directly):

```
pnpm --filter example-nodejs-ethers6 dev
```

Build + run:

```
pnpm --filter example-nodejs-ethers6 build
pnpm --filter example-nodejs-ethers6 start
```

## Signer-less example

`src/signerless.ts` runs the same trade without ever passing a signer or private key to the SDK:
the order is signed by a local ethers `Wallet` standing in for a cold wallet or custody service.
Set `PRIVATE_KEY` in `src/signerless.ts`, then:

```
pnpm --filter example-nodejs-ethers6 dev:signerless
```

## Pre-sign example

`src/presign.ts` creates a `PRESIGN` order and then builds its `setPreSignature` transaction with
`getPreSignCallData` on a signer-less adapter — no signer, no RPC call, no gas estimate — before
sending it from the owner's wallet. That last step stands in for a Safe, multisig, or custody stack.
Set `PRIVATE_KEY` in `src/presign.ts`, then:

```
pnpm --filter example-nodejs-ethers6 dev:presign
```
