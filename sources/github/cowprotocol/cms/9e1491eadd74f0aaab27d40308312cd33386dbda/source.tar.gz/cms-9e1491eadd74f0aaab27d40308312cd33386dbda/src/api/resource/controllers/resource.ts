"use strict";

/**
 * resource controller
 */

import { factories } from "@strapi/strapi";

export default factories.createCoreController("api::resource.resource");
