export default {
  default: {},
  validator() {},
};
