/**
 * notification service
 */

import { factories } from '@strapi/strapi';
import type { EntityService } from '@strapi/types';

const MODULE_ID = 'api::notification.notification' as const
const NOTIFICATIONS_CONSUMER_MODULE_ID = 'api::notifications-consumer.notifications-consumer' as const
const SINGLETON_ID = 1
const NOTIFICATIONS_LIMIT = 50

const NOTIFICATIONS_POPULATE: EntityService.Params.Populate.ObjectNotation<typeof MODULE_ID> = {
  notification_template: {
    fields: ['id', 'title', 'description', 'url', 'push', 'location'],
    populate: {
      thumbnail: {
        fields: ['url']
      }
    }
  }
}

const notificationsTemplateFilter = (push: boolean) => ({
  $or: [
    {
      push,
      dueDate: { $gt: new Date() }
    },
    {
      push,
      dueDate: { $null: true }
    }
  ]
})

export default factories.createCoreService(MODULE_ID, ({ strapi }) => {
  return {
    async getNotificationsForAll(push: boolean) {
      return strapi.entityService.findMany(
        MODULE_ID,
        {
          start: 0,
          limit: NOTIFICATIONS_LIMIT,
          filters: {
            account: { $null: true },
            notification_template: notificationsTemplateFilter(push)
          },
          populate: NOTIFICATIONS_POPULATE
        }
      )
    },
    async getNotificationList(account: string) {
      const push = false
      const templateFilter = notificationsTemplateFilter(push)
      const notifications = await strapi.entityService.findMany(
        MODULE_ID,
        {
          start: 0,
          limit: NOTIFICATIONS_LIMIT,
          filters: {
            $or: [
              { account, notification_template: templateFilter },
              { account: account.toLowerCase(), notification_template: templateFilter },
            ]
          },
          populate: NOTIFICATIONS_POPULATE
        }
      )
      const notificationsForAll = await this.getNotificationsForAll(push)

      return [...notifications, ...notificationsForAll].map(notification => ({
        id: notification.id,
        account: notification.account,
        title: notification.notification_template.title,
        description: templateNotification(notification.notification_template.description, notification.data as Record<string, string>),
        dueDate: notification.notification_template.dueDate,
        url: notification.notification_template.url,
        createdAt: notification.createdAt,
        thumbnail: notification.notification_template.thumbnail?.url,
        location: notification.notification_template?.location ?? 'default'
      }))
    },
    async getPushNotifications() {
      const push = true
      const notificationsConsumer = await strapi.entityService.findOne(NOTIFICATIONS_CONSUMER_MODULE_ID, SINGLETON_ID)

      const lastConsumedNotificationDate = notificationsConsumer?.lastConsumedNotificationDate

      return strapi.entityService.findMany(
        MODULE_ID,
        {
          limit: 200,
          filters: {
            notification_template: notificationsTemplateFilter(push),
            ...(lastConsumedNotificationDate ? {
              createdAt: { $gt: lastConsumedNotificationDate }
            } : undefined)
          },
          populate: NOTIFICATIONS_POPULATE
        }
      )
    },
    async updateLastConsumedNotificationDate() {
      const existing = await strapi.entityService.findOne(NOTIFICATIONS_CONSUMER_MODULE_ID, SINGLETON_ID)

      if (!existing) {
        return strapi.entityService.create(
          NOTIFICATIONS_CONSUMER_MODULE_ID,
          {
            data: { lastConsumedNotificationDate: new Date() }
          }
        )
      }

      return strapi.entityService.update(
        NOTIFICATIONS_CONSUMER_MODULE_ID,
        SINGLETON_ID,
        {
          data: { lastConsumedNotificationDate: new Date() }
        }
      )
    }
  }
});

export function templateNotification(description: string, data: { [key: string]: string }): string {
  let result = description

  if (!data) return result

  Object.keys(data).forEach(key => {
    result = result.replace(`{{ ${key} }}`, data[key])
  })

  return result
}
