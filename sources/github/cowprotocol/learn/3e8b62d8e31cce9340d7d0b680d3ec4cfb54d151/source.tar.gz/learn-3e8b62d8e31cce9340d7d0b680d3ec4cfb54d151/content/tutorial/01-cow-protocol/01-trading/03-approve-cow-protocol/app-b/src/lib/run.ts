import type { PublicClient, WalletClient } from 'viem';
import { OrderKind, SupportedChainId, TradeParameters, TradingSdk } from '@cowprotocol/cow-sdk';
import { ViemAdapter } from '@cowprotocol/sdk-viem-adapter';

export async function run(
	setup: (chainId: SupportedChainId) => Promise<{ publicClient: PublicClient; walletClient: WalletClient }>
): Promise<unknown> {
	const { publicClient, walletClient } = await setup(SupportedChainId.GNOSIS_CHAIN);

	const adapter = new ViemAdapter({
		provider: publicClient,
		walletClient
	});

	const sdk = new TradingSdk(
		{
			chainId: SupportedChainId.GNOSIS_CHAIN,
			appCode: 'CoW Swap'
		},
		{},
		adapter
	);

	const sellToken = '0xe91d153e0b41518a2ce8dd3d7944fa863463a97d'; // wxDAI
	const buyToken = '0x177127622c4A00F3d409B75571e12cB3c8973d3c'; // COW

	const parameters: TradeParameters = {
		kind: OrderKind.SELL,
		sellToken,
		sellTokenDecimals: 18,
		buyToken,
		buyTokenDecimals: 18,
		amount: '1000000000000000000' // 1 wxDAI
	};

	const { quoteResults } = await sdk.getQuote(parameters);

	console.log('QuoteResults', quoteResults);

	// Approve CoW Protocol to spend the sell token
	const approvalTx = await sdk.approveCowProtocol({
		tokenAddress: sellToken,
		amount: BigInt(parameters.amount)
	});

	return {
		approvalTxHash: approvalTx,
		message: 'CoW Protocol has been approved to spend your wxDAI'
	};
}
