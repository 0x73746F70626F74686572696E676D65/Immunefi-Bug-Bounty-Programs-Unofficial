import type { ExternalProvider } from '@ethersproject/providers';

declare global {
	interface Window {
		ethereum: ExternalProvider & { enable(): Promise<void> };
	}
}
