"""Logic for Post CIP 20 Solver Payout Calculation"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timedelta
from fractions import Fraction

import numpy as np
import pandas as pd
from dune_client.types import Address
from pandas import DataFrame, Series

from src.config import AccountingConfig
from src.fetch.dune import DuneFetcher
from src.fetch.prices import exchange_rate_atoms
from src.logger import log_saver, set_log
from src.models.accounting_period import AccountingPeriod
from src.models.overdraft import Overdraft
from src.models.token import Token
from src.models.transfer import Transfer
from src.pg_client import MultiInstanceDBFetcher
from src.utils.print_store import Category

log = set_log(__name__)

SOLVER_PAYOUTS_COLUMNS = [
    "solver",
    "solver_name",
    "primary_reward_eth",
    "primary_reward_cow",
    "consistency_reward_eth",
    "consistency_reward_cow",
    "quote_reward_cow",
    "protocol_fee_eth",
    "network_fee_eth",
    "slippage_eth",
    "reward_target",
    "buffer_accounting_target",
    "reward_token_address",
    "service_fee",
]
PARTNER_PAYOUTS_COLUMNS = ["partner", "partner_fee_eth", "partner_fee_tax"]


@dataclass
class PeriodPayouts:
    """Dataclass to keep track of reimbursements, rewards and solver overdrafts"""

    overdrafts: list[Overdraft]
    # ETH Reimbursements & COW Rewards
    transfers: list[Transfer]


class RewardAndPenaltyDatum:  # pylint: disable=too-many-instance-attributes
    """
    All pertinent information and functionality related to individual solver payout (or overdraft)
    """

    def __init__(  # pylint: disable=too-many-arguments, too-many-positional-arguments
        self,
        solver: Address,
        solver_name: str,
        reward_target: Address,  # recipient address of rewards
        buffer_accounting_target: Address,  # recipient address of net buffer changes
        primary_reward_eth: int,
        consistency_reward_eth: int,
        slippage_eth: int,
        primary_reward_cow: int,
        consistency_reward_cow: int,
        quote_reward_cow: int,
        service_fee: Fraction,
        reward_token_address: Address,
    ):

        assert quote_reward_cow >= 0, "invalid quote_reward_cow"

        self.solver = solver
        self.solver_name = solver_name
        self.reward_target = reward_target
        self.buffer_accounting_target = buffer_accounting_target
        self.slippage_eth = slippage_eth
        self.primary_reward_eth = primary_reward_eth
        self.primary_reward_cow = primary_reward_cow
        self.consistency_reward_eth = consistency_reward_eth
        self.consistency_reward_cow = consistency_reward_cow
        self.quote_reward_cow = quote_reward_cow
        self.service_fee = service_fee
        self.reward_token_address = reward_token_address

    @classmethod
    def from_series(cls, frame: Series) -> RewardAndPenaltyDatum:
        """Constructor from row in Dataframe"""
        slippage = int(frame["slippage_eth"]) + int(frame["network_fee_eth"])
        solver = frame["solver"]
        reward_target = frame["reward_target"]
        if pd.isna(reward_target):
            log.warning(
                f"Solver {solver} without reward_target. "
                f"Using solver submission address instead."
            )
            reward_target = solver

        buffer_accounting_target = frame["buffer_accounting_target"]
        if pd.isna(buffer_accounting_target):
            log.warning(
                f"Solver {solver} without buffer_accounting_target. "
                f"Using solver submission address instead."
            )
            buffer_accounting_target = solver

        return cls(
            solver=Address(solver),
            solver_name=frame["solver_name"],
            reward_target=Address(reward_target),
            buffer_accounting_target=Address(buffer_accounting_target),
            slippage_eth=slippage,
            primary_reward_eth=int(frame["primary_reward_eth"]),
            primary_reward_cow=int(frame["primary_reward_cow"]),
            consistency_reward_eth=int(frame["consistency_reward_eth"]),
            consistency_reward_cow=int(frame["consistency_reward_cow"]),
            quote_reward_cow=int(frame["quote_reward_cow"]),
            service_fee=Fraction(frame["service_fee"]),
            reward_token_address=Address(frame["reward_token_address"]),
        )

    def total_outgoing_eth(self) -> int:
        """Total outgoing amount (including slippage) for the payout."""
        return self.total_eth_reward() + self.slippage_eth

    def total_cow_reward(self) -> int:
        """Total outgoing COW token reward"""
        raw_solver_competition_cow_reward = (
            self.primary_reward_cow + self.consistency_reward_cow
        )
        return (
            int(self.reward_scaling() * raw_solver_competition_cow_reward)
            if raw_solver_competition_cow_reward > 0
            else raw_solver_competition_cow_reward
        )

    def total_eth_reward(self) -> int:
        """Total outgoing ETH reward"""
        raw_solver_competition_eth_reward = (
            self.primary_reward_eth + self.consistency_reward_eth
        )
        return (
            int(self.reward_scaling() * raw_solver_competition_eth_reward)
            if raw_solver_competition_eth_reward > 0
            else raw_solver_competition_eth_reward
        )

    def reward_scaling(self) -> Fraction:
        """Scaling factor for service fee
        The reward is multiplied by this factor"""
        return 1 - self.service_fee

    def total_service_fee(self) -> Fraction:
        """Total service fee charged from rewards"""
        return self.service_fee * (
            max(self.primary_reward_cow + self.consistency_reward_cow, 0)
            + self.quote_reward_cow
        )

    def is_overdraft(self) -> bool:
        """
        True if the solver's complete combined data results in a net negative
        """
        return self.total_outgoing_eth() < 0

    def as_payouts(self) -> list[Transfer]:
        """
        Isolating the logic of how solvers are paid out according to their
            execution costs, rewards and slippage
        """
        quote_reward_cow = int(self.reward_scaling() * self.quote_reward_cow)
        result = []
        if quote_reward_cow > 0:
            result.append(
                Transfer(
                    token=Token(self.reward_token_address, 18),  # remove magic constant
                    recipient=self.reward_target,
                    amount_wei=quote_reward_cow,
                )
            )
        if self.is_overdraft():
            return result

        total_eth_reward = int(self.total_eth_reward())
        total_cow_reward = int(self.total_cow_reward())

        reimbursement_eth = int(self.slippage_eth)
        # We do not have access to token conversion here, but we do have other converted values
        # x_eth:x_cow = y_eth:y_cow --> y_cow = y_eth * x_cow / x_eth
        reimbursement_cow = (
            (reimbursement_eth * total_cow_reward) // total_eth_reward
            if total_eth_reward != 0
            else 0
        )
        if reimbursement_eth > 0 > total_cow_reward:
            # If the total payment is positive but the total rewards are negative,
            # pay the total payment in ETH. The total payment corresponds to reimbursement,
            # reduced by the negative reward.
            # Note that;
            # reimbursement_eth + reward_eth
            # = self.total_eth_reward() + self.exec_cost + self.slippage_eth
            # = self.payment_eth + self.slippage_eth
            # = self.total_outgoing_eth()
            # >= 0 (because not self.is_overdraft())
            try:
                result.append(
                    Transfer(
                        token=None,
                        recipient=self.buffer_accounting_target,
                        amount_wei=reimbursement_eth + total_eth_reward,
                    )
                )
            except AssertionError:
                log.warning(
                    f"Invalid ETH Transfer {self.solver} "
                    f"with amount={reimbursement_eth + total_eth_reward}"
                )

            return result

        if reimbursement_eth < 0 < total_cow_reward:
            # If the total payment is positive but the total reimbursement is negative,
            # pay the total payment in COW. The total payment corresponds to a payment of rewards,
            # reduced by the negative reimbursement.
            try:
                result.append(
                    Transfer(
                        token=Token(
                            self.reward_token_address, 18
                        ),  # remove magic constant
                        recipient=self.reward_target,
                        amount_wei=reimbursement_cow + total_cow_reward,
                    )
                )
            except AssertionError:
                log.warning(
                    f"Invalid COW Transfer {self.solver} "
                    f"with amount={reimbursement_cow + total_cow_reward}"
                )

            return result

        try:
            result.append(
                Transfer(
                    token=None,
                    recipient=self.buffer_accounting_target,
                    amount_wei=reimbursement_eth,
                )
            )
        except AssertionError:
            log.warning(
                f"Invalid ETH Transfer {self.solver} with amount={reimbursement_eth}"
            )
        try:
            result.append(
                Transfer(
                    token=Token(self.reward_token_address, 18),  # remove magic constant
                    recipient=self.reward_target,
                    amount_wei=total_cow_reward,
                )
            )
        except AssertionError:
            log.warning(
                f"Invalid COW Transfer {self.solver} with amount={total_cow_reward}"
            )

        return result


def prepare_payouts(  # pylint: disable=too-many-locals
    solver_payouts: DataFrame,
    partner_payouts: DataFrame,
    period: AccountingPeriod,
    config: AccountingConfig,
) -> PeriodPayouts:
    """Prepare payouts.

    Prepares and calculates payouts for solvers and partners based on the input data.

    Parameters
    ----------
    solver_payouts : DataFrame
        Data frame containing payout information for solvers. The expected columns are defined by
        `SOLVER_PAYOUTS_COLUMNS`.

    partner_payouts : DataFrame
        Data frame containing payout information for partners. The expected columns are defined by
        `PARTNER_PAYOUTS_COLUMNS`.

    period : AccountingPeriod
        The current accounting period for which the payouts are being prepared.

    config : AccountingConfig
        Configuration object that contains payout-related settings, such as protocol fee
        configurations.

    Returns
    -------
    PeriodPayouts
        An object containing the prepared overdrafts and transfers based on the input data.

    Raises
    ------
    AssertionError
        If the columns in the solver_payouts or partner_payouts DataFrame do not match the required
        columns.

    Notes
    -----
    - Overdrafts are calculated for solvers whose outgoing payouts exceed available balances.
    - Transfers are constructed for batch and quote rewards, protocol fee payouts, partner payouts,
        and adjusted for any applicable taxes.
    - All transfers and overdrafts are accumulated and returned as part of the result.
    """

    assert set(SOLVER_PAYOUTS_COLUMNS) == set(solver_payouts.columns)
    assert set(PARTNER_PAYOUTS_COLUMNS) == set(partner_payouts.columns)

    overdrafts: list[Overdraft] = []
    transfers: list[Transfer] = []
    for _, payment in solver_payouts.iterrows():
        payout_datum = RewardAndPenaltyDatum.from_series(payment)
        if payout_datum.is_overdraft():
            overdraft = Overdraft(
                period=period,
                account=payout_datum.solver,
                name=payout_datum.solver_name,
                wei=-int(payout_datum.total_outgoing_eth()),
            )
            print(f"Solver Overdraft! {overdraft}")
            overdrafts.append(overdraft)
        transfers += payout_datum.as_payouts()

    total_protocol_fee = int(solver_payouts["protocol_fee_eth"].sum())
    total_partner_fee = int(partner_payouts["partner_fee_eth"].sum())
    total_partner_fee_taxed = sum(
        int(row["partner_fee_eth"] * (1 - row["partner_fee_tax"]))
        for _, row in partner_payouts.iterrows()
    )
    total_partner_fee_tax = total_partner_fee - total_partner_fee_taxed

    net_protocol_fee = total_protocol_fee - total_partner_fee

    if net_protocol_fee > 0:
        transfers.append(
            Transfer(
                token=None,
                recipient=config.protocol_fee_config.protocol_fee_safe,
                amount_wei=net_protocol_fee,
            )
        )
    if total_partner_fee_tax > 0:
        transfers.append(
            Transfer(
                token=None,
                recipient=config.protocol_fee_config.protocol_fee_safe,
                amount_wei=total_partner_fee_tax,
            )
        )
    wrapped_native_token = Token(config.payment_config.wrapped_native_token_address, 18)
    for _, row in partner_payouts.iterrows():
        partner = row["partner"]
        partner_fee = int(row["partner_fee_eth"] * (1 - row["partner_fee_tax"]))
        assert partner_fee >= 0, f"Can't construct negative transfer of {partner_fee}"
        if partner_fee > 0 and Address(partner) != Address(
            "0x81BA8A2b895D30280bca199C2Ff75f3F058d4C6c"
        ):
            if (
                Address(partner)
                in config.protocol_fee_config.partners_with_wrapped_native_transfers
            ):
                target_token = wrapped_native_token
            else:
                target_token = None
            transfers.append(
                Transfer(
                    token=target_token,
                    recipient=Address(partner),
                    amount_wei=partner_fee,
                )
            )

    return PeriodPayouts(overdrafts, transfers)


def fetch_exchange_rates(
    period_end: datetime, config: AccountingConfig
) -> tuple[Fraction, Fraction]:
    """Fetch exchange rates.

    Fetches exchange rates for converting COW to native tokens and ETH to native tokens. The
    exchange rate is an average rate from the day before the end of the accounting period.

    Parameters
    ----------
    period_end : datetime
        The end of the accounting period for which the exchange rates are being fetched.

    config : AccountingConfig
        Configuration object containing reward and payment settings, including token addresses.

    Returns
    -------
    exchange_rate_native_to_cow : Fraction
        The rate of exchange from the native token to COW.
    exchange_rate_native_to_eth: Fraction
        The rate of exchange from the native token to ETH.
    """
    reward_token = config.reward_config.reward_token_address
    native_token = Address(config.payment_config.wrapped_native_token_address)
    wrapped_eth = config.payment_config.wrapped_eth_address
    price_day = period_end - timedelta(days=1)
    exchange_rate_native_to_cow = exchange_rate_atoms(
        native_token, reward_token, price_day
    )
    exchange_rate_native_to_eth = exchange_rate_atoms(
        native_token, wrapped_eth, price_day
    )
    return exchange_rate_native_to_cow, exchange_rate_native_to_eth


def compute_solver_payouts(
    data_per_solver: DataFrame, config: AccountingConfig
) -> DataFrame:
    """Compute solver payouts.

    Information on solvers is combined with data on rewards, protocol fees, and buffer accounting to
    compute solver payouts.

    Parameters
    ----------
    data_per_solver : DataFrame
        Contains information about solver accounting.
    config : AccountingConfig
        Configuration object containing reward and payment settings, including token addresses.

    Returns
    -------
    solver_payouts : DataFrame
        A consolidated DataFrame with solver payout information, including rewards, fees, and other
        accounting details. Merges and processes input DataFrames with applied default values and
        normalized fields.
        Missing values are set to zero or some other reasonable default value.
        The columns are SOLVER_PAYOUTS_COLUMNS:
        - solver : str
            "0x"-prefixed hex representation of the submission address of a solver.
        - solver_name : str
            Name of a solver.
        - primary_reward_eth : int
            Reward for settling batches in wei.
        - primary_reward_cow : int
            Reward for settling batches in wei.
        - consistency_reward_eth: int
            Reward for being consistent throughout the week in wei
        - consistency_reward_cow: int
            Reward for being consistent throughout the week in atoms of COW
        - quote_reward_cow : int
            Reward for providing quotes in atoms of COW.
        - protocol_fee_eth : int
            Protocol fee of a solver for settling batches in wei.
        - network_fee_eth : int
            Network fees in wei of a solver for settling batches.
        - slippage_eth : int
            Slippage in wei accrued by a solver in settling batches.
        - reward_target : str
            "0x"-prefixed hex representation of the reward target of a solver. All
            rewards are sent to this address.
        - buffer_accounting_target : str
            "0x"-prefixed hex representation of the buffer accounting target address of a solver.
            Results of the buffer accounting are sent to this address. It is equal to `solver` or
            `reward_target`.
        - reward_token_address : str
            "0x"-prefixed hex representation of the reward token contract address.
        - service_fee : Fraction
            The fraction of rewards which need to be paid to the CoW DAO.
    """
    solver_payouts = DataFrame(columns=SOLVER_PAYOUTS_COLUMNS, dtype=object)
    solver_payouts["solver"] = data_per_solver["solver"]
    solver_payouts["solver_name"] = data_per_solver["solver_name"]
    solver_payouts["primary_reward_eth"] = (
        data_per_solver["sum_batch_reward_native"].fillna(0).astype(object)
    )
    solver_payouts["primary_reward_cow"] = (
        data_per_solver["sum_batch_reward_cow"].fillna(0).astype(object)
    )
    solver_payouts["consistency_reward_eth"] = (
        data_per_solver["consistency_reward_native"].fillna(0).astype(object)
    )
    solver_payouts["consistency_reward_cow"] = (
        data_per_solver["consistency_reward_cow"].fillna(0).astype(object)
    )
    solver_payouts["quote_reward_cow"] = (
        data_per_solver["sum_quote_reward_cow"].fillna(0).astype(object)
    )
    solver_payouts["protocol_fee_eth"] = (
        data_per_solver["sum_protocol_fee_native"].fillna(0).astype(object)
    )
    solver_payouts["network_fee_eth"] = (
        data_per_solver["sum_network_fee_native"].fillna(0).astype(object)
    )
    solver_payouts["slippage_eth"] = (
        data_per_solver["sum_slippage_native"].fillna(0).astype(object)
    )
    solver_payouts["reward_target"] = data_per_solver["reward_target"]

    send_buffers_to_rewards_address_pools_addresses = [
        pool.address
        for pool in config.buffer_accounting_config.send_buffers_to_rewards_address_pools
    ]
    solver_payouts["buffer_accounting_target"] = np.where(
        data_per_solver["pool_address"].isin(
            send_buffers_to_rewards_address_pools_addresses
        ),
        data_per_solver["reward_target"],
        data_per_solver["solver"],
    )
    solver_payouts["reward_token_address"] = str(
        config.reward_config.reward_token_address
    )
    solver_payouts["service_fee"] = (
        data_per_solver["service_fee_enabled"] * config.reward_config.service_fee_factor
    )

    solver_payouts = solver_payouts.sort_values(by="solver")

    assert set(solver_payouts.columns) == set(SOLVER_PAYOUTS_COLUMNS)

    return solver_payouts


def compute_partner_payouts(partner_and_protocol_fees: DataFrame) -> DataFrame:
    """Combine partner fee information into partner fee payouts.

    Returns
    -------
    DataFrame
    """
    partner_payouts = DataFrame(columns=PARTNER_PAYOUTS_COLUMNS, dtype=object)
    partner_payouts["partner"] = partner_and_protocol_fees["partner_fee_recipient"]
    partner_payouts["partner_fee_eth"] = partner_and_protocol_fees[
        "sum_partner_fee_native"
    ]
    partner_payouts["partner_fee_tax"] = partner_and_protocol_fees["partner_fee_cut"]

    partner_payouts = partner_payouts[partner_payouts["partner"].notnull()]

    partner_payouts = partner_payouts.sort_values(by="partner")

    return partner_payouts


def summarize_payments(  # pylint: disable=too-many-locals
    solver_payouts: DataFrame,
    partner_payouts: DataFrame,
    exchange_rate_native_to_cow: Fraction,
    exchange_rate_native_to_eth: Fraction,
    config: AccountingConfig,
) -> None:
    """Summarize payment information.

    Summarizes payment information, calculating various fees and rewards, and outputs a detailed
    payment breakdown log.

    The log is written to the global variable `log_saver`.

    Parameters
    ----------
    solver_payouts : DataFrame
        Contains payout details from solvers, including primary rewards, quote rewards, protocol
        fees, slippage, and network fees.

    partner_payouts : DataFrame
        Contains partner-related payout details such as partner fees and associated tax information.

    exchange_rate_native_to_cow : Fraction
        Exchange rate that defines the number of COW tokens equivalent to one unit of the native
        token.

    exchange_rate_native_to_eth : Fraction
        Exchange rate that defines the number of ETH tokens equivalent to one unit of the native
        token.

    config : AccountingConfig
        Configuration object containing payment parameters such as minimum acceptable native token
        transfer and COW transfer thresholds.
    """
    performance_reward = solver_payouts["primary_reward_cow"].sum()
    consistency_reward = solver_payouts["consistency_reward_cow"].sum()
    quote_reward = solver_payouts["quote_reward_cow"].sum()
    protocol_fee = solver_payouts["protocol_fee_eth"].sum()
    service_fee = sum(
        solver_payouts["service_fee"]
        * (
            solver_payouts["primary_reward_cow"]
            + solver_payouts["consistency_reward_cow"]
            + solver_payouts["quote_reward_cow"]
        )
    )
    partner_fee = partner_payouts["partner_fee_eth"].sum()
    partner_fee_taxed = sum(
        row["partner_fee_eth"] * (1 - row["partner_fee_tax"])
        for _, row in partner_payouts.iterrows()
    )
    partner_fee_tax = partner_fee - partner_fee_taxed
    slippage = solver_payouts["slippage_eth"].sum()
    network_fee = solver_payouts["network_fee_eth"].sum()

    min_native_token_transfer = config.payment_config.min_native_token_transfer
    min_cow_transfer = config.payment_config.min_cow_transfer

    log_saver.print(
        "Payment breakdown:\n"
        f"Performance Reward (before fee): {performance_reward / 10 ** 18:.4f}\n"
        f"Consistency Reward (before fee): {consistency_reward / 10 ** 18:.4f}\n"
        f"Quote Reward (before fee): {quote_reward / 10 ** 18:.4f}\n"
        f"CoW DAO Service Fees: {service_fee / 10 ** 18:.4f}\n"
        f"Protocol Fees (excluding partner fees): {(protocol_fee - partner_fee) / 10 ** 18:.4f}\n"
        f"Partner Fees (after tax): {(partner_fee - partner_fee_tax) / 10 ** 18:.4f}\n"
        f"Partner Fees Tax: {partner_fee_tax / 10 ** 18:.4f}\n"
        f"Network Fees: {network_fee / 10**18:.4f}\n"
        f"Slippage: {slippage / 10**18:.4f}\n\n"
        f"Exchange rate native token to COW: {exchange_rate_native_to_cow:.4f} COW/native token\n"
        f"Exchange rate native token to ETH: {exchange_rate_native_to_eth:.4f} ETH/native token\n\n"
        f"Minimum native token transfer: {min_native_token_transfer / 10**18} units\n"
        f"Minimum COW transfer: {min_cow_transfer / 10**18} units\n",
        category=Category.TOTALS,
    )


def construct_payouts(
    orderbook: MultiInstanceDBFetcher,
    dune: DuneFetcher,
    config: AccountingConfig,
) -> PeriodPayouts:
    """Construct payouts by combining data from multiple sources.

    Parameters
    ----------
    orderbook : MultiInstanceDBFetcher
        Fetcher for analytics database providing batch and quote data.
    dune : DuneFetcher
        Fetcher for querying Dune to retrieve various metrics.
    config : AccountingConfig
        Configuration object containing all settings relevant to accounting.

    Returns
    -------
    list[Transfer]
        A list of Transfer objects representing the payouts.

    Notes
    -----
    Overdrafts are set and managed by an external contract.
    """
    # pylint: disable=too-many-locals

    data_per_solver = orderbook.get_data_per_solver(
        accounting_period=dune.period, config=config
    )
    partner_and_protocol_fees = orderbook.get_partner_and_protocol_fees(
        accounting_period=dune.period, config=config
    )
    solver_payouts = compute_solver_payouts(data_per_solver, config)
    partner_payouts = compute_partner_payouts(partner_and_protocol_fees)
    exchange_rate_native_to_cow = Fraction(
        1 / data_per_solver.iloc[0]["conversion_rate_cow_to_native"]
    )
    _, exchange_rate_native_to_eth = fetch_exchange_rates(dune.period.end, config)

    summarize_payments(
        solver_payouts,
        partner_payouts,
        exchange_rate_native_to_cow,
        exchange_rate_native_to_eth,
        config,
    )

    # create transfers and overdrafts
    payouts = prepare_payouts(solver_payouts, partner_payouts, dune.period, config)

    for overdraft in payouts.overdrafts:
        log_saver.print(str(overdraft), Category.OVERDRAFT)
    return payouts
