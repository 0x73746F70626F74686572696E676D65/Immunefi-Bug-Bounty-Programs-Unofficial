ALL_NETWORKS = [
    "mainnet",
    "base",
    "arbitrum",
    "gnosis",
    "avalanche",
    "polygon",
    "bnb",
    "linea",
    "plasma",
    "ink",
]

# Contract Addresses
OVERDRAFTS_CONTRACT_ADDRESS = "0x8Fd67Ea651329fD142D7Cfd8e90406F133F26E8a"

# Addresses
DUMMY_REWARDS_ADDRESS_1 = "0xDeaDbeefdEAdbeefdEadbEEFdeadbeEFdEaDbeeF"
DUMMY_SOLVER_NAME_1 = "test-Solver"
