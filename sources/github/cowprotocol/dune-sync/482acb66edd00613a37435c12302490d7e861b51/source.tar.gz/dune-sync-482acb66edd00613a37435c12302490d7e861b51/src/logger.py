"""Easy universal log configuration """
import logging.config
from logging import Logger

from src.environment import LOG_CONFIG_FILE


def set_log(name: str) -> Logger:
    """Removes redundancy when setting log in each file"""

    log = logging.getLogger(name)
    logging.config.fileConfig(
        fname=LOG_CONFIG_FILE.absolute(), disable_existing_loggers=True
    )
    return log
