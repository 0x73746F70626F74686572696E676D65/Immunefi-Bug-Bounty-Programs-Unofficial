# `ComposableCoW`: Composable Conditional orders

This repository is the next in evolution of the [`conditional-smart-orders`](https://github.com/cowprotocol/conditional-smart-orders), providing a unified interface for stateless, composable conditional orders. `ComposableCoW` is designed to be used with the [`ExtensibleFallbackHandler`](https://github.com/rndlabs/safe-contracts/tree/merged-efh-sigmuxer), a powerful _extensible_ fallback handler that allows for significant customisation of a `Safe`, while preserving strong security guarantees.

## Architecture

A detailed explanation on the architecture is available [here](https://hackmd.io/@mfw78/ByFP7Iazn).

### Methodology

For the purposes of outlining the methodologies, it is assumed that:

1. The `Safe` has already had its fallback handler set to `ExtensibleFallbackHandler`.
2. The `Safe` has set the `domainVerifier` for the `GPv2Settlement.domainSeparator()` to `ComposableCoW`

#### Conditional order creation

A conditional order is a struct `ConditionalOrderParams`, consisting of:

1. The address of handler, ie. type of conditional order (such as `TWAP`).
2. A unique `salt` - a fresh random value per order, as it is what keeps two otherwise-identical orders distinct.
3. Implementation specific `staticInput` - data that is known at the creation time of the conditional order.

##### Single Order

1. From the context of the Safe that is placing the order, call `ComposableCoW.create` with the `ConditionalOrderParams` struct. Optionally set `dispatch = true` to have events emitted that are picked up by a watch tower.

##### Merkle Root

1. Collect all the conditional orders, which are multiple structs of `ConditionalOrderParams`.
2. Populate a merkle tree with the leaves from (1), where each leaf is a double hashed of the ABI-encoded struct.
3. Determine the merkle root of the tree and set this as the root, calling `ComposableCoW.setRoot`. The `proof` must be set, and currently:
   a. Set a `location` of `0` for no proofs emitted.
   b. Otherwise, set a `location` of `1` at which case the payload in the proof will be interpreted as an array of proofs and indexed by the watch tower.

#### Get Tradeable Order With Signature

Conditional orders may generate one or many discrete orders depending on their implementation. To retrieve a discrete order that is valid at the current block:

1. Call `ComposableCoW.getTradeableOrderWithSignature(address owner, ConditionalOrderParams params, bytes offchainInput, bytes32[] proof)` where:
   - `owner`: smart contract / `Safe`
   - `params`: mentioned above.
   - `offchainInput` is any implementation specific offchain input for discrete order generation / validation.
   - `proof`: a zero length array if a single order, otherwise the merkle proof for the merkle root that's set for `owner`.
2. Decoding the `GPv2Order`, use this data to populate a `POST` to the CoW Protocol API to create an order. Set the `signingScheme` to `eip1271` and the `signature` to that returned from the call in (1).
3. Review the order on [CoW Explorer](https://explorer.cow.fi/).
4. `getTradeableOrderWithSignature(address,ConditionalOrderParams,bytes,bytes32[])` may revert with one of the custom errors. This provides feedback for watch towers to modify their internal state.

#### Conditional order cancellation

##### Single Order

1. Determine the digest for the conditional order, ie.`H(Params)`.
2. Call `ComposableCoW.remove(H(Params))`

##### Merkle Root

1. Prune the leaf from the merkle tree.
2. Determine the new root.
3. Call `ComposableCoW.setRoot` with the new root, which will invalidate any orders that have been pruned from the tree.

## Time-weighted average price (TWAP)

A simple _time-weighted average price_ trade may be thought of as `n` smaller trades happening every `t` time interval, commencing at time `t0`. Additionally, it is possible to limit a part's validity of the order to a certain `span` of time interval `t`.

### Data Structure

```solidity=
struct Data {
    IERC20 sellToken;
    IERC20 buyToken;
    address receiver; // address(0) if the safe
    uint256 partSellAmount; // amount to sell in each part
    uint256 minPartLimit; // minimum buy amount in each part (limit)
    uint256 t0;
    uint256 n;
    uint256 t;
    uint256 span;
}
```

**NOTE:** No direction of trade is specified, as for TWAP it is assumed to be a _sell_ order

Example: Alice wants to sell 12,000,000 DAI for at least 7500 WETH. She wants to do this using a TWAP, executing a part each day over a period of 30 days.

- `sellToken` = DAI
- `buyToken` = WETH
- `receiver` = `address(0)`
- `partSellAmount` = 12000000 / 30 = 400000 DAI
- `minPartLimit` = 7500 / 30 = 250 WETH
- `t0` = Nominated start time (unix epoch seconds)
- `n` = 30 (number of parts)
- `t` = 86400 (duration of each part, in seconds)
- `span` = 0 (duration of `span`, in seconds, or `0` for entire interval)

If Alice also wanted to restrict the duration in which each part traded in each day, she may set `span` to a non-zero duration. For example, if Alice wanted to execute the TWAP, each day for 30 days, however only wanted to trade for the first 12 hours of each day, she would set `span` to `43200` (i.e. `60 * 60 * 12`).

Using `span` allows for use cases such as weekend or week-day only trading.

### Methodology

To create a TWAP order:

1. ABI-Encode the `IConditionalOrder.ConditionalOrderParams` struct with:
   - `handler`: set to the `TWAP` smart contract deployment.
   - `salt`: a fresh random value per order. It is what keeps two otherwise-identical orders distinct,
     so reusing one makes them indistinguishable.
   - `staticInput`: the ABI-encoded `TWAP.Data` struct.
2. Use the `struct` from (1) as either a Merkle leaf, or with `ComposableCoW.create` to create a single conditional order.
3. Approve `GPv2VaultRelayer` to trade `n x partSellAmount` of the safe's `sellToken` tokens (in the example above, `GPv2VaultRelayer` would receive approval for spending 12,000,000 DAI tokens).

**NOTE**: When calling `ComposableCoW.create`, setting `dispatch = true` will cause `ComposableCoW` to emit event logs that are indexed by the watch tower automatically. If you wish to maintain a private order (and will submit to the CoW Protocol API through your own infrastructure, you may set `dispatch` to `false`).

Fortunately, when using Safe, it is possible to batch together all the above calls to perform this step atomically, and optimise gas consumption / UX. For code examples on how to do this, please refer to the [CLI](#CLI).

**TODO**
**NOTE:** For canceling a TWAP order, follow the instructions at [Conditional order cancellation](#Conditional-order-cancellation).

## Just-in-time funding with `ComposableCowPoller`

`ComposableCowPoller` enables an EOA to create a ComposableCoW conditional order, such as a TWAP, without moving the full sell amount into the order's smart account up front. The permissionless `pollFunds` function is normally called from a settlement pre-hook. It requires a registered schedule, checks that the same conditional-order parameters are currently authorized in `ComposableCoW.singleOrders`, then calls the handler with the stored `staticInput` and empty `offchainInput`.

The handler chooses the sell token, amount, and trading window; the Poller does not validate them. It transfers the returned amount from the funder to the owner and records funding per `(schedule ID, order digest)`. Each pair can be funded once, but a new digest or different schedule ID can pull again. Anyone can trigger funding without settling the order, leaving the tokens in the owner's account.

The funder can register or revoke a funding schedule directly. To avoid a separate transaction, the funder can instead sign an EIP-712 authorization that a relayer submits on-chain. The Poller validates EOA signatures directly and uses ERC-1271 when the funder is a contract. Signed actions include a deadline and the current authorization epoch. Revocation derives the schedule ID from its funder, handler, owner, and salt, so it works before or after registration without allowing one funder to cancel another's schedule. It advances the authorization epoch, invalidating pending signatures from prior epochs while allowing the same schedule ID to be reused.

A funder who already does some operations through a [CowShed](https://github.com/cowdao-grants/cow-shed) does not need a second signature to also include the registration. `registerFromShed` and `revokeFromShed` allow the funder's shed, `proxyOf(funder)`, to register and revoke schedules on behalf of the funder. Without these methods, the funder would need to sign a second EIP-712 authorization or transaction for the schedule registration.

Removing the conditional order from ComposableCoW only pauses funding. The owner can reauthorize the same parameters and resume funding while the schedule and allowance remain active. Revoking the schedule stops it, but leaves the token allowance active; revoke that allowance separately when it is no longer needed.

### Handler compatibility

Anyone can build a handler and reuse the Poller, which has no handler allowlist, but compatibility is not guaranteed.

The five handlers below use `BaseConditionalOrder`. The pre-hook first calls `getTradeableOrder` with empty `offchainInput` and funds the owner. CoW then calls `verify` with the input stored in the submitted signature; `BaseConditionalOrder` regenerates the order and compares its hash. Compatibility requires the first call to succeed and the submitted order to match the regenerated order.

The funder must trust the handler, which can pull any token and amount covered by the allowance, and the owner, which receives the funds and controls the order authorization and cabinet context. A handler that returns different order digests for the same intended trade can trigger repeated funding, potentially exhausting the allowance.

| Handler               | Poller compatibility                    | Reason                                                                                                                      |
| --------------------- | --------------------------------------- | --------------------------------------------------------------------------------------------------------------------------- |
| `TWAP`                | Compatible                              | Each part has a fixed order for an unchanged start time and enforces its time window.                                      |
| `StopLoss`            | Compatible                              | Returns the same order whenever its checks pass and accepts empty `offchainInput`.                                        |
| `TradeAboveThreshold` | Compatible with funding simulation      | `sellAmount` is the owner's balance; see below.                                                                             |
| `PerpetualStableSwap` | Compatible with funding simulation      | Similar to `TradeAboveThreshold`: its sell token and amounts depend on the owner's balances.                                |
| `GoodAfterTime`       | Not compatible                          | It gets `buyAmount` from the `offchainInput` passed to `getTradeableOrderWithSignature`, but the Poller passes empty bytes. |

A watchtower must simulate funding first, then query balance-based handlers. `TradeAboveThreshold` cannot fund an empty owner.

For a TWAP with `t0 == 0`, calling `createWithContext` again can change the start time and create new fundable digests.

## Developers

### Requirements

- `forge` ([Foundry](https://github.com/foundry-rs/foundry))

### Deployed Contracts

| Contract Name                  | Ethereum Mainnet                                                                                                      | Gnosis Chain                                                                                                           | Sepolia                                                                                                                       | Arbitrum One                                                                                                         | Base                                                                                                                  | Bsc                                                                                                                  | Avalanche                                                                                                             | Optimism                                                                                                                         | Polygon                                                                                                                  | Lens                                                                                                                       | Linea                                                                                                                    | Plasma                                                                                                                 | Ink                                                                                                                              |
| ------------------------------ | --------------------------------------------------------------------------------------------------------------------- | ---------------------------------------------------------------------------------------------------------------------- | ----------------------------------------------------------------------------------------------------------------------------- | -------------------------------------------------------------------------------------------------------------------- | --------------------------------------------------------------------------------------------------------------------- | -------------------------------------------------------------------------------------------------------------------- | --------------------------------------------------------------------------------------------------------------------- | -------------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------ | -------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------ | ---------------------------------------------------------------------------------------------------------------------- | -------------------------------------------------------------------------------------------------------------------------------- |
| `ExtensibleFallbackHandler`    | [0x2f55e8b20D0B9FEFA187AA7d00B6Cbe563605bF5](https://etherscan.io/address/0x2f55e8b20D0B9FEFA187AA7d00B6Cbe563605bF5) | [0x2f55e8b20D0B9FEFA187AA7d00B6Cbe563605bF5](https://gnosisscan.io/address/0x2f55e8b20D0B9FEFA187AA7d00B6Cbe563605bF5) | [0x2f55e8b20D0B9FEFA187AA7d00B6Cbe563605bF5](https://sepolia.etherscan.io/address/0x2f55e8b20D0B9FEFA187AA7d00B6Cbe563605bF5) | [0x2f55e8b20D0B9FEFA187AA7d00B6Cbe563605bF5](https://arbiscan.io/address/0x2f55e8b20D0B9FEFA187AA7d00B6Cbe563605bF5) | [0x2f55e8b20D0B9FEFA187AA7d00B6Cbe563605bF5](https://basescan.org/address/0x2f55e8b20D0B9FEFA187AA7d00B6Cbe563605bF5) | [0x2f55e8b20D0B9FEFA187AA7d00B6Cbe563605bF5](https://bscscan.com/address/0x2f55e8b20D0B9FEFA187AA7d00B6Cbe563605bF5) | [0x2f55e8b20D0B9FEFA187AA7d00B6Cbe563605bF5](https://snowscan.xyz/address/0x2f55e8b20D0B9FEFA187AA7d00B6Cbe563605bF5) | [0x2f55e8b20D0B9FEFA187AA7d00B6Cbe563605bF5](https://optimistic.etherscan.io/address/0x2f55e8b20D0B9FEFA187AA7d00B6Cbe563605bF5) | [0x2f55e8b20D0B9FEFA187AA7d00B6Cbe563605bF5](https://polygonscan.com/address/0x2f55e8b20D0B9FEFA187AA7d00B6Cbe563605bF5) | [0x2f55e8b20D0B9FEFA187AA7d00B6Cbe563605bF5](https://explorer.lens.xyz/address/0x2f55e8b20D0B9FEFA187AA7d00B6Cbe563605bF5) | [0x2f55e8b20D0B9FEFA187AA7d00B6Cbe563605bF5](https://lineascan.build/address/0x2f55e8b20D0B9FEFA187AA7d00B6Cbe563605bF5) | [0x2f55e8b20D0B9FEFA187AA7d00B6Cbe563605bF5](https://plasmascan.to/address/0x2f55e8b20D0B9FEFA187AA7d00B6Cbe563605bF5) | -                                                                                                                                |
| `ComposableCoW`                | [0xfdaFc9d1902f4e0b84f65F49f244b32b31013b74](https://etherscan.io/address/0xfdaFc9d1902f4e0b84f65F49f244b32b31013b74) | [0xfdaFc9d1902f4e0b84f65F49f244b32b31013b74](https://gnosisscan.io/address/0xfdaFc9d1902f4e0b84f65F49f244b32b31013b74) | [0xfdaFc9d1902f4e0b84f65F49f244b32b31013b74](https://sepolia.etherscan.io/address/0xfdaFc9d1902f4e0b84f65F49f244b32b31013b74) | [0xfdaFc9d1902f4e0b84f65F49f244b32b31013b74](https://arbiscan.io/address/0xfdaFc9d1902f4e0b84f65F49f244b32b31013b74) | [0xfdaFc9d1902f4e0b84f65F49f244b32b31013b74](https://basescan.org/address/0xfdaFc9d1902f4e0b84f65F49f244b32b31013b74) | [0xfdaFc9d1902f4e0b84f65F49f244b32b31013b74](https://bscscan.com/address/0xfdaFc9d1902f4e0b84f65F49f244b32b31013b74) | [0xfdaFc9d1902f4e0b84f65F49f244b32b31013b74](https://snowscan.xyz/address/0xfdaFc9d1902f4e0b84f65F49f244b32b31013b74) | [0xfdaFc9d1902f4e0b84f65F49f244b32b31013b74](https://optimistic.etherscan.io/address/0xfdaFc9d1902f4e0b84f65F49f244b32b31013b74) | [0xfdaFc9d1902f4e0b84f65F49f244b32b31013b74](https://polygonscan.com/address/0xfdaFc9d1902f4e0b84f65F49f244b32b31013b74) | [0xfdaFc9d1902f4e0b84f65F49f244b32b31013b74](https://explorer.lens.xyz/address/0xfdaFc9d1902f4e0b84f65F49f244b32b31013b74) | [0xfdaFc9d1902f4e0b84f65F49f244b32b31013b74](https://lineascan.build/address/0xfdaFc9d1902f4e0b84f65F49f244b32b31013b74) | [0xfdaFc9d1902f4e0b84f65F49f244b32b31013b74](https://plasmascan.to/address/0xfdaFc9d1902f4e0b84f65F49f244b32b31013b74) | -                                                                                                                                |
| `TWAP`                         | [0x6cF1e9cA41f7611dEf408122793c358a3d11E5a5](https://etherscan.io/address/0x6cF1e9cA41f7611dEf408122793c358a3d11E5a5) | [0x6cF1e9cA41f7611dEf408122793c358a3d11E5a5](https://gnosisscan.io/address/0x6cF1e9cA41f7611dEf408122793c358a3d11E5a5) | [0x6cF1e9cA41f7611dEf408122793c358a3d11E5a5](https://sepolia.etherscan.io/address/0x6cF1e9cA41f7611dEf408122793c358a3d11E5a5) | [0x6cF1e9cA41f7611dEf408122793c358a3d11E5a5](https://arbiscan.io/address/0x6cF1e9cA41f7611dEf408122793c358a3d11E5a5) | [0x6cF1e9cA41f7611dEf408122793c358a3d11E5a5](https://basescan.org/address/0x6cF1e9cA41f7611dEf408122793c358a3d11E5a5) | [0x6cF1e9cA41f7611dEf408122793c358a3d11E5a5](https://bscscan.com/address/0x6cF1e9cA41f7611dEf408122793c358a3d11E5a5) | [0x6cF1e9cA41f7611dEf408122793c358a3d11E5a5](https://snowscan.xyz/address/0x6cF1e9cA41f7611dEf408122793c358a3d11E5a5) | [0x6cF1e9cA41f7611dEf408122793c358a3d11E5a5](https://optimistic.etherscan.io/address/0x6cF1e9cA41f7611dEf408122793c358a3d11E5a5) | [0x6cF1e9cA41f7611dEf408122793c358a3d11E5a5](https://polygonscan.com/address/0x6cF1e9cA41f7611dEf408122793c358a3d11E5a5) | [0x6cF1e9cA41f7611dEf408122793c358a3d11E5a5](https://explorer.lens.xyz/address/0x6cF1e9cA41f7611dEf408122793c358a3d11E5a5) | [0x6cf1e9ca41f7611def408122793c358a3d11e5a5](https://lineascan.build/address/0x6cf1e9ca41f7611def408122793c358a3d11e5a5) | [0x6cf1e9ca41f7611def408122793c358a3d11e5a5](https://plasmascan.to/address/0x6cf1e9ca41f7611def408122793c358a3d11e5a5) | -                                                                                                                                |
| `GoodAfterTime`                | [0xdaf33924925e03c9cc3a10d434016d6cfad0add5](https://etherscan.io/address/0xdaf33924925e03c9cc3a10d434016d6cfad0add5) | [0xdaf33924925e03c9cc3a10d434016d6cfad0add5](https://gnosisscan.io/address/0xdaf33924925e03c9cc3a10d434016d6cfad0add5) | [0xdaf33924925e03c9cc3a10d434016d6cfad0add5](https://sepolia.etherscan.io/address/0xdaf33924925e03c9cc3a10d434016d6cfad0add5) | [0xdaf33924925e03c9cc3a10d434016d6cfad0add5](https://arbiscan.io/address/0xdaf33924925e03c9cc3a10d434016d6cfad0add5) | [0xdaf33924925e03c9cc3a10d434016d6cfad0add5](https://basescan.org/address/0xdaf33924925e03c9cc3a10d434016d6cfad0add5) | [0xdaf33924925e03c9cc3a10d434016d6cfad0add5](https://bscscan.com/address/0xdaf33924925e03c9cc3a10d434016d6cfad0add5) | [0xdaf33924925e03c9cc3a10d434016d6cfad0add5](https://snowscan.xyz/address/0xdaf33924925e03c9cc3a10d434016d6cfad0add5) | [0xdaf33924925e03c9cc3a10d434016d6cfad0add5](https://optimistic.etherscan.io/address/0xdaf33924925e03c9cc3a10d434016d6cfad0add5) | [0xdaf33924925e03c9cc3a10d434016d6cfad0add5](https://polygonscan.com/address/0xdaf33924925e03c9cc3a10d434016d6cfad0add5) | [0xdaf33924925e03c9cc3a10d434016d6cfad0add5](https://explorer.lens.xyz/address/0xdaf33924925e03c9cc3a10d434016d6cfad0add5) | [0xdaf33924925e03c9cc3a10d434016d6cfad0add5](https://lineascan.build/address/0xdaf33924925e03c9cc3a10d434016d6cfad0add5) | [0xdaf33924925e03c9cc3a10d434016d6cfad0add5](https://plasmascan.to/address/0xdaf33924925e03c9cc3a10d434016d6cfad0add5) | -                                                                                                                                |
| `PerpetualStableSwap`          | [0x519BA24e959E33b3B6220CA98bd353d8c2D89920](https://etherscan.io/address/0x519BA24e959E33b3B6220CA98bd353d8c2D89920) | [0x519BA24e959E33b3B6220CA98bd353d8c2D89920](https://gnosisscan.io/address/0x519BA24e959E33b3B6220CA98bd353d8c2D89920) | [0x519BA24e959E33b3B6220CA98bd353d8c2D89920](https://sepolia.etherscan.io/address/0x519BA24e959E33b3B6220CA98bd353d8c2D89920) | [0x519BA24e959E33b3B6220CA98bd353d8c2D89920](https://arbiscan.io/address/0x519BA24e959E33b3B6220CA98bd353d8c2D89920) | [0x519BA24e959E33b3B6220CA98bd353d8c2D89920](https://basescan.org/address/0x519BA24e959E33b3B6220CA98bd353d8c2D89920) | [0x519BA24e959E33b3B6220CA98bd353d8c2D89920](https://bscscan.com/address/0x519BA24e959E33b3B6220CA98bd353d8c2D89920) | [0x519BA24e959E33b3B6220CA98bd353d8c2D89920](https://snowscan.xyz/address/0x519BA24e959E33b3B6220CA98bd353d8c2D89920) | [0x519BA24e959E33b3B6220CA98bd353d8c2D89920](https://optimistic.etherscan.io/address/0x519BA24e959E33b3B6220CA98bd353d8c2D89920) | [0x519BA24e959E33b3B6220CA98bd353d8c2D89920](https://polygonscan.com/address/0x519BA24e959E33b3B6220CA98bd353d8c2D89920) | [0x519BA24e959E33b3B6220CA98bd353d8c2D89920](https://explorer.lens.xyz/address/0x519BA24e959E33b3B6220CA98bd353d8c2D89920) | [0x519BA24e959E33b3B6220CA98bd353d8c2D89920](https://lineascan.build/address/0x519BA24e959E33b3B6220CA98bd353d8c2D89920) | [0x519BA24e959E33b3B6220CA98bd353d8c2D89920](https://plasmascan.to/address/0x519BA24e959E33b3B6220CA98bd353d8c2D89920) | -                                                                                                                                |
| `TradeAboveThreshold`          | [0x812308712a6d1367f437e1c1e4af85c854e1e9f6](https://etherscan.io/address/0x812308712a6d1367f437e1c1e4af85c854e1e9f6) | [0x812308712a6d1367f437e1c1e4af85c854e1e9f6](https://gnosisscan.io/address/0x812308712a6d1367f437e1c1e4af85c854e1e9f6) | [0x812308712a6d1367f437e1c1e4af85c854e1e9f6](https://sepolia.etherscan.io/address/0x812308712a6d1367f437e1c1e4af85c854e1e9f6) | [0x812308712a6d1367f437e1c1e4af85c854e1e9f6](https://arbiscan.io/address/0x812308712a6d1367f437e1c1e4af85c854e1e9f6) | [0x812308712a6d1367f437e1c1e4af85c854e1e9f6](https://basescan.org/address/0x812308712a6d1367f437e1c1e4af85c854e1e9f6) | [0x812308712a6d1367f437e1c1e4af85c854e1e9f6](https://bscscan.com/address/0x812308712a6d1367f437e1c1e4af85c854e1e9f6) | [0x812308712a6d1367f437e1c1e4af85c854e1e9f6](https://snowscan.xyz/address/0x812308712a6d1367f437e1c1e4af85c854e1e9f6) | [0x812308712a6d1367f437e1c1e4af85c854e1e9f6](https://optimistic.etherscan.io/address/0x812308712a6d1367f437e1c1e4af85c854e1e9f6) | [0x812308712a6d1367f437e1c1e4af85c854e1e9f6](https://polygonscan.com/address/0x812308712a6d1367f437e1c1e4af85c854e1e9f6) | [0x812308712a6d1367f437e1c1e4af85c854e1e9f6](https://explorer.lens.xyz/address/0x812308712a6d1367f437e1c1e4af85c854e1e9f6) | [0x812308712a6d1367f437e1c1e4af85c854e1e9f6](https://lineascan.build/address/0x812308712a6d1367f437e1c1e4af85c854e1e9f6) | [0x812308712a6d1367f437e1c1e4af85c854e1e9f6](https://plasmascan.to/address/0x812308712a6d1367f437e1c1e4af85c854e1e9f6) | -                                                                                                                                |
| `StopLoss`                     | [0x412c36e5011cd2517016d243a2dfb37f73a242e7](https://etherscan.io/address/0x412c36e5011cd2517016d243a2dfb37f73a242e7) | [0x412c36e5011cd2517016d243a2dfb37f73a242e7](https://gnosisscan.io/address/0x412c36e5011cd2517016d243a2dfb37f73a242e7) | [0x412c36e5011cd2517016d243a2dfb37f73a242e7](https://sepolia.etherscan.io/address/0x412c36e5011cd2517016d243a2dfb37f73a242e7) | [0x412c36e5011cd2517016d243a2dfb37f73a242e7](https://arbiscan.io/address/0x412c36e5011cd2517016d243a2dfb37f73a242e7) | [0x412c36e5011cd2517016d243a2dfb37f73a242e7](https://basescan.org/address/0x412c36e5011cd2517016d243a2dfb37f73a242e7) | [0x412c36e5011cd2517016d243a2dfb37f73a242e7](https://bscscan.com/address/0x412c36e5011cd2517016d243a2dfb37f73a242e7) | [0x412c36e5011cd2517016d243a2dfb37f73a242e7](https://snowscan.xyz/address/0x412c36e5011cd2517016d243a2dfb37f73a242e7) | [0x412c36e5011cd2517016d243a2dfb37f73a242e7](https://optimistic.etherscan.io/address/0x412c36e5011cd2517016d243a2dfb37f73a242e7) | [0x412c36e5011cd2517016d243a2dfb37f73a242e7](https://polygonscan.com/address/0x412c36e5011cd2517016d243a2dfb37f73a242e7) | [0x412c36e5011cd2517016d243a2dfb37f73a242e7](https://explorer.lens.xyz/address/0x412c36e5011cd2517016d243a2dfb37f73a242e7) | [0x412c36e5011cd2517016d243a2dfb37f73a242e7](https://lineascan.build/address/0x412c36e5011cd2517016d243a2dfb37f73a242e7) | [0x412c36e5011cd2517016d243a2dfb37f73a242e7](https://plasmascan.to/address/0x412c36e5011cd2517016d243a2dfb37f73a242e7) | -                                                                                                                                |
| `CurrentBlockTimestampFactory` | [0x52eD56Da04309Aca4c3FECC595298d80C2f16BAc](https://etherscan.io/address/0x52eD56Da04309Aca4c3FECC595298d80C2f16BAc) | [0x52eD56Da04309Aca4c3FECC595298d80C2f16BAc](https://gnosisscan.io/address/0x52eD56Da04309Aca4c3FECC595298d80C2f16BAc) | [0x52eD56Da04309Aca4c3FECC595298d80C2f16BAc](https://sepolia.etherscan.io/address/0x52eD56Da04309Aca4c3FECC595298d80C2f16BAc) | [0x52eD56Da04309Aca4c3FECC595298d80C2f16BAc](https://arbiscan.io/address/0x52eD56Da04309Aca4c3FECC595298d80C2f16BAc) | [0x52eD56Da04309Aca4c3FECC595298d80C2f16BAc](https://basescan.org/address/0x52eD56Da04309Aca4c3FECC595298d80C2f16BAc) | [0x52eD56Da04309Aca4c3FECC595298d80C2f16BAc](https://bscscan.com/address/0x52eD56Da04309Aca4c3FECC595298d80C2f16BAc) | [0x52eD56Da04309Aca4c3FECC595298d80C2f16BAc](https://snowscan.xyz/address/0x52eD56Da04309Aca4c3FECC595298d80C2f16BAc) | [0x52eD56Da04309Aca4c3FECC595298d80C2f16BAc](https://optimistic.etherscan.io/address/0x52eD56Da04309Aca4c3FECC595298d80C2f16BAc) | [0x52eD56Da04309Aca4c3FECC595298d80C2f16BAc](https://polygonscan.com/address/0x52eD56Da04309Aca4c3FECC595298d80C2f16BAc) | [0x52eD56Da04309Aca4c3FECC595298d80C2f16BAc](https://explorer.lens.xyz/address/0x52eD56Da04309Aca4c3FECC595298d80C2f16BAc) | [0x52eD56Da04309Aca4c3FECC595298d80C2f16BAc](https://lineascan.build/address/0x52eD56Da04309Aca4c3FECC595298d80C2f16BAc) | [0x52eD56Da04309Aca4c3FECC595298d80C2f16BAc](https://plasmascan.to/address/0x52eD56Da04309Aca4c3FECC595298d80C2f16BAc) | -                                                                                                                                |
| `ComposableCowPoller`          | [0xd8088f0d57dB91AC6404FB3a9723A890100a6bB3](https://etherscan.io/address/0xd8088f0d57dB91AC6404FB3a9723A890100a6bB3) | [0xd8088f0d57dB91AC6404FB3a9723A890100a6bB3](https://gnosisscan.io/address/0xd8088f0d57dB91AC6404FB3a9723A890100a6bB3) | [0xd8088f0d57dB91AC6404FB3a9723A890100a6bB3](https://sepolia.etherscan.io/address/0xd8088f0d57dB91AC6404FB3a9723A890100a6bB3) | [0xd8088f0d57dB91AC6404FB3a9723A890100a6bB3](https://arbiscan.io/address/0xd8088f0d57dB91AC6404FB3a9723A890100a6bB3) | [0xd8088f0d57dB91AC6404FB3a9723A890100a6bB3](https://basescan.org/address/0xd8088f0d57dB91AC6404FB3a9723A890100a6bB3) | [0xd8088f0d57dB91AC6404FB3a9723A890100a6bB3](https://bscscan.com/address/0xd8088f0d57dB91AC6404FB3a9723A890100a6bB3) | [0xd8088f0d57dB91AC6404FB3a9723A890100a6bB3](https://snowscan.xyz/address/0xd8088f0d57dB91AC6404FB3a9723A890100a6bB3) | [0xd8088f0d57dB91AC6404FB3a9723A890100a6bB3](https://optimistic.etherscan.io/address/0xd8088f0d57dB91AC6404FB3a9723A890100a6bB3) | [0xd8088f0d57dB91AC6404FB3a9723A890100a6bB3](https://polygonscan.com/address/0xd8088f0d57dB91AC6404FB3a9723A890100a6bB3) | -                                                                                                                          | [0xd8088f0d57dB91AC6404FB3a9723A890100a6bB3](https://lineascan.build/address/0xd8088f0d57dB91AC6404FB3a9723A890100a6bB3) | [0xd8088f0d57dB91AC6404FB3a9723A890100a6bB3](https://plasmascan.to/address/0xd8088f0d57dB91AC6404FB3a9723A890100a6bB3) | [0xd8088f0d57dB91AC6404FB3a9723A890100a6bB3](https://explorer.inkonchain.com/address/0xd8088f0d57dB91AC6404FB3a9723A890100a6bB3) |

#### Audits

The core of the framework — `ComposableCoW` and `ExtensibleFallbackHandler` — has been audited by:

- Ackee Blockchain: [CoW Protocol - `ComposableCoW` and `ExtensibleFallbackHandler`](./audits/ackee-blockchain-cow-protocol-composablecow-extensiblefallbackhandler-report-1.2.pdf)
- Gnosis internal audit: [ComposableCoW - May/July 2023](./audits/gnosis-ComposableCoWMayJul2023.pdf)
- Gnosis internal audit (August 2024): [ComposableCoW - Diff between May/July 2023 and August 2024](./audits/Composable_CoW_Diff.pdf)

Not every contract in the table above is covered by these reports. Several order types, and
`ComposableCowPoller`, were added after they were written and are therefore outside their scope. Refer to
the scope section of each report to check whether a given contract was reviewed.

### Environment setup

Copy the `.env.example` to `.env` and set the applicable configuration variables for the testing / deployment environment.

### Testing

Effort has been made to adhere as close as possible to [best practices](https://book.getfoundry.sh/guides/best-practices), with _unit_, _fuzzing_ and _fork_ tests being implemented.

**NOTE:** Fuzz tests also include a `simulate` that runs full end-to-end integration testing, including the ability to settle conditional orders. Fork testing simulates end-to-end against production ethereum mainnet contracts, and as such requires `ETH_RPC_URL` to be defined (this should correspond to an archive node).

```bash
forge test -vvv --no-match-test "fork|[fF]uzz" # Basic unit testing only
forge test -vvv --no-match-test "fork" # Unit and fuzz testing
forge test -vvv # Unit, fuzz, and fork testing
```

### Coverage

```bash
forge coverage -vvv --no-match-test "fork" --report summary
```

### Deploy the older contracts (legacy)

Older contract like `ComposableCoW can no longer be deployed to their official addresses by compiling this repository (see
[#93](https://github.com/cowprotocol/composable-cow/issues/93)). These are all affected contracts:

`ComposableCoW`, `CurrentBlockTimestampFactory`, `ExtensibleFallbackHandler`, `GoodAfterTime`,
`PerpetualStableSwap`, `StopLoss`, `TWAP`, `TradeAboveThreshold`.

Their recorded initcode is replayed instead:

```bash
bash dev/deploy-canonical.sh --rpc-url $ETH_RPC_URL                                # dry run
PRIVATE_KEY=... bash dev/deploy-canonical.sh --rpc-url $ETH_RPC_URL --broadcast
```

See [`canonical/`](./canonical) for how it works and what it covers.

### Deploy newer contracts

Every contract not listed in the legacy section is deployed using the official foundry scripts.

To deploy all newer contracts in a single run:

```bash
source .env
forge script script/deploy_All.s.sol:DeployAll --rpc-url $ETH_RPC_URL --broadcast -vvvv --verify
```

By default it skips the legacy contracts and binds to their canonical addresses, deploying
everything else. Pass `CANONICAL=false` to deploy them from source too: those addresses won't match
the canonical ones, but they are still deterministic.

Contracts already on the chain are reported and skipped, so an interrupted run can be repeated.

### Deploy a single contract

Each contract also has its own script, for when only one of them needs deploying:

```bash
forge script script/deploy_ComposableCoW.s.sol:DeployComposableCoW --rpc-url $ETH_RPC_URL --broadcast -vvvv --verify
forge script script/deploy_ExtensibleFallbackHandler.s.sol:DeployExtensibleFallbackHandler --rpc-url $ETH_RPC_URL --broadcast -vvvv --verify
forge script script/deploy_ValueFactories.s.sol:DeployValueFactories --rpc-url $ETH_RPC_URL --broadcast -vvvv --verify
```

`ComposableCowPoller` pins a `ComposableCoW` and the `COWShedFactoryForComposableCoW`, so it needs
`COMPOSABLE_COW` and `COW_SHED_FACTORY_FOR_COMPOSABLE_COW` alongside `SETTLEMENT`, and checks each
address holds the contract it claims:

```bash
SETTLEMENT=0x9008D19f58AAbD9eD0D60971565AA8510560ab41 \
  COMPOSABLE_COW=0xfdaFc9d1902f4e0b84f65F49f244b32b31013b74 \
  COW_SHED_FACTORY_FOR_COMPOSABLE_COW=0x221c28ec177cf7da6f837dfd0052ba8f265fb4ca \
  SALT=v1.2.0 \
  forge script script/deploy_ComposableCowPoller.s.sol:DeployComposableCowPoller --rpc-url $ETH_RPC_URL --broadcast -vvvv --verify
```

### Updating `networks.json`

[`networks.json`](./networks.json) lists the address and creation transaction of the latest official deployments by chain.

It is generated automatically. After deploying, regenerate it with:

```bash
bash dev/generate-networks-file.sh > networks.json
```

The script figures out the official contract address from 2 sources:

- `broadcast/**/*.json`: Reads the Foundry deployment artifacts.
- `broadcast/networks-manual.json`: Some chains can't be deployed to with the scripts (see
  [#93](https://github.com/cowprotocol/composable-cow/issues/93)) and are deployed by hand, leaving no
  artifact behind. Record those in [`broadcast/networks-manual.json`](./broadcast/networks-manual.json),
  which has the same shape as `networks.json` and is merged on top of the generated result.

Re-running the script on an unchanged repository must reproduce the committed file, so a quick way to check there´s no drift is to run:

```bash
diff -u networks.json <(bash dev/generate-networks-file.sh)
```

Only chain `31337` is gitignored under `broadcast/`, so broadcasting to a local node that
impersonates a real chain id leaves artifacts that override the published addresses. Keep anvil on
its default chain id, and run the `diff` above before committing anything under `broadcast/`.

### Contract verification on block explorer

There's a dedicated script to verify all contracts at the same time once they have been deployed on a new chain:

```sh
export ETHERSCAN_API_KEY="your API key here"
chain_id=1337
dev/verify-contracts.sh "$chain_id"
```

If this doesn't work, check out [broadcast/StandardJsonInput/README.md](./broadcast/StandardJsonInput/README.md).

`foundry.toml` sets `bytecode_hash = "none"`, so the deployed bytecode carries no metadata:
explorers still verify it, but Sourcify cannot record a full match.

### Local deployment

For local integration testing, including the use of [Watch Tower](https://github.com/cowprotocol/tenderly-watch-tower), it may be useful deploying to a _forked_ mainnet environment. This can be done with `anvil`.

1. Open a terminal and run `anvil`:

   ```bash
   anvil --code-size-limit 50000 --block-time 5
   ```

   **NOTE**: When deploying the full stack on `anvil`, the balancer vault may exceed contract code size limits necessitating the use of `--code-size-limit`.

2. Follow the previous deployment directions, with this time specifying `anvil` as the RPC-URL:

   ```bash
   source .env
   forge script script/deploy_AnvilStack.s.sol:DeployAnvilStack --rpc-url http://127.0.0.1:8545 --broadcast -vvvv
   ```

   **NOTE**: Within the output of the above command, there will be an address for a `Safe` that was deployed to `anvil`. This is needed for the next step.

   **NOTE:** `--verify` is omitted as with local deployments, these should not be submitted to Etherscan for verification.

3. To then simulate the creation of a single order:

   ```bash
   source .env
   SAFE="address here" forge script script/submit_SingleOrder.s.sol:SubmitSingleOrder --rpc-url http://127.0.0.1:8545 --broadcast
   ```
