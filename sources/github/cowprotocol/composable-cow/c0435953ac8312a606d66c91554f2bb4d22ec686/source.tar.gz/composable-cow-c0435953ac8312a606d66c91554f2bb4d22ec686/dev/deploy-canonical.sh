#!/bin/bash

set -o errexit -o pipefail -o nounset

# Deploy the older contracts to a new chain at their official addresses, by replaying the initcode
# recorded in `canonical/`. See `canonical/README.md` for why this exists.

repo_root_dir="$(git rev-parse --show-toplevel)"
canonical_dir="$repo_root_dir/canonical"
initcode_dir="$canonical_dir/initcode"
manifest="$canonical_dir/manifest.json"

# Deterministic deployment proxy: takes `salt ++ initcode` as calldata and CREATE2s it.
deployer=0x4e59b44847b379578588920cA78FbF26c0B4956C

broadcast=false
rpc_url=${ETH_RPC_URL:-}

usage() {
  cat <<'USAGE'
Usage: dev/deploy-canonical.sh [--rpc-url URL] [--broadcast]

Without --broadcast the script only reports what it would do; nothing is sent.

Environment:
  ETH_RPC_URL   used when --rpc-url is not given
  PRIVATE_KEY   deployer key, required with --broadcast
USAGE
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    --rpc-url) rpc_url=$2; shift 2 ;;
    --broadcast) broadcast=true; shift ;;
    -h | --help) usage; exit 0 ;;
    *) echo "Error: unknown argument '$1'." >&2; usage >&2; exit 1 ;;
  esac
done

if [[ -z "$rpc_url" ]]; then
  echo "Error: no RPC endpoint. Pass --rpc-url or set ETH_RPC_URL." >&2
  exit 1
fi

if [[ "$broadcast" == true && -z "${PRIVATE_KEY:-}" ]]; then
  echo "Error: PRIVATE_KEY must be set to broadcast." >&2
  exit 1
fi

# Fails loudly instead of returning "0x", so a broken RPC is never read as "nothing deployed here".
code_at() {
  local address=$1 code
  if ! code=$(cast code "$address" --rpc-url "$rpc_url" 2>&1); then
    echo "Error: could not read code at $address." >&2
    echo "       $code" >&2
    exit 1
  fi
  printf '%s' "$code"
}

if ! chain_id=$(cast chain-id --rpc-url "$rpc_url" 2>&1); then
  echo "Error: could not reach the RPC endpoint at $rpc_url." >&2
  echo "       $chain_id" >&2
  exit 1
fi
echo "Chain id: $chain_id"

# Required: the deployer address is part of the CREATE2 preimage.
if [[ "$(code_at "$deployer")" == "0x" ]]; then
  cat >&2 <<EOF
Error: the deterministic deployment proxy is not present at $deployer on chain $chain_id.

The canonical addresses cannot be reproduced without it. Deploy it first by broadcasting its
keyless transaction, then re-run this script:
  https://github.com/Arachnid/deterministic-deployment-proxy
EOF
  exit 1
fi
echo "Deterministic deployment proxy: present"

# Ensure the settlement is deployed, because `ComposableCoW`'s reads from it in the constructor
# The settlement address is read from the initcode (to avoid hardcoding)
composable_cow_initcode=$(cat "$initcode_dir/ComposableCoW.initcode")
settlement="0x${composable_cow_initcode: -40}"
if [[ "$(code_at "$settlement")" == "0x" ]]; then
  cat >&2 <<EOF
Error: GPv2Settlement is not present at $settlement on chain $chain_id.

ComposableCoW's constructor calls domainSeparator(), so it must be deployed first.
EOF
  exit 1
fi

# Code at the address is not enough: `ComposableCoW` stores the separator forever, so a wrong one
# (settlement deployed for another chain id, or a different contract entirely) is unrecoverable.
# GPv2Signing computes it as the EIP-712 domain of ("Gnosis Protocol", "v2", chain id, settlement).
expected_domain_separator=$(cast keccak "$(cast abi-encode \
  'f(bytes32,bytes32,bytes32,uint256,address)' \
  "$(cast keccak 'EIP712Domain(string name,string version,uint256 chainId,address verifyingContract)')" \
  "$(cast keccak 'Gnosis Protocol')" \
  "$(cast keccak 'v2')" \
  "$chain_id" \
  "$settlement")")
if ! domain_separator=$(cast call "$settlement" 'domainSeparator()(bytes32)' --rpc-url "$rpc_url" 2>&1); then
  cat >&2 <<EOF
Error: the contract at $settlement does not answer domainSeparator().
       $domain_separator

It is not a GPv2Settlement, so ComposableCoW's constructor would revert.
EOF
  exit 1
fi
if [[ "$domain_separator" != "$expected_domain_separator" ]]; then
  cat >&2 <<EOF
Error: unexpected domain separator at $settlement on chain $chain_id.
  expected $expected_domain_separator
  got      $domain_separator

Deploying against it would bake the wrong separator into ComposableCoW.
EOF
  exit 1
fi
echo "GPv2Settlement: present at $settlement, domain separator matches chain $chain_id"

# Fail closed on a corrupted or hand-edited `canonical/` before touching the chain.
echo
echo "Verifying recorded initcode..."
bash "$repo_root_dir/dev/verify-canonical.sh"

echo
deployed=0
skipped=0
records=""
# One level shallower than Foundry's `broadcast/<script>/<chain>/run-*.json`, because
# `generate-networks-file.sh` globs `broadcast/*/*/*.json` and reads every match as a run artifact.
deployment_dir="$repo_root_dir/broadcast/canonical"
deployment_file="$deployment_dir/$chain_id.json"
while read -r name; do
  salt=$(jq -r --arg n "$name" '.[$n].salt' "$manifest")
  address=$(jq -r --arg n "$name" '.[$n].address' "$manifest")
  initcode=$(cat "$initcode_dir/$name.initcode")

  if [[ "$(code_at "$address")" != "0x" ]]; then
    printf '%-30s %s  already deployed\n' "$name" "$address"
    skipped=$((skipped + 1))
    continue
  fi

  if [[ "$broadcast" != true ]]; then
    printf '%-30s %s  would deploy\n' "$name" "$address"
    continue
  fi

  printf '%-30s %s  deploying...\n' "$name" "$address"
  receipt=$(cast send "$deployer" "0x${salt#0x}${initcode#0x}" \
    --rpc-url "$rpc_url" --private-key "$PRIVATE_KEY" --json)

  # The proxy does not revert on every failure mode, so check rather than trust the receipt.
  if [[ "$(code_at "$address")" == "0x" ]]; then
    echo "Error: $name did not appear at $address after broadcasting." >&2
    exit 1
  fi
  printf '%-30s %s  deployed\n' "$name" "$address"
  deployed=$((deployed + 1))

  # Leave some deployment records, so `networks.json` can be regenerated from it.
  records="${records}$(jq -nc --arg name "$name" --arg address "$address" \
    --arg hash "$(jq -r '.transactionHash' <<<"$receipt")" \
    '{name: $name, address: $address, transactionHash: $hash}')
"
done < <(jq -r 'keys[]' "$manifest")

# Write the deployment records in `networks.json` format (so it can be merged straight)
if [[ -n "$records" ]]; then
  mkdir -p "$deployment_dir"
  existing='{}'
  if [[ -f "$deployment_file" ]]; then
    existing=$(cat "$deployment_file")
  fi
  printf '%s' "$records" | jq --slurp --sort-keys --arg chain "$chain_id" --argjson existing "$existing" '
    map({(.name): {($chain): {address: .address, transactionHash: .transactionHash}}})
    | reduce .[] as $record ($existing; . * $record)
  ' > "$deployment_file"
fi

echo
if [[ "$broadcast" != true ]]; then
  echo "Dry run. Re-run with --broadcast to send the transactions."
else
  echo "Deployed $deployed contract(s), skipped $skipped already present."
  if [[ -n "$records" ]]; then
    echo "Transactions recorded in ${deployment_file#"$repo_root_dir/"}; merge them into networks.json."
  fi
fi
