import { ethers } from "ethers";
import { Database } from "../db";
import { NetworkConfig, ProcessedBlock, OrderPlacement } from "../types";
import { createProvider, getLogger, Logger } from "../utils";
import { ORDER_PLACEMENT_TOPIC, decodeOrderPlacementLogs } from "./events";
import { FactoryVerifier } from "./factory";
import { OrderPoster } from "../poster";

const DEFAULT_PAGE_SIZE = 5000;

/**
 * A ChainIndexer is responsible for one network:
 *  1. Syncs historical OrderPlacement events from deploymentBlock (or last checkpoint).
 *  2. Subscribes to new blocks and indexes events in real-time.
 */
export class ChainIndexer {
  private provider: ethers.Provider;
  private log: Logger;
  private running = false;
  private chainId: number | null = null;
  private verifier: FactoryVerifier;
  private poster: OrderPoster;

  constructor(
    private network: NetworkConfig,
    private db: Database,
  ) {
    this.log = getLogger("ChainIndexer", { chain: network.name });
    this.provider = createProvider(network.rpc);
    this.verifier = new FactoryVerifier(network.factoryAddress, this.provider);
    this.poster = new OrderPoster(network.orderBookApi);
  }

  async start(): Promise<void> {
    this.running = true;
    this.log.info(`Starting indexer for ${this.network.name}`);
    const network = await this.provider.getNetwork();
    this.chainId = Number(network.chainId);
    this.log.info(`Chain ID: ${this.chainId}`);

    await this.syncHistorical();

    if (this.running) {
      await this.subscribeLive();
    }
  }

  stop(): void {
    this.running = false;
    this.log.info("Stopping indexer");
    const p = this.provider;
    if (p instanceof ethers.WebSocketProvider) {
      p.destroy();
    }
  }

  // -------------------------------------------------------------------------
  // Historical sync
  // -------------------------------------------------------------------------

  private async syncHistorical(): Promise<void> {
    const pageSize = this.network.pageSize ?? DEFAULT_PAGE_SIZE;
    const lastBlock = await this.db.getLastProcessedBlock(this.network.name);

    let fromBlock = lastBlock
      ? lastBlock.number + 1
      : this.network.deploymentBlock;

    const latestBlock = await this.provider.getBlockNumber();

    if (fromBlock > latestBlock) {
      this.log.info("Already in sync");
      return;
    }

    const totalBlocks = latestBlock - fromBlock;
    const pages = pageSize > 0 ? Math.ceil(totalBlocks / pageSize) : 1;

    this.log.info(
      `Syncing from block ${fromBlock} to ${latestBlock} (~${pages} page(s))`,
    );

    while (fromBlock <= latestBlock && this.running) {
      const toBlock =
        pageSize > 0
          ? Math.min(fromBlock + pageSize - 1, latestBlock)
          : latestBlock;

      const orders = await this.fetchEvents(fromBlock, toBlock);
      const block = await this.resolveBlock(toBlock);

      await this.db.commitBatch(this.network.name, orders, block);

      if (orders.length > 0) {
        this.log.info(
          `Blocks ${fromBlock}–${toBlock}: found ${orders.length} order(s)`,
        );
      } else {
        this.log.debug(`Blocks ${fromBlock}–${toBlock}: no events`);
      }

      fromBlock = toBlock + 1;
    }

    this.log.info("Historical sync complete");
  }

  private async fetchLogs(
    fromBlock: number,
    toBlock: number,
    retries = 3,
  ): Promise<ethers.Log[]> {
    for (let attempt = 1; attempt <= retries; attempt++) {
      try {
        return await this.provider.getLogs({
          topics: [ORDER_PLACEMENT_TOPIC],
          fromBlock,
          toBlock,
        });
      } catch (err) {
        if (attempt === retries) throw err;
        const delay = attempt * 2000;
        this.log.warn(
          `getLogs failed for ${fromBlock}–${toBlock} (attempt ${attempt}/${retries}), retrying in ${delay}ms`,
        );
        await new Promise((r) => setTimeout(r, delay));
      }
    }
    return []; // unreachable
  }

  // -------------------------------------------------------------------------
  // Live subscription
  // -------------------------------------------------------------------------

  private async subscribeLive(): Promise<void> {
    this.log.info("Subscribing to new blocks");

    return new Promise<void>((resolve) => {
      this.provider.on("block", async (blockNumber: number) => {
        if (!this.running) {
          resolve();
          return;
        }

        try {
          await this.processBlock(blockNumber);
        } catch (err) {
          this.log.error(`Error processing block ${blockNumber}:`, err);
        }
      });
    });
  }

  private async processBlock(blockNumber: number): Promise<void> {
    const orders = await this.fetchEvents(blockNumber, blockNumber);
    const block = await this.resolveBlock(blockNumber);

    await this.db.commitBatch(this.network.name, orders, block);

    if (orders.length > 0) {
      this.log.info(
        `Block ${blockNumber}: indexed ${orders.length} new order(s)`,
      );
    }
  }

  // -------------------------------------------------------------------------
  // Helpers
  // -------------------------------------------------------------------------

  private async fetchEvents(
    fromBlock: number,
    toBlock: number,
  ): Promise<OrderPlacement[]> {
    const logs = await this.fetchLogs(fromBlock, toBlock);

    const decoded = decodeOrderPlacementLogs(logs, this.chainId!);

    // // Verify each event came from a factory-deployed OrderFlow contract
    // const verified: OrderPlacement[] = [];
    // for (const placement of decoded) {
    //   if (
    //     await this.verifier.isLegitimate(
    //       placement.sender,
    //       placement.orderContract,
    //     )
    //   ) {
    //     verified.push(placement);
    //   }
    // }

    // Post verified orders to the OrderBook API
    await this.poster.postAll(decoded);
    return decoded;
  }

  private async resolveBlock(blockNumber: number): Promise<ProcessedBlock> {
    const block = await this.provider.getBlock(blockNumber);
    if (!block) {
      throw new Error(`Block ${blockNumber} not found`);
    }
    return {
      number: block.number,
      hash: block.hash!,
      timestamp: block.timestamp,
    };
  }
}
