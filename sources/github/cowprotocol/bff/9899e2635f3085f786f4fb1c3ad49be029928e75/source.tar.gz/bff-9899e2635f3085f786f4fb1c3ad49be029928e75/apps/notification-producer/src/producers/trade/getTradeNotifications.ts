import {
  AnyAppDataDocVersion,
  BARN_ETH_FLOW_ADDRESSES,
  COW_PROTOCOL_SETTLEMENT_CONTRACT_ADDRESS,
  COW_PROTOCOL_SETTLEMENT_CONTRACT_ADDRESS_STAGING,
  CowEnv,
  ETH_FLOW_ADDRESSES,
  getAddressKey,
  SupportedChainId,
  LatestAppDataDocVersion,
  areAddressesEqual,
} from '@cowprotocol/cow-sdk'
import { PushNotification } from '@cowprotocol/notifications'
import {
  Erc20Repository,
  getViemClients,
  OnChainPlacedOrdersRepository,
  OrderExecutionPosition,
  OrdersAppDataRepository,
  OrdersRepository,
  getOrderExecutionPositionKey,
} from '@cowprotocol/repositories'
import { bigIntReplacer, EvmChainId, logger } from '@cowprotocol/shared'
import { getAddress, parseAbi } from 'viem'
import { getBlockTimestamps } from '../../utils/getBlockTimestamps'
import { fromTradeToNotification } from './fromTradeToNotification'

const EVENTS = parseAbi([
  // 'event OrderInvalidated(address indexed owner, bytes orderUid)', // Do not index this event
  'event Trade(address indexed owner, address sellToken, address buyToken, uint256 sellAmount, uint256 buyAmount, uint256 feeAmount, bytes orderUid)',
])

export interface GetTradeNotificationParams {
  accounts: string[]
  fromBlock: bigint
  toBlock: bigint
  chainId: SupportedChainId
  erc20Repository: Erc20Repository
  onChainPlacedOrdersRepository: OnChainPlacedOrdersRepository
  ordersAppDataRepository: OrdersAppDataRepository
  ordersRepository: OrdersRepository
  prefix: string
}

export async function getTradeNotifications(params: GetTradeNotificationParams) {
  const {
    accounts,
    fromBlock,
    toBlock,
    chainId,
    erc20Repository,
    onChainPlacedOrdersRepository,
    ordersAppDataRepository,
    ordersRepository,
    prefix,
  } = params

  const client = getViemClients()[chainId as EvmChainId]

  const env: CowEnv = process.env.COW_PROTOCOL_ENV === 'staging' ? 'staging' : 'prod'

  const ethFlowAddress = getAddressKey(
    env === 'staging' ? BARN_ETH_FLOW_ADDRESSES[chainId] : ETH_FLOW_ADDRESSES[chainId]
  )
  const owners = [...accounts, ethFlowAddress]

  const settlementAddresses =
    env === 'staging' ? COW_PROTOCOL_SETTLEMENT_CONTRACT_ADDRESS_STAGING : COW_PROTOCOL_SETTLEMENT_CONTRACT_ADDRESS
  const settlementAddress = settlementAddresses[chainId]

  logger.debug(
    `${prefix} Fetching Trade logs from block ${fromBlock} to ${toBlock} on settlement contract ${settlementAddress}, filtered to ${owners.length} owner(s) (${accounts.length} subscribed + ${ethFlowAddress} eth-flow)`
  )

  const logs = await client.getLogs({
    events: EVENTS,
    fromBlock,
    toBlock,
    address: getAddress(settlementAddress),
    args: {
      owner: owners,
    } as any,
  })

  // Return empty array if no events
  if (logs.length === 0) {
    logger.debug(
      `${prefix} No Trade events found for blocks ${fromBlock}-${toBlock} matching the ${owners.length} watched owner(s). Note: trades from accounts not subscribed to push notifications (and not eth-flow) are filtered out at the RPC log query level and will never appear here.`
    )
    return []
  }

  logger.debug(`${prefix} Found ${logs.length} events`)
  const notificationLogs = getLatestTradeLogs(logs)

  const orderUids = notificationLogs.reduce<string[]>((acc, log) => {
    const { orderUid } = log.args

    if (log.eventName !== 'Trade' || !orderUid) return acc

    acc.push(orderUid.toLowerCase())

    return acc
  }, [])

  const ethFlowOrderIds = notificationLogs.reduce<string[]>((acc, log) => {
    const { owner, orderUid } = log.args

    if (log.eventName !== 'Trade') return acc
    if (!orderUid) return acc
    if (!owner || !areAddressesEqual(ethFlowAddress, owner)) return acc

    acc.push(orderUid)

    return acc
  }, [])

  const ethFlowOrderOwners = ethFlowOrderIds.length
    ? await onChainPlacedOrdersRepository.getAccountsForOrders(chainId, ethFlowOrderIds)
    : {}

  const ordersAppData = await ordersAppDataRepository.getAppDataForOrders(chainId, orderUids)

  const orderExecutionSnapshots = await ordersRepository.getOrderExecutionSnapshots(
    chainId,
    getOrderExecutionPositions(notificationLogs)
  )
  const blockTimestamps = await getBlockTimestamps(client, notificationLogs)

  const notificationPromises = notificationLogs.reduce<Promise<PushNotification>[]>((acc, log) => {
    switch (log.eventName) {
      case 'Trade': {
        const {
          owner,
          orderUid,
          sellToken: sellTokenAddress,
          buyToken: buyTokenAddress,
          sellAmount,
          buyAmount,
          feeAmount,
        } = log.args

        if (
          owner === undefined ||
          sellTokenAddress === undefined ||
          buyTokenAddress === undefined ||
          orderUid === undefined ||
          sellAmount === undefined ||
          buyAmount === undefined ||
          feeAmount === undefined
        ) {
          logger.error(`${prefix} Invalid Trade event ${JSON.stringify(log, bigIntReplacer, 2)}`)
          break
        }

        // orderUid is a 56-byte order digest, not an address, so getAddressKey() would leave it untouched: plain lowercase is correct here.
        const orderUidLower = orderUid.toLowerCase()
        const timestamp = log.blockNumber === null ? undefined : blockTimestamps.get(log.blockNumber)
        const orderExecutionPosition = getOrderExecutionPosition(log)
        const order = orderExecutionPosition
          ? orderExecutionSnapshots.get(getOrderExecutionPositionKey(orderExecutionPosition))
          : undefined
        const isEthFlowOrder = areAddressesEqual(ethFlowAddress, owner)
        const appData = ordersAppData.get(orderUidLower)
        const isBridgingOrder = getIsBridgingOrder(appData)

        const orderOwner = isEthFlowOrder
          ? Object.keys(ethFlowOrderOwners).find((key) => {
              const orderUids = ethFlowOrderOwners[key]

              return orderUids.includes(orderUidLower)
            })
          : getAddressKey(owner)

        if (!orderOwner) {
          logger.debug(
            `${prefix} Skipping eth-flow order ${orderUidLower} (tx=${log.transactionHash}): no matching owner found in on-chain placed orders`
          )
        } else if (isBridgingOrder) {
          logger.debug(`${prefix} Skipping bridging order ${orderUidLower} (tx=${log.transactionHash})`)
        }

        if (orderOwner && timestamp && !isBridgingOrder) {
          acc.push(
            fromTradeToNotification({
              prefix,
              isEthFlowOrder,
              id: 'Trade-' + log.transactionHash + '-' + log.logIndex,
              chainId,
              orderUid,
              owner: orderOwner,
              sellTokenAddress,
              buyTokenAddress,
              sellAmount,
              buyAmount,
              feeAmount,
              erc20Repository,
              transactionHash: log.transactionHash,
              logIndex: log.logIndex,
              timestamp,
              order,
              appData,
            })
          )
        }
        break
      }

      default:
        logger.info(`${prefix} Unknown event ${log}`)
        break
    }
    return acc
  }, [])

  // Return empty array if no notifications
  if (notificationPromises.length === 0) {
    return []
  }

  return Promise.all(notificationPromises)
}

type TradeLog = {
  eventName: string
  blockNumber: bigint | null
  logIndex: number | null
  args: { orderUid?: string }
}

export function getLatestTradeLogs<T extends TradeLog>(logs: T[]): T[] {
  const latestLogs = new Map<string, T>()

  for (const log of logs) {
    const position = getOrderExecutionPosition(log)
    if (!position) continue

    const currentLog = latestLogs.get(position.orderUid.toLowerCase())
    const currentPosition = currentLog && getOrderExecutionPosition(currentLog)
    if (
      !currentPosition ||
      position.blockNumber > currentPosition.blockNumber ||
      (position.blockNumber === currentPosition.blockNumber && position.logIndex > currentPosition.logIndex)
    ) {
      latestLogs.set(position.orderUid.toLowerCase(), log)
    }
  }

  return logs.filter((log) => {
    const position = getOrderExecutionPosition(log)
    return position !== undefined && latestLogs.get(position.orderUid.toLowerCase()) === log
  })
}

function getOrderExecutionPositions(logs: TradeLog[]): OrderExecutionPosition[] {
  return logs.flatMap((log) => {
    const position = getOrderExecutionPosition(log)
    return position ? [position] : []
  })
}

function getOrderExecutionPosition(log: TradeLog): OrderExecutionPosition | undefined {
  const { orderUid } = log.args
  if (!orderUid || log.blockNumber === null || log.logIndex === null) return undefined

  return { orderUid, blockNumber: log.blockNumber, logIndex: log.logIndex }
}

function getIsBridgingOrder(appData: AnyAppDataDocVersion | undefined) {
  return !!(appData as LatestAppDataDocVersion)?.metadata?.bridging
}
