import { getAddress } from 'viem'

import { AllChainIds, NativeCurrencyAddress, WrappedNativeTokenAddress } from '../const'
import { isSolanaChain, SOL_NATIVE_CURRENCY_ADDRESS, SupportedChainId } from '@cowprotocol/cow-sdk'

/**
 * Returns the token address. On EVM chains, this function will throw if the address passed is not an
 * Ethereum address, and will convert the address representing the native currency
 * (0xEeeeeEeeeEeEeeEeEeEeeEEEeeeeEeeeeeeeEEeE) into its wrapped version.
 * On Solana, addresses are case-sensitive base58 and are returned as-is (only the native SOL placeholder
 * is converted to its wrapped version), since they can't be checksummed/lowercased like EVM addresses.
 */
export function toTokenAddress(address: string, chainId: SupportedChainId): string {
  if (isSolanaChain(chainId)) {
    return address === SOL_NATIVE_CURRENCY_ADDRESS ? WrappedNativeTokenAddress[chainId] : address
  }

  if (address.toLocaleLowerCase() === NativeCurrencyAddress) {
    return WrappedNativeTokenAddress[chainId]
  }

  return getAddress(address.toLowerCase())
}

export function isSupportedChain(chain: number): chain is SupportedChainId {
  return AllChainIds.includes(chain as SupportedChainId)
}

export function toSupportedChainId(chain: string | number): SupportedChainId {
  if (typeof chain === 'string') {
    chain = parseInt(chain)
  }

  if (!isSupportedChain(chain)) {
    throw new Error(`Unsupported chain ID: ${chain}. Supported chains are: ${AllChainIds.join(', ')}`)
  }

  return chain
}

export function bigIntReplacer(key: string, value: any): any {
  if (typeof value === 'bigint') {
    return value.toString() + 'n'
  }
  return value
}

export function bigIntReviver(key: string, value: any): any {
  if (typeof value === 'string' && /^\d+n$/.test(value)) {
    return BigInt(value.slice(0, -1))
  }
  return value
}

export function sleep(ms: number) {
  return new Promise((resolve) => setTimeout(resolve, ms))
}

/**
 * Like `sleep`, but resolves early if `signal` is aborted, instead of always waiting the full `ms`.
 * Used to make polling loops shut down promptly instead of waiting out their current interval.
 */
export function interruptibleSleep(ms: number, signal?: AbortSignal): Promise<void> {
  if (signal?.aborted) {
    return Promise.resolve()
  }

  return new Promise((resolve) => {
    const onAbort = () => {
      clearTimeout(timer)
      resolve()
    }

    const timer = setTimeout(() => {
      signal?.removeEventListener('abort', onAbort)
      resolve()
    }, ms)

    signal?.addEventListener('abort', onAbort, { once: true })
  })
}

export function ensureEnvs(envs: string[]) {
  const missingEnvs = envs.filter((env) => !process.env[env])
  if (missingEnvs.length > 0) {
    throw new Error(`Missing required environment variables: ${missingEnvs.join(', ')}`)
  }
}
