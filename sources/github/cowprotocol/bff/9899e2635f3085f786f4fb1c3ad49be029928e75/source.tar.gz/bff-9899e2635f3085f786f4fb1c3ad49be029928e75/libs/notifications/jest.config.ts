/* eslint-disable */
export default {
  displayName: 'notifications',
  preset: '../../jest.preset.js',
  testEnvironment: 'node',
  transform: {
    '^.+\\.[tj]s$': ['ts-jest', { tsconfig: '<rootDir>/tsconfig.spec.json' }],
  },
  moduleFileExtensions: ['ts', 'js', 'html'],
  coverageDirectory: '../../coverage/libs/notifications',
  setupFilesAfterEnv: ['../../jest.setup.ts'],
};
