# Intellectual Property Notice

Copyright (c) 2021 Gnosis Ltd  
Copyright (c) 2022 Cow Services Lda

Except as otherwise noted (below and/or in individual files), this project is licensed under
the Apache License, Version 2.0 ([`LICENSE-APACHE`](LICENSE-APACHE) or <http://www.apache.org/licenses/LICENSE-2.0>) or
the MIT license, ([`LICENSE-MIT`](LICENSE-MIT) or <http://opensource.org/licenses/MIT>), at your option.
