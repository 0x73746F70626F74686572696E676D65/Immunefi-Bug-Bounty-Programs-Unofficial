use std::collections::HashMap;

use dalek_ff_group::Ristretto;
use ciphersuite::Ciphersuite;

use dockertest::DockerTest;

use crate::*;

mod key_gen;
pub(crate) use key_gen::key_gen;

mod batch;
pub(crate) use batch::{recv_batch_preprocesses, sign_batch, substrate_block};

mod send;

pub(crate) const COORDINATORS: usize = 4;
pub(crate) const THRESHOLD: usize = ((COORDINATORS * 2) / 3) + 1;

fn clone_without<K: Clone + core::cmp::Eq + core::hash::Hash, V: Clone>(
  map: &HashMap<K, V>,
  without: &K,
) -> HashMap<K, V> {
  let mut res = map.clone();
  res.remove(without).unwrap();
  res
}

fn new_test(
  network: ExternalNetworkId,
) -> (Vec<(Handles, <Ristretto as Ciphersuite>::F)>, DockerTest) {
  let mut coordinators = vec![];
  let mut test = DockerTest::new().with_network(dockertest::Network::Isolated);
  let mut eth_handle = None;
  for _ in 0 .. COORDINATORS {
    let (handles, coord_key, compositions) = processor_stack(network, eth_handle.clone());
    // TODO: Remove this once https://github.com/foundry-rs/foundry/issues/7955
    // This has all processors share an Ethereum node until we can sync controlled nodes
    if network == ExternalNetworkId::Ethereum {
      eth_handle = eth_handle.or_else(|| Some(handles.0.clone()));
    }
    coordinators.push((handles, coord_key));
    for composition in compositions {
      test.provide_container(composition);
    }
  }
  (coordinators, test)
}
