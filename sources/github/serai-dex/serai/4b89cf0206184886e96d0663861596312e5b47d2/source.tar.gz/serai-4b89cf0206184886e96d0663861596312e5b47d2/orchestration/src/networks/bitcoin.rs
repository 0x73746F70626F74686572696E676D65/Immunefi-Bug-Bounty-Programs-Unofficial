use std::path::Path;

use crate::{Network, Os, mimalloc, os, write_dockerfile};

pub fn bitcoin(orchestration_path: &Path, network: Network) {
  #[rustfmt::skip]
  const DOWNLOAD_BITCOIN: &str = r#"
FROM alpine:latest AS bitcoin

ENV BITCOIN_VERSION=27.1

RUN apk --no-cache add wget git gnupg

# Download Bitcoin
RUN wget -4 https://bitcoincore.org/bin/bitcoin-core-${BITCOIN_VERSION}/bitcoin-${BITCOIN_VERSION}-$(uname -m)-linux-gnu.tar.gz
RUN wget -4 https://bitcoincore.org/bin/bitcoin-core-${BITCOIN_VERSION}/SHA256SUMS
RUN wget -4 https://bitcoincore.org/bin/bitcoin-core-${BITCOIN_VERSION}/SHA256SUMS.asc

# Verify all sigs and check for a valid signature from laanwj -- 71A3
RUN git clone https://github.com/bitcoin-core/guix.sigs && \
  cd guix.sigs/builder-keys && \
  find . -iname '*.gpg' -exec gpg --import {} \; && \
  gpg --verify --status-fd 1 --verify ../../SHA256SUMS.asc ../../SHA256SUMS | grep "^\[GNUPG:\] VALIDSIG.*71A3B16735405025D447E8F274810B012346C9A6"

RUN grep bitcoin-${BITCOIN_VERSION}-$(uname -m)-linux-gnu.tar.gz SHA256SUMS | sha256sum -c

# Prepare Image
RUN tar xzvf bitcoin-${BITCOIN_VERSION}-$(uname -m)-linux-gnu.tar.gz
RUN mv bitcoin-${BITCOIN_VERSION}/bin/bitcoind .
"#;

  let setup = mimalloc(Os::Debian).to_string() + DOWNLOAD_BITCOIN;

  let run_bitcoin = format!(
    r#"
COPY --from=bitcoin --chown=bitcoin bitcoind /bin

EXPOSE 8332 8333

ADD /orchestration/{}/networks/bitcoin/run.sh /
CMD ["/run.sh"]
"#,
    network.label()
  );

  let run = os(Os::Debian, "", "bitcoin") + &run_bitcoin;
  let res = setup + &run;

  let mut bitcoin_path = orchestration_path.to_path_buf();
  bitcoin_path.push("networks");
  bitcoin_path.push("bitcoin");
  bitcoin_path.push("Dockerfile");

  write_dockerfile(bitcoin_path, &res);
}
