// Copyright 2017-2023 Weald Technology Trading.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package ens

import (
	"context"
	"errors"
	"fmt"

	"github.com/ensdomains/go-ens/v4/contracts/reverseresolver"
	"github.com/ethereum/go-ethereum/accounts/abi/bind"
	"github.com/ethereum/go-ethereum/common"
)

// ReverseResolver is the structure for the reverse resolver contract.
type ReverseResolver struct {
	Contract     *reverseresolver.Contract
	ContractAddr common.Address
}

// NewReverseResolverFor creates a reverse resolver contract for the given address.
func NewReverseResolverFor(backend bind.ContractBackend, address common.Address) (*ReverseResolver, error) {
	registry, err := NewRegistry(backend)
	if err != nil {
		return nil, err
	}

	// Now fetch the resolver.
	domain := fmt.Sprintf("%x.addr.reverse", address.Bytes())
	contractAddress, err := registry.ResolverAddress(domain)
	if err != nil {
		return nil, err
	}
	return NewReverseResolverAt(backend, contractAddress)
}

// NewReverseResolver obtains the reverse resolver.
func NewReverseResolver(backend bind.ContractBackend) (*ReverseResolver, error) {
	reverseRegistrar, err := NewReverseRegistrar(backend)
	if err != nil {
		return nil, err
	}

	// Now fetch the default resolver.
	address, err := reverseRegistrar.DefaultResolverAddress()
	if err != nil {
		return nil, err
	}

	return NewReverseResolverAt(backend, address)
}

// NewReverseResolverAt obtains the reverse resolver at a given address.
func NewReverseResolverAt(backend bind.ContractBackend, address common.Address) (*ReverseResolver, error) {
	// Instantiate the reverse registrar contract.
	contract, err := reverseresolver.NewContract(address, backend)
	if err != nil {
		return nil, err
	}

	// Ensure the contract is a resolver.
	nameHash, err := NameHash("0.addr.reverse")
	if err != nil {
		return nil, err
	}
	_, err = contract.Name(nil, nameHash)
	if err != nil && err.Error() == "no contract code at given address" {
		return nil, fmt.Errorf("not a resolver")
	}

	return &ReverseResolver{
		Contract:     contract,
		ContractAddr: address,
	}, nil
}

// Name obtains the name for an address.
func (r *ReverseResolver) Name(address common.Address) (string, error) {
	nameHash, err := NameHash(fmt.Sprintf("%s.addr.reverse", address.Hex()[2:]))
	if err != nil {
		return "", err
	}
	return r.Contract.Name(nil, nameHash)
}

// Format provides a string version of an address, reverse resolving it if possible.
func Format(ctx context.Context, backend bind.ContractBackend, address common.Address) string {
	result, err := ReverseResolve(ctx, backend, address)
	if err != nil {
		result = address.Hex()
	}
	return result
}

// ReverseResolve resolves an address in to an ENS name. Resolution flows
// through the ENS UniversalResolver, so ENSIP-10 wildcard resolution and
// ERC-3668 CCIP-Read are handled transparently and reverse records stored
// offchain or on an L2 resolve the same way as fully on-chain reverse records.
//
// ctx is honoured for cancellation and deadline propagation through the
// CCIP-Read hops.
//
// This will return an error if no primary name is set for the address.
func ReverseResolve(ctx context.Context, backend bind.ContractBackend, address common.Address) (string, error) {
	ur, err := NewUniversalResolver(ctx, backend)
	if err != nil {
		return "", err
	}
	name, _, _, err := ur.Reverse(ctx, address.Bytes(), CoinTypeETH)
	if err != nil {
		return "", err
	}
	if name == "" {
		return "", errors.New("no resolution")
	}
	return name, nil
}
