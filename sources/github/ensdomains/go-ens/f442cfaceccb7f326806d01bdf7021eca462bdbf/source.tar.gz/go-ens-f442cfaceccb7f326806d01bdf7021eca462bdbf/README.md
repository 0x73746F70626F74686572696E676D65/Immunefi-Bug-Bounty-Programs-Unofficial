# go-ens

[![Tag](https://img.shields.io/github/tag/ensdomains/go-ens.svg)](https://github.com/ensdomains/go-ens/releases/)
[![License](https://img.shields.io/github/license/ensdomains/go-ens.svg)](LICENSE)
[![GoDoc](https://pkg.go.dev/badge/github.com/ensdomains/go-ens/v4.svg)](https://pkg.go.dev/github.com/ensdomains/go-ens/v4)
[![Test](https://github.com/ensdomains/go-ens/actions/workflows/test.yml/badge.svg)](https://github.com/ensdomains/go-ens/actions/workflows/test.yml)

Go module to simplify interacting with the [Ethereum Name Service](https://ens.domains/) contracts.

This is the ENS Go library. It is the continuation of [`wealdtech/go-ens`](https://github.com/wealdtech/go-ens); install and import `github.com/ensdomains/go-ens/v4` rather than `github.com/wealdtech/go-ens/v3`.

v4 resolves names through the ENS [Universal Resolver](https://docs.ens.domains/web/ensv2-readiness/), so ENSIP-10 wildcards and ERC-3668 CCIP-Read work out of the box. Callers that need the previous registry-walking behaviour should stay on `github.com/wealdtech/go-ens/v3`. Upgrading from v3: [MIGRATION.md](MIGRATION.md). Full history: [CHANGELOG.md](CHANGELOG.md).


## Table of Contents

- [Install](#install)
- [Usage](#usage)
- [Migrating from v3](MIGRATION.md)
- [Changelog](CHANGELOG.md)
- [Maintainers](#maintainers)
- [Contribute](#contribute)
- [License](#license)

## Install

`go-ens` is a standard Go module which can be installed with:

```sh
go get github.com/ensdomains/go-ens/v4
```

## Usage

`go-ens` provides simple access to the [Ethereum Name Service](https://ens.domains/) (ENS) contracts.

### Resolution

The most commonly-used feature of ENS is resolution: converting an ENS name to an Ethereum address.  `go-ens` provides a simple call to allow this:

```go
address, err := ens.Resolve(ctx, client, domain)
```

where `ctx` is a `context.Context` (honoured for cancellation and deadlines through any CCIP-Read hops), `client` is a connection to an Ethereum client, and `domain` is the fully-qualified name you wish to resolve (e.g. `foo.mydomain.eth`) (full examples for using this are given in the [Example](#Example) section below).

The reverse process, converting an address to an ENS name, is just as simple:

```go
domain, err := ens.ReverseResolve(ctx, client, address)
```

If the address has no primary name set this returns an error (`"no resolution"`).  If you just want a string version of an address for on-screen display then you can use `ens.Format()`, for example:

```go
fmt.Printf("The address is %s\n", ens.Format(ctx, client, address))
```

This will carry out reverse resolution of the address and print the name if present; if not it will print a formatted version of the address.

`ens.Resolve`, `ens.ReverseResolve`, `ens.Format`, and `Name.Address` all go through the Universal Resolver, so ENSIP-10 wildcards and ERC-3668 CCIP-Read names resolve the same way as on-chain names. `Resolver` read methods (`Address`, `Text`, `Contenthash`, `MultiAddress`) call the specific resolver contract that `Resolver` is bound to and do **not** follow wildcards or CCIP-Read. For those names use `ens.Resolve` (or `UniversalResolver`); keep `Resolver` for writes (`SetAddress`, `SetText`, and so on) and for reading a resolver you already hold.

### Management of names

A top-level name is one that sits directly underneath `.eth`, for example `mydomain.eth`.  Lower-level names, such as `foo.mydomain.eth` are covered in the following section.  `go-ens` provides a simplified `Name` interface to manage top-level, removing the requirement to understand registrars, controllers, _etc._

Starting out with names in `go-ens` is easy:

```go
client, err := ethclient.Dial("https://infura.io/v3/SECRET")
name, err := ens.NewName(client, "mydomain.eth")
```

Addresses can be set and obtained using the address functions, for example to get an address:

```go
COIN_TYPE_ETHEREUM := uint64(60)
address, err := name.Address(ctx, COIN_TYPE_ETHEREUM)
```

`Name.Address` uses the Universal Resolver (same answer as `ens.Resolve` for coin type 60). The `Resolver.Address` method does not — see the note under [Resolution](#resolution).

ENS supports addresses for multiple coin types; values of coin types can be found at https://github.com/satoshilabs/slips/blob/master/slip-0044.md

### Registering and extending names

Most operations on a domain will involve setting resolvers and resolver information.


### Management of subdomains

Because subdomains have their own registrars they do not work with the `Name` interface.

### Example

```go
package main

import (
	"context"
	"fmt"

	"github.com/ethereum/go-ethereum/ethclient"
	ens "github.com/ensdomains/go-ens/v4"
)

func main() {
	ctx := context.Background()

	// Replace SECRET with your own access token for this example to work.
	client, err := ethclient.Dial("https://mainnet.infura.io/v3/SECRET")
	if err != nil {
		panic(err)
	}

	// Resolve a name to an address.
	domain := "ethereum.eth"
	address, err := ens.Resolve(ctx, client, domain)
	if err != nil {
		panic(err)
	}
	fmt.Printf("Address of %s is %s\n", domain, address.Hex())

	// Reverse resolve an address to a name.
	reverse, err := ens.ReverseResolve(ctx, client, address)
	if err != nil {
		fmt.Printf("%s has no reverse lookup: %v\n", address.Hex(), err)
	} else {
		fmt.Printf("Name of %s is %s\n", address.Hex(), reverse)
	}
}
```

## Maintainers

[ENS](https://github.com/ensdomains).

Originally written by Jim McDonald ([@mcdee](https://github.com/mcdee)) at Weald Technology.

## Contribute

Contributions welcome. Please check out [the issues](https://github.com/ensdomains/go-ens/issues).

## License

[Apache-2.0](LICENSE) © 2019 Weald Technology Trading Ltd
