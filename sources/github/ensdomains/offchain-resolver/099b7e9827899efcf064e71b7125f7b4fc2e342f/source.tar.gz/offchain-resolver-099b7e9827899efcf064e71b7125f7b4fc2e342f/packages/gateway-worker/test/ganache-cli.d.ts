declare module 'ganache-cli';
