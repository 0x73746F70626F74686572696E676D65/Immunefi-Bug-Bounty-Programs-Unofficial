DROP TABLE subgraphs;
