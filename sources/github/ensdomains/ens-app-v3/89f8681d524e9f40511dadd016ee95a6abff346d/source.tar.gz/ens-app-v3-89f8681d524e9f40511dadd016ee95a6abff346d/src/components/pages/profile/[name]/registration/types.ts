import { Address, Hex } from 'viem'

import { ProfileRecord } from '@app/constants/profileRecordOptions'

export type RegistrationStep = 'pricing' | 'profile' | 'info' | 'transactions' | 'complete'

type UnionToIntersection<U> = (U extends any ? (k: U) => void : never) extends (k: infer I) => void
  ? I
  : never

type Prettify<T> = {
  [K in keyof T]: T[K]
} & {}

export type RegistrationStepData = {
  pricing: {
    seconds: number
    reverseRecord: boolean
    estimatedTotal?: bigint
    ethPrice?: bigint
    durationType: 'date' | 'years'
  }
  profile: {
    records: ProfileRecord[]
    clearRecords?: boolean
    resolverAddress?: Address
  }
  info: {}
  transactions: {
    secret: Hex
    started: boolean
  }
  complete: {}
}

export type BackObj = { back: boolean }

export type RegistrationData = Prettify<UnionToIntersection<RegistrationStepData[RegistrationStep]>>

export type SelectedItemProperties = {
  address: string
  name: string
  chainId: number
  referrer?: Hex
}

export type RegistrationReducerDataItem = Prettify<
  RegistrationData & {
    stepIndex: number
    queue: RegistrationStep[]
    version: number
    referrer?: Hex
  } & SelectedItemProperties
>

export type RegistrationReducerData = {
  items: RegistrationReducerDataItem[]
}

export type RegistrationReducerAction =
  | {
      name: 'increaseStep'
      selected: SelectedItemProperties
    }
  | {
      name: 'decreaseStep'
      selected: SelectedItemProperties
    }
  | {
      name: 'setQueue'
      selected: SelectedItemProperties
      payload: RegistrationStep[]
    }
  | {
      name: 'setPricingData'
      selected: SelectedItemProperties
      payload: RegistrationStepData['pricing']
    }
  | {
      name: 'setProfileData'
      selected: SelectedItemProperties
      payload: RegistrationStepData['profile']
    }
  | {
      name: 'setTransactionsData'
      selected: SelectedItemProperties
      payload: RegistrationStepData['transactions']
    }
  | {
      name: 'clearItem'
      selected: SelectedItemProperties
    }
  | {
      name: 'setStarted'
      selected: SelectedItemProperties
    }
  | {
      name: 'resetItem'
      selected: SelectedItemProperties
    }
  | {
      name: 'resetSecret'
      selected: SelectedItemProperties
    }
  | {
      name: 'setReferrer'
      selected: SelectedItemProperties
      payload: Hex
    }
