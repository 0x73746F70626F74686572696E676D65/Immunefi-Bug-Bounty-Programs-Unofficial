import { useMemo } from 'react'
import { useTranslation } from 'react-i18next'
import styled, { css } from 'styled-components'

import { Button, Helper, NametagSVG, Tag, Typography } from '@ensdomains/thorin'

import ClockSVG from '@app/assets/Clock.svg'
import FastForwardSVG from '@app/assets/FastForward.svg'
import VerifiedPersonSVG from '@app/assets/VerifiedPerson.svg'
import { useAbilities } from '@app/hooks/abilities/useAbilities'
import { useBeautifiedName } from '@app/hooks/useBeautifiedName'
import { useEnsAvatar } from '@app/hooks/useEnsAvatar'
import { useIsWrapped } from '@app/hooks/useIsWrapped'
import { useNameDetails } from '@app/hooks/useNameDetails'
import { useRouterWithHistory } from '@app/hooks/useRouterWithHistory'
import { getTimezoneOffset } from '@app/utils/getTimezoneOffset'
import { isShortEth2LD } from '@app/utils/shortName'

import { useTransactionFlow } from '../transaction-flow/TransactionFlowProvider'
import { NameAvatar } from './AvatarWithZorb'

const Container = styled.div(
  ({ theme }) => css`
    position: relative;
    width: 100%;
    padding: 0;
    background-color: ${theme.colors.background};
    border-radius: ${theme.radii['2xLarge']};
    border: ${theme.space.px} solid ${theme.colors.border};
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    justify-content: center;
    gap: 0;
    flex-gap: 0;
    overflow: hidden;
  `,
)

const HeaderContainer = styled.div<{ $header?: string }>(
  ({ theme, $header }) => css`
    position: relative;
    top: -1px;
    left: 0;
    width: 100%;
    ${$header
      ? `
    background-image: url("${encodeURI($header)}")};
    height: ${theme.space['32']};
    `
      : `
        background-image: ${theme.colors.blueGradient};
        height: ${theme.space['28']};
    `}
    background-position: center;
    background-size: cover;
    background-repeat: no-repeat;
    background-attachment: scroll;
  `,
)

const ContentContainer = styled.div(
  ({ theme }) => css`
    width: 100%;
    padding: ${theme.space['4']};
    padding-top: 0;
    margin-top: -${theme.space['12']};
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    justify-content: center;
    gap: ${theme.space['4']};
    flex-gap: ${theme.space['4']};

    @media (min-width: ${theme.breakpoints.sm}px) {
      padding: ${theme.space['6']};
      padding-top: 0;
      margin-top: -${theme.space['16']};
    }
  `,
)

const DetailStack = styled.div(
  () => css`
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    width: 100%;
    overflow: hidden;
  `,
)

const Name = styled(Typography)(
  () => css`
    width: 100%;
    overflow-wrap: anywhere;
  `,
)

const NameRecord = styled(Typography)(
  ({ theme }) => css`
    color: ${theme.colors.greyPrimary};
    margin-top: -${theme.space['0.5']};
  `,
)

const TextStack = styled.div(
  ({ theme }) => css`
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    justify-content: center;
    gap: ${theme.space['1']};
    width: 100%;
    overflow: hidden;
  `,
)

const FirstItems = styled.div(
  () => css`
    width: 100%;
    display: flex;
    flex-direction: row;
    align-items: flex-end;
    justify-content: space-between;
  `,
)

const DetailButtonWrapper = styled.div(
  ({ theme }) => css`
    & > button {
      border-radius: ${theme.radii.large};
    }
  `,
)

const ButtonStack = styled.div(
  () => css`
    display: flex;
    flex-direction: row;
    align-items: center;
    justify-content: flex-end;
  `,
)

const LocationAndUrl = styled.div(
  ({ theme }) => css`
    display: flex;
    flex-direction: row;
    align-items: center;
    justify-content: flex-start;
    gap: ${theme.space['2']};

    #profile-loc {
      color: ${theme.colors.greyPrimary};
    }

    #profile-url {
      font-weight: bold;
    }
  `,
)

const Timezone = styled.div(
  ({ theme }) => css`
    display: flex;
    flex-direction: row;
    align-items: center;
    justify-content: flex-start;
    gap: ${theme.space['1']};
    color: ${theme.colors.greyPrimary};

    svg {
      display: block;
      width: ${theme.space['4']};
      height: ${theme.space['4']};
    }
  `,
)

const TagsContainer = styled.div(
  ({ theme }) => css`
    display: flex;
    flex-direction: row;
    align-items: center;
    justify-content: flex-start;
    gap: ${theme.space['2']};
  `,
)

const PrimaryNameTag = styled(Tag)(
  ({ theme }) => css`
    display: flex;
    flex-direction: row;
    align-items: center;
    justify-content: center;
    gap: ${theme.space['1']};

    & > svg {
      height: ${theme.space['4']};
      width: ${theme.space['4']};
    }
  `,
)

const VerificationBadgeWrapper = styled.div(
  ({ theme }) => css`
    display: inline-flex;
    height: ${theme.space['10']};
    margin-left: ${theme.space['2']};
    color: ${theme.colors.greenPrimary};

    svg {
      display: block;
      height: ${theme.space['6']};
      width: ${theme.space['6']};
    }
  `,
)

export const getUserDefinedUrl = (url?: string) => {
  if (!url) return undefined
  if (url.startsWith('http://') || url.startsWith('https://')) {
    return url
  }
  return ``
}

export const ProfileSnippet = ({
  name,
  getTextRecord,
  button,
  // network,
  isPrimary,
  isVerified,
  hasMismatch,
  children,
}: {
  name: string
  getTextRecord?: (key: string) => { value: string } | undefined
  button?: 'viewProfile' | 'extend' | 'register' | undefined
  isPrimary?: boolean
  isVerified?: boolean
  hasMismatch?: boolean
  children?: React.ReactNode
}) => {
  const router = useRouterWithHistory()
  const { t } = useTranslation('common')

  const nameDetails = useNameDetails({ name })
  const { registrationStatus } = nameDetails
  const isShortName = isShortEth2LD(nameDetails)

  const { usePreparedDataInput } = useTransactionFlow()
  const showExtendNamesInput = usePreparedDataInput('ExtendNames')
  const abilities = useAbilities({ name })
  const { data: isWrapped } = useIsWrapped({ name })

  // Always call the hook but conditionally use its result
  const hookBeautifiedName = useBeautifiedName(name)
  const beautifiedName = hasMismatch ? name : hookBeautifiedName

  // We are overriding the key parameter here to get the header url. This will break the type checker
  // @ts-ignore
  const { data: headerUrl } = useEnsAvatar({ name, key: 'header' })

  const description = getTextRecord?.('description')?.value
  const url = getUserDefinedUrl(getTextRecord?.('url')?.value)
  const location = getTextRecord?.('location')?.value
  const recordName = getTextRecord?.('name')?.value
  const timezone = getTextRecord?.('timezone')?.value
  const timezoneOffset = getTimezoneOffset(timezone)

  const { canSelfExtend, canEdit } = abilities.data ?? {}

  const isDesynced =
    !!registrationStatus && ['desynced', 'desynced:gracePeriod'].includes(registrationStatus)

  const ActionButton = useMemo(() => {
    if (button === 'extend' && !isShortName)
      return (
        <Button
          size="small"
          colorStyle="accentSecondary"
          prefix={FastForwardSVG}
          data-testid="extend-button"
          onClick={() => {
            showExtendNamesInput(`extend-names-${name}`, {
              names: [name],
              isSelf: canSelfExtend,
              hasWrapped: isWrapped || isDesynced,
            })
          }}
        >
          {t('action.extend', { ns: 'common' })}
        </Button>
      )
    if (button === 'register')
      return (
        <Button
          onClick={() => router.pushWithHistory(`/register/${name}`)}
          size="small"
          colorStyle="accentSecondary"
        >
          {t(`wallet.${button}`)}
        </Button>
      )
    if (button === 'viewProfile')
      return (
        <Button
          onClick={() => router.pushWithHistory(`/profile/${name}`)}
          size="small"
          colorStyle="accentSecondary"
        >
          {t(`wallet.${button}`)}
        </Button>
      )
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [button, name, canSelfExtend, isShortName, isWrapped])

  return (
    <Container data-testid="profile-snippet">
      <HeaderContainer $header={headerUrl ?? undefined} />
      <ContentContainer>
        <FirstItems>
          <NameAvatar
            size={{ min: '24', sm: '32' }}
            label={name}
            name={name}
            noCache={canEdit}
            decoding="sync"
          />
          <ButtonStack>
            {ActionButton && <DetailButtonWrapper>{ActionButton}</DetailButtonWrapper>}
          </ButtonStack>
        </FirstItems>
        <TextStack>
          <DetailStack>
            <Name fontVariant="headingTwo" data-testid="profile-snippet-name">
              {beautifiedName}
              {isVerified && (
                <VerificationBadgeWrapper>
                  <VerifiedPersonSVG data-testid="profile-snippet-person-icon" />
                </VerificationBadgeWrapper>
              )}
            </Name>
            {recordName && (
              <NameRecord data-testid="profile-snippet-nickname">{recordName}</NameRecord>
            )}
          </DetailStack>
          {description && (
            <Typography data-testid="profile-snippet-description">{description}</Typography>
          )}
          {(url || location || timezoneOffset) && (
            <LocationAndUrl>
              {location && (
                <Typography id="profile-loc" data-testid="profile-snippet-location">
                  {location}
                </Typography>
              )}
              {timezoneOffset && (
                <Timezone data-testid="profile-snippet-timezone">
                  <ClockSVG />
                  <Typography>{`${timezone} (${timezoneOffset})`}</Typography>
                </Timezone>
              )}
              {url && (
                <a href={url} data-testid="profile-snippet-url" target="_blank" rel="noreferrer">
                  <Typography color="blue" id="profile-url">
                    {url?.replace(/http(s?):\/\//g, '').replace(/\/$/g, '')}
                  </Typography>
                </a>
              )}
            </LocationAndUrl>
          )}
        </TextStack>
        {(isPrimary || hasMismatch) && (
          <TagsContainer>
            {isPrimary && (
              <PrimaryNameTag size="medium" colorStyle="greenSecondary">
                <NametagSVG />
                {t('name.yourPrimaryName')}
              </PrimaryNameTag>
            )}
            {hasMismatch && (
              <Helper alert="warning" alignment="horizontal">
                {t('name.unnormalized')}
              </Helper>
            )}
          </TagsContainer>
        )}
        {children}
      </ContentContainer>
    </Container>
  )
}
