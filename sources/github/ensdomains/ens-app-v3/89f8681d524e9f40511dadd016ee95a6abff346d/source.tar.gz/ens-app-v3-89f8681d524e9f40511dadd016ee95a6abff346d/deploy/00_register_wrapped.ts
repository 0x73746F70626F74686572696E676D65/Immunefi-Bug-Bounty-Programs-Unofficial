/* eslint-disable import/no-extraneous-dependencies */
/* eslint-disable no-await-in-loop */
import { DeployFunction } from 'hardhat-deploy/types'
import { HardhatRuntimeEnvironment } from 'hardhat/types'
import { labelhash, namehash, type Account } from 'viem'

import {
  EMPTY_ADDRESS,
  EMPTY_BYTES32,
  encodeFuses,
  generateRecordCallArray,
  // makeRegistrationTuple,
  RecordOptions,
} from '@ensdomains/ensjs/utils'

import {
  makeCommitment as generateCommitment,
  type CommitmentTuple,
  type RegistrationParameters,
  type RegistrationTuple,
} from './.utils/nameWrapperRegisterHelpers'
import { nonceManager } from './.utils/nonceManager'

type Name = {
  name: string
  namedOwner: string
  reverseRecord?: boolean
  records?: RecordOptions
  fuses?: RegistrationParameters['fuses']
  customDuration?: number
  subnames?: {
    label: string
    namedOwner: string
    fuses?: number
    expiry?: number
  }[]
}

export const makeCommitmentTuple = ({
  name,
  owner,
  duration,
  resolverAddress = EMPTY_ADDRESS,
  records: { coins = [], ...records } = { texts: [], coins: [] },
  reverseRecord,
  fuses,
  secret,
}: RegistrationParameters): CommitmentTuple => {
  const labelHash = labelhash(name.split('.')[0])
  const hash = namehash(name)
  const fuseData = fuses ? encodeFuses({ restriction: 'child', input: fuses }) : 0

  if (
    reverseRecord &&
    !coins.find(
      (c) =>
        (typeof c.coin === 'string' && c.coin.toLowerCase() === 'eth') ||
        (typeof c.coin === 'string' ? Number.parseInt(c.coin) === 60 : c.coin === 60),
    )
  ) {
    coins.push({ coin: 60, value: owner })
  }

  const data = records ? generateRecordCallArray({ namehash: hash, coins, ...records }) : []

  if (data.length > 0 && resolverAddress === EMPTY_ADDRESS)
    throw new Error('resolver address required')

  return [
    labelHash,
    owner,
    BigInt(duration),
    secret,
    resolverAddress,
    data,
    !!reverseRecord,
    fuseData,
  ]
}

export const makeRegistrationTuple = (params: RegistrationParameters): RegistrationTuple => {
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const [_labelhash, ...commitmentData] = makeCommitmentTuple(params)
  const label = params.name.split('.')[0]
  return [label, ...commitmentData]
}

type ProcessedSubname = {
  label: string
  owner: Account
  expiry: number
  fuses: number
}

type ProcessedNameData = Omit<RegistrationParameters, 'owner'> & {
  label: string
  subnames: ProcessedSubname[]
  resolverAddress: string
  secret: string
  duration: number
  owner: Account
  name: string
  fuses?: RegistrationParameters['fuses']
}

const adjustTime = (time: number) => {
  return time + 2419200 + 7776000 // 28 days + 90 days
}

const names: Name[] = [
  {
    name: 'wrapped.eth',
    namedOwner: 'owner',
    subnames: [
      { label: 'sub', namedOwner: 'deployer' },
      { label: 'test', namedOwner: 'deployer' },
      { label: 'legacy', namedOwner: 'deployer' },
      { label: 'xyz', namedOwner: 'deployer' },
    ],
  },
  {
    name: 'wrapped-expired-subnames.eth',
    namedOwner: 'owner',
    fuses: {
      named: ['CANNOT_UNWRAP'],
    },
    subnames: [
      {
        label: 'day-expired',
        namedOwner: 'owner',
        // set expiry to 24 hours ago
        expiry: Math.floor(Date.now() / 1000) - 86400,
        fuses: encodeFuses({ input: { parent: { named: ['PARENT_CANNOT_CONTROL'] } } }),
      },
      {
        label: 'hour-expired',
        namedOwner: 'owner',
        // set expiry to 24 hours ago
        expiry: Math.floor(Date.now() / 1000) - 3600,
        fuses: encodeFuses({ input: { parent: { named: ['PARENT_CANNOT_CONTROL'] } } }),
      },
      {
        label: 'two-minute-expired',
        namedOwner: 'owner',
        expiry: Math.floor(Date.now() / 1000) - 120,
        fuses: encodeFuses({ input: { parent: { named: ['PARENT_CANNOT_CONTROL'] } } }),
      },
      {
        label: 'two-minute-expiring',
        namedOwner: 'owner',
        expiry: Math.floor(Date.now() / 1000) + 120,
        fuses: encodeFuses({ input: { parent: { named: ['PARENT_CANNOT_CONTROL'] } } }),
      },
      {
        label: 'hour-expiring',
        namedOwner: 'owner',
        // set expiry to 24 hours ago
        expiry: Math.floor(Date.now() / 1000) + 3600,
        fuses: encodeFuses({ input: { parent: { named: ['PARENT_CANNOT_CONTROL'] } } }),
      },
      {
        label: 'no-pcc',
        namedOwner: 'owner',
        expiry: Math.floor(Date.now() / 1000) - 86400,
      },
      {
        label: 'not-expired',
        namedOwner: 'owner',
        fuses: encodeFuses({ input: { parent: { named: ['PARENT_CANNOT_CONTROL'] } } }),
      },
    ],
  },
  {
    name: 'wrapped-to-delete.eth',
    namedOwner: 'owner',
    subnames: [
      { label: 'parent-not-child', namedOwner: 'deployer' },
      { label: 'parent-child', namedOwner: 'owner' },
      { label: 'not-parent-child', namedOwner: 'deployer' },
    ],
  },
  {
    name: 'emancipated-to-delete.eth',
    namedOwner: 'owner',
    fuses: {
      named: ['CANNOT_UNWRAP'],
    },
    subnames: [
      {
        label: 'parent-not-child',
        namedOwner: 'deployer',
        expiry: Math.floor(Date.now() / 1000) + 60 * 60 * 24 * 365,
        fuses: encodeFuses({ input: { parent: { named: ['PARENT_CANNOT_CONTROL'] } } }),
      },
      {
        label: 'parent-child',
        namedOwner: 'owner',
        expiry: Math.floor(Date.now() / 1000) + 60 * 60 * 24 * 365,
        fuses: encodeFuses({ input: { parent: { named: ['PARENT_CANNOT_CONTROL'] } } }),
      },
      {
        label: 'not-parent-child',
        namedOwner: 'deployer',
        expiry: Math.floor(Date.now() / 1000) + 60 * 60 * 24 * 365,
        fuses: encodeFuses({ input: { parent: { named: ['PARENT_CANNOT_CONTROL'] } } }),
      },
    ],
  },
]

const func: DeployFunction = async function (hre: HardhatRuntimeEnvironment) {
  const { network, viem } = hre
  const allNamedClients = await viem.getNamedClients()
  const publicClient = await viem.getPublicClient()

  const controller = await viem.getContract('WrappedEthRegistrarController' as any)
  const publicResolver = await viem.getContract('NameWrapperPublicResolver' as any)
  const nameWrapper = await viem.getContract('NameWrapper')

  const makeData = ({ namedOwner, customDuration, fuses, name, subnames, ...rest }: Name) => {
    const resolverAddress = publicResolver.address
    const secret = EMPTY_BYTES32 as `0x${string}`
    const duration = customDuration || 31536000
    // 1659467455 is an approximate base timestamp; adding duration to it gives the wrapper expiry
    const wrapperExpiry = 1659467455 + adjustTime(duration)
    const owner = allNamedClients[namedOwner].account

    const processedSubnames: ProcessedSubname[] =
      subnames?.map(
        ({ label, namedOwner: subNamedOwner, fuses: subnameFuses, expiry: subnameExpiry }) => ({
          label,
          owner: allNamedClients[subNamedOwner].account,
          expiry: subnameExpiry || wrapperExpiry,
          fuses: subnameFuses || 0,
        }),
      ) || []

    return {
      resolverAddress,
      secret,
      duration,
      owner,
      name,
      label: name.split('.')[0],
      subnames: processedSubnames,
      fuses: fuses || undefined,
      ...rest,
    }
  }

  const makeCommitment =
    (nonce: number) =>
    async ({ owner, name, ...rest }: ProcessedNameData, index: number) => {
      const commitment = generateCommitment({ owner: owner.address, name, ...rest })
      const commitTxHash = await controller.write.commit([commitment], {
        nonce: nonce + index,
        account: owner,
      })
      console.log(`Commiting commitment for ${name} (tx: ${commitTxHash})...`)
      return 1
    }

  const makeRegistration =
    (nonce: number) =>
    async ({ owner, name, duration, label, ...rest }: ProcessedNameData, index: number) => {
      const { base: price } = await controller.read.rentPrice([label, BigInt(duration)])
      console.log('>>>', {
        owner: owner.address,
        name,
        duration,
        label,
        ...rest,
      })
      console.log('>>>', makeRegistrationTuple({ owner: owner.address, name, duration, ...rest }))
      const registerTxHash = await controller.write.register(
        makeRegistrationTuple({ owner: owner.address, name, duration, ...rest }),
        {
          account: owner,
          value: price,
          nonce: nonce + index,
        },
      )
      console.log(`Registering name ${name} (tx: ${registerTxHash})...`)
      return 1
    }

  const makeSubname =
    (nonce: number) =>
    async ({ name, subnames, owner }: ProcessedNameData, index: number) => {
      for (let i = 0; i < subnames.length; i += 1) {
        const { label, owner: subOwner, fuses, expiry } = subnames[i]
        const subnameTxHash = await nameWrapper.write.setSubnodeOwner(
          [namehash(name), label, subOwner.address, fuses, BigInt(expiry)],
          {
            account: owner,
            nonce: nonce + index + i,
          },
        )
        console.log(`Creating subname ${label}.${name} (tx: ${subnameTxHash})...`)
      }
      return subnames.length
    }

  const allNameData = names.map(makeData)

  const getNonceAndApply = nonceManager(allNamedClients, allNameData)

  await network.provider.send('evm_setAutomine', [false])
  await getNonceAndApply('owner', makeCommitment)
  await network.provider.send('evm_mine')
  const oldTimestamp = await publicClient.getBlock().then((b) => Number(b.timestamp))
  await network.provider.send('evm_setNextBlockTimestamp', [oldTimestamp + 60])
  await network.provider.send('evm_mine')
  await getNonceAndApply('owner', makeRegistration)
  await network.provider.send('evm_mine')
  await getNonceAndApply('owner', makeSubname)
  await network.provider.send('evm_mine')

  await network.provider.send('evm_setAutomine', [true])
  await network.provider.send('anvil_setBlockTimestampInterval', [1])
  await network.provider.send('evm_mine')

  return true
}

func.id = 'register-wrapped-names'
func.tags = ['register-wrapped-names']
func.dependencies = ['WrappedEthRegistrarController', 'NameWrapperPublicResolver']
func.runAtTheEnd = true

export default func
