//root pointer
