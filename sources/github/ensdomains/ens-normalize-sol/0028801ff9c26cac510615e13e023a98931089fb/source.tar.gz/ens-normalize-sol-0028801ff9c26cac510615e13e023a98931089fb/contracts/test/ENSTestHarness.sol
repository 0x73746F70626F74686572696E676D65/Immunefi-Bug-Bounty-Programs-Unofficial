// SPDX-License-Identifier: MIT
pragma solidity ^0.8.27;

import {ENSBytes} from "../lib/ENSBytes.sol";
import {ENSUnicode} from "../lib/ENSUnicode.sol";

/// @dev Focused access to otherwise-internal defensive paths for coverage.
contract ENSTestHarness {
    function readCode(address source) external view returns (bytes memory) {
        return ENSBytes.readCode(source);
    }

    function nfcEmpty(address normalizationStore) external view returns (uint256 length) {
        bytes memory data = ENSBytes.readCode(normalizationStore);
        uint256[] memory empty = new uint256[](0);
        (, length) = ENSUnicode.nfc(empty, 0, data);
    }
}
