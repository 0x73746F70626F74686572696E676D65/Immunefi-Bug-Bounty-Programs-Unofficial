// SPDX-License-Identifier: MIT
pragma solidity ^0.8.27;

import {ENSTables} from "./ENSTables.sol";

/// @dev Strict UTF-8 and canonical Unicode normalization helpers.
library ENSUnicode {
    ////////////////////////////////////////////////////////////////////////
    // Constants
    ////////////////////////////////////////////////////////////////////////

    /// @dev First precomposed Hangul syllable.
    uint256 internal constant S0 = 0xac00;

    /// @dev First leading Hangul Jamo.
    uint256 internal constant L0 = 0x1100;

    /// @dev First vowel Hangul Jamo.
    uint256 internal constant V0 = 0x1161;

    /// @dev Code point immediately before the first trailing Hangul Jamo.
    uint256 internal constant T0 = 0x11a7;

    /// @dev Number of leading Hangul Jamo.
    uint256 internal constant L_COUNT = 19;

    /// @dev Number of vowel Hangul Jamo.
    uint256 internal constant V_COUNT = 21;

    /// @dev Number of trailing Hangul choices, including no trailing Jamo.
    uint256 internal constant T_COUNT = 28;

    /// @dev Number of Hangul syllables per leading Jamo.
    uint256 internal constant N_COUNT = V_COUNT * T_COUNT;

    /// @dev Total number of algorithmically composed Hangul syllables.
    uint256 internal constant S_COUNT = L_COUNT * N_COUNT;

    /// @dev Exclusive upper bound for precomposed Hangul syllables.
    uint256 internal constant S1 = S0 + S_COUNT;

    /// @dev Exclusive upper bound for leading Hangul Jamo.
    uint256 internal constant L1 = L0 + L_COUNT;

    /// @dev Exclusive upper bound for vowel Hangul Jamo.
    uint256 internal constant V1 = V0 + V_COUNT;

    /// @dev Exclusive upper bound for trailing Hangul Jamo.
    uint256 internal constant T1 = T0 + T_COUNT;

    ////////////////////////////////////////////////////////////////////////
    // Encoding Functions
    ////////////////////////////////////////////////////////////////////////

    /// @dev Strictly decodes a UTF-8 string into Unicode scalar values.
    function decode(string memory value)
        internal
        pure
        returns (uint256[] memory codepoints, uint256 length, bool valid)
    {
        bytes memory input = bytes(value);
        codepoints = new uint256[](input.length);
        uint256 position;
        while (position < input.length) {
            uint256 first = uint8(input[position++]);
            uint256 cp;
            if (first < 0x80) {
                cp = first;
            } else if (first >= 0xc2 && first <= 0xdf) {
                if (position >= input.length)
                    return (codepoints, length, false);
                uint256 second = uint8(input[position++]);
                if ((second & 0xc0) != 0x80)
                    return (codepoints, length, false);
                cp = ((first & 0x1f) << 6) | (second & 0x3f);
            } else if (first >= 0xe0 && first <= 0xef) {
                if (position + 1 >= input.length)
                    return (codepoints, length, false);
                uint256 second = uint8(input[position++]);
                uint256 third = uint8(input[position++]);
                if ((second & 0xc0) != 0x80 || (third & 0xc0) != 0x80) {
                    return (codepoints, length, false);
                }
                if ((first == 0xe0 && second < 0xa0) || (first == 0xed && second >= 0xa0)) {
                    return (codepoints, length, false);
                }
                cp = ((first & 0x0f) << 12) | ((second & 0x3f) << 6) | (third & 0x3f);
            } else if (first >= 0xf0 && first <= 0xf4) {
                if (position + 2 >= input.length)
                    return (codepoints, length, false);
                uint256 second = uint8(input[position++]);
                uint256 third = uint8(input[position++]);
                uint256 fourth = uint8(input[position++]);
                if ((second & 0xc0) != 0x80 || (third & 0xc0) != 0x80 || (fourth & 0xc0) != 0x80) {
                    return (codepoints, length, false);
                }
                if ((first == 0xf0 && second < 0x90) || (first == 0xf4 && second >= 0x90)) {
                    return (codepoints, length, false);
                }
                cp =
                    ((first & 7) << 18) |
                    ((second & 0x3f) << 12) |
                    ((third & 0x3f) << 6) |
                    (fourth & 0x3f);
            } else {
                return (codepoints, length, false);
            }
            codepoints[length++] = cp;
        }
        return (codepoints, length, true);
    }

    /// @dev Encodes Unicode scalar values as a UTF-8 string.
    function encode(uint256[] memory codepoints, uint256 length)
        internal
        pure
        returns (string memory)
    {
        bytes memory output = new bytes(length * 4);
        uint256 outputLength;
        for (uint256 i; i < length; ++i) {
            uint256 cp = codepoints[i];
            if (cp < 0x80) {
                output[outputLength++] = bytes1(uint8(cp));
            } else if (cp < 0x800) {
                output[outputLength++] = bytes1(uint8(0xc0 | (cp >> 6)));
                output[outputLength++] = bytes1(uint8(0x80 | (cp & 0x3f)));
            } else if (cp < 0x10000) {
                output[outputLength++] = bytes1(uint8(0xe0 | (cp >> 12)));
                output[outputLength++] = bytes1(uint8(0x80 | ((cp >> 6) & 0x3f)));
                output[outputLength++] = bytes1(uint8(0x80 | (cp & 0x3f)));
            } else {
                output[outputLength++] = bytes1(uint8(0xf0 | (cp >> 18)));
                output[outputLength++] = bytes1(uint8(0x80 | ((cp >> 12) & 0x3f)));
                output[outputLength++] = bytes1(uint8(0x80 | ((cp >> 6) & 0x3f)));
                output[outputLength++] = bytes1(uint8(0x80 | (cp & 0x3f)));
            }
        }
        assembly ("memory-safe") {
            mstore(output, outputLength)
        }
        return string(output);
    }

    ////////////////////////////////////////////////////////////////////////
    // Normalization Functions
    ////////////////////////////////////////////////////////////////////////

    /// @dev Computes canonical decomposition and combining-mark ordering.
    function nfd(uint256[] memory input, uint256 inputLength, bytes memory normalizationData)
        internal
        pure
        returns (uint256[] memory output, uint256 outputLength)
    {
        output = new uint256[](inputLength * 4 + 8);
        uint256[] memory ranks = new uint256[](inputLength * 4 + 8);
        uint256[] memory stack = new uint256[](inputLength * 4 + 8);

        for (uint256 inputIndex; inputIndex < inputLength; ++inputIndex) {
            uint256 stackLength = 1;
            stack[0] = input[inputIndex];
            while (stackLength != 0) {
                uint256 cp = stack[--stackLength];
                if (cp >= S0 && cp < S1) {
                    uint256 syllable = cp - S0;
                    uint256 leading = L0 + syllable / N_COUNT;
                    uint256 vowel = V0 + (syllable % N_COUNT) / T_COUNT;
                    uint256 trailing = syllable % T_COUNT;
                    outputLength = _appendOrdered(output, ranks, outputLength, leading, 0);
                    outputLength = _appendOrdered(output, ranks, outputLength, vowel, 0);
                    if (trailing != 0) {
                        outputLength = _appendOrdered(output, ranks, outputLength, T0 + trailing, 0);
                    }
                    continue;
                }

                (bool found, uint256 count, uint256 first, uint256 second) =
                    ENSTables.decomposition(normalizationData, cp);
                if (found) {
                    if (count == 2)
                        stack[stackLength++] = second;
                    stack[stackLength++] = first;
                } else {
                    uint256 rank = cp < 0x80
                        ? 0
                        : ENSTables.combiningRank(normalizationData, cp);
                    outputLength = _appendOrdered(output, ranks, outputLength, cp, rank);
                }
            }
        }
    }

    /// @dev Computes canonical composition through NFD followed by pair composition.
    function nfc(uint256[] memory input, uint256 inputLength, bytes memory normalizationData)
        internal
        pure
        returns (uint256[] memory output, uint256 outputLength)
    {
        (uint256[] memory decomposed, uint256 decomposedLength) =
            nfd(input, inputLength, normalizationData);
        output = new uint256[](decomposedLength);
        if (decomposedLength == 0)
            return (output, 0);

        bool hasStarter;
        uint256 starterIndex;
        uint256 starter;
        uint256 previousRank;

        for (uint256 i; i < decomposedLength; ++i) {
            uint256 cp = decomposed[i];
            uint256 rank = ENSTables.combiningRank(normalizationData, cp);
            bool composed;
            uint256 composition;
            if (hasStarter && (previousRank == 0 || previousRank < rank)) {
                (composed, composition) = _composePair(normalizationData, starter, cp);
            }

            if (composed) {
                output[starterIndex] = composition;
                starter = composition;
            } else {
                if (rank == 0) {
                    hasStarter = true;
                    starterIndex = outputLength;
                    starter = cp;
                }
                output[outputLength++] = cp;
                previousRank = rank;
            }
        }
    }

    ////////////////////////////////////////////////////////////////////////
    // Private Functions
    ////////////////////////////////////////////////////////////////////////

    /// @dev Inserts a code point in canonical combining-class order.
    function _appendOrdered(
        uint256[] memory codepoints,
        uint256[] memory ranks,
        uint256 length,
        uint256 cp,
        uint256 rank
    )
        private
        pure
        returns (uint256)
    {
        uint256 position = length;
        if (rank != 0) {
            while (position != 0 && ranks[position - 1] != 0 && ranks[position - 1] > rank) {
                codepoints[position] = codepoints[position - 1];
                ranks[position] = ranks[position - 1];
                unchecked {
                    --position;
                }
            }
        }
        codepoints[position] = cp;
        ranks[position] = rank;
        return length + 1;
    }

    /// @dev Composes Hangul algorithmically or looks up a canonical composition pair.
    function _composePair(bytes memory data, uint256 first, uint256 second)
        private
        pure
        returns (bool found, uint256 composed)
    {
        if (first >= L0 && first < L1 && second >= V0 && second < V1) {
            return (true, S0 + (first - L0) * N_COUNT + (second - V0) * T_COUNT);
        }
        if (first >= S0 && first < S1 && second > T0 && second < T1 && (first - S0) % T_COUNT == 0) {
            return (true, first + second - T0);
        }
        return ENSTables.composition(data, first, second);
    }
}
