// SPDX-License-Identifier: MIT
pragma solidity ^0.8.27;

/// @dev Packed-byte decoding helpers for generated ENSIP-15 table payloads.
library ENSBytes {
    ////////////////////////////////////////////////////////////////////////
    // Errors
    ////////////////////////////////////////////////////////////////////////

    /// @dev Error selector: `0x71d4cc59`
    error InvalidDataContract(address source);

    ////////////////////////////////////////////////////////////////////////
    // Data Contract Functions
    ////////////////////////////////////////////////////////////////////////

    /// @dev Copies a bytecode data contract's payload, excluding its leading STOP byte.
    function readCode(address source) internal view returns (bytes memory data) {
        uint256 size = source.code.length;
        if (size <= 1)
            revert InvalidDataContract(source);
        unchecked {
            data = new bytes(size - 1);
        }
        assembly ("memory-safe") {
            extcodecopy(source, add(data, 32), 1, sub(size, 1))
        }
    }

    ////////////////////////////////////////////////////////////////////////
    // Integer Decoding Functions
    ////////////////////////////////////////////////////////////////////////

    /// @dev Reads an unsigned 8-bit big-endian integer.
    function u8(bytes memory data, uint256 position) internal pure returns (uint256 value) {
        assembly ("memory-safe") {
            value := byte(0, mload(add(add(data, 32), position)))
        }
    }

    /// @dev Reads an unsigned 16-bit big-endian integer.
    function u16(bytes memory data, uint256 position) internal pure returns (uint256 value) {
        assembly ("memory-safe") {
            value := shr(240, mload(add(add(data, 32), position)))
        }
    }

    /// @dev Reads an unsigned 24-bit big-endian integer.
    function u24(bytes memory data, uint256 position) internal pure returns (uint256 value) {
        assembly ("memory-safe") {
            value := shr(232, mload(add(add(data, 32), position)))
        }
    }

    /// @dev Reads an unsigned 168-bit big-endian integer.
    function u168(bytes memory data, uint256 position) internal pure returns (uint256 value) {
        assembly ("memory-safe") {
            value := shr(88, mload(add(add(data, 32), position)))
        }
    }

    /// @dev Reads an unsigned 256-bit big-endian integer.
    function u256(bytes memory data, uint256 position) internal pure returns (uint256 value) {
        assembly ("memory-safe") {
            value := mload(add(add(data, 32), position))
        }
    }

    /// @dev Reads an unsigned base-128 variable-length integer.
    function varuint(bytes memory data, uint256 position)
        internal
        pure
        returns (uint256 value, uint256 next)
    {
        uint256 shift;
        while (true) {
            uint256 byteValue = u8(data, position++);
            value |= (byteValue & 0x7f) << shift;
            if (byteValue < 0x80)
                return (value, position);
            shift += 7;
        }
    }

    ////////////////////////////////////////////////////////////////////////
    // Bit Functions
    ////////////////////////////////////////////////////////////////////////

    /// @dev Counts the set bits in a 256-bit value.
    function popcount(uint256 value) internal pure returns (uint256) {
        uint256 m1 = type(uint256).max / 3;
        uint256 m2 = type(uint256).max / 5;
        uint256 m4 = type(uint256).max / 17;
        value = value - ((value >> 1) & m1);
        value = (value & m2) + ((value >> 2) & m2);
        value = (value + (value >> 4)) & m4;
        value += value >> 8;
        value += value >> 16;
        value += value >> 32;
        value += value >> 64;
        value += value >> 128;
        // Callers count a strict subset of a 256-bit page, so 255 is the
        // largest possible result and the low byte contains the full sum.
        return value & 0xff;
    }

    /// @dev Returns whether a nonzero value contains exactly one set bit.
    function singleBit(uint256 value) internal pure returns (bool) {
        return value != 0 && (value & (value - 1)) == 0;
    }
}
