// SPDX-License-Identifier: MIT
pragma solidity ^0.8.27;

/// @notice Deploys immutable bytes as contract runtime code.
/// @dev Byte zero is STOP; payload bytes begin at code offset one.
contract ENSDataStore {
    ////////////////////////////////////////////////////////////////////////
    // Constants
    ////////////////////////////////////////////////////////////////////////

    /// @notice Maximum payload size that keeps the deployed runtime within EIP-170.
    uint256 public constant MAX_DATA_SIZE = 24_575;

    ////////////////////////////////////////////////////////////////////////
    // Errors
    ////////////////////////////////////////////////////////////////////////

    /// @dev Error selector: `0x247b458c`
    error DataTooLarge(uint256 size);

    /// @dev Error selector: `0x99d8fec9`
    error EmptyData();

    ////////////////////////////////////////////////////////////////////////
    // Initialization
    ////////////////////////////////////////////////////////////////////////

    /// @param data The immutable payload to expose from runtime bytecode offset one.
    constructor(bytes memory data) {
        uint256 size = data.length;
        if (size == 0)
            revert EmptyData();
        if (size > MAX_DATA_SIZE)
            revert DataTooLarge(size);

        assembly ("memory-safe") {
            // The final byte of the bytes-length word becomes a non-executable
            // STOP prefix. `size` was captured before changing that word.
            mstore8(add(data, 31), 0)
            return(add(data, 31), add(size, 1))
        }
    }
}
