// SPDX-License-Identifier: MIT
pragma solidity ^0.8.27;

import {ENSBytes} from "./ENSBytes.sol";

/// @dev Lookup and decoding helpers for the generated ENSIP-15 table formats.
library ENSTables {
    using ENSBytes for bytes;

    ////////////////////////////////////////////////////////////////////////
    // Types
    ////////////////////////////////////////////////////////////////////////

    /// @dev Parsed offsets and counts for the core character table.
    struct Core {
        bytes data;
        uint256 ignoredOffset;
        uint256 ignoredCount;
        uint256 cmOffset;
        uint256 cmCount;
        uint256 nsmOffset;
        uint256 nsmCount;
        uint256 groupOffset;
        uint256 groupCount;
        uint256 masksOffset;
        uint256 nsmGroups;
    }

    ////////////////////////////////////////////////////////////////////////
    // Constants
    ////////////////////////////////////////////////////////////////////////

    /// @dev Unicode variation selector 16.
    uint256 internal constant FE0F = 0xfe0f;

    /// @dev Byte width of each 167-bit script-group mask.
    uint256 internal constant MASK_BYTES = 21;

    ////////////////////////////////////////////////////////////////////////
    // Implementation
    ////////////////////////////////////////////////////////////////////////

    /// @dev Parses the fixed header and calculated offsets of the core table.
    function parseCore(bytes memory data) internal pure returns (Core memory core) {
        core.data = data;
        core.ignoredCount = data.u16(5);
        core.cmCount = data.u16(7);
        core.nsmCount = data.u16(9);
        core.groupCount = data.u16(11);
        core.nsmGroups = data.u168(14);
        core.ignoredOffset = 35;
        core.cmOffset = core.ignoredOffset + core.ignoredCount * 6;
        core.nsmOffset = core.cmOffset + core.cmCount * 6;
        core.groupOffset = core.nsmOffset + core.nsmCount * 6;
        core.masksOffset = core.groupOffset + core.groupCount * 7;
    }

    /// @dev Returns the script-group membership mask for a code point.
    function groupMask(Core memory core, uint256 cp) internal pure returns (uint256) {
        (bool found, uint256 position) =
            _findRange(core.data, core.groupOffset, core.groupCount, 7, cp);
        if (!found)
            return 0;
        uint256 index = core.data.u8(position + 6);
        return core.data.u168(core.masksOffset + index * MASK_BYTES);
    }

    /// @dev Returns whether a code point belongs to an ignored range.
    function isIgnored(Core memory core, uint256 cp) internal pure returns (bool) {
        (bool found, ) = _findRange(core.data, core.ignoredOffset, core.ignoredCount, 6, cp);
        return found;
    }

    /// @dev Returns whether a code point belongs to a combining-mark range.
    function isCombiningMark(Core memory core, uint256 cp) internal pure returns (bool) {
        (bool found, ) = _findRange(core.data, core.cmOffset, core.cmCount, 6, cp);
        return found;
    }

    /// @dev Returns whether a code point belongs to a non-spacing-mark range.
    function isNonSpacingMark(Core memory core, uint256 cp) internal pure returns (bool) {
        (bool found, ) = _findRange(core.data, core.nsmOffset, core.nsmCount, 6, cp);
        return found;
    }

    /// @dev Returns whether a script group requires non-spacing-mark validation.
    function needsNsmCheck(Core memory core, uint256 groupBit) internal pure returns (bool) {
        return (core.nsmGroups & groupBit) != 0;
    }

    /// @dev Appends the mapping for a code point when a mapping record exists.
    function appendMapped(
        bytes memory data,
        uint256 cp,
        uint256[] memory destination,
        uint256 destinationLength
    )
        internal
        pure
        returns (bool found, uint256 newLength)
    {
        uint256 position;
        (found, position) = _mappedRecord(data, cp);
        if (!found)
            return (false, destinationLength);
        uint256 outputLength = data.u8(position++);
        newLength = destinationLength;
        for (uint256 i; i < outputLength; ++i) {
            (uint256 value, uint256 next) = data.varuint(position);
            position = next;
            destination[newLength++] = value;
        }
        return (true, newLength);
    }

    /// @dev Returns the output length of a code-point mapping when present.
    function mappedLength(bytes memory data, uint256 cp)
        internal
        pure
        returns (bool found, uint256 outputLength)
    {
        uint256 position;
        (found, position) = _mappedRecord(data, cp);
        if (found)
            outputLength = data.u8(position);
    }

    /// @dev Returns the longest emoji-sequence match at an input position.
    function emojiMatch(
        bytes memory data,
        uint256[] memory input,
        uint256 inputPosition,
        uint256 inputEnd
    )
        internal
        pure
        returns (uint256 bestLength)
    {
        uint256 count = data.u16(5);
        uint256 root = input[inputPosition];
        (bool found, uint256 directoryPosition, uint256 index) =
            _findFixedKey(data, 7, count, 5, root, 3);
        if (!found)
            return 0;

        uint256 position = data.u16(directoryPosition + 3);
        uint256 end = index + 1 < count
            ? data.u16(directoryPosition + 8)
            : data.length;

        while (position < end) {
            uint256 sequenceLength = data.u8(position++);
            uint256 cursor = inputPosition + 1;
            bool matches = true;
            for (uint256 i = 1; i < sequenceLength; ++i) {
                (uint256 expected, uint256 next) = data.varuint(position);
                position = next;
                if (!matches)
                    continue;
                if (expected == FE0F) {
                    if (cursor < inputEnd && input[cursor] == FE0F)
                        ++cursor;
                } else if (cursor < inputEnd && input[cursor] == expected) {
                    ++cursor;
                } else {
                    matches = false;
                }
            }
            if (matches && cursor - inputPosition > bestLength) {
                bestLength = cursor - inputPosition;
            }
        }
    }

    /// @dev Returns the whole-script-confusable classification for a code point.
    /// @return kind 0 when absent, 1 when immediately safe, 2 when `mask` applies.
    function wholeMask(bytes memory data, uint256 cp)
        internal
        pure
        returns (uint256 kind, uint256 mask)
    {
        uint256 zeroCount = data.u16(5);
        uint256 nonzeroCount = data.u16(7);
        uint256 zeroOffset = 11;
        (bool safe, ) = _findRange(data, zeroOffset, zeroCount, 6, cp);
        if (safe)
            return (1, 0);

        uint256 nonzeroOffset = zeroOffset + zeroCount * 6;
        (bool found, uint256 position) = _findRange(data, nonzeroOffset, nonzeroCount, 8, cp);
        if (!found)
            return (0, 0);
        uint256 index = data.u16(position + 6);
        uint256 masksOffset = nonzeroOffset + nonzeroCount * 8;
        return (2, data.u168(masksOffset + index * MASK_BYTES));
    }

    /// @dev Returns the canonical combining class rank for a code point.
    function combiningRank(bytes memory data, uint256 cp) internal pure returns (uint256) {
        uint256 count = data.u16(5);
        (bool found, uint256 position) = _findRange(data, 16, count, 7, cp);
        return found ? data.u8(position + 6) : 0;
    }

    /// @dev Returns the canonical decomposition of a code point when present.
    function decomposition(bytes memory data, uint256 cp)
        internal
        pure
        returns (bool found, uint256 length, uint256 first, uint256 second)
    {
        uint256 pageCount = data.u8(7);
        uint256 directoryOffset = data.u16(10);
        uint256 pageOffset;
        (found, pageOffset) = _findPageAt(data, directoryOffset, pageCount, cp >> 8);
        if (!found)
            return (false, 0, 0, 0);

        uint256 low = cp & 0xff;
        uint256 bitmap = data.u256(pageOffset);
        if (((bitmap >> low) & 1) == 0)
            return (false, 0, 0, 0);

        uint256 rank;
        if (low != 0)
            rank = ENSBytes.popcount(bitmap & ((uint256(1) << low) - 1));
        uint256 position =
            pageOffset + 66 + data.u16(pageOffset + 32 + (rank >> 4) * 2);
        uint256 remaining = rank & 15;
        while (remaining != 0) {
            uint256 itemLength = data.u8(position++);
            while (itemLength != 0) {
                (, position) = data.varuint(position);
                unchecked {
                    --itemLength;
                }
            }
            unchecked {
                --remaining;
            }
        }

        length = data.u8(position++);
        (first, position) = data.varuint(position);
        if (length == 2)
            (second, ) = data.varuint(position);
        return (true, length, first, second);
    }

    /// @dev Returns the canonical composition of two code points when present.
    function composition(bytes memory data, uint256 first, uint256 second)
        internal
        pure
        returns (bool found, uint256 composed)
    {
        uint256 count = data.u16(8);
        uint256 directoryOffset = data.u16(12);
        uint256 directoryPosition;
        uint256 index;
        (found, directoryPosition, index) = _findFixedKey(data, directoryOffset, count, 5, first, 3);
        if (!found)
            return (false, 0);

        uint256 position = data.u16(directoryPosition + 3);
        uint256 end = index + 1 < count
            ? data.u16(directoryPosition + 8)
            : data.u16(14);
        while (position < end) {
            (uint256 combining, uint256 next) = data.varuint(position);
            (uint256 result, uint256 afterResult) = data.varuint(next);
            if (combining == second)
                return (true, result);
            if (combining > second)
                return (false, 0);
            position = afterResult;
        }
        return (false, 0);
    }

    ////////////////////////////////////////////////////////////////////////
    // Private Functions
    ////////////////////////////////////////////////////////////////////////

    /// @dev Finds a mapping-table page by its high-byte value.
    function _findPage(bytes memory data, uint256 page)
        private
        pure
        returns (bool found, uint256 offset)
    {
        return _findPageAt(data, 6, data.u8(5), page);
    }

    /// @dev Finds the variable-length mapping record for a code point.
    function _mappedRecord(bytes memory data, uint256 cp)
        private
        pure
        returns (bool found, uint256 position)
    {
        uint256 pageOffset;
        (found, pageOffset) = _findPage(data, cp >> 8);
        if (!found)
            return (false, 0);

        uint256 low = cp & 0xff;
        uint256 bitmap = data.u256(pageOffset);
        if (((bitmap >> low) & 1) == 0)
            return (false, 0);

        uint256 rank;
        if (low != 0)
            rank = ENSBytes.popcount(bitmap & ((uint256(1) << low) - 1));
        position = pageOffset + 66 + data.u16(pageOffset + 32 + (rank >> 4) * 2);
        uint256 remaining = rank & 15;
        while (remaining != 0) {
            uint256 length = data.u8(position++);
            while (length != 0) {
                (, position) = data.varuint(position);
                unchecked {
                    --length;
                }
            }
            unchecked {
                --remaining;
            }
        }
        return (true, position);
    }

    /// @dev Binary-searches a page directory at an arbitrary byte offset.
    function _findPageAt(bytes memory data, uint256 directoryOffset, uint256 count, uint256 page)
        private
        pure
        returns (bool found, uint256 offset)
    {
        uint256 low;
        uint256 high = count;
        while (low < high) {
            uint256 middle = (low + high) >> 1;
            uint256 middlePosition = directoryOffset + middle * 4;
            uint256 candidate = data.u16(middlePosition);
            if (candidate < page) {
                low = middle + 1;
            } else {
                high = middle;
            }
        }
        if (low == count)
            return (false, 0);
        uint256 position = directoryOffset + low * 4;
        if (data.u16(position) != page)
            return (false, 0);
        return (true, data.u16(position + 2));
    }

    /// @dev Binary-searches fixed-width inclusive code-point ranges.
    function _findRange(
        bytes memory data,
        uint256 offset,
        uint256 count,
        uint256 recordSize,
        uint256 cp
    )
        private
        pure
        returns (bool found, uint256 position)
    {
        uint256 low;
        uint256 high = count;
        while (low < high) {
            uint256 middle = (low + high) >> 1;
            position = offset + middle * recordSize;
            if (data.u24(position + 3) < cp) {
                low = middle + 1;
            } else {
                high = middle;
            }
        }
        if (low == count)
            return (false, 0);
        position = offset + low * recordSize;
        if (data.u24(position) > cp)
            return (false, 0);
        return (true, position);
    }

    /// @dev Binary-searches fixed-width records by a two- or three-byte key.
    function _findFixedKey(
        bytes memory data,
        uint256 offset,
        uint256 count,
        uint256 recordSize,
        uint256 key,
        uint256 keySize
    )
        private
        pure
        returns (bool found, uint256 position, uint256 index)
    {
        uint256 low;
        uint256 high = count;
        while (low < high) {
            uint256 middle = (low + high) >> 1;
            position = offset + middle * recordSize;
            uint256 middleCandidate = keySize == 3 ? data.u24(position) : data.u16(position);
            if (middleCandidate < key) {
                low = middle + 1;
            } else {
                high = middle;
            }
        }
        if (low == count)
            return (false, 0, 0);
        position = offset + low * recordSize;
        uint256 candidate = keySize == 3 ? data.u24(position) : data.u16(position);
        if (candidate != key)
            return (false, 0, 0);
        return (true, position, low);
    }
}
