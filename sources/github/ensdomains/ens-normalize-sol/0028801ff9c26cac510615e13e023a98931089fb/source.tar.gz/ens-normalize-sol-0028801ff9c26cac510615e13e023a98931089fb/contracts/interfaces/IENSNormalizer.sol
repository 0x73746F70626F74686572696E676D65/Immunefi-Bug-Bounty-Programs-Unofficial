// SPDX-License-Identifier: MIT
pragma solidity ^0.8.27;

/// @dev Interface selector: `0x9f10f4b5`
interface IENSNormalizer {
    /// @notice Normalizes an ENS name according to ENSIP-15.
    /// @dev Reverts when the name is not normalizable.
    /// @param name The UTF-8 ENS name to normalize.
    /// @return normalizedName The normalized UTF-8 ENS name.
    function normalize(string memory name) external view returns (string memory normalizedName);
}
