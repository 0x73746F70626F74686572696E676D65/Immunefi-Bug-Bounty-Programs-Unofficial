// SPDX-License-Identifier: MIT
pragma solidity ^0.8.27;

import {IENSNormalizer} from "./interfaces/IENSNormalizer.sol";
import {ENSBytes} from "./lib/ENSBytes.sol";
import {ENSTables} from "./lib/ENSTables.sol";
import {ENSUnicode} from "./lib/ENSUnicode.sol";

/// @notice ENSIP-15 normalizer matching @adraffy/ens-normalize 1.11.1.
/// @dev The Unicode 17 tables live in six immutable bytecode data contracts.
contract ENSNormalizer is IENSNormalizer {
    using ENSBytes for bytes;

    ////////////////////////////////////////////////////////////////////////
    // Types
    ////////////////////////////////////////////////////////////////////////

    /// @dev In-memory view of the six packed Unicode and ENSIP-15 data shards.
    struct Tables {
        ENSTables.Core core;
        bytes mapped;
        bytes normalization;
        bytes whole;
        bytes emoji0;
        bytes emoji1;
    }

    ////////////////////////////////////////////////////////////////////////
    // Constants & Immutables
    ////////////////////////////////////////////////////////////////////////

    /// @notice Version of `@adraffy/ens-normalize` reproduced by this contract.
    string public constant UPSTREAM_VERSION = "1.11.1";

    /// @notice Unicode version encoded by the immutable data tables.
    string public constant UNICODE_VERSION = "17.0.0";

    /// @dev Bit mask containing every supported ENS script group.
    uint256 private constant ALL_GROUPS = (uint256(1) << 167) - 1;

    /// @dev Unicode variation selector 16.
    uint256 private constant FE0F = 0xfe0f;

    /// @dev ENS label separator code point.
    uint256 private constant STOP = 0x2e;

    /// @dev ASCII underscore code point.
    uint256 private constant UNDERSCORE = 0x5f;

    /// @dev ASCII hyphen-minus code point.
    uint256 private constant HYPHEN = 0x2d;

    /// @dev Maximum permitted number of consecutive non-spacing marks.
    uint256 private constant NSM_MAX = 4;

    /// @notice Address of the core character and script-group data shard.
    address public immutable CORE_DATA;

    /// @notice Address of the character-mapping data shard.
    address public immutable MAPPING_DATA;

    /// @notice Address of the Unicode normalization data shard.
    address public immutable NORMALIZATION_DATA;

    /// @notice Address of the whole-script-confusable data shard.
    address public immutable WHOLE_DATA;

    /// @notice Address of the first emoji-sequence data shard.
    address public immutable EMOJI_DATA_0;

    /// @notice Address of the second emoji-sequence data shard.
    address public immutable EMOJI_DATA_1;

    ////////////////////////////////////////////////////////////////////////
    // Errors
    ////////////////////////////////////////////////////////////////////////

    /// @dev Error selector: `0x430f13b3`
    error InvalidName();

    /// @dev Error selector: `0x5b4d0ab8`
    error InvalidDataSize(address source, uint256 expected, uint256 actual);

    ////////////////////////////////////////////////////////////////////////
    // Initialization
    ////////////////////////////////////////////////////////////////////////

    /// @param coreData_ Address of the core character and script-group shard.
    /// @param mappingData_ Address of the character-mapping shard.
    /// @param normalizationData_ Address of the Unicode normalization shard.
    /// @param wholeData_ Address of the whole-script-confusable shard.
    /// @param emojiData0_ Address of the first emoji-sequence shard.
    /// @param emojiData1_ Address of the second emoji-sequence shard.
    constructor(
        address coreData_,
        address mappingData_,
        address normalizationData_,
        address wholeData_,
        address emojiData0_,
        address emojiData1_
    )
    {
        _checkDataSize(coreData_, 16_242);
        _checkDataSize(mappingData_, 21_957);
        _checkDataSize(normalizationData_, 20_404);
        _checkDataSize(wholeData_, 14_211);
        _checkDataSize(emojiData0_, 18_221);
        _checkDataSize(emojiData1_, 18_339);
        CORE_DATA = coreData_;
        MAPPING_DATA = mappingData_;
        NORMALIZATION_DATA = normalizationData_;
        WHOLE_DATA = wholeData_;
        EMOJI_DATA_0 = emojiData0_;
        EMOJI_DATA_1 = emojiData1_;
    }

    ////////////////////////////////////////////////////////////////////////
    // Implementation
    ////////////////////////////////////////////////////////////////////////

    /// @notice Normalizes an ENS name according to ENSIP-15.
    /// @param name The UTF-8 ENS name to normalize.
    /// @return normalizedName The normalized UTF-8 ENS name.
    function normalize(string memory name)
        external
        view
        override
        returns (string memory normalizedName)
    {
        Tables memory tables = _loadTables();
        (bool valid, string memory normalized) = _tryNormalize(name, tables);
        if (!valid)
            revert InvalidName();
        return normalized;
    }

    /// @notice Non-reverting normalization helper.
    /// @param name The UTF-8 ENS name to normalize.
    /// @return valid Whether the input is a valid ENSIP-15 name.
    /// @return normalizedName The normalized name, or an empty string when invalid.
    function tryNormalize(string memory name)
        external
        view
        returns (bool valid, string memory normalizedName)
    {
        return _tryNormalize(name, _loadTables());
    }

    /// @notice Batched helper used to replay large conformance corpora efficiently.
    /// @param names The UTF-8 ENS names to normalize.
    /// @return valid Validity result corresponding to each input name.
    /// @return normalizedNames Normalized names, with empty strings for invalid inputs.
    function normalizeBatch(string[] calldata names)
        external
        view
        returns (bool[] memory valid, string[] memory normalizedNames)
    {
        Tables memory tables = _loadTables();
        valid = new bool[](names.length);
        normalizedNames = new string[](names.length);
        for (uint256 i; i < names.length; ++i) {
            string memory name = names[i];
            (valid[i], normalizedNames[i]) = _tryNormalize(name, tables);
        }
    }

    ////////////////////////////////////////////////////////////////////////
    // Private Functions
    ////////////////////////////////////////////////////////////////////////

    /// @dev Copies all immutable bytecode payloads into a reusable in-memory table view.
    function _loadTables() private view returns (Tables memory tables) {
        tables.core = ENSTables.parseCore(ENSBytes.readCode(CORE_DATA));
        tables.mapped = ENSBytes.readCode(MAPPING_DATA);
        tables.normalization = ENSBytes.readCode(NORMALIZATION_DATA);
        tables.whole = ENSBytes.readCode(WHOLE_DATA);
        tables.emoji0 = ENSBytes.readCode(EMOJI_DATA_0);
        tables.emoji1 = ENSBytes.readCode(EMOJI_DATA_1);
    }

    /// @dev Reverts unless a data shard has its generated runtime-code size.
    function _checkDataSize(address source, uint256 expected) private view {
        uint256 actual = source.code.length;
        if (actual != expected)
            revert InvalidDataSize(source, expected, actual);
    }

    /// @dev Normalizes a name using tables already copied into memory.
    function _tryNormalize(string memory name, Tables memory tables)
        private
        pure
        returns (bool valid, string memory normalized)
    {
        (uint256[] memory input, uint256 inputLength, bool utf8Valid) = ENSUnicode.decode(name);
        if (!utf8Valid)
            return (false, "");
        if (inputLength == 0)
            return (true, "");

        uint256 outputCapacity;
        uint256 measuredStart;
        for (uint256 measuredPosition; measuredPosition <= inputLength; ++measuredPosition) {
            if (measuredPosition != inputLength && input[measuredPosition] != STOP)
                continue;
            if (measuredPosition == measuredStart)
                return (false, "");
            (bool measurable, uint256 rawTotal, , uint256 emojiOutput) =
                _measureLabel(input, measuredStart, measuredPosition, tables);
            if (!measurable)
                return (false, "");
            outputCapacity += rawTotal * 4 + emojiOutput + 1;
            measuredStart = measuredPosition + 1;
        }

        uint256[] memory output = new uint256[](outputCapacity + 8);
        uint256 outputLength;
        uint256 labelStart;

        for (uint256 position; position <= inputLength; ++position) {
            if (position != inputLength && input[position] != STOP)
                continue;

            (uint256[] memory normalizedLabel, uint256 normalizedLength, bool labelValid) =
                _normalizeLabel(input, labelStart, position, tables);
            if (!labelValid)
                return (false, "");
            for (uint256 i; i < normalizedLength; ++i) {
                output[outputLength++] = normalizedLabel[i];
            }
            if (position != inputLength)
                output[outputLength++] = STOP;
            labelStart = position + 1;
        }

        return (true, ENSUnicode.encode(output, outputLength));
    }

    /// @dev Normalizes and validates one label between the supplied code-point bounds.
    function _normalizeLabel(
        uint256[] memory input,
        uint256 start,
        uint256 end,
        Tables memory tables
    )
        private
        pure
        returns (uint256[] memory normalized, uint256 normalizedLength, bool valid)
    {
        (, uint256 rawTotal, uint256 maximumRawToken, uint256 emojiOutput) =
            _measureLabel(input, start, end, tables);

        uint256 textCapacity = rawTotal * 4 + 8;
        normalized = new uint256[](textCapacity + emojiOutput);
        uint256[] memory text = new uint256[](textCapacity);
        uint256 textLength;
        uint256[] memory raw = new uint256[](maximumRawToken + 8);
        uint256 rawLength;
        uint256 tokenCount;
        bool hasEmoji;

        uint256 position = start;
        while (position < end) {
            uint256 emojiLength = ENSTables.emojiMatch(tables.emoji0, input, position, end);
            if (emojiLength == 0) {
                emojiLength = ENSTables.emojiMatch(tables.emoji1, input, position, end);
            }
            if (emojiLength != 0) {
                if (rawLength != 0) {
                    bool flushed;
                    (normalizedLength, textLength, flushed) = _flushText(
                        raw,
                        rawLength,
                        normalized,
                        normalizedLength,
                        text,
                        textLength,
                        tables
                    );
                    if (!flushed)
                        return (normalized, normalizedLength, false);
                    rawLength = 0;
                    ++tokenCount;
                }
                ++tokenCount;
                hasEmoji = true;
                for (uint256 i; i < emojiLength; ++i) {
                    uint256 emojiCp = input[position + i];
                    if (emojiCp != FE0F)
                        normalized[normalizedLength++] = emojiCp;
                }
                position += emojiLength;
                continue;
            }

            uint256 cp = input[position++];
            uint256 mask = ENSTables.groupMask(tables.core, cp);
            if (mask != 0 || _isExtraValid(cp)) {
                raw[rawLength++] = cp;
                continue;
            }
            (bool mapped, uint256 nextLength) =
                ENSTables.appendMapped(tables.mapped, cp, raw, rawLength);
            if (mapped) {
                rawLength = nextLength;
            }
        }

        if (rawLength != 0) {
            bool flushed;
            (normalizedLength, textLength, flushed) = _flushText(
                raw,
                rawLength,
                normalized,
                normalizedLength,
                text,
                textLength,
                tables
            );
            if (!flushed)
                return (normalized, normalizedLength, false);
            ++tokenCount;
        }
        if (tokenCount == 0 || normalizedLength == 0) {
            return (normalized, normalizedLength, false);
        }
        valid = _validateLabel(normalized, normalizedLength, text, textLength, hasEmoji, tables);
    }

    /// @dev Preflights a label to determine validity and required buffer capacities.
    function _measureLabel(uint256[] memory input, uint256 start, uint256 end, Tables memory tables)
        private
        pure
        returns (bool valid, uint256 rawTotal, uint256 maximumRawToken, uint256 emojiOutput)
    {
        uint256 currentRaw;
        uint256 position = start;
        while (position < end) {
            uint256 emojiLength = ENSTables.emojiMatch(tables.emoji0, input, position, end);
            if (emojiLength == 0) {
                emojiLength = ENSTables.emojiMatch(tables.emoji1, input, position, end);
            }
            if (emojiLength != 0) {
                if (currentRaw > maximumRawToken)
                    maximumRawToken = currentRaw;
                currentRaw = 0;
                for (uint256 i; i < emojiLength; ++i) {
                    if (input[position + i] != FE0F)
                        ++emojiOutput;
                }
                position += emojiLength;
                continue;
            }

            uint256 cp = input[position++];
            if (ENSTables.groupMask(tables.core, cp) != 0 || _isExtraValid(cp)) {
                ++currentRaw;
                ++rawTotal;
                continue;
            }
            (bool mapped, uint256 mappedCount) = ENSTables.mappedLength(tables.mapped, cp);
            if (mapped) {
                currentRaw += mappedCount;
                rawTotal += mappedCount;
            } else if (!ENSTables.isIgnored(tables.core, cp)) {
                return (false, rawTotal, maximumRawToken, emojiOutput);
            }
        }
        if (currentRaw > maximumRawToken)
            maximumRawToken = currentRaw;
        return (true, rawTotal, maximumRawToken, emojiOutput);
    }

    /// @dev NFC-normalizes a contiguous text token and appends it to the output buffers.
    function _flushText(
        uint256[] memory raw,
        uint256 rawLength,
        uint256[] memory normalized,
        uint256 normalizedLength,
        uint256[] memory text,
        uint256 textLength,
        Tables memory tables
    )
        private
        pure
        returns (uint256 nextNormalizedLength, uint256 nextTextLength, bool valid)
    {
        (uint256[] memory composed, uint256 composedLength) =
            ENSUnicode.nfc(raw, rawLength, tables.normalization);
        if (composedLength == 0 || ENSTables.isCombiningMark(tables.core, composed[0])) {
            return (normalizedLength, textLength, false);
        }
        nextNormalizedLength = normalizedLength;
        nextTextLength = textLength;
        for (uint256 i; i < composedLength; ++i) {
            normalized[nextNormalizedLength++] = composed[i];
            text[nextTextLength++] = composed[i];
        }
        return (nextNormalizedLength, nextTextLength, true);
    }

    /// @dev Applies underscore, extension, fencing, group, NSM, and confusable validation.
    function _validateLabel(
        uint256[] memory normalized,
        uint256 normalizedLength,
        uint256[] memory text,
        uint256 textLength,
        bool hasEmoji,
        Tables memory tables
    )
        private
        pure
        returns (bool)
    {
        bool nonUnderscore;
        bool ascii = !hasEmoji;
        for (uint256 i; i < normalizedLength; ++i) {
            uint256 cp = normalized[i];
            if (cp == UNDERSCORE) {
                if (nonUnderscore)
                    return false;
            } else {
                nonUnderscore = true;
            }
            if (cp >= 0x80)
                ascii = false;
        }

        if (ascii) {
            return !(normalizedLength >= 4 && normalized[2] == HYPHEN && normalized[3] == HYPHEN);
        }
        if (textLength == 0)
            return true;
        if (!_validFencing(normalized, normalizedLength))
            return false;

        uint256 candidates = ALL_GROUPS;
        for (uint256 i; i < textLength; ++i) {
            uint256 mask = ENSTables.groupMask(tables.core, text[i]);
            if (mask == 0)
                return false;
            candidates &= mask;
            if (candidates == 0)
                return false;
        }
        uint256 groupBit = candidates & (~candidates + 1);

        if (ENSTables.needsNsmCheck(tables.core, groupBit)) {
            if (!_validNsm(text, textLength, tables))
                return false;
        }
        return _validWholes(text, textLength, tables);
    }

    /// @dev Checks the ENSIP-15 contextual constraints for fenced characters.
    function _validFencing(uint256[] memory normalized, uint256 length) private pure returns (bool) {
        if (_isFenced(normalized[0]) || _isFenced(normalized[length - 1])) {
            return false;
        }
        bool previousFenced;
        for (uint256 i = 1; i + 1 < length; ++i) {
            bool fenced = _isFenced(normalized[i]);
            if (fenced && previousFenced)
                return false;
            previousFenced = fenced;
        }
        return true;
    }

    /// @dev Checks the duplicate and maximum-run constraints for non-spacing marks.
    function _validNsm(uint256[] memory text, uint256 textLength, Tables memory tables)
        private
        pure
        returns (bool)
    {
        (uint256[] memory decomposed, uint256 decomposedLength) =
            ENSUnicode.nfd(text, textLength, tables.normalization);
        uint256 i = 1;
        while (i < decomposedLength) {
            if (!ENSTables.isNonSpacingMark(tables.core, decomposed[i])) {
                ++i;
                continue;
            }
            uint256 end = i + 1;
            while (
                end < decomposedLength && ENSTables.isNonSpacingMark(tables.core, decomposed[end])
            ) {
                for (uint256 previous = i; previous < end; ++previous) {
                    if (decomposed[previous] == decomposed[end])
                        return false;
                }
                ++end;
            }
            if (end - i > NSM_MAX)
                return false;
            i = end;
        }
        return true;
    }

    /// @dev Checks whole-script-confusable safety for a normalized text token.
    function _validWholes(uint256[] memory text, uint256 textLength, Tables memory tables)
        private
        pure
        returns (bool)
    {
        bool hasMaker;
        uint256 maker;
        uint256 shared = ALL_GROUPS;

        for (uint256 i; i < textLength; ++i) {
            uint256 cp = text[i];
            uint256 groupMembership = ENSTables.groupMask(tables.core, cp);
            (uint256 kind, uint256 complement) = ENSTables.wholeMask(tables.whole, cp);
            if (kind == 1)
                return true;
            if (kind == 2) {
                maker = hasMaker ? maker & complement : complement;
                hasMaker = true;
                if (maker == 0)
                    return true;
            } else {
                if (ENSBytes.singleBit(groupMembership))
                    return true;
                shared &= groupMembership;
            }
        }
        return !hasMaker || (maker & shared) == 0;
    }

    /// @dev Returns whether a code point is valid outside the generated script-group ranges.
    function _isExtraValid(uint256 cp) private pure returns (bool) {
        return
            cp == 807 ||
            cp == 808 ||
            cp == 1729 ||
            cp == 1749 ||
            cp == 4467 ||
            cp == 12441 ||
            cp == 12442;
    }

    /// @dev Returns whether a code point is subject to ENSIP-15 fencing rules.
    function _isFenced(uint256 cp) private pure returns (bool) {
        return cp == 0x2019 || cp == 0x2044 || cp == 0x30fb;
    }
}
