# ENS normalization in Solidity

This repository implements ENSIP-15 normalization in Solidity with the API:

```solidity
function normalize(string memory name)
    external
    view
    returns (string memory normalizedName);
```

The behavior is pinned to `@adraffy/ens-normalize` **1.11.1**, Unicode
**17.0.0**, and CLDR **47**. Valid inputs return the same UTF-8 output as the
JavaScript implementation; invalid inputs revert with `InvalidName()`.

## Status

- 38,613 / 38,613 upstream validation vectors pass.
- 21,466 valid outputs match byte-for-byte.
- 17,147 invalid inputs are rejected.
- Hardhat 3 coverage is 100% for lines and statements.
- The optimized `ENSNormalizer` runtime is below the EIP-170 24 KiB limit.
- Every immutable data shard is below the same 24 KiB limit.

Character-breakdown reports and upstream error-message strings are intentionally
not reproduced. Acceptance/rejection and normalized output are reproduced.

## Architecture

The algorithm in `ENSNormalizer.sol` performs:

1. strict UTF-8 decoding and `.` label splitting;
2. longest-match emoji tokenization, including optional `FE0F`;
3. valid/mapped/ignored character processing;
4. custom Unicode NFC/NFD (including algorithmic Hangul);
5. underscore, label-extension, fencing, script-group, combining-mark, and
   whole-script-confusable validation; and
6. UTF-8 encoding of the normalized result.

Unicode tables do not use storage slots. Six `ENSDataStore` contracts hold
immutable packed bytes in runtime bytecode:

| Payload | Bytes |
| --- | ---: |
| Core character/group data | 16,241 |
| Mappings | 21,956 |
| NFC/NFD data | 20,403 |
| Whole-script confusables | 14,210 |
| Emoji shard 0 | 18,220 |
| Emoji shard 1 | 18,338 |

The normalizer receives those six addresses in its constructor and verifies
their exact deployed code sizes.

## Development

Requirements: Node.js 22+ and pnpm.

```sh
pnpm install
pnpm build:data
pnpm compile
pnpm lint
pnpm format:check
pnpm test
```

Solidity linting and formatting use Solgrid 0.1.0. `solgrid.toml` mirrors the
ENS contracts production rules, while `solgrid.test.toml` applies the
corresponding relaxed policy to Solidity test harnesses.

`pnpm test` runs focused contract tests plus all 38,613 vendored upstream
vectors. On a typical development machine the full conformance replay takes a
few minutes.

Run coverage with:

```sh
ENS_UPSTREAM_LIMIT=1000 pnpm coverage
```

The focused tests plus the first 1,000 conformance vectors cover every Solidity
line and statement; the separate default test command always replays the full
corpus.

To regenerate the packed tables, edit or replace the pinned files in
`upstream/`, then run `pnpm build:data`. The generator fails if any payload
would exceed EIP-170.

## Deployment

Compile with the production optimizer profile and deploy all data shards plus
the normalizer:

```sh
pnpm hardhat --build-profile production compile
pnpm hardhat --build-profile production --network <network> run scripts/deploy.ts
```

The script prints a JSON deployment manifest containing the normalizer and all
six data-contract addresses.

### Sepolia

The production-profile deployment on Sepolia is:

```text
ENSNormalizer: 0x999999999Af528aDe2B7Ad1C321CA71f886DB7F9
```

The normalizer was deployed through the deterministic deployment proxy at
`0x4e59b44847b379578588920cA78FbF26c0B4956C` with `CREATE2`.
The complete address, transaction, gas, cost, and verification record is in
[`deployments/sepolia.json`](deployments/sepolia.json).

For local integrations, `tryNormalize` returns `(bool, string)` without
reverting, and `normalizeBatch` amortizes table loading across many names.
These helpers do not change the requested `normalize(string)` selector.

## Version integrity

The authoritative input and generated-payload hashes are in
[`data/manifest.json`](data/manifest.json). The upstream `spec.json` SHA-256 is:

```text
4febc8f5d285cbf80d2320fb0c1777ac25e378eb72910c34ec963d0a4e319c84
```

That is the Unicode 17.0.0 ENSIP-15 specification hash published by the
upstream project.

## License

This project is MIT licensed. The pinned upstream data and tests originate from
`adraffy/ens-normalize.js`; its MIT license is retained in
`upstream/LICENSE.adraffy`.
