import { readFile } from "node:fs/promises";
import { resolve } from "node:path";

import { artifacts, network } from "hardhat";
import { formatEther, formatGwei, type Address, type Hex } from "viem";

const files = [
  "core.bin",
  "mapping.bin",
  "normalization.bin",
  "wholes.bin",
  "emoji-0.bin",
  "emoji-1.bin",
] as const;

const { viem, networkName } = await network.create();
const publicClient = await viem.getPublicClient();
const [walletClient] = await viem.getWalletClients();
if (walletClient === undefined) {
  throw new Error("The selected network has no configured deployer account");
}

const chainId = await publicClient.getChainId();
const balanceBefore = await publicClient.getBalance({
  address: walletClient.account.address,
});
const fees = await publicClient.estimateFeesPerGas();
const estimatedDeploymentGas = 30_000_000n;
const estimatedMaxCost =
  estimatedDeploymentGas *
  (fees.maxFeePerGas ?? fees.gasPrice ?? 0n);

if (balanceBefore < estimatedMaxCost) {
  throw new Error(
    `Insufficient deployer balance: ${formatEther(balanceBefore)} ETH; ` +
      `estimated maximum required: ${formatEther(estimatedMaxCost)} ETH`,
  );
}

console.log(
  JSON.stringify(
    {
      network: networkName,
      chainId,
      deployer: walletClient.account.address,
      balance: `${formatEther(balanceBefore)} ETH`,
      estimatedMaxFeePerGas:
        fees.maxFeePerGas === undefined
          ? undefined
          : `${formatGwei(fees.maxFeePerGas)} gwei`,
    },
    null,
    2,
  ),
);

const stores: Address[] = [];
const deployments: Array<{
  name: string;
  address: Address;
  transactionHash: Hex;
  blockNumber: string;
  gasUsed: string;
  effectiveGasPrice: string;
  cost: string;
}> = [];
const deploymentArtifacts = {
  ENSDataStore: await artifacts.readArtifact("ENSDataStore"),
  ENSNormalizer: await artifacts.readArtifact("ENSNormalizer"),
};

async function sendDeployment(
  name: string,
  contractName: "ENSDataStore" | "ENSNormalizer",
  constructorArgs: readonly unknown[],
) {
  const artifact = deploymentArtifacts[contractName];
  const transactionHash = await walletClient.deployContract({
    abi: artifact.abi,
    bytecode: artifact.bytecode as Hex,
    args: constructorArgs,
  });
  return confirmDeployment(name, transactionHash);
}

async function confirmDeployment(
  name: string,
  transactionHash: Hex,
  expectedAddress?: Address,
) {
  console.log(`${name}: submitted ${transactionHash}`);
  const receipt = await publicClient.waitForTransactionReceipt({
    hash: transactionHash,
    confirmations: 1,
    timeout: 300_000,
  });
  if (receipt.status !== "success" || receipt.contractAddress == null) {
    throw new Error(`${name} deployment reverted: ${transactionHash}`);
  }

  const address = receipt.contractAddress;
  if (
    expectedAddress !== undefined &&
    address.toLowerCase() !== expectedAddress.toLowerCase()
  ) {
    throw new Error(
      `${name} receipt address ${address} does not match ${expectedAddress}`,
    );
  }

  const cost = receipt.gasUsed * receipt.effectiveGasPrice;
  deployments.push({
    name,
    address,
    transactionHash,
    blockNumber: receipt.blockNumber.toString(),
    gasUsed: receipt.gasUsed.toString(),
    effectiveGasPrice: receipt.effectiveGasPrice.toString(),
    cost: cost.toString(),
  });
  console.log(
    `${name}: confirmed in block ${receipt.blockNumber}; ` +
      `${receipt.gasUsed} gas; ${formatEther(cost)} ETH`,
  );
  return address;
}

const resumedStoreAddresses = (process.env.RESUME_DATA_STORES ?? "")
  .split(",")
  .filter((value) => value !== "") as Address[];
const resumedStoreTransactions = (process.env.RESUME_DATA_STORE_TXS ?? "")
  .split(",")
  .filter((value) => value !== "") as Hex[];
if (
  resumedStoreAddresses.length !== resumedStoreTransactions.length ||
  resumedStoreAddresses.length > files.length
) {
  throw new Error(
    "RESUME_DATA_STORES and RESUME_DATA_STORE_TXS must contain matching " +
      "ordered prefixes",
  );
}

for (const [index, file] of files.entries()) {
  const bytes = await readFile(resolve("data", file));
  const data = `0x${bytes.toString("hex")}` as Hex;
  const resumedAddress = resumedStoreAddresses[index];
  const resumedTransaction = resumedStoreTransactions[index];
  if (resumedAddress !== undefined && resumedTransaction !== undefined) {
    const code = await publicClient.getCode({ address: resumedAddress });
    if (code?.toLowerCase() !== `0x00${data.slice(2)}`.toLowerCase()) {
      throw new Error(`${file} resume address has unexpected runtime code`);
    }
    stores.push(resumedAddress);
    console.log(`${file}: resuming verified deployment at ${resumedAddress}`);
    await confirmDeployment(file, resumedTransaction, resumedAddress);
    continue;
  }

  stores.push(await sendDeployment(file, "ENSDataStore", [data]));
}

const normalizer = await sendDeployment(
  "ENSNormalizer",
  "ENSNormalizer",
  stores as [Address, Address, Address, Address, Address, Address],
);

const totalCost = deployments.reduce(
  (total, deployment) => total + BigInt(deployment.cost),
  0n,
);
console.log(
  JSON.stringify(
    {
      network: networkName,
      chainId,
      deployer: walletClient.account.address,
      normalizer,
      dataStores: Object.fromEntries(
        files.map((file, index) => [file, stores[index]]),
      ),
      deployments,
      totalGasUsed: deployments
        .reduce((total, deployment) => total + BigInt(deployment.gasUsed), 0n)
        .toString(),
      totalCost: totalCost.toString(),
      totalCostEth: formatEther(totalCost),
    },
    null,
    2,
  ),
);
