import { readFile } from "node:fs/promises";
import { resolve } from "node:path";

import { artifacts, network } from "hardhat";
import {
  concatHex,
  encodeDeployData,
  formatEther,
  formatGwei,
  getAddress,
  getCreate2Address,
  keccak256,
  type Address,
  type Hex,
} from "viem";

const DEFAULT_FACTORY =
  "0x4e59b44847b379578588920cA78FbF26c0B4956C";
const files = [
  "core.bin",
  "mapping.bin",
  "normalization.bin",
  "wholes.bin",
  "emoji-0.bin",
  "emoji-1.bin",
] as const;

const salt = process.env.CREATE2_SALT as Hex | undefined;
if (salt === undefined || !/^0x[0-9a-fA-F]{64}$/.test(salt)) {
  throw new Error("CREATE2_SALT must be a 32-byte hex value");
}

const { viem, networkName } = await network.create();
const publicClient = await viem.getPublicClient();
const [walletClient] = await viem.getWalletClients();
if (walletClient === undefined) {
  throw new Error("The selected network has no configured deployer account");
}

const manifestPath =
  process.env.DEPLOYMENT_MANIFEST ??
  resolve("deployments", `${networkName}.json`);
const manifest = JSON.parse(await readFile(manifestPath, "utf8")) as {
  normalizer?: Address;
  dataStores: Record<(typeof files)[number], Address>;
};
const stores = files.map((file) => manifest.dataStores[file]) as [
  Address,
  Address,
  Address,
  Address,
  Address,
  Address,
];

const artifact = await artifacts.readArtifact("ENSNormalizer");
const initCode = encodeDeployData({
  abi: artifact.abi,
  bytecode: artifact.bytecode as Hex,
  args: stores,
});
const initCodeHash = keccak256(initCode);
const factory = getAddress(
  process.env.CREATE2_FACTORY ?? DEFAULT_FACTORY,
);
const address = getCreate2Address({
  from: factory,
  salt,
  bytecodeHash: initCodeHash,
});
const expectedAddress =
  process.env.CREATE2_EXPECTED_ADDRESS === undefined
    ? undefined
    : getAddress(process.env.CREATE2_EXPECTED_ADDRESS);

if (expectedAddress !== undefined && address !== expectedAddress) {
  throw new Error(
    `Computed address ${address} does not match expected ${expectedAddress}`,
  );
}

const [chainId, factoryCode, existingCode, referenceCode] = await Promise.all([
  publicClient.getChainId(),
  publicClient.getCode({ address: factory }),
  publicClient.getCode({ address }),
  manifest.normalizer === undefined
    ? undefined
    : publicClient.getCode({ address: manifest.normalizer }),
]);
if (factoryCode === undefined || factoryCode === "0x") {
  throw new Error(`CREATE2 factory is not deployed at ${factory}`);
}

if (existingCode !== undefined && existingCode !== "0x") {
  if (
    referenceCode !== undefined &&
    existingCode.toLowerCase() !== referenceCode.toLowerCase()
  ) {
    throw new Error(`Target ${address} is occupied by unexpected code`);
  }
  console.log(
    JSON.stringify(
      {
        status: "already-deployed",
        network: networkName,
        chainId,
        factory,
        salt,
        initCodeHash,
        address,
        runtimeCodeHash: keccak256(existingCode),
      },
      null,
      2,
    ),
  );
  process.exit(0);
}

const data = concatHex([salt, initCode]);
const gas = await publicClient.estimateGas({
  account: walletClient.account.address,
  to: factory,
  data,
});
const gasLimit = gas + gas / 10n;
const [balance, fees] = await Promise.all([
  publicClient.getBalance({ address: walletClient.account.address }),
  publicClient.estimateFeesPerGas(),
]);
const maxFeePerGas = fees.maxFeePerGas ?? fees.gasPrice ?? 0n;
const estimatedMaxCost = gasLimit * maxFeePerGas;
if (balance < estimatedMaxCost) {
  throw new Error(
    `Insufficient deployer balance: ${formatEther(balance)} ETH; ` +
      `estimated maximum required: ${formatEther(estimatedMaxCost)} ETH`,
  );
}

console.log(
  JSON.stringify(
    {
      status: "ready",
      network: networkName,
      chainId,
      deployer: walletClient.account.address,
      factory,
      salt,
      initCodeBytes: (initCode.length - 2) / 2,
      initCodeHash,
      expectedAddress: address,
      estimatedGas: gas.toString(),
      gasLimit: gasLimit.toString(),
      estimatedMaxFeePerGas: `${formatGwei(maxFeePerGas)} gwei`,
      estimatedMaxCost: `${formatEther(estimatedMaxCost)} ETH`,
    },
    null,
    2,
  ),
);

if (process.env.CREATE2_DRY_RUN === "1") {
  process.exit(0);
}

const transactionHash = await walletClient.sendTransaction({
  to: factory,
  data,
  gas: gasLimit,
});
console.log(`submitted ${transactionHash}`);

const receipt = await publicClient.waitForTransactionReceipt({
  hash: transactionHash,
  confirmations: 1,
  timeout: 300_000,
});
if (receipt.status !== "success") {
  throw new Error(`CREATE2 deployment reverted: ${transactionHash}`);
}

const runtimeCode = await publicClient.getCode({ address });
if (runtimeCode === undefined || runtimeCode === "0x") {
  throw new Error(`CREATE2 deployment produced no code at ${address}`);
}
if (
  referenceCode !== undefined &&
  runtimeCode.toLowerCase() !== referenceCode.toLowerCase()
) {
  throw new Error(`Deployed runtime at ${address} is unexpected`);
}

const cost = receipt.gasUsed * receipt.effectiveGasPrice;
console.log(
  JSON.stringify(
    {
      status: "deployed",
      network: networkName,
      chainId,
      deployer: walletClient.account.address,
      factory,
      salt,
      initCodeHash,
      address,
      runtimeCodeHash: keccak256(runtimeCode),
      transactionHash,
      blockNumber: receipt.blockNumber.toString(),
      gasUsed: receipt.gasUsed.toString(),
      effectiveGasPrice: receipt.effectiveGasPrice.toString(),
      costWei: cost.toString(),
      costEth: formatEther(cost),
    },
    null,
    2,
  ),
);
