import { createHash } from "node:crypto";
import { mkdirSync, readFileSync, writeFileSync } from "node:fs";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";

const root = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const specPath = resolve(root, "upstream/spec.json");
const nfPath = resolve(root, "upstream/nf.json");
const outputDir = resolve(root, "data");
const specBytes = readFileSync(specPath);
const nfBytes = readFileSync(nfPath);
const spec = JSON.parse(specBytes);
const nf = JSON.parse(nfBytes);

const MAX_DATA_SIZE = 24_575;
const GROUP_COUNT = spec.groups.length;
const MASK_BYTES = Math.ceil(GROUP_COUNT / 8);

class Writer {
  bytes = [];

  ascii(value) {
    for (const byte of Buffer.from(value, "ascii")) this.u8(byte);
  }

  u8(value) {
    if (!Number.isInteger(value) || value < 0 || value > 0xff) {
      throw new RangeError(`u8: ${value}`);
    }
    this.bytes.push(value);
  }

  u16(value) {
    if (!Number.isInteger(value) || value < 0 || value > 0xffff) {
      throw new RangeError(`u16: ${value}`);
    }
    this.u8((value >>> 8) & 0xff);
    this.u8(value & 0xff);
  }

  u24(value) {
    if (!Number.isInteger(value) || value < 0 || value > 0xffffff) {
      throw new RangeError(`u24: ${value}`);
    }
    this.u8((value >>> 16) & 0xff);
    this.u8((value >>> 8) & 0xff);
    this.u8(value & 0xff);
  }

  uint(value, width) {
    value = BigInt(value);
    for (let i = width - 1; i >= 0; i--) {
      this.u8(Number((value >> BigInt(i * 8)) & 0xffn));
    }
  }

  varuint(value) {
    if (!Number.isInteger(value) || value < 0 || value > 0x10ffff) {
      throw new RangeError(`varuint: ${value}`);
    }
    do {
      let byte = value & 0x7f;
      value >>>= 7;
      if (value) byte |= 0x80;
      this.u8(byte);
    } while (value);
  }

  append(value) {
    this.bytes.push(...value);
  }

  get length() {
    return this.bytes.length;
  }

  buffer() {
    return Buffer.from(this.bytes);
  }
}

function sha256(bytes) {
  return createHash("sha256").update(bytes).digest("hex");
}

function contiguousRanges(values, valueOf = () => 0) {
  const sorted = [...values].sort((a, b) => {
    const acp = Array.isArray(a) ? a[0] : a;
    const bcp = Array.isArray(b) ? b[0] : b;
    return acp - bcp;
  });
  const ranges = [];
  for (const item of sorted) {
    const cp = Array.isArray(item) ? item[0] : item;
    const value = valueOf(item);
    const previous = ranges.at(-1);
    if (previous && previous.end + 1 === cp && previous.value === value) {
      previous.end = cp;
    } else {
      ranges.push({ start: cp, end: cp, value });
    }
  }
  return ranges;
}

function uniqueIndex(values) {
  const indices = new Map();
  const unique = [];
  for (const value of values) {
    if (!indices.has(value)) {
      indices.set(value, unique.length);
      unique.push(value);
    }
  }
  return { indices, unique };
}

function writeRange(writer, range) {
  writer.u24(range.start);
  writer.u24(range.end);
}

function groupMasks() {
  const masks = new Map();
  spec.groups.forEach((group, index) => {
    const bit = 1n << BigInt(index);
    for (const cp of [...group.primary, ...group.secondary]) {
      masks.set(cp, (masks.get(cp) ?? 0n) | bit);
    }
  });
  return masks;
}

const masksByCodepoint = groupMasks();

function makeCore() {
  const ignored = contiguousRanges(spec.ignored);
  const cm = contiguousRanges(spec.cm);
  const nsm = contiguousRanges(spec.nsm);
  const membership = [...masksByCodepoint.entries()].sort((a, b) => a[0] - b[0]);
  const { indices, unique } = uniqueIndex(membership.map(([, mask]) => mask));
  const groups = contiguousRanges(membership, ([, mask]) => indices.get(mask));
  let nsmGroups = 0n;
  spec.groups.forEach((group, index) => {
    if (!Array.isArray(group.cm)) nsmGroups |= 1n << BigInt(index);
  });

  if (unique.length > 0xff) throw new Error("group mask index no longer fits in one byte");

  const writer = new Writer();
  writer.ascii("ENSC");
  writer.u8(1);
  writer.u16(ignored.length);
  writer.u16(cm.length);
  writer.u16(nsm.length);
  writer.u16(groups.length);
  writer.u8(unique.length);
  writer.uint(nsmGroups, MASK_BYTES);
  for (const range of ignored) writeRange(writer, range);
  for (const range of cm) writeRange(writer, range);
  for (const range of nsm) writeRange(writer, range);
  for (const range of groups) {
    writeRange(writer, range);
    writer.u8(range.value);
  }
  for (const mask of unique) writer.uint(mask, MASK_BYTES);
  return writer.buffer();
}

function makeWholes() {
  const mapped = new Map();

  for (const whole of spec.wholes) {
    const codepoints = [...whole.valid, ...whole.confused];
    const records = [];
    for (const cp of codepoints) {
      const mask = masksByCodepoint.get(cp) ?? 0n;
      let record = records.find((candidate) => (candidate.mask & mask) !== 0n);
      if (!record) {
        record = { mask: 0n, codepoints: [] };
        records.push(record);
      }
      record.mask |= mask;
      record.codepoints.push(cp);
    }
    const union = records.reduce((mask, record) => mask | record.mask, 0n);
    const confused = new Set(whole.confused);
    for (const record of records) {
      const complement = union & ~record.mask;
      for (const cp of record.codepoints) {
        if (!confused.has(cp)) continue;
        if (mapped.has(cp)) throw new Error(`duplicate whole-script codepoint: ${cp}`);
        mapped.set(cp, complement);
      }
    }
  }

  const zero = contiguousRanges([...mapped].filter(([, mask]) => mask === 0n));
  const nonzeroEntries = [...mapped].filter(([, mask]) => mask !== 0n);
  const { indices, unique } = uniqueIndex(nonzeroEntries.map(([, mask]) => mask));
  const nonzero = contiguousRanges(
    nonzeroEntries,
    ([, mask]) => indices.get(mask)
  );

  const writer = new Writer();
  writer.ascii("ENSW");
  writer.u8(1);
  writer.u16(zero.length);
  writer.u16(nonzero.length);
  writer.u16(unique.length);
  for (const range of zero) writeRange(writer, range);
  for (const range of nonzero) {
    writeRange(writer, range);
    writer.u16(range.value);
  }
  for (const mask of unique) writer.uint(mask, MASK_BYTES);
  return writer.buffer();
}

function groupByPage(records) {
  const pages = new Map();
  for (const record of [...records].sort((a, b) => a[0] - b[0])) {
    const page = record[0] >>> 8;
    if (!pages.has(page)) pages.set(page, []);
    pages.get(page).push(record);
  }
  return [...pages.entries()].sort((a, b) => a[0] - b[0]);
}

function makeBitmapPage(records) {
  let bitmap = 0n;
  const encoded = [];
  const offsets = [];
  for (let index = 0; index < records.length; index++) {
    if (index % 16 === 0) offsets.push(encoded.length);
    const [cp, output] = records[index];
    bitmap |= 1n << BigInt(cp & 0xff);
    const writer = new Writer();
    writer.u8(output.length);
    for (const value of output) writer.varuint(value);
    encoded.push(...writer.bytes);
  }
  while (offsets.length < 17) offsets.push(encoded.length);
  offsets.push(encoded.length);
  offsets.length = 17;

  const writer = new Writer();
  writer.uint(bitmap, 32);
  for (const offset of offsets) writer.u16(offset);
  writer.append(encoded);
  return writer.buffer();
}

function makePagedMap(magic, records) {
  const pages = groupByPage(records);
  if (pages.length > 0xff) throw new Error(`${magic}: too many pages`);
  const blocks = pages.map(([, pageRecords]) => makeBitmapPage(pageRecords));
  const headerSize = 6 + pages.length * 4;
  let offset = headerSize;

  const writer = new Writer();
  writer.ascii(magic);
  writer.u8(1);
  writer.u8(pages.length);
  pages.forEach(([page], index) => {
    writer.u16(page);
    writer.u16(offset);
    offset += blocks[index].length;
  });
  for (const block of blocks) writer.append(block);
  return writer.buffer();
}

function makeMapping() {
  return makePagedMap("ENSM", spec.mapped);
}

function makeNormalization() {
  const rankEntries = [];
  nf.ranks.forEach((codepoints, index) => {
    for (const cp of codepoints) rankEntries.push([cp, index + 1]);
  });
  const rankRanges = contiguousRanges(rankEntries, ([, rank]) => rank);
  const decompPages = groupByPage(nf.decomp);
  const decompBlocks = decompPages.map(([, records]) => makeBitmapPage(records));

  const exclusions = new Set(nf.exclusions);
  const composition = nf.decomp
    .filter(([cp, cps]) => !exclusions.has(cp) && cps.length === 2)
    .map(([cp, [a, b]]) => [a, b, cp])
    .sort((x, y) => x[0] - y[0] || x[1] - y[1]);
  const compGroups = [];
  for (const record of composition) {
    let group = compGroups.at(-1);
    if (!group || group.base !== record[0]) {
      group = { base: record[0], records: [] };
      compGroups.push(group);
    }
    group.records.push(record);
  }
  const compBlocks = compGroups.map(({ records }) => {
    const writer = new Writer();
    for (const [, combining, composed] of records) {
      writer.varuint(combining);
      writer.varuint(composed);
    }
    return writer.buffer();
  });

  const headerSize = 16;
  const rankSize = rankRanges.length * 7;
  const decompDirectoryOffset = headerSize + rankSize;
  const compDirectoryOffset = decompDirectoryOffset + decompPages.length * 4;
  let payloadOffset = compDirectoryOffset + compGroups.length * 5;
  const decompOffsets = [];
  for (const block of decompBlocks) {
    decompOffsets.push(payloadOffset);
    payloadOffset += block.length;
  }
  const compOffsets = [];
  for (const block of compBlocks) {
    compOffsets.push(payloadOffset);
    payloadOffset += block.length;
  }

  const writer = new Writer();
  writer.ascii("ENSN");
  writer.u8(1);
  writer.u16(rankRanges.length);
  writer.u8(decompPages.length);
  writer.u16(compGroups.length);
  writer.u16(decompDirectoryOffset);
  writer.u16(compDirectoryOffset);
  writer.u16(payloadOffset);
  for (const range of rankRanges) {
    writeRange(writer, range);
    writer.u8(range.value);
  }
  decompPages.forEach(([page], index) => {
    writer.u16(page);
    writer.u16(decompOffsets[index]);
  });
  compGroups.forEach((group, index) => {
    writer.u24(group.base);
    writer.u16(compOffsets[index]);
  });
  for (const block of decompBlocks) writer.append(block);
  for (const block of compBlocks) writer.append(block);

  if (writer.length !== payloadOffset) {
    throw new Error(`normalization offset mismatch: ${writer.length} != ${payloadOffset}`);
  }
  return writer.buffer();
}

function emojiGroupData(sequences) {
  const writer = new Writer();
  for (const sequence of sequences) {
    writer.u8(sequence.length);
    for (const cp of sequence.slice(1)) writer.varuint(cp);
  }
  return writer.buffer();
}

function makeEmojiShard(groups) {
  const blocks = groups.map(([, sequences]) => emojiGroupData(sequences));
  let offset = 7 + groups.length * 5;
  const writer = new Writer();
  writer.ascii("ENSE");
  writer.u8(1);
  writer.u16(groups.length);
  groups.forEach(([root], index) => {
    writer.u24(root);
    writer.u16(offset);
    offset += blocks[index].length;
  });
  for (const block of blocks) writer.append(block);
  return writer.buffer();
}

function makeEmoji() {
  const groups = new Map();
  for (const sequence of spec.emoji) {
    if (!groups.has(sequence[0])) groups.set(sequence[0], []);
    groups.get(sequence[0]).push(sequence);
  }
  const sorted = [...groups.entries()].sort((a, b) => a[0] - b[0]);

  let best;
  for (let split = 1; split < sorted.length; split++) {
    const left = makeEmojiShard(sorted.slice(0, split));
    const right = makeEmojiShard(sorted.slice(split));
    const score = Math.max(left.length, right.length);
    if (!best || score < best.score) best = { split, left, right, score };
  }
  if (!best) throw new Error("unable to split emoji data");
  return [best.left, best.right];
}

const files = {
  "core.bin": makeCore(),
  "mapping.bin": makeMapping(),
  "normalization.bin": makeNormalization(),
  "wholes.bin": makeWholes()
};
const [emoji0, emoji1] = makeEmoji();
files["emoji-0.bin"] = emoji0;
files["emoji-1.bin"] = emoji1;

mkdirSync(outputDir, { recursive: true });
const manifest = {
  schema: 1,
  package: "@adraffy/ens-normalize",
  packageVersion: "1.11.1",
  unicode: spec.unicode,
  cldr: spec.cldr,
  specSha256: sha256(specBytes),
  nfSha256: sha256(nfBytes),
  groupCount: GROUP_COUNT,
  maskBytes: MASK_BYTES,
  files: {}
};

for (const [name, bytes] of Object.entries(files)) {
  if (bytes.length > MAX_DATA_SIZE) {
    throw new Error(`${name} is ${bytes.length} bytes (max ${MAX_DATA_SIZE})`);
  }
  writeFileSync(resolve(outputDir, name), bytes);
  manifest.files[name] = {
    bytes: bytes.length,
    sha256: sha256(bytes)
  };
}
writeFileSync(resolve(outputDir, "manifest.json"), `${JSON.stringify(manifest, null, 2)}\n`);

console.table(
  Object.entries(manifest.files).map(([file, value]) => ({
    file,
    bytes: value.bytes,
    sha256: value.sha256
  }))
);
