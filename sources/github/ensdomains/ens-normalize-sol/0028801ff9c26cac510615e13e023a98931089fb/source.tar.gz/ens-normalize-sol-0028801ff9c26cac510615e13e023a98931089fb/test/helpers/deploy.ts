import { readFile } from "node:fs/promises";
import { resolve } from "node:path";

import { network } from "hardhat";
import type { Hex } from "viem";

const DATA_FILES = [
  "core.bin",
  "mapping.bin",
  "normalization.bin",
  "wholes.bin",
  "emoji-0.bin",
  "emoji-1.bin",
] as const;

export async function deployNormalizer() {
  const { viem } = await network.create("hardhatMainnet");
  const stores = [];

  for (const file of DATA_FILES) {
    const bytes = await readFile(resolve("data", file));
    const data = `0x${bytes.toString("hex")}` as Hex;
    stores.push(await viem.deployContract("ENSDataStore", [data]));
  }

  const normalizer = await viem.deployContract("ENSNormalizer", [
    stores[0].address,
    stores[1].address,
    stores[2].address,
    stores[3].address,
    stores[4].address,
    stores[5].address,
  ]);

  return { viem, normalizer, stores };
}
