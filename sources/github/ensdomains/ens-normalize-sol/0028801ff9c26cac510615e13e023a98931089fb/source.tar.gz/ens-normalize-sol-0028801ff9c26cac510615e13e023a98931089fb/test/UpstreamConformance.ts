import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import { describe, it } from "node:test";

import { deployNormalizer } from "./helpers/deploy.js";

interface UpstreamVector {
  name: string;
  norm?: string;
  error?: boolean;
  comment?: string;
}

describe("upstream ENSIP-15 conformance", () => {
  it("passes every @adraffy/ens-normalize 1.11.1 validation vector", async () => {
    const fixture = await deployNormalizer();
    const parsed = JSON.parse(
      await readFile("test/fixtures/ensip15-tests.json", "utf8"),
    ) as UpstreamVector[];
    const requestedLimit = Number(process.env.ENS_UPSTREAM_LIMIT ?? 0);
    const vectors = parsed.slice(
      1,
      requestedLimit > 0 ? requestedLimit + 1 : undefined,
    );

    const batches: UpstreamVector[][] = [];
    let batch: UpstreamVector[] = [];
    let batchBytes = 0;
    for (const vector of vectors) {
      const bytes = Buffer.byteLength(vector.name);
      if (
        batch.length > 0 &&
        (batch.length >= 64 || batchBytes + bytes > 16_384)
      ) {
        batches.push(batch);
        batch = [];
        batchBytes = 0;
      }
      batch.push(vector);
      batchBytes += bytes;
    }
    if (batch.length > 0) batches.push(batch);

    const failures: string[] = [];
    let offset = 0;
    for (const current of batches) {
      const [valid, normalized] =
        (await fixture.normalizer.read.normalizeBatch([
          current.map((vector) => vector.name),
        ])) as readonly [readonly boolean[], readonly string[]];

      current.forEach((vector, index) => {
        const expectedValid = vector.error !== true;
        const expectedNormalized = expectedValid
          ? (vector.norm ?? vector.name)
          : "";
        if (
          valid[index] !== expectedValid ||
          normalized[index] !== expectedNormalized
        ) {
          failures.push(
            JSON.stringify({
              index: offset + index + 1,
              name: vector.name,
              comment: vector.comment,
              expectedValid,
              actualValid: valid[index],
              expectedNormalized,
              actualNormalized: normalized[index],
            }),
          );
        }
      });
      offset += current.length;
      if (failures.length >= 20) break;
    }

    assert.deepEqual(failures, []);
    assert.equal(offset, vectors.length);
  });
});
