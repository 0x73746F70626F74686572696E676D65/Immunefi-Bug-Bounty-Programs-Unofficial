import assert from "node:assert/strict";
import { before, describe, it } from "node:test";
import {
  concatHex,
  decodeFunctionResult,
  numberToHex,
  padHex,
  toFunctionSelector,
  type Hex,
} from "viem";

import { deployNormalizer } from "./helpers/deploy.js";

describe("ENSNormalizer", { concurrency: 1 }, () => {
  let fixture: Awaited<ReturnType<typeof deployNormalizer>>;

  before(async () => {
    fixture = await deployNormalizer();
  });

  it("matches representative upstream normalization behavior", async () => {
    const cases = [
      ["", ""],
      ["ETH", "eth"],
      ["RaFFY🚴‍♂️.eTh", "raffy🚴‍♂.eth"],
      ["1⃣2⃣.eth", "1⃣2⃣.eth"],
      ["E︎̃", "ẽ"],
      ["_＄Ａ", "_$a"],
      ["𓆏🐸", "𓆏🐸"],
      ["👨🏻‍💻.ETH", "👨🏻‍💻.eth"],
      ["a™️", "atm"],
      ["가각", "가각"],
    ] as const;

    for (const [input, expected] of cases) {
      assert.equal(await fixture.normalizer.read.normalize([input]), expected);
    }
  });

  it("rejects representative invalid names", async () => {
    const invalid = [
      " ",
      ".",
      ".eth",
      "eth.",
      "xn--",
      "abc_",
      "\u0300",
      "nı̇ck",
      "a・・a",
      "0х",
      "\u0300💩",
    ];

    for (const name of invalid) {
      await assert.rejects(fixture.normalizer.read.normalize([name]));
      const [valid, normalized] = (await fixture.normalizer.read.tryNormalize([
        name,
      ])) as readonly [boolean, string];
      assert.equal(valid, false);
      assert.equal(normalized, "");
    }
  });

  it("normalizes batches without letting invalid entries abort the batch", async () => {
    const [valid, normalized] = (await fixture.normalizer.read.normalizeBatch([
      ["ETH", "xn--", "💩"],
    ])) as readonly [readonly boolean[], readonly string[]];
    assert.deepEqual(valid, [true, false, true]);
    assert.deepEqual(normalized, ["eth", "", "💩"]);
  });

  it("rejects every malformed UTF-8 sequence class", async () => {
    const malformed = [
      [0xc2],
      [0xc2, 0x20],
      [0xe0, 0xa0],
      [0xe1, 0x20, 0x80],
      [0xe0, 0x80, 0x80],
      [0xf0, 0x90, 0x80],
      [0xf1, 0x80, 0x20, 0x80],
      [0xf0, 0x80, 0x80, 0x80],
      [0x80],
    ];
    const publicClient = await fixture.viem.getPublicClient();
    const selector = toFunctionSelector("tryNormalize(string)");

    for (const bytes of malformed) {
      const payload = Buffer.from(bytes).toString("hex");
      const paddedPayload = payload.padEnd(Math.ceil(bytes.length / 32) * 64, "0");
      const data = concatHex([
        selector,
        padHex(numberToHex(32), { size: 32 }),
        padHex(numberToHex(bytes.length), { size: 32 }),
        `0x${paddedPayload}` as Hex,
      ]);
      const response = await publicClient.call({
        to: fixture.normalizer.address,
        data,
      });
      const [valid, normalized] = decodeFunctionResult({
        abi: fixture.normalizer.abi,
        functionName: "tryNormalize",
        data: response.data!,
      }) as readonly [boolean, string];
      assert.equal(valid, false);
      assert.equal(normalized, "");
    }
  });

  it("covers data deployment and defensive data-source failures", async () => {
    await assert.rejects(fixture.viem.deployContract("ENSDataStore", ["0x"]));
    const oversized = `0x${"00".repeat(24_576)}` as Hex;
    await assert.rejects(
      fixture.viem.deployContract("ENSDataStore", [oversized]),
    );

    await assert.rejects(
      fixture.viem.deployContract("ENSNormalizer", [
        "0x0000000000000000000000000000000000000000",
        fixture.stores[1].address,
        fixture.stores[2].address,
        fixture.stores[3].address,
        fixture.stores[4].address,
        fixture.stores[5].address,
      ]),
    );

    const harness = await fixture.viem.deployContract("ENSTestHarness");
    await assert.rejects(
      harness.read.readCode([
        "0x0000000000000000000000000000000000000000",
      ]),
    );
    assert.equal(
      await harness.read.nfcEmpty([fixture.stores[2].address]),
      0n,
    );
  });
});
