# Pinned upstream inputs

These files pin the implementation to `@adraffy/ens-normalize` **1.11.1**:

- `spec.json` — ENSIP-15 data derived for Unicode 17.0.0 / CLDR 47.
- `nf.json` — Unicode 17.0.0 canonical normalization data.
- `LICENSE.adraffy` — the upstream MIT license.

`scripts/generate-data.mjs` deterministically compiles the JSON into the six
bytecode payloads under `data/`. Their sizes and SHA-256 hashes are recorded in
`data/manifest.json`.

The upstream validation corpus is vendored separately at
`test/fixtures/ensip15-tests.json`.
