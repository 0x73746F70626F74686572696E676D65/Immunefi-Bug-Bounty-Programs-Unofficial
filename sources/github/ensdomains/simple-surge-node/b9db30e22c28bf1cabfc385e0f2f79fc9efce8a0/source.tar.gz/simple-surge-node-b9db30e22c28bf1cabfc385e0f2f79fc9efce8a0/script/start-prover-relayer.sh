#!/bin/sh

set -eou pipefail

if [ "$ENABLE_PROVER" = "true" ]; then
    ARGS="--verbosity 4
        --l1.ws ${L1_ENDPOINT_WS}
        --l2.ws ws://l2-nethermind-execution-client:${L2_WS_PORT}
        --l2.http http://l2-nethermind-execution-client:${L2_HTTP_PORT}
        --taikoInbox ${TAIKO_INBOX}
        --taikoAnchor ${TAIKO_ANCHOR}
        --l1.proverPrivKey ${L1_PROVER_PRIVATE_KEY}
        --raiko.host.sgx ${SGX_RAIKO_HOST}
        --prover.sgx.batchSize ${SGX_BATCH_SIZE}
        --prover.zkvm.batchSize ${ZKVM_BATCH_SIZE}
        --metrics true
        --metrics.port 6062"

    if [ -z "$SGX_RAIKO_HOST" ]; then
        echo "Error: SGX_RAIKO_HOST must be non-empty"
        exit 1
    fi

    if [ -z "$L1_ENDPOINT_WS" ]; then
        echo "Error: L1_ENDPOINT_WS must be non-empty"
        exit 1
    fi

    if [ -z "$L1_ENDPOINT_HTTP" ]; then
        echo "Error: L1_ENDPOINT_HTTP must be non-empty"
        exit 1
    fi

    if [ -z "$L1_PROVER_PRIVATE_KEY" ]; then
        echo "Error: L1_PROVER_PRIVATE_KEY must be non-empty"
        exit 1
    fi
    
    if [ -n "$RAIKO_HOST_ZKVM" ]; then
        ARGS="${ARGS} --raiko.host.zkvm ${RAIKO_HOST_ZKVM}"
    fi

    if [ -n "$RAIKO_REQUEST_TIMEOUT" ]; then
        ARGS="${ARGS} --raiko.requestTimeout ${RAIKO_REQUEST_TIMEOUT}"
    fi

    if [ -n "$PROVER_SET" ]; then
        ARGS="${ARGS} --proverSet ${PROVER_SET}"
    fi

    if [ "$PROVE_UNASSIGNED_BLOCKS" = "true" ]; then
        ARGS="${ARGS} --prover.proveUnassignedBlocks"
    fi

    if [ -n "$FORCE_BATCH_PROVING_INTERVAL" ]; then
        ARGS="${ARGS} --prover.forceBatchProvingInterval ${FORCE_BATCH_PROVING_INTERVAL}"
    fi

    if [ -n "$STARTING_BATCH_ID" ]; then
        ARGS="${ARGS} --prover.startingBatchId ${STARTING_BATCH_ID}"
    fi

    if [ -n "$LOCAL_PROPOSER_ADDRESSES" ]; then
        ARGS="${ARGS} --prover.localProposerAddresses ${LOCAL_PROPOSER_ADDRESSES}"
    fi

    if [ -n "$BLOCK_CONFIRMATIONS" ]; then
        ARGS="${ARGS} --prover.blockConfirmations ${BLOCK_CONFIRMATIONS}"
    fi

    if [ -n "$SURGE_PROPOSER_WRAPPER" ]; then
        ARGS="${ARGS} --surgeProposerWrapper ${SURGE_PROPOSER_WRAPPER}"
    fi

    # TXMGR Settings
    if [ -n "$TX_FEE_LIMIT_MULTIPLIER" ]; then
        ARGS="${ARGS} --tx.feeLimitMultiplier ${TX_FEE_LIMIT_MULTIPLIER}"
    fi

    if [ -n "$TX_FEE_LIMIT_THRESHOLD" ]; then
        ARGS="${ARGS} --tx.feeLimitThreshold ${TX_FEE_LIMIT_THRESHOLD}"
    fi

    if [ -n "$TX_GAS_LIMIT" ]; then
        ARGS="${ARGS} --tx.gasLimit ${TX_GAS_LIMIT}"
    fi

    if [ -n "$TX_MIN_BASE_FEE" ]; then
        ARGS="${ARGS} --tx.minBaseFee ${TX_MIN_BASE_FEE}"
    fi

    if [ -n "$TX_MIN_TIP_CAP" ]; then
        ARGS="${ARGS} --tx.minTipCap ${TX_MIN_TIP_CAP}"
    fi

    if [ -n "$TX_NOT_IN_MEMPOOL_TIMEOUT" ]; then
        ARGS="${ARGS} --tx.notInMempoolTimeout ${TX_NOT_IN_MEMPOOL_TIMEOUT}"
    fi

    if [ -n "$TX_NUM_CONFIRMATIONS" ]; then
        ARGS="${ARGS} --tx.numConfirmations ${TX_NUM_CONFIRMATIONS}"
    fi

    if [ -n "$TX_RECEIPT_QUERY_INTERVAL" ]; then
        ARGS="${ARGS} --tx.receiptQueryInterval ${TX_RECEIPT_QUERY_INTERVAL}"
    fi

    if [ -n "$TX_RESUBMISSION_TIMEOUT" ]; then
        ARGS="${ARGS} --tx.resubmissionTimeout ${TX_RESUBMISSION_TIMEOUT}"
    fi

    if [ -n "$TX_SAFE_ABORT_NONCE_TOO_LOW_COUNT" ]; then
        ARGS="${ARGS} --tx.safeAbortNonceTooLowCount ${TX_SAFE_ABORT_NONCE_TOO_LOW_COUNT}"
    fi

    if [ -n "$TX_SEND_TIMEOUT" ]; then
        ARGS="${ARGS} --tx.sendTimeout ${TX_SEND_TIMEOUT}"
    fi

    if [ -n "$PROOF_POLLING_INTERVAL" ]; then
        ARGS="${ARGS} --prover.proofPollingInterval ${PROOF_POLLING_INTERVAL}"
    fi

    echo "Starting Prover Relayer with args: ${ARGS}"
    exec taiko-client prover ${ARGS}
else
    echo "PROVER IS DISABLED"
    sleep infinity
fi
