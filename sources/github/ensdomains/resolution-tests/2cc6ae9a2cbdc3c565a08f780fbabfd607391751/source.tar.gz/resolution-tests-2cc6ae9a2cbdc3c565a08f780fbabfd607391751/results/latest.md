# ENS Resolution Test Results

Generated: 2026-09-24T03:16:52.586Z

## Feature Support

| Test Case | go-ens-v4 | thirdweb-v5 | go-ens-v3 | alloy | ethers-v5 | viem-v3 | viem-v2 | ensjs-v4 | nethereum | ensjs-v3 | ethers-v6 | eth-zig | web3py |
|-----------|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|
| universal-resolver | ✅ | ✅ | ❌ | ✅ | ❌ | ✅ | ✅ | ✅ | ❌ | ❌ | ✅ | ✅ | ✅ |
| forward-base-onchain | ✅ | - | ✅ | ✅ | ❌ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | - | ✅ |
| forward-wildcard | ✅ | ✅ | ❌ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| forward-eth-offchain | ✅ | ❌ | ❌ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ❌ | ✅ |
| forward-text-onchain | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| forward-text-offchain | ✅ | ❌ | ❌ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ❌ | ✅ |
| forward-contenthash | ✅ | - | ✅ | - | ✅ | - | - | ✅ | ✅ | ✅ | ✅ | ✅ | - |
| reverse-universal-resolver | ✅ | ✅ | ❌ | ✅ | ❌ | ✅ | ✅ | ✅ | ❌ | ❌ | ✅ | ✅ | ✅ |
| reverse-eth | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| reverse-l2 | ❌ | - | - | - | - | ❌ | ❌ | ❌ | - | - | - | - | - |
| forward-dns-offchain | ✅ | ❌ | ❌ | ✅ | ✅ | ✅ | ✅ | ✅ | ❌ | ✅ | ✅ | ❌ | ❌ |
| **TOTAL** | **10/11** | **5/11** | **4/11** | **9/11** | **7/11** | **9/11** | **9/11** | **10/11** | **7/11** | **8/11** | **10/11** | **6/11** | **8/11** |

### Legend

- ✅ Pass
- ❌ Fail
- `-` Not tested
- ⚠️ Run failed; case results are not scored