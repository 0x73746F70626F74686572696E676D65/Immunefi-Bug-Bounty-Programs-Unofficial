contract OPKeyStore {

}
