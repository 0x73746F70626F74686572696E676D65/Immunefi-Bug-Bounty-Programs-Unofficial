import { Button } from './ui/Button'
import { H2 } from './ui/Typography'

const navigation = [
  {
    title: 'Get Started',
    links: [
      ['Protocol Docs', '/learn/protocol'],
      ['Resolution', '/resolution'],
      ['Tools and Libraries', '/web/libraries'],
      ['Building with AI', '/building-with-ai'],
      ['ENSIPs', '/ensip'],
    ],
  },
  {
    title: 'Use ENS',
    links: [
      ['Address Lookup', '/web/resolution'],
      ['Text Records', '/web/records'],
      ['Avatars', '/web/avatars'],
      ['Primary Names', '/web/reverse'],
      ['List Names', '/web/enumerate'],
    ],
  },
  {
    title: 'Registries',
    links: [
      ['ENS Registrar', '/registry/ens'],
      ['ETH Registrar', '/registry/eth'],
      ['DNS Registrar', '/registry/dns'],
      ['Reverse Registrar', '/registry/reverse'],
    ],
  },
  {
    title: 'Resolvers',
    links: [
      ['Public Resolver', '/resolvers/public'],
      ['Writing a Resolver', '/resolvers/writing'],
      ['Interacting with a Resolver', '/resolvers/interacting'],
      ['Cross Chain Resolvers', '/resolvers/ccip-read'],
      ['Interface Reference', '/resolvers/interfaces'],
    ],
  },
  {
    title: 'Governance',
    links: [
      ['Welcome', '/dao'],
      ['Constitution', '/dao/constitution'],
      ['Foundation', '/dao/foundation'],
      ['Token & Airdrop', '/dao/token'],
    ],
  },
  {
    title: 'Extra',
    links: [
      ['Naming Smart Contracts', '/web/naming-contracts'],
      // ["Issuing Subdomains", "/web/subdomains"],
      ['Name Wrapper', '/wrapper/overview'],
      ['Subgraph', '/web/subgraph'],
      ['Sign In With Ethereum (SIWE)', '/web/siwe'],
      ['ENSv2 Readiness', '/web/ensv2-readiness'],
    ],
  },
]

const videos = [
  {
    title: 'ETHGlobal Brussels Workshop',
    href: 'https://www.youtube.com/watch?v=TcMUvPPW2oI',
    thumbnail: '/img/thumbnails/ethglobal-workshop.jpg',
  },
  {
    title: 'ENS Evolution Beyond ETH',
    href: 'https://www.youtube.com/watch?v=Tp0r5t8BGt8',
    thumbnail: '/img/thumbnails/frensday-keynote.jpg',
  },
]

export function HomePage() {
  return (
    <>
      <div className="bg-background-secondary border-grey-light border-t px-4 py-16">
        <div className="mx-auto flex max-w-4xl flex-col gap-4">
          <h1 className="text-3xl font-semibold sm:text-4xl">
            ENS Documentation
          </h1>
          <p>Build applications with decentralized self-sovereign identity.</p>
          <div className="flex flex-col gap-3 sm:flex-row">
            <Button href="/web/quickstart">Get Started</Button>
            <Button variant="outline" href="/building-with-ai">
              Build with AI
            </Button>
            <Button variant="outline" href="/learn/protocol">
              Learn about ENS
            </Button>
          </div>
        </div>
      </div>

      <div className="mx-auto max-w-4xl px-4 pt-6">
        <div className="border-blue rounded-lg border p-4 lg:-mx-4">
          <div className="grid grid-cols-2 gap-6 lg:grid-cols-3">
            <div className="flex items-center gap-3">
              <img
                src="/img/ensv2-logo-offblack.svg"
                alt="ENSv2"
                className="h-7 dark:invert"
              />
              <span className="font-medium">Live on Sepolia</span>
            </div>
            <div>
              <div>
                <a className="vocs_Anchor !no-underline" href="/ensv2/overview">
                  Overview
                </a>
              </div>
              <div>
                <a
                  className="vocs_Anchor !no-underline"
                  href="/ensv2/tutorial-app-developers"
                >
                  For App Developers
                </a>
              </div>
            </div>
            <div>
              <div>
                <a
                  className="vocs_Anchor !no-underline"
                  href="/learn/deployments#sepolia-ensv2"
                >
                  Deployments
                </a>
              </div>
              <div>
                <a
                  className="vocs_Anchor !no-underline"
                  href="/web/ensv2-readiness"
                >
                  Readiness
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="mx-auto grid max-w-4xl grid-cols-2 gap-6 px-4 pt-6 lg:grid-cols-3 lg:gap-y-10">
        {navigation.map((column) => (
          <div key={column.title}>
            <div className="font-bold">{column.title}</div>
            {column.links.map(([title, href]) => (
              <div key={title} className="flex items-center gap-3">
                <a className="vocs_Anchor !no-underline" href={href}>
                  {title}
                </a>
              </div>
            ))}
          </div>
        ))}
      </div>

      <div className="mx-auto flex max-w-4xl flex-col px-4">
        <H2>Videos</H2>
        <div className="grid grid-cols-2 gap-6 lg:gap-y-10">
          {videos.map((video) => (
            <a
              key={video.title}
              href={video.href}
              target="_blank"
              className="border-grey-light overflow-hidden rounded-lg border"
            >
              <img src={video.thumbnail} alt={video.title} className="w-full" />
              <span className="block p-2 leading-6 font-medium">
                {video.title}
              </span>
            </a>
          ))}
        </div>
      </div>
    </>
  )
}
