/**
 * Generate pre-compiled WASM trampoline modules for Cloudflare Workers compatibility.
 *
 * Each trampoline is a minimal WASM module that imports a function `e.f` with a
 * specific signature and re-exports it as `f`. This lets us wrap JS callbacks as
 * WASM-typed functions via instantiation (allowed in Workers) instead of compilation
 * from bytes (blocked in Workers).
 */
const fs = require('fs');
const path = require('path');

// All unique WASM-level signatures used by hbjs.js addFunction() calls.
// In the sig strings: v=void, i=i32, f=f32. First char is return type, rest are params.
// The 'p' type in hbjs.js maps to i32 at the WASM level.
const SIGNATURES = {
  'vi':             { params: [0x7F], results: [] },
  'viiiffi':        { params: [0x7F, 0x7F, 0x7F, 0x7D, 0x7D, 0x7F], results: [] },
  'viiiffffffi':    { params: [0x7F, 0x7F, 0x7F, 0x7D, 0x7D, 0x7D, 0x7D, 0x7D, 0x7D, 0x7F], results: [] },
  'viiiffffi':      { params: [0x7F, 0x7F, 0x7F, 0x7D, 0x7D, 0x7D, 0x7D, 0x7F], results: [] },
  'viiii':          { params: [0x7F, 0x7F, 0x7F, 0x7F], results: [] },
  'iiiii':          { params: [0x7F, 0x7F, 0x7F, 0x7F], results: [0x7F] },
  'iiiiii':         { params: [0x7F, 0x7F, 0x7F, 0x7F, 0x7F], results: [0x7F] },
  'iiiiiii':        { params: [0x7F, 0x7F, 0x7F, 0x7F, 0x7F, 0x7F], results: [0x7F] },
};

// WASM binary encoding helpers
function encodeString(s) {
  const bytes = [...s].map(c => c.charCodeAt(0));
  return [bytes.length, ...bytes];
}

function encodeSection(id, contents) {
  return [id, contents.length, ...contents];
}

function buildTrampoline(params, results) {
  // Type section: 1 function type
  const typeSectionContents = [
    0x01,                                   // count: 1 type
    0x60,                                   // func type marker
    params.length, ...params,               // param count + param types
    results.length, ...results              // result count + result types
  ];
  const typeSection = encodeSection(0x01, typeSectionContents);

  // Import section: import e.f as function type 0
  const importSectionContents = [
    0x01,                                   // count: 1 import
    ...encodeString('e'),                   // module name
    ...encodeString('f'),                   // field name
    0x00,                                   // import kind: function
    0x00                                    // type index: 0
  ];
  const importSection = encodeSection(0x02, importSectionContents);

  // Export section: export "f" as function 0
  const exportSectionContents = [
    0x01,                                   // count: 1 export
    ...encodeString('f'),                   // export name
    0x00,                                   // export kind: function
    0x00                                    // function index: 0
  ];
  const exportSection = encodeSection(0x07, exportSectionContents);

  return Uint8Array.from([
    0x00, 0x61, 0x73, 0x6D,  // magic: \0asm
    0x01, 0x00, 0x00, 0x00,  // version: 1
    ...typeSection,
    ...importSection,
    ...exportSection
  ]);
}

// Generate
const outDir = path.join(__dirname, '..', 'trampolines');
fs.mkdirSync(outDir, { recursive: true });

for (const [sig, { params, results }] of Object.entries(SIGNATURES)) {
  const wasm = buildTrampoline(params, results);
  const outPath = path.join(outDir, `trampoline-${sig}.wasm`);
  fs.writeFileSync(outPath, wasm);
  // Validate
  const mod = new WebAssembly.Module(wasm);
  const inst = new WebAssembly.Instance(mod, { e: { f: () => 0 } });
  console.log(`  ${sig}: ${wasm.length} bytes — OK`);
}

console.log(`Generated ${Object.keys(SIGNATURES).length} trampolines in ${outDir}`);
