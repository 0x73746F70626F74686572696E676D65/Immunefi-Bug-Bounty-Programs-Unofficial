#!/usr/bin/env python3
"""
Verify PKCS#1 v1.5 padding of RSASHA256 signatures in DNSSEC proof chains.

For each RSASHA256 level:
1. Extract the signing DNSKEY (RSA public key: n, e)
2. Extract the signature bytes from the sig field
3. Compute sig^e mod n (raw RSA verification)
4. Check the PKCS#1 v1.5 padding structure:
   00 01 [FF...FF] 00 [DigestInfo] [SHA-256 hash]
5. Flag any deviations (extra bytes, short padding, wrong DigestInfo)
"""

import csv

ALGORITHMS = {
    5: 'RSASHA1', 7: 'RSASHA1-NSEC3-SHA1', 8: 'RSASHA256',
    10: 'RSASHA512', 13: 'ECDSAP256SHA256', 14: 'ECDSAP384SHA384',
}

TYPES = {43: 'DS', 48: 'DNSKEY', 16: 'TXT'}

# PKCS#1 v1.5 DigestInfo prefix for SHA-256
# SEQUENCE { SEQUENCE { OID sha256, NULL }, OCTET STRING(32) }
SHA256_DIGEST_INFO = bytes.fromhex('3031300d060960864801650304020105000420')

# DigestInfo prefix for SHA-1 (for RSASHA1)
SHA1_DIGEST_INFO = bytes.fromhex('3021300906052b0e03021a05000414')


def parse_dns_name(data, offset):
    """Parse DNS wire format name."""
    labels = []
    pos = offset
    while pos < len(data):
        label_len = data[pos]
        if label_len == 0:
            pos += 1
            break
        elif (label_len & 0xc0) == 0xc0:
            pos += 2
            break
        else:
            labels.append(data[pos+1:pos+1+label_len].decode('ascii', errors='replace'))
            pos += 1 + label_len
    return '.'.join(labels) if labels else '.', pos - offset


def dns_name_length(data, offset):
    """Get byte length of a DNS wire format name."""
    pos = offset
    while pos < len(data):
        label_len = data[pos]
        if label_len == 0:
            return pos - offset + 1
        elif (label_len & 0xc0) == 0xc0:
            return pos - offset + 2
        else:
            pos += 1 + label_len
    return pos - offset


def compute_key_tag(rdata):
    """Compute DNSKEY key tag per RFC 4034 Appendix B."""
    ac = 0
    for i in range(len(rdata)):
        if i & 1:
            ac += rdata[i]
        else:
            ac += rdata[i] << 8
    ac += (ac >> 16) & 0xFFFF
    return ac & 0xFFFF


def parse_rsa_pubkey(dnskey_rdata):
    """Extract RSA (e, n) from DNSKEY RDATA.

    DNSKEY RDATA: flags(2) + protocol(1) + algorithm(1) + public_key
    Public key: [exp_length_prefix] + exponent + modulus
    """
    if len(dnskey_rdata) < 5:
        return None, None, "DNSKEY too short"

    pubkey = dnskey_rdata[4:]
    if len(pubkey) < 3:
        return None, None, "Public key field too short"

    first_byte = pubkey[0]
    if first_byte == 0:
        if len(pubkey) < 3:
            return None, None, "Missing exponent length"
        exp_len = int.from_bytes(pubkey[1:3], 'big')
        exp_start = 3
    else:
        exp_len = first_byte
        exp_start = 1

    if exp_start + exp_len > len(pubkey):
        return None, None, "Exponent extends beyond key data"

    e = int.from_bytes(pubkey[exp_start:exp_start+exp_len], 'big')
    n_bytes = pubkey[exp_start+exp_len:]
    n = int.from_bytes(n_bytes, 'big')
    key_size = len(n_bytes)

    return e, n, key_size


def parse_rrset_field(rrset_data):
    """Parse rrset field: RRSIG header + signer name + RR records."""
    if len(rrset_data) < 18:
        return None, []

    rrsig = {
        'type_covered': int.from_bytes(rrset_data[0:2], 'big'),
        'algorithm': rrset_data[2],
        'labels': rrset_data[3],
        'ttl': int.from_bytes(rrset_data[4:8], 'big'),
        'expiration': int.from_bytes(rrset_data[8:12], 'big'),
        'inception': int.from_bytes(rrset_data[12:16], 'big'),
        'keytag': int.from_bytes(rrset_data[16:18], 'big'),
    }

    signer_name, signer_len = parse_dns_name(rrset_data, 18)
    rrsig['signer_name'] = signer_name
    rrsig['signer_name_len'] = signer_len

    # Parse RR records after signer name
    pos = 18 + signer_len
    records = []

    while pos < len(rrset_data):
        name_len = dns_name_length(rrset_data, pos)
        if pos + name_len > len(rrset_data):
            break
        rr_name, _ = parse_dns_name(rrset_data, pos)
        pos += name_len

        if pos + 10 > len(rrset_data):
            break

        rr_type = int.from_bytes(rrset_data[pos:pos+2], 'big')
        rr_class = int.from_bytes(rrset_data[pos+2:pos+4], 'big')
        rr_ttl = int.from_bytes(rrset_data[pos+4:pos+8], 'big')
        rdlength = int.from_bytes(rrset_data[pos+8:pos+10], 'big')
        pos += 10

        if pos + rdlength > len(rrset_data):
            break

        rdata = rrset_data[pos:pos+rdlength]
        pos += rdlength

        record = {
            'name': rr_name,
            'type': rr_type,
            'rdata': rdata,
        }

        if rr_type == 48 and len(rdata) >= 4:  # DNSKEY
            flags = int.from_bytes(rdata[0:2], 'big')
            record['dnskey'] = {
                'flags': flags,
                'algorithm': rdata[3],
                'key_tag': compute_key_tag(rdata),
                'is_ksk': flags == 257,
                'is_zsk': flags == 256,
            }

        records.append(record)

    return rrsig, records


def parse_calldata(tx_data_hex):
    """Parse calldata to extract RRSetWithSignature array."""
    data = bytes.fromhex(tx_data_hex[2:] if tx_data_hex.startswith('0x') else tx_data_hex)
    selector = data[:4].hex()
    params = data[4:]

    input_offset = int.from_bytes(params[32:64], 'big')
    array_length = int.from_bytes(params[input_offset:input_offset+32], 'big')
    data_area_start = input_offset + 32

    element_offsets = []
    for i in range(array_length):
        off = int.from_bytes(params[data_area_start + i*32:data_area_start + (i+1)*32], 'big')
        element_offsets.append(off)

    rrsets = []
    for elem_off in element_offsets:
        elem_start = data_area_start + elem_off
        rrset_off = int.from_bytes(params[elem_start:elem_start+32], 'big')
        sig_off = int.from_bytes(params[elem_start+32:elem_start+64], 'big')

        rrset_abs = elem_start + rrset_off
        rrset_len = int.from_bytes(params[rrset_abs:rrset_abs+32], 'big')
        rrset_data = params[rrset_abs+32:rrset_abs+32+rrset_len]

        sig_abs = elem_start + sig_off
        sig_len = int.from_bytes(params[sig_abs:sig_abs+32], 'big')
        sig_data = params[sig_abs+32:sig_abs+32+sig_len]

        rrsets.append({'rrset': rrset_data, 'sig': sig_data})

    return selector, rrsets


def check_pkcs1_v15(padded_msg, key_size, algorithm):
    """Check PKCS#1 v1.5 padding structure.

    Returns dict with validation results.
    """
    result = {
        'valid': True,
        'issues': [],
        'ff_count': 0,
        'has_extra_bytes': False,
        'exponent': None,
    }

    if len(padded_msg) != key_size:
        result['issues'].append(f"Length {len(padded_msg)} != key_size {key_size}")
        result['valid'] = False

    # Check 00 01 prefix
    if padded_msg[0] != 0x00:
        result['issues'].append(f"Byte 0: 0x{padded_msg[0]:02x} (expected 0x00)")
        result['valid'] = False
    if padded_msg[1] != 0x01:
        result['issues'].append(f"Byte 1: 0x{padded_msg[1]:02x} (expected 0x01)")
        result['valid'] = False

    # Count FF padding bytes
    pos = 2
    while pos < len(padded_msg) and padded_msg[pos] == 0xFF:
        pos += 1
    ff_count = pos - 2
    result['ff_count'] = ff_count

    if ff_count < 8:
        result['issues'].append(f"Only {ff_count} FF bytes (RFC requires >= 8)")
        result['valid'] = False

    # Check 00 separator
    if pos >= len(padded_msg):
        result['issues'].append("No 0x00 separator found")
        result['valid'] = False
        return result

    if padded_msg[pos] != 0x00:
        result['issues'].append(f"Expected 0x00 at offset {pos}, got 0x{padded_msg[pos]:02x}")
        result['valid'] = False
        return result

    pos += 1  # skip 00 separator

    # Check DigestInfo
    remaining = padded_msg[pos:]

    if algorithm == 8:  # RSASHA256
        digest_info = SHA256_DIGEST_INFO
        hash_len = 32
    elif algorithm in (5, 7):  # RSASHA1
        digest_info = SHA1_DIGEST_INFO
        hash_len = 20
    else:
        result['issues'].append(f"Unknown algorithm {algorithm}")
        return result

    if not remaining[:len(digest_info)] == digest_info:
        result['issues'].append(f"DigestInfo mismatch")
        result['issues'].append(f"  Got:      {remaining[:len(digest_info)].hex()}")
        result['issues'].append(f"  Expected: {digest_info.hex()}")
        result['valid'] = False
        return result

    hash_value = remaining[len(digest_info):]

    if len(hash_value) != hash_len:
        result['issues'].append(
            f"Hash length {len(hash_value)} != expected {hash_len}"
        )
        result['valid'] = False
        if len(hash_value) > hash_len:
            extra = len(hash_value) - hash_len
            result['has_extra_bytes'] = True
            result['issues'].append(
                f"*** {extra} EXTRA BYTES AFTER HASH "
                f"(Bleichenbacher-style forgery indicator!) ***"
            )
            result['issues'].append(
                f"  Extra bytes: {hash_value[hash_len:].hex()}"
            )

    # Verify total fills the key exactly
    expected_len = 2 + ff_count + 1 + len(digest_info) + hash_len
    if expected_len != key_size:
        result['issues'].append(
            f"Structure size {expected_len} != key_size {key_size} "
            f"(padding should fill exactly)"
        )

    result['hash_hex'] = hash_value[:hash_len].hex()
    return result


def main():
    csv_path = 'data/insecure_onchain_combined.csv'

    with open(csv_path) as f:
        reader = csv.DictReader(f)
        rows = list(reader)

    print(f"Checking PKCS#1 v1.5 padding for {len(rows)} transactions...\n")
    print("=" * 80)

    total_sigs_checked = 0
    total_issues = 0
    padding_results = []

    for row in rows:
        name = row['name']
        tx_hash = row['tx_hash']
        tx_data = row.get('tx_data', '')

        if not tx_data or len(tx_data) < 10:
            continue

        try:
            selector, rrsets = parse_calldata(tx_data)

            # First pass: collect all DNSKEY records by (zone_name, key_tag)
            dnskey_lookup = {}  # (zone, key_tag) -> dnskey_rdata

            parsed_levels = []
            for i, rrset_entry in enumerate(rrsets):
                rrsig, records = parse_rrset_field(rrset_entry['rrset'])
                parsed_levels.append((rrsig, records, rrset_entry['sig']))

                for rec in records:
                    if rec['type'] == 48 and 'dnskey' in rec:
                        zone = rec['name']
                        tag = rec['dnskey']['key_tag']
                        dnskey_lookup[(zone, tag)] = rec['rdata']

            print(f"\n{name} (tx: {tx_hash[:20]}...)")
            print("-" * 60)

            # Second pass: verify each RSASHA256 signature
            for i, (rrsig, records, sig_data) in enumerate(parsed_levels):
                if not rrsig:
                    continue

                algo = rrsig['algorithm']
                if algo not in (5, 7, 8):  # Only check RSA algorithms
                    continue

                type_name = TYPES.get(rrsig['type_covered'], f"TYPE{rrsig['type_covered']}")
                algo_name = ALGORITHMS.get(algo, f"ALG{algo}")

                # Find the signing DNSKEY
                signer_zone = rrsig['signer_name']
                keytag = rrsig['keytag']
                lookup_key = (signer_zone, keytag)

                if lookup_key not in dnskey_lookup:
                    print(f"  Level {i}: {algo_name} RRSIG for {type_name} "
                          f"by {signer_zone} (tag={keytag})")
                    print(f"    SKIP: Signing DNSKEY not found in proof chain")
                    continue

                dnskey_rdata = dnskey_lookup[lookup_key]
                e, n, key_size = parse_rsa_pubkey(dnskey_rdata)

                if e is None:
                    print(f"  Level {i}: Could not parse RSA key")
                    continue

                print(f"  Level {i}: {algo_name} RRSIG for {type_name} "
                      f"by {signer_zone} (tag={keytag})")
                print(f"    Key: e={e} (0x{e:x}), modulus={key_size*8} bits")

                # Check exponent
                if e == 3:
                    print(f"    *** WARNING: e=3 (vulnerable to Bleichenbacher e=3 attack!) ***")
                elif e == 65537:
                    pass  # Standard, good
                else:
                    print(f"    NOTE: Non-standard exponent e={e}")

                # Perform raw RSA verification
                if len(sig_data) != key_size:
                    print(f"    Signature length {len(sig_data)} != key_size {key_size}")
                    # Try to handle length differences
                    if len(sig_data) < key_size:
                        sig_data = b'\x00' * (key_size - len(sig_data)) + sig_data
                    elif len(sig_data) > key_size:
                        print(f"    SKIP: Signature longer than modulus")
                        continue

                sig_int = int.from_bytes(sig_data, 'big')
                n_int = n

                if sig_int >= n_int:
                    print(f"    ERROR: Signature >= modulus!")
                    continue

                # sig^e mod n
                result_int = pow(sig_int, e, n_int)
                padded_msg = result_int.to_bytes(key_size, 'big')

                # Check PKCS#1 v1.5 padding
                check = check_pkcs1_v15(padded_msg, key_size, algo)
                total_sigs_checked += 1

                if check['valid']:
                    print(f"    Padding: OK ({check['ff_count']} FF bytes)")
                else:
                    total_issues += 1
                    print(f"    Padding: ISSUES FOUND!")
                    for issue in check['issues']:
                        print(f"      {issue}")

                    if check['has_extra_bytes']:
                        print(f"    *** POSSIBLE FORGERY DETECTED ***")

                    # Dump raw padded message for analysis
                    print(f"    Raw (first 64 bytes): {padded_msg[:64].hex()}")
                    print(f"    Raw (last 64 bytes):  {padded_msg[-64:].hex()}")

                padding_results.append({
                    'name': name,
                    'tx_hash': tx_hash,
                    'level': i,
                    'signer': signer_zone,
                    'keytag': keytag,
                    'algorithm': algo_name,
                    'type_covered': type_name,
                    'exponent': e,
                    'key_bits': key_size * 8,
                    'ff_count': check['ff_count'],
                    'valid_padding': check['valid'],
                    'has_extra_bytes': check.get('has_extra_bytes', False),
                    'issues': '; '.join(check['issues']) if check['issues'] else 'none',
                })

        except Exception as ex:
            print(f"\n{name}: ERROR - {ex}")
            import traceback
            traceback.print_exc()

    # Summary
    print("\n" + "=" * 80)
    print("SUMMARY")
    print("=" * 80)
    print(f"\n  Total RSA signatures checked: {total_sigs_checked}")
    print(f"  Signatures with padding issues: {total_issues}")
    print(f"  Signatures with correct padding: {total_sigs_checked - total_issues}")

    if total_issues > 0:
        print(f"\n  *** PADDING ISSUES FOUND - SEE DETAILS ABOVE ***")
        forgeries = [r for r in padding_results if r['has_extra_bytes']]
        if forgeries:
            print(f"\n  POSSIBLE FORGERIES (extra bytes after hash):")
            for f in forgeries:
                print(f"    {f['name']} level {f['level']}: {f['signer']} ({f['issues']})")
    else:
        print(f"\n  All RSA signatures have correct PKCS#1 v1.5 padding.")

    # Check exponents
    exponents = set(r['exponent'] for r in padding_results)
    print(f"\n  Exponents used: {exponents}")
    e3_sigs = [r for r in padding_results if r['exponent'] == 3]
    if e3_sigs:
        print(f"  *** WARNING: {len(e3_sigs)} signatures use e=3 ***")

    # Save results
    output_path = 'data/insecure_onchain_padding_check.csv'
    with open(output_path, 'w', newline='') as f:
        fieldnames = ['name', 'tx_hash', 'level', 'signer', 'keytag', 'algorithm',
                      'type_covered', 'exponent', 'key_bits', 'ff_count',
                      'valid_padding', 'has_extra_bytes', 'issues']
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for r in padding_results:
            writer.writerow(r)

    print(f"\n  Results saved to {output_path}")


if __name__ == '__main__':
    main()
