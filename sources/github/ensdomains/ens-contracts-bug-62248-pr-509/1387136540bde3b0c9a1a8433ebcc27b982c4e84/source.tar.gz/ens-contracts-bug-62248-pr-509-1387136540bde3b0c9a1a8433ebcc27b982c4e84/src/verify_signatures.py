#!/usr/bin/env python3
"""
Verify RSA signatures by comparing computed hash vs hash from sig^e mod n.

For each RSA signature:
1. Extract the signed data (rrset field)
2. Compute SHA-256 hash of signed data
3. Extract hash from padded message (after sig^e mod n)
4. Compare - if they match, signature is valid and untampered
"""

import csv
import hashlib

from check_padding import (
    parse_calldata, parse_rrset_field, parse_rsa_pubkey,
    check_pkcs1_v15, ALGORITHMS, TYPES
)

def verify_rsa_signature(rrset_data, sig_data, dnskey_rdata, algorithm):
    """
    Verify RSA signature by comparing computed hash vs extracted hash.

    Returns:
        dict with: valid, computed_hash, extracted_hash, match
    """
    result = {
        'valid': False,
        'computed_hash': None,
        'extracted_hash': None,
        'match': False,
        'error': None
    }

    # Parse RSA public key
    e, n, key_size = parse_rsa_pubkey(dnskey_rdata)
    if e is None:
        result['error'] = f"Could not parse RSA key: {key_size}"
        return result

    # Compute hash of signed data (the rrset field)
    if algorithm == 8:  # RSASHA256
        computed_hash = hashlib.sha256(rrset_data).digest()
    elif algorithm in (5, 7):  # RSASHA1
        computed_hash = hashlib.sha1(rrset_data).digest()
    else:
        result['error'] = f"Unknown algorithm {algorithm}"
        return result

    result['computed_hash'] = computed_hash.hex()

    # Compute sig^e mod n
    sig_int = int.from_bytes(sig_data, 'big')
    result_int = pow(sig_int, e, n)
    padded_msg = result_int.to_bytes(key_size, 'big')

    # Check PKCS#1 v1.5 padding and extract hash
    print(f"   Padded message: {padded_msg.hex()}")
    print(f"   Key size: {key_size} bytes, Algorithm: {algorithm}")

    check = check_pkcs1_v15(padded_msg, key_size, algorithm)

    if check['valid'] and 'hash_hex' in check:
        result['extracted_hash'] = check['hash_hex']
        result['match'] = (computed_hash.hex() == check['hash_hex'])
        result['valid'] = result['match']
    else:
        result['error'] = 'Invalid padding or could not extract hash'
        result['padding_issues'] = check.get('issues', [])

    return result


def main():
    csv_path = 'data/insecure_onchain_combined.csv'

    with open(csv_path) as f:
        reader = csv.DictReader(f)
        rows = list(reader)

    print(f"Verifying signatures for {len(rows)} transactions...\n")
    print("=" * 80)

    # Track TLD KSKs
    tld_ksks = {}  # (tld, keytag) -> { e, n, key_size, count, first_seen }

    verification_results = []
    total_sigs = 0
    valid_sigs = 0
    invalid_sigs = 0
    
    for row in rows:
        name = row['name']
        tx_hash = row['tx_hash']
        tx_data = row.get('tx_data', '')
        # print(row)
        if not tx_data or len(tx_data) < 10:
            continue

        try:
            # print("tx_data:", tx_data)
            selector, rrsets = parse_calldata(tx_data)
            # print("selector:", selector)
            # print("rrsets:", rrsets)
            # First pass: collect DNSKEYs
            dnskey_lookup = {}
            parsed_levels = []
            for i, rrset_entry in enumerate(rrsets):
                rrsig, records = parse_rrset_field(rrset_entry['rrset'])
                parsed_levels.append((rrsig, records, rrset_entry['sig'], rrset_entry['rrset']))

                for rec in records:
                    if rec['type'] == 48 and 'dnskey' in rec:
                        zone = rec['name']
                        tag = rec['dnskey']['key_tag']
                        dnskey_lookup[(zone, tag)] = rec['rdata']

                        # Track TLD KSKs
                        if rec['dnskey']['is_ksk'] and zone in ('cc', 'name'):
                            key_info = parse_rsa_pubkey(rec['rdata'])
                            if key_info[0] is not None:
                                ksk_key = (zone, tag)
                                if ksk_key not in tld_ksks:
                                    tld_ksks[ksk_key] = {
                                        'e': key_info[0],
                                        'n': key_info[1],
                                        'key_size': key_info[2],
                                        'count': 0,
                                        'first_seen': tx_hash[:16]
                                    }
                                tld_ksks[ksk_key]['count'] += 1

            print(f"\n{name} (tx: {tx_hash[:20]}...)")
            print("-" * 60)

            # Second pass: verify RSA signatures
            for i, (rrsig, records, sig_data, rrset_data) in enumerate(parsed_levels):
                if not rrsig:
                    continue

                algo = rrsig['algorithm']
                if algo not in (5, 7, 8):  # Only RSA
                    continue

                type_name = TYPES.get(rrsig['type_covered'], f"TYPE{rrsig['type_covered']}")
                algo_name = ALGORITHMS.get(algo, f"ALG{algo}")
                signer_zone = rrsig['signer_name']
                keytag = rrsig['keytag']

                lookup_key = (signer_zone, keytag)

                if lookup_key not in dnskey_lookup:
                    print(f"  Level {i}: {algo_name} for {type_name} by {signer_zone} (tag={keytag})")
                    print(f"    SKIP: Signing DNSKEY not in proof chain")
                    continue

                dnskey_rdata = dnskey_lookup[lookup_key]

                print(f"  Level {i}: {algo_name} for {type_name} by {signer_zone} (tag={keytag})")

                # Verify signature
                # print(f"    Verifying RSA signature...")
                # print(rrset_data.hex())
                # print(sig_data.hex())
                # print(dnskey_rdata.hex())

                verify_result = verify_rsa_signature(rrset_data, sig_data, dnskey_rdata, algo)
                total_sigs += 1

                if verify_result['valid']:
                    valid_sigs += 1
                    print(f"    ✓ VALID - hashes match")
                    print(f"      Computed:  {verify_result['computed_hash']}")
                    print(f"      Extracted: {verify_result['extracted_hash']}")
                else:
                    invalid_sigs += 1
                    print(f"    ✗ INVALID - verification failed")
                    if verify_result['computed_hash']:
                        print(f"      Computed:  {verify_result['computed_hash']}")
                    if verify_result['extracted_hash']:
                        print(f"      Extracted: {verify_result['extracted_hash']}")
                    if verify_result['error']:
                        print(f"      Error: {verify_result['error']}")
                    if 'padding_issues' in verify_result:
                        for issue in verify_result['padding_issues']:
                            print(f"        {issue}")

                verification_results.append({
                    'name': name,
                    'tx_hash': tx_hash,
                    'level': i,
                    'signer': signer_zone,
                    'keytag': keytag,
                    'algorithm': algo_name,
                    'type_covered': type_name,
                    'valid': verify_result['valid'],
                    'computed_hash': verify_result.get('computed_hash', ''),
                    'extracted_hash': verify_result.get('extracted_hash', ''),
                    'match': verify_result.get('match', False),
                    'error': verify_result.get('error', ''),
                })

        except Exception as ex:
            print(f"\n{name}: ERROR - {ex}")
            import traceback
            traceback.print_exc()

    # Summary
    print("\n" + "=" * 80)
    print("SUMMARY")
    print("=" * 80)

    print(f"\nTotal RSA signatures checked: {total_sigs}")
    print(f"  Valid (hash match): {valid_sigs}")
    print(f"  Invalid: {invalid_sigs}")

    if invalid_sigs > 0:
        print(f"\n*** {invalid_sigs} INVALID SIGNATURES FOUND ***")
        print("These transactions may have been tampered with!")
    else:
        print(f"\n✓ All signatures are valid - no tampering detected")

    # TLD KSK summary
    print("\n" + "=" * 80)
    print("TLD KSK SUMMARY")
    print("=" * 80)

    for (tld, keytag), info in sorted(tld_ksks.items()):
        print(f"\n{tld} KSK (tag={keytag}):")
        print(f"  Exponent: {info['e']}")
        print(f"  Key size: {info['key_size']} bytes ({info['key_size'] * 8} bits)")
        print(f"  Used in: {info['count']} transactions")
        print(f"  First seen: tx {info['first_seen']}...")

        if info['e'] == 3:
            print(f"  ⚠️  WARNING: e=3 (vulnerable to Bleichenbacher e=3 attack)")

    # Check if all .cc and .name use same keys
    cc_keys = [(tld, tag) for (tld, tag) in tld_ksks if tld == 'cc']
    name_keys = [(tld, tag) for (tld, tag) in tld_ksks if tld == 'name']

    if len(cc_keys) == 1:
        print(f"\n✓ All .cc transactions use the same KSK (tag={cc_keys[0][1]})")
    elif len(cc_keys) > 1:
        print(f"\n⚠️  WARNING: .cc transactions use {len(cc_keys)} different KSKs!")
        print("   This could indicate key rollover or tampering")

    if len(name_keys) == 1:
        print(f"✓ All .name transactions use the same KSK (tag={name_keys[0][1]})")
    elif len(name_keys) > 1:
        print(f"\n⚠️  WARNING: .name transactions use {len(name_keys)} different KSKs!")
        print("   This could indicate key rollover or tampering")

    # Save results
    output_path = 'data/signature_verification.csv'
    with open(output_path, 'w', newline='') as f:
        fieldnames = ['name', 'tx_hash', 'level', 'signer', 'keytag', 'algorithm',
                      'type_covered', 'valid', 'computed_hash', 'extracted_hash',
                      'match', 'error']
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for r in verification_results:
            writer.writerow(r)

    print(f"\n  Results saved to {output_path}")


if __name__ == '__main__':
    main()
