#!/usr/bin/env python3
"""
Check proveAndClaim transactions for potential DNSSEC proof forgery.

Extracts and cross-references:
1. TXT record (ENS address) from the leaf level of the proof chain
2. addr parameter from the calldata
3. DNSKEY records and key tags at each level
4. DS records and their referenced key tags
5. Consistency between levels
"""

import csv
import json

# Import shared functions from check_padding
from check_padding import (
    parse_dns_name,
    dns_name_length,
    compute_key_tag,
    ALGORITHMS,
    TYPES,
)

# Well-known root zone KSK key tags
KNOWN_ROOT_KSK_TAGS = {20326, 19036}


def parse_calldata_extended(tx_data_hex):
    """
    Parse calldata to extract name, addr, and RRSetWithSignature array.

    Extended version that extracts addr parameter (not in base parse_calldata).
    """
    data = bytes.fromhex(tx_data_hex[2:] if tx_data_hex.startswith('0x') else tx_data_hex)
    selector = data[:4].hex()
    params = data[4:]

    # Parse DNS name (first parameter)
    name_offset = int.from_bytes(params[0:32], 'big')
    name_len = int.from_bytes(params[name_offset:name_offset+32], 'big')
    name_data = params[name_offset+32:name_offset+32+name_len]
    dns_name, _ = parse_dns_name(name_data, 0)

    # Parse addr parameter (specific to forgery analysis)
    if selector == '06963218':
        # proveAndClaimWithResolver(bytes, RRSetWithSignature[], address, address)
        addr = '0x' + params[96:128][-20:].hex()
    elif selector == '224199c2':
        # proveAndClaimWithResolver(bytes, RRSetWithSignature[], bytes, address, address)
        addr = '0x' + params[128:160][-20:].hex()
    else:
        addr = 'unknown'

    # Parse RRSetWithSignature array (second parameter)
    input_offset = int.from_bytes(params[32:64], 'big')
    array_length = int.from_bytes(params[input_offset:input_offset+32], 'big')
    data_area_start = input_offset + 32

    element_offsets = []
    for i in range(array_length):
        off = int.from_bytes(params[data_area_start + i*32:data_area_start + (i+1)*32], 'big')
        element_offsets.append(off)

    rrsets = []
    for elem_off in element_offsets:
        elem_start = data_area_start + elem_off
        rrset_off = int.from_bytes(params[elem_start:elem_start+32], 'big')
        sig_off = int.from_bytes(params[elem_start+32:elem_start+64], 'big')

        rrset_abs = elem_start + rrset_off
        rrset_len = int.from_bytes(params[rrset_abs:rrset_abs+32], 'big')
        rrset_data = params[rrset_abs+32:rrset_abs+32+rrset_len]

        sig_abs = elem_start + sig_off
        sig_len = int.from_bytes(params[sig_abs:sig_abs+32], 'big')
        sig_data = params[sig_abs+32:sig_abs+32+sig_len]

        rrsets.append({'rrset': rrset_data, 'sig': sig_data})

    return selector, dns_name, addr, rrsets


def parse_rrset_field_extended(rrset_data):
    """
    Parse rrset field with extended record details (DS, TXT parsing).

    Extended version that parses DS and TXT record details (not in base version).
    """
    if len(rrset_data) < 18:
        return None, []

    # RRSIG fixed header (18 bytes)
    rrsig = {
        'type_covered': int.from_bytes(rrset_data[0:2], 'big'),
        'algorithm': rrset_data[2],
        'labels': rrset_data[3],
        'ttl': int.from_bytes(rrset_data[4:8], 'big'),
        'expiration': int.from_bytes(rrset_data[8:12], 'big'),
        'inception': int.from_bytes(rrset_data[12:16], 'big'),
        'keytag': int.from_bytes(rrset_data[16:18], 'big'),
    }

    # Signer name (variable length)
    signer_name, signer_len = parse_dns_name(rrset_data, 18)
    rrsig['signer_name'] = signer_name

    # RR records start after signer name
    pos = 18 + signer_len
    records = []

    while pos < len(rrset_data):
        if pos + 1 > len(rrset_data):
            break

        # Parse RR owner name
        name_len = dns_name_length(rrset_data, pos)
        if pos + name_len > len(rrset_data):
            break
        rr_name, _ = parse_dns_name(rrset_data, pos)
        pos += name_len

        # Need at least 10 more bytes for type(2)+class(2)+ttl(4)+rdlength(2)
        if pos + 10 > len(rrset_data):
            break

        rr_type = int.from_bytes(rrset_data[pos:pos+2], 'big')
        rr_class = int.from_bytes(rrset_data[pos+2:pos+4], 'big')
        rr_ttl = int.from_bytes(rrset_data[pos+4:pos+8], 'big')
        rdlength = int.from_bytes(rrset_data[pos+8:pos+10], 'big')
        pos += 10

        if pos + rdlength > len(rrset_data):
            break

        rdata = rrset_data[pos:pos+rdlength]
        pos += rdlength

        record = {
            'name': rr_name,
            'type': rr_type,
            'type_name': TYPES.get(rr_type, f'TYPE{rr_type}'),
            'rdata': rdata,
        }

        # Parse DNSKEY rdata
        if rr_type == 48 and len(rdata) >= 4:
            flags = int.from_bytes(rdata[0:2], 'big')
            protocol = rdata[2]
            algorithm = rdata[3]
            key_tag = compute_key_tag(rdata)
            record['dnskey'] = {
                'flags': flags,
                'protocol': protocol,
                'algorithm': algorithm,
                'key_tag': key_tag,
                'is_ksk': flags == 257,
                'is_zsk': flags == 256,
            }

        # Parse DS rdata (extended)
        elif rr_type == 43 and len(rdata) >= 4:
            record['ds'] = {
                'key_tag': int.from_bytes(rdata[0:2], 'big'),
                'algorithm': rdata[2],
                'digest_type': rdata[3],
                'digest': rdata[4:].hex(),
            }

        # Parse TXT rdata (extended)
        elif rr_type == 16:
            txt_pos = 0
            txt_strings = []
            while txt_pos < len(rdata):
                txt_len = rdata[txt_pos]
                txt_pos += 1
                if txt_pos + txt_len <= len(rdata):
                    txt_strings.append(rdata[txt_pos:txt_pos+txt_len].decode('ascii', errors='replace'))
                txt_pos += txt_len
            record['txt'] = ''.join(txt_strings)

        records.append(record)

    return rrsig, records


def analyze_transaction(name, tx_hash, tx_data, tx_from):
    """Analyze a single transaction for forgery indicators."""
    findings = []
    warnings = []

    selector, dns_name, addr_param, rrsets = parse_calldata_extended(tx_data)

    findings.append(f"  DNS name in calldata: {dns_name}")
    findings.append(f"  addr parameter: {addr_param}")
    findings.append(f"  tx_from: {tx_from}")

    # Track key tags across levels for cross-referencing
    all_dnskey_tags = {}  # zone -> set of key tags
    all_ds_refs = {}       # zone -> set of referenced key tags
    txt_address = None

    for i, rrset_entry in enumerate(rrsets):
        rrsig, records = parse_rrset_field_extended(rrset_entry['rrset'])
        if not rrsig:
            warnings.append(f"  WARNING: Could not parse level {i}")
            continue

        type_name = TYPES.get(rrsig['type_covered'], f"TYPE{rrsig['type_covered']}")
        algo_name = ALGORITHMS.get(rrsig['algorithm'], f"ALG{rrsig['algorithm']}")
        findings.append(f"  Level {i}: RRSIG for {type_name} by {rrsig['signer_name']} "
                       f"(alg={algo_name}, keytag={rrsig['keytag']})")

        # Check root zone DNSKEY level
        if rrsig['signer_name'] == '.' and rrsig['type_covered'] == 48:  # DNSKEY
            # Root zone RRSIG should reference a known KSK
            if rrsig['keytag'] not in KNOWN_ROOT_KSK_TAGS:
                warnings.append(f"  WARNING: Root zone RRSIG uses unknown KSK keytag={rrsig['keytag']}")

        # Parse records at this level
        for rec in records:
            if rec['type'] == 48 and 'dnskey' in rec:  # DNSKEY
                dk = rec['dnskey']
                zone = rec['name']
                if zone not in all_dnskey_tags:
                    all_dnskey_tags[zone] = set()
                all_dnskey_tags[zone].add(dk['key_tag'])

                key_type = 'KSK' if dk['is_ksk'] else 'ZSK' if dk['is_zsk'] else f"flags={dk['flags']}"
                findings.append(f"    DNSKEY: zone={zone} tag={dk['key_tag']} {key_type} alg={dk['algorithm']}")

            elif rec['type'] == 43 and 'ds' in rec:  # DS
                ds = rec['ds']
                # DS record points to a DNSKEY in a child zone
                # The name of the DS record is the child zone
                child_zone = rec['name']
                if child_zone not in all_ds_refs:
                    all_ds_refs[child_zone] = set()
                all_ds_refs[child_zone].add(ds['key_tag'])

                findings.append(f"    DS: for zone={child_zone} ref_tag={ds['key_tag']} alg={ds['algorithm']}")

            elif rec['type'] == 16 and 'txt' in rec:  # TXT
                txt_content = rec['txt']
                findings.append(f"    TXT: {txt_content[:80]}{'...' if len(txt_content) > 80 else ''}")

                # Extract ENS address from TXT record
                if txt_content.startswith('a=0x') or txt_content.startswith('a=0X'):
                    txt_address = txt_content[2:42].lower()

    # Cross-reference checks
    findings.append("\n  Cross-reference checks:")

    # Check if TXT address matches addr parameter and tx_from
    if txt_address:
        findings.append(f"    TXT address: {txt_address}")
        if txt_address == addr_param.lower():
            findings.append(f"    ✓ TXT address matches addr parameter")
        else:
            warnings.append(f"    WARNING: TXT address {txt_address} != addr param {addr_param}")

        if txt_address == tx_from.lower():
            findings.append(f"    ✓ TXT address matches tx_from (self-registration)")
        else:
            warnings.append(f"    NOTE: TXT address {txt_address} != tx_from {tx_from} (third-party registration)")

    # Check DS -> DNSKEY references
    for zone, ds_tags in all_ds_refs.items():
        if zone in all_dnskey_tags:
            dnskey_tags = all_dnskey_tags[zone]
            for ds_tag in ds_tags:
                if ds_tag in dnskey_tags:
                    findings.append(f"    ✓ DS for {zone} tag={ds_tag} matches DNSKEY")
                else:
                    warnings.append(f"    WARNING: DS for {zone} tag={ds_tag} does not match any DNSKEY (tags: {dnskey_tags})")
        else:
            warnings.append(f"    WARNING: DS for {zone} but no DNSKEY found in proof chain")

    return findings, warnings, txt_address


def main():
    csv_path = 'data/insecure_onchain_combined.csv'

    with open(csv_path) as f:
        reader = csv.DictReader(f)
        rows = list(reader)

    print(f"Analyzing {len(rows)} transactions for forgery indicators...\n")
    print("=" * 80)

    results = []

    for row in rows:
        name = row['name']
        tx_hash = row['tx_hash']
        tx_data = row.get('tx_data', '')
        tx_from = row.get('tx_from', '')

        if not tx_data or len(tx_data) < 10:
            continue

        print(f"\n{name} (tx: {tx_hash[:20]}...)")
        print("-" * 60)

        try:
            findings, warnings, txt_address = analyze_transaction(name, tx_hash, tx_data, tx_from)

            for finding in findings:
                print(finding)

            for warning in warnings:
                print(warning)

            # Determine verdict
            if warnings:
                verdict = "SUSPICIOUS"
            else:
                verdict = "OK"

            results.append({
                'name': name,
                'tx_hash': tx_hash,
                'txt_address': txt_address or '',
                'addr_param': '',  # Would need to extract from findings
                'tx_from': tx_from,
                'warnings': '; '.join([w.strip() for w in warnings]),
                'verdict': verdict,
            })

        except Exception as ex:
            print(f"  ERROR: {ex}")
            import traceback
            traceback.print_exc()

    # Summary
    print("\n" + "=" * 80)
    print("SUMMARY")
    print("=" * 80)

    suspicious = [r for r in results if r['verdict'] == 'SUSPICIOUS']
    print(f"\nTotal analyzed: {len(results)}")
    print(f"Suspicious: {len(suspicious)}")
    print(f"OK: {len(results) - len(suspicious)}")

    if suspicious:
        print(f"\nSuspicious transactions:")
        for r in suspicious:
            print(f"  {r['name']} - {r['tx_hash'][:20]}...")
            print(f"    {r['warnings'][:100]}...")

    # Save results
    output_path = 'data/insecure_onchain_forgery_check.csv'
    with open(output_path, 'w', newline='') as f:
        fieldnames = ['name', 'tx_hash', 'txt_address', 'addr_param', 'tx_from', 'warnings', 'verdict']
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for r in results:
            writer.writerow(r)

    print(f"\n  Results saved to {output_path}")


if __name__ == '__main__':
    main()
