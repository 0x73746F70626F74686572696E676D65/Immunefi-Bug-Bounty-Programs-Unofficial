# Impact Report: RSA e=3 Signature Forgery in ENS DNSSEC Oracle

## Summary

55 TLDs use RSA KSK keys with public exponent e=3, making them vulnerable to signature forgery via Bleichenbacher's cube root attack. Of these, 2 TLDs (`.cc` and `.name`) have confirmed impacted ENS domains (on-chain registrations or off-chain domains with active ENS1 TXT records).

**Total domains at risk: 27** (20 on-chain + 7 off-chain with ENS1 records)

## Impacted TLDs

| TLD | Algorithm | On-chain | Off-chain (ENS1) | Total |
|-----|-----------|----------|------------------|-------|
| .cc | RSASHA256 | 6 | 3 | 9 |
| .name | RSASHA256 | 14 | 4 | 18 |
| **Total** | | **20** | **7** | **27** |

Note: Off-chain domains are only counted if they have an active `ENS1` TXT record on DNS, which is required for gasless DNSSEC / off-chain resolution. Of 669 off-chain domains under insecure TLDs found in gateway logs, only 7 have active ENS1 records.

### Insecure TLDs with no confirmed impacted domains

.abb, .abc, .accenture, .aeg, .airbus, .aol, .arte, .asda, .bbt, .bloomberg, .bms, .bofa, .bosch, .cfa, .chanel, .clubmed, .comsec, .fidelity, .genting, .ice, .jaguar, .juniper, .kerryhotels, .kerryproperties, .kuokgroup, .landrover, .lefrak, .lego, .lundbeck, .maif, .nab, .next, .nextdirect, .nikon, .nissay, .orange, .pictet, .rexroth, .rwe, .sanofi, .sener, .shangrila, .tatamotors, .tiaa, .ubank, .ubs, .vanguard, .verisign, .visa, .volvo, .weber, .weir, .yahoo

These 53 TLDs have e=3 RSA KSK keys but no confirmed impacted ENS domains (no on-chain registrations and no off-chain domains with active ENS1 TXT records). 16 of these had domains in gateway logs but none with ENS1 records set.

The 55 insecure TLDs were identified by checking DNSKEY records for 1,295 TLDs (deduplicated from 223 TLDs with on-chain ENS registrations via TheGraph and TLDs extracted from 118,771 unique domains in the off-chain DNSSEC gateway logs).

---

## Impacted domains

All 27 impacted domains are listed in [`insecure_names.csv`](insecure_names.csv) with columns: name, tld, algorithm, type (onchain/offchain).

- **On-chain (20)**: Registered on ENS contracts. An attacker could forge DNSSEC proofs in an on-chain import transaction to hijack ownership.
- **Off-chain (7)**: Have active ENS1 TXT records under insecure TLDs. An attacker could hijack resolution by compromising the DNS gateway with forged DNSSEC responses.

Note: 669 off-chain domains under insecure TLDs were checked. Of those, only 7 had active ENS1 records; the rest returned NXDOMAIN, no TXT records, or DNS errors.

---

## Appendix: Data Sources and Domain Breakdown

### On-chain

**Data sources**: TheGraph 

| Metric | Count |
|---|---|
| TLDs with at least 1 registration | 223 |
| Total 2LD names | 4,870 |
| Total subnames (under insecure TLDs) | 1 (`vault.validator.name`) |
| Insecure TLDs with registrations | 2 (`.cc`, `.name`) |
| Insecure on-chain names | 20 |

<details>
<summary>All 223 TLDs with registrations</summary>

ac, af, ag, agency, ai, am, app, army, art, asia, at, attorney, au, audio, auto, autos, bar, best, bet, bio, biz, black, blue, boats, bot, broker, build, bz, ca, cafe, cam, capital, casa, cash, cc, ch, chat, christmas, church, city, click, cloud, club, co, codes, com, community, company, computer, consulting, cool, country, cz, day, de, deal, deals, design, dev, digital, direct, diy, dog, domains, eco, ee, email, engineer, enterprises, es, eu, exchange, fan, fans, farm, fi, finance, financial, fm, forsale, foundation, fr, fun, fund, fyi, gallery, game, games, garden, gay, gg, gift, glass, global, gold, gr, group, guru, haus, health, healthcare, hiphop, hk, homes, host, id, in, info, ing, ink, investments, io, irish, is, je, jp, juegos, kitchen, kr, kred, land, li, life, limo, link, live, lk, llc, loan, locker, lol, love, ltd, lu, luxe, market, markets, me, media, meme, mobile, moe, money, monster, music, my, name, net, network, news, ngo, ninja, nl, now, observer, one, onl, online, ooo, org, parts, party, pet, photos, pics, pink, pizza, plus, porn, pr, pro, quest, realestate, red, reverse, rich, rip, ro, rocks, se, sh, shop, show, ski, social, solutions, soy, space, store, studio, style, team, tech, tf, today, tokyo, tools, top, town, trading, travel, tw, ug, uk, uno, us, vc, ventures, vet, video, vip, vision, vn, vodka, vote, wang, website, work, works, world, wtf, xyz, zone

</details>

### Off-chain

**Data source**: Plausible analytics

| Metric | Count |
|---|---|
| Unique domains in gateway logs | 118,771 |

**ENS1 scan** (to find active off-chain names)

| Metric | Count |
|---|---|
| Domains with ≥3 visitors (scanned) | 11,953 |
| Domains with ENS1 TXT record | 937 |

**Insecure TLD filter** (to find vulnerable names)

| Metric | Count |
|---|---|
| Insecure TLDs (e=3 RSA KSK) | 55 |
| Insecure TLDs with gateway domains | 16 |
| Domains under the 16 insecure TLDs | 669 |

**Intersection**

| Metric | Count |
|---|---|
| **Insecure domains with ENS1 TXT record** | **7** |

<details>
<summary>All 55 insecure TLDs (e=3 RSA KSK)</summary>

.abb, .abc, .accenture, .aeg, .airbus, .aol, .arte, .asda, .bbt, .bloomberg, .bms, .bofa, .bosch, .cc, .cfa, .chanel, .clubmed, .comsec, .fidelity, .genting, .ice, .jaguar, .juniper, .kerryhotels, .kerryproperties, .kuokgroup, .landrover, .lefrak, .lego, .lundbeck, .maif, .nab, .name, .next, .nextdirect, .nikon, .nissay, .orange, .pictet, .rexroth, .rwe, .sanofi, .sener, .shangrila, .tatamotors, .tiaa, .ubank, .ubs, .vanguard, .verisign, .visa, .volvo, .weber, .weir, .yahoo

</details>

<details>
<summary>16 insecure TLDs with off-chain domains</summary>

.abb, .abc, .aeg, .aol, .arte, .asda, .bms, .bosch, .cc, .ice, .nab, .name, .next, .orange, .ubs, .yahoo

</details>

---

## Scan Metadata

- **Date**: January 29–30, 2026
- **DNSKEY scan**: 4,213 lookups (TLDs + 2LDs), ~30 min (Jan 29, 18:01–18:32 UTC)
- **ENS1 TXT scan (insecure TLD domains)**: 669 lookups, ~3 min (Jan 30)
- **ENS1 TXT scan (popular domains)**: 11,953 lookups, ~61 min (Jan 30)
- **TLDs checked**: 1,295 (from on-chain + off-chain sources)
- **2LDs checked**: 2,918 (all on-chain 2LDs excluding .luxe)
- **2LD result**: 0 insecure 2LDs found (all with DNSKEY use ECDSA or RSA e=65537)
