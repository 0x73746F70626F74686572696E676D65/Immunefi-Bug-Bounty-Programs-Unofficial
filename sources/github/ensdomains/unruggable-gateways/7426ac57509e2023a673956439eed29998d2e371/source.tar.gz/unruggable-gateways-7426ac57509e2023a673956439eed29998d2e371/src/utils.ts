import { AbiCoder, Interface } from 'ethers/abi';
import { id as keccakStr } from 'ethers/hash';
import { isCallException, type EthersError } from 'ethers/utils';
import type {
  RawProvider,
  BigNumberish,
  HexString,
  HexString32,
  HexAddress,
} from './types.js';
import type { RPCEthGetBlock } from './eth/types.js';

export const ABI_CODER = AbiCoder.defaultAbiCoder();

// https://adraffy.github.io/keccak.js/test/demo.html#algo=keccak-256&s=&escape=1&encoding=utf8
// "0xc5d2460186f7233c927e7db2dcc703c0e500b653ca82273b7bfad8045d85a470"
export const NULL_CODE_HASH = keccakStr('');

export const EVM_BLOCKHASH_DEPTH = 256;

// TODO: make this a function of Chain
export const MAINNET_BLOCK_SEC = 12;

export const LATEST_BLOCK_TAG = 'latest';

// hex-prefixed w/o zero-padding
export function toUnpaddedHex(x: BigNumberish | boolean): HexString {
  return '0x' + BigInt(x).toString(16);
}
// hex-prefixed left-pad w/truncation
export function toPaddedHex(x: BigNumberish | boolean, width = 32) {
  const i = x === '0x' ? 0n : BigInt.asUintN(width << 3, BigInt(x));
  return '0x' + i.toString(16).padStart(width << 1, '0');
}

// manual polyfill: ES2024
export function withResolvers<T = void>() {
  let resolve!: (value: T) => void;
  let reject!: (reason?: any) => void;
  const promise = new Promise<T>((ful, rej) => {
    resolve = ful;
    reject = rej;
  });
  return { promise, resolve, reject };
}

export function isBlockTag(x: BigNumberish): x is string {
  return typeof x === 'string' && !x.startsWith('0x');
}

// Convert block tag to a format safe for JSON serialization (bigint -> hex string)
function toBlockTag(relBlockTag: BigNumberish): string {
  return typeof relBlockTag === 'bigint'
    ? toUnpaddedHex(relBlockTag)
    : String(relBlockTag);
}

export async function fetchBlock(
  provider: RawProvider,
  relBlockTag: BigNumberish = LATEST_BLOCK_TAG
): Promise<RPCEthGetBlock> {
  if (!isBlockTag(relBlockTag)) {
    let i = BigInt(relBlockTag);
    if (i < 0) i += await fetchBlockNumber(provider);
    relBlockTag = toUnpaddedHex(i);
  }
  const json = await provider.send('eth_getBlockByNumber', [
    relBlockTag,
    false,
  ]);
  if (!json) throw new Error(`no block: ${relBlockTag}`);
  return json;
}

export async function fetchBlockFromHash(
  provider: RawProvider,
  blockHash: HexString32
): Promise<RPCEthGetBlock> {
  const block: RPCEthGetBlock | null = await provider.send(
    'eth_getBlockByHash',
    [blockHash, false]
  );
  if (!block) throw new Error(`no blockhash: ${blockHash}`);
  return block;
}

// avoid an rpc if possible
// use negative (-100) for offset from "latest" (#-100)
export async function fetchBlockNumber(
  provider: RawProvider,
  relBlockTag: BigNumberish = LATEST_BLOCK_TAG
): Promise<bigint> {
  if (relBlockTag === LATEST_BLOCK_TAG) {
    return BigInt(await provider.send('eth_blockNumber', []));
  } else if (isBlockTag(relBlockTag)) {
    const info = await fetchBlock(provider, relBlockTag);
    return BigInt(info.number);
  } else {
    let i = BigInt(relBlockTag);
    if (i < 0) i += await fetchBlockNumber(provider);
    return i;
  }
}

// avoid an rpc if possible
// convert negative (-100) => absolute (#-100)
export async function fetchBlockTag(
  provider: RawProvider,
  relBlockTag: BigNumberish = LATEST_BLOCK_TAG
): Promise<string | bigint> {
  return isBlockTag(relBlockTag)
    ? relBlockTag
    : fetchBlockNumber(provider, relBlockTag);
}

export async function fetchStorage(
  provider: RawProvider,
  target: HexAddress,
  slot: BigNumberish,
  relBlockTag: BigNumberish = LATEST_BLOCK_TAG
): Promise<HexString32> {
  const data: HexString32 | null = await provider.send('eth_getStorageAt', [
    target,
    toPaddedHex(slot),
    toBlockTag(relBlockTag),
  ]);
  if (!data) {
    throw new Error(
      `expected storage: ${target}<${toUnpaddedHex(slot)}>@${relBlockTag}`
    );
  }
  // i think i've seen "0x" before...
  return data.length === 66 ? data : toPaddedHex(data);
}

export async function fetchCode(
  provider: RawProvider,
  target: HexAddress,
  relBlockTag: BigNumberish = LATEST_BLOCK_TAG
): Promise<HexString> {
  return provider.send('eth_getCode', [target, toBlockTag(relBlockTag)]);
}

export async function staticCall<T>(
  provider: RawProvider,
  to: HexAddress,
  abi: Interface,
  fragment: string,
  args: any[],
  blockTag: BigNumberish = LATEST_BLOCK_TAG
): Promise<T> {
  const data = abi.encodeFunctionData(fragment, args);
  try {
    const answer: string = await provider.send('eth_call', [
      {
        to,
        data: abi.encodeFunctionData(fragment, args),
      },
      toBlockTag(blockTag),
    ]);
    const result = abi.decodeFunctionResult(fragment, answer);
    return (result.length == 1 ? result[0] : result) as T;
  } catch (err) {
    if (isCallException(err) && err.data) {
      throw abi.makeError(err.data, { to, data });
    }
    throw err;
  }
}

export function isEthersError(err: unknown): err is EthersError {
  return err instanceof Error && 'code' in err && 'shortMessage' in err;
}

export function isRPCError(err: any, ...code: number[]): err is EthersError {
  return (
    isEthersError(err) &&
    err.error instanceof Object &&
    'code' in err.error &&
    typeof err.error.code === 'number' &&
    code.includes(err.error.code)
  );
}

export function flattenErrors(err: unknown, stringify = stringifyError) {
  const errors = [stringify(err)];
  for (let e = err; e instanceof Error && e.cause; e = e.cause) {
    errors.push(stringify(e.cause));
  }
  return errors.join(' <== ');
}

function stringifyError(err: unknown) {
  if (isEthersError(err) && err.code === 'SERVER_ERROR') {
    // this leaks api key via "requestUrl"
    // https://github.com/ethers-io/ethers.js/blob/d2c9ca0e0fd15e7884bcaab7d5152d68662e3e43/src.ts/utils/fetch.ts#L953
    return err.shortMessage;
  } else {
    return String(err);
  }
}
