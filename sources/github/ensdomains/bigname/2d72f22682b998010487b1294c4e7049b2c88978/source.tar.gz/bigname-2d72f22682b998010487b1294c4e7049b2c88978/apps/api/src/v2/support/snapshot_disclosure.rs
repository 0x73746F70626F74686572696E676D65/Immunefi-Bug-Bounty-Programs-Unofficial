use super::*;

#[cfg(test)]
use crate::v2::search_public_namespace_read_test_hooks::{self as read_hooks, ReadHookPoint};
use crate::v2::{AsOfCompleteness, Completeness, Meta, V2Result, api_error_to_v2, as_of_meta};

const TEMPORARILY_UNAVAILABLE: &str = "temporarily_unavailable";

#[derive(Debug, Eq, PartialEq)]
pub(crate) struct ExplicitNamespaceRequestScope {
    meta: Meta,
    selected_heads: BTreeMap<String, Option<(i64, String)>>,
    project_generations: Option<BTreeMap<String, String>>,
    interpret_redo_state: bigname_storage::SelectedInterpretRedoState,
}

pub(crate) fn request_scope_meta(scopes: &[RequestScopeSnapshot]) -> V2Result<Meta> {
    let mut meta = Meta::default();
    let as_of = scopes
        .iter()
        .filter_map(RequestScopeSnapshot::selected)
        .map(as_of_meta)
        .collect::<V2Result<Vec<_>>>()?
        .into_iter()
        .flatten()
        .collect::<BTreeMap<_, _>>();
    if !as_of.is_empty() {
        meta.as_of = Some(as_of);
    }
    apply_request_scope_completeness(&mut meta, scopes)?;
    Ok(meta)
}

pub(crate) fn apply_request_scope_completeness(
    meta: &mut Meta,
    scopes: &[RequestScopeSnapshot],
) -> V2Result<()> {
    let mut suppressed = meta.as_of_completeness.take().unwrap_or_default();
    for scope in scopes.iter().filter(|scope| scope.selected().is_none()) {
        for position in scope.scope().required_positions() {
            let chain_id = crate::v2::slug_to_numeric(&position.chain_id).ok_or_else(|| {
                crate::v2::V2Error::internal_error(format!(
                    "request scope uses unmapped chain_id {}",
                    position.chain_id
                ))
            })?;
            suppressed.insert(
                chain_id.to_string(),
                AsOfCompleteness {
                    completeness: Completeness::Unsupported,
                    unsupported_reason: TEMPORARILY_UNAVAILABLE.to_owned(),
                },
            );
        }
    }
    if !suppressed.is_empty() {
        if let Some(as_of) = meta.as_of.as_mut() {
            as_of.retain(|chain_id, _| !suppressed.contains_key(chain_id));
            if as_of.is_empty() {
                meta.as_of = None;
            }
        }
        meta.as_of_completeness = Some(suppressed);
    }
    Ok(())
}

pub(crate) fn apply_suppressed_request_scope_completeness(
    meta: &mut Meta,
    scope: &SnapshotSelectionScope,
) -> V2Result<()> {
    apply_request_scope_completeness(
        meta,
        &[RequestScopeSnapshot {
            scope: scope.clone(),
            selected: None,
        }],
    )
}

pub(crate) async fn explicit_namespace_request_scope(
    state: &AppState,
    namespace: &str,
) -> V2Result<ExplicitNamespaceRequestScope> {
    let scope = exact_name_snapshot_scope(
        &state.pool,
        namespace,
        ExactNameSnapshotSelector::default(),
        false,
    )
    .await
    .map_err(api_error_to_v2)?;
    let selected_heads = request_scope_head_fingerprint(&state.pool, &scope).await?;
    let input = crate::v2::snapshots::selector_input(None, None, SnapshotConsistency::Head)
        .map_err(snapshot_selection_api_error)
        .map_err(api_error_to_v2)?;
    let (selected, project_generations, interpret_redo_state) =
        match resolve_exact_name_snapshot_selection(&state.pool, &scope, &input).await {
            Ok(selected) => {
                #[cfg(test)]
                read_hooks::run_at(&state.pool, ReadHookPoint::AfterExplicitSelection).await?;
                let chain_ids = selected
                    .chain_positions
                    .as_map()
                    .values()
                    .map(|position| position.chain_id.clone())
                    .collect::<Vec<_>>();
                let redo_state =
                    bigname_storage::load_selected_interpret_redo_state(&state.pool, &chain_ids)
                        .await
                        .map_err(|_| {
                            crate::v2::V2Error::internal_error(
                                "failed to validate request-scope metadata",
                            )
                        })?;
                let readable_generations =
                    load_selected_project_generations_for_read(&state.pool, &selected, true)
                        .await
                        .map_err(|_| {
                            crate::v2::V2Error::internal_error(
                                "failed to validate request-scope metadata",
                            )
                        })?;
                let project_generations = match readable_generations.as_ref() {
                    Some(_) => readable_generations.clone(),
                    None => {
                        load_unfenced_explicit_namespace_generations(
                            &state.pool,
                            &selected,
                            &redo_state,
                        )
                        .await?
                    }
                };
                (
                    readable_generations.map(|_| selected),
                    project_generations,
                    redo_state,
                )
            }
            Err(error)
                if matches!(
                    error.kind(),
                    SnapshotSelectionErrorKind::Conflict | SnapshotSelectionErrorKind::Stale
                ) =>
            {
                let redo_state =
                    load_explicit_namespace_interpret_redo_state(&state.pool, &scope).await?;
                (None, None, redo_state)
            }
            Err(error) => return Err(api_error_to_v2(snapshot_selection_api_error(error))),
        };
    Ok(ExplicitNamespaceRequestScope {
        meta: request_scope_meta(&[RequestScopeSnapshot { scope, selected }])?,
        selected_heads,
        project_generations,
        interpret_redo_state,
    })
}

async fn load_explicit_namespace_interpret_redo_state(
    pool: &PgPool,
    scope: &SnapshotSelectionScope,
) -> V2Result<bigname_storage::SelectedInterpretRedoState> {
    let chain_ids = scope
        .required_positions()
        .iter()
        .map(|position| position.chain_id.clone())
        .collect::<Vec<_>>();
    let redo_state = bigname_storage::load_selected_interpret_redo_state(pool, &chain_ids)
        .await
        .map_err(|_| {
            crate::v2::V2Error::internal_error("failed to validate request-scope metadata")
        })?;
    match redo_state.changed_or_active(&redo_state) {
        true => Err(crate::v2::V2Error::stale(
            "served data is temporarily unavailable while Interpret redo is in progress",
        )),
        false => Ok(redo_state),
    }
}

async fn load_unfenced_explicit_namespace_generations(
    pool: &PgPool,
    selected: &SelectedSnapshot,
    expected_redo_state: &bigname_storage::SelectedInterpretRedoState,
) -> V2Result<Option<BTreeMap<String, String>>> {
    #[cfg(test)]
    read_hooks::run_at(pool, ReadHookPoint::BeforeUnfencedGenerations).await?;
    let generations = load_selected_project_generations_for_read(pool, selected, false)
        .await
        .map_err(|_| {
            crate::v2::V2Error::internal_error("failed to validate request-scope metadata")
        })?;
    let chain_ids = selected
        .chain_positions
        .as_map()
        .values()
        .map(|position| position.chain_id.clone())
        .collect::<Vec<_>>();
    let current_redo_state = bigname_storage::load_selected_interpret_redo_state(pool, &chain_ids)
        .await
        .map_err(|_| {
            crate::v2::V2Error::internal_error("failed to validate request-scope metadata")
        })?;
    if expected_redo_state.changed_or_active(&current_redo_state) {
        return Err(crate::v2::V2Error::stale(
            "served data is temporarily unavailable while Interpret redo is in progress",
        ));
    }
    if generations.is_some() {
        return Err(crate::v2::V2Error::conflict(
            "search namespace readiness changed while the request was being read",
        ));
    }
    Ok(None)
}

async fn request_scope_head_fingerprint(
    pool: &PgPool,
    scope: &SnapshotSelectionScope,
) -> V2Result<BTreeMap<String, Option<(i64, String)>>> {
    let mut heads = BTreeMap::new();
    for requirement in scope.required_positions() {
        let head = sqlx::query_as::<_, (i64, String)>(
            "SELECT latest_block_number, latest_block_hash
             FROM chain_heads
             WHERE chain_id = $1",
        )
        .bind(&requirement.chain_id)
        .fetch_optional(pool)
        .await
        .map_err(|_| crate::v2::V2Error::internal_error("failed to capture request-scope head"))?;
        heads.insert(requirement.chain_id.clone(), head);
    }
    Ok(heads)
}

pub(crate) async fn revalidate_explicit_namespace_request_scope(
    state: &AppState,
    namespace: &str,
    expected: ExplicitNamespaceRequestScope,
) -> V2Result<Meta> {
    let current = explicit_namespace_request_scope(state, namespace).await?;
    if expected
        .interpret_redo_state
        .changed_or_active(&current.interpret_redo_state)
    {
        return Err(crate::v2::V2Error::stale(
            "served data is temporarily unavailable while Interpret redo is in progress",
        ));
    }
    if current != expected {
        return Err(crate::v2::V2Error::conflict(
            "search namespace position changed while the request was being read",
        ));
    }
    Ok(expected.meta)
}

#[cfg(test)]
mod tests {
    use bigname_storage::{
        ChainPosition, ChainPositions, SelectedSnapshot, SnapshotConsistency,
        SnapshotPositionRequirement, SnapshotSelectionScope,
    };

    use super::*;

    fn ethereum_scope() -> SnapshotSelectionScope {
        SnapshotSelectionScope::new(
            vec![SnapshotPositionRequirement::new(
                "ethereum",
                "ethereum-mainnet",
            )],
            Some("ethereum".to_owned()),
        )
        .expect("test scope must be valid")
    }

    fn ethereum_snapshot() -> SelectedSnapshot {
        SelectedSnapshot {
            chain_positions: ChainPositions::new(BTreeMap::from([(
                "ethereum".to_owned(),
                ChainPosition {
                    slot: "ethereum".to_owned(),
                    chain_id: "ethereum-mainnet".to_owned(),
                    block_number: 100,
                    block_hash: "0xoverlap".to_owned(),
                    timestamp: parse_rfc3339_utc_timestamp("2026-08-26T00:00:00Z")
                        .expect("test timestamp must parse"),
                },
            )])),
            consistency: SnapshotConsistency::Head,
        }
    }

    #[test]
    fn request_scope_meta_gives_suppression_precedence_for_overlapping_chain_scopes() {
        let meta = request_scope_meta(&[
            RequestScopeSnapshot {
                scope: ethereum_scope(),
                selected: Some(ethereum_snapshot()),
            },
            RequestScopeSnapshot {
                scope: ethereum_scope(),
                selected: None,
            },
        ])
        .expect("overlapping request scopes must produce metadata");

        assert!(meta.as_of.is_none());
        assert_eq!(
            meta.as_of_completeness
                .expect("suppressed chain must be disclosed")["1"],
            AsOfCompleteness {
                completeness: Completeness::Unsupported,
                unsupported_reason: TEMPORARILY_UNAVAILABLE.to_owned(),
            }
        );
    }
}
