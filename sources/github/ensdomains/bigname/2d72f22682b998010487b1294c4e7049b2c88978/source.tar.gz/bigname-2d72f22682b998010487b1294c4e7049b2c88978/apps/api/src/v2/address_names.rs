use std::collections::{BTreeMap, BTreeSet};

use crate::AppState;
use axum::{
    Json,
    extract::{Path, State},
};
use bigname_storage::{EffectivePermissionRow, PrimaryNameClaimStatus};
use serde::{Deserialize, Serialize};
use serde_json::Value;

use super::permission_support::{
    apply_role_summary_support_meta, permission_support_for_resources,
};
use super::support::{ensure_public_namespace, parse_evm_address};
use super::{
    Authority, AuthoritySet, Envelope, GrantRelation, Page, QueryParamAllowlist,
    RegistrationStatus, Relation, RelationSet, SortOrder, StrictQueryParams, V2Error, V2Result,
    api_error_to_v2, decode, effective_permission_scope_value, encode,
    name_record::{load_migrated_at, name_registration_fields, registration_id},
    permission_powers_value,
    restrictions::ResourceRestrictions,
    validate_latest_collection_selectors,
};

#[cfg(test)]
#[allow(unused_imports)]
pub(crate) use self::cursor::{
    ADDRESS_FILTER_KEY, ORDER_FILTER_KEY, SORT_KIND_CURSOR_KEY, SORT_KIND_NAME,
    SORT_KIND_TIMESTAMP_NULL, SORT_KIND_TIMESTAMP_VALUE, SORT_VALUE_CURSOR_KEY,
};
pub(crate) use self::cursor::{
    AddressNamesCursorBinding, address_names_cursor_payload, address_names_storage_cursor,
};

mod cursor;
mod former_owner;
mod record_counts;
mod resolves_to;
mod resolves_to_evm;
mod role_summary;
mod row;
mod storage_mapping;

use record_counts::load_address_name_record_counts;

pub(crate) use self::storage_mapping::{
    dedupe_to_storage, order_to_storage, relation_from_storage, relation_set_to_storage,
    sort_to_storage,
};

pub(crate) use self::resolves_to::{AddressNameResolution, address_name_resolution};
#[cfg(test)]
pub(crate) use self::role_summary::grant_read_test_hooks;
pub(crate) use self::row::{build_address_name, permission_resource_handle};

pub(crate) struct AddressNamesQueryParams;

impl QueryParamAllowlist for AddressNamesQueryParams {
    const ALLOWED: &'static [&'static str] = &[
        "namespace",
        "at",
        "finality",
        "relation",
        "coin_type",
        "expires_after",
        "expires_before",
        "authority",
        "is_migrated",
        "parent",
        "q",
        "match",
        "sort",
        "order",
        "dedupe",
        "include",
        "cursor",
        "page_size",
    ];
}

pub(crate) type AddressNamesQuery = StrictQueryParams<AddressNamesQueryParams>;

#[derive(Clone, Debug, Deserialize, PartialEq, Serialize)]
pub(crate) struct AddressName {
    pub(crate) name: String,
    pub(crate) display_name: String,
    pub(crate) namespace: String,
    pub(crate) namehash: String,
    /// Absent only on a `relation=resolves_to` row whose name has no permission authority
    /// resource.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub(crate) permission_resource_id: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub(crate) owner: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub(crate) manager: Option<String>,
    pub(crate) registration_status: RegistrationStatus,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub(crate) registered_at: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub(crate) created_at: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub(crate) expires_at: Option<crate::v2::timestamps::ExpiryTimestamp>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub(crate) expires_at_reason: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub(crate) grace_ends_at: Option<crate::v2::timestamps::ExpiryTimestamp>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub(crate) authority: Option<Authority>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub(crate) ens_v1: Option<crate::v2::name_record::EnsV1>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub(crate) migrated_at: Option<String>,
    pub(crate) relations: Vec<Relation>,
    pub(crate) is_primary: bool,
    /// Present only on `relation=resolves_to` rows: the coin type asked about and the record
    /// key that answered it.
    #[serde(skip_serializing_if = "Option::is_none")]
    pub(crate) resolution: Option<AddressNameResolution>,
    /// Present only on `relation=resolves_to&coin_type=evm` rows: every EVM coin type whose
    /// stored record matched, ascending, with the record key that matched.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub(crate) resolutions: Option<Vec<AddressNameResolution>>,
    /// Present only on `relation=former_owner` rows: the ended registration's last holder,
    /// as name detail serves it.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub(crate) lapsed_registration: Option<crate::v2::name_record::LapsedRegistration>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub(crate) subname_count: Option<u64>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub(crate) record_count: Option<u64>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub(crate) role_summary: Option<Vec<AddressNameRoleSummary>>,
    /// Present with `include=role_summary` when the row's registration has a resource-level
    /// constraint model; the same block `GET /v1/permissions` serves.
    #[serde(skip_serializing_if = "Option::is_none")]
    pub(crate) restrictions: Option<ResourceRestrictions>,
}

#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize)]
pub(crate) struct AddressNameRoleSummary {
    pub(crate) address: String,
    pub(crate) grants: Vec<AddressNameGrant>,
}

#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize)]
pub(crate) struct AddressNameGrant {
    #[serde(skip_serializing_if = "Option::is_none")]
    pub(crate) grant_relation: Option<GrantRelation>,
    pub(crate) grant_scope: Value,
    pub(crate) powers: Value,
}

pub(crate) async fn get_address_names(
    Path(address): Path<String>,
    params: AddressNamesQuery,
    State(state): State<AppState>,
) -> V2Result<Json<Envelope<Vec<AddressName>>>> {
    let params = params.into_inner();
    validate_latest_collection_selectors(params.at.as_ref(), params.finality)?;
    let normalized_address = parse_evm_address(&address, "address").map_err(api_error_to_v2)?;
    if let Some(namespace) = params.namespace.as_deref() {
        ensure_public_namespace(namespace).map_err(api_error_to_v2)?;
    }
    let parent = params
        .parent
        .as_deref()
        .map(super::names::normalize_parent)
        .transpose()?;
    if (params.expires_after.is_some() || params.expires_before.is_some())
        && !params
            .relation
            .as_ref()
            .is_some_and(RelationSet::is_former_owner)
    {
        return Err(V2Error::invalid_input(
            "expires_after and expires_before require relation=former_owner",
        ));
    }
    if params
        .relation
        .as_ref()
        .is_some_and(RelationSet::is_resolves_to)
    {
        return resolves_to::get_address_resolves_to(
            &state,
            &normalized_address,
            &params,
            parent.as_deref(),
        )
        .await;
    }
    if params
        .relation
        .as_ref()
        .is_some_and(RelationSet::is_former_owner)
    {
        return former_owner::get_address_former_owners(
            &state,
            &normalized_address,
            &params,
            parent.as_deref(),
        )
        .await;
    }
    if params.coin_type.is_some() {
        return Err(V2Error::invalid_input(
            "coin_type requires relation=resolves_to",
        ));
    }
    let namespace_filter = params.namespace.clone();
    let include = address_names_include(&params.include)?;
    let include_role_summary = include.role_summary;
    let storage_relations = params
        .relation
        .as_ref()
        .map(relation_set_to_storage)
        .unwrap_or_default();
    let storage_relations = (!storage_relations.is_empty()).then_some(storage_relations.as_slice());
    let storage_dedupe = dedupe_to_storage(params.dedupe);
    let storage_sort = sort_to_storage(params.sort);
    let order = params.order.unwrap_or(SortOrder::Asc);
    let storage_order = order_to_storage(order);
    let normalized_q = params
        .q
        .as_deref()
        .map(|q| params.name_match.normalize(q))
        .transpose()?;
    let authorities = params.authority.as_ref().map(AuthoritySet::wire_values);

    let cursor_binding = AddressNamesCursorBinding {
        address: &normalized_address,
        namespace: namespace_filter.as_deref(),
        relation: params.relation.as_ref(),
        dedupe: params.dedupe,
        q: normalized_q.as_deref(),
        name_match: params.name_match,
        authority: params.authority.as_ref(),
        is_migrated: params.is_migrated,
        parent: parent.as_deref(),
        sort: params.sort,
        order,
    };
    // Validate the position and request filters before publication admission.
    let cursor_payload = params.cursor.as_deref().map(decode).transpose()?;
    let storage_cursor = cursor_payload
        .as_ref()
        .map(|payload| address_names_storage_cursor(payload, &cursor_binding))
        .transpose()?;
    let mut snapshot = super::collection_snapshot::CollectionSnapshot::capture_for_namespace(
        &state,
        params.cursor.as_deref(),
        params.namespace.as_deref(),
    )
    .await?;

    let storage_page = bigname_storage::load_address_names_current_page_filtered(
        snapshot.conn().await?,
        &normalized_address,
        namespace_filter.as_deref(),
        storage_relations,
        storage_dedupe,
        normalized_q
            .as_deref()
            .map(|q| params.name_match.to_storage(q)),
        authorities.as_deref(),
        params.is_migrated,
        parent.as_deref(),
        storage_sort,
        storage_order,
        storage_cursor.as_ref(),
        params.page_size,
    )
    .await
    .map_err(|error| {
        // A chain whose families are not published is stale.
        super::name_rows_error(super::SnapshotReadResource::Resource, |_| {
            V2Error::internal_error(format!(
                "failed to load address names for {normalized_address}"
            ))
        })(error)
    })?;

    let logical_name_ids = storage_page
        .entries
        .iter()
        .map(|entry| entry.logical_name_id.clone())
        .collect::<BTreeSet<_>>()
        .into_iter()
        .collect::<Vec<_>>();
    let name_rows = bigname_storage::load_name_current_by_logical_name_ids(
        snapshot.conn().await?,
        &logical_name_ids,
    )
    .await
    .map_err(super::name_rows_error(
        super::SnapshotReadResource::Resource,
        |_| {
            V2Error::internal_error(format!(
                "failed to load address-name registration summaries for {normalized_address}"
            ))
        },
    ))?;
    let migrated_logical_name_ids = name_rows
        .values()
        .filter(|row| Authority::from_provenance(&row.provenance) == Some(Authority::EnsV2))
        .map(|row| row.logical_name_id.clone())
        .collect::<Vec<_>>();
    let migrated_at_by_name =
        load_migrated_at(snapshot.conn().await?, &migrated_logical_name_ids).await?;
    let primary_names_by_namespace = load_primary_names_by_namespace(
        snapshot.conn().await?,
        &normalized_address,
        storage_page
            .entries
            .iter()
            .map(|entry| entry.namespace.as_str()),
    )
    .await?;
    let role_resource_ids = include_role_summary.then(|| {
        storage_page
            .entries
            .iter()
            .map(|entry| entry.resource_id)
            .collect::<BTreeSet<_>>()
            .into_iter()
            .collect::<Vec<_>>()
    });
    let permission_namespace = namespace_filter.as_deref();
    let permissions_by_resource = if let Some(resource_ids) = role_resource_ids.as_deref() {
        role_summary::load_rows(
            &state,
            &mut snapshot,
            resource_ids,
            permission_namespace,
            storage_page.entries.iter().map(|entry| entry.resource_id),
        )
        .await?
        .into_iter()
        .fold(BTreeMap::new(), |mut grouped, row| {
            grouped
                .entry(row.resource_id)
                .or_insert_with(Vec::new)
                .push(row);
            grouped
        })
    } else {
        std::collections::BTreeMap::new()
    };
    let permission_summaries = if let Some(resource_ids) = role_resource_ids.as_deref() {
        bigname_storage::load_serving_permission_summaries(snapshot.conn().await?, resource_ids)
            .await
            .map_err(crate::v2::name_rows_error(
                crate::v2::SnapshotReadResource::Resource,
                |_| {
                    V2Error::internal_error(format!(
                        "failed to load address-name role support for {normalized_address}"
                    ))
                },
            ))?
    } else {
        BTreeMap::new()
    };
    let subname_counts_by_name = if include.counts {
        bigname_storage::load_children_current_summaries(snapshot.conn().await?, &logical_name_ids)
            .await
            .map_err(super::name_rows_error(
                super::SnapshotReadResource::Resource,
                |_| {
                    V2Error::internal_error(format!(
                        "failed to load address-name subname counts for {normalized_address}"
                    ))
                },
            ))?
            .into_iter()
            .map(|summary| {
                (
                    summary.parent_logical_name_id,
                    u64::try_from(summary.child_count).unwrap_or_default(),
                )
            })
            .collect::<BTreeMap<_, _>>()
    } else {
        BTreeMap::new()
    };
    let record_counts_by_name = if include_role_summary || include.counts {
        load_address_name_record_counts(
            snapshot.conn().await?,
            storage_page
                .entries
                .iter()
                .map(|entry| entry.logical_name_id.as_str()),
            &name_rows,
        )
        .await
        .map_err(super::name_rows_error(
            super::SnapshotReadResource::Resource,
            |_| {
                V2Error::internal_error(format!(
                    "failed to load address-name record counts for {normalized_address}"
                ))
            },
        ))?
    } else {
        BTreeMap::new()
    };

    let next_cursor = storage_page
        .next_cursor
        .as_ref()
        .map(|cursor| encode(&address_names_cursor_payload(cursor, &cursor_binding)));
    let has_more = next_cursor.is_some();
    let data = storage_page
        .entries
        .iter()
        .map(|entry| {
            let role_summary = if include_role_summary {
                Some(build_address_name_role_summary(
                    permissions_by_resource
                        .get(&entry.resource_id)
                        .map(Vec::as_slice)
                        .unwrap_or_default(),
                )?)
            } else {
                None
            };
            let mut row = build_address_name(
                entry,
                name_rows.get(&entry.logical_name_id),
                primary_names_by_namespace
                    .get(&entry.namespace)
                    .and_then(Option::as_deref),
                migrated_at_by_name.get(&entry.logical_name_id).cloned(),
                include.counts.then(|| {
                    subname_counts_by_name
                        .get(&entry.logical_name_id)
                        .copied()
                        .unwrap_or_default()
                }),
                record_counts_by_name.get(&entry.logical_name_id).copied(),
                role_summary,
            )?;
            if include_role_summary {
                row.restrictions = permission_summaries
                    .get(&entry.resource_id)
                    .map(ResourceRestrictions::from_summary)
                    .transpose()?
                    .flatten()
                    .map(|restrictions| {
                        restrictions.for_registration(
                            name_rows
                                .get(&entry.logical_name_id)
                                .and_then(|row| registration_id(&row.declared_summary, None)),
                        )
                    });
            }
            Ok(row)
        })
        .collect::<V2Result<Vec<_>>>()?;
    let mut meta = snapshot.finish(&state).await?;
    if let Some(resource_ids) = role_resource_ids.as_deref() {
        let permission_support =
            permission_support_for_resources(resource_ids, &permission_summaries);
        apply_role_summary_support_meta(&mut meta, permission_support);
    }

    Ok(Json(Envelope {
        data,
        page: Some(Page {
            cursor: params.cursor.clone(),
            next_cursor,
            page_size: params.page_size,
            total_count: Some(storage_page.summary.grouped_entry_count),
            has_more,
        }),
        meta,
    }))
}

async fn load_primary_names_by_namespace<'a>(
    db: impl Into<bigname_storage::ReadDb<'_>>,
    address: &str,
    namespaces: impl Iterator<Item = &'a str>,
) -> V2Result<BTreeMap<String, Option<String>>> {
    let namespaces = namespaces.collect::<BTreeSet<_>>();
    let mut db = db.into();
    let mut primary_names = BTreeMap::new();
    for namespace in namespaces {
        let primary_name = bigname_storage::load_primary_name_current_snapshot(
            db.reborrow(),
            address,
            namespace,
            "60",
        )
        .await
        .map_err(crate::v2::name_rows_error(
            crate::v2::SnapshotReadResource::Resource,
            |_| {
                V2Error::internal_error(format!(
                    "failed to load primary name for address {address}"
                ))
            },
        ))?
        .filter(|snapshot| snapshot.row.claim_status == PrimaryNameClaimStatus::Success)
        .and_then(|snapshot| {
            snapshot
                .normalized_claim_name
                .map(|name| name.trim().to_owned())
                .filter(|name| !name.is_empty())
        });
        primary_names.insert(namespace.to_owned(), primary_name);
    }
    Ok(primary_names)
}

pub(crate) fn build_address_name_role_summary(
    rows: &[EffectivePermissionRow],
) -> V2Result<Vec<AddressNameRoleSummary>> {
    let mut subjects = BTreeMap::<String, Vec<&EffectivePermissionRow>>::new();

    for row in rows {
        subjects.entry(row.subject.clone()).or_default().push(row);
    }

    subjects
        .into_iter()
        .map(|(address, mut rows)| {
            rows.sort_by_key(|row| row.scope.storage_key());
            Ok(AddressNameRoleSummary {
                address,
                grants: rows
                    .into_iter()
                    .map(|row| {
                        Ok(AddressNameGrant {
                            grant_relation: super::permission_grant_relation(row.grant_relation),
                            grant_scope: effective_permission_scope_value(&row.scope)?,
                            powers: permission_powers_value(&row.effective_powers)?,
                        })
                    })
                    .collect::<V2Result<Vec<_>>>()?,
            })
        })
        .collect()
}

#[derive(Clone, Copy, Debug, Default, Eq, PartialEq)]
pub(super) struct AddressNamesInclude {
    pub(super) role_summary: bool,
    pub(super) counts: bool,
}

pub(super) fn address_names_include(include: &[String]) -> V2Result<AddressNamesInclude> {
    let mut parsed = AddressNamesInclude::default();
    for value in include {
        match value.as_str() {
            "role_summary" => parsed.role_summary = true,
            "counts" => parsed.counts = true,
            _ => {
                return Err(V2Error::invalid_input(
                    "include must contain only role_summary or counts",
                ));
            }
        }
    }
    Ok(parsed)
}

#[cfg(test)]
mod tests;
