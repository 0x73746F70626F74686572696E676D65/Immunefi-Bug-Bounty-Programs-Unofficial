#[allow(dead_code)]
mod support;
use std::collections::BTreeMap;

use anyhow::Result;
use axum::{Json, Router, extract::State, routing::post};
use bigname_ingest::{RpcChainCheck, VerificationProvider};
use phase_runner::{
    config::{SeedBasis, SourceConfig, SourceRole},
    phase::{PhaseName, RunMode},
    phase_lock::PhaseLock,
    source_transport::{transition, transition_with_readers},
    state::{PhaseStore, StartDisposition},
};
use serde_json::{Value, json};
use sqlx::Row as _;
use support::ScratchDatabase;
use tokio::net::TcpListener;
use uuid::Uuid;

const SEPOLIA: &str = "ethereum-sepolia";
const CONTRACT: &str = "0x0000000000000000000000000000000000000004";
const TRANSFER_TOPIC: &str = "0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef";

#[tokio::test]
async fn active_writer_refuses_transport_change_before_provider_access() -> Result<()> {
    let db = ScratchDatabase::create("source_transport_lock").await?;
    let old = source("drpc", "http://127.0.0.1:1")?;
    let new = source("reth_db", "/missing/reth")?;
    for phase in PhaseName::ALL {
        let lock = PhaseLock::acquire(db.writer_connect_options(), SEPOLIA, phase).await?;
        let error = transition(&db.runner(), &old, &new, RpcChainCheck::ChainIdOnly)
            .await
            .unwrap_err();
        assert!(
            error.to_string().contains("stop all phase writers"),
            "{error:#}"
        );
        lock.release().await?;
    }
    let count: i64 = sqlx::query_scalar("SELECT count(*) FROM ingest_cursors")
        .fetch_one(db.pool())
        .await?;
    assert_eq!(count, 0);
    db.cleanup().await
}

#[tokio::test]
async fn direct_reader_without_a_datadir_is_refused_and_changes_nothing() -> Result<()> {
    let db = ScratchDatabase::create("source_transport_no_datadir").await?;
    seed_watch_set(db.pool()).await?;
    seed_ingest(db.pool(), "drpc", Redo::None).await?;
    let (rpc, server) = NodeDouble::through(6).spawn().await?;
    let datadir = std::env::temp_dir().join(format!("source-transport-{}", Uuid::new_v4()));
    std::fs::create_dir_all(&datadir)?;
    let before = snapshot(db.pool()).await?;

    let error = transition(
        &db.runner(),
        &source("drpc", &rpc)?,
        &source("reth_db", datadir.to_str().expect("utf-8 temp path"))?,
        RpcChainCheck::ChainIdOnly,
    )
    .await
    .expect_err("an empty directory is not a Reth datadir");

    // Standard builds refuse the unavailable reader; opt-in builds reject the datadir.
    let message = format!("{error:#}");
    assert!(
        message.contains("is missing")
            || message.contains("Reth DB support was not compiled; enable the reth-db feature"),
        "{message}"
    );
    assert_eq!(before, snapshot(db.pool()).await?);
    server.abort();
    std::fs::remove_dir_all(datadir)?;
    db.cleanup().await
}

#[tokio::test]
async fn a_refused_change_releases_the_phase_writer_locks_before_it_returns() -> Result<()> {
    let db = ScratchDatabase::create("source_transport_refusal_locks").await?;
    seed_watch_set(db.pool()).await?;
    seed_ingest(db.pool(), "drpc", Redo::None).await?;
    let node = NodeDouble::through(6).with_watched_log(6);
    let forked = node.clone().with_hash(5, block_hash(1_005));
    // A second session is open before the refusal. Its probe is one unprepared statement
    // (simple query protocol, no bind parameters), so the lock attempt is the first thing
    // this connection sends after the refusal; a prepared query would yield to the runtime
    // on its Parse round trip first, and that yield is when a dropped transaction's queued
    // rollback gets flushed.
    let mut probe = db.pool().begin().await?;

    switch(&db, "drpc", &node, "reth_db", &forked)
        .await
        .expect_err("the two interfaces disagree at the retained boundary");

    let attempts = PhaseName::ALL
        .iter()
        .map(|phase| {
            format!(
                "pg_try_advisory_xact_lock(hashtextextended('phase-runner:{SEPOLIA}:{phase}', \
                 0::bigint))"
            )
        })
        .collect::<Vec<_>>()
        .join(", ");
    let row = sqlx::raw_sql(&format!("SELECT {attempts}"))
        .fetch_one(&mut *probe)
        .await?;
    for (index, phase) in PhaseName::ALL.iter().enumerate() {
        let free: bool = row.try_get(index)?;
        assert!(
            free,
            "the refused change still holds the {phase} writer lock after reporting its error"
        );
    }
    probe.rollback().await?;
    db.cleanup().await
}

#[tokio::test]
async fn matching_node_interfaces_change_only_the_stored_source_kind() -> Result<()> {
    let db = ScratchDatabase::create("source_transport_success").await?;
    seed_watch_set(db.pool()).await?;
    seed_ingest(db.pool(), "drpc", Redo::None).await?;
    let node = NodeDouble::through(6).with_watched_log(6);
    let before = snapshot(db.pool()).await?;

    let receipt = switch(&db, "drpc", &node, "reth_db", &node).await?;

    assert_eq!(receipt["from_kind"], "drpc");
    assert_eq!(receipt["to_kind"], "reth_db");
    assert_eq!(receipt["previous_cursor"], before["cursors"][0]);
    assert_eq!(receipt["ingest_phase"], before["phases"][0]);
    assert_eq!(
        receipt["checked_boundaries"],
        json!([
            {"block": 5, "hash": block_hash(5)},
            {"block": 5, "hash": block_hash(5)}
        ]),
        "the cursor boundary and the Ingest phase boundary are both checked"
    );
    assert_eq!(receipt["next_block"], 6);
    assert_eq!(receipt["compared_block"], 6);
    assert_eq!(receipt["compared_block_hash"], block_hash(6));
    assert_eq!(receipt["compared_block_log_count"], 1);
    assert_eq!(receipt["live_continuation"], Value::Null);
    assert_eq!(
        snapshot(db.pool()).await?,
        with_stored_kind(before, "reth_db"),
        "only the stored source kind may change; progress, retained hashes, phase state, \
         lineage, raw logs and manifests stay as they were"
    );
    db.cleanup().await
}

#[tokio::test]
async fn reverse_switch_restores_the_http_source_kind() -> Result<()> {
    let db = ScratchDatabase::create("source_transport_reverse").await?;
    seed_watch_set(db.pool()).await?;
    seed_ingest(db.pool(), "drpc", Redo::None).await?;
    let node = NodeDouble::through(6).with_watched_log(6);
    let original = snapshot(db.pool()).await?;

    switch(&db, "drpc", &node, "reth_db", &node).await?;
    let error = switch(&db, "drpc", &node, "reth_db", &node)
        .await
        .expect_err("the stored kind is no longer drpc");
    assert!(
        error.to_string().contains("stored source kind differs"),
        "{error:#}"
    );
    let receipt = switch(&db, "reth_db", &node, "drpc", &node).await?;

    assert_eq!(receipt["from_kind"], "reth_db");
    assert_eq!(receipt["to_kind"], "drpc");
    assert_eq!(snapshot(db.pool()).await?, original);
    db.cleanup().await
}

#[tokio::test]
async fn retained_boundary_hash_mismatch_is_refused() -> Result<()> {
    let db = ScratchDatabase::create("source_transport_boundary").await?;
    seed_watch_set(db.pool()).await?;
    seed_ingest(db.pool(), "drpc", Redo::None).await?;
    let node = NodeDouble::through(6);
    let forked = node.clone().with_hash(5, block_hash(1_005));
    let before = snapshot(db.pool()).await?;

    // The new interface is on another fork at the retained boundary.
    let error = switch(&db, "drpc", &node, "reth_db", &forked)
        .await
        .expect_err("the two interfaces disagree at the retained boundary");
    assert!(
        error
            .to_string()
            .contains("retained boundary differs at block 5"),
        "{error:#}"
    );
    // Both interfaces agree with each other but not with the hash Ingest retained.
    let error = switch(&db, "drpc", &forked, "reth_db", &forked)
        .await
        .expect_err("the node does not hold the retained boundary block");
    assert!(
        error
            .to_string()
            .contains("retained boundary differs at block 5"),
        "{error:#}"
    );

    assert_eq!(before, snapshot(db.pool()).await?);
    db.cleanup().await
}

#[tokio::test]
async fn next_block_mismatch_is_refused() -> Result<()> {
    let db = ScratchDatabase::create("source_transport_next_block").await?;
    seed_watch_set(db.pool()).await?;
    seed_ingest(db.pool(), "drpc", Redo::None).await?;
    let node = NodeDouble::through(6).with_watched_log(6);
    let before = snapshot(db.pool()).await?;

    let other_hash = NodeDouble::through(6)
        .with_hash(6, block_hash(1_006))
        .with_watched_log(6);
    let missing_log = NodeDouble::through(6);
    for other in [&other_hash, &missing_log] {
        let error = switch(&db, "drpc", &node, "reth_db", other)
            .await
            .expect_err("the two interfaces disagree about the next block");
        assert!(
            error.to_string().contains("next block data differs"),
            "{error:#}"
        );
    }

    assert_eq!(before, snapshot(db.pool()).await?);
    db.cleanup().await
}

#[tokio::test]
async fn redo_in_progress_checks_the_redo_position_and_keeps_the_redo() -> Result<()> {
    let db = ScratchDatabase::create("source_transport_redo").await?;
    seed_watch_set(db.pool()).await?;
    seed_ingest(db.pool(), "drpc", Redo::ResumedAt(3)).await?;
    let node = NodeDouble::through(6)
        .with_watched_log(4)
        .with_watched_log(6);
    let before = snapshot(db.pool()).await?;

    // The redo resumes at block 4, so that is the block whose logs must match.
    let disagrees_at_redo_position = NodeDouble::through(6).with_watched_log(6);
    let error = switch(&db, "drpc", &node, "reth_db", &disagrees_at_redo_position)
        .await
        .expect_err("the two interfaces disagree about the block the redo reads next");
    assert!(
        error.to_string().contains("next block data differs"),
        "{error:#}"
    );
    let forked_at_redo_boundary = node.clone().with_hash(3, block_hash(1_003));
    let error = switch(&db, "drpc", &node, "reth_db", &forked_at_redo_boundary)
        .await
        .expect_err("the two interfaces disagree at the redo's retained boundary");
    assert!(
        error
            .to_string()
            .contains("retained boundary differs at block 3"),
        "{error:#}"
    );
    assert_eq!(before, snapshot(db.pool()).await?);

    let receipt = switch(&db, "drpc", &node, "reth_db", &node).await?;

    assert_eq!(receipt["next_block"], 4);
    assert_eq!(receipt["compared_block_log_count"], 1);
    assert_eq!(
        receipt["checked_boundaries"][2],
        json!({"block": 3, "hash": block_hash(3)})
    );
    assert_eq!(
        snapshot(db.pool()).await?,
        with_stored_kind(before, "reth_db"),
        "the redo range, its position and its retained hash are untouched"
    );
    db.cleanup().await
}

#[tokio::test]
async fn redo_that_has_not_started_checks_its_first_block() -> Result<()> {
    let db = ScratchDatabase::create("source_transport_redo_start").await?;
    seed_watch_set(db.pool()).await?;
    seed_ingest(db.pool(), "drpc", Redo::NotStarted).await?;
    let node = NodeDouble::through(6).with_watched_log(2);
    let before = snapshot(db.pool()).await?;

    let receipt = switch(&db, "drpc", &node, "reth_db", &node).await?;

    assert_eq!(receipt["next_block"], 2);
    assert_eq!(receipt["compared_block_log_count"], 1);
    assert_eq!(
        snapshot(db.pool()).await?,
        with_stored_kind(before, "reth_db")
    );
    db.cleanup().await
}

#[tokio::test]
async fn direct_reader_floor_above_the_declared_start_refuses_unfinished_normal_ingest()
-> Result<()> {
    let db = ScratchDatabase::create("source_transport_floor_normal").await?;
    seed_watch_set(db.pool()).await?;
    seed_ingest(db.pool(), "drpc", Redo::None).await?;
    // Ingest still has catch-up work: it stands at block 5 with a target of 8.
    sqlx::query(
        "UPDATE chain_phase_state
         SET phase_status = 'running', finished_at = NULL,
             target_block_number = 8, target_block_hash = $2
         WHERE chain_id = $1 AND phase_name = 'ingest'",
    )
    .bind(SEPOLIA)
    .bind(block_hash(8))
    .execute(db.pool())
    .await?;
    let node = NodeDouble::through(8).with_watched_log(6);
    let before = snapshot(db.pool()).await?;

    // The node has pruned history below block 3. The retained boundary (5) and the next
    // block (6) are both readable, so every comparison passes; only the floor differs.
    let error = switch_to_direct_reader_with_floor(&db, &node, 3)
        .await
        .expect_err("resumed normal Ingest plans from the declared start block 0");

    let message = format!("{error:#}");
    assert!(
        message.contains("cannot serve the Ingest work that resumes after this change")
            && message.contains("keeps history from block 3 only")
            && message.contains("0..=head"),
        "{message}"
    );
    assert_eq!(before, snapshot(db.pool()).await?);

    // A node that still holds the declared range is admitted.
    switch_to_direct_reader_with_floor(&db, &node, 0).await?;
    assert_eq!(
        snapshot(db.pool()).await?,
        with_stored_kind(before, "reth_db")
    );
    db.cleanup().await
}

#[tokio::test]
async fn direct_reader_floor_is_judged_on_the_remaining_redo_suffix() -> Result<()> {
    let db = ScratchDatabase::create("source_transport_floor_redo").await?;
    seed_watch_set(db.pool()).await?;
    seed_ingest(db.pool(), "drpc", Redo::ResumedAt(3)).await?;
    let node = NodeDouble::through(6)
        .with_watched_log(4)
        .with_watched_log(6);
    let before = snapshot(db.pool()).await?;

    // The redo of 2..=5 resumes at block 4; a floor of 5 leaves block 4 unreadable.
    let error = switch_to_direct_reader_with_floor(&db, &node, 5)
        .await
        .expect_err("the redo still has to read block 4");
    let message = format!("{error:#}");
    assert!(
        message.contains("keeps history from block 5 only") && message.contains("4..=5"),
        "{message}"
    );
    assert_eq!(before, snapshot(db.pool()).await?);

    // Blocks 2 and 3 are already re-read, so a floor of 4 admits what remains.
    switch_to_direct_reader_with_floor(&db, &node, 4).await?;
    assert_eq!(
        snapshot(db.pool()).await?,
        with_stored_kind(before, "reth_db")
    );
    db.cleanup().await
}

#[tokio::test]
async fn direct_reader_floor_is_judged_on_the_whole_range_of_an_unstarted_redo() -> Result<()> {
    let db = ScratchDatabase::create("source_transport_floor_redo_start").await?;
    seed_watch_set(db.pool()).await?;
    seed_ingest(db.pool(), "drpc", Redo::NotStarted).await?;
    let node = NodeDouble::through(6).with_watched_log(2);
    let before = snapshot(db.pool()).await?;

    let error = switch_to_direct_reader_with_floor(&db, &node, 3)
        .await
        .expect_err("the redo of 2..=5 has not read block 2 yet");
    let message = format!("{error:#}");
    assert!(
        message.contains("keeps history from block 3 only") && message.contains("2..=5"),
        "{message}"
    );
    assert_eq!(before, snapshot(db.pool()).await?);

    switch_to_direct_reader_with_floor(&db, &node, 2).await?;
    assert_eq!(
        snapshot(db.pool()).await?,
        with_stored_kind(before, "reth_db")
    );
    db.cleanup().await
}

#[tokio::test]
async fn direct_reader_floor_is_judged_on_the_live_suffix_after_ingest_completed() -> Result<()> {
    let db = ScratchDatabase::create("source_transport_floor_live").await?;
    seed_watch_set(db.pool()).await?;
    seed_ingest(db.pool(), "drpc", Redo::None).await?;
    // Ingest is complete: it handed block 5 to live follow, which reads from block 6.
    hand_off_to_live(db.pool()).await?;
    seed_published_head(db.pool(), 5).await?;
    let node = NodeDouble::through(6).with_watched_log(6);
    let before = snapshot(db.pool()).await?;

    let error = switch_to_direct_reader_with_floor(&db, &node, 7)
        .await
        .expect_err("live follow reads block 6 next");
    let message = format!("{error:#}");
    assert!(
        message.contains("keeps history from block 7 only") && message.contains("6..=head"),
        "{message}"
    );
    assert_eq!(before, snapshot(db.pool()).await?);

    switch_to_direct_reader_with_floor(&db, &node, 6).await?;
    assert_eq!(
        snapshot(db.pool()).await?,
        with_stored_kind(before, "reth_db")
    );
    db.cleanup().await
}

#[tokio::test]
async fn direct_reader_floor_is_judged_where_live_follow_resumes_not_at_the_handoff() -> Result<()>
{
    let db = ScratchDatabase::create("source_transport_floor_live_resumed").await?;
    seed_watch_set(db.pool()).await?;
    seed_ingest(db.pool(), "drpc", Redo::None).await?;
    hand_off_to_live(db.pool()).await?;
    // Live follow has since published through block 10. The historical Ingest cursor still
    // says 6: live progress never advances it. The node is unchanged and stands at 11.
    seed_published_head(db.pool(), 10).await?;
    let node = NodeDouble::through(11)
        .with_watched_log(6)
        .with_watched_log(11);
    let before = snapshot(db.pool()).await?;

    // The node pruned history below block 7. Live follow needs block 11 next, which it holds.
    let receipt = switch_to_direct_reader_with_floor(&db, &node, 7).await?;

    assert_eq!(receipt["next_block"], 11);
    assert_eq!(receipt["compared_block"], 11);
    assert_eq!(receipt["compared_block_hash"], block_hash(11));
    assert_eq!(receipt["compared_block_log_count"], 1);
    assert_eq!(
        receipt["live_continuation"],
        json!({
            "ancestor": {"number": 10, "hash": block_hash(10)},
            "node_head": {"number": 11, "hash": block_hash(11)}
        })
    );
    assert_eq!(
        snapshot(db.pool()).await?,
        with_stored_kind(before, "reth_db"),
        "the historical Ingest cursor keeps its next block 6; only the stored kind changes"
    );
    db.cleanup().await
}

#[tokio::test]
async fn live_continuation_below_the_direct_reader_floor_is_refused() -> Result<()> {
    let db = ScratchDatabase::create("source_transport_floor_live_reorg").await?;
    seed_watch_set(db.pool()).await?;
    seed_ingest(db.pool(), "drpc", Redo::None).await?;
    hand_off_to_live(db.pool()).await?;
    seed_published_head(db.pool(), 10).await?;
    // The node reorganized: from block 6 on it holds other blocks than live follow published,
    // so live follow resumes from block 6, the last block both still share.
    let mut node = NodeDouble::through(11);
    for number in 6..=11 {
        node = node.with_hash(number, block_hash(1_000 + number));
    }
    let node = node.with_watched_log(6);
    let before = snapshot(db.pool()).await?;

    let error = switch_to_direct_reader_with_floor(&db, &node, 7)
        .await
        .expect_err("live follow has to read block 6, which the node pruned");

    let message = format!("{error:#}");
    assert!(
        message.contains("keeps history from block 7 only") && message.contains("6..=head"),
        "{message}"
    );
    assert_eq!(before, snapshot(db.pool()).await?);
    db.cleanup().await
}

#[tokio::test]
async fn caught_up_live_follow_compares_the_published_head_and_admits_the_direct_reader()
-> Result<()> {
    let db = ScratchDatabase::create("source_transport_floor_live_caught_up").await?;
    seed_watch_set(db.pool()).await?;
    seed_ingest(db.pool(), "drpc", Redo::None).await?;
    hand_off_to_live(db.pool()).await?;
    // Live follow published the node's head. Its next block, 11, does not exist yet, so the
    // block both interfaces are compared on is the published head itself.
    seed_published_head(db.pool(), 10).await?;
    let node = NodeDouble::through(10)
        .with_watched_log(6)
        .with_watched_log(10);
    let before = snapshot(db.pool()).await?;

    let error = switch_to_direct_reader_with_floor(&db, &node, 12)
        .await
        .expect_err("the floor still applies to the block live follow loads next");
    let message = format!("{error:#}");
    assert!(
        message.contains("keeps history from block 12 only") && message.contains("11..=head"),
        "{message}"
    );
    assert_eq!(before, snapshot(db.pool()).await?);

    let receipt = switch_to_direct_reader_with_floor(&db, &node, 7).await?;

    assert_eq!(receipt["next_block"], 11);
    assert_eq!(receipt["compared_block"], 10);
    assert_eq!(receipt["compared_block_hash"], block_hash(10));
    assert_eq!(receipt["compared_block_log_count"], 1);
    assert_eq!(
        snapshot(db.pool()).await?,
        with_stored_kind(before, "reth_db")
    );
    db.cleanup().await
}

#[tokio::test]
async fn retained_completion_awaiting_revalidation_is_judged_as_handed_off() -> Result<()> {
    let db = ScratchDatabase::create("source_transport_floor_retained_completion").await?;
    seed_watch_set(db.pool()).await?;
    seed_ingest(db.pool(), "drpc", Redo::None).await?;
    hand_off_to_live(db.pool()).await?;
    seed_published_head(db.pool(), 5).await?;
    // A completed-phase validation failed after the handoff. The runner keeps the completed
    // extent and revalidates it on the next start instead of rescanning from block 0.
    fail_completed_validation(
        db.pool(),
        "completed phase validation failed: source changed",
    )
    .await?;
    let node = NodeDouble::through(6).with_watched_log(6);
    let before = snapshot(db.pool()).await?;
    assert_eq!(
        PhaseStore::new(db.pool().clone())
            .start_phase(SEPOLIA, PhaseName::Ingest, &RunMode::Normal)
            .await?,
        StartDisposition::RecoveringCompleted,
        "the runner revalidates this state without a historical rescan"
    );

    let receipt = switch_to_direct_reader_with_floor(&db, &node, 3).await?;

    assert_eq!(receipt["next_block"], 6);
    assert_eq!(receipt["compared_block"], 6);
    assert_eq!(receipt["compared_block_log_count"], 1);
    assert_eq!(
        snapshot(db.pool()).await?,
        with_stored_kind(before, "reth_db"),
        "the failed status, its error and the completed markers are untouched"
    );
    db.cleanup().await
}

#[tokio::test]
async fn ordinary_failed_or_incomplete_ingest_still_replans_from_the_declared_start() -> Result<()>
{
    let db = ScratchDatabase::create("source_transport_floor_failed_ingest").await?;
    seed_watch_set(db.pool()).await?;
    seed_ingest(db.pool(), "drpc", Redo::None).await?;
    seed_published_head(db.pool(), 5).await?;
    let node = NodeDouble::through(6).with_watched_log(6);

    // Failed without the completed-validation marker: a normal restart from block 0.
    fail_completed_validation(db.pool(), "provider unreachable").await?;
    let before = snapshot(db.pool()).await?;
    let error = switch_to_direct_reader_with_floor(&db, &node, 3)
        .await
        .expect_err("a failed catch-up replans from the declared start block 0");
    let message = format!("{error:#}");
    assert!(
        message.contains("keeps history from block 3 only") && message.contains("0..=head"),
        "{message}"
    );
    assert_eq!(before, snapshot(db.pool()).await?);

    // The marker alone is not a retained completion: this pass never handed off to live
    // follow, so the runner restarts it from the declared start as well.
    fail_completed_validation(
        db.pool(),
        "completed phase validation failed: source changed",
    )
    .await?;
    let before = snapshot(db.pool()).await?;
    let error = switch_to_direct_reader_with_floor(&db, &node, 3)
        .await
        .expect_err("without a live handoff the completed extent is not retained");
    assert!(format!("{error:#}").contains("0..=head"), "{error:#}");
    assert_eq!(before, snapshot(db.pool()).await?);
    db.cleanup().await
}

#[tokio::test]
async fn exhausted_redo_at_the_node_head_is_judged_on_the_work_that_follows_it() -> Result<()> {
    let db = ScratchDatabase::create("source_transport_redo_exhausted").await?;
    seed_watch_set(db.pool()).await?;
    // The redo of 2..=5 read its last block, and the process stopped before finish_redo
    // cleared the marker. The pass it interrupted had completed and handed block 5 to live
    // follow, so once the marker clears the runner's next act is live follow, not a fetch of
    // block 6 for the redo.
    seed_ingest(db.pool(), "drpc", Redo::ResumedAt(5)).await?;
    hand_off_to_live(db.pool()).await?;
    seed_published_head(db.pool(), 5).await?;
    // The redo ended at the node's head: there is no block 6 to read anywhere.
    let node = NodeDouble::through(5).with_watched_log(5);
    let before = snapshot(db.pool()).await?;

    let receipt = switch_to_direct_reader_with_floor(&db, &node, 3).await?;

    assert_eq!(receipt["next_block"], 6);
    assert_eq!(receipt["compared_block"], 5);
    assert_eq!(receipt["compared_block_log_count"], 1);
    assert_eq!(
        receipt["checked_boundaries"][2],
        json!({"block": 5, "hash": block_hash(5)}),
        "the redo's own boundary is still checked"
    );
    assert_eq!(
        snapshot(db.pool()).await?,
        with_stored_kind(before, "reth_db"),
        "the redo marker, its position and the interrupted lifecycle are untouched"
    );
    db.cleanup().await
}

#[tokio::test]
async fn candidate_reader_without_checkpoint_heads_is_refused_before_live_follow_would_be()
-> Result<()> {
    let db = ScratchDatabase::create("source_transport_live_checkpoints").await?;
    seed_watch_set(db.pool()).await?;
    seed_ingest(db.pool(), "drpc", Redo::None).await?;
    hand_off_to_live(db.pool()).await?;
    seed_published_head(db.pool(), 5).await?;
    // The candidate answers for its latest block but has no safe or finalized head. Live
    // follow refuses such a provider on its first batch, so the switch must refuse it now.
    let node = NodeDouble::through(6)
        .with_watched_log(6)
        .without_checkpoint_heads();
    let before = snapshot(db.pool()).await?;

    let error = switch(&db, "drpc", &node, "reth_db", &node)
        .await
        .expect_err("live follow would reject this reader on its first batch");

    assert!(
        format!("{error:#}")
            .contains("live provider must report safe and finalized checkpoint heads"),
        "{error:#}"
    );
    assert_eq!(before, snapshot(db.pool()).await?);
    db.cleanup().await
}

#[tokio::test]
async fn exhausted_redo_of_an_unfinished_pass_replans_from_the_declared_start() -> Result<()> {
    let db = ScratchDatabase::create("source_transport_redo_exhausted_declared").await?;
    seed_watch_set(db.pool()).await?;
    // The pass the redo interrupted never handed off to live follow, so once the marker
    // clears the runner restarts normal Ingest from the declared start.
    seed_ingest(db.pool(), "drpc", Redo::ResumedAt(5)).await?;
    let node = NodeDouble::through(6).with_watched_log(6);
    let before = snapshot(db.pool()).await?;

    let error = switch_to_direct_reader_with_floor(&db, &node, 3)
        .await
        .expect_err("the restored pass replans from block 0");
    assert!(format!("{error:#}").contains("0..=head"), "{error:#}");
    assert_eq!(before, snapshot(db.pool()).await?);

    let receipt = switch_to_direct_reader_with_floor(&db, &node, 0).await?;

    assert_eq!(receipt["next_block"], 6);
    assert_eq!(receipt["compared_block"], 6);
    assert_eq!(receipt["live_continuation"], Value::Null);
    assert_eq!(
        snapshot(db.pool()).await?,
        with_stored_kind(before, "reth_db")
    );
    db.cleanup().await
}

#[tokio::test]
async fn exhausted_redo_with_the_node_ahead_compares_the_block_live_follow_loads_next() -> Result<()>
{
    let db = ScratchDatabase::create("source_transport_redo_exhausted_ahead").await?;
    seed_watch_set(db.pool()).await?;
    seed_ingest(db.pool(), "drpc", Redo::ResumedAt(5)).await?;
    hand_off_to_live(db.pool()).await?;
    seed_published_head(db.pool(), 5).await?;
    // The node moved on to block 6 while the redo was finishing.
    let node = NodeDouble::through(6).with_watched_log(6);
    let before = snapshot(db.pool()).await?;

    let receipt = switch_to_direct_reader_with_floor(&db, &node, 3).await?;

    assert_eq!(receipt["next_block"], 6);
    assert_eq!(receipt["compared_block"], 6);
    assert_eq!(receipt["compared_block_log_count"], 1);
    assert_eq!(
        receipt["live_continuation"]["ancestor"],
        json!({"number": 5, "hash": block_hash(5)})
    );
    assert_eq!(
        snapshot(db.pool()).await?,
        with_stored_kind(before, "reth_db")
    );
    db.cleanup().await
}

#[tokio::test]
async fn compared_block_is_judged_with_the_watch_set_ingest_would_use() -> Result<()> {
    let db = ScratchDatabase::create("source_transport_announced_emitter").await?;
    seed_watch_set(db.pool()).await?;
    seed_ingest(db.pool(), "drpc", Redo::None).await?;
    seed_published_head(db.pool(), 5).await?;
    // An ENSv2 resolver announced itself in canonical block 4. Ingest has retained that
    // announcement as a raw log but Interpret has not yet persisted a discovery edge for it,
    // so only the announcement supplement Ingest applies to its watch set knows the emitter.
    let (announced_emitter, scoped_topic0) = seed_resolver_announcement(db.pool(), 4).await?;
    let node =
        NodeDouble::through(6)
            .with_watched_log(6)
            .with_log(6, announced_emitter, &scoped_topic0);
    let candidate_missing_the_log = NodeDouble::through(6).with_watched_log(6);
    let before = snapshot(db.pool()).await?;

    let error = switch(&db, "drpc", &node, "reth_db", &candidate_missing_the_log)
        .await
        .expect_err("the next Ingest batch reads the announced emitter's logs at block 6");

    assert!(
        error.to_string().contains("next block data differs"),
        "{error:#}"
    );
    assert_eq!(before, snapshot(db.pool()).await?);

    let receipt = switch(&db, "drpc", &node, "reth_db", &node).await?;
    assert_eq!(receipt["compared_block_log_count"], 2);
    db.cleanup().await
}

#[tokio::test]
async fn reth_spelled_direct_reader_can_roll_back_to_the_http_interface() -> Result<()> {
    let db = ScratchDatabase::create("source_transport_reth_alias").await?;
    seed_watch_set(db.pool()).await?;
    // A Sepolia deployment configured with source kind `reth`, the accepted spelling of the
    // direct reader that the cursor stores as written.
    seed_ingest(db.pool(), "reth", Redo::None).await?;
    let node = NodeDouble::through(6).with_watched_log(6);
    let before = snapshot(db.pool()).await?;

    let receipt = switch(&db, "reth", &node, "drpc", &node).await?;

    assert_eq!(receipt["from_kind"], "reth");
    assert_eq!(receipt["to_kind"], "drpc");
    assert_eq!(
        snapshot(db.pool()).await?,
        with_stored_kind(before.clone(), "drpc")
    );
    let receipt = switch(&db, "drpc", &node, "reth", &node).await?;
    assert_eq!(receipt["to_kind"], "reth");
    assert_eq!(snapshot(db.pool()).await?, before);
    db.cleanup().await
}

#[tokio::test]
async fn candidate_reader_without_checkpoint_heads_is_refused_before_normal_ingest_would_be()
-> Result<()> {
    let db = ScratchDatabase::create("source_transport_ingest_checkpoints").await?;
    seed_watch_set(db.pool()).await?;
    // Ingest is completed but never handed off, so it replans a normal batch from the
    // declared start; that batch requires safe and finalized heads before it plans anything.
    seed_ingest(db.pool(), "drpc", Redo::None).await?;
    let node = NodeDouble::through(6)
        .with_watched_log(6)
        .without_checkpoint_heads();
    let before = snapshot(db.pool()).await?;

    let error = switch(&db, "drpc", &node, "reth_db", &node)
        .await
        .expect_err("the next normal Ingest batch would reject this reader");

    assert!(
        format!("{error:#}")
            .contains("ingest provider must report safe and finalized checkpoint heads"),
        "{error:#}"
    );
    assert_eq!(before, snapshot(db.pool()).await?);
    db.cleanup().await
}

#[tokio::test]
async fn redo_target_missing_on_the_candidate_is_refused() -> Result<()> {
    let db = ScratchDatabase::create("source_transport_redo_target").await?;
    seed_watch_set(db.pool()).await?;
    // Ingest handed off at 5 and live follow published through 10, so an Ingest redo may
    // extend up to the published head (redo_extent): this one covers 2..=8 and resumes at
    // block 4. A redo batch first resolves the range's last block on its source.
    seed_ingest(db.pool(), "drpc", Redo::ResumedAt(3)).await?;
    hand_off_to_live(db.pool()).await?;
    seed_published_head(db.pool(), 10).await?;
    sqlx::query(
        "UPDATE chain_phase_state SET redo_to_block_number = 8
         WHERE chain_id = $1 AND phase_name = 'ingest'",
    )
    .bind(SEPOLIA)
    .execute(db.pool())
    .await?;
    let node = NodeDouble::through(10).with_watched_log(4);
    // Holds every retained boundary and the next block, but not block 8.
    let candidate_behind_the_target = NodeDouble::through(6).with_watched_log(4);
    let before = snapshot(db.pool()).await?;

    let error = switch(&db, "drpc", &node, "reth_db", &candidate_behind_the_target)
        .await
        .expect_err("the resumed redo batch resolves block 8 first");

    assert!(format!("{error:#}").contains("redo target"), "{error:#}");
    assert_eq!(before, snapshot(db.pool()).await?);

    let receipt = switch(&db, "drpc", &node, "reth_db", &node).await?;
    assert_eq!(receipt["next_block"], 4);
    assert_eq!(
        receipt["redo_target"],
        json!({"block": 8, "hash": block_hash(8)})
    );
    db.cleanup().await
}

#[tokio::test]
async fn retained_normal_target_missing_on_the_candidate_is_refused() -> Result<()> {
    let db = ScratchDatabase::create("source_transport_normal_target").await?;
    seed_watch_set(db.pool()).await?;
    seed_ingest(db.pool(), "drpc", Redo::None).await?;
    // A normal batch selects the node's latest block as its target and retains that target
    // in SourceProgress even when only its first window completes. The runner persists it
    // separately from the cursor position (state_ingest_progress::upsert_ingest_cursor),
    // and the resumed engine resolves that same target before loading the next window.
    sqlx::query(
        "UPDATE ingest_cursors SET next_block_number = 256, target_block_number = 1000,
            last_processed_block_number = 255, last_processed_block_hash = $2
         WHERE chain_id = $1",
    )
    .bind(SEPOLIA)
    .bind(block_hash(255))
    .execute(db.pool())
    .await?;
    sqlx::query(
        "UPDATE chain_phase_state SET phase_status = 'failed', finished_at = now(),
            last_error = 'normal batch interrupted', current_block_number = 255,
            current_block_hash = $2, target_block_number = 1000, target_block_hash = $3
         WHERE chain_id = $1 AND phase_name = 'ingest'",
    )
    .bind(SEPOLIA)
    .bind(block_hash(255))
    .bind(block_hash(1000))
    .execute(db.pool())
    .await?;
    let node = NodeDouble::through(1000).with_watched_log(256);
    // Both checkpoint heads exist, and all retained boundaries and the next block match.
    // This reader lacks only the higher retained target; its retention floor is zero.
    let behind = NodeDouble::through(998).with_watched_log(256);
    let before = snapshot(db.pool()).await?;
    let mut probe = db.pool().begin().await?;

    let error = switch_with_readers(&db, "drpc", &node, "reth_db", &behind, |source| {
        let provider = VerificationProvider::new(SEPOLIA, "drpc", source.endpoint())?;
        Ok(if source.source_kind == "reth_db" {
            provider.with_declared_retention_floor(0)
        } else {
            provider
        })
    })
    .await
    .expect_err("normal Ingest resolves its retained target before reading block 256");
    assert!(
        format!("{error:#}").contains("normal Ingest target block 1000 is not readable"),
        "{error:#}"
    );
    // Probe from a pre-opened second session before any further request can flush a queued
    // rollback; refusal must already have released every writer lock.
    let attempts = PhaseName::ALL
        .iter()
        .map(|phase| {
            format!(
                "pg_try_advisory_xact_lock(hashtextextended('phase-runner:{SEPOLIA}:{phase}', \
                 0::bigint))"
            )
        })
        .collect::<Vec<_>>()
        .join(", ");
    let row = sqlx::raw_sql(&format!("SELECT {attempts}"))
        .fetch_one(&mut *probe)
        .await?;
    for (index, phase) in PhaseName::ALL.iter().enumerate() {
        assert!(row.try_get::<bool, _>(index)?, "{phase} lock remains held");
    }
    probe.rollback().await?;
    assert_eq!(before, snapshot(db.pool()).await?);

    let forked = node.clone().with_hash(1000, block_hash(2000));
    let error = switch(&db, "drpc", &node, "reth_db", &forked)
        .await
        .expect_err("both readers must agree on the retained target's hash");
    assert!(format!("{error:#}").contains("normal Ingest target differs at block 1000"));
    assert_eq!(before, snapshot(db.pool()).await?);

    let receipt = switch_to_direct_reader_with_floor(&db, &node, 0).await?;
    assert_eq!(receipt["next_block"], 256);
    assert_eq!(
        receipt["normal_target"],
        json!({"block": 1000, "hash": block_hash(1000)})
    );
    assert_eq!(
        snapshot(db.pool()).await?,
        with_stored_kind(before, "reth_db")
    );
    db.cleanup().await
}

/// Runs the production switch with each descriptor read through an HTTP node double. The
/// direct database reader needs a real Reth datadir, so `direct` stands in for it; the locks,
/// cursor checks, comparisons and update are the ones `transition` runs.
async fn switch(
    db: &ScratchDatabase,
    from_kind: &str,
    from_node: &NodeDouble,
    to_kind: &str,
    to_node: &NodeDouble,
) -> Result<Value> {
    switch_with_readers(db, from_kind, from_node, to_kind, to_node, |source| {
        Ok(VerificationProvider::new(
            SEPOLIA,
            "drpc",
            source.endpoint(),
        )?)
    })
    .await
}

/// [`switch`] from `drpc` to `reth_db` where the double standing in for the direct reader
/// reports a retention floor, as a pruned datadir would.
async fn switch_to_direct_reader_with_floor(
    db: &ScratchDatabase,
    node: &NodeDouble,
    floor: i64,
) -> Result<Value> {
    switch_with_readers(db, "drpc", node, "reth_db", node, |source| {
        let provider = VerificationProvider::new(SEPOLIA, "drpc", source.endpoint())?;
        Ok(if source.source_kind == "reth_db" {
            provider.with_declared_retention_floor(floor)
        } else {
            provider
        })
    })
    .await
}

async fn switch_with_readers(
    db: &ScratchDatabase,
    from_kind: &str,
    from_node: &NodeDouble,
    to_kind: &str,
    to_node: &NodeDouble,
    open_reader: impl Fn(&SourceConfig) -> Result<VerificationProvider>,
) -> Result<Value> {
    let (from_rpc, from_server) = from_node.spawn().await?;
    let (to_rpc, to_server) = to_node.spawn().await?;
    let result = transition_with_readers(
        &db.runner(),
        &source(from_kind, &from_rpc)?,
        &source(to_kind, &to_rpc)?,
        open_reader,
    )
    .await;
    from_server.abort();
    to_server.abort();
    result
}

fn with_stored_kind(mut snapshot: Value, kind: &str) -> Value {
    snapshot["cursors"][0]["source_kind"] = json!(kind);
    snapshot
}

fn source(kind: &str, endpoint: &str) -> Result<SourceConfig> {
    Ok(SourceConfig::new_with_role(
        SEPOLIA,
        "node",
        kind,
        SeedBasis::EthereumHead,
        0,
        SourceRole::Intake,
        endpoint,
    )?)
}

fn block_hash(number: i64) -> String {
    format!("0x{:064x}", 0xb10c_0000_i64 + number)
}

/// One execution node as its HTTP interface reports it: canonical hashes by height and
/// the logs of each block.
#[derive(Clone)]
struct NodeDouble {
    hashes: BTreeMap<i64, String>,
    logs: BTreeMap<i64, Vec<Value>>,
    /// Whether the node reports safe and finalized heads; a synced node does.
    checkpoint_heads: bool,
}

impl NodeDouble {
    fn through(head: i64) -> Self {
        Self {
            hashes: (0..=head)
                .map(|number| (number, block_hash(number)))
                .collect(),
            logs: BTreeMap::new(),
            checkpoint_heads: true,
        }
    }

    fn without_checkpoint_heads(mut self) -> Self {
        self.checkpoint_heads = false;
        self
    }

    fn with_hash(mut self, number: i64, hash: String) -> Self {
        self.hashes.insert(number, hash);
        self
    }

    fn with_watched_log(self, number: i64) -> Self {
        self.with_log(number, CONTRACT, TRANSFER_TOPIC)
    }

    fn with_log(mut self, number: i64, address: &str, topic0: &str) -> Self {
        let logs = self.logs.entry(number).or_default();
        let log = json!({
            "blockHash": self.hashes[&number],
            "blockNumber": format!("{number:#x}"),
            "transactionHash": format!("0x{:064x}", 0x7a00_i64 + number),
            "transactionIndex": "0x0",
            "logIndex": format!("{:#x}", logs.len()),
            "address": address,
            "topics": [topic0],
            "data": "0x"
        });
        logs.push(log);
        self
    }

    async fn spawn(&self) -> Result<(String, tokio::task::JoinHandle<()>)> {
        let listener = TcpListener::bind("127.0.0.1:0").await?;
        let address = listener.local_addr()?;
        let node = self.clone();
        let server = tokio::spawn(async move {
            axum::serve(
                listener,
                Router::new().route("/", post(answer)).with_state(node),
            )
            .await
            .expect("source transport node double");
        });
        Ok((format!("http://{address}/"), server))
    }

    fn respond(&self, request: &Value) -> Value {
        let id = request.get("id").cloned().unwrap_or(json!(1));
        let number = |value: &Value| {
            let quantity = value.as_str().expect("hex quantity");
            i64::from_str_radix(quantity.trim_start_matches("0x"), 16).expect("block number")
        };
        let result = match request["method"].as_str().unwrap_or_default() {
            "eth_chainId" => json!("0xaa36a7"),
            "eth_getBlockByNumber" => {
                let head = || self.hashes.keys().next_back().copied();
                let number = match request["params"][0].as_str() {
                    Some("latest") => head(),
                    // The double reports its head as its checkpoints; only their presence
                    // matters here.
                    Some("safe" | "finalized") => self.checkpoint_heads.then(head).flatten(),
                    _ => Some(number(&request["params"][0])),
                };
                let block =
                    number.and_then(|number| self.hashes.get(&number).map(|hash| (number, hash)));
                block.map_or(Value::Null, |(number, hash)| {
                    json!({
                        "hash": hash,
                        "parentHash": block_hash(number - 1),
                        "number": format!("{number:#x}"),
                        "timestamp": format!("{number:#x}")
                    })
                })
            }
            "eth_getLogs" => {
                let filter = &request["params"][0];
                let (from, to) = (number(&filter["fromBlock"]), number(&filter["toBlock"]));
                let logs = self
                    .logs
                    .range(from..=to)
                    .flat_map(|(_, logs)| logs.clone());
                Value::Array(logs.collect())
            }
            method => panic!("unexpected source transport RPC method {method}"),
        };
        json!({"jsonrpc": "2.0", "id": id, "result": result})
    }
}

async fn answer(State(node): State<NodeDouble>, Json(request): Json<Value>) -> Json<Value> {
    Json(match request.as_array() {
        Some(batch) => Value::Array(batch.iter().map(|item| node.respond(item)).collect()),
        None => node.respond(&request),
    })
}

/// Whether the seeded Ingest phase also carries an explicit redo of blocks 2..=5.
enum Redo {
    None,
    /// Installed but no block re-read yet.
    NotStarted,
    /// Re-read through this block.
    ResumedAt(i64),
}

/// An Ingest pass that finished through block 5, so the cursor's next block is 6.
async fn seed_ingest(pool: &sqlx::PgPool, stored_kind: &str, redo: Redo) -> Result<()> {
    support::seed_lineage(pool, SEPOLIA, 5).await?;
    sqlx::query(
        "INSERT INTO ingest_cursors (
            chain_id, source_key, source_kind, seed_basis, start_block_number,
            next_block_number, target_block_number, last_processed_block_number,
            last_processed_block_hash
         ) VALUES ($1, 'node', $2, 'ethereum_head', 0, 6, 5, 5, $3)",
    )
    .bind(SEPOLIA)
    .bind(stored_kind)
    .bind(block_hash(5))
    .execute(pool)
    .await?;
    for phase in PhaseName::ALL {
        let ingest = phase == PhaseName::Ingest;
        sqlx::query(
            "INSERT INTO chain_phase_state (
                chain_id, phase_name, phase_status, current_block_number, current_block_hash,
                target_block_number, target_block_hash, started_at, finished_at
             ) VALUES (
                $1, $2, $3, $4, $5, $4, $5,
                CASE WHEN $3 = 'completed' THEN now() END,
                CASE WHEN $3 = 'completed' THEN now() END
             )",
        )
        .bind(SEPOLIA)
        .bind(phase.as_str())
        .bind(if ingest { "completed" } else { "idle" })
        .bind(ingest.then_some(5_i64))
        .bind(ingest.then(|| block_hash(5)))
        .execute(pool)
        .await?;
    }
    let resumed_at = match redo {
        Redo::None => return Ok(()),
        Redo::NotStarted => None,
        Redo::ResumedAt(number) => Some(number),
    };
    sqlx::query(
        "UPDATE chain_phase_state
         SET phase_status = 'running', finished_at = NULL, redo_in_progress = true,
             redo_mode = 'redo', redo_previous_phase_status = 'completed',
             redo_previous_started_at = started_at, redo_previous_finished_at = finished_at,
             redo_from_block_number = 2, redo_to_block_number = 5,
             redo_current_block_number = $2, redo_current_block_hash = $3
         WHERE chain_id = $1 AND phase_name = 'ingest'",
    )
    .bind(SEPOLIA)
    .bind(resumed_at)
    .bind(resumed_at.map(block_hash))
    .execute(pool)
    .await?;
    Ok(())
}

/// The seeded Ingest pass handed block 5 to live follow, so Ingest is complete and has no
/// catch-up work of its own.
async fn hand_off_to_live(pool: &sqlx::PgPool) -> Result<()> {
    sqlx::query(
        "UPDATE chain_phase_state
         SET live_handoff_block_number = 5, live_handoff_block_hash = $2
         WHERE chain_id = $1 AND phase_name = 'ingest'",
    )
    .bind(SEPOLIA)
    .bind(block_hash(5))
    .execute(pool)
    .await?;
    Ok(())
}

/// The seeded completed Ingest pass failed its completed-phase validation with `message`,
/// the way `PhaseStore::fail_completed_validation` records it: the status changes and the
/// error is kept, the completed markers stay.
async fn fail_completed_validation(pool: &sqlx::PgPool, message: &str) -> Result<()> {
    sqlx::query(
        "UPDATE chain_phase_state
         SET phase_status = 'failed', last_error = $2, finished_at = now(), updated_at = now()
         WHERE chain_id = $1 AND phase_name = 'ingest'",
    )
    .bind(SEPOLIA)
    .bind(message)
    .execute(pool)
    .await?;
    Ok(())
}

/// Live follow published the chain through block `through`: the canonical lineage holds
/// every block up to it with the hashes the node double reports, and the chain head points
/// at it. Live progress never touches the Ingest cursor, which keeps saying block 6.
async fn seed_published_head(pool: &sqlx::PgPool, through: i64) -> Result<()> {
    for number in 0..=through {
        sqlx::query(
            "INSERT INTO chain_lineage (
                chain_id, block_hash, parent_hash, block_number, block_timestamp,
                canonicality_state
             ) VALUES ($1, $2, $3, $4, to_timestamp($4), 'canonical')",
        )
        .bind(SEPOLIA)
        .bind(block_hash(number))
        .bind((number > 0).then(|| block_hash(number - 1)))
        .bind(number)
        .execute(pool)
        .await?;
    }
    sqlx::query(
        "INSERT INTO chain_heads (chain_id, latest_block_hash, latest_block_number)
         VALUES ($1, $2, $3)",
    )
    .bind(SEPOLIA)
    .bind(block_hash(through))
    .bind(through)
    .execute(pool)
    .await?;
    Ok(())
}

/// An active ENSv2 resolver manifest whose emitters announce themselves with
/// `ResolverCreated()`, and one such announcement retained as a canonical raw log in block
/// `announced_at` with no discovery edge persisted yet. Returns the announced emitter and the
/// `topic0` of the resolver event Ingest then watches on it.
async fn seed_resolver_announcement(
    pool: &sqlx::PgPool,
    announced_at: i64,
) -> Result<(&'static str, String)> {
    const EMITTER: &str = "0x00000000000000000000000000000000000000aa";
    let created = bigname_manifests::resolver_creation_topic0();
    let text_updated = format!(
        "{}",
        alloy_primitives::keccak256("TextUpdated(uint256,string,string,string)")
    );
    let payload = json!({
        "manifest_version": 1, "namespace": "ens", "source_family": "ens_v2_resolver_l1",
        "chain": SEPOLIA, "deployment_epoch": "test", "rollout_status": "active",
        "normalizer_version": "test", "capability_flags": {},
        "roots": [], "contracts": [], "discovery_rules": [],
        "abi": {"events": [
            {"name": "ResolverCreated", "fragment": "event ResolverCreated()",
             "emitter_roles": [], "normalized_events": []},
            {"name": "TextUpdated",
             "fragment": "event TextUpdated(uint256 indexed recordId, string indexed keyHash, string key, string value)",
             "emitter_roles": [], "normalized_events": []}
        ]}
    });
    sqlx::query(
        "INSERT INTO manifest_versions (
            manifest_version, namespace, source_family, chain_id, deployment_label,
            rollout_status, normalizer_version, file_path, manifest_payload
         ) VALUES (1, 'ens', 'ens_v2_resolver_l1', $1, 'test', 'active', 'test', $2, $3::jsonb)",
    )
    .bind(SEPOLIA)
    .bind(format!("tests/{SEPOLIA}-resolver.toml"))
    .bind(payload.to_string())
    .execute(pool)
    .await?;
    sqlx::query(
        "INSERT INTO raw_transactions (
            chain_id, block_hash, block_number, transaction_hash, transaction_index, from_address
         ) VALUES ($1, $2, $3, $4, 0, $5)",
    )
    .bind(SEPOLIA)
    .bind(block_hash(announced_at))
    .bind(announced_at)
    .bind(format!("0x{:064x}", 0x7a00_i64 + announced_at))
    .bind(EMITTER)
    .execute(pool)
    .await?;
    sqlx::query(
        "INSERT INTO raw_logs (
            chain_id, block_hash, block_number, transaction_hash, transaction_index, log_index,
            emitting_address, topics
         ) VALUES ($1, $2, $3, $4, 0, 0, $5, $6)",
    )
    .bind(SEPOLIA)
    .bind(block_hash(announced_at))
    .bind(announced_at)
    .bind(format!("0x{:064x}", 0x7a00_i64 + announced_at))
    .bind(EMITTER)
    .bind(vec![created])
    .execute(pool)
    .await?;
    Ok((EMITTER, text_updated))
}

/// Everything the command is documented to preserve, plus the cursor it may edit.
async fn snapshot(pool: &sqlx::PgPool) -> Result<Value> {
    Ok(sqlx::query_scalar(
        "SELECT jsonb_build_object(
            'cursors', (SELECT jsonb_agg(to_jsonb(c) ORDER BY source_key) FROM ingest_cursors c),
            'phases', (SELECT jsonb_agg(to_jsonb(p) ORDER BY phase_name) FROM chain_phase_state p),
            'lineage', (SELECT jsonb_agg(to_jsonb(l) ORDER BY block_number, block_hash)
                        FROM chain_lineage l),
            'raw_logs', (SELECT count(*) FROM raw_logs),
            'manifests', (SELECT jsonb_agg(to_jsonb(m) ORDER BY manifest_id)
                          FROM manifest_versions m)
        )",
    )
    .fetch_one(pool)
    .await?)
}

async fn seed_watch_set(pool: &sqlx::PgPool) -> Result<()> {
    let contract_id = Uuid::new_v4();
    sqlx::query(
        "INSERT INTO contract_instances (contract_instance_id, chain_id, contract_kind, provenance)
         VALUES ($1, $2, 'contract', '{}'::jsonb)",
    )
    .bind(contract_id)
    .bind(SEPOLIA)
    .execute(pool)
    .await?;
    let payload = json!({
        "manifest_version": 1,
        "namespace": "test",
        "source_family": "test_events",
        "chain": SEPOLIA,
        "deployment_epoch": "test",
        "rollout_status": "active",
        "normalizer_version": "test",
        "capability_flags": {},
        "roots": [],
        "contracts": [],
        "discovery_rules": [],
        "abi": {"events": [{
            "name": "Transfer",
            "fragment": "event Transfer(address indexed from,address indexed to,uint256 value)",
            "emitter_roles": [],
            "normalized_events": []
        }]}
    });
    let manifest_id: i64 = sqlx::query_scalar(
        "INSERT INTO manifest_versions (
            manifest_version, namespace, source_family, chain_id, deployment_label,
            rollout_status, normalizer_version, file_path, manifest_payload
         ) VALUES (1, 'test', 'test_events', $1, 'test', 'active', 'test', $2, $3::jsonb)
         RETURNING manifest_id",
    )
    .bind(SEPOLIA)
    .bind(format!("tests/{SEPOLIA}.toml"))
    .bind(payload.to_string())
    .fetch_one(pool)
    .await?;
    sqlx::query(
        "INSERT INTO manifest_contract_instances (
            manifest_id, chain_id, declaration_kind, declaration_name, contract_instance_id,
            declared_address, role, proxy_kind
         ) VALUES ($1, $2, 'contract', 'test', $3, $4, 'test', 'none')",
    )
    .bind(manifest_id)
    .bind(SEPOLIA)
    .bind(contract_id)
    .bind(CONTRACT)
    .execute(pool)
    .await?;
    sqlx::query(
        "INSERT INTO contract_instance_addresses (
            contract_instance_id, chain_id, address, active_from_block_number,
            source_manifest_id, provenance
         ) VALUES ($1, $2, $3, 0, $4, '{}'::jsonb)",
    )
    .bind(contract_id)
    .bind(SEPOLIA)
    .bind(CONTRACT)
    .bind(manifest_id)
    .execute(pool)
    .await?;
    Ok(())
}
