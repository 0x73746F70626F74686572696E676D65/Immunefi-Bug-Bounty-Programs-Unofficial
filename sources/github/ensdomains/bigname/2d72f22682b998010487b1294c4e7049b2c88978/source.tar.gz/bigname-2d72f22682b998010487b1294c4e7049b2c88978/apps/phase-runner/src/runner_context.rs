use std::{future::Future, pin::Pin, sync::Arc};

use tokio_util::sync::CancellationToken;

use crate::{
    config::ChainConfig,
    error::{RunnerError, RunnerResult},
    heads::{HeadMarkers, load_available_heads, load_marker},
    phase::{Phase, PhaseContext, PhaseName, RedoAttemptFence, RunMode},
    phase_lock::PhaseLock,
    runner_support::StopClock,
    state::{PhaseStatus, StartDisposition},
    state_persistence::validate_progress,
};

use super::{PhaseRunner, chain::bounded_recovery};

pub(super) type BeforePhaseContext =
    Arc<dyn Fn(PhaseName) -> Pin<Box<dyn Future<Output = ()> + Send>> + Send + Sync>;

impl PhaseRunner {
    #[doc(hidden)]
    pub fn with_before_phase_context<F, Fut>(mut self, hook: F) -> Self
    where
        F: Fn(PhaseName) -> Fut + Send + Sync + 'static,
        Fut: Future<Output = ()> + Send + 'static,
    {
        self.before_phase_context = Some(Arc::new(move |phase| Box::pin(hook(phase))));
        self
    }

    pub(super) async fn before_phase_context(&self, phase: PhaseName) {
        if let Some(hook) = self.before_phase_context.as_deref() {
            hook(phase).await;
        }
    }

    pub(crate) fn verify_before_live(chain: &ChainConfig) -> RunnerResult<bool> {
        Ok(chain.verify_before_live
            || crate::verify_phase::provider_trusted_verify_required(
                &chain.chain_id,
                &chain.sources,
            )?)
    }

    pub(super) async fn check_ingest_identity(
        &self,
        phase: PhaseName,
        chain: &ChainConfig,
        mode: &RunMode,
    ) -> RunnerResult<()> {
        let intake_sources = chain.intake_sources();
        let production_verify = crate::verify_phase::production_verify_chain(&chain.chain_id);
        if phase == PhaseName::Verify && production_verify {
            self.store
                .validate_completed_ingest_sources(&chain.chain_id, &intake_sources)
                .await?;
        }
        if phase == PhaseName::Ingest {
            let status = self.store.status(&chain.chain_id, phase).await?;
            let completed_phase_restarts = status == crate::state::PhaseStatus::Completed
                && self
                    .store
                    .completed_ingest_requires_restart(&chain.chain_id)
                    .await?;
            let validates_retained_completion = matches!(mode, RunMode::Normal)
                && ((status == crate::state::PhaseStatus::Completed && !completed_phase_restarts)
                    || self
                        .store
                        .pending_completed_validation(&chain.chain_id, phase)
                        .await?);
            if validates_retained_completion {
                self.store
                    .validate_completed_ingest_sources(&chain.chain_id, &intake_sources)
                    .await?;
                if production_verify {
                    crate::verify_phase::provider_trusted_verify_required(
                        &chain.chain_id,
                        &chain.sources,
                    )?;
                }
            } else {
                if production_verify {
                    self.store
                        .validate_existing_ingest_sources(&chain.chain_id, &intake_sources)
                        .await?;
                    crate::verify_phase::provider_trusted_verify_required(
                        &chain.chain_id,
                        &chain.sources,
                    )?;
                }
                self.store
                    .ensure_ingest_sources(&chain.chain_id, &intake_sources)
                    .await?;
            }
        }
        if matches!(
            phase,
            PhaseName::Ingest | PhaseName::Live | PhaseName::Verify
        ) {
            // The startup check finds no cursor another start creates and completes after it.
            self.store
                .reconcile_verified_rpc_chains(&intake_sources)
                .await?;
        }
        Ok(())
    }

    pub(super) async fn finish_completed_phase(
        &self,
        stop_clock: &StopClock,
        chain: &ChainConfig,
        phase: Arc<dyn Phase>,
        phase_lock: &mut PhaseLock,
        cancellation: &CancellationToken,
        recovering: bool,
    ) -> RunnerResult<()> {
        let phase_name = phase.name();
        let result = async {
            self.validate_completed_config(chain, phase_name).await?;
            if phase.revalidates_completed(&chain.chain_id, &chain.sources)? {
                self.revalidate_completed_phase(chain, phase, phase_lock)
                    .await?;
            }
            if recovering {
                phase_lock.check_alive().await?;
                self.store
                    .complete_revalidated_phase(
                        phase_lock.connection(),
                        &chain.chain_id,
                        phase_name,
                    )
                    .await?;
            } else {
                phase_lock.check_alive().await?;
                self.store
                    .clear_unconfigured_settlement(
                        phase_lock.connection(),
                        &chain.chain_id,
                        phase_name,
                    )
                    .await?;
            }
            Ok(())
        }
        .await;
        match result {
            Ok(()) => Ok(()),
            Err(error) => {
                self.record_phase_validation_failure(
                    stop_clock,
                    &chain.chain_id,
                    phase_name,
                    &RunMode::Normal,
                    phase_lock,
                    cancellation,
                    error,
                )
                .await
            }
        }
    }

    pub(super) async fn start_normal_phase(
        &self,
        stop_clock: &StopClock,
        chain: &ChainConfig,
        phase: Arc<dyn Phase>,
        phase_lock: &mut PhaseLock,
        cancellation: &CancellationToken,
    ) -> RunnerResult<bool> {
        match self
            .store
            .start_phase(&chain.chain_id, phase.name(), &RunMode::Normal)
            .await?
        {
            StartDisposition::Started => Ok(true),
            StartDisposition::AlreadyCompleted => {
                self.finish_completed_phase(
                    stop_clock,
                    chain,
                    phase,
                    phase_lock,
                    cancellation,
                    false,
                )
                .await?;
                Ok(false)
            }
            StartDisposition::RecoveringCompleted => {
                self.finish_completed_phase(
                    stop_clock,
                    chain,
                    phase,
                    phase_lock,
                    cancellation,
                    true,
                )
                .await?;
                Ok(false)
            }
        }
    }

    #[allow(clippy::too_many_arguments)]
    pub(super) async fn record_phase_validation_failure(
        &self,
        stop_clock: &StopClock,
        chain_id: &str,
        phase: PhaseName,
        mode: &RunMode,
        phase_lock: &mut PhaseLock,
        cancellation: &CancellationToken,
        error: RunnerError,
    ) -> RunnerResult<()> {
        if error.is_retryable()
            || !matches!(mode, RunMode::Normal)
            || !matches!(phase, PhaseName::Ingest | PhaseName::Verify)
        {
            return Err(error);
        }
        // The status read, the probe, and the failure record all wait on the
        // database; once a stop is pending they draw on the stop budget, and the
        // validation error is what is reported either way.
        let recorded = bounded_recovery(
            stop_clock,
            "recording the completed-phase validation failure",
            chain_id,
            cancellation,
            async {
                let step = |what: &str, step_error: RunnerError| {
                    RunnerError::new(step_error.kind(), format!("{what}: {step_error}"))
                };
                let status = self
                    .store
                    .status(chain_id, phase)
                    .await
                    .map_err(|status_error| step("load phase state", status_error))?;
                if status != PhaseStatus::Completed {
                    return Ok(());
                }
                phase_lock
                    .check_alive()
                    .await
                    .map_err(|lock_error| step("confirm phase lock", lock_error))?;
                let failure_reason = format!(
                    "{}{error}",
                    crate::error::COMPLETED_VALIDATION_FAILURE_PREFIX
                );
                self.store
                    .fail_completed_validation(chain_id, phase, &failure_reason)
                    .await
            },
        )
        .await;
        match recorded {
            Ok(()) => Err(error),
            Err(record_error) => {
                Err(error.with_secondary("record completed-phase validation failure", record_error))
            }
        }
    }

    pub(super) async fn validate_completed_config(
        &self,
        chain: &ChainConfig,
        phase: PhaseName,
    ) -> RunnerResult<()> {
        if phase == PhaseName::Verify {
            let resume = self
                .store
                .phase_resume(&chain.chain_id, phase, &RunMode::Normal)
                .await?;
            let provider_trusted_downgrade = resume.verification_level.is_some()
                && crate::verify_phase::provider_trusted_verify_required(
                    &chain.chain_id,
                    &chain.sources,
                )?;
            if !provider_trusted_downgrade {
                crate::verify_phase::validate_reported_level(
                    &chain.chain_id,
                    &chain.sources,
                    resume.verification_level,
                )?;
            }
        }
        Ok(())
    }

    pub(super) async fn revalidate_completed_phase(
        &self,
        chain: &ChainConfig,
        phase: Arc<dyn Phase>,
        phase_lock: &mut PhaseLock,
    ) -> RunnerResult<()> {
        let phase_name = phase.name();
        let context = self
            .phase_context(chain, phase_name, RunMode::Normal, None)
            .await?;
        let retained_verification_level = context.resume.verification_level;
        let progress = phase_lock
            .run_while_alive(
                self.timing.live_poll_interval,
                phase.revalidate_completed(context),
            )
            .await?;
        let Some(progress) = progress else {
            return Ok(());
        };
        phase_lock.check_alive().await?;
        validate_progress(phase_name, &progress, true)?;
        if phase_name == PhaseName::Verify {
            crate::verify_phase::validate_reported_level(
                &chain.chain_id,
                &chain.sources,
                progress.verification_level,
            )?;
        }
        if progress.heads.is_some() {
            return Err(RunnerError::data_integrity(format!(
                "completed phase {phase_name} cannot publish chain heads during revalidation"
            )));
        }
        phase_lock.check_alive().await?;
        self.store
            .record_progress(
                &chain.chain_id,
                phase_name,
                &RunMode::Normal,
                None,
                &progress,
            )
            .await?;
        if phase_name == PhaseName::Verify {
            crate::verify_level::warn_optional_downgrade(
                &chain.chain_id,
                retained_verification_level,
                progress.verification_level,
            );
        }
        Ok(())
    }

    pub(super) async fn phase_context(
        &self,
        chain: &ChainConfig,
        phase: PhaseName,
        mode: RunMode,
        redo_attempt: Option<RedoAttemptFence>,
    ) -> RunnerResult<PhaseContext> {
        self.before_phase_context(phase).await;
        let available_heads = match mode.range() {
            Some(range) if phase == PhaseName::Project => {
                let end = redo_attempt.map_or(range.to, |attempt| attempt.execution_range.to);
                match load_available_heads(self.store.pool(), &chain.chain_id).await? {
                    Some(heads) => load_marker(
                        self.store.pool(),
                        &chain.chain_id,
                        end.min(heads.latest.number),
                    )
                    .await?
                    .map(|latest| HeadMarkers {
                        latest,
                        safe: None,
                        finalized: None,
                    }),
                    None => None,
                }
            }
            Some(_) if phase == PhaseName::Interpret && matches!(mode, RunMode::Redo(_)) => {
                interpret_redo_heads(self.store.pool(), &chain.chain_id).await?
            }
            Some(range) => load_marker(self.store.pool(), &chain.chain_id, range.to)
                .await?
                .map(|latest| HeadMarkers {
                    latest,
                    safe: None,
                    finalized: None,
                }),
            None => load_available_heads(self.store.pool(), &chain.chain_id).await?,
        };
        let live_handoff = if phase == PhaseName::Live && matches!(mode, RunMode::Normal) {
            let mut handoff = self.store.ingest_handoff(&chain.chain_id).await?;
            if handoff.is_none()
                && self
                    .store
                    .required_redo_range(&chain.chain_id, PhaseName::Ingest)
                    .await?
                    .is_some()
            {
                // A rewind may be the only way to replace a provider fork after manifest sync
                // stamped Ingest while finite intake was interrupted before recording its
                // handoff. The published readable head is the recovery anchor; Live validates
                // the provider path from it before publishing a replacement suffix.
                handoff = available_heads.as_ref().map(|heads| heads.latest.clone());
            }
            if handoff.is_none() {
                return Err(RunnerError::data_integrity(format!(
                    "cannot start live phase for chain {} without the ingest handoff block",
                    chain.chain_id
                )));
            }
            handoff
        } else {
            None
        };
        let resume = self
            .store
            .phase_resume(&chain.chain_id, phase, &mode)
            .await?;
        Ok(PhaseContext {
            chain_id: chain.chain_id.clone(),
            phase,
            mode,
            redo_attempt,
            sources: if phase == PhaseName::Verify {
                Arc::clone(&chain.sources)
            } else {
                chain.intake_sources()
            },
            available_heads,
            live_handoff,
            resume,
        })
    }

    pub(super) async fn confirm_progress(&self, mut context: PhaseContext) -> RunnerResult<()> {
        context.resume = self
            .store
            .phase_resume(&context.chain_id, context.phase, &context.mode)
            .await?;
        self.phase_progress.begin_batch(&context);
        Ok(())
    }
}

async fn interpret_redo_heads(
    pool: &sqlx::PgPool,
    chain_id: &str,
) -> RunnerResult<Option<HeadMarkers>> {
    let number: Option<i64> = sqlx::query_scalar(
        "SELECT current_block_number
         FROM chain_phase_state
         WHERE chain_id = $1 AND phase_name = 'interpret'",
    )
    .bind(chain_id)
    .fetch_optional(pool)
    .await
    .map_err(|error| {
        RunnerError::database(
            format!("failed to load recorded interpret head for redo on chain {chain_id}"),
            error,
        )
    })?
    .flatten();
    let number = number.ok_or_else(|| {
        RunnerError::data_integrity(format!(
            "cannot redo interpret on chain {chain_id}: the phase has no recorded head"
        ))
    })?;
    let latest = load_marker(pool, chain_id, number).await?.ok_or_else(|| {
        RunnerError::data_integrity(format!(
            "cannot redo interpret on chain {chain_id}: recorded head {number} is not readable (canonical, safe, or finalized)"
        ))
    })?;
    Ok(Some(HeadMarkers {
        latest,
        safe: None,
        finalized: None,
    }))
}
