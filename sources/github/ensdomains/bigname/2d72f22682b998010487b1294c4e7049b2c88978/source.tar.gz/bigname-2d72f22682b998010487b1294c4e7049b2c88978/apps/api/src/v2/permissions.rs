use std::collections::BTreeSet;

use axum::{Json, extract::State};
use bigname_storage::{EffectivePermissionRow, PermissionGrantRelation};
use serde::{Deserialize, Serialize};
use serde_json::Value;

use crate::AppState;

use super::address_names::permission_resource_handle;
use super::collection_snapshot::CollectionSnapshot;
use super::name_record::wrapper_metadata;
use super::permission_support::{
    PermissionRequestScope, PermissionSupport, apply_permissions_collection_support_meta,
    permission_support_for_resources,
};
use super::{
    AddressNameGrant, Envelope, GrantRelation, Meta, Page, QueryParamAllowlist, QueryParams,
    StrictQueryParams, V2Error, V2Result, decode, effective_permission_scope_value, encode,
    permission_powers_value, record_resource_value,
    restrictions::ResourceRestrictions,
    validate_latest_collection_selectors,
    vocab::{AuthorityContext, WrapperFuses, WrapperState},
};

#[path = "permissions/lineage.rs"]
mod lineage;
use lineage::permission_lineage;
#[path = "permissions/current_name.rs"]
mod current_name;
use current_name::load_current_name_row;

mod filter;
pub(crate) use filter::registration_row;

mod paging;
mod read_errors;
use filter::{EmptyPermissionsSelection, permissions_filter_inputs, resolve_permissions_filter};
use paging::{permissions_cursor_payload, permissions_storage_cursor};

const NAMESPACE_FILTER_KEY: &str = "namespace";
const NAME_FILTER_KEY: &str = "name";
const ADDRESS_FILTER_KEY: &str = "address";
const REGISTRATION_ID_FILTER_KEY: &str = "registration_id";
const INCLUDE_FILTER_KEY: &str = "include";

pub(crate) struct PermissionsQueryParams;

impl QueryParamAllowlist for PermissionsQueryParams {
    const ALLOWED: &'static [&'static str] = &[
        "name",
        "registration_id",
        "address",
        "namespace",
        "at",
        "finality",
        "include",
        "cursor",
        "page_size",
    ];
}

pub(crate) type PermissionsQuery = StrictQueryParams<PermissionsQueryParams>;

#[derive(Clone, Debug, Deserialize, PartialEq, Serialize)]
pub(crate) struct PermissionRow {
    pub(crate) address: String,
    #[serde(flatten)]
    pub(crate) grant: AddressNameGrant,
    pub(crate) registration_id: String,
    /// Present for a grant on an ENSv2 record-ID resolver, whose resource is the keccak
    /// of a setter argument: which record the granted resource is about.
    /// (upstream: .refs/ens_v2/contracts/src/resolver/PermissionedResolver.sol:L307-L338 @ ens_v2@a971bd64)
    #[serde(skip_serializing_if = "Option::is_none")]
    pub(crate) record_resource: Option<Value>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub(crate) name: Option<String>,
    pub(crate) authority_context: AuthorityContext,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub(crate) wrapper_state: Option<WrapperState>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub(crate) wrapper_fuses: Option<WrapperFuses>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub(crate) lineage: Option<PermissionLineage>,
}

/// The `GET /v1/permissions` body: the collection envelope plus, for a resource-bound read, the
/// selected registration's [resource restrictions](../../../../docs/api-v1.md#resource-restrictions).
#[derive(Clone, Debug, Deserialize, PartialEq, Serialize)]
pub(crate) struct PermissionsResponse {
    #[serde(flatten)]
    pub(crate) envelope: Envelope<Vec<PermissionRow>>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub(crate) restrictions: Option<ResourceRestrictions>,
}

#[derive(Clone, Debug, Deserialize, PartialEq, Serialize)]
pub(crate) struct PermissionLineage {
    pub(crate) grant: Value,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub(crate) revocation: Option<Value>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub(crate) inheritance_path: Option<Value>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub(crate) transfer_behavior: Option<Value>,
}

pub(crate) async fn get_permissions(
    params: PermissionsQuery,
    State(state): State<AppState>,
) -> V2Result<Json<PermissionsResponse>> {
    let params = params.into_inner();
    validate_latest_collection_selectors(params.at.as_ref(), params.finality)?;
    let include_lineage = permissions_include_lineage(&params.include)?;
    let filter_inputs = permissions_filter_inputs(&params)?;
    let namespace = filter_inputs
        .name_filter
        .as_ref()
        .map(|name| name.namespace.as_str())
        .or(params.namespace.as_deref());
    let mut snapshot =
        CollectionSnapshot::capture_for_namespace(&state, params.cursor.as_deref(), namespace)
            .await?;

    let resolved = resolve_permissions_filter(
        &state,
        &params,
        include_lineage,
        &filter_inputs,
        &snapshot.block_bounds(),
    )
    .await?;
    let storage_cursor = params
        .cursor
        .as_deref()
        .map(|cursor| {
            let payload = decode(cursor)?;
            permissions_storage_cursor(&payload, &resolved.cursor_filters)
        })
        .transpose()?;

    if let Some(selection) = resolved.empty_selection {
        let support = if selection == EmptyPermissionsSelection::SupersededNameRegistrationPair {
            // The explicitly requested registration classifies the empty page like its own
            // standalone read, through the resource that controls it; the name's own control
            // resource does not.
            let ids = resolved
                .pair_support_resource_id
                .into_iter()
                .collect::<Vec<_>>();
            let summaries =
                bigname_storage::load_serving_permission_summaries(snapshot.conn().await?, &ids)
                    .await
                    .map_err(read_errors::support_error())?;
            permission_support_for_resources(&ids, &summaries)
        } else {
            PermissionSupport::UNKNOWN
        };
        return Ok(empty_permissions_response(
            &params,
            selection,
            support,
            snapshot.finish(&state).await?,
        ));
    }

    let storage_page = bigname_storage::load_serving_effective_permissions_page(
        snapshot.conn().await?,
        resolved.subject.as_deref(),
        resolved.resource_id,
        // A name filter already selected its registration inside the name's namespace.
        params
            .namespace
            .as_deref()
            .filter(|_| filter_inputs.name_filter.is_none()),
        storage_cursor.as_ref(),
        params.page_size,
    )
    .await
    .map_err(read_errors::page_error())?;

    let resource_ids = storage_page
        .rows
        .iter()
        .map(|row| row.resource_id)
        .collect::<Vec<_>>();
    let support_resource_ids = resolved
        .resource_id
        .into_iter()
        .chain(resource_ids.iter().copied())
        .collect::<BTreeSet<_>>()
        .into_iter()
        .collect::<Vec<_>>();
    let block_bounds = snapshot.block_bounds();
    let reads = snapshot.conn().await?;
    let permission_summaries =
        bigname_storage::load_serving_permission_summaries(&mut *reads, &support_resource_ids)
            .await
            .map_err(read_errors::support_error())?;
    // The selected resource is included so an empty page still serves its restrictions under
    // the name's registration_id.
    let current_names =
        bigname_storage::load_current_names_by_resource_ids(&mut *reads, &support_resource_ids)
            .await
            .map_err(super::name_rows_error(
                super::SnapshotReadResource::Resource,
                |_| V2Error::internal_error("failed to load permission names"),
            ))?;
    let nameless_resource_ids = support_resource_ids
        .iter()
        .copied()
        .filter(|id| !current_names.contains_key(id))
        .collect::<Vec<_>>();
    let registry_registrations = bigname_storage::load_registry_permission_registration_map(
        reads,
        &nameless_resource_ids,
        None,
        &block_bounds,
    )
    .await
    .map_err(|_| V2Error::internal_error("failed to load permission registrations"))?;
    let next_cursor = storage_page.next_cursor.as_ref().map(|cursor| {
        encode(&permissions_cursor_payload(
            cursor,
            &resolved.cursor_filters,
        ))
    });
    let has_more = next_cursor.is_some();
    let data = storage_page
        .rows
        .iter()
        .map(|row| {
            let current_name = current_names.get(&row.resource_id);
            let mut permission = build_permission_row(
                row,
                current_name.map(|name| name.normalized_name.as_str()),
                current_name.map(|name| &name.declared_summary),
                include_lineage,
                resolved.authority_context,
            )?;
            permission.registration_id = permission_resource_handle(current_name, row.resource_id);
            if current_name.is_none()
                && let Some(registration) = registry_registrations.get(&row.resource_id)
            {
                permission.registration_id = registration.to_string();
            }
            Ok(permission)
        })
        .collect::<V2Result<Vec<_>>>()?;
    let mut meta = snapshot.finish(&state).await?;
    let permission_support =
        permission_support_for_resources(&support_resource_ids, &permission_summaries);
    apply_permissions_collection_support_meta(
        &mut meta,
        permission_support,
        if resolved.resource_id.is_some() {
            PermissionRequestScope::ResourceBound
        } else {
            PermissionRequestScope::AccountWide
        },
    );
    let restrictions = resolved
        .resource_id
        .and_then(|resource_id| permission_summaries.get(&resource_id))
        .map(ResourceRestrictions::from_summary)
        .transpose()?
        .flatten()
        .map(|restrictions| {
            restrictions.for_registration(
                resolved
                    .resource_id
                    .and_then(|resource_id| {
                        current_names
                            .get(&resource_id)
                            .map(|name| permission_resource_handle(Some(name), resource_id))
                    })
                    .or_else(|| {
                        resolved
                            .resource_id
                            .and_then(|id| registry_registrations.get(&id))
                            .map(ToString::to_string)
                    }),
            )
        });

    Ok(Json(PermissionsResponse {
        envelope: Envelope {
            data,
            page: Some(Page {
                cursor: params.cursor.clone(),
                next_cursor,
                page_size: params.page_size,
                total_count: None,
                has_more,
            }),
            meta,
        },
        restrictions,
    }))
}

fn empty_permissions_response(
    params: &QueryParams,
    selection: EmptyPermissionsSelection,
    support: PermissionSupport,
    mut meta: Meta,
) -> Json<PermissionsResponse> {
    match selection {
        EmptyPermissionsSelection::MissingOrUnsupportedNameAnchor => {
            apply_permissions_collection_support_meta(
                &mut meta,
                PermissionSupport::UNKNOWN,
                PermissionRequestScope::AccountWide,
            );
        }
        EmptyPermissionsSelection::SupersededNameRegistrationPair => {
            apply_permissions_collection_support_meta(
                &mut meta,
                support,
                PermissionRequestScope::ResourceBound,
            );
        }
        EmptyPermissionsSelection::NamespaceRegistrationMismatch
        | EmptyPermissionsSelection::ResourceIsNotARegistration => {}
    }

    Json(PermissionsResponse {
        envelope: Envelope {
            data: Vec::new(),
            page: Some(Page {
                cursor: params.cursor.clone(),
                next_cursor: None,
                page_size: params.page_size,
                total_count: None,
                has_more: false,
            }),
            meta,
        },
        restrictions: None,
    })
}

pub(crate) fn build_permission_row(
    row: &EffectivePermissionRow,
    name: Option<&str>,
    declared_summary: Option<&Value>,
    include_lineage: bool,
    authority_context: AuthorityContext,
) -> V2Result<PermissionRow> {
    let (wrapper_state, wrapper_fuses) = declared_summary
        .map(wrapper_metadata)
        .transpose()?
        .flatten()
        .map_or((None, None), |(state, fuses)| (Some(state), Some(fuses)));
    Ok(PermissionRow {
        address: row.subject.clone(),
        grant: AddressNameGrant {
            grant_relation: row.grant_relation.map(|relation| match relation {
                PermissionGrantRelation::Operator => GrantRelation::Operator,
            }),
            grant_scope: effective_permission_scope_value(&row.scope)?,
            powers: permission_powers_value(&row.effective_powers)?,
        },
        registration_id: row.resource_id.to_string(),
        record_resource: row
            .record_resource_selector
            .as_ref()
            .map(|selector| record_resource_value(selector, &row.effective_powers))
            .transpose()?
            .flatten(),
        name: name.map(str::to_owned),
        authority_context,
        wrapper_state,
        wrapper_fuses,
        lineage: include_lineage
            .then(|| permission_lineage(row))
            .transpose()?,
    })
}

fn permissions_include_lineage(include: &[String]) -> V2Result<bool> {
    let mut include_lineage = false;
    for value in include {
        match value.as_str() {
            "lineage" => include_lineage = true,
            _ => return Err(V2Error::invalid_input("include must contain only lineage")),
        }
    }
    Ok(include_lineage)
}

#[cfg(test)]
mod tests {
    use std::collections::BTreeMap;

    use bigname_storage::{EffectivePermissionScope, PermissionsCurrentAccountResourceCursor};
    use serde_json::json;
    use sqlx::types::Uuid;
    use sqlx::types::time::OffsetDateTime;

    use super::*;

    const ADDRESS: &str = "0x00000000000000000000000000000000000000aa";
    const REGISTRATION_ID: &str = "550e8400-e29b-41d4-a716-446655440000";

    fn sample_storage_cursor() -> PermissionsCurrentAccountResourceCursor {
        PermissionsCurrentAccountResourceCursor {
            subject: ADDRESS.to_owned(),
            resource_id: Uuid::parse_str(REGISTRATION_ID).expect("uuid literal must parse"),
            scope: "resource".to_owned(),
        }
    }

    fn sample_filters() -> BTreeMap<String, String> {
        BTreeMap::from([
            ("address".to_owned(), ADDRESS.to_owned()),
            ("include".to_owned(), "lineage".to_owned()),
            ("registration_id".to_owned(), REGISTRATION_ID.to_owned()),
        ])
    }

    fn sample_permissions_row(
        inheritance_path: Value,
        transfer_behavior: Value,
    ) -> EffectivePermissionRow {
        EffectivePermissionRow {
            resource_id: Uuid::parse_str(REGISTRATION_ID).expect("uuid literal must parse"),
            subject: ADDRESS.to_owned(),
            scope: EffectivePermissionScope::Direct(bigname_storage::PermissionScope::Resolver {
                chain_id: "ethereum-mainnet".to_owned(),
                resolver_address: "0x0000000000000000000000000000000000000ABC".to_owned(),
            }),
            record_resource_selector: None,
            grant_relation: None,
            effective_powers: json!(["set_resolver"]),
            grant_source: json!({
                "kind": "raw_log",
                "source_event": "EACRolesChanged",
                "upstream_resource": "root",
                "root_resource": true,
                "changed_powers": ["set_resolver"],
                "resolver_contract_instance_id": "00000000-0000-0000-0000-000000000010"
            }),
            revocation_source: Some(json!({
                "kind": "raw_log",
                "source_event": "EACRolesChanged",
                "upstream_resource": "root",
                "root_resource": true,
                "changed_powers": ["set_resolver"],
                "resolver_contract_instance_id": "00000000-0000-0000-0000-000000000011"
            })),
            inheritance_path,
            transfer_behavior,
            provenance: json!({}),
            coverage: json!({}),
            chain_positions: json!({}),
            canonicality_summary: json!({}),
            manifest_version: 1,
            last_recomputed_at: OffsetDateTime::UNIX_EPOCH,
        }
    }

    #[test]
    fn permissions_cursor_payload_round_trips_storage_cursor() {
        let cursor = sample_storage_cursor();
        let filters = sample_filters();
        let payload = permissions_cursor_payload(&cursor, &filters);

        assert_eq!(payload.filters, filters);
        assert_eq!(
            permissions_storage_cursor(&payload, &sample_filters()).expect("cursor must decode"),
            cursor
        );
        assert!(payload.snapshot.is_none());
    }

    #[test]
    fn permissions_cursor_rejects_wrong_sort_or_filters() {
        let cursor = sample_storage_cursor();
        let filters = sample_filters();

        let mut payload = permissions_cursor_payload(&cursor, &filters);
        payload.sort = "name".to_owned();
        assert!(permissions_storage_cursor(&payload, &filters).is_err());

        let mut payload = permissions_cursor_payload(&cursor, &filters);
        payload
            .filters
            .insert("namespace".to_owned(), "ens".to_owned());
        assert!(permissions_storage_cursor(&payload, &filters).is_err());

        let mut payload = permissions_cursor_payload(&cursor, &filters);
        payload.filters.remove("address");
        assert!(permissions_storage_cursor(&payload, &filters).is_err());
    }

    #[test]
    fn permissions_cursor_ignores_legacy_snapshot_component() {
        let cursor = sample_storage_cursor();
        let filters = sample_filters();
        let mut payload = permissions_cursor_payload(&cursor, &filters);
        payload.snapshot = Some("legacy-snapshot".to_owned());

        assert_eq!(
            permissions_storage_cursor(&payload, &filters)
                .expect("legacy snapshot component must not bind a latest-state cursor"),
            cursor
        );
    }

    #[test]
    fn build_permission_row_maps_scope_powers_name_and_lineage() {
        let row = sample_permissions_row(
            json!([{
                "kind": "resolver_root_fallback",
                "chain_id": "ethereum-mainnet",
                "resolver_address": "0x0000000000000000000000000000000000000ABC",
                "upstream_resource": "root"
            }]),
            Value::Null,
        );
        let name = "alice.eth".to_owned();
        let mapped = build_permission_row(
            &row,
            Some(&name),
            None,
            true,
            AuthorityContext::CurrentForName,
        )
        .expect("known storage chain id must map");

        assert_eq!(mapped.address, ADDRESS);
        assert_eq!(mapped.registration_id, REGISTRATION_ID);
        assert_eq!(mapped.name, Some("alice.eth".to_owned()));
        assert_eq!(mapped.grant.powers, json!(["set_resolver"]));
        assert_eq!(
            mapped.grant.grant_scope,
            json!({
                "kind": "resolver",
                "detail": {
                    "resolver": {
                        "chain_id": 1,
                        "address": "0x0000000000000000000000000000000000000abc"
                    }
                }
            })
        );
        assert_eq!(
            mapped.lineage,
            Some(PermissionLineage {
                grant: json!({"kind": "event"}),
                revocation: Some(json!({
                    "kind": "event"
                })),
                inheritance_path: Some(json!([{
                    "kind": "resolver_root_fallback",
                    "resolver": {
                        "chain_id": 1,
                        "address": "0x0000000000000000000000000000000000000abc"
                    }
                }])),
                transfer_behavior: None,
            })
        );
    }

    #[test]
    fn registry_operator_grants_emit_operator_relation() {
        let mut row = sample_permissions_row(json!([]), json!({"mode": "owner_scoped"}));
        row.grant_relation = Some(PermissionGrantRelation::Operator);
        row.scope = EffectivePermissionScope::Account {
            chain_id: "ethereum-mainnet".to_owned(),
            authority_kind: "registry".to_owned(),
            authority_contract: "0x0000000000000000000000000000000000000c33".to_owned(),
            owner: "0x0000000000000000000000000000000000000a11".to_owned(),
        };
        let mapped = build_permission_row(&row, None, None, false, AuthorityContext::ResourceAudit)
            .expect("registry operator grant must map");
        let value = serde_json::to_value(mapped).expect("permission row must serialize");

        assert_eq!(value["grant_relation"], json!("operator"));
    }

    #[test]
    fn lineage_omits_absent_optional_members() {
        let mut row = sample_permissions_row(json!([]), Value::Null);
        row.revocation_source = None;
        let mapped = build_permission_row(&row, None, None, true, AuthorityContext::ResourceAudit)
            .expect("known storage chain id must map");
        let lineage = mapped.lineage.expect("lineage must be present");

        assert_eq!(mapped.name, None);
        assert_eq!(lineage.grant, json!({"kind": "event"}));
        assert_eq!(lineage.revocation, None);
        assert_eq!(lineage.inheritance_path, None);
        assert_eq!(lineage.transfer_behavior, None);
    }
}
