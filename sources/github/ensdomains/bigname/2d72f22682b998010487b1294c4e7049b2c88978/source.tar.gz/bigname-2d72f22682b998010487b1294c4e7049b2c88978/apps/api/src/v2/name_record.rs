use std::collections::BTreeMap;

use axum::Json;
use axum::extract::{Path, State};
use bigname_domain::resolver_read::{IndexedRecordStatus, evaluate_indexed_record};
use bigname_storage::{BASENAMES_NAMESPACE, NameCurrentRow, RecordInventoryCurrentRow};
use serde::{Deserialize, Serialize};
use serde_json::Value;

use super::collection_snapshot::CollectionSnapshot;
use super::record_groups::{AbiSource, RecordGroups, fill_abi_content_types};
use crate::AppState;

use super::support::{
    V2_RECORD_UNSUPPORTED_FIELD_NAMES, direct_json_field, load_name_current_for_selected_snapshot,
    map_internal_api_error, normalize_inferred_route_name, record_addresses_from_entries,
    record_unsupported_fields, serving_record_inventory, snapshot_selection_api_error,
};
use super::{
    Envelope, QueryParamAllowlist, RegistryRef, RequestSource, SnapshotReadResource,
    StrictQueryParams, V2Error, V2Result, api_error_to_v2_for_resource, load_subregistry_refs,
    name_chain_id, resolve_v2_snapshot_for, snapshot_block_for_chain, snapshot_meta,
    v2_exact_name_snapshot_scope_with_resolution_auxiliary,
    vocab::{Authority, RegistrationStatus, Resolver, Source, Status},
};

#[path = "name_record/counts.rs"]
mod counts;
#[path = "name_record/declared.rs"]
mod declared;

#[path = "name_record/ens_v1.rs"]
mod ens_v1;
#[path = "name_record/inventory.rs"]
mod inventory;
#[path = "name_record/values.rs"]
mod values;
#[path = "name_record/verified.rs"]
mod verified;
#[path = "name_record/wrapper.rs"]
mod wrapper;

pub(crate) use declared::{LapsedRegistration, lapsed_registration, registration_id};
use declared::{
    chain_positions_created_at, declared_created_at, declared_expires_at, declared_grace_ends_at,
    declared_owner, declared_registered_at, declared_registration, declared_registry_owner,
};
pub(crate) use ens_v1::{EnsV1, ens_v1, ens_v1_of_registry_child, ens_v1_of_row};
use inventory::load_name_record_inventory;
pub(super) use values::{
    chain_id_from_positions, declared_token_id, identity_declared_token_id,
    identity_row_has_current_registration, identity_row_serves_resolver, json_string_at_paths,
    network_from_parts, row_has_current_registration, row_serves_resolver, string_field,
    value_to_string,
};
use values::{
    has_name_binding, json_chain_id, json_value_present, network, object_field, response_chain_id,
};
pub(crate) use wrapper::{served_manager, wrapper_lifecycle_matches_fuses, wrapper_metadata};
pub(crate) struct NameRecordQueryParams;
impl QueryParamAllowlist for NameRecordQueryParams {
    const ALLOWED: &'static [&'static str] = &["namespace", "at", "finality", "source", "include"];
}

pub(crate) type NameRecordQuery = StrictQueryParams<NameRecordQueryParams>;

#[derive(Clone, Debug, Deserialize, PartialEq, Serialize)]
pub(crate) struct NameRecord {
    #[serde(skip_serializing_if = "Option::is_none")]
    pub(crate) registration_id: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub(crate) token_id: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub(crate) owner: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub(crate) manager: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub(crate) registered_at: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub(crate) created_at: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub(crate) expires_at: Option<crate::v2::timestamps::ExpiryTimestamp>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub(crate) expires_at_reason: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub(crate) grace_ends_at: Option<crate::v2::timestamps::ExpiryTimestamp>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub(crate) registration_status: Option<RegistrationStatus>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub(crate) authority: Option<Authority>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub(crate) ens_v1: Option<EnsV1>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub(crate) lapsed_registration: Option<LapsedRegistration>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub(crate) migrated_at: Option<String>,
    pub(crate) name: String,
    pub(crate) display_name: String,
    pub(crate) namespace: String,
    pub(crate) namehash: String,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub(crate) resolver: Option<Resolver>,
    /// Why the name resolves to nothing through the Universal Resolver although its authority
    /// records a resolver: `no_live_ens_v2_entry` once the chain resolves through ENSv2 and the
    /// `.eth` name has no live ENSv2 entry. Its resolver and records are then withheld.
    #[serde(skip_serializing_if = "Option::is_none")]
    pub(crate) unresolvable_reason: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub(crate) subregistry: Option<RegistryRef>,
    /// Present when the name may serve resolver records and has a record inventory, or on a
    /// verified read that requested keys (`record_groups.rs`).
    #[serde(skip_serializing_if = "Option::is_none")]
    pub(crate) records: Option<RecordGroups>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub(crate) primary_name: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub(crate) primary_address: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub(crate) chain_id: Option<u64>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub(crate) network: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub(crate) subname_count: Option<u64>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub(crate) record_count: Option<u64>,
    pub(crate) status: Status,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub(crate) unsupported_reason: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub(crate) failure_reason: Option<String>,
    #[serde(skip_serializing_if = "Vec::is_empty")]
    pub(crate) unsupported_fields: Vec<String>,
}

pub(crate) async fn get_name_record(
    Path(input_name): Path<String>,
    params: NameRecordQuery,
    State(state): State<AppState>,
) -> V2Result<Json<Envelope<NameRecord>>> {
    let params = params.into_inner();
    let normalized = normalize_inferred_route_name(&input_name)
        .map_err(|error| V2Error::invalid_input(error.message))?;
    let namespace = params
        .namespace
        .clone()
        .unwrap_or_else(|| normalized.namespace.to_owned());
    let route_source = route_source(params.source)?;
    let include_counts = counts::include_counts(&params.include)?;
    let mut count_snapshot = if include_counts {
        Some(CollectionSnapshot::capture_for_namespace(&state, None, Some(&namespace)).await?)
    } else {
        None
    };

    let include_resolution_auxiliary =
        namespace == BASENAMES_NAMESPACE && route_source == Source::Verified;
    let scope = v2_exact_name_snapshot_scope_with_resolution_auxiliary(
        &state,
        &namespace,
        params.at.as_ref(),
        include_resolution_auxiliary,
    )
    .await?;
    let mut selected_snapshot = resolve_v2_snapshot_for(
        &state.pool,
        &scope,
        params.at.as_ref(),
        params.finality,
        SnapshotReadResource::Name,
    )
    .await?;
    let row = load_name_current_for_selected_snapshot(
        &state.pool,
        &namespace,
        &normalized.normalized_name,
        &selected_snapshot,
    )
    .await
    .map_err(|error| {
        api_error_to_v2_for_resource(
            map_internal_api_error(
                error,
                format!(
                    "failed to load name profile for {}/{}",
                    namespace, normalized.normalized_name
                ),
            ),
            SnapshotReadResource::Name,
        )
    })?;

    let record_inventory = if row_has_current_registration(&row) {
        load_name_record_inventory(&state.pool, &row, &selected_snapshot)
            .await
            .map_err(|error| {
                api_error_to_v2_for_resource(
                    snapshot_selection_api_error(error),
                    SnapshotReadResource::Name,
                )
            })?
    } else {
        None
    };
    let chain_id = response_chain_id(&selected_snapshot);
    let mut record = verified::build_name_record_for_source(
        &state,
        &row,
        record_inventory.as_ref(),
        chain_id,
        &mut selected_snapshot,
        route_source,
    )
    .await?;
    if let Some(groups) = record.records.as_mut() {
        let source = record_inventory
            .as_ref()
            .map(AbiSource::of_row)
            .transpose()?;
        fill_abi_content_types(&state.pool, vec![(groups, source.as_ref())]).await?;
    }
    let as_of_block = name_chain_id(&row)
        .and_then(|chain_id| snapshot_block_for_chain(&selected_snapshot, &chain_id));
    if record.status != Status::Unsupported {
        record.subregistry = load_subregistry_refs(
            &state.pool,
            std::slice::from_ref(&row.logical_name_id),
            as_of_block,
        )
        .await?
        .remove(&row.logical_name_id);
    }
    if record.authority == Some(Authority::EnsV2) {
        record.migrated_at =
            load_migrated_at(&state.pool, std::slice::from_ref(&row.logical_name_id))
                .await?
                .remove(&row.logical_name_id);
    }
    counts::apply(
        &state,
        &row,
        &selected_snapshot,
        count_snapshot.as_mut(),
        &mut record,
    )
    .await?;
    let mut meta = snapshot_meta(&selected_snapshot)?;
    meta.source = Some(route_source);

    Ok(Json(Envelope {
        data: record,
        page: None,
        meta,
    }))
}

/// Decimal Unix-second `migrated_at` per logical name for names whose current ENSv2 authority was proven by
/// an ENSv1→ENSv2 migration transition; other names are absent.
pub(crate) async fn load_migrated_at(
    db: impl Into<bigname_storage::ReadDb<'_>>,
    logical_name_ids: &[String],
) -> V2Result<BTreeMap<String, String>> {
    let transitions =
        bigname_storage::load_name_migration_transition_timestamps(db, logical_name_ids)
            .await
            .map_err(|_| V2Error::internal_error("failed to load name migration transitions"))?;
    Ok(transitions
        .into_iter()
        .map(|(logical_name_id, timestamp)| (logical_name_id, super::format_timestamp(timestamp)))
        .collect())
}

pub(crate) fn build_name_record(
    row: &NameCurrentRow,
    record_inventory: Option<&RecordInventoryCurrentRow>,
    chain_id: Option<u64>,
    status: Status,
) -> V2Result<NameRecord> {
    let registration = name_registration_fields(Some(row), &row.namespace);
    // Current registrations and explicitly classified ownerless registry read paths may
    // expose their selected resolver resource; other retained state remains audit-only.
    let has_current_registration = row_has_current_registration(row);
    let record_inventory = record_inventory.filter(|_| has_current_registration);
    let unsupported_fields = unsupported_fields(record_inventory);
    let field_supported = |field: &str| {
        !unsupported_fields
            .iter()
            .any(|unsupported| unsupported == field)
    };
    // `primary_address` keeps the flat coin-60 answer, including the default-address derivation.
    let addresses = field_supported("addresses").then(|| {
        let mut addresses = record_addresses(record_inventory);
        if !addresses.contains_key("60")
            && let Some(inventory) = record_inventory
        {
            let answer = evaluate_indexed_record(
                &inventory.entries,
                &inventory.provenance,
                &inventory.coverage,
                "addr:60",
                "addr",
                Some("60"),
            );
            if answer.status == IndexedRecordStatus::Success
                && let Some(value) = answer
                    .value
                    .and_then(|value| value.as_str().map(str::to_owned))
            {
                addresses.insert("60".to_owned(), value);
            }
        }
        addresses
    });
    let primary_address = field_supported("primary_address")
        .then(|| {
            addresses
                .as_ref()
                .and_then(|addresses| addresses.get("60").cloned())
        })
        .flatten();
    let authority = Authority::from_provenance(&row.provenance);
    let ens_v1 = ens_v1(authority, &row.declared_summary)?;
    let resolver = row_serves_resolver(row)
        .then(|| resolver(&row.declared_summary))
        .flatten();

    Ok(NameRecord {
        registration_id: (registration.registration_status != RegistrationStatus::Unregistered)
            .then(|| registration_id(&row.declared_summary, row.resource_id))
            .flatten(),
        token_id: if has_name_binding(row) {
            declared_token_id(row)
        } else {
            None
        },
        owner: registration.owner,
        manager: registration.manager,
        registered_at: registration.registered_at,
        created_at: registration.created_at,
        expires_at: registration.expires_at,
        expires_at_reason: registration.expires_at_reason,
        grace_ends_at: registration.grace_ends_at,
        registration_status: Some(registration.registration_status),
        authority,
        ens_v1,
        lapsed_registration: lapsed_registration(&row.declared_summary),
        migrated_at: None,
        name: row.normalized_name.clone(),
        display_name: row.canonical_display_name.clone(),
        namespace: row.namespace.clone(),
        namehash: row.namehash.clone(),
        resolver,
        unresolvable_reason: row.unresolvable_reason().map(str::to_owned),
        subregistry: None,
        records: record_inventory.map(|inventory| RecordGroups::indexed(inventory.into())),
        primary_name: json_string_at_paths(
            &row.declared_summary,
            &[
                &["primary_name"],
                &["primary_name", "name"],
                &["primary", "name"],
            ],
        ),
        primary_address,
        chain_id,
        network: Some(network(row)),
        subname_count: None,
        record_count: None,
        status,
        unsupported_reason: None,
        failure_reason: None,
        // The record categories carry their own unknown values; only the flat
        // `primary_address` still reports that it could not be served.
        unsupported_fields: unsupported_fields
            .into_iter()
            .filter(|field| field == "primary_address")
            .collect(),
    })
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub(super) struct NameRegistrationFields {
    pub(super) owner: Option<String>,
    pub(super) manager: Option<String>,
    pub(super) registered_at: Option<String>,
    pub(super) created_at: Option<String>,
    pub(super) expires_at: Option<crate::v2::timestamps::ExpiryTimestamp>,
    pub(super) expires_at_reason: Option<String>,
    pub(super) grace_ends_at: Option<crate::v2::timestamps::ExpiryTimestamp>,
    pub(super) registration_status: RegistrationStatus,
}

pub(super) fn name_registration_fields(
    row: Option<&NameCurrentRow>,
    namespace: &str,
) -> NameRegistrationFields {
    let Some(row) = row else {
        return empty_registration_fields(namespace);
    };

    registration_fields_from_parts(
        &row.namespace,
        &row.declared_summary,
        &row.chain_positions,
        has_name_binding(row),
    )
}

pub(super) fn identity_name_registration_fields(
    row: Option<&bigname_storage::IdentityNameCurrentRow>,
    namespace: &str,
) -> NameRegistrationFields {
    let Some(row) = row else {
        return empty_registration_fields(namespace);
    };

    registration_fields_from_parts(
        &row.namespace,
        &row.declared_summary,
        &row.chain_positions,
        row.resource_id.is_some(),
    )
}

fn empty_registration_fields(namespace: &str) -> NameRegistrationFields {
    NameRegistrationFields {
        owner: None,
        manager: None,
        registered_at: None,
        created_at: None,
        expires_at: None,
        expires_at_reason: None,
        grace_ends_at: None,
        registration_status: classify_registration_status(namespace, None, None, false),
    }
}

fn registration_fields_from_parts(
    namespace: &str,
    declared_summary: &Value,
    chain_positions: &Value,
    has_binding: bool,
) -> NameRegistrationFields {
    let registration = declared_registration(declared_summary);
    let owner = declared_owner(declared_summary);

    NameRegistrationFields {
        manager: served_manager(
            declared_summary,
            owner.as_ref(),
            declared_registry_owner(declared_summary).as_ref(),
        ),
        registered_at: declared_registered_at(declared_summary),
        created_at: declared_created_at(declared_summary)
            .or_else(|| chain_positions_created_at(chain_positions)),
        expires_at: declared_expires_at(declared_summary),
        expires_at_reason: declared_summary
            .pointer("/registration/expires_at_reason")
            .and_then(Value::as_str)
            .map(str::to_owned),
        grace_ends_at: declared_grace_ends_at(declared_summary),
        registration_status: classify_registration_status(
            namespace,
            registration,
            owner.as_deref(),
            has_binding,
        ),
        owner,
    }
}

pub(crate) fn classify_registration_status(
    namespace: &str,
    registration: Option<&Value>,
    owner: Option<&str>,
    has_binding: bool,
) -> RegistrationStatus {
    // Classification is state at the indexed head. A registrar name past grace
    // whose release block is not indexed yet still reads active with a past
    // expires_at until reprojection observes released_at/status=released.
    if !has_binding {
        return RegistrationStatus::Unregistered;
    }

    let status = registration.and_then(|value| string_field(value.get("status")));
    let authority_kind = registration.and_then(|value| string_field(value.get("authority_kind")));
    let released_at = registration.and_then(|value| value.get("released_at"));

    if released_at.is_some_and(json_value_present) || status.as_deref() == Some("released") {
        return RegistrationStatus::Released;
    }

    match authority_kind.as_deref() {
        Some("registrar") => RegistrationStatus::Active,
        Some("registry_only") if owner.is_some_and(|value| !value.trim().is_empty()) => {
            RegistrationStatus::Registered
        }
        Some("ens_v2_registry") if owner.is_some_and(|value| !value.trim().is_empty()) => {
            RegistrationStatus::Registered
        }
        Some("wrapper") if namespace != bigname_storage::BASENAMES_NAMESPACE => {
            RegistrationStatus::Wrapped
        }
        // At this point the name is bound; an unrecognized authority_kind or
        // missing required owner evidence cannot be classified as registered.
        _ => RegistrationStatus::Unregistered,
    }
}

pub(super) fn resolver(summary: &Value) -> Option<Resolver> {
    let resolver = object_field(summary, "resolver")?;
    let address = string_field(resolver.get("address"))
        .map(|value| value.to_ascii_lowercase())
        .filter(|value| !value.trim().is_empty())?;
    let chain_id = resolver.get("chain_id").and_then(json_chain_id)?;

    Some(Resolver { chain_id, address })
}

pub(super) fn record_addresses(
    record_inventory: Option<&RecordInventoryCurrentRow>,
) -> BTreeMap<String, String> {
    record_addresses_from_entries(
        record_inventory.map(|inventory| &inventory.entries),
        direct_json_field,
    )
}

fn unsupported_fields(record_inventory: Option<&RecordInventoryCurrentRow>) -> Vec<String> {
    record_unsupported_fields(
        serving_record_inventory(record_inventory).is_some(),
        record_inventory.map(|inventory| &inventory.unsupported_families),
        direct_json_field,
        V2_RECORD_UNSUPPORTED_FIELD_NAMES,
    )
    .into_iter()
    .collect()
}

fn route_source(source: RequestSource) -> V2Result<Source> {
    match source {
        RequestSource::Indexed => Ok(Source::Indexed),
        RequestSource::Verified => Ok(Source::Verified),
        RequestSource::Auto => Err(V2Error::invalid_input(
            "source must be one of: indexed, verified",
        )),
    }
}

#[cfg(test)]
mod tests;
