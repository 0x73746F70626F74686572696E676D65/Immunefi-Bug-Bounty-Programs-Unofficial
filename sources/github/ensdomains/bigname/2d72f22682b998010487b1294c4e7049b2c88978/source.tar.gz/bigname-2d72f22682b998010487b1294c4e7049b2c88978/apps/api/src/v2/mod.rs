mod address_history;
mod address_names;
mod cache_headers;
mod chains;
pub(crate) mod collection_snapshot;
mod cursor;
mod diag_events;
mod diag_namespace_manifests;
mod diagnostics;
mod envelope;
mod error;
mod event_data;
mod events;
mod history;
mod history_context;
mod history_filters;
pub(crate) mod history_keyset;
mod list_cursor;
pub(crate) mod lookup;
mod name_filter;
mod name_record;
mod name_records;
#[cfg(test)]
pub(crate) use name_records::auto_fallback_test_hooks as name_records_auto_fallback_test_hooks;
mod name_records_inventory;
#[cfg(test)]
pub(crate) use name_records_inventory::abi_content_types_test_hooks;
mod names;
mod namespaces;
mod params;
mod permission_support;
mod permission_values;
mod permissions;
mod primary_name;
pub(crate) mod record_groups;
mod registries;
mod resolvers;
#[cfg(test)]
pub(crate) use resolvers::generation_test_hooks as resolver_generation_test_hooks;
mod restrictions;
mod router;
mod search;
mod snapshots;
mod status;
mod strict_query;
mod subnames;
pub(crate) mod support;
mod vocab;

pub(crate) use address_history::get_address_history;
#[cfg(test)]
pub(crate) use address_history::{AddressHistoryCursorBinding, address_history_cursor_payload};
#[cfg(test)]
pub(crate) use address_names::grant_read_test_hooks as address_names_grant_read_test_hooks;
pub(crate) use address_names::{AddressNameGrant, AddressNameResolution, get_address_names};
pub(crate) use chains::{
    all_chain_slugs, numeric_to_slug, slug_to_numeric, snapshot_slot_for_slug,
};
pub(crate) use cursor::{Payload as CursorPayload, decode, encode};
pub(crate) use diag_events::get_diagnostic_events;
pub(crate) use diag_namespace_manifests::get_diagnostic_namespace_manifests;
pub(crate) use diagnostics::{
    get_name_authority_diagnostic, get_name_binding_diagnostic, get_name_coverage_diagnostic,
    get_name_records_diagnostic,
};
pub(crate) use envelope::{AsOfCompleteness, Envelope, Meta, Page};
#[cfg(test)]
pub(crate) use error::ErrorCode;
pub(crate) use error::{V2Error, V2Result};
pub(crate) use event_data::{
    EventDetail, HistoryInclude, build_event_detail, history_include, raw_event_kind,
};
pub(crate) use events::{
    Event, build_event, events_cursor_payload, events_storage_cursor, get_events,
};
pub(crate) use history::{
    HISTORY_TOTAL_COUNT_CAP, format_timestamp, get_history, history_event_id, history_event_type,
    history_page_options, history_sort_token, history_storage_order, history_storage_scope,
    history_total_count, insert_history_filter_keys, map_history_page_error,
    product_history_event_kinds, resolve_history_block_window, v2_exact_name_snapshot_scope,
    v2_exact_name_snapshot_scope_with_resolution_auxiliary,
};
#[cfg(test)]
pub(crate) use history::{HistoryCursorBinding, history_cursor_payload};
pub(crate) use lookup::get_lookup;
#[cfg(test)]
pub(crate) use lookup::served_head_initial_validation_test_hooks as lookup_served_head_initial_validation_test_hooks;
#[cfg(test)]
pub(crate) use lookup::served_head_revalidation_test_hooks as lookup_served_head_revalidation_test_hooks;
pub(crate) use name_record::{NameRecord, build_name_record, get_name_record};
pub(crate) use name_records::{
    RecordAnswer, RecordSelection, build_indexed_name_records, build_verified_name_records,
    get_name_records, load_ephemeral_verified_record_lookup, parse_record_keys,
};
pub(crate) use name_records_inventory::{default_requested_records, validate_product_record};
pub(crate) use names::get_names;
pub(crate) use namespaces::get_namespace;
pub(crate) use params::{
    AtSelector, DEFAULT_PAGE_SIZE, MAX_PAGE_SIZE, QueryParams, RawQueryParams, RequestSource,
    SortOrder, parse_relation_set_param, validate_latest_collection_selectors,
};
pub(crate) use permission_values::{
    GrantRelation, effective_permission_scope_value, permission_grant_relation,
    permission_powers_value, permission_scope_value, record_resource_value,
};
pub(crate) use permissions::get_permissions;
pub(crate) use primary_name::get_primary_name;
pub(crate) use registries::{
    RegistryRef, get_registry, get_registry_labels, load_subregistry_refs, name_chain_id,
    snapshot_block_for_chain,
};
#[cfg(test)]
#[allow(unused_imports)]
pub(crate) use resolvers::{
    BoundNames, BoundNamesCursorBinding, bound_names_next_cursor, bound_names_storage_cursor,
    build_resolver_overview,
};
pub(crate) use resolvers::{
    get_resolver, get_resolver_links, get_resolver_roles, parse_numeric_chain_id,
    resolver_snapshot_scope,
};
pub(crate) use search::get_search;
#[cfg(test)]
pub(crate) use search::public_namespace_read_test_hooks as search_public_namespace_read_test_hooks;
pub(crate) use snapshots::{
    SnapshotReadResource, api_error_to_v2, api_error_to_v2_for_resource, as_of_meta,
    decode_at_token, encode_at_token, name_rows_error, resolve_v2_snapshot_for,
    sanitized_snapshot_internal_error, snapshot_meta, stale_name_rows_api_error,
};
pub(crate) use status::get_status;
pub(crate) use strict_query::{
    NoQueryParams, QueryParamAllowlist, StrictQueryParams, parse_raw_query_params_with_allowlist,
};
pub(crate) use subnames::get_subnames;
#[cfg(test)]
#[allow(unused_imports)]
pub(crate) use vocab::matched_boundary_vocabulary_terms;
pub(crate) use vocab::{
    AddressNamesDedupe, AddressNamesSort, Authority, AuthoritySet, Completeness, Finality,
    HistoryEventType, HistoryScope, OpsStatus, PRODUCT_PIPELINE_TERMS, RegistrationStatus,
    Relation, RelationSet, Resolver, Source, Status, contains_boundary_vocabulary,
    shared_product_reason,
};

use axum::Router;

use crate::state::AppState;

pub(crate) fn router() -> Router<AppState> {
    router::router()
}

mod timestamps;

#[cfg(test)]
#[path = "../tests/openapi_vocabulary.rs"]
mod openapi_vocabulary;
