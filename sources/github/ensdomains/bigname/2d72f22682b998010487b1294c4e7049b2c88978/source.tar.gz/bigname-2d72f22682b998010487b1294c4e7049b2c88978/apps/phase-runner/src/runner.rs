use std::{
    collections::BTreeMap,
    sync::{Arc, OnceLock},
};

use tokio_util::sync::CancellationToken;
use tracing::warn;

use crate::{
    capacity::CapacityGuard,
    config::{ChainConfig, TimingConfig},
    database::RunnerDatabase,
    error::{ErrorKind, RunnerError, RunnerResult, VERIFICATION_MISMATCH_PREFIX},
    phase::{Phase, PhaseBatchOutcome, PhaseName, PhaseSet, RunMode},
    phase_lock::PhaseLock,
    progress_monitor::RunnerPhaseProgress,
    runner_support::{
        Backoff, HeartbeatThrottle, PhaseLoopResult, StopClock, cancelled_redo_error,
        finish_failed_redo_start, finish_stopped_redo_start, redo_outcome,
        release_lock_racing_stop,
    },
    shutdown::until_cancelled,
    state::PhaseStore,
};

#[path = "runner_batch.rs"]
mod batch;
#[path = "runner_capacity.rs"]
mod capacity_wait;
#[path = "runner_chain.rs"]
mod chain;
use chain::bounded_recovery;
#[path = "runner_context.rs"]
mod context;
#[path = "runner_live_follow.rs"]
mod live_follow;
#[path = "runner_attestation.rs"]
mod manifest_attestation;
#[path = "runner_operator_redo.rs"]
mod operator_redo;
#[path = "runner_recovery.rs"]
mod recovery;
#[path = "runner_required_redo.rs"]
mod required_redo;
#[path = "runner_restart.rs"]
mod restart;

pub(super) type LiveMismatchReason = Arc<OnceLock<String>>;

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum RedoPhase {
    Phase(PhaseName),
    RecomputeFlags,
    All,
}

#[derive(Clone, Debug, Default, Eq, PartialEq)]
pub struct SupervisorReport {
    pub stopped_chains: Vec<(String, RunnerError)>,
}

#[derive(Clone)]
pub struct PhaseRunner {
    database: RunnerDatabase,
    store: PhaseStore,
    phases: PhaseSet,
    capacity: CapacityGuard,
    instance_id: Arc<str>,
    timing: TimingConfig,
    watch_set_coverage_attestations: BTreeMap<String, String>,
    manifest_authority_audit_before_emit: Option<Arc<dyn Fn() + Send + Sync>>,
    before_redo_progress_write: Option<batch::BeforeRedoProgressWrite>,
    before_phase_context: Option<context::BeforePhaseContext>,
    after_required_redo_catch_up: Option<live_follow::AfterRequiredRedoCatchUp>,
    loop_heartbeat: Option<crate::metrics::RunnerLoopHeartbeat>,
    phase_progress: RunnerPhaseProgress,
    metrics_feed: crate::metrics::RunnerMetricsFeed,
    stop_budget: std::time::Duration,
    chain_stop_clocks: Arc<std::sync::Mutex<BTreeMap<String, Arc<StopClock>>>>,
    capacity_memo: Arc<capacity_wait::CapacityMemo>,
}

impl PhaseRunner {
    pub fn new(
        database: RunnerDatabase,
        phases: PhaseSet,
        capacity: CapacityGuard,
        instance_id: impl Into<String>,
        timing: TimingConfig,
    ) -> RunnerResult<Self> {
        timing.validate()?;
        let instance_id = instance_id.into();
        if instance_id.trim().is_empty() {
            return Err(RunnerError::new(
                ErrorKind::Configuration,
                "runner instance id must not be empty",
            ));
        }
        let store = PhaseStore::new(database.pool().clone());
        Ok(Self {
            database,
            store,
            phases,
            capacity,
            instance_id: Arc::from(instance_id),
            timing,
            watch_set_coverage_attestations: BTreeMap::new(),
            manifest_authority_audit_before_emit: None,
            before_redo_progress_write: None,
            before_phase_context: None,
            after_required_redo_catch_up: None,
            loop_heartbeat: None,
            phase_progress: RunnerPhaseProgress::default(),
            metrics_feed: crate::metrics::RunnerMetricsFeed::default(),
            stop_budget: StopClock::DEFAULT_BUDGET,
            chain_stop_clocks: Arc::new(std::sync::Mutex::new(BTreeMap::new())),
            capacity_memo: Arc::default(),
        })
    }

    pub fn with_watch_set_coverage_attestations(
        mut self,
        attestations: BTreeMap<String, String>,
    ) -> Self {
        self.watch_set_coverage_attestations = attestations;
        self
    }

    pub fn with_watch_set_coverage_attestation(
        mut self,
        chain_id: impl Into<String>,
        generation_token: impl Into<String>,
    ) -> Self {
        self.watch_set_coverage_attestations
            .insert(chain_id.into(), generation_token.into());
        self
    }

    /// A stop that wins before the phase transition commits leaves nothing to
    /// record for a normal run; a redo still has to report itself incomplete.
    async fn stopped_before_start(
        &self,
        stop_clock: &StopClock,
        chain: &ChainConfig,
        phase_name: PhaseName,
        mode: &RunMode,
    ) -> RunnerResult<()> {
        if mode.is_redo() {
            return Err(
                cancelled_redo_error(stop_clock, &self.store, &chain.chain_id, phase_name).await?,
            );
        }
        Ok(())
    }

    /// Resets `backoff` whenever a batch settles, so a failure after progress waits only the
    /// initial delay.
    #[allow(clippy::too_many_arguments)]
    async fn run_phase_once(
        &self,
        chain: &ChainConfig,
        phase: Arc<dyn Phase>,
        mode: RunMode,
        cancellation: CancellationToken,
        automatic_discovery_ingest: bool,
        backoff: &mut Backoff,
    ) -> RunnerResult<()> {
        let phase_name = phase.name();
        // Each attempt has its own stop budget, so a stop that lands during its
        // batch bounds this attempt's records and release from the moment they
        // begin, whatever another chain or the paired phase is doing.
        let stop_clock = StopClock::new(self.stop_budget);
        // The lock opens its own connection and probes it, both of which can stall
        // on the network; a stop accepted meanwhile must not wait for them.
        let acquired = until_cancelled(&cancellation, async {
            let mut phase_lock =
                PhaseLock::acquire(self.database.connect_options(), &chain.chain_id, phase_name)
                    .await?;
            phase_lock.check_alive().await?;
            Ok(phase_lock)
        })
        .await?;
        let Some(mut phase_lock) = acquired else {
            return self
                .stopped_before_start(&stop_clock, chain, phase_name, &mode)
                .await;
        };
        let result = self
            .run_locked_phase(
                &stop_clock,
                chain,
                phase,
                mode,
                cancellation.clone(),
                automatic_discovery_ingest,
                &mut phase_lock,
                backoff,
            )
            .await;
        let release = release_lock_racing_stop(
            &stop_clock,
            phase_lock,
            &chain.chain_id,
            phase_name,
            &cancellation,
        )
        .await;
        match (result, release) {
            (Ok(()), Ok(())) => Ok(()),
            (Ok(()), Err(error)) => Err(error),
            (Err(error), Ok(())) => Err(error),
            (Err(error), Err(release_error)) => {
                warn!(
                    chain_id = chain.chain_id,
                    phase = %phase_name,
                    error = %release_error,
                    "phase lock release also failed"
                );
                Err(error)
            }
        }
    }

    #[allow(clippy::too_many_arguments)]
    async fn run_locked_phase(
        &self,
        stop_clock: &StopClock,
        chain: &ChainConfig,
        phase: Arc<dyn Phase>,
        mode: RunMode,
        cancellation: CancellationToken,
        automatic_discovery_ingest: bool,
        phase_lock: &mut PhaseLock,
        backoff: &mut Backoff,
    ) -> RunnerResult<()> {
        let phase_name = phase.name();
        // Start-up is raced like the batch loop, from the lock in `run_phase_once`
        // through the identity check, the phase transition and the heartbeat: all
        // wait on rows without a timeout, and a stop accepted during them must not
        // be held until the grace period ends. A transition that loses the race is
        // dropped before it commits.
        let identity = until_cancelled(
            &cancellation,
            self.check_ingest_identity(phase_name, chain, &mode),
        )
        .await;
        match identity {
            Ok(Some(())) => {}
            Ok(None) => {
                return self
                    .stopped_before_start(stop_clock, chain, phase_name, &mode)
                    .await;
            }
            Err(error) => {
                return self
                    .record_phase_validation_failure(
                        stop_clock,
                        &chain.chain_id,
                        phase_name,
                        &mode,
                        phase_lock,
                        &cancellation,
                        error,
                    )
                    .await;
            }
        }
        let supplied_manifest_authority_generation = (phase_name == PhaseName::Interpret)
            .then(|| self.supplied_manifest_attestation_generation(&chain.chain_id))
            .flatten();
        let redo_session = if mode.is_redo() {
            let begun = until_cancelled(
                &cancellation,
                self.store.begin_redo(
                    &chain.chain_id,
                    phase_name,
                    &mode,
                    chain.intake_sources().as_ref(),
                    supplied_manifest_authority_generation.as_deref(),
                    &self.instance_id,
                    automatic_discovery_ingest,
                ),
            )
            .await?;
            let Some(session) = begun else {
                return self
                    .stopped_before_start(stop_clock, chain, phase_name, &mode)
                    .await;
            };
            if phase_name == PhaseName::Interpret
                && let Some(audit) = session.manifest_authority_audit.as_ref()
            {
                self.before_manifest_authority_audit_emit();
                audit.emit();
            }
            Some(session)
        } else {
            let started = until_cancelled(
                &cancellation,
                self.start_normal_phase(
                    stop_clock,
                    chain,
                    Arc::clone(&phase),
                    phase_lock,
                    &cancellation,
                ),
            )
            .await?;
            if started != Some(true) {
                return Ok(());
            }
            None
        };
        let redo_attempt = redo_session.as_ref().map(|session| session.attempt_fence());
        // The lock probe after the transition is an unbounded `SELECT 1` on the
        // lock's own connection, so it is raced with the heartbeat start.
        let heartbeat = until_cancelled(&cancellation, async {
            phase_lock.check_alive().await?;
            self.store
                .start_heartbeat(&self.instance_id, &chain.chain_id, phase_name)
                .await
        })
        .await;
        let started = match heartbeat {
            Ok(Some(())) => Ok(()),
            Ok(None) => {
                let Some(session) = redo_session else {
                    return Ok(());
                };
                let error =
                    cancelled_redo_error(stop_clock, &self.store, &chain.chain_id, phase_name)
                        .await?;
                return Err(finish_stopped_redo_start(
                    stop_clock,
                    &self.store,
                    phase_lock,
                    &chain.chain_id,
                    phase_name,
                    session,
                    error,
                )
                .await);
            }
            Err(error) => Err(error),
        };
        if let Err(error) = started {
            // The probe and the failed-start record run on the lock's connection;
            // a stop arriving now bounds them, as it does the bookkeeping after
            // the loop.
            let Some(session) = redo_session else {
                return Err(error);
            };
            return bounded_recovery(
                stop_clock,
                "phase start failure recording",
                &chain.chain_id,
                &cancellation,
                async {
                    phase_lock.check_alive().await?;
                    finish_failed_redo_start(
                        &self.store,
                        phase_lock.connection(),
                        &chain.chain_id,
                        phase_name,
                        session,
                        error,
                    )
                    .await
                },
            )
            .await;
        }
        let mut heartbeat = HeartbeatThrottle::new();
        let result = self
            .run_phase_batches(
                stop_clock,
                chain,
                phase,
                batch::Execution::new(mode.clone(), redo_attempt),
                cancellation.clone(),
                &mut heartbeat,
                phase_lock,
                backoff,
            )
            .await;
        let result = match result {
            Ok(PhaseLoopResult::Cancelled) if mode.is_redo() => {
                Err(
                    cancelled_redo_error(stop_clock, &self.store, &chain.chain_id, phase_name)
                        .await?,
                )
            }
            result => result,
        };
        if let Err(error) = &result
            && !error.permits_pool_writes_after_error()
        {
            return Err(error.clone());
        }
        if let Some(session) = redo_session {
            // The lock's connection may be the stall a stop is waiting out; the
            // probe and the redo bookkeeping on it are bounded once a stop is
            // pending, whether it was already or arrives during them.
            let restore = bounded_recovery(
                stop_clock,
                "redo bookkeeping",
                &chain.chain_id,
                &cancellation,
                async {
                    phase_lock.check_alive().await?;
                    self.store
                        .finish_redo(
                            phase_lock.connection(),
                            &chain.chain_id,
                            phase_name,
                            session,
                            redo_outcome(&result),
                        )
                        .await
                },
            )
            .await;
            return match (result, restore) {
                (Ok(_), Ok(())) => Ok(()),
                (Ok(_), Err(error)) => Err(error),
                (Err(error), Ok(())) => Err(error),
                (Err(error), Err(restore_error)) => {
                    Err(error.with_secondary("record phase state after redo", restore_error))
                }
            };
        }
        // Completion and failure are recorded on the lock's connection, which after
        // a stop may be the stall that ended the loop; both are bounded then, like
        // the redo bookkeeping above.
        match result {
            Ok(PhaseLoopResult::Completed(progress)) => {
                bounded_recovery(
                    stop_clock,
                    "phase completion",
                    &chain.chain_id,
                    &cancellation,
                    async {
                        phase_lock.check_alive().await?;
                        self.store
                            .complete_phase_with_lock(
                                phase_lock,
                                &chain.chain_id,
                                phase_name,
                                &progress,
                            )
                            .await
                    },
                )
                .await
            }
            Ok(PhaseLoopResult::Cancelled) => {
                // Only a stop produces this arm, so a probe of the lock here would
                // wait on the connection whose stall may have won; the release
                // that follows is bounded and detects a lost lock itself. A Live
                // mismatch is recorded by the live-follow loop that owns it.
                Ok(())
            }
            Err(error) => {
                let failure_reason = if phase_name == PhaseName::Verify
                    && error.kind() == ErrorKind::VerificationMismatch
                {
                    format!("{VERIFICATION_MISMATCH_PREFIX}{error}")
                } else {
                    error.to_string()
                };
                let record = bounded_recovery(
                    stop_clock,
                    "phase failure recording",
                    &chain.chain_id,
                    &cancellation,
                    async {
                        phase_lock.check_alive().await?;
                        self.store
                            .fail_phase(&chain.chain_id, phase_name, &failure_reason)
                            .await
                    },
                )
                .await;
                if let Err(record_error) = record {
                    return Err(error.with_secondary("record phase failure", record_error));
                }
                Err(error)
            }
        }
    }

    #[allow(clippy::too_many_arguments)]
    async fn run_phase_batches(
        &self,
        stop_clock: &StopClock,
        chain: &ChainConfig,
        phase: Arc<dyn Phase>,
        execution: batch::Execution,
        cancellation: CancellationToken,
        heartbeat: &mut HeartbeatThrottle,
        phase_lock: &mut PhaseLock,
        backoff: &mut Backoff,
    ) -> RunnerResult<PhaseLoopResult> {
        let batch::Execution { mode, redo_attempt } = execution;
        let phase_name = phase.name();
        let mut reserved_write_bytes = 0;
        loop {
            if cancellation.is_cancelled() {
                return Ok(PhaseLoopResult::Cancelled);
            }
            // Everything between the check above and the batch waits on the
            // database — the lock probe, the capacity probe and its pause and
            // resume writes, the context reads — so the whole prelude is raced.
            // A write dropped mid-flight rolls back; a stop after a pause
            // committed leaves the phase paused, which is where a stop inside
            // the capacity wait already left it.
            let prelude = until_cancelled(&cancellation, async {
                phase_lock.check_alive().await?;
                if self
                    .wait_for_capacity(
                        chain,
                        phase_name,
                        reserved_write_bytes,
                        capacity_wait::Measure::Fresh,
                        &cancellation,
                        heartbeat,
                        phase_lock,
                    )
                    .await?
                {
                    return Ok(None);
                }
                self.phase_context(chain, phase_name, mode.clone(), redo_attempt)
                    .await
                    .map(Some)
            })
            .await?;
            let Some(context) = prelude.flatten() else {
                return Ok(PhaseLoopResult::Cancelled);
            };
            let progress_token = self.phase_progress.begin_batch(&context);
            let retained_verification_level = context.resume.verification_level;
            let batch = phase.run_batch(context.clone());
            let outcome = phase_lock
                .run_while_alive(self.timing.live_poll_interval, batch)
                .await;
            // The batch has finished; what follows records it and is required, since
            // the batch's own writes are already committed. A stop accepted meanwhile
            // does not abandon it, but bounds it: on expiry the run exits with a
            // transient error and the durable state is what a kill between the batch
            // and its progress write would have left, which the next start handles.
            let (outcome, progress) = bounded_recovery(
                stop_clock,
                "post-batch settlement",
                &chain.chain_id,
                &cancellation,
                self.settle_batch(
                    chain,
                    phase_name,
                    &mode,
                    redo_attempt,
                    context,
                    outcome,
                    progress_token,
                    retained_verification_level,
                    heartbeat,
                    phase_lock,
                ),
            )
            .await?;
            self.record_loop_progress(&chain.chain_id);
            backoff.reset();
            reserved_write_bytes = progress.estimated_write_bytes;
            if !self
                .follow_batch(chain, &*phase, &cancellation, heartbeat, phase_lock)
                .await?
            {
                return Ok(PhaseLoopResult::Cancelled);
            }

            match outcome {
                PhaseBatchOutcome::Complete(_) => {
                    return Ok(PhaseLoopResult::Completed(Box::new(progress)));
                }
                PhaseBatchOutcome::Continue(_) => {}
                PhaseBatchOutcome::Idle(_) => {
                    tokio::select! {
                        () = cancellation.cancelled() => {
                            return Ok(PhaseLoopResult::Cancelled);
                        }
                        () = tokio::time::sleep(self.timing.live_poll_interval) => {}
                    }
                }
            }
        }
    }
}
