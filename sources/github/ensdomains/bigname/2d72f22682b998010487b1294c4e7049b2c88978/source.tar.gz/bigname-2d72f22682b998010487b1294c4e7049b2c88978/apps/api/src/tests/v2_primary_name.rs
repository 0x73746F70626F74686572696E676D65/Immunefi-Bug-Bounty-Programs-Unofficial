#[tokio::test]
async fn v2_get_primary_name_executes_lookup_each_time_without_legacy_persistence() -> Result<()> {
    let database = TestDatabase::new_migrated().await?;
    database.initialize_lookup_schema().await?;
    database
        .seed_default_ens_primary_name_fallback_context()
        .await?;
    let lookup_pool = database.lookup_pool().await?;
    seed_schema_v2_ens_primary_name_authority(
        &lookup_pool,
        21_000_003,
        "0xbinding",
        "2026-04-17T00:00:03Z",
    )
    .await?;
    let (rpc_url, rpc_handle) = spawn_primary_name_mock_rpc(vec![
        json!("0x000000000000000000000000a2c122be93b0074270ebee7f6b7292c7deb45047"),
        primary_name_reverse_name_response("taytems.eth"),
        primary_name_universal_resolver_addr60_response(V2_ON_DEMAND_PRIMARY_NAME_ADDRESS),
        json!("0x000000000000000000000000a2c122be93b0074270ebee7f6b7292c7deb45047"),
        primary_name_reverse_name_response("taytems.eth"),
        primary_name_universal_resolver_addr60_response(V2_ON_DEMAND_PRIMARY_NAME_ADDRESS),
        json!("0x000000000000000000000000a2c122be93b0074270ebee7f6b7292c7deb45047"),
        primary_name_reverse_name_response("taytems.eth"),
        primary_name_universal_resolver_addr60_response(V2_ON_DEMAND_PRIMARY_NAME_ADDRESS),
    ])
    .await?;
    let chain_rpc_urls =
        bigname_lookup::ChainRpcUrls::from_entries(&[format!("ethereum-mainnet={rpc_url}")])?;
    let state = database
        .app_state_with_lookup_chain_rpc_urls(chain_rpc_urls)
        .await?;

    for _ in 0..2 {
        let verified_response = app_router(state.clone())
        .oneshot(
            Request::builder()
                .uri(format!(
                    "/v1/addresses/{V2_ON_DEMAND_PRIMARY_NAME_ADDRESS}/primary-name?source=verified"
                ))
                .body(Body::empty())
                .expect("request must build"),
        )
        .await
        .context("v2 verified schema-v2 primary-name request failed")?;
        let status = verified_response.status();
        let verified_payload: Value = read_json(verified_response).await?;
        assert_eq!(status, StatusCode::OK, "unexpected response: {verified_payload}");
        assert_eq!(
            verified_payload["data"]["answers"],
            json!([{
                "source": "verified",
                "status": "ok",
                "name": "taytems.eth"
            }])
        );
        assert_primary_name_snapshot_meta_chain_ids(&verified_payload, &["1"]);
    }

    let mixed_response = app_router(state)
        .oneshot(
            Request::builder()
                .uri(format!(
                    "/v1/addresses/{V2_ON_DEMAND_PRIMARY_NAME_ADDRESS}/primary-name"
                ))
                .body(Body::empty())
                .expect("request must build"),
        )
        .await
        .context("v2 mixed schema-v2 primary-name request failed")?;
    let status = mixed_response.status();
    let mixed_payload: Value = read_json(mixed_response).await?;
    assert_eq!(status, StatusCode::OK, "unexpected response: {mixed_payload}");
    assert_eq!(
        mixed_payload["data"]["answers"],
        json!([
            {
                "source": "indexed",
                "status": "not_found"
            },
            {
                "source": "verified",
                "status": "ok",
                "name": "taytems.eth"
            }
        ])
    );

    let rpc_requests = join_primary_name_mock_rpc_requests(rpc_handle).await?;
    assert_eq!(
        rpc_requests.len(),
        9,
        "v2 primary-name verification must execute again on every request"
    );
    let ledger_count: i64 = sqlx::query_scalar("SELECT count(*) FROM resolution_divergences")
        .fetch_one(&lookup_pool)
        .await?;
    assert_eq!(ledger_count, 0, "primary-name lookup has no ledger comparison target");

    lookup_pool.close().await;
    database.cleanup().await?;
    Ok(())
}

#[tokio::test]
async fn v2_get_primary_name_uses_one_phase_position_without_legacy_checkpoint() -> Result<()> {
    let database = TestDatabase::new_migrated().await?;
    database.initialize_lookup_schema().await?;
    database
        .seed_default_ens_primary_name_fallback_context()
        .await?;
    publish_primary_claim(
        &database.pool,
        "ens",
        V2_ON_DEMAND_PRIMARY_NAME_ADDRESS,
        b"legacy-worker.eth",
    )
    .await?;
    let lookup_pool = database.lookup_pool().await?;
    seed_schema_v2_ens_primary_name_authority(
        &lookup_pool,
        21_000_004,
        "0xnewer-phase-head",
        "2026-04-17T00:00:04Z",
    )
    .await?;
    publish_primary_claim(
        &lookup_pool,
        "ens",
        V2_ON_DEMAND_PRIMARY_NAME_ADDRESS,
        b"taytems.eth",
    )
    .await?;
    let (rpc_url, rpc_handle) = spawn_primary_name_mock_rpc(vec![
        json!("0x000000000000000000000000a2c122be93b0074270ebee7f6b7292c7deb45047"),
        primary_name_reverse_name_response("taytems.eth"),
        primary_name_universal_resolver_addr60_response(V2_ON_DEMAND_PRIMARY_NAME_ADDRESS),
    ])
    .await?;
    let chain_rpc_urls =
        bigname_lookup::ChainRpcUrls::from_entries(&[format!("ethereum-mainnet={rpc_url}")])?;
    let state = database
        .app_state_with_lookup_chain_rpc_urls(chain_rpc_urls)
        .await?;

    let response = app_router(state.clone())
        .oneshot(
            Request::builder()
                .uri(format!(
                    "/v1/addresses/{V2_ON_DEMAND_PRIMARY_NAME_ADDRESS}/primary-name"
                ))
                .body(Body::empty())
                .expect("request must build"),
        )
        .await
        .context("v2 mixed primary-name request failed")?;
    let status = response.status();
    let payload: Value = read_json(response).await?;
    assert_eq!(status, StatusCode::OK, "unexpected response: {payload}");
    assert_eq!(payload["meta"]["as_of"]["1"]["block_number"], 21_000_004);
    assert_eq!(
        payload["data"]["answers"],
        json!([
            {
                "source": "indexed",
                "status": "ok",
                "name": "taytems.eth"
            },
            {
                "source": "verified",
                "status": "ok",
                "name": "taytems.eth"
            }
        ])
    );

    let indexed_response = app_router(state)
        .oneshot(
            Request::builder()
                .uri(format!(
                    "/v1/addresses/{V2_ON_DEMAND_PRIMARY_NAME_ADDRESS}/primary-name?source=indexed"
                ))
                .body(Body::empty())
                .expect("request must build"),
        )
        .await?;
    assert_eq!(indexed_response.status(), StatusCode::OK);
    let indexed_payload: Value = read_json(indexed_response).await?;
    assert_eq!(
        indexed_payload["data"]["answers"],
        json!([{
            "source": "indexed",
            "status": "ok",
            "name": "taytems.eth"
        }])
    );

    assert_eq!(join_primary_name_mock_rpc_requests(rpc_handle).await?.len(), 3);
    lookup_pool.close().await;
    database.cleanup().await?;
    Ok(())
}

#[tokio::test]
async fn v2_get_primary_name_returns_mixed_answers_at_one_position() -> Result<()> {
    let database = TestDatabase::new_migrated().await?;
    database.initialize_lookup_schema().await?;
    database
        .seed_default_ens_primary_name_fallback_context()
        .await?;
    publish_primary_claim(
        &database.pool,
        "ens",
        V2_ON_DEMAND_PRIMARY_NAME_ADDRESS,
        b"taytems.eth",
    )
    .await?;
    let lookup_pool = database.lookup_pool().await?;
    seed_schema_v2_ens_primary_name_authority(
        &lookup_pool,
        21_000_003,
        "0xbinding",
        "2026-04-17T00:00:03Z",
    )
    .await?;
    publish_primary_claim(
        &lookup_pool,
        "ens",
        V2_ON_DEMAND_PRIMARY_NAME_ADDRESS,
        b"taytems.eth",
    )
    .await?;
    let (rpc_url, rpc_handle) = spawn_primary_name_mock_rpc(vec![
        json!("0x000000000000000000000000a2c122be93b0074270ebee7f6b7292c7deb45047"),
        primary_name_reverse_name_response("taytems.eth"),
        primary_name_universal_resolver_addr60_response(V2_ON_DEMAND_PRIMARY_NAME_ADDRESS),
    ])
    .await?;
    let chain_rpc_urls =
        bigname_lookup::ChainRpcUrls::from_entries(&[format!("ethereum-mainnet={rpc_url}")])?;
    let state = database
        .app_state_with_lookup_chain_rpc_urls(chain_rpc_urls)
        .await?;

    let response = app_router(state)
        .oneshot(
            Request::builder()
                .uri(format!(
                    "/v1/addresses/{V2_ON_DEMAND_PRIMARY_NAME_ADDRESS}/primary-name"
                ))
                .body(Body::empty())
                .expect("request must build"),
        )
        .await
        .context("v2 mixed primary-name request failed")?;
    let status = response.status();
    let payload: Value = read_json(response).await?;
    assert_eq!(status, StatusCode::OK, "unexpected response: {payload}");
    assert_eq!(
        payload["data"]["answers"],
        json!([
            {
                "source": "indexed",
                "status": "ok",
                "name": "taytems.eth"
            },
            {
                "source": "verified",
                "status": "ok",
                "name": "taytems.eth"
            }
        ])
    );
    assert_eq!(payload["meta"]["as_of"]["1"]["block_hash"], json!("0xbinding"));
    assert_eq!(join_primary_name_mock_rpc_requests(rpc_handle).await?.len(), 3);

    lookup_pool.close().await;
    database.cleanup().await?;
    Ok(())
}

/// Live-follow stores a head before Project publishes for it. While the publication trails the
/// head within the lag tolerance, the reverse and forward calls execute at the publication's block,
/// the position the indexed claim is read at and `meta.as_of` reports.
#[tokio::test]
async fn v2_get_primary_name_verifies_at_a_publication_behind_the_head() -> Result<()> {
    let database = TestDatabase::new_migrated().await?;
    database.initialize_lookup_schema().await?;
    database
        .seed_default_ens_primary_name_fallback_context()
        .await?;
    let lookup_pool = database.lookup_pool().await?;
    seed_schema_v2_ens_primary_name_authority(
        &lookup_pool,
        21_000_004,
        "0xprimary-publication",
        "2026-04-17T00:00:04Z",
    )
    .await?;
    publish_primary_claim(
        &lookup_pool,
        "ens",
        V2_ON_DEMAND_PRIMARY_NAME_ADDRESS,
        b"taytems.eth",
    )
    .await?;
    seed_schema_v2_ens_lookup_head(
        &lookup_pool,
        21_000_005,
        "0xprimary-head",
        "2026-04-17T00:00:05Z",
    )
    .await?;
    let (rpc_url, rpc_handle) = spawn_primary_name_mock_rpc(vec![
        json!("0x000000000000000000000000a2c122be93b0074270ebee7f6b7292c7deb45047"),
        primary_name_reverse_name_response("taytems.eth"),
        primary_name_universal_resolver_addr60_response(V2_ON_DEMAND_PRIMARY_NAME_ADDRESS),
    ])
    .await?;
    let chain_rpc_urls =
        bigname_lookup::ChainRpcUrls::from_entries(&[format!("ethereum-mainnet={rpc_url}")])?;
    let state = database
        .app_state_with_lookup_chain_rpc_urls(chain_rpc_urls)
        .await?;

    let response = app_router(state)
        .oneshot(
            Request::builder()
                .uri(format!(
                    "/v1/addresses/{V2_ON_DEMAND_PRIMARY_NAME_ADDRESS}/primary-name"
                ))
                .body(Body::empty())
                .expect("request must build"),
        )
        .await
        .context("mixed primary-name request behind the head failed")?;
    let status = response.status();
    let payload: Value = read_json(response).await?;
    assert_eq!(status, StatusCode::OK, "unexpected response: {payload}");
    assert_eq!(
        payload["data"]["answers"],
        json!([
            {
                "source": "indexed",
                "status": "ok",
                "name": "taytems.eth"
            },
            {
                "source": "verified",
                "status": "ok",
                "name": "taytems.eth"
            }
        ])
    );
    assert_eq!(payload["meta"]["as_of"]["1"]["block_number"], json!(21_000_004));
    assert_eq!(
        payload["meta"]["as_of"]["1"]["block_hash"],
        json!("0xprimary-publication")
    );
    let requests = join_primary_name_mock_rpc_requests(rpc_handle).await?;
    assert_eq!(requests.len(), 3);
    for request in &requests {
        assert_eq!(
            request["params"][1]["blockHash"],
            json!("0xprimary-publication")
        );
    }

    lookup_pool.close().await;
    database.cleanup().await?;
    Ok(())
}

#[tokio::test]
async fn v2_get_primary_name_normalizes_schema_v2_successful_claim() -> Result<()> {
    let database = TestDatabase::new_migrated().await?;
    database
        .seed_snapshot_selector_chain_positions(&json!({
            "ethereum": {
                "chain_id": "ethereum-mainnet",
                "block_number": 21_000_005,
                "block_hash": "0xprimary-nonnormalized",
                "timestamp": "2026-04-17T00:00:05Z"
            }
        }))
        .await?;
    publish_primary_claim(
        &database.lookup_pool,
        "ens",
        V2_ON_DEMAND_PRIMARY_NAME_ADDRESS,
        b"Taytems.eth",
    )
    .await?;

    let payload = v2_primary_name_payload_for_database(
        &database,
        &format!(
            "/v1/addresses/{V2_ON_DEMAND_PRIMARY_NAME_ADDRESS}/primary-name?source=indexed"
        ),
    )
    .await?;
    assert_eq!(
        payload["data"]["answers"],
        json!([{
            "source": "indexed",
            "status": "ok",
            "name": "taytems.eth"
        }])
    );

    database.cleanup().await
}

// TYR-120. With an empty `addr.reverse` name, coin type 60 serves the `default.reverse` name, as
// ENS's ETH reverse resolver does; coin type 2147483648 reads the default name itself.
#[tokio::test]
async fn v2_get_primary_name_falls_back_to_the_default_reverse_name() -> Result<()> {
    let database = TestDatabase::new_migrated().await?;
    database
        .seed_snapshot_selector_chain_positions(&json!({
            "ethereum": {
                "chain_id": "ethereum-mainnet",
                "block_number": 21_000_005,
                "block_hash": "0xprimary-default-reverse",
                "timestamp": "2026-04-17T00:00:05Z"
            }
        }))
        .await?;
    let indexed = |coin_type: &str| {
        format!(
            "/v1/addresses/{V2_ON_DEMAND_PRIMARY_NAME_ADDRESS}/primary-name?coin_type={coin_type}&source=indexed"
        )
    };
    publish_primary_claim(
        &database.lookup_pool,
        "ens",
        V2_ON_DEMAND_PRIMARY_NAME_ADDRESS,
        b"",
    )
    .await?;
    publish_primary_claim(
        &database.lookup_pool,
        ENS_DEFAULT_REVERSE,
        V2_ON_DEMAND_PRIMARY_NAME_ADDRESS,
        b"evers.eth",
    )
    .await?;
    for coin_type in ["60", "2147483648"] {
        let payload = v2_primary_name_payload_for_database(&database, &indexed(coin_type)).await?;
        assert_eq!(
            payload["data"]["answers"],
            json!([{"source": "indexed", "status": "ok", "name": "evers.eth"}]),
            "coin type {coin_type}"
        );
    }

    // A non-empty addr.reverse name on the reverse node's resolver wins.
    publish_primary_claim(
        &database.lookup_pool,
        "ens",
        V2_ON_DEMAND_PRIMARY_NAME_ADDRESS,
        b"taytems.eth",
    )
    .await?;
    let payload = v2_primary_name_payload_for_database(&database, &indexed("60")).await?;
    assert_eq!(
        payload["data"]["answers"],
        json!([{"source": "indexed", "status": "ok", "name": "taytems.eth"}])
    );

    database.cleanup().await
}

#[tokio::test]
async fn v2_get_primary_name_reports_an_unnormalizable_stored_claim_as_invalid_name() -> Result<()> {
    let database = TestDatabase::new_migrated().await?;
    database
        .seed_snapshot_selector_chain_positions(&json!({
            "ethereum": {
                "chain_id": "ethereum-mainnet",
                "block_number": 21_000_005,
                "block_hash": "0xprimary-unnormalizable",
                "timestamp": "2026-04-17T00:00:05Z"
            }
        }))
        .await?;
    // Invalid bytes are retained by the claim reducer and reported with the invalid-name
    // vocabulary through the indexed route.
    publish_primary_claim(
        &database.lookup_pool,
        "ens",
        V2_ON_DEMAND_PRIMARY_NAME_ADDRESS,
        b"taytems..eth",
    )
    .await?;

    let payload = v2_primary_name_payload_for_database(
        &database,
        &format!(
            "/v1/addresses/{V2_ON_DEMAND_PRIMARY_NAME_ADDRESS}/primary-name?source=indexed"
        ),
    )
    .await?;
    assert_eq!(
        payload["data"]["answers"],
        json!([{
            "source": "indexed",
            "status": "invalid_name",
            "raw_claim_name": "taytems..eth"
        }])
    );

    database.cleanup().await
}

#[tokio::test]
async fn v2_get_primary_name_publishes_an_already_normalized_claim_as_stored() -> Result<()> {
    let database = TestDatabase::new_migrated().await?;
    database
        .seed_snapshot_selector_chain_positions(&json!({
            "ethereum": {
                "chain_id": "ethereum-mainnet",
                "block_number": 21_000_005,
                "block_hash": "0xprimary-prenormalized",
                "timestamp": "2026-04-17T00:00:05Z"
            }
        }))
        .await?;
    // An already normalized event claim is published unchanged by the indexed route.
    publish_primary_claim(
        &database.lookup_pool,
        "ens",
        V2_ON_DEMAND_PRIMARY_NAME_ADDRESS,
        b"taytems.eth",
    )
    .await?;

    let payload = v2_primary_name_payload_for_database(
        &database,
        &format!(
            "/v1/addresses/{V2_ON_DEMAND_PRIMARY_NAME_ADDRESS}/primary-name?source=indexed"
        ),
    )
    .await?;
    assert_eq!(
        payload["data"]["answers"],
        json!([{
            "source": "indexed",
            "status": "ok",
            "name": "taytems.eth"
        }])
    );

    database.cleanup().await
}

#[tokio::test]
async fn v2_get_primary_name_excludes_lower_height_orphaned_project_target() -> Result<()> {
    let database = TestDatabase::new_migrated().await?;
    database
        .seed_snapshot_selector_chain_positions(&json!({
            "ethereum": {
                "chain_id": "ethereum-mainnet",
                "block_number": 21_000_005,
                "block_hash": "0xprimary-readable-head",
                "timestamp": "2026-04-17T00:00:05Z"
            }
        }))
        .await?;
    publish_primary_claim(
        &database.lookup_pool,
        "ens",
        V2_ON_DEMAND_PRIMARY_NAME_ADDRESS,
        b"orphaned.eth",
    )
    .await?;
    sqlx::query(
        r#"
        INSERT INTO bigname_phase.chain_lineage (
            chain_id, block_hash, block_number, block_timestamp, canonicality_state
        ) VALUES (
            'ethereum-mainnet', '0xorphaned-primary-target', 21000004,
            '2026-04-17T00:00:04Z', 'orphaned'
        )
        "#,
    )
    .execute(&database.lookup_pool)
    .await?;
    // The claim's transaction (ReverseClaimed, NewResolver, NameChanged) moves to the orphaned
    // block.
    let updated = sqlx::query(
        "UPDATE bigname_phase.normalized_events
         SET block_number = 21000004, block_hash = '0xorphaned-primary-target', canonicality_state = 'orphaned'
         WHERE event_kind IN ('ReverseChanged', 'ResolverChanged', 'RecordChanged')",
    ).execute(&database.lookup_pool).await?;
    assert_eq!(updated.rows_affected(), 3);
    rebuild_fixture_families(&database.lookup_pool, "ethereum-mainnet", 21_000_005,
        "0xprimary-readable-head").await?;

    let payload = v2_primary_name_payload_for_database(
        &database,
        &format!(
            "/v1/addresses/{V2_ON_DEMAND_PRIMARY_NAME_ADDRESS}/primary-name?source=indexed"
        ),
    )
    .await?;
    assert_eq!(
        payload["data"]["answers"],
        json!([{"source": "indexed", "status": "not_found"}])
    );

    database.cleanup().await
}

#[tokio::test]
async fn v2_get_primary_name_rejects_project_change_after_indexed_read() -> Result<()> {
    let database = TestDatabase::new_migrated().await?;
    database
        .seed_snapshot_selector_chain_positions(&json!({
            "ethereum": {
                "chain_id": "ethereum-mainnet",
                "block_number": 21_000_006,
                "block_hash": "0xprimary-before-publication",
                "timestamp": "2026-04-17T00:00:06Z"
            }
        }))
        .await?;
    publish_primary_claim(
        &database.lookup_pool,
        "ens",
        V2_ON_DEMAND_PRIMARY_NAME_ADDRESS,
        b"before.eth",
    )
    .await?;
    let (_guard, control) =
        crate::v2::support::indexed_read_test_hooks::install(&database.lookup_pool).await?;
    let state = database.app_state();
    let request_task = tokio::spawn(async move {
        app_router(state)
            .oneshot(
                Request::builder()
                    .uri(format!(
                        "/v1/addresses/{V2_ON_DEMAND_PRIMARY_NAME_ADDRESS}/primary-name?source=indexed"
                    ))
                    .body(Body::empty())
                    .expect("request must build"),
            )
            .await
    });

    control.wait_until_reached().await;
    publish_primary_claim(
        &database.lookup_pool,
        "ens",
        V2_ON_DEMAND_PRIMARY_NAME_ADDRESS,
        b"after.eth",
    )
    .await?;
    let (block, hash): (i64, String) = sqlx::query_as(
        "SELECT current_block_number, current_block_hash FROM project_family_marker WHERE chain_id = 'ethereum-mainnet'"
    ).fetch_one(&database.lookup_pool).await?;
    rebuild_fixture_families(&database.lookup_pool, "ethereum-mainnet", block, &hash).await?;
    control.resume().await;

    let response = request_task
        .await
        .context("indexed primary-name request task panicked")?
        .context("indexed primary-name request failed")?;
    assert_eq!(response.status(), StatusCode::CONFLICT);
    let payload: Value = read_json(response).await?;
    assert_eq!(payload["error"]["code"], json!("stale"));

    database.cleanup().await
}

#[tokio::test]
async fn v2_get_primary_name_rejects_same_head_republication_during_mixed_read() -> Result<()> {
    let database = TestDatabase::new_migrated().await?;
    database.initialize_lookup_schema().await?;
    database
        .seed_default_ens_primary_name_fallback_context()
        .await?;
    let lookup_pool = database.lookup_pool().await?;
    seed_schema_v2_ens_primary_name_authority(
        &lookup_pool,
        21_000_007,
        "0xprimary-mixed-publication",
        "2026-04-17T00:00:07Z",
    )
    .await?;
    publish_primary_claim(
        &lookup_pool,
        "ens",
        V2_ON_DEMAND_PRIMARY_NAME_ADDRESS,
        b"taytems.eth",
    )
    .await?;
    let (rpc_url, rpc_handle) = spawn_primary_name_mock_rpc(vec![
        json!("0x000000000000000000000000a2c122be93b0074270ebee7f6b7292c7deb45047"),
        primary_name_reverse_name_response("taytems.eth"),
        primary_name_universal_resolver_addr60_response(V2_ON_DEMAND_PRIMARY_NAME_ADDRESS),
    ])
    .await?;
    let chain_rpc_urls =
        bigname_lookup::ChainRpcUrls::from_entries(&[format!("ethereum-mainnet={rpc_url}")])?;
    let (_guard, control) =
        crate::v2::support::indexed_read_test_hooks::install(&database.lookup_pool).await?;
    let state = database
        .app_state_with_lookup_chain_rpc_urls(chain_rpc_urls)
        .await?;
    let request_task = tokio::spawn(async move {
        app_router(state)
            .oneshot(
                Request::builder()
                    .uri(format!(
                        "/v1/addresses/{V2_ON_DEMAND_PRIMARY_NAME_ADDRESS}/primary-name"
                    ))
                    .body(Body::empty())
                    .expect("request must build"),
            )
            .await
    });

    control.wait_until_reached().await;
    let (block, hash): (i64, String) = sqlx::query_as(
        "SELECT current_block_number, current_block_hash FROM project_family_marker WHERE chain_id = 'ethereum-mainnet'"
    ).fetch_one(&database.lookup_pool).await?;
    rebuild_fixture_families(&database.lookup_pool, "ethereum-mainnet", block, &hash).await?;
    control.resume().await;

    let response = request_task
        .await
        .context("mixed primary-name request task panicked")?
        .context("mixed primary-name request failed")?;
    assert_eq!(response.status(), StatusCode::CONFLICT);
    let payload: Value = read_json(response).await?;
    assert_eq!(payload["error"]["code"], json!("stale"));
    assert_eq!(join_primary_name_mock_rpc_requests(rpc_handle).await?.len(), 3);

    lookup_pool.close().await;
    database.cleanup().await
}

#[tokio::test]
async fn v2_get_primary_name_keeps_provider_response_timeout_in_band_without_persistence()
-> Result<()> {
    let database = TestDatabase::new_migrated().await?;
    database.initialize_lookup_schema().await?;
    database
        .seed_default_ens_primary_name_fallback_context()
        .await?;
    let lookup_pool = database.lookup_pool().await?;
    seed_schema_v2_ens_primary_name_authority(
        &lookup_pool,
        21_000_003,
        "0xbinding",
        "2026-04-17T00:00:03Z",
    )
    .await?;
    let (rpc_url, rpc_handle) = spawn_hanging_primary_name_rpc().await?;
    let chain_rpc_urls =
        bigname_lookup::ChainRpcUrls::from_entries(&[format!("ethereum-mainnet={rpc_url}")])?
            .with_http_timeouts(
                std::time::Duration::from_millis(10),
                std::time::Duration::from_millis(25),
            )?;
    let state = database
        .app_state_with_lookup_chain_rpc_urls(chain_rpc_urls)
        .await?;

    let response = app_router(state)
        .oneshot(
            Request::builder()
                .uri(format!(
                    "/v1/addresses/{V2_ON_DEMAND_PRIMARY_NAME_ADDRESS}/primary-name"
                ))
                .body(Body::empty())
                .expect("request must build"),
        )
        .await
        .context("v2 timed-out primary-name request failed")?;
    rpc_handle.abort();
    let status = response.status();
    let payload: Value = read_json(response).await?;
    assert_eq!(status, StatusCode::OK, "unexpected response: {payload}");
    assert_eq!(
        payload["data"]["answers"],
        json!([
            {
                "source": "indexed",
                "status": "not_found"
            },
            {
                "source": "verified",
                "status": "failed",
                "failure_reason": "resolver_call_failed"
            }
        ])
    );
    let ledger_count: i64 = sqlx::query_scalar("SELECT count(*) FROM resolution_divergences")
        .fetch_one(&lookup_pool)
        .await?;
    assert_eq!(ledger_count, 0);

    lookup_pool.close().await;
    database.cleanup().await?;
    Ok(())
}

#[tokio::test]
async fn v2_get_primary_name_aborts_provider_transport_failure_without_persistence() -> Result<()>
{
    let database = TestDatabase::new_migrated().await?;
    database.initialize_lookup_schema().await?;
    database
        .seed_default_ens_primary_name_fallback_context()
        .await?;
    let lookup_pool = database.lookup_pool().await?;
    seed_schema_v2_ens_primary_name_authority(
        &lookup_pool,
        21_000_003,
        "0xbinding",
        "2026-04-17T00:00:03Z",
    )
    .await?;
    let listener = tokio::net::TcpListener::bind("127.0.0.1:0").await?;
    let unavailable_rpc_url = format!("http://{}", listener.local_addr()?);
    drop(listener);
    let chain_rpc_urls = bigname_lookup::ChainRpcUrls::from_entries(&[format!(
        "ethereum-mainnet={unavailable_rpc_url}"
    )])?;
    let state = database
        .app_state_with_lookup_chain_rpc_urls(chain_rpc_urls)
        .await?;

    let response = app_router(state)
        .oneshot(
            Request::builder()
                .uri(format!(
                    "/v1/addresses/{V2_ON_DEMAND_PRIMARY_NAME_ADDRESS}/primary-name?source=verified"
                ))
                .body(Body::empty())
                .expect("request must build"),
        )
        .await
        .context("v2 transport-failed primary-name request failed")?;
    let status = response.status();
    let payload: Value = read_json(response).await?;
    assert_eq!(status, StatusCode::INTERNAL_SERVER_ERROR, "{payload}");
    assert_eq!(payload["error"]["code"], json!("internal_error"));
    let ledger_count: i64 = sqlx::query_scalar("SELECT count(*) FROM resolution_divergences")
        .fetch_one(&lookup_pool)
        .await?;
    assert_eq!(ledger_count, 0);

    lookup_pool.close().await;
    database.cleanup().await?;
    Ok(())
}

#[tokio::test]
async fn v2_get_basenames_primary_name_verified_is_explicitly_unsupported_and_base_scoped()
-> Result<()> {
    let database = TestDatabase::new_migrated().await?;
    let address = "0x0000000000000000000000000000000000000bcd";
    seed_v2_basenames_primary_name_snapshot_positions(&database).await?;
    seed_v2_basenames_primary_name_claim(&database, address).await?;

    let verified = v2_primary_name_payload_for_database(
        &database,
        &format!(
            "/v1/addresses/{address}/primary-name?namespace=basenames&coin_type={V2_BASENAMES_PRIMARY_COIN_TYPE}&source=verified"
        ),
    )
    .await?;
    assert_eq!(
        verified["data"]["answers"],
        json!([{
            "source": "verified",
            "status": "unsupported",
            "unsupported_reason": "verified primary-name entrypoint is not yet supported"
        }])
    );
    assert_primary_name_snapshot_meta_chain_ids(&verified, &["8453"]);
    assert_primary_name_snapshot_token_slots(&verified, &["base"]);
    assert_eq!(
        verified["meta"]["as_of"]["8453"]["block_hash"],
        json!("0xprimary-base")
    );

    let indexed = v2_primary_name_payload_for_database(
        &database,
        &format!(
            "/v1/addresses/{address}/primary-name?namespace=basenames&coin_type={V2_BASENAMES_PRIMARY_COIN_TYPE}&source=indexed"
        ),
    )
    .await?;
    assert_primary_name_snapshot_meta_chain_ids(&indexed, &["8453"]);
    assert_primary_name_snapshot_token_slots(&indexed, &["base"]);

    database.cleanup().await?;
    Ok(())
}

#[tokio::test]
async fn v2_get_basenames_primary_name_normalization_gate_keeps_meta_base_scoped() -> Result<()> {
    let database = TestDatabase::new_migrated().await?;
    let address = "0x0000000000000000000000000000000000000bcf";
    seed_v2_basenames_primary_name_snapshot_positions(&database).await?;
    // The published name record contains valid but non-normalized bytes. F12 derives the
    // normalization gate from that input; the fixture does not overwrite its verdict.
    publish_primary_claim(&database.pool, "basenames", address, b"Alice.base.eth").await?;
    let verified = v2_primary_name_payload_for_database(
        &database,
        &format!(
            "/v1/addresses/{address}/primary-name?namespace=basenames&coin_type={V2_BASENAMES_PRIMARY_COIN_TYPE}&source=verified"
        ),
    )
    .await?;

    assert_eq!(
        verified["data"],
        json!({
            "address": address,
            "coin_type": 2_147_492_101_u64,
            "namespace": "basenames",
            "answers": [{
                "source": "verified",
                "status": "unsupported",
                "unsupported_reason": "verified primary-name entrypoint is not yet supported"
            }]
        })
    );
    assert_primary_name_snapshot_meta_chain_ids(&verified, &["8453"]);
    assert_primary_name_snapshot_token_slots(&verified, &["base"]);

    database.cleanup().await?;
    Ok(())
}

#[tokio::test]
async fn v2_get_basenames_primary_name_without_persisted_verified_stays_base_scoped() -> Result<()>
{
    let database = TestDatabase::new_migrated().await?;
    let address = "0x0000000000000000000000000000000000000bce";
    seed_v2_basenames_primary_name_base_snapshot_position(&database).await?;
    publish_primary_claim(&database.pool, "basenames", address, b"alice.base.eth").await?;

    let verified = v2_primary_name_payload_for_database(
        &database,
        &format!(
            "/v1/addresses/{address}/primary-name?namespace=basenames&coin_type={V2_BASENAMES_PRIMARY_COIN_TYPE}&source=verified"
        ),
    )
    .await?;
    assert_eq!(
        verified["data"]["answers"],
        json!([{
            "source": "verified",
            "status": "unsupported",
            "unsupported_reason": "verified primary-name entrypoint is not yet supported"
        }])
    );
    assert_primary_name_snapshot_meta_chain_ids(&verified, &["8453"]);
    assert_primary_name_snapshot_token_slots(&verified, &["base"]);

    let omitted_source = v2_primary_name_payload_for_database(
        &database,
        &format!(
            "/v1/addresses/{address}/primary-name?namespace=basenames&coin_type={V2_BASENAMES_PRIMARY_COIN_TYPE}"
        ),
    )
    .await?;
    assert_eq!(
        omitted_source["data"]["answers"],
        json!([
            {
                "source": "indexed",
                "status": "ok",
                "name": "alice.base.eth"
            },
            {
                "source": "verified",
                "status": "unsupported",
                "unsupported_reason": "verified primary-name entrypoint is not yet supported"
            }
        ])
    );
    assert_primary_name_snapshot_meta_chain_ids(&omitted_source, &["8453"]);
    assert_primary_name_snapshot_token_slots(&omitted_source, &["base"]);

    database.cleanup().await?;
    Ok(())
}

#[tokio::test]
async fn v2_get_primary_name_rejects_malformed_address() -> Result<()> {
    let database = TestDatabase::new(false).await?;

    let response =
        v2_primary_name_response_for_database(&database, "/v1/addresses/not-an-address/primary-name")
            .await?;

    assert_eq!(response.status(), StatusCode::BAD_REQUEST);
    assert_eq!(
        read_json::<Value>(response).await?["error"]["code"],
        json!("invalid_input")
    );

    database.cleanup().await?;
    Ok(())
}

// Forward verification consults the claimed name's selected exact-name authority before it
// dispatches anything. The RPC endpoint here is dead, so reaching a provider at all would fail the
// whole request with 500: a successful in-band unsupported answer is the proof no call went out.
/// Widens the seeded `ens_execution` manifest to admit the ENSv2 arm, as the `sepolia`
/// profile declares (`docs/manifests.md` § `verified_authority_arms`). The seeded default admits
/// only `ens_v1`.
async fn admit_ens_v2_arm_on_execution_entrypoint(pool: &PgPool) -> Result<()> {
    sqlx::query(
        "UPDATE bigname_phase.manifest_versions
         SET manifest_payload = manifest_payload
             || '{\"verified_authority_arms\": [\"ens_v1\", \"ens_v2\"]}'::jsonb
         WHERE source_family = 'ens_execution'",
    )
    .execute(pool)
    .await?;
    Ok(())
}

// The other half of the gate: a claim the projection fully supports, whose selected authority is
// the ENSv2 arm. The seeded execution manifest declares no `verified_authority_arms`, so it admits
// only the ENSv1 arm and the route must decline rather than resolve the name through an entrypoint
// whose answer the selection ruled out. The reason differs from the unsupported-projection branch
// even though the shape matches.
#[tokio::test]
async fn v2_get_primary_name_refuses_a_supported_ens_v2_arm_claim_without_provider_dispatch()
-> Result<()> {
    let database = TestDatabase::new_migrated().await?;
    database.initialize_lookup_schema().await?;
    database
        .seed_default_ens_primary_name_fallback_context()
        .await?;
    let lookup_pool = database.lookup_pool().await?;
    seed_schema_v2_ens_primary_name_authority(
        &lookup_pool,
        21_000_003,
        "0xbinding",
        "2026-04-17T00:00:03Z",
    )
    .await?;
    publish_primary_claim(
        &database.pool,
        "ens",
        V2_ON_DEMAND_PRIMARY_NAME_ADDRESS,
        b"taytems.eth",
    )
    .await?;
    seed_schema_v2_claimed_name(&lookup_pool, "ens", "taytems.eth", None, "ens_v2").await?;

    // Anti-vacuity: the projection supports this name, so only the selected arm can refuse it.
    let composed = primary_fixture_name(&lookup_pool, "taytems.eth").await?;
    assert_ne!(composed.coverage["status"], json!("unsupported"));

    let listener = tokio::net::TcpListener::bind("127.0.0.1:0").await?;
    let unavailable_rpc_url = format!("http://{}", listener.local_addr()?);
    drop(listener);
    let chain_rpc_urls = bigname_lookup::ChainRpcUrls::from_entries(&[format!(
        "ethereum-mainnet={unavailable_rpc_url}"
    )])?;
    let state = database
        .app_state_with_lookup_chain_rpc_urls(chain_rpc_urls)
        .await?;

    let response = app_router(state)
        .oneshot(
            Request::builder()
                .uri(format!(
                    "/v1/addresses/{V2_ON_DEMAND_PRIMARY_NAME_ADDRESS}/primary-name?source=verified"
                ))
                .body(Body::empty())
                .expect("request must build"),
        )
        .await
        .context("v2 ens_v2-arm primary-name request failed")?;
    let status = response.status();
    let payload: Value = read_json(response).await?;
    // The RPC endpoint is closed, so a 200 at all proves no provider call was dispatched.
    assert_eq!(status, StatusCode::OK, "{payload}");

    let verified = payload["data"]["answers"]
        .as_array()
        .expect("answers must be an array")
        .iter()
        .find(|answer| answer["source"] == json!("verified"))
        .expect("a verified answer must be present");
    assert_eq!(verified["status"], json!("unsupported"), "{payload}");
    assert_eq!(
        verified["unsupported_reason"],
        json!("exact_name_authority_not_verifiable"),
        "{payload}"
    );
    assert!(payload["data"].get("verification").is_none(), "{payload}");

    lookup_pool.close().await;
    database.cleanup().await?;
    Ok(())
}

// TYR-120 review. The projected `addr.reverse` name is empty but the reverse node keeps a nonzero
// resolver, so the indexed snapshot serves the `default.reverse` name. The chain may still answer a
// name from that resolver (an unadmitted or event-silent one), so the refused authority of the
// substituted default name must not decide the verified answer: the live name, on an admitted
// arm, is verified.
#[tokio::test]
async fn v2_get_primary_name_gates_the_live_name_when_the_default_was_substituted() -> Result<()> {
    let database = TestDatabase::new_migrated().await?;
    database.initialize_lookup_schema().await?;
    database
        .seed_default_ens_primary_name_fallback_context()
        .await?;
    let lookup_pool = database.lookup_pool().await?;
    seed_schema_v2_ens_primary_name_authority(
        &lookup_pool,
        21_000_003,
        "0xbinding",
        "2026-04-17T00:00:03Z",
    )
    .await?;
    publish_primary_claim(&database.pool, "ens", V2_ON_DEMAND_PRIMARY_NAME_ADDRESS, b"").await?;
    publish_primary_claim(
        &database.pool,
        ENS_DEFAULT_REVERSE,
        V2_ON_DEMAND_PRIMARY_NAME_ADDRESS,
        b"evers.eth",
    )
    .await?;
    seed_schema_v2_claimed_name(&lookup_pool, "ens", "evers.eth", None, "ens_v2").await?;
    seed_schema_v2_claimed_name(&lookup_pool, "ens", "taytems.eth", None, "ens_v1").await?;

    // Reverse leg answered by the resolver itself, then the forward call for the live name.
    let (rpc_url, rpc_handle) = spawn_primary_name_mock_rpc(vec![
        json!("0x000000000000000000000000a2c122be93b0074270ebee7f6b7292c7deb45047"),
        primary_name_reverse_name_response("taytems.eth"),
        primary_name_universal_resolver_addr60_response(V2_ON_DEMAND_PRIMARY_NAME_ADDRESS),
    ])
    .await?;
    let chain_rpc_urls =
        bigname_lookup::ChainRpcUrls::from_entries(&[format!("ethereum-mainnet={rpc_url}")])?;
    let state = database
        .app_state_with_lookup_chain_rpc_urls(chain_rpc_urls)
        .await?;

    let response = app_router(state)
        .oneshot(
            Request::builder()
                .uri(format!(
                    "/v1/addresses/{V2_ON_DEMAND_PRIMARY_NAME_ADDRESS}/primary-name?source=verified"
                ))
                .body(Body::empty())
                .expect("request must build"),
        )
        .await
        .context("v2 substituted-default primary-name request failed")?;
    let status = response.status();
    let payload: Value = read_json(response).await?;
    assert_eq!(status, StatusCode::OK, "{payload}");
    assert_eq!(
        payload["data"]["answers"],
        json!([{"source": "verified", "status": "ok", "name": "taytems.eth"}]),
        "{payload}"
    );
    assert_eq!(join_primary_name_mock_rpc_requests(rpc_handle).await?.len(), 3);

    lookup_pool.close().await;
    database.cleanup().await?;
    Ok(())
}

// TYR-120 review. The reverse node was claimed through a registrar no manifest admits, so no
// coin type 60 tuple exists, but the registry projection holds its nonzero resolver. The served
// `default.reverse` name must not decide the verified answer either.
#[tokio::test]
async fn v2_get_primary_name_gates_the_live_name_without_a_projected_reverse_tuple() -> Result<()> {
    let database = TestDatabase::new_migrated().await?;
    database.initialize_lookup_schema().await?;
    database
        .seed_default_ens_primary_name_fallback_context()
        .await?;
    let lookup_pool = database.lookup_pool().await?;
    seed_schema_v2_ens_primary_name_authority(
        &lookup_pool,
        21_000_003,
        "0xbinding",
        "2026-04-17T00:00:03Z",
    )
    .await?;
    publish_primary_claim(
        &database.pool,
        ENS_UNADMITTED_REVERSE,
        V2_ON_DEMAND_PRIMARY_NAME_ADDRESS,
        b"",
    )
    .await?;
    publish_primary_claim(
        &database.pool,
        ENS_DEFAULT_REVERSE,
        V2_ON_DEMAND_PRIMARY_NAME_ADDRESS,
        b"evers.eth",
    )
    .await?;
    seed_schema_v2_claimed_name(&lookup_pool, "ens", "evers.eth", None, "ens_v2").await?;
    seed_schema_v2_claimed_name(&lookup_pool, "ens", "taytems.eth", None, "ens_v1").await?;

    // Reverse leg answered by the resolver itself, then the forward call for the live name.
    let (rpc_url, rpc_handle) = spawn_primary_name_mock_rpc(vec![
        json!("0x000000000000000000000000a2c122be93b0074270ebee7f6b7292c7deb45047"),
        primary_name_reverse_name_response("taytems.eth"),
        primary_name_universal_resolver_addr60_response(V2_ON_DEMAND_PRIMARY_NAME_ADDRESS),
    ])
    .await?;
    let chain_rpc_urls =
        bigname_lookup::ChainRpcUrls::from_entries(&[format!("ethereum-mainnet={rpc_url}")])?;
    let state = database
        .app_state_with_lookup_chain_rpc_urls(chain_rpc_urls)
        .await?;

    let response = app_router(state)
        .oneshot(
            Request::builder()
                .uri(format!(
                    "/v1/addresses/{V2_ON_DEMAND_PRIMARY_NAME_ADDRESS}/primary-name?source=verified"
                ))
                .body(Body::empty())
                .expect("request must build"),
        )
        .await
        .context("v2 tuple-less substituted-default primary-name request failed")?;
    let status = response.status();
    let payload: Value = read_json(response).await?;
    assert_eq!(status, StatusCode::OK, "{payload}");
    assert_eq!(
        payload["data"]["answers"],
        json!([{"source": "verified", "status": "ok", "name": "taytems.eth"}]),
        "{payload}"
    );
    assert_eq!(join_primary_name_mock_rpc_requests(rpc_handle).await?.len(), 3);

    lookup_pool.close().await;
    database.cleanup().await?;
    Ok(())
}

/// The same projected ENSv2-arm claim is admitted when the selected execution manifest declares
/// the arm: the forward call dispatches through the declared Universal Resolver and the verified
/// answer is served. Only the manifest declaration differs from the refusing test above.
#[tokio::test]
async fn v2_get_primary_name_verifies_a_supported_ens_v2_arm_claim_through_an_admitting_entrypoint()
-> Result<()> {
    let database = TestDatabase::new_migrated().await?;
    database.initialize_lookup_schema().await?;
    database
        .seed_default_ens_primary_name_fallback_context()
        .await?;
    let lookup_pool = database.lookup_pool().await?;
    seed_schema_v2_ens_primary_name_authority(
        &lookup_pool,
        21_000_003,
        "0xbinding",
        "2026-04-17T00:00:03Z",
    )
    .await?;
    admit_ens_v2_arm_on_execution_entrypoint(&lookup_pool).await?;
    publish_primary_claim(
        &database.pool,
        "ens",
        V2_ON_DEMAND_PRIMARY_NAME_ADDRESS,
        b"taytems.eth",
    )
    .await?;
    seed_schema_v2_claimed_name(&lookup_pool, "ens", "taytems.eth", None, "ens_v2").await?;
    let composed = primary_fixture_name(&lookup_pool, "taytems.eth").await?;
    assert_eq!(composed.provenance["authority_selection"]["authority_arm"], json!("ens_v2"));

    // Reverse leg plus the admitted forward call.
    let (rpc_url, rpc_handle) = spawn_primary_name_mock_rpc(vec![
        json!("0x000000000000000000000000a2c122be93b0074270ebee7f6b7292c7deb45047"),
        primary_name_reverse_name_response("taytems.eth"),
        primary_name_universal_resolver_addr60_response(V2_ON_DEMAND_PRIMARY_NAME_ADDRESS),
    ])
    .await?;
    let chain_rpc_urls =
        bigname_lookup::ChainRpcUrls::from_entries(&[format!("ethereum-mainnet={rpc_url}")])?;
    let state = database
        .app_state_with_lookup_chain_rpc_urls(chain_rpc_urls)
        .await?;

    let response = app_router(state)
        .oneshot(
            Request::builder()
                .uri(format!(
                    "/v1/addresses/{V2_ON_DEMAND_PRIMARY_NAME_ADDRESS}/primary-name?source=verified"
                ))
                .body(Body::empty())
                .expect("request must build"),
        )
        .await
        .context("v2 admitted ens_v2-arm primary-name request failed")?;
    let status = response.status();
    let payload: Value = read_json(response).await?;
    assert_eq!(status, StatusCode::OK, "{payload}");
    assert_eq!(
        payload["data"]["answers"],
        json!([{
            "source": "verified",
            "status": "ok",
            "name": "taytems.eth"
        }]),
        "{payload}"
    );

    let rpc_requests = join_primary_name_mock_rpc_requests(rpc_handle).await?;
    assert_eq!(
        rpc_requests.len(),
        3,
        "an admitted ENSv2-arm claim dispatches the forward call: {rpc_requests:?}"
    );
    assert_eq!(
        rpc_requests[2]["params"][0]["to"],
        json!("0xeeeeeeee14d718c2b47d9923deab1335e144eeee"),
        "the forward call executes through the declared Universal Resolver"
    );

    lookup_pool.close().await;
    database.cleanup().await?;
    Ok(())
}

#[tokio::test]
async fn v2_get_primary_name_refuses_an_unsupported_claim_without_provider_dispatch() -> Result<()>
{
    let database = TestDatabase::new_migrated().await?;
    database.initialize_lookup_schema().await?;
    database
        .seed_default_ens_primary_name_fallback_context()
        .await?;
    let lookup_pool = database.lookup_pool().await?;
    seed_schema_v2_ens_primary_name_authority(
        &lookup_pool,
        21_000_003,
        "0xbinding",
        "2026-04-17T00:00:03Z",
    )
    .await?;
    publish_primary_claim(
        &database.pool,
        "ens",
        V2_ON_DEMAND_PRIMARY_NAME_ADDRESS,
        b"taytems.eth",
    )
    .await?;
    // The claimed name's exact-name authority is unsupported: no registration is selected for it,
    // so there is nothing for forward verification to resolve through.
    seed_schema_v2_claimed_name(
        &lookup_pool,
        "ens",
        "taytems.eth",
        Some("current_authority_not_projected"),
        "ens_v1",
    )
    .await?;

    let listener = tokio::net::TcpListener::bind("127.0.0.1:0").await?;
    let unavailable_rpc_url = format!("http://{}", listener.local_addr()?);
    drop(listener);
    let chain_rpc_urls = bigname_lookup::ChainRpcUrls::from_entries(&[format!(
        "ethereum-mainnet={unavailable_rpc_url}"
    )])?;
    let state = database
        .app_state_with_lookup_chain_rpc_urls(chain_rpc_urls)
        .await?;

    let response = app_router(state)
        .oneshot(
            Request::builder()
                .uri(format!(
                    "/v1/addresses/{V2_ON_DEMAND_PRIMARY_NAME_ADDRESS}/primary-name?source=verified"
                ))
                .body(Body::empty())
                .expect("request must build"),
        )
        .await
        .context("v2 authority-gated primary-name request failed")?;
    let status = response.status();
    let payload: Value = read_json(response).await?;
    assert_eq!(status, StatusCode::OK, "{payload}");

    let verified = payload["data"]["answers"]
        .as_array()
        .expect("answers must be an array")
        .iter()
        .find(|answer| answer["source"] == json!("verified"))
        .expect("a verified answer must be present");
    assert_eq!(verified["status"], json!("unsupported"), "{payload}");
    assert_eq!(
        verified["unsupported_reason"],
        json!("current_authority_not_projected")
    );
    // No provider call ran, so there is no verification outcome to report.
    assert!(payload["data"].get("verification").is_none(), "{payload}");

    lookup_pool.close().await;
    database.cleanup().await?;
    Ok(())
}

const V2_PRIMARY_NAME_ADDRESS: &str = "0x0000000000000000000000000000000000000abc";
const V2_ON_DEMAND_PRIMARY_NAME_ADDRESS: &str = "0x8e8db5ccef88cca9d624701db544989c996e3216";
const V2_BASENAMES_PRIMARY_COIN_TYPE: &str = "2147492101";

async fn v2_primary_name_payload_for_database(
    database: &TestDatabase,
    uri: &str,
) -> Result<Value> {
    let response = v2_primary_name_response_for_database(database, uri).await?;
    assert_eq!(response.status(), StatusCode::OK);
    read_json(response).await
}

async fn v2_primary_name_response_for_database(
    database: &TestDatabase,
    uri: &str,
) -> Result<Response> {
    app_router(database.app_state())
        .oneshot(
            Request::builder()
                .uri(uri)
                .body(Body::empty())
                .expect("request must build"),
        )
        .await
        .context("v2 primary-name request failed")
}

fn assert_primary_name_snapshot_meta(payload: &Value) {
    assert!(
        payload["meta"]["as_of"].is_object(),
        "primary-name response must include meta.as_of"
    );
    let token = payload["meta"]["as_of_token"]
        .as_str()
        .expect("primary-name response must include meta.as_of_token");
    assert!(!token.is_empty(), "meta.as_of_token must not be empty");
    assert!(
        token
            .bytes()
            .all(|byte| byte.is_ascii_alphanumeric() || matches!(byte, b'-' | b'_' | b'.' | b'~')),
        "meta.as_of_token must be URL-safe"
    );
}

fn assert_primary_name_snapshot_meta_chain_ids(payload: &Value, expected_chain_ids: &[&str]) {
    assert_primary_name_snapshot_meta(payload);
    let actual = payload["meta"]["as_of"]
        .as_object()
        .expect("primary-name meta.as_of must be an object")
        .keys()
        .map(String::as_str)
        .collect::<std::collections::BTreeSet<_>>();
    let expected = expected_chain_ids
        .iter()
        .copied()
        .collect::<std::collections::BTreeSet<_>>();
    assert_eq!(actual, expected);
}

fn assert_primary_name_snapshot_token_slots(payload: &Value, expected_slots: &[&str]) {
    let token = payload["meta"]["as_of_token"]
        .as_str()
        .expect("primary-name response must include meta.as_of_token");
    let bigname_storage::SnapshotAt::ResolvedPositions(chain_positions) =
        crate::v2::decode_at_token(token).expect("primary-name token must decode")
    else {
        panic!("primary-name token must contain resolved chain positions");
    };
    let actual = chain_positions
        .as_map()
        .keys()
        .map(String::as_str)
        .collect::<std::collections::BTreeSet<_>>();
    let expected = expected_slots
        .iter()
        .copied()
        .collect::<std::collections::BTreeSet<_>>();
    assert_eq!(actual, expected);
}

async fn seed_v2_basenames_primary_name_snapshot_positions(database: &TestDatabase) -> Result<()> {
    database
        .seed_snapshot_selector_chain_positions(&json!({
            "base": {
                "chain_id": "base-mainnet",
                "block_number": 84_530_001,
                "block_hash": "0xprimary-base",
                "timestamp": "2026-04-17T00:10:01Z"
            },
            "ethereum": {
                "chain_id": "ethereum-mainnet",
                "block_number": 21_000_010,
                "block_hash": "0xprimary-ethereum",
                "timestamp": "2026-04-17T00:10:00Z"
            }
        }))
        .await
}

async fn seed_v2_basenames_primary_name_base_snapshot_position(
    database: &TestDatabase,
) -> Result<()> {
    database
        .seed_snapshot_selector_chain_positions(&json!({
            "base": {
                "chain_id": "base-mainnet",
                "block_number": 84_530_001,
                "block_hash": "0xprimary-base",
                "timestamp": "2026-04-17T00:10:01Z"
            }
        }))
        .await
}

// Projects one claimed name. `unsupported_reason` withholds exact-name support; `authority_arm`
// sets the arm the selection recorded, which is what decides whether this deployment declares an
// entrypoint able to forward verify the name.
async fn seed_schema_v2_claimed_name(
    pool: &PgPool,
    namespace: &str,
    name: &str,
    unsupported_reason: Option<&str>,
    authority_arm: &str,
) -> Result<()> {
    let chain_id = "ethereum-mainnet";
    let (block_number, block_hash, at): (i64, String, OffsetDateTime) = sqlx::query_as(
        "SELECT block_number, block_hash, block_timestamp FROM bigname_phase.chain_lineage
         WHERE chain_id = $1 AND canonicality_state IN ('canonical', 'safe', 'finalized')
         ORDER BY block_number DESC, block_hash LIMIT 1",
    )
    .bind(chain_id)
    .fetch_one(pool)
    .await?;
    let normalized = bigname_domain::normalization::normalize_name(name)?;
    let (logical, node) = phase_logical_identity(namespace, &normalized.normalized_name)?;
    let resource_id = Uuid::new_v4();
    let binding_id = Uuid::new_v4();
    let token_id = Uuid::new_v4();
    upsert_test_name_surfaces(
        pool,
        &[NameSurface {
            logical_name_id: logical.clone(),
            namespace: namespace.into(),
            input_name: name.into(),
            canonical_display_name: normalized.canonical_display_name,
            normalized_name: normalized.normalized_name,
            dns_encoded_name: normalized.dns_encoded_name,
            namehash: node,
            labelhashes: vec![],
            normalizer_version: bigname_domain::normalization::ENS_NORMALIZER_VERSION.into(),
            normalization_warnings: json!([]),
            normalization_errors: json!([]),
            chain_id: chain_id.into(),
            block_number,
            block_hash: block_hash.clone(),
            provenance: json!({}),
            canonicality_state: CanonicalityState::Canonical,
        }],
    )
    .await?;
    if unsupported_reason.is_none() {
        upsert_test_token_lineages(
            pool,
            &[TokenLineage {
                token_lineage_id: token_id,
                chain_id: chain_id.into(),
                block_number,
                block_hash: block_hash.clone(),
                provenance: json!({}),
                canonicality_state: CanonicalityState::Canonical,
            }],
        )
        .await?;
        upsert_test_resources(
            pool,
            &[Resource {
                resource_id,
                token_lineage_id: Some(token_id),
                chain_id: chain_id.into(),
                block_number,
                block_hash: block_hash.clone(),
                provenance: json!({}),
                canonicality_state: CanonicalityState::Canonical,
            }],
        )
        .await?;
        upsert_test_surface_bindings(
            pool,
            &[SurfaceBinding {
                surface_binding_id: binding_id,
                logical_name_id: format!("{namespace}:{name}"),
                resource_id,
                binding_kind: SurfaceBindingKind::DeclaredRegistryPath,
                authority_arm: authority_arm.into(),
                active_from: at,
                active_to: None,
                chain_id: chain_id.into(),
                block_number,
                block_hash: block_hash.clone(),
                provenance: json!({}),
                canonicality_state: CanonicalityState::Canonical,
            }],
        )
        .await?;
        let mut grant = history_event(
            &format!("claim-name-grant-{resource_id}"),
            Some(&logical),
            Some(resource_id),
            Some(chain_id),
            Some(block_number),
            Some(&block_hash),
            Some("0xclaim-name"),
            Some(0),
            CanonicalityState::Canonical,
        );
        grant.event_kind = "RegistrationGranted".into();
        grant.source_family = if authority_arm == "ens_v2" {
            "ens_v2_registry_l1"
        } else {
            "ens_v1_registrar_l1"
        }
        .into();
        grant.after_state = json!({"authority_kind": if authority_arm == "ens_v2" { "registry" } else { "registrar" },
            "registrant": V2_ON_DEMAND_PRIMARY_NAME_ADDRESS, "expiry": 2100000000});
        bigname_storage::insert_normalized_event_fixtures(pool, &[grant]).await?;
    }
    rebuild_fixture_families(pool, chain_id, block_number, &block_hash).await
}

async fn primary_fixture_name(
    pool: &PgPool,
    name: &str,
) -> Result<bigname_storage::NameCurrentRow> {
    bigname_storage::families::name::load_family_name(
        pool,
        &bigname_storage::logical_name_id_for_name("ens", name),
    )
    .await?
    .context("the primary fixture produced its composed name")
}

async fn seed_v2_basenames_primary_name_claim(
    database: &TestDatabase,
    address: &str,
) -> Result<()> {
    publish_primary_claim(&database.pool, "basenames", address, b"alice.base.eth").await?;
    Ok(())
}

/// The arm gate must not depend on a projected claim existing. An address with no indexed claim
/// still reaches the live reverse leg, and that leg can name an ENSv2-armed name just as a
/// projected claim can. The refusal belongs to the name being resolved, not to how we learned it,
/// so it has to fire before the forward call goes out. The seeded execution manifest admits only
/// the ENSv1 arm; the admitting counterpart follows this test.
#[tokio::test]
async fn v2_get_primary_name_refuses_a_live_ens_v2_arm_claim_without_forward_dispatch() -> Result<()>
{
    let database = TestDatabase::new_migrated().await?;
    database.initialize_lookup_schema().await?;
    database
        .seed_default_ens_primary_name_fallback_context()
        .await?;
    let lookup_pool = database.lookup_pool().await?;
    seed_schema_v2_ens_primary_name_authority(
        &lookup_pool,
        21_000_003,
        "0xbinding",
        "2026-04-17T00:00:03Z",
    )
    .await?;
    // No projected claim for this address: the gate's snapshot read returns None.
    seed_schema_v2_claimed_name(&lookup_pool, "ens", "taytems.eth", None, "ens_v2").await?;

    // Anti-vacuity: the projection supports the name the live leg will claim, so only the selected
    // arm can refuse it, and no projected claim exists to drive the pre-lookup gate.
    let composed = primary_fixture_name(&lookup_pool, "taytems.eth").await?;
    assert_ne!(composed.coverage["status"], json!("unsupported"));
    let projected_claims: i64 = sqlx::query_scalar(
        "SELECT count(*) FROM bigname_phase.project_reverse_tuple WHERE lower(address) = $1",
    )
    .bind(V2_ON_DEMAND_PRIMARY_NAME_ADDRESS.to_lowercase())
    .fetch_one(&lookup_pool)
    .await?;
    assert_eq!(projected_claims, 0);

    // Exactly the two calls the reverse leg makes. The mock serves one response per queued entry,
    // so a forward dispatch would find the listener gone and fail the lookup outright.
    let (rpc_url, rpc_handle) = spawn_primary_name_mock_rpc(vec![
        json!("0x000000000000000000000000a2c122be93b0074270ebee7f6b7292c7deb45047"),
        primary_name_reverse_name_response("taytems.eth"),
    ])
    .await?;
    let chain_rpc_urls =
        bigname_lookup::ChainRpcUrls::from_entries(&[format!("ethereum-mainnet={rpc_url}")])?;
    let state = database
        .app_state_with_lookup_chain_rpc_urls(chain_rpc_urls)
        .await?;

    let response = app_router(state)
        .oneshot(
            Request::builder()
                .uri(format!(
                    "/v1/addresses/{V2_ON_DEMAND_PRIMARY_NAME_ADDRESS}/primary-name?source=verified"
                ))
                .body(Body::empty())
                .expect("request must build"),
        )
        .await
        .context("v2 live ens_v2-arm primary-name request failed")?;
    let status = response.status();
    let payload: Value = read_json(response).await?;
    assert_eq!(status, StatusCode::OK, "{payload}");

    let verified = payload["data"]["answers"]
        .as_array()
        .expect("answers must be an array")
        .iter()
        .find(|answer| answer["source"] == json!("verified"))
        .expect("a verified answer must be present");
    assert_eq!(verified["status"], json!("unsupported"), "{payload}");
    assert_eq!(
        verified["unsupported_reason"],
        json!("exact_name_authority_not_verifiable"),
        "{payload}"
    );

    let rpc_requests = join_primary_name_mock_rpc_requests(rpc_handle).await?;
    assert_eq!(
        rpc_requests.len(),
        2,
        "the reverse leg may run, but the forward call must not: {rpc_requests:?}"
    );

    lookup_pool.close().await;
    database.cleanup().await?;
    Ok(())
}

/// A live reverse claim naming an ENSv2-arm name is admitted to the forward call when the selected
/// execution manifest declares the arm; the gate fires after the reverse leg with the same
/// declaration the projected-claim gate reads.
#[tokio::test]
async fn v2_get_primary_name_forwards_a_live_ens_v2_arm_claim_through_an_admitting_entrypoint()
-> Result<()> {
    let database = TestDatabase::new_migrated().await?;
    database.initialize_lookup_schema().await?;
    database
        .seed_default_ens_primary_name_fallback_context()
        .await?;
    let lookup_pool = database.lookup_pool().await?;
    seed_schema_v2_ens_primary_name_authority(
        &lookup_pool,
        21_000_003,
        "0xbinding",
        "2026-04-17T00:00:03Z",
    )
    .await?;
    admit_ens_v2_arm_on_execution_entrypoint(&lookup_pool).await?;
    // No projected claim for this address: only the live leg names the ENSv2-arm name.
    seed_schema_v2_claimed_name(&lookup_pool, "ens", "taytems.eth", None, "ens_v2").await?;
    let projected_claims: i64 = sqlx::query_scalar(
        "SELECT count(*) FROM bigname_phase.project_reverse_tuple WHERE lower(address) = $1",
    )
    .bind(V2_ON_DEMAND_PRIMARY_NAME_ADDRESS.to_lowercase())
    .fetch_one(&lookup_pool)
    .await?;
    assert_eq!(projected_claims, 0);

    let (rpc_url, rpc_handle) = spawn_primary_name_mock_rpc(vec![
        json!("0x000000000000000000000000a2c122be93b0074270ebee7f6b7292c7deb45047"),
        primary_name_reverse_name_response("taytems.eth"),
        primary_name_universal_resolver_addr60_response(V2_ON_DEMAND_PRIMARY_NAME_ADDRESS),
    ])
    .await?;
    let chain_rpc_urls =
        bigname_lookup::ChainRpcUrls::from_entries(&[format!("ethereum-mainnet={rpc_url}")])?;
    let state = database
        .app_state_with_lookup_chain_rpc_urls(chain_rpc_urls)
        .await?;

    let response = app_router(state)
        .oneshot(
            Request::builder()
                .uri(format!(
                    "/v1/addresses/{V2_ON_DEMAND_PRIMARY_NAME_ADDRESS}/primary-name?source=verified"
                ))
                .body(Body::empty())
                .expect("request must build"),
        )
        .await
        .context("v2 admitted live ens_v2-arm primary-name request failed")?;
    let status = response.status();
    let payload: Value = read_json(response).await?;
    assert_eq!(status, StatusCode::OK, "{payload}");
    assert_eq!(
        payload["data"]["answers"],
        json!([{
            "source": "verified",
            "status": "ok",
            "name": "taytems.eth"
        }]),
        "{payload}"
    );

    let rpc_requests = join_primary_name_mock_rpc_requests(rpc_handle).await?;
    assert_eq!(
        rpc_requests.len(),
        3,
        "the admitted live claim must reach the forward call: {rpc_requests:?}"
    );

    lookup_pool.close().await;
    database.cleanup().await?;
    Ok(())
}

/// A projected tuple does not constrain the name returned by the live reverse leg. If that leg
/// names a different name whose selected authority cannot be verified under the seeded
/// ENSv1-only execution declaration, the refusal remains the verified outcome and metric; the
/// stored tuple supplies only the independent indexed answer.
#[tokio::test]
async fn a_live_authority_refusal_overrides_a_different_projected_tuple_for_response_and_metrics()
-> Result<()> {
    let database = TestDatabase::new_migrated().await?;
    database.initialize_lookup_schema().await?;
    database
        .seed_default_ens_primary_name_fallback_context()
        .await?;
    let lookup_pool = database.lookup_pool().await?;
    seed_schema_v2_ens_primary_name_authority(
        &lookup_pool,
        21_000_003,
        "0xbinding",
        "2026-04-17T00:00:03Z",
    )
    .await?;
    publish_primary_claim(
        &database.pool,
        "ens",
        V2_ON_DEMAND_PRIMARY_NAME_ADDRESS,
        b"alice.eth",
    )
    .await?;
    seed_schema_v2_claimed_name(&lookup_pool, "ens", "alice.eth", None, "ens_v1").await?;
    seed_schema_v2_claimed_name(&lookup_pool, "ens", "taytems.eth", None, "ens_v2").await?;

    let projected_claim = load_primary_name_current(&lookup_pool,
        V2_ON_DEMAND_PRIMARY_NAME_ADDRESS, "ens", "60").await?.context("indexed claim")?;
    assert_eq!(projected_claim.raw_claim_name.as_deref(), Some("alice.eth"));
    let composed = primary_fixture_name(&lookup_pool, "taytems.eth").await?;
    assert_eq!(composed.provenance["authority_selection"]["authority_arm"], json!("ens_v2"));

    let (rpc_url, rpc_handle) = spawn_primary_name_mock_rpc(vec![
        json!("0x000000000000000000000000a2c122be93b0074270ebee7f6b7292c7deb45047"),
        primary_name_reverse_name_response("taytems.eth"),
    ])
    .await?;
    let chain_rpc_urls =
        bigname_lookup::ChainRpcUrls::from_entries(&[format!("ethereum-mainnet={rpc_url}")])?;
    let state = database
        .app_state_with_lookup_chain_rpc_urls(chain_rpc_urls)
        .await?;

    let (response, metric_outcomes) = crate::metrics::capture_verified_execution_outcomes(
        app_router(state).oneshot(
            Request::builder()
                .uri(format!(
                    "/v1/addresses/{V2_ON_DEMAND_PRIMARY_NAME_ADDRESS}/primary-name?source=verified"
                ))
                .body(Body::empty())
                .expect("request must build"),
        ),
    )
    .await;
    let response = response.context("v2 live refusal with projected tuple request failed")?;
    let status = response.status();
    let payload: Value = read_json(response).await?;
    assert_eq!(status, StatusCode::OK, "{payload}");

    let verified = payload["data"]["answers"]
        .as_array()
        .expect("answers must be an array")
        .iter()
        .find(|answer| answer["source"] == json!("verified"))
        .expect("a verified answer must be present");
    assert_eq!(
        (
            verified["status"].as_str(),
            verified["unsupported_reason"].as_str(),
            metric_outcomes.as_slice(),
        ),
        (
            Some("unsupported"),
            Some("exact_name_authority_not_verifiable"),
            ["unsupported"].as_slice(),
        ),
        "live refusal must serve and count as unsupported: {payload}"
    );

    let rpc_requests = join_primary_name_mock_rpc_requests(rpc_handle).await?;
    assert_eq!(
        rpc_requests.len(),
        2,
        "the reverse leg may run, but the refused forward call must not: {rpc_requests:?}"
    );

    lookup_pool.close().await;
    database.cleanup().await?;
    Ok(())
}

/// An absent exact-name row means the name is outside indexed coverage, not that the projection
/// selected an unverifiable authority. Live verification is its only answer path and must run.
#[tokio::test]
async fn an_unindexed_name_is_admitted_to_live_verification() -> Result<()> {
    let database = TestDatabase::new_migrated().await?;
    database.initialize_lookup_schema().await?;
    database
        .seed_default_ens_primary_name_fallback_context()
        .await?;
    let lookup_pool = database.lookup_pool().await?;
    seed_schema_v2_ens_primary_name_authority(
        &lookup_pool,
        21_000_003,
        "0xbinding",
        "2026-04-17T00:00:03Z",
    )
    .await?;

    assert!(bigname_storage::families::name::load_family_name(&lookup_pool,
        &bigname_storage::logical_name_id_for_name("ens", "taytems.eth")).await?.is_none(),
        "the contract requires no exact-name row");

    // The first two calls are the reverse leg; the third response lets the admitted forward
    // dispatch verify the address returned by the claim.
    let (rpc_url, rpc_handle) = spawn_primary_name_mock_rpc(vec![
        json!("0x000000000000000000000000a2c122be93b0074270ebee7f6b7292c7deb45047"),
        primary_name_reverse_name_response("taytems.eth"),
        primary_name_universal_resolver_addr60_response(V2_ON_DEMAND_PRIMARY_NAME_ADDRESS),
    ])
    .await?;
    let chain_rpc_urls =
        bigname_lookup::ChainRpcUrls::from_entries(&[format!("ethereum-mainnet={rpc_url}")])?;
    let state = database
        .app_state_with_lookup_chain_rpc_urls(chain_rpc_urls)
        .await?;

    let response = app_router(state)
        .oneshot(
            Request::builder()
                .uri(format!(
                    "/v1/addresses/{V2_ON_DEMAND_PRIMARY_NAME_ADDRESS}/primary-name?source=verified"
                ))
                .body(Body::empty())
                .expect("request must build"),
        )
        .await
        .context("v2 unindexed-name primary-name request failed")?;
    let status = response.status();
    let payload: Value = read_json(response).await?;
    assert_eq!(status, StatusCode::OK, "{payload}");
    assert_eq!(
        payload["data"]["answers"],
        json!([{
            "source": "verified",
            "status": "ok",
            "name": "taytems.eth"
        }]),
        "{payload}"
    );

    let rpc_requests = join_primary_name_mock_rpc_requests(rpc_handle).await?;
    assert_eq!(
        rpc_requests.len(),
        3,
        "an unindexed name must dispatch the reverse leg and forward verification"
    );
    assert!(
        rpc_requests
            .iter()
            .all(|request| request["method"] == json!("eth_call"))
    );

    lookup_pool.close().await;
    database.cleanup().await?;
    Ok(())
}

/// Under the Sepolia deployment profile the ENS projection publishes on `ethereum-sepolia`, and
/// live ENS/60 verification executes against that chain's manifest-admitted registry and
/// Universal Resolver at its family publication's block: same reverse leg, same gate, same forward call, same
/// hash pinning as Mainnet. The provider is selected by that chain, so a Mainnet-only provider
/// map is a configuration failure rather than a Mainnet call.
#[tokio::test]
async fn v2_get_primary_name_verifies_against_sepolia_under_the_sepolia_profile() -> Result<()> {
    let database = TestDatabase::new_migrated().await?;
    database.initialize_lookup_schema().await?;
    database
        .seed_default_sepolia_ens_primary_name_fallback_context()
        .await?;
    let lookup_pool = database.lookup_pool().await?;
    seed_schema_v2_ens_primary_name_authority_on_chain(
        &lookup_pool,
        "ethereum-sepolia",
        21_000_003,
        "0xbinding",
        "2026-04-17T00:00:03Z",
    )
    .await?;
    let (rpc_url, rpc_handle) = spawn_primary_name_mock_rpc(vec![
        json!("0x000000000000000000000000a2c122be93b0074270ebee7f6b7292c7deb45047"),
        primary_name_reverse_name_response("taytems.eth"),
        primary_name_universal_resolver_addr60_response(V2_ON_DEMAND_PRIMARY_NAME_ADDRESS),
    ])
    .await?;

    let mainnet_only = database
        .app_state_with_lookup_chain_rpc_urls(bigname_lookup::ChainRpcUrls::from_entries(&[
            format!("ethereum-mainnet={rpc_url}"),
        ])?)
        .await?;
    let response = app_router(mainnet_only)
        .oneshot(
            Request::builder()
                .uri(format!(
                    "/v1/addresses/{V2_ON_DEMAND_PRIMARY_NAME_ADDRESS}/primary-name?source=verified"
                ))
                .body(Body::empty())
                .expect("request must build"),
        )
        .await
        .context("v2 sepolia primary-name request without a sepolia provider failed")?;
    let status = response.status();
    let payload: Value = read_json(response).await?;
    assert_eq!(status, StatusCode::CONFLICT, "{payload}");
    assert_eq!(payload["error"]["code"], json!("stale"), "{payload}");

    let sepolia = database
        .app_state_with_lookup_chain_rpc_urls(bigname_lookup::ChainRpcUrls::from_entries(&[
            format!("ethereum-sepolia={rpc_url}"),
        ])?)
        .await?;
    let response = app_router(sepolia)
        .oneshot(
            Request::builder()
                .uri(format!(
                    "/v1/addresses/{V2_ON_DEMAND_PRIMARY_NAME_ADDRESS}/primary-name?source=verified"
                ))
                .body(Body::empty())
                .expect("request must build"),
        )
        .await
        .context("v2 sepolia primary-name request failed")?;
    let status = response.status();
    let payload: Value = read_json(response).await?;
    assert_eq!(status, StatusCode::OK, "{payload}");
    assert_eq!(
        payload["data"]["answers"],
        json!([{
            "source": "verified",
            "status": "ok",
            "name": "taytems.eth"
        }]),
        "{payload}"
    );
    assert_primary_name_snapshot_meta_chain_ids(&payload, &["11155111"]);
    assert_primary_name_snapshot_token_slots(&payload, &["ethereum-sepolia"]);

    let rpc_requests = join_primary_name_mock_rpc_requests(rpc_handle).await?;
    assert_eq!(
        rpc_requests.len(),
        3,
        "the Mainnet-only provider map must not dispatch; the Sepolia map dispatches the reverse leg and forward verification"
    );
    assert_eq!(
        rpc_requests[0]["params"][0]["to"],
        json!("0x00000000000c2e074ec69a0dfb2997ba6c7d2e1e")
    );
    assert_eq!(
        rpc_requests[2]["params"][0]["to"],
        json!("0xeeeeeeee14d718c2b47d9923deab1335e144eeee")
    );
    for request in &rpc_requests {
        assert_eq!(
            request["params"][1]["blockHash"],
            json!("0xbinding"),
            "sepolia calls stay pinned to the sepolia publication: {request}"
        );
    }

    lookup_pool.close().await;
    database.cleanup().await?;
    Ok(())
}

/// A missing family publication refuses verification before any provider dispatch.
#[tokio::test]
async fn v2_get_primary_name_is_stale_without_a_family_publication() -> Result<()> {
    let database = TestDatabase::new_migrated().await?;
    database.initialize_lookup_schema().await?;
    database
        .seed_default_ens_primary_name_fallback_context()
        .await?;
    let lookup_pool = database.lookup_pool().await?;
    seed_schema_v2_ens_primary_name_authority(
        &lookup_pool,
        21_000_003,
        "0xbinding",
        "2026-04-17T00:00:03Z",
    )
    .await?;
    sqlx::query("DELETE FROM bigname_phase.project_family_marker")
        .execute(&lookup_pool)
        .await?;

    let listener = tokio::net::TcpListener::bind("127.0.0.1:0").await?;
    let unavailable_rpc_url = format!("http://{}", listener.local_addr()?);
    drop(listener);
    let chain_rpc_urls = bigname_lookup::ChainRpcUrls::from_entries(&[format!(
        "ethereum-mainnet={unavailable_rpc_url}"
    )])?;
    let state = database
        .app_state_with_lookup_chain_rpc_urls(chain_rpc_urls)
        .await?;

    let response = app_router(state)
        .oneshot(
            Request::builder()
                .uri(format!(
                    "/v1/addresses/{V2_ON_DEMAND_PRIMARY_NAME_ADDRESS}/primary-name?source=verified"
                ))
                .body(Body::empty())
                .expect("request must build"),
        )
        .await
        .context("v2 absent-projection primary-name request failed")?;
    let status = response.status();
    let payload: Value = read_json(response).await?;
    assert_eq!(status, StatusCode::CONFLICT, "{payload}");
    assert_eq!(payload["error"]["code"], json!("stale"));

    lookup_pool.close().await;
    database.cleanup().await?;
    Ok(())
}
