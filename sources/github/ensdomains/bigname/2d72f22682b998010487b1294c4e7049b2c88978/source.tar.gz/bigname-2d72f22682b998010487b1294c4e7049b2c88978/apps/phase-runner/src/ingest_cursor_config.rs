use std::collections::BTreeSet;

use sqlx::{PgPool, Postgres, Transaction};

use crate::{
    config::{SourceConfig, normalized_source_kind},
    error::{RunnerError, RunnerResult},
};

type StoredSourceConfig = (String, String, i64);

pub(crate) async fn ensure_all(
    pool: &PgPool,
    chain_id: &str,
    sources: &[SourceConfig],
) -> RunnerResult<()> {
    validate_persisted_source_keys(pool, chain_id, sources, true).await?;
    for source in sources {
        let stored = initialize(pool, source).await?;
        validate(source, stored)?;
        record_verified_rpc_chain(pool, source).await?;
    }
    validate_persisted_source_keys(pool, chain_id, sources, false).await?;
    Ok(())
}

pub(crate) async fn validate_completed(
    pool: &PgPool,
    chain_id: &str,
    sources: &[SourceConfig],
) -> RunnerResult<()> {
    for source in sources {
        let stored = load(pool, source).await?.ok_or_else(|| {
            RunnerError::data_integrity(format!(
                "completed Ingest source {} on chain {} has no matching cursor; retained ingest \
                 data requires an explicit reset before the source configuration can change",
                source.source_key, source.chain_id
            ))
        })?;
        validate(source, stored)?;
    }
    validate_persisted_source_keys(pool, chain_id, sources, false).await
}

pub(crate) async fn validate_completed_tx(
    transaction: &mut Transaction<'_, Postgres>,
    chain_id: &str,
    sources: &[SourceConfig],
) -> RunnerResult<()> {
    for source in sources {
        let stored = sqlx::query_as::<_, StoredSourceConfig>(
            "SELECT source_kind, seed_basis, start_block_number
             FROM ingest_cursors
             WHERE chain_id = $1 AND source_key = $2",
        )
        .bind(&source.chain_id)
        .bind(&source.source_key)
        .fetch_optional(&mut **transaction)
        .await
        .map_err(|error| {
            RunnerError::database(
                format!(
                    "failed to load ingest cursor {} for chain {}",
                    source.source_key, source.chain_id
                ),
                error,
            )
        })?
        .ok_or_else(|| {
            RunnerError::data_integrity(format!(
                "completed Ingest source {} on chain {} has no matching cursor; retained ingest \
                 data requires an explicit reset before the source configuration can change",
                source.source_key, source.chain_id
            ))
        })?;
        validate(source, stored)?;
    }
    let persisted: Vec<String> = sqlx::query_scalar(
        "SELECT source_key FROM ingest_cursors WHERE chain_id = $1 ORDER BY source_key",
    )
    .bind(chain_id)
    .fetch_all(&mut **transaction)
    .await
    .map_err(|error| {
        RunnerError::database(
            format!("failed to load persisted ingest source keys for chain {chain_id}"),
            error,
        )
    })?;
    validate_source_keys(chain_id, sources, &persisted)
}

pub(crate) async fn validate_existing(
    pool: &PgPool,
    chain_id: &str,
    sources: &[SourceConfig],
) -> RunnerResult<()> {
    validate_persisted_source_keys(pool, chain_id, sources, true).await?;
    for source in sources {
        if let Some(stored) = load(pool, source).await? {
            validate(source, stored)?;
        }
    }
    Ok(())
}

async fn validate_persisted_source_keys(
    pool: &PgPool,
    chain_id: &str,
    sources: &[SourceConfig],
    allow_initializing_subset: bool,
) -> RunnerResult<()> {
    let persisted: Vec<String> = sqlx::query_scalar(
        "SELECT source_key FROM ingest_cursors WHERE chain_id = $1 ORDER BY source_key",
    )
    .bind(chain_id)
    .fetch_all(pool)
    .await
    .map_err(|error| {
        RunnerError::database(
            format!("failed to load persisted ingest source keys for chain {chain_id}"),
            error,
        )
    })?;
    if allow_initializing_subset {
        if persisted.is_empty() {
            return Ok(());
        }
        let configured = sources
            .iter()
            .map(|source| source.source_key.as_str())
            .collect::<BTreeSet<_>>();
        if persisted
            .iter()
            .all(|source_key| configured.contains(source_key.as_str()))
            && !has_durable_ingest_data(pool, chain_id).await?
            && !has_progressed_ingest_cursor(pool, chain_id).await?
        {
            return Ok(());
        }
    }
    validate_source_keys(chain_id, sources, &persisted)
}

async fn has_progressed_ingest_cursor(pool: &PgPool, chain_id: &str) -> RunnerResult<bool> {
    sqlx::query_scalar(
        "SELECT EXISTS (
             SELECT 1 FROM ingest_cursors
             WHERE chain_id = $1
               AND (next_block_number <> start_block_number
                    OR target_block_number IS NOT NULL
                    OR last_processed_block_number IS NOT NULL
                    OR last_processed_block_hash IS NOT NULL)
         )",
    )
    .bind(chain_id)
    .fetch_one(pool)
    .await
    .map_err(|error| {
        RunnerError::database(
            format!("failed to check persisted ingest cursor progress for chain {chain_id}"),
            error,
        )
    })
}

pub(crate) fn validate_source_keys(
    chain_id: &str,
    sources: &[SourceConfig],
    persisted: &[String],
) -> RunnerResult<()> {
    let configured = sources
        .iter()
        .map(|source| source.source_key.as_str())
        .collect::<BTreeSet<_>>();
    let persisted = persisted
        .iter()
        .map(String::as_str)
        .collect::<BTreeSet<_>>();
    if configured == persisted {
        return Ok(());
    }
    Err(RunnerError::data_integrity(format!(
        "persisted ingest source keys for chain {chain_id} differ from the configured source keys; \
         an explicit reset is required before source configuration can change"
    )))
}

async fn initialize(pool: &PgPool, source: &SourceConfig) -> RunnerResult<StoredSourceConfig> {
    if let Some(stored) = load(pool, source).await? {
        return Ok(stored);
    }
    if has_durable_ingest_data(pool, &source.chain_id).await? {
        return Err(RunnerError::data_integrity(format!(
            "cannot initialize ingest source {} on chain {} because durable ingest data already \
             exists without a matching cursor; an explicit reset is required before Ingest can \
             run",
            source.source_key, source.chain_id
        )));
    }
    let (verified_chain_id, verified_genesis_hash) = verified_identity(source)?;
    sqlx::query(
        "INSERT INTO ingest_cursors (
             chain_id, source_key, source_kind, seed_basis,
             start_block_number, next_block_number,
             verified_chain_id, verified_genesis_hash
         )
         VALUES ($1, $2, $3, $4, $5, $5, $6, $7)
         ON CONFLICT (chain_id, source_key) DO NOTHING",
    )
    .bind(&source.chain_id)
    .bind(&source.source_key)
    .bind(normalized_source_kind(&source.source_kind))
    .bind(source.seed_basis.as_str())
    .bind(source.start_block_number)
    .bind(verified_chain_id)
    .bind(verified_genesis_hash)
    .execute(pool)
    .await
    .map_err(|error| {
        RunnerError::database(
            format!(
                "failed to initialize ingest cursor {} for chain {}",
                source.source_key, source.chain_id
            ),
            error,
        )
    })?;
    load(pool, source).await?.ok_or_else(|| {
        RunnerError::data_integrity(format!(
            "initialized ingest cursor {} for chain {} is missing",
            source.source_key, source.chain_id
        ))
    })
}

async fn has_durable_ingest_data(pool: &PgPool, chain_id: &str) -> RunnerResult<bool> {
    sqlx::query_scalar(
        "SELECT EXISTS (
             SELECT 1 FROM raw_transactions WHERE chain_id = $1
         ) OR EXISTS (
             SELECT 1 FROM raw_receipts WHERE chain_id = $1
         ) OR EXISTS (
             SELECT 1 FROM raw_logs WHERE chain_id = $1
         ) OR EXISTS (
             SELECT 1 FROM chain_lineage WHERE chain_id = $1
         ) OR EXISTS (
             SELECT 1 FROM chain_header_audit WHERE chain_id = $1
         )",
    )
    .bind(chain_id)
    .fetch_one(pool)
    .await
    .map_err(|error| {
        RunnerError::database(
            format!("failed to check durable ingest data for chain {chain_id}"),
            error,
        )
    })
}

async fn load(pool: &PgPool, source: &SourceConfig) -> RunnerResult<Option<StoredSourceConfig>> {
    sqlx::query_as(
        "SELECT source_kind, seed_basis, start_block_number
         FROM ingest_cursors
         WHERE chain_id = $1 AND source_key = $2",
    )
    .bind(&source.chain_id)
    .bind(&source.source_key)
    .fetch_optional(pool)
    .await
    .map_err(|error| {
        RunnerError::database(
            format!(
                "failed to check ingest cursor {} for chain {}",
                source.source_key, source.chain_id
            ),
            error,
        )
    })
}

fn validate(source: &SourceConfig, stored: StoredSourceConfig) -> RunnerResult<()> {
    let (_, stored_seed, stored_start) = &stored;
    if stored_seed != source.seed_basis.as_str() || *stored_start != source.start_block_number {
        return Err(RunnerError::data_integrity(format!(
            "persisted ingest seed configuration for source {} on chain {} differs from runtime \
             configuration",
            source.source_key, source.chain_id
        )));
    }
    validate_kind(source, &stored)
}

fn validate_kind(source: &SourceConfig, stored: &StoredSourceConfig) -> RunnerResult<()> {
    let (stored_kind, _, _) = stored;
    if normalized_source_kind(stored_kind) != normalized_source_kind(&source.source_kind) {
        return Err(RunnerError::data_integrity(format!(
            "persisted ingest source kind for source {} on chain {} differs from runtime \
             configuration; source kind changes require an explicit reset and full source \
             re-walk (docs/glossary.md#re-derivation-boundary)",
            source.source_key, source.chain_id
        )));
    }
    Ok(())
}

type VerifiedIdentity = (Option<i64>, Option<String>);

fn verified_identity(source: &SourceConfig) -> RunnerResult<VerifiedIdentity> {
    let Some(observed) = &source.verified_rpc_chain else {
        return Ok((None, None));
    };
    let chain_id = observed
        .chain_id
        .map(i64::try_from)
        .transpose()
        .map_err(|_| {
            RunnerError::data_integrity(format!(
                "verified chain id of source {} on chain {} exceeds the stored range",
                source.source_key, source.chain_id
            ))
        })?;
    Ok((chain_id, observed.genesis_hash.clone()))
}

/// Records the identity this start's RPC chain check observed on the source's cursor where the
/// cursor has none yet, and refuses when the cursor recorded a different chain id, or a
/// different genesis hash when both are known. Runs at startup and again once Ingest holds its
/// cursor, so a cursor another start created in between is held to this start's observation.
pub(crate) async fn record_verified_rpc_chain(
    pool: &PgPool,
    source: &SourceConfig,
) -> RunnerResult<()> {
    let observed = verified_identity(source)?;
    if observed.0.is_none() {
        return Ok(());
    }
    let label = format!(
        "ingest cursor {} for chain {}",
        source.source_key, source.chain_id
    );
    let mut transaction = pool.begin().await.map_err(|error| {
        RunnerError::database(format!("failed to begin recording {label}"), error)
    })?;
    let stored = sqlx::query_as::<_, VerifiedIdentity>(
        "SELECT verified_chain_id, verified_genesis_hash
         FROM ingest_cursors
         WHERE chain_id = $1 AND source_key = $2
         FOR UPDATE",
    )
    .bind(&source.chain_id)
    .bind(&source.source_key)
    .fetch_optional(&mut *transaction)
    .await
    .map_err(|error| RunnerError::database(format!("failed to load {label}"), error))?;
    let Some(stored) = stored else {
        return Ok(());
    };
    let genesis_differs = matches!(
        (&stored.1, &observed.1),
        (Some(recorded), Some(reported)) if recorded != reported
    );
    if stored
        .0
        .is_some_and(|recorded| Some(recorded) != observed.0)
        || genesis_differs
    {
        return Err(RunnerError::data_integrity(format!(
            "{label} recorded RPC chain id {} and genesis block hash {}, but its endpoint now \
             reports chain id {} and genesis block hash {}; a cursor cannot continue on another \
             chain",
            describe(stored.0),
            stored.1.as_deref().unwrap_or("none"),
            describe(observed.0),
            observed.1.as_deref().unwrap_or("not checked"),
        )));
    }
    if stored.0.is_none() || (stored.1.is_none() && observed.1.is_some()) {
        sqlx::query(
            "UPDATE ingest_cursors
             SET verified_chain_id = $3,
                 verified_genesis_hash = COALESCE(verified_genesis_hash, $4)
             WHERE chain_id = $1 AND source_key = $2",
        )
        .bind(&source.chain_id)
        .bind(&source.source_key)
        .bind(observed.0)
        .bind(&observed.1)
        .execute(&mut *transaction)
        .await
        .map_err(|error| RunnerError::database(format!("failed to record {label}"), error))?;
    }
    transaction
        .commit()
        .await
        .map_err(|error| RunnerError::database(format!("failed to commit {label}"), error))
}

fn describe(chain_id: Option<i64>) -> String {
    chain_id.map_or_else(|| "none".to_owned(), |id| id.to_string())
}
