// `relation=resolves_to&coin_type=evm`: names whose stored `addr:<coin_type>` record for any EVM
// coin type (60, or 2^31 through 2^32 - 1) resolves to the address, one row per name with the
// matched coin types in `resolutions`.

const V2_RESOLVES_TO_BASE_COIN: &str = "2147492101";

/// Extra records over `seed_v2_resolves_to_records`: alpha also resolves here on Base, and
/// 20-byte values under non-EVM coin types (118, 61), which the record index keeps because it
/// checks the value's shape, not the coin type.
async fn seed_v2_resolves_to_evm_records(database: &TestDatabase) -> Result<()> {
    seed_v2_resolves_to_records(database).await?;
    write_address_name_records(
        database,
        &[
            (
                "alpha.eth",
                vec![(format!("addr:{V2_RESOLVES_TO_BASE_COIN}"), V2_ADDRESS.into())],
            ),
            ("gamma.eth", vec![("addr:118".into(), V2_ADDRESS.into())]),
            ("beta.eth", vec![("addr:61".into(), V2_ADDRESS.into())]),
        ],
    )
    .await
}

fn resolutions(row: &Value) -> Vec<(u64, &str)> {
    row["resolutions"]
        .as_array()
        .unwrap_or_else(|| panic!("row must carry resolutions: {row}"))
        .iter()
        .map(|entry| {
            (
                entry["coin_type"].as_u64().expect("numeric coin_type"),
                entry["record_key"].as_str().expect("record_key"),
            )
        })
        .collect()
}

fn row_named<'a>(rows: &'a [Value], name: &str) -> &'a Value {
    rows.iter()
        .find(|row| row["name"] == json!(name))
        .unwrap_or_else(|| panic!("{name} must be present"))
}

async fn v2_resolves_to_evm_rows(database: &TestDatabase, query: &str) -> Result<Vec<Value>> {
    let payload = v2_address_names_payload_for_database(
        database,
        &format!("/v1/addresses/{V2_ADDRESS}/names?relation=resolves_to&coin_type=evm{query}"),
    )
    .await?;
    Ok(payload["data"].as_array().expect("data array").clone())
}

#[tokio::test]
async fn v2_resolves_to_evm_discovers_names_across_evm_coin_types() -> Result<()> {
    let database = TestDatabase::new_migrated().await?;
    seed_v2_address_names_fixture(&database).await?;
    seed_v2_resolves_to_evm_records(&database).await?;

    let payload = v2_address_names_payload_for_database(
        &database,
        &format!("/v1/addresses/{V2_ADDRESS}/names?relation=resolves_to&coin_type=evm"),
    )
    .await?;
    let rows = payload["data"].as_array().expect("evm data");
    // beta matches only another EVM chain and shared-one only the shadowed default record, so
    // neither appears in the default coin-60 read; here every EVM match is found in one call.
    assert_eq!(
        names(rows),
        vec!["alpha.eth", "beta.eth", "gamma.eth", "shared-one.eth"]
    );
    // One row per name with every matched EVM coin type, ascending.
    assert_eq!(
        resolutions(row_named(rows, "alpha.eth")),
        vec![(60, "addr:60"), (2_147_492_101, "addr:2147492101")]
    );
    // Coin 61 is a legacy SLIP-44 coin type, not an ENSIP-19 EVM coin type.
    assert_eq!(
        resolutions(row_named(rows, "beta.eth")),
        vec![(2_147_483_658, "addr:2147483658")]
    );
    // A non-EVM coin type with a 20-byte value is not matched.
    assert_eq!(
        resolutions(row_named(rows, "gamma.eth")),
        vec![(60, "addr:60")]
    );
    // The stored default record appears once under its own coin type, although an exact coin-60
    // entry shadows it for coin 60, and it is not expanded into the chains it would answer.
    assert_eq!(
        resolutions(row_named(rows, "shared-one.eth")),
        vec![(2_147_483_648, "addr:2147483648")]
    );
    for row in rows {
        assert!(row.get("resolution").is_none(), "{row}");
        assert_eq!(row["relations"], json!(["resolves_to"]), "{row}");
    }
    assert_eq!(payload["page"]["total_count"], Value::Null);
    assert_eq!(payload["page"]["has_more"], json!(false));
    assert_no_banned_v1_spellings(&payload);

    // The single-coin reads keep their meaning and shape.
    let default_payload = v2_address_names_payload_for_database(
        &database,
        &format!("/v1/addresses/{V2_ADDRESS}/names?relation=resolves_to"),
    )
    .await?;
    let default_rows = default_payload["data"].as_array().expect("default data");
    assert_eq!(names(default_rows), vec!["alpha.eth", "gamma.eth"]);
    assert_eq!(
        default_rows[0]["resolution"],
        json!({"coin_type": 60, "record_key": "addr:60"})
    );
    assert!(
        default_rows
            .iter()
            .all(|row| row.get("resolutions").is_none())
    );
    let cosmos = v2_address_names_payload_for_database(
        &database,
        &format!("/v1/addresses/{V2_ADDRESS}/names?relation=resolves_to&coin_type=118"),
    )
    .await?;
    assert_eq!(
        names(cosmos["data"].as_array().expect("coin 118 data")),
        vec!["gamma.eth"]
    );

    // Filters narrow the evm read before pagination exactly as they narrow a single-coin read.
    let q_rows = v2_resolves_to_evm_rows(&database, "&q=sh").await?;
    assert_eq!(names(&q_rows), vec!["shared-one.eth"]);
    let basenames = v2_resolves_to_evm_rows(&database, "&namespace=basenames").await?;
    assert!(basenames.is_empty());
    let counted = v2_resolves_to_evm_rows(&database, "&include=counts&q=alpha").await?;
    assert_eq!(names(&counted), vec!["alpha.eth"]);
    assert!(counted[0]["subname_count"].is_u64(), "{}", counted[0]);

    database.cleanup().await
}

#[tokio::test]
async fn v2_resolves_to_evm_finds_a_base_only_address() -> Result<()> {
    let database = TestDatabase::new_migrated().await?;
    seed_v2_address_names_fixture(&database).await?;
    write_address_name_records(
        &database,
        &[(
            "beta.eth",
            vec![(format!("addr:{V2_RESOLVES_TO_BASE_COIN}"), V2_OTHER_ADDRESS.into())],
        )],
    )
    .await?;

    let default_payload = v2_address_names_payload_for_database(
        &database,
        &format!("/v1/addresses/{V2_OTHER_ADDRESS}/names?relation=resolves_to"),
    )
    .await?;
    assert_eq!(default_payload["data"], json!([]));

    // Checksum case is accepted and lowercased, as on every address route.
    let evm_payload = v2_address_names_payload_for_database(
        &database,
        "/v1/addresses/0x0000000000000000000000000000000000000DEF/names?relation=resolves_to&coin_type=evm",
    )
    .await?;
    let rows = evm_payload["data"].as_array().expect("evm data");
    assert_eq!(names(rows), vec!["beta.eth"]);
    assert_eq!(
        resolutions(&rows[0]),
        vec![(2_147_492_101, "addr:2147492101")]
    );

    database.cleanup().await
}

#[tokio::test]
async fn v2_resolves_to_evm_parameter_spelling() -> Result<()> {
    let database = TestDatabase::new_migrated().await?;
    seed_v2_address_names_fixture(&database).await?;
    seed_v2_resolves_to_evm_records(&database).await?;
    let base = format!("/v1/addresses/{V2_ADDRESS}/names?relation=resolves_to");

    // A bare or whitespace-only coin_type stays "omitted": coin type 60.
    let omitted = v2_address_names_payload_for_database(&database, &base).await?;
    for blank in ["&coin_type=", "&coin_type=%20%20"] {
        let payload = v2_address_names_payload_for_database(&database, &format!("{base}{blank}"))
            .await?;
        assert_eq!(payload["data"], omitted["data"], "{blank}");
    }
    // Boundary whitespace is trimmed like every query value.
    let evm = v2_address_names_payload_for_database(&database, &format!("{base}&coin_type=evm"))
        .await?;
    let padded =
        v2_address_names_payload_for_database(&database, &format!("{base}&coin_type=%20evm%20"))
            .await?;
    assert_eq!(padded["data"], evm["data"]);

    for (query, fragment) in [
        ("&coin_type=EVM", "coin_type"),
        ("&coin_type=Evm", "coin_type"),
        ("&coin_type=evm,60", "coin_type"),
        ("&coin_type=60,2147492101", "coin_type"),
        ("&coin_type=any", "coin_type"),
        ("&coin_type=evm&is_migrated=true", "is_migrated"),
    ] {
        let uri = format!("{base}{query}");
        let response = v2_address_names_response_for_database(&database, &uri).await?;
        assert_eq!(response.status(), StatusCode::BAD_REQUEST, "{uri}");
        let payload: Value = read_json(response).await?;
        assert_eq!(payload["error"]["code"], json!("invalid_input"), "{uri}");
        let message = payload["error"]["message"].as_str().expect("message");
        assert!(message.contains(fragment), "{uri}: {message}");
    }
    let response = v2_address_names_response_for_database(
        &database,
        &format!("/v1/addresses/{V2_ADDRESS}/names?relation=owner&coin_type=evm"),
    )
    .await?;
    assert_eq!(response.status(), StatusCode::BAD_REQUEST);

    database.cleanup().await
}

/// Walk `coin_type=evm` with `page_size=1` for each covered sort and order and require the pages,
/// concatenated, to equal the unpaged read: nothing repeated or skipped when a name or group
/// matches several coin types.
async fn assert_v2_resolves_to_evm_page_walks(database: &TestDatabase, dedupe: &str) -> Result<()> {
    for (sort, order) in [("name", "asc"), ("name", "desc"), ("expires_at", "asc")] {
        let base = format!(
            "/v1/addresses/{V2_ADDRESS}/names?relation=resolves_to&coin_type=evm&dedupe={dedupe}&sort={sort}&order={order}"
        );
        let full = v2_address_names_payload_for_database(database, &base).await?;
        let expected = full["data"].as_array().expect("full page").clone();
        let mut paged = Vec::new();
        let mut cursor: Option<String> = None;
        loop {
            let uri = match &cursor {
                Some(cursor) => format!("{base}&page_size=1&cursor={cursor}"),
                None => format!("{base}&page_size=1"),
            };
            let page = v2_address_names_payload_for_database(database, &uri).await?;
            let rows = page["data"].as_array().expect("page rows");
            assert_eq!(rows.len(), 1, "{uri}: {page}");
            paged.push(rows[0].clone());
            match page["page"]["next_cursor"].as_str() {
                Some(next) => cursor = Some(next.to_owned()),
                None => break,
            }
        }
        let paged_names = names(&paged);
        let distinct = paged_names.iter().collect::<std::collections::BTreeSet<_>>();
        assert_eq!(distinct.len(), paged_names.len(), "{dedupe} {sort} {order}");
        assert_eq!(paged, expected, "{dedupe} {sort} {order}");
    }
    Ok(())
}

#[tokio::test]
async fn v2_resolves_to_evm_paginates_and_binds_cursor_to_the_selector() -> Result<()> {
    let database = TestDatabase::new_migrated().await?;
    seed_v2_address_names_fixture(&database).await?;
    seed_v2_resolves_to_evm_records(&database).await?;

    assert_v2_resolves_to_evm_page_walks(&database, "name").await?;

    let first = v2_address_names_payload_for_database(
        &database,
        &format!("/v1/addresses/{V2_ADDRESS}/names?relation=resolves_to&coin_type=evm&page_size=1"),
    )
    .await?;
    let evm_cursor = first["page"]["next_cursor"].as_str().expect("evm cursor");
    let single = v2_address_names_payload_for_database(
        &database,
        &format!("/v1/addresses/{V2_ADDRESS}/names?relation=resolves_to&page_size=1"),
    )
    .await?;
    let single_cursor = single["page"]["next_cursor"].as_str().expect("single cursor");
    for uri in [
        format!(
            "/v1/addresses/{V2_ADDRESS}/names?relation=resolves_to&page_size=1&cursor={evm_cursor}"
        ),
        format!(
            "/v1/addresses/{V2_ADDRESS}/names?relation=resolves_to&coin_type=2147483648&page_size=1&cursor={evm_cursor}"
        ),
        format!(
            "/v1/addresses/{V2_ADDRESS}/names?relation=resolves_to&coin_type=evm&dedupe=registration&page_size=1&cursor={evm_cursor}"
        ),
        format!(
            "/v1/addresses/{V2_ADDRESS}/names?relation=resolves_to&coin_type=evm&page_size=1&cursor={single_cursor}"
        ),
    ] {
        let response = v2_address_names_response_for_database(&database, &uri).await?;
        assert_eq!(response.status(), StatusCode::BAD_REQUEST, "{uri}");
    }

    database.cleanup().await
}

#[tokio::test]
async fn v2_resolves_to_evm_registration_dedupe_paginates() -> Result<()> {
    let database = TestDatabase::new_migrated().await?;
    seed_v2_address_names_fixture(&database).await?;
    seed_v2_resolves_to_evm_records(&database).await?;
    // alpha matches coin 60 and Base.
    let rows = v2_resolves_to_evm_rows(&database, "&dedupe=registration").await?;
    assert_eq!(
        names(&rows),
        vec!["alpha.eth", "beta.eth", "gamma.eth", "shared-one.eth"]
    );
    assert_eq!(resolutions(row_named(&rows, "alpha.eth")).len(), 2);

    assert_v2_resolves_to_evm_page_walks(&database, "registration").await?;

    database.cleanup().await
}

// The admitted ENS reverse registrar claims coin type 60 only, so every ENS claim here is a
// coin-60 claim; one naming a row that did not match coin 60 does not mark it.
#[tokio::test]
async fn v2_resolves_to_evm_is_primary_counts_only_the_row_matched_coins() -> Result<()> {
    let database = TestDatabase::new_migrated().await?;
    seed_v2_address_names_fixture(&database).await?;
    seed_v2_resolves_to_evm_records(&database).await?;

    let rows = v2_resolves_to_evm_rows(&database, "").await?;
    // The fixture's coin-60 claim names alpha, which matched coin 60.
    assert_eq!(row_named(&rows, "alpha.eth")["is_primary"], json!(true));
    assert_eq!(row_named(&rows, "gamma.eth")["is_primary"], json!(false));
    assert_eq!(row_named(&rows, "beta.eth")["is_primary"], json!(false));
    assert_eq!(row_named(&rows, "shared-one.eth")["is_primary"], json!(false));

    // beta and shared-one matched only other EVM coin types, so a coin-60 claim naming either
    // one leaves it unmarked.
    for name in ["beta.eth", "shared-one.eth"] {
        publish_primary_claim(&database.pool, "ens", V2_ADDRESS, name.as_bytes()).await?;
        let rows = v2_resolves_to_evm_rows(&database, "").await?;
        assert!(
            rows.iter().all(|row| row["is_primary"] == json!(false)),
            "{name}: {rows:#?}"
        );
    }

    database.cleanup().await
}

/// An address other fixtures leave empty, holding one name at exactly the per-row coin-type limit.
const V2_EVM_BOUNDED_ADDRESS: &str = "0x0000000000000000000000000000000000000e0b";
/// An address other fixtures leave empty, holding one name past the per-row coin-type limit.
const V2_EVM_WIDE_ADDRESS: &str = "0x0000000000000000000000000000000000000e0a";

/// The `count` lowest ENSIP-11 coin types above the default coin type, ascending.
fn v2_evm_wide_coin_types(count: u64) -> Vec<u64> {
    (1..=count).map(|offset| 2_147_483_648 + offset).collect()
}

/// Stores `name` as resolving to `address` under each of `coin_types`.
async fn seed_v2_evm_wide_rows(
    database: &TestDatabase,
    address: &str,
    name: &str,
    coin_types: &[u64],
) -> Result<()> {
    let writes = coin_types
        .iter()
        .map(|coin_type| (format!("addr:{coin_type}"), address.to_owned()))
        .collect();
    write_address_name_records(database, &[(name, writes)]).await
}

/// Seeds the bound fixture: at `V2_EVM_BOUNDED_ADDRESS`, alpha and shared-one match exactly the
/// limit; at `V2_EVM_WIDE_ADDRESS`, beta and shared-two match one coin type past the limit. A
/// name holds one value per coin type, so no name resolves to both addresses.
async fn seed_v2_evm_bound_fixture(database: &TestDatabase) -> Result<()> {
    let limit = bigname_storage::EVM_MATCHED_COIN_TYPES_PER_ROW_LIMIT;
    let at_limit = v2_evm_wide_coin_types(limit);
    let past_limit = v2_evm_wide_coin_types(limit + 1);
    for name in ["alpha.eth", "shared-one.eth"] {
        seed_v2_evm_wide_rows(database, V2_EVM_BOUNDED_ADDRESS, name, &at_limit).await?;
    }
    for name in ["beta.eth", "shared-two.eth"] {
        seed_v2_evm_wide_rows(database, V2_EVM_WIDE_ADDRESS, name, &past_limit).await?;
    }
    Ok(())
}

#[tokio::test]
async fn v2_resolves_to_evm_rejects_a_row_past_the_coin_type_limit() -> Result<()> {
    let limit = bigname_storage::EVM_MATCHED_COIN_TYPES_PER_ROW_LIMIT;
    let database = TestDatabase::new_migrated().await?;
    seed_v2_address_names_fixture(&database).await?;
    seed_v2_evm_bound_fixture(&database).await?;

    // A row at exactly the limit is served whole, under either dedupe.
    let at_limit = v2_evm_wide_coin_types(limit);
    for (dedupe, name) in [("name", "alpha.eth"), ("registration", "shared-one.eth")] {
        let payload = v2_address_names_payload_for_database(
            &database,
            &format!(
                "/v1/addresses/{V2_EVM_BOUNDED_ADDRESS}/names?relation=resolves_to&coin_type=evm&dedupe={dedupe}"
            ),
        )
        .await?;
        let rows = payload["data"].as_array().expect("data array");
        let coins = resolutions(row_named(rows, name))
            .into_iter()
            .map(|(coin_type, _)| coin_type)
            .collect::<Vec<_>>();
        assert_eq!(coins, at_limit, "{dedupe}");
    }

    // One coin type past the limit is rejected, even for a one-row page, rather than served
    // truncated.
    for query in ["&page_size=1", "&dedupe=registration&page_size=1", ""] {
        let uri = format!(
            "/v1/addresses/{V2_EVM_WIDE_ADDRESS}/names?relation=resolves_to&coin_type=evm{query}"
        );
        let response = v2_address_names_response_for_database(&database, &uri).await?;
        assert_eq!(
            response.status(),
            StatusCode::UNPROCESSABLE_ENTITY,
            "{uri}"
        );
        let payload: Value = read_json(response).await?;
        assert_eq!(payload["error"]["code"], json!("unsupported"), "{uri}");
        assert_eq!(
            payload["error"]["message"],
            json!(format!(
                "coin_type=evm matched more than {limit} EVM coin types on one row; request a single decimal coin_type instead"
            )),
            "{uri}"
        );
    }
    // A single coin type still serves the same names.
    let single = v2_address_names_payload_for_database(
        &database,
        &format!(
            "/v1/addresses/{V2_EVM_WIDE_ADDRESS}/names?relation=resolves_to&coin_type={}",
            2_147_483_648 + limit + 1
        ),
    )
    .await?;
    assert_eq!(
        names(single["data"].as_array().expect("data array")),
        vec!["beta.eth", "shared-two.eth"]
    );

    database.cleanup().await
}
