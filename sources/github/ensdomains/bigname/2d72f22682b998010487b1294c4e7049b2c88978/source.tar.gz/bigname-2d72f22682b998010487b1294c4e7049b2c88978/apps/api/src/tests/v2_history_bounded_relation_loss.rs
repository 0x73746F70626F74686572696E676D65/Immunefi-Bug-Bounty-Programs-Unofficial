// A relation the address held at the bound and lost after it. Project's publication after the loss
// has no current row for the relation, so a read bound below the loss
// can admit the name's older events only if the historical event matcher reproduces the relation
// from the event that created it. The matcher knows three shapes: a `RegistrationGranted`
// registrant and a `TokenControlTransferred` recipient on a token-backed resource, both read as
// `owner`, and an `AuthorityTransferred` owner on a registry-only resource or an ENSv2 registry
// resource. Each
// test below loses one relation kind; the ignored ones are the known limitation listed under
// "Known limitation" in the history anchor section of docs/api-v1-routes.md: kinds the matcher
// does not reproduce, which stay on the current-row path bounded by the cited block.

const LOST_OTHER: &str = "0x00000000000000000000000000000000000b0aff";

/// Seed `name` with `relation` created by `created` at block 205 and a later name event at 210,
/// then lose the relation at 241: the token and the registry node move to another account, and
/// Project publishes 241 without the address's relation. Returns the bounded read at 240 before
/// and after that publication, filtered to `filter` when given.
async fn lost_relation_history(
    name: &str,
    seed: u128,
    filter: Option<bigname_storage::AddressNameRelation>,
    created: impl FnOnce(&str, Uuid) -> NormalizedEvent,
) -> Result<(Vec<String>, Vec<String>)> {
    let database = TestDatabase::new_migrated().await?;
    seed_bounded_membership_blocks(&database, 240).await?;
    let (logical_name_id, resource) =
        seed_bounded_name(&database, name, seed).await?;
    let mut later = v2_history_event(
        &format!("{name}-renewed"),
        Some(&logical_name_id),
        Some(resource),
        "RegistrationRenewed",
        210,
    );
    later.log_index = Some(1);
    let mut lost = v2_history_event(
        &format!("{name}-lost"),
        Some(&logical_name_id),
        Some(resource),
        "TokenControlTransferred",
        241,
    );
    lost.after_state = json!({ "to": LOST_OTHER });
    let mut lost_control = v2_history_event(
        &format!("{name}-lost-control"),
        Some(&logical_name_id),
        Some(resource),
        "AuthorityTransferred",
        241,
    );
    lost_control.source_family = "ens_v1_registry_l1".to_owned();
    lost_control.log_index = Some(1);
    lost_control.after_state = json!({
        "source_event": "Transfer",
        "node": bigname_lookup::ens_namehash_hex(name)?,
        "owner": LOST_OTHER,
    });
    bigname_storage::insert_normalized_event_fixtures(
        &database.pool,
        &[created(&logical_name_id, resource), later, lost, lost_control],
    )
    .await?;
    publish_test_families(&database, 240).await?;
    let held = bounded_address_history_hashes(&database, filter, 240).await?;
    publish_test_families(&database, 241).await?;
    let current = bigname_storage::load_address_names_current(
        &database.pool,
        BOUNDED_ADDRESS,
        None,
        None,
    )
    .await?;
    anyhow::ensure!(
        current.iter().all(|row| row.logical_name_id != logical_name_id),
        "the publication at 241 still relates the address to {name}: {current:?}"
    );
    let lost = bounded_address_history_hashes(&database, filter, 240).await?;
    database.cleanup().await?;
    Ok((held, lost))
}

fn assert_relation_survives_loss(held: &[String], lost: &[String]) {
    assert_eq!(
        held,
        ["0xtx210", "0xtx205"],
        "the relation held at 240 admits the name"
    );
    assert_eq!(
        lost, held,
        "losing the relation at 241 changed what a read bound at 240 admits"
    );
}

fn relation_event(
    kind: &str,
    after_state: Value,
    derivation_kind: &str,
) -> impl FnOnce(&str, Uuid) -> NormalizedEvent {
    let kind = kind.to_owned();
    let derivation_kind = derivation_kind.to_owned();
    move |logical_name_id: &str, resource: Uuid| {
        let mut event = v2_history_event(
            &format!("{logical_name_id}-{kind}"),
            Some(logical_name_id),
            Some(resource),
            &kind,
            205,
        );
        event.after_state = after_state;
        event.derivation_kind = derivation_kind;
        event
    }
}

const V1_DERIVATION: &str = "ens_v1_unwrapped_authority";
const V2_DERIVATION: &str = "ens_v2_registry_resource_surface";

#[tokio::test]
async fn lost_token_holder_from_a_transfer_keeps_its_bounded_history() -> Result<()> {
    let (held, lost) = lost_relation_history(
        "lost-transfer-holder.eth",
        0xb0a_6100,
        Some(bigname_storage::AddressNameRelation::TokenHolder),
        relation_event(
            "TokenControlTransferred",
            json!({"to": BOUNDED_ADDRESS}),
            V1_DERIVATION,
        ),
    )
    .await?;
    assert_relation_survives_loss(&held, &lost);
    Ok(())
}

#[tokio::test]
async fn lost_ens_v2_controller_from_an_authority_transfer_keeps_its_bounded_history() -> Result<()>
{
    let (held, lost) = lost_relation_history(
        "lost-v2-controller.eth",
        0xb0a_6200,
        Some(bigname_storage::AddressNameRelation::EffectiveController),
        relation_event(
            "AuthorityTransferred",
            json!({"owner": BOUNDED_ADDRESS}),
            V2_DERIVATION,
        ),
    )
    .await?;
    assert_relation_survives_loss(&held, &lost);
    Ok(())
}

#[tokio::test]
#[ignore = "docs/api-v1-routes.md history known limitation: an ENSv1 .eth registry controller \
            from AuthorityTransferred on a token-backed resource is not reproduced"]
async fn lost_ens_v1_controller_of_a_token_backed_name_keeps_its_bounded_history() -> Result<()> {
    let (held, lost) = lost_relation_history(
        "lost-v1-token-controller.eth",
        0xb0a_6300,
        Some(bigname_storage::AddressNameRelation::EffectiveController),
        relation_event(
            "AuthorityTransferred",
            json!({"owner": BOUNDED_ADDRESS}),
            V1_DERIVATION,
        ),
    )
    .await?;
    assert_relation_survives_loss(&held, &lost);
    Ok(())
}

#[tokio::test]
async fn lost_token_holder_from_a_grant_keeps_its_bounded_history() -> Result<()> {
    let (held, lost) = lost_relation_history(
        "lost-grant-holder.eth",
        0xb0a_6400,
        Some(bigname_storage::AddressNameRelation::TokenHolder),
        relation_event(
            "RegistrationGranted",
            json!({"authority_kind": "registrar", "registrant": BOUNDED_ADDRESS}),
            V1_DERIVATION,
        ),
    )
    .await?;
    assert_relation_survives_loss(&held, &lost);
    Ok(())
}

#[tokio::test]
#[ignore = "docs/api-v1-routes.md history known limitation: an effective controller that fell \
            back to the token holder is not reproduced"]
async fn lost_controller_from_the_token_holder_fallback_keeps_its_bounded_history() -> Result<()> {
    let (held, lost) = lost_relation_history(
        "lost-fallback-controller.eth",
        0xb0a_6600,
        Some(bigname_storage::AddressNameRelation::EffectiveController),
        relation_event(
            "TokenControlTransferred",
            json!({"to": BOUNDED_ADDRESS}),
            V1_DERIVATION,
        ),
    )
    .await?;
    assert_relation_survives_loss(&held, &lost);
    Ok(())
}

const WRAPPER_CONTRACT: &str = "0x00000000000000000000000000000000000b0a0e";

/// The NameWrapper holder powers the adapter grants with the ERC-1155 token, in its order.
const WRAPPER_HOLDER_POWERS: [&str; 10] = [
    "resource_control",
    "set_resolver",
    "set_ttl",
    "create_subnames",
    "transfer",
    "unwrap",
    "burn_fuses",
    "approve",
    "extend_subname_expiry",
    "extend_expiry",
];

/// The holder grant the ENSv1 adapter writes when the NameWrapper token moves to `subject`: a
/// resource-scoped `PermissionChanged` carrying `resource_control`, the shape the controller fold
/// sets a controller from.
fn wrapper_holder_grant(logical_name_id: &str, resource: Uuid, subject: &str) -> NormalizedEvent {
    let mut event = v2_history_event(
        &format!("{logical_name_id}-wrapper-holder-grant"),
        Some(logical_name_id),
        Some(resource),
        "PermissionChanged",
        205,
    );
    event.source_family = "ens_v1_wrapper_l1".to_owned();
    event.log_index = Some(1);
    event.derivation_kind = V1_DERIVATION.to_owned();
    let node = logical_name_id.rsplit(':').next().unwrap_or_default();
    let state = |powers: Value, grant_source: Value| {
        json!({
            "subject": subject,
            "scope": {"kind": "resource"},
            "effective_powers": powers,
            "grant_source": grant_source,
            "revocation_source": null,
            "inheritance_path": [],
            "transfer_behavior": "replace_on_authority_change",
        })
    };
    event.before_state = state(json!([]), Value::Null);
    event.after_state = state(
        json!(WRAPPER_HOLDER_POWERS),
        json!({
            "kind": "ens_v1_authority",
            "authority_kind": "wrapper",
            "authority_key": "wrapper:ethereum-mainnet:history",
            "authority_contract": WRAPPER_CONTRACT,
            "relation_kind": "holder",
            "node": node,
            "source_event_kind": "TransferSingle",
        }),
    );
    event
}

/// An ENSv1 controller set by the NameWrapper holder grant: Project writes the controller row from
/// the grant, and the address loses it after the bound. No historical shape reproduces a
/// `PermissionChanged` controller, so the read at the bound loses the name.
#[tokio::test]
#[ignore = "docs/api-v1-routes.md history known limitation: an ENSv1 controller from a \
            NameWrapper holder PermissionChanged is not reproduced"]
async fn lost_controller_from_a_wrapper_holder_grant_keeps_its_bounded_history() -> Result<()> {
    const NAME: &str = "lost-wrapper-controller.eth";
    let database = TestDatabase::new_migrated().await?;
    seed_bounded_membership_blocks(&database, 240).await?;
    let (logical_name_id, resource) = seed_bounded_name(&database, NAME, 0xb0a_6700)
    .await?;
    // Open the binding before every event of the lease, so they all fall inside it.
    sqlx::query(
        "UPDATE bigname_phase.surface_bindings SET active_from = '2023-11-14T00:00:00Z'
         WHERE logical_name_id = $1",
    )
    .bind(&logical_name_id)
    .execute(&database.pool)
    .await?;
    // The lease registered through the NameWrapper: the registrar token belongs to the wrapper
    // contract, and the address holds the wrapper token that the holder grant stands for.
    let mut registered = v2_history_event(
        &format!("{NAME}-registered"),
        Some(&logical_name_id),
        Some(resource),
        "RegistrationGranted",
        205,
    );
    registered.after_state["registrant"] = json!(WRAPPER_CONTRACT);
    let mut renewed = v2_history_event(
        &format!("{NAME}-renewed"),
        Some(&logical_name_id),
        Some(resource),
        "RegistrationRenewed",
        210,
    );
    renewed.log_index = Some(1);
    let mut lost = v2_history_event(
        &format!("{NAME}-lost"),
        Some(&logical_name_id),
        Some(resource),
        "TokenControlTransferred",
        241,
    );
    lost.after_state = json!({ "to": LOST_OTHER });
    bigname_storage::insert_normalized_event_fixtures(
        &database.pool,
        &[
            registered,
            wrapper_holder_grant(&logical_name_id, resource, BOUNDED_ADDRESS),
            renewed,
            lost,
        ],
    )
    .await?;
    publish_test_families(&database, 240).await?;
    let controller = bigname_storage::load_address_names_current(
        &database.pool,
        BOUNDED_ADDRESS,
        None,
        Some(bigname_storage::AddressNameRelation::EffectiveController),
    )
    .await?
    .into_iter()
    .find(|row| row.logical_name_id == logical_name_id)
    .context("the controller relation at 240")?;
    let cited = (
        controller.provenance["normalized_event_id"]
            .as_i64()
            .context("cited event")?,
        controller.chain_positions["block_number"]
            .as_i64()
            .context("cited block")?,
    );
    let grant: i64 = sqlx::query_scalar(
        "SELECT normalized_event_id FROM normalized_events WHERE event_identity = $1",
    )
    .bind(format!("{logical_name_id}-wrapper-holder-grant"))
    .fetch_one(&database.pool)
    .await?;
    assert_eq!(cited, (grant, 205), "Project cites the holder grant for the controller");

    let filter = Some(bigname_storage::AddressNameRelation::EffectiveController);
    let held = bounded_address_history_hashes(&database, filter, 240).await?;
    publish_test_families(&database, 241).await?;
    let lost = bounded_address_history_hashes(&database, filter, 240).await?;
    database.cleanup().await?;
    // The registration and the holder grant share the wrapper's registration transaction.
    assert_eq!(
        held,
        ["0xtx210", "0xtx205", "0xtx205"],
        "the relation held at 240 admits the name"
    );
    assert_eq!(
        lost, held,
        "losing the relation at 241 changed what a read bound at 240 admits"
    );
    Ok(())
}

// A relation the address still holds, whose cited event moves above the bound without a change
// of holder. A token transfer from the holder to itself (a registrar `Transfer(A, A)`) is a valid
// upstream event that the adapters keep, and Project cites the latest registration event for the
// token holder and fallback controller rows, so the current row published at 241
// cites a block above the bound. The holder at the bound is unchanged: a read bound at 240 must
// admit the same rows, and a cursor issued at 240 continues after the self-transfer.
#[tokio::test]
async fn self_transfer_above_the_bound_keeps_the_held_token_holder() -> Result<()> {
    const NAME: &str = "self-transfer-holder.eth";
    let database = TestDatabase::new_migrated().await?;
    seed_bounded_membership_blocks(&database, 240).await?;
    let (logical_name_id, resource) = seed_bounded_name(&database, NAME, 0xb0a_6800)
    .await?;
    let mut grant = v2_history_event(
        "self-transfer-grant",
        Some(&logical_name_id),
        Some(resource),
        "RegistrationGranted",
        205,
    );
    grant.after_state["registrant"] = json!(BOUNDED_ADDRESS);
    let mut renewed = v2_history_event(
        "self-transfer-renewed",
        Some(&logical_name_id),
        Some(resource),
        "RegistrationRenewed",
        210,
    );
    renewed.log_index = Some(1);
    bigname_storage::insert_normalized_event_fixtures(&database.pool, &[grant, renewed]).await?;
    publish_test_families(&database, 240).await?;

    let route =
        format!("/v1/addresses/{BOUNDED_ADDRESS}/history?relation=owner&page_size=1&include=total_count");
    let first = v2_history_payload_for_database(&database, &route).await?;
    assert_eq!(bounded_route_hashes(&first), vec!["0xtx210"], "{first}");
    assert_eq!(first["page"]["total_count"], json!(2), "{first}");
    let cursor = first["page"]["next_cursor"]
        .as_str()
        .expect("second page")
        .to_owned();
    let held = bounded_address_history_hashes(
        &database,
        Some(bigname_storage::AddressNameRelation::TokenHolder),
        240,
    )
    .await?;
    assert_eq!(held, ["0xtx210", "0xtx205"]);

    // The holder transfers the token to itself at 241, and Project publishes 241 with the row
    // citing that transfer.
    let mut self_transfer = v2_history_event(
        "self-transfer-241",
        Some(&logical_name_id),
        Some(resource),
        "TokenControlTransferred",
        241,
    );
    self_transfer.before_state = json!({ "from": BOUNDED_ADDRESS });
    self_transfer.after_state = json!({ "source_event": "Transfer", "to": BOUNDED_ADDRESS });
    bigname_storage::insert_normalized_event_fixtures(&database.pool, &[self_transfer]).await?;
    publish_test_families(&database, 241).await?;

    let again = bounded_address_history_hashes(
        &database,
        Some(bigname_storage::AddressNameRelation::TokenHolder),
        240,
    )
    .await?;
    assert_eq!(
        again, held,
        "a self-transfer above the bound dropped the name the address held at 240"
    );
    // The route now reads the publication at 241, which lists the self-transfer first.
    let repeated = v2_history_payload_for_database(&database, &route).await?;
    assert_eq!(bounded_route_hashes(&repeated), vec!["0xtx241"], "{repeated}");
    assert_eq!(repeated["page"]["total_count"], json!(3), "{repeated}");
    let (status, continued) =
        bounded_route_status(&database, &format!("{route}&cursor={cursor}")).await?;
    assert_eq!(status, StatusCode::OK, "continuation: {continued}");
    assert_eq!(bounded_route_hashes(&continued), vec!["0xtx205"], "{continued}");
    database.cleanup().await
}

// The same for a relation that begins above the bound with a grant or an ENSv2 reservation of the
// token to the address, followed by a self-transfer that Project's publication at 241 cites: the
// grant or the reservation lies between the bound and the self-transfer, so the row stays out of
// a read at 240.
#[tokio::test]
async fn self_transfer_after_a_later_grant_or_reservation_admits_no_older_events() -> Result<()> {
    let database = TestDatabase::new_migrated().await?;
    seed_bounded_membership_blocks(&database, 240).await?;
    let mut expected_absent = Vec::new();
    for (name, seed, began) in [
        ("granted-then-self.eth", 0xb0a_6b00_u128, "RegistrationGranted"),
        ("reserved-then-self.eth", 0xb0a_6c00_u128, "RegistrationReserved"),
    ] {
        let (logical_name_id, resource) = seed_bounded_name(&database, name, seed)
        .await?;
        // Older history on the resource that names no relation of the address.
        let mut older = v2_history_event(
            &format!("{name}-older"),
            Some(&logical_name_id),
            Some(resource),
            "RegistrationRenewed",
            205,
        );
        older.transaction_hash = Some(format!("0x{name}-205"));
        let mut begun = v2_history_event(
            &format!("{name}-began"),
            Some(&logical_name_id),
            Some(resource),
            began,
            241,
        );
        if began == "RegistrationGranted" {
            begun.after_state["registrant"] = json!(BOUNDED_ADDRESS);
        } else {
            begun.derivation_kind = "ens_v2_registry_resource_surface".to_owned();
            begun.after_state = json!({ "status": "reserved", "expiry": 1_900_000_000_i64 });
        }
        let mut self_transfer = v2_history_event(
            &format!("{name}-self"),
            Some(&logical_name_id),
            Some(resource),
            "TokenControlTransferred",
            241,
        );
        self_transfer.log_index = Some(1);
        self_transfer.before_state = json!({ "from": BOUNDED_ADDRESS });
        self_transfer.after_state = json!({ "source_event": "Transfer", "to": BOUNDED_ADDRESS });
        bigname_storage::insert_normalized_event_fixtures(
            &database.pool,
            &[older, begun, self_transfer],
        )
        .await?;
        expected_absent.push(format!("0x{name}-205"));
    }
    publish_test_families(&database, 241).await?;
    let hashes = bounded_address_history_hashes(
        &database,
        Some(bigname_storage::AddressNameRelation::TokenHolder),
        240,
    )
    .await?;
    assert!(
        !hashes.iter().any(|hash| expected_absent.contains(hash)),
        "a relation begun above the bound admitted older events: {hashes:?}"
    );
    database.cleanup().await
}

// The negative side of the rule above: a token-holder row published at 241 and cited above the
// bound stays out of a read bound at 240 when the address acquired the token after the bound, even
// when the cited event is a self-transfer, because a transfer to the address lies between the
// bound and it.
#[tokio::test]
async fn self_transfer_after_a_later_acquisition_admits_no_older_events() -> Result<()> {
    let database = TestDatabase::new_migrated().await?;
    seed_bounded_membership_blocks(&database, 240).await?;
    let mut expected_absent = Vec::new();
    for (name, seed, acquired_by) in [
        ("acquired-then-self.eth", 0xb0a_6900_u128, "transfer"),
        ("acquired-by-transfer.eth", 0xb0a_6a00_u128, "cited"),
    ] {
        let (logical_name_id, resource) = seed_bounded_name(&database, name, seed)
        .await?;
        // The name's history at the bound names another holder.
        let mut grant = v2_history_event(
            &format!("{name}-grant"),
            Some(&logical_name_id),
            Some(resource),
            "RegistrationGranted",
            205,
        );
        grant.after_state["registrant"] = json!(LOST_OTHER);
        grant.transaction_hash = Some(format!("0x{name}-205"));
        let mut acquired = v2_history_event(
            &format!("{name}-acquired"),
            Some(&logical_name_id),
            Some(resource),
            "TokenControlTransferred",
            241,
        );
        acquired.before_state = json!({ "from": LOST_OTHER });
        acquired.after_state = json!({ "source_event": "Transfer", "to": BOUNDED_ADDRESS });
        let mut events = vec![grant, acquired];
        if acquired_by == "transfer" {
            let mut self_transfer = v2_history_event(
                &format!("{name}-self"),
                Some(&logical_name_id),
                Some(resource),
                "TokenControlTransferred",
                241,
            );
            self_transfer.log_index = Some(1);
            self_transfer.before_state = json!({ "from": BOUNDED_ADDRESS });
            self_transfer.after_state =
                json!({ "source_event": "Transfer", "to": BOUNDED_ADDRESS });
            events.push(self_transfer);
        }
        bigname_storage::insert_normalized_event_fixtures(&database.pool, &events).await?;
        expected_absent.push(format!("0x{name}-205"));
    }
    publish_test_families(&database, 241).await?;
    let hashes = bounded_address_history_hashes(
        &database,
        Some(bigname_storage::AddressNameRelation::TokenHolder),
        240,
    )
    .await?;
    assert!(
        !hashes.iter().any(|hash| expected_absent.contains(hash)),
        "a holder acquired above the bound admitted older events: {hashes:?}"
    );
    database.cleanup().await
}
