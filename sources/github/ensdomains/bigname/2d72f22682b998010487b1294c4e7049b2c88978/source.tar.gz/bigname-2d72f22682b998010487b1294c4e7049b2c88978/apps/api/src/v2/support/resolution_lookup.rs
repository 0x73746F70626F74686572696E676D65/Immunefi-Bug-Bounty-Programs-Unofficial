use super::*;

pub(crate) enum ResolutionLookupError {
    Concurrent(SnapshotSelectionError),
    Snapshot(SnapshotSelectionError),
}

impl ResolutionLookupError {
    pub(crate) fn into_snapshot(self) -> SnapshotSelectionError {
        match self {
            Self::Concurrent(error) | Self::Snapshot(error) => error,
        }
    }
}

impl From<SnapshotSelectionError> for ResolutionLookupError {
    fn from(error: SnapshotSelectionError) -> Self {
        Self::Snapshot(error)
    }
}

/// What a fresh lookup produced when it did not fail: an executed response, or one of the
/// engine's in-band refusals the route reports under its own public reason.
pub(crate) enum ResolutionLookupOutcome {
    Executed(Box<bigname_lookup::LookupResponse>),
    /// The engine declared the name outside its supported classes.
    NotSupported,
    /// The name's selected authority arm is outside the arms the selected execution manifest
    /// declares (`docs/manifests.md` § `verified_authority_arms`); nothing was dispatched.
    AuthorityArmNotAdmitted,
}

/// Executes a fresh read-only schema-v2 lookup and revalidates the captured
/// execution state after provider calls.
pub(crate) async fn execute_resolution_lookup(
    state: &AppState,
    row: &NameCurrentRow,
    records: &[ResolutionRecordKey],
    selected_snapshot: &mut SelectedSnapshot,
) -> std::result::Result<ResolutionLookupOutcome, ResolutionLookupError> {
    if records.is_empty() {
        return Ok(ResolutionLookupOutcome::NotSupported);
    }

    let logical_name_id = schema_v2_logical_name_id(row)?;
    let request = bigname_lookup::LookupRequest::new(
        logical_name_id,
        records.iter().map(|record| record.record_key.as_str()),
    )
    .map_err(lookup_snapshot_error)?;
    let timer = crate::metrics::verified_execution_timer();
    let admitted_positions = selected_snapshot
        .chain_positions
        .as_map()
        .values()
        .map(|position| bigname_lookup::LookupPosition {
            chain_id: position.chain_id.clone(),
            block_number: position.block_number,
            block_hash: position.block_hash.clone(),
            timestamp: bigname_storage::UnixSeconds::from(position.timestamp).internal_string(),
        })
        .collect::<Vec<_>>();
    let response = bigname_lookup::LookupEngine::read_only(
        state.pool.clone(),
        state.lookup_chain_rpc_urls.clone(),
    )
    .with_publication_lag_tolerance_blocks(crate::state::publication_lag_tolerance_blocks())
    .lookup_at_positions(request, &admitted_positions)
    .await;
    match response {
        Ok(response) => {
            expose_lookup_positions(selected_snapshot, &response)?;
            let outcome = if response
                .records
                .iter()
                .all(|record| record.status == bigname_lookup::LookupRecordStatus::Success)
            {
                "success"
            } else {
                "partial"
            };
            timer.finish(outcome);
            Ok(ResolutionLookupOutcome::Executed(Box::new(response)))
        }
        Err(error) if error.kind() == bigname_lookup::ErrorKind::Unsupported => {
            timer.finish("unsupported");
            Ok(match error.refusal() {
                Some(bigname_lookup::LookupRefusal::AuthorityArmNotAdmitted) => {
                    ResolutionLookupOutcome::AuthorityArmNotAdmitted
                }
                _ => ResolutionLookupOutcome::NotSupported,
            })
        }
        Err(error) => {
            timer.finish("failed");
            Err(lookup_snapshot_error(error))
        }
    }
}

fn expose_lookup_positions(
    selected_snapshot: &mut SelectedSnapshot,
    response: &bigname_lookup::LookupResponse,
) -> std::result::Result<(), SnapshotSelectionError> {
    let mut positions = selected_snapshot.chain_positions.as_map().clone();
    for lookup_position in [
        &response.authoritative_position,
        &response.execution_position,
    ] {
        let Some(slot) = positions.iter().find_map(|(slot, position)| {
            (position.chain_id == lookup_position.chain_id).then(|| slot.clone())
        }) else {
            return Err(SnapshotSelectionError::stale(
                "verified lookup returned a position outside the selected chain scope",
            ));
        };
        let timestamp =
            parse_rfc3339_utc_timestamp(&lookup_position.timestamp).map_err(|error| {
                error!(
                    service = "api",
                    timestamp = %lookup_position.timestamp,
                    error = ?error,
                    "schema-v2 verified lookup returned an invalid timestamp"
                );
                SnapshotSelectionError::internal(
                    "verified lookup returned an invalid execution position",
                )
            })?;
        positions.insert(
            slot.clone(),
            ChainPosition {
                slot,
                chain_id: lookup_position.chain_id.clone(),
                block_number: lookup_position.block_number,
                block_hash: lookup_position.block_hash.clone(),
                timestamp,
            },
        );
    }
    selected_snapshot.chain_positions = ChainPositions::new(positions);
    Ok(())
}

fn schema_v2_logical_name_id(
    row: &NameCurrentRow,
) -> std::result::Result<String, SnapshotSelectionError> {
    let namehash = row.namehash.to_ascii_lowercase();
    let valid = namehash.strip_prefix("0x").is_some_and(|digits| {
        digits.len() == 64 && digits.bytes().all(|byte| byte.is_ascii_hexdigit())
    });
    if !valid {
        return Err(SnapshotSelectionError::stale(
            "verified lookup name identity is unavailable",
        ));
    }
    Ok(format!("{}:{namehash}", row.namespace))
}

pub(crate) fn lookup_snapshot_error(error: bigname_lookup::LookupError) -> ResolutionLookupError {
    match error.kind() {
        bigname_lookup::ErrorKind::ConcurrentState => ResolutionLookupError::Concurrent(
            SnapshotSelectionError::stale(error.message().to_owned()),
        ),
        bigname_lookup::ErrorKind::Configuration | bigname_lookup::ErrorKind::Stale => {
            ResolutionLookupError::Snapshot(SnapshotSelectionError::stale(
                error.message().to_owned(),
            ))
        }
        bigname_lookup::ErrorKind::Unsupported => ResolutionLookupError::Snapshot(
            SnapshotSelectionError::stale("verified lookup is not supported for this name"),
        ),
        bigname_lookup::ErrorKind::Transport
        | bigname_lookup::ErrorKind::Execution
        | bigname_lookup::ErrorKind::Database => ResolutionLookupError::Snapshot(
            SnapshotSelectionError::internal(error.message().to_owned()),
        ),
    }
}
