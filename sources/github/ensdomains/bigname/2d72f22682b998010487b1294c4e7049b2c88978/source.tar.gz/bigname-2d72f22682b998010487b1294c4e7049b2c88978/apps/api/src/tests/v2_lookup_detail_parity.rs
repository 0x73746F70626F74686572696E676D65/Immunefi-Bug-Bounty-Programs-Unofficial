// TYR-85: batch lookup classifies a name as name detail does.

/// The name-level fields a `profile=detail` lookup record and `GET /v1/names/{name}` share.
const SHARED_DETAIL_FIELDS: &[&str] = &[
    "status",
    "unsupported_reason",
    "failure_reason",
    "unsupported_fields",
    "registration_status",
    "registration_id",
    "token_id",
    "owner",
    "manager",
    "registrant",
    "registered_at",
    "created_at",
    "expires_at",
    "lapsed_registration",
    "authority",
    "migrated_at",
    "resolver",
    "subregistry",
    "records",
    "primary_address",
    "primary_name",
    "chain_id",
    "network",
];

async fn assert_lookup_detail_matches_name_detail(
    database: &TestDatabase,
    name: &str,
) -> Result<Value> {
    let detail = v2_name_record_payload_for_database(database, &format!("/v1/names/{name}")).await?;
    let batch = v2_lookup_json(
        database,
        json!({"profile": "detail", "inputs": [{"name": name}]}),
    )
    .await?;
    let result = &batch["data"][0];
    let record = &result["record"];
    for field in SHARED_DETAIL_FIELDS {
        assert_eq!(
            record.get(*field),
            detail["data"].get(*field),
            "{name}: `{field}` differs\nlookup: {record}\ndetail: {}",
            detail["data"]
        );
    }
    assert_eq!(result["status"], record["status"], "{name}: {result}");
    assert_eq!(
        batch["meta"]["as_of"], detail["meta"]["as_of"],
        "{name}: both routes read one snapshot"
    );
    Ok(detail["data"].clone())
}

#[tokio::test]
async fn lookup_detail_status_matches_name_detail_for_a_registered_name() -> Result<()> {
    let database = TestDatabase::new_migrated().await?;
    seed_v2_lookup_reverse_fixture(&database, "0x0000000000000000000000000000000000000abc").await?;
    let detail = assert_lookup_detail_matches_name_detail(&database, "bob.eth").await?;
    assert_eq!(detail["status"], json!("ok"));
    database.cleanup().await
}

#[tokio::test]
async fn lookup_detail_status_matches_name_detail_without_projected_authority() -> Result<()> {
    let database = TestDatabase::new_migrated().await?;
    // alice.eth keeps retained registration inputs, but no binding is observed for its surface,
    // so the row is `current_authority_not_projected`: the $2442.eth shape.
    seed_alice_state_inputs(&database, AliceInputState::Unbound).await?;
    let detail = assert_lookup_detail_matches_name_detail(&database, "alice.eth").await?;
    assert_eq!(detail["status"], json!("ok"), "{detail}");
    assert!(detail.get("unsupported_reason").is_none(), "{detail}");
    assert_eq!(detail["registration_status"], json!("unregistered"));
    assert!(detail.get("owner").is_none(), "{detail}");
    assert!(detail.get("authority").is_none(), "{detail}");
    assert!(detail.get("resolver").is_none(), "{detail}");

    let feed = v2_lookup_json(
        &database,
        json!({"profile": "feed", "inputs": [{"name": "alice.eth"}]}),
    )
    .await?;
    assert_eq!(feed["data"][0]["status"], json!("ok"), "{feed}");
    assert!(feed["data"][0]["record"].get("unsupported_reason").is_none());
    database.cleanup().await
}

#[tokio::test]
async fn lookup_detail_status_matches_name_detail_for_a_root_registry_pointer() -> Result<()> {
    let database = TestDatabase::new_migrated().await?;
    seed_unbound_name_inputs(&database, "eth", true).await?;
    let detail = assert_lookup_detail_matches_name_detail(&database, "eth").await?;
    assert_eq!(detail["status"], json!("ok"), "{detail}");
    assert_eq!(detail["registration_status"], json!("unregistered"));
    assert!(detail["resolver"].is_object(), "{detail}");
    database.cleanup().await
}

#[tokio::test]
async fn lookup_detail_status_matches_name_detail_for_released_and_reserved_names() -> Result<()> {
    for (state, registration_status) in [
        (AliceInputState::Released, "released"),
        (AliceInputState::Reserved, "unregistered"),
    ] {
        let database = TestDatabase::new_migrated().await?;
        seed_alice_state_inputs(&database, state).await?;
        let detail = assert_lookup_detail_matches_name_detail(&database, "alice.eth").await?;
        assert_eq!(detail["status"], json!("ok"), "{detail}");
        assert_eq!(detail["registration_status"], json!(registration_status));
        database.cleanup().await?;
    }
    Ok(())
}

#[tokio::test]
async fn lookup_detail_status_matches_name_detail_with_a_historical_arm_and_no_binding() -> Result<()> {
    let database = TestDatabase::new_migrated().await?;
    // No binding is observed for alice.eth, but a named ENSv1 registration event votes the arm.
    // The row stays `current_authority_not_projected` and unregistered, and `authority` follows
    // the voted arm on both routes: no selected binding does not by itself omit `authority`.
    seed_alice_state_inputs(&database, AliceInputState::Unbound).await?;
    append_alice_name_input(
        &database,
        "RegistrationGranted",
        "ens_v1_registrar_l1",
        json!({"authority_kind": "registrar",
            "registrant": "0x00000000000000000000000000000000000000aa",
            "expiry": 4_000_000_000_u64}),
    )
    .await?;
    rebuild_fixture_families(&database.pool, "ethereum-mainnet", 21_000_003, "0xbinding").await?;
    let detail = assert_lookup_detail_matches_name_detail(&database, "alice.eth").await?;
    assert_eq!(detail["status"], json!("ok"), "{detail}");
    assert_eq!(detail["registration_status"], json!("unregistered"), "{detail}");
    assert!(detail.get("registration_id").is_none(), "{detail}");
    assert!(detail.get("resolver").is_none(), "{detail}");
    assert_eq!(detail["authority"], json!("ens_v1"), "{detail}");
    database.cleanup().await
}

#[tokio::test]
async fn lookup_detail_status_matches_name_detail_for_wrapped_and_ownerless_names() -> Result<()> {
    for state in [AliceInputState::Wrapped, AliceInputState::Ownerless] {
        let database = TestDatabase::new_migrated().await?;
        seed_alice_state_inputs(&database, state).await?;
        let detail = assert_lookup_detail_matches_name_detail(&database, "alice.eth").await?;
        assert_eq!(detail["status"], json!("ok"), "{detail}");
        database.cleanup().await?;
    }
    Ok(())
}

/// Lookup serves name detail's grouped `records`, and omits it where name detail does.
#[tokio::test]
async fn lookup_detail_records_match_name_detail() -> Result<()> {
    for (name, served) in [("eth", true), ("alice.eth", false)] {
        let database = TestDatabase::new_migrated().await?;
        if served {
            seed_unbound_name_inputs(&database, name, true).await?;
        } else {
            seed_alice_state_inputs(&database, AliceInputState::Unbound).await?;
        }
        let detail = assert_lookup_detail_matches_name_detail(&database, name).await?;
        assert_eq!(detail.get("records").is_some(), served, "{name}: {detail}");
        database.cleanup().await?;
    }
    Ok(())
}

/// A resolver whose implementation is not an admitted profile: the keys it was seen writing are
/// listed on both routes, with no value, singletons included.
#[tokio::test]
async fn lookup_detail_records_list_an_unknown_resolvers_keys_without_values() -> Result<()> {
    let database = TestDatabase::new_migrated().await?;
    let mut writes = unknown_resolver_record_writes();
    writes.push(family_fixture_record_write("contenthash", Some(json!("0xe3010170"))));
    seed_unknown_resolver_inputs(&database, &writes).await?;
    let detail = assert_lookup_detail_matches_name_detail(&database, "alice.eth").await?;
    let records = &detail["records"];
    assert_eq!(records["seen_addresses"], json!(["60"]), "{detail}");
    assert_eq!(records["addresses"], json!({}), "{detail}");
    assert_eq!(records["seen_texts"], json!(["description"]), "{detail}");
    assert_eq!(records["texts"], json!({}), "{detail}");
    // Written, value unknown.
    assert_eq!(records["seen_singletons"], json!(["contenthash"]), "{detail}");
    assert!(records.get("contenthash").is_none(), "{detail}");
    assert!(records.get("name").is_none(), "{detail}");
    database.cleanup().await
}

const GROUPED_RESOLVER: &str = "0x0000000000000000000000000000000000000abc";

async fn seed_grouped_records_name(database: &TestDatabase, name: &str, id: u128) -> Result<()> {
    seed_identity_name(
        database,
        &format!("ens:{name}"),
        name,
        name,
        &format!("namehash:{name}"),
        Uuid::from_u128(id),
        Uuid::from_u128(id + 1),
        Uuid::from_u128(id + 2),
        GROUPED_RESOLVER,
        bigname_storage::AddressNameRelation::TokenHolder,
        38,
    )
    .await
}

/// A cleared value is a listed key mapped to `null` (a cleared singleton is `null`) on both routes.
#[tokio::test]
async fn lookup_detail_records_serve_cleared_values_as_null() -> Result<()> {
    let database = TestDatabase::new_migrated().await?;
    let name = "cleared.eth";
    seed_grouped_records_name(&database, name, 0x5a0c10).await?;
    insert_family_fixture_record_writes(
        &database.pool,
        "ens",
        "ethereum-mainnet",
        name,
        GROUPED_RESOLVER,
        38,
        "0xname26",
        &[
            family_fixture_record_write("text:url", Some(json!("https://cleared.example"))),
            family_fixture_record_write("text:email", Some(json!("kept@example.test"))),
            json!({"source_event":"ContenthashChanged", "record_key":"contenthash",
                "record_family":"contenthash", "selector_key":null,
                "contenthash_hex":"0xe3010170"}),
            family_fixture_record_write("text:url", Some(json!(""))),
            json!({"source_event":"ContenthashChanged", "record_key":"contenthash",
                "record_family":"contenthash", "selector_key":null, "contenthash_hex":"0x"}),
        ],
    )
    .await?;
    rebuild_fixture_families(&database.pool, "ethereum-mainnet", 38, "0xname26").await?;
    let detail = assert_lookup_detail_matches_name_detail(&database, name).await?;
    let records = &detail["records"];
    // `seed_identity_name` also writes the fixture's own text records.
    let text_keys = records["seen_texts"].as_array().expect("text keys");
    assert!(text_keys.contains(&json!("url")) && text_keys.contains(&json!("email")), "{detail}");
    assert_eq!(records["texts"]["email"], json!("kept@example.test"), "{detail}");
    assert_eq!(records["texts"].get("url"), Some(&Value::Null), "{detail}");
    assert_eq!(records["seen_singletons"], json!(["contenthash"]), "{detail}");
    assert_eq!(records.get("contenthash"), Some(&Value::Null), "{detail}");
    database.cleanup().await
}

/// The forward `name` record on the name's own node: a write, a clear, a rewrite and a
/// record-version reset, served alike on both routes. It is not the primary name.
#[tokio::test]
async fn lookup_detail_records_follow_the_forward_name_record() -> Result<()> {
    const CHAIN: &str = "ethereum-mainnet";
    const FAMILY: &str = "ens_v1_resolver_l1";
    let database = TestDatabase::new_migrated().await?;
    let name = "forward.eth";
    seed_grouped_records_name(&database, name, 0x5a0c20).await?;
    let manifest =
        declare_family_fixture_resolver(&database.pool, "ens", CHAIN, FAMILY, GROUPED_RESOLVER)
            .await?;
    let node = bigname_lookup::ens_namehash_hex(name)?;
    let publish = |kind: &'static str, after: Value| {
        let database = &database;
        async move {
            publish_node_record_event(
                database,
                CHAIN,
                "ens",
                kind,
                FAMILY,
                Some(manifest),
                GROUPED_RESOLVER,
                (None, None),
                after,
            )
            .await
        }
    };
    let name_changed = |value: &str| {
        json!({"source_event":"NameChanged", "resolver":GROUPED_RESOLVER, "node":node,
            "record_key":"name", "record_family":"name", "selector_key":null,
            "value_retained":false, "raw_name":value})
    };
    let forward_name = |detail: &Value| detail["records"].get("name").cloned();
    let name_seen = |detail: &Value| {
        detail["records"]["seen_singletons"]
            .as_array()
            .expect("seen singletons")
            .contains(&json!("name"))
    };

    // Never written, on an authoritative inventory: not seen, unset.
    let detail = assert_lookup_detail_matches_name_detail(&database, name).await?;
    assert_eq!(forward_name(&detail), Some(Value::Null), "{detail}");
    assert!(!name_seen(&detail), "{detail}");

    publish("RecordChanged", name_changed("forward-target.eth")).await?;
    let detail = assert_lookup_detail_matches_name_detail(&database, name).await?;
    assert_eq!(forward_name(&detail), Some(json!("forward-target.eth")), "{detail}");
    assert!(name_seen(&detail), "{detail}");
    assert!(detail.get("primary_name").is_none(), "{detail}");

    // `setName("")` clears it: seen, `null`.
    publish("RecordChanged", name_changed("")).await?;
    let detail = assert_lookup_detail_matches_name_detail(&database, name).await?;
    assert_eq!(forward_name(&detail), Some(Value::Null), "{detail}");
    assert!(name_seen(&detail), "{detail}");

    // A rewrite counts again, and a record-version reset drops it.
    publish("RecordChanged", name_changed("rewritten.eth")).await?;
    let detail = assert_lookup_detail_matches_name_detail(&database, name).await?;
    assert_eq!(forward_name(&detail), Some(json!("rewritten.eth")), "{detail}");
    publish("RecordVersionChanged", version_after(&node, GROUPED_RESOLVER, 1)).await?;
    let detail = assert_lookup_detail_matches_name_detail(&database, name).await?;
    assert_eq!(forward_name(&detail), Some(Value::Null), "{detail}");
    assert!(!name_seen(&detail), "{detail}");
    database.cleanup().await
}

/// Declare `GROUPED_RESOLVER` under `role` before the name fixture points at it, then drop the
/// fixture's own record writes with a record-version reset, so no singleton is written.
async fn seed_grouped_records_name_on(
    database: &TestDatabase,
    name: &str,
    id: u128,
    role: &str,
) -> Result<()> {
    let (manifest, _) = declare_family_fixture_contract(
        &database.pool,
        "ens",
        "ethereum-mainnet",
        "ens_v1_resolver_l1",
        role,
        GROUPED_RESOLVER,
    )
    .await?;
    seed_grouped_records_name(database, name, id).await?;
    let node = bigname_lookup::ens_namehash_hex(name)?;
    publish_node_record_event(
        database,
        "ethereum-mainnet",
        "ens",
        "RecordVersionChanged",
        "ens_v1_resolver_l1",
        Some(manifest),
        GROUPED_RESOLVER,
        (None, None),
        version_after(&node, GROUPED_RESOLVER, 1),
    )
    .await
}

/// A legacy public resolver generation without `IContentHashResolver` never has a contenthash to
/// report unset, so an unwritten one is unknown; a current resolver's unwritten singletons are
/// unset. Name is held by every one of them.
#[tokio::test]
async fn lookup_detail_records_default_singletons_only_where_the_resolver_holds_them() -> Result<()> {
    for (role, contenthash_unset) in [
        ("public_resolver_5ffc0143", false),
        ("public_resolver_1da02271", false),
        ("public_resolver", true),
    ] {
        let database = TestDatabase::new_migrated().await?;
        seed_grouped_records_name_on(&database, "profile.eth", 0x5a0c30, role).await?;
        let detail = assert_lookup_detail_matches_name_detail(&database, "profile.eth").await?;
        let records = &detail["records"];
        assert_eq!(records["seen_singletons"], json!([]), "{role}: {detail}");
        assert_eq!(
            records.get("contenthash"),
            contenthash_unset.then_some(&Value::Null),
            "{role}: {detail}"
        );
        assert_eq!(records.get("name"), Some(&Value::Null), "{role}: {detail}");
        // The records route agrees: no `not_found` for a family the resolver cannot hold.
        let route = v2_name_record_payload_for_database(
            &database,
            "/v1/names/profile.eth/records?keys=contenthash&include=inventory",
        )
        .await?;
        let answer = &route["data"]["records"]["contenthash"];
        if contenthash_unset {
            assert_eq!(answer, &json!({"status": "not_found"}), "{role}: {route}");
        } else {
            assert_eq!(
                answer,
                &json!({"status": "unsupported",
                    "unsupported_reason": "record_family_not_supported_by_resolver"}),
                "{role}: {route}"
            );
            assert_eq!(
                route["data"]["inventory"]["unsupported_keys"],
                json!(["contenthash"]),
                "{role}: {route}"
            );
        }
        database.cleanup().await?;
    }
    Ok(())
}

/// Retained text keys outside the `keys=` request grammar (whitespace, commas) are listed and
/// served on an authoritative inventory, a clear included, and listed without values on an
/// unknown resolver.
#[tokio::test]
async fn lookup_detail_records_keep_text_keys_with_spaces_and_commas() -> Result<()> {
    let writes = [
        family_fixture_record_write("text:display name", Some(json!("Alice"))),
        family_fixture_record_write("text:a,b", Some(json!("first"))),
        family_fixture_record_write("text:a,b", Some(json!(""))),
    ];

    let database = TestDatabase::new_migrated().await?;
    let name = "spaced.eth";
    seed_grouped_records_name(&database, name, 0x5a0c40).await?;
    insert_family_fixture_record_writes(
        &database.pool,
        "ens",
        "ethereum-mainnet",
        name,
        GROUPED_RESOLVER,
        38,
        "0xname26",
        &writes,
    )
    .await?;
    rebuild_fixture_families(&database.pool, "ethereum-mainnet", 38, "0xname26").await?;
    let detail = assert_lookup_detail_matches_name_detail(&database, name).await?;
    let records = &detail["records"];
    let seen = records["seen_texts"].as_array().expect("seen texts");
    assert!(
        seen.contains(&json!("display name")) && seen.contains(&json!("a,b")),
        "{detail}"
    );
    assert_eq!(records["texts"]["display name"], json!("Alice"), "{detail}");
    assert_eq!(records["texts"].get("a,b"), Some(&Value::Null), "{detail}");
    database.cleanup().await?;

    let database = TestDatabase::new_migrated().await?;
    seed_unknown_resolver_inputs(&database, &writes).await?;
    let detail = assert_lookup_detail_matches_name_detail(&database, "alice.eth").await?;
    let records = &detail["records"];
    assert_eq!(records["seen_texts"], json!(["a,b", "display name"]), "{detail}");
    assert_eq!(records["texts"], json!({}), "{detail}");
    database.cleanup().await
}

// TYR-192: a feed record carries the expiry fields and `ens_v1` of the detail record, and no
// other registration field.
const FEED_EXPIRY_FIELDS: &[&str] = &["expires_at", "expires_at_reason", "grace_ends_at", "ens_v1"];

const DETAIL_ONLY_FIELDS: &[&str] = &[
    "registration_id",
    "token_id",
    "owner",
    "manager",
    "registered_at",
    "created_at",
    "registration_status",
    "lapsed_registration",
    "resolver",
    "unresolvable_reason",
    "records",
    "primary_address",
    "primary_name",
    "authority",
    "migrated_at",
];

fn assert_feed_expiry_fields(feed: &Value, detail: &Value, context: &str) {
    for field in FEED_EXPIRY_FIELDS {
        assert_eq!(
            feed.get(*field),
            detail.get(*field),
            "{context}: `{field}` differs\nfeed: {feed}\ndetail: {detail}"
        );
    }
    for field in DETAIL_ONLY_FIELDS {
        assert!(feed.get(*field).is_none(), "{context}: feed carries `{field}`: {feed}");
    }
}

async fn assert_feed_expiry_matches_detail(database: &TestDatabase, name: &str) -> Result<Value> {
    let detail = v2_name_record_payload_for_database(database, &format!("/v1/names/{name}")).await?;
    let lookup = |profile: &str| {
        v2_lookup_json(database, json!({"profile": profile, "inputs": [{"name": name}]}))
    };
    let feed = lookup("feed").await?["data"][0]["record"].clone();
    let lookup_detail = lookup("detail").await?["data"][0]["record"].clone();
    assert_feed_expiry_fields(&feed, &lookup_detail, &format!("{name} lookup detail"));
    assert_feed_expiry_fields(&feed, &detail["data"], &format!("{name} name detail"));
    Ok(feed)
}

#[tokio::test]
async fn lookup_feed_serves_the_detail_expiry_of_a_live_a_grace_and_a_released_lease() -> Result<()> {
    const HOLDER: &str = "0x0000000000000000000000000000000000000abc";
    let database = TestDatabase::new_migrated().await?;
    let released = seed_names_registration(
        &database, "ens", "lapsed-feed.eth", 91, "2023-02-02T00:00:00Z", 1_700_000_000, HOLDER,
        HOLDER,
    )
    .await?;
    seed_names_registration(
        &database, "ens", "live-feed.eth", 92, "2024-02-02T00:00:00Z", 1_900_000_000, HOLDER,
        HOLDER,
    )
    .await?;
    // The published head is 2026-06-10 (1781049600): this lease expired twelve days before it
    // and is in its registrar grace period.
    seed_names_registration(
        &database, "ens", "grace-feed.eth", 93, "2024-02-05T00:00:00Z", 1_780_000_000, HOLDER,
        HOLDER,
    )
    .await?;
    upsert_phase_raw_blocks(
        &database.pool,
        &[raw_block("ethereum-mainnet", "0xfeed-released", None, 94, 1_707_776_000)],
    )
    .await?;
    sqlx::query("UPDATE surface_bindings SET active_to=to_timestamp(1707776000) WHERE resource_id=$1")
        .bind(released)
        .execute(&database.pool)
        .await?;
    let mut release = history_event(
        "feed-lapsed-release",
        Some(&bigname_storage::logical_name_id_for_name("ens", "lapsed-feed.eth")),
        Some(released),
        Some("ethereum-mainnet"),
        Some(94),
        Some("0xfeed-released"),
        Some("0xrelease"),
        Some(0),
        CanonicalityState::Canonical,
    );
    release.event_kind = "RegistrationReleased".into();
    release.source_family = "ens_v1_registrar_l1".into();
    release.before_state = json!({"registrant":HOLDER,"authority_kind":"registrar","authority_key":"registrar:lapsed"});
    release.after_state = json!({"expiry":1700000000,"released_at":1707776000});
    bigname_storage::insert_normalized_event_fixtures(&database.pool, &[release]).await?;
    publish_v2_names_fixture(&database).await?;

    for (name, expires_at, grace_ends_at) in [
        ("live-feed.eth", "1900000000", "1907776000"),
        ("grace-feed.eth", "1780000000", "1787776000"),
        ("lapsed-feed.eth", "1700000000", "1707776000"),
    ] {
        let feed = assert_feed_expiry_matches_detail(&database, name).await?;
        assert_eq!(feed["expires_at"], json!(expires_at), "{name}: {feed}");
        assert_eq!(feed["grace_ends_at"], json!(grace_ends_at), "{name}: {feed}");
        assert_eq!(feed["ens_v1"], json!({"expires_at": expires_at}), "{name}: {feed}");
        assert!(feed.get("expires_at_reason").is_none(), "{name}: {feed}");
    }
    database.cleanup().await
}

#[tokio::test]
async fn lookup_feed_serves_the_detail_expiry_of_an_ens_v2_registration() -> Result<()> {
    let database = TestDatabase::new_migrated().await?;
    seed_alice_state_inputs(&database, AliceInputState::Registry).await?;
    let feed = assert_feed_expiry_matches_detail(&database, "alice.eth").await?;
    assert_eq!(feed["expires_at"], json!("4000000000"), "{feed}");
    assert!(feed.get("ens_v1").is_none(), "{feed}");
    database.cleanup().await
}

#[tokio::test]
async fn lookup_reverse_feed_rows_serve_the_detail_expiry() -> Result<()> {
    let database = TestDatabase::new_migrated().await?;
    let address = "0x0000000000000000000000000000000000000abc";
    seed_v2_lookup_reverse_fixture(&database, address).await?;
    let rows = |profile: &str| {
        v2_lookup_json(
            &database,
            json!({"profile": profile, "inputs": [{"address": address, "relation": "any"}]}),
        )
    };
    let feed = rows("feed").await?["data"][0]["records"].clone();
    let detail = rows("detail").await?["data"][0]["records"].clone();
    let (feed, detail) = (feed.as_array().unwrap(), detail.as_array().unwrap());
    assert!(!feed.is_empty(), "{feed:?}");
    assert_eq!(feed.len(), detail.len());
    for (feed, detail) in feed.iter().zip(detail) {
        assert_feed_expiry_fields(feed, detail, "reverse");
        assert_eq!(feed["is_primary"], detail["is_primary"], "{feed}");
        assert_eq!(feed["relations"], detail["relations"], "{feed}");
        assert!(feed["expires_at"].is_string(), "{feed}");
    }
    database.cleanup().await
}
