use std::{future::Future, pin::Pin, sync::Arc};

use crate::{
    config::ChainConfig,
    error::{RunnerError, RunnerResult},
    heads::publish_heads,
    ingest_progress,
    metrics::{RunnerLoopHeartbeat, RunnerMetricsFeed},
    phase::{
        AfterProgress, Phase, PhaseBatchOutcome, PhaseContext, PhaseName, PhaseProgress,
        RedoAttemptFence, RunMode, VerificationLevel,
    },
    phase_lock::PhaseLock,
    progress_monitor::{ProgressToken, RunnerPhaseProgress},
    runner_support::HeartbeatThrottle,
    shutdown::until_cancelled,
    state_persistence::validate_progress,
};
use tokio_util::sync::CancellationToken;

use super::PhaseRunner;

pub(super) struct Execution {
    pub(super) mode: RunMode,
    pub(super) redo_attempt: Option<RedoAttemptFence>,
}

impl Execution {
    pub(super) const fn new(mode: RunMode, redo_attempt: Option<RedoAttemptFence>) -> Self {
        Self { mode, redo_attempt }
    }
}

pub(super) type BeforeRedoProgressWrite =
    Arc<dyn Fn() -> Pin<Box<dyn Future<Output = ()> + Send>> + Send + Sync>;

impl PhaseRunner {
    pub fn with_loop_heartbeat(mut self, heartbeat: RunnerLoopHeartbeat) -> Self {
        self.loop_heartbeat = Some(heartbeat);
        self
    }

    /// How long required work -- start-up recovery, a finished batch's settlement --
    /// may run past an accepted stop before the run gives it up. Ten seconds
    /// unless a test shortens it.
    pub fn with_stop_deadline(mut self, deadline: std::time::Duration) -> Self {
        self.stop_budget = deadline;
        self.chain_stop_clocks
            .lock()
            .expect("stop clocks lock")
            .clear();
        self
    }

    /// The stop budget for a chain's own waits -- start-up recovery, fence
    /// releases, mismatch records, recovery lookups -- as opposed to a phase
    /// attempt's, which each attempt starts for itself at its batch boundary.
    pub(super) fn chain_stop_clock(&self, chain_id: &str) -> Arc<crate::runner_support::StopClock> {
        Arc::clone(
            self.chain_stop_clocks
                .lock()
                .expect("stop clocks lock")
                .entry(chain_id.to_owned())
                .or_insert_with(|| {
                    Arc::new(crate::runner_support::StopClock::new(self.stop_budget))
                }),
        )
    }

    pub fn with_phase_progress(mut self, progress: RunnerPhaseProgress) -> Self {
        self.phase_progress = progress;
        self
    }

    pub fn with_metrics_feed(mut self, feed: RunnerMetricsFeed) -> Self {
        self.metrics_feed = feed;
        self
    }

    pub(super) fn record_loop_progress(&self, chain_id: &str) {
        if let Some(heartbeat) = &self.loop_heartbeat {
            heartbeat.record_progress(chain_id);
        }
    }

    #[doc(hidden)]
    pub fn with_before_redo_progress_write<F, Fut>(mut self, hook: F) -> Self
    where
        F: Fn() -> Fut + Send + Sync + 'static,
        Fut: Future<Output = ()> + Send + 'static,
    {
        self.before_redo_progress_write = Some(Arc::new(move || Box::pin(hook())));
        self
    }

    pub(super) async fn before_redo_progress_write(&self) {
        if let Some(hook) = self.before_redo_progress_write.as_deref() {
            hook().await;
        }
    }
}

impl PhaseRunner {
    /// Record a finished batch: probe the lock, publish heads, write progress,
    /// confirm completion, heartbeat. The batch's own writes are already
    /// committed, so this runs to completion; the caller bounds it after a stop.
    #[allow(clippy::too_many_arguments)]
    pub(super) async fn settle_batch(
        &self,
        chain: &ChainConfig,
        phase_name: PhaseName,
        mode: &RunMode,
        redo_attempt: Option<RedoAttemptFence>,
        context: PhaseContext,
        outcome: RunnerResult<PhaseBatchOutcome>,
        progress_token: ProgressToken,
        retained_verification_level: Option<VerificationLevel>,
        heartbeat: &mut HeartbeatThrottle,
        phase_lock: &mut PhaseLock,
    ) -> RunnerResult<(PhaseBatchOutcome, PhaseProgress)> {
        phase_lock.check_alive().await?;
        let outcome = outcome?;
        let progress = outcome.progress().clone();
        validate_progress(
            phase_name,
            &progress,
            matches!(&outcome, PhaseBatchOutcome::Complete(_)),
        )?;
        if phase_name == PhaseName::Verify {
            crate::verify_phase::validate_reported_level(
                &chain.chain_id,
                &chain.sources,
                progress.verification_level,
            )?;
        }
        if phase_name == PhaseName::Ingest && matches!(mode, RunMode::Normal) {
            ingest_progress::validate(
                &chain.intake_sources(),
                &progress,
                matches!(&outcome, PhaseBatchOutcome::Complete(_)),
            )?;
        }
        if progress.heads.is_some() && !matches!(phase_name, PhaseName::Ingest | PhaseName::Live) {
            return Err(RunnerError::data_integrity(format!(
                "phase {phase_name} cannot publish chain heads; only ingest and live own \
                 chain-head updates"
            )));
        }
        if matches!(mode, RunMode::Normal)
            && let Some(heads) = &progress.heads
        {
            phase_lock.check_alive().await?;
            let heads =
                crate::heads::retain_stored_finality(self.store.pool(), &chain.chain_id, heads)
                    .await?;
            publish_heads(self.store.pool(), &chain.chain_id, &heads).await?;
        }
        phase_lock.check_alive().await?;
        if mode.is_redo() {
            self.before_redo_progress_write().await;
        }
        if phase_name == PhaseName::Ingest && matches!(mode, RunMode::Normal) {
            phase_lock.check_alive().await?;
            self.store
                .record_ingest_progress(&chain.chain_id, &chain.intake_sources(), &progress)
                .await?;
        } else {
            self.store
                .record_progress(&chain.chain_id, phase_name, mode, redo_attempt, &progress)
                .await?;
        }
        self.phase_progress
            .record_committed(progress_token, &outcome);
        if matches!(outcome, PhaseBatchOutcome::Complete(_)) {
            self.confirm_progress(context).await?;
        }
        if matches!(
            phase_name,
            PhaseName::Ingest | PhaseName::Live | PhaseName::Project
        ) {
            self.metrics_feed.batch_committed();
        }
        if phase_name == PhaseName::Verify && matches!(mode, RunMode::Normal) {
            crate::verify_level::warn_optional_downgrade(
                &chain.chain_id,
                retained_verification_level,
                progress.verification_level,
            );
        }
        phase_lock.check_alive().await?;
        heartbeat
            .record_if_due(&self.store, &self.instance_id, &chain.chain_id, phase_name)
            .await?;
        Ok((outcome, progress))
    }

    /// The phase's shadow work after a recorded batch, call after call until it is done; its
    /// error fails the run with the batch kept. With no work waiting it returns true without
    /// calling the hook, stop or not, so a phase with nothing to follow finishes its batch as
    /// before. Otherwise every call, the first included, is preceded by the lock probe, the
    /// phase heartbeat and the capacity guard, with no write reservation, since a family run
    /// carries no estimate. Unlike a batch prelude, which always probes, this check may reuse a
    /// measurement younger than the capacity poll interval that showed room; served and family
    /// writes made since that measurement are not in it. A breach it sees pauses the phase, and
    /// while paused every poll probes afresh. A family catch-up that spans hours so stays
    /// visibly alive. Returns false when a stop abandoned waiting work.
    pub(super) async fn follow_batch(
        &self,
        chain: &ChainConfig,
        phase: &dyn Phase,
        cancellation: &CancellationToken,
        heartbeat: &mut HeartbeatThrottle,
        phase_lock: &mut PhaseLock,
    ) -> RunnerResult<bool> {
        if !phase.has_after_progress_work(&chain.chain_id) {
            return Ok(true);
        }
        loop {
            let admitted = until_cancelled(cancellation, async {
                phase_lock.check_alive().await?;
                heartbeat
                    .record_if_due(
                        &self.store,
                        &self.instance_id,
                        &chain.chain_id,
                        phase.name(),
                    )
                    .await?;
                let stopped = self
                    .wait_for_capacity(
                        chain,
                        phase.name(),
                        0,
                        super::capacity_wait::Measure::ReuseFresh,
                        cancellation,
                        heartbeat,
                        phase_lock,
                    )
                    .await?;
                Ok::<_, RunnerError>(!stopped)
            })
            .await?;
            if admitted != Some(true) {
                return Ok(false);
            }
            // Asked again after the maintenance, which may have waited long for capacity.
            if !phase.has_after_progress_work(&chain.chain_id) {
                return Ok(true);
            }
            // The stop is checked first, and the hook is called only inside the polled branch:
            // calling it plans a family run, so a stop observable here never reaches it. A stop
            // raised once the run is under way abandons it at its next await.
            let step = tokio::select! {
                biased;
                () = cancellation.cancelled() => return Ok(false),
                result = async { phase.after_progress_recorded(&chain.chain_id).await } => result?,
            };
            if step == AfterProgress::Done {
                return Ok(true);
            }
            self.record_loop_progress(&chain.chain_id);
        }
    }
}
