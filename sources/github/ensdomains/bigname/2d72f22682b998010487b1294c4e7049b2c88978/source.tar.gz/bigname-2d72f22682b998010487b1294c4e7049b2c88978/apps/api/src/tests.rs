include!("tests/support.rs");

#[path = "tests/openapi_contract.rs"]
pub(crate) mod openapi_contract;
#[path = "tests/openapi_responses.rs"]
mod openapi_responses;
#[path = "tests/openapi_surface.rs"]
mod openapi_surface;

#[tokio::test]
async fn healthz_reports_phase_runner_health_from_the_phase_schema() -> Result<()> {
    let database = TestDatabase::new_migrated().await?;
    seed_expected_phase_chains(&database, &["1"]).await?;
    seed_phase_runner_heartbeat(&database, "1", "now()").await?;

    let payload = healthz_payload(&database).await?;
    assert_eq!(payload["status"], json!("ready"));
    assert_eq!(payload["api_status"], json!("ready"));
    assert_eq!(payload["database"]["check"], json!("database_identity"));
    assert!(
        payload["database"]["identity"]
            .as_str()
            .is_some_and(|identity| identity.starts_with("keccak256:"))
    );
    assert_eq!(payload["loops"]["phase_runner"]["status"], json!("running"));
    assert_eq!(payload["loops"]["phase_runner"]["phase"], json!("live"));
    assert_eq!(
        payload["identity"]["interpreter_content_hash"],
        json!(bigname_content_hash::INTERPRETER_CONTENT_HASH)
    );

    database.cleanup().await
}

#[tokio::test]
async fn health_and_registry_routes_work_with_documented_api_role_privileges() -> Result<()> {
    let database = TestDatabase::new_migrated().await?;
    seed_expected_phase_chains(&database, &["1"]).await?;
    seed_phase_runner_heartbeat(&database, "1", "now()").await?;
    seed_registry_fixture(&database).await?;
    seed_declared_registry(&database).await?;
    let role = format!(
        "bigname_api_reader_{}_{}",
        std::process::id(),
        NEXT_TEST_ID.fetch_add(1, Ordering::Relaxed)
    );
    sqlx::query(&format!("CREATE ROLE {role} NOLOGIN"))
        .execute(&database.lookup_pool)
        .await?;
    sqlx::query(&format!("GRANT USAGE ON SCHEMA bigname_phase TO {role}"))
        .execute(&database.lookup_pool)
        .await?;
    // Exercise the published allowlist itself: schema-wide grants hide missing dependencies.
    let deployment = include_str!("../../../docs/deployment.md");
    let grants = deployment
        .split_once("GRANT SELECT ON TABLE\n")
        .context("deployment docs must contain the API SELECT grant")?
        .1
        .split_once("TO bigname_api;")
        .context("deployment docs must terminate the API SELECT grant")?
        .0;
    sqlx::query(&format!("GRANT SELECT ON TABLE {grants} TO {role}"))
        .execute(&database.lookup_pool)
        .await?;

    let config = database.database_config(2)?;
    let options = PgConnectOptions::from_str(
        config
            .database_url
            .as_deref()
            .context("restricted API test database URL is missing")?,
    )?
    .options([("search_path", "bigname_phase".to_owned())]);
    let set_role = format!("SET ROLE {role}");
    let restricted_pool = PgPoolOptions::new()
        .max_connections(config.max_connections)
        .after_connect(move |connection, _metadata| {
            let set_role = set_role.clone();
            Box::pin(async move {
                sqlx::query(&set_role).execute(&mut *connection).await?;
                Ok(())
            })
        })
        .connect_with(options)
        .await?;
    let state = AppState::new_with_rpc_urls(
        restricted_pool.clone(),
        bigname_lookup::ChainRpcUrls::default(),
    )
    .with_public_namespaces_for_test(["ens", "basenames"]);
    let app = app_router(state);
    let response = app
        .clone()
        .oneshot(
            Request::builder()
                .uri("/healthz")
                .body(Body::empty())
                .expect("health request must build"),
        )
        .await?;
    let status = response.status();
    let payload: Value = read_json(response).await?;
    let mut registry_results = Vec::new();
    for address in [ROOT_REGISTRY, DECLARED_REGISTRY] {
        for suffix in ["", "/labels"] {
            let uri = format!("/v1/registries/1/{address}{suffix}");
            let response = app
                .clone()
                .oneshot(Request::builder().uri(&uri).body(Body::empty())?)
                .await?;
            registry_results.push((uri, response.status(), read_json::<Value>(response).await?));
        }
    }
    // The children read also joins label preimages, discovery edges and migration associations.
    let uri = "/v1/names/alpha.eth/subnames".to_owned();
    let response = app
        .clone()
        .oneshot(Request::builder().uri(&uri).body(Body::empty())?)
        .await?;
    registry_results.push((uri, response.status(), read_json::<Value>(response).await?));
    restricted_pool.close().await;
    sqlx::query(&format!("DROP OWNED BY {role}"))
        .execute(&database.lookup_pool)
        .await?;
    sqlx::query(&format!("DROP ROLE {role}"))
        .execute(&database.lookup_pool)
        .await?;

    assert_eq!(status, StatusCode::OK);
    for (uri, status, payload) in &registry_results {
        assert_eq!(*status, StatusCode::OK, "{uri}: {payload}");
    }
    let (_, _, subnames) = registry_results.last().context("subnames result")?;
    assert_eq!(
        subnames["data"].as_array().map(Vec::len),
        Some(3),
        "{subnames}"
    );
    assert!(
        payload["database"]["identity"]
            .as_str()
            .is_some_and(|identity| identity.starts_with("keccak256:")),
        "read-only API role must be able to produce the opaque database identity: {payload}"
    );
    database.cleanup().await
}

#[tokio::test]
async fn healthz_database_identity_probes_share_one_timeout_window() -> Result<()> {
    let database = TestDatabase::new_migrated().await?;
    let config = database.database_config(1)?;
    let options = PgConnectOptions::from_str(
        config
            .database_url
            .as_deref()
            .context("health timeout test database URL is missing")?,
    )?
    .options([("search_path", "bigname_phase".to_owned())]);
    let serving_pool = PgPoolOptions::new()
        .max_connections(1)
        .connect_with(options.clone())
        .await?;
    let readiness_pool = PgPoolOptions::new()
        .max_connections(1)
        .connect_with(options)
        .await?;
    let serving_connection = serving_pool.acquire().await?;
    let readiness_connection = readiness_pool.acquire().await?;
    let state = AppState::new_with_rpc_urls(
        serving_pool.clone(),
        bigname_lookup::ChainRpcUrls::default(),
    );
    let app = app_router_with_bounds(state, readiness_pool.clone(), &ApiBoundsConfig::default());

    let started = std::time::Instant::now();
    let response = app
        .oneshot(
            Request::builder()
                .uri("/healthz")
                .body(Body::empty())
                .expect("health request must build"),
        )
        .await?;
    let elapsed = started.elapsed();

    assert_eq!(response.status(), StatusCode::SERVICE_UNAVAILABLE);
    assert!(
        elapsed < HEALTH_DATABASE_CHECK_TIMEOUT + std::time::Duration::from_secs(1),
        "concurrent identity probes took {elapsed:?}"
    );
    drop(serving_connection);
    drop(readiness_connection);
    serving_pool.close().await;
    readiness_pool.close().await;
    database.cleanup().await
}

#[tokio::test]
async fn healthz_reports_not_started_without_any_phase_runner_heartbeat() -> Result<()> {
    let database = TestDatabase::new_migrated().await?;
    seed_expected_phase_chains(&database, &["1", "8453"]).await?;

    let payload = healthz_payload(&database).await?;
    assert_eq!(
        payload["loops"]["phase_runner"]["status"],
        json!("not_started")
    );
    assert_eq!(payload["status"], json!("degraded"));
    assert_eq!(payload["api_status"], json!("ready"));

    database.cleanup().await
}

#[tokio::test]
async fn healthz_judges_the_worst_expected_chain_not_the_freshest_heartbeat() -> Result<()> {
    let database = TestDatabase::new_migrated().await?;
    seed_expected_phase_chains(&database, &["1", "8453"]).await?;
    seed_phase_runner_heartbeat(&database, "1", "now()").await?;

    let missing = healthz_payload(&database).await?;
    let missing_loop = &missing["loops"]["phase_runner"];
    assert_eq!(missing_loop["status"], json!("stale"));
    assert_eq!(missing["status"], json!("degraded"));
    assert_eq!(missing["api_status"], json!("ready"));
    // A chain with no heartbeat is not described by another chain's evidence. The keys stay
    // present and carry null, so index-and-compare would also pass on a dropped key.
    for field in [
        "phase",
        "started_at",
        "heartbeat_at",
        "heartbeat_age_seconds",
    ] {
        let value = missing_loop
            .get(field)
            .unwrap_or_else(|| panic!("{field} must be present"));
        assert!(value.is_null(), "{field} must be null, got {value}");
    }
    assert_eq!(missing_loop["max_age_seconds"], json!(60));

    seed_phase_runner_heartbeat(&database, "8453", "now() - interval '10 minutes'").await?;
    let stalled = healthz_payload(&database).await?;
    assert_eq!(stalled["loops"]["phase_runner"]["status"], json!("stale"));
    assert!(
        stalled["loops"]["phase_runner"]["heartbeat_age_seconds"]
            .as_i64()
            .expect("stale heartbeat age must be reported")
            >= 600
    );

    sqlx::query(
        "UPDATE bigname_phase.service_heartbeats SET heartbeat_at = now() \
         WHERE service_name = 'phase-runner' AND chain_id = '8453'",
    )
    .execute(&database.lookup_pool)
    .await?;
    let recovered = healthz_payload(&database).await?;
    assert_eq!(
        recovered["loops"]["phase_runner"]["status"],
        json!("running")
    );
    assert_eq!(recovered["status"], json!("ready"));

    database.cleanup().await
}

/// The phase runner only ever heartbeats a chain that already has a running phase row, so every
/// heartbeat fixture needs the phase state that admits it.
async fn seed_expected_phase_chains(database: &TestDatabase, chain_ids: &[&str]) -> Result<()> {
    for chain_id in chain_ids {
        sqlx::query(
            "INSERT INTO bigname_phase.chain_phase_state ( \
                 chain_id, phase_name, phase_status, started_at \
             ) VALUES ($1, 'live', 'running', now())",
        )
        .bind(chain_id)
        .execute(&database.lookup_pool)
        .await?;
    }
    Ok(())
}

async fn seed_phase_runner_heartbeat(
    database: &TestDatabase,
    chain_id: &str,
    heartbeat_at_sql: &str,
) -> Result<()> {
    sqlx::query(&format!(
        "INSERT INTO bigname_phase.service_heartbeats ( \
             service_name, instance_id, chain_id, phase_name, started_at, heartbeat_at \
         ) VALUES ('phase-runner', 'api-health', $1, 'live', {heartbeat_at_sql}, \
         {heartbeat_at_sql})"
    ))
    .bind(chain_id)
    .execute(&database.lookup_pool)
    .await?;
    Ok(())
}

async fn healthz_payload(database: &TestDatabase) -> Result<Value> {
    let response = app_router(database.app_state())
        .oneshot(
            Request::builder()
                .uri("/healthz")
                .body(Body::empty())
                .expect("health request must build"),
        )
        .await?;
    assert_eq!(response.status(), StatusCode::OK);
    read_json(response).await
}

#[tokio::test]
async fn v2_namespace_ens_uses_the_checked_in_sepolia_capability_aggregate() -> Result<()> {
    let database = TestDatabase::new(true).await?;
    let manifest_root = std::path::Path::new(env!("CARGO_MANIFEST_DIR"))
        .join("../..")
        .join("manifests/sepolia");
    let repository = bigname_manifests::load_repository(manifest_root)?;
    bigname_manifests::sync_schema_v2_repository(&database.lookup_pool, &repository).await?;

    let response = app_router(database.app_state())
        .oneshot(
            Request::builder()
                .uri("/v1/namespaces/ens")
                .body(Body::empty())
                .expect("namespace request must build"),
        )
        .await?;
    assert_eq!(response.status(), StatusCode::OK);
    let payload: Value = read_json(response).await?;
    // Name reads and name history serve every name whatever the registrar manifests' flags say.
    for capability in ["name_profile", "name_history"] {
        assert_eq!(
            payload["data"]["capabilities"][capability],
            json!({ "completeness": "full" }),
            "{capability}"
        );
    }
    assert_eq!(
        payload["data"]["networks"],
        json!([{ "network": "ethereum-sepolia", "chain_id": 11155111 }]),
        "no family publication, so no resolution"
    );
    // The checked-in Sepolia profile declares the ENS execution entrypoint and the ENSv1
    // registry, so both verified capabilities turn on the moment a Sepolia provider is
    // configured -- and say exactly what is missing until then.
    for capability in ["verified_records", "verified_primary_name"] {
        assert_eq!(
            payload["data"]["capabilities"][capability],
            json!({
                "completeness": "unsupported",
                "unsupported_reason": "execution_provider_not_configured",
                "chains": {
                    "11155111": {
                        "completeness": "unsupported",
                        "unsupported_reason": "execution_provider_not_configured"
                    }
                }
            }),
            "{capability}: {payload}"
        );
    }

    let configured = database
        .app_state_with_lookup_chain_rpc_urls(bigname_lookup::ChainRpcUrls::from_entries(&[
            "ethereum-sepolia=http://rpc.test".to_owned(),
        ])?)
        .await?;
    let response = app_router(configured)
        .oneshot(
            Request::builder()
                .uri("/v1/namespaces/ens")
                .body(Body::empty())
                .expect("namespace request must build"),
        )
        .await?;
    assert_eq!(response.status(), StatusCode::OK);
    let payload: Value = read_json(response).await?;
    for capability in ["verified_records", "verified_primary_name"] {
        assert_eq!(
            payload["data"]["capabilities"][capability],
            json!({
                "completeness": "full",
                "chains": { "11155111": { "completeness": "full" } }
            }),
            "{capability}: {payload}"
        );
    }

    database.cleanup().await
}

#[tokio::test]
async fn v2_namespace_profile_and_history_are_full_where_names_serve() -> Result<()> {
    let database = TestDatabase::new_migrated().await?;
    seed_family_routes_fixture(&database).await?;
    let (status, namespace) = read_family_response(&database, "/v1/namespaces/ens").await?;
    assert_eq!(status, StatusCode::OK, "{namespace:#}");
    for capability in ["name_profile", "name_history"] {
        assert_eq!(
            namespace["data"]["capabilities"][capability],
            json!({ "completeness": "full" }),
            "{capability}: {namespace:#}"
        );
    }
    let (status, name) = read_family_response(&database, "/v1/names/alpha.eth").await?;
    assert_eq!(status, StatusCode::OK, "{name:#}");
    assert_eq!(name["data"]["name"], json!("alpha.eth"), "{name:#}");
    let (status, history) = read_family_response(&database, "/v1/names/alpha.eth/history").await?;
    assert_eq!(status, StatusCode::OK, "{history:#}");
    assert!(
        history["data"]
            .as_array()
            .is_some_and(|rows| !rows.is_empty()),
        "{history:#}"
    );
    database.cleanup().await
}

include!("tests/removed_graphql_route.rs");
include!("tests/v2_name_record.rs");
include!("tests/v2_name_records_default_set.rs");
include!("tests/v2_lookup_detail_parity.rs");
include!("tests/v2_verified_name_detail.rs");
include!("tests/record_id_resolver.rs");
include!("tests/v2_diagnostics_names.rs");
include!("tests/v2_history.rs");
include!("tests/v2_history_registration_identity.rs");
include!("tests/v2_history_publication_bounds.rs");
include!("tests/v2_history_bounded_membership.rs");
include!("tests/v2_history_bounded_registration.rs");
include!("tests/v2_history_bounded_relation_loss.rs");
include!("tests/v2_wrapped_name_control.rs");
include!("tests/v2_history_redo.rs");
include!("tests/v2_history_paging.rs");
include!("tests/v2_history_keyset.rs");
include!("tests/v2_history_keyset_walk.rs");
include!("tests/v2_history_query_filters.rs");
include!("tests/v2_contract_event_counts.rs");
include!("tests/v2_history_block_order.rs");
include!("tests/v2_history_block_order_children.rs");
include!("tests/v2_history_child_registrations.rs");
include!("tests/v2_diag_events.rs");
include!("tests/v2_address_names.rs");
include!("tests/v2_address_names_budget.rs");
include!("tests/v2_address_names_budget_fence.rs");
include!("tests/v2_address_names_roles.rs");
include!("tests/v2_history_permission_changes.rs");
include!("tests/v2_address_resolves_to.rs");
include!("tests/v2_address_resolves_to_evm.rs");
include!("tests/v2_address_resolves_to_evm_plan.rs");
#[path = "tests/v2_address_name_queries.rs"]
mod v2_address_name_queries;
#[path = "tests/v2_authority_ens_v0.rs"]
mod v2_authority_ens_v0;
#[path = "tests/v2_authority_ens_v0_produced.rs"]
mod v2_authority_ens_v0_produced;
#[path = "tests/v2_registry_label_owners.rs"]
mod v2_registry_label_owners;
include!("tests/v2_permissions.rs");
#[path = "tests/site_pages.rs"]
mod site_pages;
#[path = "tests/v2_history_bounded_rebinding.rs"]
mod v2_history_bounded_rebinding;
#[path = "tests/v2_history_bounded_regeneration.rs"]
mod v2_history_bounded_regeneration;
#[path = "tests/v2_registry_permission_identity.rs"]
mod v2_registry_permission_identity;
include!("tests/v2_resolvers.rs");
include!("tests/v2_resolver_collections.rs");
include!("tests/v2_resolver_generation_races.rs");
include!("tests/v2_registries.rs");
include!("tests/v2_registries_manifest_history.rs");
include!("tests/v2_interpret_redo_loaders.rs");
include!("tests/v2_primary_name.rs");
include!("tests/v2_lookup.rs");
include!("tests/v2_record_inventory_abi.rs");
include!("tests/v2_node_record_events.rs");
include!("tests/v2_history_event_data.rs");
include!("tests/v2_search.rs");
include!("tests/v2_names.rs");
include!("tests/v2_names_filters.rs");
include!("tests/v2_former_owner_cursors.rs");
#[path = "tests/v2_former_owner_produced.rs"]
mod v2_former_owner_produced;
include!("tests/v2_query_params.rs");
include!("tests/v2_status.rs");
include!("tests/v2_namespaces_sepolia.rs");
include!("tests/v2_envelope_conformance.rs");
include!("tests/api_storage_quick_wins.rs");

include!("tests/v2_publication_bindings.rs");
include!("tests/v2_family_marker_fence.rs");
include!("tests/v2_family_names.rs");
include!("tests/v2_family_status.rs");
include!("tests/v2_family_records.rs");
include!("tests/v2_family_reverse_page.rs");
include!("tests/v2_family_lookup.rs");
include!("tests/v2_family_lookup_cutover.rs");
include!("tests/v2_ens_v1_object.rs");
#[path = "tests/v2_family_lookup_redo.rs"]
mod lookup_redo;
#[path = "tests/v2_read_only_lookup.rs"]
mod read_only_lookup;
#[path = "tests/v2_family_lookup_release.rs"]
mod v2_family_lookup_release;
#[path = "tests/v2_sepolia_redeploy.rs"]
mod v2_sepolia_redeploy;
include!("tests/v2_family_permissions.rs");
include!("tests/v2_family_history_publication.rs");
include!("tests/v2_family_records_review.rs");
include!("tests/v2_list_cursor.rs");
include!("tests/v2_collection_cursor_completion.rs");
include!("tests/v2_family_children.rs");
include!("tests/v2_family_registry_children.rs");
include!("tests/v2_address_names_parent.rs");
include!("tests/v2_bracketed_labelhash_names.rs");
include!("tests/v2_family_name_publication_changes.rs");
include!("tests/v2_family_name_recompute.rs");
include!("tests/v2_family_resolver_history.rs");
include!("tests/v2_family_child_authority.rs");
include!("tests/v2_family_name_display.rs");
include!("tests/family_fixture_inputs_b.rs");

include!("tests/v2_unix_timestamps.rs");
