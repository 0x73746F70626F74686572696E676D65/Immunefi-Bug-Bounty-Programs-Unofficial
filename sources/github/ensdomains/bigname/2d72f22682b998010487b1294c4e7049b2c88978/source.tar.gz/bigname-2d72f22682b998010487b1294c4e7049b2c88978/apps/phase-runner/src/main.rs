use std::{net::SocketAddr, sync::Arc, time::Duration};

use anyhow::{Context, Result, bail};
use clap::Parser;
use phase_runner::{
    capacity::CapacityGuard,
    cli::{
        Cli, RedoChains, ResolvedCommand, resolve_all_redo_chains, validate_redo_attestation_chains,
    },
    database::{RunnerDatabase, VerificationDatabase},
    ingest_phase::IngestPhase,
    interpret_phase::InterpretPhase,
    live_phase::LivePhase,
    phase::PhaseSet,
    project_phase::ProjectPhase,
    rpc_chain_check,
    runner::{PhaseRunner, SupervisorReport},
    verify_phase::VerifyPhase,
};
use tokio_util::sync::CancellationToken;

#[path = "main_manifests.rs"]
mod manifests;
use manifests::{bind_runtime_manifests, hash_manifests_off_runtime};
#[cfg(test)]
use manifests::{load_hashed_manifest_repository, prepare_runtime_manifests};
#[cfg(test)]
use phase_runner::config::{COMPILED_CHAIN_NAMESPACES, validate_deployment_table_set};
use phase_runner::manifest_startup::sync_loaded_manifests;

#[tokio::main]
async fn main() -> Result<()> {
    phase_runner::logging::init();
    let command = Cli::parse().resolve()?;

    match command {
        ResolvedCommand::SourceTransport {
            database_url,
            old,
            new,
            rpc_chain_check,
        } => {
            let no_hydration = bigname_lookup::ChainRpcUrls::default();
            rpc_chain_check::verify_all([&old, &new], &no_hydration, rpc_chain_check).await?;
            let database = RunnerDatabase::connect(&database_url, 2).await?;
            let receipt =
                phase_runner::source_transport::transition(&database, &old, &new, rpc_chain_check)
                    .await?;
            println!("{}", serde_json::to_string(&receipt)?);
        }
        ResolvedCommand::InitSchema { database_url } => {
            let database = RunnerDatabase::connect(&database_url, 1).await?;
            phase_runner::schema::initialize_schema_v2(database.pool()).await?;
            tracing::info!(
                schema = phase_runner::schema::PHASE_SCHEMA_NAME,
                "schema-v2 database is ready"
            );
        }
        ResolvedCommand::Run {
            database_url,
            verification_database_url,
            metrics_bind_addr,
            heartbeat_stale_after_secs,
            manifests_root,
            mut runtime,
            hydration_rpc_urls,
            project_families,
        } => {
            // Only the supervised run and an explicit redo poll the token; the
            // one-shot commands keep the default SIGTERM disposition.
            let cancellation = CancellationToken::new();
            phase_runner::shutdown::cancel_on_signal(&cancellation)
                .context("register the stop signals before starting")?;
            let startup = async {
                let (manifest_repository, manifest_profile) =
                    hash_manifests_off_runtime(manifests_root.clone()).await??;
                bind_runtime_manifests(
                    &manifest_repository,
                    manifest_profile,
                    Arc::make_mut(&mut runtime.chains),
                )?;
                let rpc_mode = rpc_chain_check::mode(&runtime.capacity);
                let sources = runtime.chains.iter().flat_map(|chain| chain.sources.iter());
                let verified_rpc =
                    rpc_chain_check::verify_all(sources, &hydration_rpc_urls, rpc_mode).await?;
                rpc_chain_check::record_on_chains(
                    Arc::make_mut(&mut runtime.chains),
                    &verified_rpc,
                )?;
                let connections = u32::try_from(runtime.chains.len())
                    .unwrap_or(u32::MAX)
                    .saturating_mul(2)
                    .max(4);
                let database = RunnerDatabase::connect(&database_url, connections).await?;
                sync_loaded_manifests(
                    database.pool(),
                    &manifests_root,
                    &manifest_repository,
                    manifest_profile,
                )
                .await?;
                rpc_chain_check::persist(database.pool(), &runtime.chains).await?;
                let (loop_heartbeat, phase_progress, metrics_feed) = start_metrics(
                    metrics_bind_addr,
                    &database,
                    &cancellation,
                    heartbeat_stale_after_secs,
                    runtime.chains.iter().map(|chain| chain.chain_id.as_str()),
                    true,
                )
                .await?;
                rpc_chain_check::report(&metrics_feed, &verified_rpc);
                let verification_database = VerificationDatabase::connect(
                    &verification_database_url,
                    &database,
                    u32::try_from(runtime.chains.len())
                        .unwrap_or(u32::MAX)
                        .max(1),
                )
                .await?;
                let ingest_engine = Arc::new(
                    bigname_ingest::Engine::with_config(
                        database.pool().clone(),
                        runtime.capacity.ingest,
                    )
                    .with_rpc_counters(metrics_feed.ingest_rpc_counters().clone()),
                );
                let phases = PhaseSet::with_ingest_interpret_project_and_live(
                    Arc::new(
                        IngestPhase::with_engine(Arc::clone(&ingest_engine))
                            .with_metrics(metrics_feed.clone()),
                    ),
                    Arc::new(InterpretPhase::from_capacity(
                        database.pool().clone(),
                        &runtime.capacity,
                    )),
                    Arc::new(
                        ProjectPhase::with_hydration(database.pool().clone(), hydration_rpc_urls)
                            .with_family_settings(project_families)
                            .with_metrics(metrics_feed.clone()),
                    ),
                    Arc::new(VerifyPhase::new(verification_database, rpc_mode)),
                    Arc::new(
                        LivePhase::with_engine(ingest_engine).with_metrics(metrics_feed.clone()),
                    ),
                )?;
                anyhow::Ok(Arc::new(
                    PhaseRunner::new(
                        database,
                        phases,
                        CapacityGuard::system(runtime.capacity.clone()),
                        runtime.instance_id.clone(),
                        runtime.timing.clone(),
                    )?
                    .with_loop_heartbeat(loop_heartbeat)
                    .with_phase_progress(phase_progress)
                    .with_metrics_feed(metrics_feed),
                ))
            };
            let Some(runner) =
                phase_runner::shutdown::until_cancelled(&cancellation, startup).await?
            else {
                tracing::info!("stop requested during start-up; the runner never started");
                return Ok(());
            };
            let report = runner.run(&runtime, cancellation).await?;
            require_clean_supervisor_exit(report)?;
        }
        ResolvedCommand::Redo {
            database_url,
            verification_database_url,
            metrics_bind_addr,
            heartbeat_stale_after_secs,
            manifests_root,
            instance_id,
            chains,
            capacity,
            timing,
            phase,
            range,
            watch_set_coverage_attestations,
            hydration_rpc_urls,
            project_families,
        } => {
            let cancellation = CancellationToken::new();
            phase_runner::shutdown::cancel_on_signal(&cancellation)
                .context("register the stop signals before starting")?;
            let startup = async {
                let database = RunnerDatabase::connect(&database_url, 4).await?;
                let mut chains = match chains {
                    RedoChains::Explicit(chains) => chains,
                    RedoChains::All { sources } => {
                        resolve_all_redo_chains(
                            database.pool(),
                            sources,
                            phase.requires_intake_sources(),
                        )
                        .await?
                    }
                };
                let (manifest_repository, manifest_profile) =
                    hash_manifests_off_runtime(manifests_root.clone()).await??;
                bind_runtime_manifests(&manifest_repository, manifest_profile, &mut chains)?;
                let sources = chains
                    .iter()
                    .filter(|_| phase.reads_sources())
                    .flat_map(|chain| chain.sources.iter());
                let rpc_mode = rpc_chain_check::mode(&capacity);
                // Replay and rebuild never hydrate, so a redo checks no hydration URL.
                let verified_rpc = rpc_chain_check::verify_all(
                    sources,
                    &bigname_lookup::ChainRpcUrls::default(),
                    rpc_mode,
                )
                .await?;
                rpc_chain_check::record_on_chains(&mut chains, &verified_rpc)?;
                let manifests = (manifest_repository, manifest_profile);
                anyhow::Ok((database, chains, manifests, verified_rpc))
            };
            // Nothing durable happens before this point, so a stop here is a redo
            // that never started. Manifest synchronization is the first commit: a
            // changed manifest can retire hashes or install required Ingest work,
            // so a stop from here on is reported as something to rerun, never as a
            // no-op, whether or not the commit made it.
            let Some((database, chains, (manifest_repository, manifest_profile), verified_rpc)) =
                phase_runner::shutdown::until_cancelled(&cancellation, startup).await?
            else {
                tracing::info!("stop requested during start-up; the redo never started");
                return Ok(());
            };
            let synchronized = phase_runner::shutdown::until_cancelled(
                &cancellation,
                sync_loaded_manifests(
                    database.pool(),
                    &manifests_root,
                    &manifest_repository,
                    manifest_profile,
                ),
            )
            .await?;
            if synchronized.is_none() {
                bail!(
                    "stop requested during manifest synchronization; whether the manifest change \
                     committed is not known, so this redo must be run again"
                );
            }
            let startup = async {
                validate_redo_attestation_chains(&watch_set_coverage_attestations, &chains)?;
                rpc_chain_check::persist(database.pool(), &chains).await?;
                let (loop_heartbeat, phase_progress, metrics_feed) = start_metrics(
                    metrics_bind_addr,
                    &database,
                    &cancellation,
                    heartbeat_stale_after_secs,
                    chains.iter().map(|chain| chain.chain_id.as_str()),
                    false,
                )
                .await?;
                rpc_chain_check::report(&metrics_feed, &verified_rpc);
                let rpc_mode = rpc_chain_check::mode(&capacity);
                let ingest_engine = Arc::new(
                    bigname_ingest::Engine::with_config(database.pool().clone(), capacity.ingest)
                        .with_rpc_counters(metrics_feed.ingest_rpc_counters().clone()),
                );
                let ingest = Arc::new(
                    IngestPhase::with_engine(ingest_engine).with_metrics(metrics_feed.clone()),
                );
                let interpret = Arc::new(InterpretPhase::from_capacity(
                    database.pool().clone(),
                    &capacity,
                ));
                let project = Arc::new(
                    ProjectPhase::with_hydration(database.pool().clone(), hydration_rpc_urls)
                        .with_family_settings(project_families)
                        .with_metrics(metrics_feed.clone()),
                );
                let phases = if phase.requires_verify() {
                    let verification_database_url =
                        verification_database_url.as_deref().ok_or_else(|| {
                            anyhow::anyhow!(
                                "verify redo requires a SELECT-only verification database URL"
                            )
                        })?;
                    let verification_database =
                        VerificationDatabase::connect(verification_database_url, &database, 1)
                            .await?;
                    PhaseSet::with_ingest_interpret_project_and_verify(
                        ingest,
                        interpret,
                        project,
                        Arc::new(VerifyPhase::new(verification_database, rpc_mode)),
                    )?
                } else {
                    PhaseSet::with_ingest_interpret_and_project(ingest, interpret, project)?
                };
                anyhow::Ok(
                    PhaseRunner::new(
                        database,
                        phases,
                        CapacityGuard::system(capacity),
                        instance_id,
                        timing,
                    )?
                    .with_watch_set_coverage_attestations(watch_set_coverage_attestations)
                    .with_loop_heartbeat(loop_heartbeat)
                    .with_phase_progress(phase_progress)
                    .with_metrics_feed(metrics_feed),
                )
            };
            let Some(runner) =
                phase_runner::shutdown::until_cancelled(&cancellation, startup).await?
            else {
                bail!(
                    "stop requested after the manifests were synchronized and before the redo \
                     started; required work that synchronization installed is durable, so this \
                     redo must be run again"
                );
            };
            let report = runner
                .redo_chains(&chains, phase, range, cancellation)
                .await?;
            require_clean_supervisor_exit(report)?;
        }
        ResolvedCommand::Rewind {
            database_url,
            chain_id,
            ancestor,
        } => {
            let database = RunnerDatabase::connect(&database_url, 2).await?;
            let outcome =
                phase_runner::rewind::rewind_to_ancestor(&database, &chain_id, ancestor).await?;
            tracing::info!(
                chain_id,
                previous_block = outcome.previous.number,
                previous_hash = outcome.previous.hash,
                ancestor_block = outcome.ancestor.number,
                ancestor_hash = outcome.ancestor.hash,
                "chain head rewound; affected downstream phases are stamped for redo"
            );
        }
        ResolvedCommand::Inspect {
            database_url,
            request,
        } => phase_runner::inspect::run(&database_url, request).await?,
        ResolvedCommand::LabelPreimagesImportEnsRainbow {
            database_url,
            batch_size,
            limit,
        } => {
            phase_runner::label_preimages::import_ens_rainbow(&database_url, batch_size, limit)
                .await?;
        }
    }
    Ok(())
}

async fn start_metrics<'a>(
    bind_addr: SocketAddr,
    database: &RunnerDatabase,
    cancellation: &CancellationToken,
    heartbeat_stale_after_secs: i64,
    chain_ids: impl IntoIterator<Item = &'a str>,
    seed_loop_heartbeats: bool,
) -> Result<(
    phase_runner::metrics::RunnerLoopHeartbeat,
    phase_runner::RunnerPhaseProgress,
    phase_runner::metrics::RunnerMetricsFeed,
)> {
    let loop_heartbeat = phase_runner::metrics::RunnerLoopHeartbeat::default();
    let phase_progress = phase_runner::RunnerPhaseProgress::new(Duration::from_secs(
        heartbeat_stale_after_secs
            .try_into()
            .expect("validated threshold"),
    ));
    let metrics_feed = phase_runner::metrics::RunnerMetricsFeed::default();
    for chain_id in chain_ids {
        if seed_loop_heartbeats {
            loop_heartbeat.record_progress(chain_id);
        }
        phase_progress.seed_chain(chain_id);
        metrics_feed.seed_chain(chain_id);
    }
    let bound_addr = phase_runner::metrics::start(
        bind_addr,
        database.pool().clone(),
        cancellation.clone(),
        heartbeat_stale_after_secs,
        loop_heartbeat.clone(),
        phase_progress.clone(),
        metrics_feed.clone(),
    )
    .await?;
    tracing::info!(
        service = "phase-runner",
        metrics_bind_addr = %bound_addr,
        version = phase_runner::SOFTWARE_VERSION,
        build_sha = phase_runner::BUILD_SHA,
        interpreter_content_hash = phase_runner::INTERPRETER_CONTENT_HASH,
        "phase-runner metrics listener started"
    );
    Ok((loop_heartbeat, phase_progress, metrics_feed))
}

fn require_clean_supervisor_exit(report: SupervisorReport) -> Result<()> {
    if report.stopped_chains.is_empty() {
        return Ok(());
    }
    let failures = report
        .stopped_chains
        .iter()
        .map(|(chain_id, error)| format!("{chain_id} ({:?}): {error}", error.kind()))
        .collect::<Vec<_>>()
        .join("; ");
    anyhow::bail!(
        "{} chain supervisor(s) stopped on terminal errors: {failures}",
        report.stopped_chains.len()
    )
}

#[cfg(test)]
#[path = "main/startup_tests.rs"]
mod startup_tests;

#[cfg(test)]
#[path = "main/tests.rs"]
mod tests;
