use std::collections::BTreeMap;

#[cfg(test)]
#[path = "resolvers/generation_test_hooks.rs"]
pub(crate) mod generation_test_hooks;

#[path = "resolvers/collections.rs"]
mod collections;
pub(crate) use collections::{get_resolver_links, get_resolver_roles};

use axum::{
    Json,
    extract::{Path, State},
};
use bigname_storage::{
    NameCurrentListCursor, NameCurrentListCursorValue, NameCurrentListRow, ResolverCurrentRow,
    SelectedSnapshot, SnapshotPositionRequirement, SnapshotSelectionScope,
};
use serde::{Deserialize, Serialize};
use serde_json::Value;
use tracing::error;

use super::support::parse_evm_address;
use crate::AppState;

#[path = "resolvers/bound_names_cursor.rs"]
mod bound_names_cursor;
pub(crate) use bound_names_cursor::{
    BoundNamesCursorBinding, bound_names_next_cursor, bound_names_storage_cursor,
    check_bound_names_cursor_shape,
};

#[path = "resolvers/link_items.rs"]
mod link_items;

#[path = "resolvers/role_grants.rs"]
mod role_grants;

#[path = "resolvers/snapshot_checks.rs"]
mod snapshot_checks;
use snapshot_checks::{
    require_phase_name_snapshot, require_phase_target_snapshot, revalidate_project_generations,
};

use super::{
    Envelope, NameRecord, PRODUCT_PIPELINE_TERMS, Page, QueryParamAllowlist, SnapshotReadResource,
    StrictQueryParams, V2Error, V2Result, api_error_to_v2, build_name_record,
    contains_boundary_vocabulary, encode_at_token, name_record, numeric_to_slug,
    resolve_v2_snapshot_for, snapshot_meta, snapshot_slot_for_slug,
    vocab::{Resolver, Status},
};

const BOUND_NAMES_SORT_TOKEN: &str = "name_asc";

pub(crate) struct ResolverQueryParams;

impl QueryParamAllowlist for ResolverQueryParams {
    const ALLOWED: &'static [&'static str] = &["at", "finality", "cursor", "page_size"];
}

pub(crate) type ResolverQuery = StrictQueryParams<ResolverQueryParams>;

/// The resolver overview: its identity, its mirror declaration and the names bound to it. It
/// carries no section counts or samples; the `/links` and `/roles` collections page
/// those rows with exact totals (docs/api-v1-routes.md, the resolver overview).
#[derive(Clone, Debug, Deserialize, PartialEq, Serialize)]
pub(crate) struct ResolverOverview {
    pub(crate) chain_id: u64,
    pub(crate) address: String,
    /// Present only for a declared ENSv1 mirror resolver: the ENSv1 registry it reads.
    #[serde(skip_serializing_if = "Option::is_none")]
    pub(crate) mirror: Option<ResolverMirror>,
    pub(crate) bound_names: BoundNames,
}

#[derive(Clone, Debug, Deserialize, PartialEq, Serialize)]
pub(crate) struct ResolverMirror {
    pub(crate) kind: String,
    pub(crate) registry: Resolver,
}

#[derive(Clone, Debug, Deserialize, PartialEq, Serialize)]
pub(crate) struct BoundNames {
    pub(crate) data: Vec<NameRecord>,
    pub(crate) page: Page,
}

pub(crate) async fn get_resolver(
    Path((chain_id, address)): Path<(String, String)>,
    params: ResolverQuery,
    State(state): State<AppState>,
) -> V2Result<Json<Envelope<ResolverOverview>>> {
    let params = params.into_inner();
    let (numeric_chain_id, chain_id_slug) = parse_numeric_chain_id(&chain_id)?;
    let normalized_address = parse_evm_address(&address, "address").map_err(api_error_to_v2)?;
    // A cursor this list could not have written is refused before anything is read; only its
    // `at` pin, which needs the selected snapshot, is compared once the snapshot is selected.
    check_bound_names_cursor_shape(
        params.cursor.as_deref(),
        &BoundNamesCursorBinding {
            chain_id: numeric_chain_id,
            resolver_address: &normalized_address,
            namespace: params.namespace.as_deref(),
            sort: BOUND_NAMES_SORT_TOKEN,
            at: None,
        },
        params.at.is_some(),
    )?;
    // Admitted without the cursor: a bound-names cursor binds no publication (`list_cursor`), so
    // only a publication during this read refuses it, with a retry.
    let mut publication = super::collection_snapshot::CollectionSnapshot::capture_for_namespace(
        &state,
        None,
        Some(resolver_namespace(chain_id_slug)?),
    )
    .await?;

    let scope = resolver_snapshot_scope(chain_id_slug)?;
    // Family bound names describe only their publication, including an empty page. A served
    // resolver row can retain an older target, so checking returned rows alone is insufficient.
    let require_selected_head = true;
    let selected_snapshot = resolve_v2_snapshot_for(
        &state.pool,
        &scope,
        params.at.as_ref(),
        params.finality,
        SnapshotReadResource::Resolver,
    )
    .await?;
    // The cursor binds `at` only when the request pinned it; a latest continuation reads the
    // publication current when it runs.
    let at_token = params
        .at
        .is_some()
        .then(|| encode_at_token(&selected_snapshot));
    let cursor_binding = BoundNamesCursorBinding {
        chain_id: numeric_chain_id,
        resolver_address: &normalized_address,
        namespace: params.namespace.as_deref(),
        sort: BOUND_NAMES_SORT_TOKEN,
        at: at_token.as_deref(),
    };
    let storage_cursor = params
        .cursor
        .as_deref()
        .map(|cursor| bound_names_storage_cursor(cursor, &cursor_binding))
        .transpose()?;
    // A cursor pinned to `at` is tied to that block: once a later block is published,
    // the continuation is stale, whatever rows the later block changed. A same-block rebuild is
    // not detected; the cursor holds no generation (`list_cursor`).
    if storage_cursor.is_some() && params.at.is_some() {
        let published = publication.block_bounds().get(chain_id_slug).copied();
        let pinned = selected_snapshot
            .chain_positions
            .as_map()
            .values()
            .find(|position| position.chain_id == chain_id_slug)
            .map(|position| position.block_number);
        if published
            .zip(pinned)
            .is_none_or(|(published, pinned)| published > pinned)
        {
            return Err(V2Error::stale(
                "resolver data is unavailable at the selected historical position",
            ));
        }
    }

    let project_generations =
        load_resolver_project_generations(&state.pool, &selected_snapshot, require_selected_head)
            .await?;
    revalidate_project_generations(
        &state,
        &mut publication,
        &selected_snapshot,
        &project_generations,
        params.at.is_some(),
        "served resolver data changed while the request was being read",
    )
    .await?;
    let row = bigname_storage::load_phase_resolver_current(
        publication.conn().await?,
        chain_id_slug,
        &normalized_address,
    )
    .await
    .map_err(super::name_rows_error(SnapshotReadResource::Resolver, |_| {
        V2Error::internal_error(format!(
            "failed to load resolver data for chain_id {chain_id_slug} address {normalized_address}"
        ))
    }))?;
    let Some(row) = row else {
        if !require_selected_head {
            return Err(V2Error::stale(
                "resolver data is unavailable at the selected historical position",
            ));
        }
        return Err(V2Error::not_found(format!(
            "resolver {normalized_address} was not found on chain {numeric_chain_id}"
        )));
    };
    require_phase_target_snapshot(&row.chain_positions, &row.chain_id, &selected_snapshot)?;
    let (bound_name_rows, storage_next_cursor) = load_bound_name_rows(
        publication.conn().await?,
        chain_id_slug,
        params.namespace.as_deref(),
        storage_cursor.as_ref(),
        params.page_size,
        numeric_chain_id,
        &normalized_address,
    )
    .await?;
    for bound_name_row in &bound_name_rows {
        require_phase_name_snapshot(bound_name_row, &selected_snapshot)?;
    }

    let next_cursor = storage_next_cursor
        .as_ref()
        .map(|cursor| bound_names_next_cursor(cursor, &cursor_binding));
    let has_more = next_cursor.is_some();
    let bound_name_records = bound_name_rows
        .iter()
        .map(|row| build_bound_name_record(row, numeric_chain_id))
        .collect::<V2Result<Vec<_>>>()?;
    let bound_names = BoundNames {
        data: bound_name_records,
        page: Page {
            cursor: params.cursor.clone(),
            next_cursor,
            page_size: params.page_size,
            total_count: None,
            has_more,
        },
    };
    let meta = snapshot_meta(&selected_snapshot)?;
    let data = build_resolver_overview(row, numeric_chain_id, bound_names);
    publication.finish(&state).await?;

    Ok(Json(Envelope {
        data,
        page: None,
        meta,
    }))
}

async fn load_resolver_project_generations(
    pool: &sqlx::PgPool,
    selected: &SelectedSnapshot,
    require_selected_head: bool,
) -> V2Result<BTreeMap<String, String>> {
    if require_selected_head {
        super::lookup::head::load_selected_project_generations(pool, selected).await
    } else {
        super::lookup::head::load_project_generations(pool, selected).await
    }
}

pub(crate) fn build_resolver_overview(
    row: ResolverCurrentRow,
    chain_id: u64,
    bound_names: BoundNames,
) -> ResolverOverview {
    let mirror = resolver_mirror(&row.declared_summary, chain_id);
    ResolverOverview {
        chain_id,
        address: row.resolver_address,
        mirror,
        bound_names,
    }
}

fn resolver_mirror(declared_summary: &Value, chain_id: u64) -> Option<ResolverMirror> {
    let mirror = declared_summary.get("classification")?.get("mirror")?;
    let address = mirror.get("mirrored_registry_address")?.as_str()?;
    Some(ResolverMirror {
        kind: "ensv1_registry".to_owned(),
        registry: Resolver {
            chain_id,
            address: address.to_ascii_lowercase(),
        },
    })
}

pub(crate) fn build_bound_name_record(
    row: &NameCurrentListRow,
    chain_id: u64,
) -> V2Result<NameRecord> {
    build_name_record(&row.row, None, Some(chain_id), Status::Ok)
}

async fn load_bound_name_rows(
    conn: &mut sqlx::PgConnection,
    chain_id_slug: &str,
    namespace: Option<&str>,
    cursor: Option<&NameCurrentListCursor>,
    page_size: u64,
    chain_id: u64,
    resolver_address: &str,
) -> V2Result<(Vec<NameCurrentListRow>, Option<NameCurrentListCursor>)> {
    let limit = page_size.saturating_add(1) as i64;
    let loaded = bigname_storage::families::name::load_family_bound_names(
        conn,
        chain_id_slug,
        resolver_address,
        namespace,
        cursor,
        limit,
    )
    .await
    .map_err(crate::v2::name_rows_error(
        SnapshotReadResource::Resolver,
        |_| {
            V2Error::internal_error(format!(
                "failed to load bound names for resolver {resolver_address} on chain {chain_id}"
            ))
        },
    ))?;
    let mut rows = loaded
        .into_iter()
        .map(|row| NameCurrentListRow {
            row,
            labelhash: None,
            token_id: None,
            owner: None,
            created_at: None,
            registration_date: None,
            expiry_date: None,
            resolver_address: Some(resolver_address.to_owned()),
        })
        .filter(|row| bound_name_row_matches_chain(row, chain_id))
        .collect::<Vec<_>>();
    let target_len = page_size as usize;
    let has_more = rows.len() > target_len;
    rows.truncate(target_len);
    let next_cursor = has_more
        .then(|| rows.last().map(bound_name_cursor_from_row))
        .flatten();
    Ok((rows, next_cursor))
}

fn bound_name_cursor_from_row(row: &NameCurrentListRow) -> NameCurrentListCursor {
    NameCurrentListCursor {
        sort_value: NameCurrentListCursorValue::Name(row.row.canonical_display_name.clone()),
        namespace: row.row.namespace.clone(),
        normalized_name: row.row.normalized_name.clone(),
        namehash: row.row.namehash.clone(),
    }
}

pub(crate) fn parse_numeric_chain_id(value: &str) -> V2Result<(u64, &'static str)> {
    let value = value.trim();
    if value.is_empty() || !value.bytes().all(|byte| byte.is_ascii_digit()) {
        return Err(invalid_chain_id());
    }

    let chain_id = value.parse::<u64>().map_err(|_| invalid_chain_id())?;
    let slug = numeric_to_slug(chain_id).ok_or_else(invalid_chain_id)?;

    Ok((chain_id, slug))
}

fn resolver_namespace(chain_id_slug: &str) -> V2Result<&'static str> {
    match chain_id_slug {
        "ethereum-mainnet" | "ethereum-sepolia" => Ok("ens"),
        "base-mainnet" | "base-sepolia" => Ok("basenames"),
        _ => Err(invalid_chain_id()),
    }
}

fn invalid_chain_id() -> V2Error {
    V2Error::invalid_input("chain_id must be a supported numeric EVM chain id")
}

pub(crate) fn resolver_snapshot_scope(chain_id_slug: &str) -> V2Result<SnapshotSelectionScope> {
    let slot = snapshot_slot_for_slug(chain_id_slug).ok_or_else(|| {
        error!(
            service = "api",
            chain_id = %chain_id_slug,
            "failed to map resolver snapshot slot"
        );
        V2Error::internal_error("failed to build resolver snapshot scope")
    })?;
    SnapshotSelectionScope::new(
        vec![SnapshotPositionRequirement::new(
            slot.to_owned(),
            chain_id_slug.to_owned(),
        )],
        Some(slot.to_owned()),
    )
    .map_err(|error| {
        error!(
            service = "api",
            chain_id = %chain_id_slug,
            slot = %slot,
            message = %error.message(),
            "failed to build resolver snapshot scope"
        );
        V2Error::internal_error("failed to build resolver snapshot scope")
    })
}

fn product_resolver_reason(reason: &str) -> V2Result<String> {
    match reason {
        "resolver_binding_enumeration_not_projected" => {
            Ok("binding_enumeration_not_supported".to_owned())
        }
        _ if contains_boundary_vocabulary(reason, PRODUCT_PIPELINE_TERMS) => {
            error!(%reason, "rejected resolver reason containing pipeline vocabulary");
            Err(V2Error::internal_error(
                "failed to map resolver reason vocabulary",
            ))
        }
        _ => Ok(reason.to_owned()),
    }
}

fn bound_name_row_matches_chain(row: &NameCurrentListRow, chain_id: u64) -> bool {
    name_record::resolver(&row.row.declared_summary)
        .is_some_and(|resolver| resolver.chain_id == chain_id)
}
