use serde::{Deserialize, Serialize};

use crate::v2::name_record::{EnsV1, LapsedRegistration};
use crate::v2::record_groups::{AbiSource, RecordGroups};
use crate::v2::{
    AddressNameResolution, Authority, Page, RegistrationStatus, RegistryRef, Relation, Resolver,
    Status,
};

#[derive(Clone, Debug, Deserialize, Eq, PartialEq)]
#[serde(deny_unknown_fields)]
pub(crate) struct LookupRequest {
    pub(super) profile: Option<String>,
    pub(super) namespace: Option<String>,
    pub(super) include: Option<String>,
    pub(super) inputs: Vec<LookupInput>,
}

#[derive(Clone, Debug, Deserialize, Eq, PartialEq)]
#[serde(untagged)]
pub(super) enum LookupInput {
    Name(LookupNameInput),
    Address(LookupAddressInput),
}

#[derive(Clone, Debug, Deserialize, Eq, PartialEq)]
#[serde(deny_unknown_fields)]
pub(super) struct LookupNameInput {
    pub(super) id: Option<String>,
    pub(super) name: String,
}

#[derive(Clone, Debug, Deserialize, Eq, PartialEq)]
#[serde(deny_unknown_fields)]
pub(super) struct LookupAddressInput {
    pub(super) id: Option<String>,
    pub(super) address: String,
    pub(super) coin_type: Option<u64>,
    pub(super) relation: Option<String>,
    pub(super) page_size: Option<u64>,
    pub(super) cursor: Option<String>,
}

#[derive(Clone, Copy, Debug, Deserialize, Eq, PartialEq, Serialize)]
#[serde(rename_all = "snake_case")]
pub(super) enum LookupKind {
    Name,
    Address,
}

#[derive(Clone, Debug, Deserialize, PartialEq, Serialize)]
pub(crate) struct LookupResult {
    pub(super) input: LookupResultInput,
    pub(super) kind: LookupKind,
    pub(super) status: Status,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub(super) unsupported_reason: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub(super) failure_reason: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub(super) normalization: Option<NormalizationInfo>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub(super) record: Option<LookupRecord>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub(super) records: Option<Vec<LookupRecord>>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub(super) page: Option<Page>,
}

#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize)]
pub(super) struct LookupResultInput {
    #[serde(skip_serializing_if = "Option::is_none")]
    pub(super) id: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub(super) name: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub(super) address: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub(super) coin_type: Option<u64>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub(super) relation: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub(super) page_size: Option<u64>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub(super) cursor: Option<String>,
}

#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize)]
pub(super) struct NormalizationInfo {
    pub(super) changed: bool,
    pub(super) input_name: String,
    pub(super) reason: String,
}

#[derive(Clone, Debug, Deserialize, PartialEq, Serialize)]
pub(crate) struct LookupRecord {
    pub(crate) name: String,
    pub(crate) display_name: String,
    pub(crate) namespace: String,
    pub(crate) namehash: String,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub(crate) registration_id: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub(crate) token_id: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub(crate) owner: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub(crate) manager: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub(crate) registered_at: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub(crate) created_at: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub(crate) expires_at: Option<crate::v2::timestamps::ExpiryTimestamp>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub(crate) expires_at_reason: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub(crate) grace_ends_at: Option<crate::v2::timestamps::ExpiryTimestamp>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub(crate) registration_status: Option<RegistrationStatus>,
    /// The lapsed holder of a released ENSv1 lease; never current data.
    #[serde(skip_serializing_if = "Option::is_none")]
    pub(crate) lapsed_registration: Option<LapsedRegistration>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub(crate) resolver: Option<Resolver>,
    /// Why the name resolves to nothing through the Universal Resolver, as on name detail.
    #[serde(skip_serializing_if = "Option::is_none")]
    pub(crate) unresolvable_reason: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub(crate) subregistry: Option<RegistryRef>,
    /// Present on `profile=detail` records that may serve resolver records and have a record
    /// inventory, as on name detail (`record_groups.rs`).
    #[serde(skip_serializing_if = "Option::is_none")]
    pub(crate) records: Option<RecordGroups>,
    /// The inventory row `records` came from, for the request's one batched ABI read.
    #[serde(skip)]
    pub(crate) abi_source: Option<AbiSource>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub(crate) primary_name: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub(crate) primary_address: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub(crate) chain_id: Option<u64>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub(crate) network: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub(crate) is_primary: Option<bool>,
    #[serde(skip_serializing_if = "Vec::is_empty")]
    pub(crate) relations: Vec<Relation>,
    /// Present only on `relation=resolves_to` reverse rows.
    #[serde(skip_serializing_if = "Option::is_none")]
    pub(crate) resolution: Option<AddressNameResolution>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub(crate) authority: Option<Authority>,
    /// Present on records of either profile whose authority is `ens_v1` or `ens_v0`.
    #[serde(skip_serializing_if = "Option::is_none")]
    pub(crate) ens_v1: Option<EnsV1>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub(crate) migrated_at: Option<String>,
    pub(crate) status: Status,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub(crate) unsupported_reason: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub(crate) failure_reason: Option<String>,
    #[serde(skip_serializing_if = "Vec::is_empty")]
    pub(crate) unsupported_fields: Vec<String>,
}
