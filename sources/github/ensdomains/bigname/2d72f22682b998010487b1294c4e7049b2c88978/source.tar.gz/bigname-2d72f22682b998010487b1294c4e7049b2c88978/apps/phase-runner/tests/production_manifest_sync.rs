#[allow(dead_code)]
mod support;

use std::{fs, time::Duration};

use alloy_primitives::keccak256;
use anyhow::{Context, Result};
use bigname_ingest::load_persisted_watch_filter;
use bigname_manifests::{load_repository, registry_announcement_topic0, sync_schema_v2_repository};
use phase_runner::{
    INTERPRETER_CONTENT_HASH,
    capacity::CapacityGuard,
    config::{CapacityConfig, ChainConfig, SeedBasis, SourceConfig, TimingConfig},
    error::ErrorKind,
    heads::BlockMarker,
    phase::{BlockRange, PhaseName, PhaseSet, RunMode},
    phase_lock::PhaseLock,
    rewind::rewind_to_ancestor,
    runner::{PhaseRunner, RedoPhase},
    state::{PhaseStore, StartDisposition},
};
use sqlx::types::Uuid;
use tokio_util::sync::CancellationToken;

use support::ScratchDatabase;

type AddressEpoch = (i64, Uuid, Option<i64>, Option<i64>, bool);

struct WatchManifestFixture {
    root: std::path::PathBuf,
    chain_id: String,
    source_family: String,
}

/// The registry and resolver family pair a discovered-resolver fixture declares.
#[derive(Clone, Copy)]
enum ResolverPair {
    /// The registry's `resolver` rule is address-admitting for manifest synchronization.
    EnsV1,
    /// The registry's `resolver` rule is topology-only; resolvers admit themselves.
    EnsV2,
}

impl ResolverPair {
    fn registry_family(self) -> &'static str {
        match self {
            Self::EnsV1 => "ens_v1_registry_l1",
            Self::EnsV2 => "ens_v2_registry_l1",
        }
    }

    fn resolver_family(self) -> &'static str {
        match self {
            Self::EnsV1 => "ens_v1_resolver_l1",
            Self::EnsV2 => "ens_v2_resolver_l1",
        }
    }

    fn registry_events(self) -> &'static str {
        match self {
            Self::EnsV1 => {
                r#"[[abi.events]]
name = "Transfer"
fragment = "event Transfer(bytes32 indexed node, address owner)"
emitter_roles = ["registry"]
normalized_events = ["AuthorityTransferred"]

[[abi.events]]
name = "NewResolver"
fragment = "event NewResolver(bytes32 indexed node, address resolver)"
emitter_roles = ["registry"]
normalized_events = ["ResolverChanged"]
"#
            }
            Self::EnsV2 => {
                r#"[[abi.events]]
name = "RegistryCreated"
fragment = "event RegistryCreated()"
emitter_roles = ["registry"]
normalized_events = ["RegistryCreated"]

[[abi.events]]
name = "ResolverUpdated"
fragment = "event ResolverUpdated(uint256 indexed tokenId, address indexed resolver, address indexed sender)"
emitter_roles = ["registry"]
normalized_events = ["ResolverChanged"]
"#
            }
        }
    }
}

impl WatchManifestFixture {
    fn new(chain_id: &str) -> Result<Self> {
        Self::with_source_family(chain_id, "test_events")
    }

    fn with_source_family(chain_id: &str, source_family: &str) -> Result<Self> {
        let root =
            std::env::temp_dir().join(format!("bigname-manifest-widening-{}", Uuid::new_v4()));
        fs::create_dir_all(root.join("test").join(source_family))?;
        Ok(Self {
            root,
            chain_id: chain_id.to_owned(),
            source_family: source_family.to_owned(),
        })
    }

    fn write(&self, include_new_event: bool, include_new_contract: bool) -> Result<()> {
        self.write_with_start(include_new_event, include_new_contract, 0)
    }

    fn write_with_start(
        &self,
        include_new_event: bool,
        include_new_contract: bool,
        source_a_start: u64,
    ) -> Result<()> {
        let new_event = include_new_event.then_some(
            r#"
[[abi.events]]
name = "Widened"
fragment = "event Widened(bytes32 indexed value)"
emitter_roles = ["source_a"]
normalized_events = []
status = "supported"
"#,
        );
        let new_contract = include_new_contract.then_some(
            r#"
[[contracts]]
role = "source_b"
address = "0x0000000000000000000000000000000000000006"
proxy_kind = "none"
start_block = 0
"#,
        );
        let registry_created = (self.source_family == "ens_v2_registry_l1").then_some(
            r#"[[abi.events]]
name = "RegistryCreated"
fragment = "event RegistryCreated()"
emitter_roles = ["source_a"]
normalized_events = []
status = "supported"
"#,
        );
        let manifest = format!(
            r#"manifest_version = 1
namespace = "test"
source_family = "{}"
chain = "{}"
deployment_epoch = "fixture"
rollout_status = "active"
normalizer_version = "ensip15@ens-normalize-0.1.1"
roots = []
discovery_rules = []

[capability_flags]

[[contracts]]
role = "source_a"
address = "0x0000000000000000000000000000000000000004"
proxy_kind = "none"
start_block = {}
{}

[[abi.events]]
name = "Transfer"
fragment = "event Transfer(address indexed from, address indexed to, uint256 value)"
emitter_roles = ["source_a"]
normalized_events = []
status = "supported"
{}
{}
"#,
            self.source_family,
            self.chain_id,
            source_a_start,
            new_contract.unwrap_or_default(),
            registry_created.unwrap_or_default(),
            new_event.unwrap_or_default(),
        );
        fs::write(
            self.root
                .join("test")
                .join(&self.source_family)
                .join("v1.toml"),
            manifest,
        )?;
        Ok(())
    }

    fn add_discovery_rule(&self, edge_kind: &str) -> Result<()> {
        self.add_discovery_rule_from_role(edge_kind, "source_a")
    }

    fn add_discovery_rule_from_role(&self, edge_kind: &str, from_role: &str) -> Result<()> {
        let path = self
            .root
            .join("test")
            .join(&self.source_family)
            .join("v1.toml");
        let manifest = fs::read_to_string(&path)?.replace(
            "discovery_rules = []",
            &format!(
                r#"[[discovery_rules]]
edge_kind = "{edge_kind}"
from_role = "{from_role}"
admission = "reachable_from_root""#
            ),
        );
        fs::write(path, manifest)?;
        Ok(())
    }

    fn replace_source_a(&self, address: &str, start_block: u64) -> Result<()> {
        let path = self
            .root
            .join("test")
            .join(&self.source_family)
            .join("v1.toml");
        let prior = r#"address = "0x0000000000000000000000000000000000000004"
proxy_kind = "none"
start_block = 0"#;
        let replacement = format!(
            r#"address = "{address}"
proxy_kind = "none"
start_block = {start_block}"#
        );
        let manifest = fs::read_to_string(&path)?.replacen(prior, &replacement, 1);
        fs::write(path, manifest)?;
        Ok(())
    }

    fn add_source_a_root(&self, address: &str, start_block: u64) -> Result<()> {
        let path = self
            .root
            .join("test")
            .join(&self.source_family)
            .join("v1.toml");
        let root = format!(
            r#"[[roots]]
name = "source_a"
address = "{address}"
start_block = {start_block}"#
        );
        let manifest = fs::read_to_string(&path)?.replace("roots = []", &root);
        fs::write(path, manifest)?;
        Ok(())
    }

    fn move_source_a_root_start(&self, from: u64, to: u64) -> Result<()> {
        let path = self
            .root
            .join("test")
            .join(&self.source_family)
            .join("v1.toml");
        let manifest = fs::read_to_string(&path)?.replacen(
            &format!("start_block = {from}"),
            &format!("start_block = {to}"),
            1,
        );
        fs::write(path, manifest)?;
        Ok(())
    }

    fn write_cross_namespace_pair(
        &self,
        earlier_start: u64,
        later_start: u64,
        edge_kind: &str,
    ) -> Result<()> {
        self.write_namespace_emitter("alpha", earlier_start, edge_kind, true)?;
        self.write_namespace_emitter("zeta", later_start, edge_kind, false)
    }

    fn write_cross_namespace_resolver_sources(
        &self,
        alpha: Option<(&str, u64)>,
        zeta: Option<(&str, u64)>,
    ) -> Result<()> {
        self.write_namespace_resolver_source(
            "alpha",
            "0x0000000000000000000000000000000000000005",
            alpha,
        )?;
        self.write_namespace_resolver_source(
            "zeta",
            "0x0000000000000000000000000000000000000007",
            zeta,
        )
    }

    fn write_namespace_resolver_source(
        &self,
        namespace: &str,
        event_source: &str,
        source: Option<(&str, u64)>,
    ) -> Result<()> {
        let source = source.map_or_else(String::new, |(address, start)| {
            format!(
                r#"[[contracts]]
role = "source_a"
address = "{address}"
proxy_kind = "none"
start_block = {start}"#
            )
        });
        let manifest = format!(
            r#"manifest_version = 1
namespace = "{namespace}"
source_family = "{}"
chain = "{}"
deployment_epoch = "fixture"
rollout_status = "active"
normalizer_version = "ensip15@ens-normalize-0.1.1"
roots = []

[capability_flags]

[[contracts]]
role = "event_source"
address = "{event_source}"
proxy_kind = "none"
start_block = 0

{source}

[[discovery_rules]]
edge_kind = "resolver"
from_role = "source_a"
admission = "reachable_from_root"

[[abi.events]]
name = "Transfer"
fragment = "event Transfer(address indexed from, address indexed to, uint256 value)"
emitter_roles = ["event_source"]
normalized_events = []
status = "supported"
"#,
            self.source_family, self.chain_id,
        );
        let directory = self.root.join(namespace).join(&self.source_family);
        fs::create_dir_all(&directory)?;
        fs::write(directory.join("v1.toml"), manifest)?;
        Ok(())
    }

    fn write_namespace_emitter(
        &self,
        namespace: &str,
        start: u64,
        edge_kind: &str,
        as_root: bool,
    ) -> Result<()> {
        let (roots, contracts, emitter_role) = if as_root {
            (
                format!(
                    r#"[[roots]]
name = "source_a"
address = "0x0000000000000000000000000000000000000004"
start_block = {start}"#
                ),
                r#"[[contracts]]
role = "event_source"
address = "0x0000000000000000000000000000000000000005"
proxy_kind = "none"
start_block = 100"#
                    .to_owned(),
                "event_source",
            )
        } else {
            (
                "roots = []".to_owned(),
                format!(
                    r#"[[contracts]]
role = "source_a"
address = "0x0000000000000000000000000000000000000004"
proxy_kind = "none"
start_block = {start}"#
                ),
                "source_a",
            )
        };
        let manifest = format!(
            r#"manifest_version = 1
namespace = "{namespace}"
source_family = "{}"
chain = "{}"
deployment_epoch = "fixture"
rollout_status = "active"
normalizer_version = "ensip15@ens-normalize-0.1.1"
{roots}

[capability_flags]

{contracts}

[[discovery_rules]]
edge_kind = "{edge_kind}"
from_role = "source_a"
admission = "reachable_from_root"

[[abi.events]]
name = "Transfer"
fragment = "event Transfer(address indexed from, address indexed to, uint256 value)"
emitter_roles = ["{emitter_role}"]
normalized_events = []
status = "supported"
"#,
            self.source_family, self.chain_id,
        );
        let directory = self.root.join(namespace).join(&self.source_family);
        fs::create_dir_all(&directory)?;
        fs::write(directory.join("v1.toml"), manifest)?;
        Ok(())
    }

    /// ENSv2 registry and resolver manifests. The registry's `resolver` rule is topology-only:
    /// `ResolverUpdated` pointers admit nothing, so manifest synchronization leaves the rule out
    /// of discovery-rule widening classification.
    fn write_discovered_resolver_namespaces(
        &self,
        widening_namespace: &str,
        peer_namespace: &str,
        widening_has_address_changed: bool,
    ) -> Result<()> {
        self.write_resolver_pair_namespaces(
            ResolverPair::EnsV2,
            widening_namespace,
            peer_namespace,
            widening_has_address_changed,
        )
    }

    /// ENSv1 registry and resolver manifests. Their `resolver` rule is still classified as
    /// address-admitting, so these carry the discovery-rule widening and deployment-epoch cases.
    fn write_admitting_resolver_namespaces(
        &self,
        widening_namespace: &str,
        peer_namespace: &str,
        widening_has_address_changed: bool,
    ) -> Result<()> {
        self.write_resolver_pair_namespaces(
            ResolverPair::EnsV1,
            widening_namespace,
            peer_namespace,
            widening_has_address_changed,
        )
    }

    fn write_resolver_pair_namespaces(
        &self,
        pair: ResolverPair,
        widening_namespace: &str,
        peer_namespace: &str,
        widening_has_address_changed: bool,
    ) -> Result<()> {
        let registry_family = pair.registry_family();
        let resolver_family = pair.resolver_family();
        let registry_events = pair.registry_events();
        for (namespace, registry_address, has_address_changed) in [
            (
                widening_namespace,
                "0x0000000000000000000000000000000000000004",
                widening_has_address_changed,
            ),
            (
                peer_namespace,
                "0x0000000000000000000000000000000000000006",
                true,
            ),
        ] {
            let registry = format!(
                r#"manifest_version = 2
namespace = "{namespace}"
source_family = "{registry_family}"
chain = "{}"
deployment_epoch = "fixture"
rollout_status = "active"
normalizer_version = "ensip15@ens-normalize-0.1.1"
roots = []

[capability_flags]

[[contracts]]
role = "registry"
address = "{registry_address}"
proxy_kind = "none"
start_block = 0

[[discovery_rules]]
edge_kind = "resolver"
from_role = "registry"
admission = "reachable_from_root"

{registry_events}"#,
                self.chain_id,
            );
            let registry_dir = self.root.join(namespace).join(registry_family);
            fs::create_dir_all(&registry_dir)?;
            fs::write(registry_dir.join("v2.toml"), registry)?;

            let address_changed = has_address_changed.then_some(
                r#"
[[abi.events]]
name = "AddressChanged"
fragment = "event AddressChanged(bytes32 indexed node, uint256 coinType, bytes newAddress)"
normalized_events = []
"#,
            );
            let resolver = format!(
                r#"manifest_version = 2
namespace = "{namespace}"
source_family = "{resolver_family}"
chain = "{}"
deployment_epoch = "fixture"
rollout_status = "active"
normalizer_version = "ensip15@ens-normalize-0.1.1"
roots = []
contracts = []
discovery_rules = []

[capability_flags]

[[abi.events]]
name = "TextChanged"
fragment = "event TextChanged(bytes32 indexed node, string indexed indexedKey, string key, string value)"
normalized_events = []
{}
"#,
                self.chain_id,
                address_changed.unwrap_or_default(),
            );
            let resolver_dir = self.root.join(namespace).join(resolver_family);
            fs::create_dir_all(&resolver_dir)?;
            fs::write(resolver_dir.join("v2.toml"), resolver)?;
        }
        Ok(())
    }

    fn set_deployment_epoch(
        &self,
        namespace: &str,
        family: &str,
        from: &str,
        to: &str,
    ) -> Result<()> {
        let path = self.root.join(namespace).join(family).join("v2.toml");
        let manifest = fs::read_to_string(&path)?.replacen(
            &format!("deployment_epoch = \"{from}\""),
            &format!("deployment_epoch = \"{to}\""),
            1,
        );
        fs::write(path, manifest)?;
        Ok(())
    }

    fn replace_deployment_epoch(
        &self,
        namespace: &str,
        family: &str,
        from: &str,
        to: &str,
    ) -> Result<()> {
        let directory = self.root.join(namespace).join(family);
        let old_path = directory.join("v2.toml");
        let manifest = fs::read_to_string(&old_path)?
            .replacen("manifest_version = 2", "manifest_version = 3", 1)
            .replacen(
                &format!("deployment_epoch = \"{from}\""),
                &format!("deployment_epoch = \"{to}\""),
                1,
            );
        fs::write(directory.join("v3.toml"), manifest)?;
        fs::remove_file(old_path)?;
        Ok(())
    }

    fn rotate_manifest_version(&self, namespace: &str, family: &str) -> Result<()> {
        let directory = self.root.join(namespace).join(family);
        let old_path = directory.join("v2.toml");
        let manifest = fs::read_to_string(&old_path)?.replacen(
            "manifest_version = 2",
            "manifest_version = 3",
            1,
        );
        fs::write(directory.join("v3.toml"), manifest)?;
        fs::remove_file(old_path)?;
        Ok(())
    }

    fn set_contract_start(&self, namespace: &str, family: &str, from: u64, to: u64) -> Result<()> {
        let path = self.root.join(namespace).join(family).join("v2.toml");
        let manifest = fs::read_to_string(&path)?.replacen(
            &format!("start_block = {from}"),
            &format!("start_block = {to}"),
            1,
        );
        fs::write(path, manifest)?;
        Ok(())
    }

    /// Moves the declaration and its events to a role the `resolver` rule does not name, leaving
    /// the rule without a matching declaration.
    fn use_only_undeclared_rule_role(&self, registry_family: &str) -> Result<()> {
        let path = self.root.join("test").join(registry_family).join("v2.toml");
        let manifest = fs::read_to_string(&path)?
            .replacen(r#"role = "registry""#, r#"role = "event_source""#, 1)
            .replace(
                r#"emitter_roles = ["registry"]"#,
                r#"emitter_roles = ["event_source"]"#,
            );
        fs::write(path, manifest)?;
        Ok(())
    }

    fn add_test_registry_announcement_rule(&self) -> Result<()> {
        let path = self.root.join("test/ens_v2_registry_l1/v2.toml");
        let manifest = fs::read_to_string(&path)?.replacen(
            "[[abi.events]]",
            r#"[[discovery_rules]]
edge_kind = "registry_announcement"
from_role = "registry"
admission = "reachable_from_root"

[[abi.events]]"#,
            1,
        );
        fs::write(path, manifest)?;
        Ok(())
    }

    fn set_test_registry_discovery_events(&self, present: bool) -> Result<()> {
        let path = self.root.join("test/ens_v2_registry_l1/v2.toml");
        let mut manifest = fs::read_to_string(&path)?;
        if present {
            manifest.push_str(
                r#"
[[abi.events]]
name = "RegistryCreated"
fragment = "event RegistryCreated()"
emitter_roles = ["event_source"]
normalized_events = ["RegistryCreated"]

[[abi.events]]
name = "ResolverUpdated"
fragment = "event ResolverUpdated(uint256 indexed tokenId, address indexed resolver, address indexed sender)"
emitter_roles = ["event_source"]
normalized_events = ["ResolverChanged"]
"#,
            );
        } else {
            manifest = manifest
                .split_once("[[abi.events]]")
                .context("test registry has no discovery event section")?
                .0
                .to_owned();
        }
        fs::write(path, manifest)?;
        Ok(())
    }

    fn use_test_root_source(&self) -> Result<()> {
        let registry_dir = self.root.join("test/ens_v2_registry_l1");
        let root_dir = self.root.join("test/ens_v2_root_l1");
        let manifest = fs::read_to_string(registry_dir.join("v2.toml"))?.replacen(
            "source_family = \"ens_v2_registry_l1\"",
            "source_family = \"ens_v2_root_l1\"",
            1,
        );
        fs::create_dir_all(&root_dir)?;
        fs::write(root_dir.join("v2.toml"), manifest)?;
        fs::remove_dir_all(registry_dir)?;
        Ok(())
    }
}

impl Drop for WatchManifestFixture {
    fn drop(&mut self) {
        let _ = fs::remove_dir_all(&self.root);
    }
}

fn write_root_resolver_rule_fixture(
    fixture: &WatchManifestFixture,
    include_resolver_rule: bool,
) -> Result<()> {
    fixture.write_discovered_resolver_namespaces("test", "peer", true)?;
    fs::remove_dir_all(fixture.root.join("peer"))?;
    fixture.use_test_root_source()?;
    let path = fixture.root.join("test/ens_v2_root_l1/v2.toml");
    let resolver_rule = r#"[[discovery_rules]]
edge_kind = "resolver"
from_role = "root_registry"
admission = "reachable_from_root""#;
    let subregistry_rule = r#"[[discovery_rules]]
edge_kind = "subregistry"
from_role = "root_registry"
admission = "reachable_from_root""#;
    let rules = if include_resolver_rule {
        format!("{subregistry_rule}\n\n{resolver_rule}")
    } else {
        subregistry_rule.to_owned()
    };
    let manifest = fs::read_to_string(&path)?
        .replace(
            r#"[[discovery_rules]]
edge_kind = "resolver"
from_role = "registry"
admission = "reachable_from_root""#,
            &rules,
        )
        .replace(r#"role = "registry""#, r#"role = "root_registry""#)
        .replace(
            r#"emitter_roles = ["registry"]"#,
            r#"emitter_roles = ["root_registry"]"#,
        );
    fs::write(path, manifest)?;
    Ok(())
}

fn loopback_runner(scratch: &ScratchDatabase, instance_id: &str) -> Result<PhaseRunner> {
    Ok(PhaseRunner::new(
        scratch.runner(),
        PhaseSet::loopback(),
        CapacityGuard::system(CapacityConfig::default()),
        instance_id,
        TimingConfig {
            initial_backoff: Duration::from_millis(1),
            maximum_backoff: Duration::from_millis(4),
            live_poll_interval: Duration::from_millis(1),
        },
    )?)
}

#[tokio::test]
async fn checked_in_sepolia_resolvers_sync_fresh_with_exact_addresses_and_family_watches()
-> Result<()> {
    let scratch = ScratchDatabase::create("production_manifest_sepolia_v1_resolver_fresh").await?;
    let root = checked_in_sepolia_root();
    let repository = load_repository(&root)?;
    sync_schema_v2_repository(scratch.pool(), &repository).await?;

    let contracts: Vec<(String, String, Option<i64>)> = sqlx::query_as(
        "SELECT declaration.role, lower(address.address), address.active_from_block_number
         FROM manifest_versions manifest
         JOIN manifest_contract_instances declaration ON declaration.manifest_id = manifest.manifest_id
         JOIN contract_instances instance ON instance.contract_instance_id = declaration.contract_instance_id
         JOIN contract_instance_addresses address
           ON address.contract_instance_id = instance.contract_instance_id
          AND address.deactivated_at IS NULL
         WHERE manifest.chain_id = 'ethereum-sepolia'
           AND manifest.namespace = 'ens'
           AND manifest.source_family = 'ens_v1_resolver_l1'
           AND manifest.rollout_status = 'active'
         ORDER BY declaration.role",
    )
    .fetch_all(scratch.pool())
    .await?;
    assert_eq!(
        contracts,
        vec![
            (
                "public_resolver".into(),
                "0xe99638b40e4fff0129d56f03b55b6bbc4bbe49b5".into(),
                Some(8_580_001)
            ),
            (
                "public_resolver_0ceec52".into(),
                "0x0ceec524b2807841739d3b5e161f5bf1430ffa48".into(),
                Some(3_790_166)
            ),
            (
                "public_resolver_8948458".into(),
                "0x8948458626811dd0c23eb25cc74291247077cc51".into(),
                Some(0)
            ),
            (
                "public_resolver_8fade66".into(),
                "0x8fade66b79cc9f707ab26799354482eb93a5b7dd".into(),
                Some(0)
            ),
        ]
    );

    let resolver = repository
        .manifests()
        .iter()
        .find(|loaded| loaded.manifest.source_family == "ens_v1_resolver_l1")
        .expect("checked-in Sepolia resolver family");
    let filter =
        load_persisted_watch_filter(scratch.pool(), "ethereum-sepolia", 0, 9_000_000).await?;
    for event in &resolver.manifest.abi.events {
        let signature = event.parsed_event_view()?.canonical_signature();
        let topic = format!("{:#x}", keccak256(signature.as_bytes()));
        if bigname_manifests::is_address_scoped_approval(
            &resolver.manifest.source_family,
            &signature,
        ) {
            assert!(!filter.includes("0x1111111111111111111111111111111111111111", &topic, 0));
            for contract in &resolver.manifest.contracts {
                let block = i64::try_from(contract.start_block.unwrap_or(0))?;
                assert_eq!(
                    filter.includes(&contract.address, &topic, block),
                    event.emitter_roles.contains(&contract.role),
                    "{} approval scope must follow declared roles",
                    contract.role
                );
            }
        } else {
            assert!(filter.includes("0x1111111111111111111111111111111111111111", &topic, 0));
        }
    }
    assert_eq!(
        required_ingest_redo(scratch.pool(), "ethereum-sepolia").await?,
        None
    );
    scratch.cleanup().await
}

#[tokio::test]
async fn approval_event_widening_stamps_retained_history_and_is_fresh_sync_safe() -> Result<()> {
    let chain_id = "manifest-approval-event-widening";
    let fixture = WatchManifestFixture::with_source_family(chain_id, "ens_v1_registry_l1")?;
    let path = fixture.root.join("test/ens_v1_registry_l1/v1.toml");
    let write_manifest = |include_approval: bool| -> Result<()> {
        let approval = include_approval.then_some(
            r#"
[[abi.events]]
name = "ApprovalForAll"
fragment = "event ApprovalForAll(address indexed owner, address indexed operator, bool approved)"
emitter_roles = ["registry"]
normalized_events = []
"#,
        );
        fs::write(
            &path,
            format!(
                r#"manifest_version = 1
namespace = "test"
source_family = "ens_v1_registry_l1"
chain = "{chain_id}"
deployment_epoch = "fixture"
rollout_status = "active"
normalizer_version = "ensip15@ens-normalize-0.1.1"
roots = []
discovery_rules = []

[capability_flags]

[[contracts]]
role = "registry"
address = "0x0000000000000000000000000000000000000004"
proxy_kind = "none"
start_block = 7

[[abi.events]]
name = "NewTTL"
fragment = "event NewTTL(bytes32 indexed node, uint64 ttl)"
emitter_roles = ["registry"]
normalized_events = []
{}
"#,
                approval.unwrap_or_default()
            ),
        )?;
        Ok(())
    };

    let scratch = ScratchDatabase::create("production_manifest_approval_event_widening").await?;
    write_manifest(false)?;
    sync_schema_v2_repository(scratch.pool(), &load_repository(&fixture.root)?).await?;
    seed_completed_ingest_range_through(&scratch, chain_id, 20).await?;
    sqlx::query(
        "UPDATE chain_phase_state
         SET phase_status = 'running', redo_in_progress = true, redo_mode = 'redo',
             redo_previous_phase_status = 'completed',
             redo_previous_started_at = started_at,
             redo_previous_finished_at = finished_at,
             redo_from_block_number = 10, redo_to_block_number = 20,
             redo_current_block_number = 15,
             redo_current_block_hash = 'interrupted-approval-redo',
             redo_manifest_authority_fingerprint = repeat('a', 64),
             last_error = 'interrupted prior redo',
             started_at = now(), finished_at = NULL
         WHERE chain_id = $1 AND phase_name = 'ingest'",
    )
    .bind(chain_id)
    .execute(scratch.pool())
    .await?;

    write_manifest(true)?;
    let desired = load_repository(&fixture.root)?;
    sync_schema_v2_repository(scratch.pool(), &desired).await?;
    assert_eq!(
        required_ingest_redo(scratch.pool(), chain_id).await?,
        Some((7, 20))
    );
    let state: (Option<i64>, Option<String>, String) = sqlx::query_as(
        "SELECT redo_current_block_number, redo_manifest_authority_fingerprint, last_error
         FROM chain_phase_state WHERE chain_id = $1 AND phase_name = 'ingest'",
    )
    .bind(chain_id)
    .fetch_one(scratch.pool())
    .await?;
    assert_eq!(state.0, None, "widening must reset interrupted progress");
    assert_eq!(
        state.1, None,
        "widening must discard the old watch fingerprint"
    );
    assert_eq!(
        state.2,
        "required downstream redo: manifest watch plan widened over an already-ingested range"
    );
    sync_schema_v2_repository(scratch.pool(), &desired).await?;
    assert_eq!(
        required_ingest_redo(scratch.pool(), chain_id).await?,
        Some((7, 20)),
        "an unchanged second sync must be idempotent"
    );

    let fresh = ScratchDatabase::create("production_manifest_approval_event_fresh").await?;
    write_manifest(false)?;
    sync_schema_v2_repository(fresh.pool(), &load_repository(&fixture.root)?).await?;
    write_manifest(true)?;
    sync_schema_v2_repository(fresh.pool(), &load_repository(&fixture.root)?).await?;
    assert_eq!(
        required_ingest_redo(fresh.pool(), chain_id).await?,
        None,
        "a fresh database has no retained history to redo"
    );

    fresh.cleanup().await?;
    scratch.cleanup().await
}

#[tokio::test]
async fn checked_in_sepolia_resolver_admission_clamps_retained_redo_to_cursor_floor() -> Result<()>
{
    let scratch =
        ScratchDatabase::create("production_manifest_sepolia_v1_resolver_retained").await?;
    let desired_root = checked_in_sepolia_root();
    let baseline_root = copy_profile_without_resolver(&desired_root)?;
    let baseline = load_repository(&baseline_root)?;
    sync_schema_v2_repository(scratch.pool(), &baseline).await?;
    seed_completed_ingest_range_through(&scratch, "ethereum-sepolia", 9_000_000).await?;
    sqlx::query(
        "UPDATE ingest_cursors SET start_block_number = 1_000_000
         WHERE chain_id = 'ethereum-sepolia'",
    )
    .execute(scratch.pool())
    .await?;
    sqlx::query(
        "UPDATE chain_phase_state SET input_content_hash = $1
         WHERE chain_id = 'ethereum-sepolia' AND phase_name IN ('interpret', 'project')",
    )
    .bind(INTERPRETER_CONTENT_HASH)
    .execute(scratch.pool())
    .await?;
    let marker_before = interpret_input_hash(scratch.pool(), "ethereum-sepolia").await?;

    sync_schema_v2_repository(scratch.pool(), &load_repository(&desired_root)?).await?;
    let marker_after = interpret_input_hash(scratch.pool(), "ethereum-sepolia").await?;
    assert_ne!(marker_after, marker_before);
    assert!(marker_after.starts_with("manifest-authority:"));
    assert_eq!(
        required_ingest_redo(scratch.pool(), "ethereum-sepolia").await?,
        Some((1_000_000, 9_000_000))
    );
    let reason: String = sqlx::query_scalar(
        "SELECT last_error FROM chain_phase_state
         WHERE chain_id = 'ethereum-sepolia' AND phase_name = 'ingest'",
    )
    .fetch_one(scratch.pool())
    .await?;
    assert_eq!(
        reason,
        "required downstream redo: manifest watch plan widened over an already-ingested range"
    );
    let text_topic = format!(
        "{:#x}",
        keccak256(b"TextChanged(bytes32,string,string,string)")
    );
    let filter =
        load_persisted_watch_filter(scratch.pool(), "ethereum-sepolia", 1_000_000, 9_000_000)
            .await?;
    let zero_filter = load_persisted_watch_filter(scratch.pool(), "ethereum-sepolia", 0, 0).await?;
    assert!(zero_filter.includes("0x8948458626811dd0c23eb25cc74291247077cc51", &text_topic, 0));
    assert!(zero_filter.includes("0x8fade66b79cc9f707ab26799354482eb93a5b7dd", &text_topic, 0));
    for address in [
        "0xe99638b40e4fff0129d56f03b55b6bbc4bbe49b5",
        "0x8948458626811dd0c23eb25cc74291247077cc51",
        "0x8fade66b79cc9f707ab26799354482eb93a5b7dd",
        "0x0ceec524b2807841739d3b5e161f5bf1430ffa48",
    ] {
        let block = match address {
            "0xe99638b40e4fff0129d56f03b55b6bbc4bbe49b5" => 8_580_001,
            "0x0ceec524b2807841739d3b5e161f5bf1430ffa48" => 3_790_166,
            _ => 1_000_000,
        };
        assert!(filter.includes(address, &text_topic, block));
    }
    let chain = ChainConfig::new(
        "ethereum-sepolia",
        vec![SourceConfig::new(
            "ethereum-sepolia",
            "rpc",
            "rpc",
            SeedBasis::NewSignatureRange,
            1_000_000,
            "http://127.0.0.1:1",
        )?],
        false,
    )?;
    let error = tokio::time::timeout(
        Duration::from_secs(10),
        loopback_runner(&scratch, "sepolia-v1-resolver-retained-runner")?
            .run_chain(&chain, CancellationToken::new()),
    )
    .await
    .context("outstanding resolver admission redo did not fence derivation")?
    .expect_err("derivation must wait for the required Ingest redo");
    assert!(error.to_string().contains("redo --chain ethereum-sepolia"));

    fs::remove_dir_all(&baseline_root)?;
    scratch.cleanup().await
}

#[tokio::test]
async fn raising_a_covered_implementation_start_stamps_no_ingest_redo() -> Result<()> {
    let scratch =
        ScratchDatabase::create("production_manifest_sepolia_implementation_start_raise").await?;
    let desired_root = checked_in_sepolia_root();
    let baseline_root = copy_profile_with_v2_resolver(&desired_root, |manifest| {
        manifest.replacen("start_block = 11820406, ", "", 1)
    })?;
    sync_schema_v2_repository(scratch.pool(), &load_repository(&baseline_root)?).await?;
    assert_eq!(
        compiled_implementation_starts(scratch.pool()).await?,
        vec![(SEPOLIA_PERMISSIONED_RESOLVER_IMPL.to_owned(), 0)]
    );
    seed_completed_ingest_range_through(&scratch, "ethereum-sepolia", 12_000_000).await?;

    sync_schema_v2_repository(scratch.pool(), &load_repository(&desired_root)?).await?;
    assert_eq!(
        compiled_implementation_starts(scratch.pool()).await?,
        vec![(SEPOLIA_PERMISSIONED_RESOLVER_IMPL.to_owned(), 11_820_406)]
    );
    assert_eq!(
        required_ingest_redo(scratch.pool(), "ethereum-sepolia").await?,
        None,
        "ingest already covers the implementation from block zero"
    );

    fs::remove_dir_all(&baseline_root)?;
    scratch.cleanup().await
}

#[tokio::test]
async fn a_new_implementation_widens_from_its_declared_start() -> Result<()> {
    const ADDED: &str = "0x00000000000000000000000000000000000000ee";
    for (start, expected_from) in [(Some(11_900_000), 11_900_000), (None, 0)] {
        let scratch =
            ScratchDatabase::create("production_manifest_sepolia_implementation_widening").await?;
        sync_schema_v2_repository(scratch.pool(), &load_repository(checked_in_sepolia_root())?)
            .await?;
        seed_completed_ingest_range_through(&scratch, "ethereum-sepolia", 12_000_000).await?;
        let desired_root = copy_profile_with_v2_resolver(&checked_in_sepolia_root(), |manifest| {
            let start = start.map_or_else(String::new, |start| format!(", start_block = {start}"));
            manifest.replacen(
                "resolver_implementations = [ ",
                &format!(
                    "resolver_implementations = [ {{ role = \"permissioned_resolver\", address = \"{ADDED}\"{start} }}, "
                ),
                1,
            )
        })?;

        sync_schema_v2_repository(scratch.pool(), &load_repository(&desired_root)?).await?;
        assert_eq!(
            required_ingest_redo(scratch.pool(), "ethereum-sepolia").await?,
            Some((expected_from, 12_000_000)),
            "implementation start {start:?}"
        );

        fs::remove_dir_all(&desired_root)?;
        scratch.cleanup().await?;
    }
    Ok(())
}

#[tokio::test]
async fn widening_an_ingested_manifest_event_blocks_initial_derivation_until_reingest() -> Result<()>
{
    let scratch = ScratchDatabase::create("production_manifest_sync_ingest_widening_gap").await?;
    let chain_id = "manifest-widening-gap";
    let fixture = WatchManifestFixture::new(chain_id)?;
    fixture.write(false, false)?;
    sync_schema_v2_repository(scratch.pool(), &load_repository(&fixture.root)?).await?;

    let chain = seed_completed_ingest_range(&scratch, chain_id).await?;

    fixture.write(true, false)?;
    sync_schema_v2_repository(scratch.pool(), &load_repository(&fixture.root)?).await?;
    let raw_new_event_count: i64 = sqlx::query_scalar(
        "SELECT count(*) FROM raw_logs
         WHERE chain_id = $1",
    )
    .bind(chain_id)
    .fetch_one(scratch.pool())
    .await?;
    assert_eq!(raw_new_event_count, 0);
    assert_eq!(
        required_ingest_redo(scratch.pool(), chain_id).await?,
        Some((0, 1))
    );

    let runner = loopback_runner(&scratch, "manifest-widening-gap-runner")?;
    let error = tokio::time::timeout(
        Duration::from_secs(10),
        runner.run_chain(&chain, CancellationToken::new()),
    )
    .await
    .context("manifest widening allowed derivation over raw facts without the new event")?
    .expect_err("manifest widening must block derivation until the explicit Ingest redo");
    assert!(error.to_string().contains("redo --chain"));

    scratch.cleanup().await
}

#[tokio::test]
async fn interrupted_recompute_resume_waits_for_required_ingest() -> Result<()> {
    let scratch = ScratchDatabase::create("production_manifest_recompute_ingest_fence").await?;
    let chain_id = "manifest-recompute-ingest-fence";
    let fixture = WatchManifestFixture::new(chain_id)?;
    fixture.write(false, false)?;
    sync_schema_v2_repository(scratch.pool(), &load_repository(&fixture.root)?).await?;
    let chain = seed_completed_ingest_range(&scratch, chain_id).await?;

    sqlx::query(
        "UPDATE chain_phase_state
         SET phase_status = 'running', redo_in_progress = true,
             current_block_number = 1, current_block_hash = $2,
             target_block_number = 1, target_block_hash = $2, input_content_hash = $3,
             redo_mode = CASE phase_name WHEN 'interpret' THEN 'recompute_flags' ELSE 'redo' END,
             redo_previous_phase_status = 'completed', redo_previous_started_at = now(),
             redo_previous_finished_at = now(), redo_from_block_number = 0, redo_to_block_number = 1,
             last_error = CASE phase_name
                 WHEN 'interpret' THEN 'injected interrupted recompute-flags'
                 ELSE 'ordinary Project redo remains pending' END,
             started_at = now(), finished_at = NULL
         WHERE chain_id = $1 AND phase_name IN ('interpret', 'project')",
    )
    .bind(chain_id)
    .bind(format!("{chain_id}-manifest-sync-head-1"))
    .bind(INTERPRETER_CONTENT_HASH)
    .execute(scratch.pool())
    .await?;

    fixture.write(true, false)?;
    sync_schema_v2_repository(scratch.pool(), &load_repository(&fixture.root)?).await?;
    assert_eq!(
        required_ingest_redo(scratch.pool(), chain_id).await?,
        Some((0, 1))
    );
    let marker_before = interpret_input_hash(scratch.pool(), chain_id).await?;
    assert!(marker_before.starts_with("manifest-authority:"));

    let resume_error = loopback_runner(&scratch, "manifest-recompute-ingest-fence-resume")?
        .redo(
            &chain,
            RedoPhase::RecomputeFlags,
            BlockRange::new(0, 1)?,
            CancellationToken::new(),
        )
        .await
        .expect_err("recompute-flags must wait for the required Ingest redo");
    let command = "rerun `phase-runner redo --chain manifest-recompute-ingest-fence --phase \
                   ingest --from-block 0 --to-block 1`";
    assert!(resume_error.to_string().contains(command), "{resume_error}");

    let marker_after = interpret_input_hash(scratch.pool(), chain_id).await?;
    assert_eq!(marker_after, marker_before);
    assert_eq!(
        required_ingest_redo(scratch.pool(), chain_id).await?,
        Some((0, 1))
    );

    sqlx::query(
        "UPDATE chain_phase_state
         SET phase_status = 'completed', finished_at = now(), last_error = NULL,
             redo_in_progress = false, redo_mode = NULL, redo_previous_phase_status = NULL,
             redo_previous_last_error = NULL, redo_previous_started_at = NULL,
             redo_previous_finished_at = NULL, redo_from_block_number = NULL,
             redo_to_block_number = NULL, redo_current_block_number = NULL,
             redo_current_block_hash = NULL, redo_target_block_number = NULL, redo_target_block_hash = NULL
         WHERE chain_id = $1 AND phase_name = 'interpret'",
    )
    .bind(chain_id)
    .execute(scratch.pool())
    .await
    .context("failed to reset the interrupted Interpret marker")?;
    sqlx::query(
        "UPDATE chain_phase_state
         SET redo_current_block_number = 0, redo_current_block_hash = 'project-checkpoint'
         WHERE chain_id = $1 AND phase_name = 'project'",
    )
    .bind(chain_id)
    .execute(scratch.pool())
    .await
    .context("failed to seed the pending ordinary Project marker")?;
    loopback_runner(&scratch, "manifest-recompute-ingest-fence-project-resume")?
        .redo(
            &chain,
            RedoPhase::RecomputeFlags,
            BlockRange::new(0, 1)?,
            CancellationToken::new(),
        )
        .await
        .expect_err("recompute beside pending Project redo must wait for required Ingest");
    let project_checkpoint: (Option<i64>, Option<String>) = sqlx::query_as(
        "SELECT redo_current_block_number, redo_current_block_hash
         FROM chain_phase_state WHERE chain_id = $1 AND phase_name = 'project'",
    )
    .bind(chain_id)
    .fetch_one(scratch.pool())
    .await?;
    assert_eq!(
        project_checkpoint,
        (Some(0), Some("project-checkpoint".into()))
    );

    scratch.cleanup().await
}

#[tokio::test]
async fn widening_after_rewind_targets_the_readable_head_and_can_complete() -> Result<()> {
    let scratch = ScratchDatabase::create("production_manifest_widening_after_rewind").await?;
    let chain_id = "manifest-widening-after-rewind";
    let fixture = WatchManifestFixture::new(chain_id)?;
    fixture.write(false, false)?;
    sync_schema_v2_repository(scratch.pool(), &load_repository(&fixture.root)?).await?;
    let chain = seed_completed_ingest_range(&scratch, chain_id).await?;
    sqlx::query(
        "UPDATE chain_phase_state
         SET phase_status = 'completed',
             current_block_number = CASE WHEN phase_name = 'interpret' THEN 1 ELSE 0 END,
             current_block_hash = CASE WHEN phase_name = 'interpret' THEN $2 ELSE $3 END,
             target_block_number = CASE WHEN phase_name = 'interpret' THEN 1 ELSE 0 END,
             target_block_hash = CASE WHEN phase_name = 'interpret' THEN $2 ELSE $3 END,
             input_content_hash = $4,
             started_at = now(), finished_at = now()
         WHERE chain_id = $1 AND phase_name IN ('interpret', 'project')",
    )
    .bind(chain_id)
    .bind(format!("{chain_id}-manifest-sync-head-1"))
    .bind(format!("{chain_id}-manifest-sync-head-0"))
    .bind(INTERPRETER_CONTENT_HASH)
    .execute(scratch.pool())
    .await?;

    let block_0 = format!("{chain_id}-manifest-sync-head-0");
    rewind_to_ancestor(&scratch.runner(), chain_id, BlockMarker::new(0, block_0)?).await?;
    fixture.write(true, false)?;
    sync_schema_v2_repository(scratch.pool(), &load_repository(&fixture.root)?).await?;
    assert_eq!(
        required_ingest_redo(scratch.pool(), chain_id).await?,
        Some((0, 0)),
        "rewound orphaned cursor suffixes are not currently published coverage"
    );

    loopback_runner(&scratch, "manifest-widening-rewind-redo")?
        .redo(
            &chain,
            RedoPhase::Phase(PhaseName::Ingest),
            BlockRange::new(0, 0)?,
            CancellationToken::new(),
        )
        .await?;
    assert_eq!(required_ingest_redo(scratch.pool(), chain_id).await?, None);

    let disposition = PhaseStore::new(scratch.pool().clone())
        .start_phase(chain_id, PhaseName::Live, &RunMode::Normal)
        .await
        .context("Live must be able to republish the replacement suffix before derived redo")?;
    assert_eq!(disposition, StartDisposition::Started);
    scratch.cleanup().await
}

// A supervisor killed mid-follow leaves Project `running` outside any redo; nothing settles the row
// until a supervisor starts again, so a watch widening deployed meanwhile must not strand the
// required Ingest redo behind it.
async fn widen_behind_a_project_left_running(
    scratch: &ScratchDatabase,
    chain_id: &str,
) -> Result<ChainConfig> {
    let fixture = WatchManifestFixture::new(chain_id)?;
    fixture.write(false, false)?;
    sync_schema_v2_repository(scratch.pool(), &load_repository(&fixture.root)?).await?;
    let chain = seed_completed_ingest_range(scratch, chain_id).await?;
    sqlx::query(
        "UPDATE chain_phase_state
         SET phase_status = CASE phase_name WHEN 'project' THEN 'running' ELSE 'completed' END,
             current_block_number = CASE phase_name WHEN 'project' THEN 0 ELSE 1 END,
             current_block_hash = CASE phase_name WHEN 'project' THEN $3 ELSE $2 END,
             target_block_number = 1, target_block_hash = $2, input_content_hash = $4,
             started_at = now(),
             finished_at = CASE phase_name WHEN 'project' THEN NULL ELSE now() END
         WHERE chain_id = $1 AND phase_name IN ('interpret', 'project')",
    )
    .bind(chain_id)
    .bind(format!("{chain_id}-manifest-sync-head-1"))
    .bind(format!("{chain_id}-manifest-sync-head-0"))
    .bind(INTERPRETER_CONTENT_HASH)
    .execute(scratch.pool())
    .await?;
    fixture.write(true, false)?;
    sync_schema_v2_repository(scratch.pool(), &load_repository(&fixture.root)?).await?;
    assert_eq!(
        required_ingest_redo(scratch.pool(), chain_id).await?,
        Some((0, 1))
    );
    Ok(chain)
}

async fn project_lifecycle(
    pool: &sqlx::PgPool,
    chain_id: &str,
) -> Result<(String, bool, Option<String>)> {
    Ok(sqlx::query_as(
        "SELECT phase_status, redo_in_progress, last_error
         FROM chain_phase_state WHERE chain_id = $1 AND phase_name = 'project'",
    )
    .bind(chain_id)
    .fetch_one(pool)
    .await?)
}

#[tokio::test]
async fn required_ingest_redo_settles_a_project_a_killed_supervisor_left_running() -> Result<()> {
    let scratch = ScratchDatabase::create("production_manifest_widening_stale_project").await?;
    let chain_id = "manifest-widening-stale-project";
    let chain = widen_behind_a_project_left_running(&scratch, chain_id).await?;

    loopback_runner(&scratch, "manifest-widening-stale-project-redo")?
        .redo(
            &chain,
            RedoPhase::Phase(PhaseName::Ingest),
            BlockRange::new(0, 1)?,
            CancellationToken::new(),
        )
        .await
        .context("a Project row no writer holds must not block the required Ingest redo")?;
    let ingest_redo_in_progress: bool = sqlx::query_scalar(
        "SELECT redo_in_progress FROM chain_phase_state
         WHERE chain_id = $1 AND phase_name = 'ingest'",
    )
    .bind(chain_id)
    .fetch_one(scratch.pool())
    .await?;
    assert!(
        !ingest_redo_in_progress,
        "the required Ingest redo completed"
    );
    let (status, redo_in_progress, last_error) =
        project_lifecycle(scratch.pool(), chain_id).await?;
    assert_eq!((status.as_str(), redo_in_progress), ("failed", false));
    assert!(
        last_error.is_some_and(|error| error.contains("advisory lock was free")),
        "the stopped Project is settled the way supervisor start-up settles it"
    );
    scratch.cleanup().await
}

#[tokio::test]
async fn required_ingest_redo_still_waits_for_a_project_writer_holding_its_lock() -> Result<()> {
    let scratch = ScratchDatabase::create("production_manifest_widening_live_project").await?;
    let chain_id = "manifest-widening-live-project";
    let chain = widen_behind_a_project_left_running(&scratch, chain_id).await?;
    let before = project_lifecycle(scratch.pool(), chain_id).await?;
    let project_lock = PhaseLock::acquire(
        scratch.writer_connect_options(),
        chain_id,
        PhaseName::Project,
    )
    .await?;

    let error = loopback_runner(&scratch, "manifest-widening-live-project-redo")?
        .redo(
            &chain,
            RedoPhase::Phase(PhaseName::Ingest),
            BlockRange::new(0, 1)?,
            CancellationToken::new(),
        )
        .await
        .expect_err("a Project writer that still holds its lock blocks the Ingest redo");
    assert_eq!(error.kind(), ErrorKind::LockHeld, "{error}");
    assert_eq!(project_lifecycle(scratch.pool(), chain_id).await?, before);
    assert_eq!(
        required_ingest_redo(scratch.pool(), chain_id).await?,
        Some((0, 1))
    );
    project_lock.release().await?;
    scratch.cleanup().await
}

#[tokio::test]
async fn rewind_preserves_a_required_ingest_obligation_above_the_new_head() -> Result<()> {
    let scratch = ScratchDatabase::create("production_manifest_widening_before_rewind").await?;
    let chain_id = "manifest-widening-before-rewind";
    let fixture = WatchManifestFixture::new(chain_id)?;
    fixture.write(false, false)?;
    sync_schema_v2_repository(scratch.pool(), &load_repository(&fixture.root)?).await?;
    seed_completed_ingest_range(&scratch, chain_id).await?;
    fixture.write(true, false)?;
    sync_schema_v2_repository(scratch.pool(), &load_repository(&fixture.root)?).await?;
    assert_eq!(
        required_ingest_redo(scratch.pool(), chain_id).await?,
        Some((0, 1))
    );

    let block_0 = format!("{chain_id}-manifest-sync-head-0");
    rewind_to_ancestor(&scratch.runner(), chain_id, BlockMarker::new(0, block_0)?).await?;
    assert_eq!(
        required_ingest_redo(scratch.pool(), chain_id).await?,
        Some((0, 1)),
        "rewind must preserve the obligation for Live to make readable again"
    );
    let latest: i64 =
        sqlx::query_scalar("SELECT latest_block_number FROM chain_heads WHERE chain_id = $1")
            .bind(chain_id)
            .fetch_one(scratch.pool())
            .await?;
    assert_eq!(
        latest, 0,
        "rewind must publish the requested readable ancestor"
    );

    scratch.cleanup().await
}

#[tokio::test]
async fn manifest_watch_comparison_trips_only_for_covered_widenings() -> Result<()> {
    for (name, before, after, before_start, after_start, already_ingested, expected_redo) in [
        (
            "new-contract",
            (false, false),
            (false, true),
            0,
            0,
            true,
            Some((0, 1)),
        ),
        (
            "start-block-lowering",
            (false, false),
            (false, false),
            1,
            0,
            true,
            Some((0, 1)),
        ),
        ("narrowing", (true, true), (false, false), 0, 0, true, None),
        ("same-set", (false, false), (false, false), 0, 0, true, None),
        (
            "fresh-chain",
            (false, false),
            (true, false),
            0,
            0,
            false,
            None,
        ),
    ] {
        let scratch =
            ScratchDatabase::create(&format!("production_manifest_watch_comparison_{}", name))
                .await?;
        let chain_id = format!("manifest-watch-{name}");
        let fixture = WatchManifestFixture::new(&chain_id)?;
        fixture.write_with_start(before.0, before.1, before_start)?;
        sync_schema_v2_repository(scratch.pool(), &load_repository(&fixture.root)?).await?;
        if already_ingested {
            seed_completed_ingest_range(&scratch, &chain_id).await?;
        }

        fixture.write_with_start(after.0, after.1, after_start)?;
        sync_schema_v2_repository(scratch.pool(), &load_repository(&fixture.root)?).await?;
        assert_eq!(
            required_ingest_redo(scratch.pool(), &chain_id).await?,
            expected_redo,
            "unexpected Ingest obligation for {name}"
        );
        scratch.cleanup().await?;
    }
    Ok(())
}

#[tokio::test]
async fn manifest_watch_comparison_refuses_before_first_persisted_interval() -> Result<()> {
    let scratch = ScratchDatabase::create("production_manifest_watch_leading_gap").await?;
    let chain_id = "manifest-watch-leading-gap";
    let fixture = WatchManifestFixture::new(chain_id)?;
    fixture.write_with_start(false, false, 1)?;
    sync_schema_v2_repository(scratch.pool(), &load_repository(&fixture.root)?).await?;
    seed_completed_ingest_range_through(&scratch, chain_id, 10).await?;

    // Construct the stored address interval left by the former producers of this state. The
    // desired declaration promises block 1, while re-admission can only reopen after the stored
    // block-5 interval and therefore leaves blocks 1 through 4 uncovered.
    sqlx::query("UPDATE manifest_versions SET rollout_status = 'deprecated' WHERE chain_id = $1")
        .bind(chain_id)
        .execute(scratch.pool())
        .await?;
    sqlx::query(
        "UPDATE contract_instance_addresses
         SET active_from_block_number = 5,
             active_to_block_number = 5, active_to_block_hash = NULL, deactivated_at = now()
         WHERE chain_id = $1 AND deactivated_at IS NULL",
    )
    .bind(chain_id)
    .execute(scratch.pool())
    .await?;

    let error = sync_schema_v2_repository(scratch.pool(), &load_repository(&fixture.root)?)
        .await
        .expect_err("compiled-watch coverage before the first interval must be refused");
    let message = error.to_string();
    assert!(message.contains("promised coverage start 1"), "{message}");
    assert!(message.contains("uncovered interval 1..=4"), "{message}");
    assert_eq!(required_ingest_redo(scratch.pool(), chain_id).await?, None);

    fixture.move_source_a_root_start(1, 5)?;
    sync_schema_v2_repository(scratch.pool(), &load_repository(&fixture.root)?).await?;
    assert_eq!(
        required_ingest_redo(scratch.pool(), chain_id).await?,
        Some((5, 10)),
        "a declaration at the first continuously covered block must still sync"
    );
    scratch.cleanup().await
}

#[tokio::test]
async fn manifest_watch_comparison_refuses_redeclared_start_across_epoch_gap() -> Result<()> {
    let scratch = ScratchDatabase::create("production_manifest_watch_epoch_gap_probe").await?;
    let chain_id = "manifest-watch-epoch-gap-probe";
    let address = "0x0000000000000000000000000000000000000004";
    let fixture = WatchManifestFixture::new(chain_id)?;
    let path = fixture.root.join("test/test_events/v1.toml");

    // 1. Declare address A at start 5; sync.
    fixture.write_with_start(false, false, 5)?;
    sync_schema_v2_repository(scratch.pool(), &load_repository(&fixture.root)?).await?;

    // 2. Retire A at head 5.
    seed_chain_head(scratch.pool(), chain_id, 5).await?;
    fs::write(
        &path,
        fs::read_to_string(&path)?.replacen(
            address,
            "0x0000000000000000000000000000000000000005",
            1,
        ),
    )?;
    sync_schema_v2_repository(scratch.pool(), &load_repository(&fixture.root)?).await?;

    // 3. Re-declare A at start 10; sync.
    fixture.write_with_start(false, false, 10)?;
    sync_schema_v2_repository(scratch.pool(), &load_repository(&fixture.root)?).await?;

    // 4. Retire A at head 10.
    advance_chain_head(scratch.pool(), chain_id, 10).await?;
    fs::write(
        &path,
        fs::read_to_string(&path)?.replacen(
            address,
            "0x0000000000000000000000000000000000000006",
            1,
        ),
    )?;
    sync_schema_v2_repository(scratch.pool(), &load_repository(&fixture.root)?).await?;

    let epochs_before: Vec<AddressEpoch> = sqlx::query_as(
        "SELECT contract_instance_address_id, contract_instance_id,
                active_from_block_number, active_to_block_number,
                deactivated_at IS NULL
         FROM contract_instance_addresses
         WHERE chain_id = $1 AND lower(address) = $2
         ORDER BY contract_instance_address_id",
    )
    .bind(chain_id)
    .bind(address)
    .fetch_all(scratch.pool())
    .await?;
    assert_eq!(epochs_before.len(), 2);
    assert_eq!(
        epochs_before
            .iter()
            .map(|epoch| (epoch.2, epoch.3, epoch.4))
            .collect::<Vec<_>>(),
        [(Some(5), Some(5), false), (Some(10), Some(10), false)]
    );
    let persisted_before = exact_manifest_sync_snapshot(scratch.pool(), chain_id).await?;

    // 5. Re-declare A at start 5. The discontinuous promise must fail before commit.
    fixture.write_with_start(false, false, 5)?;
    let error = sync_schema_v2_repository(scratch.pool(), &load_repository(&fixture.root)?)
        .await
        .expect_err("persisted blocks 6 through 9 do not honor the re-declared promise");
    let message = error.to_string();
    let transfer = format!("{:#x}", keccak256(b"Transfer(address,address,uint256)"));
    assert!(
        message.contains("compiled-watch comparison refused promised coverage start 5")
            && message.contains("uncovered interval 6..=9")
            && message.contains(chain_id)
            && message.contains("source family test_events")
            && message.contains(address)
            && message.contains(&transfer),
        "unexpected refusal: {message}"
    );
    assert!(
        message.contains("Raise the declaration to the first continuously covered start")
            && message.contains("rebuild from a fresh database/from-zero ingest")
            && message.contains("separately planned repair")
            && message.contains("ordinary address-scoped redo")
            && message.contains("cannot fill this gap")
            && message.contains("did not mark these blocks repaired"),
        "missing operator recovery instructions: {message}"
    );
    assert_eq!(
        exact_manifest_sync_snapshot(scratch.pool(), chain_id).await?,
        persisted_before,
        "the refused synchronization must roll back every persisted mutation"
    );
    assert_eq!(required_ingest_redo(scratch.pool(), chain_id).await?, None);

    fixture.write_with_start(false, false, 10)?;
    sync_schema_v2_repository(scratch.pool(), &load_repository(&fixture.root)?).await?;
    let accepted_epochs: Vec<AddressEpoch> = sqlx::query_as(
        "SELECT contract_instance_address_id, contract_instance_id,
                active_from_block_number, active_to_block_number,
                deactivated_at IS NULL
         FROM contract_instance_addresses
         WHERE chain_id = $1 AND lower(address) = $2
         ORDER BY contract_instance_address_id",
    )
    .bind(chain_id)
    .bind(address)
    .fetch_all(scratch.pool())
    .await?;
    assert_eq!(
        accepted_epochs
            .iter()
            .map(|epoch| (epoch.2, epoch.3, epoch.4))
            .collect::<Vec<_>>(),
        [
            (Some(5), Some(5), false),
            (Some(10), Some(10), false),
            (Some(11), None, true),
        ]
    );
    let filter = load_persisted_watch_filter(scratch.pool(), chain_id, 5, 11).await?;
    assert!(!filter.includes(address, &transfer, 9));
    assert!(filter.includes(address, &transfer, 10));
    assert!(filter.includes(address, &transfer, 11));
    let compiled_watch: serde_json::Value = sqlx::query_scalar(
        "SELECT manifest_payload -> '_bigname_compiled_watch'
         FROM manifest_versions
         WHERE chain_id = $1 AND rollout_status = 'active'",
    )
    .bind(chain_id)
    .fetch_one(scratch.pool())
    .await?;
    let entries = compiled_watch
        .as_array()
        .context("compiled watch plan must remain a JSON array")?;
    assert_eq!(entries.len(), 1);
    assert_eq!(entries[0]["emitter"]["kind"], "address");
    assert_eq!(entries[0]["emitter"]["address"], address);
    assert_eq!(entries[0]["topic0"], transfer);
    assert_eq!(entries[0]["start"], 10);

    sync_schema_v2_repository(scratch.pool(), &load_repository(&fixture.root)?).await?;
    let repeated_watch: serde_json::Value = sqlx::query_scalar(
        "SELECT manifest_payload -> '_bigname_compiled_watch'
         FROM manifest_versions
         WHERE chain_id = $1 AND rollout_status = 'active'",
    )
    .bind(chain_id)
    .fetch_one(scratch.pool())
    .await?;
    assert_eq!(repeated_watch, compiled_watch);
    let repeated_epochs: Vec<AddressEpoch> = sqlx::query_as(
        "SELECT contract_instance_address_id, contract_instance_id,
                active_from_block_number, active_to_block_number,
                deactivated_at IS NULL
         FROM contract_instance_addresses
         WHERE chain_id = $1 AND lower(address) = $2
         ORDER BY contract_instance_address_id",
    )
    .bind(chain_id)
    .bind(address)
    .fetch_all(scratch.pool())
    .await?;
    assert_eq!(repeated_epochs, accepted_epochs);
    assert_eq!(required_ingest_redo(scratch.pool(), chain_id).await?, None);
    scratch.cleanup().await
}

#[tokio::test]
async fn empty_retired_intervals_do_not_fill_persisted_watch_gaps() -> Result<()> {
    let scratch = ScratchDatabase::create("production_manifest_empty_interval_gap").await?;
    let chain_id = "manifest-empty-interval-gap";
    let fixture = WatchManifestFixture::new(chain_id)?;
    let path = fixture.root.join("test/test_events/v1.toml");

    fixture.write_with_start(false, false, 5)?;
    sync_schema_v2_repository(scratch.pool(), &load_repository(&fixture.root)?).await?;
    seed_chain_head(scratch.pool(), chain_id, 5).await?;
    fs::write(
        &path,
        fs::read_to_string(&path)?.replacen(
            "0x0000000000000000000000000000000000000004",
            "0x0000000000000000000000000000000000000005",
            1,
        ),
    )?;
    sync_schema_v2_repository(scratch.pool(), &load_repository(&fixture.root)?).await?;

    fixture.write_with_start(false, false, 10)?;
    sync_schema_v2_repository(scratch.pool(), &load_repository(&fixture.root)?).await?;
    advance_chain_head(scratch.pool(), chain_id, 10).await?;
    fs::write(
        &path,
        fs::read_to_string(&path)?.replacen(
            "0x0000000000000000000000000000000000000004",
            "0x0000000000000000000000000000000000000006",
            1,
        ),
    )?;
    sync_schema_v2_repository(scratch.pool(), &load_repository(&fixture.root)?).await?;

    let epochs: Vec<(Option<i64>, Option<i64>)> = sqlx::query_as(
        "SELECT active_from_block_number, active_to_block_number
         FROM contract_instance_addresses
         WHERE chain_id = $1 AND lower(address) = $2
         ORDER BY contract_instance_address_id",
    )
    .bind(chain_id)
    .bind("0x0000000000000000000000000000000000000004")
    .fetch_all(scratch.pool())
    .await?;
    assert_eq!(epochs, [(Some(5), Some(5)), (Some(10), Some(10))]);

    fixture.write_with_start(false, false, 7)?;
    let error = sync_schema_v2_repository(scratch.pool(), &load_repository(&fixture.root)?)
        .await
        .expect_err("empty retired intervals must not fill persisted Ingest coverage gaps");
    let message = error.to_string();
    assert!(message.contains("promised coverage start 7"), "{message}");
    assert!(message.contains("uncovered interval 7..=9"), "{message}");
    scratch.cleanup().await
}

#[tokio::test]
async fn desired_all_emitter_watch_covers_an_address_across_a_persisted_gap() -> Result<()> {
    let scratch = ScratchDatabase::create("production_manifest_desired_all_covers_gap").await?;
    let chain_id = "manifest-desired-all-covers-gap";
    let fixture = WatchManifestFixture::with_source_family(chain_id, "ens_v2_registry_l1")?;
    fixture.write_with_start(false, false, 1)?;
    let path = fixture.root.join("test/ens_v2_registry_l1/v1.toml");
    let manifest = fs::read_to_string(&path)?.replace(
        r#"[[abi.events]]
name = "Transfer"
fragment = "event Transfer(address indexed from, address indexed to, uint256 value)"
emitter_roles = ["source_a"]
normalized_events = []
status = "supported"
"#,
        "",
    );
    fs::write(&path, manifest)?;
    sync_schema_v2_repository(scratch.pool(), &load_repository(&fixture.root)?).await?;
    seed_completed_ingest_range_through(&scratch, chain_id, 10).await?;

    sqlx::query("UPDATE manifest_versions SET rollout_status = 'deprecated' WHERE chain_id = $1")
        .bind(chain_id)
        .execute(scratch.pool())
        .await?;
    sqlx::query(
        "UPDATE contract_instance_addresses
         SET active_from_block_number = 5,
             active_to_block_number = 5, active_to_block_hash = NULL, deactivated_at = now()
         WHERE chain_id = $1 AND deactivated_at IS NULL",
    )
    .bind(chain_id)
    .execute(scratch.pool())
    .await?;

    sync_schema_v2_repository(scratch.pool(), &load_repository(&fixture.root)?)
        .await
        .expect("the desired all-emitter watch already honors the promised address coverage");
    assert_eq!(
        required_ingest_redo(scratch.pool(), chain_id).await?,
        Some((0, 10))
    );
    scratch.cleanup().await
}

#[tokio::test]
async fn combined_announcement_widening_and_all_emitter_removal_is_refused() -> Result<()> {
    let scratch = ScratchDatabase::create("production_manifest_previous_all_removed").await?;
    let chain_id = "manifest-previous-all-removed";
    let fixture = WatchManifestFixture::with_source_family(chain_id, "ens_v2_registry_l1")?;
    fixture.write_with_start(false, false, 1)?;
    let path = fixture.root.join("test/ens_v2_registry_l1/v1.toml");
    let manifest = fs::read_to_string(&path)?.replace(
        "name = \"Transfer\"\nfragment = \"event Transfer(address indexed from, address indexed to, uint256 value)\"",
        "name = \"TextChanged\"\nfragment = \"event TextChanged(bytes32 indexed node, string indexed indexedKey, string key, string value)\"",
    );
    fs::write(&path, manifest)?;
    sync_schema_v2_repository(scratch.pool(), &load_repository(&fixture.root)?).await?;
    seed_completed_ingest_range_through(&scratch, chain_id, 10).await?;

    sqlx::query(
        "WITH closed AS (
             UPDATE contract_instance_addresses SET active_from_block_number = 5, active_to_block_number = 5, active_to_block_hash = NULL, deactivated_at = now()
             WHERE chain_id = $1 AND deactivated_at IS NULL RETURNING contract_instance_id, chain_id, address, source_manifest_id, provenance)
         INSERT INTO contract_instance_addresses (contract_instance_id, chain_id, address, active_from_block_number, source_manifest_id, provenance)
         SELECT contract_instance_id, chain_id, address, 6, source_manifest_id, provenance FROM closed",
    )
    .bind(chain_id)
    .execute(scratch.pool())
    .await?;

    let text_changed = format!(
        "{:#x}",
        keccak256(b"TextChanged(bytes32,string,string,string)")
    );
    sqlx::query(
        "UPDATE manifest_versions SET manifest_payload = jsonb_set(manifest_payload, '{_bigname_compiled_watch}',
             (manifest_payload -> '_bigname_compiled_watch') || jsonb_build_array(jsonb_build_object('emitter', jsonb_build_object('kind', 'all'), 'topic0', $2, 'start', 0)))
         WHERE chain_id = $1 AND rollout_status = 'active'",
    )
    .bind(chain_id)
    .bind(&text_changed)
    .execute(scratch.pool())
    .await?;
    fixture.add_discovery_rule("registry_announcement")?;

    let before_refusal = exact_manifest_sync_snapshot(scratch.pool(), chain_id).await?;
    let error = sync_schema_v2_repository(scratch.pool(), &load_repository(&fixture.root)?)
        .await
        .expect_err("same-sync widening must not license removal across an address gap");
    let message = error.to_string();
    assert!(message.contains("uncovered interval 1..=4"), "{message}");
    assert!(
        message.contains("Let any pending required Ingest redo on this chain complete")
            && message.contains("split a combined manifest change"),
        "{message}"
    );
    assert_eq!(
        exact_manifest_sync_snapshot(scratch.pool(), chain_id).await?,
        before_refusal,
        "the refusal must preserve the prior manifest, watch plan, address epochs, and redo state"
    );
    assert_eq!(
        required_ingest_redo(scratch.pool(), chain_id).await?,
        None,
        "the same-sync registry-announcement redo must roll back with the refusal"
    );
    scratch.cleanup().await
}

#[tokio::test]
async fn removing_all_emitter_while_chain_redo_is_pending_uses_wait_recovery() -> Result<()> {
    let scratch = ScratchDatabase::create("production_manifest_pending_all_removed").await?;
    let chain_id = "manifest-pending-all-removed";
    let fixture = WatchManifestFixture::with_source_family(chain_id, "ens_v1_resolver_l1")?;
    fixture.write_with_start(false, false, 1)?;
    let path = fixture.root.join("test/ens_v1_resolver_l1/v1.toml");
    fs::write(
        &path,
        fs::read_to_string(&path)?.replace(
            "name = \"Transfer\"\nfragment = \"event Transfer(address indexed from, address indexed to, uint256 value)\"",
            "name = \"TextChanged\"\nfragment = \"event TextChanged(bytes32 indexed node, string indexed indexedKey, string key, string value)\"",
        ),
    )?;
    sync_schema_v2_repository(scratch.pool(), &load_repository(&fixture.root)?).await?;
    seed_completed_ingest_range_through(&scratch, chain_id, 10).await?;
    sqlx::query(
        "WITH closed AS (
             UPDATE contract_instance_addresses SET active_from_block_number = 5, active_to_block_number = 5, deactivated_at = now()
             WHERE chain_id = $1 AND deactivated_at IS NULL RETURNING contract_instance_id, chain_id, address, source_manifest_id, provenance)
         INSERT INTO contract_instance_addresses (contract_instance_id, chain_id, address, active_from_block_number, source_manifest_id, provenance) SELECT contract_instance_id, chain_id, address, 6, source_manifest_id, provenance FROM closed",
    )
    .bind(chain_id)
    .execute(scratch.pool())
    .await?;
    sqlx::query(
        "UPDATE chain_phase_state SET phase_status = 'running', redo_in_progress = true, redo_mode = 'redo', redo_previous_phase_status = 'completed', redo_from_block_number = 0, redo_to_block_number = 10,
             redo_previous_started_at = started_at, redo_previous_finished_at = finished_at, last_error = 'required downstream redo: unrelated fixture', started_at = now(), finished_at = NULL WHERE chain_id = $1 AND phase_name = 'ingest'",
    )
    .bind(chain_id)
    .execute(scratch.pool())
    .await?;
    let replacement = fixture.root.join("test/test_events_pending_removed");
    fs::rename(fixture.root.join("test/ens_v1_resolver_l1"), &replacement)?;
    let path = replacement.join("v1.toml");
    fs::write(
        &path,
        fs::read_to_string(&path)?.replace("ens_v1_resolver_l1", "test_events_pending_removed"),
    )?;

    let before_refusal = exact_manifest_sync_snapshot(scratch.pool(), chain_id).await?;
    let error = sync_schema_v2_repository(scratch.pool(), &load_repository(&fixture.root)?)
        .await
        .expect_err("any pending chain redo must conservatively gate all-emitter removal");
    let message = error.to_string();
    assert!(message.contains("Let any pending required Ingest redo on this chain complete"));
    assert!(message.contains("split a combined manifest change"));
    assert_eq!(
        exact_manifest_sync_snapshot(scratch.pool(), chain_id).await?,
        before_refusal,
        "the refusal must preserve the prior manifest, watch plan, address epochs, and redo state"
    );
    assert_eq!(
        required_ingest_redo(scratch.pool(), chain_id).await?,
        Some((0, 10))
    );
    scratch.cleanup().await
}

#[tokio::test]
async fn manifest_sync_reports_only_declared_starts_that_keep_a_lower_floor() -> Result<()> {
    let scratch = ScratchDatabase::create("production_manifest_start_notice").await?;
    let chain_id = "manifest-start-notice";
    let fixture = WatchManifestFixture::new(chain_id)?;
    fixture.write_with_start(false, false, 0)?;
    let initial =
        sync_schema_v2_repository(scratch.pool(), &load_repository(&fixture.root)?).await?;
    assert!(initial.notices.is_empty());

    fixture.move_source_a_root_start(0, 2)?;
    let no_effect =
        sync_schema_v2_repository(scratch.pool(), &load_repository(&fixture.root)?).await?;
    assert_eq!(
        no_effect.notices,
        [format!(
            "declared start 2 for {chain_id}:0x0000000000000000000000000000000000000004 did not raise persisted address floor; keeping 0"
        )]
    );
    assert_eq!(
        test_registry_active_from(scratch.pool(), chain_id).await?,
        Some(0)
    );
    let filter = load_persisted_watch_filter(scratch.pool(), chain_id, 0, 2).await?;
    let transfer = format!("{:#x}", keccak256(b"Transfer(address,address,uint256)"));
    let address = "0x0000000000000000000000000000000000000004";
    assert!(!filter.includes(address, &transfer, 1));
    assert!(filter.includes(address, &transfer, 2));
    scratch.cleanup().await?;

    let no_notice = ScratchDatabase::create("production_manifest_start_no_notice").await?;
    let at_floor = WatchManifestFixture::with_source_family(
        "manifest-start-no-notice",
        "test_events_no_notice",
    )?;
    at_floor.write_with_start(false, false, 2)?;
    let initial_at_floor =
        sync_schema_v2_repository(no_notice.pool(), &load_repository(&at_floor.root)?).await?;
    assert!(initial_at_floor.notices.is_empty());
    let repeated_at_floor =
        sync_schema_v2_repository(no_notice.pool(), &load_repository(&at_floor.root)?).await?;
    assert!(repeated_at_floor.notices.is_empty());
    no_notice.cleanup().await
}

#[tokio::test]
async fn required_ingest_obligation_persists_after_the_watch_plan_narrows_back() -> Result<()> {
    let scratch = ScratchDatabase::create("production_manifest_narrow_back_keeps_redo").await?;
    let chain_id = "manifest-narrow-back-keeps-redo";
    let fixture = WatchManifestFixture::new(chain_id)?;
    fixture.write(false, false)?;
    sync_schema_v2_repository(scratch.pool(), &load_repository(&fixture.root)?).await?;
    seed_completed_ingest_range(&scratch, chain_id).await?;

    fixture.write(true, false)?;
    sync_schema_v2_repository(scratch.pool(), &load_repository(&fixture.root)?).await?;
    assert_eq!(
        required_ingest_redo(scratch.pool(), chain_id).await?,
        Some((0, 1))
    );

    fixture.write(false, false)?;
    sync_schema_v2_repository(scratch.pool(), &load_repository(&fixture.root)?).await?;
    assert_eq!(
        required_ingest_redo(scratch.pool(), chain_id).await?,
        Some((0, 1)),
        "narrowing must not clear an uncompleted historical-fetch obligation"
    );

    scratch.cleanup().await
}

#[tokio::test]
async fn adding_a_declared_address_to_a_discovery_family_requires_reingest() -> Result<()> {
    let scratch = ScratchDatabase::create("production_manifest_discovery_family_address").await?;
    let chain_id = "manifest-discovery-family-address";
    let fixture = WatchManifestFixture::with_source_family(chain_id, "ens_v1_resolver_l1")?;
    fixture.write(false, false)?;
    sync_schema_v2_repository(scratch.pool(), &load_repository(&fixture.root)?).await?;
    seed_completed_ingest_range(&scratch, chain_id).await?;

    fixture.write(false, true)?;
    sync_schema_v2_repository(scratch.pool(), &load_repository(&fixture.root)?).await?;
    assert_eq!(
        required_ingest_redo(scratch.pool(), chain_id).await?,
        Some((0, 1)),
        "a family-scoped discovery watch does not cover a newly declared direct address"
    );

    scratch.cleanup().await
}

#[tokio::test]
async fn adding_a_discovery_rule_over_ingested_history_is_rejected() -> Result<()> {
    let scratch = ScratchDatabase::create("production_manifest_discovery_rule_widening").await?;
    let chain_id = "manifest-discovery-rule-widening";
    let fixture = WatchManifestFixture::new(chain_id)?;
    fixture.write(false, false)?;
    sync_schema_v2_repository(scratch.pool(), &load_repository(&fixture.root)?).await?;
    seed_completed_ingest_range(&scratch, chain_id).await?;

    fixture.add_discovery_rule("resolver")?;
    let error = sync_schema_v2_repository(scratch.pool(), &load_repository(&fixture.root)?)
        .await
        .expect_err("historical indexability admission needs prior discovery derivation");
    assert!(error.to_string().contains("discovery rule"));
    fixture.write(false, false)?;
    fixture.add_discovery_rule("registry_announcement")?;
    let error = sync_schema_v2_repository(scratch.pool(), &load_repository(&fixture.root)?)
        .await
        .expect_err("unsupported historical announcement widening must reject");
    assert!(error.to_string().contains("registry announcement"));
    fixture.write(false, false)?;
    fixture.add_discovery_rule("subregistry")?;
    sync_schema_v2_repository(scratch.pool(), &load_repository(&fixture.root)?).await?;
    scratch.cleanup().await?;

    let fresh = ScratchDatabase::create("production_manifest_fresh_discovery_rule").await?;
    let fresh_chain = "manifest-fresh-discovery-rule";
    let fresh_fixture =
        WatchManifestFixture::with_source_family(fresh_chain, "ens_v2_registry_l1")?;
    fresh_fixture.write(false, false)?;
    fresh_fixture.add_discovery_rule("registry_announcement")?;
    sync_schema_v2_repository(fresh.pool(), &load_repository(&fresh_fixture.root)?).await?;
    seed_completed_ingest_range(&fresh, fresh_chain).await?;
    fresh_fixture.write(false, false)?;
    sync_schema_v2_repository(fresh.pool(), &load_repository(&fresh_fixture.root)?).await?;

    fresh.cleanup().await
}

#[tokio::test]
async fn historical_registry_announcement_rule_stamps_backfillable_ingest() -> Result<()> {
    let scratch = ScratchDatabase::create("production_manifest_announcement_rule_widening").await?;
    let chain_id = "manifest-announcement-rule-widening";
    let fixture = WatchManifestFixture::with_source_family(chain_id, "ens_v2_registry_l1")?;
    fixture.write(false, false)?;
    sync_schema_v2_repository(scratch.pool(), &load_repository(&fixture.root)?).await?;
    seed_completed_ingest_range(&scratch, chain_id).await?;

    fixture.add_discovery_rule("registry_announcement")?;
    sync_schema_v2_repository(scratch.pool(), &load_repository(&fixture.root)?).await?;
    assert_eq!(
        required_ingest_redo(scratch.pool(), chain_id).await?,
        Some((0, 1))
    );

    scratch.cleanup().await
}

#[tokio::test]
async fn announcement_widening_starts_at_an_earlier_retained_announcement() -> Result<()> {
    let scratch = ScratchDatabase::create("production_manifest_pre_anchor_announcement").await?;
    let chain_id = "manifest-pre-anchor-announcement";
    let fixture = WatchManifestFixture::with_source_family(chain_id, "ens_v2_registry_l1")?;
    fixture.write_with_start(false, false, 3)?;
    sync_schema_v2_repository(scratch.pool(), &load_repository(&fixture.root)?).await?;
    seed_completed_ingest_range_through(&scratch, chain_id, 5).await?;
    seed_retained_registry_announcement(scratch.pool(), chain_id, 1).await?;

    fixture.add_discovery_rule("registry_announcement")?;
    sync_schema_v2_repository(scratch.pool(), &load_repository(&fixture.root)?).await?;
    assert_eq!(
        required_ingest_redo(scratch.pool(), chain_id).await?,
        Some((1, 5)),
        "the redo must include the earliest retained announcement admitted by the new rule"
    );

    scratch.cleanup().await
}

#[tokio::test]
async fn future_registry_announcement_rule_remains_admissible() -> Result<()> {
    let scratch = ScratchDatabase::create("production_manifest_future_announcement").await?;
    let chain_id = "manifest-future-announcement";
    let fixture = WatchManifestFixture::with_source_family(chain_id, "ens_v2_registry_l1")?;
    fixture.write_with_start(false, false, 2)?;
    sync_schema_v2_repository(scratch.pool(), &load_repository(&fixture.root)?).await?;
    seed_completed_ingest_range(&scratch, chain_id).await?;
    fixture.add_discovery_rule("registry_announcement")?;
    sync_schema_v2_repository(scratch.pool(), &load_repository(&fixture.root)?).await?;
    assert_eq!(required_ingest_redo(scratch.pool(), chain_id).await?, None);
    scratch.cleanup().await
}

#[tokio::test]
async fn resolver_discovery_widening_uses_the_published_head_after_a_rewind() -> Result<()> {
    for (case, published_head, emitter_start, should_admit) in [
        ("future-of-published-head", Some(4), 7, true),
        ("at-published-head", Some(4), 4, false),
        ("missing-published-head", None, 10, false),
    ] {
        let scratch = ScratchDatabase::create(&format!(
            "production_manifest_discovery_published_head_{case}"
        ))
        .await?;
        let chain_id = format!("manifest-discovery-published-head-{case}");
        let fixture = WatchManifestFixture::new(&chain_id)?;
        fixture.write_namespace_resolver_source(
            "test",
            "0x0000000000000000000000000000000000000005",
            None,
        )?;
        sync_schema_v2_repository(scratch.pool(), &load_repository(&fixture.root)?).await?;
        seed_completed_ingest_range_through(&scratch, &chain_id, 10).await?;
        if let Some(head) = published_head {
            advance_chain_head(scratch.pool(), &chain_id, head).await?;
        } else {
            sqlx::query("DELETE FROM chain_heads WHERE chain_id = $1")
                .bind(&chain_id)
                .execute(scratch.pool())
                .await?;
        }

        fixture.write_namespace_resolver_source(
            "test",
            "0x0000000000000000000000000000000000000005",
            Some(("0x0000000000000000000000000000000000000004", emitter_start)),
        )?;
        let result =
            sync_schema_v2_repository(scratch.pool(), &load_repository(&fixture.root)?).await;
        if should_admit {
            result.context("future resolver discovery work must be admitted after a rewind")?;
            assert_eq!(required_ingest_redo(scratch.pool(), &chain_id).await?, None);
        } else {
            let error = result.expect_err("covered resolver discovery work must still reject");
            assert!(
                error.to_string().contains("discovery rule widening"),
                "{error}"
            );
        }
        scratch.cleanup().await?;
    }
    Ok(())
}

#[tokio::test]
async fn replacing_a_resolver_discovery_source_over_ingested_history_is_rejected() -> Result<()> {
    let scratch =
        ScratchDatabase::create("production_manifest_resolver_source_replacement").await?;
    let chain_id = "manifest-resolver-source-replacement";
    let fixture = WatchManifestFixture::new(chain_id)?;
    fixture.write(false, false)?;
    fixture.add_discovery_rule("resolver")?;
    sync_schema_v2_repository(scratch.pool(), &load_repository(&fixture.root)?).await?;
    seed_completed_ingest_range(&scratch, chain_id).await?;

    fixture.replace_source_a("0x0000000000000000000000000000000000000007", 0)?;
    let result = sync_schema_v2_repository(scratch.pool(), &load_repository(&fixture.root)?).await;
    let error = match result {
        Err(error) => error,
        Ok(_) => {
            assert_eq!(
                required_ingest_redo(scratch.pool(), chain_id).await?,
                Some((0, 1)),
                "the slipped transition should only stamp the new declaration's watched logs"
            );
            let resolver_logs: i64 =
                sqlx::query_scalar("SELECT count(*) FROM raw_logs WHERE chain_id = $1")
                    .bind(chain_id)
                    .fetch_one(scratch.pool())
                    .await?;
            assert_eq!(
                resolver_logs, 0,
                "the stamped pass has no resolver addresses until Interpret materializes them"
            );
            panic!(
                "resolver discovery source replacement slipped through as an ordinary watch-plan widening"
            );
        }
    };
    assert!(
        error
            .to_string()
            .contains("resolver discovery source replacement"),
        "the loud rejection must name the transition: {error}"
    );

    scratch.cleanup().await?;

    let fresh = ScratchDatabase::create("production_manifest_fresh_resolver_replacement").await?;
    let fresh_chain = "manifest-fresh-resolver-replacement";
    let fresh_fixture = WatchManifestFixture::new(fresh_chain)?;
    fresh_fixture.write(false, false)?;
    fresh_fixture.add_discovery_rule("resolver")?;
    sync_schema_v2_repository(fresh.pool(), &load_repository(&fresh_fixture.root)?).await?;
    seed_chain_head(fresh.pool(), fresh_chain, 0).await?;
    fresh_fixture.replace_source_a("0x0000000000000000000000000000000000000007", 0)?;
    sync_schema_v2_repository(fresh.pool(), &load_repository(&fresh_fixture.root)?).await?;
    fresh.cleanup().await?;

    let future = ScratchDatabase::create("production_manifest_future_resolver_replacement").await?;
    let future_chain = "manifest-future-resolver-replacement";
    let future_fixture = WatchManifestFixture::new(future_chain)?;
    future_fixture.write(false, false)?;
    future_fixture.add_discovery_rule("resolver")?;
    sync_schema_v2_repository(future.pool(), &load_repository(&future_fixture.root)?).await?;
    seed_completed_ingest_range(&future, future_chain).await?;
    future_fixture.replace_source_a("0x0000000000000000000000000000000000000007", 2)?;
    sync_schema_v2_repository(future.pool(), &load_repository(&future_fixture.root)?).await?;
    assert_eq!(
        required_ingest_redo(future.pool(), future_chain).await?,
        None,
        "a source replacement beginning after retained history remains admissible"
    );

    future.cleanup().await
}

#[tokio::test]
async fn moving_one_of_multiple_resolver_sources_into_history_is_rejected() -> Result<()> {
    let scratch =
        ScratchDatabase::create("production_manifest_resolver_source_start_widening").await?;
    let chain_id = "manifest-resolver-source-start-widening";
    let fixture = WatchManifestFixture::new(chain_id)?;
    fixture.write(false, false)?;
    fixture.add_source_a_root("0x0000000000000000000000000000000000000008", 1)?;
    fixture.add_discovery_rule("resolver")?;
    sync_schema_v2_repository(scratch.pool(), &load_repository(&fixture.root)?).await?;
    seed_completed_ingest_range(&scratch, chain_id).await?;

    fixture.move_source_a_root_start(1, 0)?;
    let error = sync_schema_v2_repository(scratch.pool(), &load_repository(&fixture.root)?)
        .await
        .expect_err("each resolver-rule emitter must retain its own covered start");
    assert!(
        error.to_string().contains("discovery rule widening"),
        "{error}"
    );

    scratch.cleanup().await
}

#[tokio::test]
async fn cross_namespace_resolver_start_widening_is_order_independent() -> Result<()> {
    for (case, earlier_start, later_start) in
        [("earlier-namespace", 50, 100), ("later-namespace", 100, 50)]
    {
        let scratch = ScratchDatabase::create(&format!(
            "production_manifest_cross_namespace_resolver_{case}"
        ))
        .await?;
        let chain_id = format!("manifest-cross-namespace-resolver-{case}");
        let fixture = WatchManifestFixture::with_source_family(&chain_id, "ens_v1_registrar_l1")?;
        fixture.write_cross_namespace_pair(100, 100, "resolver")?;
        sync_schema_v2_repository(scratch.pool(), &load_repository(&fixture.root)?).await?;
        seed_completed_ingest_range_through(&scratch, &chain_id, 100).await?;

        fixture.write_cross_namespace_pair(earlier_start, later_start, "resolver")?;
        let result =
            sync_schema_v2_repository(scratch.pool(), &load_repository(&fixture.root)?).await;
        let error = match result {
            Err(error) => error,
            Ok(_) => {
                assert_eq!(
                    required_ingest_redo(scratch.pool(), &chain_id).await?,
                    Some((50, 100)),
                    "the slipped transition should stamp only an ordinary Ingest redo"
                );
                panic!(
                    "{case} resolver discovery widening slipped through as an ordinary watch-plan widening"
                );
            }
        };
        assert!(
            error.to_string().contains("discovery rule widening"),
            "the loud rejection must name the transition for {case}: {error}"
        );
        scratch.cleanup().await?;
    }
    Ok(())
}

#[tokio::test]
async fn namespace_scoped_resolver_start_widening_is_not_masked_by_an_earlier_peer() -> Result<()> {
    let scratch = ScratchDatabase::create("production_manifest_namespace_start_key").await?;
    let chain_id = "manifest-namespace-start-key";
    let fixture = WatchManifestFixture::with_source_family(chain_id, "ens_v1_registrar_l1")?;
    fixture.write_cross_namespace_pair(100, 30, "resolver")?;
    sync_schema_v2_repository(scratch.pool(), &load_repository(&fixture.root)?).await?;
    seed_completed_ingest_range_through(&scratch, chain_id, 100).await?;

    fixture.write_cross_namespace_pair(50, 30, "resolver")?;
    let error = sync_schema_v2_repository(scratch.pool(), &load_repository(&fixture.root)?)
        .await
        .expect_err("an earlier peer namespace must not mask resolver discovery widening");
    assert!(
        error.to_string().contains("discovery rule widening"),
        "the namespace-scoped transition must reject loudly: {error}"
    );

    scratch.cleanup().await
}

#[tokio::test]
async fn cross_namespace_different_address_swap_is_rule_widening_not_replacement() -> Result<()> {
    let scratch = ScratchDatabase::create("production_manifest_namespace_address_key").await?;
    let chain_id = "manifest-namespace-address-key";
    let fixture = WatchManifestFixture::with_source_family(chain_id, "ens_v1_registrar_l1")?;
    fixture.write_cross_namespace_resolver_sources(
        Some(("0x0000000000000000000000000000000000000004", 0)),
        None,
    )?;
    sync_schema_v2_repository(scratch.pool(), &load_repository(&fixture.root)?).await?;
    seed_completed_ingest_range(&scratch, chain_id).await?;

    fixture.write_cross_namespace_resolver_sources(
        None,
        Some(("0x0000000000000000000000000000000000000006", 0)),
    )?;
    let error = sync_schema_v2_repository(scratch.pool(), &load_repository(&fixture.root)?)
        .await
        .expect_err("adding zeta's historical emitter must reject as rule widening");
    assert!(
        error.to_string().contains("discovery rule widening")
            && !error.to_string().contains("source replacement"),
        "alpha's removed emitter must not leak into zeta's diagnosis: {error}"
    );

    scratch.cleanup().await
}

// This covers only `insert_watch`'s minimum merge. `insert_discovery_rule`'s equivalent merge is
// defensive: repository loading permits only one active manifest per namespace/source family, and
// each manifest has already merged declarations with the same role/address to their earliest start,
// so a valid repository cannot insert one discovery-rule key with differing starts.
#[tokio::test]
async fn cross_namespace_watch_plan_entries_min_merge_the_earlier_start() -> Result<()> {
    let scratch = ScratchDatabase::create("production_manifest_cross_namespace_watch_min").await?;
    let chain_id = "manifest-cross-namespace-watch-min";
    let fixture = WatchManifestFixture::with_source_family(chain_id, "ens_v1_registrar_l1")?;
    fixture.write_cross_namespace_pair(100, 100, "subregistry")?;
    sync_schema_v2_repository(scratch.pool(), &load_repository(&fixture.root)?).await?;
    seed_completed_ingest_range_through(&scratch, chain_id, 100).await?;

    fixture.write_cross_namespace_pair(50, 100, "subregistry")?;
    sync_schema_v2_repository(scratch.pool(), &load_repository(&fixture.root)?).await?;
    assert_eq!(
        required_ingest_redo(scratch.pool(), chain_id).await?,
        Some((50, 100)),
        "duplicate cross-namespace watch keys must retain the minimum start"
    );

    scratch.cleanup().await
}

#[tokio::test]
async fn discovered_family_event_widening_is_namespace_scoped_in_both_orderings() -> Result<()> {
    for (case, widening_namespace, peer_namespace, widening_address, peer_address) in [
        (
            "first",
            "alpha",
            "zeta",
            "0x0000000000000000000000000000000000000005",
            "0x0000000000000000000000000000000000000007",
        ),
        (
            "last",
            "zeta",
            "alpha",
            "0x0000000000000000000000000000000000000005",
            "0x0000000000000000000000000000000000000007",
        ),
    ] {
        let scratch = ScratchDatabase::create(&format!(
            "production_manifest_discovered_namespace_watch_{case}"
        ))
        .await?;
        let chain_id = format!("manifest-discovered-namespace-watch-{case}");
        let fixture = WatchManifestFixture::new(&chain_id)?;
        fixture.write_discovered_resolver_namespaces(widening_namespace, peer_namespace, false)?;
        sync_schema_v2_repository(scratch.pool(), &load_repository(&fixture.root)?).await?;
        seed_discovered_resolver_address(
            scratch.pool(),
            &chain_id,
            ResolverPair::EnsV2,
            widening_namespace,
            widening_address,
        )
        .await?;
        seed_discovered_resolver_address(
            scratch.pool(),
            &chain_id,
            ResolverPair::EnsV2,
            peer_namespace,
            peer_address,
        )
        .await?;

        let filter = load_persisted_watch_filter(scratch.pool(), &chain_id, 0, 1).await?;
        let address_changed = format!("{:#x}", keccak256(b"AddressChanged(bytes32,uint256,bytes)"));
        assert!(!filter.includes(widening_address, &address_changed, 0));
        assert!(filter.includes(peer_address, &address_changed, 0));

        seed_completed_ingest_range(&scratch, &chain_id).await?;
        fixture.write_discovered_resolver_namespaces(widening_namespace, peer_namespace, true)?;
        sync_schema_v2_repository(scratch.pool(), &load_repository(&fixture.root)?).await?;
        assert_eq!(
            required_ingest_redo(scratch.pool(), &chain_id).await?,
            Some((0, 1)),
            "{case} namespace must refetch its already-discovered resolver history"
        );
        scratch.cleanup().await?;
    }
    Ok(())
}

#[tokio::test]
async fn resolver_epoch_flip_without_complete_discovery_is_rejected() -> Result<()> {
    let scratch = ScratchDatabase::create("production_manifest_resolver_epoch_flip").await?;
    let chain_id = "manifest-resolver-epoch-flip";
    let fixture = WatchManifestFixture::new(chain_id)?;
    fixture.write_admitting_resolver_namespaces("test", "peer", true)?;
    fixture.set_deployment_epoch("test", "ens_v1_registry_l1", "fixture", "matched")?;
    fixture.set_deployment_epoch("test", "ens_v1_resolver_l1", "fixture", "resolver-old")?;
    sync_schema_v2_repository(scratch.pool(), &load_repository(&fixture.root)?).await?;
    seed_completed_ingest_range(&scratch, chain_id).await?;

    fixture.replace_deployment_epoch("test", "ens_v1_resolver_l1", "resolver-old", "matched")?;
    let error = sync_schema_v2_repository(scratch.pool(), &load_repository(&fixture.root)?)
        .await
        .expect_err(
            "manifest snapshots cannot prove that Interpret materialized every resolver edge",
        );
    assert!(
        error
            .to_string()
            .contains("resolver discovery rule widening from a newly matching deployment epoch"),
        "{error}"
    );

    scratch.cleanup().await
}

#[tokio::test]
async fn future_only_resolver_epoch_match_is_admissible() -> Result<()> {
    let scratch = ScratchDatabase::create("production_manifest_future_epoch_match").await?;
    let chain_id = "manifest-future-epoch-match";
    let fixture = WatchManifestFixture::new(chain_id)?;
    fixture.write_admitting_resolver_namespaces("test", "peer", true)?;
    fixture.set_contract_start("test", "ens_v1_registry_l1", 0, 2)?;
    fixture.set_deployment_epoch("test", "ens_v1_registry_l1", "fixture", "matched")?;
    fixture.set_deployment_epoch("test", "ens_v1_resolver_l1", "fixture", "resolver-old")?;
    sync_schema_v2_repository(scratch.pool(), &load_repository(&fixture.root)?).await?;
    assert_eq!(
        test_registry_active_from(scratch.pool(), chain_id).await?,
        Some(2)
    );
    seed_completed_ingest_range(&scratch, chain_id).await?;

    fixture.replace_deployment_epoch("test", "ens_v1_resolver_l1", "resolver-old", "matched")?;
    sync_schema_v2_repository(scratch.pool(), &load_repository(&fixture.root)?).await?;
    assert_eq!(required_ingest_redo(scratch.pool(), chain_id).await?, None);

    scratch.cleanup().await
}

#[tokio::test]
async fn unrelated_same_address_role_does_not_lower_future_candidate() -> Result<()> {
    let scratch = ScratchDatabase::create("production_manifest_future_role_floor").await?;
    let chain_id = "manifest-future-role-floor";
    let fixture = WatchManifestFixture::new(chain_id)?;
    fixture.write_admitting_resolver_namespaces("test", "peer", true)?;
    fixture.set_contract_start("test", "ens_v1_registry_l1", 0, 2)?;
    let path = fixture.root.join("test/ens_v1_registry_l1/v2.toml");
    let manifest = fs::read_to_string(&path)?.replacen(
        "roots = []",
        r#"[[roots]]
name = "early_root"
address = "0x0000000000000000000000000000000000000004"
start_block = 0"#,
        1,
    );
    fs::write(path, manifest)?;
    fixture.set_deployment_epoch("test", "ens_v1_registry_l1", "fixture", "matched")?;
    fixture.set_deployment_epoch("test", "ens_v1_resolver_l1", "fixture", "resolver-old")?;
    sync_schema_v2_repository(scratch.pool(), &load_repository(&fixture.root)?).await?;
    seed_completed_ingest_range(&scratch, chain_id).await?;

    fixture.replace_deployment_epoch("test", "ens_v1_resolver_l1", "resolver-old", "matched")?;
    sync_schema_v2_repository(scratch.pool(), &load_repository(&fixture.root)?).await?;
    assert_eq!(required_ingest_redo(scratch.pool(), chain_id).await?, None);
    scratch.cleanup().await
}

#[tokio::test]
async fn ens_v2_resolver_epoch_match_beside_a_retained_announcement_is_topology_only() -> Result<()>
{
    let scratch = ScratchDatabase::create("production_manifest_epoch_announcement_floor").await?;
    let chain_id = "manifest-epoch-announcement-floor";
    let fixture = WatchManifestFixture::new(chain_id)?;
    fixture.write_discovered_resolver_namespaces("test", "peer", true)?;
    fixture.set_contract_start("test", "ens_v2_registry_l1", 0, 2)?;
    fixture.add_test_registry_announcement_rule()?;
    fixture.set_deployment_epoch("test", "ens_v2_registry_l1", "fixture", "matched")?;
    fixture.set_deployment_epoch("test", "ens_v2_resolver_l1", "fixture", "resolver-old")?;
    sync_schema_v2_repository(scratch.pool(), &load_repository(&fixture.root)?).await?;
    seed_completed_ingest_range(&scratch, chain_id).await?;
    seed_announced_registry_address(
        scratch.pool(),
        chain_id,
        "test",
        "0x0000000000000000000000000000000000000009",
    )
    .await?;

    // An announced registry can emit `ResolverUpdated` from block zero, but an ENSv2 pointer
    // admits no resolver: the newly matching epoch leaves no resolver events unfetched.
    fixture.replace_deployment_epoch("test", "ens_v2_resolver_l1", "resolver-old", "matched")?;
    sync_schema_v2_repository(scratch.pool(), &load_repository(&fixture.root)?).await?;
    assert_eq!(required_ingest_redo(scratch.pool(), chain_id).await?, None);

    scratch.cleanup().await
}

#[tokio::test]
async fn resolver_epoch_flip_away_from_registry_is_admissible_narrowing() -> Result<()> {
    let scratch = ScratchDatabase::create("production_manifest_resolver_epoch_narrowing").await?;
    let chain_id = "manifest-resolver-epoch-narrowing";
    let fixture = WatchManifestFixture::new(chain_id)?;
    fixture.write_admitting_resolver_namespaces("test", "peer", true)?;
    sync_schema_v2_repository(scratch.pool(), &load_repository(&fixture.root)?).await?;
    seed_completed_ingest_range(&scratch, chain_id).await?;

    fixture.replace_deployment_epoch("test", "ens_v1_resolver_l1", "fixture", "unmatched")?;
    sync_schema_v2_repository(scratch.pool(), &load_repository(&fixture.root)?).await?;
    assert_eq!(
        required_ingest_redo(scratch.pool(), chain_id).await?,
        None,
        "stopping the label join removes discovered intervals and needs no historical fetch"
    );

    scratch.cleanup().await
}

#[tokio::test]
async fn deployment_epoch_match_without_a_resolver_rule_is_admissible() -> Result<()> {
    let scratch = ScratchDatabase::create("production_manifest_epoch_without_rule").await?;
    let chain_id = "manifest-epoch-without-rule";
    let fixture = WatchManifestFixture::new(chain_id)?;
    fixture.write_admitting_resolver_namespaces("test", "peer", true)?;
    let path = fixture.root.join("test/ens_v1_registry_l1/v2.toml");
    let manifest = fs::read_to_string(&path)?
        .replace("roots = []", "roots = []\ndiscovery_rules = []")
        .replace(
            "[[discovery_rules]]\nedge_kind = \"resolver\"\nfrom_role = \"registry\"\nadmission = \"reachable_from_root\"",
            "",
        );
    fs::write(path, manifest)?;
    fixture.set_deployment_epoch("test", "ens_v1_registry_l1", "fixture", "registry-old")?;
    sync_schema_v2_repository(scratch.pool(), &load_repository(&fixture.root)?).await?;
    seed_completed_ingest_range(&scratch, chain_id).await?;

    fixture.replace_deployment_epoch("test", "ens_v1_registry_l1", "registry-old", "fixture")?;
    sync_schema_v2_repository(scratch.pool(), &load_repository(&fixture.root)?).await?;
    assert_eq!(required_ingest_redo(scratch.pool(), chain_id).await?, None);
    scratch.cleanup().await
}

#[tokio::test]
async fn registry_epoch_flip_over_retained_history_is_rejected() -> Result<()> {
    let scratch = ScratchDatabase::create("production_manifest_registry_epoch_flip").await?;
    let chain_id = "manifest-registry-epoch-flip";
    let fixture = WatchManifestFixture::new(chain_id)?;
    fixture.write_admitting_resolver_namespaces("test", "peer", true)?;
    fixture.set_deployment_epoch("test", "ens_v1_registry_l1", "fixture", "registry-old")?;
    fixture.set_deployment_epoch("test", "ens_v1_resolver_l1", "fixture", "matched")?;
    sync_schema_v2_repository(scratch.pool(), &load_repository(&fixture.root)?).await?;
    let resolver = "0x0000000000000000000000000000000000000005";
    seed_discovered_resolver_address(
        scratch.pool(),
        chain_id,
        ResolverPair::EnsV1,
        "test",
        resolver,
    )
    .await?;
    seed_completed_ingest_range(&scratch, chain_id).await?;

    fixture.replace_deployment_epoch("test", "ens_v1_registry_l1", "registry-old", "matched")?;
    let result = sync_schema_v2_repository(scratch.pool(), &load_repository(&fixture.root)?).await;
    let error = match result {
        Err(error) => error,
        Ok(_) => {
            assert_eq!(required_ingest_redo(scratch.pool(), chain_id).await?, None);
            panic!(
                "registry epoch flip synced without rejection or required Ingest; its retained \
                 discovery edge still names the deprecated source manifest"
            );
        }
    };
    assert!(
        error
            .to_string()
            .contains("resolver discovery rule widening from a newly matching deployment epoch"),
        "{error}"
    );

    scratch.cleanup().await
}

#[tokio::test]
async fn matched_registry_and_resolver_epoch_rotation_is_rejected() -> Result<()> {
    let scratch = ScratchDatabase::create("production_manifest_matched_epoch_rotation").await?;
    let chain_id = "manifest-matched-epoch-rotation";
    let fixture = WatchManifestFixture::new(chain_id)?;
    fixture.write_admitting_resolver_namespaces("test", "peer", true)?;
    sync_schema_v2_repository(scratch.pool(), &load_repository(&fixture.root)?).await?;
    seed_completed_ingest_range(&scratch, chain_id).await?;

    fixture.replace_deployment_epoch("test", "ens_v1_registry_l1", "fixture", "next")?;
    fixture.replace_deployment_epoch("test", "ens_v1_resolver_l1", "fixture", "next")?;
    sync_schema_v2_repository(scratch.pool(), &load_repository(&fixture.root)?)
        .await
        .expect_err("replacing the matching source manifest invalidates its retained edges");
    scratch.cleanup().await
}

#[tokio::test]
async fn same_epoch_registry_rotation_with_resolver_event_widening_is_rejected() -> Result<()> {
    let scratch =
        ScratchDatabase::create("production_manifest_registry_rotation_with_resolver_widening")
            .await?;
    let chain_id = "manifest-registry-rotation-with-resolver-widening";
    let fixture = WatchManifestFixture::new(chain_id)?;
    fixture.write_admitting_resolver_namespaces("test", "peer", false)?;
    sync_schema_v2_repository(scratch.pool(), &load_repository(&fixture.root)?).await?;
    let resolver = "0x0000000000000000000000000000000000000005";
    seed_discovered_resolver_address(
        scratch.pool(),
        chain_id,
        ResolverPair::EnsV1,
        "test",
        resolver,
    )
    .await?;
    seed_completed_ingest_range(&scratch, chain_id).await?;

    fixture.write_admitting_resolver_namespaces("test", "peer", true)?;
    fixture.rotate_manifest_version("test", "ens_v1_registry_l1")?;
    let result = sync_schema_v2_repository(scratch.pool(), &load_repository(&fixture.root)?).await;
    let error = match result {
        Err(error) => error,
        Ok(_) => {
            assert_eq!(
                required_ingest_redo(scratch.pool(), chain_id).await?,
                Some((0, 1))
            );
            let filter = load_persisted_watch_filter(scratch.pool(), chain_id, 0, 1).await?;
            let widened_topic =
                format!("{:#x}", keccak256(b"AddressChanged(bytes32,uint256,bytes)"));
            assert!(
                !filter.includes(resolver, &widened_topic, 0),
                "the redo filter omits edges anchored by the deprecated registry manifest"
            );
            panic!("same-epoch source-manifest replacement was not classified");
        }
    };
    assert!(
        error
            .to_string()
            .contains("resolver discovery source replacement"),
        "{error}"
    );

    scratch.cleanup().await
}

#[tokio::test]
async fn same_epoch_registry_rotation_without_retained_history_is_admissible() -> Result<()> {
    let scratch = ScratchDatabase::create("production_manifest_fresh_registry_rotation").await?;
    let chain_id = "manifest-fresh-registry-rotation";
    let fixture = WatchManifestFixture::new(chain_id)?;
    fixture.write_admitting_resolver_namespaces("test", "peer", false)?;
    sync_schema_v2_repository(scratch.pool(), &load_repository(&fixture.root)?).await?;

    fixture.rotate_manifest_version("test", "ens_v1_registry_l1")?;
    sync_schema_v2_repository(scratch.pool(), &load_repository(&fixture.root)?).await?;
    assert_eq!(required_ingest_redo(scratch.pool(), chain_id).await?, None);

    scratch.cleanup().await
}

#[tokio::test]
async fn emitterless_resolver_rule_epoch_match_is_rejected() -> Result<()> {
    let scratch = ScratchDatabase::create("production_manifest_emitterless_rule_epoch").await?;
    let chain_id = "manifest-emitterless-rule-epoch";
    let fixture = WatchManifestFixture::new(chain_id)?;
    fixture.write_admitting_resolver_namespaces("test", "peer", false)?;
    fixture.use_only_undeclared_rule_role("ens_v1_registry_l1")?;
    fixture.set_deployment_epoch("test", "ens_v1_registry_l1", "fixture", "matched")?;
    fixture.set_deployment_epoch("test", "ens_v1_resolver_l1", "fixture", "resolver-old")?;
    sync_schema_v2_repository(scratch.pool(), &load_repository(&fixture.root)?).await?;
    seed_completed_ingest_range(&scratch, chain_id).await?;

    fixture.replace_deployment_epoch("test", "ens_v1_resolver_l1", "resolver-old", "matched")?;
    let error = sync_schema_v2_repository(scratch.pool(), &load_repository(&fixture.root)?)
        .await
        .expect_err("a rule with no matching declaration is a block-zero discovery candidate");
    assert!(
        error
            .to_string()
            .contains("resolver discovery rule widening from a newly matching deployment epoch"),
        "{error}"
    );

    scratch.cleanup().await
}

#[tokio::test]
async fn adding_announcement_rule_beside_a_topology_only_resolver_rule_stamps_ingest() -> Result<()>
{
    let scratch =
        ScratchDatabase::create("production_manifest_add_announcement_resolver_path").await?;
    let chain_id = "manifest-add-announcement-resolver-path";
    let fixture = WatchManifestFixture::new(chain_id)?;
    fixture.write_discovered_resolver_namespaces("test", "peer", false)?;
    fixture.use_only_undeclared_rule_role("ens_v2_registry_l1")?;
    sync_schema_v2_repository(scratch.pool(), &load_repository(&fixture.root)?).await?;
    seed_completed_ingest_range(&scratch, chain_id).await?;

    // Announced registries can now emit `ResolverUpdated`, but that pointer admits nothing.
    // Only the announcement rule widens intake, and one Ingest redo backfills it.
    fixture.add_test_registry_announcement_rule()?;
    sync_schema_v2_repository(scratch.pool(), &load_repository(&fixture.root)?).await?;
    assert_eq!(
        required_ingest_redo(scratch.pool(), chain_id).await?,
        Some((0, 1))
    );
    scratch.cleanup().await
}

#[tokio::test]
async fn adding_discovery_producer_topics_without_version_rotation_stamps_ingest() -> Result<()> {
    let scratch = ScratchDatabase::create("production_manifest_add_discovery_topics").await?;
    let chain_id = "manifest-add-discovery-topics";
    let fixture = WatchManifestFixture::new(chain_id)?;
    fixture.write_discovered_resolver_namespaces("test", "peer", false)?;
    fixture.add_test_registry_announcement_rule()?;
    fixture.use_only_undeclared_rule_role("ens_v2_registry_l1")?;
    fixture.set_test_registry_discovery_events(false)?;
    sync_schema_v2_repository(scratch.pool(), &load_repository(&fixture.root)?).await?;
    seed_completed_ingest_range(&scratch, chain_id).await?;

    // `RegistryCreated` is backfillable in one Ingest redo, and the `ResolverUpdated` pointer
    // admits no resolver, so neither producer leaves an address Ingest cannot reach.
    fixture.set_test_registry_discovery_events(true)?;
    sync_schema_v2_repository(scratch.pool(), &load_repository(&fixture.root)?).await?;
    assert_eq!(
        required_ingest_redo(scratch.pool(), chain_id).await?,
        Some((0, 1))
    );
    let resolver = "0x0000000000000000000000000000000000000005";
    let text_changed = format!(
        "{:#x}",
        keccak256(b"TextChanged(bytes32,string,string,string)")
    );
    let filter = load_persisted_watch_filter(scratch.pool(), chain_id, 0, 1).await?;
    assert!(
        !filter.includes(resolver, &text_changed, 0),
        "a registry pointer target is never watched"
    );
    scratch.cleanup().await
}

#[tokio::test]
async fn enabling_ens_v2_resolver_pointer_for_rule_role_is_topology_only() -> Result<()> {
    let scratch = ScratchDatabase::create("production_manifest_enable_resolver_role").await?;
    let chain_id = "manifest-enable-resolver-role";
    let fixture = WatchManifestFixture::new(chain_id)?;
    fixture.write_discovered_resolver_namespaces("test", "peer", true)?;
    let path = fixture.root.join("test/ens_v2_registry_l1/v2.toml");
    let manifest = fs::read_to_string(&path)?
        .replacen(
            "[[discovery_rules]]",
            r#"[[contracts]]
role = "event_source"
address = "0x0000000000000000000000000000000000000008"
proxy_kind = "none"
start_block = 0

[[discovery_rules]]"#,
            1,
        )
        .replacen(
            "name = \"ResolverUpdated\"\nfragment = \"event ResolverUpdated(uint256 indexed tokenId, address indexed resolver, address indexed sender)\"\nemitter_roles = [\"registry\"]",
            "name = \"ResolverUpdated\"\nfragment = \"event ResolverUpdated(uint256 indexed tokenId, address indexed resolver, address indexed sender)\"\nemitter_roles = [\"event_source\"]",
            1,
        );
    fs::write(&path, manifest)?;
    sync_schema_v2_repository(scratch.pool(), &load_repository(&fixture.root)?).await?;
    seed_completed_ingest_range(&scratch, chain_id).await?;

    let manifest = fs::read_to_string(&path)?.replacen(
        "emitter_roles = [\"event_source\"]\nnormalized_events = [\"ResolverChanged\"]",
        "emitter_roles = [\"registry\"]\nnormalized_events = [\"ResolverChanged\"]",
        1,
    );
    fs::write(path, manifest)?;
    // The rule's role can now emit `ResolverUpdated`, but the pointer admits no resolver.
    sync_schema_v2_repository(scratch.pool(), &load_repository(&fixture.root)?).await?;
    assert_eq!(required_ingest_redo(scratch.pool(), chain_id).await?, None);
    scratch.cleanup().await
}

#[tokio::test]
async fn declaring_required_registry_announcement_output_is_discovery_widening() -> Result<()> {
    let scratch = ScratchDatabase::create("production_manifest_enable_announcement_output").await?;
    let chain_id = "manifest-enable-announcement-output";
    let fixture = WatchManifestFixture::new(chain_id)?;
    fixture.write_discovered_resolver_namespaces("test", "peer", true)?;
    fixture.add_test_registry_announcement_rule()?;
    let path = fixture.root.join("test/ens_v2_registry_l1/v2.toml");
    let manifest = fs::read_to_string(&path)?
        .replacen(
            "normalized_events = [\"RegistryCreated\"]",
            "normalized_events = []",
            1,
        )
        .replacen(
            "normalized_events = [\"ResolverChanged\"]",
            "normalized_events = []",
            1,
        );
    fs::write(&path, manifest)?;
    sync_schema_v2_repository(scratch.pool(), &load_repository(&fixture.root)?).await?;
    seed_completed_ingest_range(&scratch, chain_id).await?;

    // Declaring the pointer's output enables no address admission, so it stamps nothing.
    let pointer_without_output = "emitter_roles = [\"registry\"]\nnormalized_events = []\n";
    let mut manifest = fs::read_to_string(&path)?;
    let pointer_at = manifest
        .rfind(pointer_without_output)
        .context("test registry has no ResolverUpdated event")?;
    manifest.replace_range(
        pointer_at..pointer_at + pointer_without_output.len(),
        "emitter_roles = [\"registry\"]\nnormalized_events = [\"ResolverChanged\"]\n",
    );
    fs::write(&path, manifest)?;
    sync_schema_v2_repository(scratch.pool(), &load_repository(&fixture.root)?).await?;
    assert_eq!(
        required_ingest_redo(scratch.pool(), chain_id).await?,
        None,
        "an ENSv2 registry pointer is topology-only"
    );

    // The watched topics are unchanged, so only the discovery classifier can stamp this redo.
    let manifest = fs::read_to_string(&path)?.replacen(
        "normalized_events = []",
        "normalized_events = [\"RegistryCreated\"]",
        1,
    );
    fs::write(path, manifest)?;
    sync_schema_v2_repository(scratch.pool(), &load_repository(&fixture.root)?).await?;
    assert_eq!(
        required_ingest_redo(scratch.pool(), chain_id).await?,
        Some((0, 1)),
        "enabling the announcement producer admits registries over retained history"
    );
    scratch.cleanup().await
}

#[tokio::test]
async fn unrelated_normalized_event_change_stays_admissible() -> Result<()> {
    let scratch = ScratchDatabase::create("production_manifest_unrelated_event_attributes").await?;
    let chain_id = "manifest-unrelated-event-attributes";
    let fixture = WatchManifestFixture::new(chain_id)?;
    fixture.write_discovered_resolver_namespaces("test", "peer", true)?;
    sync_schema_v2_repository(scratch.pool(), &load_repository(&fixture.root)?).await?;
    seed_completed_ingest_range(&scratch, chain_id).await?;

    let path = fixture.root.join("test/ens_v2_resolver_l1/v2.toml");
    let manifest = fs::read_to_string(&path)?.replacen(
        "name = \"TextChanged\"\nfragment = \"event TextChanged(bytes32 indexed node, string indexed indexedKey, string key, string value)\"\nnormalized_events = []",
        "name = \"TextChanged\"\nfragment = \"event TextChanged(bytes32 indexed node, string indexed indexedKey, string key, string value)\"\nnormalized_events = [\"RecordChanged\"]",
        1,
    );
    fs::write(path, manifest)?;
    sync_schema_v2_repository(scratch.pool(), &load_repository(&fixture.root)?).await?;
    assert_eq!(required_ingest_redo(scratch.pool(), chain_id).await?, None);
    scratch.cleanup().await
}

#[tokio::test]
async fn persisted_admission_floors_future_resolver_epoch_candidate() -> Result<()> {
    let scratch = ScratchDatabase::create("production_manifest_epoch_admission_floor").await?;
    let chain_id = "manifest-epoch-admission-floor";
    let fixture = WatchManifestFixture::new(chain_id)?;
    fixture.write_admitting_resolver_namespaces("test", "peer", true)?;
    fixture.set_deployment_epoch("test", "ens_v1_registry_l1", "fixture", "matched")?;
    fixture.set_deployment_epoch("test", "ens_v1_resolver_l1", "fixture", "resolver-old")?;
    sync_schema_v2_repository(scratch.pool(), &load_repository(&fixture.root)?).await?;
    seed_completed_ingest_range(&scratch, chain_id).await?;

    fixture.set_contract_start("test", "ens_v1_registry_l1", 0, 2)?;
    fixture.replace_deployment_epoch("test", "ens_v1_resolver_l1", "resolver-old", "matched")?;
    let result = sync_schema_v2_repository(scratch.pool(), &load_repository(&fixture.root)?).await;
    let error = match result {
        Err(error) => error,
        Ok(_) => {
            let floor: Option<i64> = sqlx::query_scalar(
                "SELECT active_from_block_number FROM contract_instance_addresses \
                 WHERE chain_id = $1 AND lower(address) = $2 AND deactivated_at IS NULL",
            )
            .bind(chain_id)
            .bind("0x0000000000000000000000000000000000000004")
            .fetch_one(scratch.pool())
            .await?;
            assert_eq!(
                floor,
                Some(0),
                "re-admission must preserve its historical floor"
            );
            assert_eq!(required_ingest_redo(scratch.pool(), chain_id).await?, None);
            panic!("epoch match was accepted as future-only despite admission from block zero");
        }
    };
    assert!(
        error
            .to_string()
            .contains("newly matching deployment epoch"),
        "{error}"
    );
    scratch.cleanup().await
}

#[tokio::test]
async fn persisted_admission_floor_survives_prior_start_raise() -> Result<()> {
    let scratch = ScratchDatabase::create("production_manifest_split_epoch_floor").await?;
    let chain_id = "manifest-split-epoch-floor";
    let fixture = WatchManifestFixture::new(chain_id)?;
    fixture.write_admitting_resolver_namespaces("test", "peer", true)?;
    fixture.set_deployment_epoch("test", "ens_v1_registry_l1", "fixture", "matched")?;
    fixture.set_deployment_epoch("test", "ens_v1_resolver_l1", "fixture", "resolver-old")?;
    sync_schema_v2_repository(scratch.pool(), &load_repository(&fixture.root)?).await?;
    seed_completed_ingest_range(&scratch, chain_id).await?;

    fixture.set_contract_start("test", "ens_v1_registry_l1", 0, 2)?;
    sync_schema_v2_repository(scratch.pool(), &load_repository(&fixture.root)?).await?;
    assert_eq!(
        test_registry_active_from(scratch.pool(), chain_id).await?,
        Some(0)
    );
    assert_eq!(required_ingest_redo(scratch.pool(), chain_id).await?, None);
    sqlx::query(
        "UPDATE contract_instance_addresses SET provenance = jsonb_build_object( \
             'source', 'registry_announcement') WHERE chain_id = $1 AND lower(address) = $2",
    )
    .bind(chain_id)
    .bind("0x0000000000000000000000000000000000000004")
    .execute(scratch.pool())
    .await?;

    fixture.replace_deployment_epoch("test", "ens_v1_resolver_l1", "resolver-old", "matched")?;
    let result = sync_schema_v2_repository(scratch.pool(), &load_repository(&fixture.root)?).await;
    let error = match result {
        Err(error) => error,
        Ok(_) => {
            assert_eq!(
                test_registry_active_from(scratch.pool(), chain_id).await?,
                Some(0)
            );
            assert_eq!(required_ingest_redo(scratch.pool(), chain_id).await?, None);
            panic!("split epoch match was accepted with retained active_from=0 and redo=None");
        }
    };
    assert!(
        error
            .to_string()
            .contains("newly matching deployment epoch"),
        "{error}"
    );
    scratch.cleanup().await
}

#[tokio::test]
async fn omitted_admission_floor_survives_prior_start_raise() -> Result<()> {
    let scratch = ScratchDatabase::create("production_manifest_split_null_epoch_floor").await?;
    let pool = scratch.pool();
    let chain_id = "manifest-split-null-epoch-floor";
    let fixture = WatchManifestFixture::new(chain_id)?;
    fixture.write_admitting_resolver_namespaces("test", "peer", true)?;
    let path = fixture.root.join("test/ens_v1_registry_l1/v2.toml");
    fs::write(
        &path,
        fs::read_to_string(&path)?.replacen("start_block = 0\n", "", 1),
    )?;
    fixture.set_deployment_epoch("test", "ens_v1_registry_l1", "fixture", "matched")?;
    fixture.set_deployment_epoch("test", "ens_v1_resolver_l1", "fixture", "resolver-old")?;
    sync_schema_v2_repository(pool, &load_repository(&fixture.root)?).await?;
    assert_eq!(test_registry_active_from(pool, chain_id).await?, None);
    seed_completed_ingest_range(&scratch, chain_id).await?;

    fs::write(
        &path,
        fs::read_to_string(&path)?.replacen(
            "proxy_kind = \"none\"\n\n[[discovery_rules]]",
            "proxy_kind = \"none\"\nstart_block = 2\n\n[[discovery_rules]]",
            1,
        ),
    )?;
    sync_schema_v2_repository(pool, &load_repository(&fixture.root)?).await?;
    assert_eq!(test_registry_active_from(pool, chain_id).await?, Some(0));
    assert_eq!(required_ingest_redo(pool, chain_id).await?, None);
    sqlx::query(
        "UPDATE contract_instance_addresses SET active_from_block_number = 2 \
         WHERE chain_id = $1 AND lower(address) = $2 AND deactivated_at IS NULL",
    )
    .bind(chain_id)
    .bind("0x0000000000000000000000000000000000000004")
    .execute(pool)
    .await?;

    fixture.replace_deployment_epoch("test", "ens_v1_resolver_l1", "resolver-old", "matched")?;
    let result = sync_schema_v2_repository(pool, &load_repository(&fixture.root)?).await;
    let error = match result {
        Err(error) => error,
        Ok(_) => panic!("split epoch match was accepted with retained floor=2 and redo=None"),
    };
    assert!(
        error
            .to_string()
            .contains("newly matching deployment epoch"),
        "{error}"
    );
    scratch.cleanup().await
}
#[tokio::test]
async fn omitted_start_raise_without_discovery_widening_is_admissible() -> Result<()> {
    let scratch = ScratchDatabase::create("production_manifest_null_start_narrowing").await?;
    let pool = scratch.pool();
    let chain_id = "manifest-null-start-narrowing";
    let fixture = WatchManifestFixture::new(chain_id)?;
    fixture.write(false, false)?;
    let path = fixture.root.join("test/test_events/v1.toml");
    fs::write(
        &path,
        fs::read_to_string(&path)?.replacen("start_block = 0\n", "", 1),
    )?;
    sync_schema_v2_repository(pool, &load_repository(&fixture.root)?).await?;
    seed_completed_ingest_range(&scratch, chain_id).await?;
    fs::write(
        &path,
        fs::read_to_string(&path)?.replacen(
            "proxy_kind = \"none\"\n\n[[abi.events]]",
            "proxy_kind = \"none\"\nstart_block = 2\n\n[[abi.events]]",
            1,
        ),
    )?;
    sync_schema_v2_repository(pool, &load_repository(&fixture.root)?).await?;
    assert_eq!(test_registry_active_from(pool, chain_id).await?, Some(0));
    assert_eq!(required_ingest_redo(pool, chain_id).await?, None);
    scratch.cleanup().await
}
#[tokio::test]
async fn omitting_a_finite_start_backdates_the_persisted_watch() -> Result<()> {
    let scratch = ScratchDatabase::create("production_manifest_finite_start_omission").await?;
    let pool = scratch.pool();
    let chain_id = "manifest-finite-start-omission";
    let fixture = WatchManifestFixture::new(chain_id)?;
    fixture.write_with_start(false, true, 2)?;
    sync_schema_v2_repository(pool, &load_repository(&fixture.root)?).await?;
    seed_completed_ingest_range(&scratch, chain_id).await?;
    let path = fixture.root.join("test/test_events/v1.toml");
    fs::write(
        &path,
        fs::read_to_string(&path)?.replacen("start_block = 2\n", "", 1),
    )?;
    sync_schema_v2_repository(pool, &load_repository(&fixture.root)?).await?;
    assert_eq!(required_ingest_redo(pool, chain_id).await?, Some((0, 1)));
    let filter = load_persisted_watch_filter(pool, chain_id, 0, 1).await?;
    let transfer = format!("{:#x}", keccak256(b"Transfer(address,address,uint256)"));
    assert!(
        filter.includes("0x0000000000000000000000000000000000000004", &transfer, 0),
        "the redo watch must include the formerly finite address from effective block zero"
    );
    scratch.cleanup().await
}
#[tokio::test]
async fn unchanged_omitted_manifest_repairs_legacy_floor_with_redo() -> Result<()> {
    let scratch = ScratchDatabase::create("production_manifest_legacy_null_floor").await?;
    let pool = scratch.pool();
    let chain_id = "manifest-legacy-null-floor";
    let fixture = WatchManifestFixture::new(chain_id)?;
    fixture.write_discovered_resolver_namespaces("test", "peer", true)?;
    let path = fixture.root.join("test/ens_v2_registry_l1/v2.toml");
    fs::write(
        &path,
        fs::read_to_string(&path)?.replacen("start_block = 0\n", "", 1),
    )?;
    sync_schema_v2_repository(pool, &load_repository(&fixture.root)?).await?;
    seed_completed_ingest_range(&scratch, chain_id).await?;
    sqlx::query(
        "UPDATE chain_phase_state SET input_content_hash = $2 \
         WHERE chain_id = $1 AND phase_name IN ('interpret', 'project')",
    )
    .bind(chain_id)
    .bind(INTERPRETER_CONTENT_HASH)
    .execute(pool)
    .await?;
    sqlx::query(
        "UPDATE contract_instance_addresses SET active_from_block_number = 2 \
         WHERE chain_id = $1 AND lower(address) = $2 AND deactivated_at IS NULL",
    )
    .bind(chain_id)
    .bind("0x0000000000000000000000000000000000000004")
    .execute(pool)
    .await?;
    sync_schema_v2_repository(pool, &load_repository(&fixture.root)?).await?;
    assert_eq!(test_registry_active_from(pool, chain_id).await?, Some(0));
    assert_eq!(required_ingest_redo(pool, chain_id).await?, Some((0, 1)));
    let derived_invalidated: bool = sqlx::query_scalar(
        "SELECT bool_and(input_content_hash LIKE 'manifest-authority:%') \
         FROM chain_phase_state WHERE chain_id = $1 AND phase_name IN ('interpret', 'project')",
    )
    .bind(chain_id)
    .fetch_one(pool)
    .await?;
    assert!(derived_invalidated);
    let marker = interpret_input_hash(pool, chain_id).await?;
    assert_eq!(
        manifest_marker_parts(&marker)?.0,
        "8b98b34fc8ec239072fed32619da4746a5a4ec842b775117864fa1ef9047300c"
    );
    scratch.cleanup().await
}

#[tokio::test]
async fn retired_omitted_initial_epoch_repairs_legacy_floor_on_readmission() -> Result<()> {
    let scratch = ScratchDatabase::create("production_manifest_retired_legacy_null_floor").await?;
    let pool = scratch.pool();
    let chain_id = "manifest-retired-legacy-null-floor";
    let fixture = WatchManifestFixture::new(chain_id)?;
    fixture.write_discovered_resolver_namespaces("test", "peer", true)?;
    fixture.set_deployment_epoch("test", "ens_v2_resolver_l1", "fixture", "resolver-old")?;
    let path = fixture.root.join("test/ens_v2_registry_l1/v2.toml");
    let omitted_manifest = fs::read_to_string(&path)?
        .replacen("start_block = 0\n", "", 1)
        .replacen("roots = []", "roots = []\ndiscovery_rules = []", 1)
        .replacen(
            "[[discovery_rules]]\nedge_kind = \"resolver\"\nfrom_role = \"registry\"\nadmission = \"reachable_from_root\"",
            "",
            1,
        );
    fs::write(&path, &omitted_manifest)?;
    sync_schema_v2_repository(pool, &load_repository(&fixture.root)?).await?;
    seed_completed_ingest_range(&scratch, chain_id).await?;
    sqlx::query(
        "UPDATE contract_instance_addresses SET active_from_block_number = 1 \
         WHERE chain_id = $1 AND lower(address) = $2 AND deactivated_at IS NULL",
    )
    .bind(chain_id)
    .bind("0x0000000000000000000000000000000000000004")
    .execute(pool)
    .await?;

    fs::remove_file(&path)?;
    sync_schema_v2_repository(pool, &load_repository(&fixture.root)?).await?;
    let retired_floor: Option<i64> = sqlx::query_scalar(
        "SELECT active_from_block_number FROM contract_instance_addresses \
         WHERE chain_id = $1 AND lower(address) = $2 AND deactivated_at IS NOT NULL \
         ORDER BY contract_instance_address_id LIMIT 1",
    )
    .bind(chain_id)
    .bind("0x0000000000000000000000000000000000000004")
    .fetch_one(pool)
    .await?;
    assert_eq!(retired_floor, Some(1));
    fs::write(&path, omitted_manifest)?;
    sqlx::query(
        "UPDATE chain_phase_state SET input_content_hash = $2 \
         WHERE chain_id = $1 AND phase_name IN ('interpret', 'project')",
    )
    .bind(chain_id)
    .bind(INTERPRETER_CONTENT_HASH)
    .execute(pool)
    .await?;
    sync_schema_v2_repository(pool, &load_repository(&fixture.root)?).await?;

    let epochs: Vec<(Option<i64>, Option<i64>, bool)> = sqlx::query_as(
        "SELECT active_from_block_number, active_to_block_number, deactivated_at IS NULL \
         FROM contract_instance_addresses WHERE chain_id = $1 AND lower(address) = $2 \
         ORDER BY contract_instance_address_id",
    )
    .bind(chain_id)
    .bind("0x0000000000000000000000000000000000000004")
    .fetch_all(pool)
    .await?;
    assert_eq!(
        epochs,
        vec![(Some(0), Some(1), false), (Some(2), None, true)]
    );

    let filter = load_persisted_watch_filter(pool, chain_id, 0, 1).await?;
    let resolver_updated = format!(
        "{:#x}",
        keccak256(b"ResolverUpdated(uint256,address,address)")
    );
    assert!(
        filter.includes(
            "0x0000000000000000000000000000000000000004",
            &resolver_updated,
            0,
        ),
        "the block-zero redo must include the repaired retired initial epoch"
    );
    assert_eq!(required_ingest_redo(pool, chain_id).await?, Some((0, 1)));
    let derived_invalidated: bool = sqlx::query_scalar(
        "SELECT bool_and(input_content_hash LIKE 'manifest-authority:%') \
         FROM chain_phase_state WHERE chain_id = $1 AND phase_name IN ('interpret', 'project')",
    )
    .bind(chain_id)
    .fetch_one(pool)
    .await?;
    assert!(derived_invalidated);
    let phase_markers: Vec<(String, Option<String>, Option<String>, String)> = sqlx::query_as(
        "SELECT phase_name, input_content_hash, last_error, updated_at::text \
         FROM chain_phase_state WHERE chain_id = $1 AND phase_name IN ('ingest', 'interpret', 'project') \
         ORDER BY phase_name",
    )
    .bind(chain_id)
    .fetch_all(pool)
    .await?;
    sync_schema_v2_repository(pool, &load_repository(&fixture.root)?).await?;
    let repeated_phase_markers: Vec<(String, Option<String>, Option<String>, String)> =
        sqlx::query_as(
            "SELECT phase_name, input_content_hash, last_error, updated_at::text \
             FROM chain_phase_state WHERE chain_id = $1 AND phase_name IN ('ingest', 'interpret', 'project') \
             ORDER BY phase_name",
        )
        .bind(chain_id)
        .fetch_all(pool)
        .await?;
    assert_eq!(repeated_phase_markers, phase_markers);
    scratch.cleanup().await
}

#[tokio::test]
async fn retired_finite_initial_epoch_is_not_repaired_as_omitted() -> Result<()> {
    let scratch = ScratchDatabase::create("production_manifest_retired_finite_floor").await?;
    let pool = scratch.pool();
    let chain_id = "manifest-retired-finite-floor";
    let fixture = WatchManifestFixture::new(chain_id)?;
    fixture.write_discovered_resolver_namespaces("test", "peer", true)?;
    fixture.set_deployment_epoch("test", "ens_v2_resolver_l1", "fixture", "resolver-old")?;
    let path = fixture.root.join("test/ens_v2_registry_l1/v2.toml");
    let finite_manifest = fs::read_to_string(&path)?
        .replacen("start_block = 0", "start_block = 1", 1)
        .replacen("roots = []", "roots = []\ndiscovery_rules = []", 1)
        .replacen(
            "[[discovery_rules]]\nedge_kind = \"resolver\"\nfrom_role = \"registry\"\nadmission = \"reachable_from_root\"",
            "",
            1,
        );
    fs::write(&path, &finite_manifest)?;
    sync_schema_v2_repository(pool, &load_repository(&fixture.root)?).await?;
    seed_completed_ingest_range(&scratch, chain_id).await?;

    fs::remove_file(&path)?;
    sync_schema_v2_repository(pool, &load_repository(&fixture.root)?).await?;
    fs::write(&path, finite_manifest)?;
    sync_schema_v2_repository(pool, &load_repository(&fixture.root)?).await?;
    let epochs: Vec<(Option<i64>, Option<i64>, bool)> = sqlx::query_as(
        "SELECT active_from_block_number, active_to_block_number, deactivated_at IS NULL \
         FROM contract_instance_addresses WHERE chain_id = $1 AND lower(address) = $2 \
         ORDER BY contract_instance_address_id",
    )
    .bind(chain_id)
    .bind("0x0000000000000000000000000000000000000004")
    .fetch_all(pool)
    .await?;
    assert_eq!(
        epochs,
        vec![(Some(1), Some(1), false), (Some(2), None, true)]
    );
    scratch.cleanup().await
}

#[tokio::test]
async fn retired_admission_epoch_remains_a_discovery_floor() -> Result<()> {
    let scratch = ScratchDatabase::create("production_manifest_retired_epoch_floor").await?;
    let chain_id = "manifest-retired-epoch-floor";
    let fixture = WatchManifestFixture::new(chain_id)?;
    fixture.write_admitting_resolver_namespaces("test", "peer", true)?;
    fixture.set_deployment_epoch("test", "ens_v1_registry_l1", "fixture", "matched")?;
    fixture.set_deployment_epoch("test", "ens_v1_resolver_l1", "fixture", "resolver-old")?;
    sync_schema_v2_repository(scratch.pool(), &load_repository(&fixture.root)?).await?;
    seed_completed_ingest_range(&scratch, chain_id).await?;

    let path = fixture.root.join("test/ens_v1_registry_l1/v2.toml");
    let manifest = fs::read_to_string(&path)?;
    fs::remove_file(&path)?;
    sync_schema_v2_repository(scratch.pool(), &load_repository(&fixture.root)?).await?;
    fs::write(
        path,
        manifest.replacen("start_block = 0", "start_block = 2", 1),
    )?;
    let error = sync_schema_v2_repository(scratch.pool(), &load_repository(&fixture.root)?)
        .await
        .expect_err("the retired block-zero admission floors rule re-admission at block two");
    assert!(
        error.to_string().contains("discovery rule widening"),
        "{error}"
    );
    scratch.cleanup().await
}

#[tokio::test]
async fn persisted_admission_floors_direct_rule_widening() -> Result<()> {
    let scratch = ScratchDatabase::create("production_manifest_rule_admission_floor").await?;
    let chain_id = "manifest-rule-admission-floor";
    let fixture = WatchManifestFixture::new(chain_id)?;
    fixture.write_admitting_resolver_namespaces("test", "peer", true)?;
    let path = fixture.root.join("test/ens_v1_registry_l1/v2.toml");
    let rule = "[[discovery_rules]]\nedge_kind = \"resolver\"\nfrom_role = \"registry\"\nadmission = \"reachable_from_root\"";
    fs::write(
        &path,
        fs::read_to_string(&path)?
            .replacen("roots = []", "roots = []\ndiscovery_rules = []", 1)
            .replacen(rule, "", 1),
    )?;
    sync_schema_v2_repository(scratch.pool(), &load_repository(&fixture.root)?).await?;
    seed_completed_ingest_range(&scratch, chain_id).await?;

    let manifest = fs::read_to_string(&path)?
        .replacen("start_block = 0", "start_block = 2", 1)
        .replacen("discovery_rules = []", rule, 1);
    fs::write(path, manifest)?;
    let error = sync_schema_v2_repository(scratch.pool(), &load_repository(&fixture.root)?)
        .await
        .expect_err("the persisted block-zero admission makes this historical widening");
    assert!(
        error.to_string().contains("discovery rule widening"),
        "{error}"
    );
    scratch.cleanup().await
}

#[tokio::test]
async fn persisted_admission_floor_survives_prior_start_raise_for_direct_rule() -> Result<()> {
    let scratch = ScratchDatabase::create("production_manifest_split_rule_floor").await?;
    let chain_id = "manifest-split-rule-floor";
    let fixture = WatchManifestFixture::new(chain_id)?;
    fixture.write_admitting_resolver_namespaces("test", "peer", true)?;
    let path = fixture.root.join("test/ens_v1_registry_l1/v2.toml");
    let rule = "[[discovery_rules]]\nedge_kind = \"resolver\"\nfrom_role = \"registry\"\nadmission = \"reachable_from_root\"";
    fs::write(
        &path,
        fs::read_to_string(&path)?
            .replacen("roots = []", "roots = []\ndiscovery_rules = []", 1)
            .replacen(rule, "", 1),
    )?;
    sync_schema_v2_repository(scratch.pool(), &load_repository(&fixture.root)?).await?;
    seed_completed_ingest_range(&scratch, chain_id).await?;

    fixture.set_contract_start("test", "ens_v1_registry_l1", 0, 2)?;
    sync_schema_v2_repository(scratch.pool(), &load_repository(&fixture.root)?).await?;
    assert_eq!(
        test_registry_active_from(scratch.pool(), chain_id).await?,
        Some(0)
    );
    assert_eq!(required_ingest_redo(scratch.pool(), chain_id).await?, None);

    fs::write(
        &path,
        fs::read_to_string(&path)?.replacen("discovery_rules = []", rule, 1),
    )?;
    let result = sync_schema_v2_repository(scratch.pool(), &load_repository(&fixture.root)?).await;
    let error = match result {
        Err(error) => error,
        Ok(_) => {
            assert_eq!(
                test_registry_active_from(scratch.pool(), chain_id).await?,
                Some(0)
            );
            assert_eq!(required_ingest_redo(scratch.pool(), chain_id).await?, None);
            panic!("split rule addition was accepted with retained active_from=0 and redo=None");
        }
    };
    assert!(
        error.to_string().contains("discovery rule widening"),
        "{error}"
    );
    scratch.cleanup().await
}

#[tokio::test]
async fn root_resolver_pointer_topic_is_ordinary_watch_widening() -> Result<()> {
    let scratch = ScratchDatabase::create("production_manifest_root_resolver_topic_key").await?;
    let chain_id = "manifest-root-resolver-topic-key";
    let fixture = WatchManifestFixture::new(chain_id)?;
    fixture.write_discovered_resolver_namespaces("test", "peer", true)?;
    fixture.set_test_registry_discovery_events(false)?;
    fixture.use_test_root_source()?;
    sync_schema_v2_repository(scratch.pool(), &load_repository(&fixture.root)?).await?;
    seed_completed_ingest_range(&scratch, chain_id).await?;

    let path = fixture.root.join("test/ens_v2_root_l1/v2.toml");
    let mut manifest = fs::read_to_string(&path)?;
    manifest.push_str(
        r#"
[[abi.events]]
name = "ResolverUpdated"
fragment = "event ResolverUpdated(uint256 indexed tokenId, address indexed resolver, address indexed sender)"
emitter_roles = ["registry"]
normalized_events = ["ResolverChanged"]
"#,
    );
    fs::write(path, manifest)?;
    // The root pointer admits no resolver. Its topic is a declared-address watch like any
    // other, which one Ingest redo backfills.
    sync_schema_v2_repository(scratch.pool(), &load_repository(&fixture.root)?).await?;
    assert_eq!(
        required_ingest_redo(scratch.pool(), chain_id).await?,
        Some((0, 1))
    );
    scratch.cleanup().await
}

#[tokio::test]
async fn root_resolver_rule_addition_is_accepted_before_retained_coverage() -> Result<()> {
    let scratch = ScratchDatabase::create("production_manifest_root_resolver_fresh").await?;
    let chain_id = "manifest-root-resolver-fresh";
    let fixture = WatchManifestFixture::new(chain_id)?;
    write_root_resolver_rule_fixture(&fixture, false)?;
    sync_schema_v2_repository(scratch.pool(), &load_repository(&fixture.root)?).await?;
    PhaseStore::new(scratch.pool().clone())
        .initialize_chain(chain_id)
        .await?;
    let seeded_hash = "root-resolver-rule-before-authority";
    sqlx::query(
        "UPDATE chain_phase_state SET input_content_hash = $2
         WHERE chain_id = $1 AND phase_name IN ('interpret', 'project')",
    )
    .bind(chain_id)
    .bind(seeded_hash)
    .execute(scratch.pool())
    .await?;
    let before: (i64, String, i64, i64) = sqlx::query_as(
        "SELECT manifest_id, deployment_label, manifest_version, applied_change_count
         FROM manifest_versions
         WHERE chain_id = $1 AND source_family = 'ens_v2_root_l1'",
    )
    .bind(chain_id)
    .fetch_one(scratch.pool())
    .await?;

    write_root_resolver_rule_fixture(&fixture, true)?;
    sync_schema_v2_repository(scratch.pool(), &load_repository(&fixture.root)?).await?;

    let after: (i64, String, i64, i64) = sqlx::query_as(
        "SELECT manifest_id, deployment_label, manifest_version, applied_change_count
         FROM manifest_versions
         WHERE chain_id = $1 AND source_family = 'ens_v2_root_l1'",
    )
    .bind(chain_id)
    .fetch_one(scratch.pool())
    .await?;
    assert_eq!(after.0, before.0);
    assert_eq!(after.1, "fixture");
    assert_eq!(after.2, 2);
    assert_eq!(after.3, before.3 + 1);
    let rules: Vec<(String, String, String)> = sqlx::query_as(
        "SELECT edge_kind, from_role, admission
         FROM manifest_discovery_rules WHERE manifest_id = $1 ORDER BY edge_kind",
    )
    .bind(after.0)
    .fetch_all(scratch.pool())
    .await?;
    assert_eq!(
        rules,
        [
            (
                "resolver".into(),
                "root_registry".into(),
                "reachable_from_root".into()
            ),
            (
                "subregistry".into(),
                "root_registry".into(),
                "reachable_from_root".into()
            ),
        ]
    );
    assert_eq!(required_ingest_redo(scratch.pool(), chain_id).await?, None);
    let hashes: Vec<String> = sqlx::query_scalar(
        "SELECT input_content_hash FROM chain_phase_state
         WHERE chain_id = $1 AND phase_name IN ('interpret', 'project')
         ORDER BY phase_name",
    )
    .bind(chain_id)
    .fetch_all(scratch.pool())
    .await?;
    assert_eq!(hashes.len(), 2);
    assert!(
        hashes
            .iter()
            .all(|hash| { hash != seeded_hash && hash.starts_with("manifest-authority:") })
    );
    scratch.cleanup().await
}

#[tokio::test]
async fn root_resolver_rule_addition_over_retained_history_is_topology_only() -> Result<()> {
    let scratch = ScratchDatabase::create("production_manifest_root_resolver_retained").await?;
    let chain_id = "manifest-root-resolver-retained";
    let fixture = WatchManifestFixture::new(chain_id)?;
    write_root_resolver_rule_fixture(&fixture, false)?;
    sync_schema_v2_repository(scratch.pool(), &load_repository(&fixture.root)?).await?;
    seed_completed_ingest_range(&scratch, chain_id).await?;
    sqlx::query(
        "UPDATE chain_phase_state SET input_content_hash = phase_name || '-before-root-rule'
         WHERE chain_id = $1",
    )
    .bind(chain_id)
    .execute(scratch.pool())
    .await?;

    // The rule only records which resolver a name uses, so retained history holds no resolver
    // events that a fetch missed. Derived interpretation is still invalidated.
    write_root_resolver_rule_fixture(&fixture, true)?;
    sync_schema_v2_repository(scratch.pool(), &load_repository(&fixture.root)?).await?;
    let rules: Vec<String> = sqlx::query_scalar(
        "SELECT rule.edge_kind FROM manifest_discovery_rules rule
         JOIN manifest_versions manifest USING (manifest_id)
         WHERE manifest.chain_id = $1 AND manifest.source_family = 'ens_v2_root_l1'
         ORDER BY rule.edge_kind",
    )
    .bind(chain_id)
    .fetch_all(scratch.pool())
    .await?;
    assert_eq!(rules, ["resolver", "subregistry"]);
    assert_eq!(required_ingest_redo(scratch.pool(), chain_id).await?, None);
    let hashes: Vec<String> = sqlx::query_scalar(
        "SELECT input_content_hash FROM chain_phase_state
         WHERE chain_id = $1 AND phase_name IN ('interpret', 'project')",
    )
    .bind(chain_id)
    .fetch_all(scratch.pool())
    .await?;
    assert_eq!(hashes.len(), 2);
    assert!(
        hashes
            .iter()
            .all(|hash| hash.starts_with("manifest-authority:")),
        "{hashes:?}"
    );
    scratch.cleanup().await
}

#[tokio::test]
async fn admitting_resolver_rule_addition_rejects_retained_history_atomically() -> Result<()> {
    let scratch = ScratchDatabase::create("production_manifest_resolver_rule_retained").await?;
    let chain_id = "manifest-resolver-rule-retained";
    let fixture = WatchManifestFixture::new(chain_id)?;
    fixture.write_admitting_resolver_namespaces("test", "peer", true)?;
    let path = fixture.root.join("test/ens_v1_registry_l1/v2.toml");
    let rule = "[[discovery_rules]]\nedge_kind = \"resolver\"\nfrom_role = \"registry\"\nadmission = \"reachable_from_root\"";
    fs::write(
        &path,
        fs::read_to_string(&path)?
            .replacen("roots = []", "roots = []\ndiscovery_rules = []", 1)
            .replacen(rule, "", 1),
    )?;
    sync_schema_v2_repository(scratch.pool(), &load_repository(&fixture.root)?).await?;
    seed_completed_ingest_range(&scratch, chain_id).await?;
    sqlx::query(
        "UPDATE chain_phase_state SET input_content_hash = phase_name || '-before-resolver-rule'
         WHERE chain_id = $1",
    )
    .bind(chain_id)
    .execute(scratch.pool())
    .await?;
    let before = manifest_authority_state(scratch.pool(), chain_id).await?;

    fs::write(
        &path,
        fs::read_to_string(&path)?.replacen("discovery_rules = []", rule, 1),
    )?;
    let error = sync_schema_v2_repository(scratch.pool(), &load_repository(&fixture.root)?)
        .await
        .expect_err("retained registry history must reject address-admitting rule widening");
    assert!(
        error.to_string().contains("discovery rule widening"),
        "{error}"
    );
    let after = manifest_authority_state(scratch.pool(), chain_id).await?;
    assert_eq!(
        after, before,
        "the rejected synchronization must roll back atomically"
    );
    assert_eq!(required_ingest_redo(scratch.pool(), chain_id).await?, None);
    scratch.cleanup().await
}

async fn manifest_authority_state(
    pool: &sqlx::PgPool,
    chain_id: &str,
) -> Result<serde_json::Value> {
    Ok(sqlx::query_scalar(
        "SELECT jsonb_build_object(
             'manifests', (
                 SELECT jsonb_agg(to_jsonb(manifest) ORDER BY source_family)
                 FROM manifest_versions manifest WHERE chain_id = $1
             ),
             'rules', (
                 SELECT COALESCE(jsonb_agg(to_jsonb(rule) ORDER BY source_family, edge_kind), '[]')
                 FROM manifest_discovery_rules rule
                 JOIN manifest_versions manifest USING (manifest_id)
                 WHERE manifest.chain_id = $1
             ),
             'history', (
                 SELECT COALESCE(jsonb_agg(to_jsonb(event) ORDER BY normalized_event_id), '[]')
                 FROM normalized_events event
                 WHERE chain_id = $1 AND event_kind = 'SourceManifestUpdated'
             ),
             'phases', (
                 SELECT jsonb_agg(to_jsonb(state) ORDER BY phase_name)
                 FROM chain_phase_state state WHERE chain_id = $1
             )
         )",
    )
    .bind(chain_id)
    .fetch_one(pool)
    .await?)
}

#[tokio::test]
async fn removing_ens_v2_resolver_pointer_topic_is_admissible() -> Result<()> {
    let scratch = ScratchDatabase::create("production_manifest_remove_resolver_topic").await?;
    let chain_id = "manifest-remove-resolver-topic";
    let fixture = WatchManifestFixture::new(chain_id)?;
    fixture.write_discovered_resolver_namespaces("test", "peer", true)?;
    sync_schema_v2_repository(scratch.pool(), &load_repository(&fixture.root)?).await?;
    seed_completed_ingest_range(&scratch, chain_id).await?;

    let path = fixture.root.join("test/ens_v2_registry_l1/v2.toml");
    let manifest = fs::read_to_string(&path)?
        .split_once("\n[[abi.events]]\nname = \"ResolverUpdated\"")
        .context("test registry has no ResolverUpdated producer")?
        .0
        .to_owned();
    fs::write(path, manifest)?;
    // No resolver was admitted through the pointer, so none is left without its producer.
    sync_schema_v2_repository(scratch.pool(), &load_repository(&fixture.root)?).await?;
    assert_eq!(required_ingest_redo(scratch.pool(), chain_id).await?, None);
    scratch.cleanup().await
}

#[tokio::test]
async fn registry_announcement_normalized_drop_stamps_instead_of_rejecting() -> Result<()> {
    let scratch = ScratchDatabase::create("manifest-announcement-normalized-drop").await?;
    let chain_id = "manifest-announcement-normalized-drop";
    let fixture = WatchManifestFixture::new(chain_id)?;
    fixture.write_discovered_resolver_namespaces("test", "peer", true)?;
    fixture.add_test_registry_announcement_rule()?;
    sync_schema_v2_repository(scratch.pool(), &load_repository(&fixture.root)?).await?;
    seed_completed_ingest_range(&scratch, chain_id).await?;

    let path = fixture.root.join("test/ens_v2_registry_l1/v2.toml");
    let manifest = fs::read_to_string(&path)?.replacen(
        "normalized_events = [\"RegistryCreated\"]",
        "normalized_events = []",
        1,
    );
    fs::write(path, manifest)?;
    sync_schema_v2_repository(scratch.pool(), &load_repository(&fixture.root)?).await?;
    assert_eq!(
        required_ingest_redo(scratch.pool(), chain_id).await?,
        Some((0, 1))
    );
    scratch.cleanup().await
}

#[tokio::test]
async fn epoch_flips_without_retained_ingest_history_are_admissible() -> Result<()> {
    for (case, initialize, flipped_family, old_epoch) in [
        (
            "fresh-resolver",
            false,
            "ens_v1_resolver_l1",
            "resolver-old",
        ),
        (
            "fresh-registry",
            false,
            "ens_v1_registry_l1",
            "registry-old",
        ),
        ("empty-resolver", true, "ens_v1_resolver_l1", "resolver-old"),
        ("empty-registry", true, "ens_v1_registry_l1", "registry-old"),
    ] {
        let scratch = ScratchDatabase::create(&format!("production_manifest_epoch_{case}")).await?;
        let chain_id = format!("manifest-epoch-{case}");
        let fixture = WatchManifestFixture::new(&chain_id)?;
        fixture.write_admitting_resolver_namespaces("test", "peer", true)?;
        fixture.set_deployment_epoch("test", flipped_family, "fixture", old_epoch)?;
        sync_schema_v2_repository(scratch.pool(), &load_repository(&fixture.root)?).await?;
        if initialize {
            PhaseStore::new(scratch.pool().clone())
                .initialize_chain(&chain_id)
                .await?;
        }

        fixture.replace_deployment_epoch("test", flipped_family, old_epoch, "fixture")?;
        sync_schema_v2_repository(scratch.pool(), &load_repository(&fixture.root)?).await?;
        assert_eq!(required_ingest_redo(scratch.pool(), &chain_id).await?, None);
        scratch.cleanup().await?;
    }
    Ok(())
}

#[tokio::test]
async fn future_resolver_source_replacement_stays_admissible_beside_a_historical_emitter()
-> Result<()> {
    let scratch = ScratchDatabase::create("production_manifest_future_resolver_source_set").await?;
    let chain_id = "manifest-future-resolver-source-set";
    let fixture = WatchManifestFixture::new(chain_id)?;
    fixture.write(false, false)?;
    fixture.add_source_a_root("0x0000000000000000000000000000000000000008", 0)?;
    fixture.add_discovery_rule("resolver")?;
    sync_schema_v2_repository(scratch.pool(), &load_repository(&fixture.root)?).await?;
    seed_completed_ingest_range(&scratch, chain_id).await?;

    let path = fixture
        .root
        .join("test")
        .join(&fixture.source_family)
        .join("v1.toml");
    let manifest = fs::read_to_string(&path)?.replace(
        "0x0000000000000000000000000000000000000008",
        "0x0000000000000000000000000000000000000009",
    );
    fs::write(path, manifest)?;
    fixture.move_source_a_root_start(0, 2)?;
    sync_schema_v2_repository(scratch.pool(), &load_repository(&fixture.root)?).await?;
    assert_eq!(required_ingest_redo(scratch.pool(), chain_id).await?, None);

    scratch.cleanup().await
}

#[tokio::test]
async fn adding_a_resolver_source_names_rule_widening_not_replacement() -> Result<()> {
    let scratch = ScratchDatabase::create("production_manifest_resolver_source_addition").await?;
    let chain_id = "manifest-resolver-source-addition";
    let fixture = WatchManifestFixture::new(chain_id)?;
    fixture.write(false, false)?;
    fixture.add_discovery_rule("resolver")?;
    sync_schema_v2_repository(scratch.pool(), &load_repository(&fixture.root)?).await?;
    seed_completed_ingest_range(&scratch, chain_id).await?;

    fixture.add_source_a_root("0x0000000000000000000000000000000000000008", 0)?;
    let error = sync_schema_v2_repository(scratch.pool(), &load_repository(&fixture.root)?)
        .await
        .expect_err("adding a historical resolver-rule emitter must reject");
    assert!(
        error.to_string().contains("discovery rule widening")
            && !error.to_string().contains("source replacement"),
        "an additive transition must be diagnosed accurately: {error}"
    );

    scratch.cleanup().await
}

#[tokio::test]
async fn removing_the_only_resolver_rule_emitter_is_admissible_narrowing() -> Result<()> {
    let scratch = ScratchDatabase::create("production_manifest_resolver_emitter_removal").await?;
    let chain_id = "manifest-resolver-emitter-removal";
    let fixture = WatchManifestFixture::new(chain_id)?;
    fixture.write(false, true)?;
    fixture.add_discovery_rule_from_role("resolver", "source_b")?;
    sync_schema_v2_repository(scratch.pool(), &load_repository(&fixture.root)?).await?;
    seed_completed_ingest_range(&scratch, chain_id).await?;

    fixture.write(false, false)?;
    fixture.add_discovery_rule_from_role("resolver", "source_b")?;
    sync_schema_v2_repository(scratch.pool(), &load_repository(&fixture.root)?).await?;
    assert_eq!(
        required_ingest_redo(scratch.pool(), chain_id).await?,
        None,
        "removing the only emitter narrows the discovery rule and needs no redo"
    );

    scratch.cleanup().await
}

#[tokio::test]
async fn adding_the_first_resolver_rule_emitter_names_rule_widening() -> Result<()> {
    let scratch = ScratchDatabase::create("production_manifest_first_resolver_emitter").await?;
    let chain_id = "manifest-first-resolver-emitter";
    let fixture = WatchManifestFixture::new(chain_id)?;
    fixture.write(false, false)?;
    fixture.add_discovery_rule_from_role("resolver", "source_b")?;
    sync_schema_v2_repository(scratch.pool(), &load_repository(&fixture.root)?).await?;
    seed_completed_ingest_range(&scratch, chain_id).await?;

    fixture.write(false, true)?;
    fixture.add_discovery_rule_from_role("resolver", "source_b")?;
    let error = sync_schema_v2_repository(scratch.pool(), &load_repository(&fixture.root)?)
        .await
        .expect_err("adding the first historical resolver-rule emitter must reject");
    assert!(
        error.to_string().contains("discovery rule widening")
            && !error.to_string().contains("source replacement"),
        "the first emitter is widening, not replacement: {error}"
    );

    scratch.cleanup().await
}

#[tokio::test]
async fn compiled_emitter_policy_widening_with_unchanged_manifest_requires_reingest() -> Result<()>
{
    let scratch = ScratchDatabase::create("production_manifest_compiled_policy_widening").await?;
    let chain_id = "manifest-compiled-policy-widening";
    let family = "ens_v1_resolver_l1";
    let fixture = WatchManifestFixture::with_source_family(chain_id, family)?;
    fixture.write(false, false)?;
    sync_schema_v2_repository(scratch.pool(), &load_repository(&fixture.root)?).await?;
    seed_completed_ingest_range(&scratch, chain_id).await?;

    let topic0 = format!("{:#x}", keccak256(b"Transfer(address,address,uint256)"));
    let narrower_compiled_watch = serde_json::json!([{
        "emitter": {
            "kind": "address",
            "family": family,
            "address": "0x0000000000000000000000000000000000000004"
        },
        "topic0": topic0,
        "start": 0
    }]);
    sqlx::query(
        "UPDATE manifest_versions
         SET manifest_payload = jsonb_set(
             manifest_payload, '{_bigname_compiled_watch}', $2::jsonb
         )
         WHERE chain_id = $1 AND rollout_status = 'active'",
    )
    .bind(chain_id)
    .bind(narrower_compiled_watch)
    .execute(scratch.pool())
    .await?;
    sqlx::query(
        "UPDATE chain_phase_state
         SET phase_status = 'running', redo_in_progress = true, redo_mode = 'redo',
             redo_previous_phase_status = 'completed',
             redo_previous_started_at = started_at,
             redo_previous_finished_at = finished_at,
             redo_from_block_number = 0, redo_to_block_number = 1,
             redo_current_block_number = 1, redo_current_block_hash = 'old-policy-checkpoint',
             redo_manifest_authority_fingerprint = repeat('a', 64),
             last_error = 'interrupted old-policy redo',
             started_at = now(), finished_at = NULL
         WHERE chain_id = $1 AND phase_name = 'ingest'",
    )
    .bind(chain_id)
    .execute(scratch.pool())
    .await?;

    sync_schema_v2_repository(scratch.pool(), &load_repository(&fixture.root)?).await?;
    assert_eq!(
        required_ingest_redo(scratch.pool(), chain_id).await?,
        Some((0, 1)),
        "persisted compiled emitter scope must survive a binary policy change"
    );
    let discarded_checkpoint: (Option<i64>, Option<String>) = sqlx::query_as(
        "SELECT redo_current_block_number, redo_manifest_authority_fingerprint
         FROM chain_phase_state WHERE chain_id = $1 AND phase_name = 'ingest'",
    )
    .bind(chain_id)
    .fetch_one(scratch.pool())
    .await?;
    assert_eq!(discarded_checkpoint, (None, None));

    scratch.cleanup().await
}

#[tokio::test]
async fn legacy_payload_upgrade_materializes_compiled_watch_without_spurious_ingest() -> Result<()>
{
    for (case, has_derived_output) in [("derived", true), ("fresh", false)] {
        let scratch =
            ScratchDatabase::create(&format!("production_manifest_legacy_compiled_watch_{case}"))
                .await?;
        let chain_id = format!("manifest-legacy-compiled-watch-{case}");
        let fixture = WatchManifestFixture::new(&chain_id)?;
        fixture.write(false, false)?;
        let repository = load_repository(&fixture.root)?;
        sync_schema_v2_repository(scratch.pool(), &repository).await?;

        if has_derived_output {
            seed_completed_ingest_range(&scratch, &chain_id).await?;
            let head_hash = format!("{chain_id}-manifest-sync-head-1");
            sqlx::query(
                "UPDATE chain_phase_state
                 SET phase_status = 'completed', current_block_number = 1,
                     current_block_hash = $2, target_block_number = 1,
                     target_block_hash = $2, input_content_hash = $3,
                     started_at = now(), finished_at = now()
                 WHERE chain_id = $1 AND phase_name IN ('interpret', 'project')",
            )
            .bind(&chain_id)
            .bind(head_hash)
            .bind(INTERPRETER_CONTENT_HASH)
            .execute(scratch.pool())
            .await?;
        } else {
            PhaseStore::new(scratch.pool().clone())
                .initialize_chain(&chain_id)
                .await?;
        }

        let removed = sqlx::query(
            "UPDATE manifest_versions
             SET manifest_payload = manifest_payload - '_bigname_compiled_watch'
             WHERE chain_id = $1 AND rollout_status = 'active'",
        )
        .bind(&chain_id)
        .execute(scratch.pool())
        .await?;
        assert_eq!(removed.rows_affected(), 1);

        sync_schema_v2_repository(scratch.pool(), &repository).await?;

        let snapshot_count: i64 = sqlx::query_scalar(
            "SELECT count(*) FROM manifest_versions
             WHERE chain_id = $1 AND rollout_status = 'active'
               AND manifest_payload ? '_bigname_compiled_watch'",
        )
        .bind(&chain_id)
        .fetch_one(scratch.pool())
        .await?;
        assert_eq!(
            snapshot_count, 1,
            "the first upgraded sync must persist the snapshot"
        );
        assert_eq!(
            required_ingest_redo(scratch.pool(), &chain_id).await?,
            None,
            "compiling the legacy side under the current binary must not invent widening"
        );

        let derived_hashes: Vec<Option<String>> = sqlx::query_scalar(
            "SELECT input_content_hash FROM chain_phase_state
             WHERE chain_id = $1 AND phase_name IN ('interpret', 'project')
             ORDER BY phase_name",
        )
        .bind(&chain_id)
        .fetch_all(scratch.pool())
        .await?;
        assert_eq!(derived_hashes.len(), 2);
        if has_derived_output {
            assert!(derived_hashes.iter().all(|hash| {
                hash.as_deref()
                    .is_some_and(|hash| hash.starts_with("manifest-authority:"))
            }));
        } else {
            assert_eq!(derived_hashes, [None, None]);
        }

        scratch.cleanup().await?;
    }
    Ok(())
}

#[tokio::test]
async fn legacy_family_watch_without_namespace_syncs_without_spurious_ingest() -> Result<()> {
    let scratch = ScratchDatabase::create("production_manifest_legacy_family_namespace").await?;
    let chain_id = "manifest-legacy-family-namespace";
    // A family-kind watch entry needs an event that is not scoped to its declared roles. The
    // ENSv2 resolver family scopes every role-declared event, so use the ENSv1 resolver family.
    let fixture = WatchManifestFixture::with_source_family(chain_id, "ens_v1_resolver_l1")?;
    fixture.write(false, false)?;
    let repository = load_repository(&fixture.root)?;
    sync_schema_v2_repository(scratch.pool(), &repository).await?;
    seed_completed_ingest_range(&scratch, chain_id).await?;
    sqlx::query(
        "UPDATE chain_phase_state
         SET phase_status = 'completed', current_block_number = 1,
             current_block_hash = $2, target_block_number = 1,
             target_block_hash = $2, input_content_hash = $3,
             started_at = now(), finished_at = now()
         WHERE chain_id = $1 AND phase_name IN ('interpret', 'project')",
    )
    .bind(chain_id)
    .bind(format!("{chain_id}-manifest-sync-head-1"))
    .bind(INTERPRETER_CONTENT_HASH)
    .execute(scratch.pool())
    .await?;

    let changed = sqlx::query(
        "UPDATE manifest_versions
         SET manifest_payload = jsonb_set(
             manifest_payload,
             '{_bigname_compiled_watch}',
             (
                 SELECT jsonb_agg(
                     CASE WHEN entry -> 'emitter' ->> 'kind' = 'family'
                          THEN jsonb_set(
                              entry, '{emitter}', (entry -> 'emitter') - 'namespace'
                          )
                          ELSE entry
                     END ORDER BY position
                 )
                 FROM jsonb_array_elements(
                     manifest_payload -> '_bigname_compiled_watch'
                 ) WITH ORDINALITY AS compiled(entry, position)
             )
         )
         WHERE chain_id = $1 AND rollout_status = 'active'",
    )
    .bind(chain_id)
    .execute(scratch.pool())
    .await?;
    assert_eq!(changed.rows_affected(), 1);
    let legacy_entries: i64 = sqlx::query_scalar(
        "SELECT count(*)
         FROM manifest_versions manifest
         CROSS JOIN LATERAL jsonb_array_elements(
             manifest.manifest_payload -> '_bigname_compiled_watch'
         ) AS compiled(entry)
         WHERE manifest.chain_id = $1
           AND entry -> 'emitter' ->> 'kind' = 'family'
           AND NOT (entry -> 'emitter' ? 'namespace')",
    )
    .bind(chain_id)
    .fetch_one(scratch.pool())
    .await?;
    assert!(
        legacy_entries > 0,
        "the fixture must persist a legacy family entry"
    );

    sync_schema_v2_repository(scratch.pool(), &repository).await?;
    assert_eq!(required_ingest_redo(scratch.pool(), chain_id).await?, None);
    let derived_hashes: Vec<String> = sqlx::query_scalar(
        "SELECT input_content_hash FROM chain_phase_state
         WHERE chain_id = $1 AND phase_name IN ('interpret', 'project')",
    )
    .bind(chain_id)
    .fetch_all(scratch.pool())
    .await?;
    assert!(
        derived_hashes
            .iter()
            .all(|hash| hash.starts_with("manifest-authority:"))
    );
    let missing_namespace: i64 = sqlx::query_scalar(
        "SELECT count(*)
         FROM manifest_versions manifest
         CROSS JOIN LATERAL jsonb_array_elements(
             manifest.manifest_payload -> '_bigname_compiled_watch'
         ) AS compiled(entry)
         WHERE manifest.chain_id = $1
           AND entry -> 'emitter' ->> 'kind' = 'family'
           AND NOT (entry -> 'emitter' ? 'namespace')",
    )
    .bind(chain_id)
    .fetch_one(scratch.pool())
    .await?;
    assert_eq!(missing_namespace, 0, "sync must rewrite the enriched shape");

    scratch.cleanup().await
}

#[tokio::test]
async fn schema_v2_manifest_sync_is_idempotent_and_retires_absent_history() -> Result<()> {
    let scratch = ScratchDatabase::create("production_manifest_sync").await?;
    let root = std::path::Path::new(env!("CARGO_MANIFEST_DIR"))
        .join("../..")
        .join("manifests/mainnet");
    let repository = load_repository(&root)?;

    let first = sync_schema_v2_repository(scratch.pool(), &repository).await?;
    let manifest_ids: Vec<i64> =
        sqlx::query_scalar("SELECT manifest_id FROM manifest_versions ORDER BY manifest_id")
            .fetch_all(scratch.pool())
            .await?;
    let first_event_count: i64 = sqlx::query_scalar(
        "SELECT count(*) FROM normalized_events WHERE event_kind = 'SourceManifestUpdated'",
    )
    .fetch_one(scratch.pool())
    .await?;
    let second = sync_schema_v2_repository(scratch.pool(), &repository).await?;
    let repeated_manifest_ids: Vec<i64> =
        sqlx::query_scalar("SELECT manifest_id FROM manifest_versions ORDER BY manifest_id")
            .fetch_all(scratch.pool())
            .await?;

    assert!(first.manifest_count > 0);
    assert!(first.declaration_count > 0);
    assert!(first.discovery_rule_count > 0);
    assert_eq!(first, second);
    assert_eq!(manifest_ids, repeated_manifest_ids);
    assert_eq!(first_event_count, first.manifest_count as i64);
    let repeated_event_count: i64 = sqlx::query_scalar(
        "SELECT count(*) FROM normalized_events WHERE event_kind = 'SourceManifestUpdated'",
    )
    .fetch_one(scratch.pool())
    .await?;
    assert_eq!(repeated_event_count, first_event_count);
    let mismatched_epoch_count: i64 = sqlx::query_scalar(
        "
        SELECT count(*)
        FROM manifest_versions
        WHERE deployment_label <> manifest_payload ->> 'deployment_epoch'
        ",
    )
    .fetch_one(scratch.pool())
    .await?;
    assert_eq!(mismatched_epoch_count, 0);

    let retained_manifest: (i64, String, i64) = sqlx::query_as(
        "
        SELECT manifest.manifest_id,
               manifest.rollout_status,
               count(declaration.manifest_contract_instance_id)
        FROM manifest_versions manifest
        LEFT JOIN manifest_contract_instances declaration
          ON declaration.manifest_id = manifest.manifest_id
        WHERE manifest.namespace = 'ens'
          AND manifest.source_family = 'ens_v1_reverse_l1'
          AND manifest.chain_id = 'ethereum-mainnet'
        GROUP BY manifest.manifest_id, manifest.rollout_status
        ",
    )
    .fetch_one(scratch.pool())
    .await?;
    assert_eq!(retained_manifest.1, "active");
    assert!(retained_manifest.2 > 0);

    seed_chain_head(scratch.pool(), "ethereum-mainnet", 30_000_000).await?;
    let base_repository = load_repository(root.join("base"))?;
    sync_schema_v2_repository(scratch.pool(), &base_repository).await?;
    let after_subset_sync: (i64, String, i64) = sqlx::query_as(
        "
        SELECT manifest.manifest_id,
               manifest.rollout_status,
               count(declaration.manifest_contract_instance_id)
        FROM manifest_versions manifest
        LEFT JOIN manifest_contract_instances declaration
          ON declaration.manifest_id = manifest.manifest_id
        WHERE manifest.namespace = 'ens'
          AND manifest.source_family = 'ens_v1_reverse_l1'
          AND manifest.chain_id = 'ethereum-mainnet'
        GROUP BY manifest.manifest_id, manifest.rollout_status
        ",
    )
    .fetch_one(scratch.pool())
    .await?;
    assert_eq!(after_subset_sync.0, retained_manifest.0);
    assert_eq!(after_subset_sync.1, "deprecated");
    assert_eq!(after_subset_sync.2, retained_manifest.2);
    let manifest_event_states: Vec<(Option<String>, String)> = sqlx::query_as(
        "
        SELECT before_state ->> 'rollout_status',
               after_state ->> 'rollout_status'
        FROM normalized_events
        WHERE source_manifest_id = $1
          AND event_kind = 'SourceManifestUpdated'
        ORDER BY normalized_event_id
        ",
    )
    .bind(retained_manifest.0)
    .fetch_all(scratch.pool())
    .await?;
    assert_eq!(
        manifest_event_states,
        [
            (None, "active".into()),
            (Some("active".into()), "deprecated".into()),
        ]
    );

    let first_deprecation_identity: String = sqlx::query_scalar(
        "SELECT event_identity FROM normalized_events
         WHERE source_manifest_id = $1
           AND event_kind = 'SourceManifestUpdated'
           AND raw_fact_ref ->> 'applied_change_count' = '2'",
    )
    .bind(retained_manifest.0)
    .fetch_one(scratch.pool())
    .await?;
    sqlx::query(
        "UPDATE manifest_versions
         SET rollout_status = 'active', applied_change_count = 1
         WHERE manifest_id = $1",
    )
    .bind(retained_manifest.0)
    .execute(scratch.pool())
    .await?;
    sync_schema_v2_repository(scratch.pool(), &base_repository).await?;
    let replayed_deprecation: (i64, String) = sqlx::query_as(
        "SELECT count(*), min(event_identity)
         FROM normalized_events
         WHERE source_manifest_id = $1
           AND event_kind = 'SourceManifestUpdated'
           AND raw_fact_ref ->> 'applied_change_count' = '2'",
    )
    .bind(retained_manifest.0)
    .fetch_one(scratch.pool())
    .await?;
    assert_eq!(replayed_deprecation, (1, first_deprecation_identity));

    sync_schema_v2_repository(scratch.pool(), &repository).await?;
    let manifest_event_states: Vec<(Option<String>, String)> = sqlx::query_as(
        "
        SELECT before_state ->> 'rollout_status',
               after_state ->> 'rollout_status'
        FROM normalized_events
        WHERE source_manifest_id = $1
          AND event_kind = 'SourceManifestUpdated'
        ORDER BY normalized_event_id
        ",
    )
    .bind(retained_manifest.0)
    .fetch_all(scratch.pool())
    .await?;
    assert_eq!(
        manifest_event_states,
        [
            (None, "active".into()),
            (Some("active".into()), "deprecated".into()),
            (Some("deprecated".into()), "active".into()),
        ]
    );

    advance_chain_head(scratch.pool(), "ethereum-mainnet", 30_000_001).await?;
    sync_schema_v2_repository(scratch.pool(), &base_repository).await?;
    let manifest_event_states: Vec<(Option<String>, String)> = sqlx::query_as(
        "
        SELECT before_state ->> 'rollout_status',
               after_state ->> 'rollout_status'
        FROM normalized_events
        WHERE source_manifest_id = $1
          AND event_kind = 'SourceManifestUpdated'
        ORDER BY normalized_event_id
        ",
    )
    .bind(retained_manifest.0)
    .fetch_all(scratch.pool())
    .await?;
    assert_eq!(
        manifest_event_states,
        [
            (None, "active".into()),
            (Some("active".into()), "deprecated".into()),
            (Some("deprecated".into()), "active".into()),
            (Some("active".into()), "deprecated".into()),
        ],
        "the second deprecation must append a distinct history event"
    );
    let project_serves_deprecated_manifest: bool = sqlx::query_scalar(
        "SELECT EXISTS (
             SELECT 1
             FROM normalized_events event
             WHERE event.normalized_event_id = (
                       SELECT max(latest.normalized_event_id)
                       FROM normalized_events latest
                       WHERE latest.source_manifest_id = $1
                         AND latest.event_kind = 'SourceManifestUpdated'
                   )
               AND event.after_state ->> 'rollout_status' = 'active'
         )",
    )
    .bind(retained_manifest.0)
    .fetch_one(scratch.pool())
    .await?;
    assert!(
        !project_serves_deprecated_manifest,
        "Project's latest-event selection must stop serving the deprecated manifest"
    );
    let identities_and_counts: Vec<(String, i64)> = sqlx::query_as(
        "SELECT event_identity, (raw_fact_ref ->> 'applied_change_count')::bigint
         FROM normalized_events
         WHERE source_manifest_id = $1
           AND event_kind = 'SourceManifestUpdated'
         ORDER BY normalized_event_id",
    )
    .bind(retained_manifest.0)
    .fetch_all(scratch.pool())
    .await?;
    assert_eq!(
        identities_and_counts
            .iter()
            .map(|(_, count)| *count)
            .collect::<Vec<_>>(),
        [1, 2, 3, 4]
    );
    assert_eq!(
        identities_and_counts
            .iter()
            .map(|(identity, _)| identity)
            .collect::<std::collections::HashSet<_>>()
            .len(),
        4
    );
    let stored_count: i64 = sqlx::query_scalar(
        "SELECT applied_change_count FROM manifest_versions WHERE manifest_id = $1",
    )
    .bind(retained_manifest.0)
    .fetch_one(scratch.pool())
    .await?;
    assert_eq!(stored_count, 4);

    let second_deprecation_identity = identities_and_counts[3].0.clone();
    PhaseStore::new(scratch.pool().clone())
        .initialize_chain("ethereum-mainnet")
        .await?;
    sqlx::query(
        "UPDATE chain_phase_state
         SET phase_status = 'completed', input_content_hash = $2,
             started_at = now(), finished_at = now()
         WHERE chain_id = $1 AND phase_name = 'project'",
    )
    .bind("ethereum-mainnet")
    .bind(INTERPRETER_CONTENT_HASH)
    .execute(scratch.pool())
    .await?;
    sqlx::query(
        "DELETE FROM normalized_events
         WHERE source_manifest_id = $1
           AND event_kind = 'SourceManifestUpdated'
           AND raw_fact_ref ->> 'applied_change_count' = '4'",
    )
    .bind(retained_manifest.0)
    .execute(scratch.pool())
    .await?;
    sqlx::query("UPDATE manifest_versions SET applied_change_count = 3 WHERE manifest_id = $1")
        .bind(retained_manifest.0)
        .execute(scratch.pool())
        .await?;
    let mut lock_connection = scratch.pool().acquire().await?;
    let lock_name = "phase-runner:ethereum-mainnet:interpret";
    let acquired: bool =
        sqlx::query_scalar("SELECT pg_try_advisory_lock(hashtextextended($1::text, 0::bigint))")
            .bind(lock_name)
            .fetch_one(&mut *lock_connection)
            .await?;
    assert!(acquired);
    let error = sync_schema_v2_repository(scratch.pool(), &base_repository)
        .await
        .expect_err("history repair must not race the affected chain's phase writer");
    assert!(error.to_string().contains("phase advisory lock"));
    let released: bool =
        sqlx::query_scalar("SELECT pg_advisory_unlock(hashtextextended($1::text, 0::bigint))")
            .bind(lock_name)
            .fetch_one(&mut *lock_connection)
            .await?;
    assert!(released);
    drop(lock_connection);
    sync_schema_v2_repository(scratch.pool(), &base_repository).await?;
    let repaired_latest: Option<(String, i64)> = sqlx::query_as(
        "SELECT event_identity, (raw_fact_ref ->> 'applied_change_count')::bigint
         FROM normalized_events
         WHERE source_manifest_id = $1
           AND event_kind = 'SourceManifestUpdated'
         ORDER BY normalized_event_id DESC
         LIMIT 1",
    )
    .bind(retained_manifest.0)
    .fetch_optional(scratch.pool())
    .await?;
    assert_eq!(
        repaired_latest,
        Some((second_deprecation_identity, 4)),
        "sync must repair stale history so its newest event agrees with stored current state"
    );
    let hash: Option<String> = sqlx::query_scalar(
        "SELECT input_content_hash FROM chain_phase_state
         WHERE chain_id = $1 AND phase_name = 'project'",
    )
    .bind("ethereum-mainnet")
    .fetch_one(scratch.pool())
    .await?;
    assert_ne!(
        hash.as_deref(),
        Some(INTERPRETER_CONTENT_HASH),
        "history repair must invalidate Project so rows built from the stale event are re-derived"
    );
    assert!(
        hash.as_deref()
            .is_some_and(|hash| hash.starts_with("manifest-authority:")),
        "history repair must leave a manifest-authority invalidation marker"
    );
    scratch.cleanup().await
}

#[tokio::test]
async fn schema_v2_manifest_sync_refuses_a_running_chain_phase() -> Result<()> {
    let scratch = ScratchDatabase::create("production_manifest_sync_phase_lock").await?;
    let root = std::path::Path::new(env!("CARGO_MANIFEST_DIR"))
        .join("../..")
        .join("manifests/mainnet");
    let repository = load_repository(&root)?;
    let mut lock_connection = scratch.pool().acquire().await?;
    let lock_name = "phase-runner:ethereum-mainnet:interpret";
    let acquired: bool =
        sqlx::query_scalar("SELECT pg_try_advisory_lock(hashtextextended($1::text, 0::bigint))")
            .bind(lock_name)
            .fetch_one(&mut *lock_connection)
            .await?;
    assert!(acquired);

    let error = sync_schema_v2_repository(scratch.pool(), &repository)
        .await
        .expect_err("manifest sync must not race a running phase");
    assert!(error.to_string().contains("phase advisory lock"));
    let released: bool =
        sqlx::query_scalar("SELECT pg_advisory_unlock(hashtextextended($1::text, 0::bigint))")
            .bind(lock_name)
            .fetch_one(&mut *lock_connection)
            .await?;
    assert!(released);
    drop(lock_connection);

    let manifests: i64 = sqlx::query_scalar("SELECT count(*) FROM manifest_versions")
        .fetch_one(scratch.pool())
        .await?;
    assert_eq!(manifests, 0);
    scratch.cleanup().await
}

#[tokio::test]
async fn historical_floor_repair_waits_for_executable_readmission() -> Result<()> {
    let scratch = ScratchDatabase::create("production_manifest_historical_floor_lock").await?;
    let retired_chain = "manifest-historical-floor-lock-retired";
    let retired = WatchManifestFixture::new(retired_chain)?;
    retired.write(false, false)?;
    let retired_path = retired.root.join("test/test_events/v1.toml");
    let omitted_manifest = fs::read_to_string(&retired_path)?.replacen("start_block = 0\n", "", 1);
    fs::write(&retired_path, &omitted_manifest)?;
    sync_schema_v2_repository(scratch.pool(), &load_repository(&retired.root)?).await?;
    seed_completed_ingest_range(&scratch, retired_chain).await?;

    let active_chain = "manifest-historical-floor-lock-active";
    let active = WatchManifestFixture::new(active_chain)?;
    active.write_namespace_emitter("active", 0, "resolver", false)?;
    let active_repository = load_repository(&active.root)?;
    sync_schema_v2_repository(scratch.pool(), &active_repository).await?;
    seed_chain_head(scratch.pool(), active_chain, 1).await?;
    sqlx::query(
        "UPDATE contract_instance_addresses SET active_from_block_number = 1 \
         WHERE chain_id = $1 AND lower(address) = $2 AND deactivated_at IS NOT NULL",
    )
    .bind(retired_chain)
    .bind("0x0000000000000000000000000000000000000004")
    .execute(scratch.pool())
    .await?;
    sqlx::query(
        "UPDATE chain_phase_state SET input_content_hash = $2 \
         WHERE chain_id = $1 AND phase_name IN ('interpret', 'project')",
    )
    .bind(retired_chain)
    .bind(INTERPRETER_CONTENT_HASH)
    .execute(scratch.pool())
    .await?;
    let marker_before = interpret_input_hash(scratch.pool(), retired_chain).await?;
    let ingest_updated_before: String = sqlx::query_scalar(
        "SELECT updated_at::text FROM chain_phase_state \
         WHERE chain_id = $1 AND phase_name = 'ingest'",
    )
    .bind(retired_chain)
    .fetch_one(scratch.pool())
    .await?;

    let mut lock_connection = scratch.pool().acquire().await?;
    let lock_name = format!("phase-runner:{retired_chain}:interpret");
    let acquired: bool =
        sqlx::query_scalar("SELECT pg_try_advisory_lock(hashtextextended($1::text, 0::bigint))")
            .bind(&lock_name)
            .fetch_one(&mut *lock_connection)
            .await?;
    assert!(acquired);
    sync_schema_v2_repository(scratch.pool(), &active_repository).await?;
    let retained_floor: Option<i64> = sqlx::query_scalar(
        "SELECT active_from_block_number FROM contract_instance_addresses \
         WHERE chain_id = $1 AND lower(address) = $2 AND deactivated_at IS NOT NULL",
    )
    .bind(retired_chain)
    .bind("0x0000000000000000000000000000000000000004")
    .fetch_one(scratch.pool())
    .await?;
    assert_eq!(retained_floor, Some(1));
    assert_eq!(
        required_ingest_redo(scratch.pool(), retired_chain).await?,
        None
    );
    assert_eq!(
        interpret_input_hash(scratch.pool(), retired_chain).await?,
        marker_before
    );
    let ingest_updated_while_retired: String = sqlx::query_scalar(
        "SELECT updated_at::text FROM chain_phase_state \
         WHERE chain_id = $1 AND phase_name = 'ingest'",
    )
    .bind(retired_chain)
    .fetch_one(scratch.pool())
    .await?;
    assert_eq!(ingest_updated_while_retired, ingest_updated_before);
    let released: bool =
        sqlx::query_scalar("SELECT pg_advisory_unlock(hashtextextended($1::text, 0::bigint))")
            .bind(&lock_name)
            .fetch_one(&mut *lock_connection)
            .await?;
    assert!(released);
    drop(lock_connection);

    sync_schema_v2_repository(scratch.pool(), &load_repository(&retired.root)?).await?;
    let epochs: Vec<(Option<i64>, Option<i64>, bool)> = sqlx::query_as(
        "SELECT active_from_block_number, active_to_block_number, deactivated_at IS NULL \
         FROM contract_instance_addresses WHERE chain_id = $1 AND lower(address) = $2 \
         ORDER BY contract_instance_address_id",
    )
    .bind(retired_chain)
    .bind("0x0000000000000000000000000000000000000004")
    .fetch_all(scratch.pool())
    .await?;
    assert_eq!(
        epochs,
        vec![(Some(0), Some(1), false), (Some(2), None, true)]
    );
    let filter = load_persisted_watch_filter(scratch.pool(), retired_chain, 0, 1).await?;
    let transfer = format!("{:#x}", keccak256(b"Transfer(address,address,uint256)"));
    assert!(filter.includes("0x0000000000000000000000000000000000000004", &transfer, 0,));
    assert_eq!(
        required_ingest_redo(scratch.pool(), retired_chain).await?,
        Some((0, 1))
    );
    let ingest_updated_after: String = sqlx::query_scalar(
        "SELECT updated_at::text FROM chain_phase_state \
         WHERE chain_id = $1 AND phase_name = 'ingest'",
    )
    .bind(retired_chain)
    .fetch_one(scratch.pool())
    .await?;
    assert_ne!(ingest_updated_after, ingest_updated_before);
    let marker_after = interpret_input_hash(scratch.pool(), retired_chain).await?;
    assert_ne!(marker_after, marker_before);
    assert!(marker_after.starts_with("manifest-authority:"));
    scratch.cleanup().await
}

#[tokio::test]
async fn schema_v2_manifest_authority_change_requires_derived_redo() -> Result<()> {
    let scratch = ScratchDatabase::create("production_manifest_sync_invalidation").await?;
    let root = std::path::Path::new(env!("CARGO_MANIFEST_DIR"))
        .join("../..")
        .join("manifests/mainnet");
    sync_schema_v2_repository(scratch.pool(), &load_repository(&root)?).await?;

    let chain_id = "ethereum-mainnet";
    PhaseStore::new(scratch.pool().clone())
        .initialize_chain(chain_id)
        .await?;
    sqlx::query(
        "
        UPDATE chain_phase_state
        SET phase_status = 'completed',
            input_content_hash = $2,
            started_at = now(),
            finished_at = now()
        WHERE chain_id = $1
          AND phase_name IN ('interpret', 'project')
        ",
    )
    .bind(chain_id)
    .bind(INTERPRETER_CONTENT_HASH)
    .execute(scratch.pool())
    .await?;

    seed_chain_head(scratch.pool(), chain_id, 30_000_000).await?;
    let base_repository = load_repository(root.join("base"))?;
    sync_schema_v2_repository(scratch.pool(), &base_repository).await?;
    let hashes: Vec<String> = sqlx::query_scalar(
        "
        SELECT input_content_hash
        FROM chain_phase_state
        WHERE chain_id = $1
          AND phase_name IN ('interpret', 'project')
        ORDER BY phase_name
        ",
    )
    .bind(chain_id)
    .fetch_all(scratch.pool())
    .await?;
    assert_eq!(hashes.len(), 2);
    assert!(
        hashes
            .iter()
            .all(|hash| hash.starts_with("manifest-authority:"))
    );
    scratch.cleanup().await
}

#[tokio::test]
async fn returning_to_the_same_manifest_authority_mints_a_new_generation() -> Result<()> {
    let scratch = ScratchDatabase::create("production_manifest_sync_generation_aba").await?;
    let root = std::path::Path::new(env!("CARGO_MANIFEST_DIR"))
        .join("../..")
        .join("manifests/mainnet");
    let full_repository = load_repository(&root)?;
    let base_repository = load_repository(root.join("base"))?;
    sync_schema_v2_repository(scratch.pool(), &full_repository).await?;

    let chain_id = "ethereum-mainnet";
    PhaseStore::new(scratch.pool().clone())
        .initialize_chain(chain_id)
        .await?;
    sqlx::query(
        "UPDATE chain_phase_state
         SET phase_status = 'completed',
             input_content_hash = $2,
             started_at = now(),
             finished_at = now()
         WHERE chain_id = $1
           AND phase_name IN ('interpret', 'project')",
    )
    .bind(chain_id)
    .bind(INTERPRETER_CONTENT_HASH)
    .execute(scratch.pool())
    .await?;
    seed_chain_head(scratch.pool(), chain_id, 30_000_000).await?;

    sync_schema_v2_repository(scratch.pool(), &base_repository).await?;
    let first_marker: String = sqlx::query_scalar(
        "SELECT input_content_hash
         FROM chain_phase_state
         WHERE chain_id = $1 AND phase_name = 'interpret'",
    )
    .bind(chain_id)
    .fetch_one(scratch.pool())
    .await?;

    sync_schema_v2_repository(scratch.pool(), &full_repository).await?;
    advance_chain_head(scratch.pool(), chain_id, 30_000_001).await?;
    sync_schema_v2_repository(scratch.pool(), &base_repository).await?;
    let second_marker: String = sqlx::query_scalar(
        "SELECT input_content_hash
         FROM chain_phase_state
         WHERE chain_id = $1 AND phase_name = 'interpret'",
    )
    .bind(chain_id)
    .fetch_one(scratch.pool())
    .await?;

    let (first_fingerprint, first_generation) = manifest_marker_parts(&first_marker)?;
    let (second_fingerprint, second_generation) = manifest_marker_parts(&second_marker)?;
    assert_eq!(
        second_fingerprint, first_fingerprint,
        "returning to the same desired manifests must preserve the authority fingerprint"
    );
    assert_ne!(
        second_generation, first_generation,
        "each distinct invalidation must mint a new generation token"
    );

    scratch.cleanup().await
}

#[tokio::test]
async fn basenames_execution_retirement_invalidates_the_base_project_epoch() -> Result<()> {
    let scratch = ScratchDatabase::create("production_manifest_sync_basenames_dependency").await?;
    let root = std::path::Path::new(env!("CARGO_MANIFEST_DIR"))
        .join("../..")
        .join("manifests/mainnet");
    let full_repository = load_repository(&root)?;
    let base_repository = load_repository(root.join("base"))?;
    sync_schema_v2_repository(scratch.pool(), &full_repository).await?;

    let store = PhaseStore::new(scratch.pool().clone());
    for chain_id in ["ethereum-mainnet", "base-mainnet"] {
        store.initialize_chain(chain_id).await?;
        sqlx::query(
            "
            UPDATE chain_phase_state
            SET phase_status = 'completed',
                input_content_hash = $2,
                started_at = now(),
                finished_at = now()
            WHERE chain_id = $1
              AND phase_name IN ('interpret', 'project')
            ",
        )
        .bind(chain_id)
        .bind(INTERPRETER_CONTENT_HASH)
        .execute(scratch.pool())
        .await?;
    }

    let basenames_manifest_id: i64 = sqlx::query_scalar(
        "SELECT manifest_id FROM manifest_versions
         WHERE chain_id = 'ethereum-mainnet'
           AND namespace = 'basenames'
           AND source_family = 'basenames_execution'
           AND manifest_version = 2
           AND rollout_status = 'active'",
    )
    .fetch_one(scratch.pool())
    .await?;
    let active_count: i64 = sqlx::query_scalar(
        "SELECT applied_change_count FROM manifest_versions WHERE manifest_id = $1",
    )
    .bind(basenames_manifest_id)
    .fetch_one(scratch.pool())
    .await?;
    sqlx::query(
        "DELETE FROM normalized_events
         WHERE source_manifest_id = $1
           AND event_kind = 'SourceManifestUpdated'
           AND (raw_fact_ref ->> 'applied_change_count')::bigint = $2",
    )
    .bind(basenames_manifest_id)
    .bind(active_count)
    .execute(scratch.pool())
    .await?;
    sqlx::query("UPDATE manifest_versions SET applied_change_count = $2 WHERE manifest_id = $1")
        .bind(basenames_manifest_id)
        .bind(active_count - 1)
        .execute(scratch.pool())
        .await?;
    sync_schema_v2_repository(scratch.pool(), &full_repository).await?;
    let active_repair_base_hash: String = sqlx::query_scalar(
        "SELECT input_content_hash FROM chain_phase_state
         WHERE chain_id = 'base-mainnet' AND phase_name = 'project'",
    )
    .fetch_one(scratch.pool())
    .await?;
    assert!(
        active_repair_base_hash.starts_with("manifest-authority:"),
        "active basenames_execution history repair must invalidate its Base Project consumer"
    );

    sqlx::query(
        "UPDATE chain_phase_state SET input_content_hash = $1
         WHERE chain_id = 'base-mainnet' AND phase_name = 'project'",
    )
    .bind(INTERPRETER_CONTENT_HASH)
    .execute(scratch.pool())
    .await?;
    let shadow_manifest_id: i64 = sqlx::query_scalar(
        "SELECT manifest_id FROM manifest_versions
         WHERE chain_id = 'ethereum-mainnet'
           AND namespace = 'basenames'
           AND source_family = 'basenames_execution'
           AND manifest_version = 1
           AND rollout_status = 'shadow'",
    )
    .fetch_one(scratch.pool())
    .await?;
    let shadow_count: i64 = sqlx::query_scalar(
        "SELECT applied_change_count FROM manifest_versions WHERE manifest_id = $1",
    )
    .bind(shadow_manifest_id)
    .fetch_one(scratch.pool())
    .await?;
    sqlx::query(
        "DELETE FROM normalized_events
         WHERE source_manifest_id = $1
           AND event_kind = 'SourceManifestUpdated'
           AND (raw_fact_ref ->> 'applied_change_count')::bigint = $2",
    )
    .bind(shadow_manifest_id)
    .bind(shadow_count)
    .execute(scratch.pool())
    .await?;
    sqlx::query(
        "UPDATE manifest_versions
         SET applied_change_count = $2,
             manifest_payload = manifest_payload || '{\"injected_drift\": true}'::jsonb
         WHERE manifest_id = $1",
    )
    .bind(shadow_manifest_id)
    .bind(shadow_count - 1)
    .execute(scratch.pool())
    .await?;
    sync_schema_v2_repository(scratch.pool(), &full_repository).await?;
    let combined_repair_base_hash: String = sqlx::query_scalar(
        "SELECT input_content_hash FROM chain_phase_state
         WHERE chain_id = 'base-mainnet' AND phase_name = 'project'",
    )
    .fetch_one(scratch.pool())
    .await?;
    assert!(
        combined_repair_base_hash.starts_with("manifest-authority:"),
        "inactive payload drift plus history repair must invalidate the Base Project consumer"
    );

    sqlx::query(
        "UPDATE chain_phase_state SET input_content_hash = $1
         WHERE chain_id IN ('ethereum-mainnet', 'base-mainnet')
           AND phase_name IN ('interpret', 'project')",
    )
    .bind(INTERPRETER_CONTENT_HASH)
    .execute(scratch.pool())
    .await?;
    seed_chain_head(scratch.pool(), "ethereum-mainnet", 30_000_000).await?;
    sync_schema_v2_repository(scratch.pool(), &base_repository).await?;

    let project_hashes: Vec<(String, String)> = sqlx::query_as(
        "
        SELECT chain_id, input_content_hash
        FROM chain_phase_state
        WHERE chain_id IN ('ethereum-mainnet', 'base-mainnet')
          AND phase_name = 'project'
        ORDER BY chain_id
        ",
    )
    .fetch_all(scratch.pool())
    .await?;
    assert_eq!(project_hashes.len(), 2);
    assert!(
        project_hashes
            .iter()
            .all(|(_, hash)| hash.starts_with("manifest-authority:")),
        "both the Ethereum authority owner and its Base projection consumer must redo: {project_hashes:?}"
    );
    let base_interpret_hash: String = sqlx::query_scalar(
        "SELECT input_content_hash
         FROM chain_phase_state
         WHERE chain_id = 'base-mainnet' AND phase_name = 'interpret'",
    )
    .fetch_one(scratch.pool())
    .await?;
    assert_eq!(base_interpret_hash, INTERPRETER_CONTENT_HASH);

    let deprecated_count: i64 = sqlx::query_scalar(
        "SELECT applied_change_count FROM manifest_versions WHERE manifest_id = $1",
    )
    .bind(basenames_manifest_id)
    .fetch_one(scratch.pool())
    .await?;
    sqlx::query(
        "DELETE FROM normalized_events
         WHERE source_manifest_id = $1
           AND event_kind = 'SourceManifestUpdated'
           AND (raw_fact_ref ->> 'applied_change_count')::bigint = $2",
    )
    .bind(basenames_manifest_id)
    .bind(deprecated_count)
    .execute(scratch.pool())
    .await?;
    sqlx::query("UPDATE manifest_versions SET applied_change_count = $2 WHERE manifest_id = $1")
        .bind(basenames_manifest_id)
        .bind(deprecated_count - 1)
        .execute(scratch.pool())
        .await?;
    sqlx::query(
        "UPDATE chain_phase_state SET input_content_hash = $1
         WHERE chain_id = 'base-mainnet' AND phase_name = 'project'",
    )
    .bind(INTERPRETER_CONTENT_HASH)
    .execute(scratch.pool())
    .await?;
    sync_schema_v2_repository(scratch.pool(), &base_repository).await?;
    let deprecated_repair_base_hash: String = sqlx::query_scalar(
        "SELECT input_content_hash FROM chain_phase_state
         WHERE chain_id = 'base-mainnet' AND phase_name = 'project'",
    )
    .fetch_one(scratch.pool())
    .await?;
    assert!(
        deprecated_repair_base_hash.starts_with("manifest-authority:"),
        "deprecated basenames_execution history repair must invalidate its Base Project consumer"
    );
    scratch.cleanup().await
}

#[tokio::test]
async fn schema_v2_manifest_readmission_appends_an_address_epoch() -> Result<()> {
    let scratch = ScratchDatabase::create("production_manifest_sync_address_epoch").await?;
    let root = std::path::Path::new(env!("CARGO_MANIFEST_DIR"))
        .join("../..")
        .join("manifests/mainnet");
    let repository = load_repository(&root)?;
    sync_schema_v2_repository(scratch.pool(), &repository).await?;

    let address = "0xa58e81fe9b61b5c3fe2afd33cf304c454abfc7cb";
    let (first_row_id, instance_id, active_from): (i64, Uuid, Option<i64>) = sqlx::query_as(
        "
        SELECT contract_instance_address_id,
               contract_instance_id,
               active_from_block_number
        FROM contract_instance_addresses
        WHERE chain_id = 'ethereum-mainnet'
          AND lower(address) = $1
          AND deactivated_at IS NULL
        ",
    )
    .bind(address)
    .fetch_one(scratch.pool())
    .await?;

    let inactive_at = 30_000_000;
    seed_chain_head(scratch.pool(), "ethereum-mainnet", inactive_at).await?;
    sync_schema_v2_repository(scratch.pool(), &load_repository(root.join("base"))?).await?;
    sync_schema_v2_repository(scratch.pool(), &repository).await?;
    let rows: Vec<AddressEpoch> = sqlx::query_as(
        "
        SELECT contract_instance_address_id,
               contract_instance_id,
               active_from_block_number,
               active_to_block_number,
               deactivated_at IS NULL
        FROM contract_instance_addresses
        WHERE chain_id = 'ethereum-mainnet'
          AND lower(address) = $1
        ORDER BY contract_instance_address_id
        ",
    )
    .bind(address)
    .fetch_all(scratch.pool())
    .await?;
    assert_eq!(rows.len(), 2);
    assert_eq!(
        rows[0],
        (
            first_row_id,
            instance_id,
            active_from,
            Some(inactive_at),
            false
        )
    );
    assert_eq!(rows[1].1, instance_id);
    assert_eq!(rows[1].2, Some(inactive_at + 1));
    assert_eq!(rows[1].3, None);
    assert!(rows[1].4);
    scratch.cleanup().await
}

async fn exact_manifest_sync_snapshot(
    pool: &sqlx::PgPool,
    chain_id: &str,
) -> Result<serde_json::Value> {
    Ok(sqlx::query_scalar(
        "SELECT jsonb_build_object(
             'manifest_versions', COALESCE((
                 SELECT jsonb_agg(to_jsonb(row) ORDER BY row.manifest_id)
                 FROM (SELECT * FROM manifest_versions WHERE chain_id = $1) row
             ), '[]'::jsonb),
             'manifest_contract_instances', COALESCE((
                 SELECT jsonb_agg(to_jsonb(row)
                                  ORDER BY row.manifest_contract_instance_id)
                 FROM (
                     SELECT declaration.*
                     FROM manifest_contract_instances declaration
                     JOIN manifest_versions manifest
                       ON manifest.manifest_id = declaration.manifest_id
                     WHERE manifest.chain_id = $1
                 ) row
             ), '[]'::jsonb),
             'manifest_discovery_rules', COALESCE((
                 SELECT jsonb_agg(to_jsonb(row)
                                  ORDER BY row.manifest_discovery_rule_id)
                 FROM (
                     SELECT rule.*
                     FROM manifest_discovery_rules rule
                     JOIN manifest_versions manifest
                       ON manifest.manifest_id = rule.manifest_id
                     WHERE manifest.chain_id = $1
                 ) row
             ), '[]'::jsonb),
             'contract_instances', COALESCE((
                 SELECT jsonb_agg(to_jsonb(row) ORDER BY row.contract_instance_id)
                 FROM (SELECT * FROM contract_instances WHERE chain_id = $1) row
             ), '[]'::jsonb),
             'contract_instance_addresses', COALESCE((
                 SELECT jsonb_agg(to_jsonb(row)
                                  ORDER BY row.contract_instance_address_id)
                 FROM (SELECT * FROM contract_instance_addresses WHERE chain_id = $1) row
             ), '[]'::jsonb),
             'discovery_edges', COALESCE((
                 SELECT jsonb_agg(to_jsonb(row) ORDER BY row.discovery_edge_id)
                 FROM (SELECT * FROM discovery_edges WHERE chain_id = $1) row
             ), '[]'::jsonb),
             'normalized_events', COALESCE((
                 SELECT jsonb_agg(to_jsonb(row) ORDER BY row.normalized_event_id)
                 FROM (SELECT * FROM normalized_events WHERE chain_id = $1) row
             ), '[]'::jsonb),
             'chain_phase_state', COALESCE((
                 SELECT jsonb_agg(to_jsonb(row) ORDER BY row.phase_name)
                 FROM (SELECT * FROM chain_phase_state WHERE chain_id = $1) row
             ), '[]'::jsonb)
         )",
    )
    .bind(chain_id)
    .fetch_one(pool)
    .await?)
}

async fn seed_completed_ingest_range(
    scratch: &ScratchDatabase,
    chain_id: &str,
) -> Result<ChainConfig> {
    seed_completed_ingest_range_through(scratch, chain_id, 1).await
}

async fn test_registry_active_from(pool: &sqlx::PgPool, chain_id: &str) -> Result<Option<i64>> {
    Ok(sqlx::query_scalar(
        "SELECT active_from_block_number FROM contract_instance_addresses \
         WHERE chain_id = $1 AND lower(address) = $2 AND deactivated_at IS NULL",
    )
    .bind(chain_id)
    .bind("0x0000000000000000000000000000000000000004")
    .fetch_one(pool)
    .await?)
}

async fn interpret_input_hash(pool: &sqlx::PgPool, chain_id: &str) -> Result<String> {
    let query = sqlx::query_scalar(
        "SELECT input_content_hash FROM chain_phase_state
         WHERE chain_id = $1 AND phase_name = 'interpret'",
    );
    Ok(query.bind(chain_id).fetch_one(pool).await?)
}

/// Seeds one discovered resolver the way Interpret materializes it for `pair`.
///
/// An ENSv1 resolver hangs off its registry's pointer edge. An ENSv2 registry pointer admits
/// nothing, so an ENSv2 resolver is seeded as the implementation self-announcement
/// (`Upgraded`) that the resolver manifest anchors, running from the implementation instance.
async fn seed_discovered_resolver_address(
    pool: &sqlx::PgPool,
    chain_id: &str,
    pair: ResolverPair,
    namespace: &str,
    address: &str,
) -> Result<()> {
    let resolver_manifest_id: i64 = sqlx::query_scalar(
        "SELECT manifest_id FROM manifest_versions
         WHERE chain_id = $1 AND namespace = $2 AND source_family = $3",
    )
    .bind(chain_id)
    .bind(namespace)
    .bind(pair.resolver_family())
    .fetch_one(pool)
    .await?;
    let insert_instance = "INSERT INTO contract_instances (
             contract_instance_id, chain_id, contract_kind, provenance
         ) VALUES ($1, $2, 'contract', '{}'::jsonb)";
    let (source_manifest_id, source_instance_id, discovery_source, admission_basis) = match pair {
        ResolverPair::EnsV1 => {
            let (manifest_id, instance_id): (i64, Uuid) = sqlx::query_as(
                "SELECT manifest.manifest_id, declaration.contract_instance_id
                 FROM manifest_versions manifest
                 JOIN manifest_contract_instances declaration
                   ON declaration.manifest_id = manifest.manifest_id
                 WHERE manifest.chain_id = $1 AND manifest.namespace = $2
                   AND manifest.source_family = $3",
            )
            .bind(chain_id)
            .bind(namespace)
            .bind(pair.registry_family())
            .fetch_one(pool)
            .await?;
            (manifest_id, instance_id, "fixture", "reachable_from_root")
        }
        ResolverPair::EnsV2 => {
            let implementation_instance_id = Uuid::new_v4();
            sqlx::query(insert_instance)
                .bind(implementation_instance_id)
                .bind(chain_id)
                .execute(pool)
                .await?;
            (
                resolver_manifest_id,
                implementation_instance_id,
                "Upgraded",
                "declared_resolver_implementation",
            )
        }
    };
    let resolver_instance_id = Uuid::new_v4();
    sqlx::query(insert_instance)
        .bind(resolver_instance_id)
        .bind(chain_id)
        .execute(pool)
        .await?;
    sqlx::query(
        "INSERT INTO contract_instance_addresses (
             contract_instance_id, chain_id, address, active_from_block_number,
             source_manifest_id, provenance
         ) VALUES ($1, $2, $3, 0, $4, '{}'::jsonb)",
    )
    .bind(resolver_instance_id)
    .bind(chain_id)
    .bind(address)
    .bind(resolver_manifest_id)
    .execute(pool)
    .await?;
    sqlx::query(
        "INSERT INTO discovery_edges (
             chain_id, edge_kind, from_contract_instance_id, to_contract_instance_id,
             discovery_source, admission_basis, source_manifest_id,
             active_from_block_number, active_from_block_hash, canonicality_state,
             provenance
         ) VALUES ($1, 'resolver', $2, $3, $4, $5,
                   $6, 0, $7, 'finalized', '{}'::jsonb)",
    )
    .bind(chain_id)
    .bind(source_instance_id)
    .bind(resolver_instance_id)
    .bind(discovery_source)
    .bind(admission_basis)
    .bind(source_manifest_id)
    .bind(format!("{chain_id}-{namespace}-discovery-block-0"))
    .execute(pool)
    .await?;
    Ok(())
}

async fn seed_announced_registry_address(
    pool: &sqlx::PgPool,
    chain_id: &str,
    namespace: &str,
    address: &str,
) -> Result<()> {
    let source_manifest_id: i64 = sqlx::query_scalar(
        "SELECT manifest_id FROM manifest_versions
         WHERE chain_id = $1 AND namespace = $2
           AND source_family = 'ens_v2_registry_l1' AND rollout_status = 'active'",
    )
    .bind(chain_id)
    .bind(namespace)
    .fetch_one(pool)
    .await?;
    let instance_id = Uuid::new_v4();
    sqlx::query(
        "INSERT INTO contract_instances (
             contract_instance_id, chain_id, contract_kind, provenance
         ) VALUES ($1, $2, 'contract', '{}'::jsonb)",
    )
    .bind(instance_id)
    .bind(chain_id)
    .execute(pool)
    .await?;
    sqlx::query(
        "INSERT INTO contract_instance_addresses (
             contract_instance_id, chain_id, address, active_from_block_number,
             source_manifest_id, provenance
         ) VALUES ($1, $2, $3, 0, $4, '{}'::jsonb)",
    )
    .bind(instance_id)
    .bind(chain_id)
    .bind(address)
    .bind(source_manifest_id)
    .execute(pool)
    .await?;
    sqlx::query(
        "INSERT INTO discovery_edges (
             chain_id, edge_kind, from_contract_instance_id, to_contract_instance_id,
             discovery_source, admission_basis, source_manifest_id,
             active_from_block_number, active_from_block_hash, canonicality_state,
             provenance
         ) VALUES ($1, 'registry_announcement', $2, $2, 'RegistryCreated',
                   'reachable_from_root', $3, 0, $4, 'finalized', '{}'::jsonb)",
    )
    .bind(chain_id)
    .bind(instance_id)
    .bind(source_manifest_id)
    .bind(format!("{chain_id}-manifest-sync-head-0"))
    .execute(pool)
    .await?;
    Ok(())
}

async fn seed_retained_registry_announcement(
    pool: &sqlx::PgPool,
    chain_id: &str,
    block_number: i64,
) -> Result<()> {
    let block_hash = format!("{chain_id}-manifest-sync-head-{block_number}");
    sqlx::query(
        "INSERT INTO chain_lineage (
             chain_id, block_hash, block_number, block_timestamp, canonicality_state
         ) VALUES ($1, $2, $3, to_timestamp($3), 'canonical')",
    )
    .bind(chain_id)
    .bind(&block_hash)
    .bind(block_number)
    .execute(pool)
    .await?;
    let transaction_hash = format!("{chain_id}-announcement-{block_number}");
    sqlx::query(
        "INSERT INTO raw_transactions (
             chain_id, block_hash, block_number, transaction_hash,
             transaction_index, from_address, to_address
         ) VALUES ($1, $2, $3, $4, 0, $5, $6)",
    )
    .bind(chain_id)
    .bind(&block_hash)
    .bind(block_number)
    .bind(&transaction_hash)
    .bind("0x0000000000000000000000000000000000000008")
    .bind("0x0000000000000000000000000000000000000009")
    .execute(pool)
    .await?;
    sqlx::query(
        "INSERT INTO raw_logs (
             chain_id, block_hash, block_number, transaction_hash,
             transaction_index, log_index, emitting_address, topics
         ) VALUES ($1, $2, $3, $4, 0, 0, $5, $6)",
    )
    .bind(chain_id)
    .bind(block_hash)
    .bind(block_number)
    .bind(transaction_hash)
    .bind("0x0000000000000000000000000000000000000009")
    .bind(vec![registry_announcement_topic0()])
    .execute(pool)
    .await?;
    Ok(())
}

async fn seed_completed_ingest_range_through(
    scratch: &ScratchDatabase,
    chain_id: &str,
    through: i64,
) -> Result<ChainConfig> {
    let source = SourceConfig::new(
        chain_id,
        "rpc",
        "rpc",
        SeedBasis::NewSignatureRange,
        0,
        "http://127.0.0.1:1",
    )?;
    let chain = ChainConfig::new(chain_id, vec![source.clone()], false)?;
    let store = PhaseStore::new(scratch.pool().clone());
    store.initialize_chain(chain_id).await?;
    store.ensure_ingest_sources(chain_id, &[source]).await?;
    seed_chain_head(scratch.pool(), chain_id, 0).await?;
    advance_chain_head(scratch.pool(), chain_id, through).await?;
    let block_hash = format!("{chain_id}-manifest-sync-head-{through}");
    sqlx::query(
        "UPDATE ingest_cursors
         SET next_block_number = $2 + 1, target_block_number = $2,
             last_processed_block_number = $2,
             last_processed_block_hash = $3
         WHERE chain_id = $1 AND source_key = 'rpc'",
    )
    .bind(chain_id)
    .bind(through)
    .bind(&block_hash)
    .execute(scratch.pool())
    .await?;
    sqlx::query(
        "UPDATE chain_phase_state
         SET phase_status = 'completed', current_block_number = $2,
             current_block_hash = $3, target_block_number = $2,
             target_block_hash = $3, live_handoff_block_number = $2,
             live_handoff_block_hash = $3, started_at = now(), finished_at = now()
         WHERE chain_id = $1 AND phase_name = 'ingest'",
    )
    .bind(chain_id)
    .bind(through)
    .bind(block_hash)
    .execute(scratch.pool())
    .await?;
    Ok(chain)
}

async fn required_ingest_redo(pool: &sqlx::PgPool, chain_id: &str) -> Result<Option<(i64, i64)>> {
    Ok(sqlx::query_as(
        "SELECT redo_from_block_number, redo_to_block_number
         FROM chain_phase_state
         WHERE chain_id = $1 AND phase_name = 'ingest'
           AND redo_in_progress
           AND last_error LIKE 'required downstream redo: %'",
    )
    .bind(chain_id)
    .fetch_optional(pool)
    .await?)
}

fn checked_in_sepolia_root() -> std::path::PathBuf {
    std::path::Path::new(env!("CARGO_MANIFEST_DIR"))
        .join("../..")
        .join("manifests/sepolia")
}

const SEPOLIA_PERMISSIONED_RESOLVER_IMPL: &str = "0x115eb53f0c60696633855f90b138178fb40b2b2c";

fn copy_dir(source: &std::path::Path, target: &std::path::Path) -> Result<()> {
    fs::create_dir_all(target)?;
    for entry in fs::read_dir(source)? {
        let entry = entry?;
        let source_path = entry.path();
        let target_path = target.join(entry.file_name());
        if source_path.is_dir() {
            copy_dir(&source_path, &target_path)?;
        } else {
            fs::copy(source_path, target_path)?;
        }
    }
    Ok(())
}

fn copy_profile_with_v2_resolver(
    source: &std::path::Path,
    edit: impl FnOnce(String) -> String,
) -> Result<std::path::PathBuf> {
    let target = std::env::temp_dir().join(format!(
        "bigname-sepolia-v2-resolver-edit-{}",
        Uuid::new_v4()
    ));
    copy_dir(source, &target)?;
    let path = target.join("ethereum/ens/ens_v2_resolver_l1/v2.toml");
    let original = fs::read_to_string(&path)?;
    let edited = edit(original.clone());
    anyhow::ensure!(
        edited != original,
        "the resolver manifest edit matched nothing"
    );
    fs::write(path, edited)?;
    Ok(target)
}

async fn compiled_implementation_starts(pool: &sqlx::PgPool) -> Result<Vec<(String, i64)>> {
    Ok(sqlx::query_as(
        "SELECT lower(entry -> 'emitter' ->> 'implementation'), (entry ->> 'start')::bigint
         FROM manifest_versions manifest
         CROSS JOIN LATERAL jsonb_array_elements(
             manifest.manifest_payload -> '_bigname_compiled_watch'
         ) AS compiled(entry)
         WHERE manifest.chain_id = 'ethereum-sepolia'
           AND manifest.source_family = 'ens_v2_resolver_l1'
           AND manifest.rollout_status = 'active'
           AND entry -> 'emitter' ->> 'kind' = 'implementation'
         ORDER BY 1",
    )
    .fetch_all(pool)
    .await?)
}

fn copy_profile_without_resolver(source: &std::path::Path) -> Result<std::path::PathBuf> {
    let target = std::env::temp_dir().join(format!(
        "bigname-sepolia-without-v1-resolver-{}",
        Uuid::new_v4()
    ));
    copy_dir(source, &target)?;
    fs::remove_dir_all(target.join("ethereum/ens/ens_v1_resolver_l1"))?;
    Ok(target)
}

async fn seed_chain_head(pool: &sqlx::PgPool, chain_id: &str, number: i64) -> Result<()> {
    let hash = format!("{chain_id}-manifest-sync-head-{number}");
    sqlx::query(
        "
        INSERT INTO chain_lineage (
            chain_id, block_hash, block_number, block_timestamp, canonicality_state
        )
        VALUES ($1, $2, $3, to_timestamp($3), 'canonical')
        ",
    )
    .bind(chain_id)
    .bind(&hash)
    .bind(number)
    .execute(pool)
    .await?;
    sqlx::query(
        "
        INSERT INTO chain_heads (chain_id, latest_block_hash, latest_block_number)
        VALUES ($1, $2, $3)
        ",
    )
    .bind(chain_id)
    .bind(hash)
    .bind(number)
    .execute(pool)
    .await?;
    Ok(())
}

async fn advance_chain_head(pool: &sqlx::PgPool, chain_id: &str, number: i64) -> Result<()> {
    let hash = format!("{chain_id}-manifest-sync-head-{number}");
    sqlx::query(
        "INSERT INTO chain_lineage (
             chain_id, block_hash, block_number, block_timestamp, canonicality_state
         ) VALUES ($1, $2, $3, to_timestamp($3), 'canonical')",
    )
    .bind(chain_id)
    .bind(&hash)
    .bind(number)
    .execute(pool)
    .await?;
    sqlx::query(
        "UPDATE chain_heads
         SET latest_block_hash = $2, latest_block_number = $3
         WHERE chain_id = $1",
    )
    .bind(chain_id)
    .bind(hash)
    .bind(number)
    .execute(pool)
    .await?;
    Ok(())
}

fn manifest_marker_parts(marker: &str) -> Result<(&str, &str)> {
    let encoded = marker
        .strip_prefix("manifest-authority:")
        .ok_or_else(|| anyhow::anyhow!("marker has no manifest-authority prefix: {marker}"))?;
    encoded
        .rsplit_once(':')
        .ok_or_else(|| anyhow::anyhow!("marker has no invalidation generation: {marker}"))
}

// Issue #553 regressions cover both supported manifest declaration-removal workflows and
// the existing still-declared re-synchronization behavior.

use bigname_interpret::{
    BatchRequest as ProbeBatchRequest, Engine as ProbeEngine, RunMode as ProbeInterpretRunMode,
};

const PROBE_DECLARED_REGISTRY: &str = "0x0000000000000000000000000000000000000004";
const PROBE_KEPT_CONTRACT: &str = "0x0000000000000000000000000000000000000006";
const PROBE_CONTROL_CONTRACT: &str = "0x0000000000000000000000000000000000000007";
const PROBE_NEXT_EPOCH_REGISTRY: &str = "0x000000000000000000000000000000000000000a";

const PROBE_LABEL_REGISTERED_SIGNATURE: &[u8] =
    b"LabelRegistered(uint256,bytes32,string,address,uint64,address)";

fn probe_manifest_dir(fixture: &WatchManifestFixture) -> std::path::PathBuf {
    fixture.root.join("test").join("ens_v2_registry_l1")
}

fn probe_initial_manifest(chain_id: &str) -> String {
    format!(
        r#"manifest_version = 1
namespace = "test"
source_family = "ens_v2_registry_l1"
chain = "{chain_id}"
deployment_epoch = "fixture"
rollout_status = "active"
normalizer_version = "ensip15@ens-normalize-0.1.1"
roots = []

[capability_flags]

[[contracts]]
role = "source_a"
address = "{PROBE_DECLARED_REGISTRY}"
proxy_kind = "none"
start_block = 0

[[contracts]]
role = "source_b"
address = "{PROBE_KEPT_CONTRACT}"
proxy_kind = "none"
start_block = 0

[[contracts]]
role = "source_c"
address = "{PROBE_CONTROL_CONTRACT}"
proxy_kind = "none"
start_block = 0

[[discovery_rules]]
edge_kind = "registry_announcement"
from_role = "source_a"
admission = "reachable_from_root"

[[abi.events]]
name = "RegistryCreated"
fragment = "event RegistryCreated()"
emitter_roles = ["source_a"]
normalized_events = ["RegistryCreated"]
status = "supported"

[[abi.events]]
name = "LabelRegistered"
fragment = "event LabelRegistered(uint256 indexed tokenId, bytes32 indexed labelHash, string label, address owner, uint64 expiry, address indexed sender)"
emitter_roles = ["source_a"]
normalized_events = ["RegistrationGranted"]
status = "supported"
"#
    )
}

/// (source, active_from, active_to, deactivated, source manifest) for the newest address epoch.
async fn probe_address_state(
    pool: &sqlx::PgPool,
    chain_id: &str,
    address: &str,
) -> Result<(
    Option<String>,
    Option<i64>,
    Option<i64>,
    bool,
    Option<i64>,
    serde_json::Value,
)> {
    Ok(sqlx::query_as(
        "SELECT provenance ->> 'source', active_from_block_number, active_to_block_number, \
         deactivated_at IS NOT NULL, source_manifest_id, provenance \
         FROM contract_instance_addresses \
         WHERE chain_id = $1 AND lower(address) = lower($2) \
         ORDER BY admitted_at DESC, contract_instance_address_id DESC LIMIT 1",
    )
    .bind(chain_id)
    .bind(address)
    .fetch_one(pool)
    .await?)
}

/// Mirrors the address-join gate of the v2 subregistry-pointer topology read
/// (crates/project/src/scope/topology.rs:133-140): any non-deactivated address row whose
/// active interval covers the block keeps matching topology scope expansion.
async fn probe_topology_address_gate(
    pool: &sqlx::PgPool,
    chain_id: &str,
    address: &str,
    block: i64,
) -> Result<bool> {
    Ok(sqlx::query_scalar(
        "SELECT EXISTS ( \
             SELECT 1 FROM contract_instance_addresses address \
             WHERE address.chain_id = $1 \
               AND lower(address.address) = lower($2) \
               AND (address.active_from_block_number IS NULL \
                    OR address.active_from_block_number <= $3) \
               AND (address.active_to_block_number IS NULL \
                    OR address.active_to_block_number > $3) \
               AND address.deactivated_at IS NULL \
         )",
    )
    .bind(chain_id)
    .bind(address)
    .bind(block)
    .fetch_one(pool)
    .await?)
}

async fn probe_seed_self_announcement(
    pool: &sqlx::PgPool,
    chain_id: &str,
    block: i64,
) -> Result<()> {
    let block_hash = format!("{chain_id}-manifest-sync-head-{block}");
    let transaction_hash = format!("{chain_id}-probe-announcement-{block}");
    sqlx::query(
        "INSERT INTO raw_transactions ( \
             chain_id, block_hash, block_number, transaction_hash, \
             transaction_index, from_address, to_address \
         ) VALUES ($1, $2, $3, $4, 0, $5, $6)",
    )
    .bind(chain_id)
    .bind(&block_hash)
    .bind(block)
    .bind(&transaction_hash)
    .bind("0x0000000000000000000000000000000000000008")
    .bind(PROBE_DECLARED_REGISTRY)
    .execute(pool)
    .await?;
    sqlx::query(
        "INSERT INTO raw_logs ( \
             chain_id, block_hash, block_number, transaction_hash, \
             transaction_index, log_index, emitting_address, topics \
         ) VALUES ($1, $2, $3, $4, 0, 0, $5, $6)",
    )
    .bind(chain_id)
    .bind(&block_hash)
    .bind(block)
    .bind(&transaction_hash)
    .bind(PROBE_DECLARED_REGISTRY)
    .bind(vec![registry_announcement_topic0()])
    .execute(pool)
    .await?;
    Ok(())
}

async fn probe_interpret(
    scratch: &ScratchDatabase,
    chain_id: &str,
    from_block: i64,
    to_block: i64,
    mode: ProbeInterpretRunMode,
) -> Result<()> {
    let outcome = ProbeEngine::new(scratch.pool().clone())
        .run_batch(ProbeBatchRequest {
            chain_id: chain_id.to_owned(),
            from_block,
            to_block,
            resume_current: None,
            mode,
        })
        .await?;
    assert!(outcome.complete, "interpret batch did not complete");
    Ok(())
}

async fn probe_interpret_output(
    pool: &sqlx::PgPool,
    chain_id: &str,
) -> Result<(Vec<serde_json::Value>, Vec<serde_json::Value>)> {
    let events = sqlx::query_scalar(
        "SELECT to_jsonb(event_row) - 'normalized_event_id' - 'observed_at'
         FROM normalized_events event_row
         WHERE chain_id = $1 AND block_number = 1 ORDER BY event_identity",
    )
    .bind(chain_id)
    .fetch_all(pool)
    .await?;
    let edges = sqlx::query_scalar(
        "SELECT to_jsonb(edge_row) - 'discovery_edge_id' - 'admitted_at'
         FROM discovery_edges edge_row
         WHERE chain_id = $1 AND edge_kind = 'registry_announcement'
         ORDER BY active_from_block_number",
    )
    .bind(chain_id)
    .fetch_all(pool)
    .await?;
    Ok((events, edges))
}

/// Declares and synchronizes an address, then interprets its self-announcement and
/// verifies that declaration authority and the event-derived edge coexist.
async fn probe_observe_declared_self_announcement(
    scratch: &ScratchDatabase,
    chain_id: &str,
    fixture: &WatchManifestFixture,
) -> Result<(i64, serde_json::Value)> {
    fs::create_dir_all(probe_manifest_dir(fixture))?;
    fs::write(
        probe_manifest_dir(fixture).join("v1.toml"),
        probe_initial_manifest(chain_id),
    )?;
    sync_schema_v2_repository(scratch.pool(), &load_repository(&fixture.root)?).await?;

    let declared = probe_address_state(scratch.pool(), chain_id, PROBE_DECLARED_REGISTRY).await?;
    assert_eq!(
        declared.0.as_deref(),
        Some("manifest_declaration"),
        "declared row does not carry manifest provenance: {declared:?}"
    );
    assert!(!declared.3, "declared row is deactivated");

    seed_completed_ingest_range(scratch, chain_id).await?;
    probe_seed_self_announcement(scratch.pool(), chain_id, 1).await?;

    probe_interpret(scratch, chain_id, 0, 1, ProbeInterpretRunMode::Normal).await?;

    let observed = probe_address_state(scratch.pool(), chain_id, PROBE_DECLARED_REGISTRY).await?;
    assert_eq!(
        observed.0.as_deref(),
        Some("manifest_declaration"),
        "raw-log discovery overwrote the declared row's provenance: {observed:?}"
    );
    assert_eq!(observed.4, declared.4);
    assert!(!observed.3);

    let announcement_edges: i64 = sqlx::query_scalar(
        "SELECT count(*) FROM discovery_edges \
         WHERE chain_id = $1 AND edge_kind = 'registry_announcement' AND deactivated_at IS NULL",
    )
    .bind(chain_id)
    .fetch_one(scratch.pool())
    .await?;
    assert_eq!(
        announcement_edges, 1,
        "expected exactly one announcement edge"
    );
    // Represent an address row written by a pre-fix interpreter. The first
    // synchronization after upgrade must repair it without an earlier heal.
    sqlx::query(
        "UPDATE contract_instance_addresses
         SET provenance = jsonb_build_object('source', 'raw_log'), source_manifest_id = NULL
         WHERE chain_id = $1 AND lower(address) = lower($2)
           AND deactivated_at IS NULL",
    )
    .bind(chain_id)
    .bind(PROBE_DECLARED_REGISTRY)
    .execute(scratch.pool())
    .await?;
    let legacy = probe_address_state(scratch.pool(), chain_id, PROBE_DECLARED_REGISTRY).await?;
    assert_eq!(legacy.0.as_deref(), Some("raw_log"));
    assert_eq!(legacy.4, None);
    Ok((
        declared.4.expect("declaration has a source manifest"),
        declared.5,
    ))
}

struct ProbeOutcome {
    retired: (
        Option<String>,
        Option<i64>,
        Option<i64>,
        bool,
        Option<i64>,
        serde_json::Value,
    ),
    control: (
        Option<String>,
        Option<i64>,
        Option<i64>,
        bool,
        Option<i64>,
        serde_json::Value,
    ),
    retired_topology: bool,
    control_topology: bool,
    retired_watch: bool,
    control_watch: bool,
}

async fn probe_observe(pool: &sqlx::PgPool, chain_id: &str) -> Result<ProbeOutcome> {
    let label_topic = format!("{:#x}", keccak256(PROBE_LABEL_REGISTERED_SIGNATURE));
    let filter = load_persisted_watch_filter(pool, chain_id, 0, 10).await?;
    Ok(ProbeOutcome {
        retired: probe_address_state(pool, chain_id, PROBE_DECLARED_REGISTRY).await?,
        control: probe_address_state(pool, chain_id, PROBE_CONTROL_CONTRACT).await?,
        retired_topology: probe_topology_address_gate(pool, chain_id, PROBE_DECLARED_REGISTRY, 5)
            .await?,
        control_topology: probe_topology_address_gate(pool, chain_id, PROBE_CONTROL_CONTRACT, 5)
            .await?,
        retired_watch: filter.includes(PROBE_DECLARED_REGISTRY, &label_topic, 5),
        control_watch: filter.includes(PROBE_CONTROL_CONTRACT, &label_topic, 5),
    })
}

fn probe_assert_retired(
    variant: &str,
    outcome: &ProbeOutcome,
    declared_authority: &(i64, serde_json::Value),
) {
    eprintln!(
        "PROBE 553 [{variant}] retired {:?} topology={} watch={} | control {:?} topology={} \
         watch={}",
        outcome.retired,
        outcome.retired_topology,
        outcome.retired_watch,
        outcome.control,
        outcome.control_topology,
        outcome.control_watch,
    );
    assert!(
        outcome.control.3,
        "retirement did not run: {:?}",
        outcome.control
    );
    assert!(
        outcome.retired.3,
        "removed declaration stayed active: {:?}",
        outcome.retired
    );
    assert_eq!(
        (&outcome.retired.5, outcome.retired.4),
        (&declared_authority.1, Some(declared_authority.0)),
        "retirement did not restore the exact declaration authority"
    );
    assert!(
        !outcome.retired_topology,
        "retired address still matches topology"
    );
    assert!(
        !outcome.retired_watch,
        "retired address remains in the ingest watch"
    );
    assert_eq!(
        (outcome.control_topology, outcome.control_watch),
        (false, false),
        "retired control escaped a serving or ingest gate: {:?}",
        outcome.control,
    );
}

/// Variant A — deprecating a manifest version (the ens_v2_sepolia_dev precedent): the old
/// version file stays
/// in the repository with rollout_status = "deprecated" while a later deployment becomes
/// active.
#[tokio::test]
async fn probe_553_epoch_transition_deprecation() -> Result<()> {
    let scratch = ScratchDatabase::create("probe_553_epoch_transition").await?;
    let chain_id = "probe-553-epoch";
    let fixture = WatchManifestFixture::with_source_family(chain_id, "ens_v2_registry_l1")?;
    let declared_authority =
        probe_observe_declared_self_announcement(&scratch, chain_id, &fixture).await?;

    let v1_path = probe_manifest_dir(&fixture).join("v1.toml");
    let deprecated = fs::read_to_string(&v1_path)?.replacen(
        "rollout_status = \"active\"",
        "rollout_status = \"deprecated\"",
        1,
    );
    fs::write(&v1_path, deprecated)?;
    fs::write(
        probe_manifest_dir(&fixture).join("v2.toml"),
        format!(
            r#"manifest_version = 2
namespace = "test"
source_family = "ens_v2_registry_l1"
chain = "{chain_id}"
deployment_epoch = "fixture-next"
rollout_status = "active"
normalizer_version = "ensip15@ens-normalize-0.1.1"
roots = []
discovery_rules = []

[capability_flags]

[[contracts]]
role = "source_a"
address = "{PROBE_NEXT_EPOCH_REGISTRY}"
proxy_kind = "none"
start_block = 2

[[abi.events]]
name = "LabelRegistered"
fragment = "event LabelRegistered(uint256 indexed tokenId, bytes32 indexed labelHash, string label, address owner, uint64 expiry, address indexed sender)"
emitter_roles = ["source_a"]
normalized_events = ["RegistrationGranted"]
status = "supported"
"#
        ),
    )?;
    let sync = sync_schema_v2_repository(scratch.pool(), &load_repository(&fixture.root)?).await;
    let sync = match sync {
        Ok(summary) => summary,
        Err(error) => panic!(
            "VARIANT A BLOCKED: the epoch-transition deprecation sync itself was rejected, so \
             this workflow never reaches retirement: {error:#}"
        ),
    };
    eprintln!("PROBE 553 [epoch-transition] sync summary: {sync:?}");

    let outcome = probe_observe(scratch.pool(), chain_id).await?;
    probe_assert_retired("epoch-transition", &outcome, &declared_authority);

    scratch.cleanup().await
}

/// Variant B — in-place declaration removal: the same manifest version stays active but stops
/// declaring the observed registry (plus the control contract), keeping one unrelated
/// contract so the family remains loadable.
#[tokio::test]
async fn probe_553_in_place_dedeclaration() -> Result<()> {
    let scratch = ScratchDatabase::create("probe_553_in_place").await?;
    let chain_id = "probe-553-inplace";
    let fixture = WatchManifestFixture::with_source_family(chain_id, "ens_v2_registry_l1")?;
    let declared_authority =
        probe_observe_declared_self_announcement(&scratch, chain_id, &fixture).await?;
    let output_before = probe_interpret_output(scratch.pool(), chain_id).await?;
    assert!(
        output_before
            .0
            .iter()
            .any(|event| event["event_kind"] == "RegistryCreated")
    );

    fs::write(
        probe_manifest_dir(&fixture).join("v1.toml"),
        format!(
            r#"manifest_version = 1
namespace = "test"
source_family = "ens_v2_registry_l1"
chain = "{chain_id}"
deployment_epoch = "fixture"
rollout_status = "active"
normalizer_version = "ensip15@ens-normalize-0.1.1"
roots = []

[capability_flags]

[[discovery_rules]]
edge_kind = "registry_announcement"
from_role = "source_b"
admission = "reachable_from_root"

[[contracts]]
role = "source_b"
address = "{PROBE_KEPT_CONTRACT}"
proxy_kind = "none"
start_block = 0

[[abi.events]]
name = "RegistryCreated"
fragment = "event RegistryCreated()"
emitter_roles = ["source_b"]
normalized_events = ["RegistryCreated"]
status = "supported"

[[abi.events]]
name = "LabelRegistered"
fragment = "event LabelRegistered(uint256 indexed tokenId, bytes32 indexed labelHash, string label, address owner, uint64 expiry, address indexed sender)"
emitter_roles = ["source_b"]
normalized_events = ["RegistrationGranted"]
status = "supported"
"#
        ),
    )?;
    let sync = sync_schema_v2_repository(scratch.pool(), &load_repository(&fixture.root)?).await;
    let sync = match sync {
        Ok(summary) => summary,
        Err(error) => panic!(
            "VARIANT B BLOCKED: the in-place declaration-removal sync itself was rejected, so this \
             workflow never reaches retirement: {error:#}"
        ),
    };
    eprintln!("PROBE 553 [in-place] sync summary: {sync:?}");

    probe_interpret(&scratch, chain_id, 0, 1, ProbeInterpretRunMode::Redo).await?;
    assert_eq!(
        probe_interpret_output(scratch.pool(), chain_id).await?,
        output_before
    );

    let outcome = probe_observe(scratch.pool(), chain_id).await?;
    probe_assert_retired("in-place", &outcome, &declared_authority);
    advance_chain_head(scratch.pool(), chain_id, 2).await?;
    probe_seed_self_announcement(scratch.pool(), chain_id, 2).await?;
    probe_interpret(&scratch, chain_id, 2, 2, ProbeInterpretRunMode::Normal).await?;
    let epochs: (i64, i64, Option<i64>) = sqlx::query_as(
        "SELECT count(*), count(DISTINCT contract_instance_id),
                max(active_from_block_number) FILTER (WHERE deactivated_at IS NULL)
         FROM contract_instance_addresses
         WHERE chain_id = $1 AND lower(address) = lower($2)",
    )
    .bind(chain_id)
    .bind(PROBE_DECLARED_REGISTRY)
    .fetch_one(scratch.pool())
    .await?;
    assert_eq!(epochs, (2, 1, Some(2)));
    let later_kinds: Vec<String> = sqlx::query_scalar(
        "SELECT event_kind FROM normalized_events
         WHERE chain_id = $1 AND block_number = 2 ORDER BY event_kind",
    )
    .bind(chain_id)
    .fetch_all(scratch.pool())
    .await?;
    assert!(later_kinds.iter().any(|kind| kind == "RegistryCreated"));
    scratch.cleanup().await
}

/// Variant C — a routine re-sync while the address is still declared keeps manifest
/// provenance authoritative, and subsequent deprecation retires the row.
#[tokio::test]
async fn probe_553_resync_while_declared_heals_then_deprecation_retires() -> Result<()> {
    let scratch = ScratchDatabase::create("probe_553_heal").await?;
    let chain_id = "probe-553-heal";
    let fixture = WatchManifestFixture::with_source_family(chain_id, "ens_v2_registry_l1")?;
    let declared_authority =
        probe_observe_declared_self_announcement(&scratch, chain_id, &fixture).await?;

    // Routine re-sync of the unchanged, still-declaring repo.
    sync_schema_v2_repository(scratch.pool(), &load_repository(&fixture.root)?).await?;
    let healed = probe_address_state(scratch.pool(), chain_id, PROBE_DECLARED_REGISTRY).await?;
    eprintln!("PROBE 553 [heal] after still-declared re-sync: {healed:?}");
    assert_eq!(
        healed.0.as_deref(),
        Some("manifest_declaration"),
        "still-declared re-sync did not preserve manifest provenance: {healed:?}"
    );
    assert_eq!(
        (&healed.5, healed.4),
        (&declared_authority.1, Some(declared_authority.0))
    );

    // Now deprecate the whole family version with a replacement epoch (variant A shape).
    let v1_path = probe_manifest_dir(&fixture).join("v1.toml");
    let deprecated = fs::read_to_string(&v1_path)?.replacen(
        "rollout_status = \"active\"",
        "rollout_status = \"deprecated\"",
        1,
    );
    fs::write(&v1_path, deprecated)?;
    fs::write(
        probe_manifest_dir(&fixture).join("v2.toml"),
        format!(
            r#"manifest_version = 2
namespace = "test"
source_family = "ens_v2_registry_l1"
chain = "{chain_id}"
deployment_epoch = "fixture-next"
rollout_status = "active"
normalizer_version = "ensip15@ens-normalize-0.1.1"
roots = []
discovery_rules = []

[capability_flags]

[[contracts]]
role = "source_a"
address = "{PROBE_NEXT_EPOCH_REGISTRY}"
proxy_kind = "none"
start_block = 2

[[abi.events]]
name = "LabelRegistered"
fragment = "event LabelRegistered(uint256 indexed tokenId, bytes32 indexed labelHash, string label, address owner, uint64 expiry, address indexed sender)"
emitter_roles = ["source_a"]
normalized_events = ["RegistrationGranted"]
status = "supported"
"#
        ),
    )?;
    sync_schema_v2_repository(scratch.pool(), &load_repository(&fixture.root)?).await?;
    let retired = probe_address_state(scratch.pool(), chain_id, PROBE_DECLARED_REGISTRY).await?;
    eprintln!("PROBE 553 [heal] after deprecation of healed row: {retired:?}");
    assert!(
        retired.3,
        "manifest-provenance row was not retired by deprecation: {retired:?}"
    );
    assert_eq!(
        (&retired.5, retired.4),
        (&declared_authority.1, Some(declared_authority.0))
    );
    scratch.cleanup().await
}

fn checked_in_official_sepolia_root() -> std::path::PathBuf {
    std::path::Path::new(env!("CARGO_MANIFEST_DIR"))
        .join("../..")
        .join("manifests/sepolia")
}

#[tokio::test]
async fn official_sepolia_mirror_and_direct_resolver_sync_idempotently() -> Result<()> {
    let scratch = ScratchDatabase::create("production_manifest_official_mirror").await?;
    let repository = load_repository(checked_in_official_sepolia_root())?;
    sync_schema_v2_repository(scratch.pool(), &repository).await?;

    let mirrors: Vec<(String, String, String, Option<i64>)> = sqlx::query_as(
        "SELECT declaration.declaration_name, declaration.role,
                lower(declaration.declared_address), declaration.start_block_number
         FROM manifest_versions manifest
         JOIN manifest_contract_instances declaration
           ON declaration.manifest_id = manifest.manifest_id
         WHERE manifest.chain_id = 'ethereum-sepolia'
           AND manifest.source_family = 'ens_v2_resolver_l1'
           AND manifest.rollout_status = 'active'
           AND declaration.role = 'ensv1_mirror_resolver'
         ORDER BY declaration.declaration_name",
    )
    .fetch_all(scratch.pool())
    .await?;
    assert_eq!(
        mirrors,
        vec![(
            "ensv1_mirror_resolver@0x322b7581ca210a69c6d0e0d7c88a7688d2789cb0".into(),
            "ensv1_mirror_resolver".into(),
            "0x322b7581ca210a69c6d0e0d7c88a7688d2789cb0".into(),
            Some(11_820_288)
        )]
    );
    // Singleton roles keep the role as their declaration name.
    let direct: Option<String> = sqlx::query_scalar(
        "SELECT declaration.declaration_name
         FROM manifest_versions manifest
         JOIN manifest_contract_instances declaration
           ON declaration.manifest_id = manifest.manifest_id
         WHERE manifest.chain_id = 'ethereum-sepolia'
           AND manifest.source_family = 'ens_v2_resolver_l1'
           AND manifest.rollout_status = 'active'
           AND declaration.role = 'public_resolver_v2'",
    )
    .fetch_optional(scratch.pool())
    .await?;
    assert_eq!(direct.as_deref(), Some("public_resolver_v2"));

    // A resync is idempotent.
    sync_schema_v2_repository(scratch.pool(), &repository).await?;
    let count: i64 = sqlx::query_scalar(
        "SELECT count(*) FROM manifest_contract_instances WHERE role = 'ensv1_mirror_resolver'",
    )
    .fetch_one(scratch.pool())
    .await?;
    assert_eq!(count, 1);
    scratch.cleanup().await?;
    Ok(())
}

#[tokio::test]
async fn two_contracts_sharing_the_mirror_role_sync_under_address_qualified_names() -> Result<()> {
    // Declarations persist under `(manifest_id, declaration_kind, declaration_name)`. Two contracts
    // that share the repeatable mirror role must therefore each keep an address-qualified name,
    // or the second would overwrite the first. The official profile declares only one mirror, so
    // this synthetic manifest covers the two-address case.
    let scratch = ScratchDatabase::create("production_manifest_shared_role_pair").await?;
    let chain_id = "manifest-shared-role-pair";
    let fixture = WatchManifestFixture::with_source_family(chain_id, "ens_v2_resolver_l1")?;
    fs::write(
        fixture
            .root
            .join("test")
            .join("ens_v2_resolver_l1")
            .join("v1.toml"),
        format!(
            r#"manifest_version = 1
namespace = "test"
source_family = "ens_v2_resolver_l1"
chain = "{chain_id}"
deployment_epoch = "fixture"
rollout_status = "active"
normalizer_version = "ensip15@ens-normalize-0.1.1"
roots = []
discovery_rules = []

[correlation_addresses]
ens_v1_registry = "0x00000000000000000000000000000000000000AA"

[capability_flags]

[[contracts]]
role = "ensv1_mirror_resolver"
address = "0x0000000000000000000000000000000000000010"
proxy_kind = "none"
start_block = 34567

[[contracts]]
role = "ensv1_mirror_resolver"
address = "0x0000000000000000000000000000000000000011"
proxy_kind = "none"
start_block = 34560
"#
        ),
    )?;
    let repository = load_repository(&fixture.root)?;
    let expected: Vec<(String, String, String, Option<i64>)> = vec![
        (
            "ensv1_mirror_resolver@0x0000000000000000000000000000000000000010".into(),
            "ensv1_mirror_resolver".into(),
            "0x0000000000000000000000000000000000000010".into(),
            Some(34_567),
        ),
        (
            "ensv1_mirror_resolver@0x0000000000000000000000000000000000000011".into(),
            "ensv1_mirror_resolver".into(),
            "0x0000000000000000000000000000000000000011".into(),
            Some(34_560),
        ),
    ];

    // The second sync checks that a resync neither collapses nor duplicates the pair.
    for pass in ["first sync", "resync"] {
        sync_schema_v2_repository(scratch.pool(), &repository).await?;
        let declared: Vec<(String, String, String, Option<i64>)> = sqlx::query_as(
            "SELECT declaration.declaration_name, declaration.role,
                    lower(declaration.declared_address), declaration.start_block_number
             FROM manifest_versions manifest
             JOIN manifest_contract_instances declaration
               ON declaration.manifest_id = manifest.manifest_id
             WHERE manifest.chain_id = $1
               AND manifest.source_family = 'ens_v2_resolver_l1'
               AND manifest.rollout_status = 'active'
             ORDER BY declaration.declaration_name",
        )
        .bind(chain_id)
        .fetch_all(scratch.pool())
        .await?;
        assert_eq!(declared, expected, "{pass}");
    }
    scratch.cleanup().await?;
    Ok(())
}
