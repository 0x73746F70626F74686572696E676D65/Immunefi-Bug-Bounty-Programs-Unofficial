use imbl::ordset::OrdSet;
use serde_json::json;
use uuid::Uuid;

use super::{State, V1NameState, V1RegistryReadAnchor, V1Release, v1_key, v1_registration_is_live};
use crate::schema_v2::model::PriorEventInput;

const NAMESPACE: &str = "test";

#[test]
fn resolver_linked_resources_only_tracks_old_registry_selection() {
    const RESOLVER: &str = "0x0000000000000000000000000000000000000001";
    let mut state = State::new(Vec::new(), Vec::new());

    state.set_v1_resolver_link(
        NAMESPACE,
        "current-node",
        Some(RESOLVER.to_owned()),
        Some(Uuid::from_u128(1)),
        Some("test:current-node".to_owned()),
        Some("registry".to_owned()),
    );
    assert!(
        !state
            .v1_resolver_linked_resources
            .contains_key("test:current-node"),
        "current-registry selection must not allocate old-registry fan-out state"
    );

    state.set_v1_resolver_link(
        NAMESPACE,
        "old-node",
        Some(RESOLVER.to_owned()),
        Some(Uuid::from_u128(2)),
        Some("test:old-node".to_owned()),
        Some("registry_old".to_owned()),
    );
    assert_eq!(
        state
            .v1_resolver_linked_resources
            .get("test:old-node")
            .map(|links| links.len()),
        Some(1),
        "old-registry selection must retain its linked resource for fallback handoff"
    );
}

#[test]
fn restore_keys_authority_derived_resolver_links_by_child() {
    let mut state = State::new(Vec::new(), Vec::new());
    let event = PriorEventInput {
        retained_state_key: "derived-resolver".to_owned(),
        chain_id: "test-chain".to_owned(),
        namespace: NAMESPACE.to_owned(),
        logical_name_id: Some("test:child".to_owned()),
        resource_id: Some(Uuid::from_u128(1)),
        event_kind: "ResolverChanged".to_owned(),
        source_family: "ens_v1_registry_l1".to_owned(),
        manifest_version: 1,
        source_manifest_id: Some(1),
        emitting_address: None,
        state_scope: None,
        block_timestamp: None,
        write_position: None,
        after_state: json!({
            "source_event": "AuthorityEpochChanged",
            "node": "parent",
            "child_node": "child",
            "resolver": "0x0000000000000000000000000000000000000001",
            "resolver_source_role": "registry_old",
        }),
    };
    crate::schema_v2::state_restore::v1(&mut state, &event);
    assert_eq!(
        state
            .v1_resolver_linked_resources
            .keys()
            .map(String::as_str)
            .collect::<Vec<_>>(),
        vec!["test:child"],
        "authority-derived resolver row was not keyed only by the affected child name",
    );
}

#[test]
fn wrapper_preimage_restore_derives_registry_labelhash_from_raw_label() {
    const NODE: &str = "node";
    const OWNER: &str = "0x0000000000000000000000000000000000000001";
    let mut state = State::new(Vec::new(), Vec::new());
    state.remember_v1_registry_authority(
        NAMESPACE,
        NODE,
        V1NameState {
            logical_name_id: "test:unknown".to_owned(),
            surface_known: false,
            resource_id: Uuid::from_u128(1),
            token_lineage_id: None,
            authority_source_family: "ens_v1_registry_l1".to_owned(),
            source_manifest_id: Some(1),
            labelhash: None,
            expiry: None,
            owner: Some(OWNER.to_owned()),
            registry_contract: None,
            authority_key: Some("registry-only:node".to_owned()),
            wrapper_fallback: false,
        },
    );
    state.remember_v1_registry_read_anchor(
        NAMESPACE,
        NODE,
        V1RegistryReadAnchor {
            logical_name_id: "test:unknown".to_owned(),
            resource_id: Uuid::from_u128(1),
            surface_known: false,
            source_family: "ens_v1_registry_l1".to_owned(),
            source_manifest_id: Some(1),
            registry_contract: None,
        },
    );
    state.set_v1_registry_owner_views(NAMESPACE, NODE, OWNER.to_owned(), OWNER.to_owned(), None);
    state.activate_v1_authority(
        NAMESPACE,
        NODE,
        Some(V1NameState {
            logical_name_id: "test:node".to_owned(),
            surface_known: true,
            resource_id: Uuid::from_u128(2),
            token_lineage_id: Some(Uuid::from_u128(3)),
            authority_source_family: "ens_v1_wrapper_l1".to_owned(),
            source_manifest_id: Some(2),
            labelhash: Some(crate::schema_v2::common::hash_hex(b"pointer")),
            expiry: Some(9_999),
            owner: Some(OWNER.to_owned()),
            registry_contract: None,
            authority_key: Some("wrapper:node".to_owned()),
            wrapper_fallback: false,
        }),
    );
    let event = PriorEventInput {
        retained_state_key: "wrapper-preimage".to_owned(),
        chain_id: "test-chain".to_owned(),
        namespace: NAMESPACE.to_owned(),
        logical_name_id: Some("test:node".to_owned()),
        resource_id: None,
        event_kind: "PreimageObserved".to_owned(),
        source_family: "ens_v1_wrapper_l1".to_owned(),
        manifest_version: 1,
        source_manifest_id: Some(2),
        emitting_address: None,
        state_scope: None,
        block_timestamp: None,
        write_position: None,
        after_state: json!({
            "namehash": NODE,
            "raw_name": "pointer.eth",
            "raw_labels": ["pointer", "eth"],
        }),
    };

    crate::schema_v2::state_restore::v1_surface::restore_preimage(&mut state, &event);

    let expected_labelhash = crate::schema_v2::common::hash_hex(b"pointer");
    assert_eq!(
        state
            .v1_registry_authorities
            .get(&v1_key(NAMESPACE, NODE))
            .and_then(|authority| authority.labelhash.as_deref()),
        Some(expected_labelhash.as_str())
    );
}

#[test]
fn observed_v1_active_surface_upgrades_an_existing_registry_read_anchor() {
    let mut state = State::new(Vec::new(), Vec::new());
    state.remember_v1_registry_read_anchor(
        NAMESPACE,
        "node",
        V1RegistryReadAnchor {
            logical_name_id: "test:node".to_owned(),
            resource_id: Uuid::from_u128(1),
            surface_known: false,
            source_family: "ens_v1_registry_l1".to_owned(),
            source_manifest_id: Some(1),
            registry_contract: None,
        },
    );

    state.observe_v1_active_surface(NAMESPACE, "node");

    assert!(
        state
            .v1_registry_read_anchor(NAMESPACE, "node")
            .is_some_and(|anchor| anchor.surface_known)
    );
}

#[test]
fn registrar_state_does_not_snapshot_registry_contract() {
    let mut state = State::new(Vec::new(), Vec::new());
    state.observe_v1_registry(
        NAMESPACE,
        "node",
        "test:node".to_owned(),
        true,
        Uuid::from_u128(3),
        "ens_v1_registry_l1".to_owned(),
        Some("0x0000000000000000000000000000000000000001".to_owned()),
        Some("0x0000000000000000000000000000000000000066".to_owned()),
        None,
    );
    observe_registrar(&mut state, "node", Some(100));
    assert_eq!(
        state
            .v1_registrar(NAMESPACE, "node")
            .unwrap()
            .registry_contract,
        None
    );
}

#[test]
fn zero_getter_blocks_stale_registry_authority_fallback_during_registrar_transfer() {
    const NODE: &str = "node";
    const OWNER: &str = "0x0000000000000000000000000000000000000001";
    const ZERO: &str = "0x0000000000000000000000000000000000000000";
    let mut state = State::new(Vec::new(), Vec::new());
    state.observe_v1_registrar(
        NAMESPACE,
        NODE,
        format!("{NAMESPACE}:{NODE}"),
        true,
        Uuid::from_u128(1),
        Uuid::from_u128(2),
        "ens_v1_registrar_l1".to_owned(),
        Some(1),
        None,
        Some(1_000),
        Some(OWNER.to_owned()),
        Some(format!("registrar:{NODE}")),
        false,
        true,
    );
    state.set_v1_registry_owner_views(
        NAMESPACE,
        NODE,
        ZERO.to_owned(),
        ZERO.to_owned(),
        Some("literal_zero".to_owned()),
    );
    state.observe_v1_registry(
        NAMESPACE,
        NODE,
        format!("{NAMESPACE}:{NODE}"),
        true,
        Uuid::from_u128(3),
        "ens_v1_registry_l1".to_owned(),
        Some(OWNER.to_owned()),
        None,
        Some(format!("registry-only:{NODE}")),
    );
    assert!(
        state.has_v1_registry_authority(NAMESPACE, NODE),
        "the fixture deliberately retains the stale entry to mutation-pin the fallback guard"
    );

    let next = state.converge_v1_registrar_transfer(
        NAMESPACE,
        NODE,
        1_000 + super::ENS_GRACE_PERIOD_SECS + 1,
    );
    assert!(
        next.is_none(),
        "a zero getter must not resurrect the stale pre-zero registry owner"
    );
}

#[test]
fn v1_release_order_matches_naive_scan_after_expiry_updates_and_removals() {
    let mut state = State::new(Vec::new(), Vec::new());
    observe_registrar(&mut state, "zeta", Some(100));
    observe_registrar(&mut state, "alpha", Some(100));
    observe_registrar(&mut state, "middle", Some(50));
    observe_registrar(&mut state, "live", Some(500));
    observe_registrar(&mut state, "updated", Some(50));
    observe_registrar(&mut state, "updated", Some(500));
    observe_registrar(&mut state, "removed", Some(50));
    state.restore_v1_registration_release(NAMESPACE, "removed", 0);

    assert_expiry_index_is_derived(&state);
    let timestamp = 100 + super::ENS_GRACE_PERIOD_SECS + 1;
    let expected = naive_due_keys(&state, timestamp);
    let actual = release_keys(state.settle_v1_releases(timestamp));

    assert_eq!(expected, vec!["test:alpha", "test:middle", "test:zeta"]);
    assert_eq!(actual, expected);
    assert_expiry_index_is_derived(&state);
}

#[test]
fn v1_expiry_index_matches_naive_scan_over_generated_mutations() {
    let mut state = State::new(Vec::new(), Vec::new());
    let mut sequence = Sequence(0xd1ff_3e12_395a_11ce);

    for step in 0..1_024 {
        let namehash = format!("name-{:02}", sequence.next() % 48);
        match sequence.next() % 5 {
            0..=2 => {
                let expiry = match sequence.next() % 8 {
                    0 => None,
                    1 => Some(i64::MAX),
                    _ => Some((sequence.next() % 4_000) as i64 - 2_000),
                };
                observe_registrar(&mut state, &namehash, expiry);
            }
            3 => state.restore_v1_registration_release(NAMESPACE, &namehash, 0),
            _ => {
                let timestamp =
                    super::ENS_GRACE_PERIOD_SECS + (sequence.next() % 6_000) as i64 - 3_000;
                assert_release_sequence(&mut state, timestamp, step);
            }
        }
        assert_expiry_index_is_derived(&state);
    }

    assert_release_sequence(&mut state, i64::MAX, 1_024);
    assert_expiry_index_is_derived(&state);
}

#[test]
fn v1_release_occurs_one_second_after_the_grace_boundary() {
    let expiry = 100;
    let boundary = expiry + super::ENS_GRACE_PERIOD_SECS;
    let mut state = State::new(Vec::new(), Vec::new());
    observe_registrar(&mut state, "boundary", Some(expiry));

    assert!(state.settle_v1_releases(boundary - 1).is_empty());
    assert!(state.settle_v1_releases(boundary).is_empty());
    assert_eq!(
        release_keys(state.settle_v1_releases(boundary + 1)),
        vec!["test:boundary"]
    );
}

#[test]
fn v1_expiry_overflow_is_never_released_and_does_not_block_finite_expiry() {
    let mut state = State::new(Vec::new(), Vec::new());
    observe_registrar(&mut state, "overflow", Some(i64::MAX));
    observe_registrar(&mut state, "finite", Some(1));

    let releases = release_keys(state.settle_v1_releases(1 + super::ENS_GRACE_PERIOD_SECS + 1));

    assert_eq!(releases, ["test:finite"]);
    assert!(state.v1_registrars.contains_key("test:overflow"));
    assert!(v1_registration_is_live(Some(i64::MAX), i64::MAX));
    assert!(
        !state
            .v1_expiries
            .iter()
            .any(|(_, key)| key == "test:overflow")
    );
}

fn assert_release_sequence(state: &mut State, timestamp: i64, step: usize) {
    let expected = naive_due_keys(state, timestamp);
    let actual = release_keys(state.settle_v1_releases(timestamp));
    assert_eq!(actual, expected, "release sequence differed at step {step}");
}

// Test-only copy of the pre-index full scan, including its registrar-key iteration order.
fn naive_due_keys(state: &State, timestamp: i64) -> Vec<String> {
    state
        .v1_registrars
        .iter()
        .filter_map(|(key, registrar)| {
            let expiry = registrar.expiry?;
            (!v1_registration_is_live(Some(expiry), timestamp)).then(|| key.clone())
        })
        .collect()
}

fn release_keys(releases: Vec<V1Release>) -> Vec<String> {
    releases
        .into_iter()
        .map(|release| format!("{NAMESPACE}:{}", release.namehash))
        .collect()
}

fn assert_expiry_index_is_derived(state: &State) {
    let expected: OrdSet<(i64, String)> = state
        .v1_registrars
        .iter()
        .filter_map(|(key, registrar)| {
            registrar
                .expiry
                .filter(|expiry| expiry.checked_add(super::ENS_GRACE_PERIOD_SECS).is_some())
                .map(|expiry| (expiry, key.clone()))
        })
        .collect::<OrdSet<_>>();
    let actual: OrdSet<(i64, String)> = state
        .v1_expiries
        .iter()
        .filter(|(expiry, _)| expiry.checked_add(super::ENS_GRACE_PERIOD_SECS).is_some())
        .map(|(expiry, key)| (*expiry, key.clone()))
        .collect::<OrdSet<_>>();
    assert_eq!(actual, expected);
}

#[test]
fn restoring_a_lapsed_wrapped_release_does_not_revive_registry_custody() {
    const HOLDER: &str = "0x0000000000000000000000000000000000000055";
    const WRAPPER: &str = "0x0000000000000000000000000000000000000077";
    let namehash = "lapsed-wrapped";
    let mut state = State::new(Vec::new(), Vec::new());
    // The NameWrapper holds the registry node on behalf of the wrapped lease, so the registry
    // remembers a non-zero, authenticatable owner for the node.
    state.observe_v1_registry(
        NAMESPACE,
        namehash,
        format!("{NAMESPACE}:{namehash}"),
        true,
        Uuid::from_u128(1),
        "ens_v1_registry_l1".to_owned(),
        Some(WRAPPER.to_owned()),
        Some("0x0000000000000000000000000000000000000099".to_owned()),
        Some(format!("registry:{namehash}")),
    );
    state.set_v1_registry_owner_views(
        NAMESPACE,
        namehash,
        WRAPPER.to_owned(),
        WRAPPER.to_owned(),
        None,
    );
    observe_registrar(&mut state, namehash, Some(100));
    state.activate_v1_authority(
        NAMESPACE,
        namehash,
        Some(V1NameState {
            logical_name_id: format!("{NAMESPACE}:{namehash}"),
            surface_known: true,
            resource_id: Uuid::from_u128(1),
            token_lineage_id: Some(Uuid::from_u128(2)),
            authority_source_family: "ens_v1_wrapper_l1".to_owned(),
            source_manifest_id: Some(1),
            labelhash: None,
            expiry: Some(100),
            owner: Some(HOLDER.to_owned()),
            registry_contract: None,
            authority_key: Some(format!("wrapper:{namehash}")),
            wrapper_fallback: false,
        }),
    );
    let lapsed_at = 100 + super::ENS_GRACE_PERIOD_SECS + 1;

    // Live path: the lapsed wrapped lease leaves no ENSv1 authority behind.
    let mut live = state.clone();
    let releases = live.settle_v1_releases(lapsed_at);
    assert_eq!(release_keys(releases), vec![v1_key(NAMESPACE, namehash)]);
    assert_eq!(live.v1_name(NAMESPACE, namehash), None, "live release");
    assert_eq!(
        live.v1_registrar(NAMESPACE, namehash),
        None,
        "live registrar"
    );

    // Restore path (the stored RegistrationReleased replayed as a prior event) must land on
    // the same state instead of reviving the wrapper's registry-only custody.
    state.restore_v1_registration_release(NAMESPACE, namehash, lapsed_at);
    assert_eq!(
        state.v1_registrar(NAMESPACE, namehash),
        None,
        "restored registrar"
    );
    assert_eq!(
        state.v1_name(NAMESPACE, namehash),
        live.v1_name(NAMESPACE, namehash),
        "restored release must match the live release"
    );
}

fn observe_registrar(state: &mut State, namehash: &str, expiry: Option<i64>) {
    state.observe_v1_registrar(
        NAMESPACE,
        namehash,
        format!("{NAMESPACE}:{namehash}"),
        true,
        Uuid::from_u128(1),
        Uuid::from_u128(2),
        "ens_v1_registrar_l1".to_owned(),
        Some(1),
        None,
        expiry,
        Some("0x0000000000000000000000000000000000000001".to_owned()),
        Some(format!("registrar:{namehash}")),
        false,
        true,
    );
}

struct Sequence(u64);

impl Sequence {
    fn next(&mut self) -> u64 {
        self.0 = self
            .0
            .wrapping_mul(6_364_136_223_846_793_005)
            .wrapping_add(1_442_695_040_888_963_407);
        self.0
    }
}

#[test]
fn controller_preimage_restore_rebinds_existing_registrar_identity() {
    let mut state = State::new(Vec::new(), Vec::new());
    observe_registrar(&mut state, "restored", Some(100));
    let resource = state.v1_registrars["test:restored"].resource_id;
    state
        .v1_registrars
        .get_mut("test:restored")
        .unwrap()
        .surface_known = false;
    state
        .v1_names
        .get_mut("test:restored")
        .unwrap()
        .surface_known = false;
    state.active_resources.remove("test:restored");

    state.bind_v1_active_surface(NAMESPACE, "restored");

    assert!(state.v1_registrars["test:restored"].surface_known);
    assert!(state.v1_names["test:restored"].surface_known);
    assert_eq!(state.active_resources.get("test:restored"), Some(&resource));
}

#[test]
fn activating_a_retained_authority_uses_an_already_known_surface() {
    const NODE: &str = "node";
    const OWNER: &str = "0x0000000000000000000000000000000000000001";
    let mut state = State::new(Vec::new(), Vec::new());
    state.observe_v1_registry(
        NAMESPACE,
        NODE,
        format!("{NAMESPACE}:{NODE}"),
        false,
        Uuid::from_u128(3),
        "ens_v1_registry_l1".to_owned(),
        Some(OWNER.to_owned()),
        Some("0x0000000000000000000000000000000000000066".to_owned()),
        Some(format!("registry-only:{NODE}")),
    );
    let retained = state.v1_name(NAMESPACE, NODE).expect("registry authority");
    state.activate_v1_authority(NAMESPACE, NODE, None);
    state.observe_v1_active_surface(NAMESPACE, NODE);

    state.activate_v1_authority(NAMESPACE, NODE, Some(retained));
    let activated = state
        .v1_name(NAMESPACE, NODE)
        .expect("reactivated authority");

    assert!(activated.surface_known);
}

#[test]
fn release_returns_the_promoted_retained_registry_authority() {
    const NODE: &str = "node";
    const OWNER: &str = "0x0000000000000000000000000000000000000001";
    let mut state = State::new(Vec::new(), Vec::new());
    state.observe_v1_registry(
        NAMESPACE,
        NODE,
        format!("{NAMESPACE}:{NODE}"),
        false,
        Uuid::from_u128(3),
        "ens_v1_registry_l1".to_owned(),
        Some(OWNER.to_owned()),
        Some("0x0000000000000000000000000000000000000066".to_owned()),
        Some(format!("registry-only:{NODE}")),
    );
    state.set_v1_registry_owner_views(
        NAMESPACE,
        NODE,
        OWNER.to_owned(),
        OWNER.to_owned(),
        Some("retained registry owner".to_owned()),
    );
    state.observe_v1_registrar(
        NAMESPACE,
        NODE,
        format!("{NAMESPACE}:{NODE}"),
        false,
        Uuid::from_u128(1),
        Uuid::from_u128(2),
        "ens_v1_registrar_l1".to_owned(),
        Some(1),
        None,
        Some(1),
        Some(OWNER.to_owned()),
        Some(format!("registrar:{NODE}")),
        false,
        true,
    );
    state.observe_v1_active_surface(NAMESPACE, NODE);

    let releases = state.settle_v1_releases(1 + super::ENS_GRACE_PERIOD_SECS + 1);
    let next = releases
        .first()
        .and_then(|release| release.next_authority.as_ref())
        .expect("retained registry authority");

    assert!(
        next.surface_known,
        "the release output must carry the surface-known state established during activation"
    );
}

#[test]
fn wrapper_renewal_restore_preserves_unsigned_expiry_and_later_fuse_state() {
    const NODE: &str = "wrapper-node";
    let mut initial = State::new(Vec::new(), Vec::new());
    initial.observe_v1_name(
        NAMESPACE,
        NODE,
        "test:wrapper-node".to_owned(),
        true,
        Uuid::from_u128(7),
        None,
        "ens_v1_wrapper_l1".to_owned(),
        Some(i64::MAX),
        None,
        None,
    );
    initial.restore_v1_wrapper_data(NAMESPACE, NODE, 1, u64::MAX);

    for expiry in [i64::MAX as u64 + 1, 1_907_776_200, 7_776_000] {
        let mut live = initial.clone();
        let (previous, wrapper) = live
            .renew_v1_wrapper_expiry(NAMESPACE, NODE, expiry)
            .expect("known wrapper");
        assert_eq!(previous, u64::MAX);
        assert_eq!(
            wrapper.expiry,
            Some(i64::try_from(expiry).unwrap_or(i64::MAX))
        );
        let serialized = serde_json::to_vec(&json!({
            "source_event": "NameRenewed",
            "node": NODE,
            "authority_kind": "wrapper",
            "expiry": expiry,
        }))
        .unwrap();
        let event = PriorEventInput {
            retained_state_key: "wrapper-expiry".to_owned(),
            chain_id: "test-chain".to_owned(),
            namespace: NAMESPACE.to_owned(),
            logical_name_id: Some(wrapper.logical_name_id),
            resource_id: Some(wrapper.resource_id),
            event_kind: "ExpiryChanged".to_owned(),
            source_family: "ens_v1_registrar_l1".to_owned(),
            manifest_version: 1,
            source_manifest_id: Some(1),
            emitting_address: None,
            state_scope: None,
            block_timestamp: None,
            write_position: None,
            after_state: serde_json::from_slice(&serialized).unwrap(),
        };
        assert_eq!(event.after_state["expiry"].as_u64(), Some(expiry));
        let mut restored = initial.clone();
        crate::schema_v2::state_restore::v1(&mut restored, &event);
        assert_eq!(
            live.v1_name(NAMESPACE, NODE),
            restored.v1_name(NAMESPACE, NODE)
        );
        let live_fuses = live.set_v1_wrapper_fuses(NAMESPACE, NODE, 3).unwrap();
        let restored_fuses = restored.set_v1_wrapper_fuses(NAMESPACE, NODE, 3).unwrap();
        assert_eq!(live_fuses, restored_fuses);
        assert_eq!(restored_fuses.1.expiry, expiry);
        assert_eq!(restored_fuses.1.fuses, 3);

        // An ordinary ExpiryExtended event still retains the larger existing expiry.
        let mut extension = event;
        extension.source_family = "ens_v1_wrapper_l1".to_owned();
        extension.after_state = json!({
            "source_event": "ExpiryExtended",
            "node": NODE,
            "expiry": expiry - 1,
        });
        crate::schema_v2::state_restore::v1(&mut restored, &extension);
        assert_eq!(
            restored
                .set_v1_wrapper_fuses(NAMESPACE, NODE, 3)
                .unwrap()
                .1
                .expiry,
            expiry
        );
    }
}
