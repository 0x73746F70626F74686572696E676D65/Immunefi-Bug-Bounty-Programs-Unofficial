pub(in crate::schema_v2) mod authority_transition;
mod reconcile_support;
pub(in crate::schema_v2) mod registrar;
mod registrar_surface;
pub(in crate::schema_v2) use registrar_surface::materialize as materialize_registrar_surface;
mod registry;
pub(in crate::schema_v2) use registry::graveyard::admitted as registry_graveyard;
pub(in crate::schema_v2) use registry::wrapper_custody::{
    WrapperCustody, admitted as registry_name_wrapper,
};
mod resolver;
pub(super) use resolver::interpret as interpret_node_resolver;
mod reverse;
mod support;
pub(in crate::schema_v2) mod unmasked_word;
mod upgrade;
pub(in crate::schema_v2) mod wrapper;
pub(in crate::schema_v2) use wrapper::{WrapperPermissionContext, append_delegate_permission};

use std::collections::HashMap;

use anyhow::bail;

use super::Interpreted;
use crate::schema_v2::{
    catalog::Selected,
    common::hash_hex,
    model::{BatchOutput, NormalizedEvent, RawLogInput},
    seam::{INTERPRETER_STATE_KEY, STATE_SCOPE_KEY},
    state::State,
    state_key::interpreter_state_key,
};

pub(in crate::schema_v2) fn materialize_wrapper_surface(
    selected: &Selected,
    raw: &RawLogInput,
    state: &mut State,
    interpreted: &mut Interpreted,
) -> anyhow::Result<()> {
    if !matches!(
        selected.source.source_family.as_str(),
        "ens_v1_wrapper_l1" | "ens_v1_registrar_l1"
    ) {
        return Ok(());
    }
    let surfaces = interpreted
        .names
        .iter()
        .enumerate()
        .filter_map(|(index, name)| {
            Some((
                index,
                name.namehash.clone(),
                name.labels.first()?.clone(),
                format!("{}:{}", selected.source.namespace, name.namehash),
                name.authority_arm.clone(),
            ))
        })
        .collect::<Vec<_>>();
    for (index, namehash, label, logical_name_id, authority_arm) in surfaces {
        let materialization = state.materialize_v1_active_surface(
            &selected.source.namespace,
            &namehash,
            &logical_name_id,
            &hash_hex(label.as_bytes()),
        )?;
        if matches!(
            materialization,
            crate::schema_v2::state::V1SurfaceMaterialization::RegistryAuthority { .. }
        ) {
            // Source-backed materialization already emits this registry binding. The controller
            // still reveals the same name, but must not open a second overlapping interval.
            interpreted.names[index].bind = false;
        }
        authority_transition::append_surface_materialization_for_trigger(
            interpreted,
            &authority_arm,
            &materialization,
            raw,
            &selected.event.name,
        );
    }
    Ok(())
}

fn is_registry_ownership_event(name: &str) -> bool {
    matches!(name, "NewOwner" | "Transfer")
}

pub(super) fn reverse_abi(source_family: &str, signature: &str) -> bool {
    reverse::supports(source_family, signature)
}

pub(super) fn validate_reverse_roles(
    source: &crate::schema_v2::manifest::ManifestSource,
    event: &crate::schema_v2::manifest::ManifestEvent,
) -> anyhow::Result<()> {
    reverse::validate_roles(source, event)
}

pub(super) fn interpret(
    selected: &Selected,
    raw: &RawLogInput,
    state: &mut State,
    registrar_context: super::super::migration::RegistrarContext,
) -> anyhow::Result<Interpreted> {
    match selected.source.source_family.as_str() {
        "ens_v1_registrar_l1" | "basenames_base_registrar" => {
            registrar::interpret(selected, raw, state, registrar_context)
        }
        "ens_v1_registry_l1" | "basenames_base_registry" => {
            registry::interpret(selected, raw, state, registrar_context)
        }
        "ens_v1_resolver_l1" | "basenames_base_resolver" => {
            resolver::interpret(selected, raw, state)
        }
        "ens_v1_wrapper_l1" => wrapper::interpret(selected, raw, state),
        "ens_v1_reverse_l1" | "basenames_base_primary" => reverse::interpret(selected, raw),
        family if family.ends_with("_execution") || family == "basenames_l1_compat" => {
            Ok(Interpreted::new())
        }
        family => bail!("source family {family} has no ENSv1/Basenames adapter"),
    }
}

pub(super) fn reconcile_block(
    catalog: &crate::schema_v2::catalog::Catalog,
    block: &crate::schema_v2::model::RawBlockInput,
    raw_logs: &[crate::schema_v2::model::RawLogInput],
    observations: &[super::MigrationObservation],
    committed_state: &crate::schema_v2::state::State,
    block_state: &mut crate::schema_v2::state::State,
    output: &mut BatchOutput,
) -> anyhow::Result<()> {
    reconcile_same_transaction_setups(output);
    let proofs = crate::schema_v2::migration::unwrapped_reconciliations(
        catalog,
        observations,
        raw_logs,
        block,
        committed_state,
        output,
    )?;
    reconcile_support::reconcile_unwrapped_migrations(output, &proofs);
    if output
        .normalized_events
        .iter()
        .any(|event| event.source_family.starts_with("ens_v1_"))
    {
        let delta = crate::schema_v2::seam::fold_prior_events(
            Vec::new(),
            &output.normalized_events,
            std::slice::from_ref(block),
        )?;
        let mut replayed_state = committed_state.clone();
        replayed_state.apply_prior_event_delta(delta);
        // Live interpretation saw provisional transitions. Advance ENSv1 using only the
        // reconciled observations; preserve other protocols' uninterrupted state.
        block_state.replace_ens_v1_protocol_state_from_replay(replayed_state);
    }
    Ok(())
}

pub(super) fn reconcile_same_transaction_setups(output: &mut BatchOutput) {
    let event_order = output
        .normalized_events
        .iter()
        .enumerate()
        .map(|(index, event)| (event.event_identity.clone(), index))
        .collect::<HashMap<_, _>>();
    let fallback_handoffs = output
        .normalized_events
        .iter()
        .enumerate()
        .filter(|(_, event)| event.after_state["registry_fallback_handoff"] == true)
        .map(|(index, event)| (index, event.clone()))
        .collect::<Vec<_>>();
    reconcile_support::reconcile(output);
    for (handoff_index, handoff) in fallback_handoffs {
        if let Some(event) = output
            .normalized_events
            .iter_mut()
            .find(|event| event.event_identity == handoff.event_identity)
        {
            *event = handoff;
            continue;
        }
        let insert_at = output
            .normalized_events
            .iter()
            .position(|event| {
                event_order
                    .get(&event.event_identity)
                    .is_some_and(|index| *index > handoff_index)
            })
            .unwrap_or(output.normalized_events.len());
        output.normalized_events.insert(insert_at, handoff);
    }
}

pub(in crate::schema_v2) fn registrar_registration_namehash(
    selected: &Selected,
    raw: &RawLogInput,
) -> anyhow::Result<Option<(String, String)>> {
    registrar::base::registration_namehash(selected, raw)
}

pub(in crate::schema_v2) fn registry_registration_setup_namehash(
    selected: &Selected,
    raw: &RawLogInput,
) -> anyhow::Result<Option<(String, String)>> {
    registry::node::registration_setup_node(selected, raw)
}

fn authority_arm(namespace: &str) -> &'static str {
    if namespace == "basenames" {
        "basenames"
    } else {
        "ens_v1"
    }
}

fn retarget_permission_authority(state: &mut serde_json::Value, authority_key: &str) {
    for field in ["grant_source", "revocation_source"] {
        let Some(source) = state
            .get_mut(field)
            .and_then(serde_json::Value::as_object_mut)
            .filter(|source| {
                source.get("kind").and_then(serde_json::Value::as_str) == Some("ens_v1_authority")
            })
        else {
            continue;
        };
        source.insert(
            "authority_kind".to_owned(),
            serde_json::Value::String("registrar".to_owned()),
        );
        source.insert(
            "authority_key".to_owned(),
            serde_json::Value::String(authority_key.to_owned()),
        );
    }
}

fn refresh_interpreter_state_key(event: &mut NormalizedEvent) {
    let state_scope = event
        .raw_fact_ref
        .get(STATE_SCOPE_KEY)
        .and_then(serde_json::Value::as_str)
        .unwrap_or_default()
        .to_owned();
    let state_key = interpreter_state_key(
        &event.namespace,
        event.logical_name_id.as_deref(),
        event.resource_id,
        &event.event_kind,
        &event.source_family,
        &state_scope,
    );
    if let Some(raw_fact_ref) = event.raw_fact_ref.as_object_mut() {
        raw_fact_ref.insert(
            INTERPRETER_STATE_KEY.to_owned(),
            serde_json::Value::String(state_key),
        );
    }
}
