/** biome-ignore-all lint/correctness/noNestedComponentDefinitions: shadcn */
import {
  ChevronDownIcon,
  ChevronLeftIcon,
  ChevronRightIcon,
} from 'lucide-react'
import * as React from 'react'
import {
  type DayButton,
  DayPicker,
  getDefaultClassNames,
} from 'react-day-picker'
import { Button, buttonVariants } from '@/components/ui/button'
import { cn } from '@/lib/utils'

type CalendarProps = Omit<
  React.ComponentProps<typeof DayPicker>,
  'mode' | 'selected' | 'onSelect'
> & {
  buttonVariant?: React.ComponentProps<typeof Button>['variant']
  showClearButton?: boolean
  onClear?: () => void
  selected?: Date
  onSelect?: (date: Date | undefined) => void
}

function Calendar({
  className,
  classNames,
  showOutsideDays = true,
  captionLayout = 'dropdown',
  buttonVariant = 'ghost',
  formatters,
  components,
  showClearButton = false,
  onClear,
  selected,
  onSelect,
  ...props
}: CalendarProps) {
  const defaultClassNames = getDefaultClassNames()
  const isControlled = selected !== undefined
  const [internalSelected, setInternalSelected] = React.useState<
    Date | undefined
  >(selected instanceof Date ? selected : undefined)
  const [month, setMonth] = React.useState<Date | undefined>(() => {
    if (selected instanceof Date) return new Date(selected)
    const dm = (props as { defaultMonth?: Date }).defaultMonth
    if (dm instanceof Date) return new Date(dm)
    return undefined
  })

  // Sync internal state when controlled prop changes
  React.useEffect(() => {
    if (isControlled) {
      setInternalSelected(selected instanceof Date ? selected : undefined)
    }
  }, [selected, isControlled])

  // Keep visible month in sync with externally controlled selected
  React.useEffect(() => {
    if (isControlled && selected instanceof Date) {
      setMonth(new Date(selected))
    }
  }, [selected, isControlled])

  const handleSelect = (date: Date | undefined) => {
    if (!isControlled) {
      setInternalSelected(date)
    }
    if (onSelect) {
      onSelect(date)
    }
  }

  const handleClear = () => {
    if (!isControlled) {
      setInternalSelected(undefined)
    }
    if (onClear) {
      onClear()
    } else if (onSelect) {
      onSelect(undefined)
    }
  }

  const selectedDate = isControlled
    ? selected instanceof Date
      ? selected
      : undefined
    : internalSelected

  return (
    <div className="p-6">
      <DayPicker
        captionLayout={captionLayout}
        className={cn(
          'group/calendar [--cell-size:2.5rem] data-[slot=card-content]:bg-transparent data-[slot=popover-content]:bg-transparent',
          String.raw`rtl:**:[.rdp-button\_next>svg]:rotate-180`,
          String.raw`rtl:**:[.rdp-button\_previous>svg]:rotate-180`,
          className,
        )}
        classNames={{
          root: cn('w-fit', defaultClassNames.root),
          months: cn(
            'relative flex flex-col gap-4 md:flex-row',
            defaultClassNames.months,
          ),
          month: cn('flex w-full flex-col gap-4', defaultClassNames.month),
          nav: cn(
            'absolute inset-x-0 top-0 flex w-full items-center justify-between gap-1 px-0',
            defaultClassNames.nav,
          ),
          button_previous: cn(
            buttonVariants({ variant: buttonVariant }),
            'size-7 select-none rounded p-0 hover:bg-gray-100 aria-disabled:opacity-50',
            defaultClassNames.button_previous,
          ),
          button_next: cn(
            buttonVariants({ variant: buttonVariant }),
            'size-7 select-none rounded p-0 hover:bg-gray-100 aria-disabled:opacity-50',
            defaultClassNames.button_next,
          ),
          month_caption: cn(
            'mb-4 flex h-7 w-full items-center justify-between px-0',
            defaultClassNames.month_caption,
          ),
          dropdowns: cn(
            'flex h-7 items-center gap-1.5 font-normal text-[#101828] text-base',
            defaultClassNames.dropdowns,
          ),
          dropdown_root: cn(
            'relative rounded border border-gray-200 bg-white px-2 py-1 text-sm hover:bg-gray-50',
            defaultClassNames.dropdown_root,
          ),
          dropdown: cn(
            'absolute inset-0 opacity-0',
            defaultClassNames.dropdown,
          ),
          caption_label: cn(
            'flex select-none items-center gap-2 font-normal text-[#101828] text-lg',
            captionLayout === 'label' ? 'text-sm' : 'text-lg',
            defaultClassNames.caption_label,
          ),
          table: 'w-full border-collapse',
          weekdays: cn('mb-2 flex', defaultClassNames.weekdays),
          weekday: cn(
            'flex-1 select-none rounded-md text-center font-normal text-[#6a7282] text-sm',
            defaultClassNames.weekday,
          ),
          week: cn('flex w-full', defaultClassNames.week),
          week_number_header: cn(
            'w-(--cell-size) select-none',
            defaultClassNames.week_number_header,
          ),
          week_number: cn(
            'select-none text-[0.8rem] text-muted-foreground',
            defaultClassNames.week_number,
          ),
          day: cn(
            'group/day relative aspect-square h-full w-full select-none p-0 text-center',
            defaultClassNames.day,
          ),
          range_start: cn(
            'rounded-l-md bg-accent',
            defaultClassNames.range_start,
          ),
          range_middle: cn('rounded-none', defaultClassNames.range_middle),
          range_end: cn('rounded-r-md bg-accent', defaultClassNames.range_end),
          today: cn('rounded-[10px]', defaultClassNames.today),
          outside: cn(
            'text-[#6a7282] aria-selected:text-[#6a7282]',
            defaultClassNames.outside,
          ),
          disabled: cn(
            'text-muted-foreground opacity-50',
            defaultClassNames.disabled,
          ),
          hidden: cn('invisible', defaultClassNames.hidden),
          ...classNames,
        }}
        components={{
          Root: ({ className, rootRef, ...props }) => {
            return (
              <div
                className={cn(className)}
                data-slot="calendar"
                ref={rootRef}
                {...props}
              />
            )
          },
          Chevron: ({ className, orientation, ...props }) => {
            if (orientation === 'left') {
              return (
                <ChevronLeftIcon
                  className={cn('size-4', className)}
                  {...props}
                />
              )
            }

            if (orientation === 'right') {
              return (
                <ChevronRightIcon
                  className={cn('size-4', className)}
                  {...props}
                />
              )
            }

            return (
              <ChevronDownIcon className={cn('size-4', className)} {...props} />
            )
          },
          DayButton: CalendarDayButton,
          WeekNumber: ({ children, ...props }) => {
            return (
              <td {...props}>
                <div className="flex size-(--cell-size) items-center justify-center text-center">
                  {children}
                </div>
              </td>
            )
          },
          ...components,
        }}
        formatters={{
          formatMonthDropdown: (date) =>
            date.toLocaleString('default', { month: 'long' }),
          formatYearDropdown: (date) => date.getFullYear().toString(),
          ...formatters,
        }}
        mode="single"
        month={month}
        onMonthChange={setMonth}
        onSelect={handleSelect}
        selected={selectedDate}
        showOutsideDays={showOutsideDays}
        {...props}
      />
      {showClearButton && (
        <div className="mt-4 flex items-center justify-between border-gray-200 border-t pt-4">
          <button
            className="font-normal text-[#101828] text-sm transition-colors hover:text-[#6a7282]"
            onClick={handleClear}
            type="button"
          >
            Clear
          </button>
        </div>
      )}
    </div>
  )
}

function CalendarDayButton({
  className,
  day,
  modifiers,
  ...props
}: React.ComponentProps<typeof DayButton>) {
  const defaultClassNames = getDefaultClassNames()

  const ref = React.useRef<HTMLButtonElement>(null)
  React.useEffect(() => {
    if (modifiers.focused) ref.current?.focus()
  }, [modifiers.focused])

  return (
    <Button
      className={cn(
        'flex aspect-square size-auto w-full min-w-(--cell-size) items-center justify-center font-normal text-[#101828] text-sm leading-none',
        'rounded-[10px] transition-colors',
        'hover:bg-ens-white',
        'data-[selected-single=true]:bg-ens-blue data-[selected-single=true]:text-white',
        'data-[range-end=true]:rounded-md data-[range-middle=true]:rounded-none data-[range-start=true]:rounded-md',
        'data-[range-end=true]:rounded-r-md data-[range-start=true]:rounded-l-md',
        'data-[range-end=true]:bg-ens-blue data-[range-middle=true]:bg-accent data-[range-start=true]:bg-ens-blue',
        'data-[range-end=true]:text-white data-[range-middle=true]:text-accent-foreground data-[range-start=true]:text-white',
        'group-data-[focused=true]/day:relative group-data-[focused=true]/day:z-10',
        'group-data-[focused=true]/day:border-ring group-data-[focused=true]/day:ring-[3px] group-data-[focused=true]/day:ring-ring/50',
        defaultClassNames.day,
        className,
      )}
      data-day={day.date.toLocaleDateString()}
      data-range-end={modifiers.range_end}
      data-range-middle={modifiers.range_middle}
      data-range-start={modifiers.range_start}
      data-selected-single={
        modifiers.selected &&
        !modifiers.range_start &&
        !modifiers.range_end &&
        !modifiers.range_middle
      }
      ref={ref}
      size="icon"
      variant="ghost"
      {...props}
    />
  )
}

export { Calendar, CalendarDayButton }
