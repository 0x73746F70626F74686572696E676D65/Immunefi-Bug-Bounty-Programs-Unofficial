import type { Address } from 'viem'
import { parseSearchQuery } from '@/features/search/parseSearchQuery'
import type { ParsedSearchQuery } from '@/features/search/search.types'
import type { SearchHistoryItem } from './useSearchHistory'

type NameSuggestion = {
  readonly type: 'name'
  readonly value: string
}

type AddressSuggestion = {
  readonly type: 'address'
  readonly value: Address
}

type Separator = {
  readonly type: 'separator'
}

export type SuggestionItem = NameSuggestion | AddressSuggestion | Separator

export type ParsedInput = ParsedSearchQuery

export const parseSearchInput = parseSearchQuery

type BuildSuggestionsParams = {
  readonly parsedInput: ParsedInput
  readonly primaryName?: string | null
  readonly history: readonly SearchHistoryItem[]
  readonly tldStatus?: 'supported' | 'unsupported' | 'unknown'
}

const MAX_SUGGESTIONS = 6

const getTypedNameSuggestions = (
  parsedInput: ParsedInput,
  tldStatus: 'supported' | 'unsupported' | 'unknown',
): string[] => {
  if (parsedInput.type === 'invalid') return [parsedInput.value]
  if (parsedInput.type !== 'name') return []

  const shouldSuggestEthFallback =
    tldStatus === 'unsupported' &&
    parsedInput.value.includes('.') &&
    !parsedInput.value.endsWith('.eth')

  return shouldSuggestEthFallback
    ? [parsedInput.value, `${parsedInput.value}.eth`]
    : [parsedInput.value]
}

export const buildSuggestions = ({
  parsedInput,
  primaryName,
  history,
  tldStatus = 'unknown',
}: BuildSuggestionsParams): SuggestionItem[] => {
  const suggestions: SuggestionItem[] = []

  if (parsedInput.type === 'address') {
    suggestions.push({ type: 'address', value: parsedInput.value })
    if (primaryName) {
      suggestions.push(
        { type: 'name', value: primaryName },
        { type: 'separator' },
      )
    }
  }

  for (const value of getTypedNameSuggestions(parsedInput, tldStatus)) {
    suggestions.push({
      type: 'name',
      value,
    })
  }

  if (parsedInput.type === 'empty') {
    for (const item of history) {
      if (item.kind === 'name') {
        const parsedHistoryName = parseSearchQuery(item.value)
        if (parsedHistoryName.type !== 'name') continue

        suggestions.push({
          type: 'name',
          value: parsedHistoryName.value,
        })
      } else {
        suggestions.push({ type: 'address', value: item.value })
      }
    }
  }

  return suggestions.slice(0, MAX_SUGGESTIONS)
}
