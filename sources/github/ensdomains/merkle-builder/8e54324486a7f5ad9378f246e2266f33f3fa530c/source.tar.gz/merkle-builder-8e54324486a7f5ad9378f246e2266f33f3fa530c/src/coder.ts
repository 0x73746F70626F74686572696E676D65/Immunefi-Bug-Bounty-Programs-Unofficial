import {
	EMPTY_BYTES,
	EMPTY_LEAF,
	encodeNode,
	isBranch,
	isEmptyLeaf,
	isExtension,
	toNibblePath,
	type MaybeNode,
} from "./trie.js";

const TY_NULL = 0;
const TY_BRANCH = 1;
const TY_EXTENSION = 2;
const TY_EMPTY_LEAF = 3;
const TY_LEAF = 4;
const TY_BRANCH_WITH_CACHE = 5;

export const MAX_SIZE = (1 << 22) - 1; // 4194304

export class Coder {
	static getByteCount(node: MaybeNode) {
		const c = new this();
		c.writeNode(node);
		return c.pos;
	}
	public pos = 0;
	constructor(public buf: Uint8Array = new Uint8Array(1024)) {}
	get remaining() {
		return Math.max(0, this.buf.length - this.pos);
	}
	reset() {
		this.pos = 0;
	}
	expand(need: number) {
		const required = this.pos + need;
		let size = this.buf.length;
		if (required <= size) return;
		while (size < required) size <<= 1;
		const v = new Uint8Array(size);
		v.set(this.buf);
		this.buf = v;
	}
	require(need: number) {
		if (need && this.pos + need > this.buf.length) {
			throw new Error(`eof: ${this.pos + need} > ${this.buf.length}`);
		}
	}
	readByte() {
		this.require(1);
		return this.buf[this.pos++];
	}
	writeByte(x: number) {
		this.expand(1);
		this.buf[this.pos++] = x;
	}
	readSize() {
		let size = this.readByte();
		if (size & 128) {
			const next = this.readByte();
			size = (size & 127) + ((next & 127) << 7);
			if (next & 128) {
				size += this.readByte() << 14;
			}
		}
		return size;
	}
	writeSize(size: number) {
		if (size < 128) {
			this.writeByte(size);
		} else {
			this.writeByte(size | 128);
			size >>= 7;
			if (size < 128) {
				this.writeByte(size);
			} else {
				this.writeByte(size | 128);
				size >>= 7;
				if (size >> 8) throw new RangeError("overflow");
				this.writeByte(size);
			}
		}
	}
	readBytes(n: number) {
		if (!n) return EMPTY_BYTES;
		this.require(n);
		return this.buf.slice(this.pos, (this.pos += n));
	}
	writeBytes(v: Uint8Array) {
		this.expand(v.length);
		this.buf.set(v, this.pos);
		this.pos += v.length;
	}
	readSizedBytes(): Uint8Array {
		return this.readBytes(this.readSize());
	}
	writeSizedBytes(v: Uint8Array) {
		this.writeSize(v.length);
		this.writeBytes(v);
	}
	readPath() {
		const n = this.readSize();
		return toNibblePath(this.readBytes((n + 1) >> 1)).subarray(0, n);
	}
	writePath(v: Uint8Array) {
		this.writeSize(v.length);
		this.expand((v.length + 1) >> 1);
		for (let i = 0; i < v.length; i += 2) {
			this.buf[this.pos++] = (v[i] << 4) | (v[i + 1] ?? 0);
		}
	}
	readNodes(length = 16): MaybeNode[] {
		return Array.from({ length }, () => this.readNode());
	}
	readNode(): MaybeNode {
		const ty = this.readByte();
		switch (ty) {
			case TY_NULL:
				return;
			case TY_BRANCH_WITH_CACHE:
				return {
					children: this.readNodes(),
					cache: this.readSizedBytes(),
				};
			case TY_BRANCH:
				return { children: this.readNodes() };
			case TY_EXTENSION: {
				const path = this.readPath();
				const child = this.readNode();
				if (!isBranch(child)) throw new Error("bug");
				return { path, child };
			}
			case TY_EMPTY_LEAF:
				return EMPTY_LEAF;
			case TY_LEAF:
				return {
					path: this.readPath(),
					data: this.readSizedBytes(),
				};
			default:
				throw new Error(`unknown type: ${ty}`);
		}
	}
	writeNode(node: MaybeNode, includeCache?: boolean) {
		if (!node) {
			this.writeByte(TY_NULL);
		} else if (isBranch(node)) {
			const cache =
				includeCache === undefined
					? node.cache
					: includeCache
						? encodeNode(node)
						: undefined;
			this.writeByte(cache ? TY_BRANCH_WITH_CACHE : TY_BRANCH);
			for (const x of node.children) {
				this.writeNode(x, includeCache);
			}
			if (cache) this.writeSizedBytes(cache);
		} else if (isExtension(node)) {
			this.writeByte(TY_EXTENSION);
			this.writePath(node.path);
			this.writeNode(node.child, includeCache);
		} else if (isEmptyLeaf(node)) {
			this.writeByte(TY_EMPTY_LEAF);
		} else {
			this.writeByte(TY_LEAF);
			this.writePath(node.path);
			this.writeSizedBytes(node.data);
		}
	}
	get bytes() {
		return this.buf.subarray(0, this.pos); // warning: not a copy
	}
}
