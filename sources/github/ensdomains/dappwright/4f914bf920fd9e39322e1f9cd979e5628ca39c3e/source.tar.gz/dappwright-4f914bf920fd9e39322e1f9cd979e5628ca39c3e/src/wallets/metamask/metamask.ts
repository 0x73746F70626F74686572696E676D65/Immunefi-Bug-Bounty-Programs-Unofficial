import downloader from '../../downloader/downloader';
import { performSetup } from '../../helpers';
import Wallet from '../wallet';
import type { Step, WalletIdOptions, WalletOptions } from '../wallets';
import {
  addNetwork,
  addToken,
  approve,
  confirmNetworkSwitch,
  confirmTransaction,
  countAccounts,
  createAccount,
  deleteAccount,
  deleteNetwork,
  getTokenBalance,
  hasNetwork,
  importPk,
  lock,
  reject,
  sign,
  signin,
  switchAccount,
  switchNetwork,
  unlock,
  updateNetworkRpc,
} from './actions';
import { adjustSettings, closePopup, createPassword, doOnboarding, importAccount } from './setup/setupActions';

export class MetaMaskWallet extends Wallet {
  static id = 'metamask' as WalletIdOptions;
  static recommendedVersion = '13.13.1';
  static releasesUrl = 'https://api.github.com/repos/metamask/metamask-extension/releases';
  static homePath = '/home.html';

  options: WalletOptions;

  // Extension Downloader
  static download = downloader(this.id, this.releasesUrl, this.recommendedVersion);

  // Setup
  defaultSetupSteps: Step<WalletOptions>[] = [importAccount, createPassword, doOnboarding, closePopup, adjustSettings];
  setup = performSetup(this.page, this.defaultSetupSteps);

  // Actions
  addNetwork = addNetwork(this.page);
  addToken = addToken(this.page);
  approve = approve(this.page);
  createAccount = createAccount(this.page);
  confirmNetworkSwitch = confirmNetworkSwitch(this.page);
  confirmTransaction = confirmTransaction(this.page);
  countAccounts = countAccounts(this.page);
  deleteAccount = deleteAccount(this.page);
  deleteNetwork = deleteNetwork(this.page);
  getTokenBalance = getTokenBalance(this.page);
  hasNetwork = hasNetwork(this.page);
  importPK = importPk(this.page);
  lock = lock(this.page);
  reject = reject(this.page);
  sign = sign(this.page);
  signin = signin(this.page);
  switchAccount = switchAccount(this.page);
  switchNetwork = switchNetwork(this.page);
  unlock = unlock(this.page);
  updateNetworkRpc = updateNetworkRpc(this.page);
}
