declare module 'dns-packet'
