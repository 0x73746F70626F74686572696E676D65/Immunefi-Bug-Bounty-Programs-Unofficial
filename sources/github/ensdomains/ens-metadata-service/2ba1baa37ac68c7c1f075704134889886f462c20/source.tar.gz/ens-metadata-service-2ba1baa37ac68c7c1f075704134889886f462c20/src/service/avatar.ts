import {
  AvatarResolver,
  UnsupportedMediaKey,
  utils
}                                        from '@ensdomains/ens-avatar';
import { MediaKey }                      from '@ensdomains/ens-avatar/dist/types';
import { strict as assert }              from 'assert';
import { JsonRpcProvider }               from 'ethers';
import createDOMPurify                   from 'dompurify';
import { JSDOM }                         from 'jsdom';
import {
  ResolverNotFound,
  RetrieveURIFailed,
  TextRecordNotFound,
}                                        from '../base';
import { IPFS_GATEWAY, MAX_CONTENT_LENGTH, NFT_METADATA_MAX_CONTENT_LENGTH, OPENSEA_API_KEY, SELF_HOST_DENYLIST } from '../config';
import { abortableFetch }                from '../utils/abortableFetch';
import isSvg, { SNIFF_BYTES }            from '../utils/isSvg';
// Side-effect import: hardens @ensdomains/ens-avatar's shared axios instance
// (single SSRF-guarded agent interceptor + metadata size cap + timeout) once.
import '../utils/ensAvatarFetch';

const window = new JSDOM('').window;
const { ALLOWED_IMAGE_MIMETYPES } = utils;

interface HostMeta {
  chain_id?        : number;
  namespace?       : string;
  contract_address?: string;
  token_id?        : string;
  reference_url?   : string;
}

export interface AvatarMetadata {
  uri              : string;
  animation        : string;
  animation_details: {};
  attributes       : any[];
  created_by       : string;
  event            : string;
  image_data       : string;
  image_url        : string;
  image_details    : string;
  name             : string;
  description?     : string;
  external_link?   : string;
  image?           : string;
  animation_url?   : string;
  hostType         : string;
  host_meta        : HostMeta;
  is_owner         : boolean;
}

export class AvatarMetadata {
  defaultProvider: JsonRpcProvider;
  avtResolver: AvatarResolver;
  constructor(provider: JsonRpcProvider, uri: string) {
    this.defaultProvider = provider;
    // Note: no per-request `agents`. the SSRF-guarded agents are applied once,
    // process-wide, via ../utils/ensAvatarFetch (see import above). Passing agents
    // here would append an un-ejected interceptor to the shared axios per request.
    this.avtResolver = new AvatarResolver(provider, {
      ipfs: IPFS_GATEWAY,
      apiKey: { opensea: OPENSEA_API_KEY },
      // Include both the bare host and its trailing-dot FQDN form: @ensdomains/ens-avatar
      // compares against `new URL(uri).hostname` with an exact-string match, which
      // preserves a trailing dot, so `metadata.ens.domains.` would otherwise bypass a
      // bare entry. (The socket-level guard in ensAvatarFetch canonicalizes instead.)
      urlDenyList: SELF_HOST_DENYLIST.flatMap((h) => [h, `${h}.`]),
      // Conservative cap on attacker-controlled metadata/image bodies (supported on
      // 1.0.3: sets fetch.defaults.maxContentLength on the shared axios). Bounds the
      // size of inline SVG / metadata fed into downstream regex/XML/DOMPurify work.
      maxContentLength: NFT_METADATA_MAX_CONTENT_LENGTH,
    });
    this.uri = uri;
  }

  async getImage(type: MediaKey = "avatar"): Promise<[Buffer, string]> {
    let avatarURI;
    try {
      if (type === "avatar") {
        avatarURI = await this.avtResolver.getAvatar(this.uri, {
          jsdomWindow: window,
        });
      } else if (type === "header") {
        avatarURI = await this.avtResolver.getHeader(this.uri, {
          jsdomWindow: window
        })
      } else {
        throw new UnsupportedMediaKey();
      }
    } catch (error: any) {
      if (error instanceof Error) {
        console.log(`${this.uri} - error:`, error.message);
      }
      if (typeof error === 'string') {
        console.log(`${this.uri} - error:`, error);
      }
      throw new RetrieveURIFailed(
        `Error fetching ${type}: Provided url or NFT source is broken.`,
        404
      );
    }

    if (!avatarURI) {
      throw new TextRecordNotFound(
        `There is no ${type} set under given address`,
        404
      );
    }

    if (avatarURI?.startsWith('http')) {
      // abort fetching image after 5sec
      const response = await abortableFetch(avatarURI, {
        timeout: 7000,
        size: MAX_CONTENT_LENGTH,
        headers: {
          'user-agent': 'ENS-ImageFetcher/1.0.0',
        },
      });

      assert(!!response, 'Response is empty');

      const mimeType = response?.headers.get('Content-Type') || '';
      const data = await response?.buffer();

      assert(
        ALLOWED_IMAGE_MIMETYPES.includes(mimeType),
        'Mimetype is not supported'
      );

      // Only materialise the SVG sniff window (not the whole ≤25MB buffer) as a
      // string. SNIFF_BYTES*4 bytes covers isSvg's first-4096-chars check even for
      // multi-byte leading content; the full toString below runs only for SVGs.
      if (
        mimeType?.includes('svg') ||
        isSvg(data.subarray(0, SNIFF_BYTES * 4).toString())
      ) {
        const DOMPurify = createDOMPurify(window);
        const cleanData = DOMPurify.sanitize(data.toString(), {
          FORBID_TAGS: ['a', 'area', 'base', 'iframe', 'link'],
        });
        return [Buffer.from(cleanData), mimeType];
      }

      return [data, mimeType];
    }

    if (avatarURI?.startsWith('data:')) {
      // base64 image
      const mimeType = avatarURI.match(/[^:]\w+\/[\w-+\d.]+(?=;|,)/);
      const base64data = avatarURI.split('base64,')[1];

      assert(base64data, 'Base64 format is incorrect: Empty data');
      assert(mimeType, 'Base64 format is incorrect: No mimetype');
      assert(
        ALLOWED_IMAGE_MIMETYPES.includes(mimeType[0]),
        'Mimetype is not supported'
      );

      const data = Buffer.from(base64data, 'base64');
      return [data, mimeType[0]];
    }

    throw new RetrieveURIFailed(
      'Unknown type/protocol given for the image source.',
      400
    );
  }

  async getMeta(networkName: string, key: MediaKey = "avatar") {
    let metadata: any;
    try {
      metadata = await this.avtResolver.getMetadata(this.uri, key);
    } catch (error: any) {
      if (error instanceof Error) {
        console.log(`${this.uri} - error:`, error.message);
      }
      if (typeof error === 'string') {
        console.log(`${this.uri} - error:`, error);
      }
      throw new ResolverNotFound(
        'There is no resolver set under given address',
        404
      );
    }

    if (!metadata) {
      throw new TextRecordNotFound(
        `There is no ${key} set under given address`,
        404
      );
    }

    if (key === "avatar") {
      if (!metadata.image) {
        if (metadata.image_url) {
          metadata.image = metadata.image_url;
        } else if (metadata.image_data) {
          metadata.image = `https://metadata.ens.domains/${networkName}/avatar/${this.uri}`;
        } else {
          throw new TextRecordNotFound(
            `There is no avatar set under given address`,
            404
          );
        }
      }
      // replace back original url after fetch
      metadata.image = metadata.image.replace(IPFS_GATEWAY, 'https://ipfs.io');
    } else if (key === "header") {
      metadata.header = metadata.header.replace(IPFS_GATEWAY, 'https://ipfs.io');
    }

    return metadata;
  }
}

export async function getAvatarMeta(
  provider: JsonRpcProvider,
  name: string,
  networkName: string
): Promise<any> {
  const avatar = new AvatarMetadata(provider, name);
  return await avatar.getMeta(networkName, "avatar");
}

export async function getHeaderMeta(
  provider: JsonRpcProvider,
  name: string,
  networkName: string
): Promise<any> {
  const avatar = new AvatarMetadata(provider, name);
  return await avatar.getMeta(networkName, "header");
}

export async function getAvatarImage(
  provider: JsonRpcProvider,
  name: string
): Promise<[Buffer, string]> {
  const avatar = new AvatarMetadata(provider, name);
  return await avatar.getImage('avatar');
}

export async function getHeaderImage(
  provider: JsonRpcProvider,
  name: string
): Promise<[Buffer, string]> {
  const avatar = new AvatarMetadata(provider, name);
  return await avatar.getImage('header');
}
