import { Request, Response } from 'express';
import { queryNFT } from '../service/queryNFT';
import { safeErrorMessage } from '../utils/safeErrorMessage';

/* istanbul ignore next */
export async function queryNFTep(req: Request, res: Response) {
  // #swagger.description = 'Query endpoint for NFT URIs'
  // #swagger.parameters['uri'] = { in: 'query', description: 'NFT URI as defined under CAIP-22 for erc721 assets and CAIP-29 for erc1155 assets.' }
  const { uri } = req.query;
  if (!uri) {
    res.status(400).json({
      message:
        'Please be sure adding your NFT URI as a query. i.e. /queryNFT?uri=eip155:1/erc721:0x...',
    });
    return;
  }
  try {
    const metadata = await queryNFT(uri as string);
    /* #swagger.responses[200] = { 
          description: 'NFT metadata'
    } */
    res.status(200).json(metadata);
  } catch (error) {
    if (error.code === 'ERR_FR_REDIRECTION_FAILURE') {
      res.status(500).json({
        message: "Redirection is not allowed",
      });
      return;
    }
    /* #swagger.responses[500] = {
          description: 'Internal Server Error'
    } */
    // Serialize a bounded scalar, never the raw error object: ethers CALL_EXCEPTION
    // carries a BigInt and axios AxiosError a circular agent graph, either of which
    // would throw inside this async catch and crash the process. See safeErrorMessage.
    res.status(500).json({
      message: safeErrorMessage(error, 'NFT metadata resolution failed'),
    });
  }
}
