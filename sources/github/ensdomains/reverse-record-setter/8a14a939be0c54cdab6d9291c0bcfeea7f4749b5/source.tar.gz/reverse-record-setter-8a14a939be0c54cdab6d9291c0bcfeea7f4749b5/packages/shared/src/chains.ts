import { toCoinType } from "viem";
import {
  type Chain,
  arbitrum,
  arbitrumSepolia,
  base,
  baseSepolia,
  linea,
  lineaSepolia,
  optimism,
  optimismSepolia,
  scroll,
  scrollSepolia,
} from "viem/chains";

// L2ReverseRegistrar addresses (same across all L2s via CREATE3)
export const L2_REVERSE_REGISTRAR_ADDRESS_MAINNET =
  "0x0000000000D8e504002cC26E3Ec46D81971C1664" as const;
export const L2_REVERSE_REGISTRAR_ADDRESS_TESTNET =
  "0x00000BeEF055f7934784D6d81b6BC86665630dbA" as const;

export function getL2ReverseRegistrarAddress(isTestnet: boolean) {
  return isTestnet
    ? L2_REVERSE_REGISTRAR_ADDRESS_TESTNET
    : L2_REVERSE_REGISTRAR_ADDRESS_MAINNET;
}

export interface ChainConfig {
  chain: Chain;
  coinType: bigint;
  isTestnet: boolean;
}

// Mainnet chains
export const MAINNET_CHAINS: ChainConfig[] = [
  {
    chain: base,
    coinType: toCoinType(base.id),
    isTestnet: false,
  },
  {
    chain: optimism,
    coinType: toCoinType(optimism.id),
    isTestnet: false,
  },
  {
    chain: arbitrum,
    coinType: toCoinType(arbitrum.id),
    isTestnet: false,
  },
  {
    chain: scroll,
    coinType: toCoinType(scroll.id),
    isTestnet: false,
  },
  {
    chain: linea,
    coinType: toCoinType(linea.id),
    isTestnet: false,
  },
];

// Testnet chains
export const TESTNET_CHAINS: ChainConfig[] = [
  {
    chain: baseSepolia,
    coinType: toCoinType(baseSepolia.id),
    isTestnet: true,
  },
  {
    chain: optimismSepolia,
    coinType: toCoinType(optimismSepolia.id),
    isTestnet: true,
  },
  {
    chain: arbitrumSepolia,
    coinType: toCoinType(arbitrumSepolia.id),
    isTestnet: true,
  },
  {
    chain: scrollSepolia,
    coinType: toCoinType(scrollSepolia.id),
    isTestnet: true,
  },
  {
    chain: lineaSepolia,
    coinType: toCoinType(lineaSepolia.id),
    isTestnet: true,
  },
];

// All supported chains
export const SUPPORTED_CHAINS: ChainConfig[] = [
  ...MAINNET_CHAINS,
  ...TESTNET_CHAINS,
];

export const CHAIN_BY_COIN_TYPE = new Map(
  SUPPORTED_CHAINS.map((config) => [config.coinType, config])
);

/**
 * Get chain config by coin type
 */
export function getChainByCoinType(
  coinType: bigint | number
): ChainConfig | undefined {
  return CHAIN_BY_COIN_TYPE.get(BigInt(coinType));
}

/**
 * Check if a coin type is supported
 */
export function isSupportedCoinType(coinType: bigint): boolean {
  return CHAIN_BY_COIN_TYPE.has(coinType);
}
