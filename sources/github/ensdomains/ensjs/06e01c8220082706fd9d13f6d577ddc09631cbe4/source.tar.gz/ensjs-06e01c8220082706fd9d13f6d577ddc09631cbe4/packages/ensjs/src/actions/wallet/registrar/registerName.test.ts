import type { Address, Hex } from 'viem'
import { maxUint256, parseAbi } from 'viem'
import { afterEach, beforeAll, beforeEach, expect, it } from 'vitest'
import {
  deploymentAddresses,
  publicClient,
  testClient,
  waitForTransaction,
  walletClient,
} from '../../../test/addTestContracts.js'
import type { L2RegistrationParameters } from '../../../utils/registrar/registerHelpers.js'
import { commitName } from './commitName.js'
import { registerName } from './registerName.js'

let snapshot: Hex
let accounts: Address[]

beforeAll(async () => {
  accounts = await walletClient.getAddresses()
})

beforeEach(async () => {
  snapshot = await testClient.snapshot()
})

afterEach(async () => {
  await testClient.revert({ id: snapshot })
})

const secret = `0x${'a'.repeat(64)}` as Hex

it('should return a registration transaction and succeed', async () => {
  const params: L2RegistrationParameters = {
    label: 'cool-swag',
    duration: 31536000,
    owner: accounts[1],
    secret,
  }
  const commitTx = await commitName(walletClient, {
    ...params,
    account: accounts[1],
  })
  expect(commitTx).toBeTruthy()
  const commitReceipt = await waitForTransaction(commitTx)

  expect(commitReceipt.status).toBe('success')

  await testClient.increaseTime({ seconds: 61 })
  await testClient.mine({ blocks: 1 })

  // Approve the ETH Registrar to spend USDC on behalf of accounts[1]
  const approveTx = await walletClient.writeContract({
    address: deploymentAddresses.USDC,
    abi: parseAbi([
      'function approve(address spender, uint256 amount) returns (bool)',
    ]),
    functionName: 'approve',
    args: [deploymentAddresses.ETHRegistrar, maxUint256],
    account: accounts[1],
  })
  const approveReceipt = await publicClient.waitForTransactionReceipt({
    hash: approveTx,
  })
  expect(approveReceipt.status).toBe('success')

  const tx = await registerName(walletClient, {
    ...params,
    account: accounts[1],
  })
  expect(tx).toBeTruthy()
  const receipt = await waitForTransaction(tx)
  expect(receipt.status).toBe('success')

  // TODO: add test for owner
  // const owner = await publicClient.readContract({
  //   abi: nameWrapperOwnerOfSnippet,
  //   functionName: 'ownerOf',
  //   address: getChainContractAddress({
  //     chain: publicClient.chain,
  //     contract: 'ensNameWrapper',
  //   }),
  //   args: [BigInt(namehash(name))],
  // })
  // expect(owner).toBe(params.owner)
})
