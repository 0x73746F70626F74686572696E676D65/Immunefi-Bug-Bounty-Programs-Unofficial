import { encodeFunctionData } from 'viem'
import { expect, it } from 'vitest'
import {
  type ResolverMulticallItem,
  resolverMulticallParameters,
} from './resolverMulticallParameters.js'

const encodeResult = (items: readonly ResolverMulticallItem[]) => {
  // @ts-expect-error ABI overlap type issues
  return items.map((item) => encodeFunctionData(item))
}

it('generates a record call array', async () => {
  expect(
    encodeResult(
      await resolverMulticallParameters({
        name: 'test.eth',
        clearRecords: true,
        coins: [
          { coin: 'ETH', value: '0xf39Fd6e51aad88F6F4ce6aB8827279cffFb92266' },
        ],

        texts: [{ key: 'email', value: 'test@example.com' }],
      }),
    ),
  ).toMatchInlineSnapshot(`
    [
      "0x3603d758eb4f647bea6caa36333c816d7b46fdcb05f9466ecacc140ea8c66faf15b3d9f1",
      "0x10f13a8ceb4f647bea6caa36333c816d7b46fdcb05f9466ecacc140ea8c66faf15b3d9f1000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000a00000000000000000000000000000000000000000000000000000000000000005656d61696c000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001074657374406578616d706c652e636f6d00000000000000000000000000000000",
      "0x8b95dd71eb4f647bea6caa36333c816d7b46fdcb05f9466ecacc140ea8c66faf15b3d9f1000000000000000000000000000000000000000000000000000000000000003c00000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000014f39fd6e51aad88f6f4ce6ab8827279cfffb92266000000000000000000000000",
    ]
  `)
})
it('adds clearRecords call when clearRecords is true', async () => {
  expect(
    encodeResult(
      await resolverMulticallParameters({
        name: 'test.eth',
        clearRecords: true,
      }),
    ),
  ).toMatchInlineSnapshot(`
    [
      "0x3603d758eb4f647bea6caa36333c816d7b46fdcb05f9466ecacc140ea8c66faf15b3d9f1",
    ]
  `)
})
it('adds contentHash call when contentHash is defined', async () => {
  expect(
    encodeResult(
      await resolverMulticallParameters({
        name: 'test.eth',
        contentHash: 'ipfs://Qma8mnp6xV3J2cRNf3mTth5C8nV11CAnceVinc3y8jSbio',
      }),
    ),
  ).toMatchInlineSnapshot(`
    [
      "0x304e6adeeb4f647bea6caa36333c816d7b46fdcb05f9466ecacc140ea8c66faf15b3d9f100000000000000000000000000000000000000000000000000000000000000400000000000000000000000000000000000000000000000000000000000000026e30101701220af4147b366bee9eb9a21a9c2d5ccdde35fa4b8d2e0d44854fc81aeb894e8ce280000000000000000000000000000000000000000000000000000",
    ]
  `)
})
it('does not add abi call when abi is undefined', async () => {
  expect(
    await resolverMulticallParameters({
      name: 'test.eth',
      abi: undefined,
    }),
  ).toMatchInlineSnapshot('[]')
})
it('adds text calls when texts array is defined and not empty', async () => {
  expect(
    encodeResult(
      await resolverMulticallParameters({
        name: 'test.eth',
        texts: [{ key: 'email', value: 'cool' }],
      }),
    ),
  ).toMatchInlineSnapshot(`
    [
      "0x10f13a8ceb4f647bea6caa36333c816d7b46fdcb05f9466ecacc140ea8c66faf15b3d9f1000000000000000000000000000000000000000000000000000000000000006000000000000000000000000000000000000000000000000000000000000000a00000000000000000000000000000000000000000000000000000000000000005656d61696c0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000004636f6f6c00000000000000000000000000000000000000000000000000000000",
    ]
  `)
})
it('adds coin calls when coins array is defined and not empty', async () => {
  expect(
    encodeResult(
      await resolverMulticallParameters({
        name: 'test.eth',
        coins: [
          {
            coin: 'ETH',
            value: '0xf39Fd6e51aad88F6F4ce6aB8827279cffFb92266',
          },
        ],
      }),
    ),
  ).toMatchInlineSnapshot(`
    [
      "0x8b95dd71eb4f647bea6caa36333c816d7b46fdcb05f9466ecacc140ea8c66faf15b3d9f1000000000000000000000000000000000000000000000000000000000000003c00000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000014f39fd6e51aad88f6f4ce6ab8827279cfffb92266000000000000000000000000",
    ]
  `)
})
it('adds abi call when data is null', async () => {
  expect(
    encodeResult(
      await resolverMulticallParameters({
        name: 'test.eth',
        abi: { encodeAs: 'uri', data: null },
      }),
    ),
  ).toMatchInlineSnapshot(`
    [
      "0x623195b0eb4f647bea6caa36333c816d7b46fdcb05f9466ecacc140ea8c66faf15b3d9f1000000000000000000000000000000000000000000000000000000000000000800000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000000",
    ]
  `)
})
it('adds abi call when data is not empty', async () => {
  expect(
    encodeResult(
      await resolverMulticallParameters({
        name: 'test.eth',
        abi: { encodeAs: 'json', data: { foo: 'bar' } },
      }),
    ),
  ).toMatchInlineSnapshot(`
    [
      "0x623195b0eb4f647bea6caa36333c816d7b46fdcb05f9466ecacc140ea8c66faf15b3d9f100000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000000000000000000000d7b22666f6f223a22626172227d00000000000000000000000000000000000000",
    ]
  `)
})
it('adds multiple abi calls when multiple abis are added', async () => {
  expect(
    encodeResult(
      await resolverMulticallParameters({
        name: 'test.eth',
        abi: [
          { encodeAs: 'json', data: { foo: 'bar' } },
          { encodeAs: 'uri', data: null },
        ],
      }),
    ),
  ).toMatchInlineSnapshot(`
    [
      "0x623195b0eb4f647bea6caa36333c816d7b46fdcb05f9466ecacc140ea8c66faf15b3d9f100000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000060000000000000000000000000000000000000000000000000000000000000000d7b22666f6f223a22626172227d00000000000000000000000000000000000000",
      "0x623195b0eb4f647bea6caa36333c816d7b46fdcb05f9466ecacc140ea8c66faf15b3d9f1000000000000000000000000000000000000000000000000000000000000000800000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000000",
    ]
  `)
})
