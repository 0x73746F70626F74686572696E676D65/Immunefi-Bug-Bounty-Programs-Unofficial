export const universalResolverErrors = [
  {
    inputs: [
      {
        name: 'dns',
        type: 'bytes',
      },
    ],
    name: 'DNSDecodingFailed',
    type: 'error',
  },
  {
    inputs: [
      {
        name: 'ens',
        type: 'string',
      },
    ],
    name: 'DNSEncodingFailed',
    type: 'error',
  },
  {
    inputs: [],
    name: 'EmptyAddress',
    type: 'error',
  },
  {
    inputs: [
      {
        name: 'status',
        type: 'uint16',
      },
      {
        name: 'message',
        type: 'string',
      },
    ],
    name: 'HttpError',
    type: 'error',
  },
  {
    inputs: [],
    name: 'InvalidBatchGatewayResponse',
    type: 'error',
  },
  {
    inputs: [
      {
        name: 'errorData',
        type: 'bytes',
      },
    ],
    name: 'ResolverError',
    type: 'error',
  },
  {
    inputs: [
      {
        name: 'name',
        type: 'bytes',
      },
      {
        name: 'resolver',
        type: 'address',
      },
    ],
    name: 'ResolverNotContract',
    type: 'error',
  },
  {
    inputs: [
      {
        name: 'name',
        type: 'bytes',
      },
    ],
    name: 'ResolverNotFound',
    type: 'error',
  },
  {
    inputs: [
      {
        name: 'primary',
        type: 'string',
      },
      {
        name: 'primaryAddress',
        type: 'bytes',
      },
    ],
    name: 'ReverseAddressMismatch',
    type: 'error',
  },
  {
    inputs: [
      {
        name: 'selector',
        type: 'bytes4',
      },
    ],
    name: 'UnsupportedResolverProfile',
    type: 'error',
  },
] as const

const universalResolverReverse = {
  inputs: [
    {
      name: 'encodedAddress',
      type: 'bytes',
    },
    {
      name: 'coinType',
      type: 'uint256',
    },
  ],
  name: 'reverse',
  outputs: [
    { type: 'string', name: 'name' },
    { type: 'address', name: 'resolver' },
    { type: 'address', name: 'reverseResolver' },
  ],
  stateMutability: 'view',
  type: 'function',
} as const

export const universalResolverReverseSnippet = [
  ...universalResolverErrors,
  universalResolverReverse,
] as const

export const universalResolverReverseWithGatewaysSnippet = [
  ...universalResolverErrors,
  {
    ...universalResolverReverse,
    name: 'reverseWithGateways',
    inputs: [
      ...universalResolverReverse.inputs,
      {
        name: 'gateways',
        type: 'string[]',
      },
    ],
  },
] as const

const universalResolverResolve = {
  inputs: [
    {
      name: 'name',
      type: 'bytes',
    },
    {
      name: 'data',
      type: 'bytes',
    },
  ],
  name: 'resolve',
  outputs: [
    {
      name: 'data',
      type: 'bytes',
    },
    {
      name: 'resolver',
      type: 'address',
    },
  ],
  stateMutability: 'view',
  type: 'function',
} as const

export const universalResolverResolveSnippet = [
  ...universalResolverErrors,
  universalResolverResolve,
] as const

export const universalResolverResolveWithGatewaysSnippet = [
  ...universalResolverErrors,
  {
    ...universalResolverResolve,
    name: 'resolveWithGateways',
    inputs: [
      ...universalResolverResolve.inputs,
      {
        name: 'gateways',
        type: 'string[]',
      },
    ],
  },
] as const

export const universalResolverFindResolverSnippet = [
  ...universalResolverErrors,
  {
    inputs: [
      {
        name: 'name',
        type: 'bytes',
      },
    ],
    name: 'findResolver',
    outputs: [
      {
        name: 'address',
        type: 'address',
      },
      {
        name: 'node',
        type: 'bytes32',
      },
      {
        name: 'offset',
        type: 'uint256',
      },
    ],
    stateMutability: 'view',
    type: 'function',
  },
] as const

// NOTE: `findOwner`, `findParentRegistry` and `findRegistries` used to live
// here. They are no longer on the UniversalResolver — see `./v2/universalHelper`
// for their snippets (and `findExactOwner`, which replaced `findOwner`).
