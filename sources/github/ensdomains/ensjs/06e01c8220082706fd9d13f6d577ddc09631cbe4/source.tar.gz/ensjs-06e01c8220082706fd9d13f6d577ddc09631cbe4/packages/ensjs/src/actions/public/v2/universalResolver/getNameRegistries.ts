import { universalHelperFindRegistriesSnippet } from '@ensdomains/ensjs-abi/v2/universalHelper'
import type {
  Address,
  Chain,
  NamehashErrorType,
  ReadContractErrorType,
} from 'viem'
import { readContract } from 'viem/actions'
import { packetToBytes } from 'viem/ens'
import {
  type GetChainContractAddressErrorType,
  getAction,
  toHex,
} from 'viem/utils'
import type { RequireClientContracts } from '../../../../clients/chain.js'
import { getChainContractAddress } from '../../../../clients/chain.js'
import { ASSERT_NO_TYPE_ERROR } from '../../../../types/internal.js'

export type GetNameRegistriesParameters = {
  name: string
  address?: Address
}

export type GetNameRegistriesReturnType = readonly Address[]

export type GetNameRegistriesErrorType =
  | GetChainContractAddressErrorType
  | ReadContractErrorType
  | NamehashErrorType

/**
 * Find all registries in the ancestry of `name`.
 * @param client - {@link Client}
 * @param parameters - {@link GetNameRegistriesParameters}
 * @returns Array of registry addresses. {@link GetNameRegistriesReturnType}
 */
export async function getNameRegistries<chain extends Chain>(
  client: RequireClientContracts<chain, 'ensUniversalHelper'>,
  { name, address }: GetNameRegistriesParameters,
): Promise<GetNameRegistriesReturnType> {
  ASSERT_NO_TYPE_ERROR(client)

  const contractAddress =
    address ??
    getChainContractAddress({
      chain: client.chain,
      contract: 'ensUniversalHelper',
    })

  const readContractAction = getAction(client, readContract, 'readContract')

  return readContractAction({
    address: contractAddress,
    abi: universalHelperFindRegistriesSnippet,
    functionName: 'findRegistries',
    args: [toHex(packetToBytes(name))],
  })
}
