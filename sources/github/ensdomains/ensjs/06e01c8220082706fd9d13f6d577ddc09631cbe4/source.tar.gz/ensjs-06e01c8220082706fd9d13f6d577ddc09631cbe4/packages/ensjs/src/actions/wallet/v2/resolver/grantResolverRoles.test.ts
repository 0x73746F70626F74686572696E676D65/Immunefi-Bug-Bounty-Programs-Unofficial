import { permissionedResolverInitializeSnippet } from '@ensdomains/ensjs-abi/v2/permissionedResolver'
import type { Address } from 'viem'
import { encodeFunctionData } from 'viem'
import { beforeAll, describe, expect, it } from 'vitest'
import {
  deploymentAddresses,
  getDeployedProxyAddress,
  publicClient,
  waitForTransaction,
  walletClient,
} from '../../../../test/addTestContracts.js'
import { computeResolverResource } from '../../../../utils/v2/roles/resolverResource.js'
import {
  RESOLVER_ROLE_LINK_ADMIN,
  RESOLVER_ROLE_SET_ADDRESS_ADMIN,
  RESOLVER_ROLE_SET_TEXT_ADMIN,
} from '../../../../utils/v2/roles/resolverRoles.js'
import { hasRoles } from '../../../public/v2/accessControl/hasRoles.js'
import { deployVerifiableProxy } from '../verifiableFactory/deployVerifiableProxy.js'
import { grantResolverRoles } from './grantResolverRoles.js'

// Admin roles needed to grant the corresponding non-admin roles to other accounts
const ADMIN_ROLES =
  RESOLVER_ROLE_SET_TEXT_ADMIN |
  RESOLVER_ROLE_SET_ADDRESS_ADMIN |
  RESOLVER_ROLE_LINK_ADMIN

let resolverProxyAddress: Address
let accounts: Address[]

beforeAll(async () => {
  accounts = await walletClient.getAddresses()

  const proxyDeployTx = await deployVerifiableProxy(walletClient, {
    factoryAddress: deploymentAddresses.VerifiableFactory,
    implAddress: deploymentAddresses.PermissionedResolverImpl,
    callData: encodeFunctionData({
      abi: permissionedResolverInitializeSnippet,
      functionName: 'initialize',
      args: [[{ account: accounts[0], roleBitmap: ADMIN_ROLES }], []],
    }),
    account: accounts[0],
  })
  const proxyReceipt = await waitForTransaction(proxyDeployTx)
  resolverProxyAddress = getDeployedProxyAddress(proxyReceipt)
})

describe('grantResolverRoles', () => {
  describe('scope: root', () => {
    it('grants root-level roles', async () => {
      const tx = await grantResolverRoles(walletClient, {
        resolverAddress: resolverProxyAddress,
        targetAccount: accounts[1],
        scope: 'root',
        roles: ['ROLE_LINK'],
        account: accounts[0],
      })
      const receipt = await waitForTransaction(tx)
      expect(receipt.status).toBe('success')

      const result = await hasRoles(publicClient, {
        resolverAddress: resolverProxyAddress,
        roles: ['ROLE_LINK'],
        account: accounts[1],
      })
      expect(result).toBe(true)
    })
  })

  describe('scope: setter', () => {
    it('grants ROLE_SET_TEXT for one text key', async () => {
      const setter = { kind: 'text', key: 'avatar' } as const
      const tx = await grantResolverRoles(walletClient, {
        resolverAddress: resolverProxyAddress,
        targetAccount: accounts[1],
        scope: 'setter',
        setter,
        account: accounts[0],
      })
      const receipt = await waitForTransaction(tx)
      expect(receipt.status).toBe('success')

      expect(
        await hasRoles(publicClient, {
          resolverAddress: resolverProxyAddress,
          resource: computeResolverResource(setter),
          roles: ['ROLE_SET_TEXT'],
          account: accounts[1],
        }),
      ).toBe(true)
      // Not granted for other keys, and not at root.
      expect(
        await hasRoles(publicClient, {
          resolverAddress: resolverProxyAddress,
          resource: computeResolverResource({ kind: 'text', key: 'other' }),
          roles: ['ROLE_SET_TEXT'],
          account: accounts[1],
        }),
      ).toBe(false)
      expect(
        await hasRoles(publicClient, {
          resolverAddress: resolverProxyAddress,
          roles: ['ROLE_SET_TEXT'],
          account: accounts[1],
        }),
      ).toBe(false)
    })

    it('grants ROLE_SET_ADDRESS for one coin type', async () => {
      const setter = { kind: 'address', coinType: 60n } as const
      const tx = await grantResolverRoles(walletClient, {
        resolverAddress: resolverProxyAddress,
        targetAccount: accounts[1],
        scope: 'setter',
        setter,
        account: accounts[0],
      })
      const receipt = await waitForTransaction(tx)
      expect(receipt.status).toBe('success')

      expect(
        await hasRoles(publicClient, {
          resolverAddress: resolverProxyAddress,
          resource: computeResolverResource(setter),
          roles: ['ROLE_SET_ADDRESS'],
          account: accounts[1],
        }),
      ).toBe(true)
    })
  })
})
