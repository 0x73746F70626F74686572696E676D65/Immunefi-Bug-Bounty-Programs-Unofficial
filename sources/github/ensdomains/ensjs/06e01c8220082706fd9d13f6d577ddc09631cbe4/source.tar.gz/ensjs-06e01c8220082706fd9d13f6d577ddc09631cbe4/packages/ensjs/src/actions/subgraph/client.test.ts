import { namehash } from 'viem/ens'
import { afterEach, describe, expect, it, vi } from 'vitest'
import { SubgraphRequestError } from '../../errors/subgraph.js'
import {
  createSubgraphClient,
  hashInvalidNames,
  injectIdSelections,
} from './client.js'

const queryWithoutId = `
query getNames($id: ID!, $expiryDate: Int) {
    account(id: $id) {
      registrations(first: 1000, where: { expiryDate_gt: $expiryDate }) {
        registrationDate
        expiryDate
        domain {
          labelName
          labelhash
          name
          isMigrated
          parent {
            name
          }
        }
      }
      domains(first: 1000) {
        labelName
        labelhash
        name
        isMigrated
        parent {
          name
        }
        createdAt
      }
    }
  }
`

const mockResponse = {
  data: {
    account: {
      registrations: [
        {
          registrationDate: '1659245504',
          expiryDate: '1690781504',
          domain: {
            id: '0xb1ccf7f6bb648f39ba48bf80f4a8a4522f474ee7d1edd6ea65f7fa51fe8b1612',
            labelName: 'randydandy',
            labelhash:
              '0x63fd5bfdd0b1eb9f4c33c209b7c3e7dcb87a761d926a65e267f7cb99ee313ddd',
            name: '0xde2551f43e950a2a4d4e6052f25edc450c48a5338faa27f09d1ee99ca9dc04fd',
            isMigrated: true,
            parent: {
              name: '0x93cdeb708b7545dc668eb9280176169d1c33cfd8ed6f04690a0bcc88a93fc4ae',
              invalidName: true,
            },
            invalidName: true,
          },
        },
        {
          registrationDate: '1635284756',
          expiryDate: '1666841708',
          domain: {
            id: '0xde2551f43e950a2a4d4e6052f25edc450c48a5338faa27f09d1ee99ca9dc04fd',
            labelName: 'randydandy',
            labelhash:
              '0x6a877a8d92ad83c8d044d0c5b69aa0da3050f4d653dcc149fca952d6439e4105',
            name: 'randydandy.eth',
            isMigrated: true,
            parent: {
              name: '0x93cdeb708b7545dc668eb9280176169d1c33cfd8ed6f04690a0bcc88a93fc4ae',
              invalidName: true,
            },
          },
        },
        {
          registrationDate: '1659250465',
          expiryDate: '1690786465',
          domain: {
            id: '0xaf119e72f050e5acad6b2d97826a7afb45afe9407376a2ab8240b62173b2d7c2',
            labelName: 'nullbyte',
            labelhash:
              '0xc8985f8323b3dc707003a6ef5b379d9e8a058b6d6bcc2cfb307c61ca36920e27',
            name: '0xb54c7c79c89d571f1fbf4c67f524e336a04441eeee4d76f156e835da99a46ddb',
            isMigrated: true,
            parent: {
              name: '0x93cdeb708b7545dc668eb9280176169d1c33cfd8ed6f04690a0bcc88a93fc4ae',
              invalidName: true,
            },
            invalidName: true,
          },
        },
      ],
      domains: [
        {
          id: '0xaf119e72f050e5acad6b2d97826a7afb45afe9407376a2ab8240b62173b2d7c2',
          labelName: 'nullbyte',
          labelhash:
            '0xc8985f8323b3dc707003a6ef5b379d9e8a058b6d6bcc2cfb307c61ca36920e27',
          name: '0xb54c7c79c89d571f1fbf4c67f524e336a04441eeee4d76f156e835da99a46ddb',
          isMigrated: true,
          parent: {
            name: '0x93cdeb708b7545dc668eb9280176169d1c33cfd8ed6f04690a0bcc88a93fc4ae',
            invalidName: true,
          },
          createdAt: '1659250465',
          invalidName: true,
        },
        {
          id: '0xb1ccf7f6bb648f39ba48bf80f4a8a4522f474ee7d1edd6ea65f7fa51fe8b1612',
          labelName: 'randydandy',
          labelhash:
            '0x63fd5bfdd0b1eb9f4c33c209b7c3e7dcb87a761d926a65e267f7cb99ee313ddd',
          name: '0xde2551f43e950a2a4d4e6052f25edc450c48a5338faa27f09d1ee99ca9dc04fd',
          isMigrated: true,
          parent: {
            name: '0x93cdeb708b7545dc668eb9280176169d1c33cfd8ed6f04690a0bcc88a93fc4ae',
            invalidName: true,
          },
          createdAt: '1659245504',
          invalidName: true,
        },
        {
          id: '0xde2551f43e950a2a4d4e6052f25edc450c48a5338faa27f09d1ee99ca9dc04fd',
          labelName: 'randydandy',
          labelhash:
            '0x6a877a8d92ad83c8d044d0c5b69aa0da3050f4d653dcc149fca952d6439e4105',
          name: 'randydandy.eth',
          isMigrated: true,
          parent: {
            name: '0x93cdeb708b7545dc668eb9280176169d1c33cfd8ed6f04690a0bcc88a93fc4ae',
            invalidName: true,
          },
          createdAt: '1635284756',
        },
      ],
    },
  },
  headers: {
    map: {
      'Content-Type': 'application/json',
    },
  },
  status: 200,
}

describe('injectIdSelections', () => {
  it('should add id to a SelectionSet if name is present and id is not', () => {
    const result = injectIdSelections(queryWithoutId).replace(/\s+/g, ' ')
    expect(result).toContain('parent { name id }')
  })

  it('should not add id to a SelectionSet that already selects it', () => {
    const query = 'query { domain { id name } }'
    const result = injectIdSelections(query).replace(/\s+/g, ' ')
    expect(result).toContain('domain { id name }')
  })

  it('should leave a SelectionSet without name alone', () => {
    const query = 'query { domain { labelhash createdAt } }'
    const result = injectIdSelections(query).replace(/\s+/g, ' ')
    expect(result).toContain('domain { labelhash createdAt }')
  })
})

describe('hashInvalidNames', () => {
  it('should replace name with the namehash when there is an invalid name and id combo', () => {
    const response = { ...mockResponse }
    hashInvalidNames(response.data)
    expect(response.data.account.domains[0].name).toBe(
      namehash(
        '0xb54c7c79c89d571f1fbf4c67f524e336a04441eeee4d76f156e835da99a46ddb',
      ),
    )
  })
})

describe('createSubgraphClient', () => {
  const client = createSubgraphClient({
    chain: { subgraphs: { ens: { url: 'http://localhost:8000/subgraph' } } },
  })

  const stubFetch = (body: string, status = 200) => {
    const fetchMock = vi.fn(
      async () =>
        new Response(body, {
          status,
          headers: { 'Content-Type': 'application/json' },
        }),
    )
    vi.stubGlobal('fetch', fetchMock)
    return fetchMock
  }

  afterEach(() => {
    vi.unstubAllGlobals()
  })

  it('should post the query and variables, with ids injected', async () => {
    const fetchMock = stubFetch(JSON.stringify({ data: { domain: null } }))

    await client.request(
      'query getDomain($id: String!) { domain(id: $id) { name } }',
      {
        id: '0x123',
      },
    )

    expect(fetchMock).toHaveBeenCalledTimes(1)
    const [url, init] = fetchMock.mock.calls[0] as unknown as [
      string,
      RequestInit,
    ]
    expect(url).toBe('http://localhost:8000/subgraph')
    expect(init.method).toBe('POST')
    expect(new Headers(init.headers).get('Content-Type')).toBe(
      'application/json',
    )

    const body = JSON.parse(init.body as string)
    expect(body.variables).toEqual({ id: '0x123' })
    expect(body.query.replace(/\s+/g, ' ')).toContain(
      'domain(id: $id) { name id }',
    )
  })

  it('should return the data payload, with invalid names hashed', async () => {
    stubFetch(
      JSON.stringify({
        data: {
          domain: {
            id: '0x0000000000000000000000000000000000000000000000000000000000000001',
            name: 'test.eth',
          },
        },
      }),
    )

    const result = await client.request<{
      domain: { name: string; invalidName?: boolean }
    }>('query { domain { id name } }')

    expect(result.domain.name).toBe(namehash('test.eth'))
    expect(result.domain.invalidName).toBe(true)
  })

  it('should throw when the response carries GraphQL errors', async () => {
    stubFetch(
      JSON.stringify({
        errors: [{ message: 'Field "nope" not found', path: ['domain'] }],
      }),
    )

    await expect(client.request('query { domain { nope } }')).rejects.toThrow(
      SubgraphRequestError,
    )
  })

  it('should throw when the response status is not ok', async () => {
    stubFetch(JSON.stringify({ data: null }), 502)

    await expect(client.request('query { domain { name } }')).rejects.toThrow(
      /status 502/,
    )
  })

  it('should throw when the response is not JSON', async () => {
    stubFetch('<html>bad gateway</html>', 200)

    await expect(client.request('query { domain { name } }')).rejects.toThrow(
      /not valid JSON/,
    )
  })
})
