import { artifacts, execute } from "@rocketh";

export default execute(
  async ({ deploy, get, getV1, namedAccounts: { deployer } }) => {
    const rootRegistry =
      get<(typeof artifacts.PermissionedRegistry)["abi"]>("RootRegistry");

    const batchGatewayProvider = await getV1<
      (typeof artifacts.GatewayProvider)["abi"]
    >(
      "BatchGatewayProvider",
    );

    const contractNamer =
      get<(typeof artifacts.IContractNamer)["abi"]>("ContractNamer");

    const dnsAliasResolver = await deploy("DNSAliasResolver", {
      account: deployer,
      artifact: artifacts.DNSAliasResolver,
      args: [
        rootRegistry.address,
        batchGatewayProvider.address,
        contractNamer.address,
      ],
    });
  },
  {
    tags: ["DNSAliasResolver", "v2"],
    dependencies: ["RootRegistry", "BatchGatewayProvider", "ContractNamer"],
  },
);
