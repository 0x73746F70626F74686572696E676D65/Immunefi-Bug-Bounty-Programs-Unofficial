// SPDX-License-Identifier: MIT
pragma solidity >=0.8.13;

import {
    PARENT_CANNOT_CONTROL,
    CANNOT_SET_RESOLVER,
    CANNOT_UNWRAP,
    CANNOT_BURN_FUSES,
    CANNOT_APPROVE,
    LabelTooShort,
    LabelTooLong
} from "@ens/contracts/wrapper/NameWrapper.sol";

import {V1Fixture, NameCoder} from "./V1Fixture.sol";

// TODO: add more NameWrapper quirks and invariant tests.
contract V1FixtureTest is V1Fixture {
    address friend = makeAddr("friend");

    function setUp() external {
        deployV1Fixture();
    }

    ////////////////////////////////////////////////////////////////////////
    // Deployment Helpers
    ////////////////////////////////////////////////////////////////////////

    function test_registerUnwrapped() external {
        (, uint256 tokenId) = registerUnwrapped("test");
        assertEq(baseRegistrar.ownerOf(tokenId), testOwner, "owner");
    }

    function test_registerUnwrapped_pranked() external {
        vm.prank(friend);
        (, uint256 tokenId) = this.registerUnwrapped("test");
        assertEq(baseRegistrar.ownerOf(tokenId), friend, "owner");
    }

    function test_registerWrappedETH2LD() external {
        bytes memory name = registerWrappedETH2LD("test", 0);
        assertEq(nameWrapper.ownerOf(uint256(NameCoder.namehash(name, 0))), testOwner, "owner");
    }

    function test_registerWrappedETH2LD_pranked() external {
        vm.prank(friend);
        bytes memory name = this.registerWrappedETH2LD("test", 0);
        assertEq(nameWrapper.ownerOf(uint256(NameCoder.namehash(name, 0))), friend, "owner");
    }

    function test_registerWrappedETH3LD() external {
        bytes memory parentName = registerWrappedETH2LD("test", 0);
        bytes memory name = createWrappedChild(parentName, "sub", 0);
        assertEq(nameWrapper.ownerOf(uint256(NameCoder.namehash(name, 0))), testOwner, "owner");
    }

    function test_registerWrappedETH3LD_pranked() external {
        bytes memory parentName = registerWrappedETH2LD("test", 0);
        vm.prank(friend);
        bytes memory name = this.createWrappedChild(parentName, "sub", 0);
        assertEq(nameWrapper.ownerOf(uint256(NameCoder.namehash(name, 0))), friend, "owner");
    }

    function test_registerWrappedDNS2LD() external {
        bytes memory name = createWrappedName("ens.domains", 0);
        assertEq(nameWrapper.ownerOf(uint256(NameCoder.namehash(name, 0))), testOwner, "owner");
    }

    function test_registerWrappedDNS3LD() external {
        bytes memory parentName = createWrappedName("ens.domains", 0);
        bytes memory name = createWrappedChild(parentName, "sub", 0);
        assertEq(nameWrapper.ownerOf(uint256(NameCoder.namehash(name, 0))), testOwner, "owner");
    }

    function test_findResolverV1_unwrapped() external {
        (bytes memory name, ) = registerUnwrapped("test");
        assertEq(findResolverV1(name), address(0), "before");
        vm.prank(testOwner);
        registryV1.setResolver(NameCoder.namehash(name, 0), address(1));
        assertEq(findResolverV1(name), address(1), "after");
    }

    function test_findResolverV1_wrapped() external {
        bytes memory name = createWrappedName("a.b.c", 0);
        assertEq(findResolverV1(name), address(0), "before");
        vm.prank(testOwner);
        nameWrapper.setResolver(NameCoder.namehash(name, 0), address(1));
        assertEq(findResolverV1(name), address(1), "after");
    }

    function test_getStatusV1_lifecycle() external {
        (, uint256 tokenId) = registerUnwrapped("test");
        assertEq(uint256(getStatusV1(tokenId)), uint8(StatusV1.REGISTERED), "REGISTERED");
        vm.warp(baseRegistrar.nameExpires(tokenId));
        assertEq(uint256(getStatusV1(tokenId)), uint8(StatusV1.GRACE), "GRACE:start");
        vm.warp(baseRegistrar.nameExpires(tokenId) + gracePeriodV1 - 1);
        assertEq(uint256(getStatusV1(tokenId)), uint8(StatusV1.GRACE), "GRACE:end");
        vm.warp(baseRegistrar.nameExpires(tokenId) + gracePeriodV1);
        assertEq(uint256(getStatusV1(tokenId)), uint8(StatusV1.AVAILABLE), "AVAILABLE");
    }

    ////////////////////////////////////////////////////////////////////////
    // NameWrapper Quirks
    ////////////////////////////////////////////////////////////////////////

    function test_nameWrapper_wrapRootReverts() external {
        vm.expectRevert("readLabel: Index out of bounds");
        nameWrapper.wrap(hex"00", address(1), address(0));
    }

    function test_nameWrapper_labelTooShort() external {
        bytes memory name = registerWrappedETH2LD("test", 0);
        vm.expectRevert(abi.encodeWithSelector(LabelTooShort.selector));
        vm.prank(testOwner);
        nameWrapper.setSubnodeOwner(
            NameCoder.namehash(name, 0),
            "",
            testOwner,
            0,
            uint64(block.timestamp + 1 days)
        );
    }

    function test_nameWraper_labelTooLong() external {
        bytes memory name = registerWrappedETH2LD("test", 0);
        string memory label = new string(256);
        vm.expectRevert(abi.encodeWithSelector(LabelTooLong.selector, label));
        vm.prank(testOwner);
        nameWrapper.setSubnodeOwner(
            NameCoder.namehash(name, 0),
            label,
            testOwner,
            0,
            uint64(block.timestamp + 1 days)
        );
    }

    function test_nameWrapper_expiryForETH2LDIncludesGrace() external {
        bytes memory name = registerWrappedETH2LD("test", 0);
        uint256 unwrappedExpiry =
            baseRegistrar.nameExpires(uint256(keccak256(bytes(NameCoder.firstLabel(name)))));
        (, , uint256 wrappedExpiry) = nameWrapper.getData(uint256(NameCoder.namehash(name, 0)));
        assertEq(unwrappedExpiry + baseRegistrar.GRACE_PERIOD(), wrappedExpiry);
    }

    function test_nameWrapper_gracePeriod() external {
        bytes memory name = registerWrappedETH2LD("test", CANNOT_UNWRAP);
        uint256 tokenId = uint256(keccak256(bytes(NameCoder.firstLabel(name))));
        uint256 unwrappedExpiry = baseRegistrar.nameExpires(tokenId);
        bytes32 node = NameCoder.namehash(name, 0);
        uint64[3] memory ts = [0, gracePeriodV1 >> 1, gracePeriodV1 - 1]; // start, middle, before-end
        for (uint256 i; i < ts.length; ++i) {
            vm.warp(unwrappedExpiry + ts[i]);
            (address owner, uint32 fuses, ) = nameWrapper.getData(uint256(node));
            assertFalse(baseRegistrar.available(tokenId), "grace:available");
            assertEq(owner, testOwner, "grace:owner");
            assertTrue((fuses & CANNOT_UNWRAP) != 0, "grace:fuses");
        }
        {
            vm.warp(unwrappedExpiry + gracePeriodV1); // after-end
            (address owner, uint32 fuses, ) = nameWrapper.getData(uint256(node));
            assertTrue(baseRegistrar.available(tokenId), "after:available");
            assertEq(owner, address(0), "after:owner");
            assertEq(fuses, 0, "after:fuses");
        }
    }

    function test_nameWrapper_CANNOT_UNWRAP_requires_PARENT_CANNOT_CONTROL() external {
        bytes memory name = registerWrappedETH2LD("test", CANNOT_UNWRAP);
        createWrappedChild(name, "1", PARENT_CANNOT_CONTROL);
        createWrappedChild(name, "2", PARENT_CANNOT_CONTROL | CANNOT_UNWRAP);
        vm.expectRevert();
        this.createWrappedChild(name, "3", CANNOT_UNWRAP);
    }

    function test_nameWrapper_PARENT_CANNOT_CONTROL_via_setFuses() external {
        bytes memory name = registerWrappedETH2LD("test", 0);
        (bytes32 labelhash, ) = NameCoder.readLabel(name, 0);
        vm.prank(testOwner);
        nameWrapper.setFuses(NameCoder.namehash(name, 0), uint16(PARENT_CANNOT_CONTROL));
        vm.prank(testOwner);
        nameWrapper.unwrapETH2LD(labelhash, testOwner, testOwner);
    }

    function test_nameWrapper_PARENT_CANNOT_CONTROL_via_wrap() external {
        bytes memory parentName = registerWrappedETH2LD("test", CANNOT_UNWRAP);
        bytes memory name = createWrappedChild(parentName, "sub", PARENT_CANNOT_CONTROL);
        (bytes32 labelhash, ) = NameCoder.readLabel(name, 0);
        vm.prank(testOwner);
        nameWrapper.unwrap(NameCoder.namehash(parentName, 0), labelhash, testOwner);
    }

    function test_nameWrapper_PARENT_CANNOT_CONTROL_withoutParent() external {
        bytes memory parentName = registerWrappedETH2LD("test", 0);
        vm.expectRevert();
        this.createWrappedChild(parentName, "sub", PARENT_CANNOT_CONTROL);
    }

    function test_nameWrapper_CANNOT_BURN_FUSES_via_wrap() external {
        registerWrappedETH2LD("test", CANNOT_UNWRAP | CANNOT_BURN_FUSES);
    }

    function test_nameWrapper_CANNOT_BURN_FUSES_via_setFuses() external {
        bytes memory name = registerWrappedETH2LD("test", CANNOT_UNWRAP);
        vm.prank(testOwner);
        nameWrapper.setFuses(NameCoder.namehash(name, 0), uint16(CANNOT_BURN_FUSES));
    }

    function test_nameWrapper_CANNOT_BURN_FUSES_via_setChildFuses() external {
        bytes memory parentName = registerWrappedETH2LD("test", CANNOT_UNWRAP);
        bytes memory name =
            createWrappedChild(parentName, "sub", CANNOT_UNWRAP | PARENT_CANNOT_CONTROL);
        // setChildFuses() does not allow fuse changes if PCC
        // _setFuses() requires CU + PCC if child fuses as burned
        vm.expectRevert();
        vm.prank(testOwner);
        nameWrapper.setChildFuses(
            NameCoder.namehash(parentName, 0),
            keccak256(bytes(NameCoder.firstLabel(name))),
            CANNOT_BURN_FUSES,
            uint64(block.timestamp + 1 days)
        );
    }

    function test_nameWrapper_CANNOT_SET_RESOLVER_requires_CANNOT_UNWRAP() external {
        vm.expectRevert();
        this.registerWrappedETH2LD("test", CANNOT_SET_RESOLVER);
        this.registerWrappedETH2LD("test", CANNOT_SET_RESOLVER | CANNOT_UNWRAP);
    }

    function test_nameWrapper_CANNOT_APPROVE_requires_CANNOT_UNWRAP() external {
        vm.expectRevert();
        this.registerWrappedETH2LD("test", CANNOT_APPROVE);
        this.registerWrappedETH2LD("test", CANNOT_APPROVE | CANNOT_UNWRAP);
    }

    function test_nameWrapper_approveBug() external {
        bytes memory name = registerWrappedETH2LD("test", 0);
        bytes32 node = NameCoder.namehash(name, 0);
        vm.prank(testOwner);
        nameWrapper.approve(friend, uint256(node));
        // https://github.com/ensdomains/ens-contracts/blob/staging/contracts/wrapper/ERC1155Fuse.sol#L146-L149
        vm.prank(friend);
        vm.expectRevert("ERC1155: caller is not owner nor approved");
        nameWrapper.safeTransferFrom(testOwner, friend, uint256(node), 1, "");
    }

    ////////////////////////////////////////////////////////////////////////
    // BaseRegistrar Quirks
    ////////////////////////////////////////////////////////////////////////

    function test_baseRegistrar_gracePeriod() external {
        (, uint256 tokenId) = registerUnwrapped("test");
        uint256 expiry = baseRegistrar.nameExpires(tokenId);
        uint64[3] memory ts = [0, gracePeriodV1 >> 1, gracePeriodV1 - 1];
        for (uint256 i; i < ts.length; ++i) {
            vm.warp(expiry + ts[i]);
            assertFalse(baseRegistrar.available(tokenId), "grace:available");
            vm.expectRevert();
            baseRegistrar.ownerOf(tokenId);
        }
        {
            vm.warp(expiry + gracePeriodV1); // after-end
            assertTrue(baseRegistrar.available(tokenId), "after:available");
            vm.expectRevert();
            baseRegistrar.ownerOf(tokenId);
        }
    }

    function test_baseRegistrar_ownerOf_unregisteredReverts() external {
        vm.expectRevert();
        baseRegistrar.ownerOf(0);
    }
}
