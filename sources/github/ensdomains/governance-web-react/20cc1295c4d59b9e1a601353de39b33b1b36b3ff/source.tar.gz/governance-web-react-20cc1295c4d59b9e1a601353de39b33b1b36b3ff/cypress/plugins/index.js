const fetch = (...args) =>
  import("node-fetch").then(({ default: fetch }) => fetch(...args));

/// <reference types="cypress" />

// ***********************************************************
// This example plugins/index.js can be used to load plugins
//
// You can change the location of this file or turn off loading
// the plugins file with the 'pluginsFile' configuration option.
//
// You can read more here:
// https://on.cypress.io/plugins-guide
// ***********************************************************

// This function is called when a project is opened or re-opened (e.g. due to
// the project's config changing)

/**
 * @type {Cypress.PluginConfig}
 */
// eslint-disable-next-line no-unused-vars
module.exports = (on, config) => {
  // `on` is used to hook into various events Cypress emits
  // `config` is the resolved Cypress config
  require("@ensdomains/cypress-metamask/plugins")(on);
  require("./delegateBySig")(on, config);
  require("./generateContracts.js")(on);

  on("task", {
    submitRpcUrl(rpcUrl) {
      console.log("using fork:", rpcUrl);
      process.env.RPC_URL = rpcUrl;

      return true;
    },
    setMetamaskData({ secretWords, network, password }) {
      process.env.SECRET_WORDS = secretWords;
      process.env.NETWORK = network;
      process.env.PASSWORD = password;

      return true;
    },
  });
};
