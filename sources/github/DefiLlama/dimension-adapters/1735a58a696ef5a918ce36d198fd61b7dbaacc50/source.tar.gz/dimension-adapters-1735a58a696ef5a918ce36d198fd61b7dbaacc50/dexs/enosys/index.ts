import { FetchOptions, FetchV2, SimpleAdapter } from "../../adapters/types";
import { CHAIN } from "../../helpers/chains";
import fetchURL from "../../utils/fetchURL";

const URL_FLARE = "http://flare.index.enosys.global/v1/public/24hourV3Volume";

const fetchVolume: FetchV2 = async () => {
  const dailyVolume = await fetchURL(URL_FLARE);

  return { dailyVolume };
};

const adapter: SimpleAdapter = {
  version: 2,
  adapter: {
    [CHAIN.FLARE]: {
      runAtCurrTime: true,
      fetch: fetchVolume,
      start: '2025-03-03',
    },
  },
};

export default adapter;
