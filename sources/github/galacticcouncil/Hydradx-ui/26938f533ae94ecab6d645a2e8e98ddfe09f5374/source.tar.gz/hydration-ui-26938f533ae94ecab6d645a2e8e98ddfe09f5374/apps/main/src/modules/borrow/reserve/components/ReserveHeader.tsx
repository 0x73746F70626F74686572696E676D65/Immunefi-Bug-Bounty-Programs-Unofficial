import { ComputedReserveData } from "@galacticcouncil/money-market/hooks"
import { Stack, ValueStats } from "@galacticcouncil/ui/components"
import { useTranslation } from "react-i18next"

export type ReserveHeaderProps = {
  reserve: ComputedReserveData
}

export const ReserveHeader: React.FC<ReserveHeaderProps> = ({ reserve }) => {
  const { t } = useTranslation(["common", "borrow"])

  const utilRate = Number(reserve.borrowUsageRatio ?? 0) * 100

  return (
    <Stack
      direction={["column", null, "row"]}
      justify="flex-start"
      gap={["base", null, "xxxl", "3.75rem"]}
      separated
    >
      <ValueStats
        label={t("borrow:reserve.reserveSize")}
        value={t("currency.compact", {
          value: Math.max(Number(reserve.totalLiquidityUSD), 0),
        })}
        size="large"
        wrap={[false, false, true]}
      />
      <ValueStats
        label={t("borrow:reserve.availableLiq")}
        value={t("currency.compact", {
          value: Math.max(Number(reserve.availableLiquidityUSD), 0),
        })}
        size="large"
        wrap={[false, false, true]}
      />
      {utilRate > 0 && (
        <ValueStats
          label={t("borrow:reserve.utilRate")}
          value={t("percent", {
            value: utilRate,
          })}
          size="large"
          wrap={[false, false, true]}
        />
      )}
      <ValueStats
        label={t("borrow:reserve.oraclePrice")}
        value={t("currency", {
          value: Number(reserve.priceInUSD ?? 0),
        })}
        size="large"
        wrap={[false, false, true]}
      />
    </Stack>
  )
}
