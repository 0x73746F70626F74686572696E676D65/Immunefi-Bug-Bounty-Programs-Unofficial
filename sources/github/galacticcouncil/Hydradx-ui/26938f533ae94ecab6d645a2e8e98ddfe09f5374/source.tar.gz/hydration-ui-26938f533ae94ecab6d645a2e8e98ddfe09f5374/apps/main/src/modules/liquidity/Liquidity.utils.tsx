import {
  omnipoolVolumeQuery as neckworkOmnipoolVolumeQuery,
  omnipoolYieldMetricsQuery as neckworkOmnipoolYieldMetricsQuery,
  stablepoolVolumeQuery as neckworkStablepoolVolumeQuery,
  stablepoolYieldMetricsQuery as neckworkStablepoolYieldMetricsQuery,
  xykVolumeQuery as neckworkXykVolumeQuery,
} from "@galacticcouncil/indexer/neckwork"
import {
  is_add_liquidity_allowed,
  is_buy_allowed,
  is_remove_liquidity_allowed,
  is_sell_allowed,
} from "@galacticcouncil/math-omnipool"
import { pool } from "@galacticcouncil/sdk-next"
import {
  GIGA_ASSETS,
  HOLLAR_ASSET_ID,
  HOLLAR_ASSETS,
  PRIME_STABLESWAP_ASSET_ID,
} from "@galacticcouncil/utils"
import { useQuery } from "@tanstack/react-query"
import { useNavigate, useRouter } from "@tanstack/react-router"
import Big from "big.js"
import { useEffect, useMemo } from "react"
import { isNumber, prop } from "remeda"
import { useShallow } from "zustand/shallow"

import { XykDeposit } from "@/api/account"
import { AssetType, TAssetData, TErc20, TErc20AToken } from "@/api/assets"
import { useAccountBalances } from "@/api/balances"
import { BorrowAssetApyData, useBorrowAssetsApy } from "@/api/borrow/hooks"
import { Farm, useIsolatedPoolsFarms, useOmnipoolFarms } from "@/api/farms"
import { neckworkClient } from "@/api/neckwork"
import { useOmnipoolAssetsData } from "@/api/omnipool"
import {
  OmniPoolToken,
  PoolBase,
  PoolFee,
  PoolToken,
  StableSwapBase,
  useOmnipoolIds,
  useStablePools,
  useXykPools,
} from "@/api/pools"
import { useStableSwapTradability } from "@/api/stableswap"
import { XYKPoolWithLiquidity } from "@/api/xyk"
import { TShareToken, useAssets } from "@/providers/assetsProvider"
import {
  AccountOmnipoolPosition,
  useAccountOmnipoolPositionsData,
  useAccountPositions,
} from "@/states/account"
import { useAssetsPrice } from "@/states/displayAsset"
import { setOmnipoolAssets, setXYKPools } from "@/states/liquidity"
import { useTradeSettings } from "@/states/tradeSettings"
import { isBlacklistedAsset } from "@/utils/assets"
import { scaleHuman } from "@/utils/formatting"

export type OmnipoolAssetTable = {
  id: string
  meta: TAssetData
  price: string | undefined
  tvlDisplay: string | undefined
  lpFeeOmnipool?: string
  lpFeeStablepool?: string
  totalFee?: string | null
  isFeeLoading: boolean
  isNative: boolean
  isPositions: boolean
  positionsAmount: number
  isStablePool: boolean
  stableswapBalance: bigint | undefined
  stableswapBalanceDisplay: string | undefined
  volumeDisplay: string | undefined
  positions: AccountOmnipoolPosition[]
  isVolumeLoading: boolean
  isFarms: boolean
  isStablepoolOnly: boolean
  isStablepoolInOmnipool: boolean
  aStableswapBalance: bigint | undefined
  aStableswapAsset: TErc20 | undefined
  farms: Farm[]
  allFarms: Farm[]
  stablepoolData: TStablepoolData | undefined
  borrowApyData: BorrowAssetApyData | undefined
  canAddLiquidity: boolean
  canRemoveLiquidity: boolean
}

export type IsolatedPoolTable = {
  id: string
  tokens: [PoolToken, PoolToken]
  tvlDisplay: string
  meta: TShareToken
  isPositions: boolean
  volumeDisplay: string | undefined
  isFeeLoading: boolean
  balance: bigint | undefined
  positionsAmount: number
  price: string | undefined
  shareTokenId: string
  positions: XykDeposit[]
  minTradingLimit: bigint
  isVolumeLoading: boolean
  isFarms: boolean
  totalApr: string
  farms: Farm[]
  allFarms: Farm[]
  canAddLiquidity: boolean
  canRemoveLiquidity: boolean
  isNative: boolean
}

export type TReserve = {
  asset_id: number
  meta: TAssetData
  amount: string
  amountHuman: string
  displayAmount: string
}

export type TStablepoolData = {
  id: number
  pool: StableSwapBase
  reserves: TReserve[]
  totalDisplayAmount: string
  volume: string | undefined
  balance: string
  isStablepool: boolean
  lpFee: string | undefined
  aToken: TErc20AToken | undefined
  borrowApyData: BorrowAssetApyData | undefined
}

export type TStablepoolDetails = {
  pool: StableSwapBase
  reserves: TReserve[]
  totalDisplayAmount: string
}

const OVERRIDE_META = [...GIGA_ASSETS, ...HOLLAR_ASSETS]

const isStablepoolData = (
  pool: TStablepoolData | OmniPoolToken,
): pool is TStablepoolData => !!(pool as TStablepoolData).isStablepool

export const useStablepools = () => {
  const { data: pools, isLoading: isPoolsLoading } = useStablepoolsReserves()

  const { data: volumes, isLoading: isVolumeLoading } = useQuery(
    neckworkStablepoolVolumeQuery(neckworkClient),
  )

  const { data: yieldMetrics, isLoading: isYieldMetricsLoading } = useQuery(
    neckworkStablepoolYieldMetricsQuery(neckworkClient),
  )

  const { getRelatedAToken, isErc20AToken } = useAssets()

  const volumeByAsset = useMemo(
    () =>
      new Map<string, string>(
        (volumes ?? []).map((v) => [v.poolId, v.poolVolNorm]),
      ),
    [volumes],
  )

  // The stablepool table consumes the APY. Neckwork returns null when a pool
  // had no in-window sample; that stays unknown rather than becoming a rate.
  const feeByAsset = useMemo(
    () =>
      new Map<string, string | undefined>(
        (yieldMetrics ?? []).map((m) => [m.poolId, m.feeApyPerc ?? undefined]),
      ),
    [yieldMetrics],
  )

  const { stablePoolData, aTokens } = useMemo(() => {
    const aTokens = new Map<string, TErc20AToken>()

    if (!pools) {
      return { stablePoolData: [], aTokens }
    }

    const list = pools.map((stablePool) => {
      const { id, tokens } = stablePool.pool
      const poolId = id.toString()
      const aToken = getRelatedAToken(poolId)

      if (aToken && isErc20AToken(aToken)) {
        aTokens.set(poolId, aToken)
      }

      return {
        poolId: id,
        tokens: tokens.filter((token) => token.type !== AssetType.STABLESWAP),
      }
    })

    return { stablePoolData: list, aTokens }
  }, [pools, getRelatedAToken, isErc20AToken])

  const { data: borrowAssetsApy } = useBorrowAssetsApy(
    stablePoolData
      ?.filter(
        (stablepool) =>
          !!getRelatedAToken(stablepool.poolId) ||
          stablepool.poolId === Number(PRIME_STABLESWAP_ASSET_ID),
      )
      .map((pool) => pool.poolId.toString()),
  )

  const aTokensApyByPool = useMemo(() => {
    return new Map(borrowAssetsApy.map((aToken) => [aToken.assetId, aToken]))
  }, [borrowAssetsApy])

  const data = useMemo(
    () =>
      pools?.map((stablepool) => {
        const { id: poolId } = stablepool.pool

        const lpFee = feeByAsset.get(poolId.toString())
        const volume = volumeByAsset.get(poolId.toString())

        const aToken = aTokens.get(poolId.toString())
        const borrowApyData = aTokensApyByPool?.get(poolId.toString())

        const data: TStablepoolData = {
          id: poolId,
          balance: stablepool.totalDisplayAmount,
          isStablepool: true,
          lpFee,
          volume,
          aToken,
          borrowApyData,
          ...stablepool,
        }

        return data
      }),
    [volumeByAsset, feeByAsset, aTokens, aTokensApyByPool, pools],
  )

  return {
    data,
    isLoading: isPoolsLoading,
    isVolumeLoading,
    isYieldMetricsLoading,
  }
}

export const useOmnipoolStablepools = () => {
  const {
    getAssetWithFallback,
    native: { id: nativeId },
  } = useAssets()
  const { data: omnipoolIds = [] } = useOmnipoolIds()
  const { data: omnipoolAssets, isLoading: isOmnipoolAssetsLoading } =
    useOmnipoolAssetsData()

  const { data: omnipoolFarms, isLoading: isOmnipoolFarmsLoading } =
    useOmnipoolFarms()

  const { getTransferableBalance } = useAccountBalances()
  const { getAssetPositions } = useAccountOmnipoolPositionsData()
  const { data: stablepools, isLoading: isStablepoolsLoading } =
    useStablepools()

  const { data: volumes, isLoading: isVolumeLoading } = useQuery(
    neckworkOmnipoolVolumeQuery(neckworkClient),
  )

  const { data: yieldMetrics, isLoading: isYieldMetricsLoading } = useQuery(
    neckworkOmnipoolYieldMetricsQuery(neckworkClient),
  )

  const volumeByAsset = useMemo(
    () =>
      new Map<string, string>(
        (volumes ?? []).map((v) => [v.assetId, v.assetVolNorm]),
      ),
    [volumes],
  )

  // The omnipool table reads the APR. It is null when a pool had no sample in
  // the window.
  const feeByAsset = useMemo(
    () =>
      new Map<string, string | undefined>(
        (yieldMetrics ?? []).map((m) => [m.assetId, m.fee ?? undefined]),
      ),
    [yieldMetrics],
  )

  const stablepoolsIds = useMemo(
    () => stablepools?.map((a) => a.id.toString()) ?? [],
    [stablepools],
  )

  const { getAssetPrice, isLoading: isPriceLoading } = useAssetsPrice([
    ...omnipoolIds,
    ...stablepoolsIds,
  ])

  const isLoading =
    isPriceLoading || isOmnipoolAssetsLoading || isStablepoolsLoading

  const data = useMemo(() => {
    if (isLoading || !omnipoolAssets) return []

    const omnipoolIds = new Set(omnipoolAssets.map((a) => a.id.toString()))

    const onlyStablepool: TStablepoolData[] = []
    const stableInOmnipool: Map<string, TStablepoolData> = new Map()

    stablepools?.forEach((stablepoolData) => {
      const id = stablepoolData.id.toString()
      const aTokenId = stablepoolData.aToken?.id

      if (omnipoolIds.has(id)) {
        stableInOmnipool.set(id, stablepoolData)
      } else if (aTokenId && omnipoolIds.has(aTokenId)) {
        stableInOmnipool.set(aTokenId.toString(), stablepoolData)
      } else {
        onlyStablepool.push(stablepoolData)
      }
    })

    const omnipoolData: OmnipoolAssetTable[] = [
      ...omnipoolAssets,
      ...onlyStablepool,
    ].map((pool) => {
      const poolId = pool.id.toString()
      const meta = getAssetWithFallback(poolId)

      const isNative = nativeId === poolId
      const assetPrice = getAssetPrice(poolId)

      const isStablepoolOnly = isStablepoolData(pool)
      const stablepoolInOmnipool = stableInOmnipool.get(poolId)
      const isStablepoolInOmnipool = !!stablepoolInOmnipool
      const isStablePool = isStablepoolOnly || isStablepoolInOmnipool

      const aStableswapAsset = isStablepoolOnly
        ? pool.aToken
        : stablepoolInOmnipool?.aToken
      const aStableswapBalance = aStableswapAsset
        ? getTransferableBalance(aStableswapAsset.id.toString())
        : undefined
      const borrowApyData = isStablepoolOnly
        ? pool.borrowApyData
        : stablepoolInOmnipool?.borrowApyData

      const allFarms = omnipoolFarms?.[poolId] ?? []
      const farms = allFarms.filter((farm) => farm.apr !== "0")

      const isFarms = farms?.length > 0
      const totalApr = farms
        .reduce((acc, farm) => acc.plus(farm.apr), Big(0))
        .toString()

      let volume: string | undefined
      let lpFeeOmnipool: string | undefined
      let lpFeeStablepool: string | undefined
      let totalFee = borrowApyData?.totalSupplyApy?.toString()

      if (isStablepoolOnly) {
        volume = pool.volume
        lpFeeStablepool = pool.lpFee
        totalFee = lpFeeStablepool
      } else {
        const stablepoolVolume = stablepoolInOmnipool?.volume
        lpFeeStablepool = stablepoolInOmnipool?.lpFee

        const omnipoolVolume = volumeByAsset.get(poolId)

        volume = Big(stablepoolVolume ?? 0)
          .plus(omnipoolVolume ?? 0)
          .toString()

        lpFeeOmnipool = isNative ? undefined : feeByAsset.get(poolId)

        totalFee = Big(lpFeeStablepool ?? 0)
          .plus(lpFeeOmnipool ?? 0)
          .plus(totalApr)
          .toString()
      }

      if (borrowApyData?.totalSupplyApy === null) {
        totalFee = undefined
      } else if (borrowApyData?.totalSupplyApy) {
        totalFee = Big(borrowApyData.totalSupplyApy)
          .plus(totalFee ?? 0)
          .minus(lpFeeStablepool ?? 0)
          .toString()
      }

      const price = assetPrice.isValid
        ? Big(assetPrice.price).round(5).toString()
        : undefined

      const { all: positions } = getAssetPositions(poolId)

      const positionsAmount = positions.length
      const stableswapBalance = isStablePool
        ? getTransferableBalance(stablepoolInOmnipool?.id.toString() ?? poolId)
        : 0n

      const isPositions =
        positionsAmount > 0 ||
        (Big(stableswapBalance.toString()).gt(0) && isStablePool) ||
        Big(aStableswapBalance?.toString() ?? 0).gt(0)

      const tvlDisplay = isStablepoolOnly
        ? pool.balance
        : price
          ? Big(scaleHuman(pool.balance, meta.decimals)).times(price).toFixed(2)
          : undefined

      const stableswapBalanceDisplay = price
        ? Big(scaleHuman(stableswapBalance, meta.decimals))
            .times(price)
            .toFixed(2)
        : undefined

      const tradability = isStablepoolOnly
        ? { canAddLiquidity: true, canRemoveLiquidity: true }
        : pool.tradeable
          ? getOmnipoolTradability(pool.tradeable)
          : { canAddLiquidity: false, canRemoveLiquidity: false }

      const isOverrideMeta = OVERRIDE_META.includes(poolId)

      return {
        id: poolId,
        meta: aStableswapAsset && isOverrideMeta ? aStableswapAsset : meta,
        price,
        tvlDisplay,
        lpFeeOmnipool,
        lpFeeStablepool,
        totalFee,
        isFeeLoading: isYieldMetricsLoading || isOmnipoolFarmsLoading,
        isNative,
        isPositions,
        positionsAmount,
        isStablePool,
        stableswapBalance,
        stableswapBalanceDisplay,
        volumeDisplay: volume,
        positions,
        isVolumeLoading,
        isFarms,
        farms,
        allFarms,
        isStablepoolOnly,
        isStablepoolInOmnipool,
        aStableswapBalance,
        aStableswapAsset,
        borrowApyData,
        stablepoolData: isStablepoolOnly ? pool : stablepoolInOmnipool,
        canAddLiquidity: tradability.canAddLiquidity,
        canRemoveLiquidity: tradability.canRemoveLiquidity,
      }
    })

    return omnipoolData.filter((pool) => !isBlacklistedAsset(pool.id))
  }, [
    getAssetWithFallback,
    getAssetPrice,
    nativeId,
    isLoading,
    getAssetPositions,
    getTransferableBalance,
    omnipoolAssets,
    volumeByAsset,
    isVolumeLoading,
    isYieldMetricsLoading,
    feeByAsset,
    stablepools,
    omnipoolFarms,
    isOmnipoolFarmsLoading,
  ])

  useEffect(() => {
    setOmnipoolAssets(data, isLoading)
  }, [data, isLoading])
}

export const useIsolatedPools = () => {
  const { data: pools, isLoading: isPoolsLoading } = useXykPools()
  const { getShareTokenByAddress } = useAssets()
  const { getPositions } = useAccountPositions()

  const { data: xykVolumes, isLoading: isVolumeLoading } = useQuery(
    neckworkXykVolumeQuery(neckworkClient),
  )
  const { data: isolatedPoolsFarms } = useIsolatedPoolsFarms()
  const { getTransferableBalance } = useAccountBalances()

  const { pricesIds, poolsData } = useMemo(() => {
    const priceIds = new Set<string>()
    const poolsDataArray: {
      spotPriceId: string
      tvl: string
      pool: PoolBase
    }[] = []

    for (const pool of pools ?? []) {
      const { tokens } = pool
      const [tokenA, tokenB] = tokens

      if (
        !tokenA ||
        !tokenB ||
        isBlacklistedAsset(tokenA.id) ||
        isBlacklistedAsset(tokenB.id)
      ) {
        continue
      }

      let knownAssetPrice: (typeof tokens)[number] | undefined

      for (const token of tokens) {
        if (priceIds.has(token.id.toString())) {
          knownAssetPrice = token
          break
        }
      }

      if (!knownAssetPrice) {
        knownAssetPrice = tokens[0]
      }

      if (!knownAssetPrice) continue

      const shiftedBalance = scaleHuman(
        knownAssetPrice.balance,
        knownAssetPrice.decimals ?? 0,
      )
      const tvl = Big(shiftedBalance).times(2).toString()

      poolsDataArray.push({
        spotPriceId: knownAssetPrice.id.toString(),
        tvl,
        pool,
      })

      if (!priceIds.has(knownAssetPrice.id.toString())) {
        priceIds.add(knownAssetPrice.id.toString())
      }
    }

    return {
      pricesIds: Array.from(priceIds),
      poolsData: poolsDataArray,
    }
  }, [pools])

  const { getAssetPrice, isLoading: isPriceLoading } = useAssetsPrice(pricesIds)
  const isLoading = isPriceLoading || isPoolsLoading

  const data = useMemo(() => {
    if (isLoading) return []

    return poolsData.reduce<IsolatedPoolTable[]>(
      (acc, { pool, tvl, spotPriceId }) => {
        const {
          tokens: [tokenA, tokenB],
          address,
          minTradingLimit,
        } = pool
        const assetPrice = getAssetPrice(spotPriceId)
        const price = assetPrice.isValid ? assetPrice.price : undefined
        const tvlDisplay = price
          ? (Big(price).times(tvl).toString() ?? "0")
          : "0"

        const allFarms = isolatedPoolsFarms?.[address] ?? []
        const farms =
          isolatedPoolsFarms?.[address]?.filter((farm) => farm.apr !== "0") ??
          []
        const isFarms = farms.length > 0
        const totalApr = farms
          .reduce((acc, farm) => acc.plus(farm.apr), Big(0))
          .toString()

        const meta = getShareTokenByAddress(address)

        if (!meta || !tokenA || !tokenB) return acc

        const shareTokenId = meta.id

        if (isBlacklistedAsset(shareTokenId)) return acc
        const { xykMiningPositions } = getPositions(address)

        const volumeDisplay = xykVolumes?.find(
          (volume) => volume.poolId === address,
        )?.poolVolume

        const balance = getTransferableBalance(shareTokenId)

        const positionsAmount = Big(xykMiningPositions.length)
          .plus(balance ? 1 : 0)
          .toNumber()

        acc.push({
          id: address,
          tokens: [tokenA, tokenB],
          meta,
          tvlDisplay,
          isPositions: positionsAmount > 0,
          positionsAmount,
          volumeDisplay,
          balance,
          price,
          shareTokenId,
          positions: xykMiningPositions,
          minTradingLimit,
          isVolumeLoading,
          isFarms,
          totalApr,
          isFeeLoading: false,
          farms,
          allFarms,
          canAddLiquidity: true,
          canRemoveLiquidity: true,
          isNative: false,
        })

        return acc
      },
      [],
    )
  }, [
    poolsData,
    getAssetPrice,
    getShareTokenByAddress,
    getPositions,
    getTransferableBalance,
    isLoading,
    xykVolumes,
    isVolumeLoading,
    isolatedPoolsFarms,
  ])

  useEffect(() => {
    setXYKPools({ data, isLoading })
  }, [data, isLoading])
}

export const isIsolatedPool = (
  pool: OmnipoolAssetTable | IsolatedPoolTable,
): pool is IsolatedPoolTable => {
  return "tokens" in pool
}

export const useOmnipoolCapacity = (id: string) => {
  const {
    dataMap: omnipoolAssets,
    hubToken,
    isLoading,
  } = useOmnipoolAssetsData()

  const data = useMemo(() => {
    if (!omnipoolAssets || !hubToken) return null

    const asset = omnipoolAssets.get(Number(id))

    if (!asset || !hubToken) return null

    const assetReserve = asset.balance.toString()
    const assetHubReserve = asset.hubReserves.toString()
    const assetCap = asset.cap.toString()
    const totalHubReserve = hubToken.balance.toString()

    const capDifference = pool.omni.OmniMath.calculateCapDifference(
      assetReserve,
      assetHubReserve,
      assetCap,
      totalHubReserve,
    )

    if (capDifference === "-1") return null

    const capacity = scaleHuman(
      Big(assetReserve).plus(capDifference).toString(),
      asset.decimals ?? 0,
    )
    const filled = scaleHuman(assetReserve, asset.decimals ?? 0)
    const filledPercent = Big(filled).div(capacity).times(100).toString()

    return { capacity, filled, filledPercent }
  }, [hubToken, id, omnipoolAssets])

  return { data, isLoading }
}

export const useStablepoolReserves = (poolId: string) => {
  const { data, isLoading } = useStablepoolsReserves([poolId])

  return { data: data[0], isLoading }
}

export const useStablepoolsReserves = (poolIds?: string[]) => {
  const { getAssetWithFallback } = useAssets()
  const { data: pools = [], isLoading: isPoolsLoading } = useStablePools()

  const stablepools_: StableSwapBase[] = []
  const tokenSet = new Set<string>()

  const filterPoolTokens = (pool: StableSwapBase) => {
    const tokens: PoolToken[] = []

    pool.tokens.forEach((token) => {
      if (token.id !== pool.id) {
        tokenSet.add(String(token.id))
        tokens.push(token)
      }
    })

    stablepools_.push({ ...pool, tokens })
  }

  if (poolIds) {
    poolIds.forEach((poolId) => {
      const pool = pools.find((pool) => pool.id.toString() === poolId)

      if (pool) filterPoolTokens(pool)
    })
  } else {
    pools.forEach(filterPoolTokens)
  }

  const { getAssetPrice, isLoading: isPriceLoading } = useAssetsPrice([
    ...tokenSet,
  ])

  if (isPriceLoading) return { data: [], isLoading: true }

  const data: TStablepoolDetails[] = stablepools_.map((pool) => {
    const reserves: TReserve[] = []
    let totalDisplayAmount = Big(0)

    for (const token of pool.tokens) {
      const id = token.id.toString()
      const meta = getAssetWithFallback(id)
      const amountHuman = scaleHuman(token.balance, meta.decimals)

      const { price, isValid } = getAssetPrice(id)

      if (!isValid) continue

      const displayAmount = Big(amountHuman).times(price).toString()
      totalDisplayAmount = totalDisplayAmount.plus(displayAmount)

      reserves.push({
        asset_id: Number(id),
        meta,
        amount: token.balance.toString(),
        amountHuman,
        displayAmount,
      })
    }

    return {
      pool,
      reserves,
      totalDisplayAmount: totalDisplayAmount.toString(),
    }
  })

  return { data, isLoading: isPoolsLoading || isPriceLoading }
}

export const isValidStablepoolToken = (token: PoolToken) => {
  return token.type === AssetType.TOKEN || token.type === AssetType.ERC20
}

export const calculatePoolFee = (fee?: number[] | PoolFee) => {
  if (fee?.length !== 2) return

  const numerator = fee[0]
  const denominator = fee[1]

  if (!isNumber(numerator) || !isNumber(denominator)) return undefined

  const tradeFee = Big(numerator).div(denominator)

  return tradeFee.times(100).toString()
}

const getOmnipoolTradability = (value: number) => {
  const canBuy = is_buy_allowed(value)
  const canSell = is_sell_allowed(value)
  const canAddLiquidity = is_add_liquidity_allowed(value)
  const canRemoveLiquidity = is_remove_liquidity_allowed(value)

  return { canBuy, canSell, canAddLiquidity, canRemoveLiquidity }
}

export const useAddableStablepoolTokens = (
  poolId: string,
  reserves: TReserve[],
) => {
  const { data: tradability } = useStableSwapTradability()
  const isTradability = !!tradability?.length

  if (!isTradability) return reserves

  return reserves.filter((reserve) => {
    const tradabilityValue = tradability.find(
      ({ keyArgs: [poolId_, assetId] }) =>
        poolId_.toString() === poolId && assetId === reserve.asset_id,
    )?.value
    return tradabilityValue ? is_add_liquidity_allowed(tradabilityValue) : true
  })
}

export const useNavigateLiquidityBack = () => {
  const { history } = useRouter()
  const navigate = useNavigate()

  return () => {
    if (history.canGoBack()) {
      history.back()
    } else {
      navigate({ to: "/liquidity" })
    }
  }
}

export const useLiquidityMinLimit = () => {
  const { slippage } = useTradeSettings(useShallow(prop("liquidity")))

  return (value: string | number | Big) =>
    Big(value)
      .times(100 - slippage)
      .div(100)
      .toFixed(0)
}

export const convertXYKSharesToValues = (
  pool: XYKPoolWithLiquidity,
  shares: bigint | string,
  cb?: (value: string) => string,
): [
  { token: PoolToken; value: string },
  { token: PoolToken; value: string },
] => {
  const { tokens, totalLiquidity } = pool

  const [tokenA, tokenB] = tokens

  const valueA = Big(tokenA.balance.toString())
    .times(shares.toString())
    .div(totalLiquidity.toString())
    .toString()

  const valueB = Big(tokenB.balance.toString())
    .times(shares.toString())
    .div(totalLiquidity.toString())
    .toString()

  return [
    { token: tokenA, value: cb ? cb(valueA) : valueA },
    { token: tokenB, value: cb ? cb(valueB) : valueB },
  ]
}

export const useIsLiquidityProvided = () => {
  const { getAsset, getShareToken } = useAssets()
  const { balances } = useAccountBalances()
  const { positionsAmount } = useAccountPositions()

  return useMemo(() => {
    if (positionsAmount > 0) return true

    return Object.values(balances).some((balance) => {
      const asset = getAsset(balance.assetId)

      if (asset) {
        return (
          asset.type === AssetType.STABLESWAP ||
          (asset.type === AssetType.ERC20 && asset.id !== HOLLAR_ASSET_ID)
        )
      }

      const shareToken = getShareToken(balance.assetId)

      return !!shareToken
    })
  }, [balances, getAsset, getShareToken, positionsAmount])
}
