export * from "./DetailedLink"
