import { calculate_loyalty_multiplier } from "@galacticcouncil/math-liquidity-mining"
import { calculate_liquidity_out_asset_a } from "@galacticcouncil/math-xyk"
import { useAccount } from "@galacticcouncil/web3-connect"
import { standardSchemaResolver } from "@hookform/resolvers/standard-schema"
import { useMutation } from "@tanstack/react-query"
import Big from "big.js"
import { useMemo } from "react"
import { useForm } from "react-hook-form"
import { useTranslation } from "react-i18next"
import { z, ZodType } from "zod/v4"

import {
  omnipoolMiningPositionsKey,
  omnipoolPositionsKey,
  useAccountXykMiningPositions,
  XykDeposit,
  xykMiningPositionsKey,
} from "@/api/account"
import { TAssetData } from "@/api/assets"
import { useAccountBalances } from "@/api/balances"
import { Farm, LoyaltyCurve, useIsolatedPoolFarms } from "@/api/farms"
import { useOraclePrice } from "@/api/omnipool"
import { PoolToken, useXykPool } from "@/api/pools"
import { useShareTokenPrices } from "@/api/spotPrice"
import { XYKPoolWithLiquidity } from "@/api/xyk"
import { useCreateBatchTx } from "@/modules/transactions/hooks/useBatchTx"
import { TShareToken, useAssets, XYKPoolMeta } from "@/providers/assetsProvider"
import { useRpcProvider } from "@/providers/rpcProvider"
import {
  AccountOmnipoolPosition,
  isDepositPosition,
  isOmnipoolDepositPosition,
} from "@/states/account"
import {
  TransactionOptions,
  TransactionToasts,
  useTransactionsStore,
} from "@/states/transactions"
import { QUINTILL } from "@/utils/consts"
import { scale, scaleHuman } from "@/utils/formatting"
import { required, validateFieldMaxBalance } from "@/utils/validators"

import { JoinFarmsProps } from "./JoinFarms"

const LIQUIDITY_OUT_SHARES = "10000"

type JoinFarmsFormValues = { amount: string }

export const getMinimalDeposit = (farms: Farm[]) =>
  farms.length > 0
    ? farms.reduce(
        (acc, farm) => {
          const minDeposit = Big(farm.minDeposit.toString())

          return minDeposit.gt(acc.value)
            ? {
                value: minDeposit,
                assetId: farm.incentivizedAsset,
              }
            : acc
        },
        { value: Big(0), assetId: 0 },
      )
    : undefined

const getAvailableFarms = (
  farms: Farm[],
  position: AccountOmnipoolPosition | XykDeposit,
) =>
  isDepositPosition(position)
    ? farms.filter(
        (farm) =>
          !position.yield_farm_entries?.find(
            (entry) =>
              entry.global_farm_id === farm.globalFarmId &&
              entry.yield_farm_id === farm.yieldFarmId,
          ),
      )
    : farms

export const useJoinOmnipoolFarms = ({
  position,
  farms,
  onSubmitted,
}: {
  position: AccountOmnipoolPosition
  farms: Farm[]
  onSubmitted: () => void
}) => {
  const {
    data: { meta },
  } = position
  const isDeposit = isOmnipoolDepositPosition(position)

  const availableFarms = getAvailableFarms(farms, position)

  const schema = useOmnipoolZodSchema({
    id: meta.id,
    farms: availableFarms,
  })

  const mutation = useJoinOmnipoolFarmsMutation({
    farms: availableFarms,
    meta,
    positionId: position.positionId,
    options: { onSubmitted },
  })

  if (!schema) return undefined

  const onSubmit = () => {
    mutation.mutate({
      ...(isDeposit && { depositId: position.miningId }),
      amountHuman: position.data.currentTotalValueHuman,
    })
  }

  return {
    formValues: { amount: position.data.currentTotalValueHuman, rule: schema },
    displayValue: position.data.currentTotalDisplay,
    onSubmit,
    availableFarms,
    meta,
  }
}

export const useXYKFarmMinShares = (poolAddress: string, farms: Farm[]) => {
  const { data: pool } = useXykPool(poolAddress)

  const minDeposit = getMinimalDeposit(farms)

  const [assetAReserve, assetBReserve] = pool?.tokens ?? []

  const { data: oracle } = useOraclePrice(
    assetAReserve?.id,
    assetBReserve?.id,
    "hydraxyk",
  )

  return useMemo(() => {
    if (
      !oracle ||
      !oracle.shares_issuance ||
      !assetAReserve?.decimals ||
      !minDeposit
    ) {
      return "0"
    }

    const liquidityOut = calculate_liquidity_out_asset_a(
      oracle.liquidity.a.toString(),
      oracle.liquidity.b.toString(),
      LIQUIDITY_OUT_SHARES,
      oracle.shares_issuance.toString(),
    )

    const valuedSharePrice = Big(liquidityOut)
      .div(LIQUIDITY_OUT_SHARES)
      .toString()

    const minShares = scale(
      Big(
        scaleHuman(
          Big(minDeposit.value).div(valuedSharePrice).toString(),
          assetAReserve.decimals,
        ),
      )
        .round(1, Big.roundUp)
        .toString(),
      assetAReserve.decimals,
    )

    return minShares
  }, [minDeposit, oracle, assetAReserve?.decimals])
}

export const useMinOmnipoolFarmJoin = (farms: Farm[], meta?: TAssetData) => {
  const minDeposit = getMinimalDeposit(farms)

  const { data: oracles } = useOraclePrice(
    minDeposit?.assetId,
    Number(meta?.id),
  )

  if (!oracles || !minDeposit || !meta) return undefined

  return Big(
    scaleHuman(
      minDeposit.value
        .times(oracles.price.d.toString())
        .div(oracles.price.n.toString())
        .toString(),
      meta.decimals,
    ),
  )
    .times(1.02)
    .toString()
}

export const useJoinIsolatedPoolFarms = ({
  props: { poolId, positionId, onSubmitted },
  meta,
  pool,
}: {
  props: JoinFarmsProps
  pool: XYKPoolWithLiquidity
  meta: TShareToken
}) => {
  const { tokens } = pool
  const { data: positions } = useAccountXykMiningPositions()
  const { data: shareTokenPrices } = useShareTokenPrices([poolId])
  const { data: activeFarms } = useIsolatedPoolFarms(poolId)
  const farms = activeFarms?.filter((farm) => farm.apr !== "0") ?? []

  const { getTransferableBalance } = useAccountBalances()
  const balance = getTransferableBalance(meta.id)
  const price = shareTokenPrices.get(poolId)

  const isDeposit = !!positionId

  const position = positions?.find((position) => position.id === positionId)
  const availableFarms = position ? getAvailableFarms(farms, position) : farms

  const schema = useXYKJoinFarmsZodSchema({
    id: poolId,
    meta,
    farms: availableFarms,
  })

  const mutation = useJoinIsolatedPoolFarmsMutation({
    farms: availableFarms,
    tokens,
    meta,
    options: { onSubmitted },
  })

  const onSubmit = (amount: string) => {
    mutation.mutate({
      ...(isDeposit && { depositId: positionId }),
      amount: scale(amount, meta.decimals),
    })
  }

  if (!schema || !price) return undefined

  if (isDeposit && position) {
    return {
      formValues: {
        amount: position.shares.toString(),
        rule: schema,
      },
      availableFarms,
      meta,
      onSubmit,
      displayValue: price
        ? Big(position.shares.toString()).times(price).toString()
        : undefined,
    }
  }

  const balanceHuman = scaleHuman(balance.toString(), meta.decimals)

  return {
    formValues: {
      amount: balanceHuman,
      rule: schema.check(validateFieldMaxBalance(balanceHuman)),
    },
    availableFarms,
    meta,
    onSubmit,
    isEditable: true,
  }
}

const useJoinOmnipoolFarmsMutation = ({
  farms,
  positionId,
  options,
  meta,
}: {
  farms: Farm[]
  positionId: string
  meta: TAssetData
  options?: TransactionOptions
}) => {
  const { t } = useTranslation("liquidity")
  const { account } = useAccount()
  const { papi } = useRpcProvider()
  const createTransaction = useTransactionsStore((s) => s.createTransaction)
  const createBatch = useCreateBatchTx()

  return useMutation({
    mutationFn: async ({
      depositId,
      amountHuman,
    }: {
      depositId?: string
      amountHuman: string
    }) => {
      if (!farms.length) throw new Error("There are no farms to join")
      if (!meta) throw new Error("Missing asset meta")

      const executeRedeposit = async (depositId: string, farms: Farm[]) => {
        const txs = farms.map((farm) =>
          papi.tx.OmnipoolLiquidityMining.redeposit_shares({
            global_farm_id: farm.globalFarmId,
            yield_farm_id: farm.yieldFarmId,
            deposit_id: BigInt(depositId),
          }),
        )

        await createBatch({
          txs,
          transaction: {
            invalidateQueries: [
              omnipoolPositionsKey(account?.address ?? ""),
              omnipoolMiningPositionsKey(account?.address ?? ""),
            ],
          },
          options,
        })
      }

      if (!depositId) {
        const tx = papi.tx.OmnipoolLiquidityMining.join_farms({
          farm_entries: farms.map((farm) => [
            farm.globalFarmId,
            farm.yieldFarmId,
          ]),
          position_id: BigInt(positionId),
        })

        const toasts: TransactionToasts = {
          submitted: t("liquidity.joinFarms.modal.join.toast.submitted", {
            value: amountHuman,
            symbol: meta.symbol,
          }),
          success: t("liquidity.joinFarms.modal.join.toast.success", {
            value: amountHuman,
            symbol: meta.symbol,
          }),
        }

        await createTransaction(
          {
            tx,
            toasts,
            invalidateQueries: [
              omnipoolPositionsKey(account?.address ?? ""),
              omnipoolMiningPositionsKey(account?.address ?? ""),
            ],
          },
          options,
        )
      } else {
        await executeRedeposit(depositId, farms)
      }
    },
  })
}

const useJoinIsolatedPoolFarmsMutation = ({
  farms,
  tokens,
  meta,
  options,
}: {
  farms: Farm[]
  tokens: [PoolToken, PoolToken]
  meta: XYKPoolMeta
  options?: TransactionOptions
}) => {
  const { account } = useAccount()
  const { papi } = useRpcProvider()
  const { t } = useTranslation("liquidity")
  const createTransaction = useTransactionsStore((s) => s.createTransaction)
  const createBatch = useCreateBatchTx()

  return useMutation({
    mutationFn: async ({
      depositId,
      amount,
    }: {
      depositId?: string
      amount: string
    }) => {
      const [farm] = farms
      if (!farm) throw new Error("There are no farms to join")

      const executeRedeposit = async (depositId: string, farms: Farm[]) => {
        const txs = farms.map((farm) =>
          papi.tx.XYKLiquidityMining.redeposit_shares({
            global_farm_id: farm.globalFarmId,
            yield_farm_id: farm.yieldFarmId,
            deposit_id: BigInt(depositId),
            asset_pair: {
              asset_in: tokens[0].id,
              asset_out: tokens[1].id,
            },
          }),
        )

        await createBatch({
          txs,
          transaction: {
            invalidateQueries: [xykMiningPositionsKey(account?.address ?? "")],
          },
          options,
        })
      }

      if (!depositId) {
        const tx = papi.tx.XYKLiquidityMining.join_farms({
          farm_entries: farms.map((farm) => [
            farm.globalFarmId,
            farm.yieldFarmId,
          ]),
          asset_pair: {
            asset_in: tokens[0].id,
            asset_out: tokens[1].id,
          },
          shares_amount: BigInt(amount),
        })

        const toasts: TransactionToasts = {
          submitted: t("liquidity.joinFarms.modal.join.toast.submitted", {
            value: scaleHuman(amount, meta.decimals),
            symbol: meta.symbol,
          }),
          success: t("liquidity.joinFarms.modal.join.toast.success", {
            value: scaleHuman(amount, meta.decimals),
            symbol: meta.symbol,
          }),
        }

        await createTransaction(
          {
            tx,
            toasts,
            invalidateQueries: [xykMiningPositionsKey(account?.address ?? "")],
          },
          options,
        )
      } else {
        await executeRedeposit(depositId, farms)
      }
    },
  })
}

export type TJoinFarmsForm = {
  amount: string
  rule: ZodType<string, string>
}

export const useJoinFarmsForm = ({ amount, rule }: TJoinFarmsForm) => {
  return useForm<JoinFarmsFormValues>({
    mode: "onChange",
    defaultValues: { amount },
    resolver: standardSchemaResolver(z.object({ amount: rule })),
  })
}

const useOmnipoolZodSchema = ({ id, farms }: { id: string; farms: Farm[] }) => {
  const { t } = useTranslation("liquidity")
  const { getAssetWithFallback } = useAssets()

  const meta = getAssetWithFallback(id)
  const minJoinAmount = useMinOmnipoolFarmJoin(farms, meta)

  if (!minJoinAmount) return undefined

  return required.refine(
    (value) => {
      return Big(value).gte(minJoinAmount)
    },
    {
      error: t("liquidity.joinFarms.modal.validation.minShares", {
        value: minJoinAmount,
        symbol: meta.symbol,
      }),
    },
  )
}

const useXYKJoinFarmsZodSchema = ({
  id,
  meta,
  farms,
}: {
  id: string
  farms: Farm[]
  meta: XYKPoolMeta
}) => {
  const { t } = useTranslation("liquidity")
  const minJoinAmount = useXYKFarmMinShares(id, farms)

  if (!minJoinAmount) return undefined

  const minJoinAmountHuman = scaleHuman(minJoinAmount, meta.decimals)

  return required.refine((value) => Big(value).gte(minJoinAmountHuman), {
    error: t("liquidity.joinFarms.modal.validation.minShares", {
      value: minJoinAmountHuman,
      symbol: meta.symbol,
    }),
  })
}

export const getCurrentLoyaltyFactor = (
  loyaltyCurve: NonNullable<LoyaltyCurve>,
  currentPeriod: number,
) =>
  Big(
    calculate_loyalty_multiplier(
      currentPeriod.toFixed(),
      loyaltyCurve.initial_reward_percentage.toString(),
      loyaltyCurve.scale_coef.toString(),
    ),
  )
    .div(QUINTILL)
    .toString()
