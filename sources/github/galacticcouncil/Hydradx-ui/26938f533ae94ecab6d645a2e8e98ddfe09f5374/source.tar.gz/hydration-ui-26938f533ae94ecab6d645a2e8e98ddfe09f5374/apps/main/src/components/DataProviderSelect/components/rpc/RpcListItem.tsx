import { CircleOff, Edit, Trash } from "@galacticcouncil/ui/assets/icons"
import {
  Box,
  Flex,
  Icon,
  SpinnerIcon,
  Text,
  TextButton,
  Tooltip,
} from "@galacticcouncil/ui/components"
import { getToken } from "@galacticcouncil/ui/utils"
import { getHostnameFromUrl, PingResponse } from "@galacticcouncil/utils"
import { useQuery } from "@tanstack/react-query"
import { useState } from "react"
import { useTranslation } from "react-i18next"
import { isNumber } from "remeda"

import { bestNumberQuery } from "@/api/chain"
import { RpcStatusQueryOptions, useRpcStatus } from "@/api/rpc"
import { ListItemEditForm } from "@/components/DataProviderSelect/components/ListItemEditForm"
import { RpcRemoveModal } from "@/components/DataProviderSelect/components/rpc/RpcRemoveModal"
import { RpcStatus } from "@/components/DataProviderSelect/components/rpc/RpcStatus"
import { useRpcProvider } from "@/providers/rpcProvider"
import { useProviderRpcUrlStore, useRpcListStore } from "@/states/provider"

import { SRpcListItem, SRpcRadio, SRpcRadioThumb } from "./RpcListItem.styled"

export type RpcListItemProps = {
  name: string
  url: string
  isActive?: boolean
  isCustom?: boolean
  isLoading?: boolean
  onClick?: (url: string) => void
  onRemove?: (url: string) => void
}

export const RpcListHeader: React.FC = () => {
  const { t } = useTranslation()
  return (
    <SRpcListItem
      bg={getToken("details.separatorsOnDim")}
      sx={{ height: "auto", borderTop: 0 }}
    >
      <Text fs="p5" color={getToken("text.medium")}>
        {t("rpc.change.modal.column.name")}
      </Text>
      <Text fs="p5" color={getToken("text.medium")}>
        {t("rpc.change.modal.column.status")}
      </Text>
      <Text
        fs="p5"
        color={getToken("text.medium")}
        display={["none", "block"]}
        align="right"
      >
        {t("rpc.change.modal.column.rpc")}
      </Text>
    </SRpcListItem>
  )
}

const RpcListItemLayout: React.FC<RpcListItemProps & Partial<PingResponse>> = ({
  name,
  url,
  isActive,
  isCustom,
  onClick,
  onRemove,
  timestamp,
  blockNumber,
  ping,
  isLoading,
}) => {
  const { t } = useTranslation()
  const [isEdit, setIsEdit] = useState(false)
  const { renameRpc } = useRpcListStore()
  const isOffline = !isLoading && !isNumber(blockNumber)
  const isBlocked = isLoading || isOffline
  const canSelect = !isBlocked && !!onClick

  if (isEdit) {
    return (
      <SRpcListItem data-edit="true">
        <ListItemEditForm
          name={name}
          onClose={() => setIsEdit(false)}
          onSubmit={(newName) => renameRpc(url, newName)}
        />
      </SRpcListItem>
    )
  }

  return (
    <SRpcListItem
      blocked={isBlocked}
      onClick={canSelect ? () => onClick?.(url) : undefined}
      isInteractive={canSelect || !!onRemove}
    >
      <Box>
        <Text
          fs="p3"
          color={getToken(isActive ? "colors.coral.700" : "text.high")}
        >
          {name}
        </Text>
        <Text
          fs="p6"
          mt="xs"
          display={["block", "none"]}
          color={getToken("text.medium")}
        >
          {getHostnameFromUrl(url)}
        </Text>
      </Box>
      <Flex height="xl" align="center">
        {isLoading ? (
          <SpinnerIcon size="xs" />
        ) : (
          <RpcStatus
            url={url}
            name={name}
            timestamp={timestamp}
            blockNumber={blockNumber}
            ping={ping}
          />
        )}
      </Flex>
      <Flex
        color={getToken("text.medium")}
        gap="s"
        justify="end"
        align="center"
      >
        <Text fs="p4" display={["none", "block"]}>
          {new URL(url).hostname}
        </Text>
        {isCustom && !!onRemove && (
          <>
            <RpcRemoveModal
              onRemove={() => onRemove(url)}
              trigger={
                <TextButton
                  sx={{ p: "xs" }}
                  onClick={(e) => {
                    e.stopPropagation()
                  }}
                >
                  <Icon size="s" component={Trash} />
                </TextButton>
              }
            />
            <Tooltip text={t("edit")} size="small" asChild side="top">
              <TextButton
                sx={{ p: "xs" }}
                onClick={(e) => {
                  e.stopPropagation()
                  setIsEdit(true)
                }}
              >
                <Icon size="s" component={Edit} />
              </TextButton>
            </Tooltip>
          </>
        )}
        {!!onClick && (
          <Box sx={{ ml: "base" }}>
            {isOffline ? (
              <Icon size="xs" component={CircleOff} />
            ) : (
              <SRpcRadio>{isActive && <SRpcRadioThumb />}</SRpcRadio>
            )}
          </Box>
        )}
      </Flex>
    </SRpcListItem>
  )
}

export const RpcListItemActive: React.FC<
  RpcListItemProps & Partial<PingResponse> & RpcStatusQueryOptions
> = ({ poll, ...props }) => {
  const provider = useRpcProvider()
  const rpcUrl = useProviderRpcUrlStore((state) => state.rpcUrl)
  const connectedRpcUrl = useProviderRpcUrlStore(
    (state) => state.connectedRpcUrl,
  )

  const isSwitching = rpcUrl !== connectedRpcUrl
  const { data: bestNumber, isLoading: isBestNumberLoading } = useQuery(
    bestNumberQuery(provider),
  )
  const { data: status } = useRpcStatus(!props?.ping ? provider.endpoint : "", {
    poll,
  })

  const blockNumber = isSwitching
    ? props.blockNumber
    : bestNumber?.parachainBlockNumber
  const timestamp = isSwitching ? props.timestamp : bestNumber?.timestamp

  const isLoading =
    !provider.isReady || isSwitching || (isBestNumberLoading && !isSwitching)

  return (
    <RpcListItemLayout
      {...props}
      ping={props?.ping ?? status?.ping}
      blockNumber={blockNumber}
      timestamp={timestamp}
      isLoading={isLoading}
    />
  )
}

export const RpcListItem: React.FC<RpcListItemProps> = (props) => {
  return props.isActive ? (
    <RpcListItemActive {...props} />
  ) : (
    <RpcListItemLayout {...props} />
  )
}
