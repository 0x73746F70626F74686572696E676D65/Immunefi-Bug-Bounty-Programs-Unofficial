import { Text, TextProps, Tooltip } from "@galacticcouncil/ui/components"
import { differenceInHours } from "date-fns"
import { useRef } from "react"
import { useTranslation } from "react-i18next"

import { RelativeDateText } from "@/components/RelativeDateText/RelativeDateText"

export type DateTextProps = TextProps & {
  date: Date
}

export const DateText: React.FC<DateTextProps> = ({ date, ...props }) => {
  const { t } = useTranslation(["common"])

  const now = useRef(new Date()).current
  const hoursAgo = differenceInHours(now, date)

  if (hoursAgo < 24) {
    return (
      <Tooltip text={t("date.datetime", { value: date })} side="left">
        <RelativeDateText shortFormat date={date} {...props} />
      </Tooltip>
    )
  }

  return <Text {...props}>{t("date.datetime.short", { value: date })}</Text>
}
