import { Search } from "@galacticcouncil/ui/assets/icons"
import { Input } from "@galacticcouncil/ui/components"
import { FC, useState } from "react"
import { useTranslation } from "react-i18next"
import { useDebounce } from "react-use"

type Props = {
  readonly searchPhrase: string
  readonly onChange: (value: string) => void
}

export const BorrowHistorySearch: FC<Props> = ({ searchPhrase, onChange }) => {
  const { t } = useTranslation("common")

  const [input, setInput] = useState(searchPhrase)
  useDebounce(
    () => {
      if (!input) {
        onChange("")
      }

      input.length >= 3 && onChange(input.trim().toLowerCase())
    },
    350,
    [input],
  )

  return (
    <Input
      iconStart={Search}
      value={input}
      onChange={(e) => setInput(e.target.value)}
      placeholder={t("search.placeholder.assets")}
      width={["100%", null, "4xl"]}
    />
  )
}
