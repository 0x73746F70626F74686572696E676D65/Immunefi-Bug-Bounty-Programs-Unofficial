import { platformStatsQuery } from "@galacticcouncil/indexer/neckwork"
import { ValueStats } from "@galacticcouncil/ui/components"
import { useQuery } from "@tanstack/react-query"
import Big from "big.js"
import { useTranslation } from "react-i18next"

import { neckworkClient } from "@/api/neckwork"
import { PoolsHeaderSeparator } from "@/modules/liquidity/components/PoolsHeader/PoolsHeaderSeparator"
import { VaultsValueTile } from "@/modules/liquidity/components/PoolsHeader/Vaults"

const NO_TOTALS = {
  liquidity: NaN,
  stablepool: NaN,
  isolated: NaN,
  volume: NaN,
  totalLiquidity: NaN,
}

export const AllPools = () => {
  const { t } = useTranslation(["liquidity", "common"])

  const { data: neckwork, isLoading } = useQuery(
    platformStatsQuery(neckworkClient),
  )

  const totals =
    neckwork &&
    neckwork.omnipoolTvlNorm !== null &&
    neckwork.stablepoolsTvlNorm !== null &&
    neckwork.xykTvlNorm !== null &&
    neckwork.totalTvlNorm !== null
      ? {
          liquidity: Big(neckwork.omnipoolTvlNorm),
          stablepool: Big(neckwork.stablepoolsTvlNorm),
          isolated: Big(neckwork.xykTvlNorm),
          totalLiquidity: Big(neckwork.totalTvlNorm),
          volume: Big(neckwork.omnipoolVolNorm)
            .plus(neckwork.stableswapVolNorm)
            .plus(neckwork.xykVolNorm),
        }
      : NO_TOTALS

  return (
    <>
      <ValueStats
        label={t("liquidity:header.totalLiquidity")}
        value={t("common:currency.compact", {
          value: totals.totalLiquidity,
        })}
        size="medium"
        isLoading={isLoading}
        wrap
      />
      <PoolsHeaderSeparator />
      <ValueStats
        label={t("liquidity:header.volume")}
        value={t("common:currency.compact", {
          value: totals.volume,
        })}
        isLoading={isLoading}
        size="medium"
        wrap
      />
      <PoolsHeaderSeparator />
      <VaultsValueTile />
      <ValueStats
        label={t("liquidity:header.valueInOmnipool")}
        value={t("common:currency.compact", { value: totals.liquidity })}
        size="medium"
        isLoading={isLoading}
        wrap
      />
      <PoolsHeaderSeparator />
      <ValueStats
        label={t("liquidity:header.valueInStablepool")}
        value={t("common:currency.compact", { value: totals.stablepool })}
        size="medium"
        isLoading={isLoading}
        wrap
      />
      <PoolsHeaderSeparator />
      <ValueStats
        label={t("liquidity:header.valueInIsolatedPools")}
        value={t("common:currency.compact", {
          value: totals.isolated,
        })}
        size="medium"
        isLoading={isLoading}
        wrap
      />
    </>
  )
}
