import { ArrowRight } from "@galacticcouncil/ui/assets/icons"
import {
  MenuItemDescription,
  MenuItemIcon,
  MenuItemLabel,
  MenuSelectionItem,
  MenuSelectionItemIcon,
  Skeleton,
  Spinner,
} from "@galacticcouncil/ui/components"
import { FC } from "react"
import { useTranslation } from "react-i18next"

import { useAccountFeePaymentAssetId } from "@/api/payments"
import { AssetLogo } from "@/components/AssetLogo"
import { useAssets } from "@/providers/assetsProvider"

type PaymentAssetProps = {
  onClick?: () => void
}

export const PaymentAsset: FC<PaymentAssetProps> = ({ onClick }) => {
  const { t } = useTranslation()
  const { getAsset } = useAssets()
  const { data: id, isLoading } = useAccountFeePaymentAssetId()
  const asset = getAsset(id?.toString() ?? "")

  return (
    <MenuSelectionItem onClick={onClick}>
      {!isLoading && asset ? (
        <>
          <MenuItemIcon
            sx={{ width: "auto", height: "auto" }}
            component={() => <AssetLogo id={asset.id} />}
          />
          <MenuItemLabel>{t("paymentAsset")}</MenuItemLabel>
          <MenuItemDescription>{asset.symbol}</MenuItemDescription>
        </>
      ) : (
        <>
          <MenuItemIcon component={Spinner} />
          <MenuItemLabel>{t("paymentAsset")}</MenuItemLabel>
          <MenuItemDescription>
            <Skeleton width={50} />
          </MenuItemDescription>
        </>
      )}
      <MenuSelectionItemIcon component={ArrowRight} />
    </MenuSelectionItem>
  )
}
