export * from "./AssetLabelFull"
