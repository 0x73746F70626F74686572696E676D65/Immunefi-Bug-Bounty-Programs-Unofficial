import { useAccount } from "@galacticcouncil/web3-connect"
import { useMutation, useQuery } from "@tanstack/react-query"
import Big from "big.js"
import { wrap } from "comlink"
import { subSeconds } from "date-fns"
import { useCallback } from "react"
import { useTranslation } from "react-i18next"

import {
  OmnipoolDepositFull,
  omnipoolMiningPositionsKey,
  XykDeposit,
  xykMiningPositionsKey,
} from "@/api/account"
import { omnipoolPositionsKey } from "@/api/account"
import { useRelayChainBlockNumber } from "@/api/chain"
import { Farm, FarmEntry } from "@/api/farms"
import { useXykPool } from "@/api/pools"
import { getCurrentLoyaltyFactor } from "@/modules/liquidity/components/JoinFarms/JoinFarms.utils"
import { useCreateBatchTx } from "@/modules/transactions/hooks/useBatchTx"
import { AnyPapiTx } from "@/modules/transactions/types"
import { useRpcProvider } from "@/providers/rpcProvider"
import {
  AccountOmnipoolPosition,
  isDepositPosition,
  isXykDepositPosition,
} from "@/states/account"
import { QUINTILL, RELAY_BLOCK_TIME } from "@/utils/consts"

import type { worker as WorkerType } from "./LoyaltyGraph.worker"
import Worker from "./LoyaltyGraph.worker?worker"

let workerInstance: ReturnType<typeof wrap<typeof WorkerType>> | null = null

export type TJoinedFarm = {
  farm: Farm
  farmEntry: FarmEntry
  period: number
  position: XykDeposit | OmnipoolDepositFull
}

export type TAprByRewardAsset = { rewardCurrency: number; apr: string }

const getWorker = () => {
  if (!workerInstance) {
    workerInstance = wrap<typeof WorkerType>(new Worker())
  }
  return workerInstance
}

export const useSecondsToLeft = (estimatedEndBlock: string) => {
  const relayChainBlockNumber = useRelayChainBlockNumber()

  return relayChainBlockNumber
    ? Big(estimatedEndBlock)
        .minus(relayChainBlockNumber)
        .times(RELAY_BLOCK_TIME)
        .div(1000)
    : undefined
}

export const useCurrentFarmPeriod = (disableRefetch?: boolean) => {
  const relayChainBlockNumber = useRelayChainBlockNumber(disableRefetch)

  return useCallback(
    (blocksPerPeriod: number) => {
      return relayChainBlockNumber
        ? Big(relayChainBlockNumber).div(blocksPerPeriod).toNumber()
        : undefined
    },
    [relayChainBlockNumber],
  )
}

export const useEnteredDate = () => {
  const relayChainBlockNumber = useRelayChainBlockNumber(true)

  return useCallback(
    (enteredAtBlock: number) => {
      if (!relayChainBlockNumber) return undefined

      const blockRange = Big(relayChainBlockNumber).minus(enteredAtBlock)
      const blockRangeSeconds = blockRange.times(RELAY_BLOCK_TIME).div(1000)

      const currentDateSeconds = Big(Date.now())
      const enteredAtDateSeconds = currentDateSeconds.minus(blockRangeSeconds)

      const rangeSeconds = currentDateSeconds.minus(enteredAtDateSeconds)
      const enteredAtDate = subSeconds(Date.now(), rangeSeconds.toNumber())

      return enteredAtDate
    },
    [relayChainBlockNumber],
  )
}

export const useLoyaltyRates = (farm: Farm, periodsInFarm?: number) => {
  const { loyaltyCurve, globalFarmId, plannedYieldingPeriods, apr } = farm

  return useQuery({
    queryKey: ["loyaltyRates", globalFarmId, periodsInFarm?.toString()],
    queryFn: loyaltyCurve
      ? async () => {
          const periods = Number(plannedYieldingPeriods)
          const initialRewardPercentage = Big(
            loyaltyCurve.initial_reward_percentage.toString(),
          )
            .div(QUINTILL.toString())
            .toNumber()

          const result = await getWorker().getLoyaltyFactor(
            periods,
            initialRewardPercentage,
            loyaltyCurve.scale_coef,
            periodsInFarm,
          )

          return result.map(({ period, rate, current }) => ({
            x: Big(period)
              .times(RELAY_BLOCK_TIME)
              .div(1000)
              .div(60)
              .div(60)
              .div(24)
              .toNumber(),
            y: Big(rate).times(Big(apr).div(100)).toNumber(),
            current,
          }))
        }
      : undefined,
    enabled: !!loyaltyCurve,
    staleTime: Infinity,
  })
}

export const useDepositAprs = () => {
  const getCurrentFarmPeriod = useCurrentFarmPeriod(true)

  return useCallback(
    (position: AccountOmnipoolPosition | XykDeposit, activeFarms: Farm[]) => {
      const isDeposit = isDepositPosition(position)

      if (!isDeposit || !activeFarms)
        return {
          aprsByRewardAsset: [],
          joinedFarms: [],
          farmsToJoin: activeFarms.filter((farm) => farm.apr !== "0"),
        }

      const joinedFarms: TJoinedFarm[] = []

      const farmsToJoin: Farm[] = []

      for (const farm of activeFarms) {
        const farmEntry = position.yield_farm_entries.find(
          (entry) => entry.global_farm_id === farm.globalFarmId,
        )

        const period = getCurrentFarmPeriod(farm.blocksPerPeriod)

        if (farmEntry && period) {
          joinedFarms.push({
            farm,
            farmEntry,
            period,
            position,
          })
        } else if (farm.apr !== "0") {
          farmsToJoin.push(farm)
        }
      }

      const totalAprs = joinedFarms.reduce(
        (acc, { farm, farmEntry, period }) => {
          const currentPeriodInFarm = Big(period)
            .minus(farmEntry.entered_at)
            .toNumber()

          const currentApr = farm.loyaltyCurve
            ? Big(farm.apr)
                .times(
                  getCurrentLoyaltyFactor(
                    farm.loyaltyCurve,
                    currentPeriodInFarm,
                  ),
                )
                .toString()
            : farm.apr

          const key = farm.rewardCurrency
          const value = currentApr ? Big(currentApr) : Big(0)

          acc[key] = (acc[key] ?? Big(0)).plus(value)

          return acc
        },
        {} as Record<number, Big>,
      )

      const aprsByRewardAsset = Object.entries(totalAprs).map(
        ([rewardCurrency, totalApr]) => ({
          rewardCurrency: Number(rewardCurrency),
          apr: totalApr.toString(),
        }),
      )

      return { aprsByRewardAsset, joinedFarms, farmsToJoin }
    },
    [getCurrentFarmPeriod],
  )
}

export const useExitDepositFarmsMutation = (
  deposit: XykDeposit | OmnipoolDepositFull,
  onSubmitted: () => void,
) => {
  const { account } = useAccount()
  const { t } = useTranslation("liquidity")
  const { papi } = useRpcProvider()
  const isXYK = isXykDepositPosition(deposit)
  const { data: pool } = useXykPool(isXYK ? deposit.amm_pool_id : "")
  const createBatch = useCreateBatchTx()

  return useMutation({
    mutationFn: async () => {
      let txs: Array<AnyPapiTx> = []

      if (isXYK) {
        if (pool) {
          const [assetA, assetB] = pool.tokens

          txs = deposit.yield_farm_entries.map((entry) => {
            return papi.tx.XYKLiquidityMining.withdraw_shares({
              deposit_id: BigInt(deposit.id),
              yield_farm_id: entry.yield_farm_id,
              asset_pair: {
                asset_in: assetA.id,
                asset_out: assetB.id,
              },
            })
          })
        } else {
          throw new Error("Pool not found")
        }
      } else {
        txs = deposit.yield_farm_entries.map((entry) => {
          return papi.tx.OmnipoolLiquidityMining.withdraw_shares({
            deposit_id: BigInt(deposit.miningId),
            yield_farm_id: entry.yield_farm_id,
          })
        })
      }

      const invalidateQueries = isXYK
        ? [xykMiningPositionsKey(account?.address ?? "")]
        : [
            omnipoolPositionsKey(account?.address ?? ""),
            omnipoolMiningPositionsKey(account?.address ?? ""),
          ]

      const toasts = {
        submitted: t("liquidity.exitFarms.toast.submitted"),
        success: t("liquidity.exitFarms.toast.success"),
      }

      return await createBatch({
        txs,
        transaction: { toasts, invalidateQueries },
        options: { onSubmitted },
      })
    },
  })
}
