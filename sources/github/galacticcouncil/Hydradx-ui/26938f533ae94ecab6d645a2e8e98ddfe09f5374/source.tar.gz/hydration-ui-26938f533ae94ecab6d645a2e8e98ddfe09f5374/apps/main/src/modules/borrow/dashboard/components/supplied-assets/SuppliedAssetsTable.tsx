import { useSuppliedAssetsData } from "@galacticcouncil/money-market/hooks"
import {
  DataTable,
  Modal,
  Paper,
  Separator,
  TableContainer,
  Text,
} from "@galacticcouncil/ui/components"
import { useBreakpoints } from "@galacticcouncil/ui/theme"
import { getToken } from "@galacticcouncil/ui/utils"
import { useState } from "react"
import { useTranslation } from "react-i18next"

import { useDataTableUrlSorting } from "@/hooks/useDataTableUrlSorting"
import { TablePaper } from "@/modules/borrow/components/TablePaper"
import { StackedTable } from "@/modules/borrow/dashboard/components/StackedTable"
import { SuppliedAssetsHeader } from "@/modules/borrow/dashboard/components/supplied-assets/SuppliedAssetsHeader"
import { useSuppliedAssetsTableColumns } from "@/modules/borrow/dashboard/components/supplied-assets/SuppliedAssetsTable.columns"
import { useNavigateToReserve } from "@/modules/borrow/hooks/useNavigateToReserve"
import {
  RemoveMoneyMarketLiquidity,
  TRemoveMoneyMarketLiquidityProps,
} from "@/modules/liquidity/components/RemoveLiquidity/RemoveMoneyMarketLiquidity"

export const SuppliedAssetsTable = () => {
  const { t } = useTranslation(["borrow"])
  const [modalProps, setModalProps] = useState<
    Omit<TRemoveMoneyMarketLiquidityProps, "onSubmitted"> | undefined
  >()
  const columns = useSuppliedAssetsTableColumns({ onRemove: setModalProps })
  const { data, isLoading } = useSuppliedAssetsData()
  const navigateToReserve = useNavigateToReserve()
  const { isMobile } = useBreakpoints()

  const sort = useDataTableUrlSorting("/borrow/dashboard", "suppliedSort")

  if (!isLoading && data.length === 0) {
    return (
      <Paper p="xl">
        <Text fw={500} color={getToken("text.low")}>
          {t("supplied.table.empty")}
        </Text>
      </Paper>
    )
  }

  return (
    <>
      <TablePaper>
        <SuppliedAssetsHeader />
        <Separator />
        {isMobile ? (
          <StackedTable
            skeletonRowCount={4}
            isLoading={isLoading}
            data={data}
            columns={columns}
          />
        ) : (
          <TableContainer>
            <DataTable
              skeletonRowCount={4}
              isLoading={isLoading}
              onRowClick={(row) => navigateToReserve(row.underlyingAsset)}
              fixedLayout
              data={data}
              columns={columns}
              {...sort}
            />
          </TableContainer>
        )}
      </TablePaper>

      <Modal
        open={!!modalProps}
        onOpenChange={() => setModalProps(undefined)}
        variant="popup"
      >
        {!!modalProps && (
          <RemoveMoneyMarketLiquidity
            {...modalProps}
            closable
            title={modalProps.title ?? t("withdraw")}
            onSubmitted={() => setModalProps(undefined)}
          />
        )}
      </Modal>
    </>
  )
}
