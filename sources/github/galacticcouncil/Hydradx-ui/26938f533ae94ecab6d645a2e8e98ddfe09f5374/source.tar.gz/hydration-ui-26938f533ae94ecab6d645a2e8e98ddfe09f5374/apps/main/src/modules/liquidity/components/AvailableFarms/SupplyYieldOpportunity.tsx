import {
  Chip,
  Flex,
  Paper,
  Separator,
  Text,
} from "@galacticcouncil/ui/components"
import { getToken } from "@galacticcouncil/ui/utils"
import Big from "big.js"
import { useTranslation } from "react-i18next"

import { BorrowAssetApyData } from "@/api/borrow"
import { TooltipAPR } from "@/modules/liquidity/components/Farms/TooltipAPR"
import { formatApyPercent } from "@/utils/formatApyPercent"

import { SYieldOpportunityContainer } from "./AvailableFarm.styled"

export const SupplyYieldOpportunity = ({
  borrowApyData,
  omnipoolFee,
  stablepoolFee,
}: {
  borrowApyData: BorrowAssetApyData
  omnipoolFee?: string
  stablepoolFee?: string
}) => {
  const { t } = useTranslation(["common", "liquidity"])

  const underlyingSupplyApy = borrowApyData.underlyingSupplyApy
  const value =
    underlyingSupplyApy === null
      ? null
      : Big(underlyingSupplyApy)
          .plus(omnipoolFee ?? 0)
          .plus(stablepoolFee ?? 0)
          .toNumber()

  return (
    <SYieldOpportunityContainer
      as={Paper}
      direction="column"
      gap="base"
      sx={{
        p: ["secondary", "primary"],
      }}
    >
      <Flex align="center" gap="base">
        <Text color={getToken("text.high")} fs="p2" fw={600}>
          {t("apy")}
        </Text>
        <Chip variant="green" size="small">
          <Flex align="center" gap="s"></Flex>
          {formatApyPercent(t, value)}

          <TooltipAPR
            borrowApyData={{ ...borrowApyData, incentives: [] }}
            omnipoolFee={omnipoolFee}
            stablepoolFee={stablepoolFee}
            farms={[]}
            iconColor={getToken("accents.success.emphasis")}
          />
        </Chip>
      </Flex>
      <Separator />
      <Text fs="p5" color={getToken("text.medium")} fw={400}>
        {t("liquidity:liquidity.supplyYieldOpportunity.apy.description")}
      </Text>
    </SYieldOpportunityContainer>
  )
}
