import { standardSchemaResolver } from "@hookform/resolvers/standard-schema"
import { useMutation } from "@tanstack/react-query"
import Big from "big.js"
import { useMemo } from "react"
import { useForm } from "react-hook-form"
import { useTranslation } from "react-i18next"
import { z } from "zod/v4"

import { TAssetData } from "@/api/assets"
import { useAccountBalances } from "@/api/balances"
import {
  useFormMaxBalanceWithFee,
  ValidateFormMaxBalanceWithFee,
} from "@/modules/transactions/hooks/useFormMaxBalanceWithFee"
import { TAsset, useAssets } from "@/providers/assetsProvider"
import { useRpcProvider } from "@/providers/rpcProvider"
import { useTransactionsStore } from "@/states/transactions"
import { scale } from "@/utils/formatting"
import { positive, required, requiredObject } from "@/utils/validators"

const schema = z.object({
  assetA: requiredObject<TAsset>(),
  amountA: required.pipe(positive),
  assetB: requiredObject<TAsset>(),
  amountB: required.pipe(positive),
})

export type CreateIsolatedPoolFormData = z.infer<typeof schema>

const useSchema = (validateBalance: ValidateFormMaxBalanceWithFee) => {
  return schema.check(
    validateBalance("amountA", (form) => [form.assetA, form.amountA]),
    validateBalance("amountB", (form) => [form.assetB, form.amountB]),
  )
}

const defaultValues: CreateIsolatedPoolFormData = {
  assetA: null,
  amountA: "",
  assetB: null,
  amountB: "",
}

export const useIsolatedPoolForm = () => {
  const { papi } = useRpcProvider()

  const createPoolTx = papi.tx.XYK.create_pool({
    asset_a: 0,
    amount_a: BigInt(scale("1", 12)),
    asset_b: 10,
    amount_b: BigInt(scale("1", 12)),
  })

  const { validateBalance, getMaxBalance } =
    useFormMaxBalanceWithFee(createPoolTx)

  const form = useForm<CreateIsolatedPoolFormData>({
    mode: "onChange",
    defaultValues,
    resolver: standardSchemaResolver(useSchema(validateBalance)),
  })

  return { form, getMaxBalance }
}

export const useSubmitCreateIsolatedPool = ({
  onSubmitted,
}: {
  onSubmitted: () => void
}) => {
  const { t } = useTranslation("liquidity")
  const { papi } = useRpcProvider()
  const createTransaction = useTransactionsStore((s) => s.createTransaction)

  return useMutation({
    mutationFn: async ({
      assetA,
      assetB,
      amountA,
      amountB,
    }: {
      assetA: TAssetData
      assetB: TAssetData
      amountA: string
      amountB: string
    }): Promise<void> => {
      const tx = papi.tx.XYK.create_pool({
        asset_a: Number(assetA.id),
        amount_a: BigInt(Big(amountA).toFixed(0)),
        asset_b: Number(assetB.id),
        amount_b: BigInt(Big(amountB).toFixed(0)),
      })

      const tOptions = { symbolA: assetA.symbol, symbolB: assetB.symbol }

      const toasts = {
        submitted: t("liquidity.createPool.toast.submitted", tOptions),
        success: t("liquidity.createPool.toast.success", tOptions),
      }

      await createTransaction(
        { tx, toasts, invalidateQueries: [["allPools"]] },
        { onSubmitted },
      )
    },
  })
}

export const createPoolExclusivityMap = (
  xykPoolsAssets: ReadonlyArray<readonly [a: string, idB: string]>,
): Readonly<Record<string, ReadonlyArray<string>>> =>
  xykPoolsAssets.reduce<Record<string, string[]>>((memo, [idA, idB]) => {
    if (!memo[idA]) {
      memo[idA] = []
    }
    if (!memo[idB]) {
      memo[idB] = []
    }
    if (!memo[idA].includes(idB)) {
      memo[idA].push(idB)
    }
    if (!memo[idB].includes(idA)) {
      memo[idB].push(idA)
    }
    return memo
  }, {})

export const filterIdsByExclusivity = (
  exclusiveId: string | undefined,
  assets: TAsset[],
  map: ReturnType<typeof createPoolExclusivityMap>,
) =>
  assets.filter(
    (asset) =>
      !exclusiveId ||
      (asset.id !== exclusiveId && !map[exclusiveId]?.includes(asset.id)),
  )

export const useAllowedXYKPoolAssets = () => {
  const { tradable } = useAssets()
  const { getTransferableBalance } = useAccountBalances()

  return useMemo(
    () => tradable.filter((asset) => getTransferableBalance(asset.id) > 0n),
    [tradable, getTransferableBalance],
  )
}
