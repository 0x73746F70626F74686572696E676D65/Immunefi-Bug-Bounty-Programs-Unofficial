import { SquareArrowOutUpRight } from "@galacticcouncil/ui/assets/icons"
import {
  ButtonIcon,
  ExternalLink,
  Flex,
  Icon,
  Text,
  Tooltip,
} from "@galacticcouncil/ui/components"
import { getToken } from "@galacticcouncil/ui/utils"
import { isMobileDevice, replaceAaveWithBorrow } from "@galacticcouncil/utils"
import { FC, ReactNode } from "react"
import { useTranslation } from "react-i18next"

import { DateText } from "@/components/RelativeDateText"
import {
  TransactionStatus,
  TransactionStatusMessage,
} from "@/components/TransactionItem/TransactionStatus"
import { TransactionStatusVariant } from "@/components/TransactionItem/TransactionStatus.styled"

type StatusProps =
  | {
      readonly status: TransactionStatusVariant.Success
      readonly sent: string
      readonly received: string
    }
  | {
      readonly status: Exclude<
        TransactionStatusVariant,
        TransactionStatusVariant.Success
      >
    }

type Props = StatusProps & {
  readonly timestamp: Date | null
  readonly message?: string | null
  readonly link?: string | null
  readonly className?: string
}

export const TransactionItemMobile: FC<Props> = ({
  timestamp,
  message,
  link,
  className,
  ...statusProps
}) => {
  const { t } = useTranslation()

  const [sent, received] =
    statusProps.status === TransactionStatusVariant.Success
      ? [statusProps.sent, statusProps.received]
      : [null, null]
  return (
    <TransactionItemMobileContainer>
      <Flex justify="space-between" flex={1} p="l" className={className}>
        <Flex direction="column" gap="xs">
          <Text fw={500} fs="p4" lh={1} color={getToken("text.high")}>
            {sent ?? "⎯"}
          </Text>
          {timestamp && (
            <DateText
              date={timestamp}
              fw={500}
              fs="p6"
              lh={1.4}
              color={getToken("text.low")}
            />
          )}
        </Flex>

        <Flex direction="column" justify="center" align="end" gap="s">
          {received && (
            <Text fw={500} fs="p4" lh={1} color={getToken("text.high")}>
              {received}
            </Text>
          )}
          <TransactionStatus variant={statusProps.status} />
          {message && (
            <TransactionStatusMessage
              variant={statusProps.status}
              sx={{ maxWidth: "200px", textAlign: "end" }}
            >
              {replaceAaveWithBorrow(message)}
            </TransactionStatusMessage>
          )}
        </Flex>
      </Flex>
      {link && (
        <TransactionItemMobileAction>
          <Tooltip
            text={isMobileDevice() ? null : t("openInExplorer")}
            size="small"
            asChild
            side="top"
          >
            <ButtonIcon asChild>
              <ExternalLink href={link}>
                <Icon
                  size="s"
                  component={SquareArrowOutUpRight}
                  color={getToken("text.high")}
                />
              </ExternalLink>
            </ButtonIcon>
          </Tooltip>
        </TransactionItemMobileAction>
      )}
    </TransactionItemMobileContainer>
  )
}

export const TransactionItemMobileContainer = ({
  children,
}: {
  readonly children: ReactNode
}) => {
  return (
    <Flex align="center" gap="s">
      {children}
    </Flex>
  )
}

export const TransactionItemMobileAction = ({
  children,
}: {
  readonly children?: ReactNode
}) => {
  return (
    <Flex width="2xl" align="center" justify="center">
      {children}
    </Flex>
  )
}
