export { DcaApp } from './App';
