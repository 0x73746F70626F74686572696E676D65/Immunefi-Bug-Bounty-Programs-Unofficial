import { getSigningClient, signTransactionWithWallet } from "./wallet.js";
import { resolveBroadcastResult, toSafeCallValueNumber, type BroadcastResponse } from "./contracts.js";

/**
 * Freeze TRX to obtain BANDWIDTH or ENERGY resources (Stake 2.0).
 * @param amount - Amount in Sun (as a decimal string for precision).
 * @param resource - "BANDWIDTH" or "ENERGY".
 * @returns Transaction hash.
 */
export async function freezeBalanceV2(
  amount: string,
  resource: "BANDWIDTH" | "ENERGY" = "BANDWIDTH",
  network = "mainnet",
) {
  const tronWeb = await getSigningClient(network);

  try {
    const transaction = await tronWeb.transactionBuilder.freezeBalanceV2(
      toSafeCallValueNumber(amount),
      resource,
      tronWeb.defaultAddress.base58 || undefined,
    );
    const signedTx = await signTransactionWithWallet(transaction, undefined, network);
    const broadcast = (await tronWeb.trx.sendRawTransaction(signedTx)) as BroadcastResponse;
    const { txID } = resolveBroadcastResult(broadcast, transaction.txID);
    return txID;
  } catch (error: any) {
    throw new Error(`Failed to freeze balance V2: ${error.message}`);
  }
}

/**
 * Unfreeze staked TRX to release resources (Stake 2.0).
 * @param amount - Amount in Sun (as a decimal string for precision).
 * @param resource - "BANDWIDTH" or "ENERGY".
 * @returns Transaction hash.
 */
export async function unfreezeBalanceV2(
  amount: string,
  resource: "BANDWIDTH" | "ENERGY" = "BANDWIDTH",
  network = "mainnet",
) {
  const tronWeb = await getSigningClient(network);

  try {
    const transaction = await tronWeb.transactionBuilder.unfreezeBalanceV2(
      toSafeCallValueNumber(amount),
      resource,
      tronWeb.defaultAddress.base58 || undefined,
    );
    const signedTx = await signTransactionWithWallet(transaction, undefined, network);
    const broadcast = (await tronWeb.trx.sendRawTransaction(signedTx)) as BroadcastResponse;
    const { txID } = resolveBroadcastResult(broadcast, transaction.txID);
    return txID;
  } catch (error: any) {
    throw new Error(`Failed to unfreeze balance V2: ${error.message}`);
  }
}

/**
 * Withdraw expired unfrozen balance after the unbonding period ends (Stake 2.0).
 * @returns Transaction hash.
 */
export async function withdrawExpireUnfreeze(network = "mainnet") {
  const tronWeb = await getSigningClient(network);

  try {
    const transaction = await tronWeb.transactionBuilder.withdrawExpireUnfreeze(
      tronWeb.defaultAddress.base58 || undefined,
    );
    const signedTx = await signTransactionWithWallet(transaction, undefined, network);
    const broadcast = (await tronWeb.trx.sendRawTransaction(signedTx)) as BroadcastResponse;
    const { txID } = resolveBroadcastResult(broadcast, transaction.txID);
    return txID;
  } catch (error: any) {
    throw new Error(`Failed to withdraw expire unfreeze: ${error.message}`);
  }
}
