/**
 * JustLend V1 Lending Operations
 *
 * VERSION: JustLend V1
 * All lending methods (supply, withdraw, borrow, repay, collateral management) are for JustLend V1.
 * Based on Compound V2 protocol architecture with jToken (cToken) mechanism.
 */

import { getTronWeb } from "./clients.js";
import { getSigningClient } from "./wallet.js";
import { safeSend, toSafeCallValueNumber } from "./contracts.js";
import { approveWithReset } from "./allowance.js";
import { getJustLendAddresses, getJTokenInfo, getAllJTokens, type JTokenInfo } from "../chains.js";
import { JTOKEN_ABI, JTRX_MINT_ABI, JTRX_REPAY_ABI, COMPTROLLER_ABI, TRC20_ABI, PRICE_ORACLE_ABI } from "../abis.js";
import { utils } from "./utils.js";
import { addressesEqual } from "./address.js";
import { fetchWithTimeout } from "./http.js";
import { getResourcePrices, type ResourcePrices } from "./resource-prices.js";
import {
  MANTISSA_18, USD_PRICE_SCALE, USD_VALUE_SCALE,
  divRound, formatScaled, formatDisplayUnits,
  formatUsdCents, formatPriceUSD, formatPercentRatio,
  amountToUsdCents, normalizeDecimalString, buildCollateralBreakdown,
} from "./bigint-math.js";

const MAX_UINT256 = "115792089237316195423570985008687907853269984665640564039457584007913129639935";

async function waitForTx(txID: string, network: string, maxRetries = 20, intervalMs = 3000): Promise<any> {
  const { getTronWeb } = await import("./clients.js");
  const tronWeb = getTronWeb(network);

  for (let i = 0; i < maxRetries; i++) {
    try {
      const info = await tronWeb.trx.getTransactionInfo(txID);
      if (info && info.id) return info;
    } catch { /* not found yet */ }
    await new Promise((r) => setTimeout(r, intervalMs));
  }
  throw new Error(`Transaction ${txID} not confirmed after ${maxRetries * intervalMs / 1000}s`);
}

async function parseTxEvents(txID: string, network: string): Promise<any[]> {
  const info = await waitForTx(txID, network);
  if (!info.log || info.log.length === 0) return [];

  const events: any[] = [];
  const FAILURE_TOPIC = "45b96fe442630264581b197e84bbada861235052c5a1aadfff9ea4e40a969aa0";

  for (const log of info.log) {
    const topics = log.topics || [];
    if (topics.length > 0 && topics[0] === FAILURE_TOPIC) {
      const error = parseInt(log.data?.slice(0, 64) || "0", 16);
      const infoVal = parseInt(log.data?.slice(64, 128) || "0", 16);
      const detail = parseInt(log.data?.slice(128, 192) || "0", 16);
      events.push({
        name: "Failure",
        params: { error, info: infoVal, detail },
        message: `Contract returned Failure: error=${error}, info=${infoVal}, detail=${detail}`,
      });
    } else {
      events.push({
        name: "Unknown",
        topics,
        data: log.data,
        address: log.address,
      });
    }
  }
  return events;
}

function resolveJToken(symbolOrAddress: string, network: string): JTokenInfo {
  const info = getJTokenInfo(symbolOrAddress, network);
  if (!info) throw new Error(`Unknown jToken market: ${symbolOrAddress}. Use get_supported_markets to list available markets.`);
  return info;
}

// ============================================================================
// PRICE ORACLE FALLBACK HELPERS (Injected to fix Nile testnet $0 collateral bug)
// ============================================================================

async function fetchPriceRawFromAPI(underlyingSymbol: string, network: string): Promise<bigint> {
  const tryFetch = async (targetNetwork: string) => {
    const host = targetNetwork === "nile" ? "https://nileapi.justlend.org" : "https://labc.ablesdxd.link";
    const resp = await fetchWithTimeout(`${host}/justlend/markets`);
    const data = await resp.json();
    if (data.code !== 0 || !data.data || !data.data.jtokenList) return 0n;

    const market = data.data.jtokenList.find((m: any) =>
      m.collateralSymbol.toUpperCase() === underlyingSymbol.toUpperCase()
    );
    if (!market) return 0n;

    const depositedUSD = normalizeDecimalString(market.depositedUSD || "0");
    const totalSupplyRaw = BigInt(market.totalSupply || 0);
    const exchangeRateRaw = BigInt(market.exchangeRate || 0);

    if (depositedUSD === "0" || totalSupplyRaw === 0n || exchangeRateRaw === 0n) return 0n;

    const underlyingRaw = totalSupplyRaw * exchangeRateRaw / MANTISSA_18;
    if (underlyingRaw === 0n) return 0n;

    const depositedUsdScaled = utils.parseUnits(depositedUSD, 18);
    return divRound(depositedUsdScaled * MANTISSA_18, underlyingRaw);
  };

  try {
    const price = await tryFetch(network);
    if (price > 0n) return price;
  } catch (err: any) {
    console.warn(`[fetchPriceRawFromAPI] primary lookup failed (network=${network}): ${err?.message ?? err}`);
  }

  if (network === "nile") {
    try {
      const mainnetPrice = await tryFetch("mainnet");
      if (mainnetPrice > 0n) return mainnetPrice;
    } catch (err: any) {
      console.warn(`[fetchPriceRawFromAPI] mainnet fallback failed: ${err?.message ?? err}`);
    }
  }
  return 0n;
}

async function getAssetPriceData(
  tronWeb: any,
  oracleAddress: string,
  assetAddress: string,
  assetInfo: JTokenInfo | undefined,
  network: string,
): Promise<{ raw: bigint; display: string }> {
  let priceRaw = 0n;

  try {
    const oracle = tronWeb.contract(PRICE_ORACLE_ABI, oracleAddress);
    priceRaw = BigInt(await oracle.methods.getUnderlyingPrice(assetAddress).call());
  } catch (err: any) {
    console.warn(`[getAssetPriceData] on-chain oracle read failed for ${assetAddress}: ${err?.message ?? err}`);
  }

  if (priceRaw > 0n && network === "mainnet") {
  } else if (assetInfo) {
    priceRaw = await fetchPriceRawFromAPI(assetInfo.underlyingSymbol, network);
  }

  const underlyingDecimals = assetInfo ? assetInfo.underlyingDecimals : 18;
  return {
    raw: priceRaw,
    display: formatPriceUSD(priceRaw, underlyingDecimals),
  };
}

// ============================================================================
// SUPPLY (Mint jTokens)
// ============================================================================

export async function supply(
  jTokenSymbol: string,
  amount: string,
  network = "mainnet",
): Promise<{ txID: string; jTokenSymbol: string; amount: string; message: string }> {
  const info = resolveJToken(jTokenSymbol, network);
  const tronWeb = await getSigningClient(network);
  const amountRaw = utils.parseUnits(amount, info.underlyingDecimals);
  const walletAddress = tronWeb.defaultAddress.base58 as string;

  if (info.underlyingSymbol === "TRX" || !info.underlying) {
    const balanceSun = await tronWeb.trx.getBalance(walletAddress);
    const supplyTypical = getTypicalResources("supply", true);
    const supplyResourceCheck = await checkResourceSufficiency(walletAddress, supplyTypical.energy, supplyTypical.bandwidth, network);
    const supplyGasSun = BigInt(Math.ceil((parseFloat(supplyResourceCheck.energyBurnTRX) + parseFloat(supplyResourceCheck.bandwidthBurnTRX)) * 1e6));
    const needed = BigInt(amountRaw.toString()) + supplyGasSun;
    if (BigInt(balanceSun) < needed) {
      throw new Error(
        `Insufficient TRX balance. Have ${formatDisplayUnits(BigInt(balanceSun), 6)} TRX, need ~${formatDisplayUnits(needed, 6)} TRX (supply + estimated gas)`,
      );
    }

    const { txID } = await safeSend({
      address: info.address,
      abi: JTRX_MINT_ABI,
      functionName: "mint",
      callValue: amountRaw.toString(),
    }, network);
    return { txID, jTokenSymbol, amount, message: `Supplied ${amount} TRX to ${jTokenSymbol}. IMPORTANT: Please call get_account_summary to see your updated position and health factor.` };
  } else {
    const token = tronWeb.contract(TRC20_ABI, info.underlying);
    const balance = BigInt(await token.methods.balanceOf(walletAddress).call());
    if (balance < BigInt(amountRaw.toString())) {
      throw new Error(
        `Insufficient ${info.underlyingSymbol} balance. Have ${utils.formatUnits(balance.toString(), info.underlyingDecimals)}, need ${amount}`,
      );
    }

    const allowance = BigInt(await token.methods.allowance(walletAddress, info.address).call());
    const formattedAllowance = utils.formatUnits(allowance.toString(), info.underlyingDecimals);
    if (allowance < BigInt(amountRaw.toString())) {
      throw new Error(
        `Insufficient ${info.underlyingSymbol} allowance for ${jTokenSymbol}. Current allowance: ${formattedAllowance}. You need to approve at least ${amount} ${info.underlyingSymbol}. Please call approve_underlying first.`,
      );
    }

    const { txID } = await safeSend({
      address: info.address,
      abi: JTOKEN_ABI,
      functionName: "mint",
      args: [amountRaw.toString()],
    }, network);
    return { txID, jTokenSymbol, amount, message: `Supplied ${amount} ${info.underlyingSymbol} to ${jTokenSymbol}. IMPORTANT: Please call get_account_summary to see your updated position and health factor.` };
  }
}

// ============================================================================
// WITHDRAW (Redeem jTokens)
// ============================================================================

export async function withdraw(
  jTokenSymbol: string,
  amount: string,
  network = "mainnet",
): Promise<{ txID: string; jTokenSymbol: string; amount: string; message: string }> {
  const info = resolveJToken(jTokenSymbol, network);
  const tronWeb = await getSigningClient(network);
  const amountRaw = utils.parseUnits(amount, info.underlyingDecimals);
  const walletAddress = tronWeb.defaultAddress.base58 as string;

  const contract = tronWeb.contract(JTOKEN_ABI, info.address);
  const jTokenBalance = BigInt(await contract.methods.balanceOf(walletAddress).call());
  const exchangeRate = BigInt(await contract.methods.exchangeRateStored().call());
  const supplyBalance = (jTokenBalance * exchangeRate) / BigInt(1e18);
  if (supplyBalance < BigInt(amountRaw.toString())) {
    throw new Error(
      `Insufficient supply balance in ${jTokenSymbol}. Have ${utils.formatUnits(supplyBalance.toString(), info.underlyingDecimals)} ${info.underlyingSymbol}, want to withdraw ${amount}`,
    );
  }

  const { txID } = await safeSend({
    address: info.address,
    abi: JTOKEN_ABI,
    functionName: "redeemUnderlying",
    args: [amountRaw.toString()],
  }, network);
  return { txID, jTokenSymbol, amount, message: `Withdrew ${amount} ${info.underlyingSymbol} from ${jTokenSymbol}. IMPORTANT: Please call get_account_summary to see your updated position and health factor.` };
}

export async function withdrawAll(
  jTokenSymbol: string,
  network = "mainnet",
): Promise<{ txID: string; jTokenSymbol: string; message: string }> {
  const info = resolveJToken(jTokenSymbol, network);
  const tronWeb = await getSigningClient(network);

  const contract = tronWeb.contract(JTOKEN_ABI, info.address);
  const walletAddress = tronWeb.defaultAddress.base58;
  const jTokenBalance = await contract.methods.balanceOf(walletAddress).call();

  if (BigInt(jTokenBalance) === 0n) {
    throw new Error(`No ${jTokenSymbol} balance to withdraw`);
  }

  const { txID } = await safeSend({
    address: info.address,
    abi: JTOKEN_ABI,
    functionName: "redeem",
    args: [jTokenBalance.toString()],
  }, network);
  return { txID, jTokenSymbol, message: `Withdrew all supply from ${jTokenSymbol}. IMPORTANT: Please call get_account_summary to see your updated position and health factor.` };
}

// ============================================================================
// BORROW
// ============================================================================

export async function borrow(
  jTokenSymbol: string,
  amount: string,
  network = "mainnet",
): Promise<{ txID: string; jTokenSymbol: string; amount: string; message: string }> {
  const info = resolveJToken(jTokenSymbol, network);
  const tronWeb = await getSigningClient(network);
  const amountRaw = utils.parseUnits(amount, info.underlyingDecimals);
  const walletAddress = tronWeb.defaultAddress.base58;

  const addresses = getJustLendAddresses(network);
  const comptroller = tronWeb.contract(COMPTROLLER_ABI, addresses.comptroller);

  const oracleAddressHex = await comptroller.methods.oracle().call();
  const realOracleAddress = tronWeb.address.fromHex(oracleAddressHex);

  const assetsInRaw: string[] = await comptroller.methods.getAssetsIn(walletAddress).call();

  if (assetsInRaw.length === 0) {
    throw new Error(
      `No borrowing capacity. You need to supply assets and enable them as collateral (enter_market) before borrowing.`
    );
  }

  interface CollateralDetail {
    symbol: string;
    supplyValueCents: bigint;
    collateralFactorMantissa: bigint;
    adjustedValueCents: bigint;
    borrowBalanceCents: bigint;
  }

  const liquidityResult = await comptroller.methods.getAccountLiquidity(walletAddress).call();
  const availableLiquidityRaw = BigInt(liquidityResult.liquidity || liquidityResult[1] || 0);
  const collateralDetails: CollateralDetail[] = [];
  let totalAdjustedCollateralCents = 0n;
  let totalBorrowCents = 0n;

  for (const rawAsset of assetsInRaw) {
    try {
      // Core fix: convert the raw hex address into the standard T-prefixed address
      const asset = tronWeb.address.fromHex(rawAsset);

      const assetInfo = getJTokenInfo(asset, network);
      const jToken = tronWeb.contract(JTOKEN_ABI, asset);
      const snapshot = await jToken.methods.getAccountSnapshot(walletAddress).call();

      const jTokenBalance = BigInt(snapshot[1] ?? snapshot.jTokenBalance ?? 0);
      const borrowBalance = BigInt(snapshot[2] ?? snapshot.borrowBalance ?? 0);
      const exchangeRateMantissa = BigInt(snapshot[3] ?? snapshot.exchangeRateMantissa ?? 0);
      const supplyBalanceRaw = jTokenBalance * exchangeRateMantissa / MANTISSA_18;

      const assetPrice = await getAssetPriceData(tronWeb, realOracleAddress, asset, assetInfo, network);

      const marketInfo = await comptroller.methods.markets(asset).call();
      const collateralFactorMantissa = BigInt(marketInfo.collateralFactorMantissa || marketInfo[1] || 0);
      const supplyValueCents = amountToUsdCents(supplyBalanceRaw, assetPrice.raw);
      const adjustedValueCents = divRound(supplyValueCents * collateralFactorMantissa, MANTISSA_18);
      const borrowBalanceCents = amountToUsdCents(borrowBalance, assetPrice.raw);

      totalAdjustedCollateralCents += adjustedValueCents;
      totalBorrowCents += borrowBalanceCents;

      const label = assetInfo ? assetInfo.underlyingSymbol : asset;
      collateralDetails.push({
        symbol: label,
        supplyValueCents,
        collateralFactorMantissa,
        adjustedValueCents,
        borrowBalanceCents,
      });
    } catch (e: any) {
      console.warn(`[Borrow Debug] Skipped asset ${rawAsset}: ${e?.message ?? e}`);
    }
  }

  const availableLiquidityCents = divRound(availableLiquidityRaw * 100n, MANTISSA_18);

  if (availableLiquidityRaw <= 0n) {
    const breakdown = buildCollateralBreakdown(collateralDetails);

    throw new Error(
      `No borrowing capacity. Total adjusted collateral: $${formatUsdCents(totalAdjustedCollateralCents)}, ` +
      `total borrows: $${formatUsdCents(totalBorrowCents)}, available: $${formatUsdCents(availableLiquidityCents)}. ` +
      `Breakdown: [${breakdown}]. ` +
      `Supply more collateral or repay existing borrows first.`
    );
  }

  const targetPrice = await getAssetPriceData(tronWeb, realOracleAddress, info.address, info, network);

  if (targetPrice.raw === 0n) {
    throw new Error(`Cannot fetch price for ${info.underlyingSymbol}. Unable to verify borrowing capacity.`);
  }

  const maxBorrowableRaw = availableLiquidityRaw * MANTISSA_18 / targetPrice.raw;

  if (amountRaw > maxBorrowableRaw) {
    const breakdown = buildCollateralBreakdown(collateralDetails);
    const requestedBorrowCents = amountToUsdCents(amountRaw, targetPrice.raw);

    throw new Error(
      `Insufficient borrowing capacity. Requested: ${amount} ${info.underlyingSymbol} (~$${formatUsdCents(requestedBorrowCents)}), ` +
      `max borrowable: ~${formatDisplayUnits(maxBorrowableRaw, info.underlyingDecimals)} ${info.underlyingSymbol} ` +
      `(~$${formatUsdCents(availableLiquidityCents)}). ` +
      `${info.underlyingSymbol} price: $${targetPrice.display}. ` +
      `Collateral breakdown: [${breakdown}]. ` +
      `Supply more collateral or reduce borrow amount.`
    );
  }

  const { txID } = await safeSend({
    address: info.address,
    abi: JTOKEN_ABI,
    functionName: "borrow",
    args: [amountRaw.toString()],
  }, network);
  return { txID, jTokenSymbol, amount, message: `Borrowed ${amount} ${info.underlyingSymbol} from ${jTokenSymbol}. IMPORTANT: Please call get_account_summary to see your updated position and health factor.` };
}

// ============================================================================
// REPAY
// ============================================================================

export async function repay(
  jTokenSymbol: string,
  amount: string,
  network = "mainnet",
): Promise<{ txID: string; jTokenSymbol: string; amount: string; message: string }> {
  const info = resolveJToken(jTokenSymbol, network);
  const tronWeb = await getSigningClient(network);

  const isMax = amount === "-1" || amount.toLowerCase() === "max";

  const contract = tronWeb.contract(JTOKEN_ABI, info.address);
  const walletAddress = tronWeb.defaultAddress.base58;
  const borrowBal = BigInt(await contract.methods.borrowBalanceStored(walletAddress).call());

  if (borrowBal === 0n) {
    throw new Error(`No outstanding ${info.underlyingSymbol} borrow on ${jTokenSymbol}. Nothing to repay.`);
  }

  if (!isMax) {
    const repayRaw = BigInt(utils.parseUnits(amount, info.underlyingDecimals).toString());
    if (info.underlyingSymbol === "TRX" || !info.underlying) {
      const balanceSun = await tronWeb.trx.getBalance(walletAddress as string);
      const repayTypical = getTypicalResources("repay", true);
      const repayResourceCheck = await checkResourceSufficiency(walletAddress as string, repayTypical.energy, repayTypical.bandwidth, network);
      const repayGasSun = BigInt(Math.ceil((parseFloat(repayResourceCheck.energyBurnTRX) + parseFloat(repayResourceCheck.bandwidthBurnTRX)) * 1e6));
      const needed = repayRaw + repayGasSun;
      if (BigInt(balanceSun) < needed) {
        throw new Error(
          `Insufficient TRX balance for repayment. Have ${formatDisplayUnits(BigInt(balanceSun), 6)} TRX, need ~${formatDisplayUnits(needed, 6)} TRX (repay + estimated gas)`
        );
      }
    } else {
      const token = tronWeb.contract(TRC20_ABI, info.underlying);
      const tokenBal = BigInt(await token.methods.balanceOf(walletAddress).call());
      if (tokenBal < repayRaw) {
        throw new Error(
          `Insufficient ${info.underlyingSymbol} balance for repayment. Have ${utils.formatUnits(tokenBal.toString(), info.underlyingDecimals)}, need ${amount}`
        );
      }
    }
  }

  if (info.underlyingSymbol === "TRX" || !info.underlying) {
    const repayAmount = isMax
      ? borrowBal + borrowBal / 1000n
      : utils.parseUnits(amount, info.underlyingDecimals);

    // Fix: TRX repayment matches the dapp frontend.
    // The dapp uses repayBorrow(uint256) + parameters: [amount] + callValue: amount,
    // passing both the argument and callValue.
    const { txID } = await safeSend({
      address: info.address,
      abi: JTRX_REPAY_ABI,                // use the payable ABI, matching the contract signature
      functionName: "repayBorrow",
      args: [repayAmount.toString()],     // pass the amount argument, matching the dapp frontend
      callValue: repayAmount.toString(),   // also send TRX via callValue
      feeLimit: 150_000_000,
    }, network);
    return { txID, jTokenSymbol, amount: isMax ? "max" : amount, message: `Repaid ${isMax ? "all" : amount} TRX to ${jTokenSymbol}. IMPORTANT: Please call get_account_summary to see your updated position and health factor.` };
  } else {
    const repayAmount = isMax ? MAX_UINT256 : utils.parseUnits(amount, info.underlyingDecimals).toString();
    const { txID } = await safeSend({
      address: info.address,
      abi: JTOKEN_ABI,
      functionName: "repayBorrow",
      args: [repayAmount],
      feeLimit: 300_000_000,
    }, network);
    return { txID, jTokenSymbol, amount: isMax ? "max" : amount, message: `Repaid ${isMax ? "all" : amount} ${info.underlyingSymbol} to ${jTokenSymbol}. IMPORTANT: Please call get_account_summary to see your updated position and health factor.` };
  }
}

// ============================================================================
// COLLATERAL MANAGEMENT (Enter/Exit Markets)
// ============================================================================

export async function enterMarket(
  jTokenSymbol: string,
  network = "mainnet",
): Promise<{ txID?: string; message: string }> {
  const info = resolveJToken(jTokenSymbol, network);
  const tronWeb = await getSigningClient(network);
  const addresses = getJustLendAddresses(network);

  const comptroller = tronWeb.contract(COMPTROLLER_ABI, addresses.comptroller);
  const walletAddress = tronWeb.defaultAddress.base58;
  const isMember = await comptroller.methods.checkMembership(walletAddress, info.address).call();
  if (isMember) {
    return { message: `${jTokenSymbol} is already enabled as collateral, no need to enable again.` };
  }

  const { txID } = await safeSend({
    address: addresses.comptroller,
    abi: COMPTROLLER_ABI,
    functionName: "enterMarkets",
    args: [[info.address]],
  }, network);
  return { txID, message: `Enabled ${jTokenSymbol} as collateral` };
}

export async function exitMarket(
  jTokenSymbol: string,
  network = "mainnet",
): Promise<{ txID?: string; message: string; events?: any[] }> {
  const info = resolveJToken(jTokenSymbol, network);
  const tronWeb = await getSigningClient(network);
  const addresses = getJustLendAddresses(network);

  const comptroller = tronWeb.contract(COMPTROLLER_ABI, addresses.comptroller);
  const walletAddress = tronWeb.defaultAddress.base58;

  const isMember = await comptroller.methods.checkMembership(walletAddress, info.address).call();
  if (!isMember) {
    return { message: `${jTokenSymbol} is not currently enabled as collateral, no need to disable.` };
  }

  const jToken = tronWeb.contract(JTOKEN_ABI, info.address);
  const snapshot = await jToken.methods.getAccountSnapshot(walletAddress).call();
  const borrowBalance = BigInt(snapshot[2] ?? snapshot.borrowBalance ?? 0);
  if (borrowBalance > 0n) {
    throw new Error(
      `Cannot disable ${jTokenSymbol} as collateral: you have an outstanding borrow of ${formatDisplayUnits(borrowBalance, info.underlyingDecimals)} ${info.underlyingSymbol} in this market. ` +
      `Please repay the borrow first before disabling collateral.`
    );
  }

  const oracleAddressHex = await comptroller.methods.oracle().call();
  const realOracleAddress = tronWeb.address.fromHex(oracleAddressHex);

  const assetsInRaw: string[] = await comptroller.methods.getAssetsIn(walletAddress).call();

  let totalAdjustedCollateralCents = 0n;
  let totalBorrowCents = 0n;
  let removedCollateralCents = 0n;
  const skippedMarkets: string[] = [];

  for (const rawAsset of assetsInRaw) {
    try {
      // Core fix: hex conversion
      const asset = tronWeb.address.fromHex(rawAsset);

      const assetInfo = getJTokenInfo(asset, network);
      const assetJToken = tronWeb.contract(JTOKEN_ABI, asset);
      const assetSnapshot = await assetJToken.methods.getAccountSnapshot(walletAddress).call();

      const jTokenBal = BigInt(assetSnapshot[1] ?? assetSnapshot.jTokenBalance ?? 0);
      const borrowBal = BigInt(assetSnapshot[2] ?? assetSnapshot.borrowBalance ?? 0);
      const exchangeRateMantissa = BigInt(assetSnapshot[3] ?? assetSnapshot.exchangeRateMantissa ?? 0);

      const supplyBalanceRaw = jTokenBal * exchangeRateMantissa / MANTISSA_18;

      const assetPrice = await getAssetPriceData(tronWeb, realOracleAddress, asset, assetInfo, network);

      const marketInfo = await comptroller.methods.markets(asset).call();
      const collateralFactorMantissa = BigInt(marketInfo.collateralFactorMantissa || marketInfo[1] || 0);
      const supplyValueCents = amountToUsdCents(supplyBalanceRaw, assetPrice.raw);
      const adjustedValueCents = divRound(supplyValueCents * collateralFactorMantissa, MANTISSA_18);
      const borrowBalanceCents = amountToUsdCents(borrowBal, assetPrice.raw);

      totalAdjustedCollateralCents += adjustedValueCents;
      totalBorrowCents += borrowBalanceCents;

      if (addressesEqual(asset, info.address)) {
        removedCollateralCents = adjustedValueCents;
      }
    } catch (err: any) {
      // Don't silently drop a market: an unread borrow position would under-count
      // total borrows and make disabling collateral look safe when it isn't.
      skippedMarkets.push(rawAsset);
      console.warn(`[disableCollateral] skipped market ${rawAsset} (read failed): ${err?.message ?? err}`);
    }
  }

  // Fail closed: never decide "safe to disable" on incomplete risk data.
  if (skippedMarkets.length > 0) {
    throw new Error(
      `Cannot safely verify the effect of disabling ${jTokenSymbol} as collateral: ` +
      `${skippedMarkets.length} market(s) failed to load, so collateral/borrow totals are incomplete. ` +
      `Please retry; refusing to disable collateral on incomplete on-chain data.`,
    );
  }

  if (totalBorrowCents > 0n) {
    const remainingCollateralCents = totalAdjustedCollateralCents - removedCollateralCents;
    if (remainingCollateralCents < totalBorrowCents) {
      const currentRatio = remainingCollateralCents > 0n
        ? formatPercentRatio(totalBorrowCents, remainingCollateralCents)
        : "∞";
      throw new Error(
        `Cannot disable ${jTokenSymbol} as collateral: doing so would make your account undercollateralized. ` +
        `After removing ${jTokenSymbol} collateral ($${formatUsdCents(removedCollateralCents)}), ` +
        `remaining collateral: $${formatUsdCents(remainingCollateralCents)}, total borrows: $${formatUsdCents(totalBorrowCents)}, ` +
        `borrow risk would be ${currentRatio}% (must be < 100%). ` +
        `Please repay some borrows or add more collateral first.`
      );
    }
  }

  const { txID } = await safeSend({
    address: addresses.comptroller,
    abi: COMPTROLLER_ABI,
    functionName: "exitMarket",
    args: [info.address],
  }, network);

  const events = await parseTxEvents(txID, network);
  return { txID, message: `Disabled ${jTokenSymbol} as collateral`, events };
}

// ============================================================================
// APPROVE (TRC20 underlying for jToken)
// ============================================================================

export async function approveUnderlying(
  jTokenSymbol: string,
  amount: string,
  network = "mainnet",
): Promise<{ txID: string; message: string; warning?: string }> {
  const info = resolveJToken(jTokenSymbol, network);
  if (!info.underlying) throw new Error(`${jTokenSymbol} is native TRX — no approval needed`);

  if (amount === undefined || amount === null || amount === "") {
    throw new Error(
      `approve_underlying requires an explicit amount. Pass the exact value you intend to supply/repay ` +
      `(e.g. amount='100'), or pass amount='max' to grant unlimited allowance (NOT recommended — see warning).`,
    );
  }

  const tronWeb = await getSigningClient(network);
  const walletAddress = tronWeb.defaultAddress.base58 as string;
  const token = tronWeb.contract(TRC20_ABI, info.underlying);

  const isMax = amount.toLowerCase() === "max";
  const currentAllowance = BigInt(await token.methods.allowance(walletAddress, info.address).call());
  const approveAmount = isMax
    ? MAX_UINT256
    : utils.parseUnits(amount, info.underlyingDecimals).toString();

  // Skip only when we already hold enough for a *non-zero* target. A revoke
  // (amount='0' → approveAmount '0') must never be swallowed here — it has to
  // reach the approve(0) below to actually lower the allowance.
  if (BigInt(approveAmount) > 0n && currentAllowance >= BigInt(approveAmount)) {
    return {
      txID: "",
      message: `${info.underlyingSymbol} already has sufficient allowance (${utils.formatUnits(currentAllowance.toString(), info.underlyingDecimals)}) for ${jTokenSymbol}. No approve needed.`,
    };
  }

  const { txID, resetTxID } = await approveWithReset({
    tokenAddress: info.underlying!,
    spender: info.address,
    approveRaw: approveAmount,
    currentAllowance,
    symbol: info.underlyingSymbol,
    network,
  });
  const action = BigInt(approveAmount) === 0n
    ? `Revoked ${info.underlyingSymbol} allowance for ${jTokenSymbol}`
    : `Approved ${isMax ? "unlimited" : amount} ${info.underlyingSymbol} for ${jTokenSymbol}`;
  const result: { txID: string; message: string; warning?: string } = {
    txID,
    message: resetTxID
      ? `${action} (existing allowance reset to 0 first — reset TX: ${resetTxID}).`
      : action,
  };
  if (isMax) {
    result.warning =
      `⚠️ UNLIMITED APPROVAL granted. The ${jTokenSymbol} contract can now spend your entire ` +
      `${info.underlyingSymbol} balance — present and future — without further confirmation. ` +
      `If you no longer need this, revoke with: approve_underlying market='${jTokenSymbol}' amount='0'.`;
  }
  return result;
}

// ============================================================================
// CLAIM REWARDS
// ============================================================================

export async function claimRewards(
  network = "mainnet",
): Promise<{ txID: string; message: string }> {
  const tronWeb = await getSigningClient(network);
  const addresses = getJustLendAddresses(network);
  const walletAddress = tronWeb.defaultAddress.base58;

  const { txID } = await safeSend({
    address: addresses.comptroller,
    abi: COMPTROLLER_ABI,
    functionName: "claimReward",
    args: [walletAddress],
  }, network);
  return { txID, message: `Claimed JustLend rewards for ${walletAddress}` };
}

// ============================================================================
// RESOURCE ESTIMATION (Energy + Bandwidth + TRX Cost)
// ============================================================================

const TYPICAL_RESOURCES: Record<string, { energy: number; bandwidth: number }> = {
  approve: { energy: 23000, bandwidth: 265 },
  supply_trx: { energy: 80000, bandwidth: 280 },
  supply_trc20: { energy: 100000, bandwidth: 310 },
  withdraw: { energy: 90000, bandwidth: 300 },
  withdraw_all: { energy: 90000, bandwidth: 300 },
  borrow: { energy: 100000, bandwidth: 313 },
  repay_trx: { energy: 80000, bandwidth: 280 },
  repay_trc20: { energy: 90000, bandwidth: 320 },
  enter_market: { energy: 80000, bandwidth: 300 },
  exit_market: { energy: 50000, bandwidth: 280 },
  claim_rewards: { energy: 60000, bandwidth: 330 },
};

interface StepEstimate {
  step: string;
  description: string;
  energyEstimate: number;
  energyBase: number;
  energyPenalty: number;
  bandwidthEstimate: number;
  energySource: "simulation" | "typical";
  simulationError?: string;
}

export interface ResourceEstimation {
  operation: string;
  market: string;
  steps: StepEstimate[];
  totalEnergy: number;
  totalBandwidth: number;
  estimatedTRXCost: string;
  costBreakdown: {
    energyCostTRX: string;
    bandwidthCostTRX: string;
    note: string;
  };
  note: string;
}

const DATA_HEX_PROTOBUF_EXTRA = 3;
const SIGNATURE_PER_BANDWIDTH = 67;
const MAX_RESULT_SIZE_IN_TX = 64;
const FEE_LIMIT_PROTOBUF_EXTRA = 6;

function encodeParams(tronWeb: any, params: Array<{ type: string; value: any }>): string {
  if (!params || params.length === 0) return "";
  try {
    const types = params.map(p => p.type);
    const values = params.map(p => p.value);
    const hex = tronWeb.utils.abi.encodeParams(types, values);
    return typeof hex === "string" && hex.startsWith("0x") ? hex.slice(2) : hex;
  } catch {
    return "";
  }
}

async function trySimulateEnergy(
  tronWeb: any,
  ownerAddress: string,
  contractAddress: string,
  functionSelector: string,
  params: Array<{ type: string; value: any }>,
  options: any = {},
  _network = "mainnet",
): Promise<{ energy: number | null; energyPenalty: number; bandwidth: number | null; error?: string }> {
  const parameter = encodeParams(tronWeb, params);
  // Use the same safe-integer guard as safeSend's broadcast path so the
  // simulation either matches what we will broadcast, or throws here cleanly
  // for values beyond Number.MAX_SAFE_INTEGER instead of silently truncating.
  const callValue = toSafeCallValueNumber(options.callValue);

  const requestBody: Record<string, any> = {
    owner_address: tronWeb.address.toHex(ownerAddress),
    contract_address: tronWeb.address.toHex(contractAddress),
    function_selector: functionSelector,
    parameter,
    call_value: callValue,
    visible: false,
  };

  const [estimateResult, simResult] = await Promise.allSettled([
    tronWeb.transactionBuilder.estimateEnergy(
      contractAddress,
      functionSelector,
      options,
      params,
      ownerAddress,
    ),
    tronWeb.fullNode.request('wallet/triggerconstantcontract', requestBody, 'post'),
  ]);

  const estimateData = estimateResult.status === "fulfilled" ? estimateResult.value : null;
  const simData = simResult.status === "fulfilled" ? simResult.value : null;

  const estimatedEnergy = (estimateData?.energy_required > 0) ? estimateData.energy_required : null;

  let energy: number | null = null;
  let energyPenalty = 0;
  let bandwidth: number | null = null;
  let error: string | undefined;

  if (simData?.result?.result) {
    const simEnergy = simData.energy_used || 0;
    energyPenalty = simData.energy_penalty || 0;

    energy = estimatedEnergy ?? simEnergy;

    try {
      const rawDataHex = simData.transaction?.raw_data_hex;
      if (rawDataHex) {
        const rawDataBytes = Buffer.byteLength(rawDataHex, 'hex');
        bandwidth = rawDataBytes + DATA_HEX_PROTOBUF_EXTRA + SIGNATURE_PER_BANDWIDTH + MAX_RESULT_SIZE_IN_TX + FEE_LIMIT_PROTOBUF_EXTRA;
      }
    } catch { /* ignore */ }
  } else {
    energy = estimatedEnergy;
    const errorMsg = simData?.result?.message
      ? Buffer.from(simData.result.message, "hex").toString()
      : "simulation reverted";
    error = errorMsg;
  }

  return { energy, energyPenalty, bandwidth, error };
}

function buildStep(
  step: string,
  description: string,
  simResult: { energy: number | null; energyPenalty: number; bandwidth: number | null; error?: string },
  typicalKey: string,
): StepEstimate {
  const typical = TYPICAL_RESOURCES[typicalKey];
  const simEnergy = simResult.energy;
  const energyEstimate = simEnergy !== null ? simEnergy : typical.energy;
  const energyPenalty = simResult.energyPenalty || 0;
  const energyBase = Math.max(energyEstimate - energyPenalty, 0);
  const bandwidthEstimate = simResult.bandwidth !== null
    ? simResult.bandwidth
    : typical.bandwidth;
  const energySource: StepEstimate["energySource"] = simEnergy !== null ? "simulation" : "typical";
  return {
    step,
    description,
    energyEstimate,
    energyBase,
    energyPenalty,
    bandwidthEstimate,
    energySource,
    ...(simResult.error ? { simulationError: simResult.error } : {}),
  };
}

function calculateTRXCost(
  totalEnergy: number,
  totalBandwidth: number,
  resourcePrices: ResourcePrices,
): ResourceEstimation["costBreakdown"] & { total: string } {
  const energyCost = totalEnergy * resourcePrices.energyPriceSun;
  const bandwidthCost = totalBandwidth * resourcePrices.bandwidthPriceSun;
  const totalCost = energyCost + bandwidthCost;

  return {
    energyCostTRX: (energyCost / resourcePrices.sunPerTRX).toFixed(3),
    bandwidthCostTRX: (bandwidthCost / resourcePrices.sunPerTRX).toFixed(3),
    total: (totalCost / resourcePrices.sunPerTRX).toFixed(3),
    note: `Energy price: ${resourcePrices.energyPriceSun} SUN/unit, Bandwidth price: ${resourcePrices.bandwidthPriceSun} SUN/point. If you have staked TRX for energy/bandwidth, actual TRX cost will be lower. Each account gets ${resourcePrices.freeBandwidthPerDay} free bandwidth points per day.${resourcePrices.source === "fallback" ? " Current values are fallback defaults because live chain parameters were unavailable." : ""}`,
  };
}

export type LendingOperation =
  | "supply" | "withdraw" | "withdraw_all" | "borrow" | "repay"
  | "enter_market" | "exit_market" | "approve" | "claim_rewards";

export interface ResourceWarning {
  hasEnoughEnergy: boolean;
  hasEnoughBandwidth: boolean;
  accountEnergy: number;
  accountBandwidth: number;
  requiredEnergy: number;
  requiredBandwidth: number;
  energyDeficit: number;
  bandwidthDeficit: number;
  energyBurnTRX: string;
  bandwidthBurnTRX: string;
  totalBurnTRX: string;
  warning: string;
}

export async function checkResourceSufficiency(
  ownerAddress: string,
  requiredEnergy: number,
  requiredBandwidth: number,
  network = "mainnet",
): Promise<ResourceWarning> {
  const tronWeb = getTronWeb(network);
  const resources = await tronWeb.trx.getAccountResources(ownerAddress);
  const resourcePrices = await getResourcePrices(network);

  const totalEnergy = (resources.EnergyLimit || 0) - (resources.EnergyUsed || 0);
  const freeBandwidth = (resources.freeNetLimit || 0) - (resources.freeNetUsed || 0);
  const stakedBandwidth = (resources.NetLimit || 0) - (resources.NetUsed || 0);

  const energyDeficit = Math.max(0, requiredEnergy - totalEnergy);
  const bandwidthCovered = freeBandwidth >= requiredBandwidth || stakedBandwidth >= requiredBandwidth;
  const bandwidthDeficit = bandwidthCovered ? 0 : requiredBandwidth;
  const totalBandwidth = freeBandwidth + stakedBandwidth;

  const energyBurnTRX = energyDeficit * resourcePrices.energyPriceSun / resourcePrices.sunPerTRX;
  const bandwidthBurnTRX = bandwidthDeficit * resourcePrices.bandwidthPriceSun / resourcePrices.sunPerTRX;

  const warnings: string[] = [];
  if (energyDeficit > 0) {
    warnings.push(
      `Energy insufficient: you have ${totalEnergy} but need ~${requiredEnergy}. ` +
      `Deficit of ${energyDeficit} energy will burn ~${energyBurnTRX.toFixed(3)} TRX.`
    );
  }
  if (bandwidthDeficit > 0) {
    warnings.push(
      `Bandwidth insufficient: you have ${totalBandwidth} but need ~${requiredBandwidth}. ` +
      `Deficit of ${bandwidthDeficit} bandwidth will burn ~${bandwidthBurnTRX.toFixed(3)} TRX.`
    );
  }

  return {
    hasEnoughEnergy: energyDeficit === 0,
    hasEnoughBandwidth: bandwidthDeficit === 0,
    accountEnergy: totalEnergy,
    accountBandwidth: totalBandwidth,
    requiredEnergy,
    requiredBandwidth,
    energyDeficit,
    bandwidthDeficit,
    energyBurnTRX: energyBurnTRX.toFixed(3),
    bandwidthBurnTRX: bandwidthBurnTRX.toFixed(3),
    totalBurnTRX: (energyBurnTRX + bandwidthBurnTRX).toFixed(3),
    warning: warnings.length > 0
      ? `⚠️ RESOURCE WARNING: ${warnings.join(" ")} Consider staking TRX for energy to reduce costs.`
      : "",
  };
}

export function getTypicalResources(operation: string, isTRX: boolean): { energy: number; bandwidth: number } {
  let key = operation;
  if (operation === "supply") key = isTRX ? "supply_trx" : "supply_trc20";
  if (operation === "repay") key = isTRX ? "repay_trx" : "repay_trc20";
  return TYPICAL_RESOURCES[key] || { energy: 100000, bandwidth: 300 };
}

async function estimateApproveStep(
  tronWeb: any,
  ownerAddress: string,
  tokenAddress: string,
  spenderAddress: string,
  tokenSymbol: string,
  spenderLabel: string,
  requiredAmount: bigint | undefined,
  network: string,
): Promise<{ step: StepEstimate; skipped: boolean } | null> {
  const sim = (addr: string, fn: string, params: Array<{ type: string; value: any }>, opts: any = {}) =>
    trySimulateEnergy(tronWeb, ownerAddress, addr, fn, params, opts, network);

  let currentAllowance = 0n;
  try {
    const token = tronWeb.contract(TRC20_ABI, tokenAddress);
    const raw = await token.methods.allowance(ownerAddress, spenderAddress).call();
    currentAllowance = BigInt(raw);
  } catch { /* default to 0 */ }

  if (requiredAmount !== undefined && currentAllowance >= requiredAmount && currentAllowance > 0n) {
    return null;
  }

  const r = await sim(tokenAddress, "approve(address,uint256)", [
    { type: "address", value: spenderAddress }, { type: "uint256", value: MAX_UINT256 },
  ]);

  if (r.energy !== null && currentAllowance === 0n) {
    r.energy = Math.max(r.energy, TYPICAL_RESOURCES.approve.energy);
  }

  const step = buildStep("approve", `Approve ${tokenSymbol} for ${spenderLabel}`, r, "approve");
  return { step, skipped: false };
}

export async function estimateLendingEnergy(
  operation: LendingOperation,
  jTokenSymbol: string,
  amount: string,
  ownerAddress: string,
  network = "mainnet",
  spender?: string,
): Promise<ResourceEstimation> {
  const tronWeb = getTronWeb(network);
  const addresses = getJustLendAddresses(network);
  const steps: StepEstimate[] = [];

  const sim = (addr: string, fn: string, params: Array<{ type: string; value: any }>, opts: any = {}) =>
    trySimulateEnergy(tronWeb, ownerAddress, addr, fn, params, opts, network);

  let info: JTokenInfo | undefined;
  if (operation !== "claim_rewards") {
    info = resolveJToken(jTokenSymbol, network);
  }

  const isTRX = info ? (info.underlyingSymbol === "TRX" || !info.underlying) : false;

  switch (operation) {

    case "approve": {
      if (isTRX || !info!.underlying) throw new Error(`${jTokenSymbol} is native TRX — no approval needed`);
      const spenderAddr = spender || info!.address;
      const spenderLabel = spender ? spender : jTokenSymbol;
      const result = await estimateApproveStep(
        tronWeb, ownerAddress, info!.underlying, spenderAddr,
        info!.underlyingSymbol, spenderLabel, undefined, network,
      );
      if (result) steps.push(result.step);
      break;
    }

    case "supply": {
      const amountRaw = utils.parseUnits(amount, info!.underlyingDecimals);
      if (!isTRX && info!.underlying) {
        const approveResult = await estimateApproveStep(
          tronWeb, ownerAddress, info!.underlying, info!.address,
          info!.underlyingSymbol, jTokenSymbol, amountRaw, network,
        );
        if (approveResult) {
          steps.push(approveResult.step);
        }
      }
      if (isTRX) {
        const mr = await sim(info!.address, "mint()", [], { callValue: amountRaw.toString() });
        steps.push(buildStep("mint", `Supply ${amount} TRX to ${jTokenSymbol}`, mr, "supply_trx"));
      } else {
        const mr = await sim(info!.address, "mint(uint256)", [{ type: "uint256", value: amountRaw.toString() }]);
        steps.push(buildStep("mint", `Supply ${amount} ${info!.underlyingSymbol} to ${jTokenSymbol}`, mr, "supply_trc20"));
      }
      break;
    }

    case "withdraw": {
      const amountRaw = utils.parseUnits(amount, info!.underlyingDecimals).toString();
      const r = await sim(info!.address, "redeemUnderlying(uint256)", [{ type: "uint256", value: amountRaw }]);
      steps.push(buildStep("redeemUnderlying", `Withdraw ${amount} ${info!.underlyingSymbol} from ${jTokenSymbol}`, r, "withdraw"));
      break;
    }

    case "withdraw_all": {
      const r = await sim(info!.address, "redeem(uint256)", [{ type: "uint256", value: "100000000" }]);
      steps.push(buildStep("redeem", `Withdraw all ${info!.underlyingSymbol} from ${jTokenSymbol}`, r, "withdraw_all"));
      break;
    }

    case "borrow": {
      const amountRaw = utils.parseUnits(amount, info!.underlyingDecimals).toString();
      const r = await sim(info!.address, "borrow(uint256)", [{ type: "uint256", value: amountRaw }]);
      steps.push(buildStep("borrow", `Borrow ${amount} ${info!.underlyingSymbol} from ${jTokenSymbol}`, r, "borrow"));
      break;
    }

    case "repay": {
      const amountRaw = utils.parseUnits(amount, info!.underlyingDecimals);
      if (!isTRX && info!.underlying) {
        const approveResult = await estimateApproveStep(
          tronWeb, ownerAddress, info!.underlying, info!.address,
          info!.underlyingSymbol, jTokenSymbol, amountRaw, network,
        );
        if (approveResult) {
          steps.push(approveResult.step);
        }
      }
      if (isTRX) {
        const r = await sim(info!.address, "repayBorrow()", [], { callValue: amountRaw.toString() });
        steps.push(buildStep("repayBorrow", `Repay ${amount} TRX to ${jTokenSymbol}`, r, "repay_trx"));
      } else {
        const r = await sim(info!.address, "repayBorrow(uint256)", [{ type: "uint256", value: amountRaw.toString() }]);
        steps.push(buildStep("repayBorrow", `Repay ${amount} ${info!.underlyingSymbol} to ${jTokenSymbol}`, r, "repay_trc20"));
      }
      break;
    }

    case "enter_market": {
      const r = await sim(addresses.comptroller, "enterMarkets(address[])", [{ type: "address[]", value: [info!.address] }]);
      steps.push(buildStep("enterMarkets", `Enable ${jTokenSymbol} as collateral`, r, "enter_market"));
      break;
    }

    case "exit_market": {
      const r = await sim(addresses.comptroller, "exitMarket(address)", [{ type: "address", value: info!.address }]);
      steps.push(buildStep("exitMarket", `Disable ${jTokenSymbol} as collateral`, r, "exit_market"));
      break;
    }

    case "claim_rewards": {
      const r = await sim(addresses.comptroller, "claimReward(address)", [{ type: "address", value: ownerAddress }]);
      steps.push(buildStep("claimReward", `Claim JustLend mining rewards`, r, "claim_rewards"));
      break;
    }
  }

  const totalEnergy = steps.reduce((sum, s) => sum + s.energyEstimate, 0);
  const totalBandwidth = steps.reduce((sum, s) => sum + s.bandwidthEstimate, 0);
  const hasTypical = steps.some((s) => s.energySource === "typical");
  const resourcePrices = await getResourcePrices(network);
  const cost = calculateTRXCost(totalEnergy, totalBandwidth, resourcePrices);

  return {
    operation,
    market: jTokenSymbol,
    steps,
    totalEnergy,
    totalBandwidth,
    estimatedTRXCost: cost.total,
    costBreakdown: {
      energyCostTRX: cost.energyCostTRX,
      bandwidthCostTRX: cost.bandwidthCostTRX,
      note: cost.note,
    },
    note: hasTypical
      ? "Some steps could not be simulated on-chain. Typical values from historical data are used."
      : "All steps were successfully simulated on-chain.",
  };
}

export async function simulateOperationResources(
  operation: string,
  jTokenSymbol: string,
  amount: string,
  ownerAddress: string,
  network = "mainnet",
): Promise<{ energy: number; bandwidth: number; source: "simulation" | "typical" }> {
  const typical = getTypicalResources(operation, operation === "supply" || operation === "repay"
    ? (() => {
      try { const i = resolveJToken(jTokenSymbol, network); return i.underlyingSymbol === "TRX" || !i.underlying; } catch { return false; }
    })()
    : false,
  );

  try {
    const tronWeb = getTronWeb(network);
    const addresses = getJustLendAddresses(network);
    let info: JTokenInfo | undefined;
    if (operation !== "claim_rewards") {
      info = resolveJToken(jTokenSymbol, network);
    }
    const isTRX = info ? (info.underlyingSymbol === "TRX" || !info.underlying) : false;

    const sim = (addr: string, fn: string, params: Array<{ type: string; value: any }>, opts: any = {}) =>
      trySimulateEnergy(tronWeb, ownerAddress, addr, fn, params, opts, network);

    let result: { energy: number | null; energyPenalty: number; bandwidth: number | null; error?: string };

    switch (operation) {
      case "supply": {
        const amountRaw = utils.parseUnits(amount, info!.underlyingDecimals);
        if (isTRX) {
          result = await sim(info!.address, "mint()", [], { callValue: amountRaw.toString() });
        } else {
          result = await sim(info!.address, "mint(uint256)", [{ type: "uint256", value: amountRaw.toString() }]);
        }
        break;
      }
      case "withdraw": {
        const amountRaw = utils.parseUnits(amount, info!.underlyingDecimals).toString();
        result = await sim(info!.address, "redeemUnderlying(uint256)", [{ type: "uint256", value: amountRaw }]);
        break;
      }
      case "withdraw_all": {
        result = await sim(info!.address, "redeem(uint256)", [{ type: "uint256", value: "100000000" }]);
        break;
      }
      case "borrow": {
        const amountRaw = utils.parseUnits(amount, info!.underlyingDecimals).toString();
        result = await sim(info!.address, "borrow(uint256)", [{ type: "uint256", value: amountRaw }]);
        break;
      }
      case "repay": {
        let repayRaw: bigint;
        const isMax = amount === "-1" || amount.toLowerCase() === "max";
        if (isMax) {
          const jToken = tronWeb.contract(JTOKEN_ABI, info!.address);
          const borrowBal = BigInt(await jToken.methods.borrowBalanceStored(ownerAddress).call());
          repayRaw = borrowBal > 0n ? borrowBal + borrowBal / 1000n : BigInt(10 ** info!.underlyingDecimals);
        } else {
          repayRaw = utils.parseUnits(amount, info!.underlyingDecimals);
        }
        if (isTRX) {
          result = await sim(info!.address, "repayBorrow()", [], { callValue: repayRaw.toString() });
        } else {
          result = await sim(info!.address, "repayBorrow(uint256)", [{ type: "uint256", value: repayRaw.toString() }]);
        }
        break;
      }
      case "enter_market": {
        result = await sim(addresses.comptroller, "enterMarkets(address[])", [{ type: "address[]", value: [info!.address] }]);
        break;
      }
      case "exit_market": {
        result = await sim(addresses.comptroller, "exitMarket(address)", [{ type: "address", value: info!.address }]);
        break;
      }
      case "claim_rewards": {
        result = await sim(addresses.comptroller, "claimReward(address)", [{ type: "address", value: ownerAddress }]);
        break;
      }
      default:
        return { ...typical, source: "typical" };
    }

    const energy = result!.energy ?? typical.energy;
    const bandwidth = result!.bandwidth ?? typical.bandwidth;

    return { energy, bandwidth, source: result!.energy !== null ? "simulation" : "typical" };

  } catch {

    return { ...typical, source: "typical" };

  }

}
