(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,631542,612207,457244,325117,391432,589551,131071,289518,923589,e=>{"use strict";(n=a||(a={})).Init="Init",n.Pending="Pending",n.Done="Done",n.Error="Error",e.s(["State",0,a],612207),(s=l||(l={})).WalletList="WalletList",s.Connecting="Connecting",s.Connected="Connected",s.Error="Error",s.NotExist="NotExist",s.Rejected="Rejected",s.QRCode="QRCode",e.s(["ModalView",0,l],457244),(i=c||(c={})).Disconnected="Disconnected",i.Connecting="Connecting",i.Connected="Connected",i.NotExist="NotExist",i.Rejected="Rejected",i.Error="Error",e.s(["WalletStatus",0,c],325117),e.s([],391432);let t=Error("Client Not Exist!"),r=Error("Request Rejected!"),o=Error("Expired!");e.s(["ClientNotExistError",0,t,"ConnectError",0,class extends Error{name="ConnectError";constructor(e){super(e)}},"ExpiredError",0,o,"RejectedError",0,r,"WalletNotProvidedError",0,class extends Error{walletName;constructor(e){super(`Wallet ${e} is not provided.`),this.walletName=e}}],589551),e.s(["getWalletStatusFromState",0,(e,o)=>{switch(e){case"Pending":return c.Connecting;case"Done":return c.Connected;case"Error":switch(o){case t.message:return c.NotExist;case r.message:return c.Rejected;default:return c.Error}default:return c.Disconnected}}],131071),e.s([],631542);var n,s,i,a,l,c,p=e.i(948475);let u=async(e,t,r)=>!1===await d(e,t,!1,r)?Promise.reject("Invalid endpoint."):e,h=async(e,t,r)=>{try{let o=await Promise.any(e.map(e=>u(e,t,r)));return r?.debug("rpcEndpoint won the race:",o),o}catch(e){return Promise.reject(e)}},d=async(e,t,r,o)=>{if(r)return o?.debug("Skipping test of accessibility for",e),!0;o?.debug("Testing accessibility of",e);try{let r;if(r="string"==typeof e?"rest"===t?await p.default.get(`${e}/cosmos/base/tendermint/v1beta1/node_info`):await p.default.post(e):"rest"===t?await p.default.get(`${e.url}/cosmos/base/tendermint/v1beta1/node_info`,{headers:e.headers}):await p.default.post(e.url,{headers:e.headers}),200==r.status)return o?.debug("Access successfully."),!0}catch(e){o?.debug(`${e.name}: ${e.message}`)}return o?.debug("Access failed."),!1},y=(e,t,r,o,n)=>void 0!==o?o:void 0!==r?r:void 0!==t?t:void 0!==e&&e;e.s(["getFastestEndpoint",0,h,"getIsLazy",0,y,"isValidEndpoint",0,d],289518),e.s(["convertChain",0,function(e,t,r,o,n,s){let i="string"==typeof e?e:e.chain_name,a=t.find(e=>e.chain_name===i),l={...o,isLazy:y(n,o?.isLazy,void 0,void 0,s)};return{name:i,chain:"string"==typeof e?void 0:e,assetList:a,clientOptions:{stargate:r?.stargate?.(e),signingStargate:r?.signingStargate?.(e),signingCosmwasm:r?.signingCosmwasm?.(e),preferredSignType:r?.preferredSignType?.(e)||"amino"},preferredEndpoints:l}}],923589)},977319,e=>{"use strict";function t(e,t){switch(e){case"ERROR":return[`%c${e} -`,"color: Red;",t];case"WARN":return[`%c${e} -`,"color: Orange;",t];case"INFO":return[`%c${e} -`,"color: Blue;",t];case"DEBUG":return[`%c${e} -`,"color: Purple;",t];case"TRACE":return[`%c${e} -`,"color: Brown;",t]}}e.s(["Logger",0,class{logger;level;levelOrder=["TRACE","DEBUG","INFO","WARN","ERROR","NONE"];constructor(e="INFO"){this.logger=console,this.level=e}compare(e,t){let r=this.levelOrder.indexOf(e),o=this.levelOrder.indexOf(t);return r>o?1:r<o?-1:0}trace(e,...r){this.compare("TRACE",this.level)>=0&&this.logger.trace(...t("TRACE",e),...r)}debug(e,...r){this.compare("DEBUG",this.level)>=0&&this.logger.debug(...t("DEBUG",e),...r)}info(e,...r){this.compare("INFO",this.level)>=0&&this.logger.info(...t("INFO",e),...r)}warn(e,...r){this.compare("WARN",this.level)>=0&&this.logger.warn(...t("WARN",e),...r)}error(e,...r){this.compare("ERROR",this.level)>=0&&this.logger.error(...t("ERROR",e),...r)}}])},722196,e=>{"use strict";let t=[{name:"icns",contract:"osmo1xk0s8xgktn9x5vwcgtjdxqzadg88fgn33p8u9cnpdxwemvxscvast52cdd",chainName:"osmosis",getQueryMsg:e=>({icns_names:{address:e}}),slip173:"osmo"},{name:"stargaze",contract:"stars1fx74nkqkw2748av8j7ew7r3xt9cgjqduwn8m0ur5lhe49uhlsasszc5fhr",chainName:"stargaze",getQueryMsg:e=>({name:{address:e}}),slip173:"stars"}];e.s(["getChainNameFromNameServiceName",0,e=>t.find(t=>t.name===e)?.chainName,"getNameServiceNameFromChainName",0,e=>t.find(t=>t.chainName===e)?.name,"getNameServiceRegistryFromChainName",0,e=>{let r=t.find(t=>t.chainName===e);if(!r)throw Error("No such name service registered with chain "+e);return r},"getNameServiceRegistryFromName",0,e=>t.find(t=>t.name===e)],722196)},686583,e=>{"use strict";e.s(["Session",0,class{sessionOptions;timeoutId;constructor(e){this.sessionOptions=e}update(){void 0!==this.timeoutId&&clearTimeout(this.timeoutId),this.timeoutId=setTimeout(()=>{this.sessionOptions.callback?.()},this.sessionOptions.duration)}}])},982455,867468,959496,e=>{"use strict";var t,r;(t=r||(r={})).Black="#010101",t.White="#FFFFFF",t.Blue="#2764C1",t.DarkBlue="#162A4A",t.LightBlue="#82A8E4",t.Pink="#CF2FB3",t.LightGray="#D3D4D7",t.Gray="#6B7280",t.Beige="#F1EDE9",t.Red="#BF1B15",e.s(["ColorPalette",0,r,"seedToBgColor",0,function(e){if(!e)return"htw-bg-gray-100";switch(e%5){case 0:return"htw-bg-blue-100";case 1:return"htw-bg-pink-200";case 2:return"htw-bg-green-100";case 3:return"htw-bg-orange-200";case 4:return"htw-bg-violet-200";default:return"htw-bg-gray-100"}}],982455);let o=e.i(730007).rootLogger.child({module:"widgets"});e.s(["widgetLogger",0,o],867468),e.s(["links",0,{home:"https://www.hyperlane.xyz",explorer:"https://explorer.hyperlane.xyz",discord:"https://discord.gg/VK9ZUy3aTV",github:"https://github.com/hyperlane-xyz/hyperlane-warp-ui-template",docs:"https://docs.hyperlane.xyz",warpDocs:"https://docs.hyperlane.xyz/docs/reference/applications/warp-routes",gasDocs:"https://docs.hyperlane.xyz/docs/reference/hooks/interchain-gas",chains:"https://docs.hyperlane.xyz/docs/resources/domains",twitter:"https://x.com/hyperlane",blog:"https://medium.com/hyperlane",tos:"https://hyperlane.xyz/terms-of-service",privacyPolicy:"https://hyperlane.xyz/privacy-policy",bounty:"https://github.com/search?q=org:hyperlane-xyz+label:bounty+is:open+is:issue&type=issues&s=&o=desc",imgPath:"https://cdn.jsdelivr.net/gh/hyperlane-xyz/hyperlane-registry@main",transferFees:"https://docs.hyperlane.xyz/docs/protocol/core/fees#fee-estimation",stake:"https://app.symbiotic.fi/vault/0xE1F23869776c82f691d9Cb34597Ab1830Fb0De58",support:"https://help.hyperlane.xyz/"}],959496)},579121,e=>{"use strict";var t,r,o,n,s,i=((t=i||{}).ADDRESS="address",t.BOOL="bool",t.GROUP="group",t.U8="u8",t.U16="u16",t.U32="u32",t.U64="u64",t.U128="u128",t.I8="i8",t.I16="i16",t.I32="i32",t.I64="i64",t.I128="i128",t.FIELD="field",t.SCALAR="scalar",t.SIGNATURE="signature",t),a=((r=a||{}).ARRAY="array",r.LITERAL="literal",r.STRUCT="struct",r),l=((o=l||{}).PLAINTEXT="plaintext",o.RECORD="record",o.FUTURE="future",o),c=((n=c||{}).PENDING="pending",n.ACCEPTED="accepted",n.FAILED="failed",n.REJECTED="rejected",n),p={mode:{type:"string",possibleValues:["issue","resolve"]},membershipProgram:{type:"string"},membershipMapping:{type:"string"},targetAddress:{type:"address",optional:!0}},u=((s=u||{}).MAINNET="mainnet",s.TESTNET="testnet",s.CANARY="canary",s);e.s(["ALGORITHM_SCHEMAS",0,{"program-scoped-blinding-factor":{args:p,outputType:"field",validSlotTypes:["field","scalar","group"]},"program-scoped-blinded-address":{args:p,outputType:"address",validSlotTypes:["address","group","scalar","field"]}},"KNOWN_ALGORITHMS",0,["program-scoped-blinding-factor","program-scoped-blinded-address"],"Network",0,u,"hasInputRequest",0,function(e){return e.some(e=>"string"!=typeof e)},"isLiteralInput",0,function(e){return"string"==typeof e}])},246015,e=>{"use strict";e.i(678382);var t,r,o,n=((t=n||{}).CONNECT="standard:connect",t.ACCOUNTS="standard:accounts",t.SIGN="aleo:sign",t.EXECUTE="aleo:execute",t.TRANSACTION_STATUS="aleo:transaction-status",t.CHAINS="standard:chains",t.SWITCH_NETWORK="standard:switch-network",t.DECRYPT="standard:decrypt",t.REQUEST_RECORDS="standard:request-records",t.EXECUTE_DEPLOYMENT="standard:execute-deployment",t.TRANSITION_VIEWKEYS="standard:transition_viewkeys",t.REQUEST_TRANSACTION_HISTORY="standard:request_transaction_history",t),s=((r=s||{}).INSTALLED="Installed",r.NOT_DETECTED="NotDetected",r.LOADABLE="Loadable",r.UNSUPPORTED="Unsupported",r),i=((o=i||{}).NoDecrypt="NO_DECRYPT",o.UponRequest="DECRYPT_UPON_REQUEST",o.AutoDecrypt="AUTO_DECRYPT",o.OnChainHistory="ON_CHAIN_HISTORY",o);e.s(["WalletDecryptPermission",0,i,"WalletFeatureName",0,n,"WalletReadyState",0,s,"hasUnsupportedConnectOptions",0,function(e){return!!e&&(void 0!==e.recordAccess||!1===e.readAddress||void 0!==e.algorithmsAllowed&&e.algorithmsAllowed.length>0)}])},431606,e=>{"use strict";var t=`{
  "connect_wallet": {
    "label": "Connect Wallet",
    "wrong_network": {
      "label": "Wrong network"
    }
  },

  "intro": {
    "title": "What is a Wallet?",
    "description": "A wallet is used to send, receive, store, and display digital assets. It's also a new way to log in, without needing to create new accounts and passwords on every website.",
    "digital_asset": {
      "title": "A Home for your Digital Assets",
      "description": "Wallets are used to send, receive, store, and display digital assets like Ethereum and NFTs."
    },
    "login": {
      "title": "A New Way to Log In",
      "description": "Instead of creating new accounts and passwords on every website, just connect your wallet."
    },
    "get": {
      "label": "Get a Wallet"
    },
    "learn_more": {
      "label": "Learn More"
    }
  },

  "sign_in": {
    "label": "Verify your account",
    "description": "To finish connecting, you must sign a message in your wallet to verify that you are the owner of this account.",
    "message": {
      "send": "Sign message",
      "preparing": "Preparing message...",
      "cancel": "Cancel",
      "preparing_error": "Error preparing message, please retry!"
    },
    "signature": {
      "waiting": "Waiting for signature...",
      "verifying": "Verifying signature...",
      "signing_error": "Error signing message, please retry!",
      "verifying_error": "Error verifying signature, please retry!",
      "oops_error": "Oops, something went wrong!"
    }
  },

  "connect": {
    "label": "Connect",
    "title": "Connect a Wallet",
    "new_to_ethereum": {
      "description": "New to Ethereum wallets?",
      "learn_more": {
        "label": "Learn More"
      }
    },
    "learn_more": {
      "label": "Learn more"
    },
    "recent": "Recent",
    "status": {
      "opening": "Opening %{wallet}...",
      "connecting": "Connecting",
      "connect_mobile": "Continue in %{wallet}",
      "not_installed": "%{wallet} is not installed",
      "not_available": "%{wallet} is not available",
      "confirm": "Confirm connection in the extension",
      "confirm_mobile": "Accept connection request in the wallet"
    },
    "secondary_action": {
      "get": {
        "description": "Don't have %{wallet}?",
        "label": "GET"
      },
      "install": {
        "label": "INSTALL"
      },
      "retry": {
        "label": "RETRY"
      }
    },
    "walletconnect": {
      "description": {
        "full": "Need the official WalletConnect modal?",
        "compact": "Need the WalletConnect modal?"
      },
      "open": {
        "label": "OPEN"
      }
    }
  },

  "connect_scan": {
    "title": "Scan with %{wallet}",
    "fallback_title": "Scan with your phone"
  },

  "connector_group": {
    "installed": "Installed",
    "recommended": "Recommended",
    "other": "Other",
    "popular": "Popular",
    "more": "More",
    "others": "Others"
  },

  "get": {
    "title": "Get a Wallet",
    "action": {
      "label": "GET"
    },
    "mobile": {
      "description": "Mobile Wallet"
    },
    "extension": {
      "description": "Browser Extension"
    },
    "mobile_and_extension": {
      "description": "Mobile Wallet and Extension"
    },
    "mobile_and_desktop": {
      "description": "Mobile and Desktop Wallet"
    },
    "looking_for": {
      "title": "Not what you're looking for?",
      "mobile": {
        "description": "Select a wallet on the main screen to get started with a different wallet provider."
      },
      "desktop": {
        "compact_description": "Select a wallet on the main screen to get started with a different wallet provider.",
        "wide_description": "Select a wallet on the left to get started with a different wallet provider."
      }
    }
  },

  "get_options": {
    "title": "Get started with %{wallet}",
    "short_title": "Get %{wallet}",
    "mobile": {
      "title": "%{wallet} for Mobile",
      "description": "Use the mobile wallet to explore the world of Ethereum.",
      "download": {
        "label": "Get the app"
      }
    },
    "extension": {
      "title": "%{wallet} for %{browser}",
      "description": "Access your wallet right from your favorite web browser.",
      "download": {
        "label": "Add to %{browser}"
      }
    },
    "desktop": {
      "title": "%{wallet} for %{platform}",
      "description": "Access your wallet natively from your powerful desktop.",
      "download": {
        "label": "Add to %{platform}"
      }
    }
  },

  "get_mobile": {
    "title": "Install %{wallet}",
    "description": "Scan with your phone to download on iOS or Android",
    "continue": {
      "label": "Continue"
    }
  },

  "get_instructions": {
    "mobile": {
      "connect": {
        "label": "Connect"
      },
      "learn_more": {
        "label": "Learn More"
      }
    },
    "extension": {
      "refresh": {
        "label": "Refresh"
      },
      "learn_more": {
        "label": "Learn More"
      }
    },
    "desktop": {
      "connect": {
        "label": "Connect"
      },
      "learn_more": {
        "label": "Learn More"
      }
    }
  },

  "chains": {
    "title": "Switch Networks",
    "wrong_network": "Wrong network detected, switch or disconnect to continue.",
    "confirm": "Confirm in Wallet",
    "switching_not_supported": "Your wallet does not support switching networks from %{appName}. Try switching networks from within your wallet instead.",
    "switching_not_supported_fallback": "Your wallet does not support switching networks from this app. Try switching networks from within your wallet instead.",
    "disconnect": "Disconnect",
    "connected": "Connected"
  },

  "profile": {
    "disconnect": {
      "label": "Disconnect"
    },
    "copy_address": {
      "label": "Copy Address",
      "copied": "Copied!"
    },
    "explorer": {
      "label": "View more on explorer"
    },
    "transactions": {
      "description": "%{appName} transactions will appear here...",
      "description_fallback": "Your transactions will appear here...",
      "recent": {
        "title": "Recent Transactions"
      },
      "clear": {
        "label": "Clear All"
      }
    }
  },

  "wallet_connectors": {
    "ready": {
      "qr_code": {
        "step1": {
          "description": "Add Ready to your home screen for faster access to your wallet.",
          "title": "Open the Ready app"
        },
        "step2": {
          "description": "Create a wallet and username, or import an existing wallet.",
          "title": "Create or Import a Wallet"
        },
        "step3": {
          "description": "After you scan, a connection prompt will appear for you to connect your wallet.",
          "title": "Tap the Scan QR button"
        }
      }
    },

    "berasig": {
      "extension": {
        "step1": {
          "title": "Install the BeraSig extension",
          "description": "We recommend pinning BeraSig to your taskbar for easier access to your wallet."
        },
        "step2": {
          "title": "Create a Wallet",
          "description": "Be sure to back up your wallet using a secure method. Never share your secret phrase with anyone."
        },
        "step3": {
          "title": "Refresh your browser",
          "description": "Once you set up your wallet, click below to refresh the browser and load up the extension."
        }
      }
    },

    "best": {
      "qr_code": {
        "step1": {
          "title": "Open the Best Wallet app",
          "description": "Add Best Wallet to your home screen for faster access to your wallet."
        },
        "step2": {
          "title": "Create or Import a Wallet",
          "description": "Create a new wallet or import an existing one."
        },
        "step3": {
          "title": "Tap the QR icon and scan",
          "description": "Tap the QR icon on your homescreen, scan the code and confirm the prompt to connect."
        }
      }
    },

    "bifrost": {
      "qr_code": {
        "step1": {
          "description": "We recommend putting Bifrost Wallet on your home screen for quicker access.",
          "title": "Open the Bifrost Wallet app"
        },
        "step2": {
          "description": "Create or import a wallet using your recovery phrase.",
          "title": "Create or Import a Wallet"
        },
        "step3": {
          "description": "After you scan, a connection prompt will appear for you to connect your wallet.",
          "title": "Tap the scan button"
        }
      }
    },

    "bitget": {
      "qr_code": {
        "step1": {
          "description": "We recommend putting Bitget Wallet on your home screen for quicker access.",
          "title": "Open the Bitget Wallet app"
        },
        "step2": {
          "description": "Be sure to back up your wallet using a secure method. Never share your secret phrase with anyone.",
          "title": "Create or Import a Wallet"
        },
        "step3": {
          "description": "After you scan, a connection prompt will appear for you to connect your wallet.",
          "title": "Tap the scan button"
        }
      },

      "extension": {
        "step1": {
          "description": "We recommend pinning Bitget Wallet to your taskbar for quicker access to your wallet.",
          "title": "Install the Bitget Wallet extension"
        },
        "step2": {
          "description": "Be sure to back up your wallet using a secure method. Never share your secret phrase with anyone.",
          "title": "Create or Import a Wallet"
        },
        "step3": {
          "description": "Once you set up your wallet, click below to refresh the browser and load up the extension.",
          "title": "Refresh your browser"
        }
      }
    },

    "bitski": {
      "extension": {
        "step1": {
          "description": "We recommend pinning Bitski to your taskbar for quicker access to your wallet.",
          "title": "Install the Bitski extension"
        },
        "step2": {
          "description": "Be sure to back up your wallet using a secure method. Never share your secret phrase with anyone.",
          "title": "Create or Import a Wallet"
        },
        "step3": {
          "description": "Once you set up your wallet, click below to refresh the browser and load up the extension.",
          "title": "Refresh your browser"
        }
      }
    },

    "bitverse": {
      "qr_code": {
        "step1": {
          "title": "Open the Bitverse Wallet app",
          "description": "Add Bitverse Wallet to your home screen for faster access to your wallet."
        },
        "step2": {
          "title": "Create or Import a Wallet",
          "description": "Create a new wallet or import an existing one."
        },
        "step3": {
          "title": "Tap the QR icon and scan",
          "description": "Tap the QR icon on your homescreen, scan the code and confirm the prompt to connect."
        }
      }
    },

    "bloom": {
      "desktop": {
        "step1": {
          "title": "Open the Bloom Wallet app",
          "description": "We recommend putting Bloom Wallet on your home screen for quicker access."
        },
        "step2": {
          "description": "Create or import a wallet using your recovery phrase.",
          "title": "Create or Import a Wallet"
        },
        "step3": {
          "description": "After you have a wallet, click on Connect to connect via Bloom. A connection prompt in the app will appear for you to confirm the connection.",
          "title": "Click on Connect"
        }
      }
    },

    "bybit": {
      "qr_code": {
        "step1": {
          "description": "We recommend putting Bybit on your home screen for faster access to your wallet.",
          "title": "Open the Bybit app"
        },
        "step2": {
          "description": "You can easily backup your wallet using our backup feature on your phone.",
          "title": "Create or Import a Wallet"
        },
        "step3": {
          "description": "After you scan, a connection prompt will appear for you to connect your wallet.",
          "title": "Tap the scan button"
        }
      },

      "extension": {
        "step1": {
          "description": "Click at the top right of your browser and pin Bybit Wallet for easy access.",
          "title": "Install the Bybit Wallet extension"
        },
        "step2": {
          "description": "Create a new wallet or import an existing one.",
          "title": "Create or Import a wallet"
        },
        "step3": {
          "description": "Once you set up Bybit Wallet, click below to refresh the browser and load up the extension.",
          "title": "Refresh your browser"
        }
      }
    },

    "binance": {
      "qr_code": {
        "step1": {
          "description": "We recommend putting Binance on your home screen for faster access to your wallet.",
          "title": "Open the Binance app"
        },
        "step2": {
          "description": "You can easily backup your wallet using our backup feature on your phone.",
          "title": "Create or Import a Wallet"
        },
        "step3": {
          "description": "After you scan, a connection prompt will appear for you to connect your wallet.",
          "title": "Tap the WalletConnect button"
        }
      },
      "extension": {
        "step1": {
          "title": "Install the Binance Wallet extension",
          "description": "We recommend pinning Binance Wallet to your taskbar for quicker access to your wallet."
        },
        "step2": {
          "title": "Create or Import a Wallet",
          "description": "Be sure to back up your wallet using a secure method. Never share your secret phrase with anyone."
        },
        "step3": {
          "title": "Refresh your browser",
          "description": "Once you set up your wallet, click below to refresh the browser and load up the extension."
        }
      }
    },

    "coin98": {
      "qr_code": {
        "step1": {
          "description": "We recommend putting Coin98 Wallet on your home screen for faster access to your wallet.",
          "title": "Open the Coin98 Wallet app"
        },
        "step2": {
          "description": "You can easily backup your wallet using our backup feature on your phone.",
          "title": "Create or Import a Wallet"
        },
        "step3": {
          "description": "After you scan, a connection prompt will appear for you to connect your wallet.",
          "title": "Tap the WalletConnect button"
        }
      },

      "extension": {
        "step1": {
          "description": "Click at the top right of your browser and pin Coin98 Wallet for easy access.",
          "title": "Install the Coin98 Wallet extension"
        },
        "step2": {
          "description": "Create a new wallet or import an existing one.",
          "title": "Create or Import a wallet"
        },
        "step3": {
          "description": "Once you set up Coin98 Wallet, click below to refresh the browser and load up the extension.",
          "title": "Refresh your browser"
        }
      }
    },

    "coinbase": {
      "qr_code": {
        "step1": {
          "description": "We recommend putting Coinbase Wallet on your home screen for quicker access.",
          "title": "Open the Coinbase Wallet app"
        },
        "step2": {
          "description": "You can easily backup your wallet using the cloud backup feature.",
          "title": "Create or Import a Wallet"
        },
        "step3": {
          "description": "After you scan, a connection prompt will appear for you to connect your wallet.",
          "title": "Tap the scan button"
        }
      },

      "extension": {
        "step1": {
          "description": "We recommend pinning Coinbase Wallet to your taskbar for quicker access to your wallet.",
          "title": "Install the Coinbase Wallet extension"
        },
        "step2": {
          "description": "Be sure to back up your wallet using a secure method. Never share your secret phrase with anyone.",
          "title": "Create or Import a Wallet"
        },
        "step3": {
          "description": "Once you set up your wallet, click below to refresh the browser and load up the extension.",
          "title": "Refresh your browser"
        }
      }
    },

    "compass": {
      "extension": {
        "step1": {
          "description": "We recommend pinning Compass Wallet to your taskbar for quicker access to your wallet.",
          "title": "Install the Compass Wallet extension"
        },
        "step2": {
          "description": "Be sure to back up your wallet using a secure method. Never share your secret phrase with anyone.",
          "title": "Create or Import a Wallet"
        },
        "step3": {
          "description": "Once you set up your wallet, click below to refresh the browser and load up the extension.",
          "title": "Refresh your browser"
        }
      }
    },

    "core": {
      "qr_code": {
        "step1": {
          "description": "We recommend putting Core on your home screen for faster access to your wallet.",
          "title": "Open the Core app"
        },
        "step2": {
          "description": "You can easily backup your wallet using our backup feature on your phone.",
          "title": "Create or Import a Wallet"
        },
        "step3": {
          "description": "After you scan, a connection prompt will appear for you to connect your wallet.",
          "title": "Tap the WalletConnect button"
        }
      },

      "extension": {
        "step1": {
          "description": "We recommend pinning Core to your taskbar for quicker access to your wallet.",
          "title": "Install the Core extension"
        },
        "step2": {
          "description": "Be sure to back up your wallet using a secure method. Never share your secret phrase with anyone.",
          "title": "Create or Import a Wallet"
        },
        "step3": {
          "description": "Once you set up your wallet, click below to refresh the browser and load up the extension.",
          "title": "Refresh your browser"
        }
      }
    },

    "fox": {
      "qr_code": {
        "step1": {
          "description": "We recommend putting FoxWallet on your home screen for quicker access.",
          "title": "Open the FoxWallet app"
        },
        "step2": {
          "description": "Be sure to back up your wallet using a secure method. Never share your secret phrase with anyone.",
          "title": "Create or Import a Wallet"
        },
        "step3": {
          "description": "After you scan, a connection prompt will appear for you to connect your wallet.",
          "title": "Tap the scan button"
        }
      }
    },

    "frontier": {
      "qr_code": {
        "step1": {
          "description": "We recommend putting Frontier Wallet on your home screen for quicker access.",
          "title": "Open the Frontier Wallet app"
        },
        "step2": {
          "description": "Be sure to back up your wallet using a secure method. Never share your secret phrase with anyone.",
          "title": "Create or Import a Wallet"
        },
        "step3": {
          "description": "After you scan, a connection prompt will appear for you to connect your wallet.",
          "title": "Tap the scan button"
        }
      },

      "extension": {
        "step1": {
          "description": "We recommend pinning Frontier Wallet to your taskbar for quicker access to your wallet.",
          "title": "Install the Frontier Wallet extension"
        },
        "step2": {
          "description": "Be sure to back up your wallet using a secure method. Never share your secret phrase with anyone.",
          "title": "Create or Import a Wallet"
        },
        "step3": {
          "description": "Once you set up your wallet, click below to refresh the browser and load up the extension.",
          "title": "Refresh your browser"
        }
      }
    },

    "im_token": {
      "qr_code": {
        "step1": {
          "title": "Open the imToken app",
          "description": "Put imToken app on your home screen for faster access to your wallet."
        },
        "step2": {
          "title": "Create or Import a Wallet",
          "description": "Create a new wallet or import an existing one."
        },
        "step3": {
          "title": "Tap Scanner Icon in top right corner",
          "description": "Choose New Connection, then scan the QR code and confirm the prompt to connect."
        }
      }
    },

    "iopay": {
      "qr_code": {
        "step1": {
          "description": "We recommend putting ioPay on your home screen for faster access to your wallet.",
          "title": "Open the ioPay app"
        },
        "step2": {
          "description": "You can easily backup your wallet using our backup feature on your phone.",
          "title": "Create or Import a Wallet"
        },
        "step3": {
          "description": "After you scan, a connection prompt will appear for you to connect your wallet.",
          "title": "Tap the WalletConnect button"
        }
      }
    },

    "kaikas": {
      "extension": {
        "step1": {
          "description": "We recommend pinning Kaikas to your taskbar for quicker access to your wallet.",
          "title": "Install the Kaikas extension"
        },
        "step2": {
          "description": "Be sure to back up your wallet using a secure method. Never share your secret phrase with anyone.",
          "title": "Create or Import a Wallet"
        },
        "step3": {
          "description": "Once you set up your wallet, click below to refresh the browser and load up the extension.",
          "title": "Refresh your browser"
        }
      },
      "qr_code": {
        "step1": {
          "title": "Open the Kaikas app",
          "description": "Put Kaikas app on your home screen for faster access to your wallet."
        },
        "step2": {
          "title": "Create or Import a Wallet",
          "description": "Create a new wallet or import an existing one."
        },
        "step3": {
          "title": "Tap Scanner Icon in top right corner",
          "description": "Choose New Connection, then scan the QR code and confirm the prompt to connect."
        }
      }
    },

    "kaia": {
      "extension": {
        "step1": {
          "description": "We recommend pinning Kaia to your taskbar for quicker access to your wallet.",
          "title": "Install the Kaia extension"
        },
        "step2": {
          "description": "Be sure to back up your wallet using a secure method. Never share your secret phrase with anyone.",
          "title": "Create or Import a Wallet"
        },
        "step3": {
          "description": "Once you set up your wallet, click below to refresh the browser and load up the extension.",
          "title": "Refresh your browser"
        }
      },
      "qr_code": {
        "step1": {
          "title": "Open the Kaia app",
          "description": "Put Kaia app on your home screen for faster access to your wallet."
        },
        "step2": {
          "title": "Create or Import a Wallet",
          "description": "Create a new wallet or import an existing one."
        },
        "step3": {
          "title": "Tap Scanner Icon in top right corner",
          "description": "Choose New Connection, then scan the QR code and confirm the prompt to connect."
        }
      }
    },

    "kraken": {
      "qr_code": {
        "step1": {
          "title": "Open the Kraken Wallet app",
          "description": "Add Kraken Wallet to your home screen for faster access to your wallet."
        },
        "step2": {
          "title": "Create or Import a Wallet",
          "description": "Create a new wallet or import an existing one."
        },
        "step3": {
          "title": "Tap the QR icon and scan",
          "description": "Tap the QR icon on your homescreen, scan the code and confirm the prompt to connect."
        }
      }
    },

    "kresus": {
      "qr_code": {
        "step1": {
          "title": "Open the Kresus Wallet app",
          "description": "Add Kresus Wallet to your home screen for faster access to your wallet."
        },
        "step2": {
          "title": "Create or Import a Wallet",
          "description": "Create a new wallet or import an existing one."
        },
        "step3": {
          "title": "Tap the QR icon and scan",
          "description": "Tap the QR icon on your homescreen, scan the code and confirm the prompt to connect."
        }
      }
    },

    "magicEden": {
      "extension": {
        "step1": {
          "title": "Install the Magic Eden extension",
          "description": "We recommend pinning Magic Eden to your taskbar for easier access to your wallet."
        },
        "step2": {
          "title": "Create or Import a Wallet",
          "description": "Be sure to back up your wallet using a secure method. Never share your secret recovery phrase with anyone."
        },
        "step3": {
          "title": "Refresh your browser",
          "description": "Once you set up your wallet, click below to refresh the browser and load up the extension."
        }
      }
    },

    "metamask": {
      "qr_code": {
        "step1": {
          "title": "Open the MetaMask app",
          "description": "We recommend putting MetaMask on your home screen for quicker access."
        },
        "step2": {
          "title": "Create or Import a Wallet",
          "description": "Be sure to back up your wallet using a secure method. Never share your secret phrase with anyone."
        },
        "step3": {
          "title": "Tap the scan button",
          "description": "After you scan, a connection prompt will appear for you to connect your wallet."
        }
      },

      "extension": {
        "step1": {
          "title": "Install the MetaMask extension",
          "description": "We recommend pinning MetaMask to your taskbar for quicker access to your wallet."
        },
        "step2": {
          "title": "Create or Import a Wallet",
          "description": "Be sure to back up your wallet using a secure method. Never share your secret phrase with anyone."
        },
        "step3": {
          "title": "Refresh your browser",
          "description": "Once you set up your wallet, click below to refresh the browser and load up the extension."
        }
      }
    },

    "nestwallet": {
      "extension": {
        "step1": {
          "title": "Install the NestWallet extension",
          "description": "We recommend pinning NestWallet to your taskbar for quicker access to your wallet."
        },
        "step2": {
          "title": "Create or Import a Wallet",
          "description": "Be sure to back up your wallet using a secure method. Never share your secret phrase with anyone."
        },
        "step3": {
          "title": "Refresh your browser",
          "description": "Once you set up your wallet, click below to refresh the browser and load up the extension."
        }
      }
    },

    "okx": {
      "qr_code": {
        "step1": {
          "title": "Open the OKX Wallet app",
          "description": "We recommend putting OKX Wallet on your home screen for quicker access."
        },
        "step2": {
          "title": "Create or Import a Wallet",
          "description": "Be sure to back up your wallet using a secure method. Never share your secret phrase with anyone."
        },
        "step3": {
          "title": "Tap the scan button",
          "description": "After you scan, a connection prompt will appear for you to connect your wallet."
        }
      },

      "extension": {
        "step1": {
          "title": "Install the OKX Wallet extension",
          "description": "We recommend pinning OKX Wallet to your taskbar for quicker access to your wallet."
        },
        "step2": {
          "title": "Create or Import a Wallet",
          "description": "Be sure to back up your wallet using a secure method. Never share your secret phrase with anyone."
        },
        "step3": {
          "title": "Refresh your browser",
          "description": "Once you set up your wallet, click below to refresh the browser and load up the extension."
        }
      }
    },

    "omni": {
      "qr_code": {
        "step1": {
          "title": "Open the Omni app",
          "description": "Add Omni to your home screen for faster access to your wallet."
        },
        "step2": {
          "title": "Create or Import a Wallet",
          "description": "Create a new wallet or import an existing one."
        },
        "step3": {
          "title": "Tap the QR icon and scan",
          "description": "Tap the QR icon on your home screen, scan the code and confirm the prompt to connect."
        }
      }
    },

    "1inch": {
      "qr_code": {
        "step1": {
          "description": "Put 1inch Wallet on your home screen for faster access to your wallet.",
          "title": "Open the 1inch Wallet app"
        },
        "step2": {
          "description": "Create a wallet and username, or import an existing wallet.",
          "title": "Create or Import a Wallet"
        },
        "step3": {
          "description": "After you scan, a connection prompt will appear for you to connect your wallet.",
          "title": "Tap the Scan QR button"
        }
      }
    },

    "token_pocket": {
      "qr_code": {
        "step1": {
          "title": "Open the TokenPocket app",
          "description": "We recommend putting TokenPocket on your home screen for quicker access."
        },
        "step2": {
          "title": "Create or Import a Wallet",
          "description": "Be sure to back up your wallet using a secure method. Never share your secret phrase with anyone."
        },
        "step3": {
          "title": "Tap the scan button",
          "description": "After you scan, a connection prompt will appear for you to connect your wallet."
        }
      },

      "extension": {
        "step1": {
          "title": "Install the TokenPocket extension",
          "description": "We recommend pinning TokenPocket to your taskbar for quicker access to your wallet."
        },
        "step2": {
          "title": "Create or Import a Wallet",
          "description": "Be sure to back up your wallet using a secure method. Never share your secret phrase with anyone."
        },
        "step3": {
          "title": "Refresh your browser",
          "description": "Once you set up your wallet, click below to refresh the browser and load up the extension."
        }
      }
    },

    "trust": {
      "qr_code": {
        "step1": {
          "title": "Open the Trust Wallet app",
          "description": "Put Trust Wallet on your home screen for faster access to your wallet."
        },
        "step2": {
          "title": "Create or Import a Wallet",
          "description": "Create a new wallet or import an existing one."
        },
        "step3": {
          "title": "Tap WalletConnect in Settings",
          "description": "Choose New Connection, then scan the QR code and confirm the prompt to connect."
        }
      },

      "extension": {
        "step1": {
          "title": "Install the Trust Wallet extension",
          "description": "Click at the top right of your browser and pin Trust Wallet for easy access."
        },
        "step2": {
          "title": "Create or Import a wallet",
          "description": "Create a new wallet or import an existing one."
        },
        "step3": {
          "title": "Refresh your browser",
          "description": "Once you set up Trust Wallet, click below to refresh the browser and load up the extension."
        }
      }
    },

    "uniswap": {
      "qr_code": {
        "step1": {
          "title": "Open the Uniswap app",
          "description": "Add Uniswap Wallet to your home screen for faster access to your wallet."
        },
        "step2": {
          "title": "Create or Import a Wallet",
          "description": "Create a new wallet or import an existing one."
        },
        "step3": {
          "title": "Tap the QR icon and scan",
          "description": "Tap the QR icon on your homescreen, scan the code and confirm the prompt to connect."
        }
      }
    },

    "zerion": {
      "qr_code": {
        "step1": {
          "title": "Open the Zerion app",
          "description": "We recommend putting Zerion on your home screen for quicker access."
        },
        "step2": {
          "title": "Create or Import a Wallet",
          "description": "Be sure to back up your wallet using a secure method. Never share your secret phrase with anyone."
        },
        "step3": {
          "title": "Tap the scan button",
          "description": "After you scan, a connection prompt will appear for you to connect your wallet."
        }
      },

      "extension": {
        "step1": {
          "title": "Install the Zerion extension",
          "description": "We recommend pinning Zerion to your taskbar for quicker access to your wallet."
        },
        "step2": {
          "title": "Create or Import a Wallet",
          "description": "Be sure to back up your wallet using a secure method. Never share your secret phrase with anyone."
        },
        "step3": {
          "title": "Refresh your browser",
          "description": "Once you set up your wallet, click below to refresh the browser and load up the extension."
        }
      }
    },

    "rainbow": {
      "qr_code": {
        "step1": {
          "title": "Open the Rainbow app",
          "description": "We recommend putting Rainbow on your home screen for faster access to your wallet."
        },
        "step2": {
          "title": "Create or Import a Wallet",
          "description": "You can easily backup your wallet using our backup feature on your phone."
        },
        "step3": {
          "title": "Tap the scan button",
          "description": "After you scan, a connection prompt will appear for you to connect your wallet."
        }
      }
    },

    "enkrypt": {
      "extension": {
        "step1": {
          "description": "We recommend pinning Enkrypt Wallet to your taskbar for quicker access to your wallet.",
          "title": "Install the Enkrypt Wallet extension"
        },
        "step2": {
          "description": "Be sure to back up your wallet using a secure method. Never share your secret phrase with anyone.",
          "title": "Create or Import a Wallet"
        },
        "step3": {
          "description": "Once you set up your wallet, click below to refresh the browser and load up the extension.",
          "title": "Refresh your browser"
        }
      }
    },

    "frame": {
      "extension": {
        "step1": {
          "description": "We recommend pinning Frame to your taskbar for quicker access to your wallet.",
          "title": "Install Frame & the companion extension"
        },
        "step2": {
          "description": "Be sure to back up your wallet using a secure method. Never share your secret phrase with anyone.",
          "title": "Create or Import a Wallet"
        },
        "step3": {
          "description": "Once you set up your wallet, click below to refresh the browser and load up the extension.",
          "title": "Refresh your browser"
        }
      }
    },

    "one_key": {
      "extension": {
        "step1": {
          "title": "Install the OneKey Wallet extension",
          "description": "We recommend pinning OneKey Wallet to your taskbar for quicker access to your wallet."
        },
        "step2": {
          "title": "Create or Import a Wallet",
          "description": "Be sure to back up your wallet using a secure method. Never share your secret phrase with anyone."
        },
        "step3": {
          "title": "Refresh your browser",
          "description": "Once you set up your wallet, click below to refresh the browser and load up the extension."
        }
      }
    },

    "paraswap": {
      "qr_code": {
        "step1": {
          "title": "Open the ParaSwap app",
          "description": "Add ParaSwap Wallet to your home screen for faster access to your wallet."
        },
        "step2": {
          "title": "Create or Import a Wallet",
          "description": "Create a new wallet or import an existing one."
        },
        "step3": {
          "title": "Tap the QR icon and scan",
          "description": "Tap the QR icon on your homescreen, scan the code and confirm the prompt to connect."
        }
      }
    },

    "phantom": {
      "extension": {
        "step1": {
          "title": "Install the Phantom extension",
          "description": "We recommend pinning Phantom to your taskbar for easier access to your wallet."
        },
        "step2": {
          "title": "Create or Import a Wallet",
          "description": "Be sure to back up your wallet using a secure method. Never share your secret recovery phrase with anyone."
        },
        "step3": {
          "title": "Refresh your browser",
          "description": "Once you set up your wallet, click below to refresh the browser and load up the extension."
        }
      }
    },

    "rabby": {
      "extension": {
        "step1": {
          "title": "Install the Rabby extension",
          "description": "We recommend pinning Rabby to your taskbar for quicker access to your wallet."
        },
        "step2": {
          "title": "Create or Import a Wallet",
          "description": "Be sure to back up your wallet using a secure method. Never share your secret phrase with anyone."
        },
        "step3": {
          "title": "Refresh your browser",
          "description": "Once you set up your wallet, click below to refresh the browser and load up the extension."
        }
      }
    },

    "ronin": {
      "qr_code": {
        "step1": {
          "description": "We recommend putting Ronin Wallet on your home screen for quicker access.",
          "title": "Open the Ronin Wallet app"
        },
        "step2": {
          "description": "Be sure to back up your wallet using a secure method. Never share your secret phrase with anyone.",
          "title": "Create or Import a Wallet"
        },
        "step3": {
          "description": "After you scan, a connection prompt will appear for you to connect your wallet.",
          "title": "Tap the scan button"
        }
      },

      "extension": {
        "step1": {
          "description": "We recommend pinning Ronin Wallet to your taskbar for quicker access to your wallet.",
          "title": "Install the Ronin Wallet extension"
        },
        "step2": {
          "description": "Be sure to back up your wallet using a secure method. Never share your secret phrase with anyone.",
          "title": "Create or Import a Wallet"
        },
        "step3": {
          "description": "Once you set up your wallet, click below to refresh the browser and load up the extension.",
          "title": "Refresh your browser"
        }
      }
    },

    "ramper": {
      "extension": {
        "step1": {
          "title": "Install the Ramper extension",
          "description": "We recommend pinning Ramper to your taskbar for easier access to your wallet."
        },
        "step2": {
          "title": "Create a Wallet",
          "description": "Be sure to back up your wallet using a secure method. Never share your secret phrase with anyone."
        },
        "step3": {
          "title": "Refresh your browser",
          "description": "Once you set up your wallet, click below to refresh the browser and load up the extension."
        }
      }
    },

    "safeheron": {
      "extension": {
        "step1": {
          "title": "Install the Core extension",
          "description": "We recommend pinning Safeheron to your taskbar for quicker access to your wallet."
        },
        "step2": {
          "title": "Create or Import a Wallet",
          "description": "Be sure to back up your wallet using a secure method. Never share your secret phrase with anyone."
        },
        "step3": {
          "title": "Refresh your browser",
          "description": "Once you set up your wallet, click below to refresh the browser and load up the extension."
        }
      }
    },

    "taho": {
      "extension": {
        "step1": {
          "title": "Install the Taho extension",
          "description": "We recommend pinning Taho to your taskbar for quicker access to your wallet."
        },
        "step2": {
          "title": "Create or Import a Wallet",
          "description": "Be sure to back up your wallet using a secure method. Never share your secret phrase with anyone."
        },
        "step3": {
          "title": "Refresh your browser",
          "description": "Once you set up your wallet, click below to refresh the browser and load up the extension."
        }
      }
    },

    "wigwam": {
      "extension": {
        "step1": {
          "title": "Install the Wigwam extension",
          "description": "We recommend pinning Wigwam to your taskbar for quicker access to your wallet."
        },
        "step2": {
          "title": "Create or Import a Wallet",
          "description": "Be sure to back up your wallet using a secure method. Never share your secret phrase with anyone."
        },
        "step3": {
          "title": "Refresh your browser",
          "description": "Once you set up your wallet, click below to refresh the browser and load up the extension."
        }
      }
    },

    "talisman": {
      "extension": {
        "step1": {
          "title": "Install the Talisman extension",
          "description": "We recommend pinning Talisman to your taskbar for quicker access to your wallet."
        },
        "step2": {
          "title": "Create or Import an Ethereum Wallet",
          "description": "Be sure to back up your wallet using a secure method. Never share your recovery phrase with anyone."
        },
        "step3": {
          "title": "Refresh your browser",
          "description": "Once you set up your wallet, click below to refresh the browser and load up the extension."
        }
      }
    },

    "ctrl": {
      "extension": {
        "step1": {
          "title": "Install the CTRL Wallet extension",
          "description": "We recommend pinning CTRL Wallet to your taskbar for quicker access to your wallet."
        },
        "step2": {
          "title": "Create or Import a Wallet",
          "description": "Be sure to back up your wallet using a secure method. Never share your secret phrase with anyone."
        },
        "step3": {
          "title": "Refresh your browser",
          "description": "Once you set up your wallet, click below to refresh the browser and load up the extension."
        }
      }
    },

    "zeal": {
      "qr_code": {
        "step1": {
          "title": "Open the Zeal app",
          "description": "Add Zeal Wallet to your home screen for faster access to your wallet."
        },
        "step2": {
          "title": "Create or Import a Wallet",
          "description": "Create a new wallet or import an existing one."
        },
        "step3": {
          "title": "Tap the QR icon and scan",
          "description": "Tap the QR icon on your homescreen, scan the code and confirm the prompt to connect."
        }
      },
      "extension": {
        "step1": {
          "title": "Install the Zeal extension",
          "description": "We recommend pinning Zeal to your taskbar for quicker access to your wallet."
        },
        "step2": {
          "title": "Create or Import a Wallet",
          "description": "Be sure to back up your wallet using a secure method. Never share your secret phrase with anyone."
        },
        "step3": {
          "title": "Refresh your browser",
          "description": "Once you set up your wallet, click below to refresh the browser and load up the extension."
        }
      }
    },

    "safepal": {
      "extension": {
        "step1": {
          "title": "Install the SafePal Wallet extension",
          "description": "Click at the top right of your browser and pin SafePal Wallet for easy access."
        },
        "step2": {
          "title": "Create or Import a wallet",
          "description": "Create a new wallet or import an existing one."
        },
        "step3": {
          "title": "Refresh your browser",
          "description": "Once you set up SafePal Wallet, click below to refresh the browser and load up the extension."
        }
      },
      "qr_code": {
        "step1": {
          "title": "Open the SafePal Wallet app",
          "description": "Put SafePal Wallet on your home screen for faster access to your wallet."
        },
        "step2": {
          "title": "Create or Import a Wallet",
          "description": "Create a new wallet or import an existing one."
        },
        "step3": {
          "title": "Tap WalletConnect in Settings",
          "description": "Choose New Connection, then scan the QR code and confirm the prompt to connect."
        }
      }
    },

    "desig": {
      "extension": {
        "step1": {
          "title": "Install the Desig extension",
          "description": "We recommend pinning Desig to your taskbar for easier access to your wallet."
        },
        "step2": {
          "title": "Create a Wallet",
          "description": "Be sure to back up your wallet using a secure method. Never share your secret phrase with anyone."
        },
        "step3": {
          "title": "Refresh your browser",
          "description": "Once you set up your wallet, click below to refresh the browser and load up the extension."
        }
      }
    },

    "subwallet": {
      "extension": {
        "step1": {
          "title": "Install the SubWallet extension",
          "description": "We recommend pinning SubWallet to your taskbar for quicker access to your wallet."
        },
        "step2": {
          "title": "Create or Import a Wallet",
          "description": "Be sure to back up your wallet using a secure method. Never share your recovery phrase with anyone."
        },
        "step3": {
          "title": "Refresh your browser",
          "description": "Once you set up your wallet, click below to refresh the browser and load up the extension."
        }
      },
      "qr_code": {
        "step1": {
          "title": "Open the SubWallet app",
          "description": "We recommend putting SubWallet on your home screen for quicker access."
        },
        "step2": {
          "title": "Create or Import a Wallet",
          "description": "Be sure to back up your wallet using a secure method. Never share your secret phrase with anyone."
        },
        "step3": {
          "title": "Tap the scan button",
          "description": "After you scan, a connection prompt will appear for you to connect your wallet."
        }
      }
    },

    "clv": {
      "extension": {
        "step1": {
          "title": "Install the CLV Wallet extension",
          "description": "We recommend pinning CLV Wallet to your taskbar for quicker access to your wallet."
        },
        "step2": {
          "title": "Create or Import a Wallet",
          "description": "Be sure to back up your wallet using a secure method. Never share your secret phrase with anyone."
        },
        "step3": {
          "title": "Refresh your browser",
          "description": "Once you set up your wallet, click below to refresh the browser and load up the extension."
        }
      },
      "qr_code": {
        "step1": {
          "title": "Open the CLV Wallet app",
          "description": "We recommend putting CLV Wallet on your home screen for quicker access."
        },
        "step2": {
          "title": "Create or Import a Wallet",
          "description": "Be sure to back up your wallet using a secure method. Never share your secret phrase with anyone."
        },
        "step3": {
          "title": "Tap the scan button",
          "description": "After you scan, a connection prompt will appear for you to connect your wallet."
        }
      }
    },

    "okto": {
      "qr_code": {
        "step1": {
          "title": "Open the Okto app",
          "description": "Add Okto to your home screen for quick access"
        },
        "step2": {
          "title": "Create an MPC Wallet",
          "description": "Create an account and generate a wallet"
        },
        "step3": {
          "title": "Tap WalletConnect in Settings",
          "description": "Tap the Scan QR icon at the top right and confirm the prompt to connect."
        }
      }
    },

    "ledger": {
      "desktop": {
        "step1": {
          "title": "Open the Ledger Live app",
          "description": "We recommend putting Ledger Live on your home screen for quicker access."
        },
        "step2": {
          "title": "Set up your Ledger",
          "description": "Set up a new Ledger or connect to an existing one."
        },
        "step3": {
          "title": "Connect",
          "description": "A connection prompt will appear for you to connect your wallet."
        }
      },
      "qr_code": {
        "step1": {
          "title": "Open the Ledger Live app",
          "description": "We recommend putting Ledger Live on your home screen for quicker access."
        },
        "step2": {
          "title": "Set up your Ledger",
          "description": "You can either sync with the desktop app or connect your Ledger."
        },
        "step3": {
          "title": "Scan the code",
          "description": "Tap WalletConnect then Switch to Scanner. After you scan, a connection prompt will appear for you to connect your wallet."
        }
      }
    },

    "valora": {
      "qr_code": {
        "step1": {
          "title": "Open the Valora app",
          "description": "We recommend putting Valora on your home screen for quicker access."
        },
        "step2": {
          "title": "Create or import a wallet",
          "description": "Create a new wallet or import an existing one."
        },
        "step3": {
          "title": "Tap the scan button",
          "description": "After you scan, a connection prompt will appear for you to connect your wallet."
        }
      }
    },

    "gate": {
      "qr_code": {
        "step1": {
          "title": "Open the Gate app",
          "description": "We recommend putting Gate on your home screen for quicker access."
        },
        "step2": {
          "title": "Create or Import a Wallet",
          "description": "Create a new wallet or import an existing one."
        },
        "step3": {
          "title": "Tap the scan button",
          "description": "After you scan, a connection prompt will appear for you to connect your wallet."
        }
      },
      "extension": {
        "step1": {
          "title": "Install the Gate extension",
          "description": "We recommend pinning Gate to your taskbar for easier access to your wallet."
        },
        "step2": {
          "title": "Create or Import a Wallet",
          "description": "Be sure to back up your wallet using a secure method. Never share your secret recovery phrase with anyone."
        },
        "step3": {
          "title": "Refresh your browser",
          "description": "Once you set up your wallet, click below to refresh the browser and load up the extension."
        }
      }
    },

    "gemini": {
      "qr_code": {
        "step1": {
          "title": "Open keys.gemini.com",
          "description": "Visit keys.gemini.com on your mobile browser - no app download required."
        },
        "step2": {
          "title": "Create Your Wallet Instantly",
          "description": "Set up your smart wallet in seconds using your device's built-in authentication."
        },
        "step3": {
          "title": "Scan to Connect",
          "description": "Scan the QR code to instantly connect your wallet - it just works."
        }
      },
      "extension": {
        "step1": {
          "title": "Go to keys.gemini.com",
          "description": "No extensions or downloads needed - your wallet lives securely in the browser."
        },
        "step2": {
          "title": "One-Click Setup",
          "description": "Create your smart wallet instantly with passkey authentication - easier than any wallet out there."
        },
        "step3": {
          "title": "Connect and Go",
          "description": "Approve the connection and you're ready - the unopinionated wallet that just works."
        }
      }
    },

    "xportal": {
      "qr_code": {
        "step1": {
          "description": "Put xPortal on your home screen for faster access to your wallet.",
          "title": "Open the xPortal app"
        },
        "step2": {
          "description": "Create a wallet or import an existing one.",
          "title": "Create or Import a Wallet"
        },
        "step3": {
          "description": "After you scan, a connection prompt will appear for you to connect your wallet.",
          "title": "Tap the Scan QR button"
        }
      }
    },

    "mew": {
      "qr_code": {
        "step1": {
          "description": "We recommend putting MEW Wallet on your home screen for quicker access.",
          "title": "Open the MEW Wallet app"
        },
        "step2": {
          "description": "You can easily backup your wallet using the cloud backup feature.",
          "title": "Create or Import a Wallet"
        },
        "step3": {
          "description": "After you scan, a connection prompt will appear for you to connect your wallet.",
          "title": "Tap the scan button"
        }
      }
    },

    "zilpay": {
      "qr_code": {
        "step1": {
          "title": "Open the ZilPay app",
          "description": "Add ZilPay to your home screen for faster access to your wallet."
        },
        "step2": {
          "title": "Create or Import a Wallet",
          "description": "Create a new wallet or import an existing one."
        },
        "step3": {
          "title": "Tap the scan button",
          "description": "After you scan, a connection prompt will appear for you to connect your wallet."
        }
      }
    },

    "nova": {
      "qr_code": {
        "step1": {
          "title": "Open the Nova Wallet app",
          "description": "Add Nova Wallet to your home screen for faster access to your wallet."
        },
        "step2": {
          "title": "Create or Import a Wallet",
          "description": "Create a new wallet or import an existing one."
        },
        "step3": {
          "title": "Tap the scan button",
          "description": "After you scan, a connection prompt will appear for you to connect your wallet."
        }
      }
    },

    "meco": {
      "qr_code": {
        "step1": {
          "title": "Open the MeCo Wallet app",
          "description": "Put MeCo Wallet on your home screen for faster access to your wallet."
        },
        "step2": {
          "title": "Create or Import a Wallet",
          "description": "Create a new wallet or import an existing one."
        },
        "step3": {
          "title": "Tap the scan button",
          "description": "After you scan, a connection prompt will appear for you to connect your wallet."
        }
      }
    },

    "anchorage_digital": {
      "extension": {
        "step1": {
          "title": "Install the Anchorage Digital extension",
          "description": "We recommend pinning Anchorage Digital to your taskbar for easier access to your wallet."
        },
        "step2": {
          "title": "Scan the QR code to login",
          "description": "Securely connect your organization's wallets to dApps with institutional-grade security."
        },
        "step3": {
          "title": "Refresh your browser",
          "description": "Once you log in, click below to refresh the browser and load up the extension."
        }
      }
    }
  }
}
`;e.s(["en_US_default",0,t])},958816,(e,t,r)=>{function o(e){return(0x100000000+e).toString(16).substring(1)}t.exports={normalizeInput:function(e){let t;if(e instanceof Uint8Array)t=e;else if("string"==typeof e)t=new TextEncoder().encode(e);else throw Error("Input must be an string, Buffer or Uint8Array");return t},toHex:function(e){return Array.prototype.map.call(e,function(e){return(e<16?"0":"")+e.toString(16)}).join("")},debugPrint:function(e,t,r){let n="\n"+e+" = ";for(let s=0;s<t.length;s+=2){if(32===r)n+=o(t[s]).toUpperCase(),n+=" ",n+=o(t[s+1]).toUpperCase();else if(64===r)n+=o(t[s+1]).toUpperCase(),n+=o(t[s]).toUpperCase();else throw Error("Invalid size "+r);s%6==4?n+="\n"+Array(e.length+4).join(" "):s<t.length-2&&(n+=" ")}console.log(n)},testSpeed:function(e,t,r){let o=new Date().getTime(),n=new Uint8Array(t);for(let e=0;e<t;e++)n[e]=e%256;let s=new Date().getTime();console.log("Generated random input in "+(s-o)+"ms"),o=s;for(let s=0;s<r;s++){let r=e(n),s=new Date().getTime(),i=s-o;o=s,console.log("Hashed in "+i+"ms: "+r.substring(0,20)+"..."),console.log(Math.round(t/1048576/(i/1e3)*100)/100+" MB PER SECOND")}}}},513024,(e,t,r)=>{let o=e.r(958816);function n(e,t,r){let o=e[t]+e[r],n=e[t+1]+e[r+1];o>=0x100000000&&n++,e[t]=o,e[t+1]=n}function s(e,t,r,o){let n=e[t]+r;r<0&&(n+=0x100000000);let s=e[t+1]+o;n>=0x100000000&&s++,e[t]=n,e[t+1]=s}function i(e,t){return e[t]^e[t+1]<<8^e[t+2]<<16^e[t+3]<<24}function a(e,t,r,o,i,a){let l=u[i],c=u[i+1],h=u[a],d=u[a+1];n(p,e,t),s(p,e,l,c);let y=p[o]^p[e],f=p[o+1]^p[e+1];p[o]=f,p[o+1]=y,n(p,r,o),y=p[t]^p[r],f=p[t+1]^p[r+1],p[t]=y>>>24^f<<8,p[t+1]=f>>>24^y<<8,n(p,e,t),s(p,e,h,d),y=p[o]^p[e],f=p[o+1]^p[e+1],p[o]=y>>>16^f<<16,p[o+1]=f>>>16^y<<16,n(p,r,o),y=p[t]^p[r],f=p[t+1]^p[r+1],p[t]=f>>>31^y<<1,p[t+1]=y>>>31^f<<1}let l=new Uint32Array([0xf3bcc908,0x6a09e667,0x84caa73b,0xbb67ae85,0xfe94f82b,0x3c6ef372,0x5f1d36f1,0xa54ff53a,0xade682d1,0x510e527f,0x2b3e6c1f,0x9b05688c,0xfb41bd6b,0x1f83d9ab,0x137e2179,0x5be0cd19]),c=new Uint8Array([0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,14,10,4,8,9,15,13,6,1,12,0,2,11,7,5,3,11,8,12,0,5,2,15,13,10,14,3,6,7,1,9,4,7,9,3,1,13,12,11,14,2,6,5,10,4,0,15,8,9,0,5,7,2,4,10,15,14,1,11,12,6,8,3,13,2,12,6,10,0,11,8,3,4,13,7,5,15,14,1,9,12,5,1,15,14,13,4,10,0,7,6,3,9,2,8,11,13,11,7,14,12,1,3,9,5,0,15,4,8,6,2,10,6,15,14,9,11,3,0,8,12,2,13,7,1,4,10,5,10,2,8,4,7,6,1,5,15,11,9,14,3,12,13,0,0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,14,10,4,8,9,15,13,6,1,12,0,2,11,7,5,3].map(function(e){return 2*e})),p=new Uint32Array(32),u=new Uint32Array(32);function h(e,t){let r=0;for(r=0;r<16;r++)p[r]=e.h[r],p[r+16]=l[r];for(p[24]=p[24]^e.t,p[25]=p[25]^e.t/0x100000000,t&&(p[28]=~p[28],p[29]=~p[29]),r=0;r<32;r++)u[r]=i(e.b,4*r);for(r=0;r<12;r++)a(0,8,16,24,c[16*r+0],c[16*r+1]),a(2,10,18,26,c[16*r+2],c[16*r+3]),a(4,12,20,28,c[16*r+4],c[16*r+5]),a(6,14,22,30,c[16*r+6],c[16*r+7]),a(0,10,20,30,c[16*r+8],c[16*r+9]),a(2,12,22,24,c[16*r+10],c[16*r+11]),a(4,14,16,26,c[16*r+12],c[16*r+13]),a(6,8,18,28,c[16*r+14],c[16*r+15]);for(r=0;r<16;r++)e.h[r]=e.h[r]^p[r]^p[r+16]}let d=new Uint8Array([0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]);function y(e,t,r,o){if(0===e||e>64)throw Error("Illegal output length, expected 0 < length <= 64");if(t&&t.length>64)throw Error("Illegal key, expected Uint8Array with 0 < length <= 64");if(r&&16!==r.length)throw Error("Illegal salt, expected Uint8Array with length is 16");if(o&&16!==o.length)throw Error("Illegal personal, expected Uint8Array with length is 16");let n={b:new Uint8Array(128),h:new Uint32Array(16),t:0,c:0,outlen:e};d.fill(0),d[0]=e,t&&(d[1]=t.length),d[2]=1,d[3]=1,r&&d.set(r,32),o&&d.set(o,48);for(let e=0;e<16;e++)n.h[e]=l[e]^i(d,4*e);return t&&(f(n,t),n.c=128),n}function f(e,t){for(let r=0;r<t.length;r++)128===e.c&&(e.t+=e.c,h(e,!1),e.c=0),e.b[e.c++]=t[r]}function m(e){for(e.t+=e.c;e.c<128;)e.b[e.c++]=0;h(e,!0);let t=new Uint8Array(e.outlen);for(let r=0;r<e.outlen;r++)t[r]=e.h[r>>2]>>8*(3&r);return t}function w(e,t,r,n,s){r=r||64,e=o.normalizeInput(e),n&&(n=o.normalizeInput(n)),s&&(s=o.normalizeInput(s));let i=y(r,t,n,s);return f(i,e),m(i)}t.exports={blake2b:w,blake2bHex:function(e,t,r,n,s){let i=w(e,t,r,n,s);return o.toHex(i)},blake2bInit:y,blake2bUpdate:f,blake2bFinal:m}},24350,(e,t,r)=>{let o=e.r(958816);function n(e,t,r,o,n,i){l[e]=l[e]+l[t]+n,l[o]=s(l[o]^l[e],16),l[r]=l[r]+l[o],l[t]=s(l[t]^l[r],12),l[e]=l[e]+l[t]+i,l[o]=s(l[o]^l[e],8),l[r]=l[r]+l[o],l[t]=s(l[t]^l[r],7)}function s(e,t){return e>>>t^e<<32-t}let i=new Uint32Array([0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19]),a=new Uint8Array([0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,14,10,4,8,9,15,13,6,1,12,0,2,11,7,5,3,11,8,12,0,5,2,15,13,10,14,3,6,7,1,9,4,7,9,3,1,13,12,11,14,2,6,5,10,4,0,15,8,9,0,5,7,2,4,10,15,14,1,11,12,6,8,3,13,2,12,6,10,0,11,8,3,4,13,7,5,15,14,1,9,12,5,1,15,14,13,4,10,0,7,6,3,9,2,8,11,13,11,7,14,12,1,3,9,5,0,15,4,8,6,2,10,6,15,14,9,11,3,0,8,12,2,13,7,1,4,10,5,10,2,8,4,7,6,1,5,15,11,9,14,3,12,13,0]),l=new Uint32Array(16),c=new Uint32Array(16);function p(e,t){let r=0;for(r=0;r<8;r++)l[r]=e.h[r],l[r+8]=i[r];for(l[12]^=e.t,l[13]^=e.t/0x100000000,t&&(l[14]=~l[14]),r=0;r<16;r++){var o,s;c[r]=(o=e.b)[s=4*r]^o[s+1]<<8^o[s+2]<<16^o[s+3]<<24}for(r=0;r<10;r++)n(0,4,8,12,c[a[16*r+0]],c[a[16*r+1]]),n(1,5,9,13,c[a[16*r+2]],c[a[16*r+3]]),n(2,6,10,14,c[a[16*r+4]],c[a[16*r+5]]),n(3,7,11,15,c[a[16*r+6]],c[a[16*r+7]]),n(0,5,10,15,c[a[16*r+8]],c[a[16*r+9]]),n(1,6,11,12,c[a[16*r+10]],c[a[16*r+11]]),n(2,7,8,13,c[a[16*r+12]],c[a[16*r+13]]),n(3,4,9,14,c[a[16*r+14]],c[a[16*r+15]]);for(r=0;r<8;r++)e.h[r]^=l[r]^l[r+8]}function u(e,t){if(!(e>0&&e<=32))throw Error("Incorrect output length, should be in [1, 32]");let r=t?t.length:0;if(t&&!(r>0&&r<=32))throw Error("Incorrect key length, should be in [1, 32]");let o={h:new Uint32Array(i),b:new Uint8Array(64),c:0,t:0,outlen:e};return o.h[0]^=0x1010000^r<<8^e,r>0&&(h(o,t),o.c=64),o}function h(e,t){for(let r=0;r<t.length;r++)64===e.c&&(e.t+=e.c,p(e,!1),e.c=0),e.b[e.c++]=t[r]}function d(e){for(e.t+=e.c;e.c<64;)e.b[e.c++]=0;p(e,!0);let t=new Uint8Array(e.outlen);for(let r=0;r<e.outlen;r++)t[r]=e.h[r>>2]>>8*(3&r)&255;return t}function y(e,t,r){r=r||32,e=o.normalizeInput(e);let n=u(r,t);return h(n,e),d(n)}t.exports={blake2s:y,blake2sHex:function(e,t,r){let n=y(e,t,r);return o.toHex(n)},blake2sInit:u,blake2sUpdate:h,blake2sFinal:d}},812837,(e,t,r)=>{let o=e.r(513024),n=e.r(24350);t.exports={blake2b:o.blake2b,blake2bHex:o.blake2bHex,blake2bInit:o.blake2bInit,blake2bUpdate:o.blake2bUpdate,blake2bFinal:o.blake2bFinal,blake2s:n.blake2s,blake2sHex:n.blake2sHex,blake2sInit:n.blake2sInit,blake2sUpdate:n.blake2sUpdate,blake2sFinal:n.blake2sFinal}},540022,(e,t,r)=>{var o="u">typeof globalThis&&globalThis||"u">typeof self&&self||e.g,n=function(){function e(){this.fetch=!1,this.DOMException=o.DOMException}return e.prototype=o,new e}();(function(t){var r=void 0!==n&&n||"u">typeof self&&self||e.g||{},o={searchParams:"URLSearchParams"in r,iterable:"Symbol"in r&&"iterator"in Symbol,blob:"FileReader"in r&&"Blob"in r&&function(){try{return new Blob,!0}catch(e){return!1}}(),formData:"FormData"in r,arrayBuffer:"ArrayBuffer"in r};if(o.arrayBuffer)var s=["[object Int8Array]","[object Uint8Array]","[object Uint8ClampedArray]","[object Int16Array]","[object Uint16Array]","[object Int32Array]","[object Uint32Array]","[object Float32Array]","[object Float64Array]"],i=ArrayBuffer.isView||function(e){return e&&s.indexOf(Object.prototype.toString.call(e))>-1};function a(e){if("string"!=typeof e&&(e=String(e)),/[^a-z0-9\-#$%&'*+.^_`|~!]/i.test(e)||""===e)throw TypeError('Invalid character in header field name: "'+e+'"');return e.toLowerCase()}function l(e){return"string"!=typeof e&&(e=String(e)),e}function c(e){var t={next:function(){var t=e.shift();return{done:void 0===t,value:t}}};return o.iterable&&(t[Symbol.iterator]=function(){return t}),t}function p(e){this.map={},e instanceof p?e.forEach(function(e,t){this.append(t,e)},this):Array.isArray(e)?e.forEach(function(e){if(2!=e.length)throw TypeError("Headers constructor: expected name/value pair to be length 2, found"+e.length);this.append(e[0],e[1])},this):e&&Object.getOwnPropertyNames(e).forEach(function(t){this.append(t,e[t])},this)}function u(e){if(!e._noBody){if(e.bodyUsed)return Promise.reject(TypeError("Already read"));e.bodyUsed=!0}}function h(e){return new Promise(function(t,r){e.onload=function(){t(e.result)},e.onerror=function(){r(e.error)}})}function d(e){var t=new FileReader,r=h(t);return t.readAsArrayBuffer(e),r}function y(e){if(e.slice)return e.slice(0);var t=new Uint8Array(e.byteLength);return t.set(new Uint8Array(e)),t.buffer}function f(){return this.bodyUsed=!1,this._initBody=function(e){if(this.bodyUsed=this.bodyUsed,this._bodyInit=e,e)if("string"==typeof e)this._bodyText=e;else if(o.blob&&Blob.prototype.isPrototypeOf(e))this._bodyBlob=e;else if(o.formData&&FormData.prototype.isPrototypeOf(e))this._bodyFormData=e;else if(o.searchParams&&URLSearchParams.prototype.isPrototypeOf(e))this._bodyText=e.toString();else{var t;o.arrayBuffer&&o.blob&&(t=e)&&DataView.prototype.isPrototypeOf(t)?(this._bodyArrayBuffer=y(e.buffer),this._bodyInit=new Blob([this._bodyArrayBuffer])):o.arrayBuffer&&(ArrayBuffer.prototype.isPrototypeOf(e)||i(e))?this._bodyArrayBuffer=y(e):this._bodyText=e=Object.prototype.toString.call(e)}else this._noBody=!0,this._bodyText="";!this.headers.get("content-type")&&("string"==typeof e?this.headers.set("content-type","text/plain;charset=UTF-8"):this._bodyBlob&&this._bodyBlob.type?this.headers.set("content-type",this._bodyBlob.type):o.searchParams&&URLSearchParams.prototype.isPrototypeOf(e)&&this.headers.set("content-type","application/x-www-form-urlencoded;charset=UTF-8"))},o.blob&&(this.blob=function(){var e=u(this);if(e)return e;if(this._bodyBlob)return Promise.resolve(this._bodyBlob);if(this._bodyArrayBuffer)return Promise.resolve(new Blob([this._bodyArrayBuffer]));if(!this._bodyFormData)return Promise.resolve(new Blob([this._bodyText]));throw Error("could not read FormData body as blob")}),this.arrayBuffer=function(){if(this._bodyArrayBuffer){var e=u(this);return e||(ArrayBuffer.isView(this._bodyArrayBuffer)?Promise.resolve(this._bodyArrayBuffer.buffer.slice(this._bodyArrayBuffer.byteOffset,this._bodyArrayBuffer.byteOffset+this._bodyArrayBuffer.byteLength)):Promise.resolve(this._bodyArrayBuffer))}if(o.blob)return this.blob().then(d);throw Error("could not read as ArrayBuffer")},this.text=function(){var e,t,r,o,n,s=u(this);if(s)return s;if(this._bodyBlob)return e=this._bodyBlob,r=h(t=new FileReader),n=(o=/charset=([A-Za-z0-9_-]+)/.exec(e.type))?o[1]:"utf-8",t.readAsText(e,n),r;if(this._bodyArrayBuffer)return Promise.resolve(function(e){for(var t=new Uint8Array(e),r=Array(t.length),o=0;o<t.length;o++)r[o]=String.fromCharCode(t[o]);return r.join("")}(this._bodyArrayBuffer));if(!this._bodyFormData)return Promise.resolve(this._bodyText);throw Error("could not read FormData body as text")},o.formData&&(this.formData=function(){return this.text().then(b)}),this.json=function(){return this.text().then(JSON.parse)},this}p.prototype.append=function(e,t){e=a(e),t=l(t);var r=this.map[e];this.map[e]=r?r+", "+t:t},p.prototype.delete=function(e){delete this.map[a(e)]},p.prototype.get=function(e){return e=a(e),this.has(e)?this.map[e]:null},p.prototype.has=function(e){return this.map.hasOwnProperty(a(e))},p.prototype.set=function(e,t){this.map[a(e)]=l(t)},p.prototype.forEach=function(e,t){for(var r in this.map)this.map.hasOwnProperty(r)&&e.call(t,this.map[r],r,this)},p.prototype.keys=function(){var e=[];return this.forEach(function(t,r){e.push(r)}),c(e)},p.prototype.values=function(){var e=[];return this.forEach(function(t){e.push(t)}),c(e)},p.prototype.entries=function(){var e=[];return this.forEach(function(t,r){e.push([r,t])}),c(e)},o.iterable&&(p.prototype[Symbol.iterator]=p.prototype.entries);var m=["CONNECT","DELETE","GET","HEAD","OPTIONS","PATCH","POST","PUT","TRACE"];function w(e,t){if(!(this instanceof w))throw TypeError('Please use the "new" operator, this DOM object constructor cannot be called as a function.');var o,n,s=(t=t||{}).body;if(e instanceof w){if(e.bodyUsed)throw TypeError("Already read");this.url=e.url,this.credentials=e.credentials,t.headers||(this.headers=new p(e.headers)),this.method=e.method,this.mode=e.mode,this.signal=e.signal,s||null==e._bodyInit||(s=e._bodyInit,e.bodyUsed=!0)}else this.url=String(e);if(this.credentials=t.credentials||this.credentials||"same-origin",(t.headers||!this.headers)&&(this.headers=new p(t.headers)),this.method=(n=(o=t.method||this.method||"GET").toUpperCase(),m.indexOf(n)>-1?n:o),this.mode=t.mode||this.mode||null,this.signal=t.signal||this.signal||function(){if("AbortController"in r)return new AbortController().signal}(),this.referrer=null,("GET"===this.method||"HEAD"===this.method)&&s)throw TypeError("Body not allowed for GET or HEAD requests");if(this._initBody(s),("GET"===this.method||"HEAD"===this.method)&&("no-store"===t.cache||"no-cache"===t.cache)){var i=/([?&])_=[^&]*/;i.test(this.url)?this.url=this.url.replace(i,"$1_="+new Date().getTime()):this.url+=(/\?/.test(this.url)?"&":"?")+"_="+new Date().getTime()}}function b(e){var t=new FormData;return e.trim().split("&").forEach(function(e){if(e){var r=e.split("="),o=r.shift().replace(/\+/g," "),n=r.join("=").replace(/\+/g," ");t.append(decodeURIComponent(o),decodeURIComponent(n))}}),t}function g(e,t){if(!(this instanceof g))throw TypeError('Please use the "new" operator, this DOM object constructor cannot be called as a function.');if(t||(t={}),this.type="default",this.status=void 0===t.status?200:t.status,this.status<200||this.status>599)throw RangeError("Failed to construct 'Response': The status provided (0) is outside the range [200, 599].");this.ok=this.status>=200&&this.status<300,this.statusText=void 0===t.statusText?"":""+t.statusText,this.headers=new p(t.headers),this.url=t.url||"",this._initBody(e)}w.prototype.clone=function(){return new w(this,{body:this._bodyInit})},f.call(w.prototype),f.call(g.prototype),g.prototype.clone=function(){return new g(this._bodyInit,{status:this.status,statusText:this.statusText,headers:new p(this.headers),url:this.url})},g.error=function(){var e=new g(null,{status:200,statusText:""});return e.ok=!1,e.status=0,e.type="error",e};var v=[301,302,303,307,308];g.redirect=function(e,t){if(-1===v.indexOf(t))throw RangeError("Invalid status code");return new g(null,{status:t,headers:{location:e}})},t.DOMException=r.DOMException;try{new t.DOMException}catch(e){t.DOMException=function(e,t){this.message=e,this.name=t;var r=Error(e);this.stack=r.stack},t.DOMException.prototype=Object.create(Error.prototype),t.DOMException.prototype.constructor=t.DOMException}function x(e,n){return new Promise(function(s,i){var c=new w(e,n);if(c.signal&&c.signal.aborted)return i(new t.DOMException("Aborted","AbortError"));var u=new XMLHttpRequest;function h(){u.abort()}if(u.onload=function(){var e,t,r={statusText:u.statusText,headers:(e=u.getAllResponseHeaders()||"",t=new p,e.replace(/\r?\n[\t ]+/g," ").split("\r").map(function(e){return 0===e.indexOf("\n")?e.substr(1,e.length):e}).forEach(function(e){var r=e.split(":"),o=r.shift().trim();if(o){var n=r.join(":").trim();try{t.append(o,n)}catch(e){console.warn("Response "+e.message)}}}),t)};0===c.url.indexOf("file://")&&(u.status<200||u.status>599)?r.status=200:r.status=u.status,r.url="responseURL"in u?u.responseURL:r.headers.get("X-Request-URL");var o="response"in u?u.response:u.responseText;setTimeout(function(){s(new g(o,r))},0)},u.onerror=function(){setTimeout(function(){i(TypeError("Network request failed"))},0)},u.ontimeout=function(){setTimeout(function(){i(TypeError("Network request timed out"))},0)},u.onabort=function(){setTimeout(function(){i(new t.DOMException("Aborted","AbortError"))},0)},u.open(c.method,function(e){try{return""===e&&r.location.href?r.location.href:e}catch(t){return e}}(c.url),!0),"include"===c.credentials?u.withCredentials=!0:"omit"===c.credentials&&(u.withCredentials=!1),"responseType"in u&&(o.blob?u.responseType="blob":o.arrayBuffer&&(u.responseType="arraybuffer")),n&&"object"==typeof n.headers&&!(n.headers instanceof p||r.Headers&&n.headers instanceof r.Headers)){var d=[];Object.getOwnPropertyNames(n.headers).forEach(function(e){d.push(a(e)),u.setRequestHeader(e,l(n.headers[e]))}),c.headers.forEach(function(e,t){-1===d.indexOf(t)&&u.setRequestHeader(t,e)})}else c.headers.forEach(function(e,t){u.setRequestHeader(t,e)});c.signal&&(c.signal.addEventListener("abort",h),u.onreadystatechange=function(){4===u.readyState&&c.signal.removeEventListener("abort",h)}),u.send(void 0===c._bodyInit?null:c._bodyInit)})}x.polyfill=!0,r.fetch||(r.fetch=x,r.Headers=p,r.Request=w,r.Response=g),t.Headers=p,t.Request=w,t.Response=g,t.fetch=x,Object.defineProperty(t,"__esModule",{value:!0})})({}),n.fetch.ponyfill=!0,delete n.fetch.polyfill;var s=o.fetch?o:n;(r=s.fetch).default=s.fetch,r.fetch=s.fetch,r.Headers=s.Headers,r.Request=s.Request,r.Response=s.Response,t.exports=r},714278,(e,t,r)=>{"use strict";var o=Object.prototype.hasOwnProperty,n="~";function s(){}function i(e,t,r){this.fn=e,this.context=t,this.once=r||!1}function a(e,t,r,o,s){if("function"!=typeof r)throw TypeError("The listener must be a function");var a=new i(r,o||e,s),l=n?n+t:t;return e._events[l]?e._events[l].fn?e._events[l]=[e._events[l],a]:e._events[l].push(a):(e._events[l]=a,e._eventsCount++),e}function l(e,t){0==--e._eventsCount?e._events=new s:delete e._events[t]}function c(){this._events=new s,this._eventsCount=0}Object.create&&(s.prototype=Object.create(null),new s().__proto__||(n=!1)),c.prototype.eventNames=function(){var e,t,r=[];if(0===this._eventsCount)return r;for(t in e=this._events)o.call(e,t)&&r.push(n?t.slice(1):t);return Object.getOwnPropertySymbols?r.concat(Object.getOwnPropertySymbols(e)):r},c.prototype.listeners=function(e){var t=n?n+e:e,r=this._events[t];if(!r)return[];if(r.fn)return[r.fn];for(var o=0,s=r.length,i=Array(s);o<s;o++)i[o]=r[o].fn;return i},c.prototype.listenerCount=function(e){var t=n?n+e:e,r=this._events[t];return r?r.fn?1:r.length:0},c.prototype.emit=function(e,t,r,o,s,i){var a=n?n+e:e;if(!this._events[a])return!1;var l,c,p=this._events[a],u=arguments.length;if(p.fn){switch(p.once&&this.removeListener(e,p.fn,void 0,!0),u){case 1:return p.fn.call(p.context),!0;case 2:return p.fn.call(p.context,t),!0;case 3:return p.fn.call(p.context,t,r),!0;case 4:return p.fn.call(p.context,t,r,o),!0;case 5:return p.fn.call(p.context,t,r,o,s),!0;case 6:return p.fn.call(p.context,t,r,o,s,i),!0}for(c=1,l=Array(u-1);c<u;c++)l[c-1]=arguments[c];p.fn.apply(p.context,l)}else{var h,d=p.length;for(c=0;c<d;c++)switch(p[c].once&&this.removeListener(e,p[c].fn,void 0,!0),u){case 1:p[c].fn.call(p[c].context);break;case 2:p[c].fn.call(p[c].context,t);break;case 3:p[c].fn.call(p[c].context,t,r);break;case 4:p[c].fn.call(p[c].context,t,r,o);break;default:if(!l)for(h=1,l=Array(u-1);h<u;h++)l[h-1]=arguments[h];p[c].fn.apply(p[c].context,l)}}return!0},c.prototype.on=function(e,t,r){return a(this,e,t,r,!1)},c.prototype.once=function(e,t,r){return a(this,e,t,r,!0)},c.prototype.removeListener=function(e,t,r,o){var s=n?n+e:e;if(!this._events[s])return this;if(!t)return l(this,s),this;var i=this._events[s];if(i.fn)i.fn!==t||o&&!i.once||r&&i.context!==r||l(this,s);else{for(var a=0,c=[],p=i.length;a<p;a++)(i[a].fn!==t||o&&!i[a].once||r&&i[a].context!==r)&&c.push(i[a]);c.length?this._events[s]=1===c.length?c[0]:c:l(this,s)}return this},c.prototype.removeAllListeners=function(e){var t;return e?(t=n?n+e:e,this._events[t]&&l(this,t)):(this._events=new s,this._eventsCount=0),this},c.prototype.off=c.prototype.removeListener,c.prototype.addListener=c.prototype.on,c.prefixed=n,c.EventEmitter=c,t.exports=c},379666,(e,t,r)=>{"use strict";var o,n="object"==typeof Reflect?Reflect:null,s=n&&"function"==typeof n.apply?n.apply:function(e,t,r){return Function.prototype.apply.call(e,t,r)};o=n&&"function"==typeof n.ownKeys?n.ownKeys:Object.getOwnPropertySymbols?function(e){return Object.getOwnPropertyNames(e).concat(Object.getOwnPropertySymbols(e))}:function(e){return Object.getOwnPropertyNames(e)};var i=Number.isNaN||function(e){return e!=e};function a(){a.init.call(this)}t.exports=a,t.exports.once=function(e,t){return new Promise(function(r,o){var n,s,i;function a(r){e.removeListener(t,l),o(r)}function l(){"function"==typeof e.removeListener&&e.removeListener("error",a),r([].slice.call(arguments))}w(e,t,l,{once:!0}),"error"!==t&&(n=e,s=a,i={once:!0},"function"==typeof n.on&&w(n,"error",s,i))})},a.EventEmitter=a,a.prototype._events=void 0,a.prototype._eventsCount=0,a.prototype._maxListeners=void 0;var l=10;function c(e){if("function"!=typeof e)throw TypeError('The "listener" argument must be of type Function. Received type '+typeof e)}function p(e){return void 0===e._maxListeners?a.defaultMaxListeners:e._maxListeners}function u(e,t,r,o){if(c(r),void 0===(s=e._events)?(s=e._events=Object.create(null),e._eventsCount=0):(void 0!==s.newListener&&(e.emit("newListener",t,r.listener?r.listener:r),s=e._events),i=s[t]),void 0===i)i=s[t]=r,++e._eventsCount;else if("function"==typeof i?i=s[t]=o?[r,i]:[i,r]:o?i.unshift(r):i.push(r),(n=p(e))>0&&i.length>n&&!i.warned){i.warned=!0;var n,s,i,a=Error("Possible EventEmitter memory leak detected. "+i.length+" "+String(t)+" listeners added. Use emitter.setMaxListeners() to increase limit");a.name="MaxListenersExceededWarning",a.emitter=e,a.type=t,a.count=i.length,console&&console.warn&&console.warn(a)}return e}function h(){if(!this.fired)return(this.target.removeListener(this.type,this.wrapFn),this.fired=!0,0==arguments.length)?this.listener.call(this.target):this.listener.apply(this.target,arguments)}function d(e,t,r){var o={fired:!1,wrapFn:void 0,target:e,type:t,listener:r},n=h.bind(o);return n.listener=r,o.wrapFn=n,n}function y(e,t,r){var o=e._events;if(void 0===o)return[];var n=o[t];return void 0===n?[]:"function"==typeof n?r?[n.listener||n]:[n]:r?function(e){for(var t=Array(e.length),r=0;r<t.length;++r)t[r]=e[r].listener||e[r];return t}(n):m(n,n.length)}function f(e){var t=this._events;if(void 0!==t){var r=t[e];if("function"==typeof r)return 1;if(void 0!==r)return r.length}return 0}function m(e,t){for(var r=Array(t),o=0;o<t;++o)r[o]=e[o];return r}function w(e,t,r,o){if("function"==typeof e.on)o.once?e.once(t,r):e.on(t,r);else if("function"==typeof e.addEventListener)e.addEventListener(t,function n(s){o.once&&e.removeEventListener(t,n),r(s)});else throw TypeError('The "emitter" argument must be of type EventEmitter. Received type '+typeof e)}Object.defineProperty(a,"defaultMaxListeners",{enumerable:!0,get:function(){return l},set:function(e){if("number"!=typeof e||e<0||i(e))throw RangeError('The value of "defaultMaxListeners" is out of range. It must be a non-negative number. Received '+e+".");l=e}}),a.init=function(){(void 0===this._events||this._events===Object.getPrototypeOf(this)._events)&&(this._events=Object.create(null),this._eventsCount=0),this._maxListeners=this._maxListeners||void 0},a.prototype.setMaxListeners=function(e){if("number"!=typeof e||e<0||i(e))throw RangeError('The value of "n" is out of range. It must be a non-negative number. Received '+e+".");return this._maxListeners=e,this},a.prototype.getMaxListeners=function(){return p(this)},a.prototype.emit=function(e){for(var t=[],r=1;r<arguments.length;r++)t.push(arguments[r]);var o="error"===e,n=this._events;if(void 0!==n)o=o&&void 0===n.error;else if(!o)return!1;if(o){if(t.length>0&&(i=t[0]),i instanceof Error)throw i;var i,a=Error("Unhandled error."+(i?" ("+i.message+")":""));throw a.context=i,a}var l=n[e];if(void 0===l)return!1;if("function"==typeof l)s(l,this,t);else for(var c=l.length,p=m(l,c),r=0;r<c;++r)s(p[r],this,t);return!0},a.prototype.addListener=function(e,t){return u(this,e,t,!1)},a.prototype.on=a.prototype.addListener,a.prototype.prependListener=function(e,t){return u(this,e,t,!0)},a.prototype.once=function(e,t){return c(t),this.on(e,d(this,e,t)),this},a.prototype.prependOnceListener=function(e,t){return c(t),this.prependListener(e,d(this,e,t)),this},a.prototype.removeListener=function(e,t){var r,o,n,s,i;if(c(t),void 0===(o=this._events)||void 0===(r=o[e]))return this;if(r===t||r.listener===t)0==--this._eventsCount?this._events=Object.create(null):(delete o[e],o.removeListener&&this.emit("removeListener",e,r.listener||t));else if("function"!=typeof r){for(n=-1,s=r.length-1;s>=0;s--)if(r[s]===t||r[s].listener===t){i=r[s].listener,n=s;break}if(n<0)return this;0===n?r.shift():function(e,t){for(;t+1<e.length;t++)e[t]=e[t+1];e.pop()}(r,n),1===r.length&&(o[e]=r[0]),void 0!==o.removeListener&&this.emit("removeListener",e,i||t)}return this},a.prototype.off=a.prototype.removeListener,a.prototype.removeAllListeners=function(e){var t,r,o;if(void 0===(r=this._events))return this;if(void 0===r.removeListener)return 0==arguments.length?(this._events=Object.create(null),this._eventsCount=0):void 0!==r[e]&&(0==--this._eventsCount?this._events=Object.create(null):delete r[e]),this;if(0==arguments.length){var n,s=Object.keys(r);for(o=0;o<s.length;++o)"removeListener"!==(n=s[o])&&this.removeAllListeners(n);return this.removeAllListeners("removeListener"),this._events=Object.create(null),this._eventsCount=0,this}if("function"==typeof(t=r[e]))this.removeListener(e,t);else if(void 0!==t)for(o=t.length-1;o>=0;o--)this.removeListener(e,t[o]);return this},a.prototype.listeners=function(e){return y(this,e,!0)},a.prototype.rawListeners=function(e){return y(this,e,!1)},a.listenerCount=function(e,t){return"function"==typeof e.listenerCount?e.listenerCount(t):f.call(e,t)},a.prototype.listenerCount=f,a.prototype.eventNames=function(){return this._eventsCount>0?o(this._events):[]}},782705,e=>{"use strict";let t=(0,e.i(55818).defineChain)({id:1,name:"Ethereum",nativeCurrency:{name:"Ether",symbol:"ETH",decimals:18},blockTime:12e3,rpcUrls:{default:{http:["https://ethereum.reth.rs/rpc"]}},blockExplorers:{default:{name:"Etherscan",url:"https://etherscan.io",apiUrl:"https://api.etherscan.io/api"}},contracts:{ensUniversalResolver:{address:"0xeeeeeeee14d718c2b47d9923deab1335e144eeee",blockCreated:0x16041f6},multicall3:{address:"0xca11bde05977b3631167028862be2a173976ca11",blockCreated:0xdb04c1}}});e.s(["mainnet",0,t])},257223,397478,e=>{"use strict";var t=e.i(610629),r=e.i(393163),o=e.i(904963),n=e.i(924164);e.s(["hashMessage",0,function(e,s){let i,a;return(0,t.keccak256)((i="string"==typeof e?(0,n.stringToHex)(e):"string"==typeof e.raw?e.raw:(0,n.bytesToHex)(e.raw),a=(0,n.stringToHex)(`\x19Ethereum Signed Message:
${(0,o.size)(i)}`),(0,r.concat)([a,i])),s)}],257223);var s=e.i(483291),i=e.i(339458),a=e.i(684705),l=e.i(830764),c=e.i(320090);class p extends c.BaseError{constructor({domain:e}){super(`Invalid domain "${(0,l.stringify)(e)}".`,{metaMessages:["Must be a valid EIP-712 domain."]})}}class u extends c.BaseError{constructor({primaryType:e,types:t}){super(`Invalid primary type \`${e}\` must be one of \`${JSON.stringify(Object.keys(t))}\`.`,{docsPath:"/api/glossary/Errors#typeddatainvalidprimarytypeerror",metaMessages:["Check that the primary type is a key in `types`."]})}}class h extends c.BaseError{constructor({type:e}){super(`Struct type "${e}" is invalid.`,{metaMessages:["Struct type must not be a Solidity type."],name:"InvalidStructTypeError"})}}class d extends c.BaseError{constructor({type:e}){const t=e.replace(/^(u?int)/,"$&256");super(`Type "${e}" is not a valid EIP-712 type.`,{metaMessages:[`Use "${t}" instead.`],name:"InvalidTypedDataTypeError"})}}var y=e.i(252422),f=e.i(230227);function m({data:e,primaryType:r,types:o}){let i=function e({data:r,primaryType:o,types:i}){let a=[{type:"bytes32"}],l=[function({primaryType:e,types:r}){let o=(0,n.toHex)(function({primaryType:e,types:t}){let r="",o=function e({primaryType:t,types:r},o=new Set){let n=t.match(/^\w*/u),s=n?.[0];if(o.has(s)||void 0===r[s])return o;for(let t of(o.add(s),r[s]))e({primaryType:t.type,types:r},o);return o}({primaryType:e,types:t});for(let n of(o.delete(e),[e,...Array.from(o).sort()]))r+=`${n}(${t[n].map(({name:e,type:t})=>`${t} ${e}`).join(",")})`;return r}({primaryType:e,types:r}));return(0,t.keccak256)(o)}({primaryType:o,types:i})];for(let c of i[o]){let[o,p]=function r({types:o,name:i,type:a,value:l}){if(void 0!==o[a])return[{type:"bytes32"},(0,t.keccak256)(e({data:l,primaryType:a,types:o}))];if("bytes"===a)return[{type:"bytes32"},(0,t.keccak256)(l)];if("string"===a)return[{type:"bytes32"},(0,t.keccak256)((0,n.toHex)(l))];if(a.lastIndexOf("]")===a.length-1){let e=a.slice(0,a.lastIndexOf("[")),n=l.map(t=>r({name:i,type:e,types:o,value:t}));return[{type:"bytes32"},(0,t.keccak256)((0,s.encodeAbiParameters)(n.map(([e])=>e),n.map(([,e])=>e)))]}return[{type:a},l]}({types:i,name:c.name,type:c.type,value:r[c.name]});a.push(o),l.push(p)}return(0,s.encodeAbiParameters)(a,l)}({data:e,primaryType:r,types:o});return(0,t.keccak256)(i)}e.s(["hashTypedData",0,function(e){let{domain:s={},message:l,primaryType:c}=e,w={EIP712Domain:function({domain:e}){return["string"==typeof e?.name&&{name:"name",type:"string"},e?.version&&{name:"version",type:"string"},("number"==typeof e?.chainId||"bigint"==typeof e?.chainId)&&{name:"chainId",type:"uint256"},e?.verifyingContract&&{name:"verifyingContract",type:"address"},e?.salt&&{name:"salt",type:"bytes32"}].filter(Boolean)}({domain:s}),...e.types};!function(e){let{domain:t,message:r,primaryType:s,types:l}=e,c=(e,t)=>{for(let r of e){let{name:e,type:s}=r,p=t[e],u=s.replace(/(\[[0-9]*\])+$/,"");if("int"===u||"uint"===u)throw new d({type:s});let m=s.match(f.integerRegex);if(m&&("number"==typeof p||"bigint"==typeof p)){let[e,t,r]=m;(0,n.numberToHex)(p,{signed:"int"===t,size:Number.parseInt(r,10)/8})}if("address"===s&&"string"==typeof p&&!(0,y.isAddress)(p))throw new a.InvalidAddressError({address:p});let w=s.match(f.bytesRegex);if(w){let[e,t]=w;if(t&&(0,o.size)(p)!==Number.parseInt(t,10))throw new i.BytesSizeMismatchError({expectedSize:Number.parseInt(t,10),givenSize:(0,o.size)(p)})}let b=l[s];b&&(function(e){if("address"===e||"bool"===e||"string"===e||e.startsWith("bytes")||e.startsWith("uint")||e.startsWith("int"))throw new h({type:e})}(s),c(b,p))}};if(l.EIP712Domain&&t){if("object"!=typeof t)throw new p({domain:t});c(l.EIP712Domain,t)}if("EIP712Domain"!==s)if(l[s])c(l[s],r);else throw new u({primaryType:s,types:l})}({domain:s,message:l,primaryType:c,types:w});let b=["0x1901"];return s&&b.push(function({domain:e,types:t}){return m({data:e,primaryType:"EIP712Domain",types:t})}({domain:s,types:w})),"EIP712Domain"!==c&&b.push(m({data:l,primaryType:c,types:w})),(0,t.keccak256)((0,r.concat)(b))}],397478)}]);