self.__BUILD_MANIFEST = {
  "/": [
    "static/immutable/chunks/208z25cday7_j.js"
  ],
  "/_error": [
    "static/immutable/chunks/3-bk2w1bnruqv.js"
  ],
  "/blocked": [
    "static/immutable/chunks/0tgvz2lay12s2.js"
  ],
  "/embed": [
    "static/immutable/chunks/04taueuhd6kpy.js"
  ],
  "__rewrites": {
    "afterFiles": [],
    "beforeFiles": [],
    "fallback": []
  },
  "sortedPages": [
    "/",
    "/_app",
    "/_error",
    "/blocked",
    "/embed"
  ]
};self.__BUILD_MANIFEST_CB && self.__BUILD_MANIFEST_CB()