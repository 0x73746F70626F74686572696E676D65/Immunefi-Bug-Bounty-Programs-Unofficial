self.__BUILD_MANIFEST = {
  "/": [
    "static/chunks/2k2w8l6b2z707.js"
  ],
  "/404": [
    "static/chunks/36-2un7t5ws0k.js"
  ],
  "/[network]": [
    "static/chunks/3a043nigpe86z.js"
  ],
  "/_error": [
    "static/chunks/1dwb-6gce2gbt.js"
  ],
  "/robots.txt": [
    "static/chunks/1ftycviyscyuv.js"
  ],
  "__rewrites": {
    "afterFiles": [],
    "beforeFiles": [],
    "fallback": []
  },
  "sortedPages": [
    "/",
    "/404",
    "/_app",
    "/_error",
    "/api/balances",
    "/api/balances/utils",
    "/api/confirmation",
    "/api/confirmation/types",
    "/api/faucet",
    "/api/faucet/types",
    "/api/faucet/utils/performTokenRequest/kvstore",
    "/api/faucet/utils/performTokenRequest/performTokenRequest",
    "/api/faucet/utils/performTokenRequest/sendLink",
    "/api/faucet/utils/performTokenRequest/sendNativeToken",
    "/api/faucet/utils/rateLimiter/rateLimitLinkRequest",
    "/api/faucet/utils/rateLimiter/rateLimitNativeRequest",
    "/api/faucet/utils/rateLimiter/rateLimiter",
    "/api/faucet/utils/rateLimiter/schemaAndTypes",
    "/api/faucet/utils/rateLimiter/supabase",
    "/api/faucet/utils/rateLimiter/utils",
    "/api/faucet-balance",
    "/api/faucet-balance/types",
    "/api/monitor",
    "/api/monitor/utils",
    "/api/terms",
    "/robots.txt",
    "/[network]"
  ]
};self.__BUILD_MANIFEST_CB && self.__BUILD_MANIFEST_CB()