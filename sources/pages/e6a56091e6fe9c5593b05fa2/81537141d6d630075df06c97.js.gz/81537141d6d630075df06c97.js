<!doctype html>
<html lang="en" data-beasties-container="">
  <head>
    <meta charset="utf-8">
    <title>1inch</title>
    <base href="/">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="favicon/apple-touch-icon.png" rel="apple-touch-icon" sizes="180x180">
    <link href="favicon/favicon-96x96.png" rel="icon" sizes="96x96" type="image/png">
    <link href="favicon/favicon.svg" rel="icon" sizes="16x16" type="image/svg">
    <link href="favicon/favicon.ico" rel="icon" sizes="16x16" type="image/ico">
    <meta content="#F7F7FA" name="msapplication-TileColor">
    <meta content="#F7F7FA" name="theme-color">
    <meta name="color-scheme" content="light dark">
    <meta name="theme-color" media="(prefers-color-scheme: light)" content="#F7F7FA">
    <meta name="theme-color" media="(prefers-color-scheme: dark)" content="#000000">
    <meta name="app-version" content="2.26.1">
    <meta name="build-timestamp" content="2026-10-02T11:00:41.000Z">
    <meta name="environment" content="production">
    <!-- Post-build build-info stamp (DAPP-8758): inert JSON data block filled by scripts/inject-version.js; read by @oneinch/environment readBuildInfo. -->
    <script type="application/json" id="build-info">{"release":"1inch@f87c696816f8","version":"2.26.1","buildTimestamp":1790938841,"shortSHA":"f87c696816f8","SHA":"f87c696816f8d3b2d6bcee3b370e3e4386027027","branch":"HEAD","lastCommitAuthor":"Ilia Kolesnik","lastCommitTime":"Fri Oct 2 14:00:41 2026 +0300","lastCommitMessage":"Merge pull request #8658 from 1inch/cursor/dapp-9251-spot-price-zero-volume-99cd","lastCommitNumber":"9378"}</script>
    <link rel="manifest" href="manifest.webmanifest" crossorigin="use-credentials">
    <meta name="robots" content="index, follow">
    <meta name="google-site-verification" content="-sj_-P6uBrA57cezBZhnhBoPzc3Nj_3afk_mx50y5yg">
    <meta name="msvalidate.01" content="D9F246B199097846A079A5EFC57D0DE8">
    <!-- Preconnects for the render-critical cross-origin hosts every page hits at boot (DAPP-5707):
         the API proxy (auth token + token/price data) and Unleash (feature flags gate routes and
         nav on first navigation). Production origins on purpose — index.html is shared across
         environments and staging's *-staging twins simply leave these hints inert. dns-prefetch
         for hosts that are fetched later or less universally (token logos, RudderStack). -->
    <link rel="preconnect" href="https://proxy-app.1inch.com" crossorigin="">
    <link rel="preconnect" href="https://unleash-edge.1inch.io" crossorigin="">
    <link rel="dns-prefetch" href="https://tokens-data.1inch.io">
    <link rel="dns-prefetch" href="https://ss-rs.1inch.io">
    <link rel="dns-prefetch" href="https://cdn.1inch.com">
    <!-- LCP face only (DAPP-8856): Medium = weight 500 for --displayDisplayL / --headlineHeadlineM.
         Regular/Book discover via inline @font-face below (first layout), not HTML parse preloads. -->
    <link rel="preload" href="assets/fonts/SuisseIntl-Medium.woff2" as="font" type="font/woff2" crossorigin="">
    <style>
      /* Byte twin of assets/styles/fonts.scss — discover faces before async styles-*.css (DAPP-8856).
         Pinned rule-for-rule by index-font-faces.spec.ts; edit fonts.scss first, then mirror it here. */
      @font-face {
        font-family: 'Suisse Intl';
        src: url('/assets/fonts/SuisseIntl-Regular.woff2') format('woff2');
        font-weight: 400;
        font-style: normal;
        font-display: swap;
      }
      @font-face {
        font-family: 'Suisse Intl';
        src: url('/assets/fonts/SuisseIntl-Book.woff2') format('woff2');
        font-weight: 450;
        font-style: normal;
        font-display: swap;
      }
      @font-face {
        font-family: 'Suisse Intl';
        src: url('/assets/fonts/SuisseIntl-Medium.woff2') format('woff2');
        font-weight: 500;
        font-style: normal;
        font-display: swap;
      }
      @font-face {
        font-family: "Suisse Int'l Mono";
        src: url('/assets/fonts/SuisseIntlMono-Regular-WebS.woff2') format('woff2');
        font-display: swap;
      }
      @font-face {
        font-family: 'Suisse Intl Fallback';
        src: local('Roboto Regular'), local('Roboto-Regular'), local('Arial'), local('ArialMT');
        font-weight: 400;
        font-style: normal;
        font-display: swap;
        ascent-override: 111.5862%;
        descent-override: 52.8466%;
        line-gap-override: 0%;
        size-adjust: 105.2101%;
      }
      @font-face {
        font-family: 'Suisse Intl Fallback';
        src: local('Roboto Regular'), local('Roboto-Regular'), local('Arial'), local('ArialMT');
        font-weight: 450;
        font-style: normal;
        font-display: swap;
        ascent-override: 109.7108%;
        descent-override: 51.9585%;
        line-gap-override: 0%;
        size-adjust: 107.0086%;
      }
      @font-face {
        font-family: 'Suisse Intl Fallback';
        src: local('Roboto Regular'), local('Roboto-Regular'), local('Arial'), local('ArialMT');
        font-weight: 500;
        font-style: normal;
        font-display: swap;
        ascent-override: 108.3452%;
        descent-override: 51.3117%;
        line-gap-override: 0%;
        size-adjust: 108.3574%;
      }
      @font-face {
        font-family: "Suisse Int'l Mono Fallback";
        src: local('Roboto Mono Regular'), local('RobotoMono-Regular'), local('Courier New'), local('CourierNewPSMT');
        font-display: swap;
        ascent-override: 91.5939%;
        descent-override: 28.8902%;
        line-gap-override: 0%;
        size-adjust: 107.6491%;
      }
    </style>
    <!-- Theme palettes are public/ passthrough assets, not build outputs, so the prerender's
         critical-CSS inliner (beasties) cannot resolve them and warned once per stylesheet per
         prerendered route (DAPP-7106, angular-cli#30986). The ../ prefix resolves outside the
         inliner's root, which makes it skip these links silently and leave them untouched; the
         browser resolves the URL against <base href="/">, so it stays /theme-light.css and
         /theme-dark.css on every page. -->
    <link rel="stylesheet" href="../theme-light.css" media="(prefers-color-scheme: light)" data-theme="light">
    <link rel="stylesheet" href="../theme-dark.css" media="(prefers-color-scheme: dark)" data-theme="dark">
    <script>
      (function () {
        var lightLinks = document.querySelectorAll('link[data-theme="light"]');
        var darkLinks = document.querySelectorAll('link[data-theme="dark"]');

        function setScheme(scheme) {
          var lightMedia, darkMedia;
          if (scheme === 'auto') {
            lightMedia = '(prefers-color-scheme: light)';
            darkMedia = '(prefers-color-scheme: dark)';
          } else {
            lightMedia = scheme === 'light' ? 'all' : 'not all';
            darkMedia = scheme === 'dark' ? 'all' : 'not all';
          }
          lightLinks.forEach(function (link) {
            link.media = lightMedia;
          });
          darkLinks.forEach(function (link) {
            link.media = darkMedia;
          });
        }

        try {
          var saved = localStorage.getItem('preferred-theme');
          if (saved === 'light-theme') setScheme('light');
          else if (saved === 'dark-theme') setScheme('dark');
        } catch (e) {}
      })();
    </script>
    <style>
      /* Boot progress bar: paints before Angular bootstraps so slow connections get immediate
         feedback during the initial bundle download. The CSS trickle runs on the compositor, so
         it keeps animating even while the main thread is busy parsing/executing the app bundle.
         It is removed once the app bootstraps and the Router-driven bar takes over. */
      #boot-progress {
        position: fixed;
        inset: 0 0 auto 0;
        height: 4px;
        z-index: 1001;
        pointer-events: none;
        background: transparent;
      }

      #boot-progress > div {
        width: 100%;
        height: 100%;
        /* Always white: during boot the dark theme renders first, so white stays visible on the
           dark backdrop. The theme-aware Router-driven bar takes over once Angular bootstraps. */
        background: #ffffff;
        transform-origin: left center;
        transform: scaleX(0.08);
        will-change: transform;
        animation: boot-progress-trickle 14s cubic-bezier(0.1, 0.85, 0.25, 1) forwards;
      }

      @keyframes boot-progress-trickle {
        0% {
          transform: scaleX(0.08);
        }
        100% {
          transform: scaleX(0.9);
        }
      }

      @media (prefers-reduced-motion: reduce) {
        #boot-progress > div {
          animation-duration: 0s;
          transform: scaleX(0.6);
        }
      }
    </style>
  <style>*,*:before,*:after{box-sizing:border-box}html{font-family:sans-serif;line-height:1.15;-webkit-text-size-adjust:100%;-webkit-tap-highlight-color:rgba(0,0,0,0)}@supports (-webkit-appearance: none){html{scrollbar-gutter:stable}}body{margin:0;font-family:-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Helvetica Neue,Arial,Noto Sans,Liberation Sans,sans-serif,"Apple Color Emoji","Segoe UI Emoji",Segoe UI Symbol,"Noto Color Emoji";font-size:1rem;font-weight:400;line-height:1.5;text-align:left}:root{--greyGrey900:#000000;--greyGrey890:#0F0F12;--greyGrey880:#141417;--greyAlphaGrey890A0:#0F0F1200;--greyAlphaGrey890A05:#0F0F1280;--greyGrey870:#19191C;--greyGrey865:#212124;--greyGrey860:#27272B;--greyAlphaGrey870A09:#19191CE6;--greyGrey850:#2E2E30;--greyGrey840:#353538;--greyGrey700:#4C4C50;--greyGrey650:#656569;--greyGrey600:#76777A;--greyAlphaGrey600A05:#76777A80;--greyAlphaGrey600A0:#76777A00;--greyGrey500:#919194;--greyGrey400:#AFAFB2;--greyGrey300:#C8C8CC;--greyGrey200:#CFCFD4;--greyGrey180:#D7D7DB;--greyGrey160:#DCDCE0;--greyGrey140:#E8E8ED;--greyGrey120:#F0F0F5;--greyAlphaGrey140A05:#E8E8ED80;--greyAlphaGrey140A0:#E8E8ED00;--greyGrey100:#F7F7FA;--greyGrey050:#FAFAFC;--darkBlueDarkBlueA005:#0F0F660D;--darkBlueDarkBlueA008:#0F0F6614;--darkBlueDarkBlueA012:#0C0C521F;--darkBlueDarkBlueA0122:#0C0C5229;--blackBlackA1:#0F0F12;--blackBlackA072:#0F0F12B8;--blackBlackA064:#0F0F12A3;--blackBlackA056:#0F0F128F;--blackBlackA032:#0F0F1252;--blackBlackA016:#0F0F1229;--blackBlackA012:#0F0F121F;--blackBlackA009:#0F0F1217;--blackBlackA005:#0F0F120D;--blackBlackA003:#0F0F1208;--blackBlackA001:#0F0F1203;--whiteWhiteA1:#FFFFFF;--whiteWhiteA088:#FFFFFFE0;--whiteWhiteA076:#FFFFFFC2;--whiteWhiteA060:#FFFFFF99;--whiteWhiteA040:#FFFFFF66;--whiteWhiteA020:#FFFFFF33;--whiteWhiteA016:#FFFFFF29;--whiteWhiteA012:#FFFFFF1F;--whiteWhiteA006:#FFFFFF17;--whiteWhiteA001:#FFFFFF03;--whiteWhiteA0:#FFFFFF00;--blueBlue100:#E0EEFF;--blueBlue300:#8AB3FF;--blueBlue400:#4175FF;--blueBlue450:#3355FF;--blueBlue500:#1F3DFE;--blueBlue700:#1E1EE8;--blueBlue800:#0D1D4C;--greenGreen100:#E1FBDE;--greenGreen300:#65E157;--greenGreen350:#3AC750;--greenGreen400:#25AF3B;--greenGreen500:#028A17;--greenGreen700:#0E6D03;--greenGreen800:#0A2C07;--orangeOrange100:#FFE7C3;--orangeOrange300:#FF9E4E;--orangeOrange500:#F97000;--orangeOrange700:#D74400;--orangeOrange800:#462500;--redRed100:#FFDBDB;--redRed300:#FF7070;--redRed400:#FF2929;--redRed450:#F42012;--redRed500:#DB261A;--redRed700:#B91F00;--redRed800:#3F1411}:root body{--commonPrimary:var(--uIInteractiveHiddenPrimaryDefault);--commonSecondary:var(--uIInteractiveHiddenCommonDefault);--commonGhost:#FFFFFF00;--commonDanger:var(--uIInteractiveHiddenDangerDefault);--commonSecondaryConstantBlack:var(--uIInteractiveHiddenSecondaryConstantBlack);--commonPrimaryConstantWhite:var(--uIInteractiveHiddenPrimaryConstantWhite);--commonSecondaryConstantWhite:var(--uIInteractiveHiddenSecondaryConstantWhite);--commonPrimaryConstantBlack:var(--uIInteractiveHiddenPrimaryConstantBlack);--commonPrimaryInverted:var(--uIInteractiveHiddenPrimaryInverted);--commonSecondaryInverted:var(--uIInteractiveHiddenSecondaryInvertedDefault);--commonNetworkSeparator:var(--uIInteractiveHiddenNetworkSeparator);--commonSpecial:var(--uIInteractiveHiddenSpecialDefault);--swapWidgetSimple:var(--uIInteractiveHiddenSwapWidgetSimpleDefault);--swapWidgetPro:var(--uIInteractiveHiddenSwapWidgetProDefault);--controlCheckboxRadioBorder:var(--uIInteractiveHiddenCheckboxCheckboxRadioBorder);--controlCheckboxRadioActiveItem:var(--uIInteractiveHiddenCheckboxCheckboxRadioBorderChecked);--controlToggleBackgroundOff:var(--uIInteractiveHiddenToggleToggleOff);--controlToggleBackgroundOn:var(--uIInteractiveHiddenToggleToggleOn);--controlToggleThumb:var(--uIInteractiveHiddenToggleThumb);--controlSegmentedBackground:var(--uIInteractiveHiddenCommonDefault);--controlSegmentedItem:#FFFFFF00;--controlSegmentedItemSelected:var(--whiteWhiteA1);--commonPrimaryHover:var(--uIInteractiveHiddenPrimaryHover);--commonSecondaryHover:var(--uIInteractiveHiddenCommonHover);--commonGhostHover:var(--uIInteractiveHiddenCommonHover);--commonDangerHover:var(--uIInteractiveHiddenDangerHover);--commonSecondaryConstantBlackHover:var(--uIInteractiveHiddenSecondaryConstantBlackHover);--commonPrimaryConstantWhiteHover:var(--uIInteractiveHiddenPrimaryConstantWhiteHover);--commonSecondaryConstantWhiteHover:var(--uIInteractiveHiddenSecondaryConstantWhiteHover);--commonPrimaryConstantBlackHover:var(--uIInteractiveHiddenPrimaryConstantBlackHover);--commonPrimaryInvertedHover:var(--uIInteractiveHiddenPrimaryInvertedHover);--commonSecondaryInvertedHover:var(--uIInteractiveHiddenSecondaryInvertedHover);--commonNetworkSeparatorHover:var(--uIInteractiveHiddenNetworkSeparatorHover);--commonSpecialHover:var(--uIInteractiveHiddenSpecialHover);--swapWidgetSimpleHover:var(--uIInteractiveHiddenSwapWidgetSimpleHover);--swapWidgetProHover:var(--uIInteractiveHiddenSwapWidgetProHover);--controlCheckboxRadioBorderHover:var(--uIInteractiveHiddenCheckboxCheckboxRadioBorderHover);--controlCheckboxRadioActiveItemHover:var(--uIInteractiveHiddenCheckboxCheckboxRadioBorderCheckedHover);--controlToggleBackgroundOffHover:var(--uIInteractiveHiddenToggleToggleOffHover);--controlToggleBackgroundOnHover:var(--uIInteractiveHiddenToggleToggleOnHover);--controlToggleThumbHover:var(--uIInteractiveHiddenToggleThumb);--controlSegmentedBackgroundHover:var(--uIInteractiveHiddenCommonDefault);--controlSegmentedItemHover:var(--uIInteractiveHiddenGhostHover);--controlSegmentedItemSelectedHover:var(--whiteWhiteA1);--commonPrimaryDisabled:var(--uIInteractiveHiddenCommonDisable);--commonSecondaryDisabled:var(--uIInteractiveHiddenCommonDisable);--commonGhostDisabled:var(--uIInteractiveHiddenCommonDisable);--commonDangerDisabled:var(--uIInteractiveHiddenCommonDisable);--commonSecondaryConstantBlackDisabled:var(--uIInteractiveHiddenCommonDisable);--commonPrimaryConstantWhiteDisabled:var(--uIInteractiveHiddenSecondaryConstantWhiteDisable);--commonSecondaryConstantWhiteDisabled:var(--uIInteractiveHiddenSecondaryConstantWhiteDisable);--commonPrimaryConstantBlackDisabled:var(--uIInteractiveHiddenCommonDisable);--commonPrimaryInvertedDisabled:var(--uIInteractiveHiddenInvertedDisable);--commonSecondaryInvertedDisabled:var(--uIInteractiveHiddenInvertedDisable);--commonNetworkSeparatorDisabled:var(--uIInteractiveHiddenCommonDisable);--commonSpecialDisabled:var(--uIInteractiveHiddenCommonDisable);--swapWidgetSimpleDisabled:var(--uIInteractiveHiddenCommonDisable);--swapWidgetProDisabled:var(--uIInteractiveHiddenCommonDisable);--controlCheckboxRadioBorderDisabled:var(--uIInteractiveHiddenCheckboxCheckboxRadioFillDisable);--controlCheckboxRadioActiveItemDisabled:var(--uIInteractiveHiddenCheckboxCheckboxRadioFillDisable);--controlToggleBackgroundOffDisabled:var(--uIInteractiveHiddenToggleToggleOff);--controlToggleBackgroundOnDisabled:var(--controlToggleBackgroundOffDisabled);--controlToggleThumbDisabled:var(--whiteWhiteA076);--controlSegmentedBackgroundDisabled:var(--uIInteractiveHiddenCommonDefault);--controlSegmentedItemDisabled:#FFFFFF00;--controlSegmentedItemSelectedDisabled:var(--whiteWhiteA1)}:root body{--greyScaleBlackBrand:#000000;--greyScaleDarkGreyLvel2Brand:var(--greyGrey870);--greyScaleDarkGreyLvel25Brand:#2E2E36;--greyScaleDarkGreyLvel3Brand:#535361;--greyScaleDarkGreyLvel4Brand:#8A8A99;--greyScaleDarkGreyLvel5Brand:#D5D5E2;--greyScaleLightGreyLvel2Brand:var(--greyGrey120);--greyScaleWhiteBrand:#FFFFFF;--coloredBlueBrand:#0000FE;--coloredPurpleBrand:#9601FF;--coloredRedBrand:#FE0000;--coloredGreenBrand:#4FF01F;--coloredMintBrand:#09F9F9;--coloredYellowBrand:#FFEE00}@media(min-width:800px){:root{--fontFamilyTitle:"Suisse Intl";--fontFamilyButton:"Suisse Intl";--fontFamilyText:"Suisse Intl";--fontFamilySpecial:"Suisse Int'l Mono";--fontWeightBold:500;--fontWeightBook:450;--fontWeightRegular:400;--fontWeightBoldNew:"Medium";--fontWeightBoldMobBook:"Medium";--fontSizeDisplayLarge:72px;--fontSizeDisplayMedium:60px;--fontSizeHeadlineLarge:32px;--fontSizeHeadlineMedium:24px;--fontSizeHeadlineSmall:20px;--fontWeightBookNew:"Book";--fontSizeBodyLarge:18px;--fontSizeBodyMedium:16px;--fontSizeBodySmall:14px;--fontSizeCaptionLarge:12px;--fontSizeCaptionMedium:10px;--fontSizeButtonMedium:16px;--fontSizeMonoLarge:18px;--fontSizeMonoMedium:16px;--fontSizeMonoSmall:14px;--lineHeightDisplayLarge:72px;--lineHeightDisplayMedium:64px;--lineHeightHeadlineLarge:40px;--lineHeightHeadlineMedium:32px;--lineHeightHeadlineSmall:28px;--lineHeightBodyLarge:24px;--lineHeightBodyMedium:24px;--lineHeightBodySmall:20px;--lineHeightCaptionLarge:16px;--lineHeightCaptionMedium:12px;--lineHeightButtonMedium:24px;--lineHeightButtonSmall:20px;--lineHeightMonoLarge:24px;--lineHeightHugeLarge:120px;--letterSpacingNumber:0;--lineHeightMonoMedium:24px;--lineHeightMonoSmall:20px;--fontSizeButtonSmall:14px;--letterSpacingDisplayLarge:0;--letterSpacingDisplayMedium:0;--letterSpacingHeadlineLarge:0;--letterSpacingHeadlineMedium:0;--letterSpacingHeadlineSmall:0;--letterSpacingBodyMedium:0;--letterSpacingBodySmall:0;--letterSpacingCaptionLarge:0;--letterSpacingCaptionSmall:0;--letterSpacingButtonMedium:0;--letterSpacingMonoLarge:0;--letterSpacingMonoMedium:0;--letterSpacingMonoSmall:0;--letterSpacingHugeLarge:0;--letterSpacingButtonSmall:0;--fontSizeHugeLarge:120px;--fontWeightRegularNew:"Regular"}}@media(max-width:799px){:root{--fontFamilyTitle:"Suisse Intl";--fontFamilyButton:"Suisse Intl";--fontFamilyText:"Suisse Intl";--fontFamilySpecial:"Suisse Int'l Mono";--fontWeightBold:500;--fontWeightBook:450;--fontWeightRegular:400;--fontWeightBoldNew:"Medium";--fontWeightBoldMobBook:"Medium";--fontSizeDisplayLarge:40px;--fontSizeDisplayMedium:36px;--fontSizeHeadlineLarge:24px;--fontSizeHeadlineMedium:20px;--fontSizeHeadlineSmall:20px;--fontWeightBookNew:"Book";--fontSizeBodyLarge:18px;--fontSizeBodyMedium:16px;--fontSizeBodySmall:14px;--fontSizeCaptionLarge:12px;--fontSizeCaptionMedium:10px;--fontSizeButtonMedium:16px;--fontSizeMonoLarge:18px;--fontSizeMonoMedium:16px;--fontSizeMonoSmall:14px;--lineHeightDisplayLarge:44px;--lineHeightDisplayMedium:40px;--lineHeightHeadlineLarge:32px;--lineHeightHeadlineMedium:28px;--lineHeightHeadlineSmall:24px;--lineHeightBodyLarge:24px;--lineHeightBodyMedium:24px;--lineHeightBodySmall:20px;--lineHeightCaptionLarge:16px;--lineHeightCaptionMedium:12px;--lineHeightButtonMedium:24px;--lineHeightButtonSmall:20px;--lineHeightMonoLarge:24px;--lineHeightHugeLarge:80px;--letterSpacingNumber:0;--lineHeightMonoMedium:24px;--lineHeightMonoSmall:20px;--fontSizeButtonSmall:14px;--letterSpacingDisplayLarge:0;--letterSpacingDisplayMedium:0;--letterSpacingHeadlineLarge:0;--letterSpacingHeadlineMedium:0;--letterSpacingHeadlineSmall:0;--letterSpacingBodyMedium:0;--letterSpacingBodySmall:0;--letterSpacingCaptionLarge:0;--letterSpacingCaptionSmall:0;--letterSpacingButtonMedium:0;--letterSpacingMonoLarge:0;--letterSpacingMonoMedium:0;--letterSpacingMonoSmall:0;--letterSpacingHugeLarge:0;--letterSpacingButtonSmall:0;--fontSizeHugeLarge:80px;--fontWeightRegularNew:"Regular"}}:root{--displayDisplayL:500 var(--fontSizeDisplayLarge)/var(--lineHeightDisplayLarge) "Suisse Intl", "Suisse Intl Fallback", system-ui;--displayDisplayM:500 var(--fontSizeDisplayMedium)/var(--lineHeightDisplayMedium) "Suisse Intl", "Suisse Intl Fallback", system-ui;--displayDisplayS:500 48px/56px "Suisse Intl", "Suisse Intl Fallback", system-ui;--headlineHeadlineL:500 var(--fontSizeHeadlineLarge)/var(--lineHeightHeadlineLarge) "Suisse Intl", "Suisse Intl Fallback", system-ui;--headlineHeadlineM:500 var(--fontSizeHeadlineMedium)/var(--lineHeightHeadlineMedium) "Suisse Intl", "Suisse Intl Fallback", system-ui;--headlineHeadlineMReg:450 var(--fontSizeHeadlineMedium)/var(--lineHeightHeadlineMedium) "Suisse Intl", "Suisse Intl Fallback", system-ui;--headlineHeadlineS:500 var(--fontSizeHeadlineSmall)/var(--lineHeightHeadlineSmall) "Suisse Intl", "Suisse Intl Fallback", system-ui;--bodyBodyLBold:500 var(--fontSizeBodyLarge)/var(--lineHeightBodyLarge) "Suisse Intl", "Suisse Intl Fallback", system-ui;--bodyBodyLRegular:400 var(--fontSizeBodyLarge)/var(--lineHeightBodyLarge) "Suisse Intl", "Suisse Intl Fallback", system-ui;--bodyBodyMBold:500 var(--fontSizeBodyMedium)/var(--lineHeightBodyMedium) "Suisse Intl", "Suisse Intl Fallback", system-ui;--bodyBodyMRegular:400 var(--fontSizeBodyMedium)/var(--lineHeightBodyMedium) "Suisse Intl", "Suisse Intl Fallback", system-ui;--bodyBodySBold:500 var(--fontSizeBodySmall)/var(--lineHeightBodySmall) "Suisse Intl", "Suisse Intl Fallback", system-ui;--bodyBodySRegular:400 var(--fontSizeBodySmall)/var(--lineHeightBodySmall) "Suisse Intl", "Suisse Intl Fallback", system-ui;--captionCaptionLBold:500 var(--fontSizeCaptionLarge)/var(--lineHeightCaptionLarge) "Suisse Intl", "Suisse Intl Fallback", system-ui;--captionCaptionLRegular:400 var(--fontSizeCaptionLarge)/var(--lineHeightCaptionLarge) "Suisse Intl", "Suisse Intl Fallback", system-ui;--captionCaptionSBold:500 var(--fontSizeCaptionMedium)/var(--lineHeightCaptionMedium) "Suisse Intl", "Suisse Intl Fallback", system-ui;--captionCaptionSRegular:400 var(--fontSizeCaptionMedium)/var(--lineHeightCaptionMedium) "Suisse Intl", "Suisse Intl Fallback", system-ui;--buttonButtonMBold:450 var(--fontSizeButtonMedium)/var(--lineHeightButtonMedium) "Suisse Intl", "Suisse Intl Fallback", system-ui;--buttonButtonMRegular:400 var(--fontSizeButtonMedium)/var(--lineHeightButtonMedium) "Suisse Intl", "Suisse Intl Fallback", system-ui;--buttonButtonSBold:450 var(--fontSizeButtonSmall)/var(--lineHeightButtonSmall) "Suisse Intl", "Suisse Intl Fallback", system-ui;--buttonButtonSRegular:400 var(--fontSizeButtonSmall)/var(--lineHeightButtonSmall) "Suisse Intl", "Suisse Intl Fallback", system-ui;--specialSwapFormNumbers:450 var(--fontSizeHeadlineLarge)/var(--lineHeightHeadlineLarge) "Suisse Intl", "Suisse Intl Fallback", system-ui;--specialSwapFormTicker:400 var(--fontSizeHeadlineLarge)/var(--lineHeightHeadlineLarge) "Suisse Intl", "Suisse Intl Fallback", system-ui;--specialOtherAccent:500 var(--fontSizeHugeLarge)/var(--lineHeightHugeLarge) "Suisse Intl", "Suisse Intl Fallback", system-ui;--specialMonoMonoL:400 var(--fontSizeMonoLarge)/var(--lineHeightMonoLarge) "Suisse Int'l Mono", "Suisse Int'l Mono Fallback", system-ui;--specialMonoMonoM:400 var(--fontSizeMonoMedium)/var(--lineHeightMonoMedium) "Suisse Int'l Mono", "Suisse Int'l Mono Fallback", system-ui;--specialMonoMonoS:400 var(--fontSizeMonoSmall)/var(--lineHeightMonoSmall) "Suisse Int'l Mono", "Suisse Int'l Mono Fallback", system-ui}:root{color-scheme:light dark}body{background-color:var(--backgroundBase);font:var(--bodyBodyMRegular);color:var(--typographyBasePrimary);overflow-x:hidden}*{box-sizing:border-box}</style><link rel="stylesheet" href="/styles-HJWGWEOP.css" media="print" onload="this.media='all'"><noscript><link rel="stylesheet" href="/styles-HJWGWEOP.css"></noscript></head>
  <body ngcm="">
    <div id="boot-progress" aria-hidden="true">
      <div></div>
    </div>
    <script>
      (function () {
        try {
          var saved = localStorage.getItem('preferred-theme');
          var isDark;
          if (saved === 'dark-theme') isDark = true;
          else if (saved === 'light-theme') isDark = false;
          else isDark = matchMedia('(prefers-color-scheme: dark)').matches;
          document.body.classList.add(isDark ? 'dark-theme' : 'light-theme');
        } catch (e) {}
      })();
    </script>
    <app-root></app-root>
    <noscript>Please enable JavaScript to continue using this application.</noscript>
    <script>
      // Completes and removes the boot progress bar once the app bootstraps, handing visual
      // feedback over to the Router-driven NavigationProgressService bar.
      (function () {
        // Hard ceiling: if the app never bootstraps (fatal load failure), give up after this so the
        // poll doesn't run forever and the bar isn't left stuck near 90%. Comfortably above a slow
        // connection's real bootstrap time and the 15s bootstrap guard below.
        const GIVE_UP_MS = 60000;

        const bar = document.getElementById('boot-progress');
        if (!bar) return;
        const fill = bar.firstElementChild;

        const remove = function () {
          bar.remove();
        };

        const finish = function () {
          fill.style.animation = 'none';
          fill.style.transition = 'transform 200ms ease-out';
          fill.style.transform = 'scaleX(1)';
          bar.style.transition = 'opacity 300ms ease-out 150ms';
          bar.style.opacity = '0';
          setTimeout(remove, 600);
        };

        const start = Date.now();
        (function tick() {
          if (window.__APP_BOOTSTRAPPED__) return finish();
          if (Date.now() - start >= GIVE_UP_MS) return remove();
          setTimeout(tick, 100);
        })();
      })();
    </script>
    <script>
      // Bootstrap & chunk guard: detects fatal app load failures and chunk loading errors,
      // reports to Sentry via raw Envelope API (no SDK needed).
      // DSN placeholder is replaced at build time by inject-version.js.
      (() => {
        const SENTRY_DSN = 'https://33ea35a1a6657f7d0be71100299c1d95@o4506234207928320.ingest.us.sentry.io/4509950035230720';
        const BOOTSTRAP_TIMEOUT_MS = 15000;
        const MAX_CHUNK_REPORTS = 5;
        let bootstrapTimeoutSent = false;
        let chunkReportCount = 0;
        let reloadInitiated = false;

        if (SENTRY_DSN.indexOf('PLACEHOLDER') !== -1) return;
        if (!/(^|\.)1inch\.com$/.test(location.hostname)) return;

        const parseDsn = (dsn) => {
          try {
            const m = dsn.match(/^https?:\/\/([^@]+)@([^/]+)\/(.+)$/);
            if (!m) return null;
            return { publicKey: m[1], host: m[2], projectId: m[3] };
          } catch (e) {
            return null;
          }
        };

        const parsedDsn = parseDsn(SENTRY_DSN);
        if (!parsedDsn) return;

        const sentryUrl =
          'https://' +
          parsedDsn.host +
          '/api/' +
          parsedDsn.projectId +
          '/envelope/?sentry_key=' +
          parsedDsn.publicKey +
          '&sentry_version=7';

        const uuid = () =>
          'xxxxxxxxxxxx4xxxyxxxxxxxxxxxxxxx'.replace(/[xy]/g, (c) => {
            const r = (Math.random() * 16) | 0;
            return (c === 'x' ? r : (r & 0x3) | 0x8).toString(16);
          });

        const getAppVersion = () =>
          document.querySelector('meta[name="app-version"]')?.getAttribute('content') || 'unknown';

        const sendEvent = (message, level, logger, extraTags, stackTrace) => {
          // DAPP-4411: Sentry is non-essential tracking, so this guard reports nothing until the
          // app publishes an ACCEPTED cookie consent on the flag below (written from CookiesStore
          // in sentry-boot.ts — this script runs before Angular and cannot read the store itself).
          // Fail closed: an unanswered banner, a decline, an expired choice, and a boot that never
          // reached the publish point all read as "not granted" and send nothing.
          if (window.__1INCH_TRACKING_CONSENT__ !== true) return;

          try {
            const eventId = uuid();
            const tags = { source: logger, 'app.version': getAppVersion() };
            if (extraTags) {
              for (const k in extraTags) tags[k] = extraTags[k];
            }

            const eventData = {
              event_id: eventId,
              timestamp: Date.now() / 1000,
              platform: 'javascript',
              level,
              logger,
              message: { formatted: message },
              tags,
              request: {
                url: location.href,
                headers: { 'User-Agent': navigator.userAgent },
              },
            };

            if (stackTrace) {
              eventData.extra = { stack_trace: stackTrace.substring(0, 500) };
            }

            const envelope =
              JSON.stringify({
                event_id: eventId,
                dsn: SENTRY_DSN,
                sent_at: new Date().toISOString(),
              }) +
              '\n' +
              JSON.stringify({ type: 'event', content_type: 'application/json' }) +
              '\n' +
              JSON.stringify(eventData) +
              '\n';

            fetch(sentryUrl, {
              method: 'POST',
              body: envelope,
              headers: { 'Content-Type': 'text/plain;charset=UTF-8' },
              mode: 'cors',
              credentials: 'omit',
              keepalive: true,
            }).catch(() => {});
          } catch (e) {
            // fail silently
          }
        };

        // Never auto-reload for crawlers (DAPP-7513): a crawler renders a cached HTML snapshot,
        // so a reload can never converge — it must render the served HTML as-is. Audit bots
        // (Lighthouse/PageSpeed, UA suffix "Chrome-Lighthouse") get the same carve-out: a
        // mid-audit reload destroys the run instead of updating anything (DAPP-8087).
        const KNOWN_CRAWLER_REGEXP =
          /googlebot|google-inspectiontool|bingbot|yandexbot|baiduspider|duckduckbot|slurp|applebot|petalbot|bytespider|lighthouse/i;
        const isKnownCrawler = () => KNOWN_CRAWLER_REGEXP.test(navigator.userAgent);

        const hasReloaded = () => {
          try {
            return sessionStorage.getItem('1inch:reloaded') === '1';
          } catch (e) {
            return false;
          }
        };
        // Verifies the one-shot mark actually persisted — without it a reload could repeat on
        // every failure (DAPP-7513), so no persisted guard means no reload (fail closed).
        const markReloaded = () => {
          try {
            sessionStorage.setItem('1inch:reloaded', '1');
            return sessionStorage.getItem('1inch:reloaded') === '1';
          } catch (e) {
            return false;
          }
        };
        const clearReloaded = () => {
          try {
            sessionStorage.removeItem('1inch:reloaded');
          } catch (e) {}
        };

        const sendBootstrapTimeout = () => {
          if (bootstrapTimeoutSent) return;
          bootstrapTimeoutSent = true;
          sendEvent('App failed to bootstrap within ' + BOOTSTRAP_TIMEOUT_MS / 1000 + 's', 'fatal', 'bootstrap-guard');
        };

        // Called from main.ts catch block
        window.__sendBootstrapError = (message) => {
          if (bootstrapTimeoutSent) return;
          bootstrapTimeoutSent = true;
          sendEvent(message, 'fatal', 'bootstrap-guard');
        };

        window.addEventListener('load', () => {
          setTimeout(() => {
            if (window.__APP_BOOTSTRAPPED__) {
              clearReloaded();
            } else {
              sendBootstrapTimeout();
            }
          }, BOOTSTRAP_TIMEOUT_MS);
        });

        // --- Chunk/script load guard (independent, fires per failed script, capped) ---

        // The reload is a recovery for the app's OWN stale assets (DAPP-8191): a third-party
        // script an ad blocker rejects (gtag, RudderStack, Intercom, MoonPay) fails again on
        // every load, so a reload can never converge — report it and move on. Same for a plain
        // "Failed to fetch"/"NetworkError" runtime message with no same-origin URL to blame:
        // that is an API call failing, not a chunk.
        const firstUrlIn = (text) => (String(text).match(/https?:\/\/[^\s'")]+/) || [null])[0];
        const isCrossOriginUrl = (url) => {
          try {
            return new URL(url, location.href).origin !== location.origin;
          } catch (e) {
            return true;
          }
        };
        const PLAIN_FETCH_ERROR_REGEXP = /Failed to fetch|NetworkError/i;

        // The report cap limits Sentry spam only — it must never consume the recovery budget:
        // an ad blocker can produce MAX_CHUNK_REPORTS report-only failures before the app's own
        // stale chunk fails, and the recovery reload still has to fire for that one.
        const reportChunkFailure = (label, src, stackTrace) => {
          if (chunkReportCount >= MAX_CHUNK_REPORTS) return;
          chunkReportCount++;
          sendEvent(
            'Script load failed (' + label + '): ' + src,
            'error',
            'chunk-guard',
            { 'chunk.src': src },
            stackTrace,
          );
        };

        const sendChunkError = (src, stackTrace, reportOnly) => {
          if (reloadInitiated) return;

          if (window.__reloadPending) return;

          const sourceUrl = firstUrlIn(src);
          const isForeignFailure = sourceUrl ? isCrossOriginUrl(sourceUrl) : PLAIN_FETCH_ERROR_REGEXP.test(String(src));
          if (reportOnly || isForeignFailure) {
            reportChunkFailure('no reload', src, stackTrace);
            return;
          }

          if (hasReloaded()) {
            reportChunkFailure('after reload', src, stackTrace);
            return;
          }

          if (isKnownCrawler() || !markReloaded()) {
            reportChunkFailure('reload skipped', src, stackTrace);
            return;
          }

          reloadInitiated = true;
          window.location.reload(true);
        };

        window.__sendChunkError = sendChunkError;
        // Capture-phase error listener catches <script> load failures directly —
        // no message guessing needed, the event target IS the failed script element.
        const CHUNK_ERROR_REGEXP = /chunk|\.js|dynamically imported module|Importing a module script failed/i;
        window.addEventListener(
          'error',
          (event) => {
            const reason = event.error?.message || event.message;
            const msg = String(reason);
            const isChunkLike = CHUNK_ERROR_REGEXP.test(msg);
            if (isChunkLike) {
              sendChunkError(msg, reason?.stack);
              return;
            }
            const target = event.target;
            if (!target || (target.tagName !== 'SCRIPT' && target.tagName !== 'LINK')) return;
            // A LINK carries href, not src; an element with neither is unattributable — report
            // it, but never reload for something that cannot be proven to be ours.
            const assetUrl = target.src || target.href;
            sendChunkError(assetUrl || 'unknown', undefined, !assetUrl);
          },
          true,
        );
        // A failed dynamic import() rejects a promise; a rejection nothing awaits surfaces as
        // `unhandledrejection`, never as an `error` event — route it into the same reload-once
        // recovery (DAPP-7382). Matches only dynamic-import failures (never plain fetch errors),
        // and only the app's own (same-origin) chunks when the message carries a URL.
        const MODULE_IMPORT_ERROR_REGEXP = /Importing a module script failed|dynamically imported module/i;
        window.addEventListener(
          'unhandledrejection',
          (event) => {
            const reason = event.reason;
            const msg = String((reason && reason.message) || reason || '');
            const isChunkLoadError = !!reason && reason.name === 'ChunkLoadError';
            if (!isChunkLoadError && !MODULE_IMPORT_ERROR_REGEXP.test(msg)) return;
            const moduleUrl = (msg.match(/https?:\/\/[^\s'")]+/) || [null])[0];
            if (moduleUrl) {
              try {
                if (new URL(moduleUrl, location.href).origin !== location.origin) return;
              } catch (e) {
                return;
              }
            }
            sendChunkError(msg, reason && reason.stack);
          },
          true,
        );
      })();
    </script>
    <script>
      (() => {
        if (typeof window.ng === 'object') {
          return;
        }
        window.initIntercom = (intercomSettings) => {
          window.intercomSettings = Object.assign(intercomSettings, {
            app_id: 'zgn72x6y',
          });

          return new Promise((resolve) => {
            (() => {
              const w = window;
              const ic = w.Intercom;
              if (typeof ic === 'function') {
                ic('reattach_activator');
                ic('update', w.intercomSettings);
              } else {
                const d = document;
                const i = (...args) => {
                  i.q.push(args);
                };
                i.q = [];
                w.Intercom = i;
                const s = d.createElement('script');
                s.type = 'text/javascript';
                s.async = true;
                s.src = 'https://widget.intercom.io/widget/zgn72x6y';
                s.onload = () => resolve();
                const x = d.getElementsByTagName('script')[0];
                x.parentNode.insertBefore(s, x);
              }
            })();
          });
        };
      })();
    </script>
    <script>
      // Access version information from meta tags
      (() => {
        const VERSION_CHECK_INTERVAL_MS = 60000; // 1 minute
        const HARD_RELOAD_DELAY_MS = 3000; // 3 seconds
        const FETCH_TIMEOUT_MS = 5000; // 5 seconds

        const log = (message) => console.debug('[1inch]', message);

        // Returns: Array of 3 numbers [major, minor, patch] or null if invalid
        const parseVersion = (v) => {
          if (!v || typeof v !== 'string') return null;
          const parts = v.split('.').map((p) => parseInt(p, 10));
          if (parts.length !== 3 || parts.some(isNaN)) return null;
          return parts;
        };

        // Returns: -1 if a < b, 1 if a > b, 0 if a === b
        const compareVersionParts = (a, b) => {
          for (let i = 0; i < 3; i++) {
            if (a[i] < b[i]) return -1;
            if (a[i] > b[i]) return 1;
          }
          return 0;
        };

        // Returns: {status: 'Update required'|'Up to date'|'Unable to compare'|'Comparison failed', color: string}
        const compareVersions = (current, minHard) => {
          try {
            const currentVersionNumbers = parseVersion(current);
            const minHardVersionNumbers = parseVersion(minHard);

            if (!currentVersionNumbers || !minHardVersionNumbers) {
              return { status: 'Unable to compare', color: 'color: #9ca3af' };
            }

            if (compareVersionParts(currentVersionNumbers, minHardVersionNumbers) < 0) {
              return { status: 'Update required', color: 'color: #ef4444; font-weight: bold' };
            }

            return { status: 'Up to date', color: 'color: #10b981; font-weight: bold' };
          } catch (e) {
            return { status: 'Comparison failed', color: 'color: #9ca3af' };
          }
        };

        // Never auto-reload for crawlers (DAPP-7513): a crawler renders a cached HTML snapshot,
        // so a reload can never converge — Googlebot logged the loop as "Page with redirect".
        // Same carve-out for audit bots (DAPP-8087): Lighthouse/PageSpeed UAs end with
        // "Chrome-Lighthouse", audit a fixed artifact a reload can never update, and a
        // mid-audit reload destroys the run ("Execution context was destroyed" killed the
        // post-deploy SEO screen).
        const KNOWN_CRAWLER_REGEXP =
          /googlebot|google-inspectiontool|bingbot|yandexbot|baiduspider|duckduckbot|slurp|applebot|petalbot|bytespider|lighthouse/i;
        const isKnownCrawler = () => KNOWN_CRAWLER_REGEXP.test(navigator.userAgent);

        // One-shot reload guard (DAPP-7513): location.reload cannot bust the HTML cache, so a
        // stale page re-serves the same "Update required" verdict after every reload — without a
        // guard that loops forever. '1inch:reloaded' is the same key the chunk guard consults
        // (cleared again after a successful bootstrap); the target-version key survives that
        // clear so one verdict never reloads twice, while a NEW floor bump still reloads once.
        const hasAlreadyReloadedFor = (targetVersion) => {
          try {
            return (
              sessionStorage.getItem('1inch:reloaded') === '1' ||
              sessionStorage.getItem('1inch:hard-reload-target') === targetVersion
            );
          } catch (e) {
            return true;
          }
        };

        // Verifies the guard actually persisted — no persisted guard, no reload (fail closed).
        const markReloadedFor = (targetVersion) => {
          try {
            sessionStorage.setItem('1inch:reloaded', '1');
            sessionStorage.setItem('1inch:hard-reload-target', targetVersion);
            return (
              sessionStorage.getItem('1inch:reloaded') === '1' &&
              sessionStorage.getItem('1inch:hard-reload-target') === targetVersion
            );
          } catch (e) {
            return false;
          }
        };

        // A suppressed reload leaves __reloadPending unset on purpose: the soft-update UI then
        // stays available as the manual escape hatch for a client stuck on a stale bundle.
        const hardReload = (currentVersion, targetVersion) => {
          if (window.__reloadPending) {
            return;
          }
          if (isKnownCrawler()) {
            log('Update to ' + targetVersion + ' skipped: crawlers render the served HTML as-is');
            return;
          }
          if (hasAlreadyReloadedFor(targetVersion)) {
            log('Update to ' + targetVersion + ' skipped: already reloaded once for this version');
            return;
          }
          if (!markReloadedFor(targetVersion)) {
            log('Update to ' + targetVersion + ' skipped: reload guard cannot be persisted');
            return;
          }
          log('Reloading in 3 seconds to update from ' + currentVersion + ' → ' + targetVersion);
          window.__reloadPending = true;
          setTimeout(() => {
            window.location.reload(true);
          }, HARD_RELOAD_DELAY_MS);
        };

        const checkRemoteVersion = (currentVersion) => {
          try {
            const versionCheckUrl = 'https://frontend-config.1inch.com/1inch-com-version.json';

            // Exit if placeholder not replaced
            if (versionCheckUrl.includes('PLACEHOLDER')) {
              return;
            }

            const xhr = new XMLHttpRequest();
            xhr.open('GET', versionCheckUrl, true);
            xhr.setRequestHeader('Accept', 'application/json');
            xhr.timeout = FETCH_TIMEOUT_MS;

            xhr.onload = () => {
              if (xhr.status !== 200) return;

              const contentType = xhr.getResponseHeader('content-type');
              if (!contentType || contentType.indexOf('application/json') === -1) return;

              let data;
              try {
                data = JSON.parse(xhr.responseText);
              } catch (e) {
                return;
              }

              if (!data || typeof data !== 'object') return;

              // Cache for Angular SoftUpdateService to reuse.
              window.__oneInchVersionData = { data: data, timestamp: Date.now() };

              if (typeof data.minHardUpdateVersion === 'string') {
                const comparison = compareVersions(currentVersion, data.minHardUpdateVersion);

                if (comparison.status === 'Update required') {
                  log('Version Check: ' + currentVersion + ' → ' + data.minHardUpdateVersion + ' [Update required]');
                  hardReload(currentVersion, data.minHardUpdateVersion);
                }
              }

              // Dispatched AFTER the hard-update check so a pending hard reload
              // (__reloadPending) is already set when SoftUpdateService re-checks —
              // the soft-update UI must not auto-open right before a forced reload.
              window.dispatchEvent(new CustomEvent('oneinch:version-data'));
            };

            // Timeout, network error, abort — all fail silently
            xhr.onerror = xhr.ontimeout = () => {};

            xhr.send();
          } catch (e) {
            // Any unexpected error - fail silently
          }
        };

        const getEnvironment = () => {
          // Check meta tag first (set by inject-version.js at build time)
          const metaEnv = document.querySelector('meta[name="environment"]')?.getAttribute('content');
          if (metaEnv && !metaEnv.includes('PLACEHOLDER')) {
            return metaEnv;
          }
          return null;
        };

        const checkIfHardRefreshRequired = () => {
          const environment = getEnvironment();
          const appVersion = document.querySelector('meta[name="app-version"]')?.getAttribute('content');
          const buildTimestamp = document.querySelector('meta[name="build-timestamp"]')?.getAttribute('content');

          // Skip version check in preview environment
          if (environment === 'preview') {
            return;
          }

          // Exit if placeholders not replaced
          if (
            !appVersion ||
            !buildTimestamp ||
            appVersion.includes('PLACEHOLDER') ||
            buildTimestamp.includes('PLACEHOLDER')
          ) {
            return;
          }

          log('Version: ' + appVersion + ' (' + buildTimestamp + ')');
          checkRemoteVersion(appVersion);

          // Hidden tabs skip the poll and re-check immediately on return to visibility (DAPP-7592).
          setInterval(() => {
            if (document.visibilityState === 'hidden') return;
            checkRemoteVersion(appVersion);
          }, VERSION_CHECK_INTERVAL_MS);

          document.addEventListener('visibilitychange', () => {
            if (document.visibilityState !== 'hidden') {
              checkRemoteVersion(appVersion);
            }
          });
        };

        // Wait for DOM to be ready
        if (document.readyState === 'loading') {
          document.addEventListener('DOMContentLoaded', checkIfHardRefreshRequired);
        } else {
          checkIfHardRefreshRequired();
        }
      })();
    </script>
    <div id="ledger-overlay" style="position: fixed; z-index: 99999; pointer-events: auto"></div>
  <script src="/main-7GZRNYP6.js" type="module"></script></body>
</html>
