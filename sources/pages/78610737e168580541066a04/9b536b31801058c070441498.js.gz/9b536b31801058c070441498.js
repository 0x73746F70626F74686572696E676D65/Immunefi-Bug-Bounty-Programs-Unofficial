(() => {
  const storageKey = 'avacloud-explorer-theme';
  let theme = 'light';

  try {
    const storedTheme = window.localStorage.getItem(storageKey);
    if (storedTheme === 'light' || storedTheme === 'dark') {
      theme = storedTheme;
    }
  } catch (_error) {
    theme = 'light';
  }

  // Mirrors avaCloudDesignTokens.ts (avaCloudThemeCssVariables) for every
  // variable that affects first paint; without the border/field/accent tokens
  // here, light mode briefly renders fields with the dark-theme defaults
  // (invisible borders on white surfaces) until React hydrates.
  const themeVariables =
    theme === 'dark'
      ? {
          '--accent': '#334155',
          '--accent-foreground': '#f1f5f9',
          '--action-border': '#334155',
          '--avacloud-explorer-background': '#020617',
          '--background': '#020617',
          '--border': '#1e293b',
          '--button-border': '#334155',
          '--card': '#0f172a',
          '--card-foreground': '#f1f5f9',
          '--destructive': '#ef4444',
          '--dialog-overlay': 'rgba(2, 6, 23, 0.72)',
          '--foreground': '#f1f5f9',
          '--input': '#334155',
          '--muted': '#1e293b',
          '--muted-foreground': '#94a3b8',
          '--popover': '#1e293b',
          '--popover-foreground': '#f1f5f9',
          '--primary': '#0a7cb9',
          '--primary-foreground': '#ffffff',
          '--ring': '#0a7cb9',
          '--secondary': '#1e293b',
          '--secondary-foreground': '#f1f5f9',
          '--theme': '#0a7cb9',
        }
      : {
          '--accent': '#f1f5f9',
          '--accent-foreground': '#0f172a',
          '--action-border': '#cbd5e1',
          '--avacloud-explorer-background': '#e2e8f0',
          '--background': '#e2e8f0',
          '--border': '#cbd5e1',
          '--button-border': '#cbd5e1',
          '--card': '#ffffff',
          '--card-foreground': '#0f172a',
          '--destructive': '#dc2626',
          '--dialog-overlay': 'rgba(15, 23, 42, 0.32)',
          '--foreground': '#0f172a',
          '--input': '#cbd5e1',
          '--muted': '#f1f5f9',
          '--muted-foreground': '#64748b',
          '--popover': '#ffffff',
          '--popover-foreground': '#0f172a',
          '--primary': '#0a7cb9',
          '--primary-foreground': '#ffffff',
          '--ring': '#0a7cb9',
          '--secondary': '#f1f5f9',
          '--secondary-foreground': '#0f172a',
          '--theme': '#0a7cb9',
        };

  const background = themeVariables['--avacloud-explorer-background'];
  const root = document.documentElement;

  root.style.colorScheme = theme;
  root.style.backgroundColor = background;
  root.classList.toggle('dark', theme === 'dark');
  root.classList.add('avacloud-explorer-theme');

  Object.entries(themeVariables).forEach(([property, value]) => {
    root.style.setProperty(property, value);
  });

  const themeColor = document.querySelector('meta[name="theme-color"]');
  if (themeColor) {
    themeColor.setAttribute('content', background);
  }
})();
