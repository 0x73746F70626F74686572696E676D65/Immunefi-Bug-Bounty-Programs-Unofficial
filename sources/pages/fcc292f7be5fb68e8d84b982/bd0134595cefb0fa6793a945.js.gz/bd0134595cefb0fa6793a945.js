(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,356836,e=>{"use strict";var t=`{
  "connect_wallet": {
    "label": "Connect Wallet",
    "wrong_network": {
      "label": "Wrong network"
    }
  },

  "intro": {
    "title": "What is a Wallet?",
    "description": "A wallet is used to send, receive, store, and display digital assets. It's also a new way to log in, without needing to create new accounts and passwords on every website.",
    "digital_asset": {
      "title": "A Home for your Digital Assets",
      "description": "Wallets are used to send, receive, store, and display digital assets like Ethereum and NFTs."
    },
    "login": {
      "title": "A New Way to Log In",
      "description": "Instead of creating new accounts and passwords on every website, just connect your wallet."
    },
    "get": {
      "label": "Get a Wallet"
    },
    "learn_more": {
      "label": "Learn More"
    }
  },

  "sign_in": {
    "label": "Verify your account",
    "description": "To finish connecting, you must sign a message in your wallet to verify that you are the owner of this account.",
    "message": {
      "send": "Sign message",
      "preparing": "Preparing message...",
      "cancel": "Cancel",
      "preparing_error": "Error preparing message, please retry!"
    },
    "signature": {
      "waiting": "Waiting for signature...",
      "verifying": "Verifying signature...",
      "signing_error": "Error signing message, please retry!",
      "verifying_error": "Error verifying signature, please retry!",
      "oops_error": "Oops, something went wrong!"
    }
  },

  "connect": {
    "label": "Connect",
    "title": "Connect a Wallet",
    "new_to_ethereum": {
      "description": "New to Ethereum wallets?",
      "learn_more": {
        "label": "Learn More"
      }
    },
    "learn_more": {
      "label": "Learn more"
    },
    "recent": "Recent",
    "status": {
      "opening": "Opening %{wallet}...",
      "connecting": "Connecting",
      "connect_mobile": "Continue in %{wallet}",
      "not_installed": "%{wallet} is not installed",
      "not_available": "%{wallet} is not available",
      "confirm": "Confirm connection in the extension",
      "confirm_mobile": "Accept connection request in the wallet"
    },
    "secondary_action": {
      "get": {
        "description": "Don't have %{wallet}?",
        "label": "GET"
      },
      "install": {
        "label": "INSTALL"
      },
      "retry": {
        "label": "RETRY"
      }
    },
    "walletconnect": {
      "description": {
        "full": "Need the official WalletConnect modal?",
        "compact": "Need the WalletConnect modal?"
      },
      "open": {
        "label": "OPEN"
      }
    }
  },

  "connect_scan": {
    "title": "Scan with %{wallet}",
    "fallback_title": "Scan with your phone"
  },

  "connector_group": {
    "installed": "Installed",
    "recommended": "Recommended",
    "other": "Other",
    "popular": "Popular",
    "more": "More",
    "others": "Others"
  },

  "get": {
    "title": "Get a Wallet",
    "action": {
      "label": "GET"
    },
    "mobile": {
      "description": "Mobile Wallet"
    },
    "extension": {
      "description": "Browser Extension"
    },
    "mobile_and_extension": {
      "description": "Mobile Wallet and Extension"
    },
    "mobile_and_desktop": {
      "description": "Mobile and Desktop Wallet"
    },
    "looking_for": {
      "title": "Not what you're looking for?",
      "mobile": {
        "description": "Select a wallet on the main screen to get started with a different wallet provider."
      },
      "desktop": {
        "compact_description": "Select a wallet on the main screen to get started with a different wallet provider.",
        "wide_description": "Select a wallet on the left to get started with a different wallet provider."
      }
    }
  },

  "get_options": {
    "title": "Get started with %{wallet}",
    "short_title": "Get %{wallet}",
    "mobile": {
      "title": "%{wallet} for Mobile",
      "description": "Use the mobile wallet to explore the world of Ethereum.",
      "download": {
        "label": "Get the app"
      }
    },
    "extension": {
      "title": "%{wallet} for %{browser}",
      "description": "Access your wallet right from your favorite web browser.",
      "download": {
        "label": "Add to %{browser}"
      }
    },
    "desktop": {
      "title": "%{wallet} for %{platform}",
      "description": "Access your wallet natively from your powerful desktop.",
      "download": {
        "label": "Add to %{platform}"
      }
    }
  },

  "get_mobile": {
    "title": "Install %{wallet}",
    "description": "Scan with your phone to download on iOS or Android",
    "continue": {
      "label": "Continue"
    }
  },

  "get_instructions": {
    "mobile": {
      "connect": {
        "label": "Connect"
      },
      "learn_more": {
        "label": "Learn More"
      }
    },
    "extension": {
      "refresh": {
        "label": "Refresh"
      },
      "learn_more": {
        "label": "Learn More"
      }
    },
    "desktop": {
      "connect": {
        "label": "Connect"
      },
      "learn_more": {
        "label": "Learn More"
      }
    }
  },

  "chains": {
    "title": "Switch Networks",
    "wrong_network": "Wrong network detected, switch or disconnect to continue.",
    "confirm": "Confirm in Wallet",
    "switching_not_supported": "Your wallet does not support switching networks from %{appName}. Try switching networks from within your wallet instead.",
    "switching_not_supported_fallback": "Your wallet does not support switching networks from this app. Try switching networks from within your wallet instead.",
    "disconnect": "Disconnect",
    "connected": "Connected"
  },

  "profile": {
    "disconnect": {
      "label": "Disconnect"
    },
    "copy_address": {
      "label": "Copy Address",
      "copied": "Copied!"
    },
    "explorer": {
      "label": "View more on explorer"
    },
    "transactions": {
      "description": "%{appName} transactions will appear here...",
      "description_fallback": "Your transactions will appear here...",
      "recent": {
        "title": "Recent Transactions"
      },
      "clear": {
        "label": "Clear All"
      }
    }
  },

  "wallet_connectors": {
    "ready": {
      "qr_code": {
        "step1": {
          "description": "Add Ready to your home screen for faster access to your wallet.",
          "title": "Open the Ready app"
        },
        "step2": {
          "description": "Create a wallet and username, or import an existing wallet.",
          "title": "Create or Import a Wallet"
        },
        "step3": {
          "description": "After you scan, a connection prompt will appear for you to connect your wallet.",
          "title": "Tap the Scan QR button"
        }
      }
    },

    "berasig": {
      "extension": {
        "step1": {
          "title": "Install the BeraSig extension",
          "description": "We recommend pinning BeraSig to your taskbar for easier access to your wallet."
        },
        "step2": {
          "title": "Create a Wallet",
          "description": "Be sure to back up your wallet using a secure method. Never share your secret phrase with anyone."
        },
        "step3": {
          "title": "Refresh your browser",
          "description": "Once you set up your wallet, click below to refresh the browser and load up the extension."
        }
      }
    },

    "best": {
      "qr_code": {
        "step1": {
          "title": "Open the Best Wallet app",
          "description": "Add Best Wallet to your home screen for faster access to your wallet."
        },
        "step2": {
          "title": "Create or Import a Wallet",
          "description": "Create a new wallet or import an existing one."
        },
        "step3": {
          "title": "Tap the QR icon and scan",
          "description": "Tap the QR icon on your homescreen, scan the code and confirm the prompt to connect."
        }
      }
    },

    "bifrost": {
      "qr_code": {
        "step1": {
          "description": "We recommend putting Bifrost Wallet on your home screen for quicker access.",
          "title": "Open the Bifrost Wallet app"
        },
        "step2": {
          "description": "Create or import a wallet using your recovery phrase.",
          "title": "Create or Import a Wallet"
        },
        "step3": {
          "description": "After you scan, a connection prompt will appear for you to connect your wallet.",
          "title": "Tap the scan button"
        }
      }
    },

    "bitget": {
      "qr_code": {
        "step1": {
          "description": "We recommend putting Bitget Wallet on your home screen for quicker access.",
          "title": "Open the Bitget Wallet app"
        },
        "step2": {
          "description": "Be sure to back up your wallet using a secure method. Never share your secret phrase with anyone.",
          "title": "Create or Import a Wallet"
        },
        "step3": {
          "description": "After you scan, a connection prompt will appear for you to connect your wallet.",
          "title": "Tap the scan button"
        }
      },

      "extension": {
        "step1": {
          "description": "We recommend pinning Bitget Wallet to your taskbar for quicker access to your wallet.",
          "title": "Install the Bitget Wallet extension"
        },
        "step2": {
          "description": "Be sure to back up your wallet using a secure method. Never share your secret phrase with anyone.",
          "title": "Create or Import a Wallet"
        },
        "step3": {
          "description": "Once you set up your wallet, click below to refresh the browser and load up the extension.",
          "title": "Refresh your browser"
        }
      }
    },

    "bitski": {
      "extension": {
        "step1": {
          "description": "We recommend pinning Bitski to your taskbar for quicker access to your wallet.",
          "title": "Install the Bitski extension"
        },
        "step2": {
          "description": "Be sure to back up your wallet using a secure method. Never share your secret phrase with anyone.",
          "title": "Create or Import a Wallet"
        },
        "step3": {
          "description": "Once you set up your wallet, click below to refresh the browser and load up the extension.",
          "title": "Refresh your browser"
        }
      }
    },

    "bitverse": {
      "qr_code": {
        "step1": {
          "title": "Open the Bitverse Wallet app",
          "description": "Add Bitverse Wallet to your home screen for faster access to your wallet."
        },
        "step2": {
          "title": "Create or Import a Wallet",
          "description": "Create a new wallet or import an existing one."
        },
        "step3": {
          "title": "Tap the QR icon and scan",
          "description": "Tap the QR icon on your homescreen, scan the code and confirm the prompt to connect."
        }
      }
    },

    "bloom": {
      "desktop": {
        "step1": {
          "title": "Open the Bloom Wallet app",
          "description": "We recommend putting Bloom Wallet on your home screen for quicker access."
        },
        "step2": {
          "description": "Create or import a wallet using your recovery phrase.",
          "title": "Create or Import a Wallet"
        },
        "step3": {
          "description": "After you have a wallet, click on Connect to connect via Bloom. A connection prompt in the app will appear for you to confirm the connection.",
          "title": "Click on Connect"
        }
      }
    },

    "bybit": {
      "qr_code": {
        "step1": {
          "description": "We recommend putting Bybit on your home screen for faster access to your wallet.",
          "title": "Open the Bybit app"
        },
        "step2": {
          "description": "You can easily backup your wallet using our backup feature on your phone.",
          "title": "Create or Import a Wallet"
        },
        "step3": {
          "description": "After you scan, a connection prompt will appear for you to connect your wallet.",
          "title": "Tap the scan button"
        }
      },

      "extension": {
        "step1": {
          "description": "Click at the top right of your browser and pin Bybit Wallet for easy access.",
          "title": "Install the Bybit Wallet extension"
        },
        "step2": {
          "description": "Create a new wallet or import an existing one.",
          "title": "Create or Import a wallet"
        },
        "step3": {
          "description": "Once you set up Bybit Wallet, click below to refresh the browser and load up the extension.",
          "title": "Refresh your browser"
        }
      }
    },

    "binance": {
      "qr_code": {
        "step1": {
          "description": "We recommend putting Binance on your home screen for faster access to your wallet.",
          "title": "Open the Binance app"
        },
        "step2": {
          "description": "You can easily backup your wallet using our backup feature on your phone.",
          "title": "Create or Import a Wallet"
        },
        "step3": {
          "description": "After you scan, a connection prompt will appear for you to connect your wallet.",
          "title": "Tap the WalletConnect button"
        }
      },
      "extension": {
        "step1": {
          "title": "Install the Binance Wallet extension",
          "description": "We recommend pinning Binance Wallet to your taskbar for quicker access to your wallet."
        },
        "step2": {
          "title": "Create or Import a Wallet",
          "description": "Be sure to back up your wallet using a secure method. Never share your secret phrase with anyone."
        },
        "step3": {
          "title": "Refresh your browser",
          "description": "Once you set up your wallet, click below to refresh the browser and load up the extension."
        }
      }
    },

    "coin98": {
      "qr_code": {
        "step1": {
          "description": "We recommend putting Coin98 Wallet on your home screen for faster access to your wallet.",
          "title": "Open the Coin98 Wallet app"
        },
        "step2": {
          "description": "You can easily backup your wallet using our backup feature on your phone.",
          "title": "Create or Import a Wallet"
        },
        "step3": {
          "description": "After you scan, a connection prompt will appear for you to connect your wallet.",
          "title": "Tap the WalletConnect button"
        }
      },

      "extension": {
        "step1": {
          "description": "Click at the top right of your browser and pin Coin98 Wallet for easy access.",
          "title": "Install the Coin98 Wallet extension"
        },
        "step2": {
          "description": "Create a new wallet or import an existing one.",
          "title": "Create or Import a wallet"
        },
        "step3": {
          "description": "Once you set up Coin98 Wallet, click below to refresh the browser and load up the extension.",
          "title": "Refresh your browser"
        }
      }
    },

    "coinbase": {
      "qr_code": {
        "step1": {
          "description": "We recommend putting Coinbase Wallet on your home screen for quicker access.",
          "title": "Open the Coinbase Wallet app"
        },
        "step2": {
          "description": "You can easily backup your wallet using the cloud backup feature.",
          "title": "Create or Import a Wallet"
        },
        "step3": {
          "description": "After you scan, a connection prompt will appear for you to connect your wallet.",
          "title": "Tap the scan button"
        }
      },

      "extension": {
        "step1": {
          "description": "We recommend pinning Coinbase Wallet to your taskbar for quicker access to your wallet.",
          "title": "Install the Coinbase Wallet extension"
        },
        "step2": {
          "description": "Be sure to back up your wallet using a secure method. Never share your secret phrase with anyone.",
          "title": "Create or Import a Wallet"
        },
        "step3": {
          "description": "Once you set up your wallet, click below to refresh the browser and load up the extension.",
          "title": "Refresh your browser"
        }
      }
    },

    "compass": {
      "extension": {
        "step1": {
          "description": "We recommend pinning Compass Wallet to your taskbar for quicker access to your wallet.",
          "title": "Install the Compass Wallet extension"
        },
        "step2": {
          "description": "Be sure to back up your wallet using a secure method. Never share your secret phrase with anyone.",
          "title": "Create or Import a Wallet"
        },
        "step3": {
          "description": "Once you set up your wallet, click below to refresh the browser and load up the extension.",
          "title": "Refresh your browser"
        }
      }
    },

    "core": {
      "qr_code": {
        "step1": {
          "description": "We recommend putting Core on your home screen for faster access to your wallet.",
          "title": "Open the Core app"
        },
        "step2": {
          "description": "You can easily backup your wallet using our backup feature on your phone.",
          "title": "Create or Import a Wallet"
        },
        "step3": {
          "description": "After you scan, a connection prompt will appear for you to connect your wallet.",
          "title": "Tap the WalletConnect button"
        }
      },

      "extension": {
        "step1": {
          "description": "We recommend pinning Core to your taskbar for quicker access to your wallet.",
          "title": "Install the Core extension"
        },
        "step2": {
          "description": "Be sure to back up your wallet using a secure method. Never share your secret phrase with anyone.",
          "title": "Create or Import a Wallet"
        },
        "step3": {
          "description": "Once you set up your wallet, click below to refresh the browser and load up the extension.",
          "title": "Refresh your browser"
        }
      }
    },

    "fox": {
      "qr_code": {
        "step1": {
          "description": "We recommend putting FoxWallet on your home screen for quicker access.",
          "title": "Open the FoxWallet app"
        },
        "step2": {
          "description": "Be sure to back up your wallet using a secure method. Never share your secret phrase with anyone.",
          "title": "Create or Import a Wallet"
        },
        "step3": {
          "description": "After you scan, a connection prompt will appear for you to connect your wallet.",
          "title": "Tap the scan button"
        }
      }
    },

    "frontier": {
      "qr_code": {
        "step1": {
          "description": "We recommend putting Frontier Wallet on your home screen for quicker access.",
          "title": "Open the Frontier Wallet app"
        },
        "step2": {
          "description": "Be sure to back up your wallet using a secure method. Never share your secret phrase with anyone.",
          "title": "Create or Import a Wallet"
        },
        "step3": {
          "description": "After you scan, a connection prompt will appear for you to connect your wallet.",
          "title": "Tap the scan button"
        }
      },

      "extension": {
        "step1": {
          "description": "We recommend pinning Frontier Wallet to your taskbar for quicker access to your wallet.",
          "title": "Install the Frontier Wallet extension"
        },
        "step2": {
          "description": "Be sure to back up your wallet using a secure method. Never share your secret phrase with anyone.",
          "title": "Create or Import a Wallet"
        },
        "step3": {
          "description": "Once you set up your wallet, click below to refresh the browser and load up the extension.",
          "title": "Refresh your browser"
        }
      }
    },

    "im_token": {
      "qr_code": {
        "step1": {
          "title": "Open the imToken app",
          "description": "Put imToken app on your home screen for faster access to your wallet."
        },
        "step2": {
          "title": "Create or Import a Wallet",
          "description": "Create a new wallet or import an existing one."
        },
        "step3": {
          "title": "Tap Scanner Icon in top right corner",
          "description": "Choose New Connection, then scan the QR code and confirm the prompt to connect."
        }
      }
    },

    "iopay": {
      "qr_code": {
        "step1": {
          "description": "We recommend putting ioPay on your home screen for faster access to your wallet.",
          "title": "Open the ioPay app"
        },
        "step2": {
          "description": "You can easily backup your wallet using our backup feature on your phone.",
          "title": "Create or Import a Wallet"
        },
        "step3": {
          "description": "After you scan, a connection prompt will appear for you to connect your wallet.",
          "title": "Tap the WalletConnect button"
        }
      }
    },

    "kaikas": {
      "extension": {
        "step1": {
          "description": "We recommend pinning Kaikas to your taskbar for quicker access to your wallet.",
          "title": "Install the Kaikas extension"
        },
        "step2": {
          "description": "Be sure to back up your wallet using a secure method. Never share your secret phrase with anyone.",
          "title": "Create or Import a Wallet"
        },
        "step3": {
          "description": "Once you set up your wallet, click below to refresh the browser and load up the extension.",
          "title": "Refresh your browser"
        }
      },
      "qr_code": {
        "step1": {
          "title": "Open the Kaikas app",
          "description": "Put Kaikas app on your home screen for faster access to your wallet."
        },
        "step2": {
          "title": "Create or Import a Wallet",
          "description": "Create a new wallet or import an existing one."
        },
        "step3": {
          "title": "Tap Scanner Icon in top right corner",
          "description": "Choose New Connection, then scan the QR code and confirm the prompt to connect."
        }
      }
    },

    "kaia": {
      "extension": {
        "step1": {
          "description": "We recommend pinning Kaia to your taskbar for quicker access to your wallet.",
          "title": "Install the Kaia extension"
        },
        "step2": {
          "description": "Be sure to back up your wallet using a secure method. Never share your secret phrase with anyone.",
          "title": "Create or Import a Wallet"
        },
        "step3": {
          "description": "Once you set up your wallet, click below to refresh the browser and load up the extension.",
          "title": "Refresh your browser"
        }
      },
      "qr_code": {
        "step1": {
          "title": "Open the Kaia app",
          "description": "Put Kaia app on your home screen for faster access to your wallet."
        },
        "step2": {
          "title": "Create or Import a Wallet",
          "description": "Create a new wallet or import an existing one."
        },
        "step3": {
          "title": "Tap Scanner Icon in top right corner",
          "description": "Choose New Connection, then scan the QR code and confirm the prompt to connect."
        }
      }
    },

    "kraken": {
      "qr_code": {
        "step1": {
          "title": "Open the Kraken Wallet app",
          "description": "Add Kraken Wallet to your home screen for faster access to your wallet."
        },
        "step2": {
          "title": "Create or Import a Wallet",
          "description": "Create a new wallet or import an existing one."
        },
        "step3": {
          "title": "Tap the QR icon and scan",
          "description": "Tap the QR icon on your homescreen, scan the code and confirm the prompt to connect."
        }
      }
    },

    "kresus": {
      "qr_code": {
        "step1": {
          "title": "Open the Kresus Wallet app",
          "description": "Add Kresus Wallet to your home screen for faster access to your wallet."
        },
        "step2": {
          "title": "Create or Import a Wallet",
          "description": "Create a new wallet or import an existing one."
        },
        "step3": {
          "title": "Tap the QR icon and scan",
          "description": "Tap the QR icon on your homescreen, scan the code and confirm the prompt to connect."
        }
      }
    },

    "magicEden": {
      "extension": {
        "step1": {
          "title": "Install the Magic Eden extension",
          "description": "We recommend pinning Magic Eden to your taskbar for easier access to your wallet."
        },
        "step2": {
          "title": "Create or Import a Wallet",
          "description": "Be sure to back up your wallet using a secure method. Never share your secret recovery phrase with anyone."
        },
        "step3": {
          "title": "Refresh your browser",
          "description": "Once you set up your wallet, click below to refresh the browser and load up the extension."
        }
      }
    },

    "metamask": {
      "qr_code": {
        "step1": {
          "title": "Open the MetaMask app",
          "description": "We recommend putting MetaMask on your home screen for quicker access."
        },
        "step2": {
          "title": "Create or Import a Wallet",
          "description": "Be sure to back up your wallet using a secure method. Never share your secret phrase with anyone."
        },
        "step3": {
          "title": "Tap the scan button",
          "description": "After you scan, a connection prompt will appear for you to connect your wallet."
        }
      },

      "extension": {
        "step1": {
          "title": "Install the MetaMask extension",
          "description": "We recommend pinning MetaMask to your taskbar for quicker access to your wallet."
        },
        "step2": {
          "title": "Create or Import a Wallet",
          "description": "Be sure to back up your wallet using a secure method. Never share your secret phrase with anyone."
        },
        "step3": {
          "title": "Refresh your browser",
          "description": "Once you set up your wallet, click below to refresh the browser and load up the extension."
        }
      }
    },

    "nestwallet": {
      "extension": {
        "step1": {
          "title": "Install the NestWallet extension",
          "description": "We recommend pinning NestWallet to your taskbar for quicker access to your wallet."
        },
        "step2": {
          "title": "Create or Import a Wallet",
          "description": "Be sure to back up your wallet using a secure method. Never share your secret phrase with anyone."
        },
        "step3": {
          "title": "Refresh your browser",
          "description": "Once you set up your wallet, click below to refresh the browser and load up the extension."
        }
      }
    },

    "okx": {
      "qr_code": {
        "step1": {
          "title": "Open the OKX Wallet app",
          "description": "We recommend putting OKX Wallet on your home screen for quicker access."
        },
        "step2": {
          "title": "Create or Import a Wallet",
          "description": "Be sure to back up your wallet using a secure method. Never share your secret phrase with anyone."
        },
        "step3": {
          "title": "Tap the scan button",
          "description": "After you scan, a connection prompt will appear for you to connect your wallet."
        }
      },

      "extension": {
        "step1": {
          "title": "Install the OKX Wallet extension",
          "description": "We recommend pinning OKX Wallet to your taskbar for quicker access to your wallet."
        },
        "step2": {
          "title": "Create or Import a Wallet",
          "description": "Be sure to back up your wallet using a secure method. Never share your secret phrase with anyone."
        },
        "step3": {
          "title": "Refresh your browser",
          "description": "Once you set up your wallet, click below to refresh the browser and load up the extension."
        }
      }
    },

    "omni": {
      "qr_code": {
        "step1": {
          "title": "Open the Omni app",
          "description": "Add Omni to your home screen for faster access to your wallet."
        },
        "step2": {
          "title": "Create or Import a Wallet",
          "description": "Create a new wallet or import an existing one."
        },
        "step3": {
          "title": "Tap the QR icon and scan",
          "description": "Tap the QR icon on your home screen, scan the code and confirm the prompt to connect."
        }
      }
    },

    "1inch": {
      "qr_code": {
        "step1": {
          "description": "Put 1inch Wallet on your home screen for faster access to your wallet.",
          "title": "Open the 1inch Wallet app"
        },
        "step2": {
          "description": "Create a wallet and username, or import an existing wallet.",
          "title": "Create or Import a Wallet"
        },
        "step3": {
          "description": "After you scan, a connection prompt will appear for you to connect your wallet.",
          "title": "Tap the Scan QR button"
        }
      }
    },

    "token_pocket": {
      "qr_code": {
        "step1": {
          "title": "Open the TokenPocket app",
          "description": "We recommend putting TokenPocket on your home screen for quicker access."
        },
        "step2": {
          "title": "Create or Import a Wallet",
          "description": "Be sure to back up your wallet using a secure method. Never share your secret phrase with anyone."
        },
        "step3": {
          "title": "Tap the scan button",
          "description": "After you scan, a connection prompt will appear for you to connect your wallet."
        }
      },

      "extension": {
        "step1": {
          "title": "Install the TokenPocket extension",
          "description": "We recommend pinning TokenPocket to your taskbar for quicker access to your wallet."
        },
        "step2": {
          "title": "Create or Import a Wallet",
          "description": "Be sure to back up your wallet using a secure method. Never share your secret phrase with anyone."
        },
        "step3": {
          "title": "Refresh your browser",
          "description": "Once you set up your wallet, click below to refresh the browser and load up the extension."
        }
      }
    },

    "trust": {
      "qr_code": {
        "step1": {
          "title": "Open the Trust Wallet app",
          "description": "Put Trust Wallet on your home screen for faster access to your wallet."
        },
        "step2": {
          "title": "Create or Import a Wallet",
          "description": "Create a new wallet or import an existing one."
        },
        "step3": {
          "title": "Tap WalletConnect in Settings",
          "description": "Choose New Connection, then scan the QR code and confirm the prompt to connect."
        }
      },

      "extension": {
        "step1": {
          "title": "Install the Trust Wallet extension",
          "description": "Click at the top right of your browser and pin Trust Wallet for easy access."
        },
        "step2": {
          "title": "Create or Import a wallet",
          "description": "Create a new wallet or import an existing one."
        },
        "step3": {
          "title": "Refresh your browser",
          "description": "Once you set up Trust Wallet, click below to refresh the browser and load up the extension."
        }
      }
    },

    "uniswap": {
      "qr_code": {
        "step1": {
          "title": "Open the Uniswap app",
          "description": "Add Uniswap Wallet to your home screen for faster access to your wallet."
        },
        "step2": {
          "title": "Create or Import a Wallet",
          "description": "Create a new wallet or import an existing one."
        },
        "step3": {
          "title": "Tap the QR icon and scan",
          "description": "Tap the QR icon on your homescreen, scan the code and confirm the prompt to connect."
        }
      }
    },

    "zerion": {
      "qr_code": {
        "step1": {
          "title": "Open the Zerion app",
          "description": "We recommend putting Zerion on your home screen for quicker access."
        },
        "step2": {
          "title": "Create or Import a Wallet",
          "description": "Be sure to back up your wallet using a secure method. Never share your secret phrase with anyone."
        },
        "step3": {
          "title": "Tap the scan button",
          "description": "After you scan, a connection prompt will appear for you to connect your wallet."
        }
      },

      "extension": {
        "step1": {
          "title": "Install the Zerion extension",
          "description": "We recommend pinning Zerion to your taskbar for quicker access to your wallet."
        },
        "step2": {
          "title": "Create or Import a Wallet",
          "description": "Be sure to back up your wallet using a secure method. Never share your secret phrase with anyone."
        },
        "step3": {
          "title": "Refresh your browser",
          "description": "Once you set up your wallet, click below to refresh the browser and load up the extension."
        }
      }
    },

    "rainbow": {
      "qr_code": {
        "step1": {
          "title": "Open the Rainbow app",
          "description": "We recommend putting Rainbow on your home screen for faster access to your wallet."
        },
        "step2": {
          "title": "Create or Import a Wallet",
          "description": "You can easily backup your wallet using our backup feature on your phone."
        },
        "step3": {
          "title": "Tap the scan button",
          "description": "After you scan, a connection prompt will appear for you to connect your wallet."
        }
      }
    },

    "enkrypt": {
      "extension": {
        "step1": {
          "description": "We recommend pinning Enkrypt Wallet to your taskbar for quicker access to your wallet.",
          "title": "Install the Enkrypt Wallet extension"
        },
        "step2": {
          "description": "Be sure to back up your wallet using a secure method. Never share your secret phrase with anyone.",
          "title": "Create or Import a Wallet"
        },
        "step3": {
          "description": "Once you set up your wallet, click below to refresh the browser and load up the extension.",
          "title": "Refresh your browser"
        }
      }
    },

    "frame": {
      "extension": {
        "step1": {
          "description": "We recommend pinning Frame to your taskbar for quicker access to your wallet.",
          "title": "Install Frame & the companion extension"
        },
        "step2": {
          "description": "Be sure to back up your wallet using a secure method. Never share your secret phrase with anyone.",
          "title": "Create or Import a Wallet"
        },
        "step3": {
          "description": "Once you set up your wallet, click below to refresh the browser and load up the extension.",
          "title": "Refresh your browser"
        }
      }
    },

    "one_key": {
      "extension": {
        "step1": {
          "title": "Install the OneKey Wallet extension",
          "description": "We recommend pinning OneKey Wallet to your taskbar for quicker access to your wallet."
        },
        "step2": {
          "title": "Create or Import a Wallet",
          "description": "Be sure to back up your wallet using a secure method. Never share your secret phrase with anyone."
        },
        "step3": {
          "title": "Refresh your browser",
          "description": "Once you set up your wallet, click below to refresh the browser and load up the extension."
        }
      }
    },

    "paraswap": {
      "qr_code": {
        "step1": {
          "title": "Open the ParaSwap app",
          "description": "Add ParaSwap Wallet to your home screen for faster access to your wallet."
        },
        "step2": {
          "title": "Create or Import a Wallet",
          "description": "Create a new wallet or import an existing one."
        },
        "step3": {
          "title": "Tap the QR icon and scan",
          "description": "Tap the QR icon on your homescreen, scan the code and confirm the prompt to connect."
        }
      }
    },

    "phantom": {
      "extension": {
        "step1": {
          "title": "Install the Phantom extension",
          "description": "We recommend pinning Phantom to your taskbar for easier access to your wallet."
        },
        "step2": {
          "title": "Create or Import a Wallet",
          "description": "Be sure to back up your wallet using a secure method. Never share your secret recovery phrase with anyone."
        },
        "step3": {
          "title": "Refresh your browser",
          "description": "Once you set up your wallet, click below to refresh the browser and load up the extension."
        }
      }
    },

    "rabby": {
      "extension": {
        "step1": {
          "title": "Install the Rabby extension",
          "description": "We recommend pinning Rabby to your taskbar for quicker access to your wallet."
        },
        "step2": {
          "title": "Create or Import a Wallet",
          "description": "Be sure to back up your wallet using a secure method. Never share your secret phrase with anyone."
        },
        "step3": {
          "title": "Refresh your browser",
          "description": "Once you set up your wallet, click below to refresh the browser and load up the extension."
        }
      }
    },

    "ronin": {
      "qr_code": {
        "step1": {
          "description": "We recommend putting Ronin Wallet on your home screen for quicker access.",
          "title": "Open the Ronin Wallet app"
        },
        "step2": {
          "description": "Be sure to back up your wallet using a secure method. Never share your secret phrase with anyone.",
          "title": "Create or Import a Wallet"
        },
        "step3": {
          "description": "After you scan, a connection prompt will appear for you to connect your wallet.",
          "title": "Tap the scan button"
        }
      },

      "extension": {
        "step1": {
          "description": "We recommend pinning Ronin Wallet to your taskbar for quicker access to your wallet.",
          "title": "Install the Ronin Wallet extension"
        },
        "step2": {
          "description": "Be sure to back up your wallet using a secure method. Never share your secret phrase with anyone.",
          "title": "Create or Import a Wallet"
        },
        "step3": {
          "description": "Once you set up your wallet, click below to refresh the browser and load up the extension.",
          "title": "Refresh your browser"
        }
      }
    },

    "ramper": {
      "extension": {
        "step1": {
          "title": "Install the Ramper extension",
          "description": "We recommend pinning Ramper to your taskbar for easier access to your wallet."
        },
        "step2": {
          "title": "Create a Wallet",
          "description": "Be sure to back up your wallet using a secure method. Never share your secret phrase with anyone."
        },
        "step3": {
          "title": "Refresh your browser",
          "description": "Once you set up your wallet, click below to refresh the browser and load up the extension."
        }
      }
    },

    "safeheron": {
      "extension": {
        "step1": {
          "title": "Install the Core extension",
          "description": "We recommend pinning Safeheron to your taskbar for quicker access to your wallet."
        },
        "step2": {
          "title": "Create or Import a Wallet",
          "description": "Be sure to back up your wallet using a secure method. Never share your secret phrase with anyone."
        },
        "step3": {
          "title": "Refresh your browser",
          "description": "Once you set up your wallet, click below to refresh the browser and load up the extension."
        }
      }
    },

    "taho": {
      "extension": {
        "step1": {
          "title": "Install the Taho extension",
          "description": "We recommend pinning Taho to your taskbar for quicker access to your wallet."
        },
        "step2": {
          "title": "Create or Import a Wallet",
          "description": "Be sure to back up your wallet using a secure method. Never share your secret phrase with anyone."
        },
        "step3": {
          "title": "Refresh your browser",
          "description": "Once you set up your wallet, click below to refresh the browser and load up the extension."
        }
      }
    },

    "wigwam": {
      "extension": {
        "step1": {
          "title": "Install the Wigwam extension",
          "description": "We recommend pinning Wigwam to your taskbar for quicker access to your wallet."
        },
        "step2": {
          "title": "Create or Import a Wallet",
          "description": "Be sure to back up your wallet using a secure method. Never share your secret phrase with anyone."
        },
        "step3": {
          "title": "Refresh your browser",
          "description": "Once you set up your wallet, click below to refresh the browser and load up the extension."
        }
      }
    },

    "talisman": {
      "extension": {
        "step1": {
          "title": "Install the Talisman extension",
          "description": "We recommend pinning Talisman to your taskbar for quicker access to your wallet."
        },
        "step2": {
          "title": "Create or Import an Ethereum Wallet",
          "description": "Be sure to back up your wallet using a secure method. Never share your recovery phrase with anyone."
        },
        "step3": {
          "title": "Refresh your browser",
          "description": "Once you set up your wallet, click below to refresh the browser and load up the extension."
        }
      }
    },

    "ctrl": {
      "extension": {
        "step1": {
          "title": "Install the CTRL Wallet extension",
          "description": "We recommend pinning CTRL Wallet to your taskbar for quicker access to your wallet."
        },
        "step2": {
          "title": "Create or Import a Wallet",
          "description": "Be sure to back up your wallet using a secure method. Never share your secret phrase with anyone."
        },
        "step3": {
          "title": "Refresh your browser",
          "description": "Once you set up your wallet, click below to refresh the browser and load up the extension."
        }
      }
    },

    "zeal": {
      "qr_code": {
        "step1": {
          "title": "Open the Zeal app",
          "description": "Add Zeal Wallet to your home screen for faster access to your wallet."
        },
        "step2": {
          "title": "Create or Import a Wallet",
          "description": "Create a new wallet or import an existing one."
        },
        "step3": {
          "title": "Tap the QR icon and scan",
          "description": "Tap the QR icon on your homescreen, scan the code and confirm the prompt to connect."
        }
      },
      "extension": {
        "step1": {
          "title": "Install the Zeal extension",
          "description": "We recommend pinning Zeal to your taskbar for quicker access to your wallet."
        },
        "step2": {
          "title": "Create or Import a Wallet",
          "description": "Be sure to back up your wallet using a secure method. Never share your secret phrase with anyone."
        },
        "step3": {
          "title": "Refresh your browser",
          "description": "Once you set up your wallet, click below to refresh the browser and load up the extension."
        }
      }
    },

    "safepal": {
      "extension": {
        "step1": {
          "title": "Install the SafePal Wallet extension",
          "description": "Click at the top right of your browser and pin SafePal Wallet for easy access."
        },
        "step2": {
          "title": "Create or Import a wallet",
          "description": "Create a new wallet or import an existing one."
        },
        "step3": {
          "title": "Refresh your browser",
          "description": "Once you set up SafePal Wallet, click below to refresh the browser and load up the extension."
        }
      },
      "qr_code": {
        "step1": {
          "title": "Open the SafePal Wallet app",
          "description": "Put SafePal Wallet on your home screen for faster access to your wallet."
        },
        "step2": {
          "title": "Create or Import a Wallet",
          "description": "Create a new wallet or import an existing one."
        },
        "step3": {
          "title": "Tap WalletConnect in Settings",
          "description": "Choose New Connection, then scan the QR code and confirm the prompt to connect."
        }
      }
    },

    "desig": {
      "extension": {
        "step1": {
          "title": "Install the Desig extension",
          "description": "We recommend pinning Desig to your taskbar for easier access to your wallet."
        },
        "step2": {
          "title": "Create a Wallet",
          "description": "Be sure to back up your wallet using a secure method. Never share your secret phrase with anyone."
        },
        "step3": {
          "title": "Refresh your browser",
          "description": "Once you set up your wallet, click below to refresh the browser and load up the extension."
        }
      }
    },

    "subwallet": {
      "extension": {
        "step1": {
          "title": "Install the SubWallet extension",
          "description": "We recommend pinning SubWallet to your taskbar for quicker access to your wallet."
        },
        "step2": {
          "title": "Create or Import a Wallet",
          "description": "Be sure to back up your wallet using a secure method. Never share your recovery phrase with anyone."
        },
        "step3": {
          "title": "Refresh your browser",
          "description": "Once you set up your wallet, click below to refresh the browser and load up the extension."
        }
      },
      "qr_code": {
        "step1": {
          "title": "Open the SubWallet app",
          "description": "We recommend putting SubWallet on your home screen for quicker access."
        },
        "step2": {
          "title": "Create or Import a Wallet",
          "description": "Be sure to back up your wallet using a secure method. Never share your secret phrase with anyone."
        },
        "step3": {
          "title": "Tap the scan button",
          "description": "After you scan, a connection prompt will appear for you to connect your wallet."
        }
      }
    },

    "clv": {
      "extension": {
        "step1": {
          "title": "Install the CLV Wallet extension",
          "description": "We recommend pinning CLV Wallet to your taskbar for quicker access to your wallet."
        },
        "step2": {
          "title": "Create or Import a Wallet",
          "description": "Be sure to back up your wallet using a secure method. Never share your secret phrase with anyone."
        },
        "step3": {
          "title": "Refresh your browser",
          "description": "Once you set up your wallet, click below to refresh the browser and load up the extension."
        }
      },
      "qr_code": {
        "step1": {
          "title": "Open the CLV Wallet app",
          "description": "We recommend putting CLV Wallet on your home screen for quicker access."
        },
        "step2": {
          "title": "Create or Import a Wallet",
          "description": "Be sure to back up your wallet using a secure method. Never share your secret phrase with anyone."
        },
        "step3": {
          "title": "Tap the scan button",
          "description": "After you scan, a connection prompt will appear for you to connect your wallet."
        }
      }
    },

    "okto": {
      "qr_code": {
        "step1": {
          "title": "Open the Okto app",
          "description": "Add Okto to your home screen for quick access"
        },
        "step2": {
          "title": "Create an MPC Wallet",
          "description": "Create an account and generate a wallet"
        },
        "step3": {
          "title": "Tap WalletConnect in Settings",
          "description": "Tap the Scan QR icon at the top right and confirm the prompt to connect."
        }
      }
    },

    "ledger": {
      "desktop": {
        "step1": {
          "title": "Open the Ledger Live app",
          "description": "We recommend putting Ledger Live on your home screen for quicker access."
        },
        "step2": {
          "title": "Set up your Ledger",
          "description": "Set up a new Ledger or connect to an existing one."
        },
        "step3": {
          "title": "Connect",
          "description": "A connection prompt will appear for you to connect your wallet."
        }
      },
      "qr_code": {
        "step1": {
          "title": "Open the Ledger Live app",
          "description": "We recommend putting Ledger Live on your home screen for quicker access."
        },
        "step2": {
          "title": "Set up your Ledger",
          "description": "You can either sync with the desktop app or connect your Ledger."
        },
        "step3": {
          "title": "Scan the code",
          "description": "Tap WalletConnect then Switch to Scanner. After you scan, a connection prompt will appear for you to connect your wallet."
        }
      }
    },

    "valora": {
      "qr_code": {
        "step1": {
          "title": "Open the Valora app",
          "description": "We recommend putting Valora on your home screen for quicker access."
        },
        "step2": {
          "title": "Create or import a wallet",
          "description": "Create a new wallet or import an existing one."
        },
        "step3": {
          "title": "Tap the scan button",
          "description": "After you scan, a connection prompt will appear for you to connect your wallet."
        }
      }
    },

    "gate": {
      "qr_code": {
        "step1": {
          "title": "Open the Gate app",
          "description": "We recommend putting Gate on your home screen for quicker access."
        },
        "step2": {
          "title": "Create or Import a Wallet",
          "description": "Create a new wallet or import an existing one."
        },
        "step3": {
          "title": "Tap the scan button",
          "description": "After you scan, a connection prompt will appear for you to connect your wallet."
        }
      },
      "extension": {
        "step1": {
          "title": "Install the Gate extension",
          "description": "We recommend pinning Gate to your taskbar for easier access to your wallet."
        },
        "step2": {
          "title": "Create or Import a Wallet",
          "description": "Be sure to back up your wallet using a secure method. Never share your secret recovery phrase with anyone."
        },
        "step3": {
          "title": "Refresh your browser",
          "description": "Once you set up your wallet, click below to refresh the browser and load up the extension."
        }
      }
    },

    "gemini": {
      "qr_code": {
        "step1": {
          "title": "Open keys.gemini.com",
          "description": "Visit keys.gemini.com on your mobile browser - no app download required."
        },
        "step2": {
          "title": "Create Your Wallet Instantly",
          "description": "Set up your smart wallet in seconds using your device's built-in authentication."
        },
        "step3": {
          "title": "Scan to Connect",
          "description": "Scan the QR code to instantly connect your wallet - it just works."
        }
      },
      "extension": {
        "step1": {
          "title": "Go to keys.gemini.com",
          "description": "No extensions or downloads needed - your wallet lives securely in the browser."
        },
        "step2": {
          "title": "One-Click Setup",
          "description": "Create your smart wallet instantly with passkey authentication - easier than any wallet out there."
        },
        "step3": {
          "title": "Connect and Go",
          "description": "Approve the connection and you're ready - the unopinionated wallet that just works."
        }
      }
    },

    "xportal": {
      "qr_code": {
        "step1": {
          "description": "Put xPortal on your home screen for faster access to your wallet.",
          "title": "Open the xPortal app"
        },
        "step2": {
          "description": "Create a wallet or import an existing one.",
          "title": "Create or Import a Wallet"
        },
        "step3": {
          "description": "After you scan, a connection prompt will appear for you to connect your wallet.",
          "title": "Tap the Scan QR button"
        }
      }
    },

    "mew": {
      "qr_code": {
        "step1": {
          "description": "We recommend putting MEW Wallet on your home screen for quicker access.",
          "title": "Open the MEW Wallet app"
        },
        "step2": {
          "description": "You can easily backup your wallet using the cloud backup feature.",
          "title": "Create or Import a Wallet"
        },
        "step3": {
          "description": "After you scan, a connection prompt will appear for you to connect your wallet.",
          "title": "Tap the scan button"
        }
      }
    },

    "zilpay": {
      "qr_code": {
        "step1": {
          "title": "Open the ZilPay app",
          "description": "Add ZilPay to your home screen for faster access to your wallet."
        },
        "step2": {
          "title": "Create or Import a Wallet",
          "description": "Create a new wallet or import an existing one."
        },
        "step3": {
          "title": "Tap the scan button",
          "description": "After you scan, a connection prompt will appear for you to connect your wallet."
        }
      }
    },

    "nova": {
      "qr_code": {
        "step1": {
          "title": "Open the Nova Wallet app",
          "description": "Add Nova Wallet to your home screen for faster access to your wallet."
        },
        "step2": {
          "title": "Create or Import a Wallet",
          "description": "Create a new wallet or import an existing one."
        },
        "step3": {
          "title": "Tap the scan button",
          "description": "After you scan, a connection prompt will appear for you to connect your wallet."
        }
      }
    },

    "meco": {
      "qr_code": {
        "step1": {
          "title": "Open the MeCo Wallet app",
          "description": "Put MeCo Wallet on your home screen for faster access to your wallet."
        },
        "step2": {
          "title": "Create or Import a Wallet",
          "description": "Create a new wallet or import an existing one."
        },
        "step3": {
          "title": "Tap the scan button",
          "description": "After you scan, a connection prompt will appear for you to connect your wallet."
        }
      }
    },

    "anchorage_digital": {
      "extension": {
        "step1": {
          "title": "Install the Anchorage Digital extension",
          "description": "We recommend pinning Anchorage Digital to your taskbar for easier access to your wallet."
        },
        "step2": {
          "title": "Scan the QR code to login",
          "description": "Securely connect your organization's wallets to dApps with institutional-grade security."
        },
        "step3": {
          "title": "Refresh your browser",
          "description": "Once you log in, click below to refresh the browser and load up the extension."
        }
      }
    }
  }
}
`;e.s(["en_US_default",0,t])},266027,912598,469637,e=>{"use strict";let t;var o=e.i(869230),r=e.i(271645),a=e.i(273911),n=e.i(619273),s=e.i(540143),i=e.i(843476),l=r.createContext(void 0),c=e=>{let t=r.useContext(l);if(e)return e;if(!t)throw Error("No QueryClient set, use QueryClientProvider to set one");return t};e.s(["QueryClientProvider",0,({client:e,children:t})=>(r.useEffect(()=>(e.mount(),()=>{e.unmount()}),[e]),(0,i.jsx)(l.Provider,{value:e,children:t})),"useQueryClient",0,c],912598);var u=r.createContext((t=!1,{clearReset:()=>{t=!1},reset:()=>{t=!0},isReset:()=>t})),p=r.createContext(!1);p.Provider;var d=(e,t,o)=>t.fetchOptimistic(e).catch(()=>{o.clearReset()});function h(e,t,o){let i,l=r.useContext(p),h=r.useContext(u),f=c(o),m=f.defaultQueryOptions(e);f.getDefaultOptions().queries?._experimental_beforeQuery?.(m);let y=f.getQueryCache().get(m.queryHash),w=!1!==e.subscribed;if(m._optimisticResults=l?"isRestoring":w?"optimistic":void 0,m.suspense){let e=e=>"static"===e?e:Math.max(e??1e3,1e3),t=m.staleTime;m.staleTime="function"==typeof t?(...o)=>e(t(...o)):e(t),"number"==typeof m.gcTime&&(m.gcTime=Math.max(m.gcTime,1e3))}i=y?.state.error&&"function"==typeof m.throwOnError?(0,n.shouldThrowError)(m.throwOnError,[y.state.error,y]):m.throwOnError,(m.suspense||m.experimental_prefetchInRender||i)&&!h.isReset()&&(m.retryOnMount=!1),r.useEffect(()=>{h.clearReset()},[h]);let g=!f.getQueryCache().get(m.queryHash),[b]=r.useState(()=>new t(f,m)),v=b.getOptimisticResult(m),x=!l&&w;if(r.useSyncExternalStore(r.useCallback(e=>{let t=x?b.subscribe(s.notifyManager.batchCalls(e)):n.noop;return b.updateResult(),t},[b,x]),()=>b.getCurrentResult(),()=>b.getCurrentResult()),r.useEffect(()=>{b.setOptions(m)},[m,b]),m?.suspense&&v.isPending)throw d(m,b,h);if((({result:e,errorResetBoundary:t,throwOnError:o,query:r,suspense:a})=>e.isError&&!t.isReset()&&!e.isFetching&&r&&(a&&void 0===e.data||(0,n.shouldThrowError)(o,[e.error,r])))({result:v,errorResetBoundary:h,throwOnError:m.throwOnError,query:y,suspense:m.suspense}))throw v.error;if(f.getDefaultOptions().queries?._experimental_afterQuery?.(m,v),m.experimental_prefetchInRender&&!a.environmentManager.isServer()&&v.isLoading&&v.isFetching&&!l){let e=g?d(m,b,h):y?.promise;e?.catch(n.noop).finally(()=>{b.updateResult()})}return m.notifyOnChangeProps?v:b.trackResult(v)}e.s(["useBaseQuery",0,h],469637),e.s(["useQuery",0,function(e,t){return h(e,o.QueryObserver,t)}],266027)},828646,365087,909744,e=>{"use strict";function t(e){let t=e.state.current,o=e.state.connections.get(t),r=o?.accounts,a=r?.[0],n=e.chains.find(e=>e.id===o?.chainId),s=e.state.status;switch(s){case"connected":return{address:a,addresses:r,chain:n,chainId:o?.chainId,connector:o?.connector,isConnected:!0,isConnecting:!1,isDisconnected:!1,isReconnecting:!1,status:s};case"reconnecting":return{address:a,addresses:r,chain:n,chainId:o?.chainId,connector:o?.connector,isConnected:!!a,isConnecting:!1,isDisconnected:!1,isReconnecting:!0,status:s};case"connecting":return{address:a,addresses:r,chain:n,chainId:o?.chainId,connector:o?.connector,isConnected:!1,isConnecting:!0,isDisconnected:!1,isReconnecting:!1,status:s};case"disconnected":return{address:void 0,addresses:void 0,chain:void 0,chainId:void 0,connector:void 0,isConnected:!1,isConnecting:!1,isDisconnected:!0,isReconnecting:!1,status:s}}}function o(e,t){if(e===t)return!0;if(e&&t&&"object"==typeof e&&"object"==typeof t){let r,a;if(e.constructor!==t.constructor)return!1;if(Array.isArray(e)&&Array.isArray(t)){if((r=e.length)!==t.length)return!1;for(a=r;0!=a--;)if(!o(e[a],t[a]))return!1;return!0}if("function"==typeof e.valueOf&&e.valueOf!==Object.prototype.valueOf)return e.valueOf()===t.valueOf();if("function"==typeof e.toString&&e.toString!==Object.prototype.toString)return e.toString()===t.toString();let n=Object.keys(e);if((r=n.length)!==Object.keys(t).length)return!1;for(a=r;0!=a--;)if(!Object.hasOwn(t,n[a]))return!1;for(a=r;0!=a--;){let r=n[a];if(r&&!o(e[r],t[r]))return!1}return!0}return e!=e&&t!=t}e.s(["getAccount",0,t],828646),e.s(["deepEqual",0,o],365087),e.s(["watchAccount",0,function(e,r){let{onChange:a}=r;return e.subscribe(()=>t(e),a,{equalityFn(e,t){let{connector:r,...a}=e,{connector:n,...s}=t;return o(a,s)&&r?.id===n?.id&&r?.uid===n?.uid}})}],909744)},288916,e=>{"use strict";var t=e.i(804558),o=e.i(426254);async function r(e,r){let{allowFailure:a=!0,chainId:n,contracts:s,...i}=r,l=e.getClient({chainId:n});return(0,o.getAction)(l,t.multicall,"multicall")({allowFailure:a,contracts:s,...i})}e.s(["multicall",0,r])},789594,e=>{"use strict";var t=e.i(388750),o=e.i(426254);e.s(["readContract",0,function(e,r){let{chainId:a,...n}=r,s=e.getClient({chainId:a});return(0,o.getAction)(s,t.readContract,"readContract")(n)}])},626338,e=>{"use strict";var t=e.i(878023),o=e.i(288916),r=e.i(789594);async function a(e,a){let{allowFailure:n=!0,blockNumber:s,blockTag:i,...l}=a,c=a.contracts;try{let t={};for(let[o,r]of c.entries()){let a=r.chainId??e.state.chainId;t[a]||(t[a]=[]),t[a]?.push({contract:r,index:o})}let r=(await Promise.all(Object.entries(t).map(([t,r])=>(0,o.multicall)(e,{...l,allowFailure:n,blockNumber:s,blockTag:i,chainId:Number.parseInt(t,10),contracts:r.map(({contract:e})=>e)})))).flat(),a=Object.values(t).flatMap(e=>e.map(({index:e})=>e));return r.reduce((e,t,o)=>(e&&(e[a[o]]=t),e),[])}catch(a){if(a instanceof t.ContractFunctionExecutionError)throw a;let o=()=>c.map(t=>(0,r.readContract)(e,{...t,blockNumber:s,blockTag:i}));if(n)return(await Promise.allSettled(o())).map(e=>"fulfilled"===e.status?{result:e.value,status:"success"}:{error:e.reason,result:void 0,status:"failure"});return await Promise.all(o())}}e.s(["readContracts",0,a])},789408,954616,348396,170778,e=>{"use strict";var t=e.i(619273);function o(e){return JSON.stringify(e,(e,t)=>!function(e){if(!r(e))return!1;let t=e.constructor;if(void 0===t)return!0;let o=t.prototype;return!!r(o)&&!!o.hasOwnProperty("isPrototypeOf")}(t)?"bigint"==typeof t?t.toString():t:Object.keys(t).sort().reduce((e,o)=>(e[o]=t[o],e),{}))}function r(e){return"[object Object]"===Object.prototype.toString.call(e)}e.s(["filterQueryOptions",0,function(e){let{_defaulted:t,behavior:o,gcTime:r,initialData:a,initialDataUpdatedAt:n,maxPages:s,meta:i,networkMode:l,queryFn:c,queryHash:u,queryKey:p,queryKeyHashFn:d,retry:h,retryDelay:f,structuralSharing:m,getPreviousPageParam:y,getNextPageParam:w,initialPageParam:g,_optimisticResults:b,enabled:v,notifyOnChangeProps:x,placeholderData:k,refetchInterval:C,refetchIntervalInBackground:W,refetchOnMount:I,refetchOnReconnect:O,refetchOnWindowFocus:E,retryOnMount:R,select:S,staleTime:T,suspense:_,throwOnError:N,config:B,connector:q,query:A,...M}=e;return M},"hashFn",0,o,"structuralSharing",0,function(e,o){return(0,t.replaceEqualDeep)(e,o)}],789408);var a=e.i(266027),n=e.i(271645),s=e.i(556345),i=e.i(540143),l=e.i(912598);function c(e){return e.state.chainId}e.s(["useMutation",0,function(e,o){let r=(0,l.useQueryClient)(o),[a]=n.useState(()=>new s.MutationObserver(r,e));n.useEffect(()=>{a.setOptions(e)},[a,e]);let c=n.useSyncExternalStore(n.useCallback(e=>a.subscribe(i.notifyManager.batchCalls(e)),[a]),()=>a.getCurrentResult(),()=>a.getCurrentResult()),u=n.useCallback((e,o)=>{a.mutate(e,o).catch(t.noop)},[a]);if(c.error&&(0,t.shouldThrowError)(a.options.throwOnError,[c.error]))throw c.error;return{...c,mutate:u,mutateAsync:c.mutate}}],954616),e.s(["useQuery",0,function(e){let t=(0,a.useQuery)({...e,queryKeyHashFn:o});return t.queryKey=e.queryKey,t}],348396);var u=e.i(210920);e.s(["useChainId",0,function(e={}){let t=(0,u.useConfig)(e);return(0,n.useSyncExternalStore)(e=>(function(e,t){let{onChange:o}=t;return e.subscribe(e=>e.chainId,o)})(t,{onChange:e}),()=>c(t),()=>c(t))}],170778)},426254,e=>{"use strict";e.s(["getAction",0,function(e,t,o){let r=e[t.name];if("function"==typeof r)return r;let a=e[o];return"function"==typeof a?a:o=>t(e,o)}])},618566,(e,t,o)=>{t.exports=e.r(976562)},846696,e=>{"use strict";var t=e.i(271645),o=e.i(174080);let r=Array(12).fill(0),a=({visible:e,className:o})=>t.default.createElement("div",{className:["sonner-loading-wrapper",o].filter(Boolean).join(" "),"data-visible":e},t.default.createElement("div",{className:"sonner-spinner"},r.map((e,o)=>t.default.createElement("div",{className:"sonner-loading-bar",key:`spinner-bar-${o}`})))),n=t.default.createElement("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 20 20",fill:"currentColor",height:"20",width:"20"},t.default.createElement("path",{fillRule:"evenodd",d:"M10 18a8 8 0 100-16 8 8 0 000 16zm3.857-9.809a.75.75 0 00-1.214-.882l-3.483 4.79-1.88-1.88a.75.75 0 10-1.06 1.061l2.5 2.5a.75.75 0 001.137-.089l4-5.5z",clipRule:"evenodd"})),s=t.default.createElement("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 24 24",fill:"currentColor",height:"20",width:"20"},t.default.createElement("path",{fillRule:"evenodd",d:"M9.401 3.003c1.155-2 4.043-2 5.197 0l7.355 12.748c1.154 2-.29 4.5-2.599 4.5H4.645c-2.309 0-3.752-2.5-2.598-4.5L9.4 3.003zM12 8.25a.75.75 0 01.75.75v3.75a.75.75 0 01-1.5 0V9a.75.75 0 01.75-.75zm0 8.25a.75.75 0 100-1.5.75.75 0 000 1.5z",clipRule:"evenodd"})),i=t.default.createElement("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 20 20",fill:"currentColor",height:"20",width:"20"},t.default.createElement("path",{fillRule:"evenodd",d:"M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a.75.75 0 000 1.5h.253a.25.25 0 01.244.304l-.459 2.066A1.75 1.75 0 0010.747 15H11a.75.75 0 000-1.5h-.253a.25.25 0 01-.244-.304l.459-2.066A1.75 1.75 0 009.253 9H9z",clipRule:"evenodd"})),l=t.default.createElement("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 20 20",fill:"currentColor",height:"20",width:"20"},t.default.createElement("path",{fillRule:"evenodd",d:"M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-8-5a.75.75 0 01.75.75v4.5a.75.75 0 01-1.5 0v-4.5A.75.75 0 0110 5zm0 10a1 1 0 100-2 1 1 0 000 2z",clipRule:"evenodd"})),c=t.default.createElement("svg",{xmlns:"http://www.w3.org/2000/svg",width:"12",height:"12",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"1.5",strokeLinecap:"round",strokeLinejoin:"round"},t.default.createElement("line",{x1:"18",y1:"6",x2:"6",y2:"18"}),t.default.createElement("line",{x1:"6",y1:"6",x2:"18",y2:"18"})),u=1,p=new class{constructor(){this.subscribe=e=>(this.subscribers.push(e),()=>{let t=this.subscribers.indexOf(e);this.subscribers.splice(t,1)}),this.publish=e=>{this.subscribers.forEach(t=>t(e))},this.addToast=e=>{this.publish(e),this.toasts=[...this.toasts,e]},this.create=e=>{var t;let{message:o,...r}=e,a="number"==typeof(null==e?void 0:e.id)||(null==(t=e.id)?void 0:t.length)>0?e.id:u++,n=this.toasts.find(e=>e.id===a),s=void 0===e.dismissible||e.dismissible;return this.dismissedToasts.has(a)&&this.dismissedToasts.delete(a),n?this.toasts=this.toasts.map(t=>t.id===a?(this.publish({...t,...e,id:a,title:o}),{...t,...e,id:a,dismissible:s,title:o}):t):this.addToast({title:o,...r,dismissible:s,id:a}),a},this.dismiss=e=>(e?(this.dismissedToasts.add(e),requestAnimationFrame(()=>this.subscribers.forEach(t=>t({id:e,dismiss:!0})))):this.toasts.forEach(e=>{this.subscribers.forEach(t=>t({id:e.id,dismiss:!0}))}),e),this.message=(e,t)=>this.create({...t,message:e}),this.error=(e,t)=>this.create({...t,message:e,type:"error"}),this.success=(e,t)=>this.create({...t,type:"success",message:e}),this.info=(e,t)=>this.create({...t,type:"info",message:e}),this.warning=(e,t)=>this.create({...t,type:"warning",message:e}),this.loading=(e,t)=>this.create({...t,type:"loading",message:e}),this.promise=(e,o)=>{let r,a;if(!o)return;void 0!==o.loading&&(a=this.create({...o,promise:e,type:"loading",message:o.loading,description:"function"!=typeof o.description?o.description:void 0}));let n=Promise.resolve(e instanceof Function?e():e),s=void 0!==a,i=n.then(async e=>{if(r=["resolve",e],t.default.isValidElement(e))s=!1,this.create({id:a,type:"default",message:e});else if(d(e)&&!e.ok){s=!1;let r="function"==typeof o.error?await o.error(`HTTP error! status: ${e.status}`):o.error,n="function"==typeof o.description?await o.description(`HTTP error! status: ${e.status}`):o.description,i="object"!=typeof r||t.default.isValidElement(r)?{message:r}:r;this.create({id:a,type:"error",description:n,...i})}else if(e instanceof Error){s=!1;let r="function"==typeof o.error?await o.error(e):o.error,n="function"==typeof o.description?await o.description(e):o.description,i="object"!=typeof r||t.default.isValidElement(r)?{message:r}:r;this.create({id:a,type:"error",description:n,...i})}else if(void 0!==o.success){s=!1;let r="function"==typeof o.success?await o.success(e):o.success,n="function"==typeof o.description?await o.description(e):o.description,i="object"!=typeof r||t.default.isValidElement(r)?{message:r}:r;this.create({id:a,type:"success",description:n,...i})}}).catch(async e=>{if(r=["reject",e],void 0!==o.error){s=!1;let r="function"==typeof o.error?await o.error(e):o.error,n="function"==typeof o.description?await o.description(e):o.description,i="object"!=typeof r||t.default.isValidElement(r)?{message:r}:r;this.create({id:a,type:"error",description:n,...i})}}).finally(()=>{s&&(this.dismiss(a),a=void 0),null==o.finally||o.finally.call(o)}),l=()=>new Promise((e,t)=>i.then(()=>"reject"===r[0]?t(r[1]):e(r[1])).catch(t));return"string"!=typeof a&&"number"!=typeof a?{unwrap:l}:Object.assign(a,{unwrap:l})},this.custom=(e,t)=>{let o=(null==t?void 0:t.id)||u++;return this.create({jsx:e(o),id:o,...t}),o},this.getActiveToasts=()=>this.toasts.filter(e=>!this.dismissedToasts.has(e.id)),this.subscribers=[],this.toasts=[],this.dismissedToasts=new Set}},d=e=>e&&"object"==typeof e&&"ok"in e&&"boolean"==typeof e.ok&&"status"in e&&"number"==typeof e.status,h=Object.assign((e,t)=>{let o=(null==t?void 0:t.id)||u++;return p.addToast({title:e,...t,id:o}),o},{success:p.success,info:p.info,warning:p.warning,error:p.error,custom:p.custom,message:p.message,promise:p.promise,dismiss:p.dismiss,loading:p.loading},{getHistory:()=>p.toasts,getToasts:()=>p.getActiveToasts()});function f(e){return void 0!==e.label}function m(...e){return e.filter(Boolean).join(" ")}!function(e){if(!e||"u"<typeof document)return;let t=document.head||document.getElementsByTagName("head")[0],o=document.createElement("style");o.type="text/css",t.appendChild(o),o.styleSheet?o.styleSheet.cssText=e:o.appendChild(document.createTextNode(e))}("[data-sonner-toaster][dir=ltr],html[dir=ltr]{--toast-icon-margin-start:-3px;--toast-icon-margin-end:4px;--toast-svg-margin-start:-1px;--toast-svg-margin-end:0px;--toast-button-margin-start:auto;--toast-button-margin-end:0;--toast-close-button-start:0;--toast-close-button-end:unset;--toast-close-button-transform:translate(-35%, -35%)}[data-sonner-toaster][dir=rtl],html[dir=rtl]{--toast-icon-margin-start:4px;--toast-icon-margin-end:-3px;--toast-svg-margin-start:0px;--toast-svg-margin-end:-1px;--toast-button-margin-start:0;--toast-button-margin-end:auto;--toast-close-button-start:unset;--toast-close-button-end:0;--toast-close-button-transform:translate(35%, -35%)}[data-sonner-toaster]{position:fixed;width:var(--width);font-family:ui-sans-serif,system-ui,-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Helvetica Neue,Arial,Noto Sans,sans-serif,Apple Color Emoji,Segoe UI Emoji,Segoe UI Symbol,Noto Color Emoji;--gray1:hsl(0, 0%, 99%);--gray2:hsl(0, 0%, 97.3%);--gray3:hsl(0, 0%, 95.1%);--gray4:hsl(0, 0%, 93%);--gray5:hsl(0, 0%, 90.9%);--gray6:hsl(0, 0%, 88.7%);--gray7:hsl(0, 0%, 85.8%);--gray8:hsl(0, 0%, 78%);--gray9:hsl(0, 0%, 56.1%);--gray10:hsl(0, 0%, 52.3%);--gray11:hsl(0, 0%, 43.5%);--gray12:hsl(0, 0%, 9%);--border-radius:8px;box-sizing:border-box;padding:0;margin:0;list-style:none;outline:0;z-index:999999999;transition:transform .4s ease}@media (hover:none) and (pointer:coarse){[data-sonner-toaster][data-lifted=true]{transform:none}}[data-sonner-toaster][data-x-position=right]{right:var(--offset-right)}[data-sonner-toaster][data-x-position=left]{left:var(--offset-left)}[data-sonner-toaster][data-x-position=center]{left:50%;transform:translateX(-50%)}[data-sonner-toaster][data-y-position=top]{top:var(--offset-top)}[data-sonner-toaster][data-y-position=bottom]{bottom:var(--offset-bottom)}[data-sonner-toast]{--y:translateY(100%);--lift-amount:calc(var(--lift) * var(--gap));z-index:var(--z-index);position:absolute;opacity:0;transform:var(--y);touch-action:none;transition:transform .4s,opacity .4s,height .4s,box-shadow .2s;box-sizing:border-box;outline:0;overflow-wrap:anywhere}[data-sonner-toast][data-styled=true]{padding:16px;background:var(--normal-bg);border:1px solid var(--normal-border);color:var(--normal-text);border-radius:var(--border-radius);box-shadow:0 4px 12px rgba(0,0,0,.1);width:var(--width);font-size:13px;display:flex;align-items:center;gap:6px}[data-sonner-toast]:focus-visible{box-shadow:0 4px 12px rgba(0,0,0,.1),0 0 0 2px rgba(0,0,0,.2)}[data-sonner-toast][data-y-position=top]{top:0;--y:translateY(-100%);--lift:1;--lift-amount:calc(1 * var(--gap))}[data-sonner-toast][data-y-position=bottom]{bottom:0;--y:translateY(100%);--lift:-1;--lift-amount:calc(var(--lift) * var(--gap))}[data-sonner-toast][data-styled=true] [data-description]{font-weight:400;line-height:1.4;color:#3f3f3f}[data-rich-colors=true][data-sonner-toast][data-styled=true] [data-description]{color:inherit}[data-sonner-toaster][data-sonner-theme=dark] [data-description]{color:#e8e8e8}[data-sonner-toast][data-styled=true] [data-title]{font-weight:500;line-height:1.5;color:inherit}[data-sonner-toast][data-styled=true] [data-icon]{display:flex;height:16px;width:16px;position:relative;justify-content:flex-start;align-items:center;flex-shrink:0;margin-left:var(--toast-icon-margin-start);margin-right:var(--toast-icon-margin-end)}[data-sonner-toast][data-promise=true] [data-icon]>svg{opacity:0;transform:scale(.8);transform-origin:center;animation:sonner-fade-in .3s ease forwards}[data-sonner-toast][data-styled=true] [data-icon]>*{flex-shrink:0}[data-sonner-toast][data-styled=true] [data-icon] svg{margin-left:var(--toast-svg-margin-start);margin-right:var(--toast-svg-margin-end)}[data-sonner-toast][data-styled=true] [data-content]{display:flex;flex-direction:column;gap:2px}[data-sonner-toast][data-styled=true] [data-button]{border-radius:4px;padding-left:8px;padding-right:8px;height:24px;font-size:12px;color:var(--normal-bg);background:var(--normal-text);margin-left:var(--toast-button-margin-start);margin-right:var(--toast-button-margin-end);border:none;font-weight:500;cursor:pointer;outline:0;display:flex;align-items:center;flex-shrink:0;transition:opacity .4s,box-shadow .2s}[data-sonner-toast][data-styled=true] [data-button]:focus-visible{box-shadow:0 0 0 2px rgba(0,0,0,.4)}[data-sonner-toast][data-styled=true] [data-button]:first-of-type{margin-left:var(--toast-button-margin-start);margin-right:var(--toast-button-margin-end)}[data-sonner-toast][data-styled=true] [data-cancel]{color:var(--normal-text);background:rgba(0,0,0,.08)}[data-sonner-toaster][data-sonner-theme=dark] [data-sonner-toast][data-styled=true] [data-cancel]{background:rgba(255,255,255,.3)}[data-sonner-toast][data-styled=true] [data-close-button]{position:absolute;left:var(--toast-close-button-start);right:var(--toast-close-button-end);top:0;height:20px;width:20px;display:flex;justify-content:center;align-items:center;padding:0;color:var(--gray12);background:var(--normal-bg);border:1px solid var(--gray4);transform:var(--toast-close-button-transform);border-radius:50%;cursor:pointer;z-index:1;transition:opacity .1s,background .2s,border-color .2s}[data-sonner-toast][data-styled=true] [data-close-button]:focus-visible{box-shadow:0 4px 12px rgba(0,0,0,.1),0 0 0 2px rgba(0,0,0,.2)}[data-sonner-toast][data-styled=true] [data-disabled=true]{cursor:not-allowed}[data-sonner-toast][data-styled=true]:hover [data-close-button]:hover{background:var(--gray2);border-color:var(--gray5)}[data-sonner-toast][data-swiping=true]::before{content:'';position:absolute;left:-100%;right:-100%;height:100%;z-index:-1}[data-sonner-toast][data-y-position=top][data-swiping=true]::before{bottom:50%;transform:scaleY(3) translateY(50%)}[data-sonner-toast][data-y-position=bottom][data-swiping=true]::before{top:50%;transform:scaleY(3) translateY(-50%)}[data-sonner-toast][data-swiping=false][data-removed=true]::before{content:'';position:absolute;inset:0;transform:scaleY(2)}[data-sonner-toast][data-expanded=true]::after{content:'';position:absolute;left:0;height:calc(var(--gap) + 1px);bottom:100%;width:100%}[data-sonner-toast][data-mounted=true]{--y:translateY(0);opacity:1}[data-sonner-toast][data-expanded=false][data-front=false]{--scale:var(--toasts-before) * 0.05 + 1;--y:translateY(calc(var(--lift-amount) * var(--toasts-before))) scale(calc(-1 * var(--scale)));height:var(--front-toast-height)}[data-sonner-toast]>*{transition:opacity .4s}[data-sonner-toast][data-x-position=right]{right:0}[data-sonner-toast][data-x-position=left]{left:0}[data-sonner-toast][data-expanded=false][data-front=false][data-styled=true]>*{opacity:0}[data-sonner-toast][data-visible=false]{opacity:0;pointer-events:none}[data-sonner-toast][data-mounted=true][data-expanded=true]{--y:translateY(calc(var(--lift) * var(--offset)));height:var(--initial-height)}[data-sonner-toast][data-removed=true][data-front=true][data-swipe-out=false]{--y:translateY(calc(var(--lift) * -100%));opacity:0}[data-sonner-toast][data-removed=true][data-front=false][data-swipe-out=false][data-expanded=true]{--y:translateY(calc(var(--lift) * var(--offset) + var(--lift) * -100%));opacity:0}[data-sonner-toast][data-removed=true][data-front=false][data-swipe-out=false][data-expanded=false]{--y:translateY(40%);opacity:0;transition:transform .5s,opacity .2s}[data-sonner-toast][data-removed=true][data-front=false]::before{height:calc(var(--initial-height) + 20%)}[data-sonner-toast][data-swiping=true]{transform:var(--y) translateY(var(--swipe-amount-y,0)) translateX(var(--swipe-amount-x,0));transition:none}[data-sonner-toast][data-swiped=true]{user-select:none}[data-sonner-toast][data-swipe-out=true][data-y-position=bottom],[data-sonner-toast][data-swipe-out=true][data-y-position=top]{animation-duration:.2s;animation-timing-function:ease-out;animation-fill-mode:forwards}[data-sonner-toast][data-swipe-out=true][data-swipe-direction=left]{animation-name:swipe-out-left}[data-sonner-toast][data-swipe-out=true][data-swipe-direction=right]{animation-name:swipe-out-right}[data-sonner-toast][data-swipe-out=true][data-swipe-direction=up]{animation-name:swipe-out-up}[data-sonner-toast][data-swipe-out=true][data-swipe-direction=down]{animation-name:swipe-out-down}@keyframes swipe-out-left{from{transform:var(--y) translateX(var(--swipe-amount-x));opacity:1}to{transform:var(--y) translateX(calc(var(--swipe-amount-x) - 100%));opacity:0}}@keyframes swipe-out-right{from{transform:var(--y) translateX(var(--swipe-amount-x));opacity:1}to{transform:var(--y) translateX(calc(var(--swipe-amount-x) + 100%));opacity:0}}@keyframes swipe-out-up{from{transform:var(--y) translateY(var(--swipe-amount-y));opacity:1}to{transform:var(--y) translateY(calc(var(--swipe-amount-y) - 100%));opacity:0}}@keyframes swipe-out-down{from{transform:var(--y) translateY(var(--swipe-amount-y));opacity:1}to{transform:var(--y) translateY(calc(var(--swipe-amount-y) + 100%));opacity:0}}@media (max-width:600px){[data-sonner-toaster]{position:fixed;right:var(--mobile-offset-right);left:var(--mobile-offset-left);width:100%}[data-sonner-toaster][dir=rtl]{left:calc(var(--mobile-offset-left) * -1)}[data-sonner-toaster] [data-sonner-toast]{left:0;right:0;width:calc(100% - var(--mobile-offset-left) * 2)}[data-sonner-toaster][data-x-position=left]{left:var(--mobile-offset-left)}[data-sonner-toaster][data-y-position=bottom]{bottom:var(--mobile-offset-bottom)}[data-sonner-toaster][data-y-position=top]{top:var(--mobile-offset-top)}[data-sonner-toaster][data-x-position=center]{left:var(--mobile-offset-left);right:var(--mobile-offset-right);transform:none}}[data-sonner-toaster][data-sonner-theme=light]{--normal-bg:#fff;--normal-border:var(--gray4);--normal-text:var(--gray12);--success-bg:hsl(143, 85%, 96%);--success-border:hsl(145, 92%, 87%);--success-text:hsl(140, 100%, 27%);--info-bg:hsl(208, 100%, 97%);--info-border:hsl(221, 91%, 93%);--info-text:hsl(210, 92%, 45%);--warning-bg:hsl(49, 100%, 97%);--warning-border:hsl(49, 91%, 84%);--warning-text:hsl(31, 92%, 45%);--error-bg:hsl(359, 100%, 97%);--error-border:hsl(359, 100%, 94%);--error-text:hsl(360, 100%, 45%)}[data-sonner-toaster][data-sonner-theme=light] [data-sonner-toast][data-invert=true]{--normal-bg:#000;--normal-border:hsl(0, 0%, 20%);--normal-text:var(--gray1)}[data-sonner-toaster][data-sonner-theme=dark] [data-sonner-toast][data-invert=true]{--normal-bg:#fff;--normal-border:var(--gray3);--normal-text:var(--gray12)}[data-sonner-toaster][data-sonner-theme=dark]{--normal-bg:#000;--normal-bg-hover:hsl(0, 0%, 12%);--normal-border:hsl(0, 0%, 20%);--normal-border-hover:hsl(0, 0%, 25%);--normal-text:var(--gray1);--success-bg:hsl(150, 100%, 6%);--success-border:hsl(147, 100%, 12%);--success-text:hsl(150, 86%, 65%);--info-bg:hsl(215, 100%, 6%);--info-border:hsl(223, 43%, 17%);--info-text:hsl(216, 87%, 65%);--warning-bg:hsl(64, 100%, 6%);--warning-border:hsl(60, 100%, 9%);--warning-text:hsl(46, 87%, 65%);--error-bg:hsl(358, 76%, 10%);--error-border:hsl(357, 89%, 16%);--error-text:hsl(358, 100%, 81%)}[data-sonner-toaster][data-sonner-theme=dark] [data-sonner-toast] [data-close-button]{background:var(--normal-bg);border-color:var(--normal-border);color:var(--normal-text)}[data-sonner-toaster][data-sonner-theme=dark] [data-sonner-toast] [data-close-button]:hover{background:var(--normal-bg-hover);border-color:var(--normal-border-hover)}[data-rich-colors=true][data-sonner-toast][data-type=success]{background:var(--success-bg);border-color:var(--success-border);color:var(--success-text)}[data-rich-colors=true][data-sonner-toast][data-type=success] [data-close-button]{background:var(--success-bg);border-color:var(--success-border);color:var(--success-text)}[data-rich-colors=true][data-sonner-toast][data-type=info]{background:var(--info-bg);border-color:var(--info-border);color:var(--info-text)}[data-rich-colors=true][data-sonner-toast][data-type=info] [data-close-button]{background:var(--info-bg);border-color:var(--info-border);color:var(--info-text)}[data-rich-colors=true][data-sonner-toast][data-type=warning]{background:var(--warning-bg);border-color:var(--warning-border);color:var(--warning-text)}[data-rich-colors=true][data-sonner-toast][data-type=warning] [data-close-button]{background:var(--warning-bg);border-color:var(--warning-border);color:var(--warning-text)}[data-rich-colors=true][data-sonner-toast][data-type=error]{background:var(--error-bg);border-color:var(--error-border);color:var(--error-text)}[data-rich-colors=true][data-sonner-toast][data-type=error] [data-close-button]{background:var(--error-bg);border-color:var(--error-border);color:var(--error-text)}.sonner-loading-wrapper{--size:16px;height:var(--size);width:var(--size);position:absolute;inset:0;z-index:10}.sonner-loading-wrapper[data-visible=false]{transform-origin:center;animation:sonner-fade-out .2s ease forwards}.sonner-spinner{position:relative;top:50%;left:50%;height:var(--size);width:var(--size)}.sonner-loading-bar{animation:sonner-spin 1.2s linear infinite;background:var(--gray11);border-radius:6px;height:8%;left:-10%;position:absolute;top:-3.9%;width:24%}.sonner-loading-bar:first-child{animation-delay:-1.2s;transform:rotate(.0001deg) translate(146%)}.sonner-loading-bar:nth-child(2){animation-delay:-1.1s;transform:rotate(30deg) translate(146%)}.sonner-loading-bar:nth-child(3){animation-delay:-1s;transform:rotate(60deg) translate(146%)}.sonner-loading-bar:nth-child(4){animation-delay:-.9s;transform:rotate(90deg) translate(146%)}.sonner-loading-bar:nth-child(5){animation-delay:-.8s;transform:rotate(120deg) translate(146%)}.sonner-loading-bar:nth-child(6){animation-delay:-.7s;transform:rotate(150deg) translate(146%)}.sonner-loading-bar:nth-child(7){animation-delay:-.6s;transform:rotate(180deg) translate(146%)}.sonner-loading-bar:nth-child(8){animation-delay:-.5s;transform:rotate(210deg) translate(146%)}.sonner-loading-bar:nth-child(9){animation-delay:-.4s;transform:rotate(240deg) translate(146%)}.sonner-loading-bar:nth-child(10){animation-delay:-.3s;transform:rotate(270deg) translate(146%)}.sonner-loading-bar:nth-child(11){animation-delay:-.2s;transform:rotate(300deg) translate(146%)}.sonner-loading-bar:nth-child(12){animation-delay:-.1s;transform:rotate(330deg) translate(146%)}@keyframes sonner-fade-in{0%{opacity:0;transform:scale(.8)}100%{opacity:1;transform:scale(1)}}@keyframes sonner-fade-out{0%{opacity:1;transform:scale(1)}100%{opacity:0;transform:scale(.8)}}@keyframes sonner-spin{0%{opacity:1}100%{opacity:.15}}@media (prefers-reduced-motion){.sonner-loading-bar,[data-sonner-toast],[data-sonner-toast]>*{transition:none!important;animation:none!important}}.sonner-loader{position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);transform-origin:center;transition:opacity .2s,transform .2s}.sonner-loader[data-visible=false]{opacity:0;transform:scale(.8) translate(-50%,-50%)}");let y=e=>{var o,r,u,p,d,h,y,w,g,b,v,x,k;let{invert:C,toast:W,unstyled:I,interacting:O,setHeights:E,visibleToasts:R,heights:S,index:T,toasts:_,expanded:N,removeToast:B,defaultRichColors:q,closeButton:A,style:M,cancelButtonStyle:P,actionButtonStyle:j,className:L="",descriptionClassName:Q="",duration:D,position:Y,gap:z,expandByDefault:K,classNames:V,icons:$,closeButtonAriaLabel:F="Close toast"}=e,[H,U]=t.default.useState(null),[G,X]=t.default.useState(null),[Z,J]=t.default.useState(!1),[ee,et]=t.default.useState(!1),[eo,er]=t.default.useState(!1),[ea,en]=t.default.useState(!1),[es,ei]=t.default.useState(!1),[el,ec]=t.default.useState(0),[eu,ep]=t.default.useState(0),ed=t.default.useRef(W.duration||D||4e3),eh=t.default.useRef(null),ef=t.default.useRef(null),em=0===T,ey=T+1<=R,ew=W.type,eg=!1!==W.dismissible,eb=W.className||"",ev=W.descriptionClassName||"",ex=t.default.useMemo(()=>S.findIndex(e=>e.toastId===W.id)||0,[S,W.id]),ek=t.default.useMemo(()=>{var e;return null!=(e=W.closeButton)?e:A},[W.closeButton,A]),eC=t.default.useMemo(()=>W.duration||D||4e3,[W.duration,D]),eW=t.default.useRef(0),eI=t.default.useRef(0),eO=t.default.useRef(0),eE=t.default.useRef(null),[eR,eS]=Y.split("-"),eT=t.default.useMemo(()=>S.reduce((e,t,o)=>o>=ex?e:e+t.height,0),[S,ex]),e_=(()=>{let[e,o]=t.default.useState(document.hidden);return t.default.useEffect(()=>{let e=()=>{o(document.hidden)};return document.addEventListener("visibilitychange",e),()=>window.removeEventListener("visibilitychange",e)},[]),e})(),eN=W.invert||C,eB="loading"===ew;eI.current=t.default.useMemo(()=>ex*z+eT,[ex,eT]),t.default.useEffect(()=>{ed.current=eC},[eC]),t.default.useEffect(()=>{J(!0)},[]),t.default.useEffect(()=>{let e=ef.current;if(e){let t=e.getBoundingClientRect().height;return ep(t),E(e=>[{toastId:W.id,height:t,position:W.position},...e]),()=>E(e=>e.filter(e=>e.toastId!==W.id))}},[E,W.id]),t.default.useLayoutEffect(()=>{if(!Z)return;let e=ef.current,t=e.style.height;e.style.height="auto";let o=e.getBoundingClientRect().height;e.style.height=t,ep(o),E(e=>e.find(e=>e.toastId===W.id)?e.map(e=>e.toastId===W.id?{...e,height:o}:e):[{toastId:W.id,height:o,position:W.position},...e])},[Z,W.title,W.description,E,W.id,W.jsx,W.action,W.cancel]);let eq=t.default.useCallback(()=>{et(!0),ec(eI.current),E(e=>e.filter(e=>e.toastId!==W.id)),setTimeout(()=>{B(W)},200)},[W,B,E,eI]);t.default.useEffect(()=>{let e;if((!W.promise||"loading"!==ew)&&W.duration!==1/0&&"loading"!==W.type){if(N||O||e_){if(eO.current<eW.current){let e=new Date().getTime()-eW.current;ed.current=ed.current-e}eO.current=new Date().getTime()}else ed.current!==1/0&&(eW.current=new Date().getTime(),e=setTimeout(()=>{null==W.onAutoClose||W.onAutoClose.call(W,W),eq()},ed.current));return()=>clearTimeout(e)}},[N,O,W,ew,e_,eq]),t.default.useEffect(()=>{W.delete&&(eq(),null==W.onDismiss||W.onDismiss.call(W,W))},[eq,W.delete]);let eA=W.icon||(null==$?void 0:$[ew])||(e=>{switch(e){case"success":return n;case"info":return i;case"warning":return s;case"error":return l;default:return null}})(ew);return t.default.createElement("li",{tabIndex:0,ref:ef,className:m(L,eb,null==V?void 0:V.toast,null==W||null==(o=W.classNames)?void 0:o.toast,null==V?void 0:V.default,null==V?void 0:V[ew],null==W||null==(r=W.classNames)?void 0:r[ew]),"data-sonner-toast":"","data-rich-colors":null!=(b=W.richColors)?b:q,"data-styled":!(W.jsx||W.unstyled||I),"data-mounted":Z,"data-promise":!!W.promise,"data-swiped":es,"data-removed":ee,"data-visible":ey,"data-y-position":eR,"data-x-position":eS,"data-index":T,"data-front":em,"data-swiping":eo,"data-dismissible":eg,"data-type":ew,"data-invert":eN,"data-swipe-out":ea,"data-swipe-direction":G,"data-expanded":!!(N||K&&Z),"data-testid":W.testId,style:{"--index":T,"--toasts-before":T,"--z-index":_.length-T,"--offset":`${ee?el:eI.current}px`,"--initial-height":K?"auto":`${eu}px`,...M,...W.style},onDragEnd:()=>{er(!1),U(null),eE.current=null},onPointerDown:e=>{2===e.button||eB||!eg||(eh.current=new Date,ec(eI.current),e.target.setPointerCapture(e.pointerId),"BUTTON"!==e.target.tagName&&(er(!0),eE.current={x:e.clientX,y:e.clientY}))},onPointerUp:()=>{var e,t,o,r,a;if(ea||!eg)return;eE.current=null;let n=Number((null==(e=ef.current)?void 0:e.style.getPropertyValue("--swipe-amount-x").replace("px",""))||0),s=Number((null==(t=ef.current)?void 0:t.style.getPropertyValue("--swipe-amount-y").replace("px",""))||0),i=new Date().getTime()-(null==(o=eh.current)?void 0:o.getTime()),l="x"===H?n:s,c=Math.abs(l)/i;if(Math.abs(l)>=45||c>.11){ec(eI.current),null==W.onDismiss||W.onDismiss.call(W,W),"x"===H?X(n>0?"right":"left"):X(s>0?"down":"up"),eq(),en(!0);return}null==(r=ef.current)||r.style.setProperty("--swipe-amount-x","0px"),null==(a=ef.current)||a.style.setProperty("--swipe-amount-y","0px"),ei(!1),er(!1),U(null)},onPointerMove:t=>{var o,r,a,n;if(!eE.current||!eg||(null==(o=window.getSelection())?void 0:o.toString().length)>0)return;let s=t.clientY-eE.current.y,i=t.clientX-eE.current.x,l=null!=(n=e.swipeDirections)?n:function(e){let[t,o]=e.split("-"),r=[];return t&&r.push(t),o&&r.push(o),r}(Y);!H&&(Math.abs(i)>1||Math.abs(s)>1)&&U(Math.abs(i)>Math.abs(s)?"x":"y");let c={x:0,y:0},u=e=>1/(1.5+Math.abs(e)/20);if("y"===H){if(l.includes("top")||l.includes("bottom"))if(l.includes("top")&&s<0||l.includes("bottom")&&s>0)c.y=s;else{let e=s*u(s);c.y=Math.abs(e)<Math.abs(s)?e:s}}else if("x"===H&&(l.includes("left")||l.includes("right")))if(l.includes("left")&&i<0||l.includes("right")&&i>0)c.x=i;else{let e=i*u(i);c.x=Math.abs(e)<Math.abs(i)?e:i}(Math.abs(c.x)>0||Math.abs(c.y)>0)&&ei(!0),null==(r=ef.current)||r.style.setProperty("--swipe-amount-x",`${c.x}px`),null==(a=ef.current)||a.style.setProperty("--swipe-amount-y",`${c.y}px`)}},ek&&!W.jsx&&"loading"!==ew?t.default.createElement("button",{"aria-label":F,"data-disabled":eB,"data-close-button":!0,onClick:eB||!eg?()=>{}:()=>{eq(),null==W.onDismiss||W.onDismiss.call(W,W)},className:m(null==V?void 0:V.closeButton,null==W||null==(u=W.classNames)?void 0:u.closeButton)},null!=(v=null==$?void 0:$.close)?v:c):null,(ew||W.icon||W.promise)&&null!==W.icon&&((null==$?void 0:$[ew])!==null||W.icon)?t.default.createElement("div",{"data-icon":"",className:m(null==V?void 0:V.icon,null==W||null==(p=W.classNames)?void 0:p.icon)},W.promise||"loading"===W.type&&!W.icon?W.icon||((null==$?void 0:$.loading)?t.default.createElement("div",{className:m(null==V?void 0:V.loader,null==W||null==(k=W.classNames)?void 0:k.loader,"sonner-loader"),"data-visible":"loading"===ew},$.loading):t.default.createElement(a,{className:m(null==V?void 0:V.loader,null==W||null==(x=W.classNames)?void 0:x.loader),visible:"loading"===ew})):null,"loading"!==W.type?eA:null):null,t.default.createElement("div",{"data-content":"",className:m(null==V?void 0:V.content,null==W||null==(d=W.classNames)?void 0:d.content)},t.default.createElement("div",{"data-title":"",className:m(null==V?void 0:V.title,null==W||null==(h=W.classNames)?void 0:h.title)},W.jsx?W.jsx:"function"==typeof W.title?W.title():W.title),W.description?t.default.createElement("div",{"data-description":"",className:m(Q,ev,null==V?void 0:V.description,null==W||null==(y=W.classNames)?void 0:y.description)},"function"==typeof W.description?W.description():W.description):null),t.default.isValidElement(W.cancel)?W.cancel:W.cancel&&f(W.cancel)?t.default.createElement("button",{"data-button":!0,"data-cancel":!0,style:W.cancelButtonStyle||P,onClick:e=>{!f(W.cancel)||eg&&(null==W.cancel.onClick||W.cancel.onClick.call(W.cancel,e),eq())},className:m(null==V?void 0:V.cancelButton,null==W||null==(w=W.classNames)?void 0:w.cancelButton)},W.cancel.label):null,t.default.isValidElement(W.action)?W.action:W.action&&f(W.action)?t.default.createElement("button",{"data-button":!0,"data-action":!0,style:W.actionButtonStyle||j,onClick:e=>{!f(W.action)||(null==W.action.onClick||W.action.onClick.call(W.action,e),e.defaultPrevented||eq())},className:m(null==V?void 0:V.actionButton,null==W||null==(g=W.classNames)?void 0:g.actionButton)},W.action.label):null)};function w(){if("u"<typeof window||"u"<typeof document)return"ltr";let e=document.documentElement.getAttribute("dir");return"auto"!==e&&e?e:window.getComputedStyle(document.documentElement).direction}let g=t.default.forwardRef(function(e,r){let{id:a,invert:n,position:s="bottom-right",hotkey:i=["altKey","KeyT"],expand:l,closeButton:c,className:u,offset:d,mobileOffset:h,theme:f="light",richColors:m,duration:g,style:b,visibleToasts:v=3,toastOptions:x,dir:k=w(),gap:C=14,icons:W,containerAriaLabel:I="Notifications"}=e,[O,E]=t.default.useState([]),R=t.default.useMemo(()=>a?O.filter(e=>e.toasterId===a):O.filter(e=>!e.toasterId),[O,a]),S=t.default.useMemo(()=>Array.from(new Set([s].concat(R.filter(e=>e.position).map(e=>e.position)))),[R,s]),[T,_]=t.default.useState([]),[N,B]=t.default.useState(!1),[q,A]=t.default.useState(!1),[M,P]=t.default.useState("system"!==f?f:"u">typeof window&&window.matchMedia&&window.matchMedia("(prefers-color-scheme: dark)").matches?"dark":"light"),j=t.default.useRef(null),L=i.join("+").replace(/Key/g,"").replace(/Digit/g,""),Q=t.default.useRef(null),D=t.default.useRef(!1),Y=t.default.useCallback(e=>{E(t=>{var o;return(null==(o=t.find(t=>t.id===e.id))?void 0:o.delete)||p.dismiss(e.id),t.filter(({id:t})=>t!==e.id)})},[]);return t.default.useEffect(()=>p.subscribe(e=>{e.dismiss?requestAnimationFrame(()=>{E(t=>t.map(t=>t.id===e.id?{...t,delete:!0}:t))}):setTimeout(()=>{o.default.flushSync(()=>{E(t=>{let o=t.findIndex(t=>t.id===e.id);return -1!==o?[...t.slice(0,o),{...t[o],...e},...t.slice(o+1)]:[e,...t]})})})}),[O]),t.default.useEffect(()=>{if("system"!==f)return void P(f);if("system"===f&&(window.matchMedia&&window.matchMedia("(prefers-color-scheme: dark)").matches?P("dark"):P("light")),"u"<typeof window)return;let e=window.matchMedia("(prefers-color-scheme: dark)");try{e.addEventListener("change",({matches:e})=>{e?P("dark"):P("light")})}catch(t){e.addListener(({matches:e})=>{try{e?P("dark"):P("light")}catch(e){console.error(e)}})}},[f]),t.default.useEffect(()=>{O.length<=1&&B(!1)},[O]),t.default.useEffect(()=>{let e=e=>{var t,o;i.every(t=>e[t]||e.code===t)&&(B(!0),null==(o=j.current)||o.focus()),"Escape"===e.code&&(document.activeElement===j.current||(null==(t=j.current)?void 0:t.contains(document.activeElement)))&&B(!1)};return document.addEventListener("keydown",e),()=>document.removeEventListener("keydown",e)},[i]),t.default.useEffect(()=>{if(j.current)return()=>{Q.current&&(Q.current.focus({preventScroll:!0}),Q.current=null,D.current=!1)}},[j.current]),t.default.createElement("section",{ref:r,"aria-label":`${I} ${L}`,tabIndex:-1,"aria-live":"polite","aria-relevant":"additions text","aria-atomic":"false",suppressHydrationWarning:!0},S.map((o,r)=>{var a;let s,[i,p]=o.split("-");return R.length?t.default.createElement("ol",{key:o,dir:"auto"===k?w():k,tabIndex:-1,ref:j,className:u,"data-sonner-toaster":!0,"data-sonner-theme":M,"data-y-position":i,"data-x-position":p,style:{"--front-toast-height":`${(null==(a=T[0])?void 0:a.height)||0}px`,"--width":"356px","--gap":`${C}px`,...b,...(s={},[d,h].forEach((e,t)=>{let o=1===t,r=o?"--mobile-offset":"--offset",a=o?"16px":"24px";function n(e){["top","right","bottom","left"].forEach(t=>{s[`${r}-${t}`]="number"==typeof e?`${e}px`:e})}"number"==typeof e||"string"==typeof e?n(e):"object"==typeof e?["top","right","bottom","left"].forEach(t=>{void 0===e[t]?s[`${r}-${t}`]=a:s[`${r}-${t}`]="number"==typeof e[t]?`${e[t]}px`:e[t]}):n(a)}),s)},onBlur:e=>{D.current&&!e.currentTarget.contains(e.relatedTarget)&&(D.current=!1,Q.current&&(Q.current.focus({preventScroll:!0}),Q.current=null))},onFocus:e=>{!(e.target instanceof HTMLElement&&"false"===e.target.dataset.dismissible)&&(D.current||(D.current=!0,Q.current=e.relatedTarget))},onMouseEnter:()=>B(!0),onMouseMove:()=>B(!0),onMouseLeave:()=>{q||B(!1)},onDragEnd:()=>B(!1),onPointerDown:e=>{e.target instanceof HTMLElement&&"false"===e.target.dataset.dismissible||A(!0)},onPointerUp:()=>A(!1)},R.filter(e=>!e.position&&0===r||e.position===o).map((r,a)=>{var s,i;return t.default.createElement(y,{key:r.id,icons:W,index:a,toast:r,defaultRichColors:m,duration:null!=(s=null==x?void 0:x.duration)?s:g,className:null==x?void 0:x.className,descriptionClassName:null==x?void 0:x.descriptionClassName,invert:n,visibleToasts:v,closeButton:null!=(i=null==x?void 0:x.closeButton)?i:c,interacting:q,position:o,style:null==x?void 0:x.style,unstyled:null==x?void 0:x.unstyled,classNames:null==x?void 0:x.classNames,cancelButtonStyle:null==x?void 0:x.cancelButtonStyle,actionButtonStyle:null==x?void 0:x.actionButtonStyle,closeButtonAriaLabel:null==x?void 0:x.closeButtonAriaLabel,removeToast:Y,toasts:R.filter(e=>e.position==r.position),heights:T.filter(e=>e.position==r.position),setHeights:_,expandByDefault:l,gap:C,expanded:N,swipeDirections:e.swipeDirections})})):null}))});e.s(["Toaster",0,g,"toast",0,h])},914146,e=>{"use strict";e.s(["ethAddress",0,"0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee","zeroAddress",0,"0x0000000000000000000000000000000000000000"])},982615,e=>{"use strict";var t=e.i(828646),o=e.i(909744),r=e.i(210920),a=e.i(365087),n=e.i(271645),s=e.i(451797);let i=e=>"object"==typeof e&&!Array.isArray(e);e.s(["useAccount",0,function(e={}){let l=(0,r.useConfig)(e);return function(e,t,o=t,r=a.deepEqual){let l=(0,n.useRef)([]),c=(0,s.useSyncExternalStoreWithSelector)(e,t,o,e=>e,(e,t)=>{if(i(e)&&i(t)&&l.current.length){for(let o of l.current)if(!r(e[o],t[o]))return!1;return!0}return r(e,t)});return(0,n.useMemo)(()=>{if(i(c)){let e={...c},t={};for(let[o,r]of Object.entries(e))t={...t,[o]:{configurable:!1,enumerable:!0,get:()=>(l.current.includes(o)||l.current.push(o),r)}};return Object.defineProperties(e,t),e}return c},[c])}(e=>(0,o.watchAccount)(l,{onChange:e}),()=>(0,t.getAccount)(l))}],982615)},210920,574983,296247,191346,e=>{"use strict";var t,o,r=e.i(271645);let a=!1;async function n(e,t={}){let o;if(a)return[];a=!0,e.setState(e=>({...e,status:e.current?"reconnecting":"connecting"}));let r=[];if(t.connectors?.length)for(let o of t.connectors){let t;t="function"==typeof o?e._internal.connectors.setup(o):o,r.push(t)}else r.push(...e.connectors);try{o=await e.storage?.getItem("recentConnectorId")}catch{}let s={};for(let[,t]of e.state.connections)s[t.connector.id]=1;o&&(s[o]=0);let i=Object.keys(s).length>0?[...r].sort((e,t)=>(s[e.id]??10)-(s[t.id]??10)):r,l=!1,c=[],u=[];for(let t of i){let o=await t.getProvider().catch(()=>void 0);if(!o||u.some(e=>e===o)||!await t.isAuthorized())continue;let r=await t.connect({isReconnecting:!0}).catch(()=>null);r&&(t.emitter.off("connect",e._internal.events.connect),t.emitter.on("change",e._internal.events.change),t.emitter.on("disconnect",e._internal.events.disconnect),e.setState(e=>{let o=new Map(l?e.connections:new Map).set(t.uid,{accounts:r.accounts,chainId:r.chainId,connector:t});return{...e,current:l?e.current:t.uid,connections:o}}),c.push({accounts:r.accounts,chainId:r.chainId,connector:t}),u.push(o),l=!0)}return("reconnecting"===e.state.status||"connecting"===e.state.status)&&(l?e.setState(e=>({...e,status:"connected"})):e.setState(e=>({...e,connections:new Map,current:null,status:"disconnected"}))),a=!1,c}function s(e){let{children:t,config:o,initialState:a,reconnectOnMount:s=!0}=e,{onMount:i}=function(e,t){let{initialState:o,reconnectOnMount:r}=t;return o&&!e._internal.store.persist.hasHydrated()&&e.setState({...o,chainId:e.chains.some(e=>e.id===o.chainId)?o.chainId:e.chains[0].id,connections:r?o.connections:new Map,status:r?"reconnecting":"disconnected"}),{async onMount(){e._internal.ssr&&(await e._internal.store.persist.rehydrate(),e._internal.mipd&&e._internal.connectors.setState(t=>{let o=new Set;for(let e of t??[])if(e.rdns)for(let t of Array.isArray(e.rdns)?e.rdns:[e.rdns])o.add(t);let r=[];for(let t of e._internal.mipd?.getProviders()??[]){if(o.has(t.info.rdns))continue;let a=e._internal.connectors.providerDetailToConnector(t),n=e._internal.connectors.setup(a);r.push(n)}return[...t,...r]})),r?n(e):e.storage&&e.setState(e=>({...e,connections:new Map}))}}}(o,{initialState:a,reconnectOnMount:s});o._internal.ssr||i();let l=(0,r.useRef)(!0);return(0,r.useEffect)(()=>{if(l.current&&o._internal.ssr)return i(),()=>{l.current=!1}},[]),t}let i=(0,r.createContext)(void 0);e.s(["WagmiContext",0,i,"WagmiProvider",0,function(e){let{children:t,config:o}=e;return(0,r.createElement)(s,e,(0,r.createElement)(i.Provider,{value:o},t))}],574983);let l="2.22.1";e.s(["version",0,l],296247);var c=function(e,t,o,r){if("a"===o&&!r)throw TypeError("Private accessor was defined without a getter");if("function"==typeof t?e!==t||!r:!t.has(e))throw TypeError("Cannot read private member from an object whose class did not declare it");return"m"===o?r:"a"===o?r.call(e):r?r.value:t.get(e)};class u extends Error{get docsBaseUrl(){return"https://wagmi.sh/core"}get version(){return`@wagmi/core@${l}`}constructor(e,o={}){super(),t.add(this),Object.defineProperty(this,"details",{enumerable:!0,configurable:!0,writable:!0,value:void 0}),Object.defineProperty(this,"docsPath",{enumerable:!0,configurable:!0,writable:!0,value:void 0}),Object.defineProperty(this,"metaMessages",{enumerable:!0,configurable:!0,writable:!0,value:void 0}),Object.defineProperty(this,"shortMessage",{enumerable:!0,configurable:!0,writable:!0,value:void 0}),Object.defineProperty(this,"name",{enumerable:!0,configurable:!0,writable:!0,value:"WagmiCoreError"});const r=o.cause instanceof u?o.cause.details:o.cause?.message?o.cause.message:o.details,a=o.cause instanceof u&&o.cause.docsPath||o.docsPath;this.message=[e||"An error occurred.","",...o.metaMessages?[...o.metaMessages,""]:[],...a?[`Docs: ${this.docsBaseUrl}${a}.html${o.docsSlug?`#${o.docsSlug}`:""}`]:[],...r?[`Details: ${r}`]:[],`Version: ${this.version}`].join("\n"),o.cause&&(this.cause=o.cause),this.details=r,this.docsPath=a,this.metaMessages=o.metaMessages,this.shortMessage=e}walk(e){return c(this,t,"m",o).call(this,this,e)}}t=new WeakSet,o=function e(o,r){return r?.(o)?o:o.cause?c(this,t,"m",e).call(this,o.cause,r):o},e.s(["BaseError",0,u],191346);class p extends u{constructor(){super(...arguments),Object.defineProperty(this,"name",{enumerable:!0,configurable:!0,writable:!0,value:"WagmiError"})}get docsBaseUrl(){return"https://wagmi.sh/react"}get version(){return"wagmi@2.19.5"}}class d extends p{constructor(){super("`useConfig` must be used within `WagmiProvider`.",{docsPath:"/api/WagmiProvider"}),Object.defineProperty(this,"name",{enumerable:!0,configurable:!0,writable:!0,value:"WagmiProviderNotFoundError"})}}e.s(["useConfig",0,function(e={}){let t=e.config??(0,r.useContext)(i);if(!t)throw new d;return t}],210920)},377379,(e,t,o)=>{"use strict";var r=e.r(271645),a="function"==typeof Object.is?Object.is:function(e,t){return e===t&&(0!==e||1/e==1/t)||e!=e&&t!=t},n=r.useState,s=r.useEffect,i=r.useLayoutEffect,l=r.useDebugValue;function c(e){var t=e.getSnapshot;e=e.value;try{var o=t();return!a(e,o)}catch(e){return!0}}var u="u"<typeof window||void 0===window.document||void 0===window.document.createElement?function(e,t){return t()}:function(e,t){var o=t(),r=n({inst:{value:o,getSnapshot:t}}),a=r[0].inst,u=r[1];return i(function(){a.value=o,a.getSnapshot=t,c(a)&&u({inst:a})},[e,o,t]),s(function(){return c(a)&&u({inst:a}),e(function(){c(a)&&u({inst:a})})},[e]),l(o),o};o.useSyncExternalStore=void 0!==r.useSyncExternalStore?r.useSyncExternalStore:u},193490,(e,t,o)=>{"use strict";e.i(247167),t.exports=e.r(377379)},731097,(e,t,o)=>{"use strict";var r=e.r(271645),a=e.r(193490),n="function"==typeof Object.is?Object.is:function(e,t){return e===t&&(0!==e||1/e==1/t)||e!=e&&t!=t},s=a.useSyncExternalStore,i=r.useRef,l=r.useEffect,c=r.useMemo,u=r.useDebugValue;o.useSyncExternalStoreWithSelector=function(e,t,o,r,a){var p=i(null);if(null===p.current){var d={hasValue:!1,value:null};p.current=d}else d=p.current;var h=s(e,(p=c(function(){function e(e){if(!l){if(l=!0,s=e,e=r(e),void 0!==a&&d.hasValue){var t=d.value;if(a(t,e))return i=t}return i=e}if(t=i,n(s,e))return t;var o=r(e);return void 0!==a&&a(t,o)?(s=e,t):(s=e,i=o)}var s,i,l=!1,c=void 0===o?null:o;return[function(){return e(t())},null===c?void 0:function(){return e(c())}]},[t,o,r,a]))[0],p[1]);return l(function(){d.hasValue=!0,d.value=h},[h]),u(h),h}},451797,(e,t,o)=>{"use strict";e.i(247167),t.exports=e.r(731097)}]);