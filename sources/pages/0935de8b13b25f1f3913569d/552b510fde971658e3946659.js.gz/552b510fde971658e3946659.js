self.__BUILD_MANIFEST = {
  "/": [
    "static/immutable/chunks/3mfk2cws7ijgv.js"
  ],
  "/_error": [
    "static/immutable/chunks/22h0a-av1h4q4.js"
  ],
  "/account-management/submissions": [
    "static/immutable/chunks/23byez-hild02.js"
  ],
  "/account-management/submissions/[id]": [
    "static/immutable/chunks/0sy829so5bbfx.js"
  ],
  "/account-management/submissions/[id]/print": [
    "static/immutable/chunks/3x66rn6ywyvl0.js"
  ],
  "/account-management/users": [
    "static/immutable/chunks/3z_hwq-qgu6tp.js"
  ],
  "/account-management/users/[id]": [
    "static/immutable/chunks/38yruj8o3n74j.js"
  ],
  "/account-recovery-success": [
    "static/immutable/chunks/359l53k4gtars.js"
  ],
  "/account-verification": [
    "static/immutable/chunks/1n94bg2dclcre.js"
  ],
  "/admin/control-panel": [
    "static/immutable/chunks/2kf5esq0qfwa5.js"
  ],
  "/admin/macros": [
    "static/immutable/chunks/241hwj5g_hkpl.js"
  ],
  "/admin/matchmaking": [
    "static/immutable/chunks/2r7f8qin9dr8-.js"
  ],
  "/admin/projects": [
    "static/immutable/chunks/24qte13t6gu-j.js"
  ],
  "/admin/projects/[id]": [
    "static/immutable/chunks/21exi3ko4mw0_.js"
  ],
  "/admin/submissions": [
    "static/immutable/chunks/1h56vkuavrxrs.js"
  ],
  "/admin/submissions/[id]": [
    "static/immutable/chunks/38ixpvbulj8b_.js"
  ],
  "/auth-action": [
    "static/immutable/chunks/31wkbt_zgp6a-.js"
  ],
  "/authenticate": [
    "static/immutable/chunks/0xw1y4hy4p3fc.js"
  ],
  "/credits": [
    "static/immutable/chunks/1xtu0ye1vqdya.js"
  ],
  "/dashboard": [
    "static/immutable/chunks/0tew70ggz7e14.js"
  ],
  "/dashboard/disclosures/[id]": [
    "static/immutable/chunks/2gl33__zm-ent.js"
  ],
  "/dashboard/new-submission": [
    "static/immutable/chunks/43e18h3uztulu.js"
  ],
  "/dashboard/new-submission/[id]": [
    "static/immutable/chunks/0ai3z9ipf5hnp.js"
  ],
  "/dashboard/new-submission/[id]/asset": [
    "static/immutable/chunks/3bfj7msg0lwj9.js"
  ],
  "/dashboard/new-submission/[id]/report": [
    "static/immutable/chunks/0ui_o9lycmzdk.js"
  ],
  "/dashboard/new-submission/[id]/review": [
    "static/immutable/chunks/1s-cm9hlzbnrd.js"
  ],
  "/dashboard/new-submission/[id]/severity": [
    "static/immutable/chunks/23_m05oek1kxc.js"
  ],
  "/dashboard/new-submission/[id]/wallet-address": [
    "static/immutable/chunks/2o9etl2hjcf_a.js"
  ],
  "/dashboard/new-submission/instant": [
    "static/immutable/chunks/1dt6oukd0maq9.js"
  ],
  "/dashboard/new-submission/safe-harbor/[projectSlug]": [
    "static/immutable/chunks/16jkewaybyq_v.js"
  ],
  "/dashboard/submission/[id]": [
    "static/immutable/chunks/1qrv-idbrc379.js"
  ],
  "/email-verification": [
    "static/immutable/chunks/36rgk9e_422nl.js"
  ],
  "/invitations/[hash]": [
    "static/immutable/chunks/02g8spqxltg9y.js"
  ],
  "/login/forgot-password": [
    "static/immutable/chunks/2ksdmr2xfngbe.js"
  ],
  "/mfa-setup": [
    "static/immutable/chunks/1r2k-s1_unvxb.js"
  ],
  "/password-reset": [
    "static/immutable/chunks/2uyx0sxp86bxv.js"
  ],
  "/program-reports": [
    "static/immutable/chunks/2tj4ib6iv44h1.js"
  ],
  "/recover-email": [
    "static/immutable/chunks/0v9ui3x3ivtpn.js"
  ],
  "/settings": [
    "static/immutable/chunks/2u6s1zdwmj8pu.js"
  ],
  "/settings/boost-payment": [
    "static/immutable/chunks/3s1xb0y3lurvw.js"
  ],
  "/settings/email-preferences": [
    "static/immutable/chunks/2xs248cvabwii.js"
  ],
  "/settings/organization": [
    "static/immutable/chunks/1mfhad55qx_ws.js"
  ],
  "/settings/payments": [
    "static/immutable/chunks/0vfninboqmu-_.js"
  ],
  "/settings/profile": [
    "static/immutable/chunks/1jni1myvi-r5q.js"
  ],
  "/settings/projects": [
    "static/immutable/chunks/3khe4-2der1tn.js"
  ],
  "/settings/projects/[id]/boost-payment": [
    "static/immutable/chunks/0927u0re88bzb.js"
  ],
  "/settings/projects/[id]/safe-harbor": [
    "static/immutable/chunks/13dxikjiob94_.js"
  ],
  "/settings/projects/[id]/vault/[vaultId]/activate": [
    "static/immutable/chunks/3i5lk0-norw3q.js"
  ],
  "/settings/projects/[id]/vault/new": [
    "static/immutable/chunks/426f81chm-oa_.js"
  ],
  "/settings/safe-harbor": [
    "static/immutable/chunks/2vyitqt9s35ml.js"
  ],
  "/settings/wallets": [
    "static/immutable/chunks/1jm0kv-rcdko1.js"
  ],
  "/signup": [
    "static/immutable/chunks/3w3fduyalsu5j.js"
  ],
  "/signup/verify-email": [
    "static/immutable/chunks/26x526vw8ff4c.js"
  ],
  "/vaults": [
    "static/immutable/chunks/1gp41aoww_61o.js"
  ],
  "__rewrites": {
    "afterFiles": [],
    "beforeFiles": [
      {
        "source": "/js/script.js"
      },
      {
        "source": "/api/event"
      },
      {
        "source": "/:path*.map",
        "destination": "/404"
      },
      {
        "source": "/mockServiceWorker.js",
        "destination": "/404"
      },
      {
        "has": [
          {
            "type": "header",
            "key": "next-url",
            "value": "/magnus/(?<nxtPorganizationId>[^/]+?)/projects/(?<nxtPorganizationProjectId>[^/]+?)/assets/radar(?:/.*)?"
          }
        ],
        "source": "/magnus/:nxtPorganizationId/projects/:nxtPorganizationProjectId/assets/radar/deployers/:nxtPid/edit",
        "destination": "/magnus/:nxtPorganizationId/projects/:nxtPorganizationProjectId/assets/radar/(.)deployers/:nxtPid/edit"
      },
      {
        "has": [
          {
            "type": "header",
            "key": "next-url",
            "value": "/magnus/(?<nxtPorganizationId>[^/]+?)/projects/(?<nxtPorganizationProjectId>[^/]+?)/assets/radar(?:/.*)?"
          }
        ],
        "source": "/magnus/:nxtPorganizationId/projects/:nxtPorganizationProjectId/assets/radar/deployers/new",
        "destination": "/magnus/:nxtPorganizationId/projects/:nxtPorganizationProjectId/assets/radar/(.)deployers/new"
      },
      {
        "has": [
          {
            "type": "header",
            "key": "next-url",
            "value": "/magnus/(?<nxtPorganizationId>[^/]+?)/projects/(?<nxtPorganizationProjectId>[^/]+?)/assets/radar(?:/.*)?"
          }
        ],
        "source": "/magnus/:nxtPorganizationId/projects/:nxtPorganizationProjectId/assets/radar/documents/new",
        "destination": "/magnus/:nxtPorganizationId/projects/:nxtPorganizationProjectId/assets/radar/(.)documents/new"
      }
    ],
    "fallback": []
  },
  "sortedPages": [
    "/",
    "/_app",
    "/_error",
    "/account-management/submissions",
    "/account-management/submissions/[id]",
    "/account-management/submissions/[id]/print",
    "/account-management/users",
    "/account-management/users/[id]",
    "/account-recovery-success",
    "/account-verification",
    "/admin/control-panel",
    "/admin/macros",
    "/admin/matchmaking",
    "/admin/projects",
    "/admin/projects/[id]",
    "/admin/submissions",
    "/admin/submissions/[id]",
    "/api/admin/account-management/reports",
    "/api/admin/account-management/reports/[id]/mass-unsubscribe",
    "/api/admin/account-management/users",
    "/api/admin/account-management/users/[id]",
    "/api/admin/account-management/users/[id]/disable",
    "/api/admin/audit-competitions/[id]/export",
    "/api/admin/firewall-owner-action-requests-status",
    "/api/admin/projects",
    "/api/admin/projects/matchmaking",
    "/api/admin/projects/matchmaking/invite",
    "/api/admin/projects/matchmaking/preview",
    "/api/admin/projects/[id]",
    "/api/admin/projects/[id]/set-fee-percent",
    "/api/admin/projects/[id]/users",
    "/api/admin/submissions/[id]/close",
    "/api/admin/submissions/[id]/self-subscribe",
    "/api/admin/submissions/[id]/subscribe",
    "/api/admin/users/block-from-organization",
    "/api/admin/users/is-blocked-in-organization",
    "/api/admin/users/search",
    "/api/admin/users/[id]/approve-request",
    "/api/admin/users/[id]/fingerprints",
    "/api/admin/users/[id]/roles",
    "/api/announcement-event/[id]",
    "/api/attachments/report/[...path]",
    "/api/attachments/report-content/[eventId]",
    "/api/auth/[...nextauth]",
    "/api/cms/safe-harbor-asset-update",
    "/api/cms/update-projects",
    "/api/contentful/update-projects",
    "/api/developer/createReportSubscription",
    "/api/developer/flags",
    "/api/developer/impersonateUser",
    "/api/developer/projects",
    "/api/developer/queues/calculateWhitehatLevel/enqueue",
    "/api/developer/reports/generateRandom",
    "/api/developer/reports/triage-readiness",
    "/api/developer/reports/[id]/autoTriage",
    "/api/developer/reports/[id]/tags",
    "/api/developer/user-testing/info",
    "/api/developer/userLookup",
    "/api/developer/users",
    "/api/developer/verifyFirebaseUser",
    "/api/developer/whitehat/resetMediationCooldown",
    "/api/exchange-rates",
    "/api/flags",
    "/api/flags/[flag]",
    "/api/managed-triage/request-access",
    "/api/marketing/all-stars",
    "/api/marketing/profile",
    "/api/marketing/projects/[slug]",
    "/api/me",
    "/api/me/contracts/[contractId]/document",
    "/api/me/credits",
    "/api/me/credits/purchase",
    "/api/me/dismiss-sr-onboarding",
    "/api/me/email-preferences",
    "/api/me/hunt-points",
    "/api/me/pay-to-verify",
    "/api/me/payments",
    "/api/me/payments/[id]/receipt",
    "/api/me/profile",
    "/api/me/profile/edit",
    "/api/me/profile/unlock",
    "/api/me/report-limit-status",
    "/api/me/request-verification",
    "/api/me/reward-wallet-selection",
    "/api/me/reward-wallet-selection/banner",
    "/api/me/session",
    "/api/me/submission-friction-status",
    "/api/me/submitted-reports",
    "/api/me/trusted-devices/details",
    "/api/me/trusted-devices/revoke",
    "/api/me/username",
    "/api/me/wallets",
    "/api/me/wallets/history",
    "/api/me/wallets/new",
    "/api/me/wallets/[id]/verify",
    "/api/projects",
    "/api/projects/[id]/boost-payments/process-results",
    "/api/projects/[id]/dismiss-audit-competition-conversion",
    "/api/projects/[id]/fee-percent",
    "/api/projects/[id]/mfa/has-trusted-devices",
    "/api/projects/[id]/mfa/revoke-trusted-devices",
    "/api/projects/[id]/mfa/toggle-allow-trusted-devices",
    "/api/projects/[id]/pagerduty",
    "/api/projects/[id]/pagerduty/connect",
    "/api/projects/[id]/pagerduty/disconnect",
    "/api/projects/[id]/pagerduty/test",
    "/api/projects/[id]/pending-vaults",
    "/api/projects/[id]/pending-vaults/new",
    "/api/projects/[id]/pending-vaults/[pendingVaultId]/delete",
    "/api/projects/[id]/pending-vaults/[pendingVaultId]/edit",
    "/api/projects/[id]/public-program-details",
    "/api/projects/[id]/reports",
    "/api/projects/[id]/reports/mark-as-read",
    "/api/projects/[id]/safe-harbor/activate",
    "/api/projects/[id]/safe-harbor/asset-history",
    "/api/projects/[id]/slack-webhook",
    "/api/projects/[id]/slack-webhook/test",
    "/api/projects/[id]/user",
    "/api/projects/[id]/vaults",
    "/api/projects/[id]/vaults/new",
    "/api/projects/[id]/vaults/[vaultId]",
    "/api/projects/[id]/vaults/[vaultId]/activate",
    "/api/public/programs",
    "/api/public/project-vaults",
    "/api/report-draft",
    "/api/report-draft/[id]",
    "/api/report-draft/[id]/submit",
    "/api/report-draft/[id]/submit-precheck",
    "/api/reports",
    "/api/reports/program-reports",
    "/api/reports/program-reports/immunefi-review",
    "/api/reports/program-reports/[id]/self-escalate",
    "/api/reports/safe-harbor/new",
    "/api/reports/[id]",
    "/api/reports/[id]/annotations",
    "/api/reports/[id]/assignee",
    "/api/reports/[id]/comments",
    "/api/reports/[id]/events",
    "/api/reports/[id]/events/read-receipt",
    "/api/reports/[id]/health",
    "/api/reports/[id]/kyc",
    "/api/reports/[id]/kyc-evidence",
    "/api/reports/[id]/mediation/new",
    "/api/reports/[id]/payments/new",
    "/api/reports/[id]/program-asset-owners",
    "/api/reports/[id]/quick-actions",
    "/api/reports/[id]/remind-verify-wallet-address",
    "/api/reports/[id]/reopen",
    "/api/reports/[id]/request-help",
    "/api/reports/[id]/subscribe",
    "/api/reports/[id]/unsubscribe",
    "/api/reports/[id]/update-severity",
    "/api/reports/[id]/update-status",
    "/api/reports/[id]/verify-wallet-address",
    "/api/session-login",
    "/api/settings/members/[id]",
    "/api/settings/project-groups",
    "/api/settings/project-groups/[id]/auth-methods",
    "/api/settings/projects",
    "/api/sign-out",
    "/api/sign-up",
    "/api/storage/avatar-upload-url",
    "/api/storage/report-attachment-upload-url",
    "/api/test/inngest-events",
    "/api/track",
    "/api/triaging/reports/[id]/attachment-download",
    "/api/triaging/reports/[id]/classify",
    "/api/triaging/reports/[id]/retry-triaging-agent-assessment",
    "/api/triaging/reports/[id]/self-subscribe",
    "/api/triaging/reports/[id]/to-markdown",
    "/api/triaging/reports/[id]/update-status",
    "/api/trpc/[trpc]",
    "/api/vaults-page",
    "/api/verify-email",
    "/api/webhooks/alchemy/splitter--pay-whitehat",
    "/api/whitehat-leaderboard",
    "/api/whitehat-leaderboard/v2",
    "/auth-action",
    "/authenticate",
    "/credits",
    "/dashboard",
    "/dashboard/disclosures/[id]",
    "/dashboard/new-submission",
    "/dashboard/new-submission/instant",
    "/dashboard/new-submission/safe-harbor/[projectSlug]",
    "/dashboard/new-submission/[id]",
    "/dashboard/new-submission/[id]/asset",
    "/dashboard/new-submission/[id]/report",
    "/dashboard/new-submission/[id]/review",
    "/dashboard/new-submission/[id]/severity",
    "/dashboard/new-submission/[id]/wallet-address",
    "/dashboard/submission/[id]",
    "/email-verification",
    "/invitations/[hash]",
    "/login/forgot-password",
    "/mfa-setup",
    "/password-reset",
    "/program-reports",
    "/recover-email",
    "/settings",
    "/settings/boost-payment",
    "/settings/email-preferences",
    "/settings/organization",
    "/settings/payments",
    "/settings/profile",
    "/settings/projects",
    "/settings/projects/[id]/boost-payment",
    "/settings/projects/[id]/safe-harbor",
    "/settings/projects/[id]/vault/new",
    "/settings/projects/[id]/vault/[vaultId]/activate",
    "/settings/safe-harbor",
    "/settings/wallets",
    "/signup",
    "/signup/verify-email",
    "/vaults"
  ]
};self.__BUILD_MANIFEST_CB && self.__BUILD_MANIFEST_CB()